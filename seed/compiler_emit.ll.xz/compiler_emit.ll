; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/emit:Emitter" = type { ptr, ptr, ptr, ptr, i1, i1, i1, i1, i1, i1, i1, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, { i64, ptr }, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, i1, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" = type { ptr, i64 }
%"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/cabi:Way" = type { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr } }
%"compiler/lower:Clone" = type { { i64, [2 x i64] }, i64, { i64, [2 x i64] }, i32 }
%"compiler/lower:Lowerer" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i32, i32, i64, i64, i64, i64, i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/mir:GenInfo", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64 }
%"compiler/mir:GenInfo" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr }, ptr, i32 }
%"compiler/mir:Fn" = type { { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/emit:fnEm" = type { ptr, ptr, { i64, [2 x i64] }, %"std/prelude/text:StringBuilder", %"std/prelude/text:StringBuilder", %"std/prelude/text:StringBuilder", i64, i64, i64, i32, i1, i1, i1, i1, i1, { i64, ptr }, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/text:StringBuilder", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, { i64, ptr }, i1 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"compiler/facts:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/facts:Table" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f" = type { i64, i1 }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/mir:Lvalue" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"compiler/mir:Local" = type { i32, %"compiler/source:Span", i32, i32, { i64, [1 x i64] } }
%"compiler/mir:ScopeInfo" = type { i32, i32, i32, %"compiler/source:Span", i32 }
%"compiler/mir:Task" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/source:Span", %"compiler/mir:Range" }
%"compiler/mir:Call" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Lvalue", i1, i32, i32, i32 }
%"compiler/mir:Case" = type { i64, i32 }
%"compiler/mir:BasicBlock" = type { %"compiler/mir:StmtList", { i64, [8 x i64] } }
%"compiler/mir:StmtList" = type { { i64, ptr }, i64 }
@G_2ecompiler_2femit_2eBigCloseMark = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\12\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2eBigCloseMark.k1 }>, align 8
@G_2ecompiler_2femit_2eBigCloseMark.k1 = internal constant <{ [18 x i8] }> <{ [18 x i8] c"\20\20\3B\6F\6C\61\6E\67\2E\62\69\67\63\6C\6F\73\65\0A" }>, align 8
@G_2ecompiler_2femit_2eHomeInst = constant <{ [8 x i8] }> <{ [8 x i8] c"\FD\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2femit_2eHomeLoc = constant <{ [8 x i8] }> <{ [8 x i8] c"\FC\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2femit_2eHomeLocal = constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2femit_2eHomeShared = constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2femit_2ePartSize = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\10\00\00\00\00\00" }>, align 8
@G_2ecompiler_2femit_2ePartSizeDev = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\08\00\00\00\00\00" }>, align 8
@G_2ecompiler_2femit_2ehexDigits = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2ehexDigits.k1 }>, align 8
@G_2ecompiler_2femit_2ehexDigits.k1 = internal global <{ [16 x i8] }> <{ [16 x i8] c"\30\31\32\33\34\35\36\37\38\39\41\42\43\44\45\46" }>, align 8
@G_2ecompiler_2femit_2emathExact = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [24 x i8] }> <{ [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k1, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k2, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k3, [24 x i8] c"\09\00\00\00\00\00\00\00\09\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 64
@G_2ecompiler_2femit_2emathExact.k1 = internal global <{ [8 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [176 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k4, [16 x i8] c"\01\00\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k5, [16 x i8] c"\01\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k6, [16 x i8] c"\01\00\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k7, [16 x i8] c"\01\00\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k8, [16 x i8] c"\01\00\00\00\00\00\00\00\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k9, [16 x i8] c"\01\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k10, [16 x i8] c"\01\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k11, [16 x i8] c"\02\00\00\00\00\00\00\00\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k12, [176 x i8] c"\03\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2femit_2emathExact.k2 = internal global <{ [128 x i8] }> <{ [128 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\05\00\00\00\00\00\00\00\03\00\00\00\00\00\00\00\06\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2femit_2emathExact.k3 = internal global <{ [128 x i8] }> <{ [128 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\07\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\08\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\04\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\01\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\00\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2femit_2emathExact.k4 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\73\71\72\74" }>, align 8
@G_2ecompiler_2femit_2emathExact.k5 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\66\6C\6F\6F\72" }>, align 8
@G_2ecompiler_2femit_2emathExact.k6 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\63\65\69\6C" }>, align 8
@G_2ecompiler_2femit_2emathExact.k7 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\74\72\75\6E\63" }>, align 8
@G_2ecompiler_2femit_2emathExact.k8 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\72\6F\75\6E\64" }>, align 8
@G_2ecompiler_2femit_2emathExact.k9 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\72\6F\75\6E\64\65\76\65\6E" }>, align 8
@G_2ecompiler_2femit_2emathExact.k10 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\66\61\62\73" }>, align 8
@G_2ecompiler_2femit_2emathExact.k11 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\63\6F\70\79\73\69\67\6E" }>, align 8
@G_2ecompiler_2femit_2emathExact.k12 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\66\6D\61" }>, align 8
@G_2ecompiler_2femit_2emathInexact = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [24 x i8] }> <{ [8 x i8] c"\40\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k1, [8 x i8] c"\40\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k2, [8 x i8] c"\40\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k3, [24 x i8] c"\2C\00\00\00\00\00\00\00\2C\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 64
@G_2ecompiler_2femit_2emathInexact.k1 = internal global <{ [8 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [488 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k4, [16 x i8] c"\01\00\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k5, [16 x i8] c"\01\00\00\00\00\00\00\00\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k6, [16 x i8] c"\01\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k7, [16 x i8] c"\01\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k8, [16 x i8] c"\01\00\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k9, [16 x i8] c"\01\00\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k10, [16 x i8] c"\01\00\00\00\00\00\00\00\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k11, [16 x i8] c"\01\00\00\00\00\00\00\00\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k12, [16 x i8] c"\01\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k13, [16 x i8] c"\01\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k14, [16 x i8] c"\01\00\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k15, [16 x i8] c"\01\00\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k16, [16 x i8] c"\01\00\00\00\00\00\00\00\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k17, [16 x i8] c"\01\00\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k18, [16 x i8] c"\01\00\00\00\00\00\00\00\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k19, [16 x i8] c"\01\00\00\00\00\00\00\00\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k20, [16 x i8] c"\01\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k21, [16 x i8] c"\01\00\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k22, [16 x i8] c"\01\00\00\00\00\00\00\00\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k23, [16 x i8] c"\01\00\00\00\00\00\00\00\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k24, [16 x i8] c"\01\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k25, [16 x i8] c"\01\00\00\00\00\00\00\00\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k26, [16 x i8] c"\01\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k27, [16 x i8] c"\01\00\00\00\00\00\00\00\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k28, [16 x i8] c"\01\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k29, [16 x i8] c"\01\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k30, [16 x i8] c"\01\00\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k31, [16 x i8] c"\01\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k32, [16 x i8] c"\01\00\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k33, [16 x i8] c"\01\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k34, [16 x i8] c"\01\00\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k35, [16 x i8] c"\01\00\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k36, [16 x i8] c"\01\00\00\00\00\00\00\00\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k37, [16 x i8] c"\01\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k38, [16 x i8] c"\01\00\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k39, [16 x i8] c"\01\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k40, [16 x i8] c"\01\00\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k41, [16 x i8] c"\01\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k42, [16 x i8] c"\01\00\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k43, [16 x i8] c"\01\00\00\00\00\00\00\00\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k44, [16 x i8] c"\01\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k45, [16 x i8] c"\01\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k46, [16 x i8] c"\01\00\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k47, [488 x i8] c"\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2femit_2emathInexact.k2 = internal global <{ [512 x i8] }> <{ [512 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\03\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\01\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\0C\00\00\00\00\00\00\00\0D\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\0A\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\08\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\04\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\1C\00\00\00\00\00\00\00\1D\00\00\00\00\00\00\00\16\00\00\00\00\00\00\00\17\00\00\00\00\00\00\00\0E\00\00\00\00\00\00\00\0F\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\11\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2femit_2emathInexact.k3 = internal global <{ [512 x i8] }> <{ [512 x i8] c"\1B\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\27\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\02\00\00\00\00\00\00\00\2A\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\0B\00\00\00\00\00\00\00\25\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\26\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\09\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\18\00\00\00\00\00\00\00\13\00\00\00\00\00\00\00\19\00\00\00\00\00\00\00\1F\00\00\00\00\00\00\00\24\00\00\00\00\00\00\00\2B\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\1E\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\29\00\00\00\00\00\00\00\21\00\00\00\00\00\00\00\07\00\00\00\00\00\00\00\12\00\00\00\00\00\00\00\1A\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\06\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\14\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\28\00\00\00\00\00\00\00\15\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\10\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\20\00\00\00\00\00\00\00\05\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\23\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\22\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2femit_2emathInexact.k4 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\63\62\72\74" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k5 = internal global <{ [5 x i8] }> <{ [5 x i8] c"\63\62\72\74\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k6 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\65\78\70" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k7 = internal global <{ [4 x i8] }> <{ [4 x i8] c"\65\78\70\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k8 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\65\78\70\32" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k9 = internal global <{ [5 x i8] }> <{ [5 x i8] c"\65\78\70\32\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k10 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\65\78\70\6D\31" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k11 = internal global <{ [6 x i8] }> <{ [6 x i8] c"\65\78\70\6D\31\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k12 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\6C\6F\67" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k13 = internal global <{ [4 x i8] }> <{ [4 x i8] c"\6C\6F\67\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k14 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\6C\6F\67\32" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k15 = internal global <{ [5 x i8] }> <{ [5 x i8] c"\6C\6F\67\32\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k16 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\6C\6F\67\31\30" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k17 = internal global <{ [6 x i8] }> <{ [6 x i8] c"\6C\6F\67\31\30\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k18 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\6C\6F\67\31\70" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k19 = internal global <{ [6 x i8] }> <{ [6 x i8] c"\6C\6F\67\31\70\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k20 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\70\6F\77" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k21 = internal global <{ [4 x i8] }> <{ [4 x i8] c"\70\6F\77\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k22 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\68\79\70\6F\74" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k23 = internal global <{ [6 x i8] }> <{ [6 x i8] c"\68\79\70\6F\74\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k24 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\73\69\6E" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k25 = internal global <{ [4 x i8] }> <{ [4 x i8] c"\73\69\6E\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k26 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\63\6F\73" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k27 = internal global <{ [4 x i8] }> <{ [4 x i8] c"\63\6F\73\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k28 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\74\61\6E" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k29 = internal global <{ [4 x i8] }> <{ [4 x i8] c"\74\61\6E\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k30 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\61\73\69\6E" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k31 = internal global <{ [5 x i8] }> <{ [5 x i8] c"\61\73\69\6E\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k32 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\61\63\6F\73" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k33 = internal global <{ [5 x i8] }> <{ [5 x i8] c"\61\63\6F\73\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k34 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\61\74\61\6E" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k35 = internal global <{ [5 x i8] }> <{ [5 x i8] c"\61\74\61\6E\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k36 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\61\74\61\6E\32" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k37 = internal global <{ [6 x i8] }> <{ [6 x i8] c"\61\74\61\6E\32\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k38 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\73\69\6E\68" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k39 = internal global <{ [5 x i8] }> <{ [5 x i8] c"\73\69\6E\68\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k40 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\63\6F\73\68" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k41 = internal global <{ [5 x i8] }> <{ [5 x i8] c"\63\6F\73\68\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k42 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\74\61\6E\68" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k43 = internal global <{ [5 x i8] }> <{ [5 x i8] c"\74\61\6E\68\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k44 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\65\72\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k45 = internal global <{ [4 x i8] }> <{ [4 x i8] c"\65\72\66\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k46 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\65\72\66\63" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k47 = internal global <{ [5 x i8] }> <{ [5 x i8] c"\65\72\66\63\66" }>, align 8
@G_2ecompiler_2femit_2etbaaElem = constant <{ [120 x i8] }> <{ [120 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\1F\00\00\00\00\00\00\00\51\00\00\00\00\00\00\00\52\00\00\00\00\00\00\00\21\00\00\00\00\00\00\00\22\00\00\00\00\00\00\00\20\00\00\00\00\00\00\00\53\00\00\00\00\00\00\00\54\00\00\00\00\00\00\00\55\00\00\00\00\00\00\00\56\00\00\00\00\00\00\00\57\00\00\00\00\00\00\00\23\00\00\00\00\00\00\00\24\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2femit_2etbaaField = constant <{ [120 x i8] }> <{ [120 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\15\00\00\00\00\00\00\00\3D\00\00\00\00\00\00\00\3E\00\00\00\00\00\00\00\17\00\00\00\00\00\00\00\18\00\00\00\00\00\00\00\16\00\00\00\00\00\00\00\3F\00\00\00\00\00\00\00\40\00\00\00\00\00\00\00\41\00\00\00\00\00\00\00\42\00\00\00\00\00\00\00\43\00\00\00\00\00\00\00\19\00\00\00\00\00\00\00\1A\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2femit_2etbaaName = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k1, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k2, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k3, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k4, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k5, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k6, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k7, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k8, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k9, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k10, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k11, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k12, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k13, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k14, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k15 }>, align 64
@G_2ecompiler_2femit_2etbaaName.k1 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2femit_2etbaaName.k2 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2femit_2etbaaName.k3 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\62\6F\6F\6C" }>, align 8
@G_2ecompiler_2femit_2etbaaName.k4 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\69\38" }>, align 8
@G_2ecompiler_2femit_2etbaaName.k5 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\69\31\36" }>, align 8
@G_2ecompiler_2femit_2etbaaName.k6 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\69\6E\74\33\32" }>, align 8
@G_2ecompiler_2femit_2etbaaName.k7 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\69\6E\74\36\34" }>, align 8
@G_2ecompiler_2femit_2etbaaName.k8 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\62\79\74\65" }>, align 8
@G_2ecompiler_2femit_2etbaaName.k9 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\75\31\36" }>, align 8
@G_2ecompiler_2femit_2etbaaName.k10 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\75\33\32" }>, align 8
@G_2ecompiler_2femit_2etbaaName.k11 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\75\36\34" }>, align 8
@G_2ecompiler_2femit_2etbaaName.k12 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\66\31\36" }>, align 8
@G_2ecompiler_2femit_2etbaaName.k13 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\62\66\31\36" }>, align 8
@G_2ecompiler_2femit_2etbaaName.k14 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\66\6C\6F\61\74\33\32" }>, align 8
@G_2ecompiler_2femit_2etbaaName.k15 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\66\6C\6F\61\74\36\34" }>, align 8
@G_2ecompiler_2femit_2etbaaTree = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\69\07\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaTree.k1 }>, align 8
@G_2ecompiler_2femit_2etbaaTree.k1 = internal constant <{ [1897 x i8] }> <{ [1897 x i8] c"\0A\21\32\30\20\3D\20\21\7B\21\22\6F\6C\61\6E\67\22\7D\0A\21\39\39\20\3D\20\21\7B\21\22\62\72\61\6E\63\68\5F\77\65\69\67\68\74\73\22\2C\20\69\33\32\20\31\2C\20\69\33\32\20\32\30\30\30\7D\0A\21\34\39\20\3D\20\21\7B\21\22\73\63\6F\70\65\68\64\72\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\35\30\20\3D\20\21\7B\21\22\63\68\75\6E\6B\68\64\72\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\35\39\20\3D\20\21\7B\21\34\39\2C\20\21\34\39\2C\20\69\36\34\20\30\7D\0A\21\36\30\20\3D\20\21\7B\21\35\30\2C\20\21\35\30\2C\20\69\36\34\20\30\7D\0A\21\31\37\20\3D\20\21\7B\21\22\61\72\72\61\79\64\65\73\63\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\31\38\20\3D\20\21\7B\21\22\63\6C\6F\73\75\72\65\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\34\37\20\3D\20\21\7B\21\22\61\72\72\61\79\64\65\73\63\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\31\39\20\3D\20\21\7B\21\22\72\65\66\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\34\38\20\3D\20\21\7B\21\22\72\65\66\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\32\39\20\3D\20\21\7B\21\31\39\2C\20\21\31\39\2C\20\69\36\34\20\30\7D\0A\21\33\39\20\3D\20\21\7B\21\34\38\2C\20\21\34\38\2C\20\69\36\34\20\30\7D\0A\21\32\37\20\3D\20\21\7B\21\31\37\2C\20\21\31\37\2C\20\69\36\34\20\30\7D\0A\21\32\38\20\3D\20\21\7B\21\31\38\2C\20\21\31\38\2C\20\69\36\34\20\30\7D\0A\21\33\37\20\3D\20\21\7B\21\34\37\2C\20\21\34\37\2C\20\69\36\34\20\30\7D\0A\21\31\31\20\3D\20\21\7B\21\22\62\6F\6F\6C\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\32\31\20\3D\20\21\7B\21\31\31\2C\20\21\31\31\2C\20\69\36\34\20\30\7D\0A\21\34\31\20\3D\20\21\7B\21\22\62\6F\6F\6C\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\33\31\20\3D\20\21\7B\21\34\31\2C\20\21\34\31\2C\20\69\36\34\20\30\7D\0A\21\35\31\20\3D\20\21\7B\21\22\69\38\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\36\31\20\3D\20\21\7B\21\35\31\2C\20\21\35\31\2C\20\69\36\34\20\30\7D\0A\21\39\31\20\3D\20\21\7B\21\22\69\38\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\38\31\20\3D\20\21\7B\21\39\31\2C\20\21\39\31\2C\20\69\36\34\20\30\7D\0A\21\35\32\20\3D\20\21\7B\21\22\69\31\36\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\36\32\20\3D\20\21\7B\21\35\32\2C\20\21\35\32\2C\20\69\36\34\20\30\7D\0A\21\39\32\20\3D\20\21\7B\21\22\69\31\36\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\38\32\20\3D\20\21\7B\21\39\32\2C\20\21\39\32\2C\20\69\36\34\20\30\7D\0A\21\31\33\20\3D\20\21\7B\21\22\69\6E\74\33\32\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\32\33\20\3D\20\21\7B\21\31\33\2C\20\21\31\33\2C\20\69\36\34\20\30\7D\0A\21\34\33\20\3D\20\21\7B\21\22\69\6E\74\33\32\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\33\33\20\3D\20\21\7B\21\34\33\2C\20\21\34\33\2C\20\69\36\34\20\30\7D\0A\21\31\34\20\3D\20\21\7B\21\22\69\6E\74\36\34\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\32\34\20\3D\20\21\7B\21\31\34\2C\20\21\31\34\2C\20\69\36\34\20\30\7D\0A\21\34\34\20\3D\20\21\7B\21\22\69\6E\74\36\34\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\33\34\20\3D\20\21\7B\21\34\34\2C\20\21\34\34\2C\20\69\36\34\20\30\7D\0A\21\31\32\20\3D\20\21\7B\21\22\62\79\74\65\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\32\32\20\3D\20\21\7B\21\31\32\2C\20\21\31\32\2C\20\69\36\34\20\30\7D\0A\21\34\32\20\3D\20\21\7B\21\22\62\79\74\65\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\33\32\20\3D\20\21\7B\21\34\32\2C\20\21\34\32\2C\20\69\36\34\20\30\7D\0A\21\35\33\20\3D\20\21\7B\21\22\75\31\36\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\36\33\20\3D\20\21\7B\21\35\33\2C\20\21\35\33\2C\20\69\36\34\20\30\7D\0A\21\39\33\20\3D\20\21\7B\21\22\75\31\36\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\38\33\20\3D\20\21\7B\21\39\33\2C\20\21\39\33\2C\20\69\36\34\20\30\7D\0A\21\35\34\20\3D\20\21\7B\21\22\75\33\32\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\36\34\20\3D\20\21\7B\21\35\34\2C\20\21\35\34\2C\20\69\36\34\20\30\7D\0A\21\39\34\20\3D\20\21\7B\21\22\75\33\32\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\38\34\20\3D\20\21\7B\21\39\34\2C\20\21\39\34\2C\20\69\36\34\20\30\7D\0A\21\35\35\20\3D\20\21\7B\21\22\75\36\34\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\36\35\20\3D\20\21\7B\21\35\35\2C\20\21\35\35\2C\20\69\36\34\20\30\7D\0A\21\39\35\20\3D\20\21\7B\21\22\75\36\34\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\38\35\20\3D\20\21\7B\21\39\35\2C\20\21\39\35\2C\20\69\36\34\20\30\7D\0A\21\35\36\20\3D\20\21\7B\21\22\66\31\36\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\36\36\20\3D\20\21\7B\21\35\36\2C\20\21\35\36\2C\20\69\36\34\20\30\7D\0A\21\39\36\20\3D\20\21\7B\21\22\66\31\36\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\38\36\20\3D\20\21\7B\21\39\36\2C\20\21\39\36\2C\20\69\36\34\20\30\7D\0A\21\35\37\20\3D\20\21\7B\21\22\62\66\31\36\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\36\37\20\3D\20\21\7B\21\35\37\2C\20\21\35\37\2C\20\69\36\34\20\30\7D\0A\21\39\37\20\3D\20\21\7B\21\22\62\66\31\36\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\38\37\20\3D\20\21\7B\21\39\37\2C\20\21\39\37\2C\20\69\36\34\20\30\7D\0A\21\31\35\20\3D\20\21\7B\21\22\66\6C\6F\61\74\33\32\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\32\35\20\3D\20\21\7B\21\31\35\2C\20\21\31\35\2C\20\69\36\34\20\30\7D\0A\21\34\35\20\3D\20\21\7B\21\22\66\6C\6F\61\74\33\32\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\33\35\20\3D\20\21\7B\21\34\35\2C\20\21\34\35\2C\20\69\36\34\20\30\7D\0A\21\31\36\20\3D\20\21\7B\21\22\66\6C\6F\61\74\36\34\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\32\36\20\3D\20\21\7B\21\31\36\2C\20\21\31\36\2C\20\69\36\34\20\30\7D\0A\21\34\36\20\3D\20\21\7B\21\22\66\6C\6F\61\74\36\34\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\33\36\20\3D\20\21\7B\21\34\36\2C\20\21\34\36\2C\20\69\36\34\20\30\7D\0A\0A" }>, align 64
define dso_local i64 @compiler_2femit_2ebmaskOf(i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %rv = alloca i64
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t3 = icmp sge i64 %t1, 64
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb3
bb2:
  %t5 = load i64, ptr %l0, !tbaa !24
  store i64 %t5, ptr %l4, !tbaa !24
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = shl i64 1, %t7
  %t10 = sub i64 %t8, 1
  store i64 %t10, ptr %l3, !tbaa !24
  br label %bb3
bb3:
  %t12 = load i64, ptr %l3, !tbaa !24
  store i64 %t12, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eabiDiffers(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l16 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i32
  %l24 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t9 = inttoptr i64 0 to ptr
  %t12 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %s0, ptr %t9, ptr %t6, i32 %t7)
  store { i64, ptr } %t12, ptr %l9
  br label %bb1
bb1:
  %t13 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l10, !tbaa !27
  %t20 = load ptr, ptr %l3, !tbaa !29
  %t21 = load i32, ptr %l2, !tbaa !23
  %t23 = inttoptr i64 0 to ptr
  %t26 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %s0, ptr %t23, ptr %t20, i32 %t21)
  store { i64, ptr } %t26, ptr %l14
  br label %bb2
bb2:
  %t27 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t27, 0
  %t29 = extractvalue { i64, ptr } %t27, 1
  %t30 = mul i64 %t28, 1
  %t31 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t30)
  call void @llvm.memcpy.p0.p0.i64(ptr %t31, ptr %t29, i64 %t30, i1 false)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  %t34 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t36 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t34, { i64, ptr } %t33)
  store i1 %t36, ptr %l16
  br label %bb3
bb3:
  %t37 = load i1, ptr %l16, !tbaa !21
  %t38 = xor i1 %t37, true
  br i1 %t38, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb8
bb5:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t41 = load i32, ptr %l1, !tbaa !23
  %t44 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t40, i32 %t41)
  store i32 %t44, ptr %l21
  br label %bb6
bb6:
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t46 = load i32, ptr %l2, !tbaa !23
  %t49 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t45, i32 %t46)
  store i32 %t49, ptr %l24
  br label %bb7
bb7:
  %t50 = load i32, ptr %l21, !tbaa !23
  %t51 = load i32, ptr %l24, !tbaa !23
  %t52 = icmp ne i32 %t50, %t51
  store i1 %t52, ptr %l18, !tbaa !21
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t54 = load i1, ptr %l18, !tbaa !21
  store i1 %t54, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eassemble(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, i1 %a2, i64 %a3, i64 %a4, ptr %a5, i64 %a6, ptr %a7, i64 %a8) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca %"std/prelude/text:StringBuilder"
  %l26 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l29 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l30 = alloca i1
  %l31 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l32 = alloca %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0"
  %l33 = alloca i64
  %l34 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca %"std/prelude/text:StringBuilder"
  %l52 = alloca ptr
  %l53 = alloca i64
  %l55 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l56 = alloca ptr
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca i64
  %l63 = alloca { i64, ptr }
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca { i64, ptr }
  %l72 = alloca i64
  %l73 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l76 = alloca i64
  %l80 = alloca i64
  %l83 = alloca i64
  %l104 = alloca i64
  %l108 = alloca i1
  %l110 = alloca i1
  %l114 = alloca i1
  %l117 = alloca i1
  %l120 = alloca i64
  %l123 = alloca i1
  %l126 = alloca i1
  %l129 = alloca i64
  %l132 = alloca i1
  %l136 = alloca i64
  %l146 = alloca { i64, ptr }
  %l150 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l151 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l159 = alloca { i64, ptr }
  %l168 = alloca %"std/prelude/text:StringBuilder"
  %l169 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l170 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l171 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l172 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l174 = alloca i1
  %l178 = alloca i1
  %l181 = alloca i64
  %l186 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l187 = alloca %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0"
  %l189 = alloca %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0"
  %l190 = alloca i32
  %l192 = alloca i1
  %l193 = alloca ptr
  %l194 = alloca i64
  %l195 = alloca i64
  %l200 = alloca { i64, ptr }
  %l203 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l204 = alloca i64
  %l206 = alloca i64
  %l211 = alloca i64
  %l215 = alloca i1
  %l219 = alloca i1
  %l220 = alloca i64
  %l224 = alloca i64
  %l225 = alloca i32
  %l229 = alloca i1
  %l233 = alloca { i64, ptr }
  %l234 = alloca ptr
  %l235 = alloca i64
  %l236 = alloca i64
  %l247 = alloca i1
  %l249 = alloca i1
  %l252 = alloca i1
  %l256 = alloca ptr
  %l260 = alloca { i64, ptr }
  %l261 = alloca ptr
  %l265 = alloca { i64, ptr }
  %l271 = alloca { i64, ptr }
  %l274 = alloca { i64, ptr }
  %l280 = alloca i64
  %l283 = alloca i64
  %l301 = alloca { i64, ptr }
  %l302 = alloca { i64, ptr }
  %l305 = alloca i64
  %l306 = alloca { i64, ptr }
  %l309 = alloca i64
  %l310 = alloca i64
  %l315 = alloca { i64, ptr }
  %l319 = alloca i64
  %l323 = alloca i64
  %l324 = alloca i32
  %l327 = alloca i1
  %l330 = alloca i1
  %l338 = alloca i64
  %l340 = alloca i1
  %l343 = alloca i64
  %l347 = alloca i64
  %l348 = alloca i32
  %l352 = alloca i1
  %l355 = alloca i1
  %l356 = alloca i1
  %l359 = alloca i1
  %l363 = alloca i64
  %l367 = alloca i1
  %l378 = alloca ptr
  %l379 = alloca i64
  %l380 = alloca i64
  %l385 = alloca { i64, ptr }
  %l386 = alloca { i64, ptr }
  %l394 = alloca ptr
  %l398 = alloca { i64, ptr }
  %l399 = alloca ptr
  %l403 = alloca { i64, ptr }
  %l409 = alloca i1
  %l413 = alloca ptr
  %l414 = alloca i64
  %l419 = alloca { i64, ptr }
  %l425 = alloca i1
  %l433 = alloca %"std/prelude/text:StringBuilder"
  %l434 = alloca ptr
  %l436 = alloca { i64, ptr }
  %l442 = alloca i64
  %l444 = alloca i64
  %l449 = alloca i64
  %l450 = alloca ptr
  %l454 = alloca { i64, ptr }
  %l457 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l459 = alloca i64
  %l461 = alloca i64
  %l466 = alloca i64
  %l468 = alloca i1
  %l472 = alloca i1
  %l473 = alloca i64
  %l477 = alloca i64
  %l478 = alloca i32
  %l482 = alloca i1
  %l484 = alloca ptr
  %l485 = alloca { i64, ptr }
  %l488 = alloca { i64, ptr }
  %l489 = alloca i32
  %l490 = alloca { i64, ptr }
  %l494 = alloca { i64, ptr }
  %l495 = alloca i32
  %l496 = alloca ptr
  %l500 = alloca { i64, ptr }
  %l501 = alloca { i64, ptr }
  %l505 = alloca { i64, ptr }
  %l511 = alloca { i64, ptr }
  %l513 = alloca i64
  %l515 = alloca i1
  %l517 = alloca i1
  %l523 = alloca { i64, ptr }
  %l529 = alloca i64
  %l532 = alloca i64
  %l550 = alloca { i64, ptr }
  %l554 = alloca i64
  %l555 = alloca { i64, ptr }
  %l556 = alloca { i64, ptr }
  %l560 = alloca i64
  %l561 = alloca { i64, ptr }
  %l564 = alloca i64
  %l565 = alloca i64
  %l569 = alloca { i64, ptr }
  %l570 = alloca i64
  %l571 = alloca i32
  %l572 = alloca i64
  %l573 = alloca i32
  %l576 = alloca ptr
  %l577 = alloca { i64, ptr }
  %l578 = alloca i64
  %l579 = alloca { i64, ptr }
  %l582 = alloca i64
  %l583 = alloca i64
  %l588 = alloca ptr
  %l591 = alloca i64
  %l594 = alloca { i64, ptr }
  %l598 = alloca { i64, ptr }
  %l602 = alloca { i64, ptr }
  %l603 = alloca { i64, ptr }
  %l606 = alloca i64
  %l607 = alloca { i64, ptr }
  %l610 = alloca i64
  %l611 = alloca i64
  %l618 = alloca i64
  %l621 = alloca i1
  %l624 = alloca i1
  %l626 = alloca ptr
  %l627 = alloca { i64, ptr }
  %l628 = alloca i64
  %l629 = alloca { i64, ptr }
  %l632 = alloca i64
  %l633 = alloca i64
  %l638 = alloca ptr
  %l639 = alloca { i64, ptr }
  %l642 = alloca { i64, ptr }
  %l643 = alloca i32
  %l644 = alloca ptr
  %l645 = alloca { i64, ptr }
  %l649 = alloca { i64, ptr }
  %l650 = alloca i64
  %l653 = alloca i64
  %l654 = alloca i64
  %l659 = alloca { i64, ptr }
  %l665 = alloca ptr
  %l666 = alloca { i64, ptr }
  %l667 = alloca i64
  %l670 = alloca i64
  %l671 = alloca i64
  %l678 = alloca ptr
  %l680 = alloca { i64, ptr }
  %l685 = alloca i1
  %l689 = alloca i1
  %l690 = alloca ptr
  %l694 = alloca i64
  %l695 = alloca { i64, ptr }
  %l697 = alloca ptr
  %l699 = alloca { i64, ptr }
  %l702 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %s48 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t142 = alloca { ptr, ptr }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i1 %a2, ptr %l2
  store ptr %a5, ptr %l5
  store i64 %a6, ptr %l6
  store ptr %a7, ptr %l7
  store i64 %a8, ptr %l8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l73
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l73
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l9
  store i64 0, ptr %l10, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/emit:Emitter", ptr %t3, i32 0, i32 18
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t5)
  store i64 %t7, ptr %l76
  br label %bb2
bb2:
  %t8 = load i64, ptr %l76, !tbaa !24
  store i64 %t8, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t9 = load i64, ptr %l11, !tbaa !24
  %t10 = load i64, ptr %l10, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load i64, ptr %l12, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l80, !tbaa !24
  br label %bb8
bb5:
  %t19 = load i64, ptr %l11, !tbaa !24
  %t20 = load i64, ptr %l10, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l12, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l12, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l83, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l83, !tbaa !24
  br label %bb7
bb7:
  %t35 = load i64, ptr %l83, !tbaa !24
  store i64 %t35, ptr %l80, !tbaa !24
  br label %bb8
bb8:
  %t36 = load i64, ptr %l80, !tbaa !24
  store i64 %t36, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb9
bb9:
  %t37 = load i64, ptr %l14, !tbaa !24
  %t38 = load i64, ptr %l13, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb10, label %bb11
bb10:
  br label %bb43
bb11:
  br label %bb12
bb12:
  %t45 = load i64, ptr %l10, !tbaa !24
  %t46 = load i64, ptr %l14, !tbaa !24
  %t47 = load i64, ptr %l12, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l15, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/emit:Emitter", ptr %t55, i32 0, i32 20
  %t58 = load i64, ptr %l15, !tbaa !24
  %t61 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t57, i64 %t58)
  store i64 %t61, ptr %l104
  br label %bb13
bb13:
  %t62 = load i64, ptr %l104, !tbaa !24
  store i64 %t62, ptr %l16, !tbaa !24
  %t63 = load i64, ptr %l16, !tbaa !24
  %t64 = load i64, ptr %l1, !tbaa !24
  %t67 = icmp eq i64 %t63, %t64
  br i1 %t67, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l108, !tbaa !21
  br label %bb19
bb15:
  %t69 = load i1, ptr %l2, !tbaa !21
  br i1 %t69, label %bb16, label %bb17
bb16:
  %t71 = load i64, ptr %l16, !tbaa !24
  %t72 = load i64, ptr @G_2ecompiler_2femit_2eHomeInst, !tbaa !24
  %t75 = icmp eq i64 %t71, %t72
  store i1 %t75, ptr %l110, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l110, !tbaa !21
  br label %bb18
bb18:
  %t77 = load i1, ptr %l110, !tbaa !21
  store i1 %t77, ptr %l108, !tbaa !21
  br label %bb19
bb19:
  %t78 = load i1, ptr %l108, !tbaa !21
  br i1 %t78, label %bb20, label %bb21
bb20:
  %t79 = load i64, ptr %l6, !tbaa !24
  %t81 = icmp slt i64 %t79, 0
  br i1 %t81, label %bb22, label %bb23
bb21:
  store i1 false, ptr %l114, !tbaa !21
  br label %bb26
bb22:
  store i1 true, ptr %l117, !tbaa !21
  br label %bb25
bb23:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i64, ptr %l15, !tbaa !24
  %t87 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2egroupOf(ptr %v0, ptr %t83, i64 %t84)
  store i64 %t87, ptr %l120
  br label %bb24
bb24:
  %t88 = load i64, ptr %l6, !tbaa !24
  %t89 = load i64, ptr %l120, !tbaa !24
  %t91 = icmp eq i64 %t89, %t88
  store i1 %t91, ptr %l117, !tbaa !21
  br label %bb25
bb25:
  %t93 = load i1, ptr %l117, !tbaa !21
  store i1 %t93, ptr %l114, !tbaa !21
  br label %bb26
bb26:
  %t94 = load i1, ptr %l114, !tbaa !21
  br i1 %t94, label %bb27, label %bb28
bb27:
  %t95 = load i64, ptr %l8, !tbaa !24
  %t97 = icmp slt i64 %t95, 0
  br i1 %t97, label %bb29, label %bb30
bb28:
  store i1 false, ptr %l123, !tbaa !21
  br label %bb33
bb29:
  store i1 true, ptr %l126, !tbaa !21
  br label %bb32
bb30:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load i64, ptr %l15, !tbaa !24
  %t103 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2einstGroupOf(ptr %v0, ptr %t99, i64 %t100)
  store i64 %t103, ptr %l129
  br label %bb31
bb31:
  %t104 = load i64, ptr %l8, !tbaa !24
  %t105 = load i64, ptr %l129, !tbaa !24
  %t107 = icmp eq i64 %t105, %t104
  store i1 %t107, ptr %l126, !tbaa !21
  br label %bb32
bb32:
  %t109 = load i1, ptr %l126, !tbaa !21
  store i1 %t109, ptr %l123, !tbaa !21
  br label %bb33
bb33:
  %t110 = load i1, ptr %l123, !tbaa !21
  br i1 %t110, label %bb34, label %bb35
bb34:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load i64, ptr %l15, !tbaa !24
  %t117 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2epartOf(ptr %v0, ptr %t111, i64 %t112, i64 %a4)
  store i64 %t117, ptr %l136
  br label %bb36
bb35:
  store i1 false, ptr %l132, !tbaa !21
  br label %bb37
bb36:
  %t119 = load i64, ptr %l136, !tbaa !24
  %t121 = icmp eq i64 %t119, %a3
  store i1 %t121, ptr %l132, !tbaa !21
  br label %bb37
bb37:
  %t123 = load i1, ptr %l132, !tbaa !21
  br i1 %t123, label %bb38, label %bb39
bb38:
  %t124 = load i64, ptr %l15, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l9, i64 %t124)
  br label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t127 = load i64, ptr %l14, !tbaa !24
  %t129 = add i64 %t127, 1
  store i64 %t129, ptr %l14, !tbaa !24
  br label %bb9
bb43:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/emit:Emitter", ptr %t131, i32 0, i32 18
  store ptr %t133, ptr %l17, !tbaa !29
  %t136 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s0, ptr %l9)
  store { i64, ptr } %t136, ptr %l146
  br label %bb44
bb44:
  %t137 = load { i64, ptr }, ptr %l146, !tbaa !27
  store { i64, ptr } %t137, ptr %l18, !tbaa !27
  %t138 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t139 = load ptr, ptr %l17, !tbaa !29
  %t140 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t141 = ptrtoint ptr %t140 to i64
  %t143 = getelementptr { ptr, ptr }, ptr %t142, i32 0, i32 0
  store ptr %t139, ptr %t143, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t145 = getelementptr { ptr, ptr }, ptr %t142, i32 0, i32 1
  store ptr %v0, ptr %t145, !tbaa !28
  %t146 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_0, 0
  %t147 = insertvalue { ptr, ptr } %t146, ptr %t142, 1
  %t150 = extractvalue { ptr, ptr } %t147, 0
  %t151 = extractvalue { ptr, ptr } %t147, 1
  call void @std_2fprelude_2farray_2eArray_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %s0, ptr %s0, { i64, ptr } %t138, ptr %t150, ptr %t151)
  br label %bb45
bb45:
  %t152 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t152, ptr %l150
  br label %bb46
bb46:
  %t153 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l150
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t153, ptr %l19
  %t154 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t154, ptr %l151
  br label %bb47
bb47:
  %t155 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l151
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t155, ptr %l20
  %t156 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t156, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t158 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t158, 0
  store i64 %t160, ptr %l23, !tbaa !24
  br label %bb48
bb48:
  %t162 = load i64, ptr %l22, !tbaa !24
  %t163 = load i64, ptr %l23, !tbaa !24
  %t166 = icmp slt i64 %t162, %t163
  %t168 = xor i1 %t166, true
  br i1 %t168, label %bb49, label %bb50
bb49:
  br label %bb55
bb50:
  br label %bb51
bb51:
  %t170 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t170, ptr %l159, !tbaa !27
  %t171 = load i64, ptr %l22, !tbaa !24
  %t173 = getelementptr { i64, ptr }, ptr %l159, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !27
  %t175 = getelementptr i64, ptr %t174, i64 %t171
  %t176 = load i64, ptr %t175, !tbaa !34
  store i64 %t176, ptr %l24, !tbaa !24
  %t178 = load i64, ptr %l24, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l19, i64 %t178)
  br label %bb52
bb52:
  %t181 = load i64, ptr %l24, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s0, ptr %l20, i64 %t181, i1 true)
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t184 = load i64, ptr %l22, !tbaa !24
  %t186 = add i64 %t184, 1
  store i64 %t186, ptr %l22, !tbaa !24
  br label %bb48
bb55:
  %t188 = call %"std/prelude/text:StringBuilder" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t188, ptr %l168
  br label %bb56
bb56:
  %t189 = load %"std/prelude/text:StringBuilder", ptr %l168
  store %"std/prelude/text:StringBuilder" %t189, ptr %l25
  %t190 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t190, ptr %l169
  br label %bb57
bb57:
  %t191 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l169
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t191, ptr %l26
  %t192 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t192, ptr %l170
  br label %bb58
bb58:
  %t193 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l170
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t193, ptr %l27
  %t194 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t194, ptr %l171
  br label %bb59
bb59:
  %t195 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l171
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t195, ptr %l28
  %t196 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t196, ptr %l172
  br label %bb60
bb60:
  %t197 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l172
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t197, ptr %l29
  %t198 = load i1, ptr %l2, !tbaa !21
  br i1 %t198, label %bb61, label %bb62
bb61:
  store i1 true, ptr %l174, !tbaa !21
  br label %bb63
bb62:
  %t200 = load i64, ptr %l1, !tbaa !24
  %t201 = load i64, ptr @G_2ecompiler_2femit_2eHomeInst, !tbaa !24
  %t204 = icmp eq i64 %t200, %t201
  store i1 %t204, ptr %l174, !tbaa !21
  br label %bb63
bb63:
  %t206 = load i1, ptr %l174, !tbaa !21
  br i1 %t206, label %bb64, label %bb65
bb64:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t209 = getelementptr %"compiler/emit:Emitter", ptr %t207, i32 0, i32 75
  %t211 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eLen_3cI64_2c_20I64_3e(ptr %v0, ptr %t209)
  store i64 %t211, ptr %l181
  br label %bb66
bb65:
  store i1 false, ptr %l178, !tbaa !21
  br label %bb67
bb66:
  %t212 = load i64, ptr %l181, !tbaa !24
  %t213 = icmp sgt i64 %t212, 0
  store i1 %t213, ptr %l178, !tbaa !21
  br label %bb67
bb67:
  %t215 = load i1, ptr %l178, !tbaa !21
  store i1 %t215, ptr %l30, !tbaa !21
  %t216 = load i1, ptr %l30, !tbaa !21
  br i1 %t216, label %bb68, label %bb69
bb68:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t220 = getelementptr %"compiler/emit:Emitter", ptr %t218, i32 0, i32 75
  %t222 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eIter_3cI64_2c_20I64_3e(ptr %v0, ptr %v0, ptr %t220)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t222, ptr %l186
  br label %bb70
bb69:
  br label %bb82
bb70:
  %t223 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l186
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t223, ptr %l31
  br label %bb71
bb71:
  store %olang.scope zeroinitializer, ptr %s10
  %t225 = call { i32, %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cI64_2c_20I64_3e_2eNext_3cI64_2c_20I64_3e(ptr %v0, ptr %l31)
  %t226 = extractvalue { i32, %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" } %t225, 1
  %t227 = extractvalue { i32, %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" } %t225, 0
  store i32 %t227, ptr %l190
  %t228 = icmp ne i32 %t227, 0
  br i1 %t228, label %bb73, label %ok.229, !prof !99
ok.229:
  store %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" %t226, ptr %l189
  br label %bb72
bb72:
  %t230 = load %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0", ptr %l189
  store %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" %t230, ptr %l187
  br label %bb75
bb73:
  %t231 = load i32, ptr %l190, !tbaa !23
  %t232 = ashr i32 %t231, 16
  %t234 = icmp eq i32 %t232, 1
  store i1 %t234, ptr %l192, !tbaa !21
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s10)
  br label %bb81
bb75:
  %t235 = load %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0", ptr %l187
  store %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" %t235, ptr %l32
  store ptr %l29, ptr %l193, !tbaa !29
  %t236 = getelementptr %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0", ptr %l32, i32 0, i32 0
  %t237 = load i64, ptr %t236, !tbaa !24
  store i64 %t237, ptr %l194, !tbaa !24
  %t238 = ptrtoint ptr %s0 to i64
  store i64 %t238, ptr %l195, !tbaa !24
  %t239 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2e1
  br i1 %t239, label %bb76, label %bb77
bb76:
  %t241 = call ptr @__olang_region_make(ptr %s0)
  %t242 = ptrtoint ptr %t241 to i64
  store i64 %t242, ptr %l195, !tbaa !24
  br label %bb77
bb77:
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t245 = getelementptr %"compiler/emit:Emitter", ptr %t243, i32 0, i32 18
  %t246 = getelementptr %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0", ptr %l32, i32 0, i32 1
  %t247 = load i64, ptr %t246, !tbaa !24
  %t250 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s10, ptr %t245, i64 %t247)
  store { i64, ptr } %t250, ptr %l200
  br label %bb78
bb78:
  %t251 = load { i64, ptr }, ptr %l200, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t251, 1
  %t253 = extractvalue { i64, ptr } %t251, 0
  %t254 = load i64, ptr %l195
  %t255 = inttoptr i64 %t254 to ptr
  %t256 = call ptr @__olang_scope_alloc(ptr %t255, i64 %t253)
  call void @olang_textcopy(ptr %t256, ptr %t252, i64 %t253)
  %t257 = insertvalue { i64, ptr } undef, i64 %t253, 0
  %t258 = insertvalue { i64, ptr } %t257, ptr %t256, 1
  %t260 = load i64, ptr %l195
  %t261 = inttoptr i64 %t260 to ptr
  %t262 = extractvalue { i64, ptr } %t258, 0
  %t263 = extractvalue { i64, ptr } %t258, 1
  %t264 = mul i64 %t262, 1
  %t265 = call ptr @__olang_scope_alloc(ptr %t261, i64 %t264)
  call void @llvm.memcpy.p0.p0.i64(ptr %t265, ptr %t263, i64 %t264, i1 false)
  %t266 = insertvalue { i64, ptr } undef, i64 %t262, 0
  %t267 = insertvalue { i64, ptr } %t266, ptr %t265, 1
  %t268 = load ptr, ptr %l193, !tbaa !29
  %t269 = load i64, ptr %l194, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Hc3dff1927e5c626a9d95abfdf4e9a462(ptr %s0, ptr %s0, ptr %t268, i64 %t269, { i64, ptr } %t267)
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s10)
  br label %bb80
bb80:
  br label %bb71
bb81:
  br label %bb82
bb82:
  store i64 0, ptr %l33, !tbaa !24
  %t271 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t271, ptr %l203
  br label %bb83
bb83:
  %t272 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l203
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t272, ptr %l34
  store i64 0, ptr %l35, !tbaa !24
  br label %bb84
bb84:
  %t273 = load i64, ptr %l35, !tbaa !24
  store i64 %t273, ptr %l204, !tbaa !24
  %t275 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l19)
  store i64 %t275, ptr %l206
  br label %bb85
bb85:
  %t276 = load i64, ptr %l204, !tbaa !24
  %t277 = load i64, ptr %l206, !tbaa !24
  %t278 = icmp slt i64 %t276, %t277
  %t280 = xor i1 %t278, true
  br i1 %t280, label %bb86, label %bb87
bb86:
  br label %bb220
bb87:
  br label %bb88
bb88:
  %t282 = load i64, ptr %l35, !tbaa !24
  %t285 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l19, i64 %t282)
  store i64 %t285, ptr %l211
  br label %bb89
bb89:
  %t286 = load i64, ptr %l211, !tbaa !24
  store i64 %t286, ptr %l36, !tbaa !24
  %t287 = load i64, ptr %l35, !tbaa !24
  %t289 = add i64 %t287, 1
  store i64 %t289, ptr %l35, !tbaa !24
  %t291 = load i1, ptr %l30, !tbaa !21
  br i1 %t291, label %bb90, label %bb91
bb90:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = getelementptr %"compiler/emit:Emitter", ptr %t293, i32 0, i32 75
  %t296 = load i64, ptr %l36, !tbaa !24
  %t299 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t295, i64 %t296)
  store i1 %t299, ptr %l219
  br label %bb92
bb91:
  store i1 false, ptr %l215, !tbaa !21
  br label %bb93
bb92:
  %t300 = load i1, ptr %l219, !tbaa !21
  store i1 %t300, ptr %l215, !tbaa !21
  br label %bb93
bb93:
  %t301 = load i1, ptr %l215, !tbaa !21
  br i1 %t301, label %bb94, label %bb95
bb94:
  store %olang.scope zeroinitializer, ptr %s13
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t304 = getelementptr %"compiler/emit:Emitter", ptr %t302, i32 0, i32 75
  %t305 = load i64, ptr %l36, !tbaa !24
  %t308 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t304, i64 %t305)
  %t309 = extractvalue { i32, i64 } %t308, 1
  %t310 = extractvalue { i32, i64 } %t308, 0
  store i32 %t310, ptr %l225
  %t311 = icmp ne i32 %t310, 0
  br i1 %t311, label %bb97, label %ok.312, !prof !99
ok.312:
  store i64 %t309, ptr %l224
  br label %bb96
bb95:
  br label %bb122
bb96:
  %t313 = load i64, ptr %l224, !tbaa !24
  store i64 %t313, ptr %l220, !tbaa !24
  br label %bb99
bb97:
  br label %bb98
bb98:
  %t314 = load i64, ptr %l36, !tbaa !24
  store i64 %t314, ptr %l220, !tbaa !24
  br label %bb99
bb99:
  %t316 = load i64, ptr %l220, !tbaa !24
  store i64 %t316, ptr %l37, !tbaa !24
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t318 = load i64, ptr %l36, !tbaa !24
  %t321 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ealiased(ptr %v0, ptr %t317, i64 %t318)
  store i1 %t321, ptr %l229
  br label %bb100
bb100:
  %t322 = load i1, ptr %l229, !tbaa !21
  br i1 %t322, label %bb101, label %bb102
bb101:
  call void @__olang_scope_close(ptr %s13)
  br label %bb219
bb102:
  br label %bb103
bb103:
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = load i64, ptr %l36, !tbaa !24
  %t325 = load i64, ptr %l37, !tbaa !24
  %t329 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewrapper(ptr %v0, ptr %s13, ptr %t323, i64 %t324, i64 %t325)
  store { i64, ptr } %t329, ptr %l233
  br label %bb104
bb104:
  %t330 = load { i64, ptr }, ptr %l233, !tbaa !27
  store { i64, ptr } %t330, ptr %l38, !tbaa !27
  store ptr %l34, ptr %l234, !tbaa !29
  %t331 = load i64, ptr %l36, !tbaa !24
  store i64 %t331, ptr %l235, !tbaa !24
  %t332 = ptrtoint ptr %s0 to i64
  store i64 %t332, ptr %l236, !tbaa !24
  %t333 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2e1
  br i1 %t333, label %bb105, label %bb106
bb105:
  %t335 = call ptr @__olang_region_make(ptr %s0)
  %t336 = ptrtoint ptr %t335 to i64
  store i64 %t336, ptr %l236, !tbaa !24
  br label %bb106
bb106:
  %t337 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t339 = extractvalue { i64, ptr } %t337, 1
  %t340 = extractvalue { i64, ptr } %t337, 0
  %t341 = load i64, ptr %l236
  %t342 = inttoptr i64 %t341 to ptr
  %t343 = call ptr @__olang_scope_alloc(ptr %t342, i64 %t340)
  call void @olang_textcopy(ptr %t343, ptr %t339, i64 %t340)
  %t344 = insertvalue { i64, ptr } undef, i64 %t340, 0
  %t345 = insertvalue { i64, ptr } %t344, ptr %t343, 1
  %t347 = load i64, ptr %l236
  %t348 = inttoptr i64 %t347 to ptr
  %t349 = extractvalue { i64, ptr } %t345, 0
  %t350 = extractvalue { i64, ptr } %t345, 1
  %t351 = mul i64 %t349, 1
  %t352 = call ptr @__olang_scope_alloc(ptr %t348, i64 %t351)
  call void @llvm.memcpy.p0.p0.i64(ptr %t352, ptr %t350, i64 %t351, i1 false)
  %t353 = insertvalue { i64, ptr } undef, i64 %t349, 0
  %t354 = insertvalue { i64, ptr } %t353, ptr %t352, 1
  %t355 = load ptr, ptr %l234, !tbaa !29
  %t356 = load i64, ptr %l235, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Hc3dff1927e5c626a9d95abfdf4e9a462(ptr %s0, ptr %s0, ptr %t355, i64 %t356, { i64, ptr } %t354)
  br label %bb107
bb107:
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t359 = load { i64, ptr }, ptr %l38, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2etypesNamedIn(ptr %v0, ptr %s13, ptr %s0, ptr %s0, ptr %t358, { i64, ptr } %t359, ptr %l27, ptr %l28)
  br label %bb108
bb108:
  %t364 = load i64, ptr %l37, !tbaa !24
  %t367 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %l20, i64 %t364)
  store i1 %t367, ptr %l247
  br label %bb109
bb109:
  %t368 = load i1, ptr %l247, !tbaa !21
  %t369 = xor i1 %t368, true
  br i1 %t369, label %bb110, label %bb111
bb110:
  %t371 = load i64, ptr %l37, !tbaa !24
  %t374 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %l26, i64 %t371)
  store i1 %t374, ptr %l252
  br label %bb112
bb111:
  store i1 false, ptr %l249, !tbaa !21
  br label %bb113
bb112:
  %t375 = load i1, ptr %l252, !tbaa !21
  %t376 = xor i1 %t375, true
  store i1 %t376, ptr %l249, !tbaa !21
  br label %bb113
bb113:
  %t378 = load i1, ptr %l249, !tbaa !21
  br i1 %t378, label %bb114, label %bb115
bb114:
  %t379 = load i64, ptr %l37, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s0, ptr %l26, i64 %t379, i1 true)
  br label %bb116
bb115:
  br label %bb121
bb116:
  store ptr %l25, ptr %l256, !tbaa !29
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t384 = getelementptr %"compiler/emit:Emitter", ptr %t382, i32 0, i32 21
  %t385 = load i64, ptr %l37, !tbaa !24
  %t388 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t384, i64 %t385)
  store { i64, ptr } %t388, ptr %l260
  br label %bb117
bb117:
  %t389 = load ptr, ptr %l256, !tbaa !29
  %t390 = load { i64, ptr }, ptr %l260, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t389, { i64, ptr } %t390)
  br label %bb118
bb118:
  %t391 = load ptr, ptr %l0, !tbaa !29
  store ptr %t391, ptr %l261, !tbaa !29
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t394 = getelementptr %"compiler/emit:Emitter", ptr %t392, i32 0, i32 21
  %t395 = load i64, ptr %l37, !tbaa !24
  %t398 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t394, i64 %t395)
  store { i64, ptr } %t398, ptr %l265
  br label %bb119
bb119:
  %t399 = load ptr, ptr %l261, !tbaa !29
  %t400 = load { i64, ptr }, ptr %l265, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclTypes(ptr %v0, ptr %v0, ptr %s0, ptr %s0, ptr %t399, { i64, ptr } %t400, ptr %l27, ptr %l28)
  br label %bb120
bb120:
  br label %bb121
bb121:
  call void @__olang_scope_close(ptr %s13)
  br label %bb219
bb122:
  %t403 = load ptr, ptr %l0, !tbaa !29
  %t405 = getelementptr %"compiler/emit:Emitter", ptr %t403, i32 0, i32 19
  %t406 = load i64, ptr %l36, !tbaa !24
  %t409 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t405, i64 %t406)
  store { i64, ptr } %t409, ptr %l271
  br label %bb123
bb123:
  %t410 = load { i64, ptr }, ptr %l271, !tbaa !27
  store { i64, ptr } %t410, ptr %l39, !tbaa !27
  %t411 = load ptr, ptr %l0, !tbaa !29
  %t412 = load i64, ptr %l36, !tbaa !24
  %t415 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2erefs(ptr %v0, ptr %v0, ptr %t411, i64 %t412)
  store { i64, ptr } %t415, ptr %l274
  br label %bb124
bb124:
  %t416 = load { i64, ptr }, ptr %l274, !tbaa !27
  store { i64, ptr } %t416, ptr %l40, !tbaa !27
  store i64 0, ptr %l41, !tbaa !24
  %t417 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t419 = extractvalue { i64, ptr } %t417, 0
  store i64 %t419, ptr %l42, !tbaa !24
  store i64 3, ptr %l43, !tbaa !24
  %t421 = load i64, ptr %l42, !tbaa !24
  %t422 = load i64, ptr %l41, !tbaa !24
  %t425 = icmp sgt i64 %t421, %t422
  br i1 %t425, label %bb125, label %bb126
bb125:
  %t427 = load i64, ptr %l43, !tbaa !24
  %t429 = icmp sgt i64 %t427, 0
  br i1 %t429, label %bb127, label %bb128
bb126:
  store i64 0, ptr %l280, !tbaa !24
  br label %bb130
bb127:
  %t431 = load i64, ptr %l42, !tbaa !24
  %t432 = load i64, ptr %l41, !tbaa !24
  %t435 = sub i64 %t431, %t432
  %t436 = load i64, ptr %l43, !tbaa !24
  %t439 = add i64 %t435, %t436
  %t441 = sub i64 %t439, 1
  %t442 = load i64, ptr %l43, !tbaa !24
  %t445 = sdiv i64 %t441, %t442
  store i64 %t445, ptr %l283, !tbaa !24
  br label %bb129
bb128:
  store i64 0, ptr %l283, !tbaa !24
  br label %bb129
bb129:
  %t447 = load i64, ptr %l283, !tbaa !24
  store i64 %t447, ptr %l280, !tbaa !24
  br label %bb130
bb130:
  %t448 = load i64, ptr %l280, !tbaa !24
  store i64 %t448, ptr %l44, !tbaa !24
  store i64 0, ptr %l45, !tbaa !24
  br label %bb131
bb131:
  %t449 = load i64, ptr %l45, !tbaa !24
  %t450 = load i64, ptr %l44, !tbaa !24
  %t453 = icmp slt i64 %t449, %t450
  %t455 = xor i1 %t453, true
  br i1 %t455, label %bb132, label %bb133
bb132:
  br label %bb218
bb133:
  br label %bb134
bb134:
  %t457 = load i64, ptr %l41, !tbaa !24
  %t458 = load i64, ptr %l45, !tbaa !24
  %t459 = load i64, ptr %l43, !tbaa !24
  %t462 = mul i64 %t458, %t459
  %t465 = add i64 %t457, %t462
  store i64 %t465, ptr %l46, !tbaa !24
  %t467 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t467, ptr %l301, !tbaa !27
  %t468 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t468, ptr %l302, !tbaa !27
  %t469 = load i64, ptr %l46, !tbaa !24
  %t471 = add i64 %t469, 1
  %t473 = getelementptr { i64, ptr }, ptr %l302, i32 0, i32 1
  %t474 = load ptr, ptr %t473, !tbaa !27
  %t475 = getelementptr i64, ptr %t474, i64 %t471
  %t476 = load i64, ptr %t475, !tbaa !34
  store i64 %t476, ptr %l305, !tbaa !24
  %t477 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t477, ptr %l306, !tbaa !27
  %t478 = load i64, ptr %l46, !tbaa !24
  %t480 = add i64 %t478, 2
  %t482 = getelementptr { i64, ptr }, ptr %l306, i32 0, i32 1
  %t483 = load ptr, ptr %t482, !tbaa !27
  %t484 = getelementptr i64, ptr %t483, i64 %t480
  %t485 = load i64, ptr %t484, !tbaa !34
  store i64 %t485, ptr %l309, !tbaa !24
  %t486 = load { i64, ptr }, ptr %l301, !tbaa !27
  %t487 = extractvalue { i64, ptr } %t486, 0
  store i64 %t487, ptr %l310, !tbaa !24
  %t488 = load i64, ptr %l305, !tbaa !24
  %t489 = icmp sge i64 %t488, 0
  br i1 %t489, label %bb135, label %bb136
bb135:
  %t491 = load i64, ptr %l305, !tbaa !24
  %t492 = load i64, ptr %l309, !tbaa !24
  %t493 = icmp sle i64 %t491, %t492
  br i1 %t493, label %bb137, label %bb138
bb136:
  call void @__olang_check_failed(ptr @olang_loc_ad9436b5748221a9_385739db7a2b20ed)
  unreachable
bb137:
  %t495 = load i64, ptr %l309, !tbaa !24
  %t496 = load i64, ptr %l310, !tbaa !24
  %t497 = icmp sle i64 %t495, %t496
  br i1 %t497, label %bb139, label %bb140
bb138:
  call void @__olang_check_failed(ptr @olang_loc_ad9436b5748221a9_385739db7a2b20ed)
  unreachable
bb139:
  %t499 = getelementptr { i64, ptr }, ptr %l301, i32 0, i32 1
  %t500 = load ptr, ptr %t499, !tbaa !27
  %t501 = load i64, ptr %l305, !tbaa !24
  %t502 = load i64, ptr %l309, !tbaa !24
  %t503 = getelementptr i8, ptr %t500, i64 %t501
  %t504 = sub i64 %t502, %t501
  %t505 = insertvalue { i64, ptr } undef, i64 %t504, 0
  %t506 = insertvalue { i64, ptr } %t505, ptr %t503, 1
  store { i64, ptr } %t506, ptr %l47, !tbaa !27
  %t508 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t508, ptr %l315, !tbaa !27
  %t509 = load i64, ptr %l46, !tbaa !24
  %t511 = getelementptr { i64, ptr }, ptr %l315, i32 0, i32 1
  %t512 = load ptr, ptr %t511, !tbaa !27
  %t513 = getelementptr i64, ptr %t512, i64 %t509
  %t514 = load i64, ptr %t513, !tbaa !34
  %t516 = icmp eq i64 %t514, 1
  br i1 %t516, label %bb141, label %bb142
bb140:
  call void @__olang_check_failed(ptr @olang_loc_ad9436b5748221a9_385739db7a2b20ed)
  unreachable
bb141:
  %t518 = load ptr, ptr %l0, !tbaa !29
  %t520 = getelementptr %"compiler/emit:Emitter", ptr %t518, i32 0, i32 53
  %t521 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t524 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v0, ptr %t520, { i64, ptr } %t521)
  %t525 = extractvalue { i32, i64 } %t524, 1
  %t526 = extractvalue { i32, i64 } %t524, 0
  store i32 %t526, ptr %l324
  %t527 = icmp ne i32 %t526, 0
  br i1 %t527, label %bb144, label %ok.528, !prof !99
ok.528:
  store i64 %t525, ptr %l323
  br label %bb143
bb142:
  br label %bb155
bb143:
  %t529 = load i64, ptr %l323, !tbaa !24
  store i64 %t529, ptr %l319, !tbaa !24
  br label %bb146
bb144:
  br label %bb145
bb145:
  store i64 -1, ptr %l319, !tbaa !24
  br label %bb146
bb146:
  %t530 = load i64, ptr %l319, !tbaa !24
  store i64 %t530, ptr %l48, !tbaa !24
  %t531 = load i64, ptr %l48, !tbaa !24
  %t533 = icmp sge i64 %t531, 0
  br i1 %t533, label %bb147, label %bb148
bb147:
  %t535 = load i64, ptr %l48, !tbaa !24
  %t538 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %l28, i64 %t535)
  store i1 %t538, ptr %l330
  br label %bb149
bb148:
  store i1 false, ptr %l327, !tbaa !21
  br label %bb150
bb149:
  %t539 = load i1, ptr %l330, !tbaa !21
  %t540 = xor i1 %t539, true
  store i1 %t540, ptr %l327, !tbaa !21
  br label %bb150
bb150:
  %t542 = load i1, ptr %l327, !tbaa !21
  br i1 %t542, label %bb151, label %bb152
bb151:
  %t543 = load ptr, ptr %l0, !tbaa !29
  %t544 = load i64, ptr %l48, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewantType(ptr %v0, ptr %s0, ptr %s0, ptr %t543, i64 %t544, ptr %l27, ptr %l28)
  br label %bb153
bb152:
  br label %bb154
bb153:
  br label %bb154
bb154:
  br label %bb217
bb155:
  %t549 = load ptr, ptr %l0, !tbaa !29
  %t550 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t553 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitemNamed(ptr %v0, ptr %v0, ptr %t549, { i64, ptr } %t550)
  store i64 %t553, ptr %l338
  br label %bb156
bb156:
  %t554 = load i64, ptr %l338, !tbaa !24
  store i64 %t554, ptr %l49, !tbaa !24
  %t555 = load i1, ptr %l30, !tbaa !21
  br i1 %t555, label %bb157, label %bb158
bb157:
  %t557 = load i64, ptr %l49, !tbaa !24
  %t559 = icmp sge i64 %t557, 0
  store i1 %t559, ptr %l340, !tbaa !21
  br label %bb159
bb158:
  store i1 false, ptr %l340, !tbaa !21
  br label %bb159
bb159:
  %t561 = load i1, ptr %l340, !tbaa !21
  br i1 %t561, label %bb160, label %bb161
bb160:
  %t562 = load ptr, ptr %l0, !tbaa !29
  %t564 = getelementptr %"compiler/emit:Emitter", ptr %t562, i32 0, i32 75
  %t565 = load i64, ptr %l49, !tbaa !24
  %t568 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t564, i64 %t565)
  %t569 = extractvalue { i32, i64 } %t568, 1
  %t570 = extractvalue { i32, i64 } %t568, 0
  store i32 %t570, ptr %l348
  %t571 = icmp ne i32 %t570, 0
  br i1 %t571, label %bb163, label %ok.572, !prof !99
ok.572:
  store i64 %t569, ptr %l347
  br label %bb162
bb161:
  br label %bb166
bb162:
  %t573 = load i64, ptr %l347, !tbaa !24
  store i64 %t573, ptr %l343, !tbaa !24
  br label %bb165
bb163:
  br label %bb164
bb164:
  %t574 = load i64, ptr %l49, !tbaa !24
  store i64 %t574, ptr %l343, !tbaa !24
  br label %bb165
bb165:
  %t576 = load i64, ptr %l343, !tbaa !24
  store i64 %t576, ptr %l49, !tbaa !24
  br label %bb166
bb166:
  %t577 = load i64, ptr %l49, !tbaa !24
  %t579 = icmp slt i64 %t577, 0
  br i1 %t579, label %bb167, label %bb168
bb167:
  store i1 true, ptr %l352, !tbaa !21
  br label %bb170
bb168:
  %t581 = load i64, ptr %l49, !tbaa !24
  %t584 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %l20, i64 %t581)
  store i1 %t584, ptr %l355
  br label %bb169
bb169:
  %t585 = load i1, ptr %l355, !tbaa !21
  store i1 %t585, ptr %l352, !tbaa !21
  br label %bb170
bb170:
  %t586 = load i1, ptr %l352, !tbaa !21
  br i1 %t586, label %bb171, label %bb172
bb171:
  store i1 true, ptr %l356, !tbaa !21
  br label %bb174
bb172:
  %t587 = load i64, ptr %l49, !tbaa !24
  %t590 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %l26, i64 %t587)
  store i1 %t590, ptr %l359
  br label %bb173
bb173:
  %t591 = load i1, ptr %l359, !tbaa !21
  store i1 %t591, ptr %l356, !tbaa !21
  br label %bb174
bb174:
  %t592 = load i1, ptr %l356, !tbaa !21
  br i1 %t592, label %bb175, label %bb176
bb175:
  br label %bb217
bb176:
  br label %bb177
bb177:
  %t593 = load ptr, ptr %l0, !tbaa !29
  %t595 = getelementptr %"compiler/emit:Emitter", ptr %t593, i32 0, i32 20
  %t596 = load i64, ptr %l49, !tbaa !24
  %t599 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t595, i64 %t596)
  store i64 %t599, ptr %l363
  br label %bb178
bb178:
  %t600 = load i64, ptr %l363, !tbaa !24
  store i64 %t600, ptr %l50, !tbaa !24
  %t601 = load i64, ptr %l50, !tbaa !24
  %t602 = load i64, ptr @G_2ecompiler_2femit_2eHomeShared, !tbaa !24
  %t605 = icmp eq i64 %t601, %t602
  br i1 %t605, label %bb179, label %bb180
bb179:
  store i1 true, ptr %l367, !tbaa !21
  br label %bb181
bb180:
  %t607 = load i64, ptr %l50, !tbaa !24
  %t608 = load i64, ptr @G_2ecompiler_2femit_2eHomeLocal, !tbaa !24
  %t611 = icmp eq i64 %t607, %t608
  store i1 %t611, ptr %l367, !tbaa !21
  br label %bb181
bb181:
  %t613 = load i1, ptr %l367, !tbaa !21
  br i1 %t613, label %bb182, label %bb183
bb182:
  store %olang.scope zeroinitializer, ptr %s23
  %t614 = load i64, ptr %l49, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s0, ptr %l20, i64 %t614, i1 true)
  br label %bb184
bb183:
  br label %bb194
bb184:
  %t617 = load i64, ptr %l49, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l19, i64 %t617)
  br label %bb185
bb185:
  %t620 = load i64, ptr %l50, !tbaa !24
  %t621 = load i64, ptr @G_2ecompiler_2femit_2eHomeLocal, !tbaa !24
  %t624 = icmp ne i64 %t620, %t621
  br i1 %t624, label %bb186, label %bb187
bb186:
  call void @__olang_scope_close(ptr %s23)
  br label %bb217
bb187:
  br label %bb188
bb188:
  store ptr %l29, ptr %l378, !tbaa !29
  %t626 = load i64, ptr %l49, !tbaa !24
  store i64 %t626, ptr %l379, !tbaa !24
  %t627 = ptrtoint ptr %s0 to i64
  store i64 %t627, ptr %l380, !tbaa !24
  %t628 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2e1
  br i1 %t628, label %bb189, label %bb190
bb189:
  %t630 = call ptr @__olang_region_make(ptr %s0)
  %t631 = ptrtoint ptr %t630 to i64
  store i64 %t631, ptr %l380, !tbaa !24
  br label %bb190
bb190:
  %t632 = load ptr, ptr %l0, !tbaa !29
  %t634 = getelementptr %"compiler/emit:Emitter", ptr %t632, i32 0, i32 18
  %t635 = load i64, ptr %l49, !tbaa !24
  %t638 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t634, i64 %t635)
  store { i64, ptr } %t638, ptr %l385
  br label %bb191
bb191:
  %t639 = load { i64, ptr }, ptr %l385, !tbaa !27
  %t640 = call { i64, ptr } @compiler_2femit_2eprefixOf(ptr %v0, ptr %s23, { i64, ptr } %t639)
  store { i64, ptr } %t640, ptr %l386
  br label %bb192
bb192:
  %t641 = load i64, ptr %l33, !tbaa !24
  %t642 = load { i64, ptr }, ptr %l386, !tbaa !27
  %t643 = extractvalue { i64, ptr } %t642, 1
  %t644 = extractvalue { i64, ptr } %t642, 0
  %t646 = call i64 @__olang_fmt_i64(ptr null, i64 %t641)
  %t647 = add i64 %t644, %t646
  %t648 = load i64, ptr %l380
  %t649 = inttoptr i64 %t648 to ptr
  %t650 = call ptr @__olang_scope_alloc(ptr %t649, i64 %t647)
  call void @olang_textcopy(ptr %t650, ptr %t643, i64 %t644)
  %t651 = getelementptr i8, ptr %t650, i64 %t644
  %t652 = call i64 @__olang_fmt_i64(ptr %t651, i64 %t641)
  %t653 = insertvalue { i64, ptr } undef, i64 %t647, 0
  %t654 = insertvalue { i64, ptr } %t653, ptr %t650, 1
  %t656 = load i64, ptr %l380
  %t657 = inttoptr i64 %t656 to ptr
  %t658 = extractvalue { i64, ptr } %t654, 0
  %t659 = extractvalue { i64, ptr } %t654, 1
  %t660 = mul i64 %t658, 1
  %t661 = call ptr @__olang_scope_alloc(ptr %t657, i64 %t660)
  call void @llvm.memcpy.p0.p0.i64(ptr %t661, ptr %t659, i64 %t660, i1 false)
  %t662 = insertvalue { i64, ptr } undef, i64 %t658, 0
  %t663 = insertvalue { i64, ptr } %t662, ptr %t661, 1
  %t664 = load ptr, ptr %l378, !tbaa !29
  %t665 = load i64, ptr %l379, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Hc3dff1927e5c626a9d95abfdf4e9a462(ptr %s0, ptr %s0, ptr %t664, i64 %t665, { i64, ptr } %t663)
  br label %bb193
bb193:
  %t667 = load i64, ptr %l33, !tbaa !24
  %t669 = add i64 %t667, 1
  store i64 %t669, ptr %l33, !tbaa !24
  call void @__olang_scope_close(ptr %s23)
  br label %bb217
bb194:
  %t671 = load i64, ptr %l49, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s0, ptr %l26, i64 %t671, i1 true)
  br label %bb195
bb195:
  store ptr %l25, ptr %l394, !tbaa !29
  %t674 = load ptr, ptr %l0, !tbaa !29
  %t676 = getelementptr %"compiler/emit:Emitter", ptr %t674, i32 0, i32 21
  %t677 = load i64, ptr %l49, !tbaa !24
  %t680 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t676, i64 %t677)
  store { i64, ptr } %t680, ptr %l398
  br label %bb196
bb196:
  %t681 = load ptr, ptr %l394, !tbaa !29
  %t682 = load { i64, ptr }, ptr %l398, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t681, { i64, ptr } %t682)
  br label %bb197
bb197:
  %t683 = load ptr, ptr %l0, !tbaa !29
  store ptr %t683, ptr %l399, !tbaa !29
  %t684 = load ptr, ptr %l0, !tbaa !29
  %t686 = getelementptr %"compiler/emit:Emitter", ptr %t684, i32 0, i32 21
  %t687 = load i64, ptr %l49, !tbaa !24
  %t690 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t686, i64 %t687)
  store { i64, ptr } %t690, ptr %l403
  br label %bb198
bb198:
  %t691 = load ptr, ptr %l399, !tbaa !29
  %t692 = load { i64, ptr }, ptr %l403, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclTypes(ptr %v0, ptr %v0, ptr %s0, ptr %s0, ptr %t691, { i64, ptr } %t692, ptr %l27, ptr %l28)
  br label %bb199
bb199:
  %t695 = load i64, ptr %l50, !tbaa !24
  %t696 = load i64, ptr @G_2ecompiler_2femit_2eHomeInst, !tbaa !24
  %t699 = icmp eq i64 %t695, %t696
  br i1 %t699, label %bb200, label %bb201
bb200:
  %t701 = load ptr, ptr %l5, !tbaa !29
  %t703 = icmp eq ptr %t701, null
  %t705 = xor i1 %t703, true
  store i1 %t705, ptr %l409, !tbaa !21
  br label %bb202
bb201:
  store i1 false, ptr %l409, !tbaa !21
  br label %bb202
bb202:
  %t707 = load i1, ptr %l409, !tbaa !21
  br i1 %t707, label %bb203, label %bb204
bb203:
  store %olang.scope zeroinitializer, ptr %s26
  %t708 = load ptr, ptr %l5, !tbaa !29
  store ptr %t708, ptr %l413, !tbaa !29
  %t709 = ptrtoint ptr %v1 to i64
  store i64 %t709, ptr %l414, !tbaa !24
  %t710 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t710, label %bb205, label %bb206
bb204:
  br label %bb209
bb205:
  %t712 = call ptr @__olang_region_make(ptr %v1)
  %t713 = ptrtoint ptr %t712 to i64
  store i64 %t713, ptr %l414, !tbaa !24
  br label %bb206
bb206:
  %t714 = load ptr, ptr %l0, !tbaa !29
  %t716 = getelementptr %"compiler/emit:Emitter", ptr %t714, i32 0, i32 18
  %t717 = load i64, ptr %l49, !tbaa !24
  %t720 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s26, ptr %t716, i64 %t717)
  store { i64, ptr } %t720, ptr %l419
  br label %bb207
bb207:
  %t721 = load { i64, ptr }, ptr %l419, !tbaa !27
  %t722 = extractvalue { i64, ptr } %t721, 1
  %t723 = extractvalue { i64, ptr } %t721, 0
  %t724 = load i64, ptr %l414
  %t725 = inttoptr i64 %t724 to ptr
  %t726 = call ptr @__olang_scope_alloc(ptr %t725, i64 %t723)
  call void @olang_textcopy(ptr %t726, ptr %t722, i64 %t723)
  %t727 = insertvalue { i64, ptr } undef, i64 %t723, 0
  %t728 = insertvalue { i64, ptr } %t727, ptr %t726, 1
  %t730 = load i64, ptr %l414
  %t731 = inttoptr i64 %t730 to ptr
  %t732 = extractvalue { i64, ptr } %t728, 0
  %t733 = extractvalue { i64, ptr } %t728, 1
  %t734 = mul i64 %t732, 1
  %t735 = call ptr @__olang_scope_alloc(ptr %t731, i64 %t734)
  call void @llvm.memcpy.p0.p0.i64(ptr %t735, ptr %t733, i64 %t734, i1 false)
  %t736 = insertvalue { i64, ptr } undef, i64 %t732, 0
  %t737 = insertvalue { i64, ptr } %t736, ptr %t735, 1
  %t738 = load ptr, ptr %l413, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t738, { i64, ptr } %t737)
  br label %bb208
bb208:
  call void @__olang_scope_close(ptr %s26)
  br label %bb209
bb209:
  %t740 = load i64, ptr %l50, !tbaa !24
  %t741 = load i64, ptr @G_2ecompiler_2femit_2eHomeLoc, !tbaa !24
  %t744 = icmp eq i64 %t740, %t741
  br i1 %t744, label %bb210, label %bb211
bb210:
  %t746 = load ptr, ptr %l7, !tbaa !29
  %t748 = icmp eq ptr %t746, null
  %t750 = xor i1 %t748, true
  store i1 %t750, ptr %l425, !tbaa !21
  br label %bb212
bb211:
  store i1 false, ptr %l425, !tbaa !21
  br label %bb212
bb212:
  %t752 = load i1, ptr %l425, !tbaa !21
  br i1 %t752, label %bb213, label %bb214
bb213:
  %t753 = load ptr, ptr %l7, !tbaa !29
  %t754 = load i64, ptr %l49, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v2, ptr %t753, i64 %t754, i1 true)
  br label %bb215
bb214:
  br label %bb216
bb215:
  br label %bb216
bb216:
  br label %bb217
bb217:
  %t757 = load i64, ptr %l45, !tbaa !24
  %t759 = add i64 %t757, 1
  store i64 %t759, ptr %l45, !tbaa !24
  br label %bb131
bb218:
  br label %bb219
bb219:
  br label %bb84
bb220:
  %t761 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t761, ptr %l433
  br label %bb221
bb221:
  %t762 = load %"std/prelude/text:StringBuilder", ptr %l433
  store %"std/prelude/text:StringBuilder" %t762, ptr %l51
  store ptr %l51, ptr %l434, !tbaa !29
  %t763 = load ptr, ptr %l0, !tbaa !29
  %t765 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehead(ptr %v0, ptr %s0, ptr %t763)
  store { i64, ptr } %t765, ptr %l436
  br label %bb222
bb222:
  %t766 = load { i64, ptr }, ptr %l436, !tbaa !27
  %t767 = extractvalue { i64, ptr } %t766, 0
  %t768 = extractvalue { i64, ptr } %t766, 1
  %t769 = mul i64 %t767, 1
  %t770 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t769)
  call void @llvm.memcpy.p0.p0.i64(ptr %t770, ptr %t768, i64 %t769, i1 false)
  %t771 = insertvalue { i64, ptr } undef, i64 %t767, 0
  %t772 = insertvalue { i64, ptr } %t771, ptr %t770, 1
  %t773 = load ptr, ptr %l434, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t773, { i64, ptr } %t772)
  br label %bb223
bb223:
  %t775 = load ptr, ptr %l0, !tbaa !29
  %t777 = getelementptr %"compiler/emit:Emitter", ptr %t775, i32 0, i32 64
  %t778 = load { i64, ptr }, ptr %t777, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %l51, { i64, ptr } %t778)
  br label %bb224
bb224:
  store ptr %l27, ptr %l52, !tbaa !29
  store i64 0, ptr %l53, !tbaa !24
  br label %bb225
bb225:
  %t782 = load i64, ptr %l53, !tbaa !24
  store i64 %t782, ptr %l442, !tbaa !24
  %t783 = load ptr, ptr %l52, !tbaa !29
  %t785 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t783)
  store i64 %t785, ptr %l444
  br label %bb226
bb226:
  %t786 = load i64, ptr %l442, !tbaa !24
  %t787 = load i64, ptr %l444, !tbaa !24
  %t788 = icmp slt i64 %t786, %t787
  %t790 = xor i1 %t788, true
  br i1 %t790, label %bb227, label %bb228
bb227:
  br label %bb234
bb228:
  br label %bb229
bb229:
  %t792 = load ptr, ptr %l52, !tbaa !29
  %t793 = load i64, ptr %l53, !tbaa !24
  %t796 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t792, i64 %t793)
  store i64 %t796, ptr %l449
  br label %bb230
bb230:
  %t797 = load i64, ptr %l449, !tbaa !24
  store ptr %l51, ptr %l450, !tbaa !29
  %t798 = load ptr, ptr %l0, !tbaa !29
  %t800 = getelementptr %"compiler/emit:Emitter", ptr %t798, i32 0, i32 52
  %t804 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t800, i64 %t797)
  store { i64, ptr } %t804, ptr %l454
  br label %bb231
bb231:
  %t805 = load ptr, ptr %l450, !tbaa !29
  %t806 = load { i64, ptr }, ptr %l454, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t805, { i64, ptr } %t806)
  br label %bb232
bb232:
  br label %bb233
bb233:
  %t807 = load i64, ptr %l53, !tbaa !24
  %t809 = add i64 %t807, 1
  store i64 %t809, ptr %l53, !tbaa !24
  br label %bb225
bb234:
  %t811 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t811, ptr %l457
  br label %bb235
bb235:
  %t812 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l457
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t812, ptr %l55
  store ptr %l19, ptr %l56, !tbaa !29
  store i64 0, ptr %l57, !tbaa !24
  br label %bb236
bb236:
  %t814 = load i64, ptr %l57, !tbaa !24
  store i64 %t814, ptr %l459, !tbaa !24
  %t815 = load ptr, ptr %l56, !tbaa !29
  %t817 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t815)
  store i64 %t817, ptr %l461
  br label %bb237
bb237:
  %t818 = load i64, ptr %l459, !tbaa !24
  %t819 = load i64, ptr %l461, !tbaa !24
  %t820 = icmp slt i64 %t818, %t819
  %t822 = xor i1 %t820, true
  br i1 %t822, label %bb238, label %bb239
bb238:
  br label %bb364
bb239:
  br label %bb240
bb240:
  %t824 = load ptr, ptr %l56, !tbaa !29
  %t825 = load i64, ptr %l57, !tbaa !24
  %t828 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t824, i64 %t825)
  store i64 %t828, ptr %l466
  br label %bb241
bb241:
  %t829 = load i64, ptr %l466, !tbaa !24
  store i64 %t829, ptr %l58, !tbaa !24
  %t830 = load i1, ptr %l30, !tbaa !21
  br i1 %t830, label %bb242, label %bb243
bb242:
  %t832 = load ptr, ptr %l0, !tbaa !29
  %t834 = getelementptr %"compiler/emit:Emitter", ptr %t832, i32 0, i32 75
  %t835 = load i64, ptr %l58, !tbaa !24
  %t838 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t834, i64 %t835)
  store i1 %t838, ptr %l472
  br label %bb244
bb243:
  store i1 false, ptr %l468, !tbaa !21
  br label %bb245
bb244:
  %t839 = load i1, ptr %l472, !tbaa !21
  store i1 %t839, ptr %l468, !tbaa !21
  br label %bb245
bb245:
  %t840 = load i1, ptr %l468, !tbaa !21
  br i1 %t840, label %bb246, label %bb247
bb246:
  store %olang.scope zeroinitializer, ptr %s35
  %t841 = load ptr, ptr %l0, !tbaa !29
  %t843 = getelementptr %"compiler/emit:Emitter", ptr %t841, i32 0, i32 75
  %t844 = load i64, ptr %l58, !tbaa !24
  %t847 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t843, i64 %t844)
  %t848 = extractvalue { i32, i64 } %t847, 1
  %t849 = extractvalue { i32, i64 } %t847, 0
  store i32 %t849, ptr %l478
  %t850 = icmp ne i32 %t849, 0
  br i1 %t850, label %bb249, label %ok.851, !prof !99
ok.851:
  store i64 %t848, ptr %l477
  br label %bb248
bb247:
  br label %bb268
bb248:
  %t852 = load i64, ptr %l477, !tbaa !24
  store i64 %t852, ptr %l473, !tbaa !24
  br label %bb251
bb249:
  br label %bb250
bb250:
  %t853 = load i64, ptr %l58, !tbaa !24
  store i64 %t853, ptr %l473, !tbaa !24
  br label %bb251
bb251:
  %t855 = load i64, ptr %l473, !tbaa !24
  store i64 %t855, ptr %l59, !tbaa !24
  %t856 = load ptr, ptr %l0, !tbaa !29
  %t857 = load i64, ptr %l58, !tbaa !24
  %t860 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ealiased(ptr %v0, ptr %t856, i64 %t857)
  store i1 %t860, ptr %l482
  br label %bb252
bb252:
  %t861 = load i1, ptr %l482, !tbaa !21
  %t862 = xor i1 %t861, true
  br i1 %t862, label %bb253, label %bb254
bb253:
  store ptr %l51, ptr %l484, !tbaa !29
  %t864 = load i64, ptr %l58, !tbaa !24
  %t867 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %s0, ptr %s0, ptr %l34, i64 %t864)
  %t868 = extractvalue { i32, { i64, ptr } } %t867, 1
  %t869 = extractvalue { i32, { i64, ptr } } %t867, 0
  store i32 %t869, ptr %l489
  %t870 = icmp ne i32 %t869, 0
  br i1 %t870, label %bb256, label %ok.871, !prof !99
ok.871:
  store { i64, ptr } %t868, ptr %l488
  br label %bb255
bb254:
  br label %bb260
bb255:
  %t872 = load { i64, ptr }, ptr %l488, !tbaa !27
  store { i64, ptr } %t872, ptr %l485, !tbaa !27
  br label %bb258
bb256:
  br label %bb257
bb257:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l485, !tbaa !27
  br label %bb258
bb258:
  %t873 = load ptr, ptr %l484, !tbaa !29
  %t874 = load { i64, ptr }, ptr %l485, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t873, { i64, ptr } %t874)
  br label %bb259
bb259:
  call void @__olang_scope_close(ptr %s35)
  br label %bb363
bb260:
  %t875 = load ptr, ptr %l0, !tbaa !29
  %t877 = getelementptr %"compiler/emit:Emitter", ptr %t875, i32 0, i32 76
  %t878 = load i64, ptr %l58, !tbaa !24
  %t881 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v0, ptr %t877, i64 %t878)
  %t882 = extractvalue { i32, { i64, ptr } } %t881, 1
  %t883 = extractvalue { i32, { i64, ptr } } %t881, 0
  store i32 %t883, ptr %l495
  %t884 = icmp ne i32 %t883, 0
  br i1 %t884, label %bb262, label %ok.885, !prof !99
ok.885:
  store { i64, ptr } %t882, ptr %l494
  br label %bb261
bb261:
  %t886 = load { i64, ptr }, ptr %l494, !tbaa !27
  store { i64, ptr } %t886, ptr %l490, !tbaa !27
  br label %bb264
bb262:
  br label %bb263
bb263:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %l490, !tbaa !27
  br label %bb264
bb264:
  %t887 = load { i64, ptr }, ptr %l490, !tbaa !27
  store { i64, ptr } %t887, ptr %l60, !tbaa !27
  store ptr %l51, ptr %l496, !tbaa !29
  %t888 = load ptr, ptr %l0, !tbaa !29
  %t890 = getelementptr %"compiler/emit:Emitter", ptr %t888, i32 0, i32 18
  %t891 = load i64, ptr %l58, !tbaa !24
  %t894 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s35, ptr %t890, i64 %t891)
  store { i64, ptr } %t894, ptr %l500
  br label %bb265
bb265:
  %t895 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t895, ptr %l501, !tbaa !27
  %t896 = load ptr, ptr %l0, !tbaa !29
  %t898 = getelementptr %"compiler/emit:Emitter", ptr %t896, i32 0, i32 18
  %t899 = load i64, ptr %l59, !tbaa !24
  %t902 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s35, ptr %t898, i64 %t899)
  store { i64, ptr } %t902, ptr %l505
  br label %bb266
bb266:
  %t903 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t904 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t905 = load { i64, ptr }, ptr %l500, !tbaa !27
  %t906 = extractvalue { i64, ptr } %t905, 1
  %t907 = extractvalue { i64, ptr } %t905, 0
  %t908 = add i64 %t904, %t907
  %t909 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t910 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t911 = add i64 %t908, %t910
  %t912 = load { i64, ptr }, ptr %l501, !tbaa !27
  %t913 = extractvalue { i64, ptr } %t912, 1
  %t914 = extractvalue { i64, ptr } %t912, 0
  %t915 = add i64 %t911, %t914
  %t916 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t917 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t918 = add i64 %t915, %t917
  %t919 = load { i64, ptr }, ptr %l505, !tbaa !27
  %t920 = extractvalue { i64, ptr } %t919, 1
  %t921 = extractvalue { i64, ptr } %t919, 0
  %t922 = add i64 %t918, %t921
  %t923 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t924 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t925 = add i64 %t922, %t924
  %t926 = call ptr @__olang_scope_alloc(ptr %s35, i64 %t925)
  call void @olang_textcopy(ptr %t926, ptr %t903, i64 %t904)
  %t927 = getelementptr i8, ptr %t926, i64 %t904
  call void @olang_textcopy(ptr %t927, ptr %t906, i64 %t907)
  %t928 = getelementptr i8, ptr %t927, i64 %t907
  call void @olang_textcopy(ptr %t928, ptr %t909, i64 %t910)
  %t929 = getelementptr i8, ptr %t928, i64 %t910
  call void @olang_textcopy(ptr %t929, ptr %t913, i64 %t914)
  %t930 = getelementptr i8, ptr %t929, i64 %t914
  call void @olang_textcopy(ptr %t930, ptr %t916, i64 %t917)
  %t931 = getelementptr i8, ptr %t930, i64 %t917
  call void @olang_textcopy(ptr %t931, ptr %t920, i64 %t921)
  %t932 = getelementptr i8, ptr %t931, i64 %t921
  call void @olang_textcopy(ptr %t932, ptr %t923, i64 %t924)
  %t933 = insertvalue { i64, ptr } undef, i64 %t925, 0
  %t934 = insertvalue { i64, ptr } %t933, ptr %t926, 1
  %t936 = extractvalue { i64, ptr } %t934, 0
  %t937 = extractvalue { i64, ptr } %t934, 1
  %t938 = mul i64 %t936, 1
  %t939 = call ptr @__olang_scope_alloc(ptr %s35, i64 %t938)
  call void @llvm.memcpy.p0.p0.i64(ptr %t939, ptr %t937, i64 %t938, i1 false)
  %t940 = insertvalue { i64, ptr } undef, i64 %t936, 0
  %t941 = insertvalue { i64, ptr } %t940, ptr %t939, 1
  %t942 = load ptr, ptr %l496, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s35, ptr %t942, { i64, ptr } %t941)
  br label %bb267
bb267:
  call void @__olang_scope_close(ptr %s35)
  br label %bb363
bb268:
  %t944 = load ptr, ptr %l0, !tbaa !29
  %t946 = getelementptr %"compiler/emit:Emitter", ptr %t944, i32 0, i32 19
  %t947 = load i64, ptr %l58, !tbaa !24
  %t950 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t946, i64 %t947)
  store { i64, ptr } %t950, ptr %l511
  br label %bb269
bb269:
  %t951 = load { i64, ptr }, ptr %l511, !tbaa !27
  store { i64, ptr } %t951, ptr %l61, !tbaa !27
  %t953 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_H0211835ad1df5edc8086b9b7bc878d6e(ptr %s0, ptr %l29)
  store i64 %t953, ptr %l513
  br label %bb270
bb270:
  %t954 = load i64, ptr %l513, !tbaa !24
  %t955 = icmp eq i64 %t954, 0
  br i1 %t955, label %bb271, label %bb272
bb271:
  %t957 = load ptr, ptr %l0, !tbaa !29
  %t959 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbg(ptr %v0, ptr %t957)
  store i1 %t959, ptr %l517
  br label %bb273
bb272:
  store i1 false, ptr %l515, !tbaa !21
  br label %bb274
bb273:
  %t960 = load i1, ptr %l517, !tbaa !21
  %t961 = xor i1 %t960, true
  store i1 %t961, ptr %l515, !tbaa !21
  br label %bb274
bb274:
  %t963 = load i1, ptr %l515, !tbaa !21
  br i1 %t963, label %bb275, label %bb276
bb275:
  %t964 = load { i64, ptr }, ptr %l61, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %l51, { i64, ptr } %t964)
  br label %bb277
bb276:
  br label %bb278
bb277:
  br label %bb363
bb278:
  store i64 0, ptr %l62, !tbaa !24
  %t967 = load ptr, ptr %l0, !tbaa !29
  %t968 = load i64, ptr %l58, !tbaa !24
  %t971 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2erefs(ptr %v0, ptr %v0, ptr %t967, i64 %t968)
  store { i64, ptr } %t971, ptr %l523
  br label %bb279
bb279:
  %t972 = load { i64, ptr }, ptr %l523, !tbaa !27
  store { i64, ptr } %t972, ptr %l63, !tbaa !27
  store i64 0, ptr %l64, !tbaa !24
  %t973 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t975 = extractvalue { i64, ptr } %t973, 0
  store i64 %t975, ptr %l65, !tbaa !24
  store i64 3, ptr %l66, !tbaa !24
  %t977 = load i64, ptr %l65, !tbaa !24
  %t978 = load i64, ptr %l64, !tbaa !24
  %t981 = icmp sgt i64 %t977, %t978
  br i1 %t981, label %bb280, label %bb281
bb280:
  %t983 = load i64, ptr %l66, !tbaa !24
  %t985 = icmp sgt i64 %t983, 0
  br i1 %t985, label %bb282, label %bb283
bb281:
  store i64 0, ptr %l529, !tbaa !24
  br label %bb285
bb282:
  %t987 = load i64, ptr %l65, !tbaa !24
  %t988 = load i64, ptr %l64, !tbaa !24
  %t991 = sub i64 %t987, %t988
  %t992 = load i64, ptr %l66, !tbaa !24
  %t995 = add i64 %t991, %t992
  %t997 = sub i64 %t995, 1
  %t998 = load i64, ptr %l66, !tbaa !24
  %t1001 = sdiv i64 %t997, %t998
  store i64 %t1001, ptr %l532, !tbaa !24
  br label %bb284
bb283:
  store i64 0, ptr %l532, !tbaa !24
  br label %bb284
bb284:
  %t1003 = load i64, ptr %l532, !tbaa !24
  store i64 %t1003, ptr %l529, !tbaa !24
  br label %bb285
bb285:
  %t1004 = load i64, ptr %l529, !tbaa !24
  store i64 %t1004, ptr %l67, !tbaa !24
  store i64 0, ptr %l68, !tbaa !24
  br label %bb286
bb286:
  store %olang.scope zeroinitializer, ptr %s40
  %t1005 = load i64, ptr %l68, !tbaa !24
  %t1006 = load i64, ptr %l67, !tbaa !24
  %t1009 = icmp slt i64 %t1005, %t1006
  %t1011 = xor i1 %t1009, true
  br i1 %t1011, label %bb287, label %bb288
bb287:
  call void @__olang_scope_close(ptr %s40)
  br label %bb355
bb288:
  br label %bb289
bb289:
  %t1013 = load i64, ptr %l64, !tbaa !24
  %t1014 = load i64, ptr %l68, !tbaa !24
  %t1015 = load i64, ptr %l66, !tbaa !24
  %t1018 = mul i64 %t1014, %t1015
  %t1021 = add i64 %t1013, %t1018
  store i64 %t1021, ptr %l69, !tbaa !24
  %t1023 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t1023, ptr %l550, !tbaa !27
  %t1024 = load i64, ptr %l69, !tbaa !24
  %t1026 = getelementptr { i64, ptr }, ptr %l550, i32 0, i32 1
  %t1027 = load ptr, ptr %t1026, !tbaa !27
  %t1028 = getelementptr i64, ptr %t1027, i64 %t1024
  %t1029 = load i64, ptr %t1028, !tbaa !34
  %t1031 = icmp eq i64 %t1029, 2
  br i1 %t1031, label %bb290, label %bb291
bb290:
  store %olang.scope zeroinitializer, ptr %s41
  %t1033 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t1033, ptr %l555, !tbaa !27
  %t1034 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t1034, ptr %l556, !tbaa !27
  %t1035 = load i64, ptr %l69, !tbaa !24
  %t1037 = add i64 %t1035, 1
  %t1039 = getelementptr { i64, ptr }, ptr %l556, i32 0, i32 1
  %t1040 = load ptr, ptr %t1039, !tbaa !27
  %t1041 = getelementptr i64, ptr %t1040, i64 %t1037
  %t1042 = load i64, ptr %t1041, !tbaa !34
  %t1044 = add i64 %t1042, 1
  store i64 %t1044, ptr %l560, !tbaa !24
  %t1045 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t1045, ptr %l561, !tbaa !27
  %t1046 = load i64, ptr %l69, !tbaa !24
  %t1048 = add i64 %t1046, 2
  %t1050 = getelementptr { i64, ptr }, ptr %l561, i32 0, i32 1
  %t1051 = load ptr, ptr %t1050, !tbaa !27
  %t1052 = getelementptr i64, ptr %t1051, i64 %t1048
  %t1053 = load i64, ptr %t1052, !tbaa !34
  store i64 %t1053, ptr %l564, !tbaa !24
  %t1054 = load { i64, ptr }, ptr %l555, !tbaa !27
  %t1055 = extractvalue { i64, ptr } %t1054, 0
  store i64 %t1055, ptr %l565, !tbaa !24
  %t1056 = load i64, ptr %l560, !tbaa !24
  %t1057 = icmp sge i64 %t1056, 0
  br i1 %t1057, label %bb292, label %bb293
bb291:
  br label %bb316
bb292:
  %t1059 = load i64, ptr %l560, !tbaa !24
  %t1060 = load i64, ptr %l564, !tbaa !24
  %t1061 = icmp sle i64 %t1059, %t1060
  br i1 %t1061, label %bb294, label %bb295
bb293:
  call void @__olang_check_failed(ptr @olang_loc_4635f1a318b549bc_759936c3a7928310)
  unreachable
bb294:
  %t1063 = load i64, ptr %l564, !tbaa !24
  %t1064 = load i64, ptr %l565, !tbaa !24
  %t1065 = icmp sle i64 %t1063, %t1064
  br i1 %t1065, label %bb296, label %bb297
bb295:
  call void @__olang_check_failed(ptr @olang_loc_4635f1a318b549bc_759936c3a7928310)
  unreachable
bb296:
  %t1067 = getelementptr { i64, ptr }, ptr %l555, i32 0, i32 1
  %t1068 = load ptr, ptr %t1067, !tbaa !27
  %t1069 = load i64, ptr %l560, !tbaa !24
  %t1070 = load i64, ptr %l564, !tbaa !24
  %t1071 = getelementptr i8, ptr %t1068, i64 %t1069
  %t1072 = sub i64 %t1070, %t1069
  %t1073 = insertvalue { i64, ptr } undef, i64 %t1072, 0
  %t1074 = insertvalue { i64, ptr } %t1073, ptr %t1071, 1
  store { i64, ptr } %t1074, ptr %l569, !tbaa !27
  %t1075 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s41, i64 10)
  %t1076 = extractvalue { i32, i64 } %t1075, 1
  %t1077 = extractvalue { i32, i64 } %t1075, 0
  store i32 %t1077, ptr %l571
  %t1078 = icmp ne i32 %t1077, 0
  br i1 %t1078, label %bb299, label %ok.1079, !prof !99
ok.1079:
  store i64 %t1076, ptr %l570
  br label %bb298
bb297:
  call void @__olang_check_failed(ptr @olang_loc_4635f1a318b549bc_759936c3a7928310)
  unreachable
bb298:
  %t1080 = load { i64, ptr }, ptr %l569, !tbaa !27
  %t1081 = load i64, ptr %l570, !tbaa !24
  %t1082 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %t1080, i64 %t1081)
  %t1083 = extractvalue { i32, i64 } %t1082, 1
  %t1084 = extractvalue { i32, i64 } %t1082, 0
  store i32 %t1084, ptr %l573
  %t1085 = icmp ne i32 %t1084, 0
  br i1 %t1085, label %bb302, label %ok.1086, !prof !99
ok.1086:
  store i64 %t1083, ptr %l572
  br label %bb301
bb299:
  br label %bb300
bb300:
  store i64 0, ptr %l554, !tbaa !24
  br label %bb303
bb301:
  %t1087 = load i64, ptr %l572, !tbaa !24
  store i64 %t1087, ptr %l554, !tbaa !24
  br label %bb303
bb302:
  br label %bb300
bb303:
  %t1088 = load i64, ptr %l554, !tbaa !24
  store i64 %t1088, ptr %l70, !tbaa !24
  %t1089 = load i64, ptr %l70, !tbaa !24
  %t1091 = icmp slt i64 %t1089, 1000
  br i1 %t1091, label %bb304, label %bb305
bb304:
  call void @__olang_scope_close(ptr %s41)
  call void @__olang_scope_close(ptr %s40)
  br label %bb354
bb305:
  br label %bb306
bb306:
  store ptr %l51, ptr %l576, !tbaa !29
  %t1093 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t1093, ptr %l577, !tbaa !27
  %t1094 = load i64, ptr %l62, !tbaa !24
  store i64 %t1094, ptr %l578, !tbaa !24
  %t1095 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t1095, ptr %l579, !tbaa !27
  %t1096 = load i64, ptr %l69, !tbaa !24
  %t1098 = add i64 %t1096, 1
  %t1100 = getelementptr { i64, ptr }, ptr %l579, i32 0, i32 1
  %t1101 = load ptr, ptr %t1100, !tbaa !27
  %t1102 = getelementptr i64, ptr %t1101, i64 %t1098
  %t1103 = load i64, ptr %t1102, !tbaa !34
  store i64 %t1103, ptr %l582, !tbaa !24
  %t1104 = load { i64, ptr }, ptr %l577, !tbaa !27
  %t1105 = extractvalue { i64, ptr } %t1104, 0
  store i64 %t1105, ptr %l583, !tbaa !24
  %t1106 = load i64, ptr %l578, !tbaa !24
  %t1107 = icmp sge i64 %t1106, 0
  br i1 %t1107, label %bb307, label %bb308
bb307:
  %t1109 = load i64, ptr %l578, !tbaa !24
  %t1110 = load i64, ptr %l582, !tbaa !24
  %t1111 = icmp sle i64 %t1109, %t1110
  br i1 %t1111, label %bb309, label %bb310
bb308:
  call void @__olang_check_failed(ptr @olang_loc_2968b987139e6167_76a7d58ddfcdba8b)
  unreachable
bb309:
  %t1113 = load i64, ptr %l582, !tbaa !24
  %t1114 = load i64, ptr %l583, !tbaa !24
  %t1115 = icmp sle i64 %t1113, %t1114
  br i1 %t1115, label %bb311, label %bb312
bb310:
  call void @__olang_check_failed(ptr @olang_loc_2968b987139e6167_76a7d58ddfcdba8b)
  unreachable
bb311:
  %t1117 = getelementptr { i64, ptr }, ptr %l577, i32 0, i32 1
  %t1118 = load ptr, ptr %t1117, !tbaa !27
  %t1119 = load i64, ptr %l578, !tbaa !24
  %t1120 = load i64, ptr %l582, !tbaa !24
  %t1121 = getelementptr i8, ptr %t1118, i64 %t1119
  %t1122 = sub i64 %t1120, %t1119
  %t1123 = insertvalue { i64, ptr } undef, i64 %t1122, 0
  %t1124 = insertvalue { i64, ptr } %t1123, ptr %t1121, 1
  %t1125 = load ptr, ptr %l576, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t1125, { i64, ptr } %t1124)
  br label %bb313
bb312:
  call void @__olang_check_failed(ptr @olang_loc_2968b987139e6167_76a7d58ddfcdba8b)
  unreachable
bb313:
  store ptr %l51, ptr %l588, !tbaa !29
  %t1127 = load i64, ptr %l70, !tbaa !24
  %t1130 = call i64 @compiler_2femit_2emetaNumber(ptr %s0, ptr %l55, i64 %t1127)
  store i64 %t1130, ptr %l591
  br label %bb314
bb314:
  %t1131 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t1132 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t1133 = load i64, ptr %l591, !tbaa !24
  %t1134 = call i64 @__olang_fmt_i64(ptr null, i64 %t1133)
  %t1135 = add i64 %t1132, %t1134
  %t1136 = call ptr @__olang_scope_alloc(ptr %s41, i64 %t1135)
  call void @olang_textcopy(ptr %t1136, ptr %t1131, i64 %t1132)
  %t1137 = getelementptr i8, ptr %t1136, i64 %t1132
  %t1138 = call i64 @__olang_fmt_i64(ptr %t1137, i64 %t1133)
  %t1139 = insertvalue { i64, ptr } undef, i64 %t1135, 0
  %t1140 = insertvalue { i64, ptr } %t1139, ptr %t1136, 1
  %t1142 = extractvalue { i64, ptr } %t1140, 0
  %t1143 = extractvalue { i64, ptr } %t1140, 1
  %t1144 = mul i64 %t1142, 1
  %t1145 = call ptr @__olang_scope_alloc(ptr %s41, i64 %t1144)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1145, ptr %t1143, i64 %t1144, i1 false)
  %t1146 = insertvalue { i64, ptr } undef, i64 %t1142, 0
  %t1147 = insertvalue { i64, ptr } %t1146, ptr %t1145, 1
  %t1148 = load ptr, ptr %l588, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s41, ptr %t1148, { i64, ptr } %t1147)
  br label %bb315
bb315:
  %t1150 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t1150, ptr %l594, !tbaa !27
  %t1151 = load i64, ptr %l69, !tbaa !24
  %t1153 = add i64 %t1151, 2
  %t1155 = getelementptr { i64, ptr }, ptr %l594, i32 0, i32 1
  %t1156 = load ptr, ptr %t1155, !tbaa !27
  %t1157 = getelementptr i64, ptr %t1156, i64 %t1153
  %t1158 = load i64, ptr %t1157, !tbaa !34
  store i64 %t1158, ptr %l62, !tbaa !24
  call void @__olang_scope_close(ptr %s41)
  call void @__olang_scope_close(ptr %s40)
  br label %bb354
bb316:
  %t1160 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t1160, ptr %l598, !tbaa !27
  %t1161 = load i64, ptr %l69, !tbaa !24
  %t1163 = getelementptr { i64, ptr }, ptr %l598, i32 0, i32 1
  %t1164 = load ptr, ptr %t1163, !tbaa !27
  %t1165 = getelementptr i64, ptr %t1164, i64 %t1161
  %t1166 = load i64, ptr %t1165, !tbaa !34
  %t1168 = icmp ne i64 %t1166, 0
  br i1 %t1168, label %bb317, label %bb318
bb317:
  call void @__olang_scope_close(ptr %s40)
  br label %bb354
bb318:
  br label %bb319
bb319:
  %t1170 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t1170, ptr %l602, !tbaa !27
  %t1171 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t1171, ptr %l603, !tbaa !27
  %t1172 = load i64, ptr %l69, !tbaa !24
  %t1174 = add i64 %t1172, 1
  %t1176 = getelementptr { i64, ptr }, ptr %l603, i32 0, i32 1
  %t1177 = load ptr, ptr %t1176, !tbaa !27
  %t1178 = getelementptr i64, ptr %t1177, i64 %t1174
  %t1179 = load i64, ptr %t1178, !tbaa !34
  store i64 %t1179, ptr %l606, !tbaa !24
  %t1180 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t1180, ptr %l607, !tbaa !27
  %t1181 = load i64, ptr %l69, !tbaa !24
  %t1183 = add i64 %t1181, 2
  %t1185 = getelementptr { i64, ptr }, ptr %l607, i32 0, i32 1
  %t1186 = load ptr, ptr %t1185, !tbaa !27
  %t1187 = getelementptr i64, ptr %t1186, i64 %t1183
  %t1188 = load i64, ptr %t1187, !tbaa !34
  store i64 %t1188, ptr %l610, !tbaa !24
  %t1189 = load { i64, ptr }, ptr %l602, !tbaa !27
  %t1190 = extractvalue { i64, ptr } %t1189, 0
  store i64 %t1190, ptr %l611, !tbaa !24
  %t1191 = load i64, ptr %l606, !tbaa !24
  %t1192 = icmp sge i64 %t1191, 0
  br i1 %t1192, label %bb320, label %bb321
bb320:
  %t1194 = load i64, ptr %l606, !tbaa !24
  %t1195 = load i64, ptr %l610, !tbaa !24
  %t1196 = icmp sle i64 %t1194, %t1195
  br i1 %t1196, label %bb322, label %bb323
bb321:
  call void @__olang_check_failed(ptr @olang_loc_493930ee087ace8a_eb37955c75d36e8e)
  unreachable
bb322:
  %t1198 = load i64, ptr %l610, !tbaa !24
  %t1199 = load i64, ptr %l611, !tbaa !24
  %t1200 = icmp sle i64 %t1198, %t1199
  br i1 %t1200, label %bb324, label %bb325
bb323:
  call void @__olang_check_failed(ptr @olang_loc_493930ee087ace8a_eb37955c75d36e8e)
  unreachable
bb324:
  %t1202 = getelementptr { i64, ptr }, ptr %l602, i32 0, i32 1
  %t1203 = load ptr, ptr %t1202, !tbaa !27
  %t1204 = load i64, ptr %l606, !tbaa !24
  %t1205 = load i64, ptr %l610, !tbaa !24
  %t1206 = getelementptr i8, ptr %t1203, i64 %t1204
  %t1207 = sub i64 %t1205, %t1204
  %t1208 = insertvalue { i64, ptr } undef, i64 %t1207, 0
  %t1209 = insertvalue { i64, ptr } %t1208, ptr %t1206, 1
  store { i64, ptr } %t1209, ptr %l71, !tbaa !27
  %t1211 = load ptr, ptr %l0, !tbaa !29
  %t1212 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t1215 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitemNamed(ptr %v0, ptr %v0, ptr %t1211, { i64, ptr } %t1212)
  store i64 %t1215, ptr %l618
  br label %bb326
bb325:
  call void @__olang_check_failed(ptr @olang_loc_493930ee087ace8a_eb37955c75d36e8e)
  unreachable
bb326:
  %t1216 = load i64, ptr %l618, !tbaa !24
  store i64 %t1216, ptr %l72, !tbaa !24
  %t1217 = load i64, ptr %l72, !tbaa !24
  %t1219 = icmp slt i64 %t1217, 0
  br i1 %t1219, label %bb327, label %bb328
bb327:
  store i1 true, ptr %l621, !tbaa !21
  br label %bb330
bb328:
  %t1221 = load i64, ptr %l72, !tbaa !24
  %t1224 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_H86f724e2dc8b3b4d675d56b45c81e2ce(ptr %s0, ptr %l29, i64 %t1221)
  store i1 %t1224, ptr %l624
  br label %bb329
bb329:
  %t1225 = load i1, ptr %l624, !tbaa !21
  %t1226 = xor i1 %t1225, true
  store i1 %t1226, ptr %l621, !tbaa !21
  br label %bb330
bb330:
  %t1228 = load i1, ptr %l621, !tbaa !21
  br i1 %t1228, label %bb331, label %bb332
bb331:
  call void @__olang_scope_close(ptr %s40)
  br label %bb354
bb332:
  br label %bb333
bb333:
  store ptr %l51, ptr %l626, !tbaa !29
  %t1229 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t1229, ptr %l627, !tbaa !27
  %t1230 = load i64, ptr %l62, !tbaa !24
  store i64 %t1230, ptr %l628, !tbaa !24
  %t1231 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t1231, ptr %l629, !tbaa !27
  %t1232 = load i64, ptr %l69, !tbaa !24
  %t1234 = add i64 %t1232, 1
  %t1236 = getelementptr { i64, ptr }, ptr %l629, i32 0, i32 1
  %t1237 = load ptr, ptr %t1236, !tbaa !27
  %t1238 = getelementptr i64, ptr %t1237, i64 %t1234
  %t1239 = load i64, ptr %t1238, !tbaa !34
  store i64 %t1239, ptr %l632, !tbaa !24
  %t1240 = load { i64, ptr }, ptr %l627, !tbaa !27
  %t1241 = extractvalue { i64, ptr } %t1240, 0
  store i64 %t1241, ptr %l633, !tbaa !24
  %t1242 = load i64, ptr %l628, !tbaa !24
  %t1243 = icmp sge i64 %t1242, 0
  br i1 %t1243, label %bb334, label %bb335
bb334:
  %t1245 = load i64, ptr %l628, !tbaa !24
  %t1246 = load i64, ptr %l632, !tbaa !24
  %t1247 = icmp sle i64 %t1245, %t1246
  br i1 %t1247, label %bb336, label %bb337
bb335:
  call void @__olang_check_failed(ptr @olang_loc_82b9110c3ab34805_cdca7d87f9ba97f1)
  unreachable
bb336:
  %t1249 = load i64, ptr %l632, !tbaa !24
  %t1250 = load i64, ptr %l633, !tbaa !24
  %t1251 = icmp sle i64 %t1249, %t1250
  br i1 %t1251, label %bb338, label %bb339
bb337:
  call void @__olang_check_failed(ptr @olang_loc_82b9110c3ab34805_cdca7d87f9ba97f1)
  unreachable
bb338:
  %t1253 = getelementptr { i64, ptr }, ptr %l627, i32 0, i32 1
  %t1254 = load ptr, ptr %t1253, !tbaa !27
  %t1255 = load i64, ptr %l628, !tbaa !24
  %t1256 = load i64, ptr %l632, !tbaa !24
  %t1257 = getelementptr i8, ptr %t1254, i64 %t1255
  %t1258 = sub i64 %t1256, %t1255
  %t1259 = insertvalue { i64, ptr } undef, i64 %t1258, 0
  %t1260 = insertvalue { i64, ptr } %t1259, ptr %t1257, 1
  %t1261 = load ptr, ptr %l626, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t1261, { i64, ptr } %t1260)
  br label %bb340
bb339:
  call void @__olang_check_failed(ptr @olang_loc_82b9110c3ab34805_cdca7d87f9ba97f1)
  unreachable
bb340:
  store ptr %l51, ptr %l638, !tbaa !29
  %t1263 = load i64, ptr %l72, !tbaa !24
  %t1266 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %s0, ptr %s0, ptr %l29, i64 %t1263)
  %t1267 = extractvalue { i32, { i64, ptr } } %t1266, 1
  %t1268 = extractvalue { i32, { i64, ptr } } %t1266, 0
  store i32 %t1268, ptr %l643
  %t1269 = icmp ne i32 %t1268, 0
  br i1 %t1269, label %bb342, label %ok.1270, !prof !99
ok.1270:
  store { i64, ptr } %t1267, ptr %l642
  br label %bb341
bb341:
  %t1271 = load { i64, ptr }, ptr %l642, !tbaa !27
  store { i64, ptr } %t1271, ptr %l639, !tbaa !27
  br label %bb344
bb342:
  br label %bb343
bb343:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l639, !tbaa !27
  br label %bb344
bb344:
  %t1272 = load ptr, ptr %l638, !tbaa !29
  %t1273 = load { i64, ptr }, ptr %l639, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t1272, { i64, ptr } %t1273)
  br label %bb345
bb345:
  store ptr %l51, ptr %l644, !tbaa !29
  %t1274 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t1274, ptr %l645, !tbaa !27
  %t1275 = load ptr, ptr %l0, !tbaa !29
  %t1277 = getelementptr %"compiler/emit:Emitter", ptr %t1275, i32 0, i32 18
  %t1278 = load i64, ptr %l72, !tbaa !24
  %t1281 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s40, ptr %t1277, i64 %t1278)
  store { i64, ptr } %t1281, ptr %l649
  br label %bb346
bb346:
  %t1282 = load { i64, ptr }, ptr %l649, !tbaa !27
  %t1283 = extractvalue { i64, ptr } %t1282, 0
  store i64 %t1283, ptr %l650, !tbaa !24
  %t1284 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t1287 = extractvalue { i64, ptr } %t1284, 0
  store i64 %t1287, ptr %l653, !tbaa !24
  %t1288 = load { i64, ptr }, ptr %l645, !tbaa !27
  %t1289 = extractvalue { i64, ptr } %t1288, 0
  store i64 %t1289, ptr %l654, !tbaa !24
  %t1290 = load i64, ptr %l650, !tbaa !24
  %t1291 = icmp sge i64 %t1290, 0
  br i1 %t1291, label %bb347, label %bb348
bb347:
  %t1293 = load i64, ptr %l650, !tbaa !24
  %t1294 = load i64, ptr %l653, !tbaa !24
  %t1295 = icmp sle i64 %t1293, %t1294
  br i1 %t1295, label %bb349, label %bb350
bb348:
  call void @__olang_check_failed(ptr @olang_loc_20b52d6bf9b06c28_18043bf0e12df584)
  unreachable
bb349:
  %t1297 = load i64, ptr %l653, !tbaa !24
  %t1298 = load i64, ptr %l654, !tbaa !24
  %t1299 = icmp sle i64 %t1297, %t1298
  br i1 %t1299, label %bb351, label %bb352
bb350:
  call void @__olang_check_failed(ptr @olang_loc_20b52d6bf9b06c28_18043bf0e12df584)
  unreachable
bb351:
  %t1301 = getelementptr { i64, ptr }, ptr %l645, i32 0, i32 1
  %t1302 = load ptr, ptr %t1301, !tbaa !27
  %t1303 = load i64, ptr %l650, !tbaa !24
  %t1304 = load i64, ptr %l653, !tbaa !24
  %t1305 = getelementptr i8, ptr %t1302, i64 %t1303
  %t1306 = sub i64 %t1304, %t1303
  %t1307 = insertvalue { i64, ptr } undef, i64 %t1306, 0
  %t1308 = insertvalue { i64, ptr } %t1307, ptr %t1305, 1
  %t1309 = load ptr, ptr %l644, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t1309, { i64, ptr } %t1308)
  br label %bb353
bb352:
  call void @__olang_check_failed(ptr @olang_loc_20b52d6bf9b06c28_18043bf0e12df584)
  unreachable
bb353:
  %t1311 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t1311, ptr %l659, !tbaa !27
  %t1312 = load i64, ptr %l69, !tbaa !24
  %t1314 = add i64 %t1312, 2
  %t1316 = getelementptr { i64, ptr }, ptr %l659, i32 0, i32 1
  %t1317 = load ptr, ptr %t1316, !tbaa !27
  %t1318 = getelementptr i64, ptr %t1317, i64 %t1314
  %t1319 = load i64, ptr %t1318, !tbaa !34
  store i64 %t1319, ptr %l62, !tbaa !24
  call void @__olang_scope_close(ptr %s40)
  br label %bb354
bb354:
  %t1321 = load i64, ptr %l68, !tbaa !24
  %t1323 = add i64 %t1321, 1
  store i64 %t1323, ptr %l68, !tbaa !24
  br label %bb286
bb355:
  store ptr %l51, ptr %l665, !tbaa !29
  %t1325 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t1325, ptr %l666, !tbaa !27
  %t1326 = load i64, ptr %l62, !tbaa !24
  store i64 %t1326, ptr %l667, !tbaa !24
  %t1327 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t1330 = extractvalue { i64, ptr } %t1327, 0
  store i64 %t1330, ptr %l670, !tbaa !24
  %t1331 = load { i64, ptr }, ptr %l666, !tbaa !27
  %t1332 = extractvalue { i64, ptr } %t1331, 0
  store i64 %t1332, ptr %l671, !tbaa !24
  %t1333 = load i64, ptr %l667, !tbaa !24
  %t1334 = icmp sge i64 %t1333, 0
  br i1 %t1334, label %bb356, label %bb357
bb356:
  %t1336 = load i64, ptr %l667, !tbaa !24
  %t1337 = load i64, ptr %l670, !tbaa !24
  %t1338 = icmp sle i64 %t1336, %t1337
  br i1 %t1338, label %bb358, label %bb359
bb357:
  call void @__olang_check_failed(ptr @olang_loc_9bd48c53dce2a143_9d318240a700faef)
  unreachable
bb358:
  %t1340 = load i64, ptr %l670, !tbaa !24
  %t1341 = load i64, ptr %l671, !tbaa !24
  %t1342 = icmp sle i64 %t1340, %t1341
  br i1 %t1342, label %bb360, label %bb361
bb359:
  call void @__olang_check_failed(ptr @olang_loc_9bd48c53dce2a143_9d318240a700faef)
  unreachable
bb360:
  %t1344 = getelementptr { i64, ptr }, ptr %l666, i32 0, i32 1
  %t1345 = load ptr, ptr %t1344, !tbaa !27
  %t1346 = load i64, ptr %l667, !tbaa !24
  %t1347 = load i64, ptr %l670, !tbaa !24
  %t1348 = getelementptr i8, ptr %t1345, i64 %t1346
  %t1349 = sub i64 %t1347, %t1346
  %t1350 = insertvalue { i64, ptr } undef, i64 %t1349, 0
  %t1351 = insertvalue { i64, ptr } %t1350, ptr %t1348, 1
  %t1352 = load ptr, ptr %l665, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t1352, { i64, ptr } %t1351)
  br label %bb362
bb361:
  call void @__olang_check_failed(ptr @olang_loc_9bd48c53dce2a143_9d318240a700faef)
  unreachable
bb362:
  br label %bb363
bb363:
  %t1354 = load i64, ptr %l57, !tbaa !24
  %t1356 = add i64 %t1354, 1
  store i64 %t1356, ptr %l57, !tbaa !24
  br label %bb236
bb364:
  store ptr %l51, ptr %l678, !tbaa !29
  %t1359 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l25)
  store { i64, ptr } %t1359, ptr %l680
  br label %bb365
bb365:
  %t1360 = load { i64, ptr }, ptr %l680, !tbaa !27
  %t1361 = extractvalue { i64, ptr } %t1360, 0
  %t1362 = extractvalue { i64, ptr } %t1360, 1
  %t1363 = mul i64 %t1361, 1
  %t1364 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1363)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1364, ptr %t1362, i64 %t1363, i1 false)
  %t1365 = insertvalue { i64, ptr } undef, i64 %t1361, 0
  %t1366 = insertvalue { i64, ptr } %t1365, ptr %t1364, 1
  %t1367 = load ptr, ptr %l678, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t1367, { i64, ptr } %t1366)
  br label %bb366
bb366:
  %t1369 = load ptr, ptr %l0, !tbaa !29
  %t1371 = getelementptr %"compiler/emit:Emitter", ptr %t1369, i32 0, i32 68
  %t1372 = load i64, ptr %t1371, !tbaa !24
  %t1374 = icmp sge i64 %t1372, 0
  br i1 %t1374, label %bb367, label %bb368
bb367:
  %t1376 = load ptr, ptr %l0, !tbaa !29
  %t1378 = getelementptr %"compiler/emit:Emitter", ptr %t1376, i32 0, i32 68
  %t1379 = load i64, ptr %t1378, !tbaa !24
  %t1382 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %s0, ptr %l55, i64 %t1379)
  store i1 %t1382, ptr %l689
  br label %bb369
bb368:
  store i1 false, ptr %l685, !tbaa !21
  br label %bb370
bb369:
  %t1383 = load i1, ptr %l689, !tbaa !21
  store i1 %t1383, ptr %l685, !tbaa !21
  br label %bb370
bb370:
  %t1384 = load i1, ptr %l685, !tbaa !21
  br i1 %t1384, label %bb371, label %bb372
bb371:
  store %olang.scope zeroinitializer, ptr %s48
  store ptr %l51, ptr %l690, !tbaa !29
  %t1385 = load ptr, ptr %l0, !tbaa !29
  %t1387 = getelementptr %"compiler/emit:Emitter", ptr %t1385, i32 0, i32 68
  %t1388 = load i64, ptr %t1387, !tbaa !24
  %t1391 = call i64 @compiler_2femit_2emetaNumber(ptr %s0, ptr %l55, i64 %t1388)
  store i64 %t1391, ptr %l694
  br label %bb373
bb372:
  br label %bb376
bb373:
  %t1392 = load i64, ptr %l694, !tbaa !24
  %t1393 = call { i64, ptr } @compiler_2femit_2edbgTail(ptr %s48, i64 %t1392)
  store { i64, ptr } %t1393, ptr %l695
  br label %bb374
bb374:
  %t1394 = load { i64, ptr }, ptr %l695, !tbaa !27
  %t1395 = extractvalue { i64, ptr } %t1394, 0
  %t1396 = extractvalue { i64, ptr } %t1394, 1
  %t1397 = mul i64 %t1395, 1
  %t1398 = call ptr @__olang_scope_alloc(ptr %s48, i64 %t1397)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1398, ptr %t1396, i64 %t1397, i1 false)
  %t1399 = insertvalue { i64, ptr } undef, i64 %t1395, 0
  %t1400 = insertvalue { i64, ptr } %t1399, ptr %t1398, 1
  %t1401 = load ptr, ptr %l690, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s48, ptr %t1401, { i64, ptr } %t1400)
  br label %bb375
bb375:
  call void @__olang_scope_close(ptr %s48)
  br label %bb376
bb376:
  store ptr %l51, ptr %l697, !tbaa !29
  %t1403 = load ptr, ptr %l0, !tbaa !29
  %t1405 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eattributes(ptr %v0, ptr %s0, ptr %t1403)
  store { i64, ptr } %t1405, ptr %l699
  br label %bb377
bb377:
  %t1406 = load { i64, ptr }, ptr %l699, !tbaa !27
  %t1407 = extractvalue { i64, ptr } %t1406, 0
  %t1408 = extractvalue { i64, ptr } %t1406, 1
  %t1409 = mul i64 %t1407, 1
  %t1410 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1409)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1410, ptr %t1408, i64 %t1409, i1 false)
  %t1411 = insertvalue { i64, ptr } undef, i64 %t1407, 0
  %t1412 = insertvalue { i64, ptr } %t1411, ptr %t1410, 1
  %t1413 = load ptr, ptr %l697, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t1413, { i64, ptr } %t1412)
  br label %bb378
bb378:
  %t1416 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v3, ptr %l51)
  store { i64, ptr } %t1416, ptr %l702
  br label %bb379
bb379:
  call void @__olang_scope_close(ptr %s0)
  %t1417 = load { i64, ptr }, ptr %l702, !tbaa !27
  store { i64, ptr } %t1417, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecBitfield(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l17 = alloca i64
  %l20 = alloca i1
  %l21 = alloca i1
  %l24 = alloca i1
  %l27 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l40 = alloca i64
  %rv = alloca { i64, ptr }
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load i32, ptr %l1, !tbaa !23
  %t7 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t10 = icmp eq i32 %t6, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l11, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t12, ptr %l12, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t13, 0
  store i64 %t14, ptr %l13, !tbaa !24
  %t15 = load i64, ptr %l13, !tbaa !24
  %t16 = mul i64 %t15, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  %t18 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l14, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = load i64, ptr %l13, !tbaa !24
  %t25 = mul i64 %t24, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t21, ptr %t23, i64 %t25, i1 false)
  %t26 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t26, ptr %l12, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t27, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t29 = load i32, ptr %l1, !tbaa !23
  %t32 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePackedBits(ptr %v0, ptr %t28, i32 %t29)
  store i64 %t32, ptr %l17
  br label %bb4
bb4:
  %t33 = load i64, ptr %l17, !tbaa !24
  store i64 %t33, ptr %l3, !tbaa !24
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t35 = load i32, ptr %l1, !tbaa !23
  %t38 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t34, i32 %t35)
  store i1 %t38, ptr %l20
  br label %bb5
bb5:
  %t39 = load i1, ptr %l20, !tbaa !21
  br i1 %t39, label %bb6, label %bb7
bb6:
  %t40 = load ptr, ptr %l2, !tbaa !29
  %t41 = load i32, ptr %l1, !tbaa !23
  %t44 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t40, i32 %t41)
  store i1 %t44, ptr %l24
  br label %bb8
bb7:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb9
bb8:
  %t45 = load i1, ptr %l24, !tbaa !21
  %t46 = xor i1 %t45, true
  store i1 %t46, ptr %l21, !tbaa !21
  br label %bb9
bb9:
  %t48 = load i1, ptr %l21, !tbaa !21
  store i1 %t48, ptr %l4, !tbaa !21
  %t49 = load i1, ptr %l4, !tbaa !21
  br i1 %t49, label %bb10, label %bb11
bb10:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d10, i32 0, i32 1) }, ptr %l27, !tbaa !27
  br label %bb12
bb11:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %l27, !tbaa !27
  br label %bb12
bb12:
  %t51 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t51, ptr %l5, !tbaa !27
  %t52 = load i64, ptr %l3, !tbaa !24
  %t54 = icmp sgt i64 %t52, 64
  br i1 %t54, label %bb13, label %bb14
bb13:
  %t56 = load i1, ptr %l4, !tbaa !21
  br i1 %t56, label %bb15, label %bb16
bb14:
  br label %bb18
bb15:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d12, i32 0, i32 1) }, ptr %l32, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t58, ptr %l31, !tbaa !27
  br label %bb17
bb16:
  store { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d13, i32 0, i32 1) }, ptr %l34, !tbaa !27
  %t60 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t60, ptr %l31, !tbaa !27
  br label %bb17
bb17:
  %t62 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t62, 0
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load i64, ptr %l36, !tbaa !24
  %t65 = mul i64 %t64, 1
  %t66 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t65)
  %t67 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  store { i64, ptr } %t68, ptr %l37, !tbaa !27
  %t69 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = load i64, ptr %l36, !tbaa !24
  %t74 = mul i64 %t73, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t70, ptr %t72, i64 %t74, i1 false)
  %t75 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t75, ptr %l31, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t76, ptr %rv
  br label %ret
bb18:
  %t77 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t77, ptr %l38, !tbaa !27
  %t78 = load i64, ptr %l3, !tbaa !24
  %t80 = call i64 @compiler_2femit_2eIntBytes8(i64 %t78)
  store i64 %t80, ptr %l40
  br label %bb19
bb19:
  %t81 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t81, 1
  %t83 = extractvalue { i64, ptr } %t81, 0
  %t84 = load i64, ptr %l40, !tbaa !24
  %t85 = call i64 @__olang_fmt_i64(ptr null, i64 %t84)
  %t86 = add i64 %t83, %t85
  %t87 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t88 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t89 = add i64 %t86, %t88
  %t90 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t89)
  call void @olang_textcopy(ptr %t90, ptr %t82, i64 %t83)
  %t91 = getelementptr i8, ptr %t90, i64 %t83
  %t92 = call i64 @__olang_fmt_i64(ptr %t91, i64 %t84)
  %t93 = getelementptr i8, ptr %t91, i64 %t85
  call void @olang_textcopy(ptr %t93, ptr %t87, i64 %t88)
  %t94 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t90, 1
  store { i64, ptr } %t95, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecHeader(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/cabi:Way"
  %l4 = alloca i32
  %l8 = alloca i32
  %l12 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l23 = alloca i1
  %l30 = alloca %"compiler/cabi:Way"
  %l32 = alloca { i64, ptr }
  %l36 = alloca i1
  %l38 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t4, i32 %a1)
  store i32 %t8, ptr %l8
  br label %bb1
bb1:
  %t9 = load i32, ptr %l8, !tbaa !23
  store i32 %t9, ptr %l2, !tbaa !23
  %t10 = load i32, ptr %l2, !tbaa !23
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t14 = icmp eq i32 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb4
bb3:
  %t16 = load i32, ptr %l2, !tbaa !23
  %t17 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t20 = icmp eq i32 %t16, %t17
  store i1 %t20, ptr %l12, !tbaa !21
  br label %bb4
bb4:
  %t22 = load i1, ptr %l12, !tbaa !21
  br i1 %t22, label %bb5, label %bb6
bb5:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %l16, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t23, ptr %l17, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 0
  store i64 %t25, ptr %l18, !tbaa !24
  %t26 = load i64, ptr %l18, !tbaa !24
  %t27 = mul i64 %t26, 1
  %t28 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t27)
  %t29 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  store { i64, ptr } %t30, ptr %l19, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = load i64, ptr %l18, !tbaa !24
  %t36 = mul i64 %t35, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t32, ptr %t34, i64 %t36, i1 false)
  %t37 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t37, ptr %l17, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t38 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t38, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/emit:Emitter", ptr %t39, i32 0, i32 0
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t43 = load i32, ptr %l2, !tbaa !23
  %t46 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t42, i32 %t43)
  store i1 %t46, ptr %l23
  br label %bb8
bb8:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/emit:Emitter", ptr %t47, i32 0, i32 3
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/emit:Emitter", ptr %t51, i32 0, i32 55
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  %t55 = load i32, ptr %l2, !tbaa !23
  %t57 = inttoptr i64 0 to ptr
  %t61 = call %"compiler/cabi:Way" @compiler_2fcabi_2eWay_2eResult(ptr %v0, ptr %v0, ptr %s0, ptr %t57, ptr %t50, { i64, ptr } %t54, i32 %t55)
  store %"compiler/cabi:Way" %t61, ptr %l30
  br label %bb9
bb9:
  %t62 = load %"compiler/cabi:Way", ptr %l30
  store %"compiler/cabi:Way" %t62, ptr %l3
  %t63 = getelementptr %"compiler/cabi:Way", ptr %l3, i32 0, i32 0
  %t64 = load i32, ptr %t63, !range !{i32 0, i32 5}
  store i32 %t64, ptr %l4
  %t66 = load i32, ptr %l4, !range !{i32 0, i32 5}
  %t68 = trunc i64 0 to i32
  %t69 = icmp eq i32 %t66, %t68
  br i1 %t69, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb18
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t71 = getelementptr %"compiler/cabi:Way", ptr %l3, i32 0, i32 4
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  %t74 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s2, { i64, ptr } %t72, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d16, i32 0, i32 1) })
  store i1 %t74, ptr %l36
  br label %bb13
bb13:
  %t75 = load i1, ptr %l36, !tbaa !21
  %t76 = xor i1 %t75, true
  br i1 %t76, label %bb14, label %bb15
bb14:
  %t78 = getelementptr %"compiler/cabi:Way", ptr %l3, i32 0, i32 4
  %t79 = load { i64, ptr }, ptr %t78, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t79, 1
  %t82 = extractvalue { i64, ptr } %t79, 0
  %t83 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t84 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t85 = add i64 %t82, %t84
  %t86 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t85)
  call void @olang_textcopy(ptr %t86, ptr %t81, i64 %t82)
  %t87 = getelementptr i8, ptr %t86, i64 %t82
  call void @olang_textcopy(ptr %t87, ptr %t83, i64 %t84)
  %t88 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t86, 1
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t92 = extractvalue { i64, ptr } %t89, 1
  %t93 = mul i64 %t91, 1
  %t94 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t93)
  call void @llvm.memcpy.p0.p0.i64(ptr %t94, ptr %t92, i64 %t93, i1 false)
  %t95 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  store { i64, ptr } %t96, ptr %l38, !tbaa !27
  br label %bb16
bb15:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l38, !tbaa !27
  br label %bb16
bb16:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load i32, ptr %l2, !tbaa !23
  %t102 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s2, ptr %t98, i32 %t99)
  store { i64, ptr } %t102, ptr %l44
  br label %bb17
bb17:
  %t103 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 1
  %t105 = extractvalue { i64, ptr } %t103, 0
  %t106 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t106, 1
  %t108 = extractvalue { i64, ptr } %t106, 0
  %t109 = add i64 %t105, %t108
  %t110 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t109)
  call void @olang_textcopy(ptr %t110, ptr %t104, i64 %t105)
  %t111 = getelementptr i8, ptr %t110, i64 %t105
  call void @olang_textcopy(ptr %t111, ptr %t107, i64 %t108)
  %t112 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t110, 1
  store { i64, ptr } %t113, ptr %l32, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb18:
  %t115 = load i32, ptr %l4, !range !{i32 0, i32 5}
  %t117 = trunc i64 1 to i32
  %t118 = icmp eq i32 %t115, %t117
  br i1 %t118, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t121 = call { i64, ptr } @compiler_2fcabi_2ePartsType(ptr %s0, ptr %v1, ptr %l3)
  store { i64, ptr } %t121, ptr %l49
  br label %bb22
bb22:
  %t122 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t122, ptr %l32, !tbaa !27
  br label %bb28
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l50, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t123, ptr %l32, !tbaa !27
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_6aada305a3873fb6_c16c54d6f05c33ea)
  unreachable
bb28:
  %t125 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t125, 0
  store i64 %t126, ptr %l52, !tbaa !24
  %t127 = load i64, ptr %l52, !tbaa !24
  %t128 = mul i64 %t127, 1
  %t129 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t128)
  %t130 = insertvalue { i64, ptr } undef, i64 %t127, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t129, 1
  store { i64, ptr } %t131, ptr %l53, !tbaa !27
  %t132 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = load i64, ptr %l52, !tbaa !24
  %t137 = mul i64 %t136, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t133, ptr %t135, i64 %t137, i1 false)
  %t138 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t138, ptr %l32, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t139 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t139, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecloneSym(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/lower:Clone"
  %l7 = alloca %"compiler/lower:Clone"
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l14 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/lower:Lowerer", ptr %t4, i32 0, i32 39
  %t10 = call %"compiler/lower:Clone" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aClone_3e_2eAt_3ccompiler_2flower_3aClone_3e(ptr %v0, ptr %t6, i64 %a1)
  store %"compiler/lower:Clone" %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load %"compiler/lower:Clone", ptr %l7
  store %"compiler/lower:Clone" %t11, ptr %l2
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/lower:Clone", ptr %l2, i32 0, i32 0
  %t14 = load { i64, [2 x i64] }, ptr %t13
  %t17 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s0, ptr %t12, { i64, [2 x i64] } %t14)
  store { i64, ptr } %t17, ptr %l10
  br label %bb2
bb2:
  %t18 = getelementptr %"compiler/lower:Clone", ptr %l2, i32 0, i32 1
  %t19 = load i64, ptr %t18, !tbaa !24
  store i64 %t19, ptr %l11, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/lower:Clone", ptr %l2, i32 0, i32 2
  %t22 = load { i64, [2 x i64] }, ptr %t21
  %t25 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s0, ptr %t20, { i64, [2 x i64] } %t22)
  store { i64, ptr } %t25, ptr %l14
  br label %bb3
bb3:
  %t26 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t26, 1
  %t28 = extractvalue { i64, ptr } %t26, 0
  %t29 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t31 = add i64 %t28, %t30
  %t32 = load i64, ptr %l11, !tbaa !24
  %t33 = call i64 @__olang_fmt_i64(ptr null, i64 %t32)
  %t34 = add i64 %t31, %t33
  %t35 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t37 = add i64 %t34, %t36
  %t38 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 1
  %t40 = extractvalue { i64, ptr } %t38, 0
  %t41 = add i64 %t37, %t40
  %t42 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t41)
  call void @olang_textcopy(ptr %t42, ptr %t27, i64 %t28)
  %t43 = getelementptr i8, ptr %t42, i64 %t28
  call void @olang_textcopy(ptr %t43, ptr %t29, i64 %t30)
  %t44 = getelementptr i8, ptr %t43, i64 %t30
  %t45 = call i64 @__olang_fmt_i64(ptr %t44, i64 %t32)
  %t46 = getelementptr i8, ptr %t44, i64 %t33
  call void @olang_textcopy(ptr %t46, ptr %t35, i64 %t36)
  %t47 = getelementptr i8, ptr %t46, i64 %t36
  call void @olang_textcopy(ptr %t47, ptr %t39, i64 %t40)
  %t48 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t42, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t49, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecodeFor(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i32
  %lp3 = alloca ptr
  %l4 = alloca i32
  %lp5 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l11 = alloca i32
  %l14 = alloca i1
  %l15 = alloca i1
  %l19 = alloca i64
  %l25 = alloca i64
  %l31 = alloca { i64, ptr }
  %l35 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i64
  %rv = alloca { i64, ptr }
  %t32 = alloca { i64, [4 x i64] }, align 8
  %t35 = alloca { i64, [7 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load { i64, [2 x i64] }, ptr %l1
  %t5 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %v1, ptr %t1, { i64, [2 x i64] } %t2)
  store { i64, ptr } %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t6, ptr %lp3
  %t7 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t8 = load ptr, ptr %lp3
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load { i64, [2 x i64] }, ptr %l1
  %t13 = call i32 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecodeType(ptr %v0, ptr %t9, { i64, [2 x i64] } %t10)
  store i32 %t13, ptr %l11
  br label %bb2
bb2:
  %t14 = load i32, ptr %l11, !tbaa !23
  store i32 %t14, ptr %l4, !tbaa !23
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load { i64, [2 x i64] }, ptr %l1
  %t19 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehasEnv(ptr %v0, ptr %t15, { i64, [2 x i64] } %t16)
  store i1 %t19, ptr %l14
  br label %bb3
bb3:
  %t20 = load i1, ptr %l14, !tbaa !21
  br i1 %t20, label %bb4, label %bb5
bb4:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load { i64, [2 x i64] }, ptr %l1
  %t23 = load i32, ptr %l4, !tbaa !23
  %t27 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2epassedOf(ptr %v0, ptr %t21, { i64, [2 x i64] } %t22, i32 %t23)
  store i64 %t27, ptr %l19
  br label %bb6
bb5:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb8
bb6:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/emit:Emitter", ptr %t28, i32 0, i32 3
  %t31 = load ptr, ptr %t30, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t32
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t32, i32 0, i32 0
  store i64 0, ptr %t33
  %t34 = load { i64, [4 x i64] }, ptr %t32
  store { i64, [7 x i64] } zeroinitializer, ptr %t35
  %t36 = getelementptr { i64, [7 x i64] }, ptr %t35, i32 0, i32 0
  store i64 2, ptr %t36
  %t38 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t34, 0
  %t39 = getelementptr { i64, [7 x i64] }, ptr %t35, i32 0, i32 1
  store { { i64, [4 x i64] } } %t38, ptr %t39
  %t40 = load { i64, [7 x i64] }, ptr %t35
  %t41 = load i32, ptr %l2, !tbaa !23
  %t45 = call i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %t31, { i64, [7 x i64] } %t40, i32 %t41)
  store i64 %t45, ptr %l25
  br label %bb7
bb7:
  %t46 = load i64, ptr %l19, !tbaa !24
  %t47 = load i64, ptr %l25, !tbaa !24
  %t48 = icmp eq i64 %t46, %t47
  store i1 %t48, ptr %l15, !tbaa !21
  br label %bb8
bb8:
  %t50 = load i1, ptr %l15, !tbaa !21
  br i1 %t50, label %bb9, label %bb10
bb9:
  %t51 = load ptr, ptr %lp3
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  store { i64, ptr } %t52, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %lp3
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t57 = load i32, ptr %l2, !tbaa !23
  %t61 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ethunkSym(ptr %v0, ptr %v1, ptr %v1, ptr %t54, { i64, ptr } %t56, i32 %t57)
  store { i64, ptr } %t61, ptr %l31
  br label %bb12
bb12:
  %t62 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t62, ptr %lp5
  %t63 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t64 = load ptr, ptr %lp5
  store { i64, ptr } %t63, ptr %t64, !tbaa !27
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/emit:Emitter", ptr %t65, i32 0, i32 30
  %t68 = load ptr, ptr %lp5
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  %t72 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v1, ptr %t67, { i64, ptr } %t69)
  store i1 %t72, ptr %l35
  br label %bb13
bb13:
  %t73 = load i1, ptr %l35, !tbaa !21
  %t74 = xor i1 %t73, true
  br i1 %t74, label %bb14, label %bb15
bb14:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/emit:Emitter", ptr %t76, i32 0, i32 30
  store ptr %t78, ptr %l38, !tbaa !29
  %t79 = ptrtoint ptr %v0 to i64
  store i64 %t79, ptr %l39, !tbaa !24
  %t80 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2e0
  br i1 %t80, label %bb16, label %bb17
bb15:
  br label %bb21
bb16:
  %t82 = call ptr @__olang_region_make(ptr %v0)
  %t83 = ptrtoint ptr %t82 to i64
  store i64 %t83, ptr %l39, !tbaa !24
  br label %bb17
bb17:
  %t84 = load ptr, ptr %lp5
  %t85 = load { i64, ptr }, ptr %t84, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t85, 1
  %t88 = extractvalue { i64, ptr } %t85, 0
  %t89 = load i64, ptr %l39
  %t90 = inttoptr i64 %t89 to ptr
  %t91 = call ptr @__olang_scope_alloc(ptr %t90, i64 %t88)
  call void @olang_textcopy(ptr %t91, ptr %t87, i64 %t88)
  %t92 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  %t95 = load i64, ptr %l39
  %t96 = inttoptr i64 %t95 to ptr
  %t97 = extractvalue { i64, ptr } %t93, 0
  %t98 = extractvalue { i64, ptr } %t93, 1
  %t99 = mul i64 %t97, 1
  %t100 = call ptr @__olang_scope_alloc(ptr %t96, i64 %t99)
  call void @llvm.memcpy.p0.p0.i64(ptr %t100, ptr %t98, i64 %t99, i1 false)
  %t101 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t100, 1
  %t103 = load ptr, ptr %l38, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %v0, ptr %v0, ptr %t103, { i64, ptr } %t102, i1 true)
  br label %bb18
bb18:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/emit:Emitter", ptr %t105, i32 0, i32 31
  %t108 = load { i64, [2 x i64] }, ptr %l1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %t107, { i64, [2 x i64] } %t108)
  br label %bb19
bb19:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/emit:Emitter", ptr %t111, i32 0, i32 32
  %t114 = load i32, ptr %l2, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t113, i32 %t114)
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t117 = load ptr, ptr %lp5
  %t118 = load { i64, ptr }, ptr %t117, !tbaa !27
  store { i64, ptr } %t118, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgName(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l20 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l27 = alloca ptr
  %l29 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l73 = alloca i64
  %l74 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load { i64, [2 x i64] }, ptr %l1
  %t8 = extractvalue { i64, [2 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  store i32 %t13, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  br label %bb41
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/emit:Emitter", ptr %t15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/lower:Lowerer", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = load i32, ptr %l3, !tbaa !23
  %t25 = sext i32 %t23 to i64
  %t28 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t21, i64 %t25)
  store ptr %t28, ptr %l20
  br label %bb4
bb4:
  %t29 = load ptr, ptr %l20, !tbaa !29
  %t31 = getelementptr %"compiler/typed:Body", ptr %t29, i32 0, i32 1
  %t32 = load { i64, [2 x i64] }, ptr %t31
  store { i64, [2 x i64] } %t32, ptr %l4
  %t34 = load { i64, [2 x i64] }, ptr %l4
  %t36 = extractvalue { i64, [2 x i64] } %t34, 0
  %t37 = icmp eq i64 %t36, 0
  br i1 %t37, label %bb5, label %bb6
bb5:
  %t39 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t40 = getelementptr { i64 }, ptr %t39, i32 0, i32 0
  %t41 = load i64, ptr %t40
  store i64 %t41, ptr %l5, !tbaa !24
  br label %bb7
bb6:
  br label %bb11
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l27, !tbaa !29
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/emit:Emitter", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  store ptr %t47, ptr %l29, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/emit:Emitter", ptr %t48, i32 0, i32 0
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t52 = load i64, ptr %l5, !tbaa !24
  %t55 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t51, i64 %t52)
  store i64 %t55, ptr %l33
  br label %bb8
bb8:
  %t56 = load ptr, ptr %l29, !tbaa !29
  %t57 = load i64, ptr %l33, !tbaa !24
  %t58 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s2, ptr %t56, i64 %t57)
  store ptr %t58, ptr %l34
  br label %bb9
bb9:
  %t59 = load ptr, ptr %l34, !tbaa !29
  %t61 = getelementptr %"compiler/ast:Func", ptr %t59, i32 0, i32 2
  %t62 = load i32, ptr %t61, !tbaa !23
  %t63 = load ptr, ptr %l27, !tbaa !29
  %t65 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %s2, ptr %t63, i32 %t62)
  store { i64, ptr } %t65, ptr %l37
  br label %bb10
bb10:
  %t66 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 1
  %t68 = extractvalue { i64, ptr } %t66, 0
  %t69 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t68)
  call void @olang_textcopy(ptr %t69, ptr %t67, i64 %t68)
  %t70 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  store { i64, ptr } %t71, ptr %l23, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  br label %bb40
bb11:
  %t73 = load { i64, [2 x i64] }, ptr %l4
  %t75 = extractvalue { i64, [2 x i64] } %t73, 0
  %t76 = icmp eq i64 %t75, 1
  br i1 %t76, label %bb12, label %bb13
bb12:
  %t78 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t79 = getelementptr { i32, i32 }, ptr %t78, i32 0, i32 0
  %t80 = load i32, ptr %t79
  store i32 %t80, ptr %l6, !tbaa !23
  br label %bb14
bb13:
  br label %bb16
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t82 = load ptr, ptr %l2, !tbaa !29
  %t83 = load i32, ptr %l6, !tbaa !23
  %t85 = inttoptr i64 0 to ptr
  %t88 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s4, ptr %t85, ptr %t82, i32 %t83)
  store { i64, ptr } %t88, ptr %l45
  br label %bb15
bb15:
  %t89 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t89, 1
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t92 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t91)
  call void @olang_textcopy(ptr %t92, ptr %t90, i64 %t91)
  %t93 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  store { i64, ptr } %t94, ptr %l23, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  br label %bb40
bb16:
  %t96 = load { i64, [2 x i64] }, ptr %l4
  %t98 = extractvalue { i64, [2 x i64] } %t96, 0
  %t99 = icmp eq i64 %t98, 3
  br i1 %t99, label %bb17, label %bb18
bb17:
  %t101 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t102 = getelementptr { i32 }, ptr %t101, i32 0, i32 0
  %t103 = load i32, ptr %t102
  store i32 %t103, ptr %l7, !tbaa !23
  br label %bb19
bb18:
  br label %bb21
bb19:
  store %olang.scope zeroinitializer, ptr %s6
  %t105 = load ptr, ptr %l2, !tbaa !29
  %t106 = load i32, ptr %l7, !tbaa !23
  %t108 = inttoptr i64 0 to ptr
  %t111 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s6, ptr %t108, ptr %t105, i32 %t106)
  store { i64, ptr } %t111, ptr %l53
  br label %bb20
bb20:
  %t112 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t112, 1
  %t114 = extractvalue { i64, ptr } %t112, 0
  %t115 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t116 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t117 = add i64 %t114, %t116
  %t118 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t117)
  call void @olang_textcopy(ptr %t118, ptr %t113, i64 %t114)
  %t119 = getelementptr i8, ptr %t118, i64 %t114
  call void @olang_textcopy(ptr %t119, ptr %t115, i64 %t116)
  %t120 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t121 = insertvalue { i64, ptr } %t120, ptr %t118, 1
  store { i64, ptr } %t121, ptr %l23, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb40
bb21:
  %t123 = load { i64, [2 x i64] }, ptr %l4
  %t125 = extractvalue { i64, [2 x i64] } %t123, 0
  %t126 = icmp eq i64 %t125, 4
  br i1 %t126, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l57, !tbaa !27
  %t128 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t128, ptr %l23, !tbaa !27
  br label %bb40
bb25:
  %t130 = load { i64, [2 x i64] }, ptr %l4
  %t132 = extractvalue { i64, [2 x i64] } %t130, 0
  %t133 = icmp eq i64 %t132, 5
  br i1 %t133, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %l61, !tbaa !27
  %t135 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t135, ptr %l23, !tbaa !27
  br label %bb40
bb29:
  %t137 = load { i64, [2 x i64] }, ptr %l4
  %t139 = extractvalue { i64, [2 x i64] } %t137, 0
  %t140 = icmp eq i64 %t139, 6
  br i1 %t140, label %bb30, label %bb31
bb30:
  %t142 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t143 = getelementptr { i64, i32 }, ptr %t142, i32 0, i32 1
  %t144 = load i32, ptr %t143
  store i32 %t144, ptr %l8, !tbaa !23
  br label %bb32
bb31:
  br label %bb34
bb32:
  store %olang.scope zeroinitializer, ptr %s10
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load i32, ptr %l8, !tbaa !23
  %t150 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %s10, ptr %t146, i32 %t147)
  store { i64, ptr } %t150, ptr %l68
  br label %bb33
bb33:
  %t151 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t151, 1
  %t153 = extractvalue { i64, ptr } %t151, 0
  %t154 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t155 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t156 = add i64 %t153, %t155
  %t157 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t156)
  call void @olang_textcopy(ptr %t157, ptr %t152, i64 %t153)
  %t158 = getelementptr i8, ptr %t157, i64 %t153
  call void @olang_textcopy(ptr %t158, ptr %t154, i64 %t155)
  %t159 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t157, 1
  store { i64, ptr } %t160, ptr %l23, !tbaa !27
  call void @__olang_scope_close(ptr %s10)
  br label %bb40
bb34:
  br i1 true, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load { i64, [2 x i64] }, ptr %l1
  %t166 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %v1, ptr %t162, { i64, [2 x i64] } %t163)
  store { i64, ptr } %t166, ptr %l72
  br label %bb38
bb38:
  %t167 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t167, ptr %l23, !tbaa !27
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_18f6acb4865fb5f2_de2c0e3f26126f06)
  unreachable
bb40:
  %t168 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t168, 0
  store i64 %t169, ptr %l73, !tbaa !24
  %t170 = load i64, ptr %l73, !tbaa !24
  %t171 = mul i64 %t170, 1
  %t172 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t171)
  %t173 = insertvalue { i64, ptr } undef, i64 %t170, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t172, 1
  store { i64, ptr } %t174, ptr %l74, !tbaa !27
  %t175 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !27
  %t177 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = load i64, ptr %l73, !tbaa !24
  %t180 = mul i64 %t179, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t176, ptr %t178, i64 %t180, i1 false)
  %t181 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t181, ptr %l23, !tbaa !27
  %t182 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t182, ptr %rv
  br label %ret
bb41:
  br i1 true, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load { i64, [2 x i64] }, ptr %l1
  %t187 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %v1, ptr %t183, { i64, [2 x i64] } %t184)
  store { i64, ptr } %t187, ptr %l77
  br label %bb45
bb45:
  %t188 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t188, ptr %rv
  br label %ret
bb46:
  call void @__olang_check_failed(ptr @olang_loc_795f0ceaa031aa73_92815be2925279e7)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgTypeName(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l15 = alloca i1
  %l17 = alloca i1
  %l19 = alloca { i64, ptr }
  %l21 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t7 = inttoptr i64 0 to ptr
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s0, ptr %t7, ptr %t4, i32 %a1)
  store { i64, ptr } %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t11, ptr %l2, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t14 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s0, ptr %s0, { i64, ptr } %t12, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) })
  %t15 = extractvalue { i32, i64 } %t14, 1
  %t16 = extractvalue { i32, i64 } %t14, 0
  store i32 %t16, ptr %l12
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb3, label %ok.18, !prof !99
ok.18:
  store i64 %t15, ptr %l11
  br label %bb2
bb2:
  %t19 = load i64, ptr %l11, !tbaa !24
  store i64 %t19, ptr %l9, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  store i64 -1, ptr %l9, !tbaa !24
  br label %bb5
bb5:
  %t20 = load i64, ptr %l9, !tbaa !24
  store i64 %t20, ptr %l3, !tbaa !24
  %t21 = load i64, ptr %l3, !tbaa !24
  %t23 = icmp sge i64 %t21, 0
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t25 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s0, { i64, ptr } %t25, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d27, i32 0, i32 1) })
  store i1 %t27, ptr %l17
  br label %bb8
bb7:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb9
bb8:
  %t28 = load i1, ptr %l17, !tbaa !21
  %t29 = xor i1 %t28, true
  store i1 %t29, ptr %l15, !tbaa !21
  br label %bb9
bb9:
  %t31 = load i1, ptr %l15, !tbaa !21
  br i1 %t31, label %bb10, label %bb11
bb10:
  %t32 = load i64, ptr %l3, !tbaa !24
  %t34 = add i64 %t32, 1
  store i64 %t34, ptr %l21, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  store i64 %t37, ptr %l23, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  store i64 %t39, ptr %l24, !tbaa !24
  %t40 = load i64, ptr %l21, !tbaa !24
  %t41 = icmp sge i64 %t40, 0
  br i1 %t41, label %bb12, label %bb13
bb11:
  %t43 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 1
  %t46 = extractvalue { i64, ptr } %t43, 0
  %t47 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t46)
  call void @olang_textcopy(ptr %t47, ptr %t45, i64 %t46)
  %t48 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  store { i64, ptr } %t49, ptr %l19, !tbaa !27
  br label %bb18
bb12:
  %t51 = load i64, ptr %l21, !tbaa !24
  %t52 = load i64, ptr %l23, !tbaa !24
  %t53 = icmp sle i64 %t51, %t52
  br i1 %t53, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_aa85ef0c362238c9_b248055339837d6d)
  unreachable
bb14:
  %t55 = load i64, ptr %l23, !tbaa !24
  %t56 = load i64, ptr %l24, !tbaa !24
  %t57 = icmp sle i64 %t55, %t56
  br i1 %t57, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_aa85ef0c362238c9_b248055339837d6d)
  unreachable
bb16:
  %t59 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = load i64, ptr %l21, !tbaa !24
  %t62 = load i64, ptr %l23, !tbaa !24
  %t63 = getelementptr i8, ptr %t60, i64 %t61
  %t64 = sub i64 %t62, %t61
  %t65 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t63, 1
  %t68 = extractvalue { i64, ptr } %t66, 1
  %t69 = extractvalue { i64, ptr } %t66, 0
  %t70 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t69)
  call void @olang_textcopy(ptr %t70, ptr %t68, i64 %t69)
  %t71 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  store { i64, ptr } %t72, ptr %l19, !tbaa !27
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_aa85ef0c362238c9_b248055339837d6d)
  unreachable
bb18:
  call void @__olang_scope_close(ptr %s0)
  %t74 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t74, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = load i64, ptr @G_2ecompiler_2femit_2eHomeShared, !tbaa !24
  %t6 = extractvalue { i64, ptr } %a2, 1
  %t7 = extractvalue { i64, ptr } %a2, 0
  %t8 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t6, i64 %t7)
  %t12 = getelementptr i8, ptr %t11, i64 %t7
  call void @olang_textcopy(ptr %t12, ptr %t8, i64 %t9)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t11, 1
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t17 = extractvalue { i64, ptr } %t14, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %v1, ptr %s0, ptr %s0, ptr %a0, { i64, ptr } %a1, i64 %t3, { i64, ptr } %t21, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) })
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edrain(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l9 = alloca ptr
  %l12 = alloca ptr
  %l17 = alloca { i64, [2 x i64] }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  br label %bb1
bb1:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 15
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = add i64 %t4, 1
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/emit:Emitter", ptr %t7, i32 0, i32 13
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2eLen_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l6
  br label %bb2
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = icmp slt i64 %t12, %t13
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l9, !tbaa !29
  %t19 = load ptr, ptr %l9, !tbaa !29
  %t20 = getelementptr %"compiler/emit:Emitter", ptr %t19, i32 0, i32 15
  %t21 = load i64, ptr %t20, !tbaa !24
  %t23 = add i64 %t21, 1
  %t25 = load ptr, ptr %l9, !tbaa !29
  %t26 = getelementptr %"compiler/emit:Emitter", ptr %t25, i32 0, i32 15
  store i64 %t23, ptr %t26, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l12, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/emit:Emitter", ptr %t28, i32 0, i32 13
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/emit:Emitter", ptr %t31, i32 0, i32 15
  %t34 = load i64, ptr %t33, !tbaa !24
  %t37 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2eAt_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %t30, i64 %t34)
  store { i64, [2 x i64] } %t37, ptr %l17
  br label %bb6
bb6:
  %t38 = load ptr, ptr %l12, !tbaa !29
  %t39 = load { i64, [2 x i64] }, ptr %l17
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efunction(ptr %v0, ptr %t38, { i64, [2 x i64] } %t39)
  br label %bb7
bb7:
  br label %bb8
bb8:
  br label %bb1
bb9:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenDropFn(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %lp3 = alloca ptr
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l21 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l28 = alloca i1
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %l36 = alloca ptr
  %l37 = alloca { i64, [2 x i64] }
  %l38 = alloca i32
  %l39 = alloca %"compiler/source:Span"
  %l40 = alloca %"compiler/mir:Fn"
  %l43 = alloca %"compiler/emit:fnEm"
  %l50 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l52 = alloca i64
  %l56 = alloca i64
  %l60 = alloca i64
  %l63 = alloca i64
  %l81 = alloca ptr
  %l82 = alloca ptr
  %l83 = alloca ptr
  %l84 = alloca i32
  %l87 = alloca { i64, ptr }
  %l88 = alloca i64
  %l89 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l97 = alloca ptr
  %l98 = alloca { i64, ptr }
  %l99 = alloca ptr
  %l103 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l112 = alloca i64
  %l115 = alloca i64
  %l118 = alloca i64
  %l120 = alloca i64
  %l126 = alloca ptr
  %l127 = alloca { i64, ptr }
  %l128 = alloca i64
  %l129 = alloca { i64, ptr }
  %l132 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l142 = alloca i64
  %l143 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t68 = alloca { i64, [2 x i64] }, align 8
  %t78 = alloca %"compiler/mir:Fn", align 8
  %t84 = alloca %"compiler/emit:fnEm", align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t9 = inttoptr i64 0 to ptr
  %t12 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s0, ptr %t9, ptr %t4, i32 %t7)
  store { i64, ptr } %t12, ptr %l21
  br label %bb1
bb1:
  %t13 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t15 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = add i64 %t14, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t13, i64 %t14)
  %t20 = getelementptr i8, ptr %t19, i64 %t14
  call void @olang_textcopy(ptr %t20, ptr %t16, i64 %t17)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t19, 1
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t25 = extractvalue { i64, ptr } %t22, 1
  %t26 = mul i64 %t24, 1
  %t27 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t26)
  call void @llvm.memcpy.p0.p0.i64(ptr %t27, ptr %t25, i64 %t26, i1 false)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  %t31 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t29)
  store { i64, ptr } %t31, ptr %l24
  br label %bb2
bb2:
  %t32 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t32, ptr %lp3
  %t33 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t34 = load ptr, ptr %lp3
  store { i64, ptr } %t33, ptr %t34, !tbaa !27
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/emit:Emitter", ptr %t35, i32 0, i32 66
  %t38 = load ptr, ptr %lp3
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  %t42 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v1, ptr %t37, { i64, ptr } %t39)
  store i1 %t42, ptr %l28
  br label %bb3
bb3:
  %t43 = load i1, ptr %l28, !tbaa !21
  br i1 %t43, label %bb4, label %bb5
bb4:
  %t44 = load ptr, ptr %lp3
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  store { i64, ptr } %t45, ptr %l29, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 0
  store i64 %t47, ptr %l30, !tbaa !24
  %t48 = load i64, ptr %l30, !tbaa !24
  %t49 = mul i64 %t48, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t49)
  %t51 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  store { i64, ptr } %t52, ptr %l31, !tbaa !27
  %t53 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = load i64, ptr %l30, !tbaa !24
  %t58 = mul i64 %t57, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t54, ptr %t56, i64 %t58, i1 false)
  %t59 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t59, ptr %l29, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t60 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t60, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/emit:Emitter", ptr %t61, i32 0, i32 66
  %t64 = load ptr, ptr %lp3
  %t65 = load { i64, ptr }, ptr %t64, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %v0, ptr %v1, ptr %t63, { i64, ptr } %t65, i1 true)
  br label %bb7
bb7:
  store { i64, [2 x i64] } zeroinitializer, ptr %t68
  %t69 = getelementptr { i64, [2 x i64] }, ptr %t68, i32 0, i32 0
  store i64 4, ptr %t69
  %t70 = insertvalue { i64 } undef, i64 0, 0
  %t71 = getelementptr { i64, [2 x i64] }, ptr %t68, i32 0, i32 1
  store { i64 } %t70, ptr %t71
  %t72 = load { i64, [2 x i64] }, ptr %t68
  store { i64, [2 x i64] } %t72, ptr %l4
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l36, !tbaa !29
  %t75 = load { i64, [2 x i64] }, ptr %l4
  store { i64, [2 x i64] } %t75, ptr %l37
  %t76 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t76, ptr %l38, !tbaa !23
  %t77 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t77, ptr %l39
  br label %bb8
bb8:
  %t79 = load { i64, [2 x i64] }, ptr %l37
  %t80 = load i32, ptr %l38, !tbaa !23
  %t81 = load %"compiler/source:Span", ptr %l39
  call void @compiler_2fmir_3aFn_2ector(ptr %t78, ptr %v0, { i64, [2 x i64] } %t79, i32 %t80, i64 0, %"compiler/source:Span" %t81)
  call void @llvm.memmove.p0.p0.i64(ptr %l40, ptr %t78, i64 800, i1 false)
  br label %bb9
bb9:
  %t82 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 800, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t82, ptr %l40, i64 800, i1 false)
  %t83 = load { i64, [2 x i64] }, ptr %l4
  %t85 = load ptr, ptr %l36, !tbaa !29
  call void @compiler_2femit_3afnEm_2ector(ptr %t84, ptr %v0, ptr %v0, ptr %v0, ptr %t85, ptr %t82, { i64, [2 x i64] } %t83)
  call void @llvm.memmove.p0.p0.i64(ptr %l43, ptr %t84, i64 1072, i1 false)
  br label %bb10
bb10:
  %t88 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 1072, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t88, ptr %l43, i64 1072, i1 false)
  store ptr %t88, ptr %l5, !tbaa !29
  %t90 = load ptr, ptr %l5, !tbaa !29
  %t92 = getelementptr %"compiler/emit:fnEm", ptr %t90, i32 0, i32 30
  store i1 true, ptr %t92, !tbaa !21
  %t93 = load ptr, ptr %l5, !tbaa !29
  %t94 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eholdersAt(ptr %v0, ptr %s0, ptr %s0, ptr %t93, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d31, i32 0, i32 1) }, i32 %t94, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d32, i32 0, i32 1) }, i1 false)
  br label %bb11
bb11:
  %t97 = load ptr, ptr %l5, !tbaa !29
  %t98 = load i32, ptr %l1, !tbaa !23
  %t101 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2femit_2ecompiler_2femit_3afnEm_2egenLeaves(ptr %v0, ptr %s0, ptr %t97, i32 %t98)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t101, ptr %l50
  br label %bb12
bb12:
  %t102 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l50
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t102, ptr %l6
  %t104 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eLen_3cArray_3cI64_3e_3e(ptr %s0, ptr %l6)
  store i64 %t104, ptr %l52
  br label %bb13
bb13:
  %t105 = load i64, ptr %l52, !tbaa !24
  %t106 = icmp sgt i64 %t105, 0
  br i1 %t106, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t108 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s3, ptr %t108, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d33, i32 0, i32 1) })
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb17:
  store i64 0, ptr %l7, !tbaa !24
  %t111 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eLen_3cArray_3cI64_3e_3e(ptr %s0, ptr %l6)
  store i64 %t111, ptr %l56
  br label %bb18
bb18:
  %t112 = load i64, ptr %l56, !tbaa !24
  store i64 %t112, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t113 = load i64, ptr %l8, !tbaa !24
  %t114 = load i64, ptr %l7, !tbaa !24
  %t117 = icmp sgt i64 %t113, %t114
  br i1 %t117, label %bb19, label %bb20
bb19:
  %t119 = load i64, ptr %l9, !tbaa !24
  %t121 = icmp sgt i64 %t119, 0
  br i1 %t121, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l60, !tbaa !24
  br label %bb24
bb21:
  %t123 = load i64, ptr %l8, !tbaa !24
  %t124 = load i64, ptr %l7, !tbaa !24
  %t127 = sub i64 %t123, %t124
  %t128 = load i64, ptr %l9, !tbaa !24
  %t131 = add i64 %t127, %t128
  %t133 = sub i64 %t131, 1
  %t134 = load i64, ptr %l9, !tbaa !24
  %t137 = sdiv i64 %t133, %t134
  store i64 %t137, ptr %l63, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb23
bb23:
  %t139 = load i64, ptr %l63, !tbaa !24
  store i64 %t139, ptr %l60, !tbaa !24
  br label %bb24
bb24:
  %t140 = load i64, ptr %l60, !tbaa !24
  store i64 %t140, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s5
  %t141 = load i64, ptr %l11, !tbaa !24
  %t142 = load i64, ptr %l10, !tbaa !24
  %t145 = icmp slt i64 %t141, %t142
  %t147 = xor i1 %t145, true
  br i1 %t147, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s5)
  br label %bb37
bb27:
  br label %bb28
bb28:
  %t149 = load i64, ptr %l7, !tbaa !24
  %t150 = load i64, ptr %l11, !tbaa !24
  %t151 = load i64, ptr %l9, !tbaa !24
  %t154 = mul i64 %t150, %t151
  %t157 = add i64 %t149, %t154
  store i64 %t157, ptr %l12, !tbaa !24
  %t159 = load ptr, ptr %l5, !tbaa !29
  store ptr %t159, ptr %l81, !tbaa !29
  %t160 = load ptr, ptr %l5, !tbaa !29
  store ptr %t160, ptr %l82, !tbaa !29
  %t161 = load ptr, ptr %l5, !tbaa !29
  store ptr %t161, ptr %l83, !tbaa !29
  %t162 = load i32, ptr %l1, !tbaa !23
  store i32 %t162, ptr %l84, !tbaa !23
  %t163 = load i64, ptr %l12, !tbaa !24
  %t166 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eAt_3cArray_3cI64_3e_3e(ptr %s0, ptr %s5, ptr %l6, i64 %t163)
  store { i64, ptr } %t166, ptr %l87
  br label %bb29
bb29:
  %t167 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t167, 0
  store i64 %t168, ptr %l88, !tbaa !24
  %t169 = load i64, ptr %l88, !tbaa !24
  %t170 = mul i64 %t169, 8
  %t171 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t170)
  %t172 = insertvalue { i64, ptr } undef, i64 %t169, 0
  %t173 = insertvalue { i64, ptr } %t172, ptr %t171, 1
  store { i64, ptr } %t173, ptr %l89, !tbaa !27
  %t174 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !27
  %t176 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = load i64, ptr %l88, !tbaa !24
  %t179 = mul i64 %t178, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t175, ptr %t177, i64 %t179, i1 false)
  %t180 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t180, 0
  %t182 = extractvalue { i64, ptr } %t180, 1
  %t183 = mul i64 %t181, 8
  %t184 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t183)
  call void @llvm.memcpy.p0.p0.i64(ptr %t184, ptr %t182, i64 %t183, i1 false)
  %t185 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t186 = insertvalue { i64, ptr } %t185, ptr %t184, 1
  %t187 = load ptr, ptr %l83, !tbaa !29
  %t188 = load i32, ptr %l84, !tbaa !23
  %t190 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eleafAt(ptr %v0, ptr %s5, ptr %s5, ptr %s5, ptr %t187, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d34, i32 0, i32 1) }, i32 %t188, { i64, ptr } %t186)
  store { i64, ptr } %t190, ptr %l91
  br label %bb30
bb30:
  %t191 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t192 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t193 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t194 = extractvalue { i64, ptr } %t193, 1
  %t195 = extractvalue { i64, ptr } %t193, 0
  %t196 = add i64 %t192, %t195
  %t197 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t198 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t199 = add i64 %t196, %t198
  %t200 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t199)
  call void @olang_textcopy(ptr %t200, ptr %t191, i64 %t192)
  %t201 = getelementptr i8, ptr %t200, i64 %t192
  call void @olang_textcopy(ptr %t201, ptr %t194, i64 %t195)
  %t202 = getelementptr i8, ptr %t201, i64 %t195
  call void @olang_textcopy(ptr %t202, ptr %t197, i64 %t198)
  %t203 = insertvalue { i64, ptr } undef, i64 %t199, 0
  %t204 = insertvalue { i64, ptr } %t203, ptr %t200, 1
  %t206 = extractvalue { i64, ptr } %t204, 0
  %t207 = extractvalue { i64, ptr } %t204, 1
  %t208 = mul i64 %t206, 1
  %t209 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t208)
  call void @llvm.memcpy.p0.p0.i64(ptr %t209, ptr %t207, i64 %t208, i1 false)
  %t210 = insertvalue { i64, ptr } undef, i64 %t206, 0
  %t211 = insertvalue { i64, ptr } %t210, ptr %t209, 1
  %t212 = load ptr, ptr %l82, !tbaa !29
  %t214 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s5, ptr %s5, ptr %t212, { i64, ptr } %t211)
  store { i64, ptr } %t214, ptr %l94
  br label %bb31
bb31:
  %t215 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t215, 0
  %t217 = extractvalue { i64, ptr } %t215, 1
  %t218 = mul i64 %t216, 1
  %t219 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t218)
  call void @llvm.memcpy.p0.p0.i64(ptr %t219, ptr %t217, i64 %t218, i1 false)
  %t220 = insertvalue { i64, ptr } undef, i64 %t216, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr %t219, 1
  %t222 = load ptr, ptr %l81, !tbaa !29
  %t224 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s5, ptr %s5, ptr %s5, ptr %s5, ptr %t222, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d37, i32 0, i32 1) }, { i64, ptr } %t221, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) })
  store { i64, ptr } %t224, ptr %l96
  br label %bb32
bb32:
  %t225 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t226 = load ptr, ptr %l5, !tbaa !29
  store ptr %t226, ptr %l97, !tbaa !29
  store { i64, ptr } %t225, ptr %l98, !tbaa !27
  %t228 = load ptr, ptr %l5, !tbaa !29
  store ptr %t228, ptr %l99, !tbaa !29
  %t229 = load ptr, ptr %l5, !tbaa !29
  %t230 = load i32, ptr %l1, !tbaa !23
  %t231 = load i64, ptr %l12, !tbaa !24
  %t235 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eownWord(ptr %v0, ptr %s5, ptr %s5, ptr %t229, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d39, i32 0, i32 1) }, i32 %t230, i64 %t231)
  store { i64, ptr } %t235, ptr %l103
  br label %bb33
bb33:
  %t236 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t237 = extractvalue { i64, ptr } %t236, 0
  %t238 = extractvalue { i64, ptr } %t236, 1
  %t239 = mul i64 %t237, 1
  %t240 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t239)
  call void @llvm.memcpy.p0.p0.i64(ptr %t240, ptr %t238, i64 %t239, i1 false)
  %t241 = insertvalue { i64, ptr } undef, i64 %t237, 0
  %t242 = insertvalue { i64, ptr } %t241, ptr %t240, 1
  %t243 = load ptr, ptr %l99, !tbaa !29
  %t245 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s5, ptr %s5, ptr %s5, ptr %s5, ptr %t243, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d40, i32 0, i32 1) }, { i64, ptr } %t242, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) })
  store { i64, ptr } %t245, ptr %l105
  br label %bb34
bb34:
  %t246 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t247 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t248 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t249 = extractvalue { i64, ptr } %t248, 1
  %t250 = extractvalue { i64, ptr } %t248, 0
  %t251 = add i64 %t247, %t250
  %t252 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t253 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t254 = add i64 %t251, %t253
  %t255 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t256 = extractvalue { i64, ptr } %t255, 1
  %t257 = extractvalue { i64, ptr } %t255, 0
  %t258 = add i64 %t254, %t257
  %t259 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t260 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t261 = add i64 %t258, %t260
  %t262 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t261)
  call void @olang_textcopy(ptr %t262, ptr %t246, i64 %t247)
  %t263 = getelementptr i8, ptr %t262, i64 %t247
  call void @olang_textcopy(ptr %t263, ptr %t249, i64 %t250)
  %t264 = getelementptr i8, ptr %t263, i64 %t250
  call void @olang_textcopy(ptr %t264, ptr %t252, i64 %t253)
  %t265 = getelementptr i8, ptr %t264, i64 %t253
  call void @olang_textcopy(ptr %t265, ptr %t256, i64 %t257)
  %t266 = getelementptr i8, ptr %t265, i64 %t257
  call void @olang_textcopy(ptr %t266, ptr %t259, i64 %t260)
  %t267 = insertvalue { i64, ptr } undef, i64 %t261, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t262, 1
  %t270 = extractvalue { i64, ptr } %t268, 0
  %t271 = extractvalue { i64, ptr } %t268, 1
  %t272 = mul i64 %t270, 1
  %t273 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t272)
  call void @llvm.memcpy.p0.p0.i64(ptr %t273, ptr %t271, i64 %t272, i1 false)
  %t274 = insertvalue { i64, ptr } undef, i64 %t270, 0
  %t275 = insertvalue { i64, ptr } %t274, ptr %t273, 1
  %t276 = load ptr, ptr %l97, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s5, ptr %t276, { i64, ptr } %t275)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s5)
  br label %bb36
bb36:
  %t278 = load i64, ptr %l11, !tbaa !24
  %t280 = add i64 %t278, 1
  store i64 %t280, ptr %l11, !tbaa !24
  br label %bb25
bb37:
  %t282 = load ptr, ptr %l5, !tbaa !29
  %t283 = load i32, ptr %l1, !tbaa !23
  %t286 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ealign(ptr %v0, ptr %t282, i32 %t283)
  store i64 %t286, ptr %l112
  br label %bb38
bb38:
  %t287 = load i64, ptr %l112, !tbaa !24
  %t290 = icmp sle i64 %t287, 8
  br i1 %t290, label %bb39, label %bb40
bb39:
  %t292 = load ptr, ptr %l5, !tbaa !29
  %t293 = load i32, ptr %l1, !tbaa !23
  %t296 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2egenBytes(ptr %v0, ptr %t292, i32 %t293)
  store i64 %t296, ptr %l118
  br label %bb41
bb40:
  store i64 -1, ptr %l115, !tbaa !24
  br label %bb43
bb41:
  %t297 = load i64, ptr %l118, !tbaa !24
  %t298 = add i64 %t297, 8
  %t300 = call i64 @compiler_2femit_2egenClass(i64 %t298)
  store i64 %t300, ptr %l120
  br label %bb42
bb42:
  %t301 = load i64, ptr %l120, !tbaa !24
  store i64 %t301, ptr %l115, !tbaa !24
  br label %bb43
bb43:
  %t302 = load i64, ptr %l115, !tbaa !24
  %t303 = load ptr, ptr %l5, !tbaa !29
  %t306 = add i64 %t302, 1
  %t307 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t308 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t310 = call i64 @__olang_fmt_i64(ptr null, i64 %t306)
  %t311 = add i64 %t308, %t310
  %t312 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t311)
  call void @olang_textcopy(ptr %t312, ptr %t307, i64 %t308)
  %t313 = getelementptr i8, ptr %t312, i64 %t308
  %t314 = call i64 @__olang_fmt_i64(ptr %t313, i64 %t306)
  %t315 = insertvalue { i64, ptr } undef, i64 %t311, 0
  %t316 = insertvalue { i64, ptr } %t315, ptr %t312, 1
  %t318 = extractvalue { i64, ptr } %t316, 0
  %t319 = extractvalue { i64, ptr } %t316, 1
  %t320 = mul i64 %t318, 1
  %t321 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t320)
  call void @llvm.memcpy.p0.p0.i64(ptr %t321, ptr %t319, i64 %t320, i1 false)
  %t322 = insertvalue { i64, ptr } undef, i64 %t318, 0
  %t323 = insertvalue { i64, ptr } %t322, ptr %t321, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t303, { i64, ptr } %t323)
  br label %bb44
bb44:
  %t326 = load ptr, ptr %l0, !tbaa !29
  store ptr %t326, ptr %l126, !tbaa !29
  %t327 = load ptr, ptr %lp3
  %t328 = load { i64, ptr }, ptr %t327, !tbaa !27
  store { i64, ptr } %t328, ptr %l127, !tbaa !27
  %t329 = load i64, ptr @G_2ecompiler_2femit_2eHomeShared, !tbaa !24
  store i64 %t329, ptr %l128, !tbaa !24
  %t330 = load ptr, ptr %lp3
  %t331 = load { i64, ptr }, ptr %t330, !tbaa !27
  store { i64, ptr } %t331, ptr %l129, !tbaa !27
  %t332 = load ptr, ptr %l5, !tbaa !29
  %t334 = getelementptr %"compiler/emit:fnEm", ptr %t332, i32 0, i32 3
  %t336 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %s0, ptr %t334)
  store { i64, ptr } %t336, ptr %l132
  br label %bb45
bb45:
  %t337 = load ptr, ptr %l5, !tbaa !29
  %t339 = getelementptr %"compiler/emit:fnEm", ptr %t337, i32 0, i32 4
  %t341 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %s0, ptr %t339)
  store { i64, ptr } %t341, ptr %l135
  br label %bb46
bb46:
  %t342 = load ptr, ptr %l5, !tbaa !29
  %t344 = getelementptr %"compiler/emit:fnEm", ptr %t342, i32 0, i32 5
  %t346 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %s0, ptr %t344)
  store { i64, ptr } %t346, ptr %l138
  br label %bb47
bb47:
  %t347 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t348 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t349 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t350 = extractvalue { i64, ptr } %t349, 1
  %t351 = extractvalue { i64, ptr } %t349, 0
  %t352 = add i64 %t348, %t351
  %t353 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t354 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t355 = add i64 %t352, %t354
  %t356 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t357 = extractvalue { i64, ptr } %t356, 1
  %t358 = extractvalue { i64, ptr } %t356, 0
  %t359 = add i64 %t355, %t358
  %t360 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t361 = extractvalue { i64, ptr } %t360, 1
  %t362 = extractvalue { i64, ptr } %t360, 0
  %t363 = add i64 %t359, %t362
  %t364 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t365 = extractvalue { i64, ptr } %t364, 1
  %t366 = extractvalue { i64, ptr } %t364, 0
  %t367 = add i64 %t363, %t366
  %t368 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t369 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  %t370 = add i64 %t367, %t369
  %t371 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t370)
  call void @olang_textcopy(ptr %t371, ptr %t347, i64 %t348)
  %t372 = getelementptr i8, ptr %t371, i64 %t348
  call void @olang_textcopy(ptr %t372, ptr %t350, i64 %t351)
  %t373 = getelementptr i8, ptr %t372, i64 %t351
  call void @olang_textcopy(ptr %t373, ptr %t353, i64 %t354)
  %t374 = getelementptr i8, ptr %t373, i64 %t354
  call void @olang_textcopy(ptr %t374, ptr %t357, i64 %t358)
  %t375 = getelementptr i8, ptr %t374, i64 %t358
  call void @olang_textcopy(ptr %t375, ptr %t361, i64 %t362)
  %t376 = getelementptr i8, ptr %t375, i64 %t362
  call void @olang_textcopy(ptr %t376, ptr %t365, i64 %t366)
  %t377 = getelementptr i8, ptr %t376, i64 %t366
  call void @olang_textcopy(ptr %t377, ptr %t368, i64 %t369)
  %t378 = insertvalue { i64, ptr } undef, i64 %t370, 0
  %t379 = insertvalue { i64, ptr } %t378, ptr %t371, 1
  %t381 = extractvalue { i64, ptr } %t379, 0
  %t382 = extractvalue { i64, ptr } %t379, 1
  %t383 = mul i64 %t381, 1
  %t384 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t383)
  call void @llvm.memcpy.p0.p0.i64(ptr %t384, ptr %t382, i64 %t383, i1 false)
  %t385 = insertvalue { i64, ptr } undef, i64 %t381, 0
  %t386 = insertvalue { i64, ptr } %t385, ptr %t384, 1
  %t387 = load ptr, ptr %l126, !tbaa !29
  %t388 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t389 = load i64, ptr %l128, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %v1, ptr %s0, ptr %s0, ptr %t387, { i64, ptr } %t388, i64 %t389, { i64, ptr } %t386, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) })
  br label %bb48
bb48:
  %t391 = load ptr, ptr %lp3
  %t392 = load { i64, ptr }, ptr %t391, !tbaa !27
  store { i64, ptr } %t392, ptr %l141, !tbaa !27
  %t393 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t394 = extractvalue { i64, ptr } %t393, 0
  store i64 %t394, ptr %l142, !tbaa !24
  %t395 = load i64, ptr %l142, !tbaa !24
  %t396 = mul i64 %t395, 1
  %t397 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t396)
  %t398 = insertvalue { i64, ptr } undef, i64 %t395, 0
  %t399 = insertvalue { i64, ptr } %t398, ptr %t397, 1
  store { i64, ptr } %t399, ptr %l143, !tbaa !27
  %t400 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t401 = load ptr, ptr %t400, !tbaa !27
  %t402 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t403 = load ptr, ptr %t402, !tbaa !27
  %t404 = load i64, ptr %l142, !tbaa !24
  %t405 = mul i64 %t404, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t401, ptr %t403, i64 %t405, i1 false)
  %t406 = load { i64, ptr }, ptr %l143, !tbaa !27
  store { i64, ptr } %t406, ptr %l141, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t407 = load { i64, ptr }, ptr %l141, !tbaa !27
  store { i64, ptr } %t407, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenOk(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %lp3 = alloca ptr
  %l7 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t7 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenOkName(ptr %v0, ptr %v1, ptr %t1, i64 %a1, i32 %a2)
  store { i64, ptr } %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t8, ptr %lp3
  %t9 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t10 = load ptr, ptr %lp3
  store { i64, ptr } %t9, ptr %t10, !tbaa !27
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load ptr, ptr %lp3
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t14 = load i64, ptr @G_2ecompiler_2femit_2eHomeShared, !tbaa !24
  %t15 = load ptr, ptr %lp3
  %t16 = load { i64, ptr }, ptr %t15, !tbaa !27
  %t17 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  %t20 = extractvalue { i64, ptr } %t16, 1
  %t21 = extractvalue { i64, ptr } %t16, 0
  %t22 = add i64 %t18, %t21
  %t23 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t25 = add i64 %t22, %t24
  %t26 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t25)
  call void @olang_textcopy(ptr %t26, ptr %t17, i64 %t18)
  %t27 = getelementptr i8, ptr %t26, i64 %t18
  call void @olang_textcopy(ptr %t27, ptr %t20, i64 %t21)
  %t28 = getelementptr i8, ptr %t27, i64 %t21
  call void @olang_textcopy(ptr %t28, ptr %t23, i64 %t24)
  %t29 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t26, 1
  %t32 = extractvalue { i64, ptr } %t30, 0
  %t33 = extractvalue { i64, ptr } %t30, 1
  %t34 = mul i64 %t32, 1
  %t35 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t34)
  call void @llvm.memcpy.p0.p0.i64(ptr %t35, ptr %t33, i64 %t34, i1 false)
  %t36 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %v1, ptr %s0, ptr %s0, ptr %t11, { i64, ptr } %t13, i64 %t14, { i64, ptr } %t37, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) })
  br label %bb2
bb2:
  %t42 = load ptr, ptr %lp3
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t43, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobalBody(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca i64
  %l11 = alloca i32
  %l15 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l45 = alloca ptr
  %l55 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/lower:Lowerer", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l15
  br label %bb1
bb1:
  %t10 = load i64, ptr %l15, !tbaa !24
  store i64 %t10, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp sgt i64 %t11, %t12
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t17 = load i64, ptr %l5, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb7
bb4:
  %t21 = load i64, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = sub i64 %t21, %t22
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = add i64 %t25, %t26
  %t31 = sub i64 %t29, 1
  %t32 = load i64, ptr %l5, !tbaa !24
  %t35 = sdiv i64 %t31, %t32
  store i64 %t35, ptr %l22, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb6
bb6:
  %t37 = load i64, ptr %l22, !tbaa !24
  store i64 %t37, ptr %l19, !tbaa !24
  br label %bb7
bb7:
  %t38 = load i64, ptr %l19, !tbaa !24
  store i64 %t38, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  %t39 = load i64, ptr %l7, !tbaa !24
  %t40 = load i64, ptr %l6, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb9, label %bb10
bb9:
  br label %bb29
bb10:
  br label %bb11
bb11:
  %t47 = load i64, ptr %l3, !tbaa !24
  %t48 = load i64, ptr %l7, !tbaa !24
  %t49 = load i64, ptr %l5, !tbaa !24
  %t52 = mul i64 %t48, %t49
  %t55 = add i64 %t47, %t52
  store i64 %t55, ptr %l8, !tbaa !24
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/emit:Emitter", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/lower:Lowerer", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = load i64, ptr %l8, !tbaa !24
  %t68 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t63, i64 %t65)
  store ptr %t68, ptr %l45
  br label %bb12
bb12:
  %t69 = load ptr, ptr %l45, !tbaa !29
  %t71 = getelementptr %"compiler/typed:Body", ptr %t69, i32 0, i32 1
  %t72 = load { i64, [2 x i64] }, ptr %t71
  store { i64, [2 x i64] } %t72, ptr %l9
  %t74 = load { i64, [2 x i64] }, ptr %l9
  %t76 = extractvalue { i64, [2 x i64] } %t74, 0
  %t77 = icmp eq i64 %t76, 6
  br i1 %t77, label %bb13, label %bb14
bb13:
  %t79 = getelementptr { i64, [2 x i64] }, ptr %l9, i32 0, i32 1
  %t80 = getelementptr { i64, i32 }, ptr %t79, i32 0, i32 0
  %t81 = load i64, ptr %t80
  store i64 %t81, ptr %l10, !tbaa !24
  %t83 = getelementptr { i64, [2 x i64] }, ptr %l9, i32 0, i32 1
  %t84 = getelementptr { i64, i32 }, ptr %t83, i32 0, i32 1
  %t85 = load i32, ptr %t84
  store i32 %t85, ptr %l11, !tbaa !23
  br label %bb15
bb14:
  br label %bb22
bb15:
  %t87 = load i64, ptr %l10, !tbaa !24
  %t91 = icmp eq i64 %t87, %a1
  br i1 %t91, label %bb16, label %bb17
bb16:
  %t93 = load i32, ptr %l11, !tbaa !23
  %t97 = icmp eq i32 %t93, %a2
  store i1 %t97, ptr %l55, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb18
bb18:
  %t99 = load i1, ptr %l55, !tbaa !21
  br i1 %t99, label %bb19, label %bb20
bb19:
  %t100 = load i64, ptr %l8, !tbaa !24
  store i64 %t100, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  br label %bb27
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_2aa1b6f8675f9eff_587e0f89839d7783)
  unreachable
bb27:
  br label %bb28
bb28:
  %t102 = load i64, ptr %l7, !tbaa !24
  %t104 = add i64 %t102, 1
  store i64 %t104, ptr %l7, !tbaa !24
  br label %bb8
bb29:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobalIn(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i64
  %l10 = alloca ptr
  %l13 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/lower:Lowerer", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t12 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t7, i64 %a1)
  store ptr %t12, ptr %l10
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l10, !tbaa !29
  %t15 = getelementptr %"compiler/typed:Body", ptr %t13, i32 0, i32 1
  %t16 = load { i64, [2 x i64] }, ptr %t15
  store { i64, [2 x i64] } %t16, ptr %l3
  %t18 = load { i64, [2 x i64] }, ptr %l3
  %t20 = extractvalue { i64, [2 x i64] } %t18, 0
  %t21 = icmp eq i64 %t20, 6
  br i1 %t21, label %bb2, label %bb3
bb2:
  %t23 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t24 = getelementptr { i64, i32 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  store i64 %t25, ptr %l4, !tbaa !24
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t27 = load i64, ptr %l4, !tbaa !24
  %t31 = icmp eq i64 %t27, %a2
  store i1 %t31, ptr %l13, !tbaa !21
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_d066018c79b1953a_bec35d4ece20e406)
  unreachable
bb10:
  %t33 = load i1, ptr %l13, !tbaa !21
  store i1 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobalOrder(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca i64
  %l13 = alloca i64
  %l18 = alloca i64
  %l22 = alloca i64
  %l24 = alloca i64
  %l29 = alloca i64
  %l33 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  store ptr %l1, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t6 = load i64, ptr %l4, !tbaa !24
  store i64 %t6, ptr %l11, !tbaa !24
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t7)
  store i64 %t9, ptr %l13
  br label %bb3
bb3:
  %t10 = load i64, ptr %l11, !tbaa !24
  %t11 = load i64, ptr %l13, !tbaa !24
  %t12 = icmp slt i64 %t10, %t11
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb4, label %bb5
bb4:
  br label %bb22
bb5:
  br label %bb6
bb6:
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t17 = load i64, ptr %l4, !tbaa !24
  %t20 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t16, i64 %t17)
  store i64 %t20, ptr %l18
  br label %bb7
bb7:
  %t21 = load i64, ptr %l18, !tbaa !24
  store i64 %t21, ptr %l5, !tbaa !24
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/emit:Emitter", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 60
  store ptr %t27, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  %t29 = load i64, ptr %l7, !tbaa !24
  store i64 %t29, ptr %l22, !tbaa !24
  %t30 = load ptr, ptr %l6, !tbaa !29
  %t32 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t30)
  store i64 %t32, ptr %l24
  br label %bb9
bb9:
  %t33 = load i64, ptr %l22, !tbaa !24
  %t34 = load i64, ptr %l24, !tbaa !24
  %t35 = icmp slt i64 %t33, %t34
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb10, label %bb11
bb10:
  br label %bb20
bb11:
  br label %bb12
bb12:
  %t39 = load ptr, ptr %l6, !tbaa !29
  %t40 = load i64, ptr %l7, !tbaa !24
  %t43 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t39, i64 %t40)
  store i64 %t43, ptr %l29
  br label %bb13
bb13:
  %t44 = load i64, ptr %l29, !tbaa !24
  store i64 %t44, ptr %l8, !tbaa !24
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i64, ptr %l8, !tbaa !24
  %t47 = load i64, ptr %l5, !tbaa !24
  %t51 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobalIn(ptr %v0, ptr %t45, i64 %t46, i64 %t47)
  store i1 %t51, ptr %l33
  br label %bb14
bb14:
  %t52 = load i1, ptr %l33, !tbaa !21
  br i1 %t52, label %bb15, label %bb16
bb15:
  %t53 = load ptr, ptr %lp2
  %t54 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t53, i64 %t54)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t57 = load i64, ptr %l7, !tbaa !24
  %t59 = add i64 %t57, 1
  store i64 %t59, ptr %l7, !tbaa !24
  br label %bb8
bb20:
  br label %bb21
bb21:
  %t61 = load i64, ptr %l4, !tbaa !24
  %t63 = add i64 %t61, 1
  store i64 %t63, ptr %l4, !tbaa !24
  br label %bb2
bb22:
  %t65 = load ptr, ptr %lp2
  %t66 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t65
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t66, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eharness(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { { i64, ptr }, { i64, ptr } }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"std/prelude/text:StringBuilder"
  %l16 = alloca { i64, ptr }
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca i64
  %l36 = alloca i64
  %l41 = alloca i64
  %l45 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i64
  %l54 = alloca { i64, ptr }
  %l59 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l61 = alloca i64
  %l63 = alloca i64
  %l68 = alloca i64
  %l71 = alloca { { i64, ptr }, { i64, ptr } }
  %l72 = alloca { i64, ptr }
  %l73 = alloca i64
  %l74 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l76 = alloca i64
  %l77 = alloca { i64, ptr }
  %l79 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i64
  %l89 = alloca ptr
  %l90 = alloca i64
  %l100 = alloca { i64, ptr }
  %l102 = alloca ptr
  %l103 = alloca i64
  %l105 = alloca { i64, ptr }
  %l106 = alloca ptr
  %l109 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l117 = alloca { i64, ptr }
  %l122 = alloca %"std/prelude/text:StringBuilder"
  %l124 = alloca i64
  %l126 = alloca ptr
  %l128 = alloca i64
  %l130 = alloca { i64, ptr }
  %l134 = alloca i64
  %l136 = alloca ptr
  %l138 = alloca i64
  %l140 = alloca { i64, ptr }
  %l160 = alloca i1
  %l162 = alloca ptr
  %l163 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l165 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l166 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l168 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l176 = alloca ptr
  %l177 = alloca ptr
  %l186 = alloca ptr
  %l189 = alloca { i64, ptr }
  %l196 = alloca i64
  %l199 = alloca ptr
  %l201 = alloca i64
  %l206 = alloca ptr
  %l208 = alloca i64
  %l215 = alloca i64
  %l218 = alloca i64
  %l221 = alloca ptr
  %l223 = alloca i64
  %l253 = alloca ptr
  %l255 = alloca { i64, ptr }
  %l267 = alloca ptr
  %l269 = alloca { i64, ptr }
  %l273 = alloca ptr
  %l277 = alloca i64
  %l279 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %t69 = alloca { i64, [2 x i64] }, align 8
  %t229 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2femit_2ecompiler_2femit_3aEmitter_2einitOrder(ptr %v0, ptr %s0, ptr %t1)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l18
  br label %bb1
bb1:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l2
  %t5 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %s0, ptr %s0, ptr %t5, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d50, i32 0, i32 1) }, { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d51, i32 0, i32 1) })
  br label %bb2
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %s0, ptr %s0, ptr %t7, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d52, i32 0, i32 1) }, { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d53, i32 0, i32 1) })
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %s0, ptr %s0, ptr %t9, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d54, i32 0, i32 1) }, { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d55, i32 0, i32 1) })
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %s0, ptr %s0, ptr %t11, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d56, i32 0, i32 1) }, { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d57, i32 0, i32 1) })
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %s0, ptr %s0, ptr %t13, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d58, i32 0, i32 1) }, { i64, ptr } { i64 68, ptr getelementptr inbounds (<{ i64, [68 x i8] }>, ptr @.d59, i32 0, i32 1) })
  br label %bb6
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t15, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d60, i32 0, i32 1) }, { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d61, i32 0, i32 1) })
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t17, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d62, i32 0, i32 1) }, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d63, i32 0, i32 1) })
  br label %bb8
bb8:
  %t19 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t19, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d64, i32 0, i32 1) }, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d65, i32 0, i32 1) })
  br label %bb9
bb9:
  %t21 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s0, ptr %t21, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d66, i32 0, i32 1) })
  br label %bb10
bb10:
  %t23 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s0, ptr %t23, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d67, i32 0, i32 1) })
  br label %bb11
bb11:
  %t25 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l29
  br label %bb12
bb12:
  %t26 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %l3
  store %olang.scope zeroinitializer, ptr %s1
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  %t31 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobalOrder(ptr %v0, ptr %s1, ptr %s1, ptr %t27, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t31, ptr %l32
  br label %bb13
bb13:
  %t32 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  %t33 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %t33
  store ptr %t33, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l5, !tbaa !24
  store i64 %t35, ptr %l34, !tbaa !24
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t38 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s1, ptr %t36)
  store i64 %t38, ptr %l36
  br label %bb15
bb15:
  %t39 = load i64, ptr %l34, !tbaa !24
  %t40 = load i64, ptr %l36, !tbaa !24
  %t41 = icmp slt i64 %t39, %t40
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb17:
  br label %bb18
bb18:
  %t45 = load ptr, ptr %l4, !tbaa !29
  %t46 = load i64, ptr %l5, !tbaa !24
  %t49 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s1, ptr %t45, i64 %t46)
  store i64 %t49, ptr %l41
  br label %bb19
bb19:
  %t50 = load i64, ptr %l41, !tbaa !24
  store i64 %t50, ptr %l6, !tbaa !24
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/emit:Emitter", ptr %t51, i32 0, i32 54
  %t54 = load i64, ptr %l6, !tbaa !24
  %t57 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_H901ad831a5883703dcf426ee01511832(ptr %v0, ptr %t53, i64 %t54)
  store i1 %t57, ptr %l45
  br label %bb20
bb20:
  %t58 = load i1, ptr %l45, !tbaa !21
  br i1 %t58, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb22:
  br label %bb23
bb23:
  store ptr %l3, ptr %l46, !tbaa !29
  %t59 = ptrtoint ptr %s0 to i64
  store i64 %t59, ptr %l47, !tbaa !24
  %t60 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t60, label %bb24, label %bb25
bb24:
  %t62 = call ptr @__olang_region_make(ptr %s0)
  %t63 = ptrtoint ptr %t62 to i64
  store i64 %t63, ptr %l47, !tbaa !24
  br label %bb25
bb25:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load i64, ptr %l6, !tbaa !24
  %t67 = trunc i64 %t65 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t69
  %t70 = getelementptr { i64, [2 x i64] }, ptr %t69, i32 0, i32 0
  store i64 0, ptr %t70
  %t72 = insertvalue { i32 } undef, i32 %t67, 0
  %t73 = getelementptr { i64, [2 x i64] }, ptr %t69, i32 0, i32 1
  store { i32 } %t72, ptr %t73
  %t74 = load { i64, [2 x i64] }, ptr %t69
  %t77 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s2, ptr %t64, { i64, [2 x i64] } %t74)
  store { i64, ptr } %t77, ptr %l54
  br label %bb26
bb26:
  %t78 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t79 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  %t80 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 1
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t83 = add i64 %t79, %t82
  %t84 = load i64, ptr %l47
  %t85 = inttoptr i64 %t84 to ptr
  %t86 = call ptr @__olang_scope_alloc(ptr %t85, i64 %t83)
  call void @olang_textcopy(ptr %t86, ptr %t78, i64 %t79)
  %t87 = getelementptr i8, ptr %t86, i64 %t79
  call void @olang_textcopy(ptr %t87, ptr %t81, i64 %t82)
  %t88 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t86, 1
  %t91 = load i64, ptr %l47
  %t92 = inttoptr i64 %t91 to ptr
  %t93 = extractvalue { i64, ptr } %t89, 0
  %t94 = extractvalue { i64, ptr } %t89, 1
  %t95 = mul i64 %t93, 1
  %t96 = call ptr @__olang_scope_alloc(ptr %t92, i64 %t95)
  call void @llvm.memcpy.p0.p0.i64(ptr %t96, ptr %t94, i64 %t95, i1 false)
  %t97 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t96, 1
  %t99 = load ptr, ptr %l46, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t99, { i64, ptr } %t98)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb28:
  %t101 = load i64, ptr %l5, !tbaa !24
  %t103 = add i64 %t101, 1
  store i64 %t103, ptr %l5, !tbaa !24
  br label %bb14
bb29:
  call void @__olang_scope_close(ptr %s1)
  %t105 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t105, ptr %l59
  br label %bb30
bb30:
  %t106 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l59
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t106, ptr %l7
  store ptr %l1, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s7
  %t108 = load i64, ptr %l9, !tbaa !24
  store i64 %t108, ptr %l61, !tbaa !24
  %t109 = load ptr, ptr %l8, !tbaa !29
  %t111 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t109)
  store i64 %t111, ptr %l63
  br label %bb32
bb32:
  %t112 = load i64, ptr %l61, !tbaa !24
  %t113 = load i64, ptr %l63, !tbaa !24
  %t114 = icmp slt i64 %t112, %t113
  %t116 = xor i1 %t114, true
  br i1 %t116, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s7)
  br label %bb57
bb34:
  br label %bb35
bb35:
  %t118 = load ptr, ptr %l8, !tbaa !29
  %t119 = load i64, ptr %l9, !tbaa !24
  %t122 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t118, i64 %t119)
  store i64 %t122, ptr %l68
  br label %bb36
bb36:
  %t123 = load i64, ptr %l68, !tbaa !24
  store i64 %t123, ptr %l10, !tbaa !24
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load i64, ptr %l10, !tbaa !24
  %t128 = call { { i64, ptr }, { i64, ptr } } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etestParts(ptr %v0, ptr %s7, ptr %t124, i64 %t125)
  store { { i64, ptr }, { i64, ptr } } %t128, ptr %l71
  br label %bb37
bb37:
  %t129 = load { { i64, ptr }, { i64, ptr } }, ptr %l71
  store { { i64, ptr }, { i64, ptr } } %t129, ptr %l11
  %t130 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l11, i32 0, i32 0
  %t131 = load { i64, ptr }, ptr %t130, !tbaa !27
  store { i64, ptr } %t131, ptr %l72, !tbaa !27
  %t132 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t132, 0
  store i64 %t133, ptr %l73, !tbaa !24
  %t134 = load i64, ptr %l73, !tbaa !24
  %t135 = mul i64 %t134, 1
  %t136 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t135)
  %t137 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t136, 1
  store { i64, ptr } %t138, ptr %l74, !tbaa !27
  %t139 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !27
  %t141 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = load i64, ptr %l73, !tbaa !24
  %t144 = mul i64 %t143, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t140, ptr %t142, i64 %t144, i1 false)
  %t145 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t145, ptr %l12, !tbaa !27
  %t146 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l11, i32 0, i32 1
  %t147 = load { i64, ptr }, ptr %t146, !tbaa !27
  store { i64, ptr } %t147, ptr %l75, !tbaa !27
  %t148 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t149 = extractvalue { i64, ptr } %t148, 0
  store i64 %t149, ptr %l76, !tbaa !24
  %t150 = load i64, ptr %l76, !tbaa !24
  %t151 = mul i64 %t150, 1
  %t152 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t151)
  %t153 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t152, 1
  store { i64, ptr } %t154, ptr %l77, !tbaa !27
  %t155 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !27
  %t157 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = load i64, ptr %l76, !tbaa !24
  %t160 = mul i64 %t159, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t156, ptr %t158, i64 %t160, i1 false)
  %t161 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t161, ptr %l13, !tbaa !27
  %t162 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t164 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s7, ptr %s7, { i64, ptr } %t162, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d69, i32 0, i32 1) })
  store i1 %t164, ptr %l79
  br label %bb38
bb38:
  %t165 = load i1, ptr %l79, !tbaa !21
  %t166 = xor i1 %t165, true
  br i1 %t166, label %bb39, label %bb40
bb39:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/emit:Emitter", ptr %t168, i32 0, i32 58
  store ptr %t170, ptr %l82, !tbaa !29
  %t171 = ptrtoint ptr %v0 to i64
  store i64 %t171, ptr %l83, !tbaa !24
  %t172 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t172, label %bb41, label %bb42
bb40:
  br label %bb44
bb41:
  %t174 = call ptr @__olang_region_make(ptr %v0)
  %t175 = ptrtoint ptr %t174 to i64
  store i64 %t175, ptr %l83, !tbaa !24
  br label %bb42
bb42:
  %t176 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t176, 1
  %t179 = extractvalue { i64, ptr } %t176, 0
  %t180 = load i64, ptr %l83
  %t181 = inttoptr i64 %t180 to ptr
  %t182 = call ptr @__olang_scope_alloc(ptr %t181, i64 %t179)
  call void @olang_textcopy(ptr %t182, ptr %t178, i64 %t179)
  %t183 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t182, 1
  %t186 = load i64, ptr %l83
  %t187 = inttoptr i64 %t186 to ptr
  %t188 = extractvalue { i64, ptr } %t184, 0
  %t189 = extractvalue { i64, ptr } %t184, 1
  %t190 = mul i64 %t188, 1
  %t191 = call ptr @__olang_scope_alloc(ptr %t187, i64 %t190)
  call void @llvm.memcpy.p0.p0.i64(ptr %t191, ptr %t189, i64 %t190, i1 false)
  %t192 = insertvalue { i64, ptr } undef, i64 %t188, 0
  %t193 = insertvalue { i64, ptr } %t192, ptr %t191, 1
  %t194 = load ptr, ptr %l82, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t194, { i64, ptr } %t193)
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/emit:Emitter", ptr %t196, i32 0, i32 58
  store ptr %t198, ptr %l89, !tbaa !29
  %t199 = ptrtoint ptr %v0 to i64
  store i64 %t199, ptr %l90, !tbaa !24
  %t200 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t200, label %bb45, label %bb46
bb45:
  %t202 = call ptr @__olang_region_make(ptr %v0)
  %t203 = ptrtoint ptr %t202 to i64
  store i64 %t203, ptr %l90, !tbaa !24
  br label %bb46
bb46:
  %t204 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t206 = extractvalue { i64, ptr } %t204, 1
  %t207 = extractvalue { i64, ptr } %t204, 0
  %t208 = load i64, ptr %l90
  %t209 = inttoptr i64 %t208 to ptr
  %t210 = call ptr @__olang_scope_alloc(ptr %t209, i64 %t207)
  call void @olang_textcopy(ptr %t210, ptr %t206, i64 %t207)
  %t211 = insertvalue { i64, ptr } undef, i64 %t207, 0
  %t212 = insertvalue { i64, ptr } %t211, ptr %t210, 1
  %t214 = load i64, ptr %l90
  %t215 = inttoptr i64 %t214 to ptr
  %t216 = extractvalue { i64, ptr } %t212, 0
  %t217 = extractvalue { i64, ptr } %t212, 1
  %t218 = mul i64 %t216, 1
  %t219 = call ptr @__olang_scope_alloc(ptr %t215, i64 %t218)
  call void @llvm.memcpy.p0.p0.i64(ptr %t219, ptr %t217, i64 %t218, i1 false)
  %t220 = insertvalue { i64, ptr } undef, i64 %t216, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr %t219, 1
  %t222 = load ptr, ptr %l89, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t222, { i64, ptr } %t221)
  br label %bb47
bb47:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t225 = load i64, ptr %l10, !tbaa !24
  %t227 = trunc i64 %t225 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t229
  %t230 = getelementptr { i64, [2 x i64] }, ptr %t229, i32 0, i32 0
  store i64 0, ptr %t230
  %t232 = insertvalue { i32 } undef, i32 %t227, 0
  %t233 = getelementptr { i64, [2 x i64] }, ptr %t229, i32 0, i32 1
  store { i32 } %t232, ptr %t233
  %t234 = load { i64, [2 x i64] }, ptr %t229
  %t237 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s7, ptr %t224, { i64, [2 x i64] } %t234)
  store { i64, ptr } %t237, ptr %l100
  br label %bb48
bb48:
  %t238 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t239 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t240 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t241 = extractvalue { i64, ptr } %t240, 1
  %t242 = extractvalue { i64, ptr } %t240, 0
  %t243 = add i64 %t239, %t242
  %t244 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t243)
  call void @olang_textcopy(ptr %t244, ptr %t238, i64 %t239)
  %t245 = getelementptr i8, ptr %t244, i64 %t239
  call void @olang_textcopy(ptr %t245, ptr %t241, i64 %t242)
  %t246 = insertvalue { i64, ptr } undef, i64 %t243, 0
  %t247 = insertvalue { i64, ptr } %t246, ptr %t244, 1
  store { i64, ptr } %t247, ptr %l14, !tbaa !27
  store ptr %l7, ptr %l102, !tbaa !29
  %t249 = ptrtoint ptr %s0 to i64
  store i64 %t249, ptr %l103, !tbaa !24
  %t250 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t250, label %bb49, label %bb50
bb49:
  %t252 = call ptr @__olang_region_make(ptr %s0)
  %t253 = ptrtoint ptr %t252 to i64
  store i64 %t253, ptr %l103, !tbaa !24
  br label %bb50
bb50:
  %t254 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t254, ptr %l105, !tbaa !27
  %t255 = load ptr, ptr %l0, !tbaa !29
  store ptr %t255, ptr %l106, !tbaa !29
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t257 = load i64, ptr %l10, !tbaa !24
  %t260 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etestName(ptr %v0, ptr %s7, ptr %t256, i64 %t257)
  store { i64, ptr } %t260, ptr %l109
  br label %bb51
bb51:
  %t261 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t262 = extractvalue { i64, ptr } %t261, 0
  %t263 = extractvalue { i64, ptr } %t261, 1
  %t264 = mul i64 %t262, 1
  %t265 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t264)
  call void @llvm.memcpy.p0.p0.i64(ptr %t265, ptr %t263, i64 %t264, i1 false)
  %t266 = insertvalue { i64, ptr } undef, i64 %t262, 0
  %t267 = insertvalue { i64, ptr } %t266, ptr %t265, 1
  %t268 = load ptr, ptr %l106, !tbaa !29
  %t270 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %s7, ptr %s7, ptr %t268, { i64, ptr } %t267)
  store { i64, ptr } %t270, ptr %l111
  br label %bb52
bb52:
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t272 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t275 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %s7, ptr %s7, ptr %t271, { i64, ptr } %t272)
  store { i64, ptr } %t275, ptr %l114
  br label %bb53
bb53:
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t277 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t280 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %s7, ptr %s7, ptr %t276, { i64, ptr } %t277)
  store { i64, ptr } %t280, ptr %l117
  br label %bb54
bb54:
  %t281 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d71, i32 0, i32 1) }, 1
  %t282 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d71, i32 0, i32 1) }, 0
  %t283 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t284 = extractvalue { i64, ptr } %t283, 1
  %t285 = extractvalue { i64, ptr } %t283, 0
  %t286 = add i64 %t282, %t285
  %t287 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t288 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  %t289 = add i64 %t286, %t288
  %t290 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t291 = extractvalue { i64, ptr } %t290, 1
  %t292 = extractvalue { i64, ptr } %t290, 0
  %t293 = add i64 %t289, %t292
  %t294 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t295 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  %t296 = add i64 %t293, %t295
  %t297 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t298 = extractvalue { i64, ptr } %t297, 1
  %t299 = extractvalue { i64, ptr } %t297, 0
  %t300 = add i64 %t296, %t299
  %t301 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t302 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  %t303 = add i64 %t300, %t302
  %t304 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t305 = extractvalue { i64, ptr } %t304, 1
  %t306 = extractvalue { i64, ptr } %t304, 0
  %t307 = add i64 %t303, %t306
  %t308 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t309 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  %t310 = add i64 %t307, %t309
  %t311 = load i64, ptr %l103
  %t312 = inttoptr i64 %t311 to ptr
  %t313 = call ptr @__olang_scope_alloc(ptr %t312, i64 %t310)
  call void @olang_textcopy(ptr %t313, ptr %t281, i64 %t282)
  %t314 = getelementptr i8, ptr %t313, i64 %t282
  call void @olang_textcopy(ptr %t314, ptr %t284, i64 %t285)
  %t315 = getelementptr i8, ptr %t314, i64 %t285
  call void @olang_textcopy(ptr %t315, ptr %t287, i64 %t288)
  %t316 = getelementptr i8, ptr %t315, i64 %t288
  call void @olang_textcopy(ptr %t316, ptr %t291, i64 %t292)
  %t317 = getelementptr i8, ptr %t316, i64 %t292
  call void @olang_textcopy(ptr %t317, ptr %t294, i64 %t295)
  %t318 = getelementptr i8, ptr %t317, i64 %t295
  call void @olang_textcopy(ptr %t318, ptr %t298, i64 %t299)
  %t319 = getelementptr i8, ptr %t318, i64 %t299
  call void @olang_textcopy(ptr %t319, ptr %t301, i64 %t302)
  %t320 = getelementptr i8, ptr %t319, i64 %t302
  call void @olang_textcopy(ptr %t320, ptr %t305, i64 %t306)
  %t321 = getelementptr i8, ptr %t320, i64 %t306
  call void @olang_textcopy(ptr %t321, ptr %t308, i64 %t309)
  %t322 = insertvalue { i64, ptr } undef, i64 %t310, 0
  %t323 = insertvalue { i64, ptr } %t322, ptr %t313, 1
  %t325 = load i64, ptr %l103
  %t326 = inttoptr i64 %t325 to ptr
  %t327 = extractvalue { i64, ptr } %t323, 0
  %t328 = extractvalue { i64, ptr } %t323, 1
  %t329 = mul i64 %t327, 1
  %t330 = call ptr @__olang_scope_alloc(ptr %t326, i64 %t329)
  call void @llvm.memcpy.p0.p0.i64(ptr %t330, ptr %t328, i64 %t329, i1 false)
  %t331 = insertvalue { i64, ptr } undef, i64 %t327, 0
  %t332 = insertvalue { i64, ptr } %t331, ptr %t330, 1
  %t333 = load ptr, ptr %l102, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t333, { i64, ptr } %t332)
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s7)
  br label %bb56
bb56:
  %t335 = load i64, ptr %l9, !tbaa !24
  %t337 = add i64 %t335, 1
  store i64 %t337, ptr %l9, !tbaa !24
  br label %bb31
bb57:
  %t339 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t339, ptr %l122
  br label %bb58
bb58:
  %t340 = load %"std/prelude/text:StringBuilder", ptr %l122
  store %"std/prelude/text:StringBuilder" %t340, ptr %l15
  %t342 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l3)
  store i64 %t342, ptr %l124
  br label %bb59
bb59:
  %t343 = load i64, ptr %l124, !tbaa !24
  %t344 = icmp sgt i64 %t343, 0
  br i1 %t344, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s14
  store ptr %l15, ptr %l126, !tbaa !29
  %t347 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l3)
  store i64 %t347, ptr %l128
  br label %bb62
bb61:
  br label %bb65
bb62:
  %t349 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s0, ptr %s14, ptr %s14, ptr %l3, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d74, i32 0, i32 1) })
  store { i64, ptr } %t349, ptr %l130
  br label %bb63
bb63:
  %t350 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d75, i32 0, i32 1) }, 1
  %t351 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d75, i32 0, i32 1) }, 0
  %t352 = load i64, ptr %l128, !tbaa !24
  %t353 = call i64 @__olang_fmt_i64(ptr null, i64 %t352)
  %t354 = add i64 %t351, %t353
  %t355 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d76, i32 0, i32 1) }, 1
  %t356 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d76, i32 0, i32 1) }, 0
  %t357 = add i64 %t354, %t356
  %t358 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t359 = extractvalue { i64, ptr } %t358, 1
  %t360 = extractvalue { i64, ptr } %t358, 0
  %t361 = add i64 %t357, %t360
  %t362 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t363 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  %t364 = add i64 %t361, %t363
  %t365 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t364)
  call void @olang_textcopy(ptr %t365, ptr %t350, i64 %t351)
  %t366 = getelementptr i8, ptr %t365, i64 %t351
  %t367 = call i64 @__olang_fmt_i64(ptr %t366, i64 %t352)
  %t368 = getelementptr i8, ptr %t366, i64 %t353
  call void @olang_textcopy(ptr %t368, ptr %t355, i64 %t356)
  %t369 = getelementptr i8, ptr %t368, i64 %t356
  call void @olang_textcopy(ptr %t369, ptr %t359, i64 %t360)
  %t370 = getelementptr i8, ptr %t369, i64 %t360
  call void @olang_textcopy(ptr %t370, ptr %t362, i64 %t363)
  %t371 = insertvalue { i64, ptr } undef, i64 %t364, 0
  %t372 = insertvalue { i64, ptr } %t371, ptr %t365, 1
  %t374 = extractvalue { i64, ptr } %t372, 0
  %t375 = extractvalue { i64, ptr } %t372, 1
  %t376 = mul i64 %t374, 1
  %t377 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t376)
  call void @llvm.memcpy.p0.p0.i64(ptr %t377, ptr %t375, i64 %t376, i1 false)
  %t378 = insertvalue { i64, ptr } undef, i64 %t374, 0
  %t379 = insertvalue { i64, ptr } %t378, ptr %t377, 1
  %t380 = load ptr, ptr %l126, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s14, ptr %t380, { i64, ptr } %t379)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s14)
  br label %bb65
bb65:
  %t383 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l7)
  store i64 %t383, ptr %l134
  br label %bb66
bb66:
  %t384 = load i64, ptr %l134, !tbaa !24
  %t385 = icmp sgt i64 %t384, 0
  br i1 %t385, label %bb67, label %bb68
bb67:
  store %olang.scope zeroinitializer, ptr %s16
  store ptr %l15, ptr %l136, !tbaa !29
  %t388 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l7)
  store i64 %t388, ptr %l138
  br label %bb69
bb68:
  br label %bb87
bb69:
  %t390 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s0, ptr %s16, ptr %s16, ptr %l7, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d78, i32 0, i32 1) })
  store { i64, ptr } %t390, ptr %l140
  br label %bb70
bb70:
  %t391 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d79, i32 0, i32 1) }, 1
  %t392 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d79, i32 0, i32 1) }, 0
  %t393 = load i64, ptr %l138, !tbaa !24
  %t394 = call i64 @__olang_fmt_i64(ptr null, i64 %t393)
  %t395 = add i64 %t392, %t394
  %t396 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d80, i32 0, i32 1) }, 1
  %t397 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d80, i32 0, i32 1) }, 0
  %t398 = add i64 %t395, %t397
  %t399 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t400 = extractvalue { i64, ptr } %t399, 1
  %t401 = extractvalue { i64, ptr } %t399, 0
  %t402 = add i64 %t398, %t401
  %t403 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d81, i32 0, i32 1) }, 1
  %t404 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d81, i32 0, i32 1) }, 0
  %t405 = add i64 %t402, %t404
  %t406 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t405)
  call void @olang_textcopy(ptr %t406, ptr %t391, i64 %t392)
  %t407 = getelementptr i8, ptr %t406, i64 %t392
  %t408 = call i64 @__olang_fmt_i64(ptr %t407, i64 %t393)
  %t409 = getelementptr i8, ptr %t407, i64 %t394
  call void @olang_textcopy(ptr %t409, ptr %t396, i64 %t397)
  %t410 = getelementptr i8, ptr %t409, i64 %t397
  call void @olang_textcopy(ptr %t410, ptr %t400, i64 %t401)
  %t411 = getelementptr i8, ptr %t410, i64 %t401
  call void @olang_textcopy(ptr %t411, ptr %t403, i64 %t404)
  %t412 = insertvalue { i64, ptr } undef, i64 %t405, 0
  %t413 = insertvalue { i64, ptr } %t412, ptr %t406, 1
  %t415 = extractvalue { i64, ptr } %t413, 0
  %t416 = extractvalue { i64, ptr } %t413, 1
  %t417 = mul i64 %t415, 1
  %t418 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t417)
  call void @llvm.memcpy.p0.p0.i64(ptr %t418, ptr %t416, i64 %t417, i1 false)
  %t419 = insertvalue { i64, ptr } undef, i64 %t415, 0
  %t420 = insertvalue { i64, ptr } %t419, ptr %t418, 1
  %t421 = load ptr, ptr %l136, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s16, ptr %t421, { i64, ptr } %t420)
  br label %bb71
bb71:
  %t423 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s16, ptr %s16, ptr %t423, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d82, i32 0, i32 1) }, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d83, i32 0, i32 1) })
  br label %bb72
bb72:
  %t425 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s16, ptr %s16, ptr %t425, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d84, i32 0, i32 1) }, { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d85, i32 0, i32 1) })
  br label %bb73
bb73:
  %t427 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s16, ptr %s16, ptr %t427, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d86, i32 0, i32 1) }, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d87, i32 0, i32 1) })
  br label %bb74
bb74:
  %t429 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s16, ptr %s16, ptr %t429, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d88, i32 0, i32 1) }, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d89, i32 0, i32 1) })
  br label %bb75
bb75:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s16, ptr %l15, { i64, ptr } { i64 92, ptr getelementptr inbounds (<{ i64, [92 x i8] }>, ptr @.d90, i32 0, i32 1) })
  br label %bb76
bb76:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s16, ptr %l15, { i64, ptr } { i64 75, ptr getelementptr inbounds (<{ i64, [75 x i8] }>, ptr @.d91, i32 0, i32 1) })
  br label %bb77
bb77:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s16, ptr %l15, { i64, ptr } { i64 73, ptr getelementptr inbounds (<{ i64, [73 x i8] }>, ptr @.d92, i32 0, i32 1) })
  br label %bb78
bb78:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s16, ptr %l15, { i64, ptr } { i64 72, ptr getelementptr inbounds (<{ i64, [72 x i8] }>, ptr @.d93, i32 0, i32 1) })
  br label %bb79
bb79:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s16, ptr %l15, { i64, ptr } { i64 108, ptr getelementptr inbounds (<{ i64, [108 x i8] }>, ptr @.d94, i32 0, i32 1) })
  br label %bb80
bb80:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s16, ptr %l15, { i64, ptr } { i64 85, ptr getelementptr inbounds (<{ i64, [85 x i8] }>, ptr @.d95, i32 0, i32 1) })
  br label %bb81
bb81:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s16, ptr %l15, { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d96, i32 0, i32 1) })
  br label %bb82
bb82:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s16, ptr %l15, { i64, ptr } { i64 96, ptr getelementptr inbounds (<{ i64, [96 x i8] }>, ptr @.d97, i32 0, i32 1) })
  br label %bb83
bb83:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s16, ptr %l15, { i64, ptr } { i64 82, ptr getelementptr inbounds (<{ i64, [82 x i8] }>, ptr @.d98, i32 0, i32 1) })
  br label %bb84
bb84:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s16, ptr %l15, { i64, ptr } { i64 95, ptr getelementptr inbounds (<{ i64, [95 x i8] }>, ptr @.d99, i32 0, i32 1) })
  br label %bb85
bb85:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s16, ptr %l15, { i64, ptr } { i64 105, ptr getelementptr inbounds (<{ i64, [105 x i8] }>, ptr @.d100, i32 0, i32 1) })
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s16)
  br label %bb87
bb87:
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t444 = getelementptr %"compiler/emit:Emitter", ptr %t442, i32 0, i32 57
  %t445 = load { i64, ptr }, ptr %t444, !tbaa !27
  %t447 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t445, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d101, i32 0, i32 1) })
  store i1 %t447, ptr %l160
  br label %bb88
bb88:
  %t448 = load i1, ptr %l160, !tbaa !21
  %t449 = xor i1 %t448, true
  br i1 %t449, label %bb89, label %bb90
bb89:
  store %olang.scope zeroinitializer, ptr %s18
  %t451 = load ptr, ptr %l0, !tbaa !29
  store ptr %t451, ptr %l162, !tbaa !29
  %t452 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t452, ptr %l163
  %t454 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s18, ptr %l163)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t454, ptr %l165
  br label %bb91
bb90:
  br label %bb94
bb91:
  %t455 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t455, ptr %l166
  %t457 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s18, ptr %l166)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t457, ptr %l168
  br label %bb92
bb92:
  %t458 = load ptr, ptr %l162, !tbaa !29
  %t459 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l165
  %t460 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l168
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efuzzHarness(ptr %v0, ptr %s18, ptr %s18, ptr %s0, ptr %t458, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t459, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t460, ptr %l15)
  br label %bb93
bb93:
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb94:
  %t462 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2etestSource(ptr %v0, ptr %t462)
  br label %bb95
bb95:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l15, { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d102, i32 0, i32 1) })
  br label %bb96
bb96:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l15, { i64, ptr } { i64 96, ptr getelementptr inbounds (<{ i64, [96 x i8] }>, ptr @.d103, i32 0, i32 1) })
  br label %bb97
bb97:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l15, { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d104, i32 0, i32 1) })
  br label %bb98
bb98:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l15, { i64, ptr } { i64 68, ptr getelementptr inbounds (<{ i64, [68 x i8] }>, ptr @.d105, i32 0, i32 1) })
  br label %bb99
bb99:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l15, { i64, ptr } { i64 74, ptr getelementptr inbounds (<{ i64, [74 x i8] }>, ptr @.d106, i32 0, i32 1) })
  br label %bb100
bb100:
  store ptr %l15, ptr %l176, !tbaa !29
  %t469 = load ptr, ptr %l0, !tbaa !29
  store ptr %t469, ptr %l177, !tbaa !29
  %t470 = load ptr, ptr %l0, !tbaa !29
  %t472 = getelementptr %"compiler/emit:Emitter", ptr %t470, i32 0, i32 0
  %t473 = load ptr, ptr %t472, !tbaa !29
  %t475 = getelementptr %"compiler/generic:Program", ptr %t473, i32 0, i32 0
  %t476 = load ptr, ptr %t475, !tbaa !29
  %t478 = getelementptr %"compiler/load:Loader", ptr %t476, i32 0, i32 10
  %t479 = load ptr, ptr %l0, !tbaa !29
  %t481 = getelementptr %"compiler/emit:Emitter", ptr %t479, i32 0, i32 0
  %t482 = load ptr, ptr %t481, !tbaa !29
  %t484 = getelementptr %"compiler/generic:Program", ptr %t482, i32 0, i32 0
  %t485 = load ptr, ptr %t484, !tbaa !29
  %t487 = getelementptr %"compiler/load:Loader", ptr %t485, i32 0, i32 12
  %t488 = load i64, ptr %t487, !tbaa !24
  %t491 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t478, i64 %t488)
  store ptr %t491, ptr %l186
  br label %bb101
bb101:
  %t492 = load ptr, ptr %l186, !tbaa !29
  %t494 = getelementptr %"compiler/load:Module", ptr %t492, i32 0, i32 0
  %t495 = load { i64, ptr }, ptr %t494, !tbaa !27
  %t496 = load ptr, ptr %l177, !tbaa !29
  %t498 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %v0, ptr %s0, ptr %t496, { i64, ptr } %t495)
  store { i64, ptr } %t498, ptr %l189
  br label %bb102
bb102:
  %t499 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d107, i32 0, i32 1) }, 1
  %t500 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d107, i32 0, i32 1) }, 0
  %t501 = load { i64, ptr }, ptr %l189, !tbaa !27
  %t502 = extractvalue { i64, ptr } %t501, 1
  %t503 = extractvalue { i64, ptr } %t501, 0
  %t504 = add i64 %t500, %t503
  %t505 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d108, i32 0, i32 1) }, 1
  %t506 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d108, i32 0, i32 1) }, 0
  %t507 = add i64 %t504, %t506
  %t508 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t507)
  call void @olang_textcopy(ptr %t508, ptr %t499, i64 %t500)
  %t509 = getelementptr i8, ptr %t508, i64 %t500
  call void @olang_textcopy(ptr %t509, ptr %t502, i64 %t503)
  %t510 = getelementptr i8, ptr %t509, i64 %t503
  call void @olang_textcopy(ptr %t510, ptr %t505, i64 %t506)
  %t511 = insertvalue { i64, ptr } undef, i64 %t507, 0
  %t512 = insertvalue { i64, ptr } %t511, ptr %t508, 1
  %t514 = extractvalue { i64, ptr } %t512, 0
  %t515 = extractvalue { i64, ptr } %t512, 1
  %t516 = mul i64 %t514, 1
  %t517 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t516)
  call void @llvm.memcpy.p0.p0.i64(ptr %t517, ptr %t515, i64 %t516, i1 false)
  %t518 = insertvalue { i64, ptr } undef, i64 %t514, 0
  %t519 = insertvalue { i64, ptr } %t518, ptr %t517, 1
  %t520 = load ptr, ptr %l176, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t520, { i64, ptr } %t519)
  br label %bb103
bb103:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l15, { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d109, i32 0, i32 1) })
  br label %bb104
bb104:
  %t523 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2esanInit(ptr %v0, ptr %s0, ptr %t523, ptr %l15)
  br label %bb105
bb105:
  %t527 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l3)
  store i64 %t527, ptr %l196
  br label %bb106
bb106:
  %t528 = load i64, ptr %l196, !tbaa !24
  %t529 = icmp sgt i64 %t528, 0
  br i1 %t529, label %bb107, label %bb108
bb107:
  store %olang.scope zeroinitializer, ptr %s20
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s20, ptr %l15, { i64, ptr } { i64 90, ptr getelementptr inbounds (<{ i64, [90 x i8] }>, ptr @.d110, i32 0, i32 1) })
  br label %bb109
bb108:
  br label %bb119
bb109:
  store ptr %l15, ptr %l199, !tbaa !29
  %t533 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l3)
  store i64 %t533, ptr %l201
  br label %bb110
bb110:
  %t534 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d111, i32 0, i32 1) }, 1
  %t535 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d111, i32 0, i32 1) }, 0
  %t536 = load i64, ptr %l201, !tbaa !24
  %t537 = call i64 @__olang_fmt_i64(ptr null, i64 %t536)
  %t538 = add i64 %t535, %t537
  %t539 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d112, i32 0, i32 1) }, 1
  %t540 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d112, i32 0, i32 1) }, 0
  %t541 = add i64 %t538, %t540
  %t542 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t541)
  call void @olang_textcopy(ptr %t542, ptr %t534, i64 %t535)
  %t543 = getelementptr i8, ptr %t542, i64 %t535
  %t544 = call i64 @__olang_fmt_i64(ptr %t543, i64 %t536)
  %t545 = getelementptr i8, ptr %t543, i64 %t537
  call void @olang_textcopy(ptr %t545, ptr %t539, i64 %t540)
  %t546 = insertvalue { i64, ptr } undef, i64 %t541, 0
  %t547 = insertvalue { i64, ptr } %t546, ptr %t542, 1
  %t549 = extractvalue { i64, ptr } %t547, 0
  %t550 = extractvalue { i64, ptr } %t547, 1
  %t551 = mul i64 %t549, 1
  %t552 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t551)
  call void @llvm.memcpy.p0.p0.i64(ptr %t552, ptr %t550, i64 %t551, i1 false)
  %t553 = insertvalue { i64, ptr } undef, i64 %t549, 0
  %t554 = insertvalue { i64, ptr } %t553, ptr %t552, 1
  %t555 = load ptr, ptr %l199, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s20, ptr %t555, { i64, ptr } %t554)
  br label %bb111
bb111:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s20, ptr %l15, { i64, ptr } { i64 75, ptr getelementptr inbounds (<{ i64, [75 x i8] }>, ptr @.d113, i32 0, i32 1) })
  br label %bb112
bb112:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s20, ptr %l15, { i64, ptr } { i64 107, ptr getelementptr inbounds (<{ i64, [107 x i8] }>, ptr @.d114, i32 0, i32 1) })
  br label %bb113
bb113:
  store ptr %l15, ptr %l206, !tbaa !29
  %t560 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l3)
  store i64 %t560, ptr %l208
  br label %bb114
bb114:
  %t561 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d115, i32 0, i32 1) }, 1
  %t562 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d115, i32 0, i32 1) }, 0
  %t563 = load i64, ptr %l208, !tbaa !24
  %t564 = call i64 @__olang_fmt_i64(ptr null, i64 %t563)
  %t565 = add i64 %t562, %t564
  %t566 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d116, i32 0, i32 1) }, 1
  %t567 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d116, i32 0, i32 1) }, 0
  %t568 = add i64 %t565, %t567
  %t569 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t568)
  call void @olang_textcopy(ptr %t569, ptr %t561, i64 %t562)
  %t570 = getelementptr i8, ptr %t569, i64 %t562
  %t571 = call i64 @__olang_fmt_i64(ptr %t570, i64 %t563)
  %t572 = getelementptr i8, ptr %t570, i64 %t564
  call void @olang_textcopy(ptr %t572, ptr %t566, i64 %t567)
  %t573 = insertvalue { i64, ptr } undef, i64 %t568, 0
  %t574 = insertvalue { i64, ptr } %t573, ptr %t569, 1
  %t576 = extractvalue { i64, ptr } %t574, 0
  %t577 = extractvalue { i64, ptr } %t574, 1
  %t578 = mul i64 %t576, 1
  %t579 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t578)
  call void @llvm.memcpy.p0.p0.i64(ptr %t579, ptr %t577, i64 %t578, i1 false)
  %t580 = insertvalue { i64, ptr } undef, i64 %t576, 0
  %t581 = insertvalue { i64, ptr } %t580, ptr %t579, 1
  %t582 = load ptr, ptr %l206, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s20, ptr %t582, { i64, ptr } %t581)
  br label %bb115
bb115:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s20, ptr %l15, { i64, ptr } { i64 69, ptr getelementptr inbounds (<{ i64, [69 x i8] }>, ptr @.d117, i32 0, i32 1) })
  br label %bb116
bb116:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s20, ptr %l15, { i64, ptr } { i64 94, ptr getelementptr inbounds (<{ i64, [94 x i8] }>, ptr @.d118, i32 0, i32 1) })
  br label %bb117
bb117:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s20, ptr %l15, { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d119, i32 0, i32 1) })
  br label %bb118
bb118:
  call void @__olang_scope_close(ptr %s20)
  br label %bb119
bb119:
  %t588 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l7)
  store i64 %t588, ptr %l215
  br label %bb120
bb120:
  %t589 = load i64, ptr %l215, !tbaa !24
  %t590 = icmp sgt i64 %t589, 0
  br i1 %t590, label %bb121, label %bb122
bb121:
  store %olang.scope zeroinitializer, ptr %s23
  %t593 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l7)
  store i64 %t593, ptr %l218
  br label %bb123
bb122:
  br label %bb148
bb123:
  %t594 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d120, i32 0, i32 1) }, 1
  %t595 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d120, i32 0, i32 1) }, 0
  %t596 = load i64, ptr %l218, !tbaa !24
  %t597 = call i64 @__olang_fmt_i64(ptr null, i64 %t596)
  %t598 = add i64 %t595, %t597
  %t599 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d121, i32 0, i32 1) }, 1
  %t600 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d121, i32 0, i32 1) }, 0
  %t601 = add i64 %t598, %t600
  %t602 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t601)
  call void @olang_textcopy(ptr %t602, ptr %t594, i64 %t595)
  %t603 = getelementptr i8, ptr %t602, i64 %t595
  %t604 = call i64 @__olang_fmt_i64(ptr %t603, i64 %t596)
  %t605 = getelementptr i8, ptr %t603, i64 %t597
  call void @olang_textcopy(ptr %t605, ptr %t599, i64 %t600)
  %t606 = insertvalue { i64, ptr } undef, i64 %t601, 0
  %t607 = insertvalue { i64, ptr } %t606, ptr %t602, 1
  store { i64, ptr } %t607, ptr %l16, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %l15, { i64, ptr } { i64 90, ptr getelementptr inbounds (<{ i64, [90 x i8] }>, ptr @.d122, i32 0, i32 1) })
  br label %bb124
bb124:
  store ptr %l15, ptr %l221, !tbaa !29
  %t611 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l7)
  store i64 %t611, ptr %l223
  br label %bb125
bb125:
  %t612 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d123, i32 0, i32 1) }, 1
  %t613 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d123, i32 0, i32 1) }, 0
  %t614 = load i64, ptr %l223, !tbaa !24
  %t615 = call i64 @__olang_fmt_i64(ptr null, i64 %t614)
  %t616 = add i64 %t613, %t615
  %t617 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d124, i32 0, i32 1) }, 1
  %t618 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d124, i32 0, i32 1) }, 0
  %t619 = add i64 %t616, %t618
  %t620 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t619)
  call void @olang_textcopy(ptr %t620, ptr %t612, i64 %t613)
  %t621 = getelementptr i8, ptr %t620, i64 %t613
  %t622 = call i64 @__olang_fmt_i64(ptr %t621, i64 %t614)
  %t623 = getelementptr i8, ptr %t621, i64 %t615
  call void @olang_textcopy(ptr %t623, ptr %t617, i64 %t618)
  %t624 = insertvalue { i64, ptr } undef, i64 %t619, 0
  %t625 = insertvalue { i64, ptr } %t624, ptr %t620, 1
  %t627 = extractvalue { i64, ptr } %t625, 0
  %t628 = extractvalue { i64, ptr } %t625, 1
  %t629 = mul i64 %t627, 1
  %t630 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t629)
  call void @llvm.memcpy.p0.p0.i64(ptr %t630, ptr %t628, i64 %t629, i1 false)
  %t631 = insertvalue { i64, ptr } undef, i64 %t627, 0
  %t632 = insertvalue { i64, ptr } %t631, ptr %t630, 1
  %t633 = load ptr, ptr %l221, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %t633, { i64, ptr } %t632)
  br label %bb126
bb126:
  %t635 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t636 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d125, i32 0, i32 1) }, 1
  %t637 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d125, i32 0, i32 1) }, 0
  %t639 = extractvalue { i64, ptr } %t635, 1
  %t640 = extractvalue { i64, ptr } %t635, 0
  %t641 = add i64 %t637, %t640
  %t642 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d126, i32 0, i32 1) }, 1
  %t643 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d126, i32 0, i32 1) }, 0
  %t644 = add i64 %t641, %t643
  %t645 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t644)
  call void @olang_textcopy(ptr %t645, ptr %t636, i64 %t637)
  %t646 = getelementptr i8, ptr %t645, i64 %t637
  call void @olang_textcopy(ptr %t646, ptr %t639, i64 %t640)
  %t647 = getelementptr i8, ptr %t646, i64 %t640
  call void @olang_textcopy(ptr %t647, ptr %t642, i64 %t643)
  %t648 = insertvalue { i64, ptr } undef, i64 %t644, 0
  %t649 = insertvalue { i64, ptr } %t648, ptr %t645, 1
  %t651 = extractvalue { i64, ptr } %t649, 0
  %t652 = extractvalue { i64, ptr } %t649, 1
  %t653 = mul i64 %t651, 1
  %t654 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t653)
  call void @llvm.memcpy.p0.p0.i64(ptr %t654, ptr %t652, i64 %t653, i1 false)
  %t655 = insertvalue { i64, ptr } undef, i64 %t651, 0
  %t656 = insertvalue { i64, ptr } %t655, ptr %t654, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %l15, { i64, ptr } %t656)
  br label %bb127
bb127:
  %t659 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t660 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d127, i32 0, i32 1) }, 1
  %t661 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d127, i32 0, i32 1) }, 0
  %t663 = extractvalue { i64, ptr } %t659, 1
  %t664 = extractvalue { i64, ptr } %t659, 0
  %t665 = add i64 %t661, %t664
  %t666 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d128, i32 0, i32 1) }, 1
  %t667 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d128, i32 0, i32 1) }, 0
  %t668 = add i64 %t665, %t667
  %t669 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t668)
  call void @olang_textcopy(ptr %t669, ptr %t660, i64 %t661)
  %t670 = getelementptr i8, ptr %t669, i64 %t661
  call void @olang_textcopy(ptr %t670, ptr %t663, i64 %t664)
  %t671 = getelementptr i8, ptr %t670, i64 %t664
  call void @olang_textcopy(ptr %t671, ptr %t666, i64 %t667)
  %t672 = insertvalue { i64, ptr } undef, i64 %t668, 0
  %t673 = insertvalue { i64, ptr } %t672, ptr %t669, 1
  %t675 = extractvalue { i64, ptr } %t673, 0
  %t676 = extractvalue { i64, ptr } %t673, 1
  %t677 = mul i64 %t675, 1
  %t678 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t677)
  call void @llvm.memcpy.p0.p0.i64(ptr %t678, ptr %t676, i64 %t677, i1 false)
  %t679 = insertvalue { i64, ptr } undef, i64 %t675, 0
  %t680 = insertvalue { i64, ptr } %t679, ptr %t678, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %l15, { i64, ptr } %t680)
  br label %bb128
bb128:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %l15, { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d129, i32 0, i32 1) })
  br label %bb129
bb129:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %l15, { i64, ptr } { i64 82, ptr getelementptr inbounds (<{ i64, [82 x i8] }>, ptr @.d130, i32 0, i32 1) })
  br label %bb130
bb130:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %l15, { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d131, i32 0, i32 1) })
  br label %bb131
bb131:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %l15, { i64, ptr } { i64 96, ptr getelementptr inbounds (<{ i64, [96 x i8] }>, ptr @.d132, i32 0, i32 1) })
  br label %bb132
bb132:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %l15, { i64, ptr } { i64 86, ptr getelementptr inbounds (<{ i64, [86 x i8] }>, ptr @.d133, i32 0, i32 1) })
  br label %bb133
bb133:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %l15, { i64, ptr } { i64 75, ptr getelementptr inbounds (<{ i64, [75 x i8] }>, ptr @.d134, i32 0, i32 1) })
  br label %bb134
bb134:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %l15, { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d135, i32 0, i32 1) })
  br label %bb135
bb135:
  %t690 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t691 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d136, i32 0, i32 1) }, 1
  %t692 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d136, i32 0, i32 1) }, 0
  %t694 = extractvalue { i64, ptr } %t690, 1
  %t695 = extractvalue { i64, ptr } %t690, 0
  %t696 = add i64 %t692, %t695
  %t697 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d137, i32 0, i32 1) }, 1
  %t698 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d137, i32 0, i32 1) }, 0
  %t699 = add i64 %t696, %t698
  %t700 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t699)
  call void @olang_textcopy(ptr %t700, ptr %t691, i64 %t692)
  %t701 = getelementptr i8, ptr %t700, i64 %t692
  call void @olang_textcopy(ptr %t701, ptr %t694, i64 %t695)
  %t702 = getelementptr i8, ptr %t701, i64 %t695
  call void @olang_textcopy(ptr %t702, ptr %t697, i64 %t698)
  %t703 = insertvalue { i64, ptr } undef, i64 %t699, 0
  %t704 = insertvalue { i64, ptr } %t703, ptr %t700, 1
  %t706 = extractvalue { i64, ptr } %t704, 0
  %t707 = extractvalue { i64, ptr } %t704, 1
  %t708 = mul i64 %t706, 1
  %t709 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t708)
  call void @llvm.memcpy.p0.p0.i64(ptr %t709, ptr %t707, i64 %t708, i1 false)
  %t710 = insertvalue { i64, ptr } undef, i64 %t706, 0
  %t711 = insertvalue { i64, ptr } %t710, ptr %t709, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %l15, { i64, ptr } %t711)
  br label %bb136
bb136:
  %t714 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t715 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d138, i32 0, i32 1) }, 1
  %t716 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d138, i32 0, i32 1) }, 0
  %t718 = extractvalue { i64, ptr } %t714, 1
  %t719 = extractvalue { i64, ptr } %t714, 0
  %t720 = add i64 %t716, %t719
  %t721 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d139, i32 0, i32 1) }, 1
  %t722 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d139, i32 0, i32 1) }, 0
  %t723 = add i64 %t720, %t722
  %t724 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t723)
  call void @olang_textcopy(ptr %t724, ptr %t715, i64 %t716)
  %t725 = getelementptr i8, ptr %t724, i64 %t716
  call void @olang_textcopy(ptr %t725, ptr %t718, i64 %t719)
  %t726 = getelementptr i8, ptr %t725, i64 %t719
  call void @olang_textcopy(ptr %t726, ptr %t721, i64 %t722)
  %t727 = insertvalue { i64, ptr } undef, i64 %t723, 0
  %t728 = insertvalue { i64, ptr } %t727, ptr %t724, 1
  %t730 = extractvalue { i64, ptr } %t728, 0
  %t731 = extractvalue { i64, ptr } %t728, 1
  %t732 = mul i64 %t730, 1
  %t733 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t732)
  call void @llvm.memcpy.p0.p0.i64(ptr %t733, ptr %t731, i64 %t732, i1 false)
  %t734 = insertvalue { i64, ptr } undef, i64 %t730, 0
  %t735 = insertvalue { i64, ptr } %t734, ptr %t733, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %l15, { i64, ptr } %t735)
  br label %bb137
bb137:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %l15, { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d140, i32 0, i32 1) })
  br label %bb138
bb138:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %l15, { i64, ptr } { i64 71, ptr getelementptr inbounds (<{ i64, [71 x i8] }>, ptr @.d141, i32 0, i32 1) })
  br label %bb139
bb139:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %l15, { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d142, i32 0, i32 1) })
  br label %bb140
bb140:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %l15, { i64, ptr } { i64 94, ptr getelementptr inbounds (<{ i64, [94 x i8] }>, ptr @.d143, i32 0, i32 1) })
  br label %bb141
bb141:
  store ptr %l15, ptr %l253, !tbaa !29
  %t742 = load ptr, ptr %l0, !tbaa !29
  %t744 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %s23, ptr %s23, ptr %t742, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d144, i32 0, i32 1) })
  store { i64, ptr } %t744, ptr %l255
  br label %bb142
bb142:
  %t745 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d145, i32 0, i32 1) }, 1
  %t746 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d145, i32 0, i32 1) }, 0
  %t747 = load { i64, ptr }, ptr %l255, !tbaa !27
  %t748 = extractvalue { i64, ptr } %t747, 1
  %t749 = extractvalue { i64, ptr } %t747, 0
  %t750 = add i64 %t746, %t749
  %t751 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d146, i32 0, i32 1) }, 1
  %t752 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d146, i32 0, i32 1) }, 0
  %t753 = add i64 %t750, %t752
  %t754 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t753)
  call void @olang_textcopy(ptr %t754, ptr %t745, i64 %t746)
  %t755 = getelementptr i8, ptr %t754, i64 %t746
  call void @olang_textcopy(ptr %t755, ptr %t748, i64 %t749)
  %t756 = getelementptr i8, ptr %t755, i64 %t749
  call void @olang_textcopy(ptr %t756, ptr %t751, i64 %t752)
  %t757 = insertvalue { i64, ptr } undef, i64 %t753, 0
  %t758 = insertvalue { i64, ptr } %t757, ptr %t754, 1
  %t760 = extractvalue { i64, ptr } %t758, 0
  %t761 = extractvalue { i64, ptr } %t758, 1
  %t762 = mul i64 %t760, 1
  %t763 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t762)
  call void @llvm.memcpy.p0.p0.i64(ptr %t763, ptr %t761, i64 %t762, i1 false)
  %t764 = insertvalue { i64, ptr } undef, i64 %t760, 0
  %t765 = insertvalue { i64, ptr } %t764, ptr %t763, 1
  %t766 = load ptr, ptr %l253, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %t766, { i64, ptr } %t765)
  br label %bb143
bb143:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %l15, { i64, ptr } { i64 82, ptr getelementptr inbounds (<{ i64, [82 x i8] }>, ptr @.d147, i32 0, i32 1) })
  br label %bb144
bb144:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %l15, { i64, ptr } { i64 107, ptr getelementptr inbounds (<{ i64, [107 x i8] }>, ptr @.d148, i32 0, i32 1) })
  br label %bb145
bb145:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %l15, { i64, ptr } { i64 85, ptr getelementptr inbounds (<{ i64, [85 x i8] }>, ptr @.d149, i32 0, i32 1) })
  br label %bb146
bb146:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %l15, { i64, ptr } { i64 59, ptr getelementptr inbounds (<{ i64, [59 x i8] }>, ptr @.d150, i32 0, i32 1) })
  br label %bb147
bb147:
  call void @__olang_scope_close(ptr %s23)
  br label %bb148
bb148:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l15, { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d151, i32 0, i32 1) })
  br label %bb149
bb149:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l15, { i64, ptr } { i64 98, ptr getelementptr inbounds (<{ i64, [98 x i8] }>, ptr @.d152, i32 0, i32 1) })
  br label %bb150
bb150:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l15, { i64, ptr } { i64 95, ptr getelementptr inbounds (<{ i64, [95 x i8] }>, ptr @.d153, i32 0, i32 1) })
  br label %bb151
bb151:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l15, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d154, i32 0, i32 1) })
  br label %bb152
bb152:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l15, { i64, ptr } { i64 74, ptr getelementptr inbounds (<{ i64, [74 x i8] }>, ptr @.d155, i32 0, i32 1) })
  br label %bb153
bb153:
  store ptr %l15, ptr %l267, !tbaa !29
  %t777 = load ptr, ptr %l0, !tbaa !29
  %t779 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %s0, ptr %s0, ptr %t777, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d156, i32 0, i32 1) })
  store { i64, ptr } %t779, ptr %l269
  br label %bb154
bb154:
  %t780 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d157, i32 0, i32 1) }, 1
  %t781 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d157, i32 0, i32 1) }, 0
  %t782 = load { i64, ptr }, ptr %l269, !tbaa !27
  %t783 = extractvalue { i64, ptr } %t782, 1
  %t784 = extractvalue { i64, ptr } %t782, 0
  %t785 = add i64 %t781, %t784
  %t786 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d158, i32 0, i32 1) }, 1
  %t787 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d158, i32 0, i32 1) }, 0
  %t788 = add i64 %t785, %t787
  %t789 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t788)
  call void @olang_textcopy(ptr %t789, ptr %t780, i64 %t781)
  %t790 = getelementptr i8, ptr %t789, i64 %t781
  call void @olang_textcopy(ptr %t790, ptr %t783, i64 %t784)
  %t791 = getelementptr i8, ptr %t790, i64 %t784
  call void @olang_textcopy(ptr %t791, ptr %t786, i64 %t787)
  %t792 = insertvalue { i64, ptr } undef, i64 %t788, 0
  %t793 = insertvalue { i64, ptr } %t792, ptr %t789, 1
  %t795 = extractvalue { i64, ptr } %t793, 0
  %t796 = extractvalue { i64, ptr } %t793, 1
  %t797 = mul i64 %t795, 1
  %t798 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t797)
  call void @llvm.memcpy.p0.p0.i64(ptr %t798, ptr %t796, i64 %t797, i1 false)
  %t799 = insertvalue { i64, ptr } undef, i64 %t795, 0
  %t800 = insertvalue { i64, ptr } %t799, ptr %t798, 1
  %t801 = load ptr, ptr %l267, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t801, { i64, ptr } %t800)
  br label %bb155
bb155:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l15, { i64, ptr } { i64 74, ptr getelementptr inbounds (<{ i64, [74 x i8] }>, ptr @.d159, i32 0, i32 1) })
  br label %bb156
bb156:
  %t804 = load ptr, ptr %l0, !tbaa !29
  store ptr %t804, ptr %l273, !tbaa !29
  %t805 = load ptr, ptr %l0, !tbaa !29
  %t807 = getelementptr %"compiler/emit:Emitter", ptr %t805, i32 0, i32 0
  %t808 = load ptr, ptr %t807, !tbaa !29
  %t810 = getelementptr %"compiler/generic:Program", ptr %t808, i32 0, i32 0
  %t811 = load ptr, ptr %t810, !tbaa !29
  %t813 = getelementptr %"compiler/load:Loader", ptr %t811, i32 0, i32 12
  %t814 = load i64, ptr %t813, !tbaa !24
  store i64 %t814, ptr %l277, !tbaa !24
  %t816 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l15)
  store { i64, ptr } %t816, ptr %l279
  br label %bb157
bb157:
  %t817 = load { i64, ptr }, ptr %l279, !tbaa !27
  %t818 = extractvalue { i64, ptr } %t817, 0
  %t819 = extractvalue { i64, ptr } %t817, 1
  %t820 = mul i64 %t818, 1
  %t821 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t820)
  call void @llvm.memcpy.p0.p0.i64(ptr %t821, ptr %t819, i64 %t820, i1 false)
  %t822 = insertvalue { i64, ptr } undef, i64 %t818, 0
  %t823 = insertvalue { i64, ptr } %t822, ptr %t821, 1
  %t824 = load ptr, ptr %l273, !tbaa !29
  %t825 = load i64, ptr %l277, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t824, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d160, i32 0, i32 1) }, i64 %t825, { i64, ptr } %t823, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) })
  br label %bb158
bb158:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehasEnv(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i32
  %l3 = alloca i1
  %l12 = alloca i1
  %rv = alloca i1
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 1
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb14
bb4:
  %t6 = load { i64, [2 x i64] }, ptr %l1
  %t8 = extractvalue { i64, [2 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 0
  br i1 %t9, label %bb5, label %bb6
bb5:
  %t11 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  store i32 %t13, ptr %l2, !tbaa !23
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t16 = load i32, ptr %l2, !tbaa !23
  %t18 = sext i32 %t16 to i64
  %t21 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisLambda(ptr %v0, ptr %a0, i64 %t18)
  store i1 %t21, ptr %l12
  br label %bb8
bb8:
  %t22 = load i1, ptr %l12, !tbaa !21
  store i1 %t22, ptr %l3, !tbaa !21
  br label %bb14
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_22c0ecf0dfd2f0b7_2552f1950a299d53)
  unreachable
bb14:
  %t23 = load i1, ptr %l3, !tbaa !21
  store i1 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2elocations(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l4 = alloca %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f"
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l15 = alloca %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f"
  %l17 = alloca %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f"
  %l18 = alloca i32
  %l20 = alloca i1
  %l26 = alloca { i64, ptr }
  %l30 = alloca %"std/prelude/text:StringBuilder"
  %l31 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l45 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t34 = alloca { ptr, ptr }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l12
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  %t5 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eIter_3cI64_2c_20Bool_3e(ptr %v1, ptr %v1, ptr %a1)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t5, ptr %l14
  br label %bb2
bb2:
  %t6 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l14
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t6, ptr %l3
  br label %bb3
bb3:
  %t8 = call { i32, %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cI64_2c_20Bool_3e_2eNext_3cI64_2c_20Bool_3e(ptr %v1, ptr %l3)
  %t9 = extractvalue { i32, %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f" } %t8, 1
  %t10 = extractvalue { i32, %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f" } %t8, 0
  store i32 %t10, ptr %l18
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb5, label %ok.12, !prof !99
ok.12:
  store %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f" %t9, ptr %l17
  br label %bb4
bb4:
  %t13 = load %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f", ptr %l17
  store %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f" %t13, ptr %l15
  br label %bb7
bb5:
  %t14 = load i32, ptr %l18, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  store i1 %t17, ptr %l20, !tbaa !21
  br label %bb6
bb6:
  br label %bb10
bb7:
  %t18 = load %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f", ptr %l15
  store %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f" %t18, ptr %l4
  %t19 = getelementptr %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f", ptr %l4, i32 0, i32 0
  %t20 = load i64, ptr %t19, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l2, i64 %t20)
  br label %bb8
bb8:
  br label %bb9
bb9:
  br label %bb3
bb10:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/emit:Emitter", ptr %t23, i32 0, i32 18
  store ptr %t25, ptr %l5, !tbaa !29
  %t28 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s0, ptr %l2)
  store { i64, ptr } %t28, ptr %l26
  br label %bb11
bb11:
  %t29 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t29, ptr %l6, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t32 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t33 = ptrtoint ptr %t32 to i64
  %t35 = getelementptr { ptr, ptr }, ptr %t34, i32 0, i32 0
  store ptr %t31, ptr %t35, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t37 = getelementptr { ptr, ptr }, ptr %t34, i32 0, i32 1
  store ptr %v0, ptr %t37, !tbaa !28
  %t38 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_161, 0
  %t39 = insertvalue { ptr, ptr } %t38, ptr %t34, 1
  %t42 = extractvalue { ptr, ptr } %t39, 0
  %t43 = extractvalue { ptr, ptr } %t39, 1
  call void @std_2fprelude_2farray_2eArray_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %s0, ptr %s0, { i64, ptr } %t30, ptr %t42, ptr %t43)
  br label %bb12
bb12:
  %t44 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t44, ptr %l30
  br label %bb13
bb13:
  %t45 = load %"std/prelude/text:StringBuilder", ptr %l30
  store %"std/prelude/text:StringBuilder" %t45, ptr %l7
  store ptr %l7, ptr %l31, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehead(ptr %v0, ptr %s0, ptr %t46)
  store { i64, ptr } %t48, ptr %l33
  br label %bb14
bb14:
  %t49 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  %t51 = extractvalue { i64, ptr } %t49, 1
  %t52 = mul i64 %t50, 1
  %t53 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t52)
  call void @llvm.memcpy.p0.p0.i64(ptr %t53, ptr %t51, i64 %t52, i1 false)
  %t54 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  %t56 = load ptr, ptr %l31, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t56, { i64, ptr } %t55)
  br label %bb15
bb15:
  %t58 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t58, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t60 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  store i64 %t62, ptr %l10, !tbaa !24
  br label %bb16
bb16:
  %t64 = load i64, ptr %l9, !tbaa !24
  %t65 = load i64, ptr %l10, !tbaa !24
  %t68 = icmp slt i64 %t64, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb17, label %bb18
bb17:
  br label %bb23
bb18:
  br label %bb19
bb19:
  %t72 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t72, ptr %l42, !tbaa !27
  %t73 = load i64, ptr %l9, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr i64, ptr %t76, i64 %t73
  %t78 = load i64, ptr %t77, !tbaa !34
  store ptr %l7, ptr %l45, !tbaa !29
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/emit:Emitter", ptr %t80, i32 0, i32 19
  %t86 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t82, i64 %t78)
  store { i64, ptr } %t86, ptr %l49
  br label %bb20
bb20:
  %t87 = load ptr, ptr %l45, !tbaa !29
  %t88 = load { i64, ptr }, ptr %l49, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t87, { i64, ptr } %t88)
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t89 = load i64, ptr %l9, !tbaa !24
  %t91 = add i64 %t89, 1
  store i64 %t91, ptr %l9, !tbaa !24
  br label %bb16
bb23:
  %t94 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l7)
  store { i64, ptr } %t94, ptr %l53
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  %t95 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t95, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eneed(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l17 = alloca i32
  %l20 = alloca i32
  %l23 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca i32
  %l30 = alloca i1
  %l33 = alloca i1
  %l35 = alloca i1
  %l39 = alloca i1
  %l49 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l17
  br label %bb1
bb1:
  %t11 = load i32, ptr %l17, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l20
  br label %bb2
bb2:
  %t17 = load i32, ptr %l20, !range !{i32 0, i32 33}
  store i32 %t17, ptr %l4
  %t18 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t20 = trunc i64 18 to i32
  %t21 = icmp eq i32 %t18, %t20
  br i1 %t21, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb29
bb5:
  %t23 = load ptr, ptr %l2, !tbaa !29
  store ptr %t23, ptr %l23, !tbaa !29
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t25 = load i32, ptr %l3, !tbaa !23
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t28, ptr %l26
  br label %bb6
bb6:
  %t29 = load ptr, ptr %l23, !tbaa !29
  %t30 = load i32, ptr %l26, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t31, ptr %l27
  br label %bb7
bb7:
  %t32 = load i32, ptr %l27, !range !{i32 0, i32 6}
  %t34 = trunc i64 0 to i32
  %t35 = icmp eq i32 %t32, %t34
  br i1 %t35, label %bb8, label %bb9
bb8:
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t38 = load i32, ptr %l3, !tbaa !23
  %t41 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePacked(ptr %v0, ptr %t37, i32 %t38)
  store i1 %t41, ptr %l33
  br label %bb10
bb9:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb11
bb10:
  %t42 = load i1, ptr %l33, !tbaa !21
  %t43 = xor i1 %t42, true
  store i1 %t43, ptr %l30, !tbaa !21
  br label %bb11
bb11:
  %t45 = load i1, ptr %l30, !tbaa !21
  br i1 %t45, label %bb12, label %bb13
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/emit:Emitter", ptr %t46, i32 0, i32 17
  %t49 = load i32, ptr %l3, !tbaa !23
  %t52 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_Hb3133f486435530b533aaf49461c92b5(ptr %v0, ptr %t48, i32 %t49)
  store i1 %t52, ptr %l39
  br label %bb14
bb13:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb15
bb14:
  %t53 = load i1, ptr %l39, !tbaa !21
  %t54 = xor i1 %t53, true
  store i1 %t54, ptr %l35, !tbaa !21
  br label %bb15
bb15:
  %t56 = load i1, ptr %l35, !tbaa !21
  br i1 %t56, label %bb16, label %bb17
bb16:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/emit:Emitter", ptr %t57, i32 0, i32 17
  %t60 = load i32, ptr %l3, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H64d9be73b6c9bed004c541bdf7f0ca0a(ptr %v0, ptr %t59, i32 %t60, i1 true)
  br label %bb18
bb17:
  br label %bb28
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/emit:Emitter", ptr %t63, i32 0, i32 16
  %t66 = load i32, ptr %l3, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t65, i32 %t66)
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t69 = load ptr, ptr %l2, !tbaa !29
  %t70 = load i32, ptr %l3, !tbaa !23
  %t73 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eEmbedded(ptr %v0, ptr %s3, ptr %t69, i32 %t70)
  store { i64, ptr } %t73, ptr %l49
  br label %bb20
bb20:
  %t74 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t74, 0
  %t76 = extractvalue { i64, ptr } %t74, 1
  %t77 = mul i64 %t75, 4
  %t78 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t77)
  call void @llvm.memcpy.p0.p0.i64(ptr %t78, ptr %t76, i64 %t77, i1 false)
  %t79 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t78, 1
  store { i64, ptr } %t80, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t82 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t82, 0
  store i64 %t84, ptr %l7, !tbaa !24
  br label %bb21
bb21:
  %t86 = load i64, ptr %l6, !tbaa !24
  %t87 = load i64, ptr %l7, !tbaa !24
  %t90 = icmp slt i64 %t86, %t87
  %t92 = xor i1 %t90, true
  br i1 %t92, label %bb22, label %bb23
bb22:
  br label %bb27
bb23:
  br label %bb24
bb24:
  %t94 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t94, ptr %l57, !tbaa !27
  %t95 = load i64, ptr %l6, !tbaa !24
  %t97 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr i32, ptr %t98, i64 %t95
  %t100 = load i32, ptr %t99, !tbaa !33
  %t102 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eneed(ptr %v0, ptr %t102, i32 %t100)
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t106 = load i64, ptr %l6, !tbaa !24
  %t108 = add i64 %t106, 1
  store i64 %t108, ptr %l6, !tbaa !24
  br label %bb21
bb27:
  call void @__olang_scope_close(ptr %s3)
  br label %bb28
bb28:
  br label %bb50
bb29:
  %t110 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t112 = trunc i64 19 to i32
  %t113 = icmp eq i32 %t110, %t112
  br i1 %t113, label %bb30, label %bb31
bb30:
  br label %bb36
bb31:
  %t115 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t117 = trunc i64 22 to i32
  %t118 = icmp eq i32 %t115, %t117
  br i1 %t118, label %bb32, label %bb33
bb32:
  br label %bb36
bb33:
  %t120 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t122 = trunc i64 23 to i32
  %t123 = icmp eq i32 %t120, %t122
  br i1 %t123, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb45
bb36:
  store %olang.scope zeroinitializer, ptr %s7
  %t125 = load ptr, ptr %l2, !tbaa !29
  %t126 = load i32, ptr %l3, !tbaa !23
  %t129 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eEmbedded(ptr %v0, ptr %s7, ptr %t125, i32 %t126)
  store { i64, ptr } %t129, ptr %l72
  br label %bb37
bb37:
  %t130 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 0
  %t132 = extractvalue { i64, ptr } %t130, 1
  %t133 = mul i64 %t131, 4
  %t134 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t133)
  call void @llvm.memcpy.p0.p0.i64(ptr %t134, ptr %t132, i64 %t133, i1 false)
  %t135 = insertvalue { i64, ptr } undef, i64 %t131, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t134, 1
  store { i64, ptr } %t136, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t138 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t138, 0
  store i64 %t140, ptr %l11, !tbaa !24
  br label %bb38
bb38:
  %t142 = load i64, ptr %l10, !tbaa !24
  %t143 = load i64, ptr %l11, !tbaa !24
  %t146 = icmp slt i64 %t142, %t143
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb39, label %bb40
bb39:
  br label %bb44
bb40:
  br label %bb41
bb41:
  %t150 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t150, ptr %l80, !tbaa !27
  %t151 = load i64, ptr %l10, !tbaa !24
  %t153 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr i32, ptr %t154, i64 %t151
  %t156 = load i32, ptr %t155, !tbaa !33
  %t158 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eneed(ptr %v0, ptr %t158, i32 %t156)
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t162 = load i64, ptr %l10, !tbaa !24
  %t164 = add i64 %t162, 1
  store i64 %t164, ptr %l10, !tbaa !24
  br label %bb38
bb44:
  call void @__olang_scope_close(ptr %s7)
  br label %bb50
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_ef8ce655497c6e66_70bdfc36b0b8c4fa)
  unreachable
bb50:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eretires(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l9 = alloca i64
  %l11 = alloca i64
  %l16 = alloca ptr
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 10
  store ptr %t9, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t11 = load i64, ptr %l3, !tbaa !24
  store i64 %t11, ptr %l9, !tbaa !24
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l11
  br label %bb2
bb2:
  %t15 = load i64, ptr %l9, !tbaa !24
  %t16 = load i64, ptr %l11, !tbaa !24
  %t17 = icmp slt i64 %t15, %t16
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t21, i64 %t22)
  store ptr %t25, ptr %l16
  br label %bb6
bb6:
  %t26 = load ptr, ptr %l16, !tbaa !29
  store ptr %t26, ptr %l4, !tbaa !29
  %t27 = load ptr, ptr %l4, !tbaa !29
  %t29 = getelementptr %"compiler/load:Module", ptr %t27, i32 0, i32 4
  %t30 = load i64, ptr %t29, !tbaa !24
  %t34 = icmp eq i64 %t30, %a1
  br i1 %t34, label %bb7, label %bb8
bb7:
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t38 = getelementptr %"compiler/load:Module", ptr %t36, i32 0, i32 5
  %t39 = load i1, ptr %t38, !tbaa !21
  store i1 %t39, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l3, !tbaa !24
  %t43 = add i64 %t41, 1
  store i64 %t43, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i1
  %l15 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l27 = alloca i32
  %l30 = alloca i32
  %l33 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l80 = alloca ptr
  %l85 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.builder
  %s3room = alloca [64 x i8], align 8
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load { i64, [2 x i64] }, ptr %l1
  %t8 = extractvalue { i64, [2 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  store i32 %t13, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l3, !tbaa !23
  %t18 = sext i32 %t16 to i64
  %t21 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ebodySym(ptr %v0, ptr %v1, ptr %t15, i64 %t18)
  store { i64, ptr } %t21, ptr %l22
  br label %bb4
bb4:
  %t22 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t22, ptr %l15, !tbaa !27
  br label %bb48
bb5:
  %t23 = load { i64, [2 x i64] }, ptr %l1
  %t25 = extractvalue { i64, [2 x i64] } %t23, 0
  %t26 = icmp eq i64 %t25, 3
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t28 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t29 = getelementptr { i32, i32 }, ptr %t28, i32 0, i32 0
  %t30 = load i32, ptr %t29, !range !{i32 0, i32 8}
  store i32 %t30, ptr %l4
  %t32 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t33 = getelementptr { i32, i32 }, ptr %t32, i32 0, i32 1
  %t34 = load i32, ptr %t33
  store i32 %t34, ptr %l5, !tbaa !23
  br label %bb8
bb7:
  br label %bb17
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load i32, ptr %l4, !range !{i32 0, i32 8}
  store i32 %t36, ptr %l27
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t38 = load i32, ptr %l5, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnnamed(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l30
  br label %bb9
bb9:
  %t42 = load i32, ptr %l5, !tbaa !23
  %t43 = load i32, ptr %l30, !tbaa !23
  %t45 = icmp eq i32 %t43, %t42
  br i1 %t45, label %bb10, label %bb11
bb10:
  %t47 = load ptr, ptr %l2, !tbaa !29
  %t48 = load i32, ptr %l5, !tbaa !23
  %t50 = inttoptr i64 0 to ptr
  %t53 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s2, ptr %t50, ptr %t47, i32 %t48)
  store { i64, ptr } %t53, ptr %l37
  br label %bb12
bb11:
  %t54 = load ptr, ptr %l2, !tbaa !29
  %t55 = load i32, ptr %l5, !tbaa !23
  %t57 = inttoptr i64 0 to ptr
  %t60 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanonNamed(ptr %v0, ptr %s2, ptr %t57, ptr %t54, i32 %t55)
  store { i64, ptr } %t60, ptr %l41
  br label %bb13
bb12:
  %t61 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t61, ptr %l33, !tbaa !27
  br label %bb14
bb13:
  %t62 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t62, ptr %l33, !tbaa !27
  br label %bb14
bb14:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s3
  store ptr %s3room, ptr %s3
  %t63 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d162, i32 0, i32 1) }, 1
  %t64 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d162, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t63, i64 %t64)
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fmir_3aHelperKind(ptr %s3, ptr %l27, i64 0)
  br label %bb15
bb15:
  %t66 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d163, i32 0, i32 1) }, 1
  %t67 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d163, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t66, i64 %t67)
  %t68 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 1
  %t70 = extractvalue { i64, ptr } %t68, 0
  call void @__olang_sb_put(ptr %s3, ptr %t69, i64 %t70)
  %t71 = load ptr, ptr %s3
  %t72 = getelementptr %olang.builder, ptr %s3, i32 0, i32 1
  %t73 = load i64, ptr %t72
  %t74 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t73)
  call void @olang_textcopy(ptr %t74, ptr %t71, i64 %t73)
  %t75 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  store { i64, ptr } %t76, ptr %l43, !tbaa !27
  %t77 = getelementptr %olang.builder, ptr %s3, i32 0, i32 3
  %t78 = load ptr, ptr %t77
  %t79 = icmp ne ptr %t78, null
  br i1 %t79, label %sbgrew.80, label %sbdone.81
sbgrew.80:
  call void @__olang_sb_done(ptr %s3)
  br label %sbdone.81
sbdone.81:
  %t82 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 0
  %t84 = extractvalue { i64, ptr } %t82, 1
  %t85 = mul i64 %t83, 1
  %t86 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t85)
  call void @llvm.memcpy.p0.p0.i64(ptr %t86, ptr %t84, i64 %t85, i1 false)
  %t87 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t86, 1
  %t90 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t88)
  store { i64, ptr } %t90, ptr %l45
  br label %bb16
bb16:
  %t91 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t91, ptr %l15, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  br label %bb48
bb17:
  %t92 = load { i64, [2 x i64] }, ptr %l1
  %t94 = extractvalue { i64, [2 x i64] } %t92, 0
  %t95 = icmp eq i64 %t94, 1
  br i1 %t95, label %bb18, label %bb19
bb18:
  %t97 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t98 = getelementptr { i32 }, ptr %t97, i32 0, i32 0
  %t99 = load i32, ptr %t98
  store i32 %t99, ptr %l6, !tbaa !23
  br label %bb20
bb19:
  br label %bb22
bb20:
  store %olang.scope zeroinitializer, ptr %s4
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load i32, ptr %l6, !tbaa !23
  %t104 = sext i32 %t102 to i64
  %t107 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ebodySym(ptr %v0, ptr %s4, ptr %t101, i64 %t104)
  store { i64, ptr } %t107, ptr %l52
  br label %bb21
bb21:
  %t108 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t108, 1
  %t110 = extractvalue { i64, ptr } %t108, 0
  %t111 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d164, i32 0, i32 1) }, 1
  %t112 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d164, i32 0, i32 1) }, 0
  %t113 = add i64 %t110, %t112
  %t114 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t113)
  call void @olang_textcopy(ptr %t114, ptr %t109, i64 %t110)
  %t115 = getelementptr i8, ptr %t114, i64 %t110
  call void @olang_textcopy(ptr %t115, ptr %t111, i64 %t112)
  %t116 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t114, 1
  store { i64, ptr } %t117, ptr %l15, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  br label %bb48
bb22:
  %t119 = load { i64, [2 x i64] }, ptr %l1
  %t121 = extractvalue { i64, [2 x i64] } %t119, 0
  %t122 = icmp eq i64 %t121, 2
  br i1 %t122, label %bb23, label %bb24
bb23:
  %t124 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t125 = getelementptr { i32 }, ptr %t124, i32 0, i32 0
  %t126 = load i32, ptr %t125
  store i32 %t126, ptr %l7, !tbaa !23
  br label %bb25
bb24:
  br label %bb27
bb25:
  store %olang.scope zeroinitializer, ptr %s6
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load i32, ptr %l7, !tbaa !23
  %t131 = sext i32 %t129 to i64
  %t134 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ebodySym(ptr %v0, ptr %s6, ptr %t128, i64 %t131)
  store { i64, ptr } %t134, ptr %l60
  br label %bb26
bb26:
  %t135 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t135, 1
  %t137 = extractvalue { i64, ptr } %t135, 0
  %t138 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d165, i32 0, i32 1) }, 1
  %t139 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d165, i32 0, i32 1) }, 0
  %t140 = add i64 %t137, %t139
  %t141 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t140)
  call void @olang_textcopy(ptr %t141, ptr %t136, i64 %t137)
  %t142 = getelementptr i8, ptr %t141, i64 %t137
  call void @olang_textcopy(ptr %t142, ptr %t138, i64 %t139)
  %t143 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t141, 1
  store { i64, ptr } %t144, ptr %l15, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb48
bb27:
  %t146 = load { i64, [2 x i64] }, ptr %l1
  %t148 = extractvalue { i64, [2 x i64] } %t146, 0
  %t149 = icmp eq i64 %t148, 6
  br i1 %t149, label %bb28, label %bb29
bb28:
  %t151 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t152 = getelementptr { i32, i64 }, ptr %t151, i32 0, i32 0
  %t153 = load i32, ptr %t152
  store i32 %t153, ptr %l8, !tbaa !23
  %t155 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t156 = getelementptr { i32, i64 }, ptr %t155, i32 0, i32 1
  %t157 = load i64, ptr %t156
  store i64 %t157, ptr %l9, !tbaa !24
  br label %bb30
bb29:
  br label %bb32
bb30:
  store %olang.scope zeroinitializer, ptr %s8
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load i32, ptr %l8, !tbaa !23
  %t162 = sext i32 %t160 to i64
  %t165 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ebodySym(ptr %v0, ptr %s8, ptr %t159, i64 %t162)
  store { i64, ptr } %t165, ptr %l69
  br label %bb31
bb31:
  %t166 = load i64, ptr %l9, !tbaa !24
  %t167 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t167, 1
  %t169 = extractvalue { i64, ptr } %t167, 0
  %t170 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d166, i32 0, i32 1) }, 1
  %t171 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d166, i32 0, i32 1) }, 0
  %t172 = add i64 %t169, %t171
  %t174 = call i64 @__olang_fmt_i64(ptr null, i64 %t166)
  %t175 = add i64 %t172, %t174
  %t176 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t175)
  call void @olang_textcopy(ptr %t176, ptr %t168, i64 %t169)
  %t177 = getelementptr i8, ptr %t176, i64 %t169
  call void @olang_textcopy(ptr %t177, ptr %t170, i64 %t171)
  %t178 = getelementptr i8, ptr %t177, i64 %t171
  %t179 = call i64 @__olang_fmt_i64(ptr %t178, i64 %t166)
  %t180 = insertvalue { i64, ptr } undef, i64 %t175, 0
  %t181 = insertvalue { i64, ptr } %t180, ptr %t176, 1
  store { i64, ptr } %t181, ptr %l15, !tbaa !27
  call void @__olang_scope_close(ptr %s8)
  br label %bb48
bb32:
  %t183 = load { i64, [2 x i64] }, ptr %l1
  %t185 = extractvalue { i64, [2 x i64] } %t183, 0
  %t186 = icmp eq i64 %t185, 4
  br i1 %t186, label %bb33, label %bb34
bb33:
  %t188 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t189 = getelementptr { i64 }, ptr %t188, i32 0, i32 0
  %t190 = load i64, ptr %t189
  store i64 %t190, ptr %l10, !tbaa !24
  br label %bb35
bb34:
  br label %bb38
bb35:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/emit:Emitter", ptr %t192, i32 0, i32 0
  %t195 = load ptr, ptr %t194, !tbaa !29
  %t197 = getelementptr %"compiler/generic:Program", ptr %t195, i32 0, i32 0
  %t198 = load ptr, ptr %t197, !tbaa !29
  %t200 = getelementptr %"compiler/load:Loader", ptr %t198, i32 0, i32 10
  %t201 = load i64, ptr %l10, !tbaa !24
  %t204 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t200, i64 %t201)
  store ptr %t204, ptr %l80
  br label %bb36
bb36:
  %t205 = load ptr, ptr %l80, !tbaa !29
  %t207 = getelementptr %"compiler/load:Module", ptr %t205, i32 0, i32 2
  %t208 = load { i64, ptr }, ptr %t207, !tbaa !27
  %t209 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d167, i32 0, i32 1) }, 1
  %t210 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d167, i32 0, i32 1) }, 0
  %t212 = extractvalue { i64, ptr } %t208, 1
  %t213 = extractvalue { i64, ptr } %t208, 0
  %t214 = add i64 %t210, %t213
  %t215 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t214)
  call void @olang_textcopy(ptr %t215, ptr %t209, i64 %t210)
  %t216 = getelementptr i8, ptr %t215, i64 %t210
  call void @olang_textcopy(ptr %t216, ptr %t212, i64 %t213)
  %t217 = insertvalue { i64, ptr } undef, i64 %t214, 0
  %t218 = insertvalue { i64, ptr } %t217, ptr %t215, 1
  %t220 = extractvalue { i64, ptr } %t218, 0
  %t221 = extractvalue { i64, ptr } %t218, 1
  %t222 = mul i64 %t220, 1
  %t223 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t222)
  call void @llvm.memcpy.p0.p0.i64(ptr %t223, ptr %t221, i64 %t222, i1 false)
  %t224 = insertvalue { i64, ptr } undef, i64 %t220, 0
  %t225 = insertvalue { i64, ptr } %t224, ptr %t223, 1
  %t227 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t225)
  store { i64, ptr } %t227, ptr %l85
  br label %bb37
bb37:
  %t228 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t228, ptr %l15, !tbaa !27
  br label %bb48
bb38:
  %t229 = load { i64, [2 x i64] }, ptr %l1
  %t231 = extractvalue { i64, [2 x i64] } %t229, 0
  %t232 = icmp eq i64 %t231, 5
  br i1 %t232, label %bb39, label %bb40
bb39:
  %t234 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t235 = getelementptr { i64, i1 }, ptr %t234, i32 0, i32 0
  %t236 = load i64, ptr %t235
  store i64 %t236, ptr %l11, !tbaa !24
  %t238 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t239 = getelementptr { i64, i1 }, ptr %t238, i32 0, i32 1
  %t240 = load i1, ptr %t239
  store i1 %t240, ptr %l12, !tbaa !21
  br label %bb41
bb40:
  br label %bb47
bb41:
  store %olang.scope zeroinitializer, ptr %s12
  %t242 = load i1, ptr %l12, !tbaa !21
  br i1 %t242, label %bb42, label %bb43
bb42:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d168, i32 0, i32 1) }, ptr %l91, !tbaa !27
  br label %bb44
bb43:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d169, i32 0, i32 1) }, ptr %l91, !tbaa !27
  br label %bb44
bb44:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t245 = load i64, ptr %l11, !tbaa !24
  %t248 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etableName(ptr %v0, ptr %s12, ptr %t244, i64 %t245)
  store { i64, ptr } %t248, ptr %l94
  br label %bb45
bb45:
  %t249 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d170, i32 0, i32 1) }, 1
  %t250 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d170, i32 0, i32 1) }, 0
  %t251 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t251, 1
  %t253 = extractvalue { i64, ptr } %t251, 0
  %t254 = add i64 %t250, %t253
  %t255 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d171, i32 0, i32 1) }, 1
  %t256 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d171, i32 0, i32 1) }, 0
  %t257 = add i64 %t254, %t256
  %t258 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t259 = extractvalue { i64, ptr } %t258, 1
  %t260 = extractvalue { i64, ptr } %t258, 0
  %t261 = add i64 %t257, %t260
  %t262 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t261)
  call void @olang_textcopy(ptr %t262, ptr %t249, i64 %t250)
  %t263 = getelementptr i8, ptr %t262, i64 %t250
  call void @olang_textcopy(ptr %t263, ptr %t252, i64 %t253)
  %t264 = getelementptr i8, ptr %t263, i64 %t253
  call void @olang_textcopy(ptr %t264, ptr %t255, i64 %t256)
  %t265 = getelementptr i8, ptr %t264, i64 %t256
  call void @olang_textcopy(ptr %t265, ptr %t259, i64 %t260)
  %t266 = insertvalue { i64, ptr } undef, i64 %t261, 0
  %t267 = insertvalue { i64, ptr } %t266, ptr %t262, 1
  %t269 = extractvalue { i64, ptr } %t267, 0
  %t270 = extractvalue { i64, ptr } %t267, 1
  %t271 = mul i64 %t269, 1
  %t272 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t271)
  call void @llvm.memcpy.p0.p0.i64(ptr %t272, ptr %t270, i64 %t271, i1 false)
  %t273 = insertvalue { i64, ptr } undef, i64 %t269, 0
  %t274 = insertvalue { i64, ptr } %t273, ptr %t272, 1
  %t276 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t274)
  store { i64, ptr } %t276, ptr %l97
  br label %bb46
bb46:
  %t277 = load { i64, ptr }, ptr %l97, !tbaa !27
  store { i64, ptr } %t277, ptr %l15, !tbaa !27
  call void @__olang_scope_close(ptr %s12)
  br label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_325a0aca37049b03_8faf0435ed6a0227)
  unreachable
bb48:
  %t278 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t278, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca ptr
  %l7 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/types:Table", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t10 = call ptr @__olang_scope_of(ptr %t9, ptr null)
  %t11 = ptrtoint ptr %t10 to i64
  %t13 = inttoptr i64 %t11 to ptr
  %t14 = load ptr, ptr %l4, !tbaa !29
  %t16 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %t13, ptr %v1, ptr %t14, i32 %a1)
  store { i64, ptr } %t16, ptr %l7
  br label %bb1
bb1:
  %t17 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t17, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2etypeHome(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l8 = alloca i32
  %l11 = alloca i32
  %l15 = alloca i1
  %l18 = alloca i32
  %l21 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i32, ptr %l8, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l11
  br label %bb2
bb2:
  %t17 = load i32, ptr %l11, !range !{i32 0, i32 33}
  %t19 = trunc i64 18 to i32
  %t20 = icmp eq i32 %t17, %t19
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb6
bb4:
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t25 = load i32, ptr %l3, !tbaa !23
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t28, ptr %l18
  br label %bb5
bb5:
  %t29 = load i32, ptr %l18, !tbaa !23
  %t30 = icmp ne i32 %t29, 0
  store i1 %t30, ptr %l15, !tbaa !21
  br label %bb6
bb6:
  %t32 = load i1, ptr %l15, !tbaa !21
  br i1 %t32, label %bb7, label %bb8
bb7:
  %t33 = load i64, ptr @G_2ecompiler_2femit_2eHomeInst, !tbaa !24
  store i64 %t33, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t35 = load ptr, ptr %l2, !tbaa !29
  store ptr %t35, ptr %l21, !tbaa !29
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t37 = load i32, ptr %l3, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t40, ptr %l24
  br label %bb10
bb10:
  %t41 = load ptr, ptr %l21, !tbaa !29
  %t42 = load i32, ptr %l24, !tbaa !23
  %t43 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t41, i32 %t42)
  store i64 %t43, ptr %l25
  br label %bb11
bb11:
  %t44 = load i64, ptr %l25, !tbaa !24
  store i64 %t44, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewalkStub(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, { i64, ptr } %a3, i64 %a4, i1 %a5, { i64, ptr } %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i1
  %l7 = alloca { i64, ptr }
  %l10 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca { i64, [2 x i64] }
  %l16 = alloca i32
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca { i64, [2 x i64] }
  %l22 = alloca i32
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i1
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i64 %a4, ptr %l4
  store i1 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load { i64, [2 x i64] }, ptr %l1
  %t5 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisGenFn(ptr %v0, ptr %t1, { i64, [2 x i64] } %t2)
  store i1 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i1, ptr %l10, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = extractvalue { i64, ptr } %a3, 1
  %t12 = extractvalue { i64, ptr } %a3, 0
  %t13 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d172, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d172, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t15)
  call void @olang_textcopy(ptr %t16, ptr %t11, i64 %t12)
  %t17 = getelementptr i8, ptr %t16, i64 %t12
  call void @olang_textcopy(ptr %t17, ptr %t13, i64 %t14)
  %t18 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t16, 1
  store { i64, ptr } %t19, ptr %l7, !tbaa !27
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l14, !tbaa !29
  %t22 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t22, ptr %l15
  %t23 = load i32, ptr %l2, !tbaa !23
  store i32 %t23, ptr %l16, !tbaa !23
  %t24 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t24, ptr %l17, !tbaa !27
  %t25 = load i64, ptr %l4, !tbaa !24
  store i64 %t25, ptr %l18, !tbaa !24
  %t26 = load i1, ptr %l5, !tbaa !21
  store i1 %t26, ptr %l19, !tbaa !21
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l20, !tbaa !29
  %t28 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t28, ptr %l21
  %t29 = load i32, ptr %l2, !tbaa !23
  store i32 %t29, ptr %l22, !tbaa !23
  %t30 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t30, ptr %l23, !tbaa !27
  %t31 = load i64, ptr %l4, !tbaa !24
  store i64 %t31, ptr %l24, !tbaa !24
  %t32 = load i1, ptr %l5, !tbaa !21
  store i1 %t32, ptr %l25, !tbaa !21
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load { i64, [2 x i64] }, ptr %l1
  %t37 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehomeOf(ptr %v0, ptr %t33, { i64, [2 x i64] } %t34)
  store i64 %t37, ptr %l28
  br label %bb5
bb5:
  %t38 = load i64, ptr %l28, !tbaa !24
  %t39 = call { i64, ptr } @compiler_2femit_2elinkFor(ptr %s0, i64 %t38)
  store { i64, ptr } %t39, ptr %l29
  br label %bb6
bb6:
  %t40 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  %t42 = extractvalue { i64, ptr } %t40, 1
  %t43 = mul i64 %t41, 1
  %t44 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t43)
  call void @llvm.memcpy.p0.p0.i64(ptr %t44, ptr %t42, i64 %t43, i1 false)
  %t45 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t44, 1
  %t47 = load ptr, ptr %l20, !tbaa !29
  %t48 = load { i64, [2 x i64] }, ptr %l21
  %t49 = load i32, ptr %l22, !tbaa !23
  %t50 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t51 = load i64, ptr %l24, !tbaa !24
  %t52 = load i1, ptr %l25, !tbaa !21
  %t54 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eheader(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t47, { i64, [2 x i64] } %t48, i32 %t49, { i64, ptr } %t50, i64 %t51, i1 %t52, { i64, ptr } %t46, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d173, i32 0, i32 1) })
  store { i64, ptr } %t54, ptr %l31
  br label %bb7
bb7:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t61 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2estub(ptr %v0, ptr %v2, ptr %s0, ptr %s0, ptr %t55, { i64, ptr } %a6, { i64, ptr } %t57)
  store { i64, ptr } %t61, ptr %l35
  br label %bb8
bb8:
  %t62 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t62, 1
  %t64 = extractvalue { i64, ptr } %t62, 0
  %t65 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 1
  %t67 = extractvalue { i64, ptr } %t65, 0
  %t68 = add i64 %t64, %t67
  %t69 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t68)
  call void @olang_textcopy(ptr %t69, ptr %t63, i64 %t64)
  %t70 = getelementptr i8, ptr %t69, i64 %t64
  call void @olang_textcopy(ptr %t70, ptr %t66, i64 %t67)
  %t71 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t69, 1
  %t74 = extractvalue { i64, ptr } %t72, 0
  %t75 = extractvalue { i64, ptr } %t72, 1
  %t76 = mul i64 %t74, 1
  %t77 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t76)
  call void @llvm.memcpy.p0.p0.i64(ptr %t77, ptr %t75, i64 %t76, i1 false)
  %t78 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  %t80 = load ptr, ptr %l14, !tbaa !29
  %t81 = load { i64, [2 x i64] }, ptr %l15
  %t82 = load i32, ptr %l16, !tbaa !23
  %t83 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t84 = load i64, ptr %l18, !tbaa !24
  %t85 = load i1, ptr %l19, !tbaa !21
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efnItem(ptr %v0, ptr %s0, ptr %s0, ptr %t80, { i64, [2 x i64] } %t81, i32 %t82, { i64, ptr } %t83, i64 %t84, i1 %t85, { i64, ptr } %t79)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2ebigArena(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 13
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/emit:fnEm", ptr %t6, i32 0, i32 13
  store i1 true, ptr %t8, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/emit:fnEm", ptr %t9, i32 0, i32 3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t11, { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d174, i32 0, i32 1) })
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/emit:fnEm", ptr %t13, i32 0, i32 4
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t15, { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d175, i32 0, i32 1) })
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/emit:fnEm", ptr %t17, i32 0, i32 0
  %t20 = load ptr, ptr %t19, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s0, ptr %t20, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d176, i32 0, i32 1) })
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/emit:fnEm", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s0, ptr %t25, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d177, i32 0, i32 1) })
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2econstItem(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca { i64, [1 x i64] }
  %l5 = alloca i64
  %l6 = alloca i32
  %l8 = alloca i32
  %l9 = alloca { { i64, ptr }, { i64, ptr }, i64 }
  %lp10 = alloca ptr
  %l11 = alloca { { i64, ptr }, i64 }
  %lp12 = alloca ptr
  %l13 = alloca i64
  %l22 = alloca { i64, [1 x i64] }
  %l30 = alloca { i64, ptr }
  %l33 = alloca i32
  %l36 = alloca i1
  %l37 = alloca i32
  %l40 = alloca i32
  %l44 = alloca i32
  %l48 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca { i64, ptr }
  %l61 = alloca i1
  %l62 = alloca i1
  %l65 = alloca i1
  %l67 = alloca ptr
  %l70 = alloca i32
  %l72 = alloca { { i64, ptr }, { i64, ptr }, i64 }
  %l73 = alloca { i64, ptr }
  %l74 = alloca i64
  %l75 = alloca { i64, ptr }
  %l77 = alloca ptr
  %l80 = alloca i32
  %l82 = alloca { { i64, ptr }, i64 }
  %l83 = alloca { i64, ptr }
  %l84 = alloca i64
  %l85 = alloca { i64, ptr }
  %l89 = alloca i1
  %l90 = alloca i1
  %l93 = alloca i1
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/emit:fnEm", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/mir:Fn", ptr %t12, i32 0, i32 19
  %t15 = load i32, ptr %l2, !tbaa !23
  %t17 = sext i32 %t15 to i64
  %t20 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2eAt_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %t14, i64 %t17)
  store { i64, [1 x i64] } %t20, ptr %l22
  br label %bb1
bb1:
  %t21 = load { i64, [1 x i64] }, ptr %l22
  store { i64, [1 x i64] } %t21, ptr %l4
  %t22 = load { i64, [1 x i64] }, ptr %l4
  %t24 = extractvalue { i64, [1 x i64] } %t22, 0
  %t25 = icmp eq i64 %t24, 0
  br i1 %t25, label %bb2, label %bb3
bb2:
  %t27 = getelementptr { i64, [1 x i64] }, ptr %l4, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  store i64 %t29, ptr %l5, !tbaa !24
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/emit:fnEm", ptr %t31, i32 0, i32 0
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t35 = load i32, ptr %l1, !tbaa !23
  %t36 = load i64, ptr %l5, !tbaa !24
  %t40 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2econstText(ptr %v0, ptr %v1, ptr %t34, i32 %t35, i64 %t36)
  store { i64, ptr } %t40, ptr %l30
  br label %bb5
bb5:
  %t41 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t41, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb42
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t42 = load ptr, ptr %l3, !tbaa !29
  %t43 = load i32, ptr %l1, !tbaa !23
  %t46 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t42, i32 %t43)
  store i32 %t46, ptr %l33
  br label %bb10
bb10:
  %t47 = load i32, ptr %l33, !tbaa !23
  store i32 %t47, ptr %l6, !tbaa !23
  %t48 = load ptr, ptr %l3, !tbaa !29
  %t49 = load i32, ptr %l6, !tbaa !23
  %t52 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t48, i32 %t49)
  store i1 %t52, ptr %l36
  br label %bb11
bb11:
  %t53 = load i1, ptr %l36, !tbaa !21
  br i1 %t53, label %bb12, label %bb13
bb12:
  %t54 = load ptr, ptr %l3, !tbaa !29
  %t55 = load i32, ptr %l6, !tbaa !23
  %t58 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t54, i32 %t55)
  store i32 %t58, ptr %l40
  br label %bb14
bb13:
  %t59 = load i32, ptr %l6, !tbaa !23
  store i32 %t59, ptr %l37, !tbaa !23
  br label %bb15
bb14:
  %t61 = load i32, ptr %l40, !tbaa !23
  store i32 %t61, ptr %l37, !tbaa !23
  br label %bb15
bb15:
  %t62 = load i32, ptr %l37, !tbaa !23
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t67 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %t63, i32 %t62)
  store i32 %t67, ptr %l44
  br label %bb16
bb16:
  %t68 = load i32, ptr %l44, !tbaa !23
  store i32 %t68, ptr %l8, !tbaa !23
  %t69 = load i32, ptr %l8, !tbaa !23
  %t70 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t73 = icmp eq i32 %t69, %t70
  br i1 %t73, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l48, !tbaa !29
  %t76 = load ptr, ptr %l3, !tbaa !29
  %t77 = load i32, ptr %l1, !tbaa !23
  %t79 = inttoptr i64 0 to ptr
  %t82 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s3, ptr %t79, ptr %t76, i32 %t77)
  store { i64, ptr } %t82, ptr %l52
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t83 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d178, i32 0, i32 1) }, 1
  %t84 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d178, i32 0, i32 1) }, 0
  %t85 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 1
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t88 = add i64 %t84, %t87
  %t89 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t88)
  call void @olang_textcopy(ptr %t89, ptr %t83, i64 %t84)
  %t90 = getelementptr i8, ptr %t89, i64 %t84
  call void @olang_textcopy(ptr %t90, ptr %t86, i64 %t87)
  %t91 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t89, 1
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t95 = extractvalue { i64, ptr } %t92, 1
  %t96 = mul i64 %t94, 1
  %t97 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t96)
  call void @llvm.memcpy.p0.p0.i64(ptr %t97, ptr %t95, i64 %t96, i1 false)
  %t98 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t97, 1
  %t100 = load ptr, ptr %l48, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s3, ptr %t100, { i64, ptr } %t99)
  br label %bb20
bb20:
  store { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d179, i32 0, i32 1) }, ptr %l55, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t102, ptr %l56, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 0
  store i64 %t104, ptr %l57, !tbaa !24
  %t105 = load i64, ptr %l57, !tbaa !24
  %t106 = mul i64 %t105, 1
  %t107 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t106)
  %t108 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t107, 1
  store { i64, ptr } %t109, ptr %l58, !tbaa !27
  %t110 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = load i64, ptr %l57, !tbaa !24
  %t115 = mul i64 %t114, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t111, ptr %t113, i64 %t115, i1 false)
  %t116 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t116, ptr %l56, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  %t117 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t117, ptr %rv
  br label %ret
bb21:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load i32, ptr %l8, !tbaa !23
  %t122 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixed(ptr %v0, ptr %t118, i32 %t119)
  store i1 %t122, ptr %l61
  br label %bb22
bb22:
  %t123 = load i1, ptr %l61, !tbaa !21
  br i1 %t123, label %bb23, label %bb24
bb23:
  %t124 = load ptr, ptr %l3, !tbaa !29
  %t125 = load i32, ptr %l6, !tbaa !23
  %t128 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t124, i32 %t125)
  store i1 %t128, ptr %l65
  br label %bb25
bb24:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb26
bb25:
  %t129 = load i1, ptr %l65, !tbaa !21
  %t130 = xor i1 %t129, true
  store i1 %t130, ptr %l62, !tbaa !21
  br label %bb26
bb26:
  %t132 = load i1, ptr %l62, !tbaa !21
  br i1 %t132, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s5
  %t133 = load ptr, ptr %l0, !tbaa !29
  store ptr %t133, ptr %l67, !tbaa !29
  %t134 = load ptr, ptr %l3, !tbaa !29
  %t135 = load i32, ptr %l8, !tbaa !23
  %t138 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t134, i32 %t135)
  store i32 %t138, ptr %l70
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t139 = load i32, ptr %l2, !tbaa !23
  %t140 = load ptr, ptr %l67, !tbaa !29
  %t141 = load i32, ptr %l70, !tbaa !23
  %t143 = call { { i64, ptr }, { i64, ptr }, i64 } @compiler_2femit_2ecompiler_2femit_3afnEm_2econstInit(ptr %v0, ptr %s5, ptr %t140, i32 %t141, i32 %t139)
  store { { i64, ptr }, { i64, ptr }, i64 } %t143, ptr %l72
  br label %bb30
bb30:
  %t144 = load { { i64, ptr }, { i64, ptr }, i64 }, ptr %l72
  store { { i64, ptr }, { i64, ptr }, i64 } %t144, ptr %l9
  %t145 = getelementptr { { i64, ptr }, { i64, ptr }, i64 }, ptr %l9, i32 0, i32 1
  %t146 = load { i64, ptr }, ptr %t145, !tbaa !27
  store { i64, ptr } %t146, ptr %l73, !tbaa !27
  %t147 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t147, 0
  store i64 %t148, ptr %l74, !tbaa !24
  %t149 = load i64, ptr %l74, !tbaa !24
  %t150 = mul i64 %t149, 1
  %t151 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t150)
  %t152 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t151, 1
  store { i64, ptr } %t153, ptr %l75, !tbaa !27
  %t154 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !27
  %t158 = load i64, ptr %l74, !tbaa !24
  %t159 = mul i64 %t158, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t155, ptr %t157, i64 %t159, i1 false)
  %t160 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t160, ptr %lp10
  %t161 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t162 = load ptr, ptr %lp10
  store { i64, ptr } %t161, ptr %t162, !tbaa !27
  %t163 = load ptr, ptr %lp10
  %t164 = load { i64, ptr }, ptr %t163, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s2)
  store { i64, ptr } %t164, ptr %rv
  br label %ret
bb31:
  %t166 = load ptr, ptr %l0, !tbaa !29
  store ptr %t166, ptr %l77, !tbaa !29
  %t167 = load ptr, ptr %l3, !tbaa !29
  %t168 = load i32, ptr %l8, !tbaa !23
  %t171 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t167, i32 %t168)
  store i32 %t171, ptr %l80
  br label %bb32
bb32:
  %t172 = load i32, ptr %l2, !tbaa !23
  %t173 = load ptr, ptr %l77, !tbaa !29
  %t174 = load i32, ptr %l80, !tbaa !23
  %t176 = call { { i64, ptr }, i64 } @compiler_2femit_2ecompiler_2femit_3afnEm_2econstGlobal(ptr %v0, ptr %s2, ptr %s2, ptr %t173, i32 %t174, i32 %t172, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d180, i32 0, i32 1) })
  store { { i64, ptr }, i64 } %t176, ptr %l82
  br label %bb33
bb33:
  %t177 = load { { i64, ptr }, i64 }, ptr %l82
  store { { i64, ptr }, i64 } %t177, ptr %l11
  %t178 = getelementptr { { i64, ptr }, i64 }, ptr %l11, i32 0, i32 0
  %t179 = load { i64, ptr }, ptr %t178, !tbaa !27
  store { i64, ptr } %t179, ptr %l83, !tbaa !27
  %t180 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t180, 0
  store i64 %t181, ptr %l84, !tbaa !24
  %t182 = load i64, ptr %l84, !tbaa !24
  %t183 = mul i64 %t182, 1
  %t184 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t183)
  %t185 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t186 = insertvalue { i64, ptr } %t185, ptr %t184, 1
  store { i64, ptr } %t186, ptr %l85, !tbaa !27
  %t187 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !27
  %t189 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !27
  %t191 = load i64, ptr %l84, !tbaa !24
  %t192 = mul i64 %t191, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t188, ptr %t190, i64 %t192, i1 false)
  %t193 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t193, ptr %lp12
  %t194 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t195 = load ptr, ptr %lp12
  store { i64, ptr } %t194, ptr %t195, !tbaa !27
  %t196 = getelementptr { { i64, ptr }, i64 }, ptr %l11, i32 0, i32 1
  %t197 = load i64, ptr %t196, !tbaa !24
  store i64 %t197, ptr %l13, !tbaa !24
  %t199 = load ptr, ptr %l3, !tbaa !29
  %t200 = load i32, ptr %l6, !tbaa !23
  %t203 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t199, i32 %t200)
  store i1 %t203, ptr %l89
  br label %bb34
bb34:
  %t204 = load i1, ptr %l89, !tbaa !21
  br i1 %t204, label %bb35, label %bb36
bb35:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load i32, ptr %l8, !tbaa !23
  %t209 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixed(ptr %v0, ptr %t205, i32 %t206)
  store i1 %t209, ptr %l93
  br label %bb37
bb36:
  store i1 false, ptr %l90, !tbaa !21
  br label %bb38
bb37:
  %t210 = load i1, ptr %l93, !tbaa !21
  store i1 %t210, ptr %l90, !tbaa !21
  br label %bb38
bb38:
  %t211 = load i1, ptr %l90, !tbaa !21
  br i1 %t211, label %bb39, label %bb40
bb39:
  %t212 = load ptr, ptr %lp12
  %t213 = load { i64, ptr }, ptr %t212, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  store { i64, ptr } %t213, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t215 = load i64, ptr %l13, !tbaa !24
  %t216 = load ptr, ptr %lp12
  %t217 = load { i64, ptr }, ptr %t216, !tbaa !27
  %t218 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d181, i32 0, i32 1) }, 1
  %t219 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d181, i32 0, i32 1) }, 0
  %t221 = call i64 @__olang_fmt_i64(ptr null, i64 %t215)
  %t222 = add i64 %t219, %t221
  %t223 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d182, i32 0, i32 1) }, 1
  %t224 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d182, i32 0, i32 1) }, 0
  %t225 = add i64 %t222, %t224
  %t227 = extractvalue { i64, ptr } %t217, 1
  %t228 = extractvalue { i64, ptr } %t217, 0
  %t229 = add i64 %t225, %t228
  %t230 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d183, i32 0, i32 1) }, 1
  %t231 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d183, i32 0, i32 1) }, 0
  %t232 = add i64 %t229, %t231
  %t233 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t232)
  call void @olang_textcopy(ptr %t233, ptr %t218, i64 %t219)
  %t234 = getelementptr i8, ptr %t233, i64 %t219
  %t235 = call i64 @__olang_fmt_i64(ptr %t234, i64 %t215)
  %t236 = getelementptr i8, ptr %t234, i64 %t221
  call void @olang_textcopy(ptr %t236, ptr %t223, i64 %t224)
  %t237 = getelementptr i8, ptr %t236, i64 %t224
  call void @olang_textcopy(ptr %t237, ptr %t227, i64 %t228)
  %t238 = getelementptr i8, ptr %t237, i64 %t228
  call void @olang_textcopy(ptr %t238, ptr %t230, i64 %t231)
  %t239 = insertvalue { i64, ptr } undef, i64 %t232, 0
  %t240 = insertvalue { i64, ptr } %t239, ptr %t233, 1
  call void @__olang_scope_close(ptr %s2)
  store { i64, ptr } %t240, ptr %rv
  br label %ret
bb42:
  call void @__olang_check_failed(ptr @olang_loc_3de177096d03f952_4b04555d717d3dfe)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ecopyArrayIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i32
  %l22 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l32 = alloca i64
  %l35 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l13, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t14 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %t10, i32 %a3)
  store i32 %t14, ptr %l16
  br label %bb1
bb1:
  %t15 = load ptr, ptr %l13, !tbaa !29
  %t16 = load i32, ptr %l16, !tbaa !23
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t17, ptr %l17
  br label %bb2
bb2:
  %t18 = load i32, ptr %l17, !tbaa !23
  store i32 %t18, ptr %l5, !tbaa !23
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t21 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d184, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d184, i32 0, i32 1) }, 0
  %t24 = extractvalue { i64, ptr } %t20, 1
  %t25 = extractvalue { i64, ptr } %t20, 0
  %t26 = add i64 %t22, %t25
  %t27 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d185, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d185, i32 0, i32 1) }, 0
  %t29 = add i64 %t26, %t28
  %t30 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t29)
  call void @olang_textcopy(ptr %t30, ptr %t21, i64 %t22)
  %t31 = getelementptr i8, ptr %t30, i64 %t22
  call void @olang_textcopy(ptr %t31, ptr %t24, i64 %t25)
  %t32 = getelementptr i8, ptr %t31, i64 %t25
  call void @olang_textcopy(ptr %t32, ptr %t27, i64 %t28)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t30, 1
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t37 = extractvalue { i64, ptr } %t34, 1
  %t38 = mul i64 %t36, 1
  %t39 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t38)
  call void @llvm.memcpy.p0.p0.i64(ptr %t39, ptr %t37, i64 %t38, i1 false)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  %t44 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t19, { i64, ptr } %t41)
  store { i64, ptr } %t44, ptr %l22
  br label %bb3
bb3:
  %t45 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t45, ptr %l6, !tbaa !27
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t48 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d186, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d186, i32 0, i32 1) }, 0
  %t51 = extractvalue { i64, ptr } %t47, 1
  %t52 = extractvalue { i64, ptr } %t47, 0
  %t53 = add i64 %t49, %t52
  %t54 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d187, i32 0, i32 1) }, 1
  %t55 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d187, i32 0, i32 1) }, 0
  %t56 = add i64 %t53, %t55
  %t57 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t48, i64 %t49)
  %t58 = getelementptr i8, ptr %t57, i64 %t49
  call void @olang_textcopy(ptr %t58, ptr %t51, i64 %t52)
  %t59 = getelementptr i8, ptr %t58, i64 %t52
  call void @olang_textcopy(ptr %t59, ptr %t54, i64 %t55)
  %t60 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t57, 1
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t64 = extractvalue { i64, ptr } %t61, 1
  %t65 = mul i64 %t63, 1
  %t66 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t65)
  call void @llvm.memcpy.p0.p0.i64(ptr %t66, ptr %t64, i64 %t65, i1 false)
  %t67 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  %t71 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t46, { i64, ptr } %t68)
  store { i64, ptr } %t71, ptr %l27
  br label %bb4
bb4:
  %t72 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t72, ptr %l7, !tbaa !27
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l28, !tbaa !29
  %t74 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t74, ptr %l29, !tbaa !27
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i32, ptr %l5, !tbaa !23
  %t79 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t75, i32 %t76)
  store i64 %t79, ptr %l32
  br label %bb5
bb5:
  %t80 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d188, i32 0, i32 1) }, 1
  %t81 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d188, i32 0, i32 1) }, 0
  %t82 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 1
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t85 = add i64 %t81, %t84
  %t86 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d189, i32 0, i32 1) }, 1
  %t87 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d189, i32 0, i32 1) }, 0
  %t88 = add i64 %t85, %t87
  %t89 = load i64, ptr %l32, !tbaa !24
  %t90 = call i64 @__olang_fmt_i64(ptr null, i64 %t89)
  %t91 = add i64 %t88, %t90
  %t92 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t91)
  call void @olang_textcopy(ptr %t92, ptr %t80, i64 %t81)
  %t93 = getelementptr i8, ptr %t92, i64 %t81
  call void @olang_textcopy(ptr %t93, ptr %t83, i64 %t84)
  %t94 = getelementptr i8, ptr %t93, i64 %t84
  call void @olang_textcopy(ptr %t94, ptr %t86, i64 %t87)
  %t95 = getelementptr i8, ptr %t94, i64 %t87
  %t96 = call i64 @__olang_fmt_i64(ptr %t95, i64 %t89)
  %t97 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t92, 1
  %t100 = extractvalue { i64, ptr } %t98, 0
  %t101 = extractvalue { i64, ptr } %t98, 1
  %t102 = mul i64 %t100, 1
  %t103 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t102)
  call void @llvm.memcpy.p0.p0.i64(ptr %t103, ptr %t101, i64 %t102, i1 false)
  %t104 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t103, 1
  %t106 = load ptr, ptr %l28, !tbaa !29
  %t108 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t106, { i64, ptr } %t105)
  store { i64, ptr } %t108, ptr %l35
  br label %bb6
bb6:
  %t109 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t109, ptr %l8, !tbaa !27
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t113 = load i32, ptr %l5, !tbaa !23
  %t118 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayStorage(ptr %v0, ptr %v1, ptr %s0, ptr %s0, ptr %t110, { i64, ptr } %a1, { i64, ptr } %t112, i32 %t113, i1 false)
  store { i64, ptr } %t118, ptr %l40
  br label %bb7
bb7:
  %t119 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t119, ptr %l9, !tbaa !27
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/emit:fnEm", ptr %t120, i32 0, i32 0
  %t123 = load ptr, ptr %t122, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t123, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d190, i32 0, i32 1) }, { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d191, i32 0, i32 1) })
  br label %bb8
bb8:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t127 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t128 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t129 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d192, i32 0, i32 1) }, 1
  %t130 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d192, i32 0, i32 1) }, 0
  %t132 = extractvalue { i64, ptr } %t126, 1
  %t133 = extractvalue { i64, ptr } %t126, 0
  %t134 = add i64 %t130, %t133
  %t135 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d193, i32 0, i32 1) }, 1
  %t136 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d193, i32 0, i32 1) }, 0
  %t137 = add i64 %t134, %t136
  %t139 = extractvalue { i64, ptr } %t127, 1
  %t140 = extractvalue { i64, ptr } %t127, 0
  %t141 = add i64 %t137, %t140
  %t142 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d194, i32 0, i32 1) }, 1
  %t143 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d194, i32 0, i32 1) }, 0
  %t144 = add i64 %t141, %t143
  %t146 = extractvalue { i64, ptr } %t128, 1
  %t147 = extractvalue { i64, ptr } %t128, 0
  %t148 = add i64 %t144, %t147
  %t149 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d195, i32 0, i32 1) }, 1
  %t150 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d195, i32 0, i32 1) }, 0
  %t151 = add i64 %t148, %t150
  %t152 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t151)
  call void @olang_textcopy(ptr %t152, ptr %t129, i64 %t130)
  %t153 = getelementptr i8, ptr %t152, i64 %t130
  call void @olang_textcopy(ptr %t153, ptr %t132, i64 %t133)
  %t154 = getelementptr i8, ptr %t153, i64 %t133
  call void @olang_textcopy(ptr %t154, ptr %t135, i64 %t136)
  %t155 = getelementptr i8, ptr %t154, i64 %t136
  call void @olang_textcopy(ptr %t155, ptr %t139, i64 %t140)
  %t156 = getelementptr i8, ptr %t155, i64 %t140
  call void @olang_textcopy(ptr %t156, ptr %t142, i64 %t143)
  %t157 = getelementptr i8, ptr %t156, i64 %t143
  call void @olang_textcopy(ptr %t157, ptr %t146, i64 %t147)
  %t158 = getelementptr i8, ptr %t157, i64 %t147
  call void @olang_textcopy(ptr %t158, ptr %t149, i64 %t150)
  %t159 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t152, 1
  %t162 = extractvalue { i64, ptr } %t160, 0
  %t163 = extractvalue { i64, ptr } %t160, 1
  %t164 = mul i64 %t162, 1
  %t165 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t164)
  call void @llvm.memcpy.p0.p0.i64(ptr %t165, ptr %t163, i64 %t164, i1 false)
  %t166 = insertvalue { i64, ptr } undef, i64 %t162, 0
  %t167 = insertvalue { i64, ptr } %t166, ptr %t165, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t125, { i64, ptr } %t167)
  br label %bb9
bb9:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t172 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t176 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epair(ptr %v0, ptr %s0, ptr %s0, ptr %v3, ptr %t170, { i64, ptr } %t171, { i64, ptr } %t172)
  store { i64, ptr } %t176, ptr %l52
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t177 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t177, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eexportBody(ptr %v0, ptr %v1, ptr %a0, { i64, [15 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [15 x i64] }
  %l3 = alloca i32
  %l4 = alloca { i64, [1 x i64] }
  %l5 = alloca %"compiler/mir:Range"
  %l6 = alloca %"compiler/mir:Range"
  %l7 = alloca { i64, [2 x i64] }
  %l9 = alloca { i64, [2 x i64] }
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca { i64, ptr }
  %l51 = alloca ptr
  %l54 = alloca ptr
  %l59 = alloca i64
  %l60 = alloca ptr
  %l63 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [15 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, [15 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [15 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 10
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d196, i32 0, i32 1) }, ptr %l14, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t8, ptr %l15, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l16, !tbaa !24
  %t11 = load i64, ptr %l16, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l17, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = load i64, ptr %l16, !tbaa !24
  %t21 = mul i64 %t20, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %t19, i64 %t21, i1 false)
  %t22 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t22, ptr %l15, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t23 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t23, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t24 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t25 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t24, i32 0, i32 0
  %t26 = load { i64, [2 x i64] }, ptr %t25
  %t28 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t29 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t28, i32 0, i32 1
  %t30 = load i32, ptr %t29
  store i32 %t30, ptr %l3, !tbaa !23
  %t32 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t33 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t32, i32 0, i32 2
  %t34 = load { i64, [1 x i64] }, ptr %t33
  store { i64, [1 x i64] } %t34, ptr %l4
  %t36 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t37 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t36, i32 0, i32 3
  %t38 = load %"compiler/mir:Range", ptr %t37
  store %"compiler/mir:Range" %t38, ptr %l5
  %t40 = getelementptr { i64, [15 x i64] }, ptr %l1, i32 0, i32 1
  %t41 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t40, i32 0, i32 4
  %t42 = load %"compiler/mir:Range", ptr %t41
  store %"compiler/mir:Range" %t42, ptr %l6
  store { i64, [2 x i64] } %t26, ptr %l7
  %t46 = load { i64, [2 x i64] }, ptr %l7
  %t48 = extractvalue { i64, [2 x i64] } %t46, 0
  %t49 = icmp eq i64 %t48, 0
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb4, label %bb5
bb4:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d197, i32 0, i32 1) }, ptr %l27, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t53, ptr %l28, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 0
  store i64 %t55, ptr %l29, !tbaa !24
  %t56 = load i64, ptr %l29, !tbaa !24
  %t57 = mul i64 %t56, 1
  %t58 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t57)
  %t59 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  store { i64, ptr } %t60, ptr %l30, !tbaa !27
  %t61 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = load i64, ptr %l29, !tbaa !24
  %t66 = mul i64 %t65, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t62, ptr %t64, i64 %t66, i1 false)
  %t67 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t67, ptr %l28, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t68 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t68, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t69 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t70 = getelementptr { i32 }, ptr %t69, i32 0, i32 0
  %t71 = load i32, ptr %t70
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/emit:fnEm", ptr %t73, i32 0, i32 0
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = getelementptr %"compiler/emit:Emitter", ptr %t76, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/lower:Lowerer", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t86 = sext i32 %t71 to i64
  %t89 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t82, i64 %t86)
  store ptr %t89, ptr %l39
  br label %bb7
bb7:
  %t90 = load ptr, ptr %l39, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Body", ptr %t90, i32 0, i32 1
  %t93 = load { i64, [2 x i64] }, ptr %t92
  store { i64, [2 x i64] } %t93, ptr %l9
  %t95 = load { i64, [2 x i64] }, ptr %l9
  %t97 = extractvalue { i64, [2 x i64] } %t95, 0
  %t98 = icmp eq i64 %t97, 0
  %t100 = xor i1 %t98, true
  br i1 %t100, label %bb8, label %bb9
bb8:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d198, i32 0, i32 1) }, ptr %l45, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t102, ptr %l46, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 0
  store i64 %t104, ptr %l47, !tbaa !24
  %t105 = load i64, ptr %l47, !tbaa !24
  %t106 = mul i64 %t105, 1
  %t107 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t106)
  %t108 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t107, 1
  store { i64, ptr } %t109, ptr %l48, !tbaa !27
  %t110 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = load i64, ptr %l47, !tbaa !24
  %t115 = mul i64 %t114, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t111, ptr %t113, i64 %t115, i1 false)
  %t116 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t116, ptr %l46, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t117 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t117, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t118 = getelementptr { i64, [2 x i64] }, ptr %l9, i32 0, i32 1
  %t119 = getelementptr { i64 }, ptr %t118, i32 0, i32 0
  %t120 = load i64, ptr %t119
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/emit:fnEm", ptr %t122, i32 0, i32 0
  %t125 = load ptr, ptr %t124, !tbaa !29
  store ptr %t125, ptr %l51, !tbaa !29
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/emit:fnEm", ptr %t126, i32 0, i32 0
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/emit:Emitter", ptr %t129, i32 0, i32 0
  %t132 = load ptr, ptr %t131, !tbaa !29
  store ptr %t132, ptr %l54, !tbaa !29
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/emit:fnEm", ptr %t133, i32 0, i32 0
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t138 = getelementptr %"compiler/emit:Emitter", ptr %t136, i32 0, i32 0
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t143 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t139, i64 %t120)
  store i64 %t143, ptr %l59
  br label %bb11
bb11:
  %t144 = load ptr, ptr %l54, !tbaa !29
  %t145 = load i64, ptr %l59, !tbaa !24
  %t146 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s0, ptr %t144, i64 %t145)
  store ptr %t146, ptr %l60
  br label %bb12
bb12:
  %t147 = load ptr, ptr %l60, !tbaa !29
  %t149 = getelementptr %"compiler/ast:Func", ptr %t147, i32 0, i32 2
  %t150 = load i32, ptr %t149, !tbaa !23
  %t151 = load ptr, ptr %l51, !tbaa !29
  %t153 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %s0, ptr %t151, i32 %t150)
  store { i64, ptr } %t153, ptr %l63
  br label %bb13
bb13:
  %t154 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t154, 1
  %t156 = extractvalue { i64, ptr } %t154, 0
  %t157 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t156)
  call void @olang_textcopy(ptr %t157, ptr %t155, i64 %t156)
  %t158 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t157, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t159, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eextend(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, ptr } %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l6 = alloca i32
  %l12 = alloca i32
  %l15 = alloca { i64, ptr }
  %l19 = alloca i1
  %l22 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t7, i32 %a2)
  store i32 %t13, ptr %l12
  br label %bb1
bb1:
  %t14 = load i32, ptr %l12, !tbaa !23
  store i32 %t14, ptr %l6, !tbaa !23
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l6, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s0, ptr %t15, i32 %t16)
  store { i64, ptr } %t19, ptr %l15
  br label %bb2
bb2:
  %t20 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 1
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t23 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t21, i64 %t22)
  %t24 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t36 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %v2, { i64, ptr } %t32, { i64, ptr } %t33)
  store i1 %t36, ptr %l19
  br label %bb3
bb3:
  %t37 = load i1, ptr %l19, !tbaa !21
  br i1 %t37, label %bb4, label %bb5
bb4:
  %t38 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 1
  %t41 = extractvalue { i64, ptr } %t38, 0
  %t42 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t41)
  call void @olang_textcopy(ptr %t42, ptr %t40, i64 %t41)
  %t43 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t44, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l22, !tbaa !29
  br i1 %a4, label %bb7, label %bb8
bb7:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d199, i32 0, i32 1) }, ptr %l24, !tbaa !27
  br label %bb9
bb8:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d200, i32 0, i32 1) }, ptr %l24, !tbaa !27
  br label %bb9
bb9:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i32, ptr %l6, !tbaa !23
  %t53 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s0, ptr %t49, i32 %t50)
  store { i64, ptr } %t53, ptr %l27
  br label %bb10
bb10:
  %t54 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t56, 1
  %t58 = extractvalue { i64, ptr } %t56, 0
  %t59 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 1
  %t61 = extractvalue { i64, ptr } %t59, 0
  %t62 = add i64 %t58, %t61
  %t63 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d201, i32 0, i32 1) }, 1
  %t64 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d201, i32 0, i32 1) }, 0
  %t65 = add i64 %t62, %t64
  %t67 = extractvalue { i64, ptr } %t54, 1
  %t68 = extractvalue { i64, ptr } %t54, 0
  %t69 = add i64 %t65, %t68
  %t70 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d202, i32 0, i32 1) }, 1
  %t71 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d202, i32 0, i32 1) }, 0
  %t72 = add i64 %t69, %t71
  %t74 = extractvalue { i64, ptr } %t55, 1
  %t75 = extractvalue { i64, ptr } %t55, 0
  %t76 = add i64 %t72, %t75
  %t77 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t76)
  call void @olang_textcopy(ptr %t77, ptr %t57, i64 %t58)
  %t78 = getelementptr i8, ptr %t77, i64 %t58
  call void @olang_textcopy(ptr %t78, ptr %t60, i64 %t61)
  %t79 = getelementptr i8, ptr %t78, i64 %t61
  call void @olang_textcopy(ptr %t79, ptr %t63, i64 %t64)
  %t80 = getelementptr i8, ptr %t79, i64 %t64
  call void @olang_textcopy(ptr %t80, ptr %t67, i64 %t68)
  %t81 = getelementptr i8, ptr %t80, i64 %t68
  call void @olang_textcopy(ptr %t81, ptr %t70, i64 %t71)
  %t82 = getelementptr i8, ptr %t81, i64 %t71
  call void @olang_textcopy(ptr %t82, ptr %t74, i64 %t75)
  %t83 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t77, 1
  %t86 = extractvalue { i64, ptr } %t84, 0
  %t87 = extractvalue { i64, ptr } %t84, 1
  %t88 = mul i64 %t86, 1
  %t89 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t88)
  call void @llvm.memcpy.p0.p0.i64(ptr %t89, ptr %t87, i64 %t88, i1 false)
  %t90 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  %t92 = load ptr, ptr %l22, !tbaa !29
  %t94 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v3, ptr %v3, ptr %t92, { i64, ptr } %t91)
  store { i64, ptr } %t94, ptr %l32
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t95 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t95, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2egenAlloc(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %lp7 = alloca ptr
  %lp9 = alloca ptr
  %l13 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i1
  %l30 = alloca i1
  %l33 = alloca i1
  %l35 = alloca i1
  %l41 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l47 = alloca i64
  %l50 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l73 = alloca i1
  %l74 = alloca i64
  %l75 = alloca ptr
  %l76 = alloca i64
  %l81 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ealign(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load i64, ptr %l13, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp sle i64 %t7, 8
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb4
bb3:
  %t11 = load i64, ptr %l3, !tbaa !24
  store i64 %t11, ptr %l16, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l16, !tbaa !24
  store i64 %t13, ptr %l4, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l2, !tbaa !23
  %t18 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2egenBytes(ptr %v0, ptr %t14, i32 %t15)
  store i64 %t18, ptr %l20
  br label %bb5
bb5:
  %t19 = load i64, ptr %l4, !tbaa !24
  %t20 = load i64, ptr %l20, !tbaa !24
  %t22 = add i64 %t20, %t19
  store i64 %t22, ptr %l5, !tbaa !24
  %t24 = load i64, ptr %l5, !tbaa !24
  %t26 = call i64 @compiler_2femit_2egenClass(i64 %t24)
  store i64 %t26, ptr %l24
  br label %bb6
bb6:
  %t27 = load i64, ptr %l24, !tbaa !24
  store i64 %t27, ptr %l6, !tbaa !24
  %t28 = load i64, ptr %l4, !tbaa !24
  %t30 = icmp eq i64 %t28, 8
  br i1 %t30, label %bb7, label %bb8
bb7:
  %t32 = load i64, ptr %l6, !tbaa !24
  %t34 = icmp sge i64 %t32, 0
  store i1 %t34, ptr %l27, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb9
bb9:
  %t36 = load i1, ptr %l27, !tbaa !21
  br i1 %t36, label %bb10, label %bb11
bb10:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load { i64, [1 x i64] }, ptr %l1
  %t41 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eisFrame(ptr %v0, ptr %t37, { i64, [1 x i64] } %t38)
  store i1 %t41, ptr %l33
  br label %bb12
bb11:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb13
bb12:
  %t42 = load i1, ptr %l33, !tbaa !21
  %t43 = xor i1 %t42, true
  store i1 %t43, ptr %l30, !tbaa !21
  br label %bb13
bb13:
  %t45 = load i1, ptr %l30, !tbaa !21
  br i1 %t45, label %bb14, label %bb15
bb14:
  %t46 = load { i64, [1 x i64] }, ptr %l1
  %t48 = extractvalue { i64, [1 x i64] } %t46, 0
  %t49 = icmp eq i64 %t48, 4
  %t51 = xor i1 %t49, true
  store i1 %t51, ptr %l35, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb16
bb16:
  %t53 = load i1, ptr %l35, !tbaa !21
  br i1 %t53, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s1
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/emit:fnEm", ptr %t54, i32 0, i32 0
  %t57 = load ptr, ptr %t56, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s1, ptr %t57, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d203, i32 0, i32 1) })
  br label %bb19
bb18:
  br label %bb24
bb19:
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l41, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load { i64, [1 x i64] }, ptr %l1
  %t64 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %s1, ptr %t60, { i64, [1 x i64] } %t61)
  store { i64, ptr } %t64, ptr %l44
  br label %bb20
bb20:
  %t65 = load i64, ptr %l6, !tbaa !24
  store i64 %t65, ptr %l45, !tbaa !24
  %t66 = load i64, ptr %l6, !tbaa !24
  %t68 = call i64 @compiler_2femit_2egenClassSize(i64 %t66)
  store i64 %t68, ptr %l47
  br label %bb21
bb21:
  %t69 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d204, i32 0, i32 1) }, 1
  %t70 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d204, i32 0, i32 1) }, 0
  %t71 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 1
  %t73 = extractvalue { i64, ptr } %t71, 0
  %t74 = add i64 %t70, %t73
  %t75 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d205, i32 0, i32 1) }, 1
  %t76 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d205, i32 0, i32 1) }, 0
  %t77 = add i64 %t74, %t76
  %t78 = load i64, ptr %l45, !tbaa !24
  %t79 = call i64 @__olang_fmt_i64(ptr null, i64 %t78)
  %t80 = add i64 %t77, %t79
  %t81 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d205, i32 0, i32 1) }, 1
  %t82 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d205, i32 0, i32 1) }, 0
  %t83 = add i64 %t80, %t82
  %t84 = load i64, ptr %l47, !tbaa !24
  %t85 = call i64 @__olang_fmt_i64(ptr null, i64 %t84)
  %t86 = add i64 %t83, %t85
  %t87 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d206, i32 0, i32 1) }, 1
  %t88 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d206, i32 0, i32 1) }, 0
  %t89 = add i64 %t86, %t88
  %t90 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t89)
  call void @olang_textcopy(ptr %t90, ptr %t69, i64 %t70)
  %t91 = getelementptr i8, ptr %t90, i64 %t70
  call void @olang_textcopy(ptr %t91, ptr %t72, i64 %t73)
  %t92 = getelementptr i8, ptr %t91, i64 %t73
  call void @olang_textcopy(ptr %t92, ptr %t75, i64 %t76)
  %t93 = getelementptr i8, ptr %t92, i64 %t76
  %t94 = call i64 @__olang_fmt_i64(ptr %t93, i64 %t78)
  %t95 = getelementptr i8, ptr %t93, i64 %t79
  call void @olang_textcopy(ptr %t95, ptr %t81, i64 %t82)
  %t96 = getelementptr i8, ptr %t95, i64 %t82
  %t97 = call i64 @__olang_fmt_i64(ptr %t96, i64 %t84)
  %t98 = getelementptr i8, ptr %t96, i64 %t85
  call void @olang_textcopy(ptr %t98, ptr %t87, i64 %t88)
  %t99 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t90, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = extractvalue { i64, ptr } %t100, 1
  %t104 = mul i64 %t102, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t104)
  call void @llvm.memcpy.p0.p0.i64(ptr %t105, ptr %t103, i64 %t104, i1 false)
  %t106 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  %t108 = load ptr, ptr %l41, !tbaa !29
  %t110 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t108, { i64, ptr } %t107)
  store { i64, ptr } %t110, ptr %l50
  br label %bb22
bb22:
  %t111 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t111, ptr %lp7
  %t112 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t113 = load ptr, ptr %lp7
  store { i64, ptr } %t112, ptr %t113, !tbaa !27
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load ptr, ptr %lp7
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  %t117 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eownWordsClear(ptr %v0, ptr %v1, ptr %t114, { i64, ptr } %t116, i32 %t117)
  br label %bb23
bb23:
  %t121 = load ptr, ptr %lp7
  %t122 = load { i64, ptr }, ptr %t121, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t122, ptr %rv
  br label %ret
bb24:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load { i64, [1 x i64] }, ptr %l1
  %t126 = load i64, ptr %l5, !tbaa !24
  %t128 = call i64 @__olang_fmt_i64(ptr null, i64 %t126)
  %t129 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t128)
  %t130 = call i64 @__olang_fmt_i64(ptr %t129, i64 %t126)
  %t131 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t129, 1
  %t134 = extractvalue { i64, ptr } %t132, 0
  %t135 = extractvalue { i64, ptr } %t132, 1
  %t136 = mul i64 %t134, 1
  %t137 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t136)
  call void @llvm.memcpy.p0.p0.i64(ptr %t137, ptr %t135, i64 %t136, i1 false)
  %t138 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t137, 1
  %t140 = load i64, ptr %l4, !tbaa !24
  %t141 = load i64, ptr %l5, !tbaa !24
  %t142 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d207, i32 0, i32 1) }, 1
  %t143 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d207, i32 0, i32 1) }, 0
  %t145 = call i64 @__olang_fmt_i64(ptr null, i64 %t141)
  %t146 = add i64 %t143, %t145
  %t147 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d208, i32 0, i32 1) }, 1
  %t148 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d208, i32 0, i32 1) }, 0
  %t149 = add i64 %t146, %t148
  %t150 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t149)
  call void @olang_textcopy(ptr %t150, ptr %t142, i64 %t143)
  %t151 = getelementptr i8, ptr %t150, i64 %t143
  %t152 = call i64 @__olang_fmt_i64(ptr %t151, i64 %t141)
  %t153 = getelementptr i8, ptr %t151, i64 %t145
  call void @olang_textcopy(ptr %t153, ptr %t147, i64 %t148)
  %t154 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t150, 1
  %t157 = extractvalue { i64, ptr } %t155, 0
  %t158 = extractvalue { i64, ptr } %t155, 1
  %t159 = mul i64 %t157, 1
  %t160 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t159)
  call void @llvm.memcpy.p0.p0.i64(ptr %t160, ptr %t158, i64 %t159, i1 false)
  %t161 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t160, 1
  %t168 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloc(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t124, { i64, [1 x i64] } %t125, { i64, ptr } %t139, i64 %t140, { i64, ptr } %t162)
  store { i64, ptr } %t168, ptr %l64
  br label %bb25
bb25:
  %t169 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = load i64, ptr %l4, !tbaa !24
  %t173 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d209, i32 0, i32 1) }, 1
  %t174 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d209, i32 0, i32 1) }, 0
  %t176 = extractvalue { i64, ptr } %t169, 1
  %t177 = extractvalue { i64, ptr } %t169, 0
  %t178 = add i64 %t174, %t177
  %t179 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d210, i32 0, i32 1) }, 1
  %t180 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d210, i32 0, i32 1) }, 0
  %t181 = add i64 %t178, %t180
  %t183 = call i64 @__olang_fmt_i64(ptr null, i64 %t172)
  %t184 = add i64 %t181, %t183
  %t185 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t184)
  call void @olang_textcopy(ptr %t185, ptr %t173, i64 %t174)
  %t186 = getelementptr i8, ptr %t185, i64 %t174
  call void @olang_textcopy(ptr %t186, ptr %t176, i64 %t177)
  %t187 = getelementptr i8, ptr %t186, i64 %t177
  call void @olang_textcopy(ptr %t187, ptr %t179, i64 %t180)
  %t188 = getelementptr i8, ptr %t187, i64 %t180
  %t189 = call i64 @__olang_fmt_i64(ptr %t188, i64 %t172)
  %t190 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t191 = insertvalue { i64, ptr } %t190, ptr %t185, 1
  %t193 = extractvalue { i64, ptr } %t191, 0
  %t194 = extractvalue { i64, ptr } %t191, 1
  %t195 = mul i64 %t193, 1
  %t196 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t195)
  call void @llvm.memcpy.p0.p0.i64(ptr %t196, ptr %t194, i64 %t195, i1 false)
  %t197 = insertvalue { i64, ptr } undef, i64 %t193, 0
  %t198 = insertvalue { i64, ptr } %t197, ptr %t196, 1
  %t201 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t170, { i64, ptr } %t198)
  store { i64, ptr } %t201, ptr %l70
  br label %bb26
bb26:
  %t202 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t202, ptr %lp9
  %t203 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t204 = load ptr, ptr %lp9
  store { i64, ptr } %t203, ptr %t204, !tbaa !27
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load { i64, [1 x i64] }, ptr %l1
  %t209 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eisFrame(ptr %v0, ptr %t205, { i64, [1 x i64] } %t206)
  store i1 %t209, ptr %l73
  br label %bb27
bb27:
  %t210 = load i1, ptr %l73, !tbaa !21
  br i1 %t210, label %bb28, label %bb29
bb28:
  store i64 196609, ptr %l74, !tbaa !24
  br label %bb30
bb29:
  store i64 1, ptr %l74, !tbaa !24
  br label %bb30
bb30:
  %t211 = load i64, ptr %l74, !tbaa !24
  %t212 = load ptr, ptr %l0, !tbaa !29
  store ptr %t212, ptr %l75, !tbaa !29
  store i64 %t211, ptr %l76, !tbaa !24
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load ptr, ptr %lp9
  %t216 = load { i64, ptr }, ptr %t215, !tbaa !27
  %t217 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d211, i32 0, i32 1) }, 1
  %t218 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d211, i32 0, i32 1) }, 0
  %t220 = extractvalue { i64, ptr } %t216, 1
  %t221 = extractvalue { i64, ptr } %t216, 0
  %t222 = add i64 %t218, %t221
  %t223 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d212, i32 0, i32 1) }, 1
  %t224 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d212, i32 0, i32 1) }, 0
  %t225 = add i64 %t222, %t224
  %t226 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t225)
  call void @olang_textcopy(ptr %t226, ptr %t217, i64 %t218)
  %t227 = getelementptr i8, ptr %t226, i64 %t218
  call void @olang_textcopy(ptr %t227, ptr %t220, i64 %t221)
  %t228 = getelementptr i8, ptr %t227, i64 %t221
  call void @olang_textcopy(ptr %t228, ptr %t223, i64 %t224)
  %t229 = insertvalue { i64, ptr } undef, i64 %t225, 0
  %t230 = insertvalue { i64, ptr } %t229, ptr %t226, 1
  %t232 = extractvalue { i64, ptr } %t230, 0
  %t233 = extractvalue { i64, ptr } %t230, 1
  %t234 = mul i64 %t232, 1
  %t235 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t234)
  call void @llvm.memcpy.p0.p0.i64(ptr %t235, ptr %t233, i64 %t234, i1 false)
  %t236 = insertvalue { i64, ptr } undef, i64 %t232, 0
  %t237 = insertvalue { i64, ptr } %t236, ptr %t235, 1
  %t240 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t214, { i64, ptr } %t237)
  store { i64, ptr } %t240, ptr %l81
  br label %bb31
bb31:
  %t241 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d213, i32 0, i32 1) }, 1
  %t242 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d213, i32 0, i32 1) }, 0
  %t243 = load i64, ptr %l76, !tbaa !24
  %t244 = call i64 @__olang_fmt_i64(ptr null, i64 %t243)
  %t245 = add i64 %t242, %t244
  %t246 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d214, i32 0, i32 1) }, 1
  %t247 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d214, i32 0, i32 1) }, 0
  %t248 = add i64 %t245, %t247
  %t249 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t250 = extractvalue { i64, ptr } %t249, 1
  %t251 = extractvalue { i64, ptr } %t249, 0
  %t252 = add i64 %t248, %t251
  %t253 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d215, i32 0, i32 1) }, 1
  %t254 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d215, i32 0, i32 1) }, 0
  %t255 = add i64 %t252, %t254
  %t256 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t255)
  call void @olang_textcopy(ptr %t256, ptr %t241, i64 %t242)
  %t257 = getelementptr i8, ptr %t256, i64 %t242
  %t258 = call i64 @__olang_fmt_i64(ptr %t257, i64 %t243)
  %t259 = getelementptr i8, ptr %t257, i64 %t244
  call void @olang_textcopy(ptr %t259, ptr %t246, i64 %t247)
  %t260 = getelementptr i8, ptr %t259, i64 %t247
  call void @olang_textcopy(ptr %t260, ptr %t250, i64 %t251)
  %t261 = getelementptr i8, ptr %t260, i64 %t251
  call void @olang_textcopy(ptr %t261, ptr %t253, i64 %t254)
  %t262 = insertvalue { i64, ptr } undef, i64 %t255, 0
  %t263 = insertvalue { i64, ptr } %t262, ptr %t256, 1
  %t265 = extractvalue { i64, ptr } %t263, 0
  %t266 = extractvalue { i64, ptr } %t263, 1
  %t267 = mul i64 %t265, 1
  %t268 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t267)
  call void @llvm.memcpy.p0.p0.i64(ptr %t268, ptr %t266, i64 %t267, i1 false)
  %t269 = insertvalue { i64, ptr } undef, i64 %t265, 0
  %t270 = insertvalue { i64, ptr } %t269, ptr %t268, 1
  %t271 = load ptr, ptr %l75, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t271, { i64, ptr } %t270)
  br label %bb32
bb32:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = load ptr, ptr %lp9
  %t275 = load { i64, ptr }, ptr %t274, !tbaa !27
  %t276 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eownWordsClear(ptr %v0, ptr %v1, ptr %t273, { i64, ptr } %t275, i32 %t276)
  br label %bb33
bb33:
  %t280 = load ptr, ptr %lp9
  %t281 = load { i64, ptr }, ptr %t280, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t281, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l10 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d216, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d216, i32 0, i32 1) }, 0
  %t8 = extractvalue { i64, ptr } %a1, 1
  %t9 = extractvalue { i64, ptr } %a1, 0
  %t10 = add i64 %t6, %t9
  %t11 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d217, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d217, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t15 = extractvalue { i64, ptr } %a2, 1
  %t16 = extractvalue { i64, ptr } %a2, 0
  %t17 = add i64 %t13, %t16
  %t19 = extractvalue { i64, ptr } %a3, 1
  %t20 = extractvalue { i64, ptr } %a3, 0
  %t21 = add i64 %t17, %t20
  %t22 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t21)
  call void @olang_textcopy(ptr %t22, ptr %t5, i64 %t6)
  %t23 = getelementptr i8, ptr %t22, i64 %t6
  call void @olang_textcopy(ptr %t23, ptr %t8, i64 %t9)
  %t24 = getelementptr i8, ptr %t23, i64 %t9
  call void @olang_textcopy(ptr %t24, ptr %t11, i64 %t12)
  %t25 = getelementptr i8, ptr %t24, i64 %t12
  call void @olang_textcopy(ptr %t25, ptr %t15, i64 %t16)
  %t26 = getelementptr i8, ptr %t25, i64 %t16
  call void @olang_textcopy(ptr %t26, ptr %t19, i64 %t20)
  %t27 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t22, 1
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t31 = extractvalue { i64, ptr } %t28, 1
  %t32 = mul i64 %t30, 1
  %t33 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t32)
  call void @llvm.memcpy.p0.p0.i64(ptr %t33, ptr %t31, i64 %t32, i1 false)
  %t34 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t33, 1
  %t38 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v4, ptr %v4, ptr %a0, { i64, ptr } %t35)
  store { i64, ptr } %t38, ptr %l10
  br label %bb1
bb1:
  %t39 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t39, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2ememmove(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t4, { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d218, i32 0, i32 1) }, { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d219, i32 0, i32 1) })
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t10 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d220, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d220, i32 0, i32 1) }, 0
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d221, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d221, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t20 = extractvalue { i64, ptr } %a2, 1
  %t21 = extractvalue { i64, ptr } %a2, 0
  %t22 = add i64 %t18, %t21
  %t23 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d222, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d222, i32 0, i32 1) }, 0
  %t25 = add i64 %t22, %t24
  %t27 = call i64 @__olang_fmt_i64(ptr null, i64 %a3)
  %t28 = add i64 %t25, %t27
  %t29 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d223, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d223, i32 0, i32 1) }, 0
  %t31 = add i64 %t28, %t30
  %t32 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t31)
  call void @olang_textcopy(ptr %t32, ptr %t10, i64 %t11)
  %t33 = getelementptr i8, ptr %t32, i64 %t11
  call void @olang_textcopy(ptr %t33, ptr %t13, i64 %t14)
  %t34 = getelementptr i8, ptr %t33, i64 %t14
  call void @olang_textcopy(ptr %t34, ptr %t16, i64 %t17)
  %t35 = getelementptr i8, ptr %t34, i64 %t17
  call void @olang_textcopy(ptr %t35, ptr %t20, i64 %t21)
  %t36 = getelementptr i8, ptr %t35, i64 %t21
  call void @olang_textcopy(ptr %t36, ptr %t23, i64 %t24)
  %t37 = getelementptr i8, ptr %t36, i64 %t24
  %t38 = call i64 @__olang_fmt_i64(ptr %t37, i64 %a3)
  %t39 = getelementptr i8, ptr %t37, i64 %t27
  call void @olang_textcopy(ptr %t39, ptr %t29, i64 %t30)
  %t40 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t32, 1
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t44 = extractvalue { i64, ptr } %t41, 1
  %t45 = mul i64 %t43, 1
  %t46 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t45)
  call void @llvm.memcpy.p0.p0.i64(ptr %t46, ptr %t44, i64 %t45, i1 false)
  %t47 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t6, { i64, ptr } %t48)
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eopaque16(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l6 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d224, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d224, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a1, 1
  %t7 = extractvalue { i64, ptr } %a1, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d225, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d225, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t11)
  call void @olang_textcopy(ptr %t12, ptr %t3, i64 %t4)
  %t13 = getelementptr i8, ptr %t12, i64 %t4
  call void @olang_textcopy(ptr %t13, ptr %t6, i64 %t7)
  %t14 = getelementptr i8, ptr %t13, i64 %t7
  call void @olang_textcopy(ptr %t14, ptr %t9, i64 %t10)
  %t15 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t12, 1
  %t18 = extractvalue { i64, ptr } %t16, 0
  %t19 = extractvalue { i64, ptr } %t16, 1
  %t20 = mul i64 %t18, 1
  %t21 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t20)
  call void @llvm.memcpy.p0.p0.i64(ptr %t21, ptr %t19, i64 %t20, i1 false)
  %t22 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  %t26 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v2, ptr %v2, ptr %a0, { i64, ptr } %t23)
  store { i64, ptr } %t26, ptr %l6
  br label %bb1
bb1:
  %t27 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t27, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eownWord(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l8 = alloca i64
  %l17 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store { i64, ptr } %a1, ptr %l5, !tbaa !27
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t7 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t3, i32 %a2)
  store i64 %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load i64, ptr %l8, !tbaa !24
  %t9 = add i64 %t8, 7
  %t11 = sdiv i64 %t9, 8
  %t13 = mul i64 %t11, 8
  %t16 = mul i64 8, %a3
  %t19 = add i64 %t13, %t16
  %t20 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d226, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d226, i32 0, i32 1) }, 0
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 1
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t25 = add i64 %t21, %t24
  %t26 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d227, i32 0, i32 1) }, 1
  %t27 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d227, i32 0, i32 1) }, 0
  %t28 = add i64 %t25, %t27
  %t30 = call i64 @__olang_fmt_i64(ptr null, i64 %t19)
  %t31 = add i64 %t28, %t30
  %t32 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t31)
  call void @olang_textcopy(ptr %t32, ptr %t20, i64 %t21)
  %t33 = getelementptr i8, ptr %t32, i64 %t21
  call void @olang_textcopy(ptr %t33, ptr %t23, i64 %t24)
  %t34 = getelementptr i8, ptr %t33, i64 %t24
  call void @olang_textcopy(ptr %t34, ptr %t26, i64 %t27)
  %t35 = getelementptr i8, ptr %t34, i64 %t27
  %t36 = call i64 @__olang_fmt_i64(ptr %t35, i64 %t19)
  %t37 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t32, 1
  %t40 = extractvalue { i64, ptr } %t38, 0
  %t41 = extractvalue { i64, ptr } %t38, 1
  %t42 = mul i64 %t40, 1
  %t43 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t42)
  call void @llvm.memcpy.p0.p0.i64(ptr %t43, ptr %t41, i64 %t42, i1 false)
  %t44 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  %t46 = load ptr, ptr %l4, !tbaa !29
  %t48 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v2, ptr %v2, ptr %t46, { i64, ptr } %t45)
  store { i64, ptr } %t48, ptr %l17
  br label %bb2
bb2:
  %t49 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t49, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2epackedInto(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %a1, i32 %a2, { i64, [15 x i64] } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, [15 x i64] }
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/mir:Range"
  %l8 = alloca i32
  %l9 = alloca %"compiler/mir:Range"
  %l10 = alloca { i64, [4 x i64] }
  %l11 = alloca { i64, [4 x i64] }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i64
  %l16 = alloca { { i64, ptr }, i32 }
  %l17 = alloca { i64, ptr }
  %l23 = alloca i32
  %l26 = alloca i1
  %l28 = alloca i1
  %l31 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l46 = alloca i64
  %l58 = alloca { i64, [4 x i64] }
  %l61 = alloca { i64, [4 x i64] }
  %l62 = alloca i64
  %l67 = alloca ptr
  %l70 = alloca i32
  %l71 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l77 = alloca i64
  %l78 = alloca ptr
  %l82 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l86 = alloca i64
  %l87 = alloca i64
  %l90 = alloca { i64, ptr }
  %l92 = alloca i64
  %l93 = alloca i64
  %l94 = alloca ptr
  %l95 = alloca ptr
  %l98 = alloca { i64, [4 x i64] }
  %l100 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  %l108 = alloca i64
  %l113 = alloca { { i64, ptr }, i32 }
  %l115 = alloca ptr
  %l118 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, [15 x i64] } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t9, i32 %a2)
  store i32 %t13, ptr %l23
  br label %bb1
bb1:
  %t14 = load i32, ptr %l23, !tbaa !23
  store i32 %t14, ptr %l5, !tbaa !23
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t16 = load i32, ptr %l5, !tbaa !23
  %t19 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePacked(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l26
  br label %bb2
bb2:
  %t20 = load i1, ptr %l26, !tbaa !21
  %t21 = xor i1 %t20, true
  br i1 %t21, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb6
bb4:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l5, !tbaa !23
  %t27 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t23, i32 %t24)
  store i64 %t27, ptr %l31
  br label %bb5
bb5:
  %t28 = load i64, ptr %l31, !tbaa !24
  %t29 = icmp eq i64 %t28, 0
  store i1 %t29, ptr %l28, !tbaa !21
  br label %bb6
bb6:
  %t31 = load i1, ptr %l28, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d228, i32 0, i32 1) }, ptr %l34, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t33, ptr %l35, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  store i64 %t35, ptr %l36, !tbaa !24
  %t36 = load i64, ptr %l36, !tbaa !24
  %t37 = mul i64 %t36, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t37)
  %t39 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  store { i64, ptr } %t40, ptr %l37, !tbaa !27
  %t41 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = load i64, ptr %l36, !tbaa !24
  %t46 = mul i64 %t45, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t42, ptr %t44, i64 %t46, i1 false)
  %t47 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t47, ptr %l6, !tbaa !27
  %t48 = load { i64, [15 x i64] }, ptr %l3
  %t50 = extractvalue { i64, [15 x i64] } %t48, 0
  %t51 = icmp eq i64 %t50, 6
  br i1 %t51, label %bb10, label %bb11
bb10:
  %t53 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t54 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t53, i32 0, i32 2
  %t55 = load %"compiler/mir:Range", ptr %t54
  store %"compiler/mir:Range" %t55, ptr %l7
  br label %bb12
bb11:
  br label %bb17
bb12:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load i32, ptr %l5, !tbaa !23
  %t59 = load %"compiler/mir:Range", ptr %l7
  %t63 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epackedMake(ptr %v0, ptr %s0, ptr %t57, i32 %t58, %"compiler/mir:Range" %t59)
  store { i64, ptr } %t63, ptr %l44
  br label %bb13
bb13:
  %t64 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  %t66 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  store i64 %t67, ptr %l46, !tbaa !24
  %t69 = load i64, ptr %l46, !tbaa !24
  %t70 = icmp eq i64 %t65, %t69
  br i1 %t70, label %bb14, label %bb15
bb14:
  %t72 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = load i64, ptr %l46, !tbaa !24
  %t77 = mul i64 %t76, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t73, ptr %t75, i64 %t77, i1 false)
  br label %bb16
bb15:
  %t78 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t78, ptr %l6, !tbaa !27
  br label %bb16
bb16:
  br label %bb53
bb17:
  %t79 = load { i64, [15 x i64] }, ptr %l3
  %t81 = extractvalue { i64, [15 x i64] } %t79, 0
  %t82 = icmp eq i64 %t81, 3
  br i1 %t82, label %bb18, label %bb19
bb18:
  %t84 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t85 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t84, i32 0, i32 0
  %t86 = load i32, ptr %t85, !range !{i32 0, i32 52}
  store i32 %t86, ptr %l8
  %t88 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t89 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t88, i32 0, i32 2
  %t90 = load %"compiler/mir:Range", ptr %t89
  store %"compiler/mir:Range" %t90, ptr %l9
  br label %bb20
bb19:
  br label %bb48
bb20:
  store %olang.scope zeroinitializer, ptr %s3
  %t92 = load i32, ptr %l8, !range !{i32 0, i32 52}
  %t94 = trunc i64 41 to i32
  %t95 = icmp eq i32 %t92, %t94
  %t97 = xor i1 %t95, true
  br i1 %t97, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load %"compiler/mir:Range", ptr %l9
  %t104 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t100, %"compiler/mir:Range" %t101, i64 0)
  store { i64, [4 x i64] } %t104, ptr %l58
  br label %bb24
bb24:
  %t105 = load { i64, [4 x i64] }, ptr %l58
  store { i64, [4 x i64] } %t105, ptr %l10
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load %"compiler/mir:Range", ptr %l9
  %t110 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t106, %"compiler/mir:Range" %t107, i64 1)
  store { i64, [4 x i64] } %t110, ptr %l61
  br label %bb25
bb25:
  %t111 = load { i64, [4 x i64] }, ptr %l61
  store { i64, [4 x i64] } %t111, ptr %l11
  %t112 = load { i64, [4 x i64] }, ptr %l11
  %t114 = extractvalue { i64, [4 x i64] } %t112, 0
  %t115 = icmp eq i64 %t114, 2
  br i1 %t115, label %bb26, label %bb27
bb26:
  %t117 = getelementptr { i64, [4 x i64] }, ptr %l11, i32 0, i32 1
  %t118 = getelementptr { i32, i64 }, ptr %t117, i32 0, i32 1
  %t119 = load i64, ptr %t118
  store i64 %t119, ptr %l12, !tbaa !24
  br label %bb28
bb27:
  br label %bb29
bb28:
  %t121 = load i64, ptr %l12, !tbaa !24
  store i64 %t121, ptr %l62, !tbaa !24
  br label %bb34
bb29:
  br i1 true, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_44ed23dda5502268_7ffab923032619a4)
  unreachable
bb34:
  %t123 = load i64, ptr %l62, !tbaa !24
  store i64 %t123, ptr %l13, !tbaa !24
  %t124 = load ptr, ptr %l4, !tbaa !29
  store ptr %t124, ptr %l67, !tbaa !29
  %t125 = load ptr, ptr %l4, !tbaa !29
  %t126 = load i32, ptr %l5, !tbaa !23
  %t129 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t125, i32 %t126)
  store i32 %t129, ptr %l70
  br label %bb35
bb35:
  %t130 = load ptr, ptr %l67, !tbaa !29
  %t131 = load i32, ptr %l70, !tbaa !23
  %t132 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s3, ptr %t130, i32 %t131)
  store { i64, ptr } %t132, ptr %l71
  br label %bb36
bb36:
  %t133 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t133, ptr %l72, !tbaa !27
  %t134 = load i64, ptr %l13, !tbaa !24
  %t136 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = getelementptr i32, ptr %t137, i64 %t134
  %t139 = load i32, ptr %t138, !tbaa !33
  store i32 %t139, ptr %l14, !tbaa !23
  %t141 = load ptr, ptr %l4, !tbaa !29
  %t142 = load i32, ptr %l14, !tbaa !23
  %t145 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePackedBits(ptr %v0, ptr %t141, i32 %t142)
  store i64 %t145, ptr %l77
  br label %bb37
bb37:
  %t146 = load i64, ptr %l77, !tbaa !24
  store i64 %t146, ptr %l15, !tbaa !24
  %t147 = load ptr, ptr %l0, !tbaa !29
  store ptr %t147, ptr %l78, !tbaa !29
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load { i64, [4 x i64] }, ptr %l10
  %t150 = load i32, ptr %l5, !tbaa !23
  %t154 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epackedBits(ptr %v0, ptr %s0, ptr %t148, { i64, [4 x i64] } %t149, i32 %t150)
  store { i64, ptr } %t154, ptr %l82
  br label %bb38
bb38:
  %t155 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t155, 0
  %t157 = extractvalue { i64, ptr } %t155, 1
  %t158 = mul i64 %t156, 1
  %t159 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t158)
  call void @llvm.memcpy.p0.p0.i64(ptr %t159, ptr %t157, i64 %t158, i1 false)
  %t160 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t161 = insertvalue { i64, ptr } %t160, ptr %t159, 1
  store { i64, ptr } %t161, ptr %l83, !tbaa !27
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load i32, ptr %l5, !tbaa !23
  %t166 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t162, i32 %t163)
  store i64 %t166, ptr %l86
  br label %bb39
bb39:
  %t167 = load i64, ptr %l86, !tbaa !24
  %t168 = mul i64 8, %t167
  store i64 %t168, ptr %l87, !tbaa !24
  %t169 = load ptr, ptr %l4, !tbaa !29
  %t170 = load i32, ptr %l5, !tbaa !23
  %t173 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBitOffsets(ptr %v0, ptr %s3, ptr %t169, i32 %t170)
  store { i64, ptr } %t173, ptr %l90
  br label %bb40
bb40:
  %t174 = load i64, ptr %l13, !tbaa !24
  %t176 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr i64, ptr %t177, i64 %t174
  %t179 = load i64, ptr %t178, !tbaa !34
  store i64 %t179, ptr %l92, !tbaa !24
  %t180 = load i64, ptr %l15, !tbaa !24
  store i64 %t180, ptr %l93, !tbaa !24
  %t181 = load ptr, ptr %l0, !tbaa !29
  store ptr %t181, ptr %l94, !tbaa !29
  %t182 = load ptr, ptr %l0, !tbaa !29
  store ptr %t182, ptr %l95, !tbaa !29
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load %"compiler/mir:Range", ptr %l9
  %t187 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t183, %"compiler/mir:Range" %t184, i64 2)
  store { i64, [4 x i64] } %t187, ptr %l98
  br label %bb41
bb41:
  %t188 = load i32, ptr %l14, !tbaa !23
  %t189 = load ptr, ptr %l95, !tbaa !29
  %t190 = load { i64, [4 x i64] }, ptr %l98
  %t192 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s0, ptr %t189, { i64, [4 x i64] } %t190, i32 %t188)
  store { i64, ptr } %t192, ptr %l100
  br label %bb42
bb42:
  %t193 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t194 = extractvalue { i64, ptr } %t193, 0
  %t195 = extractvalue { i64, ptr } %t193, 1
  %t196 = mul i64 %t194, 1
  %t197 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t196)
  call void @llvm.memcpy.p0.p0.i64(ptr %t197, ptr %t195, i64 %t196, i1 false)
  %t198 = insertvalue { i64, ptr } undef, i64 %t194, 0
  %t199 = insertvalue { i64, ptr } %t198, ptr %t197, 1
  %t200 = load i32, ptr %l14, !tbaa !23
  %t201 = load i64, ptr %l15, !tbaa !24
  %t202 = load ptr, ptr %l94, !tbaa !29
  %t206 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2etoBits(ptr %v0, ptr %s0, ptr %s0, ptr %t202, { i64, ptr } %t199, i32 %t200, i64 %t201)
  store { i64, ptr } %t206, ptr %l104
  br label %bb43
bb43:
  %t207 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t207, 0
  %t209 = extractvalue { i64, ptr } %t207, 1
  %t210 = mul i64 %t208, 1
  %t211 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t210)
  call void @llvm.memcpy.p0.p0.i64(ptr %t211, ptr %t209, i64 %t210, i1 false)
  %t212 = insertvalue { i64, ptr } undef, i64 %t208, 0
  %t213 = insertvalue { i64, ptr } %t212, ptr %t211, 1
  %t214 = load ptr, ptr %l78, !tbaa !29
  %t215 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t216 = load i64, ptr %l87, !tbaa !24
  %t217 = load i64, ptr %l92, !tbaa !24
  %t218 = load i64, ptr %l93, !tbaa !24
  %t220 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eplaceBits(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t214, { i64, ptr } %t215, i64 %t216, i64 %t217, i64 %t218, { i64, ptr } %t213)
  store { i64, ptr } %t220, ptr %l106
  br label %bb44
bb44:
  %t221 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t222 = extractvalue { i64, ptr } %t221, 0
  %t223 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t224 = extractvalue { i64, ptr } %t223, 0
  store i64 %t224, ptr %l108, !tbaa !24
  %t226 = load i64, ptr %l108, !tbaa !24
  %t227 = icmp eq i64 %t222, %t226
  br i1 %t227, label %bb45, label %bb46
bb45:
  %t229 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t230 = load ptr, ptr %t229, !tbaa !27
  %t231 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !27
  %t233 = load i64, ptr %l108, !tbaa !24
  %t234 = mul i64 %t233, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t230, ptr %t232, i64 %t234, i1 false)
  br label %bb47
bb46:
  %t235 = load { i64, ptr }, ptr %l106, !tbaa !27
  store { i64, ptr } %t235, ptr %l6, !tbaa !27
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s3)
  br label %bb53
bb48:
  br i1 true, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb52:
  call void @__olang_check_failed(ptr @olang_loc_745b41379bd01239_c904106b8ad08895)
  unreachable
bb53:
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t241 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s0, ptr %t237, %"compiler/mir:Lvalue" %a1)
  store { { i64, ptr }, i32 } %t241, ptr %l113
  br label %bb54
bb54:
  %t242 = load { { i64, ptr }, i32 }, ptr %l113
  store { { i64, ptr }, i32 } %t242, ptr %l16
  %t243 = getelementptr { { i64, ptr }, i32 }, ptr %l16, i32 0, i32 0
  %t244 = load { i64, ptr }, ptr %t243, !tbaa !27
  store { i64, ptr } %t244, ptr %l17, !tbaa !27
  %t246 = load ptr, ptr %l0, !tbaa !29
  store ptr %t246, ptr %l115, !tbaa !29
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load i32, ptr %l5, !tbaa !23
  %t251 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t247, i32 %t248)
  store i64 %t251, ptr %l118
  br label %bb55
bb55:
  %t252 = load i64, ptr %l118, !tbaa !24
  %t253 = mul i64 8, %t252
  %t254 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d229, i32 0, i32 1) }, 1
  %t255 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d229, i32 0, i32 1) }, 0
  %t257 = call i64 @__olang_fmt_i64(ptr null, i64 %t253)
  %t258 = add i64 %t255, %t257
  %t259 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t258)
  call void @olang_textcopy(ptr %t259, ptr %t254, i64 %t255)
  %t260 = getelementptr i8, ptr %t259, i64 %t255
  %t261 = call i64 @__olang_fmt_i64(ptr %t260, i64 %t253)
  %t262 = insertvalue { i64, ptr } undef, i64 %t258, 0
  %t263 = insertvalue { i64, ptr } %t262, ptr %t259, 1
  %t265 = extractvalue { i64, ptr } %t263, 0
  %t266 = extractvalue { i64, ptr } %t263, 1
  %t267 = mul i64 %t265, 1
  %t268 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t267)
  call void @llvm.memcpy.p0.p0.i64(ptr %t268, ptr %t266, i64 %t267, i1 false)
  %t269 = insertvalue { i64, ptr } undef, i64 %t265, 0
  %t270 = insertvalue { i64, ptr } %t269, ptr %t268, 1
  %t271 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t272 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t273 = load ptr, ptr %l115, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t273, { i64, ptr } %t270, { i64, ptr } %t271, { i64, ptr } %t272, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d230, i32 0, i32 1) })
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eparts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, %"compiler/mir:Range" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %lp5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l25 = alloca i64
  %l28 = alloca i64
  %l46 = alloca ptr
  %l50 = alloca { i64, [4 x i64] }
  %l51 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l69 = alloca i64
  %l76 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l78 = alloca i64
  %l79 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s0, ptr %t1, i32 %a1)
  store { i64, ptr } %t5, ptr %l15
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t6, ptr %l4, !tbaa !27
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d231, i32 0, i32 1) }, ptr %l16, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t7, ptr %l17, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l18, !tbaa !24
  %t10 = load i64, ptr %l18, !tbaa !24
  %t11 = mul i64 %t10, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l19, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l18, !tbaa !24
  %t20 = mul i64 %t19, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %t18, i64 %t20, i1 false)
  %t21 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t21, ptr %lp5
  %t22 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t23 = load ptr, ptr %lp5
  store { i64, ptr } %t22, ptr %t23, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t24 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  store i64 %t26, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t28 = load i64, ptr %l7, !tbaa !24
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = icmp sgt i64 %t28, %t29
  br i1 %t32, label %bb2, label %bb3
bb2:
  %t34 = load i64, ptr %l8, !tbaa !24
  %t36 = icmp sgt i64 %t34, 0
  br i1 %t36, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb7
bb4:
  %t38 = load i64, ptr %l7, !tbaa !24
  %t39 = load i64, ptr %l6, !tbaa !24
  %t42 = sub i64 %t38, %t39
  %t43 = load i64, ptr %l8, !tbaa !24
  %t46 = add i64 %t42, %t43
  %t48 = sub i64 %t46, 1
  %t49 = load i64, ptr %l8, !tbaa !24
  %t52 = sdiv i64 %t48, %t49
  store i64 %t52, ptr %l28, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb6
bb6:
  %t54 = load i64, ptr %l28, !tbaa !24
  store i64 %t54, ptr %l25, !tbaa !24
  br label %bb7
bb7:
  %t55 = load i64, ptr %l25, !tbaa !24
  store i64 %t55, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t56 = load i64, ptr %l10, !tbaa !24
  %t57 = load i64, ptr %l9, !tbaa !24
  %t60 = icmp slt i64 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb10:
  br label %bb11
bb11:
  %t64 = load i64, ptr %l6, !tbaa !24
  %t65 = load i64, ptr %l10, !tbaa !24
  %t66 = load i64, ptr %l8, !tbaa !24
  %t69 = mul i64 %t65, %t66
  %t72 = add i64 %t64, %t69
  store i64 %t72, ptr %l11, !tbaa !24
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l46, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = load i64, ptr %l11, !tbaa !24
  %t81 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t75, %"compiler/mir:Range" %a3, i64 %t77)
  store { i64, [4 x i64] } %t81, ptr %l50
  br label %bb12
bb12:
  %t82 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t82, ptr %l51, !tbaa !27
  %t83 = load i64, ptr %l11, !tbaa !24
  %t85 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr i32, ptr %t86, i64 %t83
  %t88 = load i32, ptr %t87, !tbaa !33
  %t89 = load ptr, ptr %l46, !tbaa !29
  %t90 = load { i64, [4 x i64] }, ptr %l50
  %t92 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s2, ptr %t89, { i64, [4 x i64] } %t90, i32 %t88)
  store { i64, ptr } %t92, ptr %l54
  br label %bb13
bb13:
  %t93 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t93, ptr %l12, !tbaa !27
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l55, !tbaa !29
  %t95 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t95, ptr %l56, !tbaa !27
  %t96 = load ptr, ptr %lp5
  %t97 = load { i64, ptr }, ptr %t96, !tbaa !27
  store { i64, ptr } %t97, ptr %l57, !tbaa !27
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t99, ptr %l59, !tbaa !27
  %t100 = load i64, ptr %l11, !tbaa !24
  %t102 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr i32, ptr %t103, i64 %t100
  %t105 = load i32, ptr %t104, !tbaa !33
  %t108 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s2, ptr %t98, i32 %t105)
  store { i64, ptr } %t108, ptr %l62
  br label %bb14
bb14:
  %t109 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t110 = load i64, ptr %l11, !tbaa !24
  %t111 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d232, i32 0, i32 1) }, 1
  %t112 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d232, i32 0, i32 1) }, 0
  %t113 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 1
  %t115 = extractvalue { i64, ptr } %t113, 0
  %t116 = add i64 %t112, %t115
  %t117 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d233, i32 0, i32 1) }, 1
  %t118 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d233, i32 0, i32 1) }, 0
  %t119 = add i64 %t116, %t118
  %t120 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t120, 1
  %t122 = extractvalue { i64, ptr } %t120, 0
  %t123 = add i64 %t119, %t122
  %t124 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d234, i32 0, i32 1) }, 1
  %t125 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d234, i32 0, i32 1) }, 0
  %t126 = add i64 %t123, %t125
  %t127 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t127, 1
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t130 = add i64 %t126, %t129
  %t131 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d233, i32 0, i32 1) }, 1
  %t132 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d233, i32 0, i32 1) }, 0
  %t133 = add i64 %t130, %t132
  %t135 = extractvalue { i64, ptr } %t109, 1
  %t136 = extractvalue { i64, ptr } %t109, 0
  %t137 = add i64 %t133, %t136
  %t138 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d234, i32 0, i32 1) }, 1
  %t139 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d234, i32 0, i32 1) }, 0
  %t140 = add i64 %t137, %t139
  %t142 = call i64 @__olang_fmt_i64(ptr null, i64 %t110)
  %t143 = add i64 %t140, %t142
  %t144 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t143)
  call void @olang_textcopy(ptr %t144, ptr %t111, i64 %t112)
  %t145 = getelementptr i8, ptr %t144, i64 %t112
  call void @olang_textcopy(ptr %t145, ptr %t114, i64 %t115)
  %t146 = getelementptr i8, ptr %t145, i64 %t115
  call void @olang_textcopy(ptr %t146, ptr %t117, i64 %t118)
  %t147 = getelementptr i8, ptr %t146, i64 %t118
  call void @olang_textcopy(ptr %t147, ptr %t121, i64 %t122)
  %t148 = getelementptr i8, ptr %t147, i64 %t122
  call void @olang_textcopy(ptr %t148, ptr %t124, i64 %t125)
  %t149 = getelementptr i8, ptr %t148, i64 %t125
  call void @olang_textcopy(ptr %t149, ptr %t128, i64 %t129)
  %t150 = getelementptr i8, ptr %t149, i64 %t129
  call void @olang_textcopy(ptr %t150, ptr %t131, i64 %t132)
  %t151 = getelementptr i8, ptr %t150, i64 %t132
  call void @olang_textcopy(ptr %t151, ptr %t135, i64 %t136)
  %t152 = getelementptr i8, ptr %t151, i64 %t136
  call void @olang_textcopy(ptr %t152, ptr %t138, i64 %t139)
  %t153 = getelementptr i8, ptr %t152, i64 %t139
  %t154 = call i64 @__olang_fmt_i64(ptr %t153, i64 %t110)
  %t155 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t144, 1
  %t158 = extractvalue { i64, ptr } %t156, 0
  %t159 = extractvalue { i64, ptr } %t156, 1
  %t160 = mul i64 %t158, 1
  %t161 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t160)
  call void @llvm.memcpy.p0.p0.i64(ptr %t161, ptr %t159, i64 %t160, i1 false)
  %t162 = insertvalue { i64, ptr } undef, i64 %t158, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t161, 1
  %t164 = load ptr, ptr %l55, !tbaa !29
  %t166 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v2, ptr %v2, ptr %t164, { i64, ptr } %t163)
  store { i64, ptr } %t166, ptr %l67
  br label %bb15
bb15:
  %t167 = load ptr, ptr %lp5
  %t168 = load { i64, ptr }, ptr %t167, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t168, 0
  %t170 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t170, 0
  store i64 %t171, ptr %l69, !tbaa !24
  %t173 = load i64, ptr %l69, !tbaa !24
  %t174 = icmp eq i64 %t169, %t173
  br i1 %t174, label %bb16, label %bb17
bb16:
  %t176 = load ptr, ptr %lp5
  %t177 = getelementptr { i64, ptr }, ptr %t176, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !27
  %t181 = load i64, ptr %l69, !tbaa !24
  %t182 = mul i64 %t181, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t178, ptr %t180, i64 %t182, i1 false)
  br label %bb18
bb17:
  %t183 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t184 = load ptr, ptr %lp5
  store { i64, ptr } %t183, ptr %t184, !tbaa !27
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t185 = load i64, ptr %l10, !tbaa !24
  %t187 = add i64 %t185, 1
  store i64 %t187, ptr %l10, !tbaa !24
  br label %bb8
bb20:
  %t189 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t189, 0
  %t193 = icmp eq i64 %t191, 0
  br i1 %t193, label %bb21, label %bb22
bb21:
  store { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d235, i32 0, i32 1) }, ptr %l76, !tbaa !27
  %t195 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t195, ptr %l77, !tbaa !27
  %t196 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t197 = extractvalue { i64, ptr } %t196, 0
  store i64 %t197, ptr %l78, !tbaa !24
  %t198 = load i64, ptr %l78, !tbaa !24
  %t199 = mul i64 %t198, 1
  %t200 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t199)
  %t201 = insertvalue { i64, ptr } undef, i64 %t198, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t200, 1
  store { i64, ptr } %t202, ptr %l79, !tbaa !27
  %t203 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !27
  %t205 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !27
  %t207 = load i64, ptr %l78, !tbaa !24
  %t208 = mul i64 %t207, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t204, ptr %t206, i64 %t208, i1 false)
  %t209 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t209, ptr %l77, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t210 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t210, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t211 = load ptr, ptr %lp5
  %t212 = load { i64, ptr }, ptr %t211, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t212, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epartsResult(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/cabi:Way" %a1, i32 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/cabi:Way"
  %l2 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l22 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l37 = alloca i64
  %l39 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca [5 x i8]
  %l51 = alloca i64
  %l55 = alloca i64
  %l58 = alloca i64
  %l78 = alloca i64
  %l80 = alloca { i64, ptr }
  %l82 = alloca ptr
  %l83 = alloca { i64, ptr }
  %l86 = alloca i64
  %l89 = alloca { i64, ptr }
  %l90 = alloca i64
  %l91 = alloca { i64, ptr }
  %l92 = alloca ptr
  %l93 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  %l98 = alloca ptr
  %l101 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l109 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/cabi:Way" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l18, !tbaa !29
  %t11 = load i32, ptr %l2, !tbaa !23
  %t15 = call i64 @compiler_2fcabi_2eSpan(ptr %v0, ptr %v1, ptr %t7, ptr %l1, i32 %t11)
  store i64 %t15, ptr %l22
  br label %bb1
bb1:
  %t16 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d236, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d236, i32 0, i32 1) }, 0
  %t18 = load i64, ptr %l22, !tbaa !24
  %t19 = call i64 @__olang_fmt_i64(ptr null, i64 %t18)
  %t20 = add i64 %t17, %t19
  %t21 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d237, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d237, i32 0, i32 1) }, 0
  %t23 = add i64 %t20, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t16, i64 %t17)
  %t25 = getelementptr i8, ptr %t24, i64 %t17
  %t26 = call i64 @__olang_fmt_i64(ptr %t25, i64 %t18)
  %t27 = getelementptr i8, ptr %t25, i64 %t19
  call void @olang_textcopy(ptr %t27, ptr %t21, i64 %t22)
  %t28 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t24, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = extractvalue { i64, ptr } %t29, 1
  %t33 = mul i64 %t31, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t33)
  call void @llvm.memcpy.p0.p0.i64(ptr %t34, ptr %t32, i64 %t33, i1 false)
  %t35 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  %t37 = load ptr, ptr %l18, !tbaa !29
  %t39 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %s0, ptr %s0, ptr %t37, { i64, ptr } %t36, i64 8)
  store { i64, ptr } %t39, ptr %l25
  br label %bb2
bb2:
  %t40 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t40, ptr %l5, !tbaa !27
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l26, !tbaa !29
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/emit:fnEm", ptr %t42, i32 0, i32 0
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t46 = load i32, ptr %l2, !tbaa !23
  %t49 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s0, ptr %t45, i32 %t46)
  store { i64, ptr } %t49, ptr %l30
  br label %bb3
bb3:
  %t50 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t50, 0
  %t52 = extractvalue { i64, ptr } %t50, 1
  %t53 = mul i64 %t51, 1
  %t54 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t53)
  call void @llvm.memcpy.p0.p0.i64(ptr %t54, ptr %t52, i64 %t53, i1 false)
  %t55 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t54, 1
  %t58 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t59 = load ptr, ptr %l26, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %v2, ptr %s0, ptr %s0, ptr %t59, { i64, ptr } %t56, { i64, ptr } %a3, { i64, ptr } %t58, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d230, i32 0, i32 1) })
  br label %bb4
bb4:
  %t64 = call { i64, ptr } @compiler_2fcabi_2ePartsType(ptr %v1, ptr %s0, ptr %l1)
  store { i64, ptr } %t64, ptr %l35
  br label %bb5
bb5:
  %t65 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t65, ptr %l6, !tbaa !27
  %t66 = getelementptr %"compiler/cabi:Way", ptr %l1, i32 0, i32 1
  %t68 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v1, ptr %t66)
  store i64 %t68, ptr %l37
  br label %bb6
bb6:
  %t69 = load i64, ptr %l37, !tbaa !24
  %t70 = icmp eq i64 %t69, 1
  br i1 %t70, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t72 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t72, ptr %l39, !tbaa !27
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t79 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s0, ptr %s0, ptr %s2, ptr %s2, ptr %t73, { i64, ptr } %t74, { i64, ptr } %t75, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) })
  store { i64, ptr } %t79, ptr %l43
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t80 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 1
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t83 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d238, i32 0, i32 1) }, 1
  %t84 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d238, i32 0, i32 1) }, 0
  %t85 = add i64 %t82, %t84
  %t86 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = add i64 %t85, %t88
  %t90 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t89)
  call void @olang_textcopy(ptr %t90, ptr %t81, i64 %t82)
  %t91 = getelementptr i8, ptr %t90, i64 %t82
  call void @olang_textcopy(ptr %t91, ptr %t83, i64 %t84)
  %t92 = getelementptr i8, ptr %t91, i64 %t84
  call void @olang_textcopy(ptr %t92, ptr %t87, i64 %t88)
  %t93 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t90, 1
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t94, ptr %rv
  br label %ret
bb10:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d239, i32 0, i32 1) }, ptr %l45, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t96, ptr %l46, !tbaa !27
  %t97 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = mul i64 5, 1
  call void @llvm.memmove.p0.p0.i64(ptr %l47, ptr %t98, i64 %t99, i1 false)
  %t101 = insertvalue { i64, ptr } undef, i64 5, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %l47, 1
  store { i64, ptr } %t102, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t104 = getelementptr %"compiler/cabi:Way", ptr %l1, i32 0, i32 1
  %t106 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v1, ptr %t104)
  store i64 %t106, ptr %l51
  br label %bb11
bb11:
  %t107 = load i64, ptr %l51, !tbaa !24
  store i64 %t107, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t108 = load i64, ptr %l9, !tbaa !24
  %t109 = load i64, ptr %l8, !tbaa !24
  %t112 = icmp sgt i64 %t108, %t109
  br i1 %t112, label %bb12, label %bb13
bb12:
  %t114 = load i64, ptr %l10, !tbaa !24
  %t116 = icmp sgt i64 %t114, 0
  br i1 %t116, label %bb14, label %bb15
bb13:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb17
bb14:
  %t118 = load i64, ptr %l9, !tbaa !24
  %t119 = load i64, ptr %l8, !tbaa !24
  %t122 = sub i64 %t118, %t119
  %t123 = load i64, ptr %l10, !tbaa !24
  %t126 = add i64 %t122, %t123
  %t128 = sub i64 %t126, 1
  %t129 = load i64, ptr %l10, !tbaa !24
  %t132 = sdiv i64 %t128, %t129
  store i64 %t132, ptr %l58, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb16
bb16:
  %t134 = load i64, ptr %l58, !tbaa !24
  store i64 %t134, ptr %l55, !tbaa !24
  br label %bb17
bb17:
  %t135 = load i64, ptr %l55, !tbaa !24
  store i64 %t135, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s5
  %t136 = load i64, ptr %l12, !tbaa !24
  %t137 = load i64, ptr %l11, !tbaa !24
  %t140 = icmp slt i64 %t136, %t137
  %t142 = xor i1 %t140, true
  br i1 %t142, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb36
bb20:
  br label %bb21
bb21:
  %t144 = load i64, ptr %l8, !tbaa !24
  %t145 = load i64, ptr %l12, !tbaa !24
  %t146 = load i64, ptr %l10, !tbaa !24
  %t149 = mul i64 %t145, %t146
  %t152 = add i64 %t144, %t149
  store i64 %t152, ptr %l13, !tbaa !24
  %t154 = getelementptr %"compiler/cabi:Way", ptr %l1, i32 0, i32 2
  %t155 = load i64, ptr %l13, !tbaa !24
  %t158 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t154, i64 %t155)
  store i64 %t158, ptr %l78
  br label %bb22
bb22:
  %t159 = load i64, ptr %l78, !tbaa !24
  %t160 = icmp eq i64 %t159, 0
  br i1 %t160, label %bb23, label %bb24
bb23:
  %t162 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t162, ptr %l80, !tbaa !27
  br label %bb27
bb24:
  %t164 = load ptr, ptr %l0, !tbaa !29
  store ptr %t164, ptr %l82, !tbaa !29
  %t165 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t165, ptr %l83, !tbaa !27
  %t166 = getelementptr %"compiler/cabi:Way", ptr %l1, i32 0, i32 2
  %t167 = load i64, ptr %l13, !tbaa !24
  %t170 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t166, i64 %t167)
  store i64 %t170, ptr %l86
  br label %bb25
bb25:
  %t171 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d240, i32 0, i32 1) }, 1
  %t172 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d240, i32 0, i32 1) }, 0
  %t173 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t174 = extractvalue { i64, ptr } %t173, 1
  %t175 = extractvalue { i64, ptr } %t173, 0
  %t176 = add i64 %t172, %t175
  %t177 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d241, i32 0, i32 1) }, 1
  %t178 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d241, i32 0, i32 1) }, 0
  %t179 = add i64 %t176, %t178
  %t180 = load i64, ptr %l86, !tbaa !24
  %t181 = call i64 @__olang_fmt_i64(ptr null, i64 %t180)
  %t182 = add i64 %t179, %t181
  %t183 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t182)
  call void @olang_textcopy(ptr %t183, ptr %t171, i64 %t172)
  %t184 = getelementptr i8, ptr %t183, i64 %t172
  call void @olang_textcopy(ptr %t184, ptr %t174, i64 %t175)
  %t185 = getelementptr i8, ptr %t184, i64 %t175
  call void @olang_textcopy(ptr %t185, ptr %t177, i64 %t178)
  %t186 = getelementptr i8, ptr %t185, i64 %t178
  %t187 = call i64 @__olang_fmt_i64(ptr %t186, i64 %t180)
  %t188 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t183, 1
  %t191 = extractvalue { i64, ptr } %t189, 0
  %t192 = extractvalue { i64, ptr } %t189, 1
  %t193 = mul i64 %t191, 1
  %t194 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t193)
  call void @llvm.memcpy.p0.p0.i64(ptr %t194, ptr %t192, i64 %t193, i1 false)
  %t195 = insertvalue { i64, ptr } undef, i64 %t191, 0
  %t196 = insertvalue { i64, ptr } %t195, ptr %t194, 1
  %t197 = load ptr, ptr %l82, !tbaa !29
  %t199 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s5, ptr %s5, ptr %t197, { i64, ptr } %t196)
  store { i64, ptr } %t199, ptr %l89
  br label %bb26
bb26:
  %t200 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t200, ptr %l80, !tbaa !27
  br label %bb27
bb27:
  %t201 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t202 = extractvalue { i64, ptr } %t201, 0
  store i64 %t202, ptr %l90, !tbaa !24
  %t203 = load i64, ptr %l90, !tbaa !24
  %t204 = mul i64 %t203, 1
  %t205 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t204)
  %t206 = insertvalue { i64, ptr } undef, i64 %t203, 0
  %t207 = insertvalue { i64, ptr } %t206, ptr %t205, 1
  store { i64, ptr } %t207, ptr %l91, !tbaa !27
  %t208 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t211 = load ptr, ptr %t210, !tbaa !27
  %t212 = load i64, ptr %l90, !tbaa !24
  %t213 = mul i64 %t212, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t209, ptr %t211, i64 %t213, i1 false)
  %t214 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t214, ptr %l14, !tbaa !27
  %t215 = load ptr, ptr %l0, !tbaa !29
  store ptr %t215, ptr %l92, !tbaa !29
  %t216 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t216, ptr %l93, !tbaa !27
  %t217 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t217, ptr %l94, !tbaa !27
  %t218 = getelementptr %"compiler/cabi:Way", ptr %l1, i32 0, i32 1
  %t219 = load i64, ptr %l13, !tbaa !24
  %t222 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %s5, ptr %t218, i64 %t219)
  store { i64, ptr } %t222, ptr %l97
  br label %bb28
bb28:
  %t223 = load ptr, ptr %l0, !tbaa !29
  store ptr %t223, ptr %l98, !tbaa !29
  %t224 = getelementptr %"compiler/cabi:Way", ptr %l1, i32 0, i32 1
  %t225 = load i64, ptr %l13, !tbaa !24
  %t228 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t224, i64 %t225)
  store { i64, ptr } %t228, ptr %l101
  br label %bb29
bb29:
  %t229 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t230 = load ptr, ptr %l98, !tbaa !29
  %t231 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t233 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %v1, ptr %s5, ptr %s5, ptr %s5, ptr %t230, { i64, ptr } %t231, { i64, ptr } %t229, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) })
  store { i64, ptr } %t233, ptr %l103
  br label %bb30
bb30:
  %t234 = load i64, ptr %l13, !tbaa !24
  %t235 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d242, i32 0, i32 1) }, 1
  %t236 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d242, i32 0, i32 1) }, 0
  %t237 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t238 = extractvalue { i64, ptr } %t237, 1
  %t239 = extractvalue { i64, ptr } %t237, 0
  %t240 = add i64 %t236, %t239
  %t241 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d243, i32 0, i32 1) }, 1
  %t242 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d243, i32 0, i32 1) }, 0
  %t243 = add i64 %t240, %t242
  %t244 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t245 = extractvalue { i64, ptr } %t244, 1
  %t246 = extractvalue { i64, ptr } %t244, 0
  %t247 = add i64 %t243, %t246
  %t248 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d244, i32 0, i32 1) }, 1
  %t249 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d244, i32 0, i32 1) }, 0
  %t250 = add i64 %t247, %t249
  %t251 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t251, 1
  %t253 = extractvalue { i64, ptr } %t251, 0
  %t254 = add i64 %t250, %t253
  %t255 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d243, i32 0, i32 1) }, 1
  %t256 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d243, i32 0, i32 1) }, 0
  %t257 = add i64 %t254, %t256
  %t258 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t259 = extractvalue { i64, ptr } %t258, 1
  %t260 = extractvalue { i64, ptr } %t258, 0
  %t261 = add i64 %t257, %t260
  %t262 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d244, i32 0, i32 1) }, 1
  %t263 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d244, i32 0, i32 1) }, 0
  %t264 = add i64 %t261, %t263
  %t266 = call i64 @__olang_fmt_i64(ptr null, i64 %t234)
  %t267 = add i64 %t264, %t266
  %t268 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t267)
  call void @olang_textcopy(ptr %t268, ptr %t235, i64 %t236)
  %t269 = getelementptr i8, ptr %t268, i64 %t236
  call void @olang_textcopy(ptr %t269, ptr %t238, i64 %t239)
  %t270 = getelementptr i8, ptr %t269, i64 %t239
  call void @olang_textcopy(ptr %t270, ptr %t241, i64 %t242)
  %t271 = getelementptr i8, ptr %t270, i64 %t242
  call void @olang_textcopy(ptr %t271, ptr %t245, i64 %t246)
  %t272 = getelementptr i8, ptr %t271, i64 %t246
  call void @olang_textcopy(ptr %t272, ptr %t248, i64 %t249)
  %t273 = getelementptr i8, ptr %t272, i64 %t249
  call void @olang_textcopy(ptr %t273, ptr %t252, i64 %t253)
  %t274 = getelementptr i8, ptr %t273, i64 %t253
  call void @olang_textcopy(ptr %t274, ptr %t255, i64 %t256)
  %t275 = getelementptr i8, ptr %t274, i64 %t256
  call void @olang_textcopy(ptr %t275, ptr %t259, i64 %t260)
  %t276 = getelementptr i8, ptr %t275, i64 %t260
  call void @olang_textcopy(ptr %t276, ptr %t262, i64 %t263)
  %t277 = getelementptr i8, ptr %t276, i64 %t263
  %t278 = call i64 @__olang_fmt_i64(ptr %t277, i64 %t234)
  %t279 = insertvalue { i64, ptr } undef, i64 %t267, 0
  %t280 = insertvalue { i64, ptr } %t279, ptr %t268, 1
  %t282 = extractvalue { i64, ptr } %t280, 0
  %t283 = extractvalue { i64, ptr } %t280, 1
  %t284 = mul i64 %t282, 1
  %t285 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t284)
  call void @llvm.memcpy.p0.p0.i64(ptr %t285, ptr %t283, i64 %t284, i1 false)
  %t286 = insertvalue { i64, ptr } undef, i64 %t282, 0
  %t287 = insertvalue { i64, ptr } %t286, ptr %t285, 1
  %t288 = load ptr, ptr %l92, !tbaa !29
  %t290 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t288, { i64, ptr } %t287)
  store { i64, ptr } %t290, ptr %l107
  br label %bb31
bb31:
  %t291 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t292 = extractvalue { i64, ptr } %t291, 0
  %t293 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t294 = extractvalue { i64, ptr } %t293, 0
  store i64 %t294, ptr %l109, !tbaa !24
  %t296 = load i64, ptr %l109, !tbaa !24
  %t297 = icmp eq i64 %t292, %t296
  br i1 %t297, label %bb32, label %bb33
bb32:
  %t299 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t300 = load ptr, ptr %t299, !tbaa !27
  %t301 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t302 = load ptr, ptr %t301, !tbaa !27
  %t303 = load i64, ptr %l109, !tbaa !24
  %t304 = mul i64 %t303, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t300, ptr %t302, i64 %t304, i1 false)
  br label %bb34
bb33:
  %t305 = load { i64, ptr }, ptr %l107, !tbaa !27
  store { i64, ptr } %t305, ptr %l7, !tbaa !27
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s5)
  br label %bb35
bb35:
  %t306 = load i64, ptr %l12, !tbaa !24
  %t308 = add i64 %t306, 1
  store i64 %t308, ptr %l12, !tbaa !24
  br label %bb18
bb36:
  %t310 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t311 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t313 = extractvalue { i64, ptr } %t310, 1
  %t314 = extractvalue { i64, ptr } %t310, 0
  %t315 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d245, i32 0, i32 1) }, 1
  %t316 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d245, i32 0, i32 1) }, 0
  %t317 = add i64 %t314, %t316
  %t319 = extractvalue { i64, ptr } %t311, 1
  %t320 = extractvalue { i64, ptr } %t311, 0
  %t321 = add i64 %t317, %t320
  %t322 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t321)
  call void @olang_textcopy(ptr %t322, ptr %t313, i64 %t314)
  %t323 = getelementptr i8, ptr %t322, i64 %t314
  call void @olang_textcopy(ptr %t323, ptr %t315, i64 %t316)
  %t324 = getelementptr i8, ptr %t323, i64 %t316
  call void @olang_textcopy(ptr %t324, ptr %t319, i64 %t320)
  %t325 = insertvalue { i64, ptr } undef, i64 %t321, 0
  %t326 = insertvalue { i64, ptr } %t325, ptr %t322, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t326, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/mir:Lvalue"
  %l4 = alloca { i64, [15 x i64] }
  %l5 = alloca { i64, [4 x i64] }
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca { { i64, ptr }, i32 }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l11 = alloca { i64, [1 x i64] }
  %l12 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i1
  %l16 = alloca i32
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca %"compiler/source:Span"
  %l22 = alloca { i64, [4 x i64] }
  %l23 = alloca { i64, [4 x i64] }
  %l24 = alloca { i64, [4 x i64] }
  %l25 = alloca { i64, [4 x i64] }
  %l26 = alloca i32
  %l27 = alloca %"compiler/mir:Range"
  %l28 = alloca { i64, [1 x i64] }
  %l29 = alloca i32
  %l30 = alloca { i64, [4 x i64] }
  %l31 = alloca { i64, [2 x i64] }
  %l32 = alloca %"compiler/mir:Lvalue"
  %l33 = alloca { { i64, ptr }, i32 }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i32
  %l36 = alloca { i64, ptr }
  %l37 = alloca %"compiler/mir:Lvalue"
  %l38 = alloca { { i64, ptr }, i32 }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i32
  %l41 = alloca { i64, ptr }
  %l42 = alloca i32
  %l43 = alloca %"compiler/mir:Lvalue"
  %l44 = alloca { { i64, ptr }, i32 }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i32
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, [1 x i64] }
  %l50 = alloca i32
  %l51 = alloca { i64, [4 x i64] }
  %l52 = alloca %"compiler/mir:Lvalue"
  %l53 = alloca %"compiler/mir:Lvalue"
  %l54 = alloca { i64, [4 x i64] }
  %l55 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca i32
  %l58 = alloca { i64, ptr }
  %l59 = alloca i32
  %l60 = alloca i32
  %l67 = alloca ptr
  %l69 = alloca %"compiler/source:Span"
  %l70 = alloca ptr
  %l71 = alloca i1
  %l80 = alloca i1
  %l86 = alloca i32
  %l91 = alloca i1
  %l96 = alloca i1
  %l99 = alloca i1
  %l100 = alloca i1
  %l105 = alloca i1
  %l109 = alloca { i64, ptr }
  %l113 = alloca i1
  %l119 = alloca { { i64, ptr }, i32 }
  %l121 = alloca ptr
  %l124 = alloca { i64, ptr }
  %l130 = alloca ptr
  %l131 = alloca i1
  %l141 = alloca %"compiler/mir:Local"
  %l145 = alloca i1
  %l149 = alloca i32
  %l150 = alloca ptr
  %l151 = alloca { i64, [1 x i64] }
  %l154 = alloca i64
  %l156 = alloca { i64, ptr }
  %l159 = alloca i64
  %l160 = alloca { i64, ptr }
  %l166 = alloca ptr
  %l167 = alloca i1
  %l170 = alloca ptr
  %l171 = alloca i1
  %l180 = alloca i1
  %l185 = alloca i1
  %l195 = alloca %"compiler/mir:ScopeInfo"
  %l212 = alloca %"compiler/mir:ScopeInfo"
  %l225 = alloca %"compiler/mir:ScopeInfo"
  %l239 = alloca ptr
  %l240 = alloca i1
  %l249 = alloca i1
  %l250 = alloca i1
  %l255 = alloca i1
  %l261 = alloca %"compiler/mir:ScopeInfo"
  %l266 = alloca ptr
  %l271 = alloca { i64, ptr }
  %l273 = alloca { i64, ptr }
  %l278 = alloca { i64, ptr }
  %l280 = alloca { i64, ptr }
  %l282 = alloca { i64, ptr }
  %l301 = alloca ptr
  %l303 = alloca i64
  %l309 = alloca i64
  %l321 = alloca ptr
  %l322 = alloca i1
  %l329 = alloca ptr
  %l330 = alloca i1
  %l337 = alloca ptr
  %l341 = alloca { i64, ptr }
  %l344 = alloca ptr
  %l345 = alloca i1
  %l351 = alloca ptr
  %l352 = alloca i1
  %l356 = alloca ptr
  %l357 = alloca i1
  %l364 = alloca ptr
  %l365 = alloca { i64, [4 x i64] }
  %l369 = alloca { i64, ptr }
  %l371 = alloca ptr
  %l372 = alloca i1
  %l385 = alloca ptr
  %l386 = alloca i1
  %l395 = alloca { i64, [2 x i64] }
  %l396 = alloca ptr
  %l397 = alloca i32
  %l398 = alloca i64
  %l403 = alloca i64
  %l404 = alloca i32
  %l405 = alloca { i64, [2 x i64] }
  %l406 = alloca i32
  %l407 = alloca ptr
  %l411 = alloca { i64, ptr }
  %l421 = alloca i1
  %l433 = alloca ptr
  %l436 = alloca { i64, ptr }
  %l440 = alloca { i64, ptr }
  %l444 = alloca { i64, ptr }
  %l447 = alloca ptr
  %l448 = alloca i1
  %l455 = alloca { { i64, ptr }, i32 }
  %l456 = alloca { i64, ptr }
  %l457 = alloca i64
  %l458 = alloca { i64, ptr }
  %l462 = alloca i1
  %l464 = alloca i1
  %l467 = alloca i1
  %l471 = alloca ptr
  %l475 = alloca { i64, ptr }
  %l478 = alloca ptr
  %l481 = alloca { i64, ptr }
  %l484 = alloca ptr
  %l487 = alloca { i64, ptr }
  %l490 = alloca { i64, ptr }
  %l493 = alloca ptr
  %l497 = alloca { i64, ptr }
  %l498 = alloca i64
  %l499 = alloca { i64, ptr }
  %l502 = alloca ptr
  %l505 = alloca { i64, ptr }
  %l506 = alloca { i64, ptr }
  %l510 = alloca { i64, ptr }
  %l513 = alloca ptr
  %l514 = alloca i1
  %l521 = alloca { { i64, ptr }, i32 }
  %l524 = alloca ptr
  %l527 = alloca { i64, ptr }
  %l530 = alloca { i64, ptr }
  %l533 = alloca ptr
  %l537 = alloca { i64, ptr }
  %l538 = alloca i64
  %l539 = alloca { i64, ptr }
  %l542 = alloca ptr
  %l545 = alloca { i64, ptr }
  %l546 = alloca { i64, ptr }
  %l550 = alloca { i64, ptr }
  %l553 = alloca ptr
  %l554 = alloca i1
  %l563 = alloca { { i64, ptr }, i32 }
  %l564 = alloca { i64, ptr }
  %l565 = alloca i64
  %l566 = alloca { i64, ptr }
  %l568 = alloca ptr
  %l569 = alloca ptr
  %l572 = alloca { i64, ptr }
  %l574 = alloca { i64, ptr }
  %l577 = alloca { i64, ptr }
  %l578 = alloca ptr
  %l582 = alloca { i64, ptr }
  %l586 = alloca { i64, ptr }
  %l594 = alloca ptr
  %l595 = alloca i1
  %l606 = alloca i1
  %l613 = alloca ptr
  %l616 = alloca { i64, ptr }
  %l620 = alloca ptr
  %l621 = alloca i1
  %l632 = alloca { i64, ptr }
  %l635 = alloca { i64, ptr }
  %l636 = alloca ptr
  %l637 = alloca ptr
  %l640 = alloca i32
  %l641 = alloca i32
  %l642 = alloca i32
  %l643 = alloca ptr
  %l644 = alloca ptr
  %l648 = alloca { i64, ptr }
  %l649 = alloca { i64, ptr }
  %l652 = alloca i32
  %l653 = alloca { i64, ptr }
  %l656 = alloca i64
  %l659 = alloca { i64, ptr }
  %l668 = alloca ptr
  %l669 = alloca i1
  %l676 = alloca ptr
  %l677 = alloca i32
  %l683 = alloca %"compiler/mir:Task"
  %s2 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %s43 = alloca %olang.scope
  %s44 = alloca %olang.scope
  %s48 = alloca %olang.scope
  %s49 = alloca %olang.scope
  %s52 = alloca %olang.scope
  %s54 = alloca %olang.scope
  %s58 = alloca %olang.scope
  %s60 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/emit:fnEm", ptr %t9, i32 0, i32 18
  %t12 = load i64, ptr %t11, !tbaa !24
  %t14 = icmp sge i64 %t12, 0
  br i1 %t14, label %bb1, label %bb2
bb1:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l67, !tbaa !29
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = call %"compiler/source:Span" @compiler_2femit_2estmtSpan(ptr %v1, ptr %t17)
  store %"compiler/source:Span" %t19, ptr %l69
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t20 = load ptr, ptr %l67, !tbaa !29
  %t21 = load %"compiler/source:Span", ptr %l69
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elocate(ptr %v0, ptr %t20, %"compiler/source:Span" %t21)
  br label %bb4
bb4:
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t23 = load ptr, ptr %l70, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = load ptr, ptr %l70, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 18}
  %t29 = icmp eq i64 %t27, 0
  store i1 %t29, ptr %l71, !tbaa !21
  br label %bb7
bb7:
  %t30 = load i1, ptr %l71, !tbaa !21
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [21 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t33, i32 0, i32 1
  %t35 = load %"compiler/mir:Lvalue", ptr %t34
  store %"compiler/mir:Lvalue" %t35, ptr %l3
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [21 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t39, i32 0, i32 2
  %t41 = load { i64, [15 x i64] }, ptr %t40
  store { i64, [15 x i64] } %t41, ptr %l4
  br label %bb10
bb9:
  br label %bb44
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load { i64, [15 x i64] }, ptr %l4
  %t45 = extractvalue { i64, [15 x i64] } %t43, 0
  %t46 = icmp eq i64 %t45, 0
  br i1 %t46, label %bb11, label %bb12
bb11:
  %t48 = getelementptr { i64, [15 x i64] }, ptr %l4, i32 0, i32 1
  %t49 = getelementptr { { i64, [4 x i64] } }, ptr %t48, i32 0, i32 0
  %t50 = load { i64, [4 x i64] }, ptr %t49
  %t52 = extractvalue { i64, [4 x i64] } %t50, 0
  %t53 = icmp eq i64 %t52, 0
  store i1 %t53, ptr %l80, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb13
bb13:
  %t55 = load i1, ptr %l80, !tbaa !21
  br i1 %t55, label %bb14, label %bb15
bb14:
  %t56 = getelementptr { i64, [15 x i64] }, ptr %l4, i32 0, i32 1
  %t57 = getelementptr { { i64, [4 x i64] } }, ptr %t56, i32 0, i32 0
  %t58 = load { i64, [4 x i64] }, ptr %t57
  store { i64, [4 x i64] } %t58, ptr %l5
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb15:
  br label %bb16
bb16:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load %"compiler/mir:Lvalue", ptr %l3
  %t64 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eplaceType(ptr %v0, ptr %t60, %"compiler/mir:Lvalue" %t61)
  store i32 %t64, ptr %l86
  br label %bb17
bb17:
  %t65 = load i32, ptr %l86, !tbaa !23
  store i32 %t65, ptr %l6, !tbaa !23
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load %"compiler/mir:Lvalue", ptr %l3
  %t68 = load i32, ptr %l6, !tbaa !23
  %t69 = load { i64, [15 x i64] }, ptr %l4
  %t74 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2epackedInto(ptr %v0, ptr %t66, %"compiler/mir:Lvalue" %t67, i32 %t68, { i64, [15 x i64] } %t69)
  store i1 %t74, ptr %l91
  br label %bb18
bb18:
  %t75 = load i1, ptr %l91, !tbaa !21
  br i1 %t75, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb20:
  br label %bb21
bb21:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load %"compiler/mir:Lvalue", ptr %l3
  %t78 = load i32, ptr %l6, !tbaa !23
  %t79 = load { i64, [15 x i64] }, ptr %l4
  %t84 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efillInPlace(ptr %v0, ptr %t76, %"compiler/mir:Lvalue" %t77, i32 %t78, { i64, [15 x i64] } %t79)
  store i1 %t84, ptr %l96
  br label %bb22
bb22:
  %t85 = load i1, ptr %l96, !tbaa !21
  br i1 %t85, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb24:
  br label %bb25
bb25:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load i32, ptr %l6, !tbaa !23
  %t90 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eviaMem(ptr %v0, ptr %t86, i32 %t87)
  store i1 %t90, ptr %l99
  br label %bb26
bb26:
  %t91 = load i1, ptr %l99, !tbaa !21
  br i1 %t91, label %bb27, label %bb28
bb27:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load %"compiler/mir:Lvalue", ptr %l3
  %t94 = load i32, ptr %l6, !tbaa !23
  %t95 = load { i64, [15 x i64] }, ptr %l4
  %t100 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eintoPlace(ptr %v0, ptr %t92, %"compiler/mir:Lvalue" %t93, i32 %t94, { i64, [15 x i64] } %t95)
  store i1 %t100, ptr %l105
  br label %bb29
bb28:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb30
bb29:
  %t101 = load i1, ptr %l105, !tbaa !21
  store i1 %t101, ptr %l100, !tbaa !21
  br label %bb30
bb30:
  %t102 = load i1, ptr %l100, !tbaa !21
  br i1 %t102, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb32:
  br label %bb33
bb33:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load { i64, [15 x i64] }, ptr %l4
  %t105 = load i32, ptr %l6, !tbaa !23
  %t109 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ervalue(ptr %v0, ptr %s2, ptr %t103, { i64, [15 x i64] } %t104, i32 %t105)
  store { i64, ptr } %t109, ptr %l109
  br label %bb34
bb34:
  %t110 = load { i64, ptr }, ptr %l109, !tbaa !27
  store { i64, ptr } %t110, ptr %l7, !tbaa !27
  %t111 = load i32, ptr %l6, !tbaa !23
  %t112 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t115 = icmp eq i32 %t111, %t112
  br i1 %t115, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l113, !tbaa !21
  br label %bb37
bb36:
  %t117 = load i32, ptr %l6, !tbaa !23
  %t118 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t121 = icmp eq i32 %t117, %t118
  store i1 %t121, ptr %l113, !tbaa !21
  br label %bb37
bb37:
  %t123 = load i1, ptr %l113, !tbaa !21
  br i1 %t123, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb39:
  br label %bb40
bb40:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load %"compiler/mir:Lvalue", ptr %l3
  %t128 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s2, ptr %t124, %"compiler/mir:Lvalue" %t125)
  store { { i64, ptr }, i32 } %t128, ptr %l119
  br label %bb41
bb41:
  %t129 = load { { i64, ptr }, i32 }, ptr %l119
  store { { i64, ptr }, i32 } %t129, ptr %l8
  %t130 = getelementptr { { i64, ptr }, i32 }, ptr %l8, i32 0, i32 0
  %t131 = load { i64, ptr }, ptr %t130, !tbaa !27
  store { i64, ptr } %t131, ptr %l9, !tbaa !27
  %t133 = load ptr, ptr %l0, !tbaa !29
  store ptr %t133, ptr %l121, !tbaa !29
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load i32, ptr %l6, !tbaa !23
  %t138 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s2, ptr %t134, i32 %t135)
  store { i64, ptr } %t138, ptr %l124
  br label %bb42
bb42:
  %t139 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t139, 0
  %t141 = extractvalue { i64, ptr } %t139, 1
  %t142 = mul i64 %t140, 1
  %t143 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t142)
  call void @llvm.memcpy.p0.p0.i64(ptr %t143, ptr %t141, i64 %t142, i1 false)
  %t144 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t143, 1
  %t146 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t147 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/emit:fnEm", ptr %t148, i32 0, i32 15
  %t151 = load { i64, ptr }, ptr %t150, !tbaa !27
  %t152 = load ptr, ptr %l121, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s2, ptr %s2, ptr %s2, ptr %v0, ptr %t152, { i64, ptr } %t145, { i64, ptr } %t146, { i64, ptr } %t147, { i64, ptr } %t151)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s2)
  br label %bb312
bb44:
  %t157 = load ptr, ptr %l1, !tbaa !29
  store ptr %t157, ptr %l130, !tbaa !29
  store i1 false, ptr %l131, !tbaa !21
  %t158 = load ptr, ptr %l130, !tbaa !29
  %t159 = icmp ne ptr %t158, null
  br i1 %t159, label %bb45, label %bb46
bb45:
  %t161 = load ptr, ptr %l130, !tbaa !29
  %t162 = load i64, ptr %t161, !range !{i64 0, i64 18}
  %t164 = icmp eq i64 %t162, 1
  store i1 %t164, ptr %l131, !tbaa !21
  br label %bb46
bb46:
  %t165 = load i1, ptr %l131, !tbaa !21
  br i1 %t165, label %bb47, label %bb48
bb47:
  %t166 = load ptr, ptr %l1, !tbaa !29
  %t168 = getelementptr { i64, [21 x i64] }, ptr %t166, i32 0, i32 1
  %t169 = getelementptr { %"compiler/source:Span", i32 }, ptr %t168, i32 0, i32 1
  %t170 = load i32, ptr %t169
  store i32 %t170, ptr %l10, !tbaa !23
  br label %bb49
bb48:
  br label %bb60
bb49:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr %"compiler/emit:fnEm", ptr %t172, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !29
  %t177 = getelementptr %"compiler/mir:Fn", ptr %t175, i32 0, i32 7
  %t178 = load i32, ptr %l10, !tbaa !23
  %t180 = sext i32 %t178 to i64
  %t183 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t177, i64 %t180)
  store %"compiler/mir:Local" %t183, ptr %l141
  br label %bb50
bb50:
  %t184 = getelementptr %"compiler/mir:Local", ptr %l141, i32 0, i32 4
  %t185 = load { i64, [1 x i64] }, ptr %t184
  store { i64, [1 x i64] } %t185, ptr %l11
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load { i64, [1 x i64] }, ptr %l11
  %t191 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eisFrame(ptr %v0, ptr %t187, { i64, [1 x i64] } %t188)
  store i1 %t191, ptr %l145
  br label %bb51
bb51:
  %t192 = load i1, ptr %l145, !tbaa !21
  %t193 = xor i1 %t192, true
  br i1 %t193, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s9
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t196 = load i32, ptr %l10, !tbaa !23
  %t199 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalType(ptr %v0, ptr %t195, i32 %t196)
  store i32 %t199, ptr %l149
  br label %bb54
bb53:
  br label %bb59
bb54:
  %t200 = load i32, ptr %l149, !tbaa !23
  store i32 %t200, ptr %l12, !tbaa !23
  %t201 = load ptr, ptr %l0, !tbaa !29
  store ptr %t201, ptr %l150, !tbaa !29
  %t202 = load { i64, [1 x i64] }, ptr %l11
  store { i64, [1 x i64] } %t202, ptr %l151
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load i32, ptr %l12, !tbaa !23
  %t207 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t203, i32 %t204)
  store i64 %t207, ptr %l154
  br label %bb55
bb55:
  %t208 = load i64, ptr %l154, !tbaa !24
  %t209 = call i64 @__olang_fmt_i64(ptr null, i64 %t208)
  %t210 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t209)
  %t211 = call i64 @__olang_fmt_i64(ptr %t210, i64 %t208)
  %t212 = insertvalue { i64, ptr } undef, i64 %t209, 0
  %t213 = insertvalue { i64, ptr } %t212, ptr %t210, 1
  %t215 = extractvalue { i64, ptr } %t213, 0
  %t216 = extractvalue { i64, ptr } %t213, 1
  %t217 = mul i64 %t215, 1
  %t218 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t217)
  call void @llvm.memcpy.p0.p0.i64(ptr %t218, ptr %t216, i64 %t217, i1 false)
  %t219 = insertvalue { i64, ptr } undef, i64 %t215, 0
  %t220 = insertvalue { i64, ptr } %t219, ptr %t218, 1
  store { i64, ptr } %t220, ptr %l156, !tbaa !27
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load i32, ptr %l12, !tbaa !23
  %t225 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ealign(ptr %v0, ptr %t221, i32 %t222)
  store i64 %t225, ptr %l159
  br label %bb56
bb56:
  %t226 = load ptr, ptr %l150, !tbaa !29
  %t227 = load { i64, [1 x i64] }, ptr %l151
  %t228 = load { i64, ptr }, ptr %l156, !tbaa !27
  %t229 = load i64, ptr %l159, !tbaa !24
  %t230 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloc(ptr %v0, ptr %s9, ptr %s9, ptr %s9, ptr %t226, { i64, [1 x i64] } %t227, { i64, ptr } %t228, i64 %t229, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d246, i32 0, i32 1) })
  store { i64, ptr } %t230, ptr %l160
  br label %bb57
bb57:
  %t231 = load { i64, ptr }, ptr %l160, !tbaa !27
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = load i32, ptr %l10, !tbaa !23
  %t235 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d247, i32 0, i32 1) }, 1
  %t236 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d247, i32 0, i32 1) }, 0
  %t238 = sext i32 %t234 to i64
  %t239 = call i64 @__olang_fmt_i64(ptr null, i64 %t238)
  %t240 = add i64 %t236, %t239
  %t241 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t240)
  call void @olang_textcopy(ptr %t241, ptr %t235, i64 %t236)
  %t242 = getelementptr i8, ptr %t241, i64 %t236
  %t243 = call i64 @__olang_fmt_i64(ptr %t242, i64 %t238)
  %t244 = insertvalue { i64, ptr } undef, i64 %t240, 0
  %t245 = insertvalue { i64, ptr } %t244, ptr %t241, 1
  %t247 = extractvalue { i64, ptr } %t245, 0
  %t248 = extractvalue { i64, ptr } %t245, 1
  %t249 = mul i64 %t247, 1
  %t250 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t249)
  call void @llvm.memcpy.p0.p0.i64(ptr %t250, ptr %t248, i64 %t249, i1 false)
  %t251 = insertvalue { i64, ptr } undef, i64 %t247, 0
  %t252 = insertvalue { i64, ptr } %t251, ptr %t250, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s9, ptr %s9, ptr %s9, ptr %s9, ptr %t232, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d248, i32 0, i32 1) }, { i64, ptr } %t231, { i64, ptr } %t252, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d230, i32 0, i32 1) })
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s9)
  br label %bb59
bb59:
  br label %bb312
bb60:
  %t256 = load ptr, ptr %l1, !tbaa !29
  store ptr %t256, ptr %l166, !tbaa !29
  store i1 false, ptr %l167, !tbaa !21
  %t257 = load ptr, ptr %l166, !tbaa !29
  %t258 = icmp ne ptr %t257, null
  br i1 %t258, label %bb61, label %bb62
bb61:
  %t260 = load ptr, ptr %l166, !tbaa !29
  %t261 = load i64, ptr %t260, !range !{i64 0, i64 18}
  %t263 = icmp eq i64 %t261, 2
  store i1 %t263, ptr %l167, !tbaa !21
  br label %bb62
bb62:
  %t264 = load i1, ptr %l167, !tbaa !21
  br i1 %t264, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb312
bb66:
  %t265 = load ptr, ptr %l1, !tbaa !29
  store ptr %t265, ptr %l170, !tbaa !29
  store i1 false, ptr %l171, !tbaa !21
  %t266 = load ptr, ptr %l170, !tbaa !29
  %t267 = icmp ne ptr %t266, null
  br i1 %t267, label %bb67, label %bb68
bb67:
  %t269 = load ptr, ptr %l170, !tbaa !29
  %t270 = load i64, ptr %t269, !range !{i64 0, i64 18}
  %t272 = icmp eq i64 %t270, 3
  store i1 %t272, ptr %l171, !tbaa !21
  br label %bb68
bb68:
  %t273 = load i1, ptr %l171, !tbaa !21
  br i1 %t273, label %bb69, label %bb70
bb69:
  %t274 = load ptr, ptr %l1, !tbaa !29
  %t276 = getelementptr { i64, [21 x i64] }, ptr %t274, i32 0, i32 1
  %t277 = getelementptr { %"compiler/source:Span", i32 }, ptr %t276, i32 0, i32 1
  %t278 = load i32, ptr %t277
  store i32 %t278, ptr %l14, !tbaa !23
  br label %bb71
bb70:
  br label %bb103
bb71:
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = getelementptr %"compiler/emit:fnEm", ptr %t280, i32 0, i32 25
  %t283 = load i32, ptr %l14, !tbaa !23
  %t285 = sext i32 %t283 to i64
  %t288 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t282, i64 %t285)
  store i1 %t288, ptr %l180
  br label %bb72
bb72:
  %t289 = load i1, ptr %l180, !tbaa !21
  br i1 %t289, label %bb73, label %bb74
bb73:
  br label %ret
bb74:
  br label %bb75
bb75:
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t292 = getelementptr %"compiler/emit:fnEm", ptr %t290, i32 0, i32 24
  %t293 = load i32, ptr %l14, !tbaa !23
  %t295 = sext i32 %t293 to i64
  %t298 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t292, i64 %t295)
  store i1 %t298, ptr %l185
  br label %bb76
bb76:
  %t299 = load i1, ptr %l185, !tbaa !21
  br i1 %t299, label %bb77, label %bb78
bb77:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr %"compiler/emit:fnEm", ptr %t300, i32 0, i32 26
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aWriteKind_3e_2eClear_3ccompiler_2fmir_3aWriteKind_3e(ptr %v0, ptr %t302)
  br label %bb79
bb78:
  br label %bb81
bb79:
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t306 = getelementptr %"compiler/emit:fnEm", ptr %t304, i32 0, i32 27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eClear_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t306)
  br label %bb80
bb80:
  br label %ret
bb81:
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t310 = getelementptr %"compiler/emit:fnEm", ptr %t308, i32 0, i32 1
  %t311 = load ptr, ptr %t310, !tbaa !29
  %t313 = getelementptr %"compiler/mir:Fn", ptr %t311, i32 0, i32 8
  %t314 = load i32, ptr %l14, !tbaa !23
  %t316 = sext i32 %t314 to i64
  %t319 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t313, i64 %t316)
  store %"compiler/mir:ScopeInfo" %t319, ptr %l195
  br label %bb82
bb82:
  %t320 = getelementptr %"compiler/mir:ScopeInfo", ptr %l195, i32 0, i32 0
  %t321 = load i32, ptr %t320, !range !{i32 0, i32 7}
  %t323 = trunc i64 6 to i32
  %t324 = icmp eq i32 %t321, %t323
  br i1 %t324, label %bb83, label %bb84
bb83:
  store %olang.scope zeroinitializer, ptr %s16
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t327 = load i32, ptr %l14, !tbaa !23
  %t328 = extractvalue { i64, ptr } { i64 76, ptr getelementptr inbounds (<{ i64, [76 x i8] }>, ptr @.d249, i32 0, i32 1) }, 1
  %t329 = extractvalue { i64, ptr } { i64 76, ptr getelementptr inbounds (<{ i64, [76 x i8] }>, ptr @.d249, i32 0, i32 1) }, 0
  %t331 = sext i32 %t327 to i64
  %t332 = call i64 @__olang_fmt_i64(ptr null, i64 %t331)
  %t333 = add i64 %t329, %t332
  %t334 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t333)
  call void @olang_textcopy(ptr %t334, ptr %t328, i64 %t329)
  %t335 = getelementptr i8, ptr %t334, i64 %t329
  %t336 = call i64 @__olang_fmt_i64(ptr %t335, i64 %t331)
  %t337 = insertvalue { i64, ptr } undef, i64 %t333, 0
  %t338 = insertvalue { i64, ptr } %t337, ptr %t334, 1
  %t340 = extractvalue { i64, ptr } %t338, 0
  %t341 = extractvalue { i64, ptr } %t338, 1
  %t342 = mul i64 %t340, 1
  %t343 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t342)
  call void @llvm.memcpy.p0.p0.i64(ptr %t343, ptr %t341, i64 %t342, i1 false)
  %t344 = insertvalue { i64, ptr } undef, i64 %t340, 0
  %t345 = insertvalue { i64, ptr } %t344, ptr %t343, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s16, ptr %t326, { i64, ptr } %t345)
  br label %bb85
bb84:
  store %olang.scope zeroinitializer, ptr %s19
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t350 = getelementptr %"compiler/emit:fnEm", ptr %t348, i32 0, i32 1
  %t351 = load ptr, ptr %t350, !tbaa !29
  %t353 = getelementptr %"compiler/mir:Fn", ptr %t351, i32 0, i32 8
  %t354 = load i32, ptr %l14, !tbaa !23
  %t356 = sext i32 %t354 to i64
  %t359 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t353, i64 %t356)
  store %"compiler/mir:ScopeInfo" %t359, ptr %l212
  br label %bb87
bb85:
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t361 = load i32, ptr %l14, !tbaa !23
  %t362 = load i32, ptr %l14, !tbaa !23
  %t363 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d250, i32 0, i32 1) }, 1
  %t364 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d250, i32 0, i32 1) }, 0
  %t366 = sext i32 %t361 to i64
  %t367 = call i64 @__olang_fmt_i64(ptr null, i64 %t366)
  %t368 = add i64 %t364, %t367
  %t369 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d251, i32 0, i32 1) }, 1
  %t370 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d251, i32 0, i32 1) }, 0
  %t371 = add i64 %t368, %t370
  %t373 = sext i32 %t362 to i64
  %t374 = call i64 @__olang_fmt_i64(ptr null, i64 %t373)
  %t375 = add i64 %t371, %t374
  %t376 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t375)
  call void @olang_textcopy(ptr %t376, ptr %t363, i64 %t364)
  %t377 = getelementptr i8, ptr %t376, i64 %t364
  %t378 = call i64 @__olang_fmt_i64(ptr %t377, i64 %t366)
  %t379 = getelementptr i8, ptr %t377, i64 %t367
  call void @olang_textcopy(ptr %t379, ptr %t369, i64 %t370)
  %t380 = getelementptr i8, ptr %t379, i64 %t370
  %t381 = call i64 @__olang_fmt_i64(ptr %t380, i64 %t373)
  %t382 = insertvalue { i64, ptr } undef, i64 %t375, 0
  %t383 = insertvalue { i64, ptr } %t382, ptr %t376, 1
  %t385 = extractvalue { i64, ptr } %t383, 0
  %t386 = extractvalue { i64, ptr } %t383, 1
  %t387 = mul i64 %t385, 1
  %t388 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t387)
  call void @llvm.memcpy.p0.p0.i64(ptr %t388, ptr %t386, i64 %t387, i1 false)
  %t389 = insertvalue { i64, ptr } undef, i64 %t385, 0
  %t390 = insertvalue { i64, ptr } %t389, ptr %t388, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s16, ptr %t360, { i64, ptr } %t390)
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s16)
  br label %bb102
bb87:
  %t393 = getelementptr %"compiler/mir:ScopeInfo", ptr %l212, i32 0, i32 0
  %t394 = load i32, ptr %t393, !range !{i32 0, i32 7}
  %t396 = trunc i64 4 to i32
  %t397 = icmp eq i32 %t394, %t396
  br i1 %t397, label %bb88, label %bb89
bb88:
  store %olang.scope zeroinitializer, ptr %s20
  %t399 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s20, ptr %t399, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d252, i32 0, i32 1) })
  br label %bb90
bb89:
  br label %bb91
bb90:
  call void @__olang_scope_close(ptr %s20)
  br label %bb91
bb91:
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t402 = load i32, ptr %l14, !tbaa !23
  %t403 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d253, i32 0, i32 1) }, 1
  %t404 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d253, i32 0, i32 1) }, 0
  %t406 = sext i32 %t402 to i64
  %t407 = call i64 @__olang_fmt_i64(ptr null, i64 %t406)
  %t408 = add i64 %t404, %t407
  %t409 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t408)
  call void @olang_textcopy(ptr %t409, ptr %t403, i64 %t404)
  %t410 = getelementptr i8, ptr %t409, i64 %t404
  %t411 = call i64 @__olang_fmt_i64(ptr %t410, i64 %t406)
  %t412 = insertvalue { i64, ptr } undef, i64 %t408, 0
  %t413 = insertvalue { i64, ptr } %t412, ptr %t409, 1
  %t415 = extractvalue { i64, ptr } %t413, 0
  %t416 = extractvalue { i64, ptr } %t413, 1
  %t417 = mul i64 %t415, 1
  %t418 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t417)
  call void @llvm.memcpy.p0.p0.i64(ptr %t418, ptr %t416, i64 %t417, i1 false)
  %t419 = insertvalue { i64, ptr } undef, i64 %t415, 0
  %t420 = insertvalue { i64, ptr } %t419, ptr %t418, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s19, ptr %t401, { i64, ptr } %t420)
  br label %bb92
bb92:
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t425 = getelementptr %"compiler/emit:fnEm", ptr %t423, i32 0, i32 1
  %t426 = load ptr, ptr %t425, !tbaa !29
  %t428 = getelementptr %"compiler/mir:Fn", ptr %t426, i32 0, i32 8
  %t429 = load i32, ptr %l14, !tbaa !23
  %t431 = sext i32 %t429 to i64
  %t434 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t428, i64 %t431)
  store %"compiler/mir:ScopeInfo" %t434, ptr %l225
  br label %bb93
bb93:
  %t435 = getelementptr %"compiler/mir:ScopeInfo", ptr %l225, i32 0, i32 0
  %t436 = load i32, ptr %t435, !range !{i32 0, i32 7}
  %t438 = trunc i64 3 to i32
  %t439 = icmp eq i32 %t436, %t438
  store i1 %t439, ptr %l15, !tbaa !21
  %t441 = load i1, ptr %l15, !tbaa !21
  br i1 %t441, label %bb94, label %bb95
bb94:
  store %olang.scope zeroinitializer, ptr %s22
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t444 = load i32, ptr %l14, !tbaa !23
  %t445 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d254, i32 0, i32 1) }, 1
  %t446 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d254, i32 0, i32 1) }, 0
  %t448 = sext i32 %t444 to i64
  %t449 = call i64 @__olang_fmt_i64(ptr null, i64 %t448)
  %t450 = add i64 %t446, %t449
  %t451 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t450)
  call void @olang_textcopy(ptr %t451, ptr %t445, i64 %t446)
  %t452 = getelementptr i8, ptr %t451, i64 %t446
  %t453 = call i64 @__olang_fmt_i64(ptr %t452, i64 %t448)
  %t454 = insertvalue { i64, ptr } undef, i64 %t450, 0
  %t455 = insertvalue { i64, ptr } %t454, ptr %t451, 1
  %t457 = extractvalue { i64, ptr } %t455, 0
  %t458 = extractvalue { i64, ptr } %t455, 1
  %t459 = mul i64 %t457, 1
  %t460 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t459)
  call void @llvm.memcpy.p0.p0.i64(ptr %t460, ptr %t458, i64 %t459, i1 false)
  %t461 = insertvalue { i64, ptr } undef, i64 %t457, 0
  %t462 = insertvalue { i64, ptr } %t461, ptr %t460, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s22, ptr %t443, { i64, ptr } %t462)
  br label %bb96
bb95:
  br label %bb97
bb96:
  call void @__olang_scope_close(ptr %s22)
  br label %bb97
bb97:
  %t465 = load ptr, ptr %l0, !tbaa !29
  %t467 = getelementptr %"compiler/emit:fnEm", ptr %t465, i32 0, i32 0
  %t468 = load ptr, ptr %t467, !tbaa !29
  %t470 = getelementptr %"compiler/emit:Emitter", ptr %t468, i32 0, i32 4
  %t471 = load i1, ptr %t470, !tbaa !21
  br i1 %t471, label %bb98, label %bb99
bb98:
  %t473 = load ptr, ptr %l0, !tbaa !29
  %t474 = load i32, ptr %l14, !tbaa !23
  %t475 = load i1, ptr %l15, !tbaa !21
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eunwindPush(ptr %v0, ptr %t473, i32 %t474, i1 %t475)
  br label %bb100
bb99:
  br label %bb101
bb100:
  br label %bb101
bb101:
  call void @__olang_scope_close(ptr %s19)
  br label %bb102
bb102:
  br label %bb312
bb103:
  %t479 = load ptr, ptr %l1, !tbaa !29
  store ptr %t479, ptr %l239, !tbaa !29
  store i1 false, ptr %l240, !tbaa !21
  %t480 = load ptr, ptr %l239, !tbaa !29
  %t481 = icmp ne ptr %t480, null
  br i1 %t481, label %bb104, label %bb105
bb104:
  %t483 = load ptr, ptr %l239, !tbaa !29
  %t484 = load i64, ptr %t483, !range !{i64 0, i64 18}
  %t486 = icmp eq i64 %t484, 4
  store i1 %t486, ptr %l240, !tbaa !21
  br label %bb105
bb105:
  %t487 = load i1, ptr %l240, !tbaa !21
  br i1 %t487, label %bb106, label %bb107
bb106:
  %t488 = load ptr, ptr %l1, !tbaa !29
  %t490 = getelementptr { i64, [21 x i64] }, ptr %t488, i32 0, i32 1
  %t491 = getelementptr { %"compiler/source:Span", i32 }, ptr %t490, i32 0, i32 1
  %t492 = load i32, ptr %t491
  store i32 %t492, ptr %l16, !tbaa !23
  br label %bb108
bb107:
  br label %bb140
bb108:
  %t494 = load ptr, ptr %l0, !tbaa !29
  %t496 = getelementptr %"compiler/emit:fnEm", ptr %t494, i32 0, i32 24
  %t497 = load i32, ptr %l16, !tbaa !23
  %t499 = sext i32 %t497 to i64
  %t502 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t496, i64 %t499)
  store i1 %t502, ptr %l249
  br label %bb109
bb109:
  %t503 = load i1, ptr %l249, !tbaa !21
  br i1 %t503, label %bb110, label %bb111
bb110:
  store i1 true, ptr %l250, !tbaa !21
  br label %bb113
bb111:
  %t504 = load ptr, ptr %l0, !tbaa !29
  %t506 = getelementptr %"compiler/emit:fnEm", ptr %t504, i32 0, i32 25
  %t507 = load i32, ptr %l16, !tbaa !23
  %t509 = sext i32 %t507 to i64
  %t512 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t506, i64 %t509)
  store i1 %t512, ptr %l255
  br label %bb112
bb112:
  %t513 = load i1, ptr %l255, !tbaa !21
  store i1 %t513, ptr %l250, !tbaa !21
  br label %bb113
bb113:
  %t514 = load i1, ptr %l250, !tbaa !21
  br i1 %t514, label %bb114, label %bb115
bb114:
  br label %ret
bb115:
  br label %bb116
bb116:
  %t515 = load ptr, ptr %l0, !tbaa !29
  %t517 = getelementptr %"compiler/emit:fnEm", ptr %t515, i32 0, i32 1
  %t518 = load ptr, ptr %t517, !tbaa !29
  %t520 = getelementptr %"compiler/mir:Fn", ptr %t518, i32 0, i32 8
  %t521 = load i32, ptr %l16, !tbaa !23
  %t523 = sext i32 %t521 to i64
  %t526 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t520, i64 %t523)
  store %"compiler/mir:ScopeInfo" %t526, ptr %l261
  br label %bb117
bb117:
  %t527 = getelementptr %"compiler/mir:ScopeInfo", ptr %l261, i32 0, i32 0
  %t528 = load i32, ptr %t527, !range !{i32 0, i32 7}
  %t530 = trunc i64 6 to i32
  %t531 = icmp eq i32 %t528, %t530
  br i1 %t531, label %bb118, label %bb119
bb118:
  store %olang.scope zeroinitializer, ptr %s27
  %t533 = load ptr, ptr %l0, !tbaa !29
  %t535 = getelementptr %"compiler/emit:fnEm", ptr %t533, i32 0, i32 0
  %t536 = load ptr, ptr %t535, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s27, ptr %t536, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d255, i32 0, i32 1) })
  br label %bb120
bb119:
  store %olang.scope zeroinitializer, ptr %s33
  %t538 = load ptr, ptr %l0, !tbaa !29
  store ptr %t538, ptr %l301, !tbaa !29
  %t539 = load i32, ptr %l16, !tbaa !23
  %t541 = sext i32 %t539 to i64
  store i64 %t541, ptr %l303, !tbaa !24
  %t542 = load ptr, ptr %l0, !tbaa !29
  %t543 = load ptr, ptr %l0, !tbaa !29
  %t545 = getelementptr %"compiler/emit:fnEm", ptr %t543, i32 0, i32 36
  %t546 = load i64, ptr %t545, !tbaa !24
  %t547 = load ptr, ptr %l0, !tbaa !29
  %t549 = getelementptr %"compiler/emit:fnEm", ptr %t547, i32 0, i32 37
  %t550 = load i64, ptr %t549, !tbaa !24
  %t554 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ewalkKey(ptr %v0, ptr %t542, i64 %t546, i64 %t550)
  store i64 %t554, ptr %l309
  br label %bb131
bb120:
  %t555 = load ptr, ptr %l0, !tbaa !29
  store ptr %t555, ptr %l266, !tbaa !29
  %t556 = load ptr, ptr %l0, !tbaa !29
  %t557 = load i32, ptr %l16, !tbaa !23
  %t558 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d256, i32 0, i32 1) }, 1
  %t559 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d256, i32 0, i32 1) }, 0
  %t561 = sext i32 %t557 to i64
  %t562 = call i64 @__olang_fmt_i64(ptr null, i64 %t561)
  %t563 = add i64 %t559, %t562
  %t564 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d257, i32 0, i32 1) }, 1
  %t565 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d257, i32 0, i32 1) }, 0
  %t566 = add i64 %t563, %t565
  %t567 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t566)
  call void @olang_textcopy(ptr %t567, ptr %t558, i64 %t559)
  %t568 = getelementptr i8, ptr %t567, i64 %t559
  %t569 = call i64 @__olang_fmt_i64(ptr %t568, i64 %t561)
  %t570 = getelementptr i8, ptr %t568, i64 %t562
  call void @olang_textcopy(ptr %t570, ptr %t564, i64 %t565)
  %t571 = insertvalue { i64, ptr } undef, i64 %t566, 0
  %t572 = insertvalue { i64, ptr } %t571, ptr %t567, 1
  %t574 = extractvalue { i64, ptr } %t572, 0
  %t575 = extractvalue { i64, ptr } %t572, 1
  %t576 = mul i64 %t574, 1
  %t577 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t576)
  call void @llvm.memcpy.p0.p0.i64(ptr %t577, ptr %t575, i64 %t576, i1 false)
  %t578 = insertvalue { i64, ptr } undef, i64 %t574, 0
  %t579 = insertvalue { i64, ptr } %t578, ptr %t577, 1
  %t582 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s27, ptr %s27, ptr %t556, { i64, ptr } %t579)
  store { i64, ptr } %t582, ptr %l271
  br label %bb121
bb121:
  %t583 = load { i64, ptr }, ptr %l271, !tbaa !27
  %t584 = extractvalue { i64, ptr } %t583, 0
  %t585 = extractvalue { i64, ptr } %t583, 1
  %t586 = mul i64 %t584, 1
  %t587 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t586)
  call void @llvm.memcpy.p0.p0.i64(ptr %t587, ptr %t585, i64 %t586, i1 false)
  %t588 = insertvalue { i64, ptr } undef, i64 %t584, 0
  %t589 = insertvalue { i64, ptr } %t588, ptr %t587, 1
  %t590 = load ptr, ptr %l266, !tbaa !29
  %t592 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s27, ptr %s27, ptr %s27, ptr %s27, ptr %t590, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d258, i32 0, i32 1) }, { i64, ptr } %t589, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) })
  store { i64, ptr } %t592, ptr %l273
  br label %bb122
bb122:
  %t593 = load { i64, ptr }, ptr %l273, !tbaa !27
  %t594 = load ptr, ptr %l0, !tbaa !29
  %t596 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d259, i32 0, i32 1) }, 1
  %t597 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d259, i32 0, i32 1) }, 0
  %t599 = extractvalue { i64, ptr } %t593, 1
  %t600 = extractvalue { i64, ptr } %t593, 0
  %t601 = add i64 %t597, %t600
  %t602 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d260, i32 0, i32 1) }, 1
  %t603 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d260, i32 0, i32 1) }, 0
  %t604 = add i64 %t601, %t603
  %t605 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t604)
  call void @olang_textcopy(ptr %t605, ptr %t596, i64 %t597)
  %t606 = getelementptr i8, ptr %t605, i64 %t597
  call void @olang_textcopy(ptr %t606, ptr %t599, i64 %t600)
  %t607 = getelementptr i8, ptr %t606, i64 %t600
  call void @olang_textcopy(ptr %t607, ptr %t602, i64 %t603)
  %t608 = insertvalue { i64, ptr } undef, i64 %t604, 0
  %t609 = insertvalue { i64, ptr } %t608, ptr %t605, 1
  %t611 = extractvalue { i64, ptr } %t609, 0
  %t612 = extractvalue { i64, ptr } %t609, 1
  %t613 = mul i64 %t611, 1
  %t614 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t613)
  call void @llvm.memcpy.p0.p0.i64(ptr %t614, ptr %t612, i64 %t613, i1 false)
  %t615 = insertvalue { i64, ptr } undef, i64 %t611, 0
  %t616 = insertvalue { i64, ptr } %t615, ptr %t614, 1
  %t619 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s27, ptr %s27, ptr %t594, { i64, ptr } %t616)
  store { i64, ptr } %t619, ptr %l278
  br label %bb123
bb123:
  %t620 = load { i64, ptr }, ptr %l278, !tbaa !27
  store { i64, ptr } %t620, ptr %l18, !tbaa !27
  %t621 = load ptr, ptr %l0, !tbaa !29
  %t623 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s27, ptr %s27, ptr %t621, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d261, i32 0, i32 1) })
  store { i64, ptr } %t623, ptr %l280
  br label %bb124
bb124:
  %t624 = load { i64, ptr }, ptr %l280, !tbaa !27
  store { i64, ptr } %t624, ptr %l19, !tbaa !27
  %t625 = load ptr, ptr %l0, !tbaa !29
  %t627 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s27, ptr %s27, ptr %t625, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d262, i32 0, i32 1) })
  store { i64, ptr } %t627, ptr %l282
  br label %bb125
bb125:
  %t628 = load { i64, ptr }, ptr %l282, !tbaa !27
  store { i64, ptr } %t628, ptr %l20, !tbaa !27
  %t629 = load ptr, ptr %l0, !tbaa !29
  %t630 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t631 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t632 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t633 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d263, i32 0, i32 1) }, 1
  %t634 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d263, i32 0, i32 1) }, 0
  %t636 = extractvalue { i64, ptr } %t630, 1
  %t637 = extractvalue { i64, ptr } %t630, 0
  %t638 = add i64 %t634, %t637
  %t639 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d264, i32 0, i32 1) }, 1
  %t640 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d264, i32 0, i32 1) }, 0
  %t641 = add i64 %t638, %t640
  %t643 = extractvalue { i64, ptr } %t631, 1
  %t644 = extractvalue { i64, ptr } %t631, 0
  %t645 = add i64 %t641, %t644
  %t646 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d264, i32 0, i32 1) }, 1
  %t647 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d264, i32 0, i32 1) }, 0
  %t648 = add i64 %t645, %t647
  %t650 = extractvalue { i64, ptr } %t632, 1
  %t651 = extractvalue { i64, ptr } %t632, 0
  %t652 = add i64 %t648, %t651
  %t653 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t652)
  call void @olang_textcopy(ptr %t653, ptr %t633, i64 %t634)
  %t654 = getelementptr i8, ptr %t653, i64 %t634
  call void @olang_textcopy(ptr %t654, ptr %t636, i64 %t637)
  %t655 = getelementptr i8, ptr %t654, i64 %t637
  call void @olang_textcopy(ptr %t655, ptr %t639, i64 %t640)
  %t656 = getelementptr i8, ptr %t655, i64 %t640
  call void @olang_textcopy(ptr %t656, ptr %t643, i64 %t644)
  %t657 = getelementptr i8, ptr %t656, i64 %t644
  call void @olang_textcopy(ptr %t657, ptr %t646, i64 %t647)
  %t658 = getelementptr i8, ptr %t657, i64 %t647
  call void @olang_textcopy(ptr %t658, ptr %t650, i64 %t651)
  %t659 = insertvalue { i64, ptr } undef, i64 %t652, 0
  %t660 = insertvalue { i64, ptr } %t659, ptr %t653, 1
  %t662 = extractvalue { i64, ptr } %t660, 0
  %t663 = extractvalue { i64, ptr } %t660, 1
  %t664 = mul i64 %t662, 1
  %t665 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t664)
  call void @llvm.memcpy.p0.p0.i64(ptr %t665, ptr %t663, i64 %t664, i1 false)
  %t666 = insertvalue { i64, ptr } undef, i64 %t662, 0
  %t667 = insertvalue { i64, ptr } %t666, ptr %t665, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s27, ptr %t629, { i64, ptr } %t667)
  br label %bb126
bb126:
  %t670 = load ptr, ptr %l0, !tbaa !29
  %t671 = load { i64, ptr }, ptr %l19, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s27, ptr %t670, { i64, ptr } %t671)
  br label %bb127
bb127:
  %t674 = load ptr, ptr %l0, !tbaa !29
  %t675 = load i32, ptr %l16, !tbaa !23
  %t676 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d265, i32 0, i32 1) }, 1
  %t677 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d265, i32 0, i32 1) }, 0
  %t679 = sext i32 %t675 to i64
  %t680 = call i64 @__olang_fmt_i64(ptr null, i64 %t679)
  %t681 = add i64 %t677, %t680
  %t682 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d266, i32 0, i32 1) }, 1
  %t683 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d266, i32 0, i32 1) }, 0
  %t684 = add i64 %t681, %t683
  %t685 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t684)
  call void @olang_textcopy(ptr %t685, ptr %t676, i64 %t677)
  %t686 = getelementptr i8, ptr %t685, i64 %t677
  %t687 = call i64 @__olang_fmt_i64(ptr %t686, i64 %t679)
  %t688 = getelementptr i8, ptr %t686, i64 %t680
  call void @olang_textcopy(ptr %t688, ptr %t682, i64 %t683)
  %t689 = insertvalue { i64, ptr } undef, i64 %t684, 0
  %t690 = insertvalue { i64, ptr } %t689, ptr %t685, 1
  %t692 = extractvalue { i64, ptr } %t690, 0
  %t693 = extractvalue { i64, ptr } %t690, 1
  %t694 = mul i64 %t692, 1
  %t695 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t694)
  call void @llvm.memcpy.p0.p0.i64(ptr %t695, ptr %t693, i64 %t694, i1 false)
  %t696 = insertvalue { i64, ptr } undef, i64 %t692, 0
  %t697 = insertvalue { i64, ptr } %t696, ptr %t695, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s27, ptr %t674, { i64, ptr } %t697)
  br label %bb128
bb128:
  %t700 = load ptr, ptr %l0, !tbaa !29
  %t701 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t702 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d267, i32 0, i32 1) }, 1
  %t703 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d267, i32 0, i32 1) }, 0
  %t705 = extractvalue { i64, ptr } %t701, 1
  %t706 = extractvalue { i64, ptr } %t701, 0
  %t707 = add i64 %t703, %t706
  %t708 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t707)
  call void @olang_textcopy(ptr %t708, ptr %t702, i64 %t703)
  %t709 = getelementptr i8, ptr %t708, i64 %t703
  call void @olang_textcopy(ptr %t709, ptr %t705, i64 %t706)
  %t710 = insertvalue { i64, ptr } undef, i64 %t707, 0
  %t711 = insertvalue { i64, ptr } %t710, ptr %t708, 1
  %t713 = extractvalue { i64, ptr } %t711, 0
  %t714 = extractvalue { i64, ptr } %t711, 1
  %t715 = mul i64 %t713, 1
  %t716 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t715)
  call void @llvm.memcpy.p0.p0.i64(ptr %t716, ptr %t714, i64 %t715, i1 false)
  %t717 = insertvalue { i64, ptr } undef, i64 %t713, 0
  %t718 = insertvalue { i64, ptr } %t717, ptr %t716, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s27, ptr %t700, { i64, ptr } %t718)
  br label %bb129
bb129:
  %t721 = load ptr, ptr %l0, !tbaa !29
  %t722 = load { i64, ptr }, ptr %l20, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s27, ptr %t721, { i64, ptr } %t722)
  br label %bb130
bb130:
  call void @__olang_scope_close(ptr %s27)
  br label %bb139
bb131:
  %t725 = load ptr, ptr %l301, !tbaa !29
  %t726 = load i64, ptr %l303, !tbaa !24
  %t727 = load i64, ptr %l309, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ewalkEnd(ptr %v0, ptr %t725, i64 %t726, i64 %t727)
  br label %bb132
bb132:
  %t728 = load ptr, ptr %l0, !tbaa !29
  %t730 = getelementptr %"compiler/emit:fnEm", ptr %t728, i32 0, i32 0
  %t731 = load ptr, ptr %t730, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s33, ptr %t731, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d268, i32 0, i32 1) })
  br label %bb133
bb133:
  %t733 = load ptr, ptr %l0, !tbaa !29
  %t734 = load i32, ptr %l16, !tbaa !23
  %t735 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d269, i32 0, i32 1) }, 1
  %t736 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d269, i32 0, i32 1) }, 0
  %t738 = sext i32 %t734 to i64
  %t739 = call i64 @__olang_fmt_i64(ptr null, i64 %t738)
  %t740 = add i64 %t736, %t739
  %t741 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d270, i32 0, i32 1) }, 1
  %t742 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d270, i32 0, i32 1) }, 0
  %t743 = add i64 %t740, %t742
  %t744 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t743)
  call void @olang_textcopy(ptr %t744, ptr %t735, i64 %t736)
  %t745 = getelementptr i8, ptr %t744, i64 %t736
  %t746 = call i64 @__olang_fmt_i64(ptr %t745, i64 %t738)
  %t747 = getelementptr i8, ptr %t745, i64 %t739
  call void @olang_textcopy(ptr %t747, ptr %t741, i64 %t742)
  %t748 = insertvalue { i64, ptr } undef, i64 %t743, 0
  %t749 = insertvalue { i64, ptr } %t748, ptr %t744, 1
  %t751 = extractvalue { i64, ptr } %t749, 0
  %t752 = extractvalue { i64, ptr } %t749, 1
  %t753 = mul i64 %t751, 1
  %t754 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t753)
  call void @llvm.memcpy.p0.p0.i64(ptr %t754, ptr %t752, i64 %t753, i1 false)
  %t755 = insertvalue { i64, ptr } undef, i64 %t751, 0
  %t756 = insertvalue { i64, ptr } %t755, ptr %t754, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s33, ptr %t733, { i64, ptr } %t756)
  br label %bb134
bb134:
  %t759 = load ptr, ptr %l0, !tbaa !29
  %t761 = getelementptr %"compiler/emit:fnEm", ptr %t759, i32 0, i32 0
  %t762 = load ptr, ptr %t761, !tbaa !29
  %t764 = getelementptr %"compiler/emit:Emitter", ptr %t762, i32 0, i32 4
  %t765 = load i1, ptr %t764, !tbaa !21
  br i1 %t765, label %bb135, label %bb136
bb135:
  %t767 = load ptr, ptr %l0, !tbaa !29
  %t768 = load i32, ptr %l16, !tbaa !23
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eunwindPop(ptr %v0, ptr %t767, i32 %t768)
  br label %bb137
bb136:
  br label %bb138
bb137:
  br label %bb138
bb138:
  call void @__olang_scope_close(ptr %s33)
  br label %bb139
bb139:
  br label %bb312
bb140:
  %t771 = load ptr, ptr %l1, !tbaa !29
  store ptr %t771, ptr %l321, !tbaa !29
  store i1 false, ptr %l322, !tbaa !21
  %t772 = load ptr, ptr %l321, !tbaa !29
  %t773 = icmp ne ptr %t772, null
  br i1 %t773, label %bb141, label %bb142
bb141:
  %t775 = load ptr, ptr %l321, !tbaa !29
  %t776 = load i64, ptr %t775, !range !{i64 0, i64 18}
  %t778 = icmp eq i64 %t776, 12
  store i1 %t778, ptr %l322, !tbaa !21
  br label %bb142
bb142:
  %t779 = load i1, ptr %l322, !tbaa !21
  br i1 %t779, label %bb143, label %bb144
bb143:
  %t780 = load ptr, ptr %l1, !tbaa !29
  %t782 = getelementptr { i64, [21 x i64] }, ptr %t780, i32 0, i32 1
  %t783 = getelementptr { %"compiler/source:Span" }, ptr %t782, i32 0, i32 0
  %t784 = load %"compiler/source:Span", ptr %t783
  store %"compiler/source:Span" %t784, ptr %l21
  br label %bb145
bb144:
  br label %bb147
bb145:
  %t786 = load ptr, ptr %l0, !tbaa !29
  %t787 = load %"compiler/source:Span", ptr %l21
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2etrace(ptr %v0, ptr %t786, %"compiler/source:Span" %t787)
  br label %bb146
bb146:
  br label %bb312
bb147:
  %t790 = load ptr, ptr %l1, !tbaa !29
  store ptr %t790, ptr %l329, !tbaa !29
  store i1 false, ptr %l330, !tbaa !21
  %t791 = load ptr, ptr %l329, !tbaa !29
  %t792 = icmp ne ptr %t791, null
  br i1 %t792, label %bb148, label %bb149
bb148:
  %t794 = load ptr, ptr %l329, !tbaa !29
  %t795 = load i64, ptr %t794, !range !{i64 0, i64 18}
  %t797 = icmp eq i64 %t795, 13
  store i1 %t797, ptr %l330, !tbaa !21
  br label %bb149
bb149:
  %t798 = load i1, ptr %l330, !tbaa !21
  br i1 %t798, label %bb150, label %bb151
bb150:
  %t799 = load ptr, ptr %l1, !tbaa !29
  %t801 = getelementptr { i64, [21 x i64] }, ptr %t799, i32 0, i32 1
  %t802 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t801, i32 0, i32 1
  %t803 = load { i64, [4 x i64] }, ptr %t802
  store { i64, [4 x i64] } %t803, ptr %l22
  br label %bb152
bb151:
  br label %bb156
bb152:
  store %olang.scope zeroinitializer, ptr %s37
  %t805 = load ptr, ptr %l0, !tbaa !29
  %t807 = getelementptr %"compiler/emit:fnEm", ptr %t805, i32 0, i32 0
  %t808 = load ptr, ptr %t807, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s37, ptr %t808, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d271, i32 0, i32 1) })
  br label %bb153
bb153:
  %t810 = load ptr, ptr %l0, !tbaa !29
  store ptr %t810, ptr %l337, !tbaa !29
  %t811 = load ptr, ptr %l0, !tbaa !29
  %t812 = load { i64, [4 x i64] }, ptr %l22
  %t813 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t817 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s37, ptr %t811, { i64, [4 x i64] } %t812, i32 %t813)
  store { i64, ptr } %t817, ptr %l341
  br label %bb154
bb154:
  %t818 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d272, i32 0, i32 1) }, 1
  %t819 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d272, i32 0, i32 1) }, 0
  %t820 = load { i64, ptr }, ptr %l341, !tbaa !27
  %t821 = extractvalue { i64, ptr } %t820, 1
  %t822 = extractvalue { i64, ptr } %t820, 0
  %t823 = add i64 %t819, %t822
  %t824 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d273, i32 0, i32 1) }, 1
  %t825 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d273, i32 0, i32 1) }, 0
  %t826 = add i64 %t823, %t825
  %t827 = call ptr @__olang_scope_alloc(ptr %s37, i64 %t826)
  call void @olang_textcopy(ptr %t827, ptr %t818, i64 %t819)
  %t828 = getelementptr i8, ptr %t827, i64 %t819
  call void @olang_textcopy(ptr %t828, ptr %t821, i64 %t822)
  %t829 = getelementptr i8, ptr %t828, i64 %t822
  call void @olang_textcopy(ptr %t829, ptr %t824, i64 %t825)
  %t830 = insertvalue { i64, ptr } undef, i64 %t826, 0
  %t831 = insertvalue { i64, ptr } %t830, ptr %t827, 1
  %t833 = extractvalue { i64, ptr } %t831, 0
  %t834 = extractvalue { i64, ptr } %t831, 1
  %t835 = mul i64 %t833, 1
  %t836 = call ptr @__olang_scope_alloc(ptr %s37, i64 %t835)
  call void @llvm.memcpy.p0.p0.i64(ptr %t836, ptr %t834, i64 %t835, i1 false)
  %t837 = insertvalue { i64, ptr } undef, i64 %t833, 0
  %t838 = insertvalue { i64, ptr } %t837, ptr %t836, 1
  %t839 = load ptr, ptr %l337, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s37, ptr %t839, { i64, ptr } %t838)
  br label %bb155
bb155:
  call void @__olang_scope_close(ptr %s37)
  br label %bb312
bb156:
  %t841 = load ptr, ptr %l1, !tbaa !29
  store ptr %t841, ptr %l344, !tbaa !29
  store i1 false, ptr %l345, !tbaa !21
  %t842 = load ptr, ptr %l344, !tbaa !29
  %t843 = icmp ne ptr %t842, null
  br i1 %t843, label %bb157, label %bb158
bb157:
  %t845 = load ptr, ptr %l344, !tbaa !29
  %t846 = load i64, ptr %t845, !range !{i64 0, i64 18}
  %t848 = icmp eq i64 %t846, 14
  store i1 %t848, ptr %l345, !tbaa !21
  br label %bb158
bb158:
  %t849 = load i1, ptr %l345, !tbaa !21
  br i1 %t849, label %bb159, label %bb160
bb159:
  br label %bb161
bb160:
  br label %bb164
bb161:
  store %olang.scope zeroinitializer, ptr %s39
  %t850 = load ptr, ptr %l0, !tbaa !29
  %t852 = getelementptr %"compiler/emit:fnEm", ptr %t850, i32 0, i32 0
  %t853 = load ptr, ptr %t852, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s39, ptr %t853, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d274, i32 0, i32 1) })
  br label %bb162
bb162:
  %t855 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s39, ptr %t855, { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d275, i32 0, i32 1) })
  br label %bb163
bb163:
  call void @__olang_scope_close(ptr %s39)
  br label %bb312
bb164:
  %t857 = load ptr, ptr %l1, !tbaa !29
  store ptr %t857, ptr %l351, !tbaa !29
  store i1 false, ptr %l352, !tbaa !21
  %t858 = load ptr, ptr %l351, !tbaa !29
  %t859 = icmp ne ptr %t858, null
  br i1 %t859, label %bb165, label %bb166
bb165:
  %t861 = load ptr, ptr %l351, !tbaa !29
  %t862 = load i64, ptr %t861, !range !{i64 0, i64 18}
  %t864 = icmp eq i64 %t862, 17
  store i1 %t864, ptr %l352, !tbaa !21
  br label %bb166
bb166:
  %t865 = load i1, ptr %l352, !tbaa !21
  br i1 %t865, label %bb167, label %bb168
bb167:
  br label %bb169
bb168:
  br label %bb171
bb169:
  store %olang.scope zeroinitializer, ptr %s40
  %t866 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s40, ptr %t866, { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d276, i32 0, i32 1) })
  br label %bb170
bb170:
  call void @__olang_scope_close(ptr %s40)
  br label %bb312
bb171:
  %t868 = load ptr, ptr %l1, !tbaa !29
  store ptr %t868, ptr %l356, !tbaa !29
  store i1 false, ptr %l357, !tbaa !21
  %t869 = load ptr, ptr %l356, !tbaa !29
  %t870 = icmp ne ptr %t869, null
  br i1 %t870, label %bb172, label %bb173
bb172:
  %t872 = load ptr, ptr %l356, !tbaa !29
  %t873 = load i64, ptr %t872, !range !{i64 0, i64 18}
  %t875 = icmp eq i64 %t873, 15
  store i1 %t875, ptr %l357, !tbaa !21
  br label %bb173
bb173:
  %t876 = load i1, ptr %l357, !tbaa !21
  br i1 %t876, label %bb174, label %bb175
bb174:
  %t877 = load ptr, ptr %l1, !tbaa !29
  %t879 = getelementptr { i64, [21 x i64] }, ptr %t877, i32 0, i32 1
  %t880 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t879, i32 0, i32 1
  %t881 = load { i64, [4 x i64] }, ptr %t880
  store { i64, [4 x i64] } %t881, ptr %l23
  %t883 = load ptr, ptr %l1, !tbaa !29
  %t885 = getelementptr { i64, [21 x i64] }, ptr %t883, i32 0, i32 1
  %t886 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t885, i32 0, i32 2
  %t887 = load { i64, [4 x i64] }, ptr %t886
  store { i64, [4 x i64] } %t887, ptr %l24
  br label %bb176
bb175:
  br label %bb179
bb176:
  store %olang.scope zeroinitializer, ptr %s41
  %t889 = load ptr, ptr %l0, !tbaa !29
  store ptr %t889, ptr %l364, !tbaa !29
  %t890 = load { i64, [4 x i64] }, ptr %l23
  store { i64, [4 x i64] } %t890, ptr %l365
  %t891 = load ptr, ptr %l0, !tbaa !29
  %t892 = load { i64, [4 x i64] }, ptr %l24
  %t893 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t897 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s41, ptr %t891, { i64, [4 x i64] } %t892, i32 %t893)
  store { i64, ptr } %t897, ptr %l369
  br label %bb177
bb177:
  %t898 = load { i64, ptr }, ptr %l369, !tbaa !27
  %t899 = extractvalue { i64, ptr } %t898, 0
  %t900 = extractvalue { i64, ptr } %t898, 1
  %t901 = mul i64 %t899, 1
  %t902 = call ptr @__olang_scope_alloc(ptr %s41, i64 %t901)
  call void @llvm.memcpy.p0.p0.i64(ptr %t902, ptr %t900, i64 %t901, i1 false)
  %t903 = insertvalue { i64, ptr } undef, i64 %t899, 0
  %t904 = insertvalue { i64, ptr } %t903, ptr %t902, 1
  %t905 = load ptr, ptr %l364, !tbaa !29
  %t906 = load { i64, [4 x i64] }, ptr %l365
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eholders(ptr %v0, ptr %s41, ptr %t905, { i64, [4 x i64] } %t906, { i64, ptr } %t904)
  br label %bb178
bb178:
  call void @__olang_scope_close(ptr %s41)
  br label %bb312
bb179:
  %t908 = load ptr, ptr %l1, !tbaa !29
  store ptr %t908, ptr %l371, !tbaa !29
  store i1 false, ptr %l372, !tbaa !21
  %t909 = load ptr, ptr %l371, !tbaa !29
  %t910 = icmp ne ptr %t909, null
  br i1 %t910, label %bb180, label %bb181
bb180:
  %t912 = load ptr, ptr %l371, !tbaa !29
  %t913 = load i64, ptr %t912, !range !{i64 0, i64 18}
  %t915 = icmp eq i64 %t913, 16
  store i1 %t915, ptr %l372, !tbaa !21
  br label %bb181
bb181:
  %t916 = load i1, ptr %l372, !tbaa !21
  br i1 %t916, label %bb182, label %bb183
bb182:
  %t917 = load ptr, ptr %l1, !tbaa !29
  %t919 = getelementptr { i64, [21 x i64] }, ptr %t917, i32 0, i32 1
  %t920 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t919, i32 0, i32 1
  %t921 = load { i64, [4 x i64] }, ptr %t920
  store { i64, [4 x i64] } %t921, ptr %l25
  %t923 = load ptr, ptr %l1, !tbaa !29
  %t925 = getelementptr { i64, [21 x i64] }, ptr %t923, i32 0, i32 1
  %t926 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t925, i32 0, i32 2
  %t927 = load i32, ptr %t926
  store i32 %t927, ptr %l26, !tbaa !23
  %t929 = load ptr, ptr %l1, !tbaa !29
  %t931 = getelementptr { i64, [21 x i64] }, ptr %t929, i32 0, i32 1
  %t932 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t931, i32 0, i32 3
  %t933 = load %"compiler/mir:Range", ptr %t932
  store %"compiler/mir:Range" %t933, ptr %l27
  br label %bb184
bb183:
  br label %bb186
bb184:
  %t935 = load ptr, ptr %l0, !tbaa !29
  %t936 = load { i64, [4 x i64] }, ptr %l25
  %t937 = load i32, ptr %l26, !tbaa !23
  %t938 = load %"compiler/mir:Range", ptr %l27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ereclaim(ptr %v0, ptr %t935, { i64, [4 x i64] } %t936, i32 %t937, %"compiler/mir:Range" %t938)
  br label %bb185
bb185:
  br label %bb312
bb186:
  %t943 = load ptr, ptr %l1, !tbaa !29
  store ptr %t943, ptr %l385, !tbaa !29
  store i1 false, ptr %l386, !tbaa !21
  %t944 = load ptr, ptr %l385, !tbaa !29
  %t945 = icmp ne ptr %t944, null
  br i1 %t945, label %bb187, label %bb188
bb187:
  %t947 = load ptr, ptr %l385, !tbaa !29
  %t948 = load i64, ptr %t947, !range !{i64 0, i64 18}
  %t950 = icmp eq i64 %t948, 5
  store i1 %t950, ptr %l386, !tbaa !21
  br label %bb188
bb188:
  %t951 = load i1, ptr %l386, !tbaa !21
  br i1 %t951, label %bb189, label %bb190
bb189:
  %t952 = load ptr, ptr %l1, !tbaa !29
  %t954 = getelementptr { i64, [21 x i64] }, ptr %t952, i32 0, i32 1
  %t955 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t954, i32 0, i32 1
  %t956 = load { i64, [1 x i64] }, ptr %t955
  store { i64, [1 x i64] } %t956, ptr %l28
  %t958 = load ptr, ptr %l1, !tbaa !29
  %t960 = getelementptr { i64, [21 x i64] }, ptr %t958, i32 0, i32 1
  %t961 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t960, i32 0, i32 2
  %t962 = load i32, ptr %t961
  store i32 %t962, ptr %l29, !tbaa !23
  %t964 = load ptr, ptr %l1, !tbaa !29
  %t966 = getelementptr { i64, [21 x i64] }, ptr %t964, i32 0, i32 1
  %t967 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t966, i32 0, i32 3
  %t968 = load { i64, [4 x i64] }, ptr %t967
  store { i64, [4 x i64] } %t968, ptr %l30
  br label %bb191
bb190:
  br label %bb214
bb191:
  store %olang.scope zeroinitializer, ptr %s43
  %t970 = load ptr, ptr %l2, !tbaa !29
  store ptr %t970, ptr %l396, !tbaa !29
  %t971 = load i32, ptr %l29, !tbaa !23
  store i32 %t971, ptr %l397, !tbaa !23
  %t972 = load ptr, ptr %l0, !tbaa !29
  %t974 = getelementptr %"compiler/emit:fnEm", ptr %t972, i32 0, i32 0
  %t975 = load ptr, ptr %t974, !tbaa !29
  %t977 = getelementptr %"compiler/emit:Emitter", ptr %t975, i32 0, i32 39
  %t978 = load i32, ptr %l29, !tbaa !23
  %t981 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %t977, i32 %t978)
  %t982 = extractvalue { i32, i64 } %t981, 1
  %t983 = extractvalue { i32, i64 } %t981, 0
  store i32 %t983, ptr %l404
  %t984 = icmp ne i32 %t983, 0
  br i1 %t984, label %bb193, label %ok.985, !prof !99
ok.985:
  store i64 %t982, ptr %l403
  br label %bb192
bb192:
  %t986 = load i64, ptr %l403, !tbaa !24
  store i64 %t986, ptr %l398, !tbaa !24
  br label %bb195
bb193:
  br label %bb194
bb194:
  store i64 -1, ptr %l398, !tbaa !24
  br label %bb195
bb195:
  %t987 = load ptr, ptr %l396, !tbaa !29
  %t988 = load i32, ptr %l397, !tbaa !23
  %t989 = load i64, ptr %l398, !tbaa !24
  %t990 = call { i32, { i64, [2 x i64] } } @compiler_2fmir_2eFnKey_2eDropFn(ptr %v0, ptr %t987, i32 %t988, i64 %t989)
  %t991 = extractvalue { i32, { i64, [2 x i64] } } %t990, 1
  %t992 = extractvalue { i32, { i64, [2 x i64] } } %t990, 0
  store i32 %t992, ptr %l406
  %t993 = icmp ne i32 %t992, 0
  br i1 %t993, label %bb197, label %ok.994, !prof !99
ok.994:
  store { i64, [2 x i64] } %t991, ptr %l405
  br label %bb196
bb196:
  %t995 = load { i64, [2 x i64] }, ptr %l405
  store { i64, [2 x i64] } %t995, ptr %l395
  br label %bb201
bb197:
  br label %bb198
bb198:
  store %olang.scope zeroinitializer, ptr %s44
  %t996 = load ptr, ptr %l0, !tbaa !29
  store ptr %t996, ptr %l407, !tbaa !29
  %t997 = load ptr, ptr %l2, !tbaa !29
  %t998 = load i32, ptr %l29, !tbaa !23
  %t1000 = inttoptr i64 0 to ptr
  %t1003 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s44, ptr %t1000, ptr %t997, i32 %t998)
  store { i64, ptr } %t1003, ptr %l411
  br label %bb199
bb199:
  %t1004 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d277, i32 0, i32 1) }, 1
  %t1005 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d277, i32 0, i32 1) }, 0
  %t1006 = load { i64, ptr }, ptr %l411, !tbaa !27
  %t1007 = extractvalue { i64, ptr } %t1006, 1
  %t1008 = extractvalue { i64, ptr } %t1006, 0
  %t1009 = add i64 %t1005, %t1008
  %t1010 = call ptr @__olang_scope_alloc(ptr %s44, i64 %t1009)
  call void @olang_textcopy(ptr %t1010, ptr %t1004, i64 %t1005)
  %t1011 = getelementptr i8, ptr %t1010, i64 %t1005
  call void @olang_textcopy(ptr %t1011, ptr %t1007, i64 %t1008)
  %t1012 = insertvalue { i64, ptr } undef, i64 %t1009, 0
  %t1013 = insertvalue { i64, ptr } %t1012, ptr %t1010, 1
  %t1015 = extractvalue { i64, ptr } %t1013, 0
  %t1016 = extractvalue { i64, ptr } %t1013, 1
  %t1017 = mul i64 %t1015, 1
  %t1018 = call ptr @__olang_scope_alloc(ptr %s44, i64 %t1017)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1018, ptr %t1016, i64 %t1017, i1 false)
  %t1019 = insertvalue { i64, ptr } undef, i64 %t1015, 0
  %t1020 = insertvalue { i64, ptr } %t1019, ptr %t1018, 1
  %t1021 = load ptr, ptr %l407, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s44, ptr %t1021, { i64, ptr } %t1020)
  br label %bb200
bb200:
  call void @__olang_scope_close(ptr %s44)
  call void @__olang_scope_close(ptr %s43)
  br label %ret
bb201:
  %t1023 = load { i64, [2 x i64] }, ptr %l395
  store { i64, [2 x i64] } %t1023, ptr %l31
  %t1024 = load ptr, ptr %l0, !tbaa !29
  %t1026 = getelementptr %"compiler/emit:fnEm", ptr %t1024, i32 0, i32 0
  %t1027 = load ptr, ptr %t1026, !tbaa !29
  %t1028 = load { i64, [2 x i64] }, ptr %l31
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewant(ptr %v0, ptr %t1027, { i64, [2 x i64] } %t1028)
  br label %bb202
bb202:
  %t1031 = load ptr, ptr %l0, !tbaa !29
  %t1033 = getelementptr %"compiler/emit:fnEm", ptr %t1031, i32 0, i32 0
  %t1034 = load ptr, ptr %t1033, !tbaa !29
  %t1036 = getelementptr %"compiler/emit:Emitter", ptr %t1034, i32 0, i32 37
  %t1037 = load { i64, [2 x i64] }, ptr %l31
  %t1040 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_Hf0a5beca6f8aee4731a76bd327ae0a99(ptr %v0, ptr %t1036, { i64, [2 x i64] } %t1037)
  store i1 %t1040, ptr %l421
  br label %bb203
bb203:
  %t1041 = load i1, ptr %l421, !tbaa !21
  %t1042 = xor i1 %t1041, true
  br i1 %t1042, label %bb204, label %bb205
bb204:
  %t1044 = load ptr, ptr %l0, !tbaa !29
  %t1046 = getelementptr %"compiler/emit:fnEm", ptr %t1044, i32 0, i32 0
  %t1047 = load ptr, ptr %t1046, !tbaa !29
  %t1049 = getelementptr %"compiler/emit:Emitter", ptr %t1047, i32 0, i32 37
  %t1050 = load { i64, [2 x i64] }, ptr %l31
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_He6968003b8dd5762fa82ec44b4ee1fc9(ptr %v0, ptr %t1049, { i64, [2 x i64] } %t1050, i1 true)
  br label %bb206
bb205:
  br label %bb208
bb206:
  %t1053 = load ptr, ptr %l0, !tbaa !29
  %t1055 = getelementptr %"compiler/emit:fnEm", ptr %t1053, i32 0, i32 0
  %t1056 = load ptr, ptr %t1055, !tbaa !29
  %t1058 = getelementptr %"compiler/emit:Emitter", ptr %t1056, i32 0, i32 36
  %t1059 = load { i64, [2 x i64] }, ptr %l31
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %t1058, { i64, [2 x i64] } %t1059)
  br label %bb207
bb207:
  br label %bb208
bb208:
  %t1062 = load ptr, ptr %l0, !tbaa !29
  %t1064 = getelementptr %"compiler/emit:fnEm", ptr %t1062, i32 0, i32 0
  %t1065 = load ptr, ptr %t1064, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s43, ptr %t1065, { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d278, i32 0, i32 1) })
  br label %bb209
bb209:
  %t1067 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1067, ptr %l433, !tbaa !29
  %t1068 = load ptr, ptr %l0, !tbaa !29
  %t1069 = load { i64, [1 x i64] }, ptr %l28
  %t1072 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %s43, ptr %t1068, { i64, [1 x i64] } %t1069)
  store { i64, ptr } %t1072, ptr %l436
  br label %bb210
bb210:
  %t1073 = load ptr, ptr %l0, !tbaa !29
  %t1074 = load { i64, [4 x i64] }, ptr %l30
  %t1075 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t1079 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s43, ptr %t1073, { i64, [4 x i64] } %t1074, i32 %t1075)
  store { i64, ptr } %t1079, ptr %l440
  br label %bb211
bb211:
  %t1080 = load ptr, ptr %l0, !tbaa !29
  %t1082 = getelementptr %"compiler/emit:fnEm", ptr %t1080, i32 0, i32 0
  %t1083 = load ptr, ptr %t1082, !tbaa !29
  %t1084 = load { i64, [2 x i64] }, ptr %l31
  %t1087 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s43, ptr %t1083, { i64, [2 x i64] } %t1084)
  store { i64, ptr } %t1087, ptr %l444
  br label %bb212
bb212:
  %t1088 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d279, i32 0, i32 1) }, 1
  %t1089 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d279, i32 0, i32 1) }, 0
  %t1090 = load { i64, ptr }, ptr %l436, !tbaa !27
  %t1091 = extractvalue { i64, ptr } %t1090, 1
  %t1092 = extractvalue { i64, ptr } %t1090, 0
  %t1093 = add i64 %t1089, %t1092
  %t1094 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d280, i32 0, i32 1) }, 1
  %t1095 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d280, i32 0, i32 1) }, 0
  %t1096 = add i64 %t1093, %t1095
  %t1097 = load { i64, ptr }, ptr %l440, !tbaa !27
  %t1098 = extractvalue { i64, ptr } %t1097, 1
  %t1099 = extractvalue { i64, ptr } %t1097, 0
  %t1100 = add i64 %t1096, %t1099
  %t1101 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d281, i32 0, i32 1) }, 1
  %t1102 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d281, i32 0, i32 1) }, 0
  %t1103 = add i64 %t1100, %t1102
  %t1104 = load { i64, ptr }, ptr %l444, !tbaa !27
  %t1105 = extractvalue { i64, ptr } %t1104, 1
  %t1106 = extractvalue { i64, ptr } %t1104, 0
  %t1107 = add i64 %t1103, %t1106
  %t1108 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d282, i32 0, i32 1) }, 1
  %t1109 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d282, i32 0, i32 1) }, 0
  %t1110 = add i64 %t1107, %t1109
  %t1111 = call ptr @__olang_scope_alloc(ptr %s43, i64 %t1110)
  call void @olang_textcopy(ptr %t1111, ptr %t1088, i64 %t1089)
  %t1112 = getelementptr i8, ptr %t1111, i64 %t1089
  call void @olang_textcopy(ptr %t1112, ptr %t1091, i64 %t1092)
  %t1113 = getelementptr i8, ptr %t1112, i64 %t1092
  call void @olang_textcopy(ptr %t1113, ptr %t1094, i64 %t1095)
  %t1114 = getelementptr i8, ptr %t1113, i64 %t1095
  call void @olang_textcopy(ptr %t1114, ptr %t1098, i64 %t1099)
  %t1115 = getelementptr i8, ptr %t1114, i64 %t1099
  call void @olang_textcopy(ptr %t1115, ptr %t1101, i64 %t1102)
  %t1116 = getelementptr i8, ptr %t1115, i64 %t1102
  call void @olang_textcopy(ptr %t1116, ptr %t1105, i64 %t1106)
  %t1117 = getelementptr i8, ptr %t1116, i64 %t1106
  call void @olang_textcopy(ptr %t1117, ptr %t1108, i64 %t1109)
  %t1118 = insertvalue { i64, ptr } undef, i64 %t1110, 0
  %t1119 = insertvalue { i64, ptr } %t1118, ptr %t1111, 1
  %t1121 = extractvalue { i64, ptr } %t1119, 0
  %t1122 = extractvalue { i64, ptr } %t1119, 1
  %t1123 = mul i64 %t1121, 1
  %t1124 = call ptr @__olang_scope_alloc(ptr %s43, i64 %t1123)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1124, ptr %t1122, i64 %t1123, i1 false)
  %t1125 = insertvalue { i64, ptr } undef, i64 %t1121, 0
  %t1126 = insertvalue { i64, ptr } %t1125, ptr %t1124, 1
  %t1127 = load ptr, ptr %l433, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s43, ptr %t1127, { i64, ptr } %t1126)
  br label %bb213
bb213:
  call void @__olang_scope_close(ptr %s43)
  br label %bb312
bb214:
  %t1129 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1129, ptr %l447, !tbaa !29
  store i1 false, ptr %l448, !tbaa !21
  %t1130 = load ptr, ptr %l447, !tbaa !29
  %t1131 = icmp ne ptr %t1130, null
  br i1 %t1131, label %bb215, label %bb216
bb215:
  %t1133 = load ptr, ptr %l447, !tbaa !29
  %t1134 = load i64, ptr %t1133, !range !{i64 0, i64 18}
  %t1136 = icmp eq i64 %t1134, 6
  store i1 %t1136, ptr %l448, !tbaa !21
  br label %bb216
bb216:
  %t1137 = load i1, ptr %l448, !tbaa !21
  br i1 %t1137, label %bb217, label %bb218
bb217:
  %t1138 = load ptr, ptr %l1, !tbaa !29
  %t1140 = getelementptr { i64, [21 x i64] }, ptr %t1138, i32 0, i32 1
  %t1141 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue" }, ptr %t1140, i32 0, i32 1
  %t1142 = load %"compiler/mir:Lvalue", ptr %t1141
  store %"compiler/mir:Lvalue" %t1142, ptr %l32
  br label %bb219
bb218:
  br label %bb242
bb219:
  store %olang.scope zeroinitializer, ptr %s48
  %t1144 = load ptr, ptr %l0, !tbaa !29
  %t1145 = load %"compiler/mir:Lvalue", ptr %l32
  %t1148 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s48, ptr %t1144, %"compiler/mir:Lvalue" %t1145)
  store { { i64, ptr }, i32 } %t1148, ptr %l455
  br label %bb220
bb220:
  %t1149 = load { { i64, ptr }, i32 }, ptr %l455
  store { { i64, ptr }, i32 } %t1149, ptr %l33
  %t1150 = getelementptr { { i64, ptr }, i32 }, ptr %l33, i32 0, i32 0
  %t1151 = load { i64, ptr }, ptr %t1150, !tbaa !27
  store { i64, ptr } %t1151, ptr %l456, !tbaa !27
  %t1152 = load { i64, ptr }, ptr %l456, !tbaa !27
  %t1153 = extractvalue { i64, ptr } %t1152, 0
  store i64 %t1153, ptr %l457, !tbaa !24
  %t1154 = load i64, ptr %l457, !tbaa !24
  %t1155 = mul i64 %t1154, 1
  %t1156 = call ptr @__olang_scope_alloc(ptr %s48, i64 %t1155)
  %t1157 = insertvalue { i64, ptr } undef, i64 %t1154, 0
  %t1158 = insertvalue { i64, ptr } %t1157, ptr %t1156, 1
  store { i64, ptr } %t1158, ptr %l458, !tbaa !27
  %t1159 = getelementptr { i64, ptr }, ptr %l458, i32 0, i32 1
  %t1160 = load ptr, ptr %t1159, !tbaa !27
  %t1161 = getelementptr { i64, ptr }, ptr %l456, i32 0, i32 1
  %t1162 = load ptr, ptr %t1161, !tbaa !27
  %t1163 = load i64, ptr %l457, !tbaa !24
  %t1164 = mul i64 %t1163, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1160, ptr %t1162, i64 %t1164, i1 false)
  %t1165 = load { i64, ptr }, ptr %l458, !tbaa !27
  store { i64, ptr } %t1165, ptr %l34, !tbaa !27
  %t1166 = getelementptr { { i64, ptr }, i32 }, ptr %l33, i32 0, i32 1
  %t1167 = load i32, ptr %t1166, !tbaa !23
  store i32 %t1167, ptr %l35, !tbaa !23
  %t1169 = load ptr, ptr %l2, !tbaa !29
  %t1170 = load i32, ptr %l35, !tbaa !23
  %t1173 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t1169, i32 %t1170)
  store i1 %t1173, ptr %l462
  br label %bb221
bb221:
  %t1174 = load i1, ptr %l462, !tbaa !21
  %t1175 = xor i1 %t1174, true
  br i1 %t1175, label %bb222, label %bb223
bb222:
  %t1177 = load ptr, ptr %l2, !tbaa !29
  %t1178 = load i32, ptr %l35, !tbaa !23
  %t1181 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %t1177, i32 %t1178)
  store i1 %t1181, ptr %l467
  br label %bb224
bb223:
  store i1 false, ptr %l464, !tbaa !21
  br label %bb225
bb224:
  %t1182 = load i1, ptr %l467, !tbaa !21
  %t1183 = xor i1 %t1182, true
  store i1 %t1183, ptr %l464, !tbaa !21
  br label %bb225
bb225:
  %t1185 = load i1, ptr %l464, !tbaa !21
  br i1 %t1185, label %bb226, label %bb227
bb226:
  store %olang.scope zeroinitializer, ptr %s49
  %t1186 = load ptr, ptr %l0, !tbaa !29
  %t1188 = getelementptr %"compiler/emit:fnEm", ptr %t1186, i32 0, i32 0
  %t1189 = load ptr, ptr %t1188, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s49, ptr %t1189, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d283, i32 0, i32 1) })
  br label %bb228
bb227:
  br label %bb233
bb228:
  %t1191 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1191, ptr %l471, !tbaa !29
  %t1192 = load ptr, ptr %l0, !tbaa !29
  %t1193 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t1194 = load i32, ptr %l35, !tbaa !23
  %t1198 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eanchorRegion(ptr %v0, ptr %s48, ptr %s49, ptr %t1192, { i64, ptr } %t1193, i32 %t1194)
  store { i64, ptr } %t1198, ptr %l475
  br label %bb229
bb229:
  %t1199 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d284, i32 0, i32 1) }, 1
  %t1200 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d284, i32 0, i32 1) }, 0
  %t1201 = load { i64, ptr }, ptr %l475, !tbaa !27
  %t1202 = extractvalue { i64, ptr } %t1201, 1
  %t1203 = extractvalue { i64, ptr } %t1201, 0
  %t1204 = add i64 %t1200, %t1203
  %t1205 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d285, i32 0, i32 1) }, 1
  %t1206 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d285, i32 0, i32 1) }, 0
  %t1207 = add i64 %t1204, %t1206
  %t1208 = call ptr @__olang_scope_alloc(ptr %s49, i64 %t1207)
  call void @olang_textcopy(ptr %t1208, ptr %t1199, i64 %t1200)
  %t1209 = getelementptr i8, ptr %t1208, i64 %t1200
  call void @olang_textcopy(ptr %t1209, ptr %t1202, i64 %t1203)
  %t1210 = getelementptr i8, ptr %t1209, i64 %t1203
  call void @olang_textcopy(ptr %t1210, ptr %t1205, i64 %t1206)
  %t1211 = insertvalue { i64, ptr } undef, i64 %t1207, 0
  %t1212 = insertvalue { i64, ptr } %t1211, ptr %t1208, 1
  %t1214 = extractvalue { i64, ptr } %t1212, 0
  %t1215 = extractvalue { i64, ptr } %t1212, 1
  %t1216 = mul i64 %t1214, 1
  %t1217 = call ptr @__olang_scope_alloc(ptr %s49, i64 %t1216)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1217, ptr %t1215, i64 %t1216, i1 false)
  %t1218 = insertvalue { i64, ptr } undef, i64 %t1214, 0
  %t1219 = insertvalue { i64, ptr } %t1218, ptr %t1217, 1
  %t1220 = load ptr, ptr %l471, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s49, ptr %t1220, { i64, ptr } %t1219)
  br label %bb230
bb230:
  %t1222 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1222, ptr %l478, !tbaa !29
  %t1223 = load ptr, ptr %l0, !tbaa !29
  %t1224 = load i32, ptr %l35, !tbaa !23
  %t1227 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s49, ptr %t1223, i32 %t1224)
  store { i64, ptr } %t1227, ptr %l481
  br label %bb231
bb231:
  %t1228 = load { i64, ptr }, ptr %l481, !tbaa !27
  %t1229 = extractvalue { i64, ptr } %t1228, 0
  %t1230 = extractvalue { i64, ptr } %t1228, 1
  %t1231 = mul i64 %t1229, 1
  %t1232 = call ptr @__olang_scope_alloc(ptr %s49, i64 %t1231)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1232, ptr %t1230, i64 %t1231, i1 false)
  %t1233 = insertvalue { i64, ptr } undef, i64 %t1229, 0
  %t1234 = insertvalue { i64, ptr } %t1233, ptr %t1232, 1
  %t1235 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t1236 = load ptr, ptr %l478, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s49, ptr %s49, ptr %s48, ptr %s49, ptr %t1236, { i64, ptr } %t1234, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d286, i32 0, i32 1) }, { i64, ptr } %t1235, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d230, i32 0, i32 1) })
  br label %bb232
bb232:
  call void @__olang_scope_close(ptr %s49)
  call void @__olang_scope_close(ptr %s48)
  br label %ret
bb233:
  %t1239 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1239, ptr %l484, !tbaa !29
  %t1240 = load ptr, ptr %l0, !tbaa !29
  %t1241 = load i32, ptr %l35, !tbaa !23
  %t1244 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s48, ptr %t1240, i32 %t1241)
  store { i64, ptr } %t1244, ptr %l487
  br label %bb234
bb234:
  %t1245 = load { i64, ptr }, ptr %l487, !tbaa !27
  %t1246 = extractvalue { i64, ptr } %t1245, 0
  %t1247 = extractvalue { i64, ptr } %t1245, 1
  %t1248 = mul i64 %t1246, 1
  %t1249 = call ptr @__olang_scope_alloc(ptr %s48, i64 %t1248)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1249, ptr %t1247, i64 %t1248, i1 false)
  %t1250 = insertvalue { i64, ptr } undef, i64 %t1246, 0
  %t1251 = insertvalue { i64, ptr } %t1250, ptr %t1249, 1
  %t1252 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t1253 = load ptr, ptr %l484, !tbaa !29
  %t1256 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s48, ptr %s48, ptr %s48, ptr %s48, ptr %t1253, { i64, ptr } %t1251, { i64, ptr } %t1252, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) })
  store { i64, ptr } %t1256, ptr %l490
  br label %bb235
bb235:
  %t1257 = load { i64, ptr }, ptr %l490, !tbaa !27
  store { i64, ptr } %t1257, ptr %l36, !tbaa !27
  %t1258 = load ptr, ptr %l0, !tbaa !29
  %t1260 = getelementptr %"compiler/emit:fnEm", ptr %t1258, i32 0, i32 0
  %t1261 = load ptr, ptr %t1260, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s48, ptr %t1261, { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d287, i32 0, i32 1) })
  br label %bb236
bb236:
  %t1263 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1263, ptr %l493, !tbaa !29
  %t1264 = load ptr, ptr %l0, !tbaa !29
  %t1265 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t1266 = load i32, ptr %l35, !tbaa !23
  %t1270 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eobjectPtr(ptr %v0, ptr %s48, ptr %s48, ptr %t1264, { i64, ptr } %t1265, i32 %t1266)
  store { i64, ptr } %t1270, ptr %l497
  br label %bb237
bb237:
  %t1271 = load { i64, ptr }, ptr %l497, !tbaa !27
  %t1272 = extractvalue { i64, ptr } %t1271, 0
  store i64 %t1272, ptr %l498, !tbaa !24
  %t1273 = load i64, ptr %l498, !tbaa !24
  %t1274 = mul i64 %t1273, 1
  %t1275 = call ptr @__olang_scope_alloc(ptr %s48, i64 %t1274)
  %t1276 = insertvalue { i64, ptr } undef, i64 %t1273, 0
  %t1277 = insertvalue { i64, ptr } %t1276, ptr %t1275, 1
  store { i64, ptr } %t1277, ptr %l499, !tbaa !27
  %t1278 = getelementptr { i64, ptr }, ptr %l499, i32 0, i32 1
  %t1279 = load ptr, ptr %t1278, !tbaa !27
  %t1280 = getelementptr { i64, ptr }, ptr %l497, i32 0, i32 1
  %t1281 = load ptr, ptr %t1280, !tbaa !27
  %t1282 = load i64, ptr %l498, !tbaa !24
  %t1283 = mul i64 %t1282, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1279, ptr %t1281, i64 %t1283, i1 false)
  %t1284 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d288, i32 0, i32 1) }, 1
  %t1285 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d288, i32 0, i32 1) }, 0
  %t1286 = load { i64, ptr }, ptr %l499, !tbaa !27
  %t1287 = extractvalue { i64, ptr } %t1286, 1
  %t1288 = extractvalue { i64, ptr } %t1286, 0
  %t1289 = add i64 %t1285, %t1288
  %t1290 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d289, i32 0, i32 1) }, 1
  %t1291 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d289, i32 0, i32 1) }, 0
  %t1292 = add i64 %t1289, %t1291
  %t1293 = call ptr @__olang_scope_alloc(ptr %s48, i64 %t1292)
  call void @olang_textcopy(ptr %t1293, ptr %t1284, i64 %t1285)
  %t1294 = getelementptr i8, ptr %t1293, i64 %t1285
  call void @olang_textcopy(ptr %t1294, ptr %t1287, i64 %t1288)
  %t1295 = getelementptr i8, ptr %t1294, i64 %t1288
  call void @olang_textcopy(ptr %t1295, ptr %t1290, i64 %t1291)
  %t1296 = insertvalue { i64, ptr } undef, i64 %t1292, 0
  %t1297 = insertvalue { i64, ptr } %t1296, ptr %t1293, 1
  %t1299 = extractvalue { i64, ptr } %t1297, 0
  %t1300 = extractvalue { i64, ptr } %t1297, 1
  %t1301 = mul i64 %t1299, 1
  %t1302 = call ptr @__olang_scope_alloc(ptr %s48, i64 %t1301)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1302, ptr %t1300, i64 %t1301, i1 false)
  %t1303 = insertvalue { i64, ptr } undef, i64 %t1299, 0
  %t1304 = insertvalue { i64, ptr } %t1303, ptr %t1302, 1
  %t1305 = load ptr, ptr %l493, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s48, ptr %t1305, { i64, ptr } %t1304)
  br label %bb238
bb238:
  %t1307 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1307, ptr %l502, !tbaa !29
  %t1308 = load ptr, ptr %l0, !tbaa !29
  %t1309 = load i32, ptr %l35, !tbaa !23
  %t1312 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s48, ptr %t1308, i32 %t1309)
  store { i64, ptr } %t1312, ptr %l505
  br label %bb239
bb239:
  %t1313 = load { i64, ptr }, ptr %l505, !tbaa !27
  %t1314 = extractvalue { i64, ptr } %t1313, 0
  %t1315 = extractvalue { i64, ptr } %t1313, 1
  %t1316 = mul i64 %t1314, 1
  %t1317 = call ptr @__olang_scope_alloc(ptr %s48, i64 %t1316)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1317, ptr %t1315, i64 %t1316, i1 false)
  %t1318 = insertvalue { i64, ptr } undef, i64 %t1314, 0
  %t1319 = insertvalue { i64, ptr } %t1318, ptr %t1317, 1
  store { i64, ptr } %t1319, ptr %l506, !tbaa !27
  %t1320 = load ptr, ptr %l0, !tbaa !29
  %t1322 = getelementptr %"compiler/emit:fnEm", ptr %t1320, i32 0, i32 0
  %t1323 = load ptr, ptr %t1322, !tbaa !29
  %t1324 = load i32, ptr %l35, !tbaa !23
  %t1327 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2econstText(ptr %v0, ptr %s48, ptr %t1323, i32 %t1324, i64 0)
  store { i64, ptr } %t1327, ptr %l510
  br label %bb240
bb240:
  %t1328 = load { i64, ptr }, ptr %l510, !tbaa !27
  %t1329 = extractvalue { i64, ptr } %t1328, 0
  %t1330 = extractvalue { i64, ptr } %t1328, 1
  %t1331 = mul i64 %t1329, 1
  %t1332 = call ptr @__olang_scope_alloc(ptr %s48, i64 %t1331)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1332, ptr %t1330, i64 %t1331, i1 false)
  %t1333 = insertvalue { i64, ptr } undef, i64 %t1329, 0
  %t1334 = insertvalue { i64, ptr } %t1333, ptr %t1332, 1
  %t1335 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t1336 = load ptr, ptr %l502, !tbaa !29
  %t1337 = load { i64, ptr }, ptr %l506, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s48, ptr %s48, ptr %s48, ptr %s48, ptr %t1336, { i64, ptr } %t1337, { i64, ptr } %t1334, { i64, ptr } %t1335, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d230, i32 0, i32 1) })
  br label %bb241
bb241:
  call void @__olang_scope_close(ptr %s48)
  br label %bb312
bb242:
  %t1340 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1340, ptr %l513, !tbaa !29
  store i1 false, ptr %l514, !tbaa !21
  %t1341 = load ptr, ptr %l513, !tbaa !29
  %t1342 = icmp ne ptr %t1341, null
  br i1 %t1342, label %bb243, label %bb244
bb243:
  %t1344 = load ptr, ptr %l513, !tbaa !29
  %t1345 = load i64, ptr %t1344, !range !{i64 0, i64 18}
  %t1347 = icmp eq i64 %t1345, 7
  store i1 %t1347, ptr %l514, !tbaa !21
  br label %bb244
bb244:
  %t1348 = load i1, ptr %l514, !tbaa !21
  br i1 %t1348, label %bb245, label %bb246
bb245:
  %t1349 = load ptr, ptr %l1, !tbaa !29
  %t1351 = getelementptr { i64, [21 x i64] }, ptr %t1349, i32 0, i32 1
  %t1352 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue" }, ptr %t1351, i32 0, i32 1
  %t1353 = load %"compiler/mir:Lvalue", ptr %t1352
  store %"compiler/mir:Lvalue" %t1353, ptr %l37
  br label %bb247
bb246:
  br label %bb257
bb247:
  store %olang.scope zeroinitializer, ptr %s52
  %t1355 = load ptr, ptr %l0, !tbaa !29
  %t1356 = load %"compiler/mir:Lvalue", ptr %l37
  %t1359 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s52, ptr %t1355, %"compiler/mir:Lvalue" %t1356)
  store { { i64, ptr }, i32 } %t1359, ptr %l521
  br label %bb248
bb248:
  %t1360 = load { { i64, ptr }, i32 }, ptr %l521
  store { { i64, ptr }, i32 } %t1360, ptr %l38
  %t1361 = getelementptr { { i64, ptr }, i32 }, ptr %l38, i32 0, i32 0
  %t1362 = load { i64, ptr }, ptr %t1361, !tbaa !27
  store { i64, ptr } %t1362, ptr %l39, !tbaa !27
  %t1364 = getelementptr { { i64, ptr }, i32 }, ptr %l38, i32 0, i32 1
  %t1365 = load i32, ptr %t1364, !tbaa !23
  store i32 %t1365, ptr %l40, !tbaa !23
  %t1367 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1367, ptr %l524, !tbaa !29
  %t1368 = load ptr, ptr %l0, !tbaa !29
  %t1369 = load i32, ptr %l40, !tbaa !23
  %t1372 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s52, ptr %t1368, i32 %t1369)
  store { i64, ptr } %t1372, ptr %l527
  br label %bb249
bb249:
  %t1373 = load { i64, ptr }, ptr %l527, !tbaa !27
  %t1374 = extractvalue { i64, ptr } %t1373, 0
  %t1375 = extractvalue { i64, ptr } %t1373, 1
  %t1376 = mul i64 %t1374, 1
  %t1377 = call ptr @__olang_scope_alloc(ptr %s52, i64 %t1376)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1377, ptr %t1375, i64 %t1376, i1 false)
  %t1378 = insertvalue { i64, ptr } undef, i64 %t1374, 0
  %t1379 = insertvalue { i64, ptr } %t1378, ptr %t1377, 1
  %t1380 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t1381 = load ptr, ptr %l524, !tbaa !29
  %t1384 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s52, ptr %s52, ptr %s52, ptr %s52, ptr %t1381, { i64, ptr } %t1379, { i64, ptr } %t1380, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) })
  store { i64, ptr } %t1384, ptr %l530
  br label %bb250
bb250:
  %t1385 = load { i64, ptr }, ptr %l530, !tbaa !27
  store { i64, ptr } %t1385, ptr %l41, !tbaa !27
  %t1386 = load ptr, ptr %l0, !tbaa !29
  %t1388 = getelementptr %"compiler/emit:fnEm", ptr %t1386, i32 0, i32 0
  %t1389 = load ptr, ptr %t1388, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s52, ptr %t1389, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d290, i32 0, i32 1) })
  br label %bb251
bb251:
  %t1391 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1391, ptr %l533, !tbaa !29
  %t1392 = load ptr, ptr %l0, !tbaa !29
  %t1393 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t1394 = load i32, ptr %l40, !tbaa !23
  %t1398 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eobjectPtr(ptr %v0, ptr %s52, ptr %s52, ptr %t1392, { i64, ptr } %t1393, i32 %t1394)
  store { i64, ptr } %t1398, ptr %l537
  br label %bb252
bb252:
  %t1399 = load { i64, ptr }, ptr %l537, !tbaa !27
  %t1400 = extractvalue { i64, ptr } %t1399, 0
  store i64 %t1400, ptr %l538, !tbaa !24
  %t1401 = load i64, ptr %l538, !tbaa !24
  %t1402 = mul i64 %t1401, 1
  %t1403 = call ptr @__olang_scope_alloc(ptr %s52, i64 %t1402)
  %t1404 = insertvalue { i64, ptr } undef, i64 %t1401, 0
  %t1405 = insertvalue { i64, ptr } %t1404, ptr %t1403, 1
  store { i64, ptr } %t1405, ptr %l539, !tbaa !27
  %t1406 = getelementptr { i64, ptr }, ptr %l539, i32 0, i32 1
  %t1407 = load ptr, ptr %t1406, !tbaa !27
  %t1408 = getelementptr { i64, ptr }, ptr %l537, i32 0, i32 1
  %t1409 = load ptr, ptr %t1408, !tbaa !27
  %t1410 = load i64, ptr %l538, !tbaa !24
  %t1411 = mul i64 %t1410, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1407, ptr %t1409, i64 %t1411, i1 false)
  %t1412 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d291, i32 0, i32 1) }, 1
  %t1413 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d291, i32 0, i32 1) }, 0
  %t1414 = load { i64, ptr }, ptr %l539, !tbaa !27
  %t1415 = extractvalue { i64, ptr } %t1414, 1
  %t1416 = extractvalue { i64, ptr } %t1414, 0
  %t1417 = add i64 %t1413, %t1416
  %t1418 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d292, i32 0, i32 1) }, 1
  %t1419 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d292, i32 0, i32 1) }, 0
  %t1420 = add i64 %t1417, %t1419
  %t1421 = call ptr @__olang_scope_alloc(ptr %s52, i64 %t1420)
  call void @olang_textcopy(ptr %t1421, ptr %t1412, i64 %t1413)
  %t1422 = getelementptr i8, ptr %t1421, i64 %t1413
  call void @olang_textcopy(ptr %t1422, ptr %t1415, i64 %t1416)
  %t1423 = getelementptr i8, ptr %t1422, i64 %t1416
  call void @olang_textcopy(ptr %t1423, ptr %t1418, i64 %t1419)
  %t1424 = insertvalue { i64, ptr } undef, i64 %t1420, 0
  %t1425 = insertvalue { i64, ptr } %t1424, ptr %t1421, 1
  %t1427 = extractvalue { i64, ptr } %t1425, 0
  %t1428 = extractvalue { i64, ptr } %t1425, 1
  %t1429 = mul i64 %t1427, 1
  %t1430 = call ptr @__olang_scope_alloc(ptr %s52, i64 %t1429)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1430, ptr %t1428, i64 %t1429, i1 false)
  %t1431 = insertvalue { i64, ptr } undef, i64 %t1427, 0
  %t1432 = insertvalue { i64, ptr } %t1431, ptr %t1430, 1
  %t1433 = load ptr, ptr %l533, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s52, ptr %t1433, { i64, ptr } %t1432)
  br label %bb253
bb253:
  %t1435 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1435, ptr %l542, !tbaa !29
  %t1436 = load ptr, ptr %l0, !tbaa !29
  %t1437 = load i32, ptr %l40, !tbaa !23
  %t1440 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s52, ptr %t1436, i32 %t1437)
  store { i64, ptr } %t1440, ptr %l545
  br label %bb254
bb254:
  %t1441 = load { i64, ptr }, ptr %l545, !tbaa !27
  %t1442 = extractvalue { i64, ptr } %t1441, 0
  %t1443 = extractvalue { i64, ptr } %t1441, 1
  %t1444 = mul i64 %t1442, 1
  %t1445 = call ptr @__olang_scope_alloc(ptr %s52, i64 %t1444)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1445, ptr %t1443, i64 %t1444, i1 false)
  %t1446 = insertvalue { i64, ptr } undef, i64 %t1442, 0
  %t1447 = insertvalue { i64, ptr } %t1446, ptr %t1445, 1
  store { i64, ptr } %t1447, ptr %l546, !tbaa !27
  %t1448 = load ptr, ptr %l0, !tbaa !29
  %t1450 = getelementptr %"compiler/emit:fnEm", ptr %t1448, i32 0, i32 0
  %t1451 = load ptr, ptr %t1450, !tbaa !29
  %t1452 = load i32, ptr %l40, !tbaa !23
  %t1455 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2econstText(ptr %v0, ptr %s52, ptr %t1451, i32 %t1452, i64 0)
  store { i64, ptr } %t1455, ptr %l550
  br label %bb255
bb255:
  %t1456 = load { i64, ptr }, ptr %l550, !tbaa !27
  %t1457 = extractvalue { i64, ptr } %t1456, 0
  %t1458 = extractvalue { i64, ptr } %t1456, 1
  %t1459 = mul i64 %t1457, 1
  %t1460 = call ptr @__olang_scope_alloc(ptr %s52, i64 %t1459)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1460, ptr %t1458, i64 %t1459, i1 false)
  %t1461 = insertvalue { i64, ptr } undef, i64 %t1457, 0
  %t1462 = insertvalue { i64, ptr } %t1461, ptr %t1460, 1
  %t1463 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t1464 = load ptr, ptr %l542, !tbaa !29
  %t1465 = load { i64, ptr }, ptr %l546, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s52, ptr %s52, ptr %s52, ptr %s52, ptr %t1464, { i64, ptr } %t1465, { i64, ptr } %t1462, { i64, ptr } %t1463, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d230, i32 0, i32 1) })
  br label %bb256
bb256:
  call void @__olang_scope_close(ptr %s52)
  br label %bb312
bb257:
  %t1468 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1468, ptr %l553, !tbaa !29
  store i1 false, ptr %l554, !tbaa !21
  %t1469 = load ptr, ptr %l553, !tbaa !29
  %t1470 = icmp ne ptr %t1469, null
  br i1 %t1470, label %bb258, label %bb259
bb258:
  %t1472 = load ptr, ptr %l553, !tbaa !29
  %t1473 = load i64, ptr %t1472, !range !{i64 0, i64 18}
  %t1475 = icmp eq i64 %t1473, 8
  store i1 %t1475, ptr %l554, !tbaa !21
  br label %bb259
bb259:
  %t1476 = load i1, ptr %l554, !tbaa !21
  br i1 %t1476, label %bb260, label %bb261
bb260:
  %t1477 = load ptr, ptr %l1, !tbaa !29
  %t1479 = getelementptr { i64, [21 x i64] }, ptr %t1477, i32 0, i32 1
  %t1480 = getelementptr { %"compiler/source:Span", i32, %"compiler/mir:Lvalue" }, ptr %t1479, i32 0, i32 1
  %t1481 = load i32, ptr %t1480
  store i32 %t1481, ptr %l42, !tbaa !23
  %t1483 = load ptr, ptr %l1, !tbaa !29
  %t1485 = getelementptr { i64, [21 x i64] }, ptr %t1483, i32 0, i32 1
  %t1486 = getelementptr { %"compiler/source:Span", i32, %"compiler/mir:Lvalue" }, ptr %t1485, i32 0, i32 2
  %t1487 = load %"compiler/mir:Lvalue", ptr %t1486
  store %"compiler/mir:Lvalue" %t1487, ptr %l43
  br label %bb262
bb261:
  br label %bb271
bb262:
  store %olang.scope zeroinitializer, ptr %s54
  %t1489 = load ptr, ptr %l0, !tbaa !29
  %t1490 = load %"compiler/mir:Lvalue", ptr %l43
  %t1493 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s54, ptr %t1489, %"compiler/mir:Lvalue" %t1490)
  store { { i64, ptr }, i32 } %t1493, ptr %l563
  br label %bb263
bb263:
  %t1494 = load { { i64, ptr }, i32 }, ptr %l563
  store { { i64, ptr }, i32 } %t1494, ptr %l44
  %t1495 = getelementptr { { i64, ptr }, i32 }, ptr %l44, i32 0, i32 0
  %t1496 = load { i64, ptr }, ptr %t1495, !tbaa !27
  store { i64, ptr } %t1496, ptr %l564, !tbaa !27
  %t1497 = load { i64, ptr }, ptr %l564, !tbaa !27
  %t1498 = extractvalue { i64, ptr } %t1497, 0
  store i64 %t1498, ptr %l565, !tbaa !24
  %t1499 = load i64, ptr %l565, !tbaa !24
  %t1500 = mul i64 %t1499, 1
  %t1501 = call ptr @__olang_scope_alloc(ptr %s54, i64 %t1500)
  %t1502 = insertvalue { i64, ptr } undef, i64 %t1499, 0
  %t1503 = insertvalue { i64, ptr } %t1502, ptr %t1501, 1
  store { i64, ptr } %t1503, ptr %l566, !tbaa !27
  %t1504 = getelementptr { i64, ptr }, ptr %l566, i32 0, i32 1
  %t1505 = load ptr, ptr %t1504, !tbaa !27
  %t1506 = getelementptr { i64, ptr }, ptr %l564, i32 0, i32 1
  %t1507 = load ptr, ptr %t1506, !tbaa !27
  %t1508 = load i64, ptr %l565, !tbaa !24
  %t1509 = mul i64 %t1508, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1505, ptr %t1507, i64 %t1509, i1 false)
  %t1510 = load { i64, ptr }, ptr %l566, !tbaa !27
  store { i64, ptr } %t1510, ptr %l45, !tbaa !27
  %t1511 = getelementptr { { i64, ptr }, i32 }, ptr %l44, i32 0, i32 1
  %t1512 = load i32, ptr %t1511, !tbaa !23
  store i32 %t1512, ptr %l46, !tbaa !23
  %t1514 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1514, ptr %l568, !tbaa !29
  %t1515 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1515, ptr %l569, !tbaa !29
  %t1516 = load ptr, ptr %l0, !tbaa !29
  %t1517 = load i32, ptr %l42, !tbaa !23
  %t1520 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalAt(ptr %v0, ptr %s54, ptr %t1516, i32 %t1517)
  store { i64, ptr } %t1520, ptr %l572
  br label %bb264
bb264:
  %t1521 = load { i64, ptr }, ptr %l572, !tbaa !27
  %t1522 = extractvalue { i64, ptr } %t1521, 0
  %t1523 = extractvalue { i64, ptr } %t1521, 1
  %t1524 = mul i64 %t1522, 1
  %t1525 = call ptr @__olang_scope_alloc(ptr %s54, i64 %t1524)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1525, ptr %t1523, i64 %t1524, i1 false)
  %t1526 = insertvalue { i64, ptr } undef, i64 %t1522, 0
  %t1527 = insertvalue { i64, ptr } %t1526, ptr %t1525, 1
  %t1528 = load ptr, ptr %l569, !tbaa !29
  %t1530 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s54, ptr %s54, ptr %s54, ptr %s54, ptr %t1528, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d293, i32 0, i32 1) }, { i64, ptr } %t1527, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) })
  store { i64, ptr } %t1530, ptr %l574
  br label %bb265
bb265:
  %t1531 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d294, i32 0, i32 1) }, 1
  %t1532 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d294, i32 0, i32 1) }, 0
  %t1533 = load { i64, ptr }, ptr %l574, !tbaa !27
  %t1534 = extractvalue { i64, ptr } %t1533, 1
  %t1535 = extractvalue { i64, ptr } %t1533, 0
  %t1536 = add i64 %t1532, %t1535
  %t1537 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d295, i32 0, i32 1) }, 1
  %t1538 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d295, i32 0, i32 1) }, 0
  %t1539 = add i64 %t1536, %t1538
  %t1540 = call ptr @__olang_scope_alloc(ptr %s54, i64 %t1539)
  call void @olang_textcopy(ptr %t1540, ptr %t1531, i64 %t1532)
  %t1541 = getelementptr i8, ptr %t1540, i64 %t1532
  call void @olang_textcopy(ptr %t1541, ptr %t1534, i64 %t1535)
  %t1542 = getelementptr i8, ptr %t1541, i64 %t1535
  call void @olang_textcopy(ptr %t1542, ptr %t1537, i64 %t1538)
  %t1543 = insertvalue { i64, ptr } undef, i64 %t1539, 0
  %t1544 = insertvalue { i64, ptr } %t1543, ptr %t1540, 1
  %t1546 = extractvalue { i64, ptr } %t1544, 0
  %t1547 = extractvalue { i64, ptr } %t1544, 1
  %t1548 = mul i64 %t1546, 1
  %t1549 = call ptr @__olang_scope_alloc(ptr %s54, i64 %t1548)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1549, ptr %t1547, i64 %t1548, i1 false)
  %t1550 = insertvalue { i64, ptr } undef, i64 %t1546, 0
  %t1551 = insertvalue { i64, ptr } %t1550, ptr %t1549, 1
  %t1552 = load ptr, ptr %l568, !tbaa !29
  %t1554 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s54, ptr %s54, ptr %t1552, { i64, ptr } %t1551)
  store { i64, ptr } %t1554, ptr %l577
  br label %bb266
bb266:
  %t1555 = load { i64, ptr }, ptr %l577, !tbaa !27
  store { i64, ptr } %t1555, ptr %l47, !tbaa !27
  %t1556 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1556, ptr %l578, !tbaa !29
  %t1557 = load ptr, ptr %l0, !tbaa !29
  %t1558 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t1559 = load i32, ptr %l46, !tbaa !23
  %t1563 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eanchorRegion(ptr %v0, ptr %s54, ptr %s54, ptr %t1557, { i64, ptr } %t1558, i32 %t1559)
  store { i64, ptr } %t1563, ptr %l582
  br label %bb267
bb267:
  %t1564 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t1565 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d296, i32 0, i32 1) }, 1
  %t1566 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d296, i32 0, i32 1) }, 0
  %t1567 = load { i64, ptr }, ptr %l582, !tbaa !27
  %t1568 = extractvalue { i64, ptr } %t1567, 1
  %t1569 = extractvalue { i64, ptr } %t1567, 0
  %t1570 = add i64 %t1566, %t1569
  %t1571 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d297, i32 0, i32 1) }, 1
  %t1572 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d297, i32 0, i32 1) }, 0
  %t1573 = add i64 %t1570, %t1572
  %t1575 = extractvalue { i64, ptr } %t1564, 1
  %t1576 = extractvalue { i64, ptr } %t1564, 0
  %t1577 = add i64 %t1573, %t1576
  %t1578 = call ptr @__olang_scope_alloc(ptr %s54, i64 %t1577)
  call void @olang_textcopy(ptr %t1578, ptr %t1565, i64 %t1566)
  %t1579 = getelementptr i8, ptr %t1578, i64 %t1566
  call void @olang_textcopy(ptr %t1579, ptr %t1568, i64 %t1569)
  %t1580 = getelementptr i8, ptr %t1579, i64 %t1569
  call void @olang_textcopy(ptr %t1580, ptr %t1571, i64 %t1572)
  %t1581 = getelementptr i8, ptr %t1580, i64 %t1572
  call void @olang_textcopy(ptr %t1581, ptr %t1575, i64 %t1576)
  %t1582 = insertvalue { i64, ptr } undef, i64 %t1577, 0
  %t1583 = insertvalue { i64, ptr } %t1582, ptr %t1578, 1
  %t1585 = extractvalue { i64, ptr } %t1583, 0
  %t1586 = extractvalue { i64, ptr } %t1583, 1
  %t1587 = mul i64 %t1585, 1
  %t1588 = call ptr @__olang_scope_alloc(ptr %s54, i64 %t1587)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1588, ptr %t1586, i64 %t1587, i1 false)
  %t1589 = insertvalue { i64, ptr } undef, i64 %t1585, 0
  %t1590 = insertvalue { i64, ptr } %t1589, ptr %t1588, 1
  %t1591 = load ptr, ptr %l578, !tbaa !29
  %t1593 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s54, ptr %s54, ptr %t1591, { i64, ptr } %t1590)
  store { i64, ptr } %t1593, ptr %l586
  br label %bb268
bb268:
  %t1594 = load { i64, ptr }, ptr %l586, !tbaa !27
  store { i64, ptr } %t1594, ptr %l48, !tbaa !27
  %t1595 = load ptr, ptr %l0, !tbaa !29
  %t1597 = getelementptr %"compiler/emit:fnEm", ptr %t1595, i32 0, i32 0
  %t1598 = load ptr, ptr %t1597, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s54, ptr %t1598, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d298, i32 0, i32 1) })
  br label %bb269
bb269:
  %t1600 = load ptr, ptr %l0, !tbaa !29
  %t1601 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t1602 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t1603 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d299, i32 0, i32 1) }, 1
  %t1604 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d299, i32 0, i32 1) }, 0
  %t1606 = extractvalue { i64, ptr } %t1601, 1
  %t1607 = extractvalue { i64, ptr } %t1601, 0
  %t1608 = add i64 %t1604, %t1607
  %t1609 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d300, i32 0, i32 1) }, 1
  %t1610 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d300, i32 0, i32 1) }, 0
  %t1611 = add i64 %t1608, %t1610
  %t1613 = extractvalue { i64, ptr } %t1602, 1
  %t1614 = extractvalue { i64, ptr } %t1602, 0
  %t1615 = add i64 %t1611, %t1614
  %t1616 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d301, i32 0, i32 1) }, 1
  %t1617 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d301, i32 0, i32 1) }, 0
  %t1618 = add i64 %t1615, %t1617
  %t1619 = call ptr @__olang_scope_alloc(ptr %s54, i64 %t1618)
  call void @olang_textcopy(ptr %t1619, ptr %t1603, i64 %t1604)
  %t1620 = getelementptr i8, ptr %t1619, i64 %t1604
  call void @olang_textcopy(ptr %t1620, ptr %t1606, i64 %t1607)
  %t1621 = getelementptr i8, ptr %t1620, i64 %t1607
  call void @olang_textcopy(ptr %t1621, ptr %t1609, i64 %t1610)
  %t1622 = getelementptr i8, ptr %t1621, i64 %t1610
  call void @olang_textcopy(ptr %t1622, ptr %t1613, i64 %t1614)
  %t1623 = getelementptr i8, ptr %t1622, i64 %t1614
  call void @olang_textcopy(ptr %t1623, ptr %t1616, i64 %t1617)
  %t1624 = insertvalue { i64, ptr } undef, i64 %t1618, 0
  %t1625 = insertvalue { i64, ptr } %t1624, ptr %t1619, 1
  %t1627 = extractvalue { i64, ptr } %t1625, 0
  %t1628 = extractvalue { i64, ptr } %t1625, 1
  %t1629 = mul i64 %t1627, 1
  %t1630 = call ptr @__olang_scope_alloc(ptr %s54, i64 %t1629)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1630, ptr %t1628, i64 %t1629, i1 false)
  %t1631 = insertvalue { i64, ptr } undef, i64 %t1627, 0
  %t1632 = insertvalue { i64, ptr } %t1631, ptr %t1630, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s54, ptr %t1600, { i64, ptr } %t1632)
  br label %bb270
bb270:
  call void @__olang_scope_close(ptr %s54)
  br label %bb312
bb271:
  %t1635 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1635, ptr %l594, !tbaa !29
  store i1 false, ptr %l595, !tbaa !21
  %t1636 = load ptr, ptr %l594, !tbaa !29
  %t1637 = icmp ne ptr %t1636, null
  br i1 %t1637, label %bb272, label %bb273
bb272:
  %t1639 = load ptr, ptr %l594, !tbaa !29
  %t1640 = load i64, ptr %t1639, !range !{i64 0, i64 18}
  %t1642 = icmp eq i64 %t1640, 9
  store i1 %t1642, ptr %l595, !tbaa !21
  br label %bb273
bb273:
  %t1643 = load i1, ptr %l595, !tbaa !21
  br i1 %t1643, label %bb274, label %bb275
bb274:
  %t1644 = load ptr, ptr %l1, !tbaa !29
  %t1646 = getelementptr { i64, [21 x i64] }, ptr %t1644, i32 0, i32 1
  %t1647 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t1646, i32 0, i32 1
  %t1648 = load { i64, [1 x i64] }, ptr %t1647
  store { i64, [1 x i64] } %t1648, ptr %l49
  %t1650 = load ptr, ptr %l1, !tbaa !29
  %t1652 = getelementptr { i64, [21 x i64] }, ptr %t1650, i32 0, i32 1
  %t1653 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t1652, i32 0, i32 2
  %t1654 = load i32, ptr %t1653, !range !{i32 0, i32 8}
  store i32 %t1654, ptr %l50
  %t1656 = load ptr, ptr %l1, !tbaa !29
  %t1658 = getelementptr { i64, [21 x i64] }, ptr %t1656, i32 0, i32 1
  %t1659 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t1658, i32 0, i32 3
  %t1660 = load { i64, [4 x i64] }, ptr %t1659
  store { i64, [4 x i64] } %t1660, ptr %l51
  br label %bb276
bb275:
  br label %bb285
bb276:
  store %olang.scope zeroinitializer, ptr %s58
  %t1662 = load ptr, ptr %l0, !tbaa !29
  %t1663 = load { i64, [1 x i64] }, ptr %l49
  %t1666 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2edirectRef(ptr %v0, ptr %t1662, { i64, [1 x i64] } %t1663)
  store i1 %t1666, ptr %l606
  br label %bb277
bb277:
  %t1667 = load i1, ptr %l606, !tbaa !21
  br i1 %t1667, label %bb278, label %bb279
bb278:
  %t1668 = load ptr, ptr %l0, !tbaa !29
  %t1670 = getelementptr %"compiler/emit:fnEm", ptr %t1668, i32 0, i32 26
  %t1671 = load i32, ptr %l50, !range !{i32 0, i32 8}
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aWriteKind_3e_2ePush_3ccompiler_2fmir_3aWriteKind_3e(ptr %v0, ptr %t1670, i32 %t1671)
  br label %bb280
bb279:
  br label %bb282
bb280:
  %t1674 = load ptr, ptr %l0, !tbaa !29
  %t1676 = getelementptr %"compiler/emit:fnEm", ptr %t1674, i32 0, i32 27
  %t1677 = load { i64, [4 x i64] }, ptr %l51
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2ePush_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t1676, { i64, [4 x i64] } %t1677)
  br label %bb281
bb281:
  call void @__olang_scope_close(ptr %s58)
  br label %ret
bb282:
  %t1680 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1680, ptr %l613, !tbaa !29
  %t1681 = load ptr, ptr %l0, !tbaa !29
  %t1682 = load { i64, [1 x i64] }, ptr %l49
  %t1685 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %s58, ptr %t1681, { i64, [1 x i64] } %t1682)
  store { i64, ptr } %t1685, ptr %l616
  br label %bb283
bb283:
  %t1686 = load { i64, ptr }, ptr %l616, !tbaa !27
  %t1687 = extractvalue { i64, ptr } %t1686, 0
  %t1688 = extractvalue { i64, ptr } %t1686, 1
  %t1689 = mul i64 %t1687, 1
  %t1690 = call ptr @__olang_scope_alloc(ptr %s58, i64 %t1689)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1690, ptr %t1688, i64 %t1689, i1 false)
  %t1691 = insertvalue { i64, ptr } undef, i64 %t1687, 0
  %t1692 = insertvalue { i64, ptr } %t1691, ptr %t1690, 1
  %t1693 = load i32, ptr %l50, !range !{i32 0, i32 8}
  %t1694 = load { i64, [4 x i64] }, ptr %l51
  %t1695 = load ptr, ptr %l613, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ewrite(ptr %v0, ptr %s58, ptr %t1695, { i64, ptr } %t1692, i32 %t1693, { i64, [4 x i64] } %t1694)
  br label %bb284
bb284:
  call void @__olang_scope_close(ptr %s58)
  br label %bb312
bb285:
  %t1699 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1699, ptr %l620, !tbaa !29
  store i1 false, ptr %l621, !tbaa !21
  %t1700 = load ptr, ptr %l620, !tbaa !29
  %t1701 = icmp ne ptr %t1700, null
  br i1 %t1701, label %bb286, label %bb287
bb286:
  %t1703 = load ptr, ptr %l620, !tbaa !29
  %t1704 = load i64, ptr %t1703, !range !{i64 0, i64 18}
  %t1706 = icmp eq i64 %t1704, 10
  store i1 %t1706, ptr %l621, !tbaa !21
  br label %bb287
bb287:
  %t1707 = load i1, ptr %l621, !tbaa !21
  br i1 %t1707, label %bb288, label %bb289
bb288:
  %t1708 = load ptr, ptr %l1, !tbaa !29
  %t1710 = getelementptr { i64, [21 x i64] }, ptr %t1708, i32 0, i32 1
  %t1711 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t1710, i32 0, i32 1
  %t1712 = load %"compiler/mir:Lvalue", ptr %t1711
  store %"compiler/mir:Lvalue" %t1712, ptr %l52
  %t1714 = load ptr, ptr %l1, !tbaa !29
  %t1716 = getelementptr { i64, [21 x i64] }, ptr %t1714, i32 0, i32 1
  %t1717 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t1716, i32 0, i32 2
  %t1718 = load %"compiler/mir:Lvalue", ptr %t1717
  store %"compiler/mir:Lvalue" %t1718, ptr %l53
  %t1720 = load ptr, ptr %l1, !tbaa !29
  %t1722 = getelementptr { i64, [21 x i64] }, ptr %t1720, i32 0, i32 1
  %t1723 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t1722, i32 0, i32 3
  %t1724 = load { i64, [4 x i64] }, ptr %t1723
  store { i64, [4 x i64] } %t1724, ptr %l54
  br label %bb290
bb289:
  br label %bb303
bb290:
  store %olang.scope zeroinitializer, ptr %s60
  %t1726 = load ptr, ptr %l0, !tbaa !29
  %t1727 = load %"compiler/mir:Lvalue", ptr %l52
  %t1730 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edataPtr(ptr %v0, ptr %s60, ptr %t1726, %"compiler/mir:Lvalue" %t1727)
  store { i64, ptr } %t1730, ptr %l632
  br label %bb291
bb291:
  %t1731 = load { i64, ptr }, ptr %l632, !tbaa !27
  store { i64, ptr } %t1731, ptr %l55, !tbaa !27
  %t1732 = load ptr, ptr %l0, !tbaa !29
  %t1733 = load %"compiler/mir:Lvalue", ptr %l53
  %t1736 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edataPtr(ptr %v0, ptr %s60, ptr %t1732, %"compiler/mir:Lvalue" %t1733)
  store { i64, ptr } %t1736, ptr %l635
  br label %bb292
bb292:
  %t1737 = load { i64, ptr }, ptr %l635, !tbaa !27
  store { i64, ptr } %t1737, ptr %l56, !tbaa !27
  %t1738 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1738, ptr %l636, !tbaa !29
  %t1739 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1739, ptr %l637, !tbaa !29
  %t1740 = load ptr, ptr %l0, !tbaa !29
  %t1741 = load %"compiler/mir:Lvalue", ptr %l52
  %t1744 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eplaceType(ptr %v0, ptr %t1740, %"compiler/mir:Lvalue" %t1741)
  store i32 %t1744, ptr %l640
  br label %bb293
bb293:
  %t1745 = load ptr, ptr %l637, !tbaa !29
  %t1746 = load i32, ptr %l640, !tbaa !23
  %t1747 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %t1745, i32 %t1746)
  store i32 %t1747, ptr %l641
  br label %bb294
bb294:
  %t1748 = load ptr, ptr %l636, !tbaa !29
  %t1749 = load i32, ptr %l641, !tbaa !23
  %t1750 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t1748, i32 %t1749)
  store i32 %t1750, ptr %l642
  br label %bb295
bb295:
  %t1751 = load i32, ptr %l642, !tbaa !23
  store i32 %t1751, ptr %l57, !tbaa !23
  %t1752 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1752, ptr %l643, !tbaa !29
  %t1753 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1753, ptr %l644, !tbaa !29
  %t1754 = load ptr, ptr %l0, !tbaa !29
  %t1755 = load { i64, [4 x i64] }, ptr %l54
  %t1756 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t1760 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s60, ptr %t1754, { i64, [4 x i64] } %t1755, i32 %t1756)
  store { i64, ptr } %t1760, ptr %l648
  br label %bb296
bb296:
  %t1761 = load { i64, ptr }, ptr %l648, !tbaa !27
  %t1762 = extractvalue { i64, ptr } %t1761, 0
  %t1763 = extractvalue { i64, ptr } %t1761, 1
  %t1764 = mul i64 %t1762, 1
  %t1765 = call ptr @__olang_scope_alloc(ptr %s60, i64 %t1764)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1765, ptr %t1763, i64 %t1764, i1 false)
  %t1766 = insertvalue { i64, ptr } undef, i64 %t1762, 0
  %t1767 = insertvalue { i64, ptr } %t1766, ptr %t1765, 1
  store { i64, ptr } %t1767, ptr %l649, !tbaa !27
  %t1768 = load ptr, ptr %l0, !tbaa !29
  %t1769 = load { i64, [4 x i64] }, ptr %l54
  %t1772 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t1768, { i64, [4 x i64] } %t1769)
  store i32 %t1772, ptr %l652
  br label %bb297
bb297:
  %t1773 = load ptr, ptr %l644, !tbaa !29
  %t1774 = load { i64, ptr }, ptr %l649, !tbaa !27
  %t1775 = load i32, ptr %l652, !tbaa !23
  %t1776 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eindex(ptr %v0, ptr %s60, ptr %s60, ptr %t1773, { i64, ptr } %t1774, i32 %t1775)
  store { i64, ptr } %t1776, ptr %l653
  br label %bb298
bb298:
  %t1777 = load ptr, ptr %l0, !tbaa !29
  %t1778 = load i32, ptr %l57, !tbaa !23
  %t1781 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t1777, i32 %t1778)
  store i64 %t1781, ptr %l656
  br label %bb299
bb299:
  %t1782 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d302, i32 0, i32 1) }, 1
  %t1783 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d302, i32 0, i32 1) }, 0
  %t1784 = load { i64, ptr }, ptr %l653, !tbaa !27
  %t1785 = extractvalue { i64, ptr } %t1784, 1
  %t1786 = extractvalue { i64, ptr } %t1784, 0
  %t1787 = add i64 %t1783, %t1786
  %t1788 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d303, i32 0, i32 1) }, 1
  %t1789 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d303, i32 0, i32 1) }, 0
  %t1790 = add i64 %t1787, %t1789
  %t1791 = load i64, ptr %l656, !tbaa !24
  %t1792 = call i64 @__olang_fmt_i64(ptr null, i64 %t1791)
  %t1793 = add i64 %t1790, %t1792
  %t1794 = call ptr @__olang_scope_alloc(ptr %s60, i64 %t1793)
  call void @olang_textcopy(ptr %t1794, ptr %t1782, i64 %t1783)
  %t1795 = getelementptr i8, ptr %t1794, i64 %t1783
  call void @olang_textcopy(ptr %t1795, ptr %t1785, i64 %t1786)
  %t1796 = getelementptr i8, ptr %t1795, i64 %t1786
  call void @olang_textcopy(ptr %t1796, ptr %t1788, i64 %t1789)
  %t1797 = getelementptr i8, ptr %t1796, i64 %t1789
  %t1798 = call i64 @__olang_fmt_i64(ptr %t1797, i64 %t1791)
  %t1799 = insertvalue { i64, ptr } undef, i64 %t1793, 0
  %t1800 = insertvalue { i64, ptr } %t1799, ptr %t1794, 1
  %t1802 = extractvalue { i64, ptr } %t1800, 0
  %t1803 = extractvalue { i64, ptr } %t1800, 1
  %t1804 = mul i64 %t1802, 1
  %t1805 = call ptr @__olang_scope_alloc(ptr %s60, i64 %t1804)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1805, ptr %t1803, i64 %t1804, i1 false)
  %t1806 = insertvalue { i64, ptr } undef, i64 %t1802, 0
  %t1807 = insertvalue { i64, ptr } %t1806, ptr %t1805, 1
  %t1808 = load ptr, ptr %l643, !tbaa !29
  %t1810 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s60, ptr %s60, ptr %t1808, { i64, ptr } %t1807)
  store { i64, ptr } %t1810, ptr %l659
  br label %bb300
bb300:
  %t1811 = load { i64, ptr }, ptr %l659, !tbaa !27
  store { i64, ptr } %t1811, ptr %l58, !tbaa !27
  %t1812 = load ptr, ptr %l0, !tbaa !29
  %t1814 = getelementptr %"compiler/emit:fnEm", ptr %t1812, i32 0, i32 0
  %t1815 = load ptr, ptr %t1814, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s60, ptr %s60, ptr %t1815, { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d304, i32 0, i32 1) }, { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d305, i32 0, i32 1) })
  br label %bb301
bb301:
  %t1817 = load ptr, ptr %l0, !tbaa !29
  %t1818 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t1819 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t1820 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t1821 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d306, i32 0, i32 1) }, 1
  %t1822 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d306, i32 0, i32 1) }, 0
  %t1824 = extractvalue { i64, ptr } %t1818, 1
  %t1825 = extractvalue { i64, ptr } %t1818, 0
  %t1826 = add i64 %t1822, %t1825
  %t1827 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d307, i32 0, i32 1) }, 1
  %t1828 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d307, i32 0, i32 1) }, 0
  %t1829 = add i64 %t1826, %t1828
  %t1831 = extractvalue { i64, ptr } %t1819, 1
  %t1832 = extractvalue { i64, ptr } %t1819, 0
  %t1833 = add i64 %t1829, %t1832
  %t1834 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d308, i32 0, i32 1) }, 1
  %t1835 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d308, i32 0, i32 1) }, 0
  %t1836 = add i64 %t1833, %t1835
  %t1838 = extractvalue { i64, ptr } %t1820, 1
  %t1839 = extractvalue { i64, ptr } %t1820, 0
  %t1840 = add i64 %t1836, %t1839
  %t1841 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d309, i32 0, i32 1) }, 1
  %t1842 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d309, i32 0, i32 1) }, 0
  %t1843 = add i64 %t1840, %t1842
  %t1844 = call ptr @__olang_scope_alloc(ptr %s60, i64 %t1843)
  call void @olang_textcopy(ptr %t1844, ptr %t1821, i64 %t1822)
  %t1845 = getelementptr i8, ptr %t1844, i64 %t1822
  call void @olang_textcopy(ptr %t1845, ptr %t1824, i64 %t1825)
  %t1846 = getelementptr i8, ptr %t1845, i64 %t1825
  call void @olang_textcopy(ptr %t1846, ptr %t1827, i64 %t1828)
  %t1847 = getelementptr i8, ptr %t1846, i64 %t1828
  call void @olang_textcopy(ptr %t1847, ptr %t1831, i64 %t1832)
  %t1848 = getelementptr i8, ptr %t1847, i64 %t1832
  call void @olang_textcopy(ptr %t1848, ptr %t1834, i64 %t1835)
  %t1849 = getelementptr i8, ptr %t1848, i64 %t1835
  call void @olang_textcopy(ptr %t1849, ptr %t1838, i64 %t1839)
  %t1850 = getelementptr i8, ptr %t1849, i64 %t1839
  call void @olang_textcopy(ptr %t1850, ptr %t1841, i64 %t1842)
  %t1851 = insertvalue { i64, ptr } undef, i64 %t1843, 0
  %t1852 = insertvalue { i64, ptr } %t1851, ptr %t1844, 1
  %t1854 = extractvalue { i64, ptr } %t1852, 0
  %t1855 = extractvalue { i64, ptr } %t1852, 1
  %t1856 = mul i64 %t1854, 1
  %t1857 = call ptr @__olang_scope_alloc(ptr %s60, i64 %t1856)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1857, ptr %t1855, i64 %t1856, i1 false)
  %t1858 = insertvalue { i64, ptr } undef, i64 %t1854, 0
  %t1859 = insertvalue { i64, ptr } %t1858, ptr %t1857, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s60, ptr %t1817, { i64, ptr } %t1859)
  br label %bb302
bb302:
  call void @__olang_scope_close(ptr %s60)
  br label %bb312
bb303:
  %t1862 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1862, ptr %l668, !tbaa !29
  store i1 false, ptr %l669, !tbaa !21
  %t1863 = load ptr, ptr %l668, !tbaa !29
  %t1864 = icmp ne ptr %t1863, null
  br i1 %t1864, label %bb304, label %bb305
bb304:
  %t1866 = load ptr, ptr %l668, !tbaa !29
  %t1867 = load i64, ptr %t1866, !range !{i64 0, i64 18}
  %t1869 = icmp eq i64 %t1867, 11
  store i1 %t1869, ptr %l669, !tbaa !21
  br label %bb305
bb305:
  %t1870 = load i1, ptr %l669, !tbaa !21
  br i1 %t1870, label %bb306, label %bb307
bb306:
  %t1871 = load ptr, ptr %l1, !tbaa !29
  %t1873 = getelementptr { i64, [21 x i64] }, ptr %t1871, i32 0, i32 1
  %t1874 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t1873, i32 0, i32 1
  %t1875 = load i32, ptr %t1874
  store i32 %t1875, ptr %l59, !tbaa !23
  %t1877 = load ptr, ptr %l1, !tbaa !29
  %t1879 = getelementptr { i64, [21 x i64] }, ptr %t1877, i32 0, i32 1
  %t1880 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t1879, i32 0, i32 2
  %t1881 = load i32, ptr %t1880
  store i32 %t1881, ptr %l60, !tbaa !23
  br label %bb308
bb307:
  br label %bb311
bb308:
  %t1883 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1883, ptr %l676, !tbaa !29
  %t1884 = load i32, ptr %l59, !tbaa !23
  store i32 %t1884, ptr %l677, !tbaa !23
  %t1885 = load ptr, ptr %l0, !tbaa !29
  %t1887 = getelementptr %"compiler/emit:fnEm", ptr %t1885, i32 0, i32 1
  %t1888 = load ptr, ptr %t1887, !tbaa !29
  %t1890 = getelementptr %"compiler/mir:Fn", ptr %t1888, i32 0, i32 16
  %t1891 = load i32, ptr %l60, !tbaa !23
  %t1893 = sext i32 %t1891 to i64
  %t1896 = call %"compiler/mir:Task" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %t1890, i64 %t1893)
  store %"compiler/mir:Task" %t1896, ptr %l683
  br label %bb309
bb309:
  %t1897 = load ptr, ptr %l676, !tbaa !29
  %t1898 = load i32, ptr %l677, !tbaa !23
  %t1899 = load %"compiler/mir:Task", ptr %l683
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2espawn(ptr %v0, ptr %t1897, i32 %t1898, %"compiler/mir:Task" %t1899)
  br label %bb310
bb310:
  br label %bb312
bb311:
  call void @__olang_check_failed(ptr @olang_loc_73cacc8093766858_2881ed4d4d5af0d4)
  unreachable
bb312:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2etaskFix(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, %"compiler/mir:Task" %a2, i64 %a3, { i64, ptr } %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/mir:Task"
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l28 = alloca i32
  %l31 = alloca i32
  %l53 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca ptr
  %l65 = alloca %"compiler/mir:Lvalue"
  %l66 = alloca i32
  %l67 = alloca i32
  %l70 = alloca i32
  %l74 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l111 = alloca i64
  %l137 = alloca { i64, ptr }
  %l143 = alloca i64
  %l146 = alloca { i64, ptr }
  %l152 = alloca { i64, ptr }
  %l167 = alloca ptr
  %l168 = alloca { i64, ptr }
  %l169 = alloca { i64, ptr }
  %l170 = alloca { i64, ptr }
  %l171 = alloca { i64, ptr }
  %l174 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s13 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/mir:Task" %a2, ptr %l2
  store { i64, ptr } %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  %t6 = load ptr, ptr %l6, !tbaa !29
  %t8 = getelementptr %"compiler/emit:Emitter", ptr %t6, i32 0, i32 3
  %t9 = load ptr, ptr %t8, !tbaa !29
  store ptr %t9, ptr %l7, !tbaa !29
  store i32 0, ptr %l8, !tbaa !23
  %t11 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 3
  %t12 = getelementptr %"compiler/mir:Range", ptr %t11, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  store i32 %t13, ptr %l9, !tbaa !23
  store i32 1, ptr %l10, !tbaa !23
  %t15 = load i32, ptr %l9, !tbaa !23
  %t16 = load i32, ptr %l8, !tbaa !23
  %t19 = icmp sgt i32 %t15, %t16
  br i1 %t19, label %bb1, label %bb2
bb1:
  %t21 = load i32, ptr %l10, !tbaa !23
  %t23 = icmp sgt i32 %t21, 0
  br i1 %t23, label %bb3, label %bb4
bb2:
  store i32 0, ptr %l28, !tbaa !23
  br label %bb6
bb3:
  %t25 = load i32, ptr %l9, !tbaa !23
  %t26 = load i32, ptr %l8, !tbaa !23
  %t29 = sub i32 %t25, %t26
  %t30 = load i32, ptr %l10, !tbaa !23
  %t33 = add i32 %t29, %t30
  %t35 = sub i32 %t33, 1
  %t36 = load i32, ptr %l10, !tbaa !23
  %t39 = sdiv i32 %t35, %t36
  store i32 %t39, ptr %l31, !tbaa !23
  br label %bb5
bb4:
  store i32 0, ptr %l31, !tbaa !23
  br label %bb5
bb5:
  %t41 = load i32, ptr %l31, !tbaa !23
  store i32 %t41, ptr %l28, !tbaa !23
  br label %bb6
bb6:
  %t42 = load i32, ptr %l28, !tbaa !23
  store i32 %t42, ptr %l11, !tbaa !23
  store i32 0, ptr %l12, !tbaa !23
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load i32, ptr %l12, !tbaa !23
  %t44 = load i32, ptr %l11, !tbaa !23
  %t47 = icmp slt i32 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb49
bb9:
  br label %bb10
bb10:
  %t51 = load i32, ptr %l8, !tbaa !23
  %t52 = load i32, ptr %l12, !tbaa !23
  %t53 = load i32, ptr %l10, !tbaa !23
  %t56 = mul i32 %t52, %t53
  %t59 = add i32 %t51, %t56
  store i32 %t59, ptr %l13, !tbaa !23
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load %"compiler/mir:Task", ptr %l2
  %t63 = load i32, ptr %l13, !tbaa !23
  %t65 = sext i32 %t63 to i64
  %t69 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2evalueTarget(ptr %v0, ptr %t61, %"compiler/mir:Task" %t62, i64 %t65)
  store i1 %t69, ptr %l53
  br label %bb11
bb11:
  %t70 = load i1, ptr %l53, !tbaa !21
  %t71 = xor i1 %t70, true
  br i1 %t71, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb48
bb13:
  br label %bb14
bb14:
  %t73 = load ptr, ptr %l7, !tbaa !29
  store ptr %t73, ptr %l55, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l56, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/emit:fnEm", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = getelementptr %"compiler/mir:Fn", ptr %t78, i32 0, i32 13
  %t81 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 3
  %t82 = getelementptr %"compiler/mir:Range", ptr %t81, i32 0, i32 0
  %t83 = load i32, ptr %t82, !tbaa !23
  %t85 = sext i32 %t83 to i64
  %t86 = load i32, ptr %l13, !tbaa !23
  %t88 = sext i32 %t86 to i64
  %t91 = add i64 %t85, %t88
  %t94 = call %"compiler/mir:Lvalue" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e_2eAt_3ccompiler_2fmir_3aLvalue_3e(ptr %v0, ptr %t80, i64 %t91)
  store %"compiler/mir:Lvalue" %t94, ptr %l65
  br label %bb15
bb15:
  %t95 = load ptr, ptr %l56, !tbaa !29
  %t96 = load %"compiler/mir:Lvalue", ptr %l65
  %t97 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eplaceType(ptr %v0, ptr %t95, %"compiler/mir:Lvalue" %t96)
  store i32 %t97, ptr %l66
  br label %bb16
bb16:
  %t98 = load ptr, ptr %l55, !tbaa !29
  %t99 = load i32, ptr %l66, !tbaa !23
  %t100 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t98, i32 %t99)
  store i32 %t100, ptr %l67
  br label %bb17
bb17:
  %t101 = load i32, ptr %l67, !tbaa !23
  %t102 = load ptr, ptr %l7, !tbaa !29
  %t106 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t102, i32 %t101)
  store i32 %t106, ptr %l70
  br label %bb18
bb18:
  %t107 = load i32, ptr %l70, !tbaa !23
  store i32 %t107, ptr %l15, !tbaa !23
  %t108 = load ptr, ptr %l6, !tbaa !29
  %t110 = getelementptr %"compiler/emit:Emitter", ptr %t108, i32 0, i32 0
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t112 = load i32, ptr %l15, !tbaa !23
  %t115 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t111, i32 %t112)
  store i1 %t115, ptr %l74
  br label %bb19
bb19:
  %t116 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s2, ptr %s2, ptr %t116, { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d310, i32 0, i32 1) }, { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d311, i32 0, i32 1) })
  br label %bb20
bb20:
  %t118 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t119 = load i32, ptr %l13, !tbaa !23
  %t120 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d312, i32 0, i32 1) }, 1
  %t121 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d312, i32 0, i32 1) }, 0
  %t123 = extractvalue { i64, ptr } %t118, 1
  %t124 = extractvalue { i64, ptr } %t118, 0
  %t125 = add i64 %t121, %t124
  %t126 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d313, i32 0, i32 1) }, 1
  %t127 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d313, i32 0, i32 1) }, 0
  %t128 = add i64 %t125, %t127
  %t130 = sext i32 %t119 to i64
  %t131 = call i64 @__olang_fmt_i64(ptr null, i64 %t130)
  %t132 = add i64 %t128, %t131
  %t133 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t132)
  call void @olang_textcopy(ptr %t133, ptr %t120, i64 %t121)
  %t134 = getelementptr i8, ptr %t133, i64 %t121
  call void @olang_textcopy(ptr %t134, ptr %t123, i64 %t124)
  %t135 = getelementptr i8, ptr %t134, i64 %t124
  call void @olang_textcopy(ptr %t135, ptr %t126, i64 %t127)
  %t136 = getelementptr i8, ptr %t135, i64 %t127
  %t137 = call i64 @__olang_fmt_i64(ptr %t136, i64 %t130)
  %t138 = insertvalue { i64, ptr } undef, i64 %t132, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t133, 1
  store { i64, ptr } %t139, ptr %l16, !tbaa !27
  %t141 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t142 = load i32, ptr %l13, !tbaa !23
  %t143 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d314, i32 0, i32 1) }, 1
  %t144 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d314, i32 0, i32 1) }, 0
  %t146 = extractvalue { i64, ptr } %t141, 1
  %t147 = extractvalue { i64, ptr } %t141, 0
  %t148 = add i64 %t144, %t147
  %t149 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d315, i32 0, i32 1) }, 1
  %t150 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d315, i32 0, i32 1) }, 0
  %t151 = add i64 %t148, %t150
  %t153 = sext i32 %t142 to i64
  %t154 = call i64 @__olang_fmt_i64(ptr null, i64 %t153)
  %t155 = add i64 %t151, %t154
  %t156 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t155)
  call void @olang_textcopy(ptr %t156, ptr %t143, i64 %t144)
  %t157 = getelementptr i8, ptr %t156, i64 %t144
  call void @olang_textcopy(ptr %t157, ptr %t146, i64 %t147)
  %t158 = getelementptr i8, ptr %t157, i64 %t147
  call void @olang_textcopy(ptr %t158, ptr %t149, i64 %t150)
  %t159 = getelementptr i8, ptr %t158, i64 %t150
  %t160 = call i64 @__olang_fmt_i64(ptr %t159, i64 %t153)
  %t161 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t156, 1
  store { i64, ptr } %t162, ptr %l17, !tbaa !27
  %t164 = load ptr, ptr %l1, !tbaa !29
  %t165 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t167 = load i32, ptr %l13, !tbaa !23
  %t169 = sext i32 %t167 to i64
  %t172 = add i64 %a3, %t169
  %t173 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t174 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t175 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d316, i32 0, i32 1) }, 1
  %t176 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d316, i32 0, i32 1) }, 0
  %t178 = extractvalue { i64, ptr } %t165, 1
  %t179 = extractvalue { i64, ptr } %t165, 0
  %t180 = add i64 %t176, %t179
  %t181 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d317, i32 0, i32 1) }, 1
  %t182 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d317, i32 0, i32 1) }, 0
  %t183 = add i64 %t180, %t182
  %t185 = call i64 @__olang_fmt_i64(ptr null, i64 %t172)
  %t186 = add i64 %t183, %t185
  %t187 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d318, i32 0, i32 1) }, 1
  %t188 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d318, i32 0, i32 1) }, 0
  %t189 = add i64 %t186, %t188
  %t191 = extractvalue { i64, ptr } %t173, 1
  %t192 = extractvalue { i64, ptr } %t173, 0
  %t193 = add i64 %t189, %t192
  %t194 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d319, i32 0, i32 1) }, 1
  %t195 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d319, i32 0, i32 1) }, 0
  %t196 = add i64 %t193, %t195
  %t198 = extractvalue { i64, ptr } %t174, 1
  %t199 = extractvalue { i64, ptr } %t174, 0
  %t200 = add i64 %t196, %t199
  %t201 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d320, i32 0, i32 1) }, 1
  %t202 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d320, i32 0, i32 1) }, 0
  %t203 = add i64 %t200, %t202
  %t204 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t203)
  call void @olang_textcopy(ptr %t204, ptr %t175, i64 %t176)
  %t205 = getelementptr i8, ptr %t204, i64 %t176
  call void @olang_textcopy(ptr %t205, ptr %t178, i64 %t179)
  %t206 = getelementptr i8, ptr %t205, i64 %t179
  call void @olang_textcopy(ptr %t206, ptr %t181, i64 %t182)
  %t207 = getelementptr i8, ptr %t206, i64 %t182
  %t208 = call i64 @__olang_fmt_i64(ptr %t207, i64 %t172)
  %t209 = getelementptr i8, ptr %t207, i64 %t185
  call void @olang_textcopy(ptr %t209, ptr %t187, i64 %t188)
  %t210 = getelementptr i8, ptr %t209, i64 %t188
  call void @olang_textcopy(ptr %t210, ptr %t191, i64 %t192)
  %t211 = getelementptr i8, ptr %t210, i64 %t192
  call void @olang_textcopy(ptr %t211, ptr %t194, i64 %t195)
  %t212 = getelementptr i8, ptr %t211, i64 %t195
  call void @olang_textcopy(ptr %t212, ptr %t198, i64 %t199)
  %t213 = getelementptr i8, ptr %t212, i64 %t199
  call void @olang_textcopy(ptr %t213, ptr %t201, i64 %t202)
  %t214 = insertvalue { i64, ptr } undef, i64 %t203, 0
  %t215 = insertvalue { i64, ptr } %t214, ptr %t204, 1
  %t217 = extractvalue { i64, ptr } %t215, 0
  %t218 = extractvalue { i64, ptr } %t215, 1
  %t219 = mul i64 %t217, 1
  %t220 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t219)
  call void @llvm.memcpy.p0.p0.i64(ptr %t220, ptr %t218, i64 %t219, i1 false)
  %t221 = insertvalue { i64, ptr } undef, i64 %t217, 0
  %t222 = insertvalue { i64, ptr } %t221, ptr %t220, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t164, { i64, ptr } %t222)
  br label %bb21
bb21:
  %t225 = load ptr, ptr %l1, !tbaa !29
  %t226 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t227 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t228 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t229 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t230 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d321, i32 0, i32 1) }, 1
  %t231 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d321, i32 0, i32 1) }, 0
  %t233 = extractvalue { i64, ptr } %t226, 1
  %t234 = extractvalue { i64, ptr } %t226, 0
  %t235 = add i64 %t231, %t234
  %t236 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d322, i32 0, i32 1) }, 1
  %t237 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d322, i32 0, i32 1) }, 0
  %t238 = add i64 %t235, %t237
  %t240 = extractvalue { i64, ptr } %t227, 1
  %t241 = extractvalue { i64, ptr } %t227, 0
  %t242 = add i64 %t238, %t241
  %t243 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d323, i32 0, i32 1) }, 1
  %t244 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d323, i32 0, i32 1) }, 0
  %t245 = add i64 %t242, %t244
  %t247 = extractvalue { i64, ptr } %t228, 1
  %t248 = extractvalue { i64, ptr } %t228, 0
  %t249 = add i64 %t245, %t248
  %t250 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d324, i32 0, i32 1) }, 1
  %t251 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d324, i32 0, i32 1) }, 0
  %t252 = add i64 %t249, %t251
  %t254 = extractvalue { i64, ptr } %t229, 1
  %t255 = extractvalue { i64, ptr } %t229, 0
  %t256 = add i64 %t252, %t255
  %t257 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d325, i32 0, i32 1) }, 1
  %t258 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d325, i32 0, i32 1) }, 0
  %t259 = add i64 %t256, %t258
  %t260 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t259)
  call void @olang_textcopy(ptr %t260, ptr %t230, i64 %t231)
  %t261 = getelementptr i8, ptr %t260, i64 %t231
  call void @olang_textcopy(ptr %t261, ptr %t233, i64 %t234)
  %t262 = getelementptr i8, ptr %t261, i64 %t234
  call void @olang_textcopy(ptr %t262, ptr %t236, i64 %t237)
  %t263 = getelementptr i8, ptr %t262, i64 %t237
  call void @olang_textcopy(ptr %t263, ptr %t240, i64 %t241)
  %t264 = getelementptr i8, ptr %t263, i64 %t241
  call void @olang_textcopy(ptr %t264, ptr %t243, i64 %t244)
  %t265 = getelementptr i8, ptr %t264, i64 %t244
  call void @olang_textcopy(ptr %t265, ptr %t247, i64 %t248)
  %t266 = getelementptr i8, ptr %t265, i64 %t248
  call void @olang_textcopy(ptr %t266, ptr %t250, i64 %t251)
  %t267 = getelementptr i8, ptr %t266, i64 %t251
  call void @olang_textcopy(ptr %t267, ptr %t254, i64 %t255)
  %t268 = getelementptr i8, ptr %t267, i64 %t255
  call void @olang_textcopy(ptr %t268, ptr %t257, i64 %t258)
  %t269 = insertvalue { i64, ptr } undef, i64 %t259, 0
  %t270 = insertvalue { i64, ptr } %t269, ptr %t260, 1
  %t272 = extractvalue { i64, ptr } %t270, 0
  %t273 = extractvalue { i64, ptr } %t270, 1
  %t274 = mul i64 %t272, 1
  %t275 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t274)
  call void @llvm.memcpy.p0.p0.i64(ptr %t275, ptr %t273, i64 %t274, i1 false)
  %t276 = insertvalue { i64, ptr } undef, i64 %t272, 0
  %t277 = insertvalue { i64, ptr } %t276, ptr %t275, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t225, { i64, ptr } %t277)
  br label %bb22
bb22:
  %t280 = load ptr, ptr %l1, !tbaa !29
  %t281 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t282 = load i32, ptr %l13, !tbaa !23
  %t283 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t284 = load i32, ptr %l13, !tbaa !23
  %t285 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d326, i32 0, i32 1) }, 1
  %t286 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d326, i32 0, i32 1) }, 0
  %t288 = extractvalue { i64, ptr } %t281, 1
  %t289 = extractvalue { i64, ptr } %t281, 0
  %t290 = add i64 %t286, %t289
  %t291 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d327, i32 0, i32 1) }, 1
  %t292 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d327, i32 0, i32 1) }, 0
  %t293 = add i64 %t290, %t292
  %t295 = sext i32 %t282 to i64
  %t296 = call i64 @__olang_fmt_i64(ptr null, i64 %t295)
  %t297 = add i64 %t293, %t296
  %t298 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d328, i32 0, i32 1) }, 1
  %t299 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d328, i32 0, i32 1) }, 0
  %t300 = add i64 %t297, %t299
  %t302 = extractvalue { i64, ptr } %t283, 1
  %t303 = extractvalue { i64, ptr } %t283, 0
  %t304 = add i64 %t300, %t303
  %t305 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d329, i32 0, i32 1) }, 1
  %t306 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d329, i32 0, i32 1) }, 0
  %t307 = add i64 %t304, %t306
  %t309 = sext i32 %t284 to i64
  %t310 = call i64 @__olang_fmt_i64(ptr null, i64 %t309)
  %t311 = add i64 %t307, %t310
  %t312 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d330, i32 0, i32 1) }, 1
  %t313 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d330, i32 0, i32 1) }, 0
  %t314 = add i64 %t311, %t313
  %t315 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t314)
  call void @olang_textcopy(ptr %t315, ptr %t285, i64 %t286)
  %t316 = getelementptr i8, ptr %t315, i64 %t286
  call void @olang_textcopy(ptr %t316, ptr %t288, i64 %t289)
  %t317 = getelementptr i8, ptr %t316, i64 %t289
  call void @olang_textcopy(ptr %t317, ptr %t291, i64 %t292)
  %t318 = getelementptr i8, ptr %t317, i64 %t292
  %t319 = call i64 @__olang_fmt_i64(ptr %t318, i64 %t295)
  %t320 = getelementptr i8, ptr %t318, i64 %t296
  call void @olang_textcopy(ptr %t320, ptr %t298, i64 %t299)
  %t321 = getelementptr i8, ptr %t320, i64 %t299
  call void @olang_textcopy(ptr %t321, ptr %t302, i64 %t303)
  %t322 = getelementptr i8, ptr %t321, i64 %t303
  call void @olang_textcopy(ptr %t322, ptr %t305, i64 %t306)
  %t323 = getelementptr i8, ptr %t322, i64 %t306
  %t324 = call i64 @__olang_fmt_i64(ptr %t323, i64 %t309)
  %t325 = getelementptr i8, ptr %t323, i64 %t310
  call void @olang_textcopy(ptr %t325, ptr %t312, i64 %t313)
  %t326 = insertvalue { i64, ptr } undef, i64 %t314, 0
  %t327 = insertvalue { i64, ptr } %t326, ptr %t315, 1
  %t329 = extractvalue { i64, ptr } %t327, 0
  %t330 = extractvalue { i64, ptr } %t327, 1
  %t331 = mul i64 %t329, 1
  %t332 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t331)
  call void @llvm.memcpy.p0.p0.i64(ptr %t332, ptr %t330, i64 %t331, i1 false)
  %t333 = insertvalue { i64, ptr } undef, i64 %t329, 0
  %t334 = insertvalue { i64, ptr } %t333, ptr %t332, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t280, { i64, ptr } %t334)
  br label %bb23
bb23:
  %t337 = load ptr, ptr %l1, !tbaa !29
  store ptr %t337, ptr %l106, !tbaa !29
  %t338 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t338, ptr %l107, !tbaa !27
  %t339 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t339, ptr %l108, !tbaa !27
  %t340 = load ptr, ptr %l7, !tbaa !29
  %t341 = load i32, ptr %l15, !tbaa !23
  %t344 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t340, i32 %t341)
  store i64 %t344, ptr %l111
  br label %bb24
bb24:
  %t345 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t346 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t347 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t348 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d331, i32 0, i32 1) }, 1
  %t349 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d331, i32 0, i32 1) }, 0
  %t350 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t351 = extractvalue { i64, ptr } %t350, 1
  %t352 = extractvalue { i64, ptr } %t350, 0
  %t353 = add i64 %t349, %t352
  %t354 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d332, i32 0, i32 1) }, 1
  %t355 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d332, i32 0, i32 1) }, 0
  %t356 = add i64 %t353, %t355
  %t357 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t358 = extractvalue { i64, ptr } %t357, 1
  %t359 = extractvalue { i64, ptr } %t357, 0
  %t360 = add i64 %t356, %t359
  %t361 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d333, i32 0, i32 1) }, 1
  %t362 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d333, i32 0, i32 1) }, 0
  %t363 = add i64 %t360, %t362
  %t364 = load i64, ptr %l111, !tbaa !24
  %t365 = call i64 @__olang_fmt_i64(ptr null, i64 %t364)
  %t366 = add i64 %t363, %t365
  %t367 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d334, i32 0, i32 1) }, 1
  %t368 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d334, i32 0, i32 1) }, 0
  %t369 = add i64 %t366, %t368
  %t371 = extractvalue { i64, ptr } %t345, 1
  %t372 = extractvalue { i64, ptr } %t345, 0
  %t373 = add i64 %t369, %t372
  %t374 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d335, i32 0, i32 1) }, 1
  %t375 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d335, i32 0, i32 1) }, 0
  %t376 = add i64 %t373, %t375
  %t378 = extractvalue { i64, ptr } %t346, 1
  %t379 = extractvalue { i64, ptr } %t346, 0
  %t380 = add i64 %t376, %t379
  %t381 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d333, i32 0, i32 1) }, 1
  %t382 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d333, i32 0, i32 1) }, 0
  %t383 = add i64 %t380, %t382
  %t385 = extractvalue { i64, ptr } %t347, 1
  %t386 = extractvalue { i64, ptr } %t347, 0
  %t387 = add i64 %t383, %t386
  %t388 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d336, i32 0, i32 1) }, 1
  %t389 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d336, i32 0, i32 1) }, 0
  %t390 = add i64 %t387, %t389
  %t391 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t390)
  call void @olang_textcopy(ptr %t391, ptr %t348, i64 %t349)
  %t392 = getelementptr i8, ptr %t391, i64 %t349
  call void @olang_textcopy(ptr %t392, ptr %t351, i64 %t352)
  %t393 = getelementptr i8, ptr %t392, i64 %t352
  call void @olang_textcopy(ptr %t393, ptr %t354, i64 %t355)
  %t394 = getelementptr i8, ptr %t393, i64 %t355
  call void @olang_textcopy(ptr %t394, ptr %t358, i64 %t359)
  %t395 = getelementptr i8, ptr %t394, i64 %t359
  call void @olang_textcopy(ptr %t395, ptr %t361, i64 %t362)
  %t396 = getelementptr i8, ptr %t395, i64 %t362
  %t397 = call i64 @__olang_fmt_i64(ptr %t396, i64 %t364)
  %t398 = getelementptr i8, ptr %t396, i64 %t365
  call void @olang_textcopy(ptr %t398, ptr %t367, i64 %t368)
  %t399 = getelementptr i8, ptr %t398, i64 %t368
  call void @olang_textcopy(ptr %t399, ptr %t371, i64 %t372)
  %t400 = getelementptr i8, ptr %t399, i64 %t372
  call void @olang_textcopy(ptr %t400, ptr %t374, i64 %t375)
  %t401 = getelementptr i8, ptr %t400, i64 %t375
  call void @olang_textcopy(ptr %t401, ptr %t378, i64 %t379)
  %t402 = getelementptr i8, ptr %t401, i64 %t379
  call void @olang_textcopy(ptr %t402, ptr %t381, i64 %t382)
  %t403 = getelementptr i8, ptr %t402, i64 %t382
  call void @olang_textcopy(ptr %t403, ptr %t385, i64 %t386)
  %t404 = getelementptr i8, ptr %t403, i64 %t386
  call void @olang_textcopy(ptr %t404, ptr %t388, i64 %t389)
  %t405 = insertvalue { i64, ptr } undef, i64 %t390, 0
  %t406 = insertvalue { i64, ptr } %t405, ptr %t391, 1
  %t408 = extractvalue { i64, ptr } %t406, 0
  %t409 = extractvalue { i64, ptr } %t406, 1
  %t410 = mul i64 %t408, 1
  %t411 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t410)
  call void @llvm.memcpy.p0.p0.i64(ptr %t411, ptr %t409, i64 %t410, i1 false)
  %t412 = insertvalue { i64, ptr } undef, i64 %t408, 0
  %t413 = insertvalue { i64, ptr } %t412, ptr %t411, 1
  %t414 = load ptr, ptr %l106, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t414, { i64, ptr } %t413)
  br label %bb25
bb25:
  %t416 = load ptr, ptr %l1, !tbaa !29
  %t417 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t418 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t419 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t420 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t421 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d337, i32 0, i32 1) }, 1
  %t422 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d337, i32 0, i32 1) }, 0
  %t424 = extractvalue { i64, ptr } %t417, 1
  %t425 = extractvalue { i64, ptr } %t417, 0
  %t426 = add i64 %t422, %t425
  %t427 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d338, i32 0, i32 1) }, 1
  %t428 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d338, i32 0, i32 1) }, 0
  %t429 = add i64 %t426, %t428
  %t431 = extractvalue { i64, ptr } %t418, 1
  %t432 = extractvalue { i64, ptr } %t418, 0
  %t433 = add i64 %t429, %t432
  %t434 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d339, i32 0, i32 1) }, 1
  %t435 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d339, i32 0, i32 1) }, 0
  %t436 = add i64 %t433, %t435
  %t438 = extractvalue { i64, ptr } %t419, 1
  %t439 = extractvalue { i64, ptr } %t419, 0
  %t440 = add i64 %t436, %t439
  %t441 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d340, i32 0, i32 1) }, 1
  %t442 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d340, i32 0, i32 1) }, 0
  %t443 = add i64 %t440, %t442
  %t445 = extractvalue { i64, ptr } %t420, 1
  %t446 = extractvalue { i64, ptr } %t420, 0
  %t447 = add i64 %t443, %t446
  %t448 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d341, i32 0, i32 1) }, 1
  %t449 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d341, i32 0, i32 1) }, 0
  %t450 = add i64 %t447, %t449
  %t451 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t450)
  call void @olang_textcopy(ptr %t451, ptr %t421, i64 %t422)
  %t452 = getelementptr i8, ptr %t451, i64 %t422
  call void @olang_textcopy(ptr %t452, ptr %t424, i64 %t425)
  %t453 = getelementptr i8, ptr %t452, i64 %t425
  call void @olang_textcopy(ptr %t453, ptr %t427, i64 %t428)
  %t454 = getelementptr i8, ptr %t453, i64 %t428
  call void @olang_textcopy(ptr %t454, ptr %t431, i64 %t432)
  %t455 = getelementptr i8, ptr %t454, i64 %t432
  call void @olang_textcopy(ptr %t455, ptr %t434, i64 %t435)
  %t456 = getelementptr i8, ptr %t455, i64 %t435
  call void @olang_textcopy(ptr %t456, ptr %t438, i64 %t439)
  %t457 = getelementptr i8, ptr %t456, i64 %t439
  call void @olang_textcopy(ptr %t457, ptr %t441, i64 %t442)
  %t458 = getelementptr i8, ptr %t457, i64 %t442
  call void @olang_textcopy(ptr %t458, ptr %t445, i64 %t446)
  %t459 = getelementptr i8, ptr %t458, i64 %t446
  call void @olang_textcopy(ptr %t459, ptr %t448, i64 %t449)
  %t460 = insertvalue { i64, ptr } undef, i64 %t450, 0
  %t461 = insertvalue { i64, ptr } %t460, ptr %t451, 1
  %t463 = extractvalue { i64, ptr } %t461, 0
  %t464 = extractvalue { i64, ptr } %t461, 1
  %t465 = mul i64 %t463, 1
  %t466 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t465)
  call void @llvm.memcpy.p0.p0.i64(ptr %t466, ptr %t464, i64 %t465, i1 false)
  %t467 = insertvalue { i64, ptr } undef, i64 %t463, 0
  %t468 = insertvalue { i64, ptr } %t467, ptr %t466, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t416, { i64, ptr } %t468)
  br label %bb26
bb26:
  %t471 = load ptr, ptr %l1, !tbaa !29
  %t472 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t473 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t474 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t475 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d342, i32 0, i32 1) }, 1
  %t476 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d342, i32 0, i32 1) }, 0
  %t478 = extractvalue { i64, ptr } %t472, 1
  %t479 = extractvalue { i64, ptr } %t472, 0
  %t480 = add i64 %t476, %t479
  %t481 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d343, i32 0, i32 1) }, 1
  %t482 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d343, i32 0, i32 1) }, 0
  %t483 = add i64 %t480, %t482
  %t485 = extractvalue { i64, ptr } %t473, 1
  %t486 = extractvalue { i64, ptr } %t473, 0
  %t487 = add i64 %t483, %t486
  %t488 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d344, i32 0, i32 1) }, 1
  %t489 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d344, i32 0, i32 1) }, 0
  %t490 = add i64 %t487, %t489
  %t492 = extractvalue { i64, ptr } %t474, 1
  %t493 = extractvalue { i64, ptr } %t474, 0
  %t494 = add i64 %t490, %t493
  %t495 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d345, i32 0, i32 1) }, 1
  %t496 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d345, i32 0, i32 1) }, 0
  %t497 = add i64 %t494, %t496
  %t498 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t497)
  call void @olang_textcopy(ptr %t498, ptr %t475, i64 %t476)
  %t499 = getelementptr i8, ptr %t498, i64 %t476
  call void @olang_textcopy(ptr %t499, ptr %t478, i64 %t479)
  %t500 = getelementptr i8, ptr %t499, i64 %t479
  call void @olang_textcopy(ptr %t500, ptr %t481, i64 %t482)
  %t501 = getelementptr i8, ptr %t500, i64 %t482
  call void @olang_textcopy(ptr %t501, ptr %t485, i64 %t486)
  %t502 = getelementptr i8, ptr %t501, i64 %t486
  call void @olang_textcopy(ptr %t502, ptr %t488, i64 %t489)
  %t503 = getelementptr i8, ptr %t502, i64 %t489
  call void @olang_textcopy(ptr %t503, ptr %t492, i64 %t493)
  %t504 = getelementptr i8, ptr %t503, i64 %t493
  call void @olang_textcopy(ptr %t504, ptr %t495, i64 %t496)
  %t505 = insertvalue { i64, ptr } undef, i64 %t497, 0
  %t506 = insertvalue { i64, ptr } %t505, ptr %t498, 1
  %t508 = extractvalue { i64, ptr } %t506, 0
  %t509 = extractvalue { i64, ptr } %t506, 1
  %t510 = mul i64 %t508, 1
  %t511 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t510)
  call void @llvm.memcpy.p0.p0.i64(ptr %t511, ptr %t509, i64 %t510, i1 false)
  %t512 = insertvalue { i64, ptr } undef, i64 %t508, 0
  %t513 = insertvalue { i64, ptr } %t512, ptr %t511, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t471, { i64, ptr } %t513)
  br label %bb27
bb27:
  %t516 = load ptr, ptr %l1, !tbaa !29
  %t517 = load i32, ptr %l13, !tbaa !23
  %t518 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t519 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t520 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t521 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d346, i32 0, i32 1) }, 1
  %t522 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d346, i32 0, i32 1) }, 0
  %t524 = sext i32 %t517 to i64
  %t525 = call i64 @__olang_fmt_i64(ptr null, i64 %t524)
  %t526 = add i64 %t522, %t525
  %t527 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d347, i32 0, i32 1) }, 1
  %t528 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d347, i32 0, i32 1) }, 0
  %t529 = add i64 %t526, %t528
  %t531 = extractvalue { i64, ptr } %t518, 1
  %t532 = extractvalue { i64, ptr } %t518, 0
  %t533 = add i64 %t529, %t532
  %t534 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d348, i32 0, i32 1) }, 1
  %t535 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d348, i32 0, i32 1) }, 0
  %t536 = add i64 %t533, %t535
  %t538 = extractvalue { i64, ptr } %t519, 1
  %t539 = extractvalue { i64, ptr } %t519, 0
  %t540 = add i64 %t536, %t539
  %t541 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d349, i32 0, i32 1) }, 1
  %t542 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d349, i32 0, i32 1) }, 0
  %t543 = add i64 %t540, %t542
  %t545 = extractvalue { i64, ptr } %t520, 1
  %t546 = extractvalue { i64, ptr } %t520, 0
  %t547 = add i64 %t543, %t546
  %t548 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d350, i32 0, i32 1) }, 1
  %t549 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d350, i32 0, i32 1) }, 0
  %t550 = add i64 %t547, %t549
  %t551 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t550)
  call void @olang_textcopy(ptr %t551, ptr %t521, i64 %t522)
  %t552 = getelementptr i8, ptr %t551, i64 %t522
  %t553 = call i64 @__olang_fmt_i64(ptr %t552, i64 %t524)
  %t554 = getelementptr i8, ptr %t552, i64 %t525
  call void @olang_textcopy(ptr %t554, ptr %t527, i64 %t528)
  %t555 = getelementptr i8, ptr %t554, i64 %t528
  call void @olang_textcopy(ptr %t555, ptr %t531, i64 %t532)
  %t556 = getelementptr i8, ptr %t555, i64 %t532
  call void @olang_textcopy(ptr %t556, ptr %t534, i64 %t535)
  %t557 = getelementptr i8, ptr %t556, i64 %t535
  call void @olang_textcopy(ptr %t557, ptr %t538, i64 %t539)
  %t558 = getelementptr i8, ptr %t557, i64 %t539
  call void @olang_textcopy(ptr %t558, ptr %t541, i64 %t542)
  %t559 = getelementptr i8, ptr %t558, i64 %t542
  call void @olang_textcopy(ptr %t559, ptr %t545, i64 %t546)
  %t560 = getelementptr i8, ptr %t559, i64 %t546
  call void @olang_textcopy(ptr %t560, ptr %t548, i64 %t549)
  %t561 = insertvalue { i64, ptr } undef, i64 %t550, 0
  %t562 = insertvalue { i64, ptr } %t561, ptr %t551, 1
  %t564 = extractvalue { i64, ptr } %t562, 0
  %t565 = extractvalue { i64, ptr } %t562, 1
  %t566 = mul i64 %t564, 1
  %t567 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t566)
  call void @llvm.memcpy.p0.p0.i64(ptr %t567, ptr %t565, i64 %t566, i1 false)
  %t568 = insertvalue { i64, ptr } undef, i64 %t564, 0
  %t569 = insertvalue { i64, ptr } %t568, ptr %t567, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t516, { i64, ptr } %t569)
  br label %bb28
bb28:
  %t572 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t572, ptr %l137, !tbaa !27
  %t573 = load i32, ptr %l13, !tbaa !23
  %t575 = sext i32 %t573 to i64
  %t576 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t577 = load ptr, ptr %t576, !tbaa !27
  %t578 = getelementptr i64, ptr %t577, i64 %t575
  %t579 = load i64, ptr %t578, !tbaa !34
  %t581 = icmp sge i64 %t579, 0
  br i1 %t581, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s13
  %t583 = load ptr, ptr %l7, !tbaa !29
  %t584 = load i32, ptr %l15, !tbaa !23
  %t587 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %t583, i32 %t584)
  store i64 %t587, ptr %l143
  br label %bb31
bb30:
  br label %bb46
bb31:
  %t588 = load i64, ptr %l143, !tbaa !24
  store i64 %t588, ptr %l18, !tbaa !24
  %t589 = load i64, ptr %l18, !tbaa !24
  %t591 = icmp sgt i64 %t589, 8
  br i1 %t591, label %bb32, label %bb33
bb32:
  store { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d351, i32 0, i32 1) }, ptr %l146, !tbaa !27
  br label %bb34
bb33:
  store { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d352, i32 0, i32 1) }, ptr %l146, !tbaa !27
  br label %bb34
bb34:
  %t593 = load { i64, ptr }, ptr %l146, !tbaa !27
  store { i64, ptr } %t593, ptr %l19, !tbaa !27
  %t594 = load ptr, ptr %l6, !tbaa !29
  %t595 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t596 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %t596, ptr %t594, { i64, ptr } %t595)
  br label %bb35
bb35:
  %t599 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %s13, ptr %s13, ptr %t599, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d353, i32 0, i32 1) }, { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d354, i32 0, i32 1) })
  br label %bb36
bb36:
  %t601 = load ptr, ptr %l1, !tbaa !29
  %t602 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t603 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t603, ptr %l152, !tbaa !27
  %t604 = load i32, ptr %l13, !tbaa !23
  %t606 = sext i32 %t604 to i64
  %t607 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t608 = load ptr, ptr %t607, !tbaa !27
  %t609 = getelementptr i64, ptr %t608, i64 %t606
  %t610 = load i64, ptr %t609, !tbaa !34
  %t611 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t612 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t613 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d355, i32 0, i32 1) }, 1
  %t614 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d355, i32 0, i32 1) }, 0
  %t616 = extractvalue { i64, ptr } %t602, 1
  %t617 = extractvalue { i64, ptr } %t602, 0
  %t618 = add i64 %t614, %t617
  %t619 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d356, i32 0, i32 1) }, 1
  %t620 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d356, i32 0, i32 1) }, 0
  %t621 = add i64 %t618, %t620
  %t623 = call i64 @__olang_fmt_i64(ptr null, i64 %t610)
  %t624 = add i64 %t621, %t623
  %t625 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d357, i32 0, i32 1) }, 1
  %t626 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d357, i32 0, i32 1) }, 0
  %t627 = add i64 %t624, %t626
  %t629 = extractvalue { i64, ptr } %t611, 1
  %t630 = extractvalue { i64, ptr } %t611, 0
  %t631 = add i64 %t627, %t630
  %t632 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d358, i32 0, i32 1) }, 1
  %t633 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d358, i32 0, i32 1) }, 0
  %t634 = add i64 %t631, %t633
  %t636 = extractvalue { i64, ptr } %t612, 1
  %t637 = extractvalue { i64, ptr } %t612, 0
  %t638 = add i64 %t634, %t637
  %t639 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d359, i32 0, i32 1) }, 1
  %t640 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d359, i32 0, i32 1) }, 0
  %t641 = add i64 %t638, %t640
  %t642 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t641)
  call void @olang_textcopy(ptr %t642, ptr %t613, i64 %t614)
  %t643 = getelementptr i8, ptr %t642, i64 %t614
  call void @olang_textcopy(ptr %t643, ptr %t616, i64 %t617)
  %t644 = getelementptr i8, ptr %t643, i64 %t617
  call void @olang_textcopy(ptr %t644, ptr %t619, i64 %t620)
  %t645 = getelementptr i8, ptr %t644, i64 %t620
  %t646 = call i64 @__olang_fmt_i64(ptr %t645, i64 %t610)
  %t647 = getelementptr i8, ptr %t645, i64 %t623
  call void @olang_textcopy(ptr %t647, ptr %t625, i64 %t626)
  %t648 = getelementptr i8, ptr %t647, i64 %t626
  call void @olang_textcopy(ptr %t648, ptr %t629, i64 %t630)
  %t649 = getelementptr i8, ptr %t648, i64 %t630
  call void @olang_textcopy(ptr %t649, ptr %t632, i64 %t633)
  %t650 = getelementptr i8, ptr %t649, i64 %t633
  call void @olang_textcopy(ptr %t650, ptr %t636, i64 %t637)
  %t651 = getelementptr i8, ptr %t650, i64 %t637
  call void @olang_textcopy(ptr %t651, ptr %t639, i64 %t640)
  %t652 = insertvalue { i64, ptr } undef, i64 %t641, 0
  %t653 = insertvalue { i64, ptr } %t652, ptr %t642, 1
  %t655 = extractvalue { i64, ptr } %t653, 0
  %t656 = extractvalue { i64, ptr } %t653, 1
  %t657 = mul i64 %t655, 1
  %t658 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t657)
  call void @llvm.memcpy.p0.p0.i64(ptr %t658, ptr %t656, i64 %t657, i1 false)
  %t659 = insertvalue { i64, ptr } undef, i64 %t655, 0
  %t660 = insertvalue { i64, ptr } %t659, ptr %t658, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s13, ptr %t601, { i64, ptr } %t660)
  br label %bb37
bb37:
  %t663 = load ptr, ptr %l1, !tbaa !29
  %t664 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t665 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t666 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t667 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t668 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t669 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d360, i32 0, i32 1) }, 1
  %t670 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d360, i32 0, i32 1) }, 0
  %t672 = extractvalue { i64, ptr } %t664, 1
  %t673 = extractvalue { i64, ptr } %t664, 0
  %t674 = add i64 %t670, %t673
  %t675 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d361, i32 0, i32 1) }, 1
  %t676 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d361, i32 0, i32 1) }, 0
  %t677 = add i64 %t674, %t676
  %t679 = extractvalue { i64, ptr } %t665, 1
  %t680 = extractvalue { i64, ptr } %t665, 0
  %t681 = add i64 %t677, %t680
  %t682 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d362, i32 0, i32 1) }, 1
  %t683 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d362, i32 0, i32 1) }, 0
  %t684 = add i64 %t681, %t683
  %t686 = extractvalue { i64, ptr } %t666, 1
  %t687 = extractvalue { i64, ptr } %t666, 0
  %t688 = add i64 %t684, %t687
  %t689 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d363, i32 0, i32 1) }, 1
  %t690 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d363, i32 0, i32 1) }, 0
  %t691 = add i64 %t688, %t690
  %t693 = extractvalue { i64, ptr } %t667, 1
  %t694 = extractvalue { i64, ptr } %t667, 0
  %t695 = add i64 %t691, %t694
  %t696 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d364, i32 0, i32 1) }, 1
  %t697 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d364, i32 0, i32 1) }, 0
  %t698 = add i64 %t695, %t697
  %t700 = extractvalue { i64, ptr } %t668, 1
  %t701 = extractvalue { i64, ptr } %t668, 0
  %t702 = add i64 %t698, %t701
  %t703 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d365, i32 0, i32 1) }, 1
  %t704 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d365, i32 0, i32 1) }, 0
  %t705 = add i64 %t702, %t704
  %t706 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t705)
  call void @olang_textcopy(ptr %t706, ptr %t669, i64 %t670)
  %t707 = getelementptr i8, ptr %t706, i64 %t670
  call void @olang_textcopy(ptr %t707, ptr %t672, i64 %t673)
  %t708 = getelementptr i8, ptr %t707, i64 %t673
  call void @olang_textcopy(ptr %t708, ptr %t675, i64 %t676)
  %t709 = getelementptr i8, ptr %t708, i64 %t676
  call void @olang_textcopy(ptr %t709, ptr %t679, i64 %t680)
  %t710 = getelementptr i8, ptr %t709, i64 %t680
  call void @olang_textcopy(ptr %t710, ptr %t682, i64 %t683)
  %t711 = getelementptr i8, ptr %t710, i64 %t683
  call void @olang_textcopy(ptr %t711, ptr %t686, i64 %t687)
  %t712 = getelementptr i8, ptr %t711, i64 %t687
  call void @olang_textcopy(ptr %t712, ptr %t689, i64 %t690)
  %t713 = getelementptr i8, ptr %t712, i64 %t690
  call void @olang_textcopy(ptr %t713, ptr %t693, i64 %t694)
  %t714 = getelementptr i8, ptr %t713, i64 %t694
  call void @olang_textcopy(ptr %t714, ptr %t696, i64 %t697)
  %t715 = getelementptr i8, ptr %t714, i64 %t697
  call void @olang_textcopy(ptr %t715, ptr %t700, i64 %t701)
  %t716 = getelementptr i8, ptr %t715, i64 %t701
  call void @olang_textcopy(ptr %t716, ptr %t703, i64 %t704)
  %t717 = insertvalue { i64, ptr } undef, i64 %t705, 0
  %t718 = insertvalue { i64, ptr } %t717, ptr %t706, 1
  %t720 = extractvalue { i64, ptr } %t718, 0
  %t721 = extractvalue { i64, ptr } %t718, 1
  %t722 = mul i64 %t720, 1
  %t723 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t722)
  call void @llvm.memcpy.p0.p0.i64(ptr %t723, ptr %t721, i64 %t722, i1 false)
  %t724 = insertvalue { i64, ptr } undef, i64 %t720, 0
  %t725 = insertvalue { i64, ptr } %t724, ptr %t723, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s13, ptr %t663, { i64, ptr } %t725)
  br label %bb38
bb38:
  %t728 = load ptr, ptr %l1, !tbaa !29
  store ptr %t728, ptr %l167, !tbaa !29
  %t729 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t729, ptr %l168, !tbaa !27
  %t730 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t730, ptr %l169, !tbaa !27
  %t731 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t731, ptr %l170, !tbaa !27
  %t732 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t732, ptr %l171, !tbaa !27
  %t733 = load i64, ptr %l18, !tbaa !24
  %t735 = icmp sgt i64 %t733, 8
  br i1 %t735, label %bb39, label %bb40
bb39:
  %t737 = load i64, ptr %l18, !tbaa !24
  %t738 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d366, i32 0, i32 1) }, 1
  %t739 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d366, i32 0, i32 1) }, 0
  %t741 = call i64 @__olang_fmt_i64(ptr null, i64 %t737)
  %t742 = add i64 %t739, %t741
  %t743 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t742)
  call void @olang_textcopy(ptr %t743, ptr %t738, i64 %t739)
  %t744 = getelementptr i8, ptr %t743, i64 %t739
  %t745 = call i64 @__olang_fmt_i64(ptr %t744, i64 %t737)
  %t746 = insertvalue { i64, ptr } undef, i64 %t742, 0
  %t747 = insertvalue { i64, ptr } %t746, ptr %t743, 1
  %t749 = extractvalue { i64, ptr } %t747, 0
  %t750 = extractvalue { i64, ptr } %t747, 1
  %t751 = mul i64 %t749, 1
  %t752 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t751)
  call void @llvm.memcpy.p0.p0.i64(ptr %t752, ptr %t750, i64 %t751, i1 false)
  %t753 = insertvalue { i64, ptr } undef, i64 %t749, 0
  %t754 = insertvalue { i64, ptr } %t753, ptr %t752, 1
  store { i64, ptr } %t754, ptr %l174, !tbaa !27
  br label %bb41
bb40:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d367, i32 0, i32 1) }, ptr %l174, !tbaa !27
  br label %bb41
bb41:
  %t756 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d368, i32 0, i32 1) }, 1
  %t757 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d368, i32 0, i32 1) }, 0
  %t758 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t759 = extractvalue { i64, ptr } %t758, 1
  %t760 = extractvalue { i64, ptr } %t758, 0
  %t761 = add i64 %t757, %t760
  %t762 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d369, i32 0, i32 1) }, 1
  %t763 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d369, i32 0, i32 1) }, 0
  %t764 = add i64 %t761, %t763
  %t765 = load { i64, ptr }, ptr %l169, !tbaa !27
  %t766 = extractvalue { i64, ptr } %t765, 1
  %t767 = extractvalue { i64, ptr } %t765, 0
  %t768 = add i64 %t764, %t767
  %t769 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d370, i32 0, i32 1) }, 1
  %t770 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d370, i32 0, i32 1) }, 0
  %t771 = add i64 %t768, %t770
  %t772 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t773 = extractvalue { i64, ptr } %t772, 1
  %t774 = extractvalue { i64, ptr } %t772, 0
  %t775 = add i64 %t771, %t774
  %t776 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d371, i32 0, i32 1) }, 1
  %t777 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d371, i32 0, i32 1) }, 0
  %t778 = add i64 %t775, %t777
  %t779 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t780 = extractvalue { i64, ptr } %t779, 1
  %t781 = extractvalue { i64, ptr } %t779, 0
  %t782 = add i64 %t778, %t781
  %t783 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d372, i32 0, i32 1) }, 1
  %t784 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d372, i32 0, i32 1) }, 0
  %t785 = add i64 %t782, %t784
  %t786 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t787 = extractvalue { i64, ptr } %t786, 1
  %t788 = extractvalue { i64, ptr } %t786, 0
  %t789 = add i64 %t785, %t788
  %t790 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d373, i32 0, i32 1) }, 1
  %t791 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d373, i32 0, i32 1) }, 0
  %t792 = add i64 %t789, %t791
  %t793 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t792)
  call void @olang_textcopy(ptr %t793, ptr %t756, i64 %t757)
  %t794 = getelementptr i8, ptr %t793, i64 %t757
  call void @olang_textcopy(ptr %t794, ptr %t759, i64 %t760)
  %t795 = getelementptr i8, ptr %t794, i64 %t760
  call void @olang_textcopy(ptr %t795, ptr %t762, i64 %t763)
  %t796 = getelementptr i8, ptr %t795, i64 %t763
  call void @olang_textcopy(ptr %t796, ptr %t766, i64 %t767)
  %t797 = getelementptr i8, ptr %t796, i64 %t767
  call void @olang_textcopy(ptr %t797, ptr %t769, i64 %t770)
  %t798 = getelementptr i8, ptr %t797, i64 %t770
  call void @olang_textcopy(ptr %t798, ptr %t773, i64 %t774)
  %t799 = getelementptr i8, ptr %t798, i64 %t774
  call void @olang_textcopy(ptr %t799, ptr %t776, i64 %t777)
  %t800 = getelementptr i8, ptr %t799, i64 %t777
  call void @olang_textcopy(ptr %t800, ptr %t780, i64 %t781)
  %t801 = getelementptr i8, ptr %t800, i64 %t781
  call void @olang_textcopy(ptr %t801, ptr %t783, i64 %t784)
  %t802 = getelementptr i8, ptr %t801, i64 %t784
  call void @olang_textcopy(ptr %t802, ptr %t787, i64 %t788)
  %t803 = getelementptr i8, ptr %t802, i64 %t788
  call void @olang_textcopy(ptr %t803, ptr %t790, i64 %t791)
  %t804 = insertvalue { i64, ptr } undef, i64 %t792, 0
  %t805 = insertvalue { i64, ptr } %t804, ptr %t793, 1
  %t807 = extractvalue { i64, ptr } %t805, 0
  %t808 = extractvalue { i64, ptr } %t805, 1
  %t809 = mul i64 %t807, 1
  %t810 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t809)
  call void @llvm.memcpy.p0.p0.i64(ptr %t810, ptr %t808, i64 %t809, i1 false)
  %t811 = insertvalue { i64, ptr } undef, i64 %t807, 0
  %t812 = insertvalue { i64, ptr } %t811, ptr %t810, 1
  %t813 = load ptr, ptr %l167, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s13, ptr %t813, { i64, ptr } %t812)
  br label %bb42
bb42:
  %t815 = load ptr, ptr %l1, !tbaa !29
  %t816 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t817 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t818 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t819 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d374, i32 0, i32 1) }, 1
  %t820 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d374, i32 0, i32 1) }, 0
  %t822 = extractvalue { i64, ptr } %t816, 1
  %t823 = extractvalue { i64, ptr } %t816, 0
  %t824 = add i64 %t820, %t823
  %t825 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d375, i32 0, i32 1) }, 1
  %t826 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d375, i32 0, i32 1) }, 0
  %t827 = add i64 %t824, %t826
  %t829 = extractvalue { i64, ptr } %t817, 1
  %t830 = extractvalue { i64, ptr } %t817, 0
  %t831 = add i64 %t827, %t830
  %t832 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d376, i32 0, i32 1) }, 1
  %t833 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d376, i32 0, i32 1) }, 0
  %t834 = add i64 %t831, %t833
  %t836 = extractvalue { i64, ptr } %t818, 1
  %t837 = extractvalue { i64, ptr } %t818, 0
  %t838 = add i64 %t834, %t837
  %t839 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d377, i32 0, i32 1) }, 1
  %t840 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d377, i32 0, i32 1) }, 0
  %t841 = add i64 %t838, %t840
  %t842 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t841)
  call void @olang_textcopy(ptr %t842, ptr %t819, i64 %t820)
  %t843 = getelementptr i8, ptr %t842, i64 %t820
  call void @olang_textcopy(ptr %t843, ptr %t822, i64 %t823)
  %t844 = getelementptr i8, ptr %t843, i64 %t823
  call void @olang_textcopy(ptr %t844, ptr %t825, i64 %t826)
  %t845 = getelementptr i8, ptr %t844, i64 %t826
  call void @olang_textcopy(ptr %t845, ptr %t829, i64 %t830)
  %t846 = getelementptr i8, ptr %t845, i64 %t830
  call void @olang_textcopy(ptr %t846, ptr %t832, i64 %t833)
  %t847 = getelementptr i8, ptr %t846, i64 %t833
  call void @olang_textcopy(ptr %t847, ptr %t836, i64 %t837)
  %t848 = getelementptr i8, ptr %t847, i64 %t837
  call void @olang_textcopy(ptr %t848, ptr %t839, i64 %t840)
  %t849 = insertvalue { i64, ptr } undef, i64 %t841, 0
  %t850 = insertvalue { i64, ptr } %t849, ptr %t842, 1
  %t852 = extractvalue { i64, ptr } %t850, 0
  %t853 = extractvalue { i64, ptr } %t850, 1
  %t854 = mul i64 %t852, 1
  %t855 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t854)
  call void @llvm.memcpy.p0.p0.i64(ptr %t855, ptr %t853, i64 %t854, i1 false)
  %t856 = insertvalue { i64, ptr } undef, i64 %t852, 0
  %t857 = insertvalue { i64, ptr } %t856, ptr %t855, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s13, ptr %t815, { i64, ptr } %t857)
  br label %bb43
bb43:
  %t860 = load ptr, ptr %l1, !tbaa !29
  %t861 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t862 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t863 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d378, i32 0, i32 1) }, 1
  %t864 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d378, i32 0, i32 1) }, 0
  %t866 = extractvalue { i64, ptr } %t861, 1
  %t867 = extractvalue { i64, ptr } %t861, 0
  %t868 = add i64 %t864, %t867
  %t869 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d379, i32 0, i32 1) }, 1
  %t870 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d379, i32 0, i32 1) }, 0
  %t871 = add i64 %t868, %t870
  %t873 = extractvalue { i64, ptr } %t862, 1
  %t874 = extractvalue { i64, ptr } %t862, 0
  %t875 = add i64 %t871, %t874
  %t876 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d380, i32 0, i32 1) }, 1
  %t877 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d380, i32 0, i32 1) }, 0
  %t878 = add i64 %t875, %t877
  %t879 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t878)
  call void @olang_textcopy(ptr %t879, ptr %t863, i64 %t864)
  %t880 = getelementptr i8, ptr %t879, i64 %t864
  call void @olang_textcopy(ptr %t880, ptr %t866, i64 %t867)
  %t881 = getelementptr i8, ptr %t880, i64 %t867
  call void @olang_textcopy(ptr %t881, ptr %t869, i64 %t870)
  %t882 = getelementptr i8, ptr %t881, i64 %t870
  call void @olang_textcopy(ptr %t882, ptr %t873, i64 %t874)
  %t883 = getelementptr i8, ptr %t882, i64 %t874
  call void @olang_textcopy(ptr %t883, ptr %t876, i64 %t877)
  %t884 = insertvalue { i64, ptr } undef, i64 %t878, 0
  %t885 = insertvalue { i64, ptr } %t884, ptr %t879, 1
  %t887 = extractvalue { i64, ptr } %t885, 0
  %t888 = extractvalue { i64, ptr } %t885, 1
  %t889 = mul i64 %t887, 1
  %t890 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t889)
  call void @llvm.memcpy.p0.p0.i64(ptr %t890, ptr %t888, i64 %t889, i1 false)
  %t891 = insertvalue { i64, ptr } undef, i64 %t887, 0
  %t892 = insertvalue { i64, ptr } %t891, ptr %t890, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s13, ptr %t860, { i64, ptr } %t892)
  br label %bb44
bb44:
  %t895 = load ptr, ptr %l1, !tbaa !29
  %t896 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t897 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t898 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t899 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t900 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t901 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d381, i32 0, i32 1) }, 1
  %t902 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d381, i32 0, i32 1) }, 0
  %t904 = extractvalue { i64, ptr } %t896, 1
  %t905 = extractvalue { i64, ptr } %t896, 0
  %t906 = add i64 %t902, %t905
  %t907 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d382, i32 0, i32 1) }, 1
  %t908 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d382, i32 0, i32 1) }, 0
  %t909 = add i64 %t906, %t908
  %t911 = extractvalue { i64, ptr } %t897, 1
  %t912 = extractvalue { i64, ptr } %t897, 0
  %t913 = add i64 %t909, %t912
  %t914 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d383, i32 0, i32 1) }, 1
  %t915 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d383, i32 0, i32 1) }, 0
  %t916 = add i64 %t913, %t915
  %t918 = extractvalue { i64, ptr } %t898, 1
  %t919 = extractvalue { i64, ptr } %t898, 0
  %t920 = add i64 %t916, %t919
  %t921 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d384, i32 0, i32 1) }, 1
  %t922 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d384, i32 0, i32 1) }, 0
  %t923 = add i64 %t920, %t922
  %t925 = extractvalue { i64, ptr } %t899, 1
  %t926 = extractvalue { i64, ptr } %t899, 0
  %t927 = add i64 %t923, %t926
  %t928 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d385, i32 0, i32 1) }, 1
  %t929 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d385, i32 0, i32 1) }, 0
  %t930 = add i64 %t927, %t929
  %t932 = extractvalue { i64, ptr } %t900, 1
  %t933 = extractvalue { i64, ptr } %t900, 0
  %t934 = add i64 %t930, %t933
  %t935 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d386, i32 0, i32 1) }, 1
  %t936 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d386, i32 0, i32 1) }, 0
  %t937 = add i64 %t934, %t936
  %t938 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t937)
  call void @olang_textcopy(ptr %t938, ptr %t901, i64 %t902)
  %t939 = getelementptr i8, ptr %t938, i64 %t902
  call void @olang_textcopy(ptr %t939, ptr %t904, i64 %t905)
  %t940 = getelementptr i8, ptr %t939, i64 %t905
  call void @olang_textcopy(ptr %t940, ptr %t907, i64 %t908)
  %t941 = getelementptr i8, ptr %t940, i64 %t908
  call void @olang_textcopy(ptr %t941, ptr %t911, i64 %t912)
  %t942 = getelementptr i8, ptr %t941, i64 %t912
  call void @olang_textcopy(ptr %t942, ptr %t914, i64 %t915)
  %t943 = getelementptr i8, ptr %t942, i64 %t915
  call void @olang_textcopy(ptr %t943, ptr %t918, i64 %t919)
  %t944 = getelementptr i8, ptr %t943, i64 %t919
  call void @olang_textcopy(ptr %t944, ptr %t921, i64 %t922)
  %t945 = getelementptr i8, ptr %t944, i64 %t922
  call void @olang_textcopy(ptr %t945, ptr %t925, i64 %t926)
  %t946 = getelementptr i8, ptr %t945, i64 %t926
  call void @olang_textcopy(ptr %t946, ptr %t928, i64 %t929)
  %t947 = getelementptr i8, ptr %t946, i64 %t929
  call void @olang_textcopy(ptr %t947, ptr %t932, i64 %t933)
  %t948 = getelementptr i8, ptr %t947, i64 %t933
  call void @olang_textcopy(ptr %t948, ptr %t935, i64 %t936)
  %t949 = insertvalue { i64, ptr } undef, i64 %t937, 0
  %t950 = insertvalue { i64, ptr } %t949, ptr %t938, 1
  %t952 = extractvalue { i64, ptr } %t950, 0
  %t953 = extractvalue { i64, ptr } %t950, 1
  %t954 = mul i64 %t952, 1
  %t955 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t954)
  call void @llvm.memcpy.p0.p0.i64(ptr %t955, ptr %t953, i64 %t954, i1 false)
  %t956 = insertvalue { i64, ptr } undef, i64 %t952, 0
  %t957 = insertvalue { i64, ptr } %t956, ptr %t955, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s13, ptr %t895, { i64, ptr } %t957)
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s13)
  br label %bb46
bb46:
  %t960 = load ptr, ptr %l1, !tbaa !29
  %t961 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t962 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t963 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d387, i32 0, i32 1) }, 1
  %t964 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d387, i32 0, i32 1) }, 0
  %t966 = extractvalue { i64, ptr } %t961, 1
  %t967 = extractvalue { i64, ptr } %t961, 0
  %t968 = add i64 %t964, %t967
  %t969 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d388, i32 0, i32 1) }, 1
  %t970 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d388, i32 0, i32 1) }, 0
  %t971 = add i64 %t968, %t970
  %t973 = extractvalue { i64, ptr } %t962, 1
  %t974 = extractvalue { i64, ptr } %t962, 0
  %t975 = add i64 %t971, %t974
  %t976 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d389, i32 0, i32 1) }, 1
  %t977 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d389, i32 0, i32 1) }, 0
  %t978 = add i64 %t975, %t977
  %t979 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t978)
  call void @olang_textcopy(ptr %t979, ptr %t963, i64 %t964)
  %t980 = getelementptr i8, ptr %t979, i64 %t964
  call void @olang_textcopy(ptr %t980, ptr %t966, i64 %t967)
  %t981 = getelementptr i8, ptr %t980, i64 %t967
  call void @olang_textcopy(ptr %t981, ptr %t969, i64 %t970)
  %t982 = getelementptr i8, ptr %t981, i64 %t970
  call void @olang_textcopy(ptr %t982, ptr %t973, i64 %t974)
  %t983 = getelementptr i8, ptr %t982, i64 %t974
  call void @olang_textcopy(ptr %t983, ptr %t976, i64 %t977)
  %t984 = insertvalue { i64, ptr } undef, i64 %t978, 0
  %t985 = insertvalue { i64, ptr } %t984, ptr %t979, 1
  %t987 = extractvalue { i64, ptr } %t985, 0
  %t988 = extractvalue { i64, ptr } %t985, 1
  %t989 = mul i64 %t987, 1
  %t990 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t989)
  call void @llvm.memcpy.p0.p0.i64(ptr %t990, ptr %t988, i64 %t989, i1 false)
  %t991 = insertvalue { i64, ptr } undef, i64 %t987, 0
  %t992 = insertvalue { i64, ptr } %t991, ptr %t990, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t960, { i64, ptr } %t992)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s2)
  br label %bb48
bb48:
  %t995 = load i32, ptr %l12, !tbaa !23
  %t997 = add i32 %t995, 1
  store i32 %t997, ptr %l12, !tbaa !23
  br label %bb7
bb49:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eviaMem(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i1
  %l9 = alloca i1
  %l18 = alloca i1
  %l23 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  %t7 = load i32, ptr %l1, !tbaa !23
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t11 = icmp eq i32 %t7, %t8
  store i1 %t11, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l5, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb6
bb5:
  %t14 = load i32, ptr %l1, !tbaa !23
  %t15 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t18 = icmp eq i32 %t14, %t15
  store i1 %t18, ptr %l9, !tbaa !21
  br label %bb6
bb6:
  %t20 = load i1, ptr %l9, !tbaa !21
  br i1 %t20, label %bb7, label %bb8
bb7:
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/emit:fnEm", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/emit:Emitter", ptr %t25, i32 0, i32 0
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t29 = load i32, ptr %l1, !tbaa !23
  %t32 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t28, i32 %t29)
  store i1 %t32, ptr %l18
  br label %bb10
bb10:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/emit:fnEm", ptr %t33, i32 0, i32 0
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/emit:Emitter", ptr %t36, i32 0, i32 3
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t40 = load i32, ptr %l1, !tbaa !23
  %t43 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %t39, i32 %t40)
  store i1 %t43, ptr %l23
  br label %bb11
bb11:
  %t44 = load i1, ptr %l23, !tbaa !21
  store i1 %t44, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2ewalkBlock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4, { i64, ptr } %a5, ptr %a6, ptr %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca { i64, [21 x i64] }
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca { i64, [8 x i64] }
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca %"compiler/mir:Range"
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca i32
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i32
  %l33 = alloca i32
  %l34 = alloca %"compiler/mir:Call"
  %l35 = alloca i32
  %l36 = alloca i32
  %l37 = alloca i32
  %l38 = alloca i32
  %l39 = alloca ptr
  %l40 = alloca i64
  %l44 = alloca { i64, ptr }
  %l50 = alloca ptr
  %l53 = alloca i64
  %l57 = alloca i64
  %l60 = alloca i64
  %l81 = alloca { i64, [21 x i64] }
  %l82 = alloca { i64, [21 x i64] }
  %l89 = alloca { i64, [21 x i64] }
  %l101 = alloca ptr
  %l105 = alloca i64
  %l110 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l137 = alloca i32
  %l140 = alloca i32
  %l158 = alloca ptr
  %l166 = alloca %"compiler/mir:Case"
  %l181 = alloca %"compiler/mir:Call"
  %l199 = alloca i1
  %l243 = alloca i64
  %l245 = alloca i64
  %l250 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  store ptr %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l8, !tbaa !29
  %t6 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t6, ptr %l44, !tbaa !27
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !27
  %t11 = getelementptr i64, ptr %t10, i64 %t7
  %t12 = load i64, ptr %t11, !tbaa !34
  store i64 %t12, ptr %l9, !tbaa !24
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t16 = getelementptr %"compiler/mir:Fn", ptr %t14, i32 0, i32 9
  %t17 = load i64, ptr %l3, !tbaa !24
  %t20 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eRef_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v0, ptr %t16, i64 %t17)
  store ptr %t20, ptr %l50
  br label %bb1
bb1:
  %t21 = load ptr, ptr %l50, !tbaa !29
  store ptr %t21, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  %t22 = load ptr, ptr %l10, !tbaa !29
  %t24 = getelementptr %"compiler/mir:BasicBlock", ptr %t22, i32 0, i32 0
  %t26 = call i64 @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eLen(ptr %v0, ptr %t24)
  store i64 %t26, ptr %l53
  br label %bb2
bb2:
  %t27 = load i64, ptr %l53, !tbaa !24
  store i64 %t27, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t28 = load i64, ptr %l12, !tbaa !24
  %t29 = load i64, ptr %l11, !tbaa !24
  %t32 = icmp sgt i64 %t28, %t29
  br i1 %t32, label %bb3, label %bb4
bb3:
  %t34 = load i64, ptr %l13, !tbaa !24
  %t36 = icmp sgt i64 %t34, 0
  br i1 %t36, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb8
bb5:
  %t38 = load i64, ptr %l12, !tbaa !24
  %t39 = load i64, ptr %l11, !tbaa !24
  %t42 = sub i64 %t38, %t39
  %t43 = load i64, ptr %l13, !tbaa !24
  %t46 = add i64 %t42, %t43
  %t48 = sub i64 %t46, 1
  %t49 = load i64, ptr %l13, !tbaa !24
  %t52 = sdiv i64 %t48, %t49
  store i64 %t52, ptr %l60, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l60, !tbaa !24
  br label %bb7
bb7:
  %t54 = load i64, ptr %l60, !tbaa !24
  store i64 %t54, ptr %l57, !tbaa !24
  br label %bb8
bb8:
  %t55 = load i64, ptr %l57, !tbaa !24
  store i64 %t55, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb9
bb9:
  %t56 = load i64, ptr %l15, !tbaa !24
  %t57 = load i64, ptr %l14, !tbaa !24
  %t60 = icmp slt i64 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb10, label %bb11
bb10:
  br label %bb42
bb11:
  br label %bb12
bb12:
  %t64 = load i64, ptr %l11, !tbaa !24
  %t65 = load i64, ptr %l15, !tbaa !24
  %t66 = load i64, ptr %l13, !tbaa !24
  %t69 = mul i64 %t65, %t66
  %t72 = add i64 %t64, %t69
  store i64 %t72, ptr %l16, !tbaa !24
  %t74 = load ptr, ptr %l10, !tbaa !29
  %t76 = getelementptr %"compiler/mir:BasicBlock", ptr %t74, i32 0, i32 0
  %t77 = load i64, ptr %l16, !tbaa !24
  %t80 = call { i64, [21 x i64] } @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eAt(ptr %v0, ptr %t76, i64 %t77)
  store { i64, [21 x i64] } %t80, ptr %l81
  br label %bb13
bb13:
  call void @llvm.memmove.p0.p0.i64(ptr %l17, ptr %l81, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l82, ptr %l17, i64 176, i1 false)
  %t81 = load { i64, [21 x i64] }, ptr %l82
  %t82 = extractvalue { i64, [21 x i64] } %t81, 0
  %t83 = icmp eq i64 %t82, 3
  br i1 %t83, label %bb14, label %bb15
bb14:
  %t85 = getelementptr { i64, [21 x i64] }, ptr %l17, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", i32 }, ptr %t85, i32 0, i32 1
  %t87 = load i32, ptr %t86
  store i32 %t87, ptr %l18, !tbaa !23
  br label %bb16
bb15:
  br label %bb20
bb16:
  %t89 = load i32, ptr %l18, !tbaa !23
  %t91 = sext i32 %t89 to i64
  %t92 = load i64, ptr %l1, !tbaa !24
  %t95 = icmp eq i64 %t91, %t92
  br i1 %t95, label %bb17, label %bb18
bb17:
  store i64 0, ptr %l9, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  br label %bb40
bb20:
  call void @llvm.memmove.p0.p0.i64(ptr %l89, ptr %l17, i64 176, i1 false)
  %t97 = load { i64, [21 x i64] }, ptr %l89
  %t98 = extractvalue { i64, [21 x i64] } %t97, 0
  %t99 = icmp eq i64 %t98, 4
  br i1 %t99, label %bb21, label %bb22
bb21:
  %t101 = getelementptr { i64, [21 x i64] }, ptr %l17, i32 0, i32 1
  %t102 = getelementptr { %"compiler/source:Span", i32 }, ptr %t101, i32 0, i32 1
  %t103 = load i32, ptr %t102
  store i32 %t103, ptr %l19, !tbaa !23
  br label %bb23
bb22:
  br label %bb35
bb23:
  %t105 = load i32, ptr %l19, !tbaa !23
  %t107 = sext i32 %t105 to i64
  %t108 = load i64, ptr %l1, !tbaa !24
  %t111 = icmp ne i64 %t107, %t108
  br i1 %t111, label %bb24, label %bb25
bb24:
  br label %bb41
bb25:
  br label %bb26
bb26:
  %t113 = load i64, ptr %l4, !tbaa !24
  %t115 = icmp eq i64 %t113, 1
  br i1 %t115, label %bb27, label %bb28
bb27:
  %t117 = load i64, ptr %l9, !tbaa !24
  %t119 = icmp eq i64 %t117, 2
  br i1 %t119, label %bb29, label %bb30
bb28:
  br label %bb34
bb29:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  store ptr %a7, ptr %l101, !tbaa !29
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load i64, ptr %l3, !tbaa !24
  %t125 = load i64, ptr %l16, !tbaa !24
  %t129 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ewalkKey(ptr %v0, ptr %t123, i64 %t124, i64 %t125)
  store i64 %t129, ptr %l105
  br label %bb32
bb32:
  %t130 = load i64, ptr %l9, !tbaa !24
  %t132 = icmp eq i64 %t130, 1
  %t133 = load ptr, ptr %l101, !tbaa !29
  %t134 = load i64, ptr %l105, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v3, ptr %t133, i64 %t134, i1 %t132)
  br label %bb33
bb33:
  br label %bb34
bb34:
  store i64 0, ptr %l9, !tbaa !24
  br label %bb40
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_93708b25bcca1908_59bc9d4dcf3d1544)
  unreachable
bb40:
  br label %bb41
bb41:
  %t136 = load i64, ptr %l15, !tbaa !24
  %t138 = add i64 %t136, 1
  store i64 %t138, ptr %l15, !tbaa !24
  br label %bb9
bb42:
  %t140 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t140, ptr %l110
  br label %bb43
bb43:
  %t141 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l110
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t141, ptr %l20
  %t142 = load ptr, ptr %l10, !tbaa !29
  %t144 = getelementptr %"compiler/mir:BasicBlock", ptr %t142, i32 0, i32 1
  %t145 = load { i64, [8 x i64] }, ptr %t144
  store { i64, [8 x i64] } %t145, ptr %l21
  %t147 = load { i64, [8 x i64] }, ptr %l21
  %t149 = extractvalue { i64, [8 x i64] } %t147, 0
  %t150 = icmp eq i64 %t149, 1
  br i1 %t150, label %bb44, label %bb45
bb44:
  %t152 = getelementptr { i64, [8 x i64] }, ptr %l21, i32 0, i32 1
  %t153 = getelementptr { i32 }, ptr %t152, i32 0, i32 0
  %t154 = load i32, ptr %t153
  store i32 %t154, ptr %l22, !tbaa !23
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t156 = load i32, ptr %l22, !tbaa !23
  %t158 = sext i32 %t156 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l20, i64 %t158)
  br label %bb47
bb47:
  br label %bb120
bb48:
  %t161 = load { i64, [8 x i64] }, ptr %l21
  %t163 = extractvalue { i64, [8 x i64] } %t161, 0
  %t164 = icmp eq i64 %t163, 2
  br i1 %t164, label %bb49, label %bb50
bb49:
  %t166 = getelementptr { i64, [8 x i64] }, ptr %l21, i32 0, i32 1
  %t167 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t166, i32 0, i32 1
  %t168 = load i32, ptr %t167
  store i32 %t168, ptr %l23, !tbaa !23
  %t170 = getelementptr { i64, [8 x i64] }, ptr %l21, i32 0, i32 1
  %t171 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t170, i32 0, i32 2
  %t172 = load i32, ptr %t171
  store i32 %t172, ptr %l24, !tbaa !23
  br label %bb51
bb50:
  br label %bb54
bb51:
  %t174 = load i32, ptr %l23, !tbaa !23
  %t176 = sext i32 %t174 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l20, i64 %t176)
  br label %bb52
bb52:
  %t179 = load i32, ptr %l24, !tbaa !23
  %t181 = sext i32 %t179 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l20, i64 %t181)
  br label %bb53
bb53:
  br label %bb120
bb54:
  %t184 = load { i64, [8 x i64] }, ptr %l21
  %t186 = extractvalue { i64, [8 x i64] } %t184, 0
  %t187 = icmp eq i64 %t186, 3
  br i1 %t187, label %bb55, label %bb56
bb55:
  %t189 = getelementptr { i64, [8 x i64] }, ptr %l21, i32 0, i32 1
  %t190 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t189, i32 0, i32 1
  %t191 = load %"compiler/mir:Range", ptr %t190
  store %"compiler/mir:Range" %t191, ptr %l25
  %t193 = getelementptr { i64, [8 x i64] }, ptr %l21, i32 0, i32 1
  %t194 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t193, i32 0, i32 2
  %t195 = load i32, ptr %t194
  store i32 %t195, ptr %l26, !tbaa !23
  br label %bb57
bb56:
  br label %bb73
bb57:
  store i32 0, ptr %l27, !tbaa !23
  %t197 = getelementptr %"compiler/mir:Range", ptr %l25, i32 0, i32 1
  %t198 = load i32, ptr %t197, !tbaa !23
  store i32 %t198, ptr %l28, !tbaa !23
  store i32 1, ptr %l29, !tbaa !23
  %t200 = load i32, ptr %l28, !tbaa !23
  %t201 = load i32, ptr %l27, !tbaa !23
  %t204 = icmp sgt i32 %t200, %t201
  br i1 %t204, label %bb58, label %bb59
bb58:
  %t206 = load i32, ptr %l29, !tbaa !23
  %t208 = icmp sgt i32 %t206, 0
  br i1 %t208, label %bb60, label %bb61
bb59:
  store i32 0, ptr %l137, !tbaa !23
  br label %bb63
bb60:
  %t210 = load i32, ptr %l28, !tbaa !23
  %t211 = load i32, ptr %l27, !tbaa !23
  %t214 = sub i32 %t210, %t211
  %t215 = load i32, ptr %l29, !tbaa !23
  %t218 = add i32 %t214, %t215
  %t220 = sub i32 %t218, 1
  %t221 = load i32, ptr %l29, !tbaa !23
  %t224 = sdiv i32 %t220, %t221
  store i32 %t224, ptr %l140, !tbaa !23
  br label %bb62
bb61:
  store i32 0, ptr %l140, !tbaa !23
  br label %bb62
bb62:
  %t226 = load i32, ptr %l140, !tbaa !23
  store i32 %t226, ptr %l137, !tbaa !23
  br label %bb63
bb63:
  %t227 = load i32, ptr %l137, !tbaa !23
  store i32 %t227, ptr %l30, !tbaa !23
  store i32 0, ptr %l31, !tbaa !23
  br label %bb64
bb64:
  %t228 = load i32, ptr %l31, !tbaa !23
  %t229 = load i32, ptr %l30, !tbaa !23
  %t232 = icmp slt i32 %t228, %t229
  %t234 = xor i1 %t232, true
  br i1 %t234, label %bb65, label %bb66
bb65:
  br label %bb71
bb66:
  br label %bb67
bb67:
  %t236 = load i32, ptr %l27, !tbaa !23
  %t237 = load i32, ptr %l31, !tbaa !23
  %t238 = load i32, ptr %l29, !tbaa !23
  %t241 = mul i32 %t237, %t238
  %t244 = add i32 %t236, %t241
  store ptr %l20, ptr %l158, !tbaa !29
  %t246 = load ptr, ptr %l8, !tbaa !29
  %t248 = getelementptr %"compiler/mir:Fn", ptr %t246, i32 0, i32 15
  %t249 = getelementptr %"compiler/mir:Range", ptr %l25, i32 0, i32 0
  %t250 = load i32, ptr %t249, !tbaa !23
  %t252 = sext i32 %t250 to i64
  %t255 = sext i32 %t244 to i64
  %t258 = add i64 %t252, %t255
  %t261 = call %"compiler/mir:Case" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eAt_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %t248, i64 %t258)
  store %"compiler/mir:Case" %t261, ptr %l166
  br label %bb68
bb68:
  %t262 = getelementptr %"compiler/mir:Case", ptr %l166, i32 0, i32 1
  %t263 = load i32, ptr %t262, !tbaa !23
  %t265 = sext i32 %t263 to i64
  %t266 = load ptr, ptr %l158, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t266, i64 %t265)
  br label %bb69
bb69:
  br label %bb70
bb70:
  %t268 = load i32, ptr %l31, !tbaa !23
  %t270 = add i32 %t268, 1
  store i32 %t270, ptr %l31, !tbaa !23
  br label %bb64
bb71:
  %t272 = load i32, ptr %l26, !tbaa !23
  %t274 = sext i32 %t272 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l20, i64 %t274)
  br label %bb72
bb72:
  br label %bb120
bb73:
  %t277 = load { i64, [8 x i64] }, ptr %l21
  %t279 = extractvalue { i64, [8 x i64] } %t277, 0
  %t280 = icmp eq i64 %t279, 4
  br i1 %t280, label %bb74, label %bb75
bb74:
  %t282 = getelementptr { i64, [8 x i64] }, ptr %l21, i32 0, i32 1
  %t283 = getelementptr { %"compiler/source:Span", i32 }, ptr %t282, i32 0, i32 1
  %t284 = load i32, ptr %t283
  store i32 %t284, ptr %l33, !tbaa !23
  br label %bb76
bb75:
  br label %bb100
bb76:
  %t286 = load ptr, ptr %l8, !tbaa !29
  %t288 = getelementptr %"compiler/mir:Fn", ptr %t286, i32 0, i32 14
  %t289 = load i32, ptr %l33, !tbaa !23
  %t291 = sext i32 %t289 to i64
  %t294 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t288, i64 %t291)
  store %"compiler/mir:Call" %t294, ptr %l181
  br label %bb77
bb77:
  %t295 = load %"compiler/mir:Call", ptr %l181
  store %"compiler/mir:Call" %t295, ptr %l34
  %t296 = load i32, ptr %l33, !tbaa !23
  %t298 = sext i32 %t296 to i64
  %t302 = icmp eq i64 %t298, %a2
  br i1 %t302, label %bb78, label %bb79
bb78:
  %t304 = load i64, ptr %l9, !tbaa !24
  %t306 = icmp ne i64 %t304, 0
  br i1 %t306, label %bb80, label %bb81
bb79:
  br label %bb94
bb80:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb81:
  br label %bb82
bb82:
  %t309 = load i64, ptr %l4, !tbaa !24
  %t311 = icmp eq i64 %t309, 0
  br i1 %t311, label %bb83, label %bb84
bb83:
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t314 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t315 = getelementptr %"compiler/mir:Call", ptr %l34, i32 0, i32 5
  %t316 = load i32, ptr %t315, !tbaa !23
  %t318 = sext i32 %t316 to i64
  %t319 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ewalkJoin(ptr %v0, ptr %v1, ptr %v2, ptr %t313, { i64, ptr } %t314, i64 %t318, i64 1, ptr %t319)
  br label %bb85
bb84:
  br label %bb86
bb85:
  br label %bb86
bb86:
  %t324 = getelementptr %"compiler/mir:Call", ptr %l34, i32 0, i32 7
  %t325 = load i32, ptr %t324, !tbaa !23
  %t326 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t329 = icmp ne i32 %t325, %t326
  br i1 %t329, label %bb87, label %bb88
bb87:
  %t331 = load i64, ptr %l4, !tbaa !24
  %t333 = icmp eq i64 %t331, 0
  store i1 %t333, ptr %l199, !tbaa !21
  br label %bb89
bb88:
  store i1 false, ptr %l199, !tbaa !21
  br label %bb89
bb89:
  %t335 = load i1, ptr %l199, !tbaa !21
  br i1 %t335, label %bb90, label %bb91
bb90:
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t337 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t338 = getelementptr %"compiler/mir:Call", ptr %l34, i32 0, i32 7
  %t339 = load i32, ptr %t338, !tbaa !23
  %t341 = sext i32 %t339 to i64
  %t342 = load i64, ptr %l9, !tbaa !24
  %t343 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ewalkJoin(ptr %v0, ptr %v1, ptr %v2, ptr %t336, { i64, ptr } %t337, i64 %t341, i64 %t342, ptr %t343)
  br label %bb92
bb91:
  br label %bb93
bb92:
  br label %bb93
bb93:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb94:
  %t349 = getelementptr %"compiler/mir:Call", ptr %l34, i32 0, i32 5
  %t350 = load i32, ptr %t349, !tbaa !23
  %t352 = sext i32 %t350 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l20, i64 %t352)
  br label %bb95
bb95:
  %t355 = getelementptr %"compiler/mir:Call", ptr %l34, i32 0, i32 7
  %t356 = load i32, ptr %t355, !tbaa !23
  %t357 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t360 = icmp ne i32 %t356, %t357
  br i1 %t360, label %bb96, label %bb97
bb96:
  %t362 = getelementptr %"compiler/mir:Call", ptr %l34, i32 0, i32 7
  %t363 = load i32, ptr %t362, !tbaa !23
  %t365 = sext i32 %t363 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l20, i64 %t365)
  br label %bb98
bb97:
  br label %bb99
bb98:
  br label %bb99
bb99:
  br label %bb120
bb100:
  %t368 = load { i64, [8 x i64] }, ptr %l21
  %t370 = extractvalue { i64, [8 x i64] } %t368, 0
  %t371 = icmp eq i64 %t370, 8
  br i1 %t371, label %bb101, label %bb102
bb101:
  %t373 = getelementptr { i64, [8 x i64] }, ptr %l21, i32 0, i32 1
  %t374 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t373, i32 0, i32 2
  %t375 = load i32, ptr %t374
  store i32 %t375, ptr %l35, !tbaa !23
  %t377 = getelementptr { i64, [8 x i64] }, ptr %l21, i32 0, i32 1
  %t378 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t377, i32 0, i32 4
  %t379 = load i32, ptr %t378
  store i32 %t379, ptr %l36, !tbaa !23
  br label %bb103
bb102:
  br label %bb109
bb103:
  %t381 = load i32, ptr %l35, !tbaa !23
  %t383 = sext i32 %t381 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l20, i64 %t383)
  br label %bb104
bb104:
  %t386 = load i32, ptr %l36, !tbaa !23
  %t387 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t390 = icmp ne i32 %t386, %t387
  br i1 %t390, label %bb105, label %bb106
bb105:
  %t392 = load i32, ptr %l36, !tbaa !23
  %t394 = sext i32 %t392 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l20, i64 %t394)
  br label %bb107
bb106:
  br label %bb108
bb107:
  br label %bb108
bb108:
  br label %bb120
bb109:
  %t397 = load { i64, [8 x i64] }, ptr %l21
  %t399 = extractvalue { i64, [8 x i64] } %t397, 0
  %t400 = icmp eq i64 %t399, 11
  br i1 %t400, label %bb110, label %bb111
bb110:
  %t402 = getelementptr { i64, [8 x i64] }, ptr %l21, i32 0, i32 1
  %t403 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range", i32 }, ptr %t402, i32 0, i32 2
  %t404 = load i32, ptr %t403
  store i32 %t404, ptr %l37, !tbaa !23
  %t406 = getelementptr { i64, [8 x i64] }, ptr %l21, i32 0, i32 1
  %t407 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range", i32 }, ptr %t406, i32 0, i32 4
  %t408 = load i32, ptr %t407
  store i32 %t408, ptr %l38, !tbaa !23
  br label %bb112
bb111:
  br label %bb115
bb112:
  %t410 = load i32, ptr %l37, !tbaa !23
  %t412 = sext i32 %t410 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l20, i64 %t412)
  br label %bb113
bb113:
  %t415 = load i32, ptr %l38, !tbaa !23
  %t417 = sext i32 %t415 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l20, i64 %t417)
  br label %bb114
bb114:
  br label %bb120
bb115:
  br i1 true, label %bb116, label %bb117
bb116:
  br label %bb118
bb117:
  br label %bb119
bb118:
  br label %bb120
bb119:
  call void @__olang_check_failed(ptr @olang_loc_82759c8127bb92d9_9a26fc180f98a435)
  unreachable
bb120:
  %t420 = load i64, ptr %l4, !tbaa !24
  %t422 = icmp eq i64 %t420, 0
  br i1 %t422, label %bb121, label %bb122
bb121:
  store ptr %l20, ptr %l39, !tbaa !29
  store i64 0, ptr %l40, !tbaa !24
  br label %bb123
bb122:
  br label %bb132
bb123:
  %t425 = load i64, ptr %l40, !tbaa !24
  store i64 %t425, ptr %l243, !tbaa !24
  %t426 = load ptr, ptr %l39, !tbaa !29
  %t428 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t426)
  store i64 %t428, ptr %l245
  br label %bb124
bb124:
  %t429 = load i64, ptr %l243, !tbaa !24
  %t430 = load i64, ptr %l245, !tbaa !24
  %t431 = icmp slt i64 %t429, %t430
  %t433 = xor i1 %t431, true
  br i1 %t433, label %bb125, label %bb126
bb125:
  br label %bb131
bb126:
  br label %bb127
bb127:
  %t435 = load ptr, ptr %l39, !tbaa !29
  %t436 = load i64, ptr %l40, !tbaa !24
  %t439 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t435, i64 %t436)
  store i64 %t439, ptr %l250
  br label %bb128
bb128:
  %t440 = load i64, ptr %l250, !tbaa !24
  %t441 = load ptr, ptr %l0, !tbaa !29
  %t442 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t444 = load i64, ptr %l9, !tbaa !24
  %t445 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ewalkJoin(ptr %v0, ptr %v1, ptr %v2, ptr %t441, { i64, ptr } %t442, i64 %t440, i64 %t444, ptr %t445)
  br label %bb129
bb129:
  br label %bb130
bb130:
  %t451 = load i64, ptr %l40, !tbaa !24
  %t453 = add i64 %t451, 1
  store i64 %t453, ptr %l40, !tbaa !24
  br label %bb123
bb131:
  br label %bb132
bb132:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ewideToBF16(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l29 = alloca i1
  %l31 = alloca ptr
  %l34 = alloca i1
  %l35 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l42 = alloca i64
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca [5 x i8]
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca { i64, ptr }
  %l54 = alloca i1
  %l60 = alloca { i64, ptr }
  %l62 = alloca i64
  %l68 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l77 = alloca i64
  %l85 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  %l107 = alloca ptr
  %l112 = alloca { i64, ptr }
  %l115 = alloca { i64, ptr }
  %l116 = alloca ptr
  %l122 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l126 = alloca ptr
  %l127 = alloca ptr
  %l133 = alloca { i64, ptr }
  %l136 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l144 = alloca { i64, ptr }
  %l152 = alloca { i64, ptr }
  %l153 = alloca ptr
  %l154 = alloca ptr
  %l159 = alloca { i64, ptr }
  %l162 = alloca { i64, ptr }
  %l165 = alloca { i64, ptr }
  %l170 = alloca { i64, ptr }
  %l171 = alloca ptr
  %l172 = alloca ptr
  %l175 = alloca { i64, ptr }
  %l179 = alloca { i64, ptr }
  %l181 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i32, ptr %l2, !tbaa !23
  %t13 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s0, ptr %t9, i32 %t10)
  store { i64, ptr } %t13, ptr %l25
  br label %bb1
bb1:
  %t14 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t14, ptr %l4, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = extractvalue { i64, ptr } %t15, 0
  %t19 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t17, i64 %t18)
  %t20 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t25 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t23, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d390, i32 0, i32 1) })
  store i1 %t25, ptr %l29
  br label %bb2
bb2:
  %t26 = load i1, ptr %l29, !tbaa !21
  %t27 = xor i1 %t26, true
  br i1 %t27, label %bb3, label %bb4
bb3:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l31, !tbaa !29
  %t30 = load ptr, ptr %l3, !tbaa !29
  %t31 = load i32, ptr %l2, !tbaa !23
  %t34 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t30, i32 %t31)
  store i1 %t34, ptr %l34
  br label %bb5
bb4:
  br label %bb13
bb5:
  %t35 = load i1, ptr %l34, !tbaa !21
  br i1 %t35, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d391, i32 0, i32 1) }, ptr %l35, !tbaa !27
  br label %bb8
bb7:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d392, i32 0, i32 1) }, ptr %l35, !tbaa !27
  br label %bb8
bb8:
  %t36 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 1
  %t40 = extractvalue { i64, ptr } %t38, 0
  %t42 = extractvalue { i64, ptr } %t36, 1
  %t43 = extractvalue { i64, ptr } %t36, 0
  %t44 = add i64 %t40, %t43
  %t45 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d393, i32 0, i32 1) }, 1
  %t46 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d393, i32 0, i32 1) }, 0
  %t47 = add i64 %t44, %t46
  %t49 = extractvalue { i64, ptr } %t37, 1
  %t50 = extractvalue { i64, ptr } %t37, 0
  %t51 = add i64 %t47, %t50
  %t52 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d394, i32 0, i32 1) }, 1
  %t53 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d394, i32 0, i32 1) }, 0
  %t54 = add i64 %t51, %t53
  %t55 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t54)
  call void @olang_textcopy(ptr %t55, ptr %t39, i64 %t40)
  %t56 = getelementptr i8, ptr %t55, i64 %t40
  call void @olang_textcopy(ptr %t56, ptr %t42, i64 %t43)
  %t57 = getelementptr i8, ptr %t56, i64 %t43
  call void @olang_textcopy(ptr %t57, ptr %t45, i64 %t46)
  %t58 = getelementptr i8, ptr %t57, i64 %t46
  call void @olang_textcopy(ptr %t58, ptr %t49, i64 %t50)
  %t59 = getelementptr i8, ptr %t58, i64 %t50
  call void @olang_textcopy(ptr %t59, ptr %t52, i64 %t53)
  %t60 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t55, 1
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t64 = extractvalue { i64, ptr } %t61, 1
  %t65 = mul i64 %t63, 1
  %t66 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t65)
  call void @llvm.memcpy.p0.p0.i64(ptr %t66, ptr %t64, i64 %t65, i1 false)
  %t67 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  %t69 = load ptr, ptr %l31, !tbaa !29
  %t71 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t69, { i64, ptr } %t68)
  store { i64, ptr } %t71, ptr %l40
  br label %bb9
bb9:
  %t72 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 0
  %t74 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t74, 0
  store i64 %t75, ptr %l42, !tbaa !24
  %t77 = load i64, ptr %l42, !tbaa !24
  %t78 = icmp eq i64 %t73, %t77
  br i1 %t78, label %bb10, label %bb11
bb10:
  %t80 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = load i64, ptr %l42, !tbaa !24
  %t85 = mul i64 %t84, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t81, ptr %t83, i64 %t85, i1 false)
  br label %bb12
bb11:
  %t86 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t86, ptr %l5, !tbaa !27
  br label %bb12
bb12:
  br label %bb13
bb13:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d395, i32 0, i32 1) }, ptr %l44, !tbaa !27
  %t87 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t87, ptr %l45, !tbaa !27
  %t88 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = mul i64 5, 1
  call void @llvm.memmove.p0.p0.i64(ptr %l46, ptr %t89, i64 %t90, i1 false)
  %t92 = insertvalue { i64, ptr } undef, i64 5, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %l46, 1
  store { i64, ptr } %t93, ptr %l6, !tbaa !27
  %t95 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t95, ptr %l49, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 0
  store i64 %t97, ptr %l50, !tbaa !24
  %t98 = load i64, ptr %l50, !tbaa !24
  %t99 = mul i64 %t98, 1
  %t100 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t99)
  %t101 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t100, 1
  store { i64, ptr } %t102, ptr %l51, !tbaa !27
  %t103 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = load i64, ptr %l50, !tbaa !24
  %t108 = mul i64 %t107, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t104, ptr %t106, i64 %t108, i1 false)
  %t109 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t109, ptr %l7, !tbaa !27
  %t110 = load ptr, ptr %l3, !tbaa !29
  %t111 = load i32, ptr %l2, !tbaa !23
  %t114 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t110, i32 %t111)
  store i1 %t114, ptr %l54
  br label %bb14
bb14:
  %t115 = load i1, ptr %l54, !tbaa !21
  %t116 = xor i1 %t115, true
  br i1 %t116, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t120 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d396, i32 0, i32 1) }, 1
  %t121 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d396, i32 0, i32 1) }, 0
  %t123 = extractvalue { i64, ptr } %t119, 1
  %t124 = extractvalue { i64, ptr } %t119, 0
  %t125 = add i64 %t121, %t124
  %t126 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d397, i32 0, i32 1) }, 1
  %t127 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d397, i32 0, i32 1) }, 0
  %t128 = add i64 %t125, %t127
  %t129 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t128)
  call void @olang_textcopy(ptr %t129, ptr %t120, i64 %t121)
  %t130 = getelementptr i8, ptr %t129, i64 %t121
  call void @olang_textcopy(ptr %t130, ptr %t123, i64 %t124)
  %t131 = getelementptr i8, ptr %t130, i64 %t124
  call void @olang_textcopy(ptr %t131, ptr %t126, i64 %t127)
  %t132 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr %t129, 1
  %t135 = extractvalue { i64, ptr } %t133, 0
  %t136 = extractvalue { i64, ptr } %t133, 1
  %t137 = mul i64 %t135, 1
  %t138 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t137)
  call void @llvm.memcpy.p0.p0.i64(ptr %t138, ptr %t136, i64 %t137, i1 false)
  %t139 = insertvalue { i64, ptr } undef, i64 %t135, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr %t138, 1
  %t143 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t118, { i64, ptr } %t140)
  store { i64, ptr } %t143, ptr %l60
  br label %bb17
bb16:
  br label %bb26
bb17:
  %t144 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t144, 0
  %t146 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t146, 0
  store i64 %t147, ptr %l62, !tbaa !24
  %t149 = load i64, ptr %l62, !tbaa !24
  %t150 = icmp eq i64 %t145, %t149
  br i1 %t150, label %bb18, label %bb19
bb18:
  %t152 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = load i64, ptr %l62, !tbaa !24
  %t157 = mul i64 %t156, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t153, ptr %t155, i64 %t157, i1 false)
  br label %bb20
bb19:
  %t158 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t158, ptr %l6, !tbaa !27
  br label %bb20
bb20:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t161 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d398, i32 0, i32 1) }, 1
  %t162 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d398, i32 0, i32 1) }, 0
  %t164 = extractvalue { i64, ptr } %t160, 1
  %t165 = extractvalue { i64, ptr } %t160, 0
  %t166 = add i64 %t162, %t165
  %t167 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t166)
  call void @olang_textcopy(ptr %t167, ptr %t161, i64 %t162)
  %t168 = getelementptr i8, ptr %t167, i64 %t162
  call void @olang_textcopy(ptr %t168, ptr %t164, i64 %t165)
  %t169 = insertvalue { i64, ptr } undef, i64 %t166, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t167, 1
  %t172 = extractvalue { i64, ptr } %t170, 0
  %t173 = extractvalue { i64, ptr } %t170, 1
  %t174 = mul i64 %t172, 1
  %t175 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t174)
  call void @llvm.memcpy.p0.p0.i64(ptr %t175, ptr %t173, i64 %t174, i1 false)
  %t176 = insertvalue { i64, ptr } undef, i64 %t172, 0
  %t177 = insertvalue { i64, ptr } %t176, ptr %t175, 1
  %t180 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s4, ptr %s4, ptr %t159, { i64, ptr } %t177)
  store { i64, ptr } %t180, ptr %l68
  br label %bb21
bb21:
  %t181 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t185 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t186 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d399, i32 0, i32 1) }, 1
  %t187 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d399, i32 0, i32 1) }, 0
  %t189 = extractvalue { i64, ptr } %t183, 1
  %t190 = extractvalue { i64, ptr } %t183, 0
  %t191 = add i64 %t187, %t190
  %t192 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d400, i32 0, i32 1) }, 1
  %t193 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d400, i32 0, i32 1) }, 0
  %t194 = add i64 %t191, %t193
  %t196 = extractvalue { i64, ptr } %t181, 1
  %t197 = extractvalue { i64, ptr } %t181, 0
  %t198 = add i64 %t194, %t197
  %t199 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d400, i32 0, i32 1) }, 1
  %t200 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d400, i32 0, i32 1) }, 0
  %t201 = add i64 %t198, %t200
  %t203 = extractvalue { i64, ptr } %t185, 1
  %t204 = extractvalue { i64, ptr } %t185, 0
  %t205 = add i64 %t201, %t204
  %t206 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t205)
  call void @olang_textcopy(ptr %t206, ptr %t186, i64 %t187)
  %t207 = getelementptr i8, ptr %t206, i64 %t187
  call void @olang_textcopy(ptr %t207, ptr %t189, i64 %t190)
  %t208 = getelementptr i8, ptr %t207, i64 %t190
  call void @olang_textcopy(ptr %t208, ptr %t192, i64 %t193)
  %t209 = getelementptr i8, ptr %t208, i64 %t193
  call void @olang_textcopy(ptr %t209, ptr %t196, i64 %t197)
  %t210 = getelementptr i8, ptr %t209, i64 %t197
  call void @olang_textcopy(ptr %t210, ptr %t199, i64 %t200)
  %t211 = getelementptr i8, ptr %t210, i64 %t200
  call void @olang_textcopy(ptr %t211, ptr %t203, i64 %t204)
  %t212 = insertvalue { i64, ptr } undef, i64 %t205, 0
  %t213 = insertvalue { i64, ptr } %t212, ptr %t206, 1
  %t215 = extractvalue { i64, ptr } %t213, 0
  %t216 = extractvalue { i64, ptr } %t213, 1
  %t217 = mul i64 %t215, 1
  %t218 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t217)
  call void @llvm.memcpy.p0.p0.i64(ptr %t218, ptr %t216, i64 %t217, i1 false)
  %t219 = insertvalue { i64, ptr } undef, i64 %t215, 0
  %t220 = insertvalue { i64, ptr } %t219, ptr %t218, 1
  %t223 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t182, { i64, ptr } %t220)
  store { i64, ptr } %t223, ptr %l75
  br label %bb22
bb22:
  %t224 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t225 = extractvalue { i64, ptr } %t224, 0
  %t226 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t227 = extractvalue { i64, ptr } %t226, 0
  store i64 %t227, ptr %l77, !tbaa !24
  %t229 = load i64, ptr %l77, !tbaa !24
  %t230 = icmp eq i64 %t225, %t229
  br i1 %t230, label %bb23, label %bb24
bb23:
  %t232 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !27
  %t234 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = load i64, ptr %l77, !tbaa !24
  %t237 = mul i64 %t236, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t233, ptr %t235, i64 %t237, i1 false)
  br label %bb25
bb24:
  %t238 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t238, ptr %l7, !tbaa !27
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s4)
  br label %bb26
bb26:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"compiler/emit:fnEm", ptr %t239, i32 0, i32 0
  %t242 = load ptr, ptr %t241, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t242, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d401, i32 0, i32 1) }, { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d402, i32 0, i32 1) })
  br label %bb27
bb27:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t245 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t246 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d403, i32 0, i32 1) }, 1
  %t247 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d403, i32 0, i32 1) }, 0
  %t249 = extractvalue { i64, ptr } %t245, 1
  %t250 = extractvalue { i64, ptr } %t245, 0
  %t251 = add i64 %t247, %t250
  %t252 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d404, i32 0, i32 1) }, 1
  %t253 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d404, i32 0, i32 1) }, 0
  %t254 = add i64 %t251, %t253
  %t255 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t254)
  call void @olang_textcopy(ptr %t255, ptr %t246, i64 %t247)
  %t256 = getelementptr i8, ptr %t255, i64 %t247
  call void @olang_textcopy(ptr %t256, ptr %t249, i64 %t250)
  %t257 = getelementptr i8, ptr %t256, i64 %t250
  call void @olang_textcopy(ptr %t257, ptr %t252, i64 %t253)
  %t258 = insertvalue { i64, ptr } undef, i64 %t254, 0
  %t259 = insertvalue { i64, ptr } %t258, ptr %t255, 1
  %t261 = extractvalue { i64, ptr } %t259, 0
  %t262 = extractvalue { i64, ptr } %t259, 1
  %t263 = mul i64 %t261, 1
  %t264 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t263)
  call void @llvm.memcpy.p0.p0.i64(ptr %t264, ptr %t262, i64 %t263, i1 false)
  %t265 = insertvalue { i64, ptr } undef, i64 %t261, 0
  %t266 = insertvalue { i64, ptr } %t265, ptr %t264, 1
  %t269 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t244, { i64, ptr } %t266)
  store { i64, ptr } %t269, ptr %l85
  br label %bb28
bb28:
  %t270 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t273 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d405, i32 0, i32 1) }, 1
  %t274 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d405, i32 0, i32 1) }, 0
  %t276 = extractvalue { i64, ptr } %t270, 1
  %t277 = extractvalue { i64, ptr } %t270, 0
  %t278 = add i64 %t274, %t277
  %t279 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d406, i32 0, i32 1) }, 1
  %t280 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d406, i32 0, i32 1) }, 0
  %t281 = add i64 %t278, %t280
  %t282 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t281)
  call void @olang_textcopy(ptr %t282, ptr %t273, i64 %t274)
  %t283 = getelementptr i8, ptr %t282, i64 %t274
  call void @olang_textcopy(ptr %t283, ptr %t276, i64 %t277)
  %t284 = getelementptr i8, ptr %t283, i64 %t277
  call void @olang_textcopy(ptr %t284, ptr %t279, i64 %t280)
  %t285 = insertvalue { i64, ptr } undef, i64 %t281, 0
  %t286 = insertvalue { i64, ptr } %t285, ptr %t282, 1
  %t288 = extractvalue { i64, ptr } %t286, 0
  %t289 = extractvalue { i64, ptr } %t286, 1
  %t290 = mul i64 %t288, 1
  %t291 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t290)
  call void @llvm.memcpy.p0.p0.i64(ptr %t291, ptr %t289, i64 %t290, i1 false)
  %t292 = insertvalue { i64, ptr } undef, i64 %t288, 0
  %t293 = insertvalue { i64, ptr } %t292, ptr %t291, 1
  %t296 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t271, { i64, ptr } %t293)
  store { i64, ptr } %t296, ptr %l90
  br label %bb29
bb29:
  %t297 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t300 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d407, i32 0, i32 1) }, 1
  %t301 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d407, i32 0, i32 1) }, 0
  %t303 = extractvalue { i64, ptr } %t297, 1
  %t304 = extractvalue { i64, ptr } %t297, 0
  %t305 = add i64 %t301, %t304
  %t306 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t305)
  call void @olang_textcopy(ptr %t306, ptr %t300, i64 %t301)
  %t307 = getelementptr i8, ptr %t306, i64 %t301
  call void @olang_textcopy(ptr %t307, ptr %t303, i64 %t304)
  %t308 = insertvalue { i64, ptr } undef, i64 %t305, 0
  %t309 = insertvalue { i64, ptr } %t308, ptr %t306, 1
  %t311 = extractvalue { i64, ptr } %t309, 0
  %t312 = extractvalue { i64, ptr } %t309, 1
  %t313 = mul i64 %t311, 1
  %t314 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t313)
  call void @llvm.memcpy.p0.p0.i64(ptr %t314, ptr %t312, i64 %t313, i1 false)
  %t315 = insertvalue { i64, ptr } undef, i64 %t311, 0
  %t316 = insertvalue { i64, ptr } %t315, ptr %t314, 1
  %t319 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t298, { i64, ptr } %t316)
  store { i64, ptr } %t319, ptr %l95
  br label %bb30
bb30:
  %t320 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t320, ptr %l11, !tbaa !27
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t322 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t323 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d408, i32 0, i32 1) }, 1
  %t324 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d408, i32 0, i32 1) }, 0
  %t326 = extractvalue { i64, ptr } %t322, 1
  %t327 = extractvalue { i64, ptr } %t322, 0
  %t328 = add i64 %t324, %t327
  %t329 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d409, i32 0, i32 1) }, 1
  %t330 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d409, i32 0, i32 1) }, 0
  %t331 = add i64 %t328, %t330
  %t332 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t331)
  call void @olang_textcopy(ptr %t332, ptr %t323, i64 %t324)
  %t333 = getelementptr i8, ptr %t332, i64 %t324
  call void @olang_textcopy(ptr %t333, ptr %t326, i64 %t327)
  %t334 = getelementptr i8, ptr %t333, i64 %t327
  call void @olang_textcopy(ptr %t334, ptr %t329, i64 %t330)
  %t335 = insertvalue { i64, ptr } undef, i64 %t331, 0
  %t336 = insertvalue { i64, ptr } %t335, ptr %t332, 1
  %t338 = extractvalue { i64, ptr } %t336, 0
  %t339 = extractvalue { i64, ptr } %t336, 1
  %t340 = mul i64 %t338, 1
  %t341 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t340)
  call void @llvm.memcpy.p0.p0.i64(ptr %t341, ptr %t339, i64 %t340, i1 false)
  %t342 = insertvalue { i64, ptr } undef, i64 %t338, 0
  %t343 = insertvalue { i64, ptr } %t342, ptr %t341, 1
  %t346 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t321, { i64, ptr } %t343)
  store { i64, ptr } %t346, ptr %l100
  br label %bb31
bb31:
  %t347 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t350 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t351 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d410, i32 0, i32 1) }, 1
  %t352 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d410, i32 0, i32 1) }, 0
  %t354 = extractvalue { i64, ptr } %t347, 1
  %t355 = extractvalue { i64, ptr } %t347, 0
  %t356 = add i64 %t352, %t355
  %t357 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d411, i32 0, i32 1) }, 1
  %t358 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d411, i32 0, i32 1) }, 0
  %t359 = add i64 %t356, %t358
  %t361 = extractvalue { i64, ptr } %t350, 1
  %t362 = extractvalue { i64, ptr } %t350, 0
  %t363 = add i64 %t359, %t362
  %t364 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d412, i32 0, i32 1) }, 1
  %t365 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d412, i32 0, i32 1) }, 0
  %t366 = add i64 %t363, %t365
  %t367 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t366)
  call void @olang_textcopy(ptr %t367, ptr %t351, i64 %t352)
  %t368 = getelementptr i8, ptr %t367, i64 %t352
  call void @olang_textcopy(ptr %t368, ptr %t354, i64 %t355)
  %t369 = getelementptr i8, ptr %t368, i64 %t355
  call void @olang_textcopy(ptr %t369, ptr %t357, i64 %t358)
  %t370 = getelementptr i8, ptr %t369, i64 %t358
  call void @olang_textcopy(ptr %t370, ptr %t361, i64 %t362)
  %t371 = getelementptr i8, ptr %t370, i64 %t362
  call void @olang_textcopy(ptr %t371, ptr %t364, i64 %t365)
  %t372 = insertvalue { i64, ptr } undef, i64 %t366, 0
  %t373 = insertvalue { i64, ptr } %t372, ptr %t367, 1
  %t375 = extractvalue { i64, ptr } %t373, 0
  %t376 = extractvalue { i64, ptr } %t373, 1
  %t377 = mul i64 %t375, 1
  %t378 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t377)
  call void @llvm.memcpy.p0.p0.i64(ptr %t378, ptr %t376, i64 %t377, i1 false)
  %t379 = insertvalue { i64, ptr } undef, i64 %t375, 0
  %t380 = insertvalue { i64, ptr } %t379, ptr %t378, 1
  %t383 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t348, { i64, ptr } %t380)
  store { i64, ptr } %t383, ptr %l106
  br label %bb32
bb32:
  %t384 = load { i64, ptr }, ptr %l106, !tbaa !27
  store { i64, ptr } %t384, ptr %l13, !tbaa !27
  %t385 = load ptr, ptr %l0, !tbaa !29
  store ptr %t385, ptr %l107, !tbaa !29
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t387 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t388 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d413, i32 0, i32 1) }, 1
  %t389 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d413, i32 0, i32 1) }, 0
  %t391 = extractvalue { i64, ptr } %t387, 1
  %t392 = extractvalue { i64, ptr } %t387, 0
  %t393 = add i64 %t389, %t392
  %t394 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t393)
  call void @olang_textcopy(ptr %t394, ptr %t388, i64 %t389)
  %t395 = getelementptr i8, ptr %t394, i64 %t389
  call void @olang_textcopy(ptr %t395, ptr %t391, i64 %t392)
  %t396 = insertvalue { i64, ptr } undef, i64 %t393, 0
  %t397 = insertvalue { i64, ptr } %t396, ptr %t394, 1
  %t399 = extractvalue { i64, ptr } %t397, 0
  %t400 = extractvalue { i64, ptr } %t397, 1
  %t401 = mul i64 %t399, 1
  %t402 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t401)
  call void @llvm.memcpy.p0.p0.i64(ptr %t402, ptr %t400, i64 %t401, i1 false)
  %t403 = insertvalue { i64, ptr } undef, i64 %t399, 0
  %t404 = insertvalue { i64, ptr } %t403, ptr %t402, 1
  %t407 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t386, { i64, ptr } %t404)
  store { i64, ptr } %t407, ptr %l112
  br label %bb33
bb33:
  %t408 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d414, i32 0, i32 1) }, 1
  %t409 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d414, i32 0, i32 1) }, 0
  %t410 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t411 = extractvalue { i64, ptr } %t410, 1
  %t412 = extractvalue { i64, ptr } %t410, 0
  %t413 = add i64 %t409, %t412
  %t414 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d415, i32 0, i32 1) }, 1
  %t415 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d415, i32 0, i32 1) }, 0
  %t416 = add i64 %t413, %t415
  %t417 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t416)
  call void @olang_textcopy(ptr %t417, ptr %t408, i64 %t409)
  %t418 = getelementptr i8, ptr %t417, i64 %t409
  call void @olang_textcopy(ptr %t418, ptr %t411, i64 %t412)
  %t419 = getelementptr i8, ptr %t418, i64 %t412
  call void @olang_textcopy(ptr %t419, ptr %t414, i64 %t415)
  %t420 = insertvalue { i64, ptr } undef, i64 %t416, 0
  %t421 = insertvalue { i64, ptr } %t420, ptr %t417, 1
  %t423 = extractvalue { i64, ptr } %t421, 0
  %t424 = extractvalue { i64, ptr } %t421, 1
  %t425 = mul i64 %t423, 1
  %t426 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t425)
  call void @llvm.memcpy.p0.p0.i64(ptr %t426, ptr %t424, i64 %t425, i1 false)
  %t427 = insertvalue { i64, ptr } undef, i64 %t423, 0
  %t428 = insertvalue { i64, ptr } %t427, ptr %t426, 1
  %t429 = load ptr, ptr %l107, !tbaa !29
  %t431 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t429, { i64, ptr } %t428)
  store { i64, ptr } %t431, ptr %l115
  br label %bb34
bb34:
  %t432 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t433 = load ptr, ptr %l0, !tbaa !29
  store ptr %t433, ptr %l116, !tbaa !29
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t435 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t437 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d416, i32 0, i32 1) }, 1
  %t438 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d416, i32 0, i32 1) }, 0
  %t440 = extractvalue { i64, ptr } %t435, 1
  %t441 = extractvalue { i64, ptr } %t435, 0
  %t442 = add i64 %t438, %t441
  %t443 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d417, i32 0, i32 1) }, 1
  %t444 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d417, i32 0, i32 1) }, 0
  %t445 = add i64 %t442, %t444
  %t447 = extractvalue { i64, ptr } %t432, 1
  %t448 = extractvalue { i64, ptr } %t432, 0
  %t449 = add i64 %t445, %t448
  %t450 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t449)
  call void @olang_textcopy(ptr %t450, ptr %t437, i64 %t438)
  %t451 = getelementptr i8, ptr %t450, i64 %t438
  call void @olang_textcopy(ptr %t451, ptr %t440, i64 %t441)
  %t452 = getelementptr i8, ptr %t451, i64 %t441
  call void @olang_textcopy(ptr %t452, ptr %t443, i64 %t444)
  %t453 = getelementptr i8, ptr %t452, i64 %t444
  call void @olang_textcopy(ptr %t453, ptr %t447, i64 %t448)
  %t454 = insertvalue { i64, ptr } undef, i64 %t449, 0
  %t455 = insertvalue { i64, ptr } %t454, ptr %t450, 1
  %t457 = extractvalue { i64, ptr } %t455, 0
  %t458 = extractvalue { i64, ptr } %t455, 1
  %t459 = mul i64 %t457, 1
  %t460 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t459)
  call void @llvm.memcpy.p0.p0.i64(ptr %t460, ptr %t458, i64 %t459, i1 false)
  %t461 = insertvalue { i64, ptr } undef, i64 %t457, 0
  %t462 = insertvalue { i64, ptr } %t461, ptr %t460, 1
  %t465 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t434, { i64, ptr } %t462)
  store { i64, ptr } %t465, ptr %l122
  br label %bb35
bb35:
  %t466 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d418, i32 0, i32 1) }, 1
  %t467 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d418, i32 0, i32 1) }, 0
  %t468 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t469 = extractvalue { i64, ptr } %t468, 1
  %t470 = extractvalue { i64, ptr } %t468, 0
  %t471 = add i64 %t467, %t470
  %t472 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d419, i32 0, i32 1) }, 1
  %t473 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d419, i32 0, i32 1) }, 0
  %t474 = add i64 %t471, %t473
  %t475 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t474)
  call void @olang_textcopy(ptr %t475, ptr %t466, i64 %t467)
  %t476 = getelementptr i8, ptr %t475, i64 %t467
  call void @olang_textcopy(ptr %t476, ptr %t469, i64 %t470)
  %t477 = getelementptr i8, ptr %t476, i64 %t470
  call void @olang_textcopy(ptr %t477, ptr %t472, i64 %t473)
  %t478 = insertvalue { i64, ptr } undef, i64 %t474, 0
  %t479 = insertvalue { i64, ptr } %t478, ptr %t475, 1
  %t481 = extractvalue { i64, ptr } %t479, 0
  %t482 = extractvalue { i64, ptr } %t479, 1
  %t483 = mul i64 %t481, 1
  %t484 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t483)
  call void @llvm.memcpy.p0.p0.i64(ptr %t484, ptr %t482, i64 %t483, i1 false)
  %t485 = insertvalue { i64, ptr } undef, i64 %t481, 0
  %t486 = insertvalue { i64, ptr } %t485, ptr %t484, 1
  %t487 = load ptr, ptr %l116, !tbaa !29
  %t489 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t487, { i64, ptr } %t486)
  store { i64, ptr } %t489, ptr %l125
  br label %bb36
bb36:
  %t490 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t490, ptr %l15, !tbaa !27
  %t491 = load ptr, ptr %l0, !tbaa !29
  store ptr %t491, ptr %l126, !tbaa !29
  %t492 = load ptr, ptr %l0, !tbaa !29
  store ptr %t492, ptr %l127, !tbaa !29
  %t493 = load ptr, ptr %l0, !tbaa !29
  %t494 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t495 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t496 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d420, i32 0, i32 1) }, 1
  %t497 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d420, i32 0, i32 1) }, 0
  %t499 = extractvalue { i64, ptr } %t494, 1
  %t500 = extractvalue { i64, ptr } %t494, 0
  %t501 = add i64 %t497, %t500
  %t502 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d421, i32 0, i32 1) }, 1
  %t503 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d421, i32 0, i32 1) }, 0
  %t504 = add i64 %t501, %t503
  %t506 = extractvalue { i64, ptr } %t495, 1
  %t507 = extractvalue { i64, ptr } %t495, 0
  %t508 = add i64 %t504, %t507
  %t509 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t508)
  call void @olang_textcopy(ptr %t509, ptr %t496, i64 %t497)
  %t510 = getelementptr i8, ptr %t509, i64 %t497
  call void @olang_textcopy(ptr %t510, ptr %t499, i64 %t500)
  %t511 = getelementptr i8, ptr %t510, i64 %t500
  call void @olang_textcopy(ptr %t511, ptr %t502, i64 %t503)
  %t512 = getelementptr i8, ptr %t511, i64 %t503
  call void @olang_textcopy(ptr %t512, ptr %t506, i64 %t507)
  %t513 = insertvalue { i64, ptr } undef, i64 %t508, 0
  %t514 = insertvalue { i64, ptr } %t513, ptr %t509, 1
  %t516 = extractvalue { i64, ptr } %t514, 0
  %t517 = extractvalue { i64, ptr } %t514, 1
  %t518 = mul i64 %t516, 1
  %t519 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t518)
  call void @llvm.memcpy.p0.p0.i64(ptr %t519, ptr %t517, i64 %t518, i1 false)
  %t520 = insertvalue { i64, ptr } undef, i64 %t516, 0
  %t521 = insertvalue { i64, ptr } %t520, ptr %t519, 1
  %t524 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t493, { i64, ptr } %t521)
  store { i64, ptr } %t524, ptr %l133
  br label %bb37
bb37:
  %t525 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d422, i32 0, i32 1) }, 1
  %t526 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d422, i32 0, i32 1) }, 0
  %t527 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t528 = extractvalue { i64, ptr } %t527, 1
  %t529 = extractvalue { i64, ptr } %t527, 0
  %t530 = add i64 %t526, %t529
  %t531 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d423, i32 0, i32 1) }, 1
  %t532 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d423, i32 0, i32 1) }, 0
  %t533 = add i64 %t530, %t532
  %t534 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t533)
  call void @olang_textcopy(ptr %t534, ptr %t525, i64 %t526)
  %t535 = getelementptr i8, ptr %t534, i64 %t526
  call void @olang_textcopy(ptr %t535, ptr %t528, i64 %t529)
  %t536 = getelementptr i8, ptr %t535, i64 %t529
  call void @olang_textcopy(ptr %t536, ptr %t531, i64 %t532)
  %t537 = insertvalue { i64, ptr } undef, i64 %t533, 0
  %t538 = insertvalue { i64, ptr } %t537, ptr %t534, 1
  %t540 = extractvalue { i64, ptr } %t538, 0
  %t541 = extractvalue { i64, ptr } %t538, 1
  %t542 = mul i64 %t540, 1
  %t543 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t542)
  call void @llvm.memcpy.p0.p0.i64(ptr %t543, ptr %t541, i64 %t542, i1 false)
  %t544 = insertvalue { i64, ptr } undef, i64 %t540, 0
  %t545 = insertvalue { i64, ptr } %t544, ptr %t543, 1
  %t546 = load ptr, ptr %l127, !tbaa !29
  %t548 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t546, { i64, ptr } %t545)
  store { i64, ptr } %t548, ptr %l136
  br label %bb38
bb38:
  %t549 = load ptr, ptr %l0, !tbaa !29
  %t550 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t551 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d424, i32 0, i32 1) }, 1
  %t552 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d424, i32 0, i32 1) }, 0
  %t554 = extractvalue { i64, ptr } %t550, 1
  %t555 = extractvalue { i64, ptr } %t550, 0
  %t556 = add i64 %t552, %t555
  %t557 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d425, i32 0, i32 1) }, 1
  %t558 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d425, i32 0, i32 1) }, 0
  %t559 = add i64 %t556, %t558
  %t560 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t559)
  call void @olang_textcopy(ptr %t560, ptr %t551, i64 %t552)
  %t561 = getelementptr i8, ptr %t560, i64 %t552
  call void @olang_textcopy(ptr %t561, ptr %t554, i64 %t555)
  %t562 = getelementptr i8, ptr %t561, i64 %t555
  call void @olang_textcopy(ptr %t562, ptr %t557, i64 %t558)
  %t563 = insertvalue { i64, ptr } undef, i64 %t559, 0
  %t564 = insertvalue { i64, ptr } %t563, ptr %t560, 1
  %t566 = extractvalue { i64, ptr } %t564, 0
  %t567 = extractvalue { i64, ptr } %t564, 1
  %t568 = mul i64 %t566, 1
  %t569 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t568)
  call void @llvm.memcpy.p0.p0.i64(ptr %t569, ptr %t567, i64 %t568, i1 false)
  %t570 = insertvalue { i64, ptr } undef, i64 %t566, 0
  %t571 = insertvalue { i64, ptr } %t570, ptr %t569, 1
  %t574 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t549, { i64, ptr } %t571)
  store { i64, ptr } %t574, ptr %l141
  br label %bb39
bb39:
  %t575 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d426, i32 0, i32 1) }, 1
  %t576 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d426, i32 0, i32 1) }, 0
  %t577 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t578 = extractvalue { i64, ptr } %t577, 1
  %t579 = extractvalue { i64, ptr } %t577, 0
  %t580 = add i64 %t576, %t579
  %t581 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d427, i32 0, i32 1) }, 1
  %t582 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d427, i32 0, i32 1) }, 0
  %t583 = add i64 %t580, %t582
  %t584 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t585 = extractvalue { i64, ptr } %t584, 1
  %t586 = extractvalue { i64, ptr } %t584, 0
  %t587 = add i64 %t583, %t586
  %t588 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t587)
  call void @olang_textcopy(ptr %t588, ptr %t575, i64 %t576)
  %t589 = getelementptr i8, ptr %t588, i64 %t576
  call void @olang_textcopy(ptr %t589, ptr %t578, i64 %t579)
  %t590 = getelementptr i8, ptr %t589, i64 %t579
  call void @olang_textcopy(ptr %t590, ptr %t581, i64 %t582)
  %t591 = getelementptr i8, ptr %t590, i64 %t582
  call void @olang_textcopy(ptr %t591, ptr %t585, i64 %t586)
  %t592 = insertvalue { i64, ptr } undef, i64 %t587, 0
  %t593 = insertvalue { i64, ptr } %t592, ptr %t588, 1
  %t595 = extractvalue { i64, ptr } %t593, 0
  %t596 = extractvalue { i64, ptr } %t593, 1
  %t597 = mul i64 %t595, 1
  %t598 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t597)
  call void @llvm.memcpy.p0.p0.i64(ptr %t598, ptr %t596, i64 %t597, i1 false)
  %t599 = insertvalue { i64, ptr } undef, i64 %t595, 0
  %t600 = insertvalue { i64, ptr } %t599, ptr %t598, 1
  %t601 = load ptr, ptr %l126, !tbaa !29
  %t603 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t601, { i64, ptr } %t600)
  store { i64, ptr } %t603, ptr %l144
  br label %bb40
bb40:
  %t604 = load { i64, ptr }, ptr %l144, !tbaa !27
  store { i64, ptr } %t604, ptr %l16, !tbaa !27
  %t605 = load ptr, ptr %l0, !tbaa !29
  %t607 = getelementptr %"compiler/emit:fnEm", ptr %t605, i32 0, i32 0
  %t608 = load ptr, ptr %t607, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s0, ptr %t608, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d428, i32 0, i32 1) })
  br label %bb41
bb41:
  %t610 = load ptr, ptr %l0, !tbaa !29
  %t611 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t612 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t613 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d429, i32 0, i32 1) }, 1
  %t614 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d429, i32 0, i32 1) }, 0
  %t616 = extractvalue { i64, ptr } %t611, 1
  %t617 = extractvalue { i64, ptr } %t611, 0
  %t618 = add i64 %t614, %t617
  %t619 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d430, i32 0, i32 1) }, 1
  %t620 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d430, i32 0, i32 1) }, 0
  %t621 = add i64 %t618, %t620
  %t623 = extractvalue { i64, ptr } %t612, 1
  %t624 = extractvalue { i64, ptr } %t612, 0
  %t625 = add i64 %t621, %t624
  %t626 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d431, i32 0, i32 1) }, 1
  %t627 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d431, i32 0, i32 1) }, 0
  %t628 = add i64 %t625, %t627
  %t629 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t628)
  call void @olang_textcopy(ptr %t629, ptr %t613, i64 %t614)
  %t630 = getelementptr i8, ptr %t629, i64 %t614
  call void @olang_textcopy(ptr %t630, ptr %t616, i64 %t617)
  %t631 = getelementptr i8, ptr %t630, i64 %t617
  call void @olang_textcopy(ptr %t631, ptr %t619, i64 %t620)
  %t632 = getelementptr i8, ptr %t631, i64 %t620
  call void @olang_textcopy(ptr %t632, ptr %t623, i64 %t624)
  %t633 = getelementptr i8, ptr %t632, i64 %t624
  call void @olang_textcopy(ptr %t633, ptr %t626, i64 %t627)
  %t634 = insertvalue { i64, ptr } undef, i64 %t628, 0
  %t635 = insertvalue { i64, ptr } %t634, ptr %t629, 1
  %t637 = extractvalue { i64, ptr } %t635, 0
  %t638 = extractvalue { i64, ptr } %t635, 1
  %t639 = mul i64 %t637, 1
  %t640 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t639)
  call void @llvm.memcpy.p0.p0.i64(ptr %t640, ptr %t638, i64 %t639, i1 false)
  %t641 = insertvalue { i64, ptr } undef, i64 %t637, 0
  %t642 = insertvalue { i64, ptr } %t641, ptr %t640, 1
  %t645 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t610, { i64, ptr } %t642)
  store { i64, ptr } %t645, ptr %l152
  br label %bb42
bb42:
  %t646 = load { i64, ptr }, ptr %l152, !tbaa !27
  store { i64, ptr } %t646, ptr %l17, !tbaa !27
  %t647 = load ptr, ptr %l0, !tbaa !29
  store ptr %t647, ptr %l153, !tbaa !29
  %t648 = load ptr, ptr %l0, !tbaa !29
  store ptr %t648, ptr %l154, !tbaa !29
  %t649 = load ptr, ptr %l0, !tbaa !29
  %t650 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t651 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d432, i32 0, i32 1) }, 1
  %t652 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d432, i32 0, i32 1) }, 0
  %t654 = extractvalue { i64, ptr } %t650, 1
  %t655 = extractvalue { i64, ptr } %t650, 0
  %t656 = add i64 %t652, %t655
  %t657 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d433, i32 0, i32 1) }, 1
  %t658 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d433, i32 0, i32 1) }, 0
  %t659 = add i64 %t656, %t658
  %t660 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t659)
  call void @olang_textcopy(ptr %t660, ptr %t651, i64 %t652)
  %t661 = getelementptr i8, ptr %t660, i64 %t652
  call void @olang_textcopy(ptr %t661, ptr %t654, i64 %t655)
  %t662 = getelementptr i8, ptr %t661, i64 %t655
  call void @olang_textcopy(ptr %t662, ptr %t657, i64 %t658)
  %t663 = insertvalue { i64, ptr } undef, i64 %t659, 0
  %t664 = insertvalue { i64, ptr } %t663, ptr %t660, 1
  %t666 = extractvalue { i64, ptr } %t664, 0
  %t667 = extractvalue { i64, ptr } %t664, 1
  %t668 = mul i64 %t666, 1
  %t669 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t668)
  call void @llvm.memcpy.p0.p0.i64(ptr %t669, ptr %t667, i64 %t668, i1 false)
  %t670 = insertvalue { i64, ptr } undef, i64 %t666, 0
  %t671 = insertvalue { i64, ptr } %t670, ptr %t669, 1
  %t674 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t649, { i64, ptr } %t671)
  store { i64, ptr } %t674, ptr %l159
  br label %bb43
bb43:
  %t675 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d434, i32 0, i32 1) }, 1
  %t676 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d434, i32 0, i32 1) }, 0
  %t677 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t678 = extractvalue { i64, ptr } %t677, 1
  %t679 = extractvalue { i64, ptr } %t677, 0
  %t680 = add i64 %t676, %t679
  %t681 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d435, i32 0, i32 1) }, 1
  %t682 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d435, i32 0, i32 1) }, 0
  %t683 = add i64 %t680, %t682
  %t684 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t683)
  call void @olang_textcopy(ptr %t684, ptr %t675, i64 %t676)
  %t685 = getelementptr i8, ptr %t684, i64 %t676
  call void @olang_textcopy(ptr %t685, ptr %t678, i64 %t679)
  %t686 = getelementptr i8, ptr %t685, i64 %t679
  call void @olang_textcopy(ptr %t686, ptr %t681, i64 %t682)
  %t687 = insertvalue { i64, ptr } undef, i64 %t683, 0
  %t688 = insertvalue { i64, ptr } %t687, ptr %t684, 1
  %t690 = extractvalue { i64, ptr } %t688, 0
  %t691 = extractvalue { i64, ptr } %t688, 1
  %t692 = mul i64 %t690, 1
  %t693 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t692)
  call void @llvm.memcpy.p0.p0.i64(ptr %t693, ptr %t691, i64 %t692, i1 false)
  %t694 = insertvalue { i64, ptr } undef, i64 %t690, 0
  %t695 = insertvalue { i64, ptr } %t694, ptr %t693, 1
  %t696 = load ptr, ptr %l154, !tbaa !29
  %t698 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t696, { i64, ptr } %t695)
  store { i64, ptr } %t698, ptr %l162
  br label %bb44
bb44:
  %t699 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d436, i32 0, i32 1) }, 1
  %t700 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d436, i32 0, i32 1) }, 0
  %t701 = load { i64, ptr }, ptr %l162, !tbaa !27
  %t702 = extractvalue { i64, ptr } %t701, 1
  %t703 = extractvalue { i64, ptr } %t701, 0
  %t704 = add i64 %t700, %t703
  %t705 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d437, i32 0, i32 1) }, 1
  %t706 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d437, i32 0, i32 1) }, 0
  %t707 = add i64 %t704, %t706
  %t708 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t707)
  call void @olang_textcopy(ptr %t708, ptr %t699, i64 %t700)
  %t709 = getelementptr i8, ptr %t708, i64 %t700
  call void @olang_textcopy(ptr %t709, ptr %t702, i64 %t703)
  %t710 = getelementptr i8, ptr %t709, i64 %t703
  call void @olang_textcopy(ptr %t710, ptr %t705, i64 %t706)
  %t711 = insertvalue { i64, ptr } undef, i64 %t707, 0
  %t712 = insertvalue { i64, ptr } %t711, ptr %t708, 1
  %t714 = extractvalue { i64, ptr } %t712, 0
  %t715 = extractvalue { i64, ptr } %t712, 1
  %t716 = mul i64 %t714, 1
  %t717 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t716)
  call void @llvm.memcpy.p0.p0.i64(ptr %t717, ptr %t715, i64 %t716, i1 false)
  %t718 = insertvalue { i64, ptr } undef, i64 %t714, 0
  %t719 = insertvalue { i64, ptr } %t718, ptr %t717, 1
  %t720 = load ptr, ptr %l153, !tbaa !29
  %t722 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t720, { i64, ptr } %t719)
  store { i64, ptr } %t722, ptr %l165
  br label %bb45
bb45:
  %t723 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t724 = load ptr, ptr %l0, !tbaa !29
  %t726 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d438, i32 0, i32 1) }, 1
  %t727 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d438, i32 0, i32 1) }, 0
  %t729 = extractvalue { i64, ptr } %t723, 1
  %t730 = extractvalue { i64, ptr } %t723, 0
  %t731 = add i64 %t727, %t730
  %t732 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d439, i32 0, i32 1) }, 1
  %t733 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d439, i32 0, i32 1) }, 0
  %t734 = add i64 %t731, %t733
  %t735 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t734)
  call void @olang_textcopy(ptr %t735, ptr %t726, i64 %t727)
  %t736 = getelementptr i8, ptr %t735, i64 %t727
  call void @olang_textcopy(ptr %t736, ptr %t729, i64 %t730)
  %t737 = getelementptr i8, ptr %t736, i64 %t730
  call void @olang_textcopy(ptr %t737, ptr %t732, i64 %t733)
  %t738 = insertvalue { i64, ptr } undef, i64 %t734, 0
  %t739 = insertvalue { i64, ptr } %t738, ptr %t735, 1
  %t741 = extractvalue { i64, ptr } %t739, 0
  %t742 = extractvalue { i64, ptr } %t739, 1
  %t743 = mul i64 %t741, 1
  %t744 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t743)
  call void @llvm.memcpy.p0.p0.i64(ptr %t744, ptr %t742, i64 %t743, i1 false)
  %t745 = insertvalue { i64, ptr } undef, i64 %t741, 0
  %t746 = insertvalue { i64, ptr } %t745, ptr %t744, 1
  %t749 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t724, { i64, ptr } %t746)
  store { i64, ptr } %t749, ptr %l170
  br label %bb46
bb46:
  %t750 = load { i64, ptr }, ptr %l170, !tbaa !27
  store { i64, ptr } %t750, ptr %l19, !tbaa !27
  %t751 = load ptr, ptr %l0, !tbaa !29
  store ptr %t751, ptr %l171, !tbaa !29
  %t752 = load ptr, ptr %l0, !tbaa !29
  store ptr %t752, ptr %l172, !tbaa !29
  %t753 = load ptr, ptr %l0, !tbaa !29
  %t754 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t757 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ewidenBF16(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t753, { i64, ptr } %t754, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d440, i32 0, i32 1) })
  store { i64, ptr } %t757, ptr %l175
  br label %bb47
bb47:
  %t758 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t759 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d441, i32 0, i32 1) }, 1
  %t760 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d441, i32 0, i32 1) }, 0
  %t761 = load { i64, ptr }, ptr %l175, !tbaa !27
  %t762 = extractvalue { i64, ptr } %t761, 1
  %t763 = extractvalue { i64, ptr } %t761, 0
  %t764 = add i64 %t760, %t763
  %t765 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d442, i32 0, i32 1) }, 1
  %t766 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d442, i32 0, i32 1) }, 0
  %t767 = add i64 %t764, %t766
  %t769 = extractvalue { i64, ptr } %t758, 1
  %t770 = extractvalue { i64, ptr } %t758, 0
  %t771 = add i64 %t767, %t770
  %t772 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t771)
  call void @olang_textcopy(ptr %t772, ptr %t759, i64 %t760)
  %t773 = getelementptr i8, ptr %t772, i64 %t760
  call void @olang_textcopy(ptr %t773, ptr %t762, i64 %t763)
  %t774 = getelementptr i8, ptr %t773, i64 %t763
  call void @olang_textcopy(ptr %t774, ptr %t765, i64 %t766)
  %t775 = getelementptr i8, ptr %t774, i64 %t766
  call void @olang_textcopy(ptr %t775, ptr %t769, i64 %t770)
  %t776 = insertvalue { i64, ptr } undef, i64 %t771, 0
  %t777 = insertvalue { i64, ptr } %t776, ptr %t772, 1
  %t779 = extractvalue { i64, ptr } %t777, 0
  %t780 = extractvalue { i64, ptr } %t777, 1
  %t781 = mul i64 %t779, 1
  %t782 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t781)
  call void @llvm.memcpy.p0.p0.i64(ptr %t782, ptr %t780, i64 %t781, i1 false)
  %t783 = insertvalue { i64, ptr } undef, i64 %t779, 0
  %t784 = insertvalue { i64, ptr } %t783, ptr %t782, 1
  %t785 = load ptr, ptr %l172, !tbaa !29
  %t787 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v2, ptr %v2, ptr %t785, { i64, ptr } %t784)
  store { i64, ptr } %t787, ptr %l179
  br label %bb48
bb48:
  %t788 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t789 = extractvalue { i64, ptr } %t788, 0
  %t790 = extractvalue { i64, ptr } %t788, 1
  %t791 = mul i64 %t789, 1
  %t792 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t791)
  call void @llvm.memcpy.p0.p0.i64(ptr %t792, ptr %t790, i64 %t791, i1 false)
  %t793 = insertvalue { i64, ptr } undef, i64 %t789, 0
  %t794 = insertvalue { i64, ptr } %t793, ptr %t792, 1
  %t795 = load ptr, ptr %l171, !tbaa !29
  %t797 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2enarrowBF16(ptr %v0, ptr %v2, ptr %v2, ptr %t795, { i64, ptr } %t794)
  store { i64, ptr } %t797, ptr %l181
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s0)
  %t798 = load { i64, ptr }, ptr %l181, !tbaa !27
  store { i64, ptr } %t798, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2edbgTail(ptr %v0, i64 %a0) #0 {
entry:
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d443, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d443, i32 0, i32 1) }, 0
  %t5 = call i64 @__olang_fmt_i64(ptr null, i64 %a0)
  %t6 = add i64 %t3, %t5
  %t7 = extractvalue { i64, ptr } { i64 72, ptr getelementptr inbounds (<{ i64, [72 x i8] }>, ptr @.d444, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 72, ptr getelementptr inbounds (<{ i64, [72 x i8] }>, ptr @.d444, i32 0, i32 1) }, 0
  %t9 = add i64 %t6, %t8
  %t10 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d445, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d445, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t2, i64 %t3)
  %t14 = getelementptr i8, ptr %t13, i64 %t3
  %t15 = call i64 @__olang_fmt_i64(ptr %t14, i64 %a0)
  %t16 = getelementptr i8, ptr %t14, i64 %t5
  call void @olang_textcopy(ptr %t16, ptr %t7, i64 %t8)
  %t17 = getelementptr i8, ptr %t16, i64 %t8
  call void @olang_textcopy(ptr %t17, ptr %t10, i64 %t11)
  %t18 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t13, 1
  store { i64, ptr } %t19, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal i1 @olang_lambda_0(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i1
  %rv = alloca i1
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  store ptr %cv0, ptr %l2
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t5 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %vc0, ptr %vc0, ptr %t1, i64 %a0)
  store { i64, ptr } %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %vc0, ptr %vc0, ptr %t6, i64 %a1)
  store { i64, ptr } %t10, ptr %l8
  br label %bb2
bb2:
  %t11 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %vc0, ptr %vc0, { i64, ptr } %t11, { i64, ptr } %t12)
  store i1 %t13, ptr %l9
  br label %bb3
bb3:
  %t14 = load i1, ptr %l9, !tbaa !21
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/text:StringBuilder" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/text:StringBuilder"
  %rv = alloca %"std/prelude/text:StringBuilder"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l0
  store %"std/prelude/text:StringBuilder" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/text:StringBuilder", ptr %rv
  ret %"std/prelude/text:StringBuilder" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2e1 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr) cold noreturn
declare i64 @__olang_fmt_i64(ptr, i64)
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d2 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"void ()" }>, align 8
@.d3 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d4 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" = dso_local alias " }>, align 8
@.d5 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c", ptr @" }>, align 8
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d7 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"!" }>, align 8
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d9 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"bool" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d10 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"int" }>, align 8
@.d11 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"uint" }>, align 8
@.d12 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"__int128" }>, align 8
@.d13 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"unsigned __int128" }>, align 8
@.d14 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"_t" }>, align 8
@.d15 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d16 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d17 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d18 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d19 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d20 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"_clone" }>, align 8
@.d21 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2e0 = weak hidden constant i1 false
@.d22 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".dtor" }>, align 8
@.d23 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"lambda" }>, align 8
@.d24 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"test" }>, align 8
@.d25 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".init" }>, align 8
@.d26 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d27 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Array<" }>, align 8
@.d28 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d29 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d30 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"olang.gendrop." }>, align 8
@.d31 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"%x" }>, align 8
@.d32 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-1" }>, align 8
@.d33 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"__olang_gen_leaf" }>, align 8
@.d34 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"%x" }>, align 8
@.d35 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"getelementptr { i64, ptr }, ptr " }>, align 8
@.d36 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", i32 0, i32 1" }>, align 8
@.d37 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d38 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d39 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"%x" }>, align 8
@.d40 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d41 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"call void @__olang_gen_leaf(ptr " }>, align 8
@.d42 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d43 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d44 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"ret i64 " }>, align 8
@.d45 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"define linkonce_odr hidden i64 @" }>, align 8
@.d46 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"(ptr %x, ptr %keep, i64 %n) #0 {\0Aentry:\0A" }>, align 8
@.d47 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"}\0A\0A" }>, align 8
@.d48 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d49 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c" = weak hidden constant i1 false\0A" }>, align 8
@.d50 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"__olang_argc" }>, align 8
@.d51 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"@__olang_argc = external global i32" }>, align 8
@.d52 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"__olang_argv" }>, align 8
@.d53 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"@__olang_argv = external global ptr" }>, align 8
@.d54 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"__olang_jmp_target" }>, align 8
@.d55 = private constant <{ i64, [67 x i8] }> <{ i64 0, [67 x i8] c"@__olang_jmp_target = external thread_local(initialexec) global ptr" }>, align 8
@.d56 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"__olang_unwind_top" }>, align 8
@.d57 = private constant <{ i64, [67 x i8] }> <{ i64 0, [67 x i8] c"@__olang_unwind_top = external thread_local(initialexec) global ptr" }>, align 8
@.d58 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_unwind_mark" }>, align 8
@.d59 = private constant <{ i64, [68 x i8] }> <{ i64 0, [68 x i8] c"@__olang_unwind_mark = external thread_local(initialexec) global ptr" }>, align 8
@.d60 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"setjmp" }>, align 8
@.d61 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"i32 @setjmp(ptr) returns_twice" }>, align 8
@.d62 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"printf" }>, align 8
@.d63 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"i32 @printf(ptr, ...)" }>, align 8
@.d64 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"fflush" }>, align 8
@.d65 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"i32 @fflush(ptr)" }>, align 8
@.d66 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_thread_init" }>, align 8
@.d67 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_test_failed" }>, align 8
@.d68 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"ptr @" }>, align 8
@.d69 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d70 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"ptr @" }>, align 8
@.d71 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"{ ptr, ptr, ptr, ptr } { " }>, align 8
@.d72 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d73 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" }" }>, align 8
@.d74 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d75 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"@olang.harness.inits = private constant [" }>, align 8
@.d76 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" x ptr] [" }>, align 8
@.d77 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"]\0A" }>, align 8
@.d78 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d79 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"@olang.harness.tests = private constant [" }>, align 8
@.d80 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c" x { ptr, ptr, ptr, ptr }] [" }>, align 8
@.d81 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"]\0A" }>, align 8
@.d82 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"strcmp" }>, align 8
@.d83 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"i32 @strcmp(ptr, ptr)" }>, align 8
@.d84 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"strncmp" }>, align 8
@.d85 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"i32 @strncmp(ptr, ptr, i64)" }>, align 8
@.d86 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"strlen" }>, align 8
@.d87 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"i64 @strlen(ptr)" }>, align 8
@.d88 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"strstr" }>, align 8
@.d89 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"ptr @strstr(ptr, ptr)" }>, align 8
@.d90 = private constant <{ i64, [92 x i8] }> <{ i64 0, [92 x i8] c"\0Adefine private i1 @olang.harness.selected(ptr %tg, ptr %td, i32 %argc, ptr %argv) {\0Aentry:\0A" }>, align 8
@.d91 = private constant <{ i64, [75 x i8] }> <{ i64 0, [75 x i8] c"  %few = icmp sle i32 %argc, 1\0A  br i1 %few, label %yes, label %loop\0Aloop:\0A" }>, align 8
@.d92 = private constant <{ i64, [73 x i8] }> <{ i64 0, [73 x i8] c"  %i = phi i32 [ 1, %entry ], [ %i2, %next ]\0A  %i64 = sext i32 %i to i64\0A" }>, align 8
@.d93 = private constant <{ i64, [72 x i8] }> <{ i64 0, [72 x i8] c"  %ip = getelementptr ptr, ptr %argv, i64 %i64\0A  %f = load ptr, ptr %ip\0A" }>, align 8
@.d94 = private constant <{ i64, [108 x i8] }> <{ i64 0, [108 x i8] c"  %c1 = call i32 @strcmp(ptr %tg, ptr %f)\0A  %e1 = icmp eq i32 %c1, 0\0A  br i1 %e1, label %yes, label %t2\0At2:\0A" }>, align 8
@.d95 = private constant <{ i64, [85 x i8] }> <{ i64 0, [85 x i8] c"  %fl = call i64 @strlen(ptr %f)\0A  %c2 = call i32 @strncmp(ptr %tg, ptr %f, i64 %fl)\0A" }>, align 8
@.d96 = private constant <{ i64, [67 x i8] }> <{ i64 0, [67 x i8] c"  %e2 = icmp eq i32 %c2, 0\0A  br i1 %e2, label %t2b, label %t3\0At2b:\0A" }>, align 8
@.d97 = private constant <{ i64, [96 x i8] }> <{ i64 0, [96 x i8] c"  %dp = getelementptr i8, ptr %tg, i64 %fl\0A  %dc = load i8, ptr %dp\0A  %dot = icmp eq i8 %dc, 46\0A" }>, align 8
@.d98 = private constant <{ i64, [82 x i8] }> <{ i64 0, [82 x i8] c"  br i1 %dot, label %yes, label %t3\0At3:\0A  %ss = call ptr @strstr(ptr %td, ptr %f)\0A" }>, align 8
@.d99 = private constant <{ i64, [95 x i8] }> <{ i64 0, [95 x i8] c"  %e3 = icmp ne ptr %ss, null\0A  br i1 %e3, label %yes, label %next\0Anext:\0A  %i2 = add i32 %i, 1\0A" }>, align 8
@.d100 = private constant <{ i64, [105 x i8] }> <{ i64 0, [105 x i8] c"  %more = icmp slt i32 %i2, %argc\0A  br i1 %more, label %loop, label %no\0Ayes:\0A  ret i1 1\0Ano:\0A  ret i1 0\0A}\0A" }>, align 8
@.d101 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d102 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c"\0Adefine i32 @main(i32 %argc, ptr %argv) #0 {\0Aentry:\0A" }>, align 8
@.d103 = private constant <{ i64, [96 x i8] }> <{ i64 0, [96 x i8] c"  %pass = alloca i32\0A  %fail = alloca i32\0A  %k = alloca i64\0A  %jb = alloca [200 x i8], align 16\0A" }>, align 8
@.d104 = private constant <{ i64, [53 x i8] }> <{ i64 0, [53 x i8] c"  %sel = alloca i32\0A  store volatile i32 0, ptr %sel\0A" }>, align 8
@.d105 = private constant <{ i64, [68 x i8] }> <{ i64 0, [68 x i8] c"  store volatile i32 0, ptr %pass\0A  store volatile i32 0, ptr %fail\0A" }>, align 8
@.d106 = private constant <{ i64, [74 x i8] }> <{ i64 0, [74 x i8] c"  store i32 %argc, ptr @__olang_argc\0A  store ptr %argv, ptr @__olang_argv\0A" }>, align 8
@.d107 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"  store ptr " }>, align 8
@.d108 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c", ptr @__olang_test_file\0A" }>, align 8
@.d109 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"  call void @__olang_thread_init()\0A" }>, align 8
@.d110 = private constant <{ i64, [90 x i8] }> <{ i64 0, [90 x i8] c"  store volatile i64 0, ptr %k\0A  br label %gloop\0Agloop:\0A  %gk = load volatile i64, ptr %k\0A" }>, align 8
@.d111 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"  %gm = icmp slt i64 %gk, " }>, align 8
@.d112 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c"\0A  br i1 %gm, label %gbody, label %gdone\0Agbody:\0A" }>, align 8
@.d113 = private constant <{ i64, [75 x i8] }> <{ i64 0, [75 x i8] c"  store ptr %jb, ptr @__olang_jmp_target\0A  %gj = call i32 @setjmp(ptr %jb)\0A" }>, align 8
@.d114 = private constant <{ i64, [107 x i8] }> <{ i64 0, [107 x i8] c"  %gz = icmp eq i32 %gj, 0\0A  br i1 %gz, label %grun, label %gnext\0Agrun:\0A  %gk2 = load volatile i64, ptr %k\0A" }>, align 8
@.d115 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"  %gp = getelementptr [" }>, align 8
@.d116 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c" x ptr], ptr @olang.harness.inits, i64 0, i64 %gk2\0A" }>, align 8
@.d117 = private constant <{ i64, [69 x i8] }> <{ i64 0, [69 x i8] c"  %gf = load ptr, ptr %gp\0A  call void %gf()\0A  br label %gnext\0Agnext:\0A" }>, align 8
@.d118 = private constant <{ i64, [94 x i8] }> <{ i64 0, [94 x i8] c"  %gk3 = load volatile i64, ptr %k\0A  %gk4 = add i64 %gk3, 1\0A  store volatile i64 %gk4, ptr %k\0A" }>, align 8
@.d119 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"  br label %gloop\0Agdone:\0A" }>, align 8
@.d120 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d121 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c" x { ptr, ptr, ptr, ptr }]" }>, align 8
@.d122 = private constant <{ i64, [90 x i8] }> <{ i64 0, [90 x i8] c"  store volatile i64 0, ptr %k\0A  br label %tloop\0Atloop:\0A  %tk = load volatile i64, ptr %k\0A" }>, align 8
@.d123 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"  %tm = icmp slt i64 %tk, " }>, align 8
@.d124 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c"\0A  br i1 %tm, label %tpick, label %tdone\0Atpick:\0A" }>, align 8
@.d125 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"  %tgp = getelementptr " }>, align 8
@.d126 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c", ptr @olang.harness.tests, i64 0, i64 %tk, i32 2\0A" }>, align 8
@.d127 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"  %tdp = getelementptr " }>, align 8
@.d128 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c", ptr @olang.harness.tests, i64 0, i64 %tk, i32 3\0A" }>, align 8
@.d129 = private constant <{ i64, [54 x i8] }> <{ i64 0, [54 x i8] c"  %tg = load ptr, ptr %tgp\0A  %td = load ptr, ptr %tdp\0A" }>, align 8
@.d130 = private constant <{ i64, [82 x i8] }> <{ i64 0, [82 x i8] c"  %tsel = call i1 @olang.harness.selected(ptr %tg, ptr %td, i32 %argc, ptr %argv)\0A" }>, align 8
@.d131 = private constant <{ i64, [49 x i8] }> <{ i64 0, [49 x i8] c"  br i1 %tsel, label %tbody, label %tnext\0Atbody:\0A" }>, align 8
@.d132 = private constant <{ i64, [96 x i8] }> <{ i64 0, [96 x i8] c"  %sl = load volatile i32, ptr %sel\0A  %sl2 = add i32 %sl, 1\0A  store volatile i32 %sl2, ptr %sel\0A" }>, align 8
@.d133 = private constant <{ i64, [86 x i8] }> <{ i64 0, [86 x i8] c"  %top = load ptr, ptr @__olang_unwind_top\0A  store ptr %top, ptr @__olang_unwind_mark\0A" }>, align 8
@.d134 = private constant <{ i64, [75 x i8] }> <{ i64 0, [75 x i8] c"  store ptr %jb, ptr @__olang_jmp_target\0A  %tj = call i32 @setjmp(ptr %jb)\0A" }>, align 8
@.d135 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"  %tk2 = load volatile i64, ptr %k\0A" }>, align 8
@.d136 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"  %tfp = getelementptr " }>, align 8
@.d137 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c", ptr @olang.harness.tests, i64 0, i64 %tk2, i32 0\0A" }>, align 8
@.d138 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"  %tnp = getelementptr " }>, align 8
@.d139 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c", ptr @olang.harness.tests, i64 0, i64 %tk2, i32 1\0A" }>, align 8
@.d140 = private constant <{ i64, [54 x i8] }> <{ i64 0, [54 x i8] c"  %tf = load ptr, ptr %tfp\0A  %tn = load ptr, ptr %tnp\0A" }>, align 8
@.d141 = private constant <{ i64, [71 x i8] }> <{ i64 0, [71 x i8] c"  %tz = icmp eq i32 %tj, 0\0A  br i1 %tz, label %trun, label %tbad\0Atrun:\0A" }>, align 8
@.d142 = private constant <{ i64, [58 x i8] }> <{ i64 0, [58 x i8] c"  store ptr %tn, ptr @__olang_test_name\0A  call void %tf()\0A" }>, align 8
@.d143 = private constant <{ i64, [94 x i8] }> <{ i64 0, [94 x i8] c"  %p = load volatile i32, ptr %pass\0A  %pp = add i32 %p, 1\0A  store volatile i32 %pp, ptr %pass\0A" }>, align 8
@.d144 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"ok - %s\0A" }>, align 8
@.d145 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"  call i32 (ptr, ...) @printf(ptr " }>, align 8
@.d146 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c", ptr %tn)\0A  call i32 @fflush(ptr null)\0A" }>, align 8
@.d147 = private constant <{ i64, [82 x i8] }> <{ i64 0, [82 x i8] c"  br label %tnext\0Atbad:\0A  %f = load volatile i32, ptr %fail\0A  %ff = add i32 %f, 1\0A" }>, align 8
@.d148 = private constant <{ i64, [107 x i8] }> <{ i64 0, [107 x i8] c"  store volatile i32 %ff, ptr %fail\0A  call void @__olang_test_failed(ptr %tn)\0A  call i32 @fflush(ptr null)\0A" }>, align 8
@.d149 = private constant <{ i64, [85 x i8] }> <{ i64 0, [85 x i8] c"  br label %tnext\0Atnext:\0A  %tk3 = load volatile i64, ptr %k\0A  %tk4 = add i64 %tk3, 1\0A" }>, align 8
@.d150 = private constant <{ i64, [59 x i8] }> <{ i64 0, [59 x i8] c"  store volatile i64 %tk4, ptr %k\0A  br label %tloop\0Atdone:\0A" }>, align 8
@.d151 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"  store ptr null, ptr @__olang_jmp_target\0A" }>, align 8
@.d152 = private constant <{ i64, [98 x i8] }> <{ i64 0, [98 x i8] c"  %ns = load volatile i32, ptr %sel\0A  %none = icmp eq i32 %ns, 0\0A  %words = icmp sgt i32 %argc, 1\0A" }>, align 8
@.d153 = private constant <{ i64, [95 x i8] }> <{ i64 0, [95 x i8] c"  %unmatched = and i1 %none, %words\0A  br i1 %unmatched, label %nomatch, label %counts\0Anomatch:\0A" }>, align 8
@.d154 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"  ret i32 3\0Acounts:\0A" }>, align 8
@.d155 = private constant <{ i64, [74 x i8] }> <{ i64 0, [74 x i8] c"  %np = load volatile i32, ptr %pass\0A  %nf = load volatile i32, ptr %fail\0A" }>, align 8
@.d156 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"%d passed, %d failed\0A" }>, align 8
@.d157 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"  call i32 (ptr, ...) @printf(ptr " }>, align 8
@.d158 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c", i32 %np, i32 %nf)\0A" }>, align 8
@.d159 = private constant <{ i64, [74 x i8] }> <{ i64 0, [74 x i8] c"  %any = icmp sgt i32 %nf, 0\0A  %st = zext i1 %any to i32\0A  ret i32 %st\0A}\0A\0A" }>, align 8
@.d160 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"main" }>, align 8
define internal i1 @olang_lambda_161(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i1
  %rv = alloca i1
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  store ptr %cv0, ptr %l2
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t5 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %vc0, ptr %vc0, ptr %t1, i64 %a0)
  store { i64, ptr } %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %vc0, ptr %vc0, ptr %t6, i64 %a1)
  store { i64, ptr } %t10, ptr %l8
  br label %bb2
bb2:
  %t11 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %vc0, ptr %vc0, { i64, ptr } %t11, { i64, ptr } %t12)
  store i1 %t13, ptr %l9
  br label %bb3
bb3:
  %t14 = load i1, ptr %l9, !tbaa !21
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d162 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"olang." }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fmir_3aHelperKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 8}
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 i64 7, label %bb9 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d446, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d446, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d447, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d447, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d448, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d448, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d449, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d449, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
bb6:
  %t13 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d450, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d450, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t13, i64 %t14)
  br label %bb1
bb7:
  %t15 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d451, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d451, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t15, i64 %t16)
  br label %bb1
bb8:
  %t17 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d452, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d452, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t17, i64 %t18)
  br label %bb1
bb9:
  %t19 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d453, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d453, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t19, i64 %t20)
  br label %bb1
ret:
  ret void
}

@.d163 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
declare void @__olang_sb_done(ptr)
@.d164 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"_adapter" }>, align 8
@.d165 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"_copied" }>, align 8
@.d166 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"_twin" }>, align 8
@.d167 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"olang.init." }>, align 8
@.d168 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".top" }>, align 8
@.d169 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d170 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"olang.anyrender" }>, align 8
@.d171 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
declare ptr @__olang_scope_of(ptr, ptr) noinline
@.d172 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".walk" }>, align 8
@.d173 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d174 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"  %big = alloca %olang.scope\0A" }>, align 8
@.d175 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c"  store %olang.scope zeroinitializer, ptr %big\0A" }>, align 8
@.d176 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"__olang_scope_alloc_a" }>, align 8
@.d177 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_scope_close" }>, align 8
@.d178 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"a constant element of a " }>, align 8
@.d179 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"zeroinitializer" }>, align 8
@.d180 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d181 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"{ i64 " }>, align 8
@.d182 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d183 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" }" }>, align 8
@.d184 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"extractvalue { i64, ptr } " }>, align 8
@.d185 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d186 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"extractvalue { i64, ptr } " }>, align 8
@.d187 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d188 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"mul i64 " }>, align 8
@.d189 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d190 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"llvm.memcpy.p0.p0.i64" }>, align 8
@.d191 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)" }>, align 8
@.d192 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"call void @llvm.memcpy.p0.p0.i64(ptr " }>, align 8
@.d193 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d194 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d195 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c", i1 false)" }>, align 8
@.d196 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d197 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d198 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d199 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"zext " }>, align 8
@.d200 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"sext " }>, align 8
@.d201 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d202 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" to " }>, align 8
@.d203 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"__olang_gen_alloc" }>, align 8
@.d204 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"call ptr @__olang_gen_alloc(ptr " }>, align 8
@.d205 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d206 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d207 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d208 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" x i8]" }>, align 8
@.d209 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"getelementptr i8, ptr " }>, align 8
@.d210 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d211 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"getelementptr i8, ptr " }>, align 8
@.d212 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", i64 -8" }>, align 8
@.d213 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"store i64 " }>, align 8
@.d214 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d215 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", align 8" }>, align 8
@.d216 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"load " }>, align 8
@.d217 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d218 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"llvm.memmove.p0.p0.i64" }>, align 8
@.d219 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c"void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)" }>, align 8
@.d220 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c"call void @llvm.memmove.p0.p0.i64(ptr " }>, align 8
@.d221 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d222 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d223 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c", i1 false)" }>, align 8
@.d224 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"call i16 asm \22\22, \22=r,0\22(i16 " }>, align 8
@.d225 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d226 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"getelementptr i8, ptr " }>, align 8
@.d227 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d228 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d229 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"i" }>, align 8
@.d230 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d231 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"undef" }>, align 8
@.d232 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"insertvalue " }>, align 8
@.d233 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d234 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d235 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"zeroinitializer" }>, align 8
@.d236 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d237 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" x i8]" }>, align 8
@.d238 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d239 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"undef" }>, align 8
@.d240 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"getelementptr i8, ptr " }>, align 8
@.d241 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d242 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"insertvalue " }>, align 8
@.d243 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d244 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d245 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d246 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d247 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%lp" }>, align 8
@.d248 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d249 = private constant <{ i64, [76 x i8] }> <{ i64 0, [76 x i8] c"store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s" }>, align 8
@.d250 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"store ptr %s" }>, align 8
@.d251 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"room, ptr %s" }>, align 8
@.d252 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"a region" }>, align 8
@.d253 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"store %olang.scope zeroinitializer, ptr %s" }>, align 8
@.d254 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"store ptr null, ptr %jh" }>, align 8
@.d255 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"__olang_sb_done" }>, align 8
@.d256 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"getelementptr %olang.builder, ptr %s" }>, align 8
@.d257 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", i32 0, i32 3" }>, align 8
@.d258 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d259 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"icmp ne ptr " }>, align 8
@.d260 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", null" }>, align 8
@.d261 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"sbgrew" }>, align 8
@.d262 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"sbdone" }>, align 8
@.d263 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"br i1 " }>, align 8
@.d264 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", label %" }>, align 8
@.d265 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"call void @__olang_sb_done(ptr %s" }>, align 8
@.d266 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d267 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"br label %" }>, align 8
@.d268 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_scope_close" }>, align 8
@.d269 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"call void @__olang_scope_close(ptr %s" }>, align 8
@.d270 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d271 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"__olang_errpay_set" }>, align 8
@.d272 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"call void @__olang_errpay_set(ptr " }>, align 8
@.d273 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d274 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"__olang_errpay_pop" }>, align 8
@.d275 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"call void @__olang_errpay_pop()" }>, align 8
@.d276 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"a cleanup (interpret's)" }>, align 8
@.d277 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"a destructor not found: " }>, align 8
@.d278 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"__olang_scope_register_dtor" }>, align 8
@.d279 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"call void @__olang_scope_register_dtor(ptr " }>, align 8
@.d280 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d281 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c", ptr @" }>, align 8
@.d282 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"_rt)" }>, align 8
@.d283 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_region_drop" }>, align 8
@.d284 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"call void @__olang_region_drop(ptr " }>, align 8
@.d285 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d286 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"zeroinitializer" }>, align 8
@.d287 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"__olang_region_release" }>, align 8
@.d288 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c"call void @__olang_region_release(ptr " }>, align 8
@.d289 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d290 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"__olang_slot_release" }>, align 8
@.d291 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"call void @__olang_slot_release(ptr " }>, align 8
@.d292 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d293 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i64" }>, align 8
@.d294 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"inttoptr i64 " }>, align 8
@.d295 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" to ptr" }>, align 8
@.d296 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"icmp eq ptr " }>, align 8
@.d297 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d298 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"__olang_region_settle" }>, align 8
@.d299 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"call void @__olang_region_settle(ptr " }>, align 8
@.d300 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c", i1 " }>, align 8
@.d301 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d302 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"mul i64 " }>, align 8
@.d303 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d304 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"llvm.memmove.p0.p0.i64" }>, align 8
@.d305 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c"void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)" }>, align 8
@.d306 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c"call void @llvm.memmove.p0.p0.i64(ptr " }>, align 8
@.d307 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d308 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d309 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c", i1 false)" }>, align 8
@.d310 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"llvm.memmove.p0.p0.i64" }>, align 8
@.d311 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c"void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)" }>, align 8
@.d312 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%tf" }>, align 8
@.d313 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d314 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"tf" }>, align 8
@.d315 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d316 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d317 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"d = load ptr, ptr %f" }>, align 8
@.d318 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"\0A  " }>, align 8
@.d319 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"v = load { i64, ptr }, ptr " }>, align 8
@.d320 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"d\0A" }>, align 8
@.d321 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d322 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"n = extractvalue { i64, ptr } " }>, align 8
@.d323 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"v, 0\0A  " }>, align 8
@.d324 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"p = extractvalue { i64, ptr } " }>, align 8
@.d325 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"v, 1\0A" }>, align 8
@.d326 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d327 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"on = extractvalue { i64, ptr } %old" }>, align 8
@.d328 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", 0\0A  " }>, align 8
@.d329 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"op = extractvalue { i64, ptr } %old" }>, align 8
@.d330 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c", 1\0A" }>, align 8
@.d331 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d332 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"b = mul i64 " }>, align 8
@.d333 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"n, " }>, align 8
@.d334 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"\0A  " }>, align 8
@.d335 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"s = icmp eq i64 " }>, align 8
@.d336 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"on\0A" }>, align 8
@.d337 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"  br i1 " }>, align 8
@.d338 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"s, label %" }>, align 8
@.d339 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"i, label %" }>, align 8
@.d340 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"f\0A" }>, align 8
@.d341 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i:\0A" }>, align 8
@.d342 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"  call void @llvm.memmove.p0.p0.i64(ptr " }>, align 8
@.d343 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"op, ptr " }>, align 8
@.d344 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"p, i64 " }>, align 8
@.d345 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"b, i1 false)\0A" }>, align 8
@.d346 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"  store { i64, ptr } %old" }>, align 8
@.d347 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d348 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"d\0A  br label %" }>, align 8
@.d349 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"e\0A" }>, align 8
@.d350 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"f:\0A" }>, align 8
@.d351 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"__olang_scope_alloc_min" }>, align 8
@.d352 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_scope_alloc" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d353 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"__olang_prog_scope" }>, align 8
@.d354 = private constant <{ i64, [67 x i8] }> <{ i64 0, [67 x i8] c"@__olang_prog_scope = external thread_local(initialexec) global ptr" }>, align 8
@.d355 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d356 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"c = load ptr, ptr %f" }>, align 8
@.d357 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"\0A  " }>, align 8
@.d358 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"z = icmp eq ptr " }>, align 8
@.d359 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"c, null\0A" }>, align 8
@.d360 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d361 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"g = load ptr, ptr @__olang_prog_scope\0A  " }>, align 8
@.d362 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"w = select i1 " }>, align 8
@.d363 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"z, ptr " }>, align 8
@.d364 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"g, ptr " }>, align 8
@.d365 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"c\0A" }>, align 8
@.d366 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d367 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d368 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d369 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"q = call ptr @" }>, align 8
@.d370 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(ptr " }>, align 8
@.d371 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"w, i64 " }>, align 8
@.d372 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"b" }>, align 8
@.d373 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")\0A" }>, align 8
@.d374 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"  call void @llvm.memmove.p0.p0.i64(ptr " }>, align 8
@.d375 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"q, ptr " }>, align 8
@.d376 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"p, i64 " }>, align 8
@.d377 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"b, i1 false)\0A" }>, align 8
@.d378 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d379 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"x = insertvalue { i64, ptr } undef, i64 " }>, align 8
@.d380 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"n, 0\0A" }>, align 8
@.d381 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d382 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"y = insertvalue { i64, ptr } " }>, align 8
@.d383 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"x, ptr " }>, align 8
@.d384 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"q, 1\0A  store { i64, ptr } " }>, align 8
@.d385 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"y, ptr " }>, align 8
@.d386 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"d\0A" }>, align 8
@.d387 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"  br label %" }>, align 8
@.d388 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"e\0A" }>, align 8
@.d389 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"e:\0A" }>, align 8
@.d390 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"i128" }>, align 8
@.d391 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"zext " }>, align 8
@.d392 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"sext " }>, align 8
@.d393 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d394 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" to i128" }>, align 8
@.d395 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"false" }>, align 8
@.d396 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"icmp slt i128 " }>, align 8
@.d397 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d398 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"sub i128 0, " }>, align 8
@.d399 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"select i1 " }>, align 8
@.d400 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c", i128 " }>, align 8
@.d401 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"llvm.ctlz.i128" }>, align 8
@.d402 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"i128 @llvm.ctlz.i128(i128, i1)" }>, align 8
@.d403 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"or i128 " }>, align 8
@.d404 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d405 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"call i128 @llvm.ctlz.i128(i128 " }>, align 8
@.d406 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c", i1 true)" }>, align 8
@.d407 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"sub i128 65, " }>, align 8
@.d408 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"icmp sgt i128 " }>, align 8
@.d409 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d410 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"select i1 " }>, align 8
@.d411 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c", i128 " }>, align 8
@.d412 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", i128 0" }>, align 8
@.d413 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"shl i128 1, " }>, align 8
@.d414 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"sub i128 " }>, align 8
@.d415 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d416 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"and i128 " }>, align 8
@.d417 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d418 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"icmp ne i128 " }>, align 8
@.d419 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d420 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"lshr i128 " }>, align 8
@.d421 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d422 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"trunc i128 " }>, align 8
@.d423 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" to i64" }>, align 8
@.d424 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"zext i1 " }>, align 8
@.d425 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" to i64" }>, align 8
@.d426 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"or i64 " }>, align 8
@.d427 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d428 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"__olang_int_bf16" }>, align 8
@.d429 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"call bfloat @__olang_int_bf16(i64 " }>, align 8
@.d430 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c", i1 " }>, align 8
@.d431 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d432 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"trunc i128 " }>, align 8
@.d433 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" to i32" }>, align 8
@.d434 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"add i32 " }>, align 8
@.d435 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c", 127" }>, align 8
@.d436 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"shl i32 " }>, align 8
@.d437 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c", 23" }>, align 8
@.d438 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"bitcast i32 " }>, align 8
@.d439 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" to float" }>, align 8
@.d440 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"float" }>, align 8
@.d441 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"fmul float " }>, align 8
@.d442 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d443 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"!llvm.dbg.cu = !{!" }>, align 8
@.d444 = private constant <{ i64, [72 x i8] }> <{ i64 0, [72 x i8] c"}\0A!llvm.module.flags = !{!1, !2}\0A!1 = !{i32 7, !\22Dwarf Version\22, i32 4}\0A" }>, align 8
@.d445 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c"!2 = !{i32 2, !\22Debug Info Version\22, i32 3}\0A" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@.d446 = private unnamed_addr constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"mir.HelperKind.Render" }>, align 8
@.d447 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"mir.HelperKind.Equal" }>, align 8
@.d448 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"mir.HelperKind.Hash" }>, align 8
@.d449 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"mir.HelperKind.Zero" }>, align 8
@.d450 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"mir.HelperKind.Copy" }>, align 8
@.d451 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"mir.HelperKind.Parts" }>, align 8
@.d452 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"mir.HelperKind.Drop" }>, align 8
@.d453 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"mir.HelperKind.Guard" }>, align 8
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2egroupOf(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2einstGroupOf(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2epartOf(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2farray_2eArray_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eLen_3cI64_2c_20I64_3e(ptr %v0, ptr %a0)
declare %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eIter_3cI64_2c_20I64_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.e476b05c61172463a7c240e364dbb6d0" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cI64_2c_20I64_3e_2eNext_3cI64_2c_20I64_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Hc3dff1927e5c626a9d95abfdf4e9a462(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ealiased(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewrapper(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2etypesNamedIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %a2, ptr %a3)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclTypes(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %a2, ptr %a3)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2erefs(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_ad9436b5748221a9_385739db7a2b20ed = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewantType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitemNamed(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2eprefixOf(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehead(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_H0211835ad1df5edc8086b9b7bc878d6e(ptr %v0, ptr %a0)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbg(ptr %v0, ptr %a0)
@olang_loc_4635f1a318b549bc_759936c3a7928310 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %a0, i64 %a1)
@olang_loc_2968b987139e6167_76a7d58ddfcdba8b = external constant [0 x i8]
declare i64 @compiler_2femit_2emetaNumber(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_493930ee087ace8a_eb37955c75d36e8e = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_H86f724e2dc8b3b4d675d56b45c81e2ce(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_82b9110c3ab34805_cdca7d87f9ba97f1 = external constant [0 x i8]
@olang_loc_20b52d6bf9b06c28_18043bf0e12df584 = external constant [0 x i8]
@olang_loc_9bd48c53dce2a143_9d318240a700faef = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eattributes(ptr %v0, ptr %v1, ptr %a0)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePackedBits(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2femit_2eIntBytes8(i64 %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/cabi:Way" @compiler_2fcabi_2eWay_2eResult(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcabi_2ePartsType(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_6aada305a3873fb6_c16c54d6f05c33ea = external constant [0 x i8]
declare %"compiler/lower:Clone" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2flower_3aClone_3e_2eAt_3ccompiler_2flower_3aClone_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecodeType(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2epassedOf(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2)
declare i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ethunkSym(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i1 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
@olang_loc_18f6acb4865fb5f2_de2c0e3f26126f06 = external constant [0 x i8]
@olang_loc_795f0ceaa031aa73_92815be2925279e7 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_aa85ef0c362238c9_b248055339837d6d = external constant [0 x i8]
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i64 %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2eLen_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0)
declare { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2eAt_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efunction(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare void @compiler_2fmir_3aFn_2ector(ptr %out, ptr %v0, { i64, [2 x i64] } %a0, i32 %a1, i64 %a2, %"compiler/source:Span" %a3)
declare void @compiler_2femit_3afnEm_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2eholdersAt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, ptr } %a3, i1 %a4)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2femit_2ecompiler_2femit_3afnEm_2egenLeaves(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eLen_3cArray_3cI64_3e_3e(ptr %v0, ptr %a0)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eAt_3cArray_3cI64_3e_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eleafAt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, ptr } %a3)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ealign(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2egenBytes(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2femit_2egenClass(i64 %a0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenOkName(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
@olang_loc_2aa1b6f8675f9eff_587e0f89839d7783 = external constant [0 x i8]
@olang_loc_d066018c79b1953a_bec35d4ece20e406 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2femit_2ecompiler_2femit_3aEmitter_2einitOrder(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_H901ad831a5883703dcf426ee01511832(ptr %v0, ptr %a0, i64 %a1)
declare { { i64, ptr }, { i64, ptr } } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etestParts(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etestName(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efuzzHarness(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2, ptr %a3)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2etestSource(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2esanInit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisLambda(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_22c0ecf0dfd2f0b7_2552f1950a299d53 = external constant [0 x i8]
declare %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eIter_3cI64_2c_20Bool_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.eb00e4a6e4307a4e46e40fbcd79d6b4f" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cI64_2c_20Bool_3e_2eNext_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePacked(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_Hb3133f486435530b533aaf49461c92b5(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H64d9be73b6c9bed004c541bdf7f0ca0a(ptr %v0, ptr %a0, i32 %a1, i1 %a2)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eEmbedded(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_ef8ce655497c6e66_70bdfc36b0b8c4fa = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ebodySym(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnnamed(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanonNamed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etableName(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_325a0aca37049b03_8faf0435ed6a0227 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisGenFn(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehomeOf(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare { i64, ptr } @compiler_2femit_2elinkFor(ptr %v0, i64 %a0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eheader(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, { i64, ptr } %a3, i64 %a4, i1 %a5, { i64, ptr } %a6, { i64, ptr } %a7)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2estub(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efnItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, { i64, ptr } %a3, i64 %a4, i1 %a5, { i64, ptr } %a6)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2eAt_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2econstText(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixed(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare { { i64, ptr }, { i64, ptr }, i64 } @compiler_2femit_2ecompiler_2femit_3afnEm_2econstInit(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare { { i64, ptr }, i64 } @compiler_2femit_2ecompiler_2femit_3afnEm_2econstGlobal(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3)
@olang_loc_3de177096d03f952_4b04555d717d3dfe = external constant [0 x i8]
declare i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayStorage(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i32 %a3, i1 %a4)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epair(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eisFrame(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1)
declare i64 @compiler_2femit_2egenClassSize(i64 %a0)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2eownWordsClear(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloc(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [1 x i64] } %a1, { i64, ptr } %a2, i64 %a3, { i64, ptr } %a4)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epackedMake(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"compiler/mir:Range" %a2)
declare { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1, i64 %a2)
@olang_loc_44ed23dda5502268_7ffab923032619a4 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epackedBits(ptr %v0, ptr %v1, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBitOffsets(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %v1, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2etoBits(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, i64 %a3)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eplaceBits(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i64 %a2, i64 %a3, i64 %a4, { i64, ptr } %a5)
@olang_loc_745b41379bd01239_c904106b8ad08895 = external constant [0 x i8]
declare { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Lvalue" %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare i64 @compiler_2fcabi_2eSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare %"compiler/source:Span" @compiler_2femit_2estmtSpan(ptr %v0, ptr %a0)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2elocate(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eplaceType(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efillInPlace(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %a1, i32 %a2, { i64, [15 x i64] } %a3)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eintoPlace(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %a1, i32 %a2, { i64, [15 x i64] } %a3)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ervalue(ptr %v0, ptr %v1, ptr %a0, { i64, [15 x i64] } %a1, i32 %a2)
declare %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalType(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aWriteKind_3e_2eClear_3ccompiler_2fmir_3aWriteKind_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eClear_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0)
declare %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2eunwindPush(ptr %v0, ptr %a0, i32 %a1, i1 %a2)
declare i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ewalkKey(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2ewalkEnd(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2eunwindPop(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2etrace(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
@G_2ecompiler_2fmir_2eI64T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\06\00\00\00" }>, align 8
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2eholders(ptr %v0, ptr %v1, ptr %a0, { i64, [4 x i64] } %a1, { i64, ptr } %a2)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2ereclaim(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/mir:Range" %a3)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %a0, i32 %a1)
declare { i32, { i64, [2 x i64] } } @compiler_2fmir_2eFnKey_2eDropFn(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewant(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_Hf0a5beca6f8aee4731a76bd327ae0a99(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_He6968003b8dd5762fa82ec44b4ee1fc9(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i1 %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eanchorRegion(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eobjectPtr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalAt(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2edirectRef(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aWriteKind_3e_2ePush_3ccompiler_2fmir_3aWriteKind_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2ePush_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2ewrite(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, [4 x i64] } %a3)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edataPtr(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Lvalue" %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eindex(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare %"compiler/mir:Task" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2espawn(ptr %v0, ptr %a0, i32 %a1, %"compiler/mir:Task" %a2)
@olang_loc_73cacc8093766858_2881ed4d4d5af0d4 = external constant [0 x i8]
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2evalueTarget(ptr %v0, ptr %a0, %"compiler/mir:Task" %a1, i64 %a2)
declare %"compiler/mir:Lvalue" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e_2eAt_3ccompiler_2fmir_3aLvalue_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %a0, i32 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eRef_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eLen(ptr %v0, ptr %a0)
declare { i64, [21 x i64] } @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eAt(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_93708b25bcca1908_59bc9d4dcf3d1544 = external constant [0 x i8]
declare %"compiler/mir:Case" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eAt_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2ewalkJoin(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i64 %a2, i64 %a3, ptr %a4)
@G_2ecompiler_2fmir_2eNoBlock = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
@olang_loc_82759c8127bb92d9_9a26fc180f98a435 = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ewidenBF16(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2enarrowBF16(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
