; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/emit:Emitter" = type { ptr, ptr, ptr, ptr, i1, i1, i1, i1, i1, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, i1, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, i64, i64, i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/lower:Lowerer" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i32, i32, i64, i64, i64, i64, i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/generic:AnyTable" = type { i32, i32, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/eval:Image" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1 }
%"compiler/eval:Blob" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, { i64, ptr }, i32 }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, { i64, ptr }, i1 }
%"compiler/mir:Fn" = type { { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
%"compiler/emit:fnEm" = type { ptr, ptr, { i64, [2 x i64] }, %"std/prelude/text:StringBuilder", %"std/prelude/text:StringBuilder", %"std/prelude/text:StringBuilder", i64, i64, i64, i32, i1, i1, i1, i1, i1, { i64, ptr }, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/text:StringBuilder", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64 }
%"compiler/mir:Lvalue" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/mir:Local" = type { i32, %"compiler/source:Span", i32, i32, { i64, [1 x i64] } }
%"compiler/mir:ScopeInfo" = type { i32, i32, i32, %"compiler/source:Span", i32 }
%"compiler/mir:Case" = type { i64, i32 }
%"compiler/mir:Call" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Lvalue", i1, i32, i32, i32 }
%"compiler/mir:Task" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/source:Span", %"compiler/mir:Range" }
%"compiler/emit:Object" = type { { i64, ptr }, i32, { i64, ptr }, i64 }
@G_2ecompiler_2femit_2eBigCloseMark = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\12\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2eBigCloseMark.k1 }>, align 8
@G_2ecompiler_2femit_2eBigCloseMark.k1 = internal constant <{ [18 x i8] }> <{ [18 x i8] c"\20\20\3B\6F\6C\61\6E\67\2E\62\69\67\63\6C\6F\73\65\0A" }>, align 8
@G_2ecompiler_2femit_2eHomeInst = constant <{ [8 x i8] }> <{ [8 x i8] c"\FD\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2femit_2eHomeLoc = constant <{ [8 x i8] }> <{ [8 x i8] c"\FC\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2femit_2eHomeLocal = constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2femit_2eHomeShared = constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2femit_2ePartSize = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\10\00\00\00\00\00" }>, align 8
@G_2ecompiler_2femit_2ePartSizeDev = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\08\00\00\00\00\00" }>, align 8
@G_2ecompiler_2femit_2ehexDigits = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2ehexDigits.k1 }>, align 8
@G_2ecompiler_2femit_2ehexDigits.k1 = internal global <{ [16 x i8] }> <{ [16 x i8] c"\30\31\32\33\34\35\36\37\38\39\41\42\43\44\45\46" }>, align 8
@G_2ecompiler_2femit_2emathExact = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [24 x i8] }> <{ [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k1, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k2, [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k3, [24 x i8] c"\09\00\00\00\00\00\00\00\09\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 64
@G_2ecompiler_2femit_2emathExact.k1 = internal global <{ [8 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [176 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k4, [16 x i8] c"\01\00\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k5, [16 x i8] c"\01\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k6, [16 x i8] c"\01\00\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k7, [16 x i8] c"\01\00\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k8, [16 x i8] c"\01\00\00\00\00\00\00\00\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k9, [16 x i8] c"\01\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k10, [16 x i8] c"\01\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k11, [16 x i8] c"\02\00\00\00\00\00\00\00\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k12, [176 x i8] c"\03\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2femit_2emathExact.k2 = internal global <{ [128 x i8] }> <{ [128 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\05\00\00\00\00\00\00\00\03\00\00\00\00\00\00\00\06\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2femit_2emathExact.k3 = internal global <{ [128 x i8] }> <{ [128 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\07\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\08\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\04\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\01\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\00\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2femit_2emathExact.k4 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\73\71\72\74" }>, align 8
@G_2ecompiler_2femit_2emathExact.k5 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\66\6C\6F\6F\72" }>, align 8
@G_2ecompiler_2femit_2emathExact.k6 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\63\65\69\6C" }>, align 8
@G_2ecompiler_2femit_2emathExact.k7 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\74\72\75\6E\63" }>, align 8
@G_2ecompiler_2femit_2emathExact.k8 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\72\6F\75\6E\64" }>, align 8
@G_2ecompiler_2femit_2emathExact.k9 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\72\6F\75\6E\64\65\76\65\6E" }>, align 8
@G_2ecompiler_2femit_2emathExact.k10 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\66\61\62\73" }>, align 8
@G_2ecompiler_2femit_2emathExact.k11 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\63\6F\70\79\73\69\67\6E" }>, align 8
@G_2ecompiler_2femit_2emathExact.k12 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\66\6D\61" }>, align 8
@G_2ecompiler_2femit_2emathInexact = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [24 x i8] }> <{ [8 x i8] c"\40\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k1, [8 x i8] c"\40\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k2, [8 x i8] c"\40\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k3, [24 x i8] c"\2C\00\00\00\00\00\00\00\2C\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 64
@G_2ecompiler_2femit_2emathInexact.k1 = internal global <{ [8 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, [488 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k4, [16 x i8] c"\01\00\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k5, [16 x i8] c"\01\00\00\00\00\00\00\00\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k6, [16 x i8] c"\01\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k7, [16 x i8] c"\01\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k8, [16 x i8] c"\01\00\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k9, [16 x i8] c"\01\00\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k10, [16 x i8] c"\01\00\00\00\00\00\00\00\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k11, [16 x i8] c"\01\00\00\00\00\00\00\00\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k12, [16 x i8] c"\01\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k13, [16 x i8] c"\01\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k14, [16 x i8] c"\01\00\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k15, [16 x i8] c"\01\00\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k16, [16 x i8] c"\01\00\00\00\00\00\00\00\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k17, [16 x i8] c"\01\00\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k18, [16 x i8] c"\01\00\00\00\00\00\00\00\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k19, [16 x i8] c"\01\00\00\00\00\00\00\00\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k20, [16 x i8] c"\01\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k21, [16 x i8] c"\01\00\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k22, [16 x i8] c"\01\00\00\00\00\00\00\00\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k23, [16 x i8] c"\01\00\00\00\00\00\00\00\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k24, [16 x i8] c"\01\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k25, [16 x i8] c"\01\00\00\00\00\00\00\00\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k26, [16 x i8] c"\01\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k27, [16 x i8] c"\01\00\00\00\00\00\00\00\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k28, [16 x i8] c"\01\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k29, [16 x i8] c"\01\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k30, [16 x i8] c"\01\00\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k31, [16 x i8] c"\01\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k32, [16 x i8] c"\01\00\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k33, [16 x i8] c"\01\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k34, [16 x i8] c"\01\00\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k35, [16 x i8] c"\01\00\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k36, [16 x i8] c"\01\00\00\00\00\00\00\00\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k37, [16 x i8] c"\01\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k38, [16 x i8] c"\01\00\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k39, [16 x i8] c"\01\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k40, [16 x i8] c"\01\00\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k41, [16 x i8] c"\01\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k42, [16 x i8] c"\01\00\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k43, [16 x i8] c"\01\00\00\00\00\00\00\00\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k44, [16 x i8] c"\01\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k45, [16 x i8] c"\01\00\00\00\00\00\00\00\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k46, [16 x i8] c"\01\00\00\00\00\00\00\00\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k47, [488 x i8] c"\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2femit_2emathInexact.k2 = internal global <{ [512 x i8] }> <{ [512 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\03\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\01\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\0C\00\00\00\00\00\00\00\0D\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\0A\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\08\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\04\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\1C\00\00\00\00\00\00\00\1D\00\00\00\00\00\00\00\16\00\00\00\00\00\00\00\17\00\00\00\00\00\00\00\0E\00\00\00\00\00\00\00\0F\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\11\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2femit_2emathInexact.k3 = internal global <{ [512 x i8] }> <{ [512 x i8] c"\1B\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\27\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\02\00\00\00\00\00\00\00\2A\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\0B\00\00\00\00\00\00\00\25\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\26\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\09\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\18\00\00\00\00\00\00\00\13\00\00\00\00\00\00\00\19\00\00\00\00\00\00\00\1F\00\00\00\00\00\00\00\24\00\00\00\00\00\00\00\2B\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\1E\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\29\00\00\00\00\00\00\00\21\00\00\00\00\00\00\00\07\00\00\00\00\00\00\00\12\00\00\00\00\00\00\00\1A\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\06\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\14\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\28\00\00\00\00\00\00\00\15\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\10\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\20\00\00\00\00\00\00\00\05\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\23\00\00\00\00\00\00\00\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\FF\22\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2femit_2emathInexact.k4 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\63\62\72\74" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k5 = internal global <{ [5 x i8] }> <{ [5 x i8] c"\63\62\72\74\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k6 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\65\78\70" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k7 = internal global <{ [4 x i8] }> <{ [4 x i8] c"\65\78\70\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k8 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\65\78\70\32" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k9 = internal global <{ [5 x i8] }> <{ [5 x i8] c"\65\78\70\32\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k10 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\65\78\70\6D\31" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k11 = internal global <{ [6 x i8] }> <{ [6 x i8] c"\65\78\70\6D\31\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k12 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\6C\6F\67" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k13 = internal global <{ [4 x i8] }> <{ [4 x i8] c"\6C\6F\67\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k14 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\6C\6F\67\32" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k15 = internal global <{ [5 x i8] }> <{ [5 x i8] c"\6C\6F\67\32\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k16 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\6C\6F\67\31\30" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k17 = internal global <{ [6 x i8] }> <{ [6 x i8] c"\6C\6F\67\31\30\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k18 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\6C\6F\67\31\70" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k19 = internal global <{ [6 x i8] }> <{ [6 x i8] c"\6C\6F\67\31\70\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k20 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\70\6F\77" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k21 = internal global <{ [4 x i8] }> <{ [4 x i8] c"\70\6F\77\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k22 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\68\79\70\6F\74" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k23 = internal global <{ [6 x i8] }> <{ [6 x i8] c"\68\79\70\6F\74\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k24 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\73\69\6E" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k25 = internal global <{ [4 x i8] }> <{ [4 x i8] c"\73\69\6E\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k26 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\63\6F\73" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k27 = internal global <{ [4 x i8] }> <{ [4 x i8] c"\63\6F\73\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k28 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\74\61\6E" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k29 = internal global <{ [4 x i8] }> <{ [4 x i8] c"\74\61\6E\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k30 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\61\73\69\6E" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k31 = internal global <{ [5 x i8] }> <{ [5 x i8] c"\61\73\69\6E\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k32 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\61\63\6F\73" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k33 = internal global <{ [5 x i8] }> <{ [5 x i8] c"\61\63\6F\73\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k34 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\61\74\61\6E" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k35 = internal global <{ [5 x i8] }> <{ [5 x i8] c"\61\74\61\6E\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k36 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\61\74\61\6E\32" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k37 = internal global <{ [6 x i8] }> <{ [6 x i8] c"\61\74\61\6E\32\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k38 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\73\69\6E\68" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k39 = internal global <{ [5 x i8] }> <{ [5 x i8] c"\73\69\6E\68\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k40 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\63\6F\73\68" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k41 = internal global <{ [5 x i8] }> <{ [5 x i8] c"\63\6F\73\68\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k42 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\74\61\6E\68" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k43 = internal global <{ [5 x i8] }> <{ [5 x i8] c"\74\61\6E\68\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k44 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\65\72\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k45 = internal global <{ [4 x i8] }> <{ [4 x i8] c"\65\72\66\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k46 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\65\72\66\63" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k47 = internal global <{ [5 x i8] }> <{ [5 x i8] c"\65\72\66\63\66" }>, align 8
@G_2ecompiler_2femit_2etbaaElem = constant <{ [120 x i8] }> <{ [120 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\1F\00\00\00\00\00\00\00\51\00\00\00\00\00\00\00\52\00\00\00\00\00\00\00\21\00\00\00\00\00\00\00\22\00\00\00\00\00\00\00\20\00\00\00\00\00\00\00\53\00\00\00\00\00\00\00\54\00\00\00\00\00\00\00\55\00\00\00\00\00\00\00\56\00\00\00\00\00\00\00\57\00\00\00\00\00\00\00\23\00\00\00\00\00\00\00\24\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2femit_2etbaaField = constant <{ [120 x i8] }> <{ [120 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\15\00\00\00\00\00\00\00\3D\00\00\00\00\00\00\00\3E\00\00\00\00\00\00\00\17\00\00\00\00\00\00\00\18\00\00\00\00\00\00\00\16\00\00\00\00\00\00\00\3F\00\00\00\00\00\00\00\40\00\00\00\00\00\00\00\41\00\00\00\00\00\00\00\42\00\00\00\00\00\00\00\43\00\00\00\00\00\00\00\19\00\00\00\00\00\00\00\1A\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2femit_2etbaaName = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k1, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k2, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k3, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k4, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k5, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k6, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k7, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k8, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k9, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k10, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k11, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k12, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k13, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k14, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k15 }>, align 64
@G_2ecompiler_2femit_2etbaaName.k1 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2femit_2etbaaName.k2 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2femit_2etbaaName.k3 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\62\6F\6F\6C" }>, align 8
@G_2ecompiler_2femit_2etbaaName.k4 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\69\38" }>, align 8
@G_2ecompiler_2femit_2etbaaName.k5 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\69\31\36" }>, align 8
@G_2ecompiler_2femit_2etbaaName.k6 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\69\6E\74\33\32" }>, align 8
@G_2ecompiler_2femit_2etbaaName.k7 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\69\6E\74\36\34" }>, align 8
@G_2ecompiler_2femit_2etbaaName.k8 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\62\79\74\65" }>, align 8
@G_2ecompiler_2femit_2etbaaName.k9 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\75\31\36" }>, align 8
@G_2ecompiler_2femit_2etbaaName.k10 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\75\33\32" }>, align 8
@G_2ecompiler_2femit_2etbaaName.k11 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\75\36\34" }>, align 8
@G_2ecompiler_2femit_2etbaaName.k12 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\66\31\36" }>, align 8
@G_2ecompiler_2femit_2etbaaName.k13 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\62\66\31\36" }>, align 8
@G_2ecompiler_2femit_2etbaaName.k14 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\66\6C\6F\61\74\33\32" }>, align 8
@G_2ecompiler_2femit_2etbaaName.k15 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\66\6C\6F\61\74\36\34" }>, align 8
@G_2ecompiler_2femit_2etbaaTree = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\69\07\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaTree.k1 }>, align 8
@G_2ecompiler_2femit_2etbaaTree.k1 = internal constant <{ [1897 x i8] }> <{ [1897 x i8] c"\0A\21\32\30\20\3D\20\21\7B\21\22\6F\6C\61\6E\67\22\7D\0A\21\39\39\20\3D\20\21\7B\21\22\62\72\61\6E\63\68\5F\77\65\69\67\68\74\73\22\2C\20\69\33\32\20\31\2C\20\69\33\32\20\32\30\30\30\7D\0A\21\34\39\20\3D\20\21\7B\21\22\73\63\6F\70\65\68\64\72\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\35\30\20\3D\20\21\7B\21\22\63\68\75\6E\6B\68\64\72\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\35\39\20\3D\20\21\7B\21\34\39\2C\20\21\34\39\2C\20\69\36\34\20\30\7D\0A\21\36\30\20\3D\20\21\7B\21\35\30\2C\20\21\35\30\2C\20\69\36\34\20\30\7D\0A\21\31\37\20\3D\20\21\7B\21\22\61\72\72\61\79\64\65\73\63\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\31\38\20\3D\20\21\7B\21\22\63\6C\6F\73\75\72\65\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\34\37\20\3D\20\21\7B\21\22\61\72\72\61\79\64\65\73\63\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\31\39\20\3D\20\21\7B\21\22\72\65\66\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\34\38\20\3D\20\21\7B\21\22\72\65\66\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\32\39\20\3D\20\21\7B\21\31\39\2C\20\21\31\39\2C\20\69\36\34\20\30\7D\0A\21\33\39\20\3D\20\21\7B\21\34\38\2C\20\21\34\38\2C\20\69\36\34\20\30\7D\0A\21\32\37\20\3D\20\21\7B\21\31\37\2C\20\21\31\37\2C\20\69\36\34\20\30\7D\0A\21\32\38\20\3D\20\21\7B\21\31\38\2C\20\21\31\38\2C\20\69\36\34\20\30\7D\0A\21\33\37\20\3D\20\21\7B\21\34\37\2C\20\21\34\37\2C\20\69\36\34\20\30\7D\0A\21\31\31\20\3D\20\21\7B\21\22\62\6F\6F\6C\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\32\31\20\3D\20\21\7B\21\31\31\2C\20\21\31\31\2C\20\69\36\34\20\30\7D\0A\21\34\31\20\3D\20\21\7B\21\22\62\6F\6F\6C\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\33\31\20\3D\20\21\7B\21\34\31\2C\20\21\34\31\2C\20\69\36\34\20\30\7D\0A\21\35\31\20\3D\20\21\7B\21\22\69\38\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\36\31\20\3D\20\21\7B\21\35\31\2C\20\21\35\31\2C\20\69\36\34\20\30\7D\0A\21\39\31\20\3D\20\21\7B\21\22\69\38\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\38\31\20\3D\20\21\7B\21\39\31\2C\20\21\39\31\2C\20\69\36\34\20\30\7D\0A\21\35\32\20\3D\20\21\7B\21\22\69\31\36\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\36\32\20\3D\20\21\7B\21\35\32\2C\20\21\35\32\2C\20\69\36\34\20\30\7D\0A\21\39\32\20\3D\20\21\7B\21\22\69\31\36\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\38\32\20\3D\20\21\7B\21\39\32\2C\20\21\39\32\2C\20\69\36\34\20\30\7D\0A\21\31\33\20\3D\20\21\7B\21\22\69\6E\74\33\32\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\32\33\20\3D\20\21\7B\21\31\33\2C\20\21\31\33\2C\20\69\36\34\20\30\7D\0A\21\34\33\20\3D\20\21\7B\21\22\69\6E\74\33\32\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\33\33\20\3D\20\21\7B\21\34\33\2C\20\21\34\33\2C\20\69\36\34\20\30\7D\0A\21\31\34\20\3D\20\21\7B\21\22\69\6E\74\36\34\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\32\34\20\3D\20\21\7B\21\31\34\2C\20\21\31\34\2C\20\69\36\34\20\30\7D\0A\21\34\34\20\3D\20\21\7B\21\22\69\6E\74\36\34\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\33\34\20\3D\20\21\7B\21\34\34\2C\20\21\34\34\2C\20\69\36\34\20\30\7D\0A\21\31\32\20\3D\20\21\7B\21\22\62\79\74\65\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\32\32\20\3D\20\21\7B\21\31\32\2C\20\21\31\32\2C\20\69\36\34\20\30\7D\0A\21\34\32\20\3D\20\21\7B\21\22\62\79\74\65\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\33\32\20\3D\20\21\7B\21\34\32\2C\20\21\34\32\2C\20\69\36\34\20\30\7D\0A\21\35\33\20\3D\20\21\7B\21\22\75\31\36\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\36\33\20\3D\20\21\7B\21\35\33\2C\20\21\35\33\2C\20\69\36\34\20\30\7D\0A\21\39\33\20\3D\20\21\7B\21\22\75\31\36\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\38\33\20\3D\20\21\7B\21\39\33\2C\20\21\39\33\2C\20\69\36\34\20\30\7D\0A\21\35\34\20\3D\20\21\7B\21\22\75\33\32\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\36\34\20\3D\20\21\7B\21\35\34\2C\20\21\35\34\2C\20\69\36\34\20\30\7D\0A\21\39\34\20\3D\20\21\7B\21\22\75\33\32\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\38\34\20\3D\20\21\7B\21\39\34\2C\20\21\39\34\2C\20\69\36\34\20\30\7D\0A\21\35\35\20\3D\20\21\7B\21\22\75\36\34\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\36\35\20\3D\20\21\7B\21\35\35\2C\20\21\35\35\2C\20\69\36\34\20\30\7D\0A\21\39\35\20\3D\20\21\7B\21\22\75\36\34\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\38\35\20\3D\20\21\7B\21\39\35\2C\20\21\39\35\2C\20\69\36\34\20\30\7D\0A\21\35\36\20\3D\20\21\7B\21\22\66\31\36\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\36\36\20\3D\20\21\7B\21\35\36\2C\20\21\35\36\2C\20\69\36\34\20\30\7D\0A\21\39\36\20\3D\20\21\7B\21\22\66\31\36\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\38\36\20\3D\20\21\7B\21\39\36\2C\20\21\39\36\2C\20\69\36\34\20\30\7D\0A\21\35\37\20\3D\20\21\7B\21\22\62\66\31\36\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\36\37\20\3D\20\21\7B\21\35\37\2C\20\21\35\37\2C\20\69\36\34\20\30\7D\0A\21\39\37\20\3D\20\21\7B\21\22\62\66\31\36\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\38\37\20\3D\20\21\7B\21\39\37\2C\20\21\39\37\2C\20\69\36\34\20\30\7D\0A\21\31\35\20\3D\20\21\7B\21\22\66\6C\6F\61\74\33\32\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\32\35\20\3D\20\21\7B\21\31\35\2C\20\21\31\35\2C\20\69\36\34\20\30\7D\0A\21\34\35\20\3D\20\21\7B\21\22\66\6C\6F\61\74\33\32\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\33\35\20\3D\20\21\7B\21\34\35\2C\20\21\34\35\2C\20\69\36\34\20\30\7D\0A\21\31\36\20\3D\20\21\7B\21\22\66\6C\6F\61\74\36\34\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\32\36\20\3D\20\21\7B\21\31\36\2C\20\21\31\36\2C\20\69\36\34\20\30\7D\0A\21\34\36\20\3D\20\21\7B\21\22\66\6C\6F\61\74\36\34\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\33\36\20\3D\20\21\7B\21\34\36\2C\20\21\34\36\2C\20\69\36\34\20\30\7D\0A\0A" }>, align 64
define dso_local { i64, ptr } @compiler_2femit_2ecWordName(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i8
  %l10 = alloca %"std/prelude/text:StringBuilder"
  %l16 = alloca i64
  %l19 = alloca i64
  %l37 = alloca { i64, ptr }
  %l44 = alloca i1
  %l47 = alloca i1
  %l49 = alloca i1
  %l50 = alloca i1
  %l51 = alloca { i64, ptr }
  %l56 = alloca i1
  %l57 = alloca { i64, ptr }
  %l61 = alloca i1
  %l64 = alloca ptr
  %l66 = alloca i8
  %l70 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l72 = alloca i64
  %l73 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l10
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store i1 false, ptr %l2, !tbaa !21
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l19, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l19, !tbaa !24
  store i64 %t33, ptr %l16, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l16, !tbaa !24
  store i64 %t34, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l7, !tbaa !24
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb37
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l8, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t53, ptr %l37, !tbaa !27
  %t54 = load i64, ptr %l8, !tbaa !24
  %t56 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr i8, ptr %t57, i64 %t54
  %t59 = load i8, ptr %t58, !tbaa !32
  store i8 %t59, ptr %l9, !tbaa !22
  %t61 = load i8, ptr %l9, !tbaa !22
  %t63 = icmp eq i8 %t61, 46
  br i1 %t63, label %bb12, label %bb13
bb12:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 95)
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb36
bb15:
  %t66 = load i1, ptr %l2, !tbaa !21
  br i1 %t66, label %bb16, label %bb17
bb16:
  %t68 = load i64, ptr %l8, !tbaa !24
  %t70 = icmp sgt i64 %t68, 0
  store i1 %t70, ptr %l44, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb18
bb18:
  %t72 = load i1, ptr %l44, !tbaa !21
  br i1 %t72, label %bb19, label %bb20
bb19:
  %t73 = load i8, ptr %l9, !tbaa !22
  %t75 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t73)
  store i1 %t75, ptr %l49
  br label %bb21
bb20:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb22
bb21:
  %t76 = load i1, ptr %l49, !tbaa !21
  store i1 %t76, ptr %l47, !tbaa !21
  br label %bb22
bb22:
  %t77 = load i1, ptr %l47, !tbaa !21
  br i1 %t77, label %bb23, label %bb24
bb23:
  %t78 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t78, ptr %l51, !tbaa !27
  %t79 = load i64, ptr %l8, !tbaa !24
  %t81 = sub i64 %t79, 1
  %t83 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = getelementptr i8, ptr %t84, i64 %t81
  %t86 = load i8, ptr %t85, !tbaa !32
  %t88 = icmp ne i8 %t86, 46
  store i1 %t88, ptr %l50, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb25
bb25:
  %t90 = load i1, ptr %l50, !tbaa !21
  br i1 %t90, label %bb26, label %bb27
bb26:
  %t91 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t91, ptr %l57, !tbaa !27
  %t92 = load i64, ptr %l8, !tbaa !24
  %t94 = sub i64 %t92, 1
  %t96 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr i8, ptr %t97, i64 %t94
  %t99 = load i8, ptr %t98, !tbaa !32
  %t101 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t99)
  store i1 %t101, ptr %l61
  br label %bb28
bb27:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb29
bb28:
  %t102 = load i1, ptr %l61, !tbaa !21
  %t103 = xor i1 %t102, true
  store i1 %t103, ptr %l56, !tbaa !21
  br label %bb29
bb29:
  %t105 = load i1, ptr %l56, !tbaa !21
  br i1 %t105, label %bb30, label %bb31
bb30:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 95)
  br label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb33
bb33:
  store ptr %l1, ptr %l64, !tbaa !29
  %t107 = load i8, ptr %l9, !tbaa !22
  %t109 = call i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToUpper(i8 %t107)
  store i8 %t109, ptr %l66
  br label %bb34
bb34:
  %t110 = load ptr, ptr %l64, !tbaa !29
  %t111 = load i8, ptr %l66, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t110, i8 %t111)
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t112 = load i64, ptr %l7, !tbaa !24
  %t114 = add i64 %t112, 1
  store i64 %t114, ptr %l7, !tbaa !24
  br label %bb8
bb37:
  %t117 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t117, ptr %l70
  br label %bb38
bb38:
  %t118 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t118, ptr %l71, !tbaa !27
  %t119 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t119, 0
  store i64 %t120, ptr %l72, !tbaa !24
  %t121 = load i64, ptr %l72, !tbaa !24
  %t122 = mul i64 %t121, 1
  %t123 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t122)
  %t124 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t123, 1
  store { i64, ptr } %t125, ptr %l73, !tbaa !27
  %t126 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = load i64, ptr %l72, !tbaa !24
  %t131 = mul i64 %t130, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t127, ptr %t129, i64 %t131, i1 false)
  %t132 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t132, ptr %l71, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t133 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t133, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eProfName(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l25 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l38 = alloca ptr
  %l41 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l47 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l75 = alloca ptr
  %l84 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l100 = alloca i64
  %l101 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l116 = alloca { i64, ptr }
  %l119 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t122 = alloca { i64, [2 x i64] }, align 8
  %t228 = alloca { i64, [2 x i64] }, align 8
  %t280 = alloca { i64, [2 x i64] }, align 8
  %t311 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load { i64, [2 x i64] }, ptr %l1
  %t8 = extractvalue { i64, [2 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  store i32 %t13, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  br label %bb49
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/emit:Emitter", ptr %t15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/lower:Lowerer", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = load i32, ptr %l3, !tbaa !23
  %t25 = sext i32 %t23 to i64
  %t28 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t21, i64 %t25)
  store ptr %t28, ptr %l25
  br label %bb4
bb4:
  %t29 = load ptr, ptr %l25, !tbaa !29
  %t31 = getelementptr %"compiler/typed:Body", ptr %t29, i32 0, i32 1
  %t32 = load { i64, [2 x i64] }, ptr %t31
  store { i64, [2 x i64] } %t32, ptr %l4
  %t34 = load { i64, [2 x i64] }, ptr %l4
  %t36 = extractvalue { i64, [2 x i64] } %t34, 0
  %t37 = icmp eq i64 %t36, 0
  br i1 %t37, label %bb5, label %bb6
bb5:
  %t39 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t40 = getelementptr { i64 }, ptr %t39, i32 0, i32 0
  %t41 = load i64, ptr %t40
  store i64 %t41, ptr %l5, !tbaa !24
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i64, ptr %l5, !tbaa !24
  %t47 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2einstanceProfName(ptr %v0, ptr %v1, ptr %t43, i64 %t44)
  store { i64, ptr } %t47, ptr %l34
  br label %bb8
bb8:
  %t48 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t48, ptr %l28, !tbaa !27
  br label %bb48
bb9:
  %t49 = load { i64, [2 x i64] }, ptr %l4
  %t51 = extractvalue { i64, [2 x i64] } %t49, 0
  %t52 = icmp eq i64 %t51, 1
  br i1 %t52, label %bb10, label %bb11
bb10:
  %t54 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t55 = getelementptr { i32, i32 }, ptr %t54, i32 0, i32 0
  %t56 = load i32, ptr %t55
  store i32 %t56, ptr %l6, !tbaa !23
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l38, !tbaa !29
  %t59 = load ptr, ptr %l2, !tbaa !29
  %t60 = load i32, ptr %l6, !tbaa !23
  %t63 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %t59, i32 %t60)
  store { i64, ptr } %t63, ptr %l41
  br label %bb13
bb13:
  %t64 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  %t66 = extractvalue { i64, ptr } %t64, 1
  %t67 = mul i64 %t65, 1
  %t68 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t67)
  call void @llvm.memcpy.p0.p0.i64(ptr %t68, ptr %t66, i64 %t67, i1 false)
  %t69 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t68, 1
  %t71 = load ptr, ptr %l38, !tbaa !29
  %t73 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ereadableTypes(ptr %v0, ptr %v1, ptr %v1, ptr %t71, { i64, ptr } %t70)
  store { i64, ptr } %t73, ptr %l43
  br label %bb14
bb14:
  %t74 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t74, ptr %l28, !tbaa !27
  br label %bb48
bb15:
  %t75 = load { i64, [2 x i64] }, ptr %l4
  %t77 = extractvalue { i64, [2 x i64] } %t75, 0
  %t78 = icmp eq i64 %t77, 3
  br i1 %t78, label %bb16, label %bb17
bb16:
  %t80 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t81 = getelementptr { i32 }, ptr %t80, i32 0, i32 0
  %t82 = load i32, ptr %t81
  store i32 %t82, ptr %l7, !tbaa !23
  br label %bb18
bb17:
  br label %bb21
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  %t84 = load ptr, ptr %l0, !tbaa !29
  store ptr %t84, ptr %l47, !tbaa !29
  %t85 = load ptr, ptr %l2, !tbaa !29
  %t86 = load i32, ptr %l7, !tbaa !23
  %t89 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s4, ptr %t85, i32 %t86)
  store { i64, ptr } %t89, ptr %l50
  br label %bb19
bb19:
  %t90 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  %t92 = extractvalue { i64, ptr } %t90, 1
  %t93 = mul i64 %t91, 1
  %t94 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t93)
  call void @llvm.memcpy.p0.p0.i64(ptr %t94, ptr %t92, i64 %t93, i1 false)
  %t95 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  %t97 = load ptr, ptr %l47, !tbaa !29
  %t99 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ereadableTypes(ptr %v0, ptr %s4, ptr %s4, ptr %t97, { i64, ptr } %t96)
  store { i64, ptr } %t99, ptr %l52
  br label %bb20
bb20:
  %t100 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t104 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t105 = add i64 %t102, %t104
  %t106 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t105)
  call void @olang_textcopy(ptr %t106, ptr %t101, i64 %t102)
  %t107 = getelementptr i8, ptr %t106, i64 %t102
  call void @olang_textcopy(ptr %t107, ptr %t103, i64 %t104)
  %t108 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t106, 1
  store { i64, ptr } %t109, ptr %l28, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  br label %bb48
bb21:
  %t111 = load { i64, [2 x i64] }, ptr %l4
  %t113 = extractvalue { i64, [2 x i64] } %t111, 0
  %t114 = icmp eq i64 %t113, 4
  br i1 %t114, label %bb22, label %bb23
bb22:
  %t116 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t117 = getelementptr { i32 }, ptr %t116, i32 0, i32 0
  %t118 = load i32, ptr %t117
  store i32 %t118, ptr %l8, !tbaa !23
  br label %bb24
bb23:
  br label %bb26
bb24:
  store %olang.scope zeroinitializer, ptr %s6
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load i32, ptr %l8, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t122
  %t123 = getelementptr { i64, [2 x i64] }, ptr %t122, i32 0, i32 0
  store i64 0, ptr %t123
  %t125 = insertvalue { i32 } undef, i32 %t121, 0
  %t126 = getelementptr { i64, [2 x i64] }, ptr %t122, i32 0, i32 1
  store { i32 } %t125, ptr %t126
  %t127 = load { i64, [2 x i64] }, ptr %t122
  %t130 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eProfName(ptr %v0, ptr %s6, ptr %t120, { i64, [2 x i64] } %t127)
  store { i64, ptr } %t130, ptr %l60
  br label %bb25
bb25:
  %t131 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t131, 1
  %t133 = extractvalue { i64, ptr } %t131, 0
  %t134 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t135 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t136 = add i64 %t133, %t135
  %t137 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t136)
  call void @olang_textcopy(ptr %t137, ptr %t132, i64 %t133)
  %t138 = getelementptr i8, ptr %t137, i64 %t133
  call void @olang_textcopy(ptr %t138, ptr %t134, i64 %t135)
  %t139 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr %t137, 1
  store { i64, ptr } %t140, ptr %l28, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb48
bb26:
  %t142 = load { i64, [2 x i64] }, ptr %l4
  %t144 = extractvalue { i64, [2 x i64] } %t142, 0
  %t145 = icmp eq i64 %t144, 5
  br i1 %t145, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %l64, !tbaa !27
  %t147 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t147, ptr %l28, !tbaa !27
  br label %bb48
bb30:
  %t149 = load { i64, [2 x i64] }, ptr %l4
  %t151 = extractvalue { i64, [2 x i64] } %t149, 0
  %t152 = icmp eq i64 %t151, 6
  br i1 %t152, label %bb31, label %bb32
bb31:
  %t154 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t155 = getelementptr { i64, i32 }, ptr %t154, i32 0, i32 0
  %t156 = load i64, ptr %t155
  store i64 %t156, ptr %l9, !tbaa !24
  %t158 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t159 = getelementptr { i64, i32 }, ptr %t158, i32 0, i32 1
  %t160 = load i32, ptr %t159
  store i32 %t160, ptr %l10, !tbaa !23
  br label %bb33
bb32:
  br label %bb37
bb33:
  store %olang.scope zeroinitializer, ptr %s9
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/emit:Emitter", ptr %t162, i32 0, i32 0
  %t165 = load ptr, ptr %t164, !tbaa !29
  %t167 = getelementptr %"compiler/generic:Program", ptr %t165, i32 0, i32 0
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t170 = getelementptr %"compiler/load:Loader", ptr %t168, i32 0, i32 10
  %t171 = load i64, ptr %l9, !tbaa !24
  %t174 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t170, i64 %t171)
  store ptr %t174, ptr %l75
  br label %bb34
bb34:
  %t175 = load ptr, ptr %l75, !tbaa !29
  %t177 = getelementptr %"compiler/load:Module", ptr %t175, i32 0, i32 2
  %t178 = load { i64, ptr }, ptr %t177, !tbaa !27
  %t179 = load i64, ptr %l9, !tbaa !24
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/emit:Emitter", ptr %t180, i32 0, i32 0
  %t183 = load ptr, ptr %t182, !tbaa !29
  %t185 = getelementptr %"compiler/generic:Program", ptr %t183, i32 0, i32 0
  %t186 = load ptr, ptr %t185, !tbaa !29
  %t188 = getelementptr %"compiler/load:Loader", ptr %t186, i32 0, i32 12
  %t189 = load i64, ptr %t188, !tbaa !24
  %t192 = icmp eq i64 %t179, %t189
  %t195 = call { i64, ptr } @compiler_2fload_2eErrQualifier(ptr %v0, ptr %s9, { i64, ptr } %t178, i1 %t192)
  store { i64, ptr } %t195, ptr %l84
  br label %bb35
bb35:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load i32, ptr %l10, !tbaa !23
  %t200 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %s9, ptr %t196, i32 %t197)
  store { i64, ptr } %t200, ptr %l87
  br label %bb36
bb36:
  %t201 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t202 = extractvalue { i64, ptr } %t201, 1
  %t203 = extractvalue { i64, ptr } %t201, 0
  %t204 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t205 = extractvalue { i64, ptr } %t204, 1
  %t206 = extractvalue { i64, ptr } %t204, 0
  %t207 = add i64 %t203, %t206
  %t208 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t209 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t210 = add i64 %t207, %t209
  %t211 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t210)
  call void @olang_textcopy(ptr %t211, ptr %t202, i64 %t203)
  %t212 = getelementptr i8, ptr %t211, i64 %t203
  call void @olang_textcopy(ptr %t212, ptr %t205, i64 %t206)
  %t213 = getelementptr i8, ptr %t212, i64 %t206
  call void @olang_textcopy(ptr %t213, ptr %t208, i64 %t209)
  %t214 = insertvalue { i64, ptr } undef, i64 %t210, 0
  %t215 = insertvalue { i64, ptr } %t214, ptr %t211, 1
  store { i64, ptr } %t215, ptr %l28, !tbaa !27
  call void @__olang_scope_close(ptr %s9)
  br label %bb48
bb37:
  %t217 = load { i64, [2 x i64] }, ptr %l4
  %t219 = extractvalue { i64, [2 x i64] } %t217, 0
  %t220 = icmp eq i64 %t219, 8
  br i1 %t220, label %bb38, label %bb39
bb38:
  %t222 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t223 = getelementptr { i32, i32, i64 }, ptr %t222, i32 0, i32 0
  %t224 = load i32, ptr %t223
  store i32 %t224, ptr %l11, !tbaa !23
  br label %bb40
bb39:
  br label %bb42
bb40:
  store %olang.scope zeroinitializer, ptr %s11
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t227 = load i32, ptr %l11, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t228
  %t229 = getelementptr { i64, [2 x i64] }, ptr %t228, i32 0, i32 0
  store i64 0, ptr %t229
  %t231 = insertvalue { i32 } undef, i32 %t227, 0
  %t232 = getelementptr { i64, [2 x i64] }, ptr %t228, i32 0, i32 1
  store { i32 } %t231, ptr %t232
  %t233 = load { i64, [2 x i64] }, ptr %t228
  %t236 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eProfName(ptr %v0, ptr %s11, ptr %t226, { i64, [2 x i64] } %t233)
  store { i64, ptr } %t236, ptr %l95
  br label %bb41
bb41:
  %t237 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t238 = extractvalue { i64, ptr } %t237, 1
  %t239 = extractvalue { i64, ptr } %t237, 0
  %t240 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t241 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t242 = add i64 %t239, %t241
  %t243 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t242)
  call void @olang_textcopy(ptr %t243, ptr %t238, i64 %t239)
  %t244 = getelementptr i8, ptr %t243, i64 %t239
  call void @olang_textcopy(ptr %t244, ptr %t240, i64 %t241)
  %t245 = insertvalue { i64, ptr } undef, i64 %t242, 0
  %t246 = insertvalue { i64, ptr } %t245, ptr %t243, 1
  store { i64, ptr } %t246, ptr %l28, !tbaa !27
  call void @__olang_scope_close(ptr %s11)
  br label %bb48
bb42:
  br i1 true, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load { i64, [2 x i64] }, ptr %l1
  %t252 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %v1, ptr %t248, { i64, [2 x i64] } %t249)
  store { i64, ptr } %t252, ptr %l99
  br label %bb46
bb46:
  %t253 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t253, ptr %l28, !tbaa !27
  br label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_708d0e5229213e92_b8dbbceffe09cee)
  unreachable
bb48:
  %t254 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t255 = extractvalue { i64, ptr } %t254, 0
  store i64 %t255, ptr %l100, !tbaa !24
  %t256 = load i64, ptr %l100, !tbaa !24
  %t257 = mul i64 %t256, 1
  %t258 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t257)
  %t259 = insertvalue { i64, ptr } undef, i64 %t256, 0
  %t260 = insertvalue { i64, ptr } %t259, ptr %t258, 1
  store { i64, ptr } %t260, ptr %l101, !tbaa !27
  %t261 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t262 = load ptr, ptr %t261, !tbaa !27
  %t263 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !27
  %t265 = load i64, ptr %l100, !tbaa !24
  %t266 = mul i64 %t265, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t262, ptr %t264, i64 %t266, i1 false)
  %t267 = load { i64, ptr }, ptr %l101, !tbaa !27
  store { i64, ptr } %t267, ptr %l28, !tbaa !27
  %t268 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t268, ptr %rv
  br label %ret
bb49:
  %t269 = load { i64, [2 x i64] }, ptr %l1
  %t271 = extractvalue { i64, [2 x i64] } %t269, 0
  %t272 = icmp eq i64 %t271, 1
  br i1 %t272, label %bb50, label %bb51
bb50:
  %t274 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t275 = getelementptr { i32 }, ptr %t274, i32 0, i32 0
  %t276 = load i32, ptr %t275
  store i32 %t276, ptr %l12, !tbaa !23
  br label %bb52
bb51:
  br label %bb54
bb52:
  store %olang.scope zeroinitializer, ptr %s14
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t279 = load i32, ptr %l12, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t280
  %t281 = getelementptr { i64, [2 x i64] }, ptr %t280, i32 0, i32 0
  store i64 0, ptr %t281
  %t283 = insertvalue { i32 } undef, i32 %t279, 0
  %t284 = getelementptr { i64, [2 x i64] }, ptr %t280, i32 0, i32 1
  store { i32 } %t283, ptr %t284
  %t285 = load { i64, [2 x i64] }, ptr %t280
  %t288 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eProfName(ptr %v0, ptr %s14, ptr %t278, { i64, [2 x i64] } %t285)
  store { i64, ptr } %t288, ptr %l108
  br label %bb53
bb53:
  %t289 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t290 = extractvalue { i64, ptr } %t289, 1
  %t291 = extractvalue { i64, ptr } %t289, 0
  %t292 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t293 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t294 = add i64 %t291, %t293
  %t295 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t294)
  call void @olang_textcopy(ptr %t295, ptr %t290, i64 %t291)
  %t296 = getelementptr i8, ptr %t295, i64 %t291
  call void @olang_textcopy(ptr %t296, ptr %t292, i64 %t293)
  %t297 = insertvalue { i64, ptr } undef, i64 %t294, 0
  %t298 = insertvalue { i64, ptr } %t297, ptr %t295, 1
  call void @__olang_scope_close(ptr %s14)
  store { i64, ptr } %t298, ptr %rv
  br label %ret
bb54:
  %t300 = load { i64, [2 x i64] }, ptr %l1
  %t302 = extractvalue { i64, [2 x i64] } %t300, 0
  %t303 = icmp eq i64 %t302, 2
  br i1 %t303, label %bb55, label %bb56
bb55:
  %t305 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t306 = getelementptr { i32 }, ptr %t305, i32 0, i32 0
  %t307 = load i32, ptr %t306
  store i32 %t307, ptr %l13, !tbaa !23
  br label %bb57
bb56:
  br label %bb59
bb57:
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t310 = load i32, ptr %l13, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t311
  %t312 = getelementptr { i64, [2 x i64] }, ptr %t311, i32 0, i32 0
  store i64 0, ptr %t312
  %t314 = insertvalue { i32 } undef, i32 %t310, 0
  %t315 = getelementptr { i64, [2 x i64] }, ptr %t311, i32 0, i32 1
  store { i32 } %t314, ptr %t315
  %t316 = load { i64, [2 x i64] }, ptr %t311
  %t319 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eProfName(ptr %v0, ptr %v1, ptr %t309, { i64, [2 x i64] } %t316)
  store { i64, ptr } %t319, ptr %l116
  br label %bb58
bb58:
  %t320 = load { i64, ptr }, ptr %l116, !tbaa !27
  store { i64, ptr } %t320, ptr %rv
  br label %ret
bb59:
  br i1 true, label %bb60, label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb64
bb62:
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t322 = load { i64, [2 x i64] }, ptr %l1
  %t325 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %v1, ptr %t321, { i64, [2 x i64] } %t322)
  store { i64, ptr } %t325, ptr %l119
  br label %bb63
bb63:
  %t326 = load { i64, ptr }, ptr %l119, !tbaa !27
  store { i64, ptr } %t326, ptr %rv
  br label %ret
bb64:
  call void @__olang_check_failed(ptr @olang_loc_adcc4a96e8e96893_813fe5cdd5223daf)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eProgram(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l9 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l20 = alloca i64
  %l22 = alloca i64
  %l27 = alloca { i64, ptr }
  %l35 = alloca i64
  %l37 = alloca i64
  %l42 = alloca { i64, ptr }
  %l51 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l57 = alloca ptr
  %l59 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eemitAll(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l1, !tbaa !29
  store ptr %t3, ptr %l9, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehead(ptr %v0, ptr %s0, ptr %t4)
  store { i64, ptr } %t6, ptr %l11
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t10 = extractvalue { i64, ptr } %t7, 1
  %t11 = mul i64 %t9, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t10, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  %t15 = load ptr, ptr %l9, !tbaa !29
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v1, ptr %s0, ptr %t15, { i64, ptr } %t14)
  br label %bb3
bb3:
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/emit:Emitter", ptr %t18, i32 0, i32 55
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v1, ptr %v0, ptr %t17, { i64, ptr } %t21)
  br label %bb4
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/emit:Emitter", ptr %t25, i32 0, i32 43
  store ptr %t27, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l3, !tbaa !24
  store i64 %t29, ptr %l20, !tbaa !24
  %t30 = load ptr, ptr %l2, !tbaa !29
  %t32 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t30)
  store i64 %t32, ptr %l22
  br label %bb6
bb6:
  %t33 = load i64, ptr %l20, !tbaa !24
  %t34 = load i64, ptr %l22, !tbaa !24
  %t35 = icmp slt i64 %t33, %t34
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  br label %bb9
bb9:
  %t39 = load ptr, ptr %l2, !tbaa !29
  %t40 = load i64, ptr %l3, !tbaa !24
  %t43 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t39, i64 %t40)
  store { i64, ptr } %t43, ptr %l27
  br label %bb10
bb10:
  %t44 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t45 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v1, ptr %v0, ptr %t45, { i64, ptr } %t44)
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t52 = add i64 %t50, 1
  store i64 %t52, ptr %l3, !tbaa !24
  br label %bb5
bb13:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/emit:Emitter", ptr %t54, i32 0, i32 17
  store ptr %t56, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb14
bb14:
  %t58 = load i64, ptr %l6, !tbaa !24
  store i64 %t58, ptr %l35, !tbaa !24
  %t59 = load ptr, ptr %l5, !tbaa !29
  %t61 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t59)
  store i64 %t61, ptr %l37
  br label %bb15
bb15:
  %t62 = load i64, ptr %l35, !tbaa !24
  %t63 = load i64, ptr %l37, !tbaa !24
  %t64 = icmp slt i64 %t62, %t63
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb16, label %bb17
bb16:
  br label %bb22
bb17:
  br label %bb18
bb18:
  %t68 = load ptr, ptr %l5, !tbaa !29
  %t69 = load i64, ptr %l6, !tbaa !24
  %t72 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t68, i64 %t69)
  store { i64, ptr } %t72, ptr %l42
  br label %bb19
bb19:
  %t73 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t74 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v1, ptr %v0, ptr %t74, { i64, ptr } %t73)
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t79 = load i64, ptr %l6, !tbaa !24
  %t81 = add i64 %t79, 1
  store i64 %t81, ptr %l6, !tbaa !24
  br label %bb14
bb22:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/emit:Emitter", ptr %t83, i32 0, i32 58
  %t86 = load i64, ptr %t85, !tbaa !24
  %t88 = icmp sge i64 %t86, 0
  br i1 %t88, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s7
  %t90 = load ptr, ptr %l1, !tbaa !29
  store ptr %t90, ptr %l51, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/emit:Emitter", ptr %t91, i32 0, i32 58
  %t94 = load i64, ptr %t93, !tbaa !24
  %t96 = call { i64, ptr } @compiler_2femit_2edbgTail(ptr %s7, i64 %t94)
  store { i64, ptr } %t96, ptr %l54
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t97 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t100 = extractvalue { i64, ptr } %t97, 1
  %t101 = mul i64 %t99, 1
  %t102 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t101)
  call void @llvm.memcpy.p0.p0.i64(ptr %t102, ptr %t100, i64 %t101, i1 false)
  %t103 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  %t105 = load ptr, ptr %l51, !tbaa !29
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v1, ptr %s7, ptr %t105, { i64, ptr } %t104)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s7)
  br label %bb27
bb27:
  %t107 = load ptr, ptr %l1, !tbaa !29
  store ptr %t107, ptr %l57, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eattributes(ptr %v0, ptr %s0, ptr %t108)
  store { i64, ptr } %t110, ptr %l59
  br label %bb28
bb28:
  %t111 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t111, 0
  %t114 = extractvalue { i64, ptr } %t111, 1
  %t115 = mul i64 %t113, 1
  %t116 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t115)
  call void @llvm.memcpy.p0.p0.i64(ptr %t116, ptr %t114, i64 %t115, i1 false)
  %t117 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t116, 1
  %t119 = load ptr, ptr %l57, !tbaa !29
  call void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v1, ptr %s0, ptr %t119, { i64, ptr } %t118)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eanyTable(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca ptr
  %l11 = alloca i64
  %l13 = alloca { i64, [2 x i64] }
  %l17 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l23 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca %"std/prelude/text:StringBuilder"
  %l31 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l54 = alloca ptr
  %l57 = alloca { i64, ptr }
  %l64 = alloca i64
  %l66 = alloca i64
  %l71 = alloca i64
  %l77 = alloca { i64, [2 x i64] }
  %l80 = alloca ptr
  %l83 = alloca { i64, ptr }
  %l90 = alloca i64
  %l93 = alloca ptr
  %l94 = alloca { i64, ptr }
  %l95 = alloca i64
  %l96 = alloca { i64, ptr }
  %l97 = alloca i64
  %l99 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t103 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etableName(ptr %v0, ptr %s0, ptr %t1, i64 %t2)
  store { i64, ptr } %t5, ptr %l17
  br label %bb1
bb1:
  %t6 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t8 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 1
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t11 = add i64 %t7, %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @olang_textcopy(ptr %t12, ptr %t6, i64 %t7)
  %t13 = getelementptr i8, ptr %t12, i64 %t7
  call void @olang_textcopy(ptr %t13, ptr %t9, i64 %t10)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t12, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t24 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t22)
  store { i64, ptr } %t24, ptr %l20
  br label %bb2
bb2:
  %t25 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t25, ptr %lp2
  %t26 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t27 = load ptr, ptr %lp2
  store { i64, ptr } %t26, ptr %t27, !tbaa !27
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %lp2
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  %t33 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehas(ptr %v0, ptr %v1, ptr %t28, { i64, ptr } %t30)
  store i1 %t33, ptr %l23
  br label %bb3
bb3:
  %t34 = load i1, ptr %l23, !tbaa !21
  br i1 %t34, label %bb4, label %bb5
bb4:
  %t35 = load ptr, ptr %lp2
  %t36 = load { i64, ptr }, ptr %t35, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t36, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/emit:Emitter", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 47
  %t44 = load i64, ptr %l1, !tbaa !24
  %t47 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2eRef_H53de96b937c1888202b72d022fb4696d(ptr %v0, ptr %v0, ptr %t43, i64 %t44)
  store ptr %t47, ptr %l29
  br label %bb7
bb7:
  %t48 = load ptr, ptr %l29, !tbaa !29
  store ptr %t48, ptr %l3, !tbaa !29
  %t49 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t49, ptr %l30
  br label %bb8
bb8:
  %t50 = load %"std/prelude/text:StringBuilder", ptr %l30
  store %"std/prelude/text:StringBuilder" %t50, ptr %l4
  store ptr %l4, ptr %l31, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load ptr, ptr %l3, !tbaa !29
  %t54 = getelementptr %"compiler/generic:AnyTable", ptr %t52, i32 0, i32 0
  %t55 = load i32, ptr %t54, !tbaa !23
  %t58 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etypeid(ptr %v0, ptr %s0, ptr %t51, i32 %t55)
  store { i64, ptr } %t58, ptr %l35
  br label %bb9
bb9:
  %t59 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t61 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t61, 1
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t64 = add i64 %t60, %t63
  %t65 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t64)
  call void @olang_textcopy(ptr %t65, ptr %t59, i64 %t60)
  %t66 = getelementptr i8, ptr %t65, i64 %t60
  call void @olang_textcopy(ptr %t66, ptr %t62, i64 %t63)
  %t67 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t65, 1
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t71 = extractvalue { i64, ptr } %t68, 1
  %t72 = mul i64 %t70, 1
  %t73 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t72)
  call void @llvm.memcpy.p0.p0.i64(ptr %t73, ptr %t71, i64 %t72, i1 false)
  %t74 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  %t76 = load ptr, ptr %l31, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t76, { i64, ptr } %t75)
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t78 = insertvalue [2 x i1] undef, i1 false, 0
  %t79 = insertvalue [2 x i1] %t78, i1 true, 1
  %t81 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 2, i64 8)
  store [2 x i1] %t79, ptr %t81
  store ptr %t81, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  %t83 = load ptr, ptr %l5
  store i64 2, ptr %l7, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s5
  %t86 = load i64, ptr %l6, !tbaa !24
  %t87 = load i64, ptr %l7, !tbaa !24
  %t90 = icmp slt i64 %t86, %t87
  %t92 = xor i1 %t90, true
  br i1 %t92, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s5)
  br label %bb19
bb13:
  br label %bb14
bb14:
  %t94 = load ptr, ptr %l5
  %t95 = load i64, ptr %l6, !tbaa !24
  %t98 = getelementptr [2 x i1], ptr %t94, i64 0, i64 %t95
  %t99 = load i1, ptr %t98, !tbaa !31
  %t101 = load i64, ptr %l1, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t103
  %t104 = getelementptr { i64, [2 x i64] }, ptr %t103, i32 0, i32 0
  store i64 5, ptr %t104
  %t106 = insertvalue { i64, i1 } undef, i64 %t101, 0
  %t108 = insertvalue { i64, i1 } %t106, i1 %t99, 1
  %t109 = getelementptr { i64, [2 x i64] }, ptr %t103, i32 0, i32 1
  store { i64, i1 } %t108, ptr %t109
  %t110 = load { i64, [2 x i64] }, ptr %t103
  store { i64, [2 x i64] } %t110, ptr %l9
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load { i64, [2 x i64] }, ptr %l9
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewant(ptr %v0, ptr %t112, { i64, [2 x i64] } %t113)
  br label %bb15
bb15:
  store ptr %l4, ptr %l54, !tbaa !29
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load { i64, [2 x i64] }, ptr %l9
  %t120 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s5, ptr %t116, { i64, [2 x i64] } %t117)
  store { i64, ptr } %t120, ptr %l57
  br label %bb16
bb16:
  %t121 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t122 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t123 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 1
  %t125 = extractvalue { i64, ptr } %t123, 0
  %t126 = add i64 %t122, %t125
  %t127 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t126)
  call void @olang_textcopy(ptr %t127, ptr %t121, i64 %t122)
  %t128 = getelementptr i8, ptr %t127, i64 %t122
  call void @olang_textcopy(ptr %t128, ptr %t124, i64 %t125)
  %t129 = insertvalue { i64, ptr } undef, i64 %t126, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t127, 1
  %t132 = extractvalue { i64, ptr } %t130, 0
  %t133 = extractvalue { i64, ptr } %t130, 1
  %t134 = mul i64 %t132, 1
  %t135 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t134)
  call void @llvm.memcpy.p0.p0.i64(ptr %t135, ptr %t133, i64 %t134, i1 false)
  %t136 = insertvalue { i64, ptr } undef, i64 %t132, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t135, 1
  %t138 = load ptr, ptr %l54, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t138, { i64, ptr } %t137)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s5)
  br label %bb18
bb18:
  %t140 = load i64, ptr %l6, !tbaa !24
  %t142 = add i64 %t140, 1
  store i64 %t142, ptr %l6, !tbaa !24
  br label %bb11
bb19:
  call void @__olang_scope_close(ptr %s4)
  %t144 = load ptr, ptr %l3, !tbaa !29
  %t146 = getelementptr %"compiler/generic:AnyTable", ptr %t144, i32 0, i32 5
  store ptr %t146, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s9
  %t148 = load i64, ptr %l11, !tbaa !24
  store i64 %t148, ptr %l64, !tbaa !24
  %t149 = load ptr, ptr %l10, !tbaa !29
  %t151 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t149)
  store i64 %t151, ptr %l66
  br label %bb21
bb21:
  %t152 = load i64, ptr %l64, !tbaa !24
  %t153 = load i64, ptr %l66, !tbaa !24
  %t154 = icmp slt i64 %t152, %t153
  %t156 = xor i1 %t154, true
  br i1 %t156, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s9)
  br label %bb31
bb23:
  br label %bb24
bb24:
  %t158 = load ptr, ptr %l10, !tbaa !29
  %t159 = load i64, ptr %l11, !tbaa !24
  %t162 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t158, i64 %t159)
  store i64 %t162, ptr %l71
  br label %bb25
bb25:
  %t163 = load i64, ptr %l71, !tbaa !24
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/emit:Emitter", ptr %t164, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t170 = trunc i64 %t163 to i32
  %t174 = call { i64, [2 x i64] } @compiler_2flower_2ecompiler_2flower_3aLowerer_2eCodeOf(ptr %v0, ptr %t167, i32 %t170)
  store { i64, [2 x i64] } %t174, ptr %l77
  br label %bb26
bb26:
  %t175 = load { i64, [2 x i64] }, ptr %l77
  store { i64, [2 x i64] } %t175, ptr %l13
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load { i64, [2 x i64] }, ptr %l13
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewant(ptr %v0, ptr %t176, { i64, [2 x i64] } %t177)
  br label %bb27
bb27:
  store ptr %l4, ptr %l80, !tbaa !29
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load { i64, [2 x i64] }, ptr %l13
  %t184 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s9, ptr %t180, { i64, [2 x i64] } %t181)
  store { i64, ptr } %t184, ptr %l83
  br label %bb28
bb28:
  %t185 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t186 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t187 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t187, 1
  %t189 = extractvalue { i64, ptr } %t187, 0
  %t190 = add i64 %t186, %t189
  %t191 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t190)
  call void @olang_textcopy(ptr %t191, ptr %t185, i64 %t186)
  %t192 = getelementptr i8, ptr %t191, i64 %t186
  call void @olang_textcopy(ptr %t192, ptr %t188, i64 %t189)
  %t193 = insertvalue { i64, ptr } undef, i64 %t190, 0
  %t194 = insertvalue { i64, ptr } %t193, ptr %t191, 1
  %t196 = extractvalue { i64, ptr } %t194, 0
  %t197 = extractvalue { i64, ptr } %t194, 1
  %t198 = mul i64 %t196, 1
  %t199 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t198)
  call void @llvm.memcpy.p0.p0.i64(ptr %t199, ptr %t197, i64 %t198, i1 false)
  %t200 = insertvalue { i64, ptr } undef, i64 %t196, 0
  %t201 = insertvalue { i64, ptr } %t200, ptr %t199, 1
  %t202 = load ptr, ptr %l80, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s9, ptr %t202, { i64, ptr } %t201)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s9)
  br label %bb30
bb30:
  %t204 = load i64, ptr %l11, !tbaa !24
  %t206 = add i64 %t204, 1
  store i64 %t206, ptr %l11, !tbaa !24
  br label %bb20
bb31:
  %t208 = load ptr, ptr %l3, !tbaa !29
  %t210 = getelementptr %"compiler/generic:AnyTable", ptr %t208, i32 0, i32 5
  %t212 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t210)
  store i64 %t212, ptr %l90
  br label %bb32
bb32:
  %t213 = load i64, ptr @G_2ecompiler_2ftypes_2eAnySlotBase, !tbaa !24
  %t214 = load i64, ptr %l90, !tbaa !24
  %t216 = add i64 %t214, %t213
  %t218 = load ptr, ptr %l0, !tbaa !29
  store ptr %t218, ptr %l93, !tbaa !29
  %t219 = load ptr, ptr %lp2
  %t220 = load { i64, ptr }, ptr %t219, !tbaa !27
  store { i64, ptr } %t220, ptr %l94, !tbaa !27
  %t221 = load i64, ptr @G_2ecompiler_2femit_2eHomeShared, !tbaa !24
  store i64 %t221, ptr %l95, !tbaa !24
  %t222 = load ptr, ptr %lp2
  %t223 = load { i64, ptr }, ptr %t222, !tbaa !27
  store { i64, ptr } %t223, ptr %l96, !tbaa !27
  store i64 %t216, ptr %l97, !tbaa !24
  %t226 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l4)
  store { i64, ptr } %t226, ptr %l99
  br label %bb33
bb33:
  %t227 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t228 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t229 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t230 = extractvalue { i64, ptr } %t229, 1
  %t231 = extractvalue { i64, ptr } %t229, 0
  %t232 = add i64 %t228, %t231
  %t233 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t234 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t235 = add i64 %t232, %t234
  %t236 = load i64, ptr %l97, !tbaa !24
  %t237 = call i64 @__olang_fmt_i64(ptr null, i64 %t236)
  %t238 = add i64 %t235, %t237
  %t239 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t240 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t241 = add i64 %t238, %t240
  %t242 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t243 = extractvalue { i64, ptr } %t242, 1
  %t244 = extractvalue { i64, ptr } %t242, 0
  %t245 = add i64 %t241, %t244
  %t246 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t247 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t248 = add i64 %t245, %t247
  %t249 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t248)
  call void @olang_textcopy(ptr %t249, ptr %t227, i64 %t228)
  %t250 = getelementptr i8, ptr %t249, i64 %t228
  call void @olang_textcopy(ptr %t250, ptr %t230, i64 %t231)
  %t251 = getelementptr i8, ptr %t250, i64 %t231
  call void @olang_textcopy(ptr %t251, ptr %t233, i64 %t234)
  %t252 = getelementptr i8, ptr %t251, i64 %t234
  %t253 = call i64 @__olang_fmt_i64(ptr %t252, i64 %t236)
  %t254 = getelementptr i8, ptr %t252, i64 %t237
  call void @olang_textcopy(ptr %t254, ptr %t239, i64 %t240)
  %t255 = getelementptr i8, ptr %t254, i64 %t240
  call void @olang_textcopy(ptr %t255, ptr %t243, i64 %t244)
  %t256 = getelementptr i8, ptr %t255, i64 %t244
  call void @olang_textcopy(ptr %t256, ptr %t246, i64 %t247)
  %t257 = insertvalue { i64, ptr } undef, i64 %t248, 0
  %t258 = insertvalue { i64, ptr } %t257, ptr %t249, 1
  %t260 = extractvalue { i64, ptr } %t258, 0
  %t261 = extractvalue { i64, ptr } %t258, 1
  %t262 = mul i64 %t260, 1
  %t263 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t262)
  call void @llvm.memcpy.p0.p0.i64(ptr %t263, ptr %t261, i64 %t262, i1 false)
  %t264 = insertvalue { i64, ptr } undef, i64 %t260, 0
  %t265 = insertvalue { i64, ptr } %t264, ptr %t263, 1
  %t266 = load ptr, ptr %l93, !tbaa !29
  %t267 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t268 = load i64, ptr %l95, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %v1, ptr %s0, ptr %s0, ptr %t266, { i64, ptr } %t267, i64 %t268, { i64, ptr } %t265, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d14, i32 0, i32 1) })
  br label %bb34
bb34:
  %t270 = load ptr, ptr %lp2
  %t271 = load { i64, ptr }, ptr %t270, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t271, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ebakedText(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %a2) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca %"std/prelude/text:StringBuilder"
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca %"std/prelude/text:StringBuilder"
  %l35 = alloca i64
  %l39 = alloca i64
  %l42 = alloca i64
  %l63 = alloca ptr
  %l66 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l81 = alloca %"std/prelude/text:StringBuilder"
  %l82 = alloca %"std/prelude/text:StringBuilder"
  %l85 = alloca i64
  %l90 = alloca i64
  %l93 = alloca i64
  %l111 = alloca i64
  %l114 = alloca i64
  %l116 = alloca i64
  %l120 = alloca i64
  %l123 = alloca i64
  %l128 = alloca i64
  %l149 = alloca i64
  %l152 = alloca i64
  %l170 = alloca ptr
  %l174 = alloca i8
  %l175 = alloca { i64, ptr }
  %l180 = alloca i64
  %l183 = alloca i64
  %l186 = alloca i64
  %l193 = alloca i64
  %l195 = alloca { i64, ptr }
  %l198 = alloca { i64, ptr }
  %l202 = alloca i64
  %l207 = alloca i64
  %l209 = alloca ptr
  %l213 = alloca i64
  %l217 = alloca i32
  %l219 = alloca { i64, ptr }
  %l223 = alloca i64
  %l225 = alloca { i64, ptr }
  %l227 = alloca { i64, ptr }
  %l231 = alloca i64
  %l234 = alloca i64
  %l236 = alloca i64
  %l237 = alloca { i64, ptr }
  %l244 = alloca i64
  %l250 = alloca ptr
  %l251 = alloca { i64, ptr }
  %l255 = alloca i64
  %l261 = alloca i64
  %l265 = alloca ptr
  %l266 = alloca { i64, ptr }
  %l267 = alloca { i64, ptr }
  %l269 = alloca { i64, ptr }
  %l271 = alloca { i64, ptr }
  %l279 = alloca { i64, ptr }
  %l280 = alloca { i64, ptr }
  %l281 = alloca i64
  %l282 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l32
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l32
  store %"std/prelude/text:StringBuilder" %t2, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t5 = getelementptr %"compiler/eval:Image", ptr %t3, i32 0, i32 0
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2eLen_3ccompiler_2feval_3aBlob_3e(ptr %v2, ptr %t5)
  store i64 %t7, ptr %l35
  br label %bb2
bb2:
  %t8 = load i64, ptr %l35, !tbaa !24
  store i64 %t8, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t9 = load i64, ptr %l5, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load i64, ptr %l6, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb8
bb5:
  %t19 = load i64, ptr %l5, !tbaa !24
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l6, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l6, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l42, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb7
bb7:
  %t35 = load i64, ptr %l42, !tbaa !24
  store i64 %t35, ptr %l39, !tbaa !24
  br label %bb8
bb8:
  %t36 = load i64, ptr %l39, !tbaa !24
  store i64 %t36, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load i64, ptr %l8, !tbaa !24
  %t38 = load i64, ptr %l7, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb117
bb11:
  br label %bb12
bb12:
  %t45 = load i64, ptr %l4, !tbaa !24
  %t46 = load i64, ptr %l8, !tbaa !24
  %t47 = load i64, ptr %l6, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l9, !tbaa !24
  %t55 = load ptr, ptr %l2, !tbaa !29
  %t57 = getelementptr %"compiler/eval:Image", ptr %t55, i32 0, i32 0
  %t58 = load i64, ptr %l9, !tbaa !24
  %t61 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2eRef_3ccompiler_2feval_3aBlob_3e(ptr %v2, ptr %v2, ptr %t57, i64 %t58)
  store ptr %t61, ptr %l63
  br label %bb13
bb13:
  %t62 = load ptr, ptr %l63, !tbaa !29
  store ptr %t62, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  %t63 = load i64, ptr %l9, !tbaa !24
  %t65 = icmp eq i64 %t63, 0
  br i1 %t65, label %bb14, label %bb15
bb14:
  %t67 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t68 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t69 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t71 = extractvalue { i64, ptr } %t67, 1
  %t72 = extractvalue { i64, ptr } %t67, 0
  %t73 = add i64 %t69, %t72
  %t74 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t73)
  call void @olang_textcopy(ptr %t74, ptr %t68, i64 %t69)
  %t75 = getelementptr i8, ptr %t74, i64 %t69
  call void @olang_textcopy(ptr %t75, ptr %t71, i64 %t72)
  %t76 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t74, 1
  store { i64, ptr } %t77, ptr %l66, !tbaa !27
  br label %bb16
bb15:
  %t79 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t80 = load i64, ptr %l9, !tbaa !24
  %t81 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t82 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t84 = extractvalue { i64, ptr } %t79, 1
  %t85 = extractvalue { i64, ptr } %t79, 0
  %t86 = add i64 %t82, %t85
  %t87 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t88 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t89 = add i64 %t86, %t88
  %t91 = call i64 @__olang_fmt_i64(ptr null, i64 %t80)
  %t92 = add i64 %t89, %t91
  %t93 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t92)
  call void @olang_textcopy(ptr %t93, ptr %t81, i64 %t82)
  %t94 = getelementptr i8, ptr %t93, i64 %t82
  call void @olang_textcopy(ptr %t94, ptr %t84, i64 %t85)
  %t95 = getelementptr i8, ptr %t94, i64 %t85
  call void @olang_textcopy(ptr %t95, ptr %t87, i64 %t88)
  %t96 = getelementptr i8, ptr %t95, i64 %t88
  %t97 = call i64 @__olang_fmt_i64(ptr %t96, i64 %t80)
  %t98 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t93, 1
  store { i64, ptr } %t99, ptr %l66, !tbaa !27
  br label %bb16
bb16:
  %t101 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t101, ptr %l12, !tbaa !27
  %t102 = load i64, ptr %l9, !tbaa !24
  %t104 = icmp eq i64 %t102, 0
  br i1 %t104, label %bb17, label %bb18
bb17:
  %t106 = load ptr, ptr %l2, !tbaa !29
  %t108 = getelementptr %"compiler/eval:Image", ptr %t106, i32 0, i32 2
  %t109 = load i1, ptr %t108, !tbaa !21
  br i1 %t109, label %bb19, label %bb20
bb18:
  %t111 = load ptr, ptr %l10, !tbaa !29
  %t113 = getelementptr %"compiler/eval:Blob", ptr %t111, i32 0, i32 2
  %t114 = load i1, ptr %t113, !tbaa !21
  br i1 %t114, label %bb22, label %bb23
bb19:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l77, !tbaa !27
  br label %bb21
bb20:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l77, !tbaa !27
  br label %bb21
bb21:
  %t116 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t116, ptr %l74, !tbaa !27
  br label %bb25
bb22:
  store { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l80, !tbaa !27
  br label %bb24
bb23:
  store { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %l80, !tbaa !27
  br label %bb24
bb24:
  %t117 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t117, ptr %l74, !tbaa !27
  br label %bb25
bb25:
  %t118 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t118, ptr %l13, !tbaa !27
  %t119 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s2)
  store %"std/prelude/text:StringBuilder" %t119, ptr %l81
  br label %bb26
bb26:
  %t120 = load %"std/prelude/text:StringBuilder", ptr %l81
  store %"std/prelude/text:StringBuilder" %t120, ptr %l14
  %t121 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s2)
  store %"std/prelude/text:StringBuilder" %t121, ptr %l82
  br label %bb27
bb27:
  %t122 = load %"std/prelude/text:StringBuilder", ptr %l82
  store %"std/prelude/text:StringBuilder" %t122, ptr %l15
  store i64 0, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  %t123 = load ptr, ptr %l10, !tbaa !29
  %t125 = getelementptr %"compiler/eval:Blob", ptr %t123, i32 0, i32 3
  %t127 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v2, ptr %t125)
  store i64 %t127, ptr %l85
  br label %bb28
bb28:
  %t128 = load i64, ptr %l85, !tbaa !24
  %t129 = add i64 %t128, 1
  store i64 %t129, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t131 = load i64, ptr %l18, !tbaa !24
  %t132 = load i64, ptr %l17, !tbaa !24
  %t135 = icmp sgt i64 %t131, %t132
  br i1 %t135, label %bb29, label %bb30
bb29:
  %t137 = load i64, ptr %l19, !tbaa !24
  %t139 = icmp sgt i64 %t137, 0
  br i1 %t139, label %bb31, label %bb32
bb30:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb34
bb31:
  %t141 = load i64, ptr %l18, !tbaa !24
  %t142 = load i64, ptr %l17, !tbaa !24
  %t145 = sub i64 %t141, %t142
  %t146 = load i64, ptr %l19, !tbaa !24
  %t149 = add i64 %t145, %t146
  %t151 = sub i64 %t149, 1
  %t152 = load i64, ptr %l19, !tbaa !24
  %t155 = sdiv i64 %t151, %t152
  store i64 %t155, ptr %l93, !tbaa !24
  br label %bb33
bb32:
  store i64 0, ptr %l93, !tbaa !24
  br label %bb33
bb33:
  %t157 = load i64, ptr %l93, !tbaa !24
  store i64 %t157, ptr %l90, !tbaa !24
  br label %bb34
bb34:
  %t158 = load i64, ptr %l90, !tbaa !24
  store i64 %t158, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb35
bb35:
  store %olang.scope zeroinitializer, ptr %s6
  %t159 = load i64, ptr %l21, !tbaa !24
  %t160 = load i64, ptr %l20, !tbaa !24
  %t163 = icmp slt i64 %t159, %t160
  %t165 = xor i1 %t163, true
  br i1 %t165, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s6)
  br label %bb112
bb37:
  br label %bb38
bb38:
  %t167 = load i64, ptr %l17, !tbaa !24
  %t168 = load i64, ptr %l21, !tbaa !24
  %t169 = load i64, ptr %l19, !tbaa !24
  %t172 = mul i64 %t168, %t169
  %t175 = add i64 %t167, %t172
  store i64 %t175, ptr %l22, !tbaa !24
  %t177 = load i64, ptr %l22, !tbaa !24
  store i64 %t177, ptr %l111, !tbaa !24
  %t178 = load ptr, ptr %l10, !tbaa !29
  %t180 = getelementptr %"compiler/eval:Blob", ptr %t178, i32 0, i32 3
  %t182 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v2, ptr %t180)
  store i64 %t182, ptr %l114
  br label %bb39
bb39:
  %t183 = load i64, ptr %l111, !tbaa !24
  %t184 = load i64, ptr %l114, !tbaa !24
  %t185 = icmp slt i64 %t183, %t184
  br i1 %t185, label %bb40, label %bb41
bb40:
  %t187 = load ptr, ptr %l10, !tbaa !29
  %t189 = getelementptr %"compiler/eval:Blob", ptr %t187, i32 0, i32 3
  %t190 = load i64, ptr %l22, !tbaa !24
  %t193 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t189, i64 %t190)
  store i64 %t193, ptr %l120
  br label %bb42
bb41:
  %t194 = load ptr, ptr %l10, !tbaa !29
  %t196 = getelementptr %"compiler/eval:Blob", ptr %t194, i32 0, i32 0
  %t198 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eLen_3cU8_3e(ptr %v2, ptr %t196)
  store i64 %t198, ptr %l123
  br label %bb43
bb42:
  %t199 = load i64, ptr %l120, !tbaa !24
  store i64 %t199, ptr %l116, !tbaa !24
  br label %bb44
bb43:
  %t200 = load i64, ptr %l123, !tbaa !24
  store i64 %t200, ptr %l116, !tbaa !24
  br label %bb44
bb44:
  %t201 = load i64, ptr %l116, !tbaa !24
  store i64 %t201, ptr %l23, !tbaa !24
  %t202 = load i64, ptr %l23, !tbaa !24
  %t203 = load i64, ptr %l16, !tbaa !24
  %t206 = icmp sgt i64 %t202, %t203
  br i1 %t206, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s7
  %t209 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s2, ptr %l14)
  store i64 %t209, ptr %l128
  br label %bb47
bb46:
  br label %bb71
bb47:
  %t210 = load i64, ptr %l128, !tbaa !24
  %t211 = icmp sgt i64 %t210, 0
  br i1 %t211, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s8
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s2, ptr %s8, ptr %l14, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d22, i32 0, i32 1) })
  br label %bb50
bb49:
  br label %bb52
bb50:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s2, ptr %s8, ptr %l15, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d23, i32 0, i32 1) })
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s8)
  br label %bb52
bb52:
  %t215 = load i64, ptr %l23, !tbaa !24
  %t216 = load i64, ptr %l16, !tbaa !24
  %t219 = sub i64 %t215, %t216
  %t220 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t221 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t223 = call i64 @__olang_fmt_i64(ptr null, i64 %t219)
  %t224 = add i64 %t221, %t223
  %t225 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t226 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t227 = add i64 %t224, %t226
  %t228 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t227)
  call void @olang_textcopy(ptr %t228, ptr %t220, i64 %t221)
  %t229 = getelementptr i8, ptr %t228, i64 %t221
  %t230 = call i64 @__olang_fmt_i64(ptr %t229, i64 %t219)
  %t231 = getelementptr i8, ptr %t229, i64 %t223
  call void @olang_textcopy(ptr %t231, ptr %t225, i64 %t226)
  %t232 = insertvalue { i64, ptr } undef, i64 %t227, 0
  %t233 = insertvalue { i64, ptr } %t232, ptr %t228, 1
  %t235 = extractvalue { i64, ptr } %t233, 0
  %t236 = extractvalue { i64, ptr } %t233, 1
  %t237 = mul i64 %t235, 1
  %t238 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t237)
  call void @llvm.memcpy.p0.p0.i64(ptr %t238, ptr %t236, i64 %t237, i1 false)
  %t239 = insertvalue { i64, ptr } undef, i64 %t235, 0
  %t240 = insertvalue { i64, ptr } %t239, ptr %t238, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s2, ptr %s7, ptr %l14, { i64, ptr } %t240)
  br label %bb53
bb53:
  %t243 = load i64, ptr %l23, !tbaa !24
  %t244 = load i64, ptr %l16, !tbaa !24
  %t247 = sub i64 %t243, %t244
  %t248 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t249 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t251 = call i64 @__olang_fmt_i64(ptr null, i64 %t247)
  %t252 = add i64 %t249, %t251
  %t253 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t254 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t255 = add i64 %t252, %t254
  %t256 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t255)
  call void @olang_textcopy(ptr %t256, ptr %t248, i64 %t249)
  %t257 = getelementptr i8, ptr %t256, i64 %t249
  %t258 = call i64 @__olang_fmt_i64(ptr %t257, i64 %t247)
  %t259 = getelementptr i8, ptr %t257, i64 %t251
  call void @olang_textcopy(ptr %t259, ptr %t253, i64 %t254)
  %t260 = insertvalue { i64, ptr } undef, i64 %t255, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t256, 1
  %t263 = extractvalue { i64, ptr } %t261, 0
  %t264 = extractvalue { i64, ptr } %t261, 1
  %t265 = mul i64 %t263, 1
  %t266 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t265)
  call void @llvm.memcpy.p0.p0.i64(ptr %t266, ptr %t264, i64 %t265, i1 false)
  %t267 = insertvalue { i64, ptr } undef, i64 %t263, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t266, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s2, ptr %s7, ptr %l15, { i64, ptr } %t268)
  br label %bb54
bb54:
  %t271 = load i64, ptr %l16, !tbaa !24
  store i64 %t271, ptr %l24, !tbaa !24
  %t273 = load i64, ptr %l23, !tbaa !24
  store i64 %t273, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t275 = load i64, ptr %l25, !tbaa !24
  %t276 = load i64, ptr %l24, !tbaa !24
  %t279 = icmp sgt i64 %t275, %t276
  br i1 %t279, label %bb55, label %bb56
bb55:
  %t281 = load i64, ptr %l26, !tbaa !24
  %t283 = icmp sgt i64 %t281, 0
  br i1 %t283, label %bb57, label %bb58
bb56:
  store i64 0, ptr %l149, !tbaa !24
  br label %bb60
bb57:
  %t285 = load i64, ptr %l25, !tbaa !24
  %t286 = load i64, ptr %l24, !tbaa !24
  %t289 = sub i64 %t285, %t286
  %t290 = load i64, ptr %l26, !tbaa !24
  %t293 = add i64 %t289, %t290
  %t295 = sub i64 %t293, 1
  %t296 = load i64, ptr %l26, !tbaa !24
  %t299 = sdiv i64 %t295, %t296
  store i64 %t299, ptr %l152, !tbaa !24
  br label %bb59
bb58:
  store i64 0, ptr %l152, !tbaa !24
  br label %bb59
bb59:
  %t301 = load i64, ptr %l152, !tbaa !24
  store i64 %t301, ptr %l149, !tbaa !24
  br label %bb60
bb60:
  %t302 = load i64, ptr %l149, !tbaa !24
  store i64 %t302, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb61
bb61:
  store %olang.scope zeroinitializer, ptr %s12
  %t303 = load i64, ptr %l28, !tbaa !24
  %t304 = load i64, ptr %l27, !tbaa !24
  %t307 = icmp slt i64 %t303, %t304
  %t309 = xor i1 %t307, true
  br i1 %t309, label %bb62, label %bb63
bb62:
  call void @__olang_scope_close(ptr %s12)
  br label %bb69
bb63:
  br label %bb64
bb64:
  %t311 = load i64, ptr %l24, !tbaa !24
  %t312 = load i64, ptr %l28, !tbaa !24
  %t313 = load i64, ptr %l26, !tbaa !24
  %t316 = mul i64 %t312, %t313
  %t319 = add i64 %t311, %t316
  store ptr %l15, ptr %l170, !tbaa !29
  %t321 = load ptr, ptr %l10, !tbaa !29
  %t323 = getelementptr %"compiler/eval:Blob", ptr %t321, i32 0, i32 0
  %t327 = call i8 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eAt_3cU8_3e(ptr %v2, ptr %t323, i64 %t319)
  store i8 %t327, ptr %l174
  br label %bb65
bb65:
  %t328 = load i8, ptr %l174, !tbaa !22
  %t329 = call { i64, ptr } @compiler_2femit_2ehexByte(ptr %s12, i8 %t328)
  store { i64, ptr } %t329, ptr %l175
  br label %bb66
bb66:
  %t330 = load { i64, ptr }, ptr %l175, !tbaa !27
  %t331 = extractvalue { i64, ptr } %t330, 0
  %t332 = extractvalue { i64, ptr } %t330, 1
  %t333 = mul i64 %t331, 1
  %t334 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t333)
  call void @llvm.memcpy.p0.p0.i64(ptr %t334, ptr %t332, i64 %t333, i1 false)
  %t335 = insertvalue { i64, ptr } undef, i64 %t331, 0
  %t336 = insertvalue { i64, ptr } %t335, ptr %t334, 1
  %t337 = load ptr, ptr %l170, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s2, ptr %s12, ptr %t337, { i64, ptr } %t336)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s12)
  br label %bb68
bb68:
  %t339 = load i64, ptr %l28, !tbaa !24
  %t341 = add i64 %t339, 1
  store i64 %t341, ptr %l28, !tbaa !24
  br label %bb61
bb69:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s2, ptr %s7, ptr %l15, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) })
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s7)
  br label %bb71
bb71:
  %t344 = load i64, ptr %l22, !tbaa !24
  store i64 %t344, ptr %l180, !tbaa !24
  %t345 = load ptr, ptr %l10, !tbaa !29
  %t347 = getelementptr %"compiler/eval:Blob", ptr %t345, i32 0, i32 3
  %t349 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v2, ptr %t347)
  store i64 %t349, ptr %l183
  br label %bb72
bb72:
  %t350 = load i64, ptr %l180, !tbaa !24
  %t351 = load i64, ptr %l183, !tbaa !24
  %t352 = icmp eq i64 %t350, %t351
  br i1 %t352, label %bb73, label %bb74
bb73:
  call void @__olang_scope_close(ptr %s6)
  br label %bb112
bb74:
  br label %bb75
bb75:
  %t355 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s2, ptr %l14)
  store i64 %t355, ptr %l186
  br label %bb76
bb76:
  %t356 = load i64, ptr %l186, !tbaa !24
  %t357 = icmp sgt i64 %t356, 0
  br i1 %t357, label %bb77, label %bb78
bb77:
  store %olang.scope zeroinitializer, ptr %s15
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s2, ptr %s15, ptr %l14, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d29, i32 0, i32 1) })
  br label %bb79
bb78:
  br label %bb81
bb79:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s2, ptr %s15, ptr %l15, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d30, i32 0, i32 1) })
  br label %bb80
bb80:
  call void @__olang_scope_close(ptr %s15)
  br label %bb81
bb81:
  %t361 = load ptr, ptr %l10, !tbaa !29
  %t363 = getelementptr %"compiler/eval:Blob", ptr %t361, i32 0, i32 4
  %t364 = load i64, ptr %l22, !tbaa !24
  %t367 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t363, i64 %t364)
  store i64 %t367, ptr %l193
  br label %bb82
bb82:
  %t368 = load i64, ptr %l193, !tbaa !24
  %t369 = icmp eq i64 %t368, 0
  br i1 %t369, label %bb83, label %bb84
bb83:
  %t371 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t372 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t373 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t375 = extractvalue { i64, ptr } %t371, 1
  %t376 = extractvalue { i64, ptr } %t371, 0
  %t377 = add i64 %t373, %t376
  %t378 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t377)
  call void @olang_textcopy(ptr %t378, ptr %t372, i64 %t373)
  %t379 = getelementptr i8, ptr %t378, i64 %t373
  call void @olang_textcopy(ptr %t379, ptr %t375, i64 %t376)
  %t380 = insertvalue { i64, ptr } undef, i64 %t377, 0
  %t381 = insertvalue { i64, ptr } %t380, ptr %t378, 1
  store { i64, ptr } %t381, ptr %l195, !tbaa !27
  br label %bb86
bb84:
  %t383 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t383, ptr %l198, !tbaa !27
  %t384 = load ptr, ptr %l10, !tbaa !29
  %t386 = getelementptr %"compiler/eval:Blob", ptr %t384, i32 0, i32 4
  %t387 = load i64, ptr %l22, !tbaa !24
  %t390 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t386, i64 %t387)
  store i64 %t390, ptr %l202
  br label %bb85
bb85:
  %t391 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t392 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t393 = load { i64, ptr }, ptr %l198, !tbaa !27
  %t394 = extractvalue { i64, ptr } %t393, 1
  %t395 = extractvalue { i64, ptr } %t393, 0
  %t396 = add i64 %t392, %t395
  %t397 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t398 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t399 = add i64 %t396, %t398
  %t400 = load i64, ptr %l202, !tbaa !24
  %t401 = call i64 @__olang_fmt_i64(ptr null, i64 %t400)
  %t402 = add i64 %t399, %t401
  %t403 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t402)
  call void @olang_textcopy(ptr %t403, ptr %t391, i64 %t392)
  %t404 = getelementptr i8, ptr %t403, i64 %t392
  call void @olang_textcopy(ptr %t404, ptr %t394, i64 %t395)
  %t405 = getelementptr i8, ptr %t404, i64 %t395
  call void @olang_textcopy(ptr %t405, ptr %t397, i64 %t398)
  %t406 = getelementptr i8, ptr %t405, i64 %t398
  %t407 = call i64 @__olang_fmt_i64(ptr %t406, i64 %t400)
  %t408 = insertvalue { i64, ptr } undef, i64 %t402, 0
  %t409 = insertvalue { i64, ptr } %t408, ptr %t403, 1
  store { i64, ptr } %t409, ptr %l195, !tbaa !27
  br label %bb86
bb86:
  %t411 = load { i64, ptr }, ptr %l195, !tbaa !27
  store { i64, ptr } %t411, ptr %l30, !tbaa !27
  %t412 = load ptr, ptr %l10, !tbaa !29
  %t414 = getelementptr %"compiler/eval:Blob", ptr %t412, i32 0, i32 4
  %t415 = load i64, ptr %l22, !tbaa !24
  %t418 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t414, i64 %t415)
  store i64 %t418, ptr %l207
  br label %bb87
bb87:
  %t419 = load i64, ptr %l207, !tbaa !24
  %t420 = icmp slt i64 %t419, 0
  br i1 %t420, label %bb88, label %bb89
bb88:
  store %olang.scope zeroinitializer, ptr %s18
  store ptr %a0, ptr %l209, !tbaa !29
  %t423 = load ptr, ptr %l10, !tbaa !29
  %t425 = getelementptr %"compiler/eval:Blob", ptr %t423, i32 0, i32 7
  %t426 = load i64, ptr %l11, !tbaa !24
  %t429 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t425, i64 %t426)
  store i64 %t429, ptr %l213
  br label %bb90
bb89:
  br label %bb101
bb90:
  %t430 = load ptr, ptr %l10, !tbaa !29
  %t432 = getelementptr %"compiler/eval:Blob", ptr %t430, i32 0, i32 8
  %t433 = load i64, ptr %l11, !tbaa !24
  %t436 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v2, ptr %t432, i64 %t433)
  store i32 %t436, ptr %l217
  br label %bb91
bb91:
  %t437 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t438 = load ptr, ptr %l209, !tbaa !29
  %t439 = load i64, ptr %l213, !tbaa !24
  %t440 = load i32, ptr %l217, !tbaa !23
  %t442 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobal(ptr %v0, ptr %s18, ptr %t438, i64 %t439, i32 %t440, i32 %t437)
  store { i64, ptr } %t442, ptr %l219
  br label %bb92
bb92:
  %t443 = load { i64, ptr }, ptr %l219, !tbaa !27
  store { i64, ptr } %t443, ptr %l31, !tbaa !27
  %t444 = load ptr, ptr %l10, !tbaa !29
  %t446 = getelementptr %"compiler/eval:Blob", ptr %t444, i32 0, i32 9
  %t447 = load i64, ptr %l11, !tbaa !24
  %t450 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t446, i64 %t447)
  store i64 %t450, ptr %l223
  br label %bb93
bb93:
  %t451 = load i64, ptr %l223, !tbaa !24
  %t452 = icmp eq i64 %t451, 0
  br i1 %t452, label %bb94, label %bb95
bb94:
  %t454 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t454, ptr %l225, !tbaa !27
  br label %bb97
bb95:
  %t456 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t456, ptr %l227, !tbaa !27
  %t457 = load ptr, ptr %l10, !tbaa !29
  %t459 = getelementptr %"compiler/eval:Blob", ptr %t457, i32 0, i32 9
  %t460 = load i64, ptr %l11, !tbaa !24
  %t463 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t459, i64 %t460)
  store i64 %t463, ptr %l231
  br label %bb96
bb96:
  %t464 = load { i64, ptr }, ptr %l227, !tbaa !27
  %t465 = extractvalue { i64, ptr } %t464, 1
  %t466 = extractvalue { i64, ptr } %t464, 0
  %t467 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t468 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t469 = add i64 %t466, %t468
  %t470 = load i64, ptr %l231, !tbaa !24
  %t471 = call i64 @__olang_fmt_i64(ptr null, i64 %t470)
  %t472 = add i64 %t469, %t471
  %t473 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t472)
  call void @olang_textcopy(ptr %t473, ptr %t465, i64 %t466)
  %t474 = getelementptr i8, ptr %t473, i64 %t466
  call void @olang_textcopy(ptr %t474, ptr %t467, i64 %t468)
  %t475 = getelementptr i8, ptr %t474, i64 %t468
  %t476 = call i64 @__olang_fmt_i64(ptr %t475, i64 %t470)
  %t477 = insertvalue { i64, ptr } undef, i64 %t472, 0
  %t478 = insertvalue { i64, ptr } %t477, ptr %t473, 1
  store { i64, ptr } %t478, ptr %l225, !tbaa !27
  br label %bb97
bb97:
  %t480 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t481 = extractvalue { i64, ptr } %t480, 0
  %t482 = load { i64, ptr }, ptr %l225, !tbaa !27
  %t483 = extractvalue { i64, ptr } %t482, 0
  store i64 %t483, ptr %l234, !tbaa !24
  %t485 = load i64, ptr %l234, !tbaa !24
  %t486 = icmp eq i64 %t481, %t485
  br i1 %t486, label %bb98, label %bb99
bb98:
  %t488 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t489 = load ptr, ptr %t488, !tbaa !27
  %t490 = getelementptr { i64, ptr }, ptr %l225, i32 0, i32 1
  %t491 = load ptr, ptr %t490, !tbaa !27
  %t492 = load i64, ptr %l234, !tbaa !24
  %t493 = mul i64 %t492, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t489, ptr %t491, i64 %t493, i1 false)
  br label %bb100
bb99:
  %t494 = load { i64, ptr }, ptr %l225, !tbaa !27
  %t495 = extractvalue { i64, ptr } %t494, 0
  store i64 %t495, ptr %l236, !tbaa !24
  %t496 = load i64, ptr %l236, !tbaa !24
  %t497 = mul i64 %t496, 1
  %t498 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t497)
  %t499 = insertvalue { i64, ptr } undef, i64 %t496, 0
  %t500 = insertvalue { i64, ptr } %t499, ptr %t498, 1
  store { i64, ptr } %t500, ptr %l237, !tbaa !27
  %t501 = getelementptr { i64, ptr }, ptr %l237, i32 0, i32 1
  %t502 = load ptr, ptr %t501, !tbaa !27
  %t503 = getelementptr { i64, ptr }, ptr %l225, i32 0, i32 1
  %t504 = load ptr, ptr %t503, !tbaa !27
  %t505 = load i64, ptr %l236, !tbaa !24
  %t506 = mul i64 %t505, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t502, ptr %t504, i64 %t506, i1 false)
  %t507 = load { i64, ptr }, ptr %l237, !tbaa !27
  store { i64, ptr } %t507, ptr %l30, !tbaa !27
  br label %bb100
bb100:
  %t508 = load i64, ptr %l11, !tbaa !24
  %t510 = add i64 %t508, 1
  store i64 %t510, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s18)
  br label %bb101
bb101:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s2, ptr %s6, ptr %l14, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d35, i32 0, i32 1) })
  br label %bb102
bb102:
  %t513 = load ptr, ptr %l10, !tbaa !29
  %t515 = getelementptr %"compiler/eval:Blob", ptr %t513, i32 0, i32 5
  %t516 = load i64, ptr %l22, !tbaa !24
  %t519 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t515, i64 %t516)
  store i64 %t519, ptr %l244
  br label %bb103
bb103:
  %t520 = load i64, ptr %l244, !tbaa !24
  %t521 = icmp eq i64 %t520, 0
  br i1 %t521, label %bb104, label %bb105
bb104:
  store %olang.scope zeroinitializer, ptr %s20
  %t523 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t524 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t525 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t527 = extractvalue { i64, ptr } %t523, 1
  %t528 = extractvalue { i64, ptr } %t523, 0
  %t529 = add i64 %t525, %t528
  %t530 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t529)
  call void @olang_textcopy(ptr %t530, ptr %t524, i64 %t525)
  %t531 = getelementptr i8, ptr %t530, i64 %t525
  call void @olang_textcopy(ptr %t531, ptr %t527, i64 %t528)
  %t532 = insertvalue { i64, ptr } undef, i64 %t529, 0
  %t533 = insertvalue { i64, ptr } %t532, ptr %t530, 1
  %t535 = extractvalue { i64, ptr } %t533, 0
  %t536 = extractvalue { i64, ptr } %t533, 1
  %t537 = mul i64 %t535, 1
  %t538 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t537)
  call void @llvm.memcpy.p0.p0.i64(ptr %t538, ptr %t536, i64 %t537, i1 false)
  %t539 = insertvalue { i64, ptr } undef, i64 %t535, 0
  %t540 = insertvalue { i64, ptr } %t539, ptr %t538, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s2, ptr %s20, ptr %l15, { i64, ptr } %t540)
  br label %bb106
bb105:
  store %olang.scope zeroinitializer, ptr %s22
  store ptr %l15, ptr %l250, !tbaa !29
  %t543 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t543, ptr %l251, !tbaa !27
  %t544 = load ptr, ptr %l10, !tbaa !29
  %t546 = getelementptr %"compiler/eval:Blob", ptr %t544, i32 0, i32 5
  %t547 = load i64, ptr %l22, !tbaa !24
  %t550 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t546, i64 %t547)
  store i64 %t550, ptr %l255
  br label %bb107
bb106:
  call void @__olang_scope_close(ptr %s20)
  br label %bb109
bb107:
  %t551 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t552 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t553 = load { i64, ptr }, ptr %l251, !tbaa !27
  %t554 = extractvalue { i64, ptr } %t553, 1
  %t555 = extractvalue { i64, ptr } %t553, 0
  %t556 = add i64 %t552, %t555
  %t557 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t558 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t559 = add i64 %t556, %t558
  %t560 = load i64, ptr %l255, !tbaa !24
  %t561 = call i64 @__olang_fmt_i64(ptr null, i64 %t560)
  %t562 = add i64 %t559, %t561
  %t563 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t564 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t565 = add i64 %t562, %t564
  %t566 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t565)
  call void @olang_textcopy(ptr %t566, ptr %t551, i64 %t552)
  %t567 = getelementptr i8, ptr %t566, i64 %t552
  call void @olang_textcopy(ptr %t567, ptr %t554, i64 %t555)
  %t568 = getelementptr i8, ptr %t567, i64 %t555
  call void @olang_textcopy(ptr %t568, ptr %t557, i64 %t558)
  %t569 = getelementptr i8, ptr %t568, i64 %t558
  %t570 = call i64 @__olang_fmt_i64(ptr %t569, i64 %t560)
  %t571 = getelementptr i8, ptr %t569, i64 %t561
  call void @olang_textcopy(ptr %t571, ptr %t563, i64 %t564)
  %t572 = insertvalue { i64, ptr } undef, i64 %t565, 0
  %t573 = insertvalue { i64, ptr } %t572, ptr %t566, 1
  %t575 = extractvalue { i64, ptr } %t573, 0
  %t576 = extractvalue { i64, ptr } %t573, 1
  %t577 = mul i64 %t575, 1
  %t578 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t577)
  call void @llvm.memcpy.p0.p0.i64(ptr %t578, ptr %t576, i64 %t577, i1 false)
  %t579 = insertvalue { i64, ptr } undef, i64 %t575, 0
  %t580 = insertvalue { i64, ptr } %t579, ptr %t578, 1
  %t581 = load ptr, ptr %l250, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s2, ptr %s22, ptr %t581, { i64, ptr } %t580)
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s22)
  br label %bb109
bb109:
  %t583 = load ptr, ptr %l10, !tbaa !29
  %t585 = getelementptr %"compiler/eval:Blob", ptr %t583, i32 0, i32 3
  %t586 = load i64, ptr %l22, !tbaa !24
  %t589 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t585, i64 %t586)
  store i64 %t589, ptr %l261
  br label %bb110
bb110:
  %t590 = load i64, ptr %l261, !tbaa !24
  %t591 = add i64 %t590, 8
  store i64 %t591, ptr %l16, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb111
bb111:
  %t593 = load i64, ptr %l21, !tbaa !24
  %t595 = add i64 %t593, 1
  store i64 %t595, ptr %l21, !tbaa !24
  br label %bb35
bb112:
  store ptr %l3, ptr %l265, !tbaa !29
  %t597 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t597, ptr %l266, !tbaa !27
  %t598 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t598, ptr %l267, !tbaa !27
  %t600 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s2, ptr %s2, ptr %l14)
  store { i64, ptr } %t600, ptr %l269
  br label %bb113
bb113:
  %t602 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s2, ptr %s2, ptr %l15)
  store { i64, ptr } %t602, ptr %l271
  br label %bb114
bb114:
  %t603 = load ptr, ptr %l10, !tbaa !29
  %t605 = getelementptr %"compiler/eval:Blob", ptr %t603, i32 0, i32 1
  %t606 = load i64, ptr %t605, !tbaa !24
  %t607 = load { i64, ptr }, ptr %l266, !tbaa !27
  %t608 = extractvalue { i64, ptr } %t607, 1
  %t609 = extractvalue { i64, ptr } %t607, 0
  %t610 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t611 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  %t612 = add i64 %t609, %t611
  %t613 = load { i64, ptr }, ptr %l267, !tbaa !27
  %t614 = extractvalue { i64, ptr } %t613, 1
  %t615 = extractvalue { i64, ptr } %t613, 0
  %t616 = add i64 %t612, %t615
  %t617 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t618 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t619 = add i64 %t616, %t618
  %t620 = load { i64, ptr }, ptr %l269, !tbaa !27
  %t621 = extractvalue { i64, ptr } %t620, 1
  %t622 = extractvalue { i64, ptr } %t620, 0
  %t623 = add i64 %t619, %t622
  %t624 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t625 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t626 = add i64 %t623, %t625
  %t627 = load { i64, ptr }, ptr %l271, !tbaa !27
  %t628 = extractvalue { i64, ptr } %t627, 1
  %t629 = extractvalue { i64, ptr } %t627, 0
  %t630 = add i64 %t626, %t629
  %t631 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t632 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t633 = add i64 %t630, %t632
  %t635 = call i64 @__olang_fmt_i64(ptr null, i64 %t606)
  %t636 = add i64 %t633, %t635
  %t637 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t638 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t639 = add i64 %t636, %t638
  %t640 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t639)
  call void @olang_textcopy(ptr %t640, ptr %t608, i64 %t609)
  %t641 = getelementptr i8, ptr %t640, i64 %t609
  call void @olang_textcopy(ptr %t641, ptr %t610, i64 %t611)
  %t642 = getelementptr i8, ptr %t641, i64 %t611
  call void @olang_textcopy(ptr %t642, ptr %t614, i64 %t615)
  %t643 = getelementptr i8, ptr %t642, i64 %t615
  call void @olang_textcopy(ptr %t643, ptr %t617, i64 %t618)
  %t644 = getelementptr i8, ptr %t643, i64 %t618
  call void @olang_textcopy(ptr %t644, ptr %t621, i64 %t622)
  %t645 = getelementptr i8, ptr %t644, i64 %t622
  call void @olang_textcopy(ptr %t645, ptr %t624, i64 %t625)
  %t646 = getelementptr i8, ptr %t645, i64 %t625
  call void @olang_textcopy(ptr %t646, ptr %t628, i64 %t629)
  %t647 = getelementptr i8, ptr %t646, i64 %t629
  call void @olang_textcopy(ptr %t647, ptr %t631, i64 %t632)
  %t648 = getelementptr i8, ptr %t647, i64 %t632
  %t649 = call i64 @__olang_fmt_i64(ptr %t648, i64 %t606)
  %t650 = getelementptr i8, ptr %t648, i64 %t635
  call void @olang_textcopy(ptr %t650, ptr %t637, i64 %t638)
  %t651 = insertvalue { i64, ptr } undef, i64 %t639, 0
  %t652 = insertvalue { i64, ptr } %t651, ptr %t640, 1
  %t654 = extractvalue { i64, ptr } %t652, 0
  %t655 = extractvalue { i64, ptr } %t652, 1
  %t656 = mul i64 %t654, 1
  %t657 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t656)
  call void @llvm.memcpy.p0.p0.i64(ptr %t657, ptr %t655, i64 %t656, i1 false)
  %t658 = insertvalue { i64, ptr } undef, i64 %t654, 0
  %t659 = insertvalue { i64, ptr } %t658, ptr %t657, 1
  %t660 = load ptr, ptr %l265, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t660, { i64, ptr } %t659)
  br label %bb115
bb115:
  call void @__olang_scope_close(ptr %s2)
  br label %bb116
bb116:
  %t662 = load i64, ptr %l8, !tbaa !24
  %t664 = add i64 %t662, 1
  store i64 %t664, ptr %l8, !tbaa !24
  br label %bb9
bb117:
  %t667 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v3, ptr %l3)
  store { i64, ptr } %t667, ptr %l279
  br label %bb118
bb118:
  %t668 = load { i64, ptr }, ptr %l279, !tbaa !27
  store { i64, ptr } %t668, ptr %l280, !tbaa !27
  %t669 = load { i64, ptr }, ptr %l280, !tbaa !27
  %t670 = extractvalue { i64, ptr } %t669, 0
  store i64 %t670, ptr %l281, !tbaa !24
  %t671 = load i64, ptr %l281, !tbaa !24
  %t672 = mul i64 %t671, 1
  %t673 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t672)
  %t674 = insertvalue { i64, ptr } undef, i64 %t671, 0
  %t675 = insertvalue { i64, ptr } %t674, ptr %t673, 1
  store { i64, ptr } %t675, ptr %l282, !tbaa !27
  %t676 = getelementptr { i64, ptr }, ptr %l282, i32 0, i32 1
  %t677 = load ptr, ptr %t676, !tbaa !27
  %t678 = getelementptr { i64, ptr }, ptr %l280, i32 0, i32 1
  %t679 = load ptr, ptr %t678, !tbaa !27
  %t680 = load i64, ptr %l281, !tbaa !24
  %t681 = mul i64 %t680, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t677, ptr %t679, i64 %t681, i1 false)
  %t682 = load { i64, ptr }, ptr %l282, !tbaa !27
  store { i64, ptr } %t682, ptr %l280, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t683 = load { i64, ptr }, ptr %l280, !tbaa !27
  store { i64, ptr } %t683, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecodeFor(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i32
  %lp3 = alloca ptr
  %l4 = alloca i32
  %lp5 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l11 = alloca i32
  %l14 = alloca i1
  %l15 = alloca i1
  %l19 = alloca i64
  %l25 = alloca i64
  %l31 = alloca { i64, ptr }
  %l35 = alloca i1
  %rv = alloca { i64, ptr }
  %t32 = alloca { i64, [4 x i64] }, align 8
  %t35 = alloca { i64, [7 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load { i64, [2 x i64] }, ptr %l1
  %t5 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %v1, ptr %t1, { i64, [2 x i64] } %t2)
  store { i64, ptr } %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t6, ptr %lp3
  %t7 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t8 = load ptr, ptr %lp3
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load { i64, [2 x i64] }, ptr %l1
  %t13 = call i32 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecodeType(ptr %v0, ptr %t9, { i64, [2 x i64] } %t10)
  store i32 %t13, ptr %l11
  br label %bb2
bb2:
  %t14 = load i32, ptr %l11, !tbaa !23
  store i32 %t14, ptr %l4, !tbaa !23
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load { i64, [2 x i64] }, ptr %l1
  %t19 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehasEnv(ptr %v0, ptr %t15, { i64, [2 x i64] } %t16)
  store i1 %t19, ptr %l14
  br label %bb3
bb3:
  %t20 = load i1, ptr %l14, !tbaa !21
  br i1 %t20, label %bb4, label %bb5
bb4:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load { i64, [2 x i64] }, ptr %l1
  %t23 = load i32, ptr %l4, !tbaa !23
  %t27 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2epassedOf(ptr %v0, ptr %t21, { i64, [2 x i64] } %t22, i32 %t23)
  store i64 %t27, ptr %l19
  br label %bb6
bb5:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb8
bb6:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/emit:Emitter", ptr %t28, i32 0, i32 3
  %t31 = load ptr, ptr %t30, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t32
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t32, i32 0, i32 0
  store i64 0, ptr %t33
  %t34 = load { i64, [4 x i64] }, ptr %t32
  store { i64, [7 x i64] } zeroinitializer, ptr %t35
  %t36 = getelementptr { i64, [7 x i64] }, ptr %t35, i32 0, i32 0
  store i64 2, ptr %t36
  %t38 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t34, 0
  %t39 = getelementptr { i64, [7 x i64] }, ptr %t35, i32 0, i32 1
  store { { i64, [4 x i64] } } %t38, ptr %t39
  %t40 = load { i64, [7 x i64] }, ptr %t35
  %t41 = load i32, ptr %l2, !tbaa !23
  %t45 = call i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %t31, { i64, [7 x i64] } %t40, i32 %t41)
  store i64 %t45, ptr %l25
  br label %bb7
bb7:
  %t46 = load i64, ptr %l19, !tbaa !24
  %t47 = load i64, ptr %l25, !tbaa !24
  %t48 = icmp eq i64 %t46, %t47
  store i1 %t48, ptr %l15, !tbaa !21
  br label %bb8
bb8:
  %t50 = load i1, ptr %l15, !tbaa !21
  br i1 %t50, label %bb9, label %bb10
bb9:
  %t51 = load ptr, ptr %lp3
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  store { i64, ptr } %t52, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %lp3
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t57 = load i32, ptr %l2, !tbaa !23
  %t61 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ethunkSym(ptr %v0, ptr %v1, ptr %v1, ptr %t54, { i64, ptr } %t56, i32 %t57)
  store { i64, ptr } %t61, ptr %l31
  br label %bb12
bb12:
  %t62 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t62, ptr %lp5
  %t63 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t64 = load ptr, ptr %lp5
  store { i64, ptr } %t63, ptr %t64, !tbaa !27
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/emit:Emitter", ptr %t65, i32 0, i32 28
  %t68 = load ptr, ptr %lp5
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  %t72 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v1, ptr %t67, { i64, ptr } %t69)
  store i1 %t72, ptr %l35
  br label %bb13
bb13:
  %t73 = load i1, ptr %l35, !tbaa !21
  %t74 = xor i1 %t73, true
  br i1 %t74, label %bb14, label %bb15
bb14:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/emit:Emitter", ptr %t76, i32 0, i32 28
  %t79 = load ptr, ptr %lp5
  %t80 = load { i64, ptr }, ptr %t79, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t80, 1
  %t83 = extractvalue { i64, ptr } %t80, 0
  %t84 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t83)
  call void @olang_textcopy(ptr %t84, ptr %t82, i64 %t83)
  %t85 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = extractvalue { i64, ptr } %t86, 1
  %t90 = mul i64 %t88, 1
  %t91 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t90)
  call void @llvm.memcpy.p0.p0.i64(ptr %t91, ptr %t89, i64 %t90, i1 false)
  %t92 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %v0, ptr %v0, ptr %t78, { i64, ptr } %t93, i1 true)
  br label %bb16
bb15:
  br label %bb19
bb16:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/emit:Emitter", ptr %t96, i32 0, i32 29
  %t99 = load { i64, [2 x i64] }, ptr %l1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %t98, { i64, [2 x i64] } %t99)
  br label %bb17
bb17:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/emit:Emitter", ptr %t102, i32 0, i32 30
  %t105 = load i32, ptr %l2, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t104, i32 %t105)
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t108 = load ptr, ptr %lp5
  %t109 = load { i64, ptr }, ptr %t108, !tbaa !27
  store { i64, ptr } %t109, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecoroDecls(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t1, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d45, i32 0, i32 1) }, { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d46, i32 0, i32 1) })
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t3, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d47, i32 0, i32 1) }, { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d48, i32 0, i32 1) })
  br label %bb2
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t5, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d49, i32 0, i32 1) }, { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d50, i32 0, i32 1) })
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t7, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d51, i32 0, i32 1) }, { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d52, i32 0, i32 1) })
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t9, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d53, i32 0, i32 1) }, { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d54, i32 0, i32 1) })
  br label %bb5
bb5:
  %t11 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t11, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d55, i32 0, i32 1) }, { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d56, i32 0, i32 1) })
  br label %bb6
bb6:
  %t13 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t13, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d57, i32 0, i32 1) }, { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d58, i32 0, i32 1) })
  br label %bb7
bb7:
  %t15 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t15, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d59, i32 0, i32 1) }, { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d60, i32 0, i32 1) })
  br label %bb8
bb8:
  %t17 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t17, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d61, i32 0, i32 1) }, { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d62, i32 0, i32 1) })
  br label %bb9
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t19, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d63, i32 0, i32 1) }, { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d64, i32 0, i32 1) })
  br label %bb10
bb10:
  %t21 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t21, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d65, i32 0, i32 1) }, { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d66, i32 0, i32 1) })
  br label %bb11
bb11:
  %t23 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t23, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d67, i32 0, i32 1) }, { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d68, i32 0, i32 1) })
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgBytes(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l1, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/emit:Emitter", ptr %t2, i32 0, i32 3
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t5, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d69, i32 0, i32 1) })
  store i32 %t7, ptr %l4
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t9 = load i32, ptr %l4, !tbaa !23
  %t10 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgType(ptr %v0, ptr %t8, i32 %t9)
  store i64 %t10, ptr %l5
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t11 = load i64, ptr %l5, !tbaa !24
  store i64 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t4 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t7 = extractvalue { i64, ptr } %a2, 1
  %t8 = extractvalue { i64, ptr } %a2, 0
  %t9 = add i64 %t5, %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t9)
  call void @olang_textcopy(ptr %t10, ptr %t4, i64 %t5)
  %t11 = getelementptr i8, ptr %t10, i64 %t5
  call void @olang_textcopy(ptr %t11, ptr %t7, i64 %t8)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t10, 1
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t16 = extractvalue { i64, ptr } %t13, 1
  %t17 = mul i64 %t15, 1
  %t18 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t16, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %v1, ptr %s0, ptr %a0, { i64, ptr } %a1, { i64, ptr } %t20)
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclared(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l6 = alloca { i64, ptr }
  %l10 = alloca i1
  %l13 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca { i64, [2 x i64] }
  %l16 = alloca i32
  %l17 = alloca { i64, ptr }
  %l21 = alloca i64
  %l24 = alloca i1
  %l27 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca { i64, [2 x i64] }
  %l30 = alloca i32
  %l33 = alloca { i64, ptr }
  %l37 = alloca i64
  %l40 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load { i64, [2 x i64] }, ptr %l1
  %t5 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s0, ptr %t1, { i64, [2 x i64] } %t2)
  store { i64, ptr } %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/emit:Emitter", ptr %t7, i32 0, i32 20
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t13 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %s0, ptr %t9, { i64, ptr } %t10)
  store i1 %t13, ptr %l10
  br label %bb2
bb2:
  %t14 = load i1, ptr %l10, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load { i64, [2 x i64] }, ptr %l1
  %t19 = call i32 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecodeType(ptr %v0, ptr %t15, { i64, [2 x i64] } %t16)
  store i32 %t19, ptr %l13
  br label %bb6
bb6:
  %t20 = load i32, ptr %l13, !tbaa !23
  store i32 %t20, ptr %l3, !tbaa !23
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l14, !tbaa !29
  %t22 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t22, ptr %l15
  %t23 = load i32, ptr %l3, !tbaa !23
  store i32 %t23, ptr %l16, !tbaa !23
  %t24 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t24, ptr %l17, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load { i64, [2 x i64] }, ptr %l1
  %t27 = load i32, ptr %l3, !tbaa !23
  %t31 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2epassedOf(ptr %v0, ptr %t25, { i64, [2 x i64] } %t26, i32 %t27)
  store i64 %t31, ptr %l21
  br label %bb7
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load { i64, [2 x i64] }, ptr %l1
  %t36 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehasEnv(ptr %v0, ptr %t32, { i64, [2 x i64] } %t33)
  store i1 %t36, ptr %l24
  br label %bb8
bb8:
  %t37 = load ptr, ptr %l14, !tbaa !29
  %t38 = load { i64, [2 x i64] }, ptr %l15
  %t39 = load i32, ptr %l16, !tbaa !23
  %t40 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t41 = load i64, ptr %l21, !tbaa !24
  %t42 = load i1, ptr %l24, !tbaa !21
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efnItem(ptr %v0, ptr %s0, ptr %s0, ptr %t37, { i64, [2 x i64] } %t38, i32 %t39, { i64, ptr } %t40, i64 %t41, i1 %t42, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d71, i32 0, i32 1) })
  br label %bb9
bb9:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load { i64, [2 x i64] }, ptr %l1
  %t47 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisGenFn(ptr %v0, ptr %t43, { i64, [2 x i64] } %t44)
  store i1 %t47, ptr %l27
  br label %bb10
bb10:
  %t48 = load i1, ptr %l27, !tbaa !21
  br i1 %t48, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l28, !tbaa !29
  %t50 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t50, ptr %l29
  %t51 = load i32, ptr %l3, !tbaa !23
  store i32 %t51, ptr %l30, !tbaa !23
  %t52 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t52, 1
  %t55 = extractvalue { i64, ptr } %t52, 0
  %t56 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t57 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  %t58 = add i64 %t55, %t57
  %t59 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t58)
  call void @olang_textcopy(ptr %t59, ptr %t54, i64 %t55)
  %t60 = getelementptr i8, ptr %t59, i64 %t55
  call void @olang_textcopy(ptr %t60, ptr %t56, i64 %t57)
  %t61 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t59, 1
  %t64 = extractvalue { i64, ptr } %t62, 0
  %t65 = extractvalue { i64, ptr } %t62, 1
  %t66 = mul i64 %t64, 1
  %t67 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t66)
  call void @llvm.memcpy.p0.p0.i64(ptr %t67, ptr %t65, i64 %t66, i1 false)
  %t68 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  store { i64, ptr } %t69, ptr %l33, !tbaa !27
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load { i64, [2 x i64] }, ptr %l1
  %t72 = load i32, ptr %l3, !tbaa !23
  %t76 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2epassedOf(ptr %v0, ptr %t70, { i64, [2 x i64] } %t71, i32 %t72)
  store i64 %t76, ptr %l37
  br label %bb13
bb12:
  br label %bb16
bb13:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load { i64, [2 x i64] }, ptr %l1
  %t81 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehasEnv(ptr %v0, ptr %t77, { i64, [2 x i64] } %t78)
  store i1 %t81, ptr %l40
  br label %bb14
bb14:
  %t82 = load ptr, ptr %l28, !tbaa !29
  %t83 = load { i64, [2 x i64] }, ptr %l29
  %t84 = load i32, ptr %l30, !tbaa !23
  %t85 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t86 = load i64, ptr %l37, !tbaa !24
  %t87 = load i1, ptr %l40, !tbaa !21
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efnItem(ptr %v0, ptr %s2, ptr %s2, ptr %t82, { i64, [2 x i64] } %t83, i32 %t84, { i64, ptr } %t85, i64 %t86, i1 %t87, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d73, i32 0, i32 1) })
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eenumWords(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i1
  %l7 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  %t8 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t4, i32 %t5)
  store i1 %t8, ptr %l5
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/emit:Emitter", ptr %t9, i32 0, i32 3
  %t12 = load ptr, ptr %t11, !tbaa !29
  store ptr %t12, ptr %l7, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/emit:Emitter", ptr %t13, i32 0, i32 3
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t17 = load i32, ptr %l1, !tbaa !23
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t16, i32 %t17)
  store i32 %t20, ptr %l11
  br label %bb2
bb2:
  %t21 = load ptr, ptr %l7, !tbaa !29
  %t22 = load i32, ptr %l11, !tbaa !23
  %t23 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePayloadSize(ptr %v0, ptr %t21, i32 %t22)
  store i64 %t23, ptr %l12
  br label %bb3
bb3:
  %t24 = load i64, ptr %l12, !tbaa !24
  %t25 = icmp sge i64 %t24, 0
  store i1 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eexportArrayResult(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l5 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i1
  %l11 = alloca i1
  %l14 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l5, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l8
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l5, !tbaa !29
  %t13 = load i32, ptr %l8, !tbaa !23
  %t14 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t14, ptr %l9
  br label %bb2
bb2:
  %t15 = load i1, ptr %l9, !tbaa !21
  %t16 = xor i1 %t15, true
  br i1 %t16, label %bb3, label %bb4
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i32 @compiler_2femit_2ecompiler_2femit_3aEmitter_2earrayOfE(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l14
  br label %bb5
bb4:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb6
bb5:
  %t23 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t24 = load i32, ptr %l14, !tbaa !23
  %t26 = icmp ne i32 %t24, %t23
  store i1 %t26, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t28 = load i1, ptr %l11, !tbaa !21
  store i1 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2efieldNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca %"compiler/source:Span"
  %l20 = alloca %"compiler/source:Span"
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l26 = alloca i64
  %l34 = alloca i64
  %l37 = alloca i64
  %l64 = alloca i32
  %l70 = alloca ptr
  %l74 = alloca i32
  %l75 = alloca ptr
  %l78 = alloca i1
  %l85 = alloca ptr
  %l86 = alloca i1
  %l102 = alloca { i64, ptr }
  %l105 = alloca ptr
  %l106 = alloca i1
  %l110 = alloca i1
  %l132 = alloca { i64, ptr }
  %l138 = alloca i64
  %l141 = alloca { i64, ptr }
  %s13 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t11 = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  store i64 %t1, ptr %l26, !tbaa !24
  %t2 = load i64, ptr %l26, !tbaa !24
  %t3 = icmp sge i64 %t2, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l26, !tbaa !24
  %t6 = icmp sle i64 %t5, 576460752303423487
  br i1 %t6, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_672626b841abebed_e9d6bd273cfd5371)
  unreachable
bb3:
  %t8 = load i64, ptr %l26, !tbaa !24
  %t9 = mul i64 %t8, 16
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  store i64 0, ptr %t11
  br label %fill.12
fill.12:
  %t15 = load i64, ptr %t11
  %t16 = icmp slt i64 %t15, %t8
  br i1 %t16, label %fillb.13, label %filld.14
fillb.13:
  %t17 = getelementptr { i64, ptr }, ptr %t10, i64 %t15
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d74, i32 0, i32 1) }, ptr %t17
  %t18 = add i64 %t15, 1
  store i64 %t18, ptr %t11
  br label %fill.12
filld.14:
  %t19 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t10, 1
  %t21 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t21, ptr %lp3
  %t23 = load ptr, ptr %lp3
  store { i64, ptr } %t20, ptr %t23, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t24 = load i64, ptr %l2, !tbaa !24
  store i64 %t24, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = icmp sgt i64 %t26, %t27
  br i1 %t30, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_672626b841abebed_e9d6bd273cfd5371)
  unreachable
bb5:
  %t32 = load i64, ptr %l6, !tbaa !24
  %t34 = icmp sgt i64 %t32, 0
  br i1 %t34, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb10
bb7:
  %t36 = load i64, ptr %l5, !tbaa !24
  %t37 = load i64, ptr %l4, !tbaa !24
  %t40 = sub i64 %t36, %t37
  %t41 = load i64, ptr %l6, !tbaa !24
  %t44 = add i64 %t40, %t41
  %t46 = sub i64 %t44, 1
  %t47 = load i64, ptr %l6, !tbaa !24
  %t50 = sdiv i64 %t46, %t47
  store i64 %t50, ptr %l37, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb9
bb9:
  %t52 = load i64, ptr %l37, !tbaa !24
  store i64 %t52, ptr %l34, !tbaa !24
  br label %bb10
bb10:
  %t53 = load i64, ptr %l34, !tbaa !24
  store i64 %t53, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb11
bb11:
  %t54 = load i64, ptr %l8, !tbaa !24
  %t55 = load i64, ptr %l7, !tbaa !24
  %t58 = icmp slt i64 %t54, %t55
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb12, label %bb13
bb12:
  br label %bb16
bb13:
  br label %bb14
bb14:
  %t62 = load i64, ptr %l4, !tbaa !24
  %t63 = load i64, ptr %l8, !tbaa !24
  %t64 = load i64, ptr %l6, !tbaa !24
  %t67 = mul i64 %t63, %t64
  %t70 = add i64 %t62, %t67
  store i64 %t70, ptr %l9, !tbaa !24
  %t72 = load i64, ptr %l9, !tbaa !24
  %t73 = load i64, ptr %l9, !tbaa !24
  %t75 = call i64 @__olang_fmt_i64(ptr null, i64 %t73)
  %t76 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t75)
  %t77 = call i64 @__olang_fmt_i64(ptr %t76, i64 %t73)
  %t78 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t76, 1
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t82 = extractvalue { i64, ptr } %t79, 1
  %t83 = mul i64 %t81, 1
  %t84 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t83)
  call void @llvm.memcpy.p0.p0.i64(ptr %t84, ptr %t82, i64 %t83, i1 false)
  %t85 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  %t88 = load ptr, ptr %lp3
  %t90 = getelementptr { i64, ptr }, ptr %t88, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %t91, i64 %t72
  store { i64, ptr } %t86, ptr %t92, !tbaa !37
  br label %bb15
bb15:
  %t93 = load i64, ptr %l8, !tbaa !24
  %t95 = add i64 %t93, 1
  store i64 %t95, ptr %l8, !tbaa !24
  br label %bb11
bb16:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/emit:Emitter", ptr %t97, i32 0, i32 3
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t101 = load i32, ptr %l1, !tbaa !23
  %t104 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t100, i32 %t101)
  store i32 %t104, ptr %l64
  br label %bb17
bb17:
  %t105 = load i32, ptr %l64, !range !{i32 0, i32 33}
  %t107 = trunc i64 18 to i32
  %t108 = icmp eq i32 %t105, %t107
  %t110 = xor i1 %t108, true
  br i1 %t110, label %bb18, label %bb19
bb18:
  %t112 = load ptr, ptr %lp3
  %t113 = load { i64, ptr }, ptr %t112, !tbaa !27
  store { i64, ptr } %t113, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/emit:Emitter", ptr %t115, i32 0, i32 0
  %t118 = load ptr, ptr %t117, !tbaa !29
  store ptr %t118, ptr %l70, !tbaa !29
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/emit:Emitter", ptr %t119, i32 0, i32 3
  %t122 = load ptr, ptr %t121, !tbaa !29
  %t123 = load i32, ptr %l1, !tbaa !23
  %t126 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t122, i32 %t123)
  store i32 %t126, ptr %l74
  br label %bb21
bb21:
  %t127 = load ptr, ptr %l70, !tbaa !29
  %t128 = load i32, ptr %l74, !tbaa !23
  %t129 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t127, i32 %t128)
  store ptr %t129, ptr %l75
  br label %bb22
bb22:
  %t130 = load ptr, ptr %l75, !tbaa !29
  store ptr %t130, ptr %l10, !tbaa !29
  %t131 = load ptr, ptr %l10, !tbaa !29
  %t133 = icmp eq ptr %t131, null
  br i1 %t133, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l78, !tbaa !21
  br label %bb25
bb24:
  %t135 = load ptr, ptr %l10, !tbaa !29
  %t137 = getelementptr %"compiler/ast:TypeDecl", ptr %t135, i32 0, i32 3
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = icmp eq ptr %t138, null
  store i1 %t140, ptr %l78, !tbaa !21
  br label %bb25
bb25:
  %t142 = load i1, ptr %l78, !tbaa !21
  br i1 %t142, label %bb26, label %bb27
bb26:
  %t143 = load ptr, ptr %lp3
  %t144 = load { i64, ptr }, ptr %t143, !tbaa !27
  store { i64, ptr } %t144, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t146 = load ptr, ptr %l10, !tbaa !29
  %t148 = getelementptr %"compiler/ast:TypeDecl", ptr %t146, i32 0, i32 3
  %t149 = load ptr, ptr %t148, !tbaa !29
  store ptr %t149, ptr %l11, !tbaa !29
  %t151 = load ptr, ptr %l11, !tbaa !29
  store ptr %t151, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t152 = load ptr, ptr %l85, !tbaa !29
  %t153 = icmp ne ptr %t152, null
  br i1 %t153, label %bb29, label %bb30
bb29:
  %t155 = load ptr, ptr %l85, !tbaa !29
  %t156 = load i64, ptr %t155, !range !{i64 0, i64 5}
  %t158 = icmp eq i64 %t156, 0
  store i1 %t158, ptr %l86, !tbaa !21
  br label %bb30
bb30:
  %t159 = load i1, ptr %l86, !tbaa !21
  %t160 = xor i1 %t159, true
  br i1 %t160, label %bb31, label %bb32
bb31:
  %t162 = load ptr, ptr %lp3
  %t163 = load { i64, ptr }, ptr %t162, !tbaa !27
  store { i64, ptr } %t163, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t165 = load ptr, ptr %l11, !tbaa !29
  %t167 = getelementptr { i64, [6 x i64] }, ptr %t165, i32 0, i32 1
  %t168 = getelementptr { ptr }, ptr %t167, i32 0, i32 0
  %t169 = load ptr, ptr %t168
  store i64 0, ptr %l13, !tbaa !24
  %t174 = getelementptr %"compiler/ast:StructBody", ptr %t169, i32 0, i32 2
  %t175 = load { i64, ptr }, ptr %t174, !tbaa !27
  store { i64, ptr } %t175, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t177 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t177, 0
  store i64 %t179, ptr %l16, !tbaa !24
  br label %bb34
bb34:
  %t181 = load i64, ptr %l15, !tbaa !24
  %t182 = load i64, ptr %l16, !tbaa !24
  %t185 = icmp slt i64 %t181, %t182
  %t187 = xor i1 %t185, true
  br i1 %t187, label %bb35, label %bb36
bb35:
  br label %bb57
bb36:
  br label %bb37
bb37:
  %t189 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t189, ptr %l102, !tbaa !27
  %t190 = load i64, ptr %l15, !tbaa !24
  %t192 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = getelementptr ptr, ptr %t193, i64 %t190
  %t195 = load ptr, ptr %t194, !tbaa !39
  store ptr %t195, ptr %l17, !tbaa !29
  %t197 = load ptr, ptr %l17, !tbaa !29
  store ptr %t197, ptr %l105, !tbaa !29
  store i1 false, ptr %l106, !tbaa !21
  %t198 = load ptr, ptr %l105, !tbaa !29
  %t199 = icmp ne ptr %t198, null
  br i1 %t199, label %bb38, label %bb39
bb38:
  %t201 = load ptr, ptr %l105, !tbaa !29
  %t202 = load i64, ptr %t201, !range !{i64 0, i64 22}
  %t204 = icmp eq i64 %t202, 1
  store i1 %t204, ptr %l106, !tbaa !21
  br label %bb39
bb39:
  %t205 = load i1, ptr %l106, !tbaa !21
  %t206 = xor i1 %t205, true
  br i1 %t206, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l110, !tbaa !21
  br label %bb42
bb41:
  %t208 = load ptr, ptr %l17, !tbaa !29
  %t210 = getelementptr { i64, [4 x i64] }, ptr %t208, i32 0, i32 1
  %t211 = getelementptr { %"compiler/source:Span", ptr }, ptr %t210, i32 0, i32 0
  %t212 = load %"compiler/source:Span", ptr %t211
  store %"compiler/source:Span" %t212, ptr %l18
  %t214 = load ptr, ptr %l17, !tbaa !29
  %t216 = getelementptr { i64, [4 x i64] }, ptr %t214, i32 0, i32 1
  %t217 = getelementptr { %"compiler/source:Span", ptr }, ptr %t216, i32 0, i32 1
  %t218 = load ptr, ptr %t217
  %t223 = getelementptr %"compiler/ast:VarDecl", ptr %t218, i32 0, i32 5
  %t224 = load i1, ptr %t223, !tbaa !21
  %t226 = xor i1 %t224, true
  store i1 %t226, ptr %l110, !tbaa !21
  br label %bb42
bb42:
  %t228 = load i1, ptr %l110, !tbaa !21
  br i1 %t228, label %bb43, label %bb44
bb43:
  br label %bb56
bb44:
  br label %bb45
bb45:
  %t229 = load ptr, ptr %l17, !tbaa !29
  %t231 = getelementptr { i64, [4 x i64] }, ptr %t229, i32 0, i32 1
  %t232 = getelementptr { %"compiler/source:Span", ptr }, ptr %t231, i32 0, i32 0
  %t233 = load %"compiler/source:Span", ptr %t232
  store %"compiler/source:Span" %t233, ptr %l20
  %t235 = load ptr, ptr %l17, !tbaa !29
  %t237 = getelementptr { i64, [4 x i64] }, ptr %t235, i32 0, i32 1
  %t238 = getelementptr { %"compiler/source:Span", ptr }, ptr %t237, i32 0, i32 1
  %t239 = load ptr, ptr %t238
  %t244 = getelementptr %"compiler/ast:VarDecl", ptr %t239, i32 0, i32 0
  %t245 = load { i64, ptr }, ptr %t244, !tbaa !27
  store { i64, ptr } %t245, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t247 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t249 = extractvalue { i64, ptr } %t247, 0
  store i64 %t249, ptr %l24, !tbaa !24
  br label %bb46
bb46:
  %t251 = load i64, ptr %l23, !tbaa !24
  %t252 = load i64, ptr %l24, !tbaa !24
  %t255 = icmp slt i64 %t251, %t252
  %t257 = xor i1 %t255, true
  br i1 %t257, label %bb47, label %bb48
bb47:
  br label %bb55
bb48:
  br label %bb49
bb49:
  %t259 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t259, ptr %l132, !tbaa !27
  %t260 = load i64, ptr %l23, !tbaa !24
  %t262 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t263 = load ptr, ptr %t262, !tbaa !27
  %t264 = getelementptr i32, ptr %t263, i64 %t260
  %t265 = load i32, ptr %t264, !tbaa !33
  store i32 %t265, ptr %l25, !tbaa !23
  %t267 = load i64, ptr %l13, !tbaa !24
  %t268 = load i64, ptr %l2, !tbaa !24
  %t271 = icmp slt i64 %t267, %t268
  br i1 %t271, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s13
  %t273 = load i64, ptr %l13, !tbaa !24
  store i64 %t273, ptr %l138, !tbaa !24
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load i32, ptr %l25, !tbaa !23
  %t278 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %s13, ptr %t274, i32 %t275)
  store { i64, ptr } %t278, ptr %l141
  br label %bb52
bb51:
  br label %bb53
bb52:
  %t279 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t280 = extractvalue { i64, ptr } %t279, 1
  %t281 = extractvalue { i64, ptr } %t279, 0
  %t282 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t281)
  call void @olang_textcopy(ptr %t282, ptr %t280, i64 %t281)
  %t283 = insertvalue { i64, ptr } undef, i64 %t281, 0
  %t284 = insertvalue { i64, ptr } %t283, ptr %t282, 1
  %t286 = extractvalue { i64, ptr } %t284, 0
  %t287 = extractvalue { i64, ptr } %t284, 1
  %t288 = mul i64 %t286, 1
  %t289 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t288)
  call void @llvm.memcpy.p0.p0.i64(ptr %t289, ptr %t287, i64 %t288, i1 false)
  %t290 = insertvalue { i64, ptr } undef, i64 %t286, 0
  %t291 = insertvalue { i64, ptr } %t290, ptr %t289, 1
  %t293 = load ptr, ptr %lp3
  %t294 = load i64, ptr %l138, !tbaa !24
  %t295 = getelementptr { i64, ptr }, ptr %t293, i32 0, i32 1
  %t296 = load ptr, ptr %t295, !tbaa !27
  %t297 = getelementptr { i64, ptr }, ptr %t296, i64 %t294
  store { i64, ptr } %t291, ptr %t297, !tbaa !37
  call void @__olang_scope_close(ptr %s13)
  br label %bb53
bb53:
  %t298 = load i64, ptr %l13, !tbaa !24
  %t300 = add i64 %t298, 1
  store i64 %t300, ptr %l13, !tbaa !24
  br label %bb54
bb54:
  %t302 = load i64, ptr %l23, !tbaa !24
  %t304 = add i64 %t302, 1
  store i64 %t304, ptr %l23, !tbaa !24
  br label %bb46
bb55:
  br label %bb56
bb56:
  %t306 = load i64, ptr %l15, !tbaa !24
  %t308 = add i64 %t306, 1
  store i64 %t308, ptr %l15, !tbaa !24
  br label %bb34
bb57:
  %t310 = load ptr, ptr %lp3
  %t311 = load { i64, ptr }, ptr %t310, !tbaa !27
  store { i64, ptr } %t311, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efunction(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i1
  %l20 = alloca %"compiler/mir:Fn"
  %l24 = alloca { i64, ptr }
  %l27 = alloca i1
  %l32 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, [2 x i64] }
  %l36 = alloca i32
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i1
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l49 = alloca i1
  %l53 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l62 = alloca i1
  %l64 = alloca i1
  %l66 = alloca ptr
  %l67 = alloca { i64, ptr }
  %l69 = alloca i1
  %l71 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l80 = alloca i1
  %l92 = alloca ptr
  %l93 = alloca { i64, [2 x i64] }
  %l95 = alloca i32
  %l96 = alloca { i64, ptr }
  %l97 = alloca i64
  %l98 = alloca i1
  %l99 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l119 = alloca i1
  %l123 = alloca i1
  %l125 = alloca ptr
  %l126 = alloca { i64, [2 x i64] }
  %l128 = alloca i32
  %l131 = alloca { i64, ptr }
  %l132 = alloca i64
  %l133 = alloca i1
  %l136 = alloca i64
  %l137 = alloca { i64, ptr }
  %l139 = alloca { i64, ptr }
  %l149 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %t22 = alloca %"compiler/mir:Fn", align 8
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 69
  store ptr %t3, ptr %l10, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t5 = load { i64, [2 x i64] }, ptr %l1
  %t8 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehomeOf(ptr %v0, ptr %t4, { i64, [2 x i64] } %t5)
  store i64 %t8, ptr %l13
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l10, !tbaa !29
  %t10 = load i64, ptr %l13, !tbaa !24
  %t11 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t9, i64 %t10)
  store i1 %t11, ptr %l14
  br label %bb2
bb2:
  %t12 = load i1, ptr %l14, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load { i64, [2 x i64] }, ptr %l1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclared(ptr %v0, ptr %t13, { i64, [2 x i64] } %t14)
  br label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/emit:Emitter", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t21 = load { i64, [2 x i64] }, ptr %l1
  call void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eLowerKey(ptr %t22, ptr %v0, ptr %v0, ptr %t20, { i64, [2 x i64] } %t21)
  call void @llvm.memmove.p0.p0.i64(ptr %l20, ptr %t22, i64 800, i1 false)
  br label %bb7
bb7:
  %t25 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 800, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %l20, i64 800, i1 false)
  store ptr %t25, ptr %l2, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load { i64, [2 x i64] }, ptr %l1
  %t31 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s0, ptr %t27, { i64, [2 x i64] } %t28)
  store { i64, ptr } %t31, ptr %l24
  br label %bb8
bb8:
  %t32 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t32, ptr %l3, !tbaa !27
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load { i64, [2 x i64] }, ptr %l1
  %t37 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehasEnv(ptr %v0, ptr %t33, { i64, [2 x i64] } %t34)
  store i1 %t37, ptr %l27
  br label %bb9
bb9:
  %t38 = load i1, ptr %l27, !tbaa !21
  store i1 %t38, ptr %l4, !tbaa !21
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load { i64, [2 x i64] }, ptr %l1
  %t41 = load ptr, ptr %l2, !tbaa !29
  %t43 = getelementptr %"compiler/mir:Fn", ptr %t41, i32 0, i32 1
  %t44 = load i32, ptr %t43, !tbaa !23
  %t48 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2epassedOf(ptr %v0, ptr %t39, { i64, [2 x i64] } %t40, i32 %t44)
  store i64 %t48, ptr %l32
  br label %bb10
bb10:
  %t49 = load i64, ptr %l32, !tbaa !24
  store i64 %t49, ptr %l5, !tbaa !24
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l33, !tbaa !29
  %t51 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t51, ptr %l34
  %t52 = load ptr, ptr %l2, !tbaa !29
  %t54 = getelementptr %"compiler/mir:Fn", ptr %t52, i32 0, i32 1
  %t55 = load i32, ptr %t54, !tbaa !23
  store i32 %t55, ptr %l36, !tbaa !23
  %t56 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t56, ptr %l37, !tbaa !27
  %t57 = load i64, ptr %l5, !tbaa !24
  store i64 %t57, ptr %l38, !tbaa !24
  %t58 = load i1, ptr %l4, !tbaa !21
  store i1 %t58, ptr %l39, !tbaa !21
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load { i64, [2 x i64] }, ptr %l1
  %t63 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehomeOf(ptr %v0, ptr %t59, { i64, [2 x i64] } %t60)
  store i64 %t63, ptr %l42
  br label %bb11
bb11:
  %t64 = load i64, ptr %l42, !tbaa !24
  %t65 = call { i64, ptr } @compiler_2femit_2elinkFor(ptr %s0, i64 %t64)
  store { i64, ptr } %t65, ptr %l43
  br label %bb12
bb12:
  %t66 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  %t68 = extractvalue { i64, ptr } %t66, 1
  %t69 = mul i64 %t67, 1
  %t70 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t69)
  call void @llvm.memcpy.p0.p0.i64(ptr %t70, ptr %t68, i64 %t69, i1 false)
  %t71 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  %t73 = load ptr, ptr %l33, !tbaa !29
  %t74 = load { i64, [2 x i64] }, ptr %l34
  %t75 = load i32, ptr %l36, !tbaa !23
  %t76 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t77 = load i64, ptr %l38, !tbaa !24
  %t78 = load i1, ptr %l39, !tbaa !21
  %t80 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eheader(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t73, { i64, [2 x i64] } %t74, i32 %t75, { i64, ptr } %t76, i64 %t77, i1 %t78, { i64, ptr } %t72, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d75, i32 0, i32 1) })
  store { i64, ptr } %t80, ptr %l45
  br label %bb13
bb13:
  %t81 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t81, ptr %l6, !tbaa !27
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/emit:Emitter", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = getelementptr %"compiler/lower:Lowerer", ptr %t85, i32 0, i32 5
  %t88 = load i1, ptr %t87, !tbaa !21
  br i1 %t88, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb16
bb15:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/emit:Emitter", ptr %t90, i32 0, i32 8
  %t93 = load i1, ptr %t92, !tbaa !21
  %t95 = xor i1 %t93, true
  store i1 %t95, ptr %l49, !tbaa !21
  br label %bb16
bb16:
  %t97 = load i1, ptr %l49, !tbaa !21
  br i1 %t97, label %bb17, label %bb18
bb17:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d76, i32 0, i32 1) }, ptr %l53, !tbaa !27
  br label %bb20
bb18:
  %t98 = load ptr, ptr %l2, !tbaa !29
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/emit:Emitter", ptr %t99, i32 0, i32 3
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t105 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eVerify(ptr %v0, ptr %v0, ptr %s0, ptr %t98, ptr %t102)
  store { i64, ptr } %t105, ptr %l57
  br label %bb19
bb19:
  %t106 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t106, 0
  %t108 = extractvalue { i64, ptr } %t106, 1
  %t109 = mul i64 %t107, 1
  %t110 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t109)
  call void @llvm.memcpy.p0.p0.i64(ptr %t110, ptr %t108, i64 %t109, i1 false)
  %t111 = insertvalue { i64, ptr } undef, i64 %t107, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l53, !tbaa !27
  br label %bb20
bb20:
  %t114 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t114, ptr %l7, !tbaa !27
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/emit:Emitter", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = getelementptr %"compiler/lower:Lowerer", ptr %t118, i32 0, i32 5
  %t121 = load i1, ptr %t120, !tbaa !21
  br i1 %t121, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb24
bb22:
  %t123 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t125 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t123, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d77, i32 0, i32 1) })
  store i1 %t125, ptr %l64
  br label %bb23
bb23:
  %t126 = load i1, ptr %l64, !tbaa !21
  %t127 = xor i1 %t126, true
  store i1 %t127, ptr %l62, !tbaa !21
  br label %bb24
bb24:
  %t129 = load i1, ptr %l62, !tbaa !21
  br i1 %t129, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s2
  %t130 = load ptr, ptr %l0, !tbaa !29
  store ptr %t130, ptr %l66, !tbaa !29
  %t131 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t131, ptr %l67, !tbaa !27
  %t132 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t134 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s2, { i64, ptr } %t132, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d78, i32 0, i32 1) })
  store i1 %t134, ptr %l69
  br label %bb27
bb26:
  br label %bb42
bb27:
  %t135 = load i1, ptr %l69, !tbaa !21
  %t136 = xor i1 %t135, true
  br i1 %t136, label %bb28, label %bb29
bb28:
  %t138 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t140 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %s0, ptr %s2, { i64, ptr } %t138)
  store { i64, ptr } %t140, ptr %l73
  br label %bb30
bb29:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d79, i32 0, i32 1) }, ptr %l71, !tbaa !27
  br label %bb31
bb30:
  %t141 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d80, i32 0, i32 1) }, 1
  %t142 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d80, i32 0, i32 1) }, 0
  %t143 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t143, 1
  %t145 = extractvalue { i64, ptr } %t143, 0
  %t146 = add i64 %t142, %t145
  %t147 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d81, i32 0, i32 1) }, 1
  %t148 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d81, i32 0, i32 1) }, 0
  %t149 = add i64 %t146, %t148
  %t150 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t149)
  call void @olang_textcopy(ptr %t150, ptr %t141, i64 %t142)
  %t151 = getelementptr i8, ptr %t150, i64 %t142
  call void @olang_textcopy(ptr %t151, ptr %t144, i64 %t145)
  %t152 = getelementptr i8, ptr %t151, i64 %t145
  call void @olang_textcopy(ptr %t152, ptr %t147, i64 %t148)
  %t153 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t150, 1
  %t156 = extractvalue { i64, ptr } %t154, 0
  %t157 = extractvalue { i64, ptr } %t154, 1
  %t158 = mul i64 %t156, 1
  %t159 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t158)
  call void @llvm.memcpy.p0.p0.i64(ptr %t159, ptr %t157, i64 %t158, i1 false)
  %t160 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t161 = insertvalue { i64, ptr } %t160, ptr %t159, 1
  store { i64, ptr } %t161, ptr %l71, !tbaa !27
  br label %bb31
bb31:
  %t163 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d82, i32 0, i32 1) }, 1
  %t164 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d82, i32 0, i32 1) }, 0
  %t165 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t166 = extractvalue { i64, ptr } %t165, 1
  %t167 = extractvalue { i64, ptr } %t165, 0
  %t168 = add i64 %t164, %t167
  %t169 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t169, 1
  %t171 = extractvalue { i64, ptr } %t169, 0
  %t172 = add i64 %t168, %t171
  %t173 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t172)
  call void @olang_textcopy(ptr %t173, ptr %t163, i64 %t164)
  %t174 = getelementptr i8, ptr %t173, i64 %t164
  call void @olang_textcopy(ptr %t174, ptr %t166, i64 %t167)
  %t175 = getelementptr i8, ptr %t174, i64 %t167
  call void @olang_textcopy(ptr %t175, ptr %t170, i64 %t171)
  %t176 = insertvalue { i64, ptr } undef, i64 %t172, 0
  %t177 = insertvalue { i64, ptr } %t176, ptr %t173, 1
  %t179 = extractvalue { i64, ptr } %t177, 0
  %t180 = extractvalue { i64, ptr } %t177, 1
  %t181 = mul i64 %t179, 1
  %t182 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t181)
  call void @llvm.memcpy.p0.p0.i64(ptr %t182, ptr %t180, i64 %t181, i1 false)
  %t183 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t182, 1
  %t185 = load ptr, ptr %l66, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2egap(ptr %v0, ptr %s2, ptr %t185, { i64, ptr } %t184)
  br label %bb32
bb32:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load { i64, [2 x i64] }, ptr %l1
  %t191 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisGlobalInit(ptr %v0, ptr %t187, { i64, [2 x i64] } %t188)
  store i1 %t191, ptr %l80
  br label %bb33
bb33:
  %t192 = load i1, ptr %l80, !tbaa !21
  br i1 %t192, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s5
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load { i64, [2 x i64] }, ptr %l1
  %t195 = load ptr, ptr %l2, !tbaa !29
  %t197 = getelementptr %"compiler/mir:Fn", ptr %t195, i32 0, i32 1
  %t198 = load i32, ptr %t197, !tbaa !23
  %t199 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t200 = load i64, ptr %l5, !tbaa !24
  %t201 = load i1, ptr %l4, !tbaa !21
  %t202 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t202, 1
  %t205 = extractvalue { i64, ptr } %t202, 0
  %t206 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d83, i32 0, i32 1) }, 1
  %t207 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d83, i32 0, i32 1) }, 0
  %t208 = add i64 %t205, %t207
  %t209 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t208)
  call void @olang_textcopy(ptr %t209, ptr %t204, i64 %t205)
  %t210 = getelementptr i8, ptr %t209, i64 %t205
  call void @olang_textcopy(ptr %t210, ptr %t206, i64 %t207)
  %t211 = insertvalue { i64, ptr } undef, i64 %t208, 0
  %t212 = insertvalue { i64, ptr } %t211, ptr %t209, 1
  %t214 = extractvalue { i64, ptr } %t212, 0
  %t215 = extractvalue { i64, ptr } %t212, 1
  %t216 = mul i64 %t214, 1
  %t217 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t216)
  call void @llvm.memcpy.p0.p0.i64(ptr %t217, ptr %t215, i64 %t216, i1 false)
  %t218 = insertvalue { i64, ptr } undef, i64 %t214, 0
  %t219 = insertvalue { i64, ptr } %t218, ptr %t217, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efnItem(ptr %v0, ptr %s0, ptr %s5, ptr %t193, { i64, [2 x i64] } %t194, i32 %t198, { i64, ptr } %t199, i64 %t200, i1 %t201, { i64, ptr } %t219)
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb37:
  %t227 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s2, ptr %t227, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d84, i32 0, i32 1) })
  br label %bb38
bb38:
  %t229 = load ptr, ptr %l0, !tbaa !29
  store ptr %t229, ptr %l92, !tbaa !29
  %t230 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t230, ptr %l93
  %t231 = load ptr, ptr %l2, !tbaa !29
  %t233 = getelementptr %"compiler/mir:Fn", ptr %t231, i32 0, i32 1
  %t234 = load i32, ptr %t233, !tbaa !23
  store i32 %t234, ptr %l95, !tbaa !23
  %t235 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t235, ptr %l96, !tbaa !27
  %t236 = load i64, ptr %l5, !tbaa !24
  store i64 %t236, ptr %l97, !tbaa !24
  %t237 = load i1, ptr %l4, !tbaa !21
  store i1 %t237, ptr %l98, !tbaa !21
  %t238 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t238, ptr %l99, !tbaa !27
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t243 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2estub(ptr %v0, ptr %s2, ptr %s0, ptr %s2, ptr %t239, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d85, i32 0, i32 1) }, { i64, ptr } %t240)
  store { i64, ptr } %t243, ptr %l102
  br label %bb39
bb39:
  %t244 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t245 = extractvalue { i64, ptr } %t244, 1
  %t246 = extractvalue { i64, ptr } %t244, 0
  %t247 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t248 = extractvalue { i64, ptr } %t247, 1
  %t249 = extractvalue { i64, ptr } %t247, 0
  %t250 = add i64 %t246, %t249
  %t251 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t250)
  call void @olang_textcopy(ptr %t251, ptr %t245, i64 %t246)
  %t252 = getelementptr i8, ptr %t251, i64 %t246
  call void @olang_textcopy(ptr %t252, ptr %t248, i64 %t249)
  %t253 = insertvalue { i64, ptr } undef, i64 %t250, 0
  %t254 = insertvalue { i64, ptr } %t253, ptr %t251, 1
  %t256 = extractvalue { i64, ptr } %t254, 0
  %t257 = extractvalue { i64, ptr } %t254, 1
  %t258 = mul i64 %t256, 1
  %t259 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t258)
  call void @llvm.memcpy.p0.p0.i64(ptr %t259, ptr %t257, i64 %t258, i1 false)
  %t260 = insertvalue { i64, ptr } undef, i64 %t256, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t259, 1
  %t262 = load ptr, ptr %l92, !tbaa !29
  %t263 = load { i64, [2 x i64] }, ptr %l93
  %t264 = load i32, ptr %l95, !tbaa !23
  %t265 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t266 = load i64, ptr %l97, !tbaa !24
  %t267 = load i1, ptr %l98, !tbaa !21
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efnItem(ptr %v0, ptr %s0, ptr %s2, ptr %t262, { i64, [2 x i64] } %t263, i32 %t264, { i64, ptr } %t265, i64 %t266, i1 %t267, { i64, ptr } %t261)
  br label %bb40
bb40:
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t270 = load { i64, [2 x i64] }, ptr %l1
  %t271 = load ptr, ptr %l2, !tbaa !29
  %t273 = getelementptr %"compiler/mir:Fn", ptr %t271, i32 0, i32 1
  %t274 = load i32, ptr %t273, !tbaa !23
  %t275 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t276 = load i64, ptr %l5, !tbaa !24
  %t277 = load i1, ptr %l4, !tbaa !21
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewalkStub(ptr %v0, ptr %s0, ptr %s2, ptr %t269, { i64, [2 x i64] } %t270, i32 %t274, { i64, ptr } %t275, i64 %t276, i1 %t277, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d86, i32 0, i32 1) })
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb42:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load { i64, [2 x i64] }, ptr %l1
  %t286 = load ptr, ptr %l2, !tbaa !29
  %t287 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t288 = load i64, ptr %l5, !tbaa !24
  %t289 = load i1, ptr %l4, !tbaa !21
  %t290 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t298 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewriteBody(ptr %v0, ptr %v0, ptr %s0, ptr %s0, ptr %t284, { i64, [2 x i64] } %t285, ptr %t286, { i64, ptr } %t287, i64 %t288, i1 %t289, { i64, ptr } %t290, i1 false)
  store i1 %t298, ptr %l119
  br label %bb43
bb43:
  %t299 = load i1, ptr %l119, !tbaa !21
  %t300 = xor i1 %t299, true
  br i1 %t300, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb45:
  br label %bb46
bb46:
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t303 = load { i64, [2 x i64] }, ptr %l1
  %t306 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisGenFn(ptr %v0, ptr %t302, { i64, [2 x i64] } %t303)
  store i1 %t306, ptr %l123
  br label %bb47
bb47:
  %t307 = load i1, ptr %l123, !tbaa !21
  %t308 = xor i1 %t307, true
  br i1 %t308, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb49:
  br label %bb50
bb50:
  %t310 = load ptr, ptr %l0, !tbaa !29
  store ptr %t310, ptr %l125, !tbaa !29
  %t311 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t311, ptr %l126
  %t312 = load ptr, ptr %l2, !tbaa !29
  %t314 = getelementptr %"compiler/mir:Fn", ptr %t312, i32 0, i32 1
  %t315 = load i32, ptr %t314, !tbaa !23
  store i32 %t315, ptr %l128, !tbaa !23
  %t316 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t318 = extractvalue { i64, ptr } %t316, 1
  %t319 = extractvalue { i64, ptr } %t316, 0
  %t320 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d87, i32 0, i32 1) }, 1
  %t321 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d87, i32 0, i32 1) }, 0
  %t322 = add i64 %t319, %t321
  %t323 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t322)
  call void @olang_textcopy(ptr %t323, ptr %t318, i64 %t319)
  %t324 = getelementptr i8, ptr %t323, i64 %t319
  call void @olang_textcopy(ptr %t324, ptr %t320, i64 %t321)
  %t325 = insertvalue { i64, ptr } undef, i64 %t322, 0
  %t326 = insertvalue { i64, ptr } %t325, ptr %t323, 1
  %t328 = extractvalue { i64, ptr } %t326, 0
  %t329 = extractvalue { i64, ptr } %t326, 1
  %t330 = mul i64 %t328, 1
  %t331 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t330)
  call void @llvm.memcpy.p0.p0.i64(ptr %t331, ptr %t329, i64 %t330, i1 false)
  %t332 = insertvalue { i64, ptr } undef, i64 %t328, 0
  %t333 = insertvalue { i64, ptr } %t332, ptr %t331, 1
  store { i64, ptr } %t333, ptr %l131, !tbaa !27
  %t334 = load i64, ptr %l5, !tbaa !24
  store i64 %t334, ptr %l132, !tbaa !24
  %t335 = load i1, ptr %l4, !tbaa !21
  store i1 %t335, ptr %l133, !tbaa !21
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t337 = load { i64, [2 x i64] }, ptr %l1
  %t340 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehomeOf(ptr %v0, ptr %t336, { i64, [2 x i64] } %t337)
  store i64 %t340, ptr %l136
  br label %bb51
bb51:
  %t341 = load i64, ptr %l136, !tbaa !24
  %t342 = call { i64, ptr } @compiler_2femit_2elinkFor(ptr %s0, i64 %t341)
  store { i64, ptr } %t342, ptr %l137
  br label %bb52
bb52:
  %t343 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t344 = extractvalue { i64, ptr } %t343, 0
  %t345 = extractvalue { i64, ptr } %t343, 1
  %t346 = mul i64 %t344, 1
  %t347 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t346)
  call void @llvm.memcpy.p0.p0.i64(ptr %t347, ptr %t345, i64 %t346, i1 false)
  %t348 = insertvalue { i64, ptr } undef, i64 %t344, 0
  %t349 = insertvalue { i64, ptr } %t348, ptr %t347, 1
  %t350 = load ptr, ptr %l125, !tbaa !29
  %t351 = load { i64, [2 x i64] }, ptr %l126
  %t352 = load i32, ptr %l128, !tbaa !23
  %t353 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t354 = load i64, ptr %l132, !tbaa !24
  %t355 = load i1, ptr %l133, !tbaa !21
  %t357 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eheader(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t350, { i64, [2 x i64] } %t351, i32 %t352, { i64, ptr } %t353, i64 %t354, i1 %t355, { i64, ptr } %t349, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d88, i32 0, i32 1) })
  store { i64, ptr } %t357, ptr %l139
  br label %bb53
bb53:
  %t358 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t360 = load { i64, [2 x i64] }, ptr %l1
  %t361 = load ptr, ptr %l2, !tbaa !29
  %t362 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t364 = extractvalue { i64, ptr } %t362, 1
  %t365 = extractvalue { i64, ptr } %t362, 0
  %t366 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d89, i32 0, i32 1) }, 1
  %t367 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d89, i32 0, i32 1) }, 0
  %t368 = add i64 %t365, %t367
  %t369 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t368)
  call void @olang_textcopy(ptr %t369, ptr %t364, i64 %t365)
  %t370 = getelementptr i8, ptr %t369, i64 %t365
  call void @olang_textcopy(ptr %t370, ptr %t366, i64 %t367)
  %t371 = insertvalue { i64, ptr } undef, i64 %t368, 0
  %t372 = insertvalue { i64, ptr } %t371, ptr %t369, 1
  %t374 = extractvalue { i64, ptr } %t372, 0
  %t375 = extractvalue { i64, ptr } %t372, 1
  %t376 = mul i64 %t374, 1
  %t377 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t376)
  call void @llvm.memcpy.p0.p0.i64(ptr %t377, ptr %t375, i64 %t376, i1 false)
  %t378 = insertvalue { i64, ptr } undef, i64 %t374, 0
  %t379 = insertvalue { i64, ptr } %t378, ptr %t377, 1
  %t380 = load i64, ptr %l5, !tbaa !24
  %t381 = load i1, ptr %l4, !tbaa !21
  %t390 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewriteBody(ptr %v0, ptr %v0, ptr %s0, ptr %s0, ptr %t359, { i64, [2 x i64] } %t360, ptr %t361, { i64, ptr } %t379, i64 %t380, i1 %t381, { i64, ptr } %t358, i1 true)
  store i1 %t390, ptr %l149
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2femit_2ecompiler_2femit_3aEmitter_2efuzzSelected(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %lp3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { { i64, ptr }, { i64, ptr } }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca i64
  %l16 = alloca i64
  %l21 = alloca i64
  %l24 = alloca { { i64, ptr }, { i64, ptr } }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l31 = alloca i1
  %l32 = alloca i1
  %l35 = alloca i1
  %l36 = alloca i1
  %l42 = alloca i1
  %l47 = alloca i1
  %l51 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 48
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t6 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l12
  br label %bb1
bb1:
  %t7 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t7, ptr %lp3
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  %t9 = load ptr, ptr %lp3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %t9
  store ptr %l1, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t11 = load i64, ptr %l5, !tbaa !24
  store i64 %t11, ptr %l14, !tbaa !24
  %t12 = load ptr, ptr %l4, !tbaa !29
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t12)
  store i64 %t14, ptr %l16
  br label %bb3
bb3:
  %t15 = load i64, ptr %l14, !tbaa !24
  %t16 = load i64, ptr %l16, !tbaa !24
  %t17 = icmp slt i64 %t15, %t16
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb5:
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t21, i64 %t22)
  store i64 %t25, ptr %l21
  br label %bb7
bb7:
  %t26 = load i64, ptr %l21, !tbaa !24
  store i64 %t26, ptr %l6, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i64, ptr %l6, !tbaa !24
  %t31 = call { { i64, ptr }, { i64, ptr } } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etestParts(ptr %v0, ptr %s2, ptr %t27, i64 %t28)
  store { { i64, ptr }, { i64, ptr } } %t31, ptr %l24
  br label %bb8
bb8:
  %t32 = load { { i64, ptr }, { i64, ptr } }, ptr %l24
  store { { i64, ptr }, { i64, ptr } } %t32, ptr %l7
  %t33 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l7, i32 0, i32 0
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  store { i64, ptr } %t34, ptr %l25, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t35, 0
  store i64 %t36, ptr %l26, !tbaa !24
  %t37 = load i64, ptr %l26, !tbaa !24
  %t38 = mul i64 %t37, 1
  %t39 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t38)
  %t40 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  store { i64, ptr } %t41, ptr %l27, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = load i64, ptr %l26, !tbaa !24
  %t47 = mul i64 %t46, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t43, ptr %t45, i64 %t47, i1 false)
  %t48 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t48, ptr %l8, !tbaa !27
  %t49 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l7, i32 0, i32 1
  %t50 = load { i64, ptr }, ptr %t49, !tbaa !27
  store { i64, ptr } %t50, ptr %l9, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t56 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %v0, { i64, ptr } %t52, { i64, ptr } %t53)
  store i1 %t56, ptr %l31
  br label %bb9
bb9:
  %t57 = load i1, ptr %l31, !tbaa !21
  br i1 %t57, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb19
bb11:
  %t58 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t62 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s2, ptr %v0, { i64, ptr } %t58, { i64, ptr } %t59)
  store i1 %t62, ptr %l35
  br label %bb12
bb12:
  %t63 = load i1, ptr %l35, !tbaa !21
  br i1 %t63, label %bb13, label %bb14
bb13:
  %t64 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t64, 0
  %t67 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t72 = icmp sgt i64 %t66, %t69
  store i1 %t72, ptr %l36, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb15
bb15:
  %t74 = load i1, ptr %l36, !tbaa !21
  br i1 %t74, label %bb16, label %bb17
bb16:
  %t75 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t75, 0
  %t79 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr i8, ptr %t80, i64 %t77
  %t82 = load i8, ptr %t81, !tbaa !32
  %t84 = icmp eq i8 %t82, 46
  store i1 %t84, ptr %l42, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb18
bb18:
  %t86 = load i1, ptr %l42, !tbaa !21
  store i1 %t86, ptr %l32, !tbaa !21
  br label %bb19
bb19:
  %t87 = load i1, ptr %l32, !tbaa !21
  br i1 %t87, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l47, !tbaa !21
  br label %bb23
bb21:
  %t88 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t89 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t93 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s2, ptr %v0, { i64, ptr } %t88, { i64, ptr } %t89)
  store i1 %t93, ptr %l51
  br label %bb22
bb22:
  %t94 = load i1, ptr %l51, !tbaa !21
  store i1 %t94, ptr %l47, !tbaa !21
  br label %bb23
bb23:
  %t95 = load i1, ptr %l47, !tbaa !21
  br i1 %t95, label %bb24, label %bb25
bb24:
  %t96 = load ptr, ptr %lp3
  %t97 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t96, i64 %t97)
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb28:
  %t100 = load i64, ptr %l5, !tbaa !24
  %t102 = add i64 %t100, 1
  store i64 %t102, ptr %l5, !tbaa !24
  br label %bb2
bb29:
  %t104 = load ptr, ptr %lp3
  %t105 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t104
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t105, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2egroupOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 16
  %t7 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store { i64, ptr } %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t11 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t9, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d90, i32 0, i32 1) })
  store i1 %t11, ptr %l8
  br label %bb2
bb2:
  %t12 = load i1, ptr %l8, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb6
bb4:
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t15 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t13, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d91, i32 0, i32 1) })
  store i1 %t15, ptr %l11
  br label %bb5
bb5:
  %t16 = load i1, ptr %l11, !tbaa !21
  store i1 %t16, ptr %l9, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l9, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i64 1, ptr %l12, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l12, !tbaa !24
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t18 = load i64, ptr %l12, !tbaa !24
  store i64 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eneed(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l17 = alloca i32
  %l20 = alloca i32
  %l23 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca i32
  %l30 = alloca i1
  %l34 = alloca i1
  %l44 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l17
  br label %bb1
bb1:
  %t11 = load i32, ptr %l17, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l20
  br label %bb2
bb2:
  %t17 = load i32, ptr %l20, !range !{i32 0, i32 33}
  store i32 %t17, ptr %l4
  %t18 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t20 = trunc i64 18 to i32
  %t21 = icmp eq i32 %t18, %t20
  br i1 %t21, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb25
bb5:
  %t23 = load ptr, ptr %l2, !tbaa !29
  store ptr %t23, ptr %l23, !tbaa !29
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t25 = load i32, ptr %l3, !tbaa !23
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t28, ptr %l26
  br label %bb6
bb6:
  %t29 = load ptr, ptr %l23, !tbaa !29
  %t30 = load i32, ptr %l26, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t31, ptr %l27
  br label %bb7
bb7:
  %t32 = load i32, ptr %l27, !range !{i32 0, i32 6}
  %t34 = trunc i64 0 to i32
  %t35 = icmp eq i32 %t32, %t34
  br i1 %t35, label %bb8, label %bb9
bb8:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/emit:Emitter", ptr %t37, i32 0, i32 15
  %t40 = load i32, ptr %l3, !tbaa !23
  %t43 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_Hb3133f486435530b533aaf49461c92b5(ptr %v0, ptr %t39, i32 %t40)
  store i1 %t43, ptr %l34
  br label %bb10
bb9:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb11
bb10:
  %t44 = load i1, ptr %l34, !tbaa !21
  %t45 = xor i1 %t44, true
  store i1 %t45, ptr %l30, !tbaa !21
  br label %bb11
bb11:
  %t47 = load i1, ptr %l30, !tbaa !21
  br i1 %t47, label %bb12, label %bb13
bb12:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/emit:Emitter", ptr %t48, i32 0, i32 15
  %t51 = load i32, ptr %l3, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H64d9be73b6c9bed004c541bdf7f0ca0a(ptr %v0, ptr %t50, i32 %t51, i1 true)
  br label %bb14
bb13:
  br label %bb24
bb14:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/emit:Emitter", ptr %t54, i32 0, i32 14
  %t57 = load i32, ptr %l3, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t56, i32 %t57)
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t61 = load i32, ptr %l3, !tbaa !23
  %t64 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eEmbedded(ptr %v0, ptr %s3, ptr %t60, i32 %t61)
  store { i64, ptr } %t64, ptr %l44
  br label %bb16
bb16:
  %t65 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  %t67 = extractvalue { i64, ptr } %t65, 1
  %t68 = mul i64 %t66, 4
  %t69 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t68)
  call void @llvm.memcpy.p0.p0.i64(ptr %t69, ptr %t67, i64 %t68, i1 false)
  %t70 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  store { i64, ptr } %t71, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t73 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t73, 0
  store i64 %t75, ptr %l7, !tbaa !24
  br label %bb17
bb17:
  %t77 = load i64, ptr %l6, !tbaa !24
  %t78 = load i64, ptr %l7, !tbaa !24
  %t81 = icmp slt i64 %t77, %t78
  %t83 = xor i1 %t81, true
  br i1 %t83, label %bb18, label %bb19
bb18:
  br label %bb23
bb19:
  br label %bb20
bb20:
  %t85 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t85, ptr %l52, !tbaa !27
  %t86 = load i64, ptr %l6, !tbaa !24
  %t88 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr i32, ptr %t89, i64 %t86
  %t91 = load i32, ptr %t90, !tbaa !33
  %t93 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eneed(ptr %v0, ptr %t93, i32 %t91)
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t97 = load i64, ptr %l6, !tbaa !24
  %t99 = add i64 %t97, 1
  store i64 %t99, ptr %l6, !tbaa !24
  br label %bb17
bb23:
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb24:
  br label %bb46
bb25:
  %t101 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t103 = trunc i64 19 to i32
  %t104 = icmp eq i32 %t101, %t103
  br i1 %t104, label %bb26, label %bb27
bb26:
  br label %bb32
bb27:
  %t106 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t108 = trunc i64 22 to i32
  %t109 = icmp eq i32 %t106, %t108
  br i1 %t109, label %bb28, label %bb29
bb28:
  br label %bb32
bb29:
  %t111 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t113 = trunc i64 23 to i32
  %t114 = icmp eq i32 %t111, %t113
  br i1 %t114, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb41
bb32:
  store %olang.scope zeroinitializer, ptr %s7
  %t116 = load ptr, ptr %l2, !tbaa !29
  %t117 = load i32, ptr %l3, !tbaa !23
  %t120 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eEmbedded(ptr %v0, ptr %s7, ptr %t116, i32 %t117)
  store { i64, ptr } %t120, ptr %l67
  br label %bb33
bb33:
  %t121 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t121, 0
  %t123 = extractvalue { i64, ptr } %t121, 1
  %t124 = mul i64 %t122, 4
  %t125 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t124)
  call void @llvm.memcpy.p0.p0.i64(ptr %t125, ptr %t123, i64 %t124, i1 false)
  %t126 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t125, 1
  store { i64, ptr } %t127, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t129 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t129, 0
  store i64 %t131, ptr %l11, !tbaa !24
  br label %bb34
bb34:
  %t133 = load i64, ptr %l10, !tbaa !24
  %t134 = load i64, ptr %l11, !tbaa !24
  %t137 = icmp slt i64 %t133, %t134
  %t139 = xor i1 %t137, true
  br i1 %t139, label %bb35, label %bb36
bb35:
  br label %bb40
bb36:
  br label %bb37
bb37:
  %t141 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t141, ptr %l75, !tbaa !27
  %t142 = load i64, ptr %l10, !tbaa !24
  %t144 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = getelementptr i32, ptr %t145, i64 %t142
  %t147 = load i32, ptr %t146, !tbaa !33
  %t149 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eneed(ptr %v0, ptr %t149, i32 %t147)
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t153 = load i64, ptr %l10, !tbaa !24
  %t155 = add i64 %t153, 1
  store i64 %t155, ptr %l10, !tbaa !24
  br label %bb34
bb40:
  call void @__olang_scope_close(ptr %s7)
  br label %bb46
bb41:
  br i1 true, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_ef8ce655497c6e66_70bdfc36b0b8c4fa)
  unreachable
bb46:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2epartOf(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l11 = alloca i1
  %l12 = alloca i64
  %l13 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i32
  %l24 = alloca { i64, ptr }
  %l26 = alloca i1
  %l27 = alloca i64
  %l29 = alloca i64
  %l34 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sle i64 %t1, 1
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i64 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i64, ptr %l1, !tbaa !24
  %t10 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ealiased(ptr %v0, ptr %t6, i64 %t7)
  store i1 %t10, ptr %l11
  br label %bb4
bb4:
  %t11 = load i1, ptr %l11, !tbaa !21
  br i1 %t11, label %bb5, label %bb6
bb5:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/emit:Emitter", ptr %t12, i32 0, i32 65
  %t15 = load i64, ptr %l1, !tbaa !24
  %t18 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t14, i64 %t15)
  %t19 = extractvalue { i32, i64 } %t18, 1
  %t20 = extractvalue { i32, i64 } %t18, 0
  store i32 %t20, ptr %l18
  %t21 = icmp ne i32 %t20, 0
  br i1 %t21, label %bb8, label %ok.22, !prof !99
ok.22:
  store i64 %t19, ptr %l17
  br label %bb7
bb6:
  %t23 = load i64, ptr %l1, !tbaa !24
  store i64 %t23, ptr %l12, !tbaa !24
  br label %bb11
bb7:
  %t25 = load i64, ptr %l17, !tbaa !24
  store i64 %t25, ptr %l13, !tbaa !24
  br label %bb10
bb8:
  br label %bb9
bb9:
  call void @__olang_ert_req_clear()
  %t26 = load i64, ptr %l1, !tbaa !24
  store i64 %t26, ptr %l13, !tbaa !24
  br label %bb10
bb10:
  %t28 = load i64, ptr %l13, !tbaa !24
  store i64 %t28, ptr %l12, !tbaa !24
  br label %bb11
bb11:
  %t29 = load i64, ptr %l12, !tbaa !24
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/emit:Emitter", ptr %t30, i32 0, i32 16
  %t36 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t32, i64 %t29)
  store { i64, ptr } %t36, ptr %l24
  br label %bb12
bb12:
  %t37 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t37, ptr %l4, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t40 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t38, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d92, i32 0, i32 1) })
  store i1 %t40, ptr %l26
  br label %bb13
bb13:
  %t41 = load i1, ptr %l26, !tbaa !21
  br i1 %t41, label %bb14, label %bb15
bb14:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb17
bb15:
  %t42 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t44 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eHash(ptr %v0, { i64, ptr } %t42)
  store i64 %t44, ptr %l29
  br label %bb16
bb16:
  %t45 = load i64, ptr %l29, !tbaa !24
  store i64 %t45, ptr %l27, !tbaa !24
  br label %bb17
bb17:
  %t46 = load i64, ptr %l2, !tbaa !24
  %t47 = load i64, ptr %l27, !tbaa !24
  %t49 = srem i64 %t47, %t46
  store i64 %t49, ptr %l5, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t53 = icmp slt i64 %t51, 0
  br i1 %t53, label %bb18, label %bb19
bb18:
  %t55 = load i64, ptr %l5, !tbaa !24
  %t56 = load i64, ptr %l2, !tbaa !24
  %t59 = add i64 %t55, %t56
  store i64 %t59, ptr %l34, !tbaa !24
  br label %bb20
bb19:
  %t61 = load i64, ptr %l5, !tbaa !24
  store i64 %t61, ptr %l34, !tbaa !24
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t63 = load i64, ptr %l34, !tbaa !24
  store i64 %t63, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eretires(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l9 = alloca i64
  %l11 = alloca i64
  %l16 = alloca ptr
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 10
  store ptr %t9, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t11 = load i64, ptr %l3, !tbaa !24
  store i64 %t11, ptr %l9, !tbaa !24
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l11
  br label %bb2
bb2:
  %t15 = load i64, ptr %l9, !tbaa !24
  %t16 = load i64, ptr %l11, !tbaa !24
  %t17 = icmp slt i64 %t15, %t16
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t21, i64 %t22)
  store ptr %t25, ptr %l16
  br label %bb6
bb6:
  %t26 = load ptr, ptr %l16, !tbaa !29
  store ptr %t26, ptr %l4, !tbaa !29
  %t27 = load ptr, ptr %l4, !tbaa !29
  %t29 = getelementptr %"compiler/load:Module", ptr %t27, i32 0, i32 4
  %t30 = load i64, ptr %t29, !tbaa !24
  %t34 = icmp eq i64 %t30, %a1
  br i1 %t34, label %bb7, label %bb8
bb7:
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t38 = getelementptr %"compiler/load:Module", ptr %t36, i32 0, i32 5
  %t39 = load i1, ptr %t38, !tbaa !21
  store i1 %t39, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l3, !tbaa !24
  %t43 = add i64 %t41, 1
  store i64 %t43, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntimeItems(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/text:LineIter"
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i32
  %l21 = alloca i1
  %l23 = alloca %"std/prelude/text:StringBuilder"
  %l24 = alloca %"std/prelude/text:StringBuilder"
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l32 = alloca %"std/prelude/text:LineIter"
  %l33 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i32
  %l38 = alloca i1
  %l40 = alloca i1
  %l46 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l51 = alloca { i64, ptr }
  %l52 = alloca %"std/prelude/text:StringBuilder"
  %l53 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l56 = alloca i64
  %l58 = alloca i64
  %l59 = alloca { i64, ptr }
  %l61 = alloca i1
  %l66 = alloca { i64, ptr }
  %l68 = alloca i1
  %l70 = alloca i1
  %l71 = alloca { i64, ptr }
  %l73 = alloca i64
  %l75 = alloca i64
  %l76 = alloca { i64, ptr }
  %l87 = alloca ptr
  %l89 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 56
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/emit:Emitter", ptr %t6, i32 0, i32 56
  store i1 true, ptr %t8, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/emit:Emitter", ptr %t9, i32 0, i32 46
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/emit:Emitter", ptr %t13, i32 0, i32 47
  %t16 = load i1, ptr %t15, !tbaa !21
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/emit:Emitter", ptr %t17, i32 0, i32 6
  %t20 = load i1, ptr %t19, !tbaa !21
  %t24 = call { i32, { i64, ptr } } @compiler_2fruntime_2eText(ptr %v0, ptr %s0, { i64, ptr } %t12, i1 %t16, i1 false, i1 %t20)
  %t25 = extractvalue { i32, { i64, ptr } } %t24, 1
  %t26 = extractvalue { i32, { i64, ptr } } %t24, 0
  store i32 %t26, ptr %l19
  %t27 = icmp ne i32 %t26, 0
  br i1 %t27, label %bb5, label %ok.28, !prof !99
ok.28:
  store { i64, ptr } %t25, ptr %l18
  br label %bb4
bb4:
  %t29 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t29, ptr %l11, !tbaa !27
  br label %bb8
bb5:
  %t30 = load i32, ptr %l19, !tbaa !23
  %t31 = ashr i32 %t30, 16
  %t33 = icmp eq i32 %t31, 1
  store i1 %t33, ptr %l21, !tbaa !21
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s2
  %t34 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2egap(ptr %v0, ptr %s2, ptr %t34, { i64, ptr } { i64 66, ptr getelementptr inbounds (<{ i64, [66 x i8] }>, ptr @.d93, i32 0, i32 1) })
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  %t36 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t36, ptr %l1, !tbaa !27
  %t37 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t37, ptr %l23
  br label %bb9
bb9:
  %t38 = load %"std/prelude/text:StringBuilder", ptr %l23
  store %"std/prelude/text:StringBuilder" %t38, ptr %l2
  %t39 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t39, ptr %l24
  br label %bb10
bb10:
  %t40 = load %"std/prelude/text:StringBuilder", ptr %l24
  store %"std/prelude/text:StringBuilder" %t40, ptr %l3
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d94, i32 0, i32 1) }, ptr %l25, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t41, ptr %l26, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  store i64 %t43, ptr %l27, !tbaa !24
  %t44 = load i64, ptr %l27, !tbaa !24
  %t45 = mul i64 %t44, 1
  %t46 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t45)
  %t47 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  store { i64, ptr } %t48, ptr %l28, !tbaa !27
  %t49 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = load i64, ptr %l27, !tbaa !24
  %t54 = mul i64 %t53, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t50, ptr %t52, i64 %t54, i1 false)
  %t55 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t55, ptr %l4, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s3
  %t56 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t58 = call { i64, ptr } @compiler_2fruntime_2eDecls(ptr %s0, ptr %s3, { i64, ptr } %t56)
  store { i64, ptr } %t58, ptr %l30
  br label %bb11
bb11:
  %t59 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 0
  %t61 = extractvalue { i64, ptr } %t59, 1
  %t62 = mul i64 %t60, 1
  %t63 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t62)
  call void @llvm.memcpy.p0.p0.i64(ptr %t63, ptr %t61, i64 %t62, i1 false)
  %t64 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  %t67 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %s3, ptr %s3, { i64, ptr } %t65)
  store %"std/prelude/text:LineIter" %t67, ptr %l32
  br label %bb12
bb12:
  %t68 = load %"std/prelude/text:LineIter", ptr %l32
  store %"std/prelude/text:LineIter" %t68, ptr %l5
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t70 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %s3, ptr %s3, ptr %l5)
  %t71 = extractvalue { i32, { i64, ptr } } %t70, 1
  %t72 = extractvalue { i32, { i64, ptr } } %t70, 0
  store i32 %t72, ptr %l36
  %t73 = icmp ne i32 %t72, 0
  br i1 %t73, label %bb15, label %ok.74, !prof !99
ok.74:
  store { i64, ptr } %t71, ptr %l35
  br label %bb14
bb14:
  %t75 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t75, ptr %l33, !tbaa !27
  br label %bb17
bb15:
  %t76 = load i32, ptr %l36, !tbaa !23
  %t77 = ashr i32 %t76, 16
  %t79 = icmp eq i32 %t77, 1
  store i1 %t79, ptr %l38, !tbaa !21
  br label %bb16
bb16:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s4)
  br label %bb56
bb17:
  %t80 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t80, ptr %l6, !tbaa !27
  %t81 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t83 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s4, { i64, ptr } %t81, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d95, i32 0, i32 1) })
  store i1 %t83, ptr %l40
  br label %bb18
bb18:
  %t84 = load i1, ptr %l40, !tbaa !21
  %t85 = xor i1 %t84, true
  br i1 %t85, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  %t87 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l3, { i64, ptr } %t87)
  br label %bb21
bb20:
  br label %bb33
bb21:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l3, i8 10)
  br label %bb22
bb22:
  %t91 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t93 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s3, ptr %s5, { i64, ptr } %t91, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d96, i32 0, i32 1) })
  store i1 %t93, ptr %l46
  br label %bb23
bb23:
  %t94 = load i1, ptr %l46, !tbaa !21
  br i1 %t94, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s6
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l47, !tbaa !29
  %t96 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t96, ptr %l48, !tbaa !27
  %t97 = load i64, ptr @G_2ecompiler_2femit_2eHomeShared, !tbaa !24
  store i64 %t97, ptr %l49, !tbaa !24
  %t99 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s6, ptr %l3)
  store { i64, ptr } %t99, ptr %l51
  br label %bb26
bb25:
  br label %bb32
bb26:
  %t100 = load ptr, ptr %l47, !tbaa !29
  %t101 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t102 = load i64, ptr %l49, !tbaa !24
  %t103 = load { i64, ptr }, ptr %l51, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %s0, ptr %s6, ptr %s6, ptr %t100, { i64, ptr } %t101, i64 %t102, { i64, ptr } %t103, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d14, i32 0, i32 1) })
  br label %bb27
bb27:
  %t104 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t104, ptr %l52
  br label %bb28
bb28:
  %t105 = load %"std/prelude/text:StringBuilder", ptr %l52
  store %"std/prelude/text:StringBuilder" %t105, ptr %l3
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d97, i32 0, i32 1) }, ptr %l53, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t106, ptr %l54, !tbaa !27
  %t107 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t107, 0
  %t109 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  store i64 %t110, ptr %l56, !tbaa !24
  %t112 = load i64, ptr %l56, !tbaa !24
  %t113 = icmp eq i64 %t108, %t112
  br i1 %t113, label %bb29, label %bb30
bb29:
  %t115 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = load i64, ptr %l56, !tbaa !24
  %t120 = mul i64 %t119, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t116, ptr %t118, i64 %t120, i1 false)
  br label %bb31
bb30:
  %t121 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t121, 0
  store i64 %t122, ptr %l58, !tbaa !24
  %t123 = load i64, ptr %l58, !tbaa !24
  %t124 = mul i64 %t123, 1
  %t125 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t124)
  %t126 = insertvalue { i64, ptr } undef, i64 %t123, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t125, 1
  store { i64, ptr } %t127, ptr %l59, !tbaa !27
  %t128 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = load i64, ptr %l58, !tbaa !24
  %t133 = mul i64 %t132, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t129, ptr %t131, i64 %t133, i1 false)
  %t134 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t134, ptr %l4, !tbaa !27
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s6)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  br label %bb55
bb33:
  %t135 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t137 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s3, ptr %s4, { i64, ptr } %t135, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d98, i32 0, i32 1) })
  store i1 %t137, ptr %l61
  br label %bb34
bb34:
  %t138 = load i1, ptr %l61, !tbaa !21
  br i1 %t138, label %bb35, label %bb36
bb35:
  %t139 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l2, { i64, ptr } %t139)
  br label %bb37
bb36:
  br label %bb39
bb37:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 10)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s4)
  br label %bb55
bb39:
  %t143 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t145 = call { i64, ptr } @compiler_2femit_2edeclaredSymbol(ptr %s3, ptr %s4, { i64, ptr } %t143)
  store { i64, ptr } %t145, ptr %l66
  br label %bb40
bb40:
  %t146 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t146, ptr %l7, !tbaa !27
  %t147 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t149 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s4, ptr %s4, { i64, ptr } %t147, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d99, i32 0, i32 1) })
  store i1 %t149, ptr %l68
  br label %bb41
bb41:
  %t150 = load i1, ptr %l68, !tbaa !21
  br i1 %t150, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s4)
  br label %bb55
bb43:
  br label %bb44
bb44:
  %t151 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t153 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s3, ptr %s4, { i64, ptr } %t151, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d100, i32 0, i32 1) })
  store i1 %t153, ptr %l70
  br label %bb45
bb45:
  %t154 = load i1, ptr %l70, !tbaa !21
  br i1 %t154, label %bb46, label %bb47
bb46:
  %t155 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t155, ptr %l71, !tbaa !27
  %t156 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t156, 0
  %t158 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t158, 0
  store i64 %t159, ptr %l73, !tbaa !24
  %t161 = load i64, ptr %l73, !tbaa !24
  %t162 = icmp eq i64 %t157, %t161
  br i1 %t162, label %bb48, label %bb49
bb47:
  store %olang.scope zeroinitializer, ptr %s10
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t166 = load i64, ptr @G_2ecompiler_2femit_2eHomeShared, !tbaa !24
  %t167 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t167, 1
  %t170 = extractvalue { i64, ptr } %t167, 0
  %t171 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d101, i32 0, i32 1) }, 1
  %t172 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d101, i32 0, i32 1) }, 0
  %t173 = add i64 %t170, %t172
  %t174 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t173)
  call void @olang_textcopy(ptr %t174, ptr %t169, i64 %t170)
  %t175 = getelementptr i8, ptr %t174, i64 %t170
  call void @olang_textcopy(ptr %t175, ptr %t171, i64 %t172)
  %t176 = insertvalue { i64, ptr } undef, i64 %t173, 0
  %t177 = insertvalue { i64, ptr } %t176, ptr %t174, 1
  %t179 = extractvalue { i64, ptr } %t177, 0
  %t180 = extractvalue { i64, ptr } %t177, 1
  %t181 = mul i64 %t179, 1
  %t182 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t181)
  call void @llvm.memcpy.p0.p0.i64(ptr %t182, ptr %t180, i64 %t181, i1 false)
  %t183 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t182, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %s4, ptr %s10, ptr %s10, ptr %t164, { i64, ptr } %t165, i64 %t166, { i64, ptr } %t184, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d14, i32 0, i32 1) })
  br label %bb53
bb48:
  %t189 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !27
  %t191 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !27
  %t193 = load i64, ptr %l73, !tbaa !24
  %t194 = mul i64 %t193, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t190, ptr %t192, i64 %t194, i1 false)
  br label %bb50
bb49:
  %t195 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t195, 0
  store i64 %t196, ptr %l75, !tbaa !24
  %t197 = load i64, ptr %l75, !tbaa !24
  %t198 = mul i64 %t197, 1
  %t199 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t198)
  %t200 = insertvalue { i64, ptr } undef, i64 %t197, 0
  %t201 = insertvalue { i64, ptr } %t200, ptr %t199, 1
  store { i64, ptr } %t201, ptr %l76, !tbaa !27
  %t202 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !27
  %t204 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !27
  %t206 = load i64, ptr %l75, !tbaa !24
  %t207 = mul i64 %t206, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t203, ptr %t205, i64 %t207, i1 false)
  %t208 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t208, ptr %l4, !tbaa !27
  br label %bb50
bb50:
  %t209 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l3, { i64, ptr } %t209)
  br label %bb51
bb51:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l3, i8 10)
  br label %bb52
bb52:
  br label %bb54
bb53:
  call void @__olang_scope_close(ptr %s10)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s4)
  br label %bb55
bb55:
  br label %bb13
bb56:
  call void @__olang_scope_close(ptr %s3)
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d102, i32 0, i32 1) })
  br label %bb57
bb57:
  %t214 = load ptr, ptr %l0, !tbaa !29
  store ptr %t214, ptr %l87, !tbaa !29
  %t216 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v0, ptr %l2)
  store { i64, ptr } %t216, ptr %l89
  br label %bb58
bb58:
  %t217 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t218 = load ptr, ptr %l87, !tbaa !29
  %t219 = getelementptr %"compiler/emit:Emitter", ptr %t218, i32 0, i32 55
  store { i64, ptr } %t217, ptr %t219, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2esanInit(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 47
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s0, ptr %t8, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d103, i32 0, i32 1) })
  br label %bb4
bb4:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %a1, { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d104, i32 0, i32 1) })
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2esignature(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l10 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca i32
  %l20 = alloca i32
  %l24 = alloca i1
  %l31 = alloca i1
  %l32 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l49 = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l10, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l13
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l10, !tbaa !29
  %t13 = load i32, ptr %l13, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t14, ptr %l14
  br label %bb2
bb2:
  %t15 = load i32, ptr %l14, !range !{i32 0, i32 33}
  %t17 = trunc i64 21 to i32
  %t18 = icmp eq i32 %t15, %t17
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb3, label %bb4
bb3:
  br label %ret
bb4:
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t23 = load i32, ptr %l1, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t26, ptr %l20
  br label %bb6
bb6:
  %t27 = load i32, ptr %l20, !tbaa !23
  store i32 %t27, ptr %l3, !tbaa !23
  %t28 = load i32, ptr %l3, !tbaa !23
  %t29 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t32 = icmp ne i32 %t28, %t29
  br i1 %t32, label %bb7, label %bb8
bb7:
  %t34 = load i32, ptr %l3, !tbaa !23
  %t35 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t38 = icmp ne i32 %t34, %t35
  store i1 %t38, ptr %l24, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb9
bb9:
  %t40 = load i1, ptr %l24, !tbaa !21
  br i1 %t40, label %bb10, label %bb11
bb10:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/emit:Emitter", ptr %t41, i32 0, i32 0
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t45 = load i32, ptr %l3, !tbaa !23
  %t48 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t44, i32 %t45)
  store i1 %t48, ptr %l31
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb13
bb13:
  %t49 = load ptr, ptr %l2, !tbaa !29
  store ptr %t49, ptr %l32, !tbaa !29
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t51 = load i32, ptr %l1, !tbaa !23
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t50, i32 %t51)
  store i32 %t54, ptr %l35
  br label %bb14
bb14:
  %t55 = load ptr, ptr %l32, !tbaa !29
  %t56 = load i32, ptr %l35, !tbaa !23
  %t57 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t55, i32 %t56)
  store { i64, ptr } %t57, ptr %l36
  br label %bb15
bb15:
  %t58 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t58, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t59 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  store i64 %t61, ptr %l6, !tbaa !24
  br label %bb16
bb16:
  %t63 = load i64, ptr %l5, !tbaa !24
  %t64 = load i64, ptr %l6, !tbaa !24
  %t67 = icmp slt i64 %t63, %t64
  %t69 = xor i1 %t67, true
  br i1 %t69, label %bb17, label %bb18
bb17:
  br label %bb22
bb18:
  br label %bb19
bb19:
  %t71 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t71, ptr %l43, !tbaa !27
  %t72 = load i64, ptr %l5, !tbaa !24
  %t74 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr i32, ptr %t75, i64 %t72
  %t77 = load i32, ptr %t76, !tbaa !33
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/emit:Emitter", ptr %t79, i32 0, i32 0
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t86 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t82, i32 %t77)
  store i1 %t86, ptr %l49
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t87 = load i64, ptr %l5, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l5, !tbaa !24
  br label %bb16
bb22:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ethunk(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"std/prelude/text:StringBuilder"
  %l12 = alloca %"std/prelude/text:StringBuilder"
  %l13 = alloca i1
  %l14 = alloca i32
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i8
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l33 = alloca i32
  %l34 = alloca i32
  %l35 = alloca i32
  %l36 = alloca i1
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l48 = alloca i32
  %l53 = alloca i64
  %l57 = alloca i64
  %l60 = alloca i64
  %l63 = alloca i64
  %l69 = alloca { i64, ptr }
  %l70 = alloca ptr
  %l71 = alloca { i64, [2 x i64] }
  %l72 = alloca i32
  %l73 = alloca { i64, ptr }
  %l74 = alloca i64
  %l76 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l79 = alloca %"std/prelude/text:StringBuilder"
  %l83 = alloca %"std/prelude/text:StringBuilder"
  %l86 = alloca i1
  %l90 = alloca i32
  %l94 = alloca i1
  %l98 = alloca i1
  %l101 = alloca i1
  %l110 = alloca i64
  %l113 = alloca i64
  %l152 = alloca ptr
  %l155 = alloca i32
  %l156 = alloca { i64, ptr }
  %l159 = alloca { i64, ptr }
  %l165 = alloca i64
  %l168 = alloca i64
  %l204 = alloca ptr
  %l206 = alloca { i64, ptr }
  %l209 = alloca { i64, ptr }
  %l217 = alloca { i64, ptr }
  %l220 = alloca { i64, ptr }
  %l222 = alloca i1
  %l223 = alloca ptr
  %l224 = alloca { i64, ptr }
  %l226 = alloca { i64, ptr }
  %l229 = alloca ptr
  %l231 = alloca i1
  %l232 = alloca { i64, ptr }
  %l233 = alloca ptr
  %l234 = alloca { i64, ptr }
  %l235 = alloca i64
  %l237 = alloca { i64, ptr }
  %l238 = alloca ptr
  %l239 = alloca { i64, ptr }
  %l240 = alloca { i64, ptr }
  %l242 = alloca { i64, ptr }
  %l247 = alloca i1
  %l248 = alloca i1
  %l251 = alloca i32
  %l254 = alloca i32
  %l260 = alloca ptr
  %l261 = alloca { i64, ptr }
  %l262 = alloca i64
  %l264 = alloca { i64, ptr }
  %l265 = alloca ptr
  %l266 = alloca { i64, [2 x i64] }
  %l267 = alloca i32
  %l268 = alloca %"compiler/source:Span"
  %l269 = alloca %"compiler/mir:Fn"
  %l272 = alloca %"compiler/emit:fnEm"
  %l276 = alloca i32
  %l279 = alloca i32
  %l282 = alloca i32
  %l286 = alloca i1
  %l290 = alloca i1
  %l293 = alloca i1
  %l295 = alloca { i64, ptr }
  %l296 = alloca { i64, ptr }
  %l297 = alloca [1 x i8]
  %l302 = alloca { i64, ptr }
  %l307 = alloca { i64, ptr }
  %l308 = alloca { i64, ptr }
  %l314 = alloca { i64, ptr }
  %l316 = alloca i64
  %l318 = alloca i64
  %l319 = alloca { i64, ptr }
  %l322 = alloca { i64, ptr }
  %l325 = alloca { i64, ptr }
  %l330 = alloca { i64, ptr }
  %l333 = alloca i1
  %l340 = alloca { i64, ptr }
  %l343 = alloca ptr
  %l344 = alloca { i64, ptr }
  %l347 = alloca { i64, ptr }
  %l350 = alloca { i64, ptr }
  %l355 = alloca { i64, ptr }
  %l361 = alloca { i64, ptr }
  %l364 = alloca { i64, ptr }
  %l369 = alloca { i64, ptr }
  %l376 = alloca { i64, ptr }
  %l377 = alloca ptr
  %l378 = alloca { i64, ptr }
  %l379 = alloca ptr
  %l380 = alloca { i64, ptr }
  %l381 = alloca { i64, ptr }
  %l382 = alloca ptr
  %l385 = alloca i32
  %l386 = alloca { i64, ptr }
  %l390 = alloca { i64, ptr }
  %l393 = alloca ptr
  %l396 = alloca { i64, ptr }
  %l398 = alloca ptr
  %l399 = alloca { i64, ptr }
  %l400 = alloca i64
  %l402 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %t19 = alloca { i64, [4 x i64] }, align 8
  %t22 = alloca { i64, [7 x i64] }, align 8
  %t613 = alloca %"compiler/mir:Fn", align 8
  %t619 = alloca %"compiler/emit:fnEm", align 8
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load { i64, [2 x i64] }, ptr %l1
  %t10 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s0, ptr %t6, { i64, [2 x i64] } %t7)
  store { i64, ptr } %t10, ptr %l45
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load { i64, [2 x i64] }, ptr %l1
  %t16 = call i32 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecodeType(ptr %v0, ptr %t12, { i64, [2 x i64] } %t13)
  store i32 %t16, ptr %l48
  br label %bb2
bb2:
  %t17 = load i32, ptr %l48, !tbaa !23
  store i32 %t17, ptr %l5, !tbaa !23
  %t18 = load ptr, ptr %l3, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t19
  %t20 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 0
  store i64 0, ptr %t20
  %t21 = load { i64, [4 x i64] }, ptr %t19
  store { i64, [7 x i64] } zeroinitializer, ptr %t22
  %t23 = getelementptr { i64, [7 x i64] }, ptr %t22, i32 0, i32 0
  store i64 2, ptr %t23
  %t25 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t21, 0
  %t26 = getelementptr { i64, [7 x i64] }, ptr %t22, i32 0, i32 1
  store { { i64, [4 x i64] } } %t25, ptr %t26
  %t27 = load { i64, [7 x i64] }, ptr %t22
  %t28 = load i32, ptr %l2, !tbaa !23
  %t32 = call i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %t18, { i64, [7 x i64] } %t27, i32 %t28)
  store i64 %t32, ptr %l53
  br label %bb3
bb3:
  %t33 = load i64, ptr %l53, !tbaa !24
  store i64 %t33, ptr %l6, !tbaa !24
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load { i64, [2 x i64] }, ptr %l1
  %t36 = load i32, ptr %l5, !tbaa !23
  %t40 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2epassedOf(ptr %v0, ptr %t34, { i64, [2 x i64] } %t35, i32 %t36)
  store i64 %t40, ptr %l57
  br label %bb4
bb4:
  %t41 = load i64, ptr %l57, !tbaa !24
  store i64 %t41, ptr %l7, !tbaa !24
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load { i64, [2 x i64] }, ptr %l1
  %t46 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehomeOf(ptr %v0, ptr %t42, { i64, [2 x i64] } %t43)
  store i64 %t46, ptr %l60
  br label %bb5
bb5:
  %t47 = load i64, ptr @G_2ecompiler_2femit_2eHomeLocal, !tbaa !24
  %t48 = load i64, ptr %l60, !tbaa !24
  %t50 = icmp eq i64 %t48, %t47
  br i1 %t50, label %bb6, label %bb7
bb6:
  %t52 = load i64, ptr @G_2ecompiler_2femit_2eHomeLocal, !tbaa !24
  store i64 %t52, ptr %l63, !tbaa !24
  br label %bb8
bb7:
  %t54 = load i64, ptr @G_2ecompiler_2femit_2eHomeShared, !tbaa !24
  store i64 %t54, ptr %l63, !tbaa !24
  br label %bb8
bb8:
  %t56 = load i64, ptr %l63, !tbaa !24
  store i64 %t56, ptr %l8, !tbaa !24
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t59 = load i32, ptr %l2, !tbaa !23
  %t63 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ethunkSym(ptr %v0, ptr %s0, ptr %s0, ptr %t57, { i64, ptr } %t58, i32 %t59)
  store { i64, ptr } %t63, ptr %l69
  br label %bb9
bb9:
  %t64 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t64, ptr %l9, !tbaa !27
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l70, !tbaa !29
  %t66 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t66, ptr %l71
  %t67 = load i32, ptr %l2, !tbaa !23
  store i32 %t67, ptr %l72, !tbaa !23
  %t68 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t68, ptr %l73, !tbaa !27
  %t69 = load i64, ptr %l6, !tbaa !24
  store i64 %t69, ptr %l74, !tbaa !24
  %t70 = load i64, ptr %l8, !tbaa !24
  %t72 = call { i64, ptr } @compiler_2femit_2elinkFor(ptr %s0, i64 %t70)
  store { i64, ptr } %t72, ptr %l76
  br label %bb10
bb10:
  %t73 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 0
  %t75 = extractvalue { i64, ptr } %t73, 1
  %t76 = mul i64 %t74, 1
  %t77 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t76)
  call void @llvm.memcpy.p0.p0.i64(ptr %t77, ptr %t75, i64 %t76, i1 false)
  %t78 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  %t80 = load ptr, ptr %l70, !tbaa !29
  %t81 = load { i64, [2 x i64] }, ptr %l71
  %t82 = load i32, ptr %l72, !tbaa !23
  %t83 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t84 = load i64, ptr %l74, !tbaa !24
  %t86 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eheader(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t80, { i64, [2 x i64] } %t81, i32 %t82, { i64, ptr } %t83, i64 %t84, i1 true, { i64, ptr } %t79, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d75, i32 0, i32 1) })
  store { i64, ptr } %t86, ptr %l78
  br label %bb11
bb11:
  %t87 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t87, ptr %l10, !tbaa !27
  %t88 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t88, ptr %l79
  br label %bb12
bb12:
  %t89 = load %"std/prelude/text:StringBuilder", ptr %l79
  store %"std/prelude/text:StringBuilder" %t89, ptr %l11
  %t90 = load { i64, ptr }, ptr %l10, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l11, { i64, ptr } %t90)
  br label %bb13
bb13:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l11, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d105, i32 0, i32 1) })
  br label %bb14
bb14:
  %t94 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t94, ptr %l83
  br label %bb15
bb15:
  %t95 = load %"std/prelude/text:StringBuilder", ptr %l83
  store %"std/prelude/text:StringBuilder" %t95, ptr %l12
  store i1 true, ptr %l13, !tbaa !21
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load { i64, [2 x i64] }, ptr %l1
  %t100 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehasEnv(ptr %v0, ptr %t96, { i64, [2 x i64] } %t97)
  store i1 %t100, ptr %l86
  br label %bb16
bb16:
  %t101 = load i1, ptr %l86, !tbaa !21
  br i1 %t101, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %l12, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d106, i32 0, i32 1) })
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i1 false, ptr %l13, !tbaa !21
  call void @__olang_scope_close(ptr %s1)
  br label %bb20
bb20:
  %t103 = load ptr, ptr %l3, !tbaa !29
  %t104 = load i32, ptr %l2, !tbaa !23
  %t107 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t103, i32 %t104)
  store i32 %t107, ptr %l90
  br label %bb21
bb21:
  %t108 = load i32, ptr %l90, !tbaa !23
  store i32 %t108, ptr %l14, !tbaa !23
  %t109 = load i32, ptr %l14, !tbaa !23
  %t110 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t113 = icmp ne i32 %t109, %t110
  br i1 %t113, label %bb22, label %bb23
bb22:
  %t115 = load i32, ptr %l14, !tbaa !23
  %t116 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t119 = icmp ne i32 %t115, %t116
  store i1 %t119, ptr %l94, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l94, !tbaa !21
  br label %bb24
bb24:
  %t121 = load i1, ptr %l94, !tbaa !21
  br i1 %t121, label %bb25, label %bb26
bb25:
  %t122 = load ptr, ptr %l3, !tbaa !29
  %t123 = load i32, ptr %l14, !tbaa !23
  %t126 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %t122, i32 %t123)
  store i1 %t126, ptr %l101
  br label %bb27
bb26:
  store i1 false, ptr %l98, !tbaa !21
  br label %bb28
bb27:
  %t127 = load i1, ptr %l101, !tbaa !21
  store i1 %t127, ptr %l98, !tbaa !21
  br label %bb28
bb28:
  %t128 = load i1, ptr %l98, !tbaa !21
  br i1 %t128, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s2
  %t129 = load i1, ptr %l13, !tbaa !21
  %t131 = xor i1 %t129, true
  br i1 %t131, label %bb31, label %bb32
bb30:
  br label %bb36
bb31:
  store %olang.scope zeroinitializer, ptr %s3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l12, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d107, i32 0, i32 1) })
  br label %bb33
bb32:
  br label %bb34
bb33:
  call void @__olang_scope_close(ptr %s3)
  br label %bb34
bb34:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l12, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d108, i32 0, i32 1) })
  br label %bb35
bb35:
  store i1 false, ptr %l13, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb36
bb36:
  store i64 0, ptr %l15, !tbaa !24
  %t135 = load i64, ptr %l7, !tbaa !24
  store i64 %t135, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t137 = load i64, ptr %l16, !tbaa !24
  %t138 = load i64, ptr %l15, !tbaa !24
  %t141 = icmp sgt i64 %t137, %t138
  br i1 %t141, label %bb37, label %bb38
bb37:
  %t143 = load i64, ptr %l17, !tbaa !24
  %t145 = icmp sgt i64 %t143, 0
  br i1 %t145, label %bb39, label %bb40
bb38:
  store i64 0, ptr %l110, !tbaa !24
  br label %bb42
bb39:
  %t147 = load i64, ptr %l16, !tbaa !24
  %t148 = load i64, ptr %l15, !tbaa !24
  %t151 = sub i64 %t147, %t148
  %t152 = load i64, ptr %l17, !tbaa !24
  %t155 = add i64 %t151, %t152
  %t157 = sub i64 %t155, 1
  %t158 = load i64, ptr %l17, !tbaa !24
  %t161 = sdiv i64 %t157, %t158
  store i64 %t161, ptr %l113, !tbaa !24
  br label %bb41
bb40:
  store i64 0, ptr %l113, !tbaa !24
  br label %bb41
bb41:
  %t163 = load i64, ptr %l113, !tbaa !24
  store i64 %t163, ptr %l110, !tbaa !24
  br label %bb42
bb42:
  %t164 = load i64, ptr %l110, !tbaa !24
  store i64 %t164, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb43
bb43:
  %t165 = load i64, ptr %l19, !tbaa !24
  %t166 = load i64, ptr %l18, !tbaa !24
  %t169 = icmp slt i64 %t165, %t166
  %t171 = xor i1 %t169, true
  br i1 %t171, label %bb44, label %bb45
bb44:
  br label %bb59
bb45:
  br label %bb46
bb46:
  %t173 = load i64, ptr %l15, !tbaa !24
  %t174 = load i64, ptr %l19, !tbaa !24
  %t175 = load i64, ptr %l17, !tbaa !24
  %t178 = mul i64 %t174, %t175
  %t181 = add i64 %t173, %t178
  store i64 %t181, ptr %l20, !tbaa !24
  %t183 = load i1, ptr %l13, !tbaa !21
  %t185 = xor i1 %t183, true
  br i1 %t185, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %l12, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d109, i32 0, i32 1) })
  br label %bb49
bb48:
  br label %bb50
bb49:
  call void @__olang_scope_close(ptr %s6)
  br label %bb50
bb50:
  store i1 false, ptr %l13, !tbaa !21
  %t188 = load i64, ptr %l20, !tbaa !24
  %t189 = load i64, ptr %l6, !tbaa !24
  %t192 = icmp slt i64 %t188, %t189
  br i1 %t192, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s7
  %t194 = load i64, ptr %l20, !tbaa !24
  %t195 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d110, i32 0, i32 1) }, 1
  %t196 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d110, i32 0, i32 1) }, 0
  %t198 = call i64 @__olang_fmt_i64(ptr null, i64 %t194)
  %t199 = add i64 %t196, %t198
  %t200 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t199)
  call void @olang_textcopy(ptr %t200, ptr %t195, i64 %t196)
  %t201 = getelementptr i8, ptr %t200, i64 %t196
  %t202 = call i64 @__olang_fmt_i64(ptr %t201, i64 %t194)
  %t203 = insertvalue { i64, ptr } undef, i64 %t199, 0
  %t204 = insertvalue { i64, ptr } %t203, ptr %t200, 1
  %t206 = extractvalue { i64, ptr } %t204, 0
  %t207 = extractvalue { i64, ptr } %t204, 1
  %t208 = mul i64 %t206, 1
  %t209 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t208)
  call void @llvm.memcpy.p0.p0.i64(ptr %t209, ptr %t207, i64 %t208, i1 false)
  %t210 = insertvalue { i64, ptr } undef, i64 %t206, 0
  %t211 = insertvalue { i64, ptr } %t210, ptr %t209, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %l12, { i64, ptr } %t211)
  br label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s9
  %t214 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %s9, ptr %s9, ptr %t214, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d111, i32 0, i32 1) }, { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d112, i32 0, i32 1) })
  br label %bb54
bb53:
  call void @__olang_scope_close(ptr %s7)
  br label %bb57
bb54:
  %t216 = load i64, ptr %l20, !tbaa !24
  %t217 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d113, i32 0, i32 1) }, 1
  %t218 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d113, i32 0, i32 1) }, 0
  %t220 = call i64 @__olang_fmt_i64(ptr null, i64 %t216)
  %t221 = add i64 %t218, %t220
  %t222 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d114, i32 0, i32 1) }, 1
  %t223 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d114, i32 0, i32 1) }, 0
  %t224 = add i64 %t221, %t223
  %t225 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t224)
  call void @olang_textcopy(ptr %t225, ptr %t217, i64 %t218)
  %t226 = getelementptr i8, ptr %t225, i64 %t218
  %t227 = call i64 @__olang_fmt_i64(ptr %t226, i64 %t216)
  %t228 = getelementptr i8, ptr %t226, i64 %t220
  call void @olang_textcopy(ptr %t228, ptr %t222, i64 %t223)
  %t229 = insertvalue { i64, ptr } undef, i64 %t224, 0
  %t230 = insertvalue { i64, ptr } %t229, ptr %t225, 1
  %t232 = extractvalue { i64, ptr } %t230, 0
  %t233 = extractvalue { i64, ptr } %t230, 1
  %t234 = mul i64 %t232, 1
  %t235 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t234)
  call void @llvm.memcpy.p0.p0.i64(ptr %t235, ptr %t233, i64 %t234, i1 false)
  %t236 = insertvalue { i64, ptr } undef, i64 %t232, 0
  %t237 = insertvalue { i64, ptr } %t236, ptr %t235, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s9, ptr %l11, { i64, ptr } %t237)
  br label %bb55
bb55:
  %t240 = load i64, ptr %l20, !tbaa !24
  %t241 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d115, i32 0, i32 1) }, 1
  %t242 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d115, i32 0, i32 1) }, 0
  %t244 = call i64 @__olang_fmt_i64(ptr null, i64 %t240)
  %t245 = add i64 %t242, %t244
  %t246 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t245)
  call void @olang_textcopy(ptr %t246, ptr %t241, i64 %t242)
  %t247 = getelementptr i8, ptr %t246, i64 %t242
  %t248 = call i64 @__olang_fmt_i64(ptr %t247, i64 %t240)
  %t249 = insertvalue { i64, ptr } undef, i64 %t245, 0
  %t250 = insertvalue { i64, ptr } %t249, ptr %t246, 1
  %t252 = extractvalue { i64, ptr } %t250, 0
  %t253 = extractvalue { i64, ptr } %t250, 1
  %t254 = mul i64 %t252, 1
  %t255 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t254)
  call void @llvm.memcpy.p0.p0.i64(ptr %t255, ptr %t253, i64 %t254, i1 false)
  %t256 = insertvalue { i64, ptr } undef, i64 %t252, 0
  %t257 = insertvalue { i64, ptr } %t256, ptr %t255, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s9, ptr %l12, { i64, ptr } %t257)
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s9)
  br label %bb57
bb57:
  br label %bb58
bb58:
  %t260 = load i64, ptr %l19, !tbaa !24
  %t262 = add i64 %t260, 1
  store i64 %t262, ptr %l19, !tbaa !24
  br label %bb43
bb59:
  %t264 = load ptr, ptr %l3, !tbaa !29
  store ptr %t264, ptr %l152, !tbaa !29
  %t265 = load ptr, ptr %l3, !tbaa !29
  %t266 = load i32, ptr %l2, !tbaa !23
  %t269 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t265, i32 %t266)
  store i32 %t269, ptr %l155
  br label %bb60
bb60:
  %t270 = load ptr, ptr %l152, !tbaa !29
  %t271 = load i32, ptr %l155, !tbaa !23
  %t272 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t270, i32 %t271)
  store { i64, ptr } %t272, ptr %l156
  br label %bb61
bb61:
  %t273 = load { i64, ptr }, ptr %l156, !tbaa !27
  store { i64, ptr } %t273, ptr %l21, !tbaa !27
  %t274 = load ptr, ptr %l3, !tbaa !29
  %t275 = load i32, ptr %l2, !tbaa !23
  %t278 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePassing(ptr %v0, ptr %s0, ptr %t274, i32 %t275)
  store { i64, ptr } %t278, ptr %l159
  br label %bb62
bb62:
  %t279 = load { i64, ptr }, ptr %l159, !tbaa !27
  store { i64, ptr } %t279, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t280 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t282 = extractvalue { i64, ptr } %t280, 0
  store i64 %t282, ptr %l24, !tbaa !24
  store i64 1, ptr %l25, !tbaa !24
  %t284 = load i64, ptr %l24, !tbaa !24
  %t285 = load i64, ptr %l23, !tbaa !24
  %t288 = icmp sgt i64 %t284, %t285
  br i1 %t288, label %bb63, label %bb64
bb63:
  %t290 = load i64, ptr %l25, !tbaa !24
  %t292 = icmp sgt i64 %t290, 0
  br i1 %t292, label %bb65, label %bb66
bb64:
  store i64 0, ptr %l165, !tbaa !24
  br label %bb68
bb65:
  %t294 = load i64, ptr %l24, !tbaa !24
  %t295 = load i64, ptr %l23, !tbaa !24
  %t298 = sub i64 %t294, %t295
  %t299 = load i64, ptr %l25, !tbaa !24
  %t302 = add i64 %t298, %t299
  %t304 = sub i64 %t302, 1
  %t305 = load i64, ptr %l25, !tbaa !24
  %t308 = sdiv i64 %t304, %t305
  store i64 %t308, ptr %l168, !tbaa !24
  br label %bb67
bb66:
  store i64 0, ptr %l168, !tbaa !24
  br label %bb67
bb67:
  %t310 = load i64, ptr %l168, !tbaa !24
  store i64 %t310, ptr %l165, !tbaa !24
  br label %bb68
bb68:
  %t311 = load i64, ptr %l165, !tbaa !24
  store i64 %t311, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb69
bb69:
  %t312 = load i64, ptr %l27, !tbaa !24
  %t313 = load i64, ptr %l26, !tbaa !24
  %t316 = icmp slt i64 %t312, %t313
  %t318 = xor i1 %t316, true
  br i1 %t318, label %bb70, label %bb71
bb70:
  br label %bb95
bb71:
  br label %bb72
bb72:
  %t320 = load i64, ptr %l23, !tbaa !24
  %t321 = load i64, ptr %l27, !tbaa !24
  %t322 = load i64, ptr %l25, !tbaa !24
  %t325 = mul i64 %t321, %t322
  %t328 = add i64 %t320, %t325
  store i64 %t328, ptr %l28, !tbaa !24
  %t330 = load i1, ptr %l13, !tbaa !21
  %t332 = xor i1 %t330, true
  br i1 %t332, label %bb73, label %bb74
bb73:
  store %olang.scope zeroinitializer, ptr %s15
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s15, ptr %l12, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d116, i32 0, i32 1) })
  br label %bb75
bb74:
  br label %bb76
bb75:
  call void @__olang_scope_close(ptr %s15)
  br label %bb76
bb76:
  store i1 false, ptr %l13, !tbaa !21
  %t335 = load i64, ptr %l28, !tbaa !24
  %t337 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t338 = load ptr, ptr %t337, !tbaa !27
  %t339 = getelementptr i8, ptr %t338, i64 %t335
  %t340 = load i8, ptr %t339, !tbaa !32
  store i8 %t340, ptr %l29, !tbaa !22
  %t342 = load i8, ptr %l29, !tbaa !22
  %t344 = icmp eq i8 %t342, 109
  br i1 %t344, label %bb77, label %bb78
bb77:
  br label %bb79
bb78:
  br label %bb81
bb79:
  store %olang.scope zeroinitializer, ptr %s16
  %t346 = load i64, ptr %l28, !tbaa !24
  %t347 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d117, i32 0, i32 1) }, 1
  %t348 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d117, i32 0, i32 1) }, 0
  %t350 = call i64 @__olang_fmt_i64(ptr null, i64 %t346)
  %t351 = add i64 %t348, %t350
  %t352 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t351)
  call void @olang_textcopy(ptr %t352, ptr %t347, i64 %t348)
  %t353 = getelementptr i8, ptr %t352, i64 %t348
  %t354 = call i64 @__olang_fmt_i64(ptr %t353, i64 %t346)
  %t355 = insertvalue { i64, ptr } undef, i64 %t351, 0
  %t356 = insertvalue { i64, ptr } %t355, ptr %t352, 1
  %t358 = extractvalue { i64, ptr } %t356, 0
  %t359 = extractvalue { i64, ptr } %t356, 1
  %t360 = mul i64 %t358, 1
  %t361 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t360)
  call void @llvm.memcpy.p0.p0.i64(ptr %t361, ptr %t359, i64 %t360, i1 false)
  %t362 = insertvalue { i64, ptr } undef, i64 %t358, 0
  %t363 = insertvalue { i64, ptr } %t362, ptr %t361, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s16, ptr %l12, { i64, ptr } %t363)
  br label %bb80
bb80:
  call void @__olang_scope_close(ptr %s16)
  br label %bb93
bb81:
  %t366 = load i8, ptr %l29, !tbaa !22
  %t368 = icmp eq i8 %t366, 115
  br i1 %t368, label %bb82, label %bb83
bb82:
  br label %bb84
bb83:
  br label %bb86
bb84:
  store %olang.scope zeroinitializer, ptr %s18
  %t370 = load i64, ptr %l28, !tbaa !24
  %t371 = load i64, ptr %l28, !tbaa !24
  %t372 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d118, i32 0, i32 1) }, 1
  %t373 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d118, i32 0, i32 1) }, 0
  %t375 = call i64 @__olang_fmt_i64(ptr null, i64 %t370)
  %t376 = add i64 %t373, %t375
  %t377 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d119, i32 0, i32 1) }, 1
  %t378 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d119, i32 0, i32 1) }, 0
  %t379 = add i64 %t376, %t378
  %t381 = call i64 @__olang_fmt_i64(ptr null, i64 %t371)
  %t382 = add i64 %t379, %t381
  %t383 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d120, i32 0, i32 1) }, 1
  %t384 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d120, i32 0, i32 1) }, 0
  %t385 = add i64 %t382, %t384
  %t386 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t385)
  call void @olang_textcopy(ptr %t386, ptr %t372, i64 %t373)
  %t387 = getelementptr i8, ptr %t386, i64 %t373
  %t388 = call i64 @__olang_fmt_i64(ptr %t387, i64 %t370)
  %t389 = getelementptr i8, ptr %t387, i64 %t375
  call void @olang_textcopy(ptr %t389, ptr %t377, i64 %t378)
  %t390 = getelementptr i8, ptr %t389, i64 %t378
  %t391 = call i64 @__olang_fmt_i64(ptr %t390, i64 %t371)
  %t392 = getelementptr i8, ptr %t390, i64 %t381
  call void @olang_textcopy(ptr %t392, ptr %t383, i64 %t384)
  %t393 = insertvalue { i64, ptr } undef, i64 %t385, 0
  %t394 = insertvalue { i64, ptr } %t393, ptr %t386, 1
  %t396 = extractvalue { i64, ptr } %t394, 0
  %t397 = extractvalue { i64, ptr } %t394, 1
  %t398 = mul i64 %t396, 1
  %t399 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t398)
  call void @llvm.memcpy.p0.p0.i64(ptr %t399, ptr %t397, i64 %t398, i1 false)
  %t400 = insertvalue { i64, ptr } undef, i64 %t396, 0
  %t401 = insertvalue { i64, ptr } %t400, ptr %t399, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s18, ptr %l12, { i64, ptr } %t401)
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s18)
  br label %bb93
bb86:
  br i1 true, label %bb87, label %bb88
bb87:
  br label %bb89
bb88:
  br label %bb92
bb89:
  store %olang.scope zeroinitializer, ptr %s20
  store ptr %l12, ptr %l204, !tbaa !29
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t405 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t405, ptr %l206, !tbaa !27
  %t406 = load i64, ptr %l28, !tbaa !24
  %t408 = getelementptr { i64, ptr }, ptr %l206, i32 0, i32 1
  %t409 = load ptr, ptr %t408, !tbaa !27
  %t410 = getelementptr i32, ptr %t409, i64 %t406
  %t411 = load i32, ptr %t410, !tbaa !33
  %t414 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s20, ptr %t404, i32 %t411)
  store { i64, ptr } %t414, ptr %l209
  br label %bb90
bb90:
  %t415 = load i64, ptr %l28, !tbaa !24
  %t416 = load { i64, ptr }, ptr %l209, !tbaa !27
  %t417 = extractvalue { i64, ptr } %t416, 1
  %t418 = extractvalue { i64, ptr } %t416, 0
  %t419 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d121, i32 0, i32 1) }, 1
  %t420 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d121, i32 0, i32 1) }, 0
  %t421 = add i64 %t418, %t420
  %t423 = call i64 @__olang_fmt_i64(ptr null, i64 %t415)
  %t424 = add i64 %t421, %t423
  %t425 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t424)
  call void @olang_textcopy(ptr %t425, ptr %t417, i64 %t418)
  %t426 = getelementptr i8, ptr %t425, i64 %t418
  call void @olang_textcopy(ptr %t426, ptr %t419, i64 %t420)
  %t427 = getelementptr i8, ptr %t426, i64 %t420
  %t428 = call i64 @__olang_fmt_i64(ptr %t427, i64 %t415)
  %t429 = insertvalue { i64, ptr } undef, i64 %t424, 0
  %t430 = insertvalue { i64, ptr } %t429, ptr %t425, 1
  %t432 = extractvalue { i64, ptr } %t430, 0
  %t433 = extractvalue { i64, ptr } %t430, 1
  %t434 = mul i64 %t432, 1
  %t435 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t434)
  call void @llvm.memcpy.p0.p0.i64(ptr %t435, ptr %t433, i64 %t434, i1 false)
  %t436 = insertvalue { i64, ptr } undef, i64 %t432, 0
  %t437 = insertvalue { i64, ptr } %t436, ptr %t435, 1
  %t438 = load ptr, ptr %l204, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s20, ptr %t438, { i64, ptr } %t437)
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s20)
  br label %bb93
bb92:
  call void @__olang_check_failed(ptr @olang_loc_afcb0129fb824946_88799b4b9f9e7b3a)
  unreachable
bb93:
  br label %bb94
bb94:
  %t440 = load i64, ptr %l27, !tbaa !24
  %t442 = add i64 %t440, 1
  store i64 %t442, ptr %l27, !tbaa !24
  br label %bb69
bb95:
  %t444 = load ptr, ptr %l3, !tbaa !29
  %t445 = load i32, ptr %l5, !tbaa !23
  %t448 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %s0, ptr %t444, i32 %t445)
  store { i64, ptr } %t448, ptr %l217
  br label %bb96
bb96:
  %t449 = load { i64, ptr }, ptr %l217, !tbaa !27
  store { i64, ptr } %t449, ptr %l30, !tbaa !27
  %t450 = load ptr, ptr %l3, !tbaa !29
  %t451 = load i32, ptr %l2, !tbaa !23
  %t454 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %s0, ptr %t450, i32 %t451)
  store { i64, ptr } %t454, ptr %l220
  br label %bb97
bb97:
  %t455 = load { i64, ptr }, ptr %l220, !tbaa !27
  store { i64, ptr } %t455, ptr %l31, !tbaa !27
  %t456 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t458 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t456, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d122, i32 0, i32 1) })
  store i1 %t458, ptr %l222
  br label %bb98
bb98:
  %t459 = load i1, ptr %l222, !tbaa !21
  br i1 %t459, label %bb99, label %bb100
bb99:
  store %olang.scope zeroinitializer, ptr %s23
  store ptr %l11, ptr %l223, !tbaa !29
  %t460 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t460, ptr %l224, !tbaa !27
  %t462 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s23, ptr %l12)
  store { i64, ptr } %t462, ptr %l226
  br label %bb101
bb100:
  br label %bb110
bb101:
  %t463 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d123, i32 0, i32 1) }, 1
  %t464 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d123, i32 0, i32 1) }, 0
  %t465 = load { i64, ptr }, ptr %l224, !tbaa !27
  %t466 = extractvalue { i64, ptr } %t465, 1
  %t467 = extractvalue { i64, ptr } %t465, 0
  %t468 = add i64 %t464, %t467
  %t469 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d124, i32 0, i32 1) }, 1
  %t470 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d124, i32 0, i32 1) }, 0
  %t471 = add i64 %t468, %t470
  %t472 = load { i64, ptr }, ptr %l226, !tbaa !27
  %t473 = extractvalue { i64, ptr } %t472, 1
  %t474 = extractvalue { i64, ptr } %t472, 0
  %t475 = add i64 %t471, %t474
  %t476 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d125, i32 0, i32 1) }, 1
  %t477 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d125, i32 0, i32 1) }, 0
  %t478 = add i64 %t475, %t477
  %t479 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t478)
  call void @olang_textcopy(ptr %t479, ptr %t463, i64 %t464)
  %t480 = getelementptr i8, ptr %t479, i64 %t464
  call void @olang_textcopy(ptr %t480, ptr %t466, i64 %t467)
  %t481 = getelementptr i8, ptr %t480, i64 %t467
  call void @olang_textcopy(ptr %t481, ptr %t469, i64 %t470)
  %t482 = getelementptr i8, ptr %t481, i64 %t470
  call void @olang_textcopy(ptr %t482, ptr %t473, i64 %t474)
  %t483 = getelementptr i8, ptr %t482, i64 %t474
  call void @olang_textcopy(ptr %t483, ptr %t476, i64 %t477)
  %t484 = insertvalue { i64, ptr } undef, i64 %t478, 0
  %t485 = insertvalue { i64, ptr } %t484, ptr %t479, 1
  %t487 = extractvalue { i64, ptr } %t485, 0
  %t488 = extractvalue { i64, ptr } %t485, 1
  %t489 = mul i64 %t487, 1
  %t490 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t489)
  call void @llvm.memcpy.p0.p0.i64(ptr %t490, ptr %t488, i64 %t489, i1 false)
  %t491 = insertvalue { i64, ptr } undef, i64 %t487, 0
  %t492 = insertvalue { i64, ptr } %t491, ptr %t490, 1
  %t493 = load ptr, ptr %l223, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %t493, { i64, ptr } %t492)
  br label %bb102
bb102:
  store ptr %l11, ptr %l229, !tbaa !29
  %t495 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t497 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s23, { i64, ptr } %t495, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d126, i32 0, i32 1) })
  store i1 %t497, ptr %l231
  br label %bb103
bb103:
  %t498 = load i1, ptr %l231, !tbaa !21
  br i1 %t498, label %bb104, label %bb105
bb104:
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d127, i32 0, i32 1) }, ptr %l232, !tbaa !27
  br label %bb106
bb105:
  store { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d128, i32 0, i32 1) }, ptr %l232, !tbaa !27
  br label %bb106
bb106:
  %t499 = load ptr, ptr %l229, !tbaa !29
  %t500 = load { i64, ptr }, ptr %l232, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %t499, { i64, ptr } %t500)
  br label %bb107
bb107:
  %t501 = load ptr, ptr %l0, !tbaa !29
  store ptr %t501, ptr %l233, !tbaa !29
  %t502 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t502, ptr %l234, !tbaa !27
  %t503 = load i64, ptr %l8, !tbaa !24
  store i64 %t503, ptr %l235, !tbaa !24
  %t505 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s23, ptr %l11)
  store { i64, ptr } %t505, ptr %l237
  br label %bb108
bb108:
  %t506 = load ptr, ptr %l233, !tbaa !29
  %t507 = load { i64, ptr }, ptr %l234, !tbaa !27
  %t508 = load i64, ptr %l235, !tbaa !24
  %t509 = load { i64, ptr }, ptr %l237, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %s0, ptr %s23, ptr %s23, ptr %t506, { i64, ptr } %t507, i64 %t508, { i64, ptr } %t509, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d14, i32 0, i32 1) })
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb110:
  store ptr %l11, ptr %l238, !tbaa !29
  %t510 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t510, ptr %l239, !tbaa !27
  %t511 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t511, ptr %l240, !tbaa !27
  %t513 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l12)
  store { i64, ptr } %t513, ptr %l242
  br label %bb111
bb111:
  %t514 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d129, i32 0, i32 1) }, 1
  %t515 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d129, i32 0, i32 1) }, 0
  %t516 = load { i64, ptr }, ptr %l239, !tbaa !27
  %t517 = extractvalue { i64, ptr } %t516, 1
  %t518 = extractvalue { i64, ptr } %t516, 0
  %t519 = add i64 %t515, %t518
  %t520 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d130, i32 0, i32 1) }, 1
  %t521 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d130, i32 0, i32 1) }, 0
  %t522 = add i64 %t519, %t521
  %t523 = load { i64, ptr }, ptr %l240, !tbaa !27
  %t524 = extractvalue { i64, ptr } %t523, 1
  %t525 = extractvalue { i64, ptr } %t523, 0
  %t526 = add i64 %t522, %t525
  %t527 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d131, i32 0, i32 1) }, 1
  %t528 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d131, i32 0, i32 1) }, 0
  %t529 = add i64 %t526, %t528
  %t530 = load { i64, ptr }, ptr %l242, !tbaa !27
  %t531 = extractvalue { i64, ptr } %t530, 1
  %t532 = extractvalue { i64, ptr } %t530, 0
  %t533 = add i64 %t529, %t532
  %t534 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d132, i32 0, i32 1) }, 1
  %t535 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d132, i32 0, i32 1) }, 0
  %t536 = add i64 %t533, %t535
  %t537 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t536)
  call void @olang_textcopy(ptr %t537, ptr %t514, i64 %t515)
  %t538 = getelementptr i8, ptr %t537, i64 %t515
  call void @olang_textcopy(ptr %t538, ptr %t517, i64 %t518)
  %t539 = getelementptr i8, ptr %t538, i64 %t518
  call void @olang_textcopy(ptr %t539, ptr %t520, i64 %t521)
  %t540 = getelementptr i8, ptr %t539, i64 %t521
  call void @olang_textcopy(ptr %t540, ptr %t524, i64 %t525)
  %t541 = getelementptr i8, ptr %t540, i64 %t525
  call void @olang_textcopy(ptr %t541, ptr %t527, i64 %t528)
  %t542 = getelementptr i8, ptr %t541, i64 %t528
  call void @olang_textcopy(ptr %t542, ptr %t531, i64 %t532)
  %t543 = getelementptr i8, ptr %t542, i64 %t532
  call void @olang_textcopy(ptr %t543, ptr %t534, i64 %t535)
  %t544 = insertvalue { i64, ptr } undef, i64 %t536, 0
  %t545 = insertvalue { i64, ptr } %t544, ptr %t537, 1
  %t547 = extractvalue { i64, ptr } %t545, 0
  %t548 = extractvalue { i64, ptr } %t545, 1
  %t549 = mul i64 %t547, 1
  %t550 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t549)
  call void @llvm.memcpy.p0.p0.i64(ptr %t550, ptr %t548, i64 %t549, i1 false)
  %t551 = insertvalue { i64, ptr } undef, i64 %t547, 0
  %t552 = insertvalue { i64, ptr } %t551, ptr %t550, 1
  %t553 = load ptr, ptr %l238, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t553, { i64, ptr } %t552)
  br label %bb112
bb112:
  %t555 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t556 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t559 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t555, { i64, ptr } %t556)
  store i1 %t559, ptr %l247
  br label %bb113
bb113:
  %t560 = load i1, ptr %l247, !tbaa !21
  br i1 %t560, label %bb114, label %bb115
bb114:
  %t561 = load ptr, ptr %l3, !tbaa !29
  %t562 = load i32, ptr %l5, !tbaa !23
  %t565 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t561, i32 %t562)
  store i32 %t565, ptr %l251
  br label %bb116
bb115:
  store i1 false, ptr %l248, !tbaa !21
  br label %bb118
bb116:
  %t566 = load ptr, ptr %l3, !tbaa !29
  %t567 = load i32, ptr %l2, !tbaa !23
  %t570 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t566, i32 %t567)
  store i32 %t570, ptr %l254
  br label %bb117
bb117:
  %t571 = load i32, ptr %l251, !tbaa !23
  %t572 = load i32, ptr %l254, !tbaa !23
  %t573 = icmp eq i32 %t571, %t572
  store i1 %t573, ptr %l248, !tbaa !21
  br label %bb118
bb118:
  %t575 = load i1, ptr %l248, !tbaa !21
  br i1 %t575, label %bb119, label %bb120
bb119:
  store %olang.scope zeroinitializer, ptr %s26
  %t576 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t577 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d133, i32 0, i32 1) }, 1
  %t578 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d133, i32 0, i32 1) }, 0
  %t580 = extractvalue { i64, ptr } %t576, 1
  %t581 = extractvalue { i64, ptr } %t576, 0
  %t582 = add i64 %t578, %t581
  %t583 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d134, i32 0, i32 1) }, 1
  %t584 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d134, i32 0, i32 1) }, 0
  %t585 = add i64 %t582, %t584
  %t586 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t585)
  call void @olang_textcopy(ptr %t586, ptr %t577, i64 %t578)
  %t587 = getelementptr i8, ptr %t586, i64 %t578
  call void @olang_textcopy(ptr %t587, ptr %t580, i64 %t581)
  %t588 = getelementptr i8, ptr %t587, i64 %t581
  call void @olang_textcopy(ptr %t588, ptr %t583, i64 %t584)
  %t589 = insertvalue { i64, ptr } undef, i64 %t585, 0
  %t590 = insertvalue { i64, ptr } %t589, ptr %t586, 1
  %t592 = extractvalue { i64, ptr } %t590, 0
  %t593 = extractvalue { i64, ptr } %t590, 1
  %t594 = mul i64 %t592, 1
  %t595 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t594)
  call void @llvm.memcpy.p0.p0.i64(ptr %t595, ptr %t593, i64 %t594, i1 false)
  %t596 = insertvalue { i64, ptr } undef, i64 %t592, 0
  %t597 = insertvalue { i64, ptr } %t596, ptr %t595, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s26, ptr %l11, { i64, ptr } %t597)
  br label %bb121
bb120:
  br label %bb124
bb121:
  %t600 = load ptr, ptr %l0, !tbaa !29
  store ptr %t600, ptr %l260, !tbaa !29
  %t601 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t601, ptr %l261, !tbaa !27
  %t602 = load i64, ptr %l8, !tbaa !24
  store i64 %t602, ptr %l262, !tbaa !24
  %t604 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s26, ptr %l11)
  store { i64, ptr } %t604, ptr %l264
  br label %bb122
bb122:
  %t605 = load ptr, ptr %l260, !tbaa !29
  %t606 = load { i64, ptr }, ptr %l261, !tbaa !27
  %t607 = load i64, ptr %l262, !tbaa !24
  %t608 = load { i64, ptr }, ptr %l264, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %s0, ptr %s26, ptr %s26, ptr %t605, { i64, ptr } %t606, i64 %t607, { i64, ptr } %t608, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d14, i32 0, i32 1) })
  br label %bb123
bb123:
  call void @__olang_scope_close(ptr %s26)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb124:
  %t609 = load ptr, ptr %l0, !tbaa !29
  store ptr %t609, ptr %l265, !tbaa !29
  %t610 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t610, ptr %l266
  %t611 = load i32, ptr %l2, !tbaa !23
  store i32 %t611, ptr %l267, !tbaa !23
  %t612 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t612, ptr %l268
  br label %bb125
bb125:
  %t614 = load { i64, [2 x i64] }, ptr %l266
  %t615 = load i32, ptr %l267, !tbaa !23
  %t616 = load %"compiler/source:Span", ptr %l268
  call void @compiler_2fmir_3aFn_2ector(ptr %t613, ptr %v0, { i64, [2 x i64] } %t614, i32 %t615, i64 0, %"compiler/source:Span" %t616)
  call void @llvm.memmove.p0.p0.i64(ptr %l269, ptr %t613, i64 800, i1 false)
  br label %bb126
bb126:
  %t617 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 800, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t617, ptr %l269, i64 800, i1 false)
  %t618 = load { i64, [2 x i64] }, ptr %l1
  %t620 = load ptr, ptr %l265, !tbaa !29
  call void @compiler_2femit_3afnEm_2ector(ptr %t619, ptr %v0, ptr %v0, ptr %v0, ptr %t620, ptr %t617, { i64, [2 x i64] } %t618)
  call void @llvm.memmove.p0.p0.i64(ptr %l272, ptr %t619, i64 960, i1 false)
  br label %bb127
bb127:
  %t623 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 960, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t623, ptr %l272, i64 960, i1 false)
  store ptr %t623, ptr %l32, !tbaa !29
  %t625 = load ptr, ptr %l3, !tbaa !29
  %t626 = load i32, ptr %l5, !tbaa !23
  %t629 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t625, i32 %t626)
  store i32 %t629, ptr %l276
  br label %bb128
bb128:
  %t630 = load i32, ptr %l276, !tbaa !23
  store i32 %t630, ptr %l33, !tbaa !23
  %t631 = load ptr, ptr %l3, !tbaa !29
  %t632 = load i32, ptr %l2, !tbaa !23
  %t635 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t631, i32 %t632)
  store i32 %t635, ptr %l279
  br label %bb129
bb129:
  %t636 = load i32, ptr %l279, !tbaa !23
  store i32 %t636, ptr %l34, !tbaa !23
  %t637 = load ptr, ptr %l3, !tbaa !29
  %t638 = load i32, ptr %l5, !tbaa !23
  %t641 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t637, i32 %t638)
  store i32 %t641, ptr %l282
  br label %bb130
bb130:
  %t642 = load i32, ptr %l282, !tbaa !23
  store i32 %t642, ptr %l35, !tbaa !23
  %t643 = load i32, ptr %l35, !tbaa !23
  %t644 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t647 = icmp ne i32 %t643, %t644
  br i1 %t647, label %bb131, label %bb132
bb131:
  %t649 = load i32, ptr %l35, !tbaa !23
  %t650 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t653 = icmp ne i32 %t649, %t650
  store i1 %t653, ptr %l286, !tbaa !21
  br label %bb133
bb132:
  store i1 false, ptr %l286, !tbaa !21
  br label %bb133
bb133:
  %t655 = load i1, ptr %l286, !tbaa !21
  br i1 %t655, label %bb134, label %bb135
bb134:
  %t656 = load ptr, ptr %l3, !tbaa !29
  %t657 = load i32, ptr %l35, !tbaa !23
  %t660 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %t656, i32 %t657)
  store i1 %t660, ptr %l293
  br label %bb136
bb135:
  store i1 false, ptr %l290, !tbaa !21
  br label %bb137
bb136:
  %t661 = load i1, ptr %l293, !tbaa !21
  %t662 = xor i1 %t661, true
  store i1 %t662, ptr %l290, !tbaa !21
  br label %bb137
bb137:
  %t664 = load i1, ptr %l290, !tbaa !21
  store i1 %t664, ptr %l36, !tbaa !21
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d135, i32 0, i32 1) }, ptr %l295, !tbaa !27
  %t665 = load { i64, ptr }, ptr %l295, !tbaa !27
  store { i64, ptr } %t665, ptr %l296, !tbaa !27
  %t666 = getelementptr { i64, ptr }, ptr %l296, i32 0, i32 1
  %t667 = load ptr, ptr %t666, !tbaa !27
  %t668 = mul i64 1, 1
  call void @llvm.memmove.p0.p0.i64(ptr %l297, ptr %t667, i64 %t668, i1 false)
  %t670 = insertvalue { i64, ptr } undef, i64 1, 0
  %t671 = insertvalue { i64, ptr } %t670, ptr %l297, 1
  store { i64, ptr } %t671, ptr %l37, !tbaa !27
  %t673 = load ptr, ptr %l3, !tbaa !29
  %t674 = load i32, ptr %l33, !tbaa !23
  %t677 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t673, i32 %t674)
  store { i64, ptr } %t677, ptr %l302
  br label %bb138
bb138:
  %t678 = load { i64, ptr }, ptr %l302, !tbaa !27
  %t679 = extractvalue { i64, ptr } %t678, 0
  %t681 = icmp sgt i64 %t679, 0
  br i1 %t681, label %bb139, label %bb140
bb139:
  %t683 = load i1, ptr %l36, !tbaa !21
  %t685 = xor i1 %t683, true
  br i1 %t685, label %bb141, label %bb142
bb140:
  br label %bb148
bb141:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d136, i32 0, i32 1) }, ptr %l308, !tbaa !27
  %t687 = load { i64, ptr }, ptr %l308, !tbaa !27
  store { i64, ptr } %t687, ptr %l307, !tbaa !27
  br label %bb144
bb142:
  %t689 = load ptr, ptr %l32, !tbaa !29
  %t690 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t691 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d137, i32 0, i32 1) }, 1
  %t692 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d137, i32 0, i32 1) }, 0
  %t694 = extractvalue { i64, ptr } %t690, 1
  %t695 = extractvalue { i64, ptr } %t690, 0
  %t696 = add i64 %t692, %t695
  %t697 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d138, i32 0, i32 1) }, 1
  %t698 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d138, i32 0, i32 1) }, 0
  %t699 = add i64 %t696, %t698
  %t700 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t699)
  call void @olang_textcopy(ptr %t700, ptr %t691, i64 %t692)
  %t701 = getelementptr i8, ptr %t700, i64 %t692
  call void @olang_textcopy(ptr %t701, ptr %t694, i64 %t695)
  %t702 = getelementptr i8, ptr %t701, i64 %t695
  call void @olang_textcopy(ptr %t702, ptr %t697, i64 %t698)
  %t703 = insertvalue { i64, ptr } undef, i64 %t699, 0
  %t704 = insertvalue { i64, ptr } %t703, ptr %t700, 1
  %t706 = extractvalue { i64, ptr } %t704, 0
  %t707 = extractvalue { i64, ptr } %t704, 1
  %t708 = mul i64 %t706, 1
  %t709 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t708)
  call void @llvm.memcpy.p0.p0.i64(ptr %t709, ptr %t707, i64 %t708, i1 false)
  %t710 = insertvalue { i64, ptr } undef, i64 %t706, 0
  %t711 = insertvalue { i64, ptr } %t710, ptr %t709, 1
  %t714 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t689, { i64, ptr } %t711)
  store { i64, ptr } %t714, ptr %l314
  br label %bb143
bb143:
  %t715 = load { i64, ptr }, ptr %l314, !tbaa !27
  store { i64, ptr } %t715, ptr %l307, !tbaa !27
  br label %bb144
bb144:
  %t716 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t717 = extractvalue { i64, ptr } %t716, 0
  %t718 = load { i64, ptr }, ptr %l307, !tbaa !27
  %t719 = extractvalue { i64, ptr } %t718, 0
  store i64 %t719, ptr %l316, !tbaa !24
  %t721 = load i64, ptr %l316, !tbaa !24
  %t722 = icmp eq i64 %t717, %t721
  br i1 %t722, label %bb145, label %bb146
bb145:
  %t724 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t725 = load ptr, ptr %t724, !tbaa !27
  %t726 = getelementptr { i64, ptr }, ptr %l307, i32 0, i32 1
  %t727 = load ptr, ptr %t726, !tbaa !27
  %t728 = load i64, ptr %l316, !tbaa !24
  %t729 = mul i64 %t728, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t725, ptr %t727, i64 %t729, i1 false)
  br label %bb147
bb146:
  %t730 = load { i64, ptr }, ptr %l307, !tbaa !27
  %t731 = extractvalue { i64, ptr } %t730, 0
  store i64 %t731, ptr %l318, !tbaa !24
  %t732 = load i64, ptr %l318, !tbaa !24
  %t733 = mul i64 %t732, 1
  %t734 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t733)
  %t735 = insertvalue { i64, ptr } undef, i64 %t732, 0
  %t736 = insertvalue { i64, ptr } %t735, ptr %t734, 1
  store { i64, ptr } %t736, ptr %l319, !tbaa !27
  %t737 = getelementptr { i64, ptr }, ptr %l319, i32 0, i32 1
  %t738 = load ptr, ptr %t737, !tbaa !27
  %t739 = getelementptr { i64, ptr }, ptr %l307, i32 0, i32 1
  %t740 = load ptr, ptr %t739, !tbaa !27
  %t741 = load i64, ptr %l318, !tbaa !24
  %t742 = mul i64 %t741, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t738, ptr %t740, i64 %t742, i1 false)
  %t743 = load { i64, ptr }, ptr %l319, !tbaa !27
  store { i64, ptr } %t743, ptr %l37, !tbaa !27
  br label %bb147
bb147:
  br label %bb148
bb148:
  %t744 = load ptr, ptr %l3, !tbaa !29
  %t745 = load i32, ptr %l33, !tbaa !23
  %t748 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t744, i32 %t745)
  store { i64, ptr } %t748, ptr %l322
  br label %bb149
bb149:
  %t749 = load { i64, ptr }, ptr %l322, !tbaa !27
  %t750 = extractvalue { i64, ptr } %t749, 0
  %t752 = icmp sgt i64 %t750, 0
  br i1 %t752, label %bb150, label %bb151
bb150:
  %t754 = load ptr, ptr %l32, !tbaa !29
  %t755 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t756 = load i32, ptr %l33, !tbaa !23
  %t757 = load i32, ptr %l34, !tbaa !23
  %t762 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2erecode(ptr %v0, ptr %s0, ptr %s0, ptr %t754, { i64, ptr } %t755, i32 %t756, i32 %t757)
  store { i64, ptr } %t762, ptr %l330
  br label %bb152
bb151:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d139, i32 0, i32 1) }, ptr %l325, !tbaa !27
  br label %bb153
bb152:
  %t763 = load { i64, ptr }, ptr %l330, !tbaa !27
  %t764 = extractvalue { i64, ptr } %t763, 0
  %t765 = extractvalue { i64, ptr } %t763, 1
  %t766 = mul i64 %t764, 1
  %t767 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t766)
  call void @llvm.memcpy.p0.p0.i64(ptr %t767, ptr %t765, i64 %t766, i1 false)
  %t768 = insertvalue { i64, ptr } undef, i64 %t764, 0
  %t769 = insertvalue { i64, ptr } %t768, ptr %t767, 1
  store { i64, ptr } %t769, ptr %l325, !tbaa !27
  br label %bb153
bb153:
  %t771 = load { i64, ptr }, ptr %l325, !tbaa !27
  store { i64, ptr } %t771, ptr %l38, !tbaa !27
  %t772 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t774 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t772, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d140, i32 0, i32 1) })
  store i1 %t774, ptr %l333
  br label %bb154
bb154:
  %t775 = load i1, ptr %l333, !tbaa !21
  br i1 %t775, label %bb155, label %bb156
bb155:
  store %olang.scope zeroinitializer, ptr %s30
  %t776 = load ptr, ptr %l32, !tbaa !29
  %t777 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t778 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d141, i32 0, i32 1) }, 1
  %t779 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d141, i32 0, i32 1) }, 0
  %t781 = extractvalue { i64, ptr } %t777, 1
  %t782 = extractvalue { i64, ptr } %t777, 0
  %t783 = add i64 %t779, %t782
  %t784 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t783)
  call void @olang_textcopy(ptr %t784, ptr %t778, i64 %t779)
  %t785 = getelementptr i8, ptr %t784, i64 %t779
  call void @olang_textcopy(ptr %t785, ptr %t781, i64 %t782)
  %t786 = insertvalue { i64, ptr } undef, i64 %t783, 0
  %t787 = insertvalue { i64, ptr } %t786, ptr %t784, 1
  %t789 = extractvalue { i64, ptr } %t787, 0
  %t790 = extractvalue { i64, ptr } %t787, 1
  %t791 = mul i64 %t789, 1
  %t792 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t791)
  call void @llvm.memcpy.p0.p0.i64(ptr %t792, ptr %t790, i64 %t791, i1 false)
  %t793 = insertvalue { i64, ptr } undef, i64 %t789, 0
  %t794 = insertvalue { i64, ptr } %t793, ptr %t792, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s30, ptr %t776, { i64, ptr } %t794)
  br label %bb157
bb156:
  store %olang.scope zeroinitializer, ptr %s32
  %t797 = load ptr, ptr %l3, !tbaa !29
  %t798 = load i32, ptr %l34, !tbaa !23
  %t801 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s32, ptr %t797, i32 %t798)
  store { i64, ptr } %t801, ptr %l340
  br label %bb158
bb157:
  call void @__olang_scope_close(ptr %s30)
  br label %bb178
bb158:
  %t802 = load { i64, ptr }, ptr %l340, !tbaa !27
  %t803 = extractvalue { i64, ptr } %t802, 0
  %t805 = icmp eq i64 %t803, 0
  br i1 %t805, label %bb159, label %bb160
bb159:
  store %olang.scope zeroinitializer, ptr %s33
  %t807 = load ptr, ptr %l32, !tbaa !29
  store ptr %t807, ptr %l343, !tbaa !29
  %t808 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t808, ptr %l344, !tbaa !27
  %t809 = load ptr, ptr %l3, !tbaa !29
  %t810 = load i32, ptr %l33, !tbaa !23
  %t813 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s33, ptr %t809, i32 %t810)
  store { i64, ptr } %t813, ptr %l347
  br label %bb161
bb160:
  store %olang.scope zeroinitializer, ptr %s36
  %t814 = load ptr, ptr %l3, !tbaa !29
  %t815 = load i32, ptr %l33, !tbaa !23
  %t818 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s36, ptr %t814, i32 %t815)
  store { i64, ptr } %t818, ptr %l361
  br label %bb167
bb161:
  %t819 = load { i64, ptr }, ptr %l347, !tbaa !27
  %t820 = extractvalue { i64, ptr } %t819, 0
  %t822 = icmp sgt i64 %t820, 0
  br i1 %t822, label %bb162, label %bb163
bb162:
  %t824 = load ptr, ptr %l32, !tbaa !29
  %t825 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t826 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d142, i32 0, i32 1) }, 1
  %t827 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d142, i32 0, i32 1) }, 0
  %t829 = extractvalue { i64, ptr } %t825, 1
  %t830 = extractvalue { i64, ptr } %t825, 0
  %t831 = add i64 %t827, %t830
  %t832 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d143, i32 0, i32 1) }, 1
  %t833 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d143, i32 0, i32 1) }, 0
  %t834 = add i64 %t831, %t833
  %t835 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t834)
  call void @olang_textcopy(ptr %t835, ptr %t826, i64 %t827)
  %t836 = getelementptr i8, ptr %t835, i64 %t827
  call void @olang_textcopy(ptr %t836, ptr %t829, i64 %t830)
  %t837 = getelementptr i8, ptr %t836, i64 %t830
  call void @olang_textcopy(ptr %t837, ptr %t832, i64 %t833)
  %t838 = insertvalue { i64, ptr } undef, i64 %t834, 0
  %t839 = insertvalue { i64, ptr } %t838, ptr %t835, 1
  %t841 = extractvalue { i64, ptr } %t839, 0
  %t842 = extractvalue { i64, ptr } %t839, 1
  %t843 = mul i64 %t841, 1
  %t844 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t843)
  call void @llvm.memcpy.p0.p0.i64(ptr %t844, ptr %t842, i64 %t843, i1 false)
  %t845 = insertvalue { i64, ptr } undef, i64 %t841, 0
  %t846 = insertvalue { i64, ptr } %t845, ptr %t844, 1
  %t849 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s33, ptr %s33, ptr %t824, { i64, ptr } %t846)
  store { i64, ptr } %t849, ptr %l355
  br label %bb164
bb163:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d144, i32 0, i32 1) }, ptr %l350, !tbaa !27
  br label %bb165
bb164:
  %t850 = load { i64, ptr }, ptr %l355, !tbaa !27
  %t851 = extractvalue { i64, ptr } %t850, 0
  %t852 = extractvalue { i64, ptr } %t850, 1
  %t853 = mul i64 %t851, 1
  %t854 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t853)
  call void @llvm.memcpy.p0.p0.i64(ptr %t854, ptr %t852, i64 %t853, i1 false)
  %t855 = insertvalue { i64, ptr } undef, i64 %t851, 0
  %t856 = insertvalue { i64, ptr } %t855, ptr %t854, 1
  store { i64, ptr } %t856, ptr %l350, !tbaa !27
  br label %bb165
bb165:
  %t858 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d145, i32 0, i32 1) }, 1
  %t859 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d145, i32 0, i32 1) }, 0
  %t860 = load { i64, ptr }, ptr %l344, !tbaa !27
  %t861 = extractvalue { i64, ptr } %t860, 1
  %t862 = extractvalue { i64, ptr } %t860, 0
  %t863 = add i64 %t859, %t862
  %t864 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d146, i32 0, i32 1) }, 1
  %t865 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d146, i32 0, i32 1) }, 0
  %t866 = add i64 %t863, %t865
  %t867 = load { i64, ptr }, ptr %l350, !tbaa !27
  %t868 = extractvalue { i64, ptr } %t867, 1
  %t869 = extractvalue { i64, ptr } %t867, 0
  %t870 = add i64 %t866, %t869
  %t871 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t870)
  call void @olang_textcopy(ptr %t871, ptr %t858, i64 %t859)
  %t872 = getelementptr i8, ptr %t871, i64 %t859
  call void @olang_textcopy(ptr %t872, ptr %t861, i64 %t862)
  %t873 = getelementptr i8, ptr %t872, i64 %t862
  call void @olang_textcopy(ptr %t873, ptr %t864, i64 %t865)
  %t874 = getelementptr i8, ptr %t873, i64 %t865
  call void @olang_textcopy(ptr %t874, ptr %t868, i64 %t869)
  %t875 = insertvalue { i64, ptr } undef, i64 %t870, 0
  %t876 = insertvalue { i64, ptr } %t875, ptr %t871, 1
  %t878 = extractvalue { i64, ptr } %t876, 0
  %t879 = extractvalue { i64, ptr } %t876, 1
  %t880 = mul i64 %t878, 1
  %t881 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t880)
  call void @llvm.memcpy.p0.p0.i64(ptr %t881, ptr %t879, i64 %t880, i1 false)
  %t882 = insertvalue { i64, ptr } undef, i64 %t878, 0
  %t883 = insertvalue { i64, ptr } %t882, ptr %t881, 1
  %t884 = load ptr, ptr %l343, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s33, ptr %t884, { i64, ptr } %t883)
  br label %bb166
bb166:
  call void @__olang_scope_close(ptr %s33)
  br label %bb177
bb167:
  %t886 = load { i64, ptr }, ptr %l361, !tbaa !27
  %t887 = extractvalue { i64, ptr } %t886, 0
  %t889 = icmp sgt i64 %t887, 0
  br i1 %t889, label %bb168, label %bb169
bb168:
  %t891 = load ptr, ptr %l32, !tbaa !29
  %t892 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t893 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d147, i32 0, i32 1) }, 1
  %t894 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d147, i32 0, i32 1) }, 0
  %t896 = extractvalue { i64, ptr } %t892, 1
  %t897 = extractvalue { i64, ptr } %t892, 0
  %t898 = add i64 %t894, %t897
  %t899 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d148, i32 0, i32 1) }, 1
  %t900 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d148, i32 0, i32 1) }, 0
  %t901 = add i64 %t898, %t900
  %t902 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t901)
  call void @olang_textcopy(ptr %t902, ptr %t893, i64 %t894)
  %t903 = getelementptr i8, ptr %t902, i64 %t894
  call void @olang_textcopy(ptr %t903, ptr %t896, i64 %t897)
  %t904 = getelementptr i8, ptr %t903, i64 %t897
  call void @olang_textcopy(ptr %t904, ptr %t899, i64 %t900)
  %t905 = insertvalue { i64, ptr } undef, i64 %t901, 0
  %t906 = insertvalue { i64, ptr } %t905, ptr %t902, 1
  %t908 = extractvalue { i64, ptr } %t906, 0
  %t909 = extractvalue { i64, ptr } %t906, 1
  %t910 = mul i64 %t908, 1
  %t911 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t910)
  call void @llvm.memcpy.p0.p0.i64(ptr %t911, ptr %t909, i64 %t910, i1 false)
  %t912 = insertvalue { i64, ptr } undef, i64 %t908, 0
  %t913 = insertvalue { i64, ptr } %t912, ptr %t911, 1
  %t916 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s36, ptr %s36, ptr %t891, { i64, ptr } %t913)
  store { i64, ptr } %t916, ptr %l369
  br label %bb170
bb169:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d149, i32 0, i32 1) }, ptr %l364, !tbaa !27
  br label %bb171
bb170:
  %t917 = load { i64, ptr }, ptr %l369, !tbaa !27
  %t918 = extractvalue { i64, ptr } %t917, 0
  %t919 = extractvalue { i64, ptr } %t917, 1
  %t920 = mul i64 %t918, 1
  %t921 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t920)
  call void @llvm.memcpy.p0.p0.i64(ptr %t921, ptr %t919, i64 %t920, i1 false)
  %t922 = insertvalue { i64, ptr } undef, i64 %t918, 0
  %t923 = insertvalue { i64, ptr } %t922, ptr %t921, 1
  store { i64, ptr } %t923, ptr %l364, !tbaa !27
  br label %bb171
bb171:
  %t925 = load { i64, ptr }, ptr %l364, !tbaa !27
  store { i64, ptr } %t925, ptr %l39, !tbaa !27
  %t926 = load ptr, ptr %l32, !tbaa !29
  %t927 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t928 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t929 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d150, i32 0, i32 1) }, 1
  %t930 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d150, i32 0, i32 1) }, 0
  %t932 = extractvalue { i64, ptr } %t927, 1
  %t933 = extractvalue { i64, ptr } %t927, 0
  %t934 = add i64 %t930, %t933
  %t935 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d151, i32 0, i32 1) }, 1
  %t936 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d151, i32 0, i32 1) }, 0
  %t937 = add i64 %t934, %t936
  %t939 = extractvalue { i64, ptr } %t928, 1
  %t940 = extractvalue { i64, ptr } %t928, 0
  %t941 = add i64 %t937, %t940
  %t942 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d152, i32 0, i32 1) }, 1
  %t943 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d152, i32 0, i32 1) }, 0
  %t944 = add i64 %t941, %t943
  %t945 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t944)
  call void @olang_textcopy(ptr %t945, ptr %t929, i64 %t930)
  %t946 = getelementptr i8, ptr %t945, i64 %t930
  call void @olang_textcopy(ptr %t946, ptr %t932, i64 %t933)
  %t947 = getelementptr i8, ptr %t946, i64 %t933
  call void @olang_textcopy(ptr %t947, ptr %t935, i64 %t936)
  %t948 = getelementptr i8, ptr %t947, i64 %t936
  call void @olang_textcopy(ptr %t948, ptr %t939, i64 %t940)
  %t949 = getelementptr i8, ptr %t948, i64 %t940
  call void @olang_textcopy(ptr %t949, ptr %t942, i64 %t943)
  %t950 = insertvalue { i64, ptr } undef, i64 %t944, 0
  %t951 = insertvalue { i64, ptr } %t950, ptr %t945, 1
  %t953 = extractvalue { i64, ptr } %t951, 0
  %t954 = extractvalue { i64, ptr } %t951, 1
  %t955 = mul i64 %t953, 1
  %t956 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t955)
  call void @llvm.memcpy.p0.p0.i64(ptr %t956, ptr %t954, i64 %t955, i1 false)
  %t957 = insertvalue { i64, ptr } undef, i64 %t953, 0
  %t958 = insertvalue { i64, ptr } %t957, ptr %t956, 1
  %t961 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s36, ptr %s36, ptr %t926, { i64, ptr } %t958)
  store { i64, ptr } %t961, ptr %l376
  br label %bb172
bb172:
  %t962 = load { i64, ptr }, ptr %l376, !tbaa !27
  %t963 = load ptr, ptr %l32, !tbaa !29
  store ptr %t963, ptr %l377, !tbaa !29
  %t964 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t964, ptr %l378, !tbaa !27
  %t965 = load ptr, ptr %l32, !tbaa !29
  store ptr %t965, ptr %l379, !tbaa !29
  %t966 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t966, ptr %l380, !tbaa !27
  store { i64, ptr } %t962, ptr %l381, !tbaa !27
  %t968 = load ptr, ptr %l0, !tbaa !29
  store ptr %t968, ptr %l382, !tbaa !29
  %t969 = load ptr, ptr %l3, !tbaa !29
  %t970 = load i32, ptr %l2, !tbaa !23
  %t973 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t969, i32 %t970)
  store i32 %t973, ptr %l385
  br label %bb173
bb173:
  %t974 = load ptr, ptr %l382, !tbaa !29
  %t975 = load i32, ptr %l385, !tbaa !23
  %t976 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s36, ptr %t974, i32 %t975)
  store { i64, ptr } %t976, ptr %l386
  br label %bb174
bb174:
  %t977 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t978 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d153, i32 0, i32 1) }, 1
  %t979 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d153, i32 0, i32 1) }, 0
  %t980 = load { i64, ptr }, ptr %l380, !tbaa !27
  %t981 = extractvalue { i64, ptr } %t980, 1
  %t982 = extractvalue { i64, ptr } %t980, 0
  %t983 = add i64 %t979, %t982
  %t984 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d154, i32 0, i32 1) }, 1
  %t985 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d154, i32 0, i32 1) }, 0
  %t986 = add i64 %t983, %t985
  %t987 = load { i64, ptr }, ptr %l381, !tbaa !27
  %t988 = extractvalue { i64, ptr } %t987, 1
  %t989 = extractvalue { i64, ptr } %t987, 0
  %t990 = add i64 %t986, %t989
  %t991 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d155, i32 0, i32 1) }, 1
  %t992 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d155, i32 0, i32 1) }, 0
  %t993 = add i64 %t990, %t992
  %t994 = load { i64, ptr }, ptr %l386, !tbaa !27
  %t995 = extractvalue { i64, ptr } %t994, 1
  %t996 = extractvalue { i64, ptr } %t994, 0
  %t997 = add i64 %t993, %t996
  %t998 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d154, i32 0, i32 1) }, 1
  %t999 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d154, i32 0, i32 1) }, 0
  %t1000 = add i64 %t997, %t999
  %t1002 = extractvalue { i64, ptr } %t977, 1
  %t1003 = extractvalue { i64, ptr } %t977, 0
  %t1004 = add i64 %t1000, %t1003
  %t1005 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d156, i32 0, i32 1) }, 1
  %t1006 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d156, i32 0, i32 1) }, 0
  %t1007 = add i64 %t1004, %t1006
  %t1008 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t1007)
  call void @olang_textcopy(ptr %t1008, ptr %t978, i64 %t979)
  %t1009 = getelementptr i8, ptr %t1008, i64 %t979
  call void @olang_textcopy(ptr %t1009, ptr %t981, i64 %t982)
  %t1010 = getelementptr i8, ptr %t1009, i64 %t982
  call void @olang_textcopy(ptr %t1010, ptr %t984, i64 %t985)
  %t1011 = getelementptr i8, ptr %t1010, i64 %t985
  call void @olang_textcopy(ptr %t1011, ptr %t988, i64 %t989)
  %t1012 = getelementptr i8, ptr %t1011, i64 %t989
  call void @olang_textcopy(ptr %t1012, ptr %t991, i64 %t992)
  %t1013 = getelementptr i8, ptr %t1012, i64 %t992
  call void @olang_textcopy(ptr %t1013, ptr %t995, i64 %t996)
  %t1014 = getelementptr i8, ptr %t1013, i64 %t996
  call void @olang_textcopy(ptr %t1014, ptr %t998, i64 %t999)
  %t1015 = getelementptr i8, ptr %t1014, i64 %t999
  call void @olang_textcopy(ptr %t1015, ptr %t1002, i64 %t1003)
  %t1016 = getelementptr i8, ptr %t1015, i64 %t1003
  call void @olang_textcopy(ptr %t1016, ptr %t1005, i64 %t1006)
  %t1017 = insertvalue { i64, ptr } undef, i64 %t1007, 0
  %t1018 = insertvalue { i64, ptr } %t1017, ptr %t1008, 1
  %t1020 = extractvalue { i64, ptr } %t1018, 0
  %t1021 = extractvalue { i64, ptr } %t1018, 1
  %t1022 = mul i64 %t1020, 1
  %t1023 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t1022)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1023, ptr %t1021, i64 %t1022, i1 false)
  %t1024 = insertvalue { i64, ptr } undef, i64 %t1020, 0
  %t1025 = insertvalue { i64, ptr } %t1024, ptr %t1023, 1
  %t1026 = load ptr, ptr %l379, !tbaa !29
  %t1028 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s36, ptr %s36, ptr %t1026, { i64, ptr } %t1025)
  store { i64, ptr } %t1028, ptr %l390
  br label %bb175
bb175:
  %t1029 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d157, i32 0, i32 1) }, 1
  %t1030 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d157, i32 0, i32 1) }, 0
  %t1031 = load { i64, ptr }, ptr %l378, !tbaa !27
  %t1032 = extractvalue { i64, ptr } %t1031, 1
  %t1033 = extractvalue { i64, ptr } %t1031, 0
  %t1034 = add i64 %t1030, %t1033
  %t1035 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d158, i32 0, i32 1) }, 1
  %t1036 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d158, i32 0, i32 1) }, 0
  %t1037 = add i64 %t1034, %t1036
  %t1038 = load { i64, ptr }, ptr %l390, !tbaa !27
  %t1039 = extractvalue { i64, ptr } %t1038, 1
  %t1040 = extractvalue { i64, ptr } %t1038, 0
  %t1041 = add i64 %t1037, %t1040
  %t1042 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t1041)
  call void @olang_textcopy(ptr %t1042, ptr %t1029, i64 %t1030)
  %t1043 = getelementptr i8, ptr %t1042, i64 %t1030
  call void @olang_textcopy(ptr %t1043, ptr %t1032, i64 %t1033)
  %t1044 = getelementptr i8, ptr %t1043, i64 %t1033
  call void @olang_textcopy(ptr %t1044, ptr %t1035, i64 %t1036)
  %t1045 = getelementptr i8, ptr %t1044, i64 %t1036
  call void @olang_textcopy(ptr %t1045, ptr %t1039, i64 %t1040)
  %t1046 = insertvalue { i64, ptr } undef, i64 %t1041, 0
  %t1047 = insertvalue { i64, ptr } %t1046, ptr %t1042, 1
  %t1049 = extractvalue { i64, ptr } %t1047, 0
  %t1050 = extractvalue { i64, ptr } %t1047, 1
  %t1051 = mul i64 %t1049, 1
  %t1052 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t1051)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1052, ptr %t1050, i64 %t1051, i1 false)
  %t1053 = insertvalue { i64, ptr } undef, i64 %t1049, 0
  %t1054 = insertvalue { i64, ptr } %t1053, ptr %t1052, 1
  %t1055 = load ptr, ptr %l377, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s36, ptr %t1055, { i64, ptr } %t1054)
  br label %bb176
bb176:
  call void @__olang_scope_close(ptr %s36)
  br label %bb177
bb177:
  call void @__olang_scope_close(ptr %s32)
  br label %bb178
bb178:
  store ptr %l11, ptr %l393, !tbaa !29
  %t1057 = load ptr, ptr %l32, !tbaa !29
  %t1059 = getelementptr %"compiler/emit:fnEm", ptr %t1057, i32 0, i32 5
  %t1061 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %s0, ptr %t1059)
  store { i64, ptr } %t1061, ptr %l396
  br label %bb179
bb179:
  %t1062 = load ptr, ptr %l393, !tbaa !29
  %t1063 = load { i64, ptr }, ptr %l396, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t1062, { i64, ptr } %t1063)
  br label %bb180
bb180:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l11, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d159, i32 0, i32 1) })
  br label %bb181
bb181:
  %t1065 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1065, ptr %l398, !tbaa !29
  %t1066 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t1066, ptr %l399, !tbaa !27
  %t1067 = load i64, ptr %l8, !tbaa !24
  store i64 %t1067, ptr %l400, !tbaa !24
  %t1069 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l11)
  store { i64, ptr } %t1069, ptr %l402
  br label %bb182
bb182:
  %t1070 = load ptr, ptr %l398, !tbaa !29
  %t1071 = load { i64, ptr }, ptr %l399, !tbaa !27
  %t1072 = load i64, ptr %l400, !tbaa !24
  %t1073 = load { i64, ptr }, ptr %l402, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t1070, { i64, ptr } %t1071, i64 %t1072, { i64, ptr } %t1073, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d14, i32 0, i32 1) })
  br label %bb183
bb183:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewantType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l20 = alloca { i64, ptr }
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i64
  %l51 = alloca i64
  %l53 = alloca i64
  %l55 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l60 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i32
  %l74 = alloca i1
  %l77 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v2, ptr %t1, i64 %t2, i1 true)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t5, i64 %t6)
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/emit:Emitter", ptr %t9, i32 0, i32 43
  %t12 = load i64, ptr %l1, !tbaa !24
  %t15 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t11, i64 %t12)
  store { i64, ptr } %t15, ptr %l20
  br label %bb3
bb3:
  %t16 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t16, ptr %l4, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2femit_2erefsIn(ptr %v0, ptr %s0, { i64, ptr } %t17)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l22
  br label %bb4
bb4:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l5)
  store i64 %t22, ptr %l24
  br label %bb5
bb5:
  %t23 = load i64, ptr %l24, !tbaa !24
  store i64 %t23, ptr %l7, !tbaa !24
  store i64 3, ptr %l8, !tbaa !24
  %t24 = load i64, ptr %l7, !tbaa !24
  %t25 = load i64, ptr %l6, !tbaa !24
  %t28 = icmp sgt i64 %t24, %t25
  br i1 %t28, label %bb6, label %bb7
bb6:
  %t30 = load i64, ptr %l8, !tbaa !24
  %t32 = icmp sgt i64 %t30, 0
  br i1 %t32, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb11
bb8:
  %t34 = load i64, ptr %l7, !tbaa !24
  %t35 = load i64, ptr %l6, !tbaa !24
  %t38 = sub i64 %t34, %t35
  %t39 = load i64, ptr %l8, !tbaa !24
  %t42 = add i64 %t38, %t39
  %t44 = sub i64 %t42, 1
  %t45 = load i64, ptr %l8, !tbaa !24
  %t48 = sdiv i64 %t44, %t45
  store i64 %t48, ptr %l31, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb10
bb10:
  %t50 = load i64, ptr %l31, !tbaa !24
  store i64 %t50, ptr %l28, !tbaa !24
  br label %bb11
bb11:
  %t51 = load i64, ptr %l28, !tbaa !24
  store i64 %t51, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb12
bb12:
  %t52 = load i64, ptr %l10, !tbaa !24
  %t53 = load i64, ptr %l9, !tbaa !24
  %t56 = icmp slt i64 %t52, %t53
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb13, label %bb14
bb13:
  br label %bb41
bb14:
  br label %bb15
bb15:
  %t60 = load i64, ptr %l6, !tbaa !24
  %t61 = load i64, ptr %l10, !tbaa !24
  %t62 = load i64, ptr %l8, !tbaa !24
  %t65 = mul i64 %t61, %t62
  %t68 = add i64 %t60, %t65
  store i64 %t68, ptr %l11, !tbaa !24
  %t70 = load i64, ptr %l11, !tbaa !24
  %t73 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l5, i64 %t70)
  store i64 %t73, ptr %l51
  br label %bb16
bb16:
  %t74 = load i64, ptr %l51, !tbaa !24
  %t75 = icmp ne i64 %t74, 1
  br i1 %t75, label %bb17, label %bb18
bb17:
  br label %bb40
bb18:
  br label %bb19
bb19:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/emit:Emitter", ptr %t77, i32 0, i32 44
  store ptr %t79, ptr %l55, !tbaa !29
  %t80 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t80, ptr %l56, !tbaa !27
  %t81 = load i64, ptr %l11, !tbaa !24
  %t83 = add i64 %t81, 1
  %t86 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l5, i64 %t83)
  store i64 %t86, ptr %l60
  br label %bb20
bb20:
  %t87 = load i64, ptr %l11, !tbaa !24
  %t89 = add i64 %t87, 2
  %t92 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l5, i64 %t89)
  store i64 %t92, ptr %l64
  br label %bb21
bb21:
  %t93 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 0
  store i64 %t94, ptr %l65, !tbaa !24
  %t95 = load i64, ptr %l60, !tbaa !24
  %t96 = icmp sge i64 %t95, 0
  br i1 %t96, label %bb22, label %bb23
bb22:
  %t98 = load i64, ptr %l60, !tbaa !24
  %t99 = load i64, ptr %l64, !tbaa !24
  %t100 = icmp sle i64 %t98, %t99
  br i1 %t100, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_6f064da57090b2af_17093dce158f11fb)
  unreachable
bb24:
  %t102 = load i64, ptr %l64, !tbaa !24
  %t103 = load i64, ptr %l65, !tbaa !24
  %t104 = icmp sle i64 %t102, %t103
  br i1 %t104, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_6f064da57090b2af_17093dce158f11fb)
  unreachable
bb26:
  %t106 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = load i64, ptr %l60, !tbaa !24
  %t109 = load i64, ptr %l64, !tbaa !24
  %t110 = getelementptr i8, ptr %t107, i64 %t108
  %t111 = sub i64 %t109, %t108
  %t112 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t110, 1
  %t114 = load ptr, ptr %l55, !tbaa !29
  %t116 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v0, ptr %t114, { i64, ptr } %t113)
  %t117 = extractvalue { i32, i64 } %t116, 1
  %t118 = extractvalue { i32, i64 } %t116, 0
  store i32 %t118, ptr %l71
  %t119 = icmp ne i32 %t118, 0
  br i1 %t119, label %bb29, label %ok.120, !prof !99
ok.120:
  store i64 %t117, ptr %l70
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_6f064da57090b2af_17093dce158f11fb)
  unreachable
bb28:
  %t121 = load i64, ptr %l70, !tbaa !24
  store i64 %t121, ptr %l53, !tbaa !24
  br label %bb31
bb29:
  br label %bb30
bb30:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l53, !tbaa !24
  br label %bb31
bb31:
  %t122 = load i64, ptr %l53, !tbaa !24
  store i64 %t122, ptr %l12, !tbaa !24
  %t123 = load i64, ptr %l12, !tbaa !24
  %t125 = icmp sge i64 %t123, 0
  br i1 %t125, label %bb32, label %bb33
bb32:
  %t127 = load ptr, ptr %l3, !tbaa !29
  %t128 = load i64, ptr %l12, !tbaa !24
  %t131 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v2, ptr %t127, i64 %t128)
  store i1 %t131, ptr %l77
  br label %bb34
bb33:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb35
bb34:
  %t132 = load i1, ptr %l77, !tbaa !21
  %t133 = xor i1 %t132, true
  store i1 %t133, ptr %l74, !tbaa !21
  br label %bb35
bb35:
  %t135 = load i1, ptr %l74, !tbaa !21
  br i1 %t135, label %bb36, label %bb37
bb36:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load i64, ptr %l12, !tbaa !24
  %t138 = load ptr, ptr %l2, !tbaa !29
  %t139 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewantType(ptr %v0, ptr %v1, ptr %v2, ptr %t136, i64 %t137, ptr %t138, ptr %t139)
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t144 = load i64, ptr %l10, !tbaa !24
  %t146 = add i64 %t144, 1
  store i64 %t146, ptr %l10, !tbaa !24
  br label %bb12
bb41:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eapart(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %a1, %"compiler/mir:Range" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Lvalue"
  %l2 = alloca %"compiler/mir:Range"
  %l3 = alloca i32
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l12 = alloca { i64, [4 x i64] }
  %l13 = alloca %"compiler/mir:Lvalue"
  %l24 = alloca i1
  %l30 = alloca i32
  %l33 = alloca i32
  %l55 = alloca { i64, [4 x i64] }
  %l61 = alloca i1
  %l62 = alloca i1
  %l65 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/mir:Lvalue" %a1, ptr %l1
  store %"compiler/mir:Range" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  store i32 %t1, ptr %l3, !tbaa !23
  %t3 = getelementptr %"compiler/mir:Lvalue", ptr %l1, i32 0, i32 0
  %t4 = load { i64, [2 x i64] }, ptr %t3
  store { i64, [2 x i64] } %t4, ptr %l4
  %t6 = load { i64, [2 x i64] }, ptr %l4
  %t8 = extractvalue { i64, [2 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 1
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  store i32 %t13, ptr %l5, !tbaa !23
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t15 = load i32, ptr %l5, !tbaa !23
  store i32 %t15, ptr %l3, !tbaa !23
  br label %bb9
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 false, ptr %rv
  br label %ret
bb8:
  call void @__olang_check_failed(ptr @olang_loc_ed162375e135a06c_e406bb0ac0d59940)
  unreachable
bb9:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load %"compiler/mir:Lvalue", ptr %l1
  %t22 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2ederefs(ptr %v0, ptr %t18, %"compiler/mir:Lvalue" %t19)
  store i1 %t22, ptr %l24
  br label %bb10
bb10:
  %t23 = load i1, ptr %l24, !tbaa !21
  br i1 %t23, label %bb11, label %bb12
bb11:
  store i1 false, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  store i32 0, ptr %l6, !tbaa !23
  %t25 = getelementptr %"compiler/mir:Range", ptr %l2, i32 0, i32 1
  %t26 = load i32, ptr %t25, !tbaa !23
  store i32 %t26, ptr %l7, !tbaa !23
  store i32 1, ptr %l8, !tbaa !23
  %t28 = load i32, ptr %l7, !tbaa !23
  %t29 = load i32, ptr %l6, !tbaa !23
  %t32 = icmp sgt i32 %t28, %t29
  br i1 %t32, label %bb14, label %bb15
bb14:
  %t34 = load i32, ptr %l8, !tbaa !23
  %t36 = icmp sgt i32 %t34, 0
  br i1 %t36, label %bb16, label %bb17
bb15:
  store i32 0, ptr %l30, !tbaa !23
  br label %bb19
bb16:
  %t38 = load i32, ptr %l7, !tbaa !23
  %t39 = load i32, ptr %l6, !tbaa !23
  %t42 = sub i32 %t38, %t39
  %t43 = load i32, ptr %l8, !tbaa !23
  %t46 = add i32 %t42, %t43
  %t48 = sub i32 %t46, 1
  %t49 = load i32, ptr %l8, !tbaa !23
  %t52 = sdiv i32 %t48, %t49
  store i32 %t52, ptr %l33, !tbaa !23
  br label %bb18
bb17:
  store i32 0, ptr %l33, !tbaa !23
  br label %bb18
bb18:
  %t54 = load i32, ptr %l33, !tbaa !23
  store i32 %t54, ptr %l30, !tbaa !23
  br label %bb19
bb19:
  %t55 = load i32, ptr %l30, !tbaa !23
  store i32 %t55, ptr %l9, !tbaa !23
  store i32 0, ptr %l10, !tbaa !23
  br label %bb20
bb20:
  %t56 = load i32, ptr %l10, !tbaa !23
  %t57 = load i32, ptr %l9, !tbaa !23
  %t60 = icmp slt i32 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb21, label %bb22
bb21:
  br label %bb52
bb22:
  br label %bb23
bb23:
  %t64 = load i32, ptr %l6, !tbaa !23
  %t65 = load i32, ptr %l10, !tbaa !23
  %t66 = load i32, ptr %l8, !tbaa !23
  %t69 = mul i32 %t65, %t66
  %t72 = add i32 %t64, %t69
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load %"compiler/mir:Range", ptr %l2
  %t78 = sext i32 %t72 to i64
  %t82 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t74, %"compiler/mir:Range" %t75, i64 %t78)
  store { i64, [4 x i64] } %t82, ptr %l55
  br label %bb24
bb24:
  %t83 = load { i64, [4 x i64] }, ptr %l55
  store { i64, [4 x i64] } %t83, ptr %l12
  %t84 = load { i64, [4 x i64] }, ptr %l12
  %t86 = extractvalue { i64, [4 x i64] } %t84, 0
  %t87 = icmp eq i64 %t86, 1
  br i1 %t87, label %bb25, label %bb26
bb25:
  %t89 = getelementptr { i64, [4 x i64] }, ptr %l12, i32 0, i32 1
  %t90 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t89, i32 0, i32 0
  %t91 = load %"compiler/mir:Lvalue", ptr %t90
  store %"compiler/mir:Lvalue" %t91, ptr %l13
  br label %bb27
bb26:
  br label %bb45
bb27:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load %"compiler/mir:Lvalue", ptr %l13
  %t97 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2ederefs(ptr %v0, ptr %t93, %"compiler/mir:Lvalue" %t94)
  store i1 %t97, ptr %l61
  br label %bb28
bb28:
  %t98 = load i1, ptr %l61, !tbaa !21
  br i1 %t98, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb32
bb30:
  %t99 = load %"compiler/mir:Lvalue", ptr %l13
  %t100 = load i32, ptr %l3, !tbaa !23
  %t103 = call i1 @compiler_2fmir_2ecompiler_2fmir_3aLvalue_2eBaseIs(%"compiler/mir:Lvalue" %t99, i32 %t100)
  store i1 %t103, ptr %l65
  br label %bb31
bb31:
  %t104 = load i1, ptr %l65, !tbaa !21
  store i1 %t104, ptr %l62, !tbaa !21
  br label %bb32
bb32:
  %t105 = load i1, ptr %l62, !tbaa !21
  br i1 %t105, label %bb33, label %bb34
bb33:
  store i1 false, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t107 = getelementptr %"compiler/mir:Lvalue", ptr %l13, i32 0, i32 0
  %t108 = load { i64, [2 x i64] }, ptr %t107
  %t112 = extractvalue { i64, [2 x i64] } %t108, 0
  %t113 = icmp eq i64 %t112, 1
  br i1 %t113, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb44
bb39:
  br i1 true, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  store i1 false, ptr %rv
  br label %ret
bb43:
  call void @__olang_check_failed(ptr @olang_loc_5f9c6fbf78b3e51d_e9dc61b8da3e01d1)
  unreachable
bb44:
  br label %bb50
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_afa6164151ba006_66d817e1c679673a)
  unreachable
bb50:
  br label %bb51
bb51:
  %t116 = load i32, ptr %l10, !tbaa !23
  %t118 = add i32 %t116, 1
  store i32 %t118, ptr %l10, !tbaa !23
  br label %bb20
bb52:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayStorage(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i32 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l10 = alloca i64
  %l14 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ealign(ptr %v0, ptr %t1, i32 %a3)
  store i64 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i64, ptr %l10, !tbaa !24
  store i64 %t6, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l5, !tbaa !24
  %t9 = icmp sgt i64 %t7, 8
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i1, ptr %l4, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb3:
  br label %bb9
bb4:
  store { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d160, i32 0, i32 1) }, ptr %l14, !tbaa !27
  br label %bb6
bb5:
  store { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d161, i32 0, i32 1) }, ptr %l14, !tbaa !27
  br label %bb6
bb6:
  %t13 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t13, ptr %l6, !tbaa !27
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/emit:fnEm", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t18 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t19 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %t19, ptr %t17, { i64, ptr } %t18)
  br label %bb7
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t26 = load i64, ptr %l5, !tbaa !24
  %t27 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d162, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d162, i32 0, i32 1) }, 0
  %t30 = extractvalue { i64, ptr } %t23, 1
  %t31 = extractvalue { i64, ptr } %t23, 0
  %t32 = add i64 %t28, %t31
  %t33 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d163, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d163, i32 0, i32 1) }, 0
  %t35 = add i64 %t32, %t34
  %t37 = extractvalue { i64, ptr } %t24, 1
  %t38 = extractvalue { i64, ptr } %t24, 0
  %t39 = add i64 %t35, %t38
  %t40 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d164, i32 0, i32 1) }, 1
  %t41 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d164, i32 0, i32 1) }, 0
  %t42 = add i64 %t39, %t41
  %t44 = extractvalue { i64, ptr } %t25, 1
  %t45 = extractvalue { i64, ptr } %t25, 0
  %t46 = add i64 %t42, %t45
  %t47 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d164, i32 0, i32 1) }, 1
  %t48 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d164, i32 0, i32 1) }, 0
  %t49 = add i64 %t46, %t48
  %t51 = call i64 @__olang_fmt_i64(ptr null, i64 %t26)
  %t52 = add i64 %t49, %t51
  %t53 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d165, i32 0, i32 1) }, 1
  %t54 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d165, i32 0, i32 1) }, 0
  %t55 = add i64 %t52, %t54
  %t56 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t55)
  call void @olang_textcopy(ptr %t56, ptr %t27, i64 %t28)
  %t57 = getelementptr i8, ptr %t56, i64 %t28
  call void @olang_textcopy(ptr %t57, ptr %t30, i64 %t31)
  %t58 = getelementptr i8, ptr %t57, i64 %t31
  call void @olang_textcopy(ptr %t58, ptr %t33, i64 %t34)
  %t59 = getelementptr i8, ptr %t58, i64 %t34
  call void @olang_textcopy(ptr %t59, ptr %t37, i64 %t38)
  %t60 = getelementptr i8, ptr %t59, i64 %t38
  call void @olang_textcopy(ptr %t60, ptr %t40, i64 %t41)
  %t61 = getelementptr i8, ptr %t60, i64 %t41
  call void @olang_textcopy(ptr %t61, ptr %t44, i64 %t45)
  %t62 = getelementptr i8, ptr %t61, i64 %t45
  call void @olang_textcopy(ptr %t62, ptr %t47, i64 %t48)
  %t63 = getelementptr i8, ptr %t62, i64 %t48
  %t64 = call i64 @__olang_fmt_i64(ptr %t63, i64 %t26)
  %t65 = getelementptr i8, ptr %t63, i64 %t51
  call void @olang_textcopy(ptr %t65, ptr %t53, i64 %t54)
  %t66 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t56, 1
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t70 = extractvalue { i64, ptr } %t67, 1
  %t71 = mul i64 %t69, 1
  %t72 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t70, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  %t77 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v3, ptr %v3, ptr %t22, { i64, ptr } %t74)
  store { i64, ptr } %t77, ptr %l25
  br label %bb8
bb8:
  %t78 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t78, ptr %rv
  br label %ret
bb9:
  %t79 = load i1, ptr %l4, !tbaa !21
  br i1 %t79, label %bb10, label %bb11
bb10:
  store { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d166, i32 0, i32 1) }, ptr %l27, !tbaa !27
  br label %bb12
bb11:
  store { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d167, i32 0, i32 1) }, ptr %l27, !tbaa !27
  br label %bb12
bb12:
  %t81 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t81, ptr %l7, !tbaa !27
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/emit:fnEm", ptr %t82, i32 0, i32 0
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t86 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t87 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %t87, ptr %t85, { i64, ptr } %t86)
  br label %bb13
bb13:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t92 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t93 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t94 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d168, i32 0, i32 1) }, 1
  %t95 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d168, i32 0, i32 1) }, 0
  %t97 = extractvalue { i64, ptr } %t91, 1
  %t98 = extractvalue { i64, ptr } %t91, 0
  %t99 = add i64 %t95, %t98
  %t100 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d169, i32 0, i32 1) }, 1
  %t101 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d169, i32 0, i32 1) }, 0
  %t102 = add i64 %t99, %t101
  %t104 = extractvalue { i64, ptr } %t92, 1
  %t105 = extractvalue { i64, ptr } %t92, 0
  %t106 = add i64 %t102, %t105
  %t107 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d170, i32 0, i32 1) }, 1
  %t108 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d170, i32 0, i32 1) }, 0
  %t109 = add i64 %t106, %t108
  %t111 = extractvalue { i64, ptr } %t93, 1
  %t112 = extractvalue { i64, ptr } %t93, 0
  %t113 = add i64 %t109, %t112
  %t114 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d171, i32 0, i32 1) }, 1
  %t115 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d171, i32 0, i32 1) }, 0
  %t116 = add i64 %t113, %t115
  %t117 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t116)
  call void @olang_textcopy(ptr %t117, ptr %t94, i64 %t95)
  %t118 = getelementptr i8, ptr %t117, i64 %t95
  call void @olang_textcopy(ptr %t118, ptr %t97, i64 %t98)
  %t119 = getelementptr i8, ptr %t118, i64 %t98
  call void @olang_textcopy(ptr %t119, ptr %t100, i64 %t101)
  %t120 = getelementptr i8, ptr %t119, i64 %t101
  call void @olang_textcopy(ptr %t120, ptr %t104, i64 %t105)
  %t121 = getelementptr i8, ptr %t120, i64 %t105
  call void @olang_textcopy(ptr %t121, ptr %t107, i64 %t108)
  %t122 = getelementptr i8, ptr %t121, i64 %t108
  call void @olang_textcopy(ptr %t122, ptr %t111, i64 %t112)
  %t123 = getelementptr i8, ptr %t122, i64 %t112
  call void @olang_textcopy(ptr %t123, ptr %t114, i64 %t115)
  %t124 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t117, 1
  %t127 = extractvalue { i64, ptr } %t125, 0
  %t128 = extractvalue { i64, ptr } %t125, 1
  %t129 = mul i64 %t127, 1
  %t130 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t129)
  call void @llvm.memcpy.p0.p0.i64(ptr %t130, ptr %t128, i64 %t129, i1 false)
  %t131 = insertvalue { i64, ptr } undef, i64 %t127, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  %t135 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v3, ptr %v3, ptr %t90, { i64, ptr } %t132)
  store { i64, ptr } %t135, ptr %l37
  br label %bb14
bb14:
  %t136 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t136, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ebitcast(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %lp5 = alloca ptr
  %l7 = alloca i1
  %l10 = alloca { i64, ptr }
  %l12 = alloca i1
  %l13 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l27 = alloca i1
  %l28 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d172, i32 0, i32 1) })
  store i1 %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load i1, ptr %l7, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ebf16Bits(ptr %v0, ptr %v1, ptr %v4, ptr %t5, { i64, ptr } %t6, i1 true)
  store { i64, ptr } %t9, ptr %l10
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t10 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t10, ptr %rv
  br label %ret
bb5:
  %t11 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t11, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d173, i32 0, i32 1) })
  store i1 %t13, ptr %l12
  br label %bb6
bb6:
  %t14 = load i1, ptr %l12, !tbaa !21
  br i1 %t14, label %bb7, label %bb8
bb7:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t19 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eopaque16(ptr %v0, ptr %v1, ptr %s0, ptr %t15, { i64, ptr } %t16)
  store { i64, ptr } %t19, ptr %l16
  br label %bb9
bb8:
  %t20 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 1
  %t23 = extractvalue { i64, ptr } %t20, 0
  %t24 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t22, i64 %t23)
  %t25 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  store { i64, ptr } %t26, ptr %l13, !tbaa !27
  br label %bb10
bb9:
  %t28 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t28, ptr %l13, !tbaa !27
  br label %bb10
bb10:
  %t29 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t34 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d174, i32 0, i32 1) }, 1
  %t35 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d174, i32 0, i32 1) }, 0
  %t37 = extractvalue { i64, ptr } %t31, 1
  %t38 = extractvalue { i64, ptr } %t31, 0
  %t39 = add i64 %t35, %t38
  %t40 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d175, i32 0, i32 1) }, 1
  %t41 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d175, i32 0, i32 1) }, 0
  %t42 = add i64 %t39, %t41
  %t44 = extractvalue { i64, ptr } %t29, 1
  %t45 = extractvalue { i64, ptr } %t29, 0
  %t46 = add i64 %t42, %t45
  %t47 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d176, i32 0, i32 1) }, 1
  %t48 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d176, i32 0, i32 1) }, 0
  %t49 = add i64 %t46, %t48
  %t51 = extractvalue { i64, ptr } %t33, 1
  %t52 = extractvalue { i64, ptr } %t33, 0
  %t53 = add i64 %t49, %t52
  %t54 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t53)
  call void @olang_textcopy(ptr %t54, ptr %t34, i64 %t35)
  %t55 = getelementptr i8, ptr %t54, i64 %t35
  call void @olang_textcopy(ptr %t55, ptr %t37, i64 %t38)
  %t56 = getelementptr i8, ptr %t55, i64 %t38
  call void @olang_textcopy(ptr %t56, ptr %t40, i64 %t41)
  %t57 = getelementptr i8, ptr %t56, i64 %t41
  call void @olang_textcopy(ptr %t57, ptr %t44, i64 %t45)
  %t58 = getelementptr i8, ptr %t57, i64 %t45
  call void @olang_textcopy(ptr %t58, ptr %t47, i64 %t48)
  %t59 = getelementptr i8, ptr %t58, i64 %t48
  call void @olang_textcopy(ptr %t59, ptr %t51, i64 %t52)
  %t60 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t54, 1
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t64 = extractvalue { i64, ptr } %t61, 1
  %t65 = mul i64 %t63, 1
  %t66 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t65)
  call void @llvm.memcpy.p0.p0.i64(ptr %t66, ptr %t64, i64 %t65, i1 false)
  %t67 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  %t71 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v4, ptr %v4, ptr %t30, { i64, ptr } %t68)
  store { i64, ptr } %t71, ptr %l25
  br label %bb11
bb11:
  %t72 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t72, ptr %lp5
  %t73 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t74 = load ptr, ptr %lp5
  store { i64, ptr } %t73, ptr %t74, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t77 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t75, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d177, i32 0, i32 1) })
  store i1 %t77, ptr %l27
  br label %bb12
bb12:
  %t78 = load i1, ptr %l27, !tbaa !21
  br i1 %t78, label %bb13, label %bb14
bb13:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load ptr, ptr %lp5
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  %t84 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eopaque16(ptr %v0, ptr %v4, ptr %v4, ptr %t79, { i64, ptr } %t81)
  store { i64, ptr } %t84, ptr %l31
  br label %bb15
bb14:
  %t85 = load ptr, ptr %lp5
  %t86 = load { i64, ptr }, ptr %t85, !tbaa !27
  store { i64, ptr } %t86, ptr %l28, !tbaa !27
  br label %bb16
bb15:
  %t88 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t88, ptr %l28, !tbaa !27
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s0)
  %t89 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t89, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2econstItem(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca { i64, [1 x i64] }
  %l5 = alloca i64
  %l6 = alloca i32
  %l8 = alloca i32
  %l9 = alloca { { i64, ptr }, { i64, ptr }, i64 }
  %lp10 = alloca ptr
  %l11 = alloca { { i64, ptr }, i64 }
  %lp12 = alloca ptr
  %l13 = alloca i64
  %l22 = alloca { i64, [1 x i64] }
  %l30 = alloca { i64, ptr }
  %l33 = alloca i32
  %l36 = alloca i1
  %l37 = alloca i32
  %l40 = alloca i32
  %l44 = alloca i32
  %l48 = alloca ptr
  %l51 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca { i64, ptr }
  %l60 = alloca i1
  %l61 = alloca i1
  %l64 = alloca i1
  %l66 = alloca ptr
  %l69 = alloca i32
  %l71 = alloca { { i64, ptr }, { i64, ptr }, i64 }
  %l72 = alloca { i64, ptr }
  %l73 = alloca i64
  %l74 = alloca { i64, ptr }
  %l76 = alloca ptr
  %l79 = alloca i32
  %l81 = alloca { { i64, ptr }, i64 }
  %l82 = alloca { i64, ptr }
  %l83 = alloca i64
  %l84 = alloca { i64, ptr }
  %l88 = alloca i1
  %l89 = alloca i1
  %l92 = alloca i1
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/emit:fnEm", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/mir:Fn", ptr %t12, i32 0, i32 19
  %t15 = load i32, ptr %l2, !tbaa !23
  %t17 = sext i32 %t15 to i64
  %t20 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2eAt_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %t14, i64 %t17)
  store { i64, [1 x i64] } %t20, ptr %l22
  br label %bb1
bb1:
  %t21 = load { i64, [1 x i64] }, ptr %l22
  store { i64, [1 x i64] } %t21, ptr %l4
  %t22 = load { i64, [1 x i64] }, ptr %l4
  %t24 = extractvalue { i64, [1 x i64] } %t22, 0
  %t25 = icmp eq i64 %t24, 0
  br i1 %t25, label %bb2, label %bb3
bb2:
  %t27 = getelementptr { i64, [1 x i64] }, ptr %l4, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  store i64 %t29, ptr %l5, !tbaa !24
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/emit:fnEm", ptr %t31, i32 0, i32 0
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t35 = load i32, ptr %l1, !tbaa !23
  %t36 = load i64, ptr %l5, !tbaa !24
  %t40 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2econstText(ptr %v0, ptr %v1, ptr %t34, i32 %t35, i64 %t36)
  store { i64, ptr } %t40, ptr %l30
  br label %bb5
bb5:
  %t41 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t41, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb42
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t42 = load ptr, ptr %l3, !tbaa !29
  %t43 = load i32, ptr %l1, !tbaa !23
  %t46 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t42, i32 %t43)
  store i32 %t46, ptr %l33
  br label %bb10
bb10:
  %t47 = load i32, ptr %l33, !tbaa !23
  store i32 %t47, ptr %l6, !tbaa !23
  %t48 = load ptr, ptr %l3, !tbaa !29
  %t49 = load i32, ptr %l6, !tbaa !23
  %t52 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t48, i32 %t49)
  store i1 %t52, ptr %l36
  br label %bb11
bb11:
  %t53 = load i1, ptr %l36, !tbaa !21
  br i1 %t53, label %bb12, label %bb13
bb12:
  %t54 = load ptr, ptr %l3, !tbaa !29
  %t55 = load i32, ptr %l6, !tbaa !23
  %t58 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t54, i32 %t55)
  store i32 %t58, ptr %l40
  br label %bb14
bb13:
  %t59 = load i32, ptr %l6, !tbaa !23
  store i32 %t59, ptr %l37, !tbaa !23
  br label %bb15
bb14:
  %t61 = load i32, ptr %l40, !tbaa !23
  store i32 %t61, ptr %l37, !tbaa !23
  br label %bb15
bb15:
  %t62 = load i32, ptr %l37, !tbaa !23
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t67 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %t63, i32 %t62)
  store i32 %t67, ptr %l44
  br label %bb16
bb16:
  %t68 = load i32, ptr %l44, !tbaa !23
  store i32 %t68, ptr %l8, !tbaa !23
  %t69 = load i32, ptr %l8, !tbaa !23
  %t70 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t73 = icmp eq i32 %t69, %t70
  br i1 %t73, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l48, !tbaa !29
  %t76 = load ptr, ptr %l3, !tbaa !29
  %t77 = load i32, ptr %l1, !tbaa !23
  %t80 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s3, ptr %t76, i32 %t77)
  store { i64, ptr } %t80, ptr %l51
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t81 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d178, i32 0, i32 1) }, 1
  %t82 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d178, i32 0, i32 1) }, 0
  %t83 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 1
  %t85 = extractvalue { i64, ptr } %t83, 0
  %t86 = add i64 %t82, %t85
  %t87 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t86)
  call void @olang_textcopy(ptr %t87, ptr %t81, i64 %t82)
  %t88 = getelementptr i8, ptr %t87, i64 %t82
  call void @olang_textcopy(ptr %t88, ptr %t84, i64 %t85)
  %t89 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t87, 1
  %t92 = extractvalue { i64, ptr } %t90, 0
  %t93 = extractvalue { i64, ptr } %t90, 1
  %t94 = mul i64 %t92, 1
  %t95 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t94)
  call void @llvm.memcpy.p0.p0.i64(ptr %t95, ptr %t93, i64 %t94, i1 false)
  %t96 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t95, 1
  %t98 = load ptr, ptr %l48, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s3, ptr %t98, { i64, ptr } %t97)
  br label %bb20
bb20:
  store { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d179, i32 0, i32 1) }, ptr %l54, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t100, ptr %l55, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 0
  store i64 %t102, ptr %l56, !tbaa !24
  %t103 = load i64, ptr %l56, !tbaa !24
  %t104 = mul i64 %t103, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t104)
  %t106 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  store { i64, ptr } %t107, ptr %l57, !tbaa !27
  %t108 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = load i64, ptr %l56, !tbaa !24
  %t113 = mul i64 %t112, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t109, ptr %t111, i64 %t113, i1 false)
  %t114 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t114, ptr %l55, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  %t115 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t115, ptr %rv
  br label %ret
bb21:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load i32, ptr %l8, !tbaa !23
  %t120 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixed(ptr %v0, ptr %t116, i32 %t117)
  store i1 %t120, ptr %l60
  br label %bb22
bb22:
  %t121 = load i1, ptr %l60, !tbaa !21
  br i1 %t121, label %bb23, label %bb24
bb23:
  %t122 = load ptr, ptr %l3, !tbaa !29
  %t123 = load i32, ptr %l6, !tbaa !23
  %t126 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t122, i32 %t123)
  store i1 %t126, ptr %l64
  br label %bb25
bb24:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb26
bb25:
  %t127 = load i1, ptr %l64, !tbaa !21
  %t128 = xor i1 %t127, true
  store i1 %t128, ptr %l61, !tbaa !21
  br label %bb26
bb26:
  %t130 = load i1, ptr %l61, !tbaa !21
  br i1 %t130, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s5
  %t131 = load ptr, ptr %l0, !tbaa !29
  store ptr %t131, ptr %l66, !tbaa !29
  %t132 = load ptr, ptr %l3, !tbaa !29
  %t133 = load i32, ptr %l8, !tbaa !23
  %t136 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t132, i32 %t133)
  store i32 %t136, ptr %l69
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t137 = load i32, ptr %l2, !tbaa !23
  %t138 = load ptr, ptr %l66, !tbaa !29
  %t139 = load i32, ptr %l69, !tbaa !23
  %t141 = call { { i64, ptr }, { i64, ptr }, i64 } @compiler_2femit_2ecompiler_2femit_3afnEm_2econstInit(ptr %v0, ptr %s5, ptr %t138, i32 %t139, i32 %t137)
  store { { i64, ptr }, { i64, ptr }, i64 } %t141, ptr %l71
  br label %bb30
bb30:
  %t142 = load { { i64, ptr }, { i64, ptr }, i64 }, ptr %l71
  store { { i64, ptr }, { i64, ptr }, i64 } %t142, ptr %l9
  %t143 = getelementptr { { i64, ptr }, { i64, ptr }, i64 }, ptr %l9, i32 0, i32 1
  %t144 = load { i64, ptr }, ptr %t143, !tbaa !27
  store { i64, ptr } %t144, ptr %l72, !tbaa !27
  %t145 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t145, 0
  store i64 %t146, ptr %l73, !tbaa !24
  %t147 = load i64, ptr %l73, !tbaa !24
  %t148 = mul i64 %t147, 1
  %t149 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t148)
  %t150 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  store { i64, ptr } %t151, ptr %l74, !tbaa !27
  %t152 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = load i64, ptr %l73, !tbaa !24
  %t157 = mul i64 %t156, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t153, ptr %t155, i64 %t157, i1 false)
  %t158 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t158, ptr %lp10
  %t159 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t160 = load ptr, ptr %lp10
  store { i64, ptr } %t159, ptr %t160, !tbaa !27
  %t161 = load ptr, ptr %lp10
  %t162 = load { i64, ptr }, ptr %t161, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s2)
  store { i64, ptr } %t162, ptr %rv
  br label %ret
bb31:
  %t164 = load ptr, ptr %l0, !tbaa !29
  store ptr %t164, ptr %l76, !tbaa !29
  %t165 = load ptr, ptr %l3, !tbaa !29
  %t166 = load i32, ptr %l8, !tbaa !23
  %t169 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t165, i32 %t166)
  store i32 %t169, ptr %l79
  br label %bb32
bb32:
  %t170 = load i32, ptr %l2, !tbaa !23
  %t171 = load ptr, ptr %l76, !tbaa !29
  %t172 = load i32, ptr %l79, !tbaa !23
  %t174 = call { { i64, ptr }, i64 } @compiler_2femit_2ecompiler_2femit_3afnEm_2econstGlobal(ptr %v0, ptr %s2, ptr %s2, ptr %t171, i32 %t172, i32 %t170, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d180, i32 0, i32 1) })
  store { { i64, ptr }, i64 } %t174, ptr %l81
  br label %bb33
bb33:
  %t175 = load { { i64, ptr }, i64 }, ptr %l81
  store { { i64, ptr }, i64 } %t175, ptr %l11
  %t176 = getelementptr { { i64, ptr }, i64 }, ptr %l11, i32 0, i32 0
  %t177 = load { i64, ptr }, ptr %t176, !tbaa !27
  store { i64, ptr } %t177, ptr %l82, !tbaa !27
  %t178 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t178, 0
  store i64 %t179, ptr %l83, !tbaa !24
  %t180 = load i64, ptr %l83, !tbaa !24
  %t181 = mul i64 %t180, 1
  %t182 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t181)
  %t183 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t182, 1
  store { i64, ptr } %t184, ptr %l84, !tbaa !27
  %t185 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !27
  %t187 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !27
  %t189 = load i64, ptr %l83, !tbaa !24
  %t190 = mul i64 %t189, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t186, ptr %t188, i64 %t190, i1 false)
  %t191 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t191, ptr %lp12
  %t192 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t193 = load ptr, ptr %lp12
  store { i64, ptr } %t192, ptr %t193, !tbaa !27
  %t194 = getelementptr { { i64, ptr }, i64 }, ptr %l11, i32 0, i32 1
  %t195 = load i64, ptr %t194, !tbaa !24
  store i64 %t195, ptr %l13, !tbaa !24
  %t197 = load ptr, ptr %l3, !tbaa !29
  %t198 = load i32, ptr %l6, !tbaa !23
  %t201 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t197, i32 %t198)
  store i1 %t201, ptr %l88
  br label %bb34
bb34:
  %t202 = load i1, ptr %l88, !tbaa !21
  br i1 %t202, label %bb35, label %bb36
bb35:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load i32, ptr %l8, !tbaa !23
  %t207 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixed(ptr %v0, ptr %t203, i32 %t204)
  store i1 %t207, ptr %l92
  br label %bb37
bb36:
  store i1 false, ptr %l89, !tbaa !21
  br label %bb38
bb37:
  %t208 = load i1, ptr %l92, !tbaa !21
  store i1 %t208, ptr %l89, !tbaa !21
  br label %bb38
bb38:
  %t209 = load i1, ptr %l89, !tbaa !21
  br i1 %t209, label %bb39, label %bb40
bb39:
  %t210 = load ptr, ptr %lp12
  %t211 = load { i64, ptr }, ptr %t210, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  store { i64, ptr } %t211, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t213 = load i64, ptr %l13, !tbaa !24
  %t214 = load ptr, ptr %lp12
  %t215 = load { i64, ptr }, ptr %t214, !tbaa !27
  %t216 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d181, i32 0, i32 1) }, 1
  %t217 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d181, i32 0, i32 1) }, 0
  %t219 = call i64 @__olang_fmt_i64(ptr null, i64 %t213)
  %t220 = add i64 %t217, %t219
  %t221 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d182, i32 0, i32 1) }, 1
  %t222 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d182, i32 0, i32 1) }, 0
  %t223 = add i64 %t220, %t222
  %t225 = extractvalue { i64, ptr } %t215, 1
  %t226 = extractvalue { i64, ptr } %t215, 0
  %t227 = add i64 %t223, %t226
  %t228 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d183, i32 0, i32 1) }, 1
  %t229 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d183, i32 0, i32 1) }, 0
  %t230 = add i64 %t227, %t229
  %t231 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t230)
  call void @olang_textcopy(ptr %t231, ptr %t216, i64 %t217)
  %t232 = getelementptr i8, ptr %t231, i64 %t217
  %t233 = call i64 @__olang_fmt_i64(ptr %t232, i64 %t213)
  %t234 = getelementptr i8, ptr %t232, i64 %t219
  call void @olang_textcopy(ptr %t234, ptr %t221, i64 %t222)
  %t235 = getelementptr i8, ptr %t234, i64 %t222
  call void @olang_textcopy(ptr %t235, ptr %t225, i64 %t226)
  %t236 = getelementptr i8, ptr %t235, i64 %t226
  call void @olang_textcopy(ptr %t236, ptr %t228, i64 %t229)
  %t237 = insertvalue { i64, ptr } undef, i64 %t230, 0
  %t238 = insertvalue { i64, ptr } %t237, ptr %t231, 1
  call void @__olang_scope_close(ptr %s2)
  store { i64, ptr } %t238, ptr %rv
  br label %ret
bb42:
  call void @__olang_check_failed(ptr @olang_loc_3de177096d03f952_4b04555d717d3dfe)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2econstText(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca { i64, [1 x i64] }
  %l4 = alloca %"compiler/mir:Range"
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l11 = alloca %"std/prelude/text:StringBuilder"
  %l17 = alloca { i64, [1 x i64] }
  %l25 = alloca i32
  %l28 = alloca i32
  %l46 = alloca ptr
  %l55 = alloca i8
  %l60 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca i64
  %l63 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l11
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/emit:fnEm", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = getelementptr %"compiler/mir:Fn", ptr %t6, i32 0, i32 19
  %t11 = sext i32 %a1 to i64
  %t14 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2eAt_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %t8, i64 %t11)
  store { i64, [1 x i64] } %t14, ptr %l17
  br label %bb2
bb2:
  %t15 = load { i64, [1 x i64] }, ptr %l17
  store { i64, [1 x i64] } %t15, ptr %l3
  %t16 = load { i64, [1 x i64] }, ptr %l3
  %t18 = extractvalue { i64, [1 x i64] } %t16, 0
  %t19 = icmp eq i64 %t18, 1
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = getelementptr { i64, [1 x i64] }, ptr %l3, i32 0, i32 1
  %t22 = getelementptr { %"compiler/mir:Range" }, ptr %t21, i32 0, i32 0
  %t23 = load %"compiler/mir:Range", ptr %t22
  store %"compiler/mir:Range" %t23, ptr %l4
  br label %bb5
bb4:
  br label %bb20
bb5:
  store i32 0, ptr %l5, !tbaa !23
  %t25 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 1
  %t26 = load i32, ptr %t25, !tbaa !23
  store i32 %t26, ptr %l6, !tbaa !23
  store i32 1, ptr %l7, !tbaa !23
  %t28 = load i32, ptr %l6, !tbaa !23
  %t29 = load i32, ptr %l5, !tbaa !23
  %t32 = icmp sgt i32 %t28, %t29
  br i1 %t32, label %bb6, label %bb7
bb6:
  %t34 = load i32, ptr %l7, !tbaa !23
  %t36 = icmp sgt i32 %t34, 0
  br i1 %t36, label %bb8, label %bb9
bb7:
  store i32 0, ptr %l25, !tbaa !23
  br label %bb11
bb8:
  %t38 = load i32, ptr %l6, !tbaa !23
  %t39 = load i32, ptr %l5, !tbaa !23
  %t42 = sub i32 %t38, %t39
  %t43 = load i32, ptr %l7, !tbaa !23
  %t46 = add i32 %t42, %t43
  %t48 = sub i32 %t46, 1
  %t49 = load i32, ptr %l7, !tbaa !23
  %t52 = sdiv i32 %t48, %t49
  store i32 %t52, ptr %l28, !tbaa !23
  br label %bb10
bb9:
  store i32 0, ptr %l28, !tbaa !23
  br label %bb10
bb10:
  %t54 = load i32, ptr %l28, !tbaa !23
  store i32 %t54, ptr %l25, !tbaa !23
  br label %bb11
bb11:
  %t55 = load i32, ptr %l25, !tbaa !23
  store i32 %t55, ptr %l8, !tbaa !23
  store i32 0, ptr %l9, !tbaa !23
  br label %bb12
bb12:
  %t56 = load i32, ptr %l9, !tbaa !23
  %t57 = load i32, ptr %l8, !tbaa !23
  %t60 = icmp slt i32 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb13, label %bb14
bb13:
  br label %bb19
bb14:
  br label %bb15
bb15:
  %t64 = load i32, ptr %l5, !tbaa !23
  %t65 = load i32, ptr %l9, !tbaa !23
  %t66 = load i32, ptr %l7, !tbaa !23
  %t69 = mul i32 %t65, %t66
  %t72 = add i32 %t64, %t69
  store ptr %l2, ptr %l46, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/emit:fnEm", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/mir:Fn", ptr %t77, i32 0, i32 21
  %t80 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 0
  %t81 = load i32, ptr %t80, !tbaa !23
  %t83 = sext i32 %t81 to i64
  %t86 = sext i32 %t72 to i64
  %t89 = add i64 %t83, %t86
  %t92 = call i8 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eAt_3cU8_3e(ptr %v0, ptr %t79, i64 %t89)
  store i8 %t92, ptr %l55
  br label %bb16
bb16:
  %t93 = load i8, ptr %l55, !tbaa !22
  %t94 = load ptr, ptr %l46, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t94, i8 %t93)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t96 = load i32, ptr %l9, !tbaa !23
  %t98 = add i32 %t96, 1
  store i32 %t98, ptr %l9, !tbaa !23
  br label %bb12
bb19:
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_a00373ca27d5619a_9315010cb9ead296)
  unreachable
bb25:
  %t101 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t101, ptr %l60
  br label %bb26
bb26:
  %t102 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t102, ptr %l61, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 0
  store i64 %t104, ptr %l62, !tbaa !24
  %t105 = load i64, ptr %l62, !tbaa !24
  %t106 = mul i64 %t105, 1
  %t107 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t106)
  %t108 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t107, 1
  store { i64, ptr } %t109, ptr %l63, !tbaa !27
  %t110 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = load i64, ptr %l62, !tbaa !24
  %t115 = mul i64 %t114, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t111, ptr %t113, i64 %t115, i1 false)
  %t116 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t116, ptr %l61, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t117 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t117, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eelemAt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l14 = alloca i32
  %l25 = alloca i32
  %l28 = alloca i1
  %l29 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l40 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, i32 }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l5, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t13 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %t9, i32 %a2)
  store i32 %t13, ptr %l14
  br label %bb1
bb1:
  %t14 = load i32, ptr %l14, !tbaa !23
  store i32 %t14, ptr %l6, !tbaa !23
  %t15 = load i32, ptr %l6, !tbaa !23
  %t16 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t19 = icmp eq i32 %t15, %t16
  br i1 %t19, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t21 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s1, ptr %t21, { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d184, i32 0, i32 1) })
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = extractvalue { i64, ptr } %t23, 0
  %t27 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t25, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  %t30 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t32 = insertvalue { { i64, ptr }, i32 } undef, { i64, ptr } %t29, 0
  %t34 = insertvalue { { i64, ptr }, i32 } %t32, i32 %t30, 1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i32 } %t34, ptr %rv
  br label %ret
bb5:
  %t36 = load ptr, ptr %l5, !tbaa !29
  %t37 = load i32, ptr %l6, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t40, ptr %l25
  br label %bb6
bb6:
  %t41 = load i32, ptr %l25, !tbaa !23
  store i32 %t41, ptr %l7, !tbaa !23
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l6, !tbaa !23
  %t46 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixed(ptr %v0, ptr %t42, i32 %t43)
  store i1 %t46, ptr %l28
  br label %bb7
bb7:
  %t47 = load i1, ptr %l28, !tbaa !21
  br i1 %t47, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l29, !tbaa !29
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i32, ptr %l6, !tbaa !23
  %t53 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s3, ptr %t49, i32 %t50)
  store { i64, ptr } %t53, ptr %l32
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t54 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t56 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d185, i32 0, i32 1) }, 1
  %t57 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d185, i32 0, i32 1) }, 0
  %t58 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t58, 1
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t61 = add i64 %t57, %t60
  %t62 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d186, i32 0, i32 1) }, 1
  %t63 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d186, i32 0, i32 1) }, 0
  %t64 = add i64 %t61, %t63
  %t66 = extractvalue { i64, ptr } %t54, 1
  %t67 = extractvalue { i64, ptr } %t54, 0
  %t68 = add i64 %t64, %t67
  %t69 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d187, i32 0, i32 1) }, 1
  %t70 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d187, i32 0, i32 1) }, 0
  %t71 = add i64 %t68, %t70
  %t73 = extractvalue { i64, ptr } %t55, 1
  %t74 = extractvalue { i64, ptr } %t55, 0
  %t75 = add i64 %t71, %t74
  %t76 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t75)
  call void @olang_textcopy(ptr %t76, ptr %t56, i64 %t57)
  %t77 = getelementptr i8, ptr %t76, i64 %t57
  call void @olang_textcopy(ptr %t77, ptr %t59, i64 %t60)
  %t78 = getelementptr i8, ptr %t77, i64 %t60
  call void @olang_textcopy(ptr %t78, ptr %t62, i64 %t63)
  %t79 = getelementptr i8, ptr %t78, i64 %t63
  call void @olang_textcopy(ptr %t79, ptr %t66, i64 %t67)
  %t80 = getelementptr i8, ptr %t79, i64 %t67
  call void @olang_textcopy(ptr %t80, ptr %t69, i64 %t70)
  %t81 = getelementptr i8, ptr %t80, i64 %t70
  call void @olang_textcopy(ptr %t81, ptr %t73, i64 %t74)
  %t82 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t76, 1
  %t85 = extractvalue { i64, ptr } %t83, 0
  %t86 = extractvalue { i64, ptr } %t83, 1
  %t87 = mul i64 %t85, 1
  %t88 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t87)
  call void @llvm.memcpy.p0.p0.i64(ptr %t88, ptr %t86, i64 %t87, i1 false)
  %t89 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  %t91 = load ptr, ptr %l29, !tbaa !29
  %t93 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v4, ptr %v4, ptr %t91, { i64, ptr } %t90)
  store { i64, ptr } %t93, ptr %l37
  br label %bb11
bb11:
  %t94 = load i32, ptr %l7, !tbaa !23
  %t95 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t96 = insertvalue { { i64, ptr }, i32 } undef, { i64, ptr } %t95, 0
  %t98 = insertvalue { { i64, ptr }, i32 } %t96, i32 %t94, 1
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i32 } %t98, ptr %rv
  br label %ret
bb12:
  %t100 = load ptr, ptr %l0, !tbaa !29
  store ptr %t100, ptr %l40, !tbaa !29
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t103 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d188, i32 0, i32 1) }, 1
  %t104 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d188, i32 0, i32 1) }, 0
  %t106 = extractvalue { i64, ptr } %t102, 1
  %t107 = extractvalue { i64, ptr } %t102, 0
  %t108 = add i64 %t104, %t107
  %t109 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d189, i32 0, i32 1) }, 1
  %t110 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d189, i32 0, i32 1) }, 0
  %t111 = add i64 %t108, %t110
  %t112 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t111)
  call void @olang_textcopy(ptr %t112, ptr %t103, i64 %t104)
  %t113 = getelementptr i8, ptr %t112, i64 %t104
  call void @olang_textcopy(ptr %t113, ptr %t106, i64 %t107)
  %t114 = getelementptr i8, ptr %t113, i64 %t107
  call void @olang_textcopy(ptr %t114, ptr %t109, i64 %t110)
  %t115 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t112, 1
  %t118 = extractvalue { i64, ptr } %t116, 0
  %t119 = extractvalue { i64, ptr } %t116, 1
  %t120 = mul i64 %t118, 1
  %t121 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t120)
  call void @llvm.memcpy.p0.p0.i64(ptr %t121, ptr %t119, i64 %t120, i1 false)
  %t122 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t121, 1
  %t126 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t101, { i64, ptr } %t123)
  store { i64, ptr } %t126, ptr %l45
  br label %bb13
bb13:
  %t127 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t127, 0
  %t129 = extractvalue { i64, ptr } %t127, 1
  %t130 = mul i64 %t128, 1
  %t131 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t130)
  call void @llvm.memcpy.p0.p0.i64(ptr %t131, ptr %t129, i64 %t130, i1 false)
  %t132 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr %t131, 1
  %t135 = load ptr, ptr %l40, !tbaa !29
  %t138 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s0, ptr %s0, ptr %v3, ptr %s0, ptr %t135, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d190, i32 0, i32 1) }, { i64, ptr } %t133, { i64, ptr } %a4)
  store { i64, ptr } %t138, ptr %l48
  br label %bb14
bb14:
  %t139 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t139, ptr %l8, !tbaa !27
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l49, !tbaa !29
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load i32, ptr %l7, !tbaa !23
  %t145 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s0, ptr %t141, i32 %t142)
  store { i64, ptr } %t145, ptr %l52
  br label %bb15
bb15:
  %t146 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t147 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t148 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d191, i32 0, i32 1) }, 1
  %t149 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d191, i32 0, i32 1) }, 0
  %t150 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t151 = extractvalue { i64, ptr } %t150, 1
  %t152 = extractvalue { i64, ptr } %t150, 0
  %t153 = add i64 %t149, %t152
  %t154 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d192, i32 0, i32 1) }, 1
  %t155 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d192, i32 0, i32 1) }, 0
  %t156 = add i64 %t153, %t155
  %t158 = extractvalue { i64, ptr } %t146, 1
  %t159 = extractvalue { i64, ptr } %t146, 0
  %t160 = add i64 %t156, %t159
  %t161 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d193, i32 0, i32 1) }, 1
  %t162 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d193, i32 0, i32 1) }, 0
  %t163 = add i64 %t160, %t162
  %t165 = extractvalue { i64, ptr } %t147, 1
  %t166 = extractvalue { i64, ptr } %t147, 0
  %t167 = add i64 %t163, %t166
  %t168 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t167)
  call void @olang_textcopy(ptr %t168, ptr %t148, i64 %t149)
  %t169 = getelementptr i8, ptr %t168, i64 %t149
  call void @olang_textcopy(ptr %t169, ptr %t151, i64 %t152)
  %t170 = getelementptr i8, ptr %t169, i64 %t152
  call void @olang_textcopy(ptr %t170, ptr %t154, i64 %t155)
  %t171 = getelementptr i8, ptr %t170, i64 %t155
  call void @olang_textcopy(ptr %t171, ptr %t158, i64 %t159)
  %t172 = getelementptr i8, ptr %t171, i64 %t159
  call void @olang_textcopy(ptr %t172, ptr %t161, i64 %t162)
  %t173 = getelementptr i8, ptr %t172, i64 %t162
  call void @olang_textcopy(ptr %t173, ptr %t165, i64 %t166)
  %t174 = insertvalue { i64, ptr } undef, i64 %t167, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t168, 1
  %t177 = extractvalue { i64, ptr } %t175, 0
  %t178 = extractvalue { i64, ptr } %t175, 1
  %t179 = mul i64 %t177, 1
  %t180 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t179)
  call void @llvm.memcpy.p0.p0.i64(ptr %t180, ptr %t178, i64 %t179, i1 false)
  %t181 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  %t183 = load ptr, ptr %l49, !tbaa !29
  %t185 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v4, ptr %v4, ptr %t183, { i64, ptr } %t182)
  store { i64, ptr } %t185, ptr %l57
  br label %bb16
bb16:
  %t186 = load i32, ptr %l7, !tbaa !23
  %t187 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t188 = insertvalue { { i64, ptr }, i32 } undef, { i64, ptr } %t187, 0
  %t190 = insertvalue { { i64, ptr }, i32 } %t188, i32 %t186, 1
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i32 } %t190, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, i32 }, ptr %rv
  ret { { i64, ptr }, i32 } %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixed(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t7, i32 %a1)
  store i32 %t11, ptr %l6
  br label %bb1
bb1:
  %t12 = load i32, ptr %l6, !tbaa !23
  %t13 = icmp ne i32 %t12, 0
  store i1 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalAt(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l8 = alloca %"compiler/mir:Local"
  %l10 = alloca i1
  %l17 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/emit:fnEm", ptr %t2, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t7 = getelementptr %"compiler/mir:Fn", ptr %t5, i32 0, i32 7
  %t8 = load i32, ptr %l1, !tbaa !23
  %t10 = sext i32 %t8 to i64
  %t13 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t7, i64 %t10)
  store %"compiler/mir:Local" %t13, ptr %l8
  br label %bb1
bb1:
  %t14 = getelementptr %"compiler/mir:Local", ptr %l8, i32 0, i32 4
  %t15 = load { i64, [1 x i64] }, ptr %t14
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eisFrame(ptr %v0, ptr %t16, { i64, [1 x i64] } %t15)
  store i1 %t18, ptr %l10
  br label %bb2
bb2:
  %t19 = load i1, ptr %l10, !tbaa !21
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t20 = load i32, ptr %l1, !tbaa !23
  %t21 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d194, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d194, i32 0, i32 1) }, 0
  %t24 = sext i32 %t20 to i64
  %t25 = call i64 @__olang_fmt_i64(ptr null, i64 %t24)
  %t26 = add i64 %t22, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t21, i64 %t22)
  %t28 = getelementptr i8, ptr %t27, i64 %t22
  %t29 = call i64 @__olang_fmt_i64(ptr %t28, i64 %t24)
  %t30 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t27, 1
  store { i64, ptr } %t31, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l1, !tbaa !23
  %t35 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d195, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d195, i32 0, i32 1) }, 0
  %t38 = sext i32 %t34 to i64
  %t39 = call i64 @__olang_fmt_i64(ptr null, i64 %t38)
  %t40 = add i64 %t36, %t39
  %t41 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t40)
  call void @olang_textcopy(ptr %t41, ptr %t35, i64 %t36)
  %t42 = getelementptr i8, ptr %t41, i64 %t36
  %t43 = call i64 @__olang_fmt_i64(ptr %t42, i64 %t38)
  %t44 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t41, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = extractvalue { i64, ptr } %t45, 1
  %t49 = mul i64 %t47, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t49)
  call void @llvm.memcpy.p0.p0.i64(ptr %t50, ptr %t48, i64 %t49, i1 false)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  %t55 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %t33, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d196, i32 0, i32 1) }, { i64, ptr } %t52, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d197, i32 0, i32 1) })
  store { i64, ptr } %t55, ptr %l17
  br label %bb6
bb6:
  %t56 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t56, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2elocate(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l4 = alloca i1
  %l12 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t2 = load i32, ptr %t1, !tbaa !23
  %t4 = icmp eq i32 %t2, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t7 = load i32, ptr %t6, !tbaa !23
  %t9 = icmp eq i32 %t7, 0
  store i1 %t9, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l4, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t12 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t13 = load i32, ptr %t12, !tbaa !23
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/emit:fnEm", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/mir:Fn", ptr %t17, i32 0, i32 3
  %t20 = getelementptr %"compiler/source:Span", ptr %t19, i32 0, i32 0
  %t21 = load i32, ptr %t20, !tbaa !23
  %t24 = icmp eq i32 %t13, %t21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t26 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t27 = load i32, ptr %t26, !tbaa !23
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/emit:fnEm", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/mir:Fn", ptr %t31, i32 0, i32 3
  %t34 = getelementptr %"compiler/source:Span", ptr %t33, i32 0, i32 1
  %t35 = load i32, ptr %t34, !tbaa !23
  %t38 = icmp eq i32 %t27, %t35
  store i1 %t38, ptr %l12, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb9
bb9:
  %t40 = load i1, ptr %l12, !tbaa !21
  br i1 %t40, label %bb10, label %bb11
bb10:
  br label %ret
bb11:
  br label %bb12
bb12:
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l18, !tbaa !29
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l19, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/emit:fnEm", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/emit:Emitter", ptr %t46, i32 0, i32 2
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/emit:fnEm", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/mir:Fn", ptr %t53, i32 0, i32 2
  %t56 = load i64, ptr %t55, !tbaa !24
  %t57 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t58 = load i32, ptr %t57, !tbaa !23
  %t60 = sext i32 %t58 to i64
  %t64 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %t49, i64 %t56, i64 %t60)
  store i64 %t64, ptr %l28
  br label %bb13
bb13:
  %t65 = load ptr, ptr %l19, !tbaa !29
  %t66 = load i64, ptr %l28, !tbaa !24
  %t67 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edbgLine(ptr %v0, ptr %v0, ptr %t65, i64 %t66)
  store { i64, ptr } %t67, ptr %l29
  br label %bb14
bb14:
  %t68 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  %t70 = extractvalue { i64, ptr } %t68, 1
  %t71 = mul i64 %t69, 1
  %t72 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t70, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  %t76 = load ptr, ptr %l18, !tbaa !29
  %t77 = getelementptr %"compiler/emit:fnEm", ptr %t76, i32 0, i32 19
  store { i64, ptr } %t74, ptr %t77, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eparts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, %"compiler/mir:Range" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %lp5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l25 = alloca i64
  %l28 = alloca i64
  %l46 = alloca ptr
  %l50 = alloca { i64, [4 x i64] }
  %l51 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l69 = alloca i64
  %l76 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l78 = alloca i64
  %l79 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s0, ptr %t1, i32 %a1)
  store { i64, ptr } %t5, ptr %l15
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t6, ptr %l4, !tbaa !27
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d198, i32 0, i32 1) }, ptr %l16, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t7, ptr %l17, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l18, !tbaa !24
  %t10 = load i64, ptr %l18, !tbaa !24
  %t11 = mul i64 %t10, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l19, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l18, !tbaa !24
  %t20 = mul i64 %t19, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %t18, i64 %t20, i1 false)
  %t21 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t21, ptr %lp5
  %t22 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t23 = load ptr, ptr %lp5
  store { i64, ptr } %t22, ptr %t23, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t24 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  store i64 %t26, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t28 = load i64, ptr %l7, !tbaa !24
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = icmp sgt i64 %t28, %t29
  br i1 %t32, label %bb2, label %bb3
bb2:
  %t34 = load i64, ptr %l8, !tbaa !24
  %t36 = icmp sgt i64 %t34, 0
  br i1 %t36, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb7
bb4:
  %t38 = load i64, ptr %l7, !tbaa !24
  %t39 = load i64, ptr %l6, !tbaa !24
  %t42 = sub i64 %t38, %t39
  %t43 = load i64, ptr %l8, !tbaa !24
  %t46 = add i64 %t42, %t43
  %t48 = sub i64 %t46, 1
  %t49 = load i64, ptr %l8, !tbaa !24
  %t52 = sdiv i64 %t48, %t49
  store i64 %t52, ptr %l28, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb6
bb6:
  %t54 = load i64, ptr %l28, !tbaa !24
  store i64 %t54, ptr %l25, !tbaa !24
  br label %bb7
bb7:
  %t55 = load i64, ptr %l25, !tbaa !24
  store i64 %t55, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t56 = load i64, ptr %l10, !tbaa !24
  %t57 = load i64, ptr %l9, !tbaa !24
  %t60 = icmp slt i64 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb10:
  br label %bb11
bb11:
  %t64 = load i64, ptr %l6, !tbaa !24
  %t65 = load i64, ptr %l10, !tbaa !24
  %t66 = load i64, ptr %l8, !tbaa !24
  %t69 = mul i64 %t65, %t66
  %t72 = add i64 %t64, %t69
  store i64 %t72, ptr %l11, !tbaa !24
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l46, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = load i64, ptr %l11, !tbaa !24
  %t81 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t75, %"compiler/mir:Range" %a3, i64 %t77)
  store { i64, [4 x i64] } %t81, ptr %l50
  br label %bb12
bb12:
  %t82 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t82, ptr %l51, !tbaa !27
  %t83 = load i64, ptr %l11, !tbaa !24
  %t85 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr i32, ptr %t86, i64 %t83
  %t88 = load i32, ptr %t87, !tbaa !33
  %t89 = load ptr, ptr %l46, !tbaa !29
  %t90 = load { i64, [4 x i64] }, ptr %l50
  %t92 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s2, ptr %t89, { i64, [4 x i64] } %t90, i32 %t88)
  store { i64, ptr } %t92, ptr %l54
  br label %bb13
bb13:
  %t93 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t93, ptr %l12, !tbaa !27
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l55, !tbaa !29
  %t95 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t95, ptr %l56, !tbaa !27
  %t96 = load ptr, ptr %lp5
  %t97 = load { i64, ptr }, ptr %t96, !tbaa !27
  store { i64, ptr } %t97, ptr %l57, !tbaa !27
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t99, ptr %l59, !tbaa !27
  %t100 = load i64, ptr %l11, !tbaa !24
  %t102 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr i32, ptr %t103, i64 %t100
  %t105 = load i32, ptr %t104, !tbaa !33
  %t108 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s2, ptr %t98, i32 %t105)
  store { i64, ptr } %t108, ptr %l62
  br label %bb14
bb14:
  %t109 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t110 = load i64, ptr %l11, !tbaa !24
  %t111 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d199, i32 0, i32 1) }, 1
  %t112 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d199, i32 0, i32 1) }, 0
  %t113 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 1
  %t115 = extractvalue { i64, ptr } %t113, 0
  %t116 = add i64 %t112, %t115
  %t117 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d200, i32 0, i32 1) }, 1
  %t118 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d200, i32 0, i32 1) }, 0
  %t119 = add i64 %t116, %t118
  %t120 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t120, 1
  %t122 = extractvalue { i64, ptr } %t120, 0
  %t123 = add i64 %t119, %t122
  %t124 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d201, i32 0, i32 1) }, 1
  %t125 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d201, i32 0, i32 1) }, 0
  %t126 = add i64 %t123, %t125
  %t127 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t127, 1
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t130 = add i64 %t126, %t129
  %t131 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d200, i32 0, i32 1) }, 1
  %t132 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d200, i32 0, i32 1) }, 0
  %t133 = add i64 %t130, %t132
  %t135 = extractvalue { i64, ptr } %t109, 1
  %t136 = extractvalue { i64, ptr } %t109, 0
  %t137 = add i64 %t133, %t136
  %t138 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d201, i32 0, i32 1) }, 1
  %t139 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d201, i32 0, i32 1) }, 0
  %t140 = add i64 %t137, %t139
  %t142 = call i64 @__olang_fmt_i64(ptr null, i64 %t110)
  %t143 = add i64 %t140, %t142
  %t144 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t143)
  call void @olang_textcopy(ptr %t144, ptr %t111, i64 %t112)
  %t145 = getelementptr i8, ptr %t144, i64 %t112
  call void @olang_textcopy(ptr %t145, ptr %t114, i64 %t115)
  %t146 = getelementptr i8, ptr %t145, i64 %t115
  call void @olang_textcopy(ptr %t146, ptr %t117, i64 %t118)
  %t147 = getelementptr i8, ptr %t146, i64 %t118
  call void @olang_textcopy(ptr %t147, ptr %t121, i64 %t122)
  %t148 = getelementptr i8, ptr %t147, i64 %t122
  call void @olang_textcopy(ptr %t148, ptr %t124, i64 %t125)
  %t149 = getelementptr i8, ptr %t148, i64 %t125
  call void @olang_textcopy(ptr %t149, ptr %t128, i64 %t129)
  %t150 = getelementptr i8, ptr %t149, i64 %t129
  call void @olang_textcopy(ptr %t150, ptr %t131, i64 %t132)
  %t151 = getelementptr i8, ptr %t150, i64 %t132
  call void @olang_textcopy(ptr %t151, ptr %t135, i64 %t136)
  %t152 = getelementptr i8, ptr %t151, i64 %t136
  call void @olang_textcopy(ptr %t152, ptr %t138, i64 %t139)
  %t153 = getelementptr i8, ptr %t152, i64 %t139
  %t154 = call i64 @__olang_fmt_i64(ptr %t153, i64 %t110)
  %t155 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t144, 1
  %t158 = extractvalue { i64, ptr } %t156, 0
  %t159 = extractvalue { i64, ptr } %t156, 1
  %t160 = mul i64 %t158, 1
  %t161 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t160)
  call void @llvm.memcpy.p0.p0.i64(ptr %t161, ptr %t159, i64 %t160, i1 false)
  %t162 = insertvalue { i64, ptr } undef, i64 %t158, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t161, 1
  %t164 = load ptr, ptr %l55, !tbaa !29
  %t166 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v2, ptr %v2, ptr %t164, { i64, ptr } %t163)
  store { i64, ptr } %t166, ptr %l67
  br label %bb15
bb15:
  %t167 = load ptr, ptr %lp5
  %t168 = load { i64, ptr }, ptr %t167, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t168, 0
  %t170 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t170, 0
  store i64 %t171, ptr %l69, !tbaa !24
  %t173 = load i64, ptr %l69, !tbaa !24
  %t174 = icmp eq i64 %t169, %t173
  br i1 %t174, label %bb16, label %bb17
bb16:
  %t176 = load ptr, ptr %lp5
  %t177 = getelementptr { i64, ptr }, ptr %t176, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !27
  %t181 = load i64, ptr %l69, !tbaa !24
  %t182 = mul i64 %t181, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t178, ptr %t180, i64 %t182, i1 false)
  br label %bb18
bb17:
  %t183 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t184 = load ptr, ptr %lp5
  store { i64, ptr } %t183, ptr %t184, !tbaa !27
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t185 = load i64, ptr %l10, !tbaa !24
  %t187 = add i64 %t185, 1
  store i64 %t187, ptr %l10, !tbaa !24
  br label %bb8
bb20:
  %t189 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t189, 0
  %t193 = icmp eq i64 %t191, 0
  br i1 %t193, label %bb21, label %bb22
bb21:
  store { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d202, i32 0, i32 1) }, ptr %l76, !tbaa !27
  %t195 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t195, ptr %l77, !tbaa !27
  %t196 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t197 = extractvalue { i64, ptr } %t196, 0
  store i64 %t197, ptr %l78, !tbaa !24
  %t198 = load i64, ptr %l78, !tbaa !24
  %t199 = mul i64 %t198, 1
  %t200 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t199)
  %t201 = insertvalue { i64, ptr } undef, i64 %t198, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t200, 1
  store { i64, ptr } %t202, ptr %l79, !tbaa !27
  %t203 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !27
  %t205 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !27
  %t207 = load i64, ptr %l78, !tbaa !24
  %t208 = mul i64 %t207, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t204, ptr %t206, i64 %t208, i1 false)
  %t209 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t209, ptr %l77, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t210 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t210, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t211 = load ptr, ptr %lp5
  %t212 = load { i64, ptr }, ptr %t211, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t212, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2equoted(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s0, ptr %t4, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d203, i32 0, i32 1) })
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/emit:fnEm", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s0, ptr %t9, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d204, i32 0, i32 1) })
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/emit:fnEm", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s0, ptr %t14, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d205, i32 0, i32 1) })
  br label %bb3
bb3:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t19 = load i64, ptr %l4, !tbaa !24
  %t20 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d206, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d206, i32 0, i32 1) }, 0
  %t23 = extractvalue { i64, ptr } %t17, 1
  %t24 = extractvalue { i64, ptr } %t17, 0
  %t25 = add i64 %t21, %t24
  %t26 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d207, i32 0, i32 1) }, 1
  %t27 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d207, i32 0, i32 1) }, 0
  %t28 = add i64 %t25, %t27
  %t30 = extractvalue { i64, ptr } %t18, 1
  %t31 = extractvalue { i64, ptr } %t18, 0
  %t32 = add i64 %t28, %t31
  %t33 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d208, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d208, i32 0, i32 1) }, 0
  %t35 = add i64 %t32, %t34
  %t37 = call i64 @__olang_fmt_i64(ptr null, i64 %t19)
  %t38 = add i64 %t35, %t37
  %t39 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d209, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d209, i32 0, i32 1) }, 0
  %t41 = add i64 %t38, %t40
  %t42 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t41)
  call void @olang_textcopy(ptr %t42, ptr %t20, i64 %t21)
  %t43 = getelementptr i8, ptr %t42, i64 %t21
  call void @olang_textcopy(ptr %t43, ptr %t23, i64 %t24)
  %t44 = getelementptr i8, ptr %t43, i64 %t24
  call void @olang_textcopy(ptr %t44, ptr %t26, i64 %t27)
  %t45 = getelementptr i8, ptr %t44, i64 %t27
  call void @olang_textcopy(ptr %t45, ptr %t30, i64 %t31)
  %t46 = getelementptr i8, ptr %t45, i64 %t31
  call void @olang_textcopy(ptr %t46, ptr %t33, i64 %t34)
  %t47 = getelementptr i8, ptr %t46, i64 %t34
  %t48 = call i64 @__olang_fmt_i64(ptr %t47, i64 %t19)
  %t49 = getelementptr i8, ptr %t47, i64 %t37
  call void @olang_textcopy(ptr %t49, ptr %t39, i64 %t40)
  %t50 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t42, 1
  %t53 = extractvalue { i64, ptr } %t51, 0
  %t54 = extractvalue { i64, ptr } %t51, 1
  %t55 = mul i64 %t53, 1
  %t56 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t55)
  call void @llvm.memcpy.p0.p0.i64(ptr %t56, ptr %t54, i64 %t55, i1 false)
  %t57 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  %t61 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t16, { i64, ptr } %t58)
  store { i64, ptr } %t61, ptr %l19
  br label %bb4
bb4:
  %t62 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t62, ptr %l5, !tbaa !27
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t66 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d210, i32 0, i32 1) }, 1
  %t67 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d210, i32 0, i32 1) }, 0
  %t69 = extractvalue { i64, ptr } %t64, 1
  %t70 = extractvalue { i64, ptr } %t64, 0
  %t71 = add i64 %t67, %t70
  %t72 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d211, i32 0, i32 1) }, 1
  %t73 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d211, i32 0, i32 1) }, 0
  %t74 = add i64 %t71, %t73
  %t76 = extractvalue { i64, ptr } %t65, 1
  %t77 = extractvalue { i64, ptr } %t65, 0
  %t78 = add i64 %t74, %t77
  %t79 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d212, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d212, i32 0, i32 1) }, 0
  %t81 = add i64 %t78, %t80
  %t82 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t81)
  call void @olang_textcopy(ptr %t82, ptr %t66, i64 %t67)
  %t83 = getelementptr i8, ptr %t82, i64 %t67
  call void @olang_textcopy(ptr %t83, ptr %t69, i64 %t70)
  %t84 = getelementptr i8, ptr %t83, i64 %t70
  call void @olang_textcopy(ptr %t84, ptr %t72, i64 %t73)
  %t85 = getelementptr i8, ptr %t84, i64 %t73
  call void @olang_textcopy(ptr %t85, ptr %t76, i64 %t77)
  %t86 = getelementptr i8, ptr %t85, i64 %t77
  call void @olang_textcopy(ptr %t86, ptr %t79, i64 %t80)
  %t87 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t82, 1
  %t90 = extractvalue { i64, ptr } %t88, 0
  %t91 = extractvalue { i64, ptr } %t88, 1
  %t92 = mul i64 %t90, 1
  %t93 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t92)
  call void @llvm.memcpy.p0.p0.i64(ptr %t93, ptr %t91, i64 %t92, i1 false)
  %t94 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t93, 1
  %t98 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t63, { i64, ptr } %t95)
  store { i64, ptr } %t98, ptr %l25
  br label %bb5
bb5:
  %t99 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t104 = load i64, ptr %l4, !tbaa !24
  %t105 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d213, i32 0, i32 1) }, 1
  %t106 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d213, i32 0, i32 1) }, 0
  %t108 = extractvalue { i64, ptr } %t99, 1
  %t109 = extractvalue { i64, ptr } %t99, 0
  %t110 = add i64 %t106, %t109
  %t111 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d214, i32 0, i32 1) }, 1
  %t112 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d214, i32 0, i32 1) }, 0
  %t113 = add i64 %t110, %t112
  %t115 = extractvalue { i64, ptr } %t102, 1
  %t116 = extractvalue { i64, ptr } %t102, 0
  %t117 = add i64 %t113, %t116
  %t118 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d215, i32 0, i32 1) }, 1
  %t119 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d215, i32 0, i32 1) }, 0
  %t120 = add i64 %t117, %t119
  %t122 = extractvalue { i64, ptr } %t103, 1
  %t123 = extractvalue { i64, ptr } %t103, 0
  %t124 = add i64 %t120, %t123
  %t125 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d216, i32 0, i32 1) }, 1
  %t126 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d216, i32 0, i32 1) }, 0
  %t127 = add i64 %t124, %t126
  %t129 = call i64 @__olang_fmt_i64(ptr null, i64 %t104)
  %t130 = add i64 %t127, %t129
  %t131 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d217, i32 0, i32 1) }, 1
  %t132 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d217, i32 0, i32 1) }, 0
  %t133 = add i64 %t130, %t132
  %t134 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t133)
  call void @olang_textcopy(ptr %t134, ptr %t105, i64 %t106)
  %t135 = getelementptr i8, ptr %t134, i64 %t106
  call void @olang_textcopy(ptr %t135, ptr %t108, i64 %t109)
  %t136 = getelementptr i8, ptr %t135, i64 %t109
  call void @olang_textcopy(ptr %t136, ptr %t111, i64 %t112)
  %t137 = getelementptr i8, ptr %t136, i64 %t112
  call void @olang_textcopy(ptr %t137, ptr %t115, i64 %t116)
  %t138 = getelementptr i8, ptr %t137, i64 %t116
  call void @olang_textcopy(ptr %t138, ptr %t118, i64 %t119)
  %t139 = getelementptr i8, ptr %t138, i64 %t119
  call void @olang_textcopy(ptr %t139, ptr %t122, i64 %t123)
  %t140 = getelementptr i8, ptr %t139, i64 %t123
  call void @olang_textcopy(ptr %t140, ptr %t125, i64 %t126)
  %t141 = getelementptr i8, ptr %t140, i64 %t126
  %t142 = call i64 @__olang_fmt_i64(ptr %t141, i64 %t104)
  %t143 = getelementptr i8, ptr %t141, i64 %t129
  call void @olang_textcopy(ptr %t143, ptr %t131, i64 %t132)
  %t144 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t134, 1
  %t147 = extractvalue { i64, ptr } %t145, 0
  %t148 = extractvalue { i64, ptr } %t145, 1
  %t149 = mul i64 %t147, 1
  %t150 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t149)
  call void @llvm.memcpy.p0.p0.i64(ptr %t150, ptr %t148, i64 %t149, i1 false)
  %t151 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t150, 1
  %t155 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t100, { i64, ptr } %t152)
  store { i64, ptr } %t155, ptr %l33
  br label %bb6
bb6:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t158 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t159 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d218, i32 0, i32 1) }, 1
  %t160 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d218, i32 0, i32 1) }, 0
  %t162 = extractvalue { i64, ptr } %t157, 1
  %t163 = extractvalue { i64, ptr } %t157, 0
  %t164 = add i64 %t160, %t163
  %t165 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d219, i32 0, i32 1) }, 1
  %t166 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d219, i32 0, i32 1) }, 0
  %t167 = add i64 %t164, %t166
  %t169 = extractvalue { i64, ptr } %t158, 1
  %t170 = extractvalue { i64, ptr } %t158, 0
  %t171 = add i64 %t167, %t170
  %t172 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d220, i32 0, i32 1) }, 1
  %t173 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d220, i32 0, i32 1) }, 0
  %t174 = add i64 %t171, %t173
  %t175 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t174)
  call void @olang_textcopy(ptr %t175, ptr %t159, i64 %t160)
  %t176 = getelementptr i8, ptr %t175, i64 %t160
  call void @olang_textcopy(ptr %t176, ptr %t162, i64 %t163)
  %t177 = getelementptr i8, ptr %t176, i64 %t163
  call void @olang_textcopy(ptr %t177, ptr %t165, i64 %t166)
  %t178 = getelementptr i8, ptr %t177, i64 %t166
  call void @olang_textcopy(ptr %t178, ptr %t169, i64 %t170)
  %t179 = getelementptr i8, ptr %t178, i64 %t170
  call void @olang_textcopy(ptr %t179, ptr %t172, i64 %t173)
  %t180 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t181 = insertvalue { i64, ptr } %t180, ptr %t175, 1
  %t183 = extractvalue { i64, ptr } %t181, 0
  %t184 = extractvalue { i64, ptr } %t181, 1
  %t185 = mul i64 %t183, 1
  %t186 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t185)
  call void @llvm.memcpy.p0.p0.i64(ptr %t186, ptr %t184, i64 %t185, i1 false)
  %t187 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t186, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t156, { i64, ptr } %t188)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2erecode(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca [1 x i8]
  %l45 = alloca i64
  %l48 = alloca i64
  %l69 = alloca { i64, ptr }
  %l72 = alloca i64
  %l79 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l88 = alloca i64
  %l96 = alloca { i64, ptr }
  %l97 = alloca ptr
  %l102 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t13 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t7, i32 %a2)
  store { i64, ptr } %t13, ptr %l24
  br label %bb1
bb1:
  %t14 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t14, ptr %l5, !tbaa !27
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t17 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d221, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d221, i32 0, i32 1) }, 0
  %t20 = extractvalue { i64, ptr } %t16, 1
  %t21 = extractvalue { i64, ptr } %t16, 0
  %t22 = add i64 %t18, %t21
  %t23 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d222, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d222, i32 0, i32 1) }, 0
  %t25 = add i64 %t22, %t24
  %t26 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t25)
  call void @olang_textcopy(ptr %t26, ptr %t17, i64 %t18)
  %t27 = getelementptr i8, ptr %t26, i64 %t18
  call void @olang_textcopy(ptr %t27, ptr %t20, i64 %t21)
  %t28 = getelementptr i8, ptr %t27, i64 %t21
  call void @olang_textcopy(ptr %t28, ptr %t23, i64 %t24)
  %t29 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t26, 1
  %t32 = extractvalue { i64, ptr } %t30, 0
  %t33 = extractvalue { i64, ptr } %t30, 1
  %t34 = mul i64 %t32, 1
  %t35 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t34)
  call void @llvm.memcpy.p0.p0.i64(ptr %t35, ptr %t33, i64 %t34, i1 false)
  %t36 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  %t40 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t15, { i64, ptr } %t37)
  store { i64, ptr } %t40, ptr %l29
  br label %bb2
bb2:
  %t41 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t41, ptr %l6, !tbaa !27
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d223, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d223, i32 0, i32 1) }, 0
  %t47 = extractvalue { i64, ptr } %t43, 1
  %t48 = extractvalue { i64, ptr } %t43, 0
  %t49 = add i64 %t45, %t48
  %t50 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d224, i32 0, i32 1) }, 1
  %t51 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d224, i32 0, i32 1) }, 0
  %t52 = add i64 %t49, %t51
  %t53 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t52)
  call void @olang_textcopy(ptr %t53, ptr %t44, i64 %t45)
  %t54 = getelementptr i8, ptr %t53, i64 %t45
  call void @olang_textcopy(ptr %t54, ptr %t47, i64 %t48)
  %t55 = getelementptr i8, ptr %t54, i64 %t48
  call void @olang_textcopy(ptr %t55, ptr %t50, i64 %t51)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t53, 1
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t60 = extractvalue { i64, ptr } %t57, 1
  %t61 = mul i64 %t59, 1
  %t62 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t61)
  call void @llvm.memcpy.p0.p0.i64(ptr %t62, ptr %t60, i64 %t61, i1 false)
  %t63 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  %t67 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t42, { i64, ptr } %t64)
  store { i64, ptr } %t67, ptr %l34
  br label %bb3
bb3:
  %t68 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t68, ptr %l7, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d225, i32 0, i32 1) }, ptr %l35, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t69, ptr %l36, !tbaa !27
  %t70 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = mul i64 1, 1
  call void @llvm.memmove.p0.p0.i64(ptr %l37, ptr %t71, i64 %t72, i1 false)
  %t74 = insertvalue { i64, ptr } undef, i64 1, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %l37, 1
  store { i64, ptr } %t75, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t77 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t77, 0
  store i64 %t79, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t81 = load i64, ptr %l10, !tbaa !24
  %t82 = load i64, ptr %l9, !tbaa !24
  %t85 = icmp sgt i64 %t81, %t82
  br i1 %t85, label %bb4, label %bb5
bb4:
  %t87 = load i64, ptr %l11, !tbaa !24
  %t89 = icmp sgt i64 %t87, 0
  br i1 %t89, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb9
bb6:
  %t91 = load i64, ptr %l10, !tbaa !24
  %t92 = load i64, ptr %l9, !tbaa !24
  %t95 = sub i64 %t91, %t92
  %t96 = load i64, ptr %l11, !tbaa !24
  %t99 = add i64 %t95, %t96
  %t101 = sub i64 %t99, 1
  %t102 = load i64, ptr %l11, !tbaa !24
  %t105 = sdiv i64 %t101, %t102
  store i64 %t105, ptr %l48, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l48, !tbaa !24
  br label %bb8
bb8:
  %t107 = load i64, ptr %l48, !tbaa !24
  store i64 %t107, ptr %l45, !tbaa !24
  br label %bb9
bb9:
  %t108 = load i64, ptr %l45, !tbaa !24
  store i64 %t108, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t109 = load i64, ptr %l13, !tbaa !24
  %t110 = load i64, ptr %l12, !tbaa !24
  %t113 = icmp slt i64 %t109, %t110
  %t115 = xor i1 %t113, true
  br i1 %t115, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb12:
  br label %bb13
bb13:
  %t117 = load i64, ptr %l9, !tbaa !24
  %t118 = load i64, ptr %l13, !tbaa !24
  %t119 = load i64, ptr %l11, !tbaa !24
  %t122 = mul i64 %t118, %t119
  %t125 = add i64 %t117, %t122
  store i64 %t125, ptr %l14, !tbaa !24
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/emit:fnEm", ptr %t127, i32 0, i32 0
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t132 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t132, ptr %l69, !tbaa !27
  %t133 = load i64, ptr %l14, !tbaa !24
  %t135 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !27
  %t137 = getelementptr i32, ptr %t136, i64 %t133
  %t138 = load i32, ptr %t137, !tbaa !33
  %t142 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eposition(ptr %v0, ptr %t130, i32 %a3, i32 %t138)
  store i64 %t142, ptr %l72
  br label %bb14
bb14:
  %t143 = load i64, ptr %l72, !tbaa !24
  store i64 %t143, ptr %l15, !tbaa !24
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t146 = load i64, ptr %l14, !tbaa !24
  %t148 = add i64 %t146, 1
  %t149 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d226, i32 0, i32 1) }, 1
  %t150 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d226, i32 0, i32 1) }, 0
  %t152 = extractvalue { i64, ptr } %t145, 1
  %t153 = extractvalue { i64, ptr } %t145, 0
  %t154 = add i64 %t150, %t153
  %t155 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d227, i32 0, i32 1) }, 1
  %t156 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d227, i32 0, i32 1) }, 0
  %t157 = add i64 %t154, %t156
  %t159 = call i64 @__olang_fmt_i64(ptr null, i64 %t148)
  %t160 = add i64 %t157, %t159
  %t161 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t160)
  call void @olang_textcopy(ptr %t161, ptr %t149, i64 %t150)
  %t162 = getelementptr i8, ptr %t161, i64 %t150
  call void @olang_textcopy(ptr %t162, ptr %t152, i64 %t153)
  %t163 = getelementptr i8, ptr %t162, i64 %t153
  call void @olang_textcopy(ptr %t163, ptr %t155, i64 %t156)
  %t164 = getelementptr i8, ptr %t163, i64 %t156
  %t165 = call i64 @__olang_fmt_i64(ptr %t164, i64 %t148)
  %t166 = insertvalue { i64, ptr } undef, i64 %t160, 0
  %t167 = insertvalue { i64, ptr } %t166, ptr %t161, 1
  %t169 = extractvalue { i64, ptr } %t167, 0
  %t170 = extractvalue { i64, ptr } %t167, 1
  %t171 = mul i64 %t169, 1
  %t172 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t171)
  call void @llvm.memcpy.p0.p0.i64(ptr %t172, ptr %t170, i64 %t171, i1 false)
  %t173 = insertvalue { i64, ptr } undef, i64 %t169, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t172, 1
  %t177 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s4, ptr %s4, ptr %t144, { i64, ptr } %t174)
  store { i64, ptr } %t177, ptr %l79
  br label %bb15
bb15:
  %t178 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = load i64, ptr %l15, !tbaa !24
  %t182 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t183 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d228, i32 0, i32 1) }, 1
  %t184 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d228, i32 0, i32 1) }, 0
  %t186 = extractvalue { i64, ptr } %t178, 1
  %t187 = extractvalue { i64, ptr } %t178, 0
  %t188 = add i64 %t184, %t187
  %t189 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d229, i32 0, i32 1) }, 1
  %t190 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d229, i32 0, i32 1) }, 0
  %t191 = add i64 %t188, %t190
  %t193 = call i64 @__olang_fmt_i64(ptr null, i64 %t181)
  %t194 = add i64 %t191, %t193
  %t195 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d229, i32 0, i32 1) }, 1
  %t196 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d229, i32 0, i32 1) }, 0
  %t197 = add i64 %t194, %t196
  %t199 = extractvalue { i64, ptr } %t182, 1
  %t200 = extractvalue { i64, ptr } %t182, 0
  %t201 = add i64 %t197, %t200
  %t202 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t201)
  call void @olang_textcopy(ptr %t202, ptr %t183, i64 %t184)
  %t203 = getelementptr i8, ptr %t202, i64 %t184
  call void @olang_textcopy(ptr %t203, ptr %t186, i64 %t187)
  %t204 = getelementptr i8, ptr %t203, i64 %t187
  call void @olang_textcopy(ptr %t204, ptr %t189, i64 %t190)
  %t205 = getelementptr i8, ptr %t204, i64 %t190
  %t206 = call i64 @__olang_fmt_i64(ptr %t205, i64 %t181)
  %t207 = getelementptr i8, ptr %t205, i64 %t193
  call void @olang_textcopy(ptr %t207, ptr %t195, i64 %t196)
  %t208 = getelementptr i8, ptr %t207, i64 %t196
  call void @olang_textcopy(ptr %t208, ptr %t199, i64 %t200)
  %t209 = insertvalue { i64, ptr } undef, i64 %t201, 0
  %t210 = insertvalue { i64, ptr } %t209, ptr %t202, 1
  %t212 = extractvalue { i64, ptr } %t210, 0
  %t213 = extractvalue { i64, ptr } %t210, 1
  %t214 = mul i64 %t212, 1
  %t215 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t214)
  call void @llvm.memcpy.p0.p0.i64(ptr %t215, ptr %t213, i64 %t214, i1 false)
  %t216 = insertvalue { i64, ptr } undef, i64 %t212, 0
  %t217 = insertvalue { i64, ptr } %t216, ptr %t215, 1
  %t220 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t179, { i64, ptr } %t217)
  store { i64, ptr } %t220, ptr %l86
  br label %bb16
bb16:
  %t221 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t222 = extractvalue { i64, ptr } %t221, 0
  %t223 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t224 = extractvalue { i64, ptr } %t223, 0
  store i64 %t224, ptr %l88, !tbaa !24
  %t226 = load i64, ptr %l88, !tbaa !24
  %t227 = icmp eq i64 %t222, %t226
  br i1 %t227, label %bb17, label %bb18
bb17:
  %t229 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t230 = load ptr, ptr %t229, !tbaa !27
  %t231 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !27
  %t233 = load i64, ptr %l88, !tbaa !24
  %t234 = mul i64 %t233, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t230, ptr %t232, i64 %t234, i1 false)
  br label %bb19
bb18:
  %t235 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t235, ptr %l8, !tbaa !27
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s4)
  br label %bb20
bb20:
  %t236 = load i64, ptr %l13, !tbaa !24
  %t238 = add i64 %t236, 1
  store i64 %t238, ptr %l13, !tbaa !24
  br label %bb10
bb21:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t242 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d230, i32 0, i32 1) }, 1
  %t243 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d230, i32 0, i32 1) }, 0
  %t245 = extractvalue { i64, ptr } %t241, 1
  %t246 = extractvalue { i64, ptr } %t241, 0
  %t247 = add i64 %t243, %t246
  %t248 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d231, i32 0, i32 1) }, 1
  %t249 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d231, i32 0, i32 1) }, 0
  %t250 = add i64 %t247, %t249
  %t251 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t250)
  call void @olang_textcopy(ptr %t251, ptr %t242, i64 %t243)
  %t252 = getelementptr i8, ptr %t251, i64 %t243
  call void @olang_textcopy(ptr %t252, ptr %t245, i64 %t246)
  %t253 = getelementptr i8, ptr %t252, i64 %t246
  call void @olang_textcopy(ptr %t253, ptr %t248, i64 %t249)
  %t254 = insertvalue { i64, ptr } undef, i64 %t250, 0
  %t255 = insertvalue { i64, ptr } %t254, ptr %t251, 1
  %t257 = extractvalue { i64, ptr } %t255, 0
  %t258 = extractvalue { i64, ptr } %t255, 1
  %t259 = mul i64 %t257, 1
  %t260 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t259)
  call void @llvm.memcpy.p0.p0.i64(ptr %t260, ptr %t258, i64 %t259, i1 false)
  %t261 = insertvalue { i64, ptr } undef, i64 %t257, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t260, 1
  %t265 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t240, { i64, ptr } %t262)
  store { i64, ptr } %t265, ptr %l96
  br label %bb22
bb22:
  %t266 = load { i64, ptr }, ptr %l96, !tbaa !27
  store { i64, ptr } %t266, ptr %l17, !tbaa !27
  %t267 = load ptr, ptr %l0, !tbaa !29
  store ptr %t267, ptr %l97, !tbaa !29
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t269 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t270 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d232, i32 0, i32 1) }, 1
  %t271 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d232, i32 0, i32 1) }, 0
  %t273 = extractvalue { i64, ptr } %t269, 1
  %t274 = extractvalue { i64, ptr } %t269, 0
  %t275 = add i64 %t271, %t274
  %t276 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d233, i32 0, i32 1) }, 1
  %t277 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d233, i32 0, i32 1) }, 0
  %t278 = add i64 %t275, %t277
  %t279 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t278)
  call void @olang_textcopy(ptr %t279, ptr %t270, i64 %t271)
  %t280 = getelementptr i8, ptr %t279, i64 %t271
  call void @olang_textcopy(ptr %t280, ptr %t273, i64 %t274)
  %t281 = getelementptr i8, ptr %t280, i64 %t274
  call void @olang_textcopy(ptr %t281, ptr %t276, i64 %t277)
  %t282 = insertvalue { i64, ptr } undef, i64 %t278, 0
  %t283 = insertvalue { i64, ptr } %t282, ptr %t279, 1
  %t285 = extractvalue { i64, ptr } %t283, 0
  %t286 = extractvalue { i64, ptr } %t283, 1
  %t287 = mul i64 %t285, 1
  %t288 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t287)
  call void @llvm.memcpy.p0.p0.i64(ptr %t288, ptr %t286, i64 %t287, i1 false)
  %t289 = insertvalue { i64, ptr } undef, i64 %t285, 0
  %t290 = insertvalue { i64, ptr } %t289, ptr %t288, 1
  %t293 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t268, { i64, ptr } %t290)
  store { i64, ptr } %t293, ptr %l102
  br label %bb23
bb23:
  %t294 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t295 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d234, i32 0, i32 1) }, 1
  %t296 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d234, i32 0, i32 1) }, 0
  %t297 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t298 = extractvalue { i64, ptr } %t297, 1
  %t299 = extractvalue { i64, ptr } %t297, 0
  %t300 = add i64 %t296, %t299
  %t301 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d235, i32 0, i32 1) }, 1
  %t302 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d235, i32 0, i32 1) }, 0
  %t303 = add i64 %t300, %t302
  %t305 = extractvalue { i64, ptr } %t294, 1
  %t306 = extractvalue { i64, ptr } %t294, 0
  %t307 = add i64 %t303, %t306
  %t308 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t307)
  call void @olang_textcopy(ptr %t308, ptr %t295, i64 %t296)
  %t309 = getelementptr i8, ptr %t308, i64 %t296
  call void @olang_textcopy(ptr %t309, ptr %t298, i64 %t299)
  %t310 = getelementptr i8, ptr %t309, i64 %t299
  call void @olang_textcopy(ptr %t310, ptr %t301, i64 %t302)
  %t311 = getelementptr i8, ptr %t310, i64 %t302
  call void @olang_textcopy(ptr %t311, ptr %t305, i64 %t306)
  %t312 = insertvalue { i64, ptr } undef, i64 %t307, 0
  %t313 = insertvalue { i64, ptr } %t312, ptr %t308, 1
  %t315 = extractvalue { i64, ptr } %t313, 0
  %t316 = extractvalue { i64, ptr } %t313, 1
  %t317 = mul i64 %t315, 1
  %t318 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t317)
  call void @llvm.memcpy.p0.p0.i64(ptr %t318, ptr %t316, i64 %t317, i1 false)
  %t319 = insertvalue { i64, ptr } undef, i64 %t315, 0
  %t320 = insertvalue { i64, ptr } %t319, ptr %t318, 1
  %t321 = load ptr, ptr %l97, !tbaa !29
  %t323 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t321, { i64, ptr } %t320)
  store { i64, ptr } %t323, ptr %l106
  br label %bb24
bb24:
  %t324 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t326 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t328 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d236, i32 0, i32 1) }, 1
  %t329 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d236, i32 0, i32 1) }, 0
  %t331 = extractvalue { i64, ptr } %t326, 1
  %t332 = extractvalue { i64, ptr } %t326, 0
  %t333 = add i64 %t329, %t332
  %t334 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d237, i32 0, i32 1) }, 1
  %t335 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d237, i32 0, i32 1) }, 0
  %t336 = add i64 %t333, %t335
  %t338 = extractvalue { i64, ptr } %t324, 1
  %t339 = extractvalue { i64, ptr } %t324, 0
  %t340 = add i64 %t336, %t339
  %t341 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t340)
  call void @olang_textcopy(ptr %t341, ptr %t328, i64 %t329)
  %t342 = getelementptr i8, ptr %t341, i64 %t329
  call void @olang_textcopy(ptr %t342, ptr %t331, i64 %t332)
  %t343 = getelementptr i8, ptr %t342, i64 %t332
  call void @olang_textcopy(ptr %t343, ptr %t334, i64 %t335)
  %t344 = getelementptr i8, ptr %t343, i64 %t335
  call void @olang_textcopy(ptr %t344, ptr %t338, i64 %t339)
  %t345 = insertvalue { i64, ptr } undef, i64 %t340, 0
  %t346 = insertvalue { i64, ptr } %t345, ptr %t341, 1
  %t348 = extractvalue { i64, ptr } %t346, 0
  %t349 = extractvalue { i64, ptr } %t346, 1
  %t350 = mul i64 %t348, 1
  %t351 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t350)
  call void @llvm.memcpy.p0.p0.i64(ptr %t351, ptr %t349, i64 %t350, i1 false)
  %t352 = insertvalue { i64, ptr } undef, i64 %t348, 0
  %t353 = insertvalue { i64, ptr } %t352, ptr %t351, 1
  %t356 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v2, ptr %v2, ptr %t325, { i64, ptr } %t353)
  store { i64, ptr } %t356, ptr %l112
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t357 = load { i64, ptr }, ptr %l112, !tbaa !27
  store { i64, ptr } %t357, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eslice(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Lvalue" %a1, { i64, [4 x i64] } %a2, { i64, [4 x i64] } %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Lvalue"
  %l2 = alloca { i64, [4 x i64] }
  %l3 = alloca { i64, [4 x i64] }
  %l5 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %lp12 = alloca ptr
  %l19 = alloca i32
  %l22 = alloca i32
  %l25 = alloca i32
  %l28 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l37 = alloca i32
  %l38 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l43 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l47 = alloca i32
  %l48 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca ptr
  %l61 = alloca i32
  %l62 = alloca i32
  %l65 = alloca i1
  %l68 = alloca ptr
  %l74 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/mir:Lvalue" %a1, ptr %l1
  store { i64, [4 x i64] } %a2, ptr %l2
  store { i64, [4 x i64] } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l5, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load %"compiler/mir:Lvalue", ptr %l1
  %t13 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eplaceType(ptr %v0, ptr %t9, %"compiler/mir:Lvalue" %t10)
  store i32 %t13, ptr %l19
  br label %bb1
bb1:
  %t14 = load i32, ptr %l19, !tbaa !23
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t19 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %t15, i32 %t14)
  store i32 %t19, ptr %l22
  br label %bb2
bb2:
  %t20 = load i32, ptr %l22, !tbaa !23
  %t21 = load ptr, ptr %l5, !tbaa !29
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t21, i32 %t20)
  store i32 %t25, ptr %l25
  br label %bb3
bb3:
  %t26 = load i32, ptr %l25, !tbaa !23
  store i32 %t26, ptr %l8, !tbaa !23
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load %"compiler/mir:Lvalue", ptr %l1
  %t31 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edataPtr(ptr %v0, ptr %s0, ptr %t27, %"compiler/mir:Lvalue" %t28)
  store { i64, ptr } %t31, ptr %l28
  br label %bb4
bb4:
  %t32 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t32, ptr %l9, !tbaa !27
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l29, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load { i64, [4 x i64] }, ptr %l2
  %t36 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t40 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s0, ptr %t34, { i64, [4 x i64] } %t35, i32 %t36)
  store { i64, ptr } %t40, ptr %l33
  br label %bb5
bb5:
  %t41 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 0
  %t43 = extractvalue { i64, ptr } %t41, 1
  %t44 = mul i64 %t42, 1
  %t45 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t44)
  call void @llvm.memcpy.p0.p0.i64(ptr %t45, ptr %t43, i64 %t44, i1 false)
  %t46 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  store { i64, ptr } %t47, ptr %l34, !tbaa !27
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load { i64, [4 x i64] }, ptr %l2
  %t52 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t48, { i64, [4 x i64] } %t49)
  store i32 %t52, ptr %l37
  br label %bb6
bb6:
  %t53 = load ptr, ptr %l29, !tbaa !29
  %t54 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t55 = load i32, ptr %l37, !tbaa !23
  %t56 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eindex(ptr %v0, ptr %s0, ptr %s0, ptr %t53, { i64, ptr } %t54, i32 %t55)
  store { i64, ptr } %t56, ptr %l38
  br label %bb7
bb7:
  %t57 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t57, ptr %l10, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l39, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load { i64, [4 x i64] }, ptr %l3
  %t61 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t65 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s0, ptr %t59, { i64, [4 x i64] } %t60, i32 %t61)
  store { i64, ptr } %t65, ptr %l43
  br label %bb8
bb8:
  %t66 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  %t68 = extractvalue { i64, ptr } %t66, 1
  %t69 = mul i64 %t67, 1
  %t70 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t69)
  call void @llvm.memcpy.p0.p0.i64(ptr %t70, ptr %t68, i64 %t69, i1 false)
  %t71 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  store { i64, ptr } %t72, ptr %l44, !tbaa !27
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load { i64, [4 x i64] }, ptr %l3
  %t77 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t73, { i64, [4 x i64] } %t74)
  store i32 %t77, ptr %l47
  br label %bb9
bb9:
  %t78 = load ptr, ptr %l39, !tbaa !29
  %t79 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t80 = load i32, ptr %l47, !tbaa !23
  %t81 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eindex(ptr %v0, ptr %s0, ptr %s0, ptr %t78, { i64, ptr } %t79, i32 %t80)
  store { i64, ptr } %t81, ptr %l48
  br label %bb10
bb10:
  %t82 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t82, ptr %l11, !tbaa !27
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l49, !tbaa !29
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i32, ptr %l8, !tbaa !23
  %t88 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s0, ptr %t84, i32 %t85)
  store { i64, ptr } %t88, ptr %l52
  br label %bb11
bb11:
  %t89 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t91 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d238, i32 0, i32 1) }, 1
  %t92 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d238, i32 0, i32 1) }, 0
  %t93 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 1
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t96 = add i64 %t92, %t95
  %t97 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d239, i32 0, i32 1) }, 1
  %t98 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d239, i32 0, i32 1) }, 0
  %t99 = add i64 %t96, %t98
  %t101 = extractvalue { i64, ptr } %t89, 1
  %t102 = extractvalue { i64, ptr } %t89, 0
  %t103 = add i64 %t99, %t102
  %t104 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d240, i32 0, i32 1) }, 1
  %t105 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d240, i32 0, i32 1) }, 0
  %t106 = add i64 %t103, %t105
  %t108 = extractvalue { i64, ptr } %t90, 1
  %t109 = extractvalue { i64, ptr } %t90, 0
  %t110 = add i64 %t106, %t109
  %t111 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t110)
  call void @olang_textcopy(ptr %t111, ptr %t91, i64 %t92)
  %t112 = getelementptr i8, ptr %t111, i64 %t92
  call void @olang_textcopy(ptr %t112, ptr %t94, i64 %t95)
  %t113 = getelementptr i8, ptr %t112, i64 %t95
  call void @olang_textcopy(ptr %t113, ptr %t97, i64 %t98)
  %t114 = getelementptr i8, ptr %t113, i64 %t98
  call void @olang_textcopy(ptr %t114, ptr %t101, i64 %t102)
  %t115 = getelementptr i8, ptr %t114, i64 %t102
  call void @olang_textcopy(ptr %t115, ptr %t104, i64 %t105)
  %t116 = getelementptr i8, ptr %t115, i64 %t105
  call void @olang_textcopy(ptr %t116, ptr %t108, i64 %t109)
  %t117 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t111, 1
  %t120 = extractvalue { i64, ptr } %t118, 0
  %t121 = extractvalue { i64, ptr } %t118, 1
  %t122 = mul i64 %t120, 1
  %t123 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t122)
  call void @llvm.memcpy.p0.p0.i64(ptr %t123, ptr %t121, i64 %t122, i1 false)
  %t124 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t123, 1
  %t126 = load ptr, ptr %l49, !tbaa !29
  %t128 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t126, { i64, ptr } %t125)
  store { i64, ptr } %t128, ptr %l57
  br label %bb12
bb12:
  %t129 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t129, ptr %lp12
  %t130 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t131 = load ptr, ptr %lp12
  store { i64, ptr } %t130, ptr %t131, !tbaa !27
  %t132 = load ptr, ptr %l5, !tbaa !29
  store ptr %t132, ptr %l58, !tbaa !29
  %t133 = load ptr, ptr %l5, !tbaa !29
  %t137 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t133, i32 %a4)
  store i32 %t137, ptr %l61
  br label %bb13
bb13:
  %t138 = load ptr, ptr %l58, !tbaa !29
  %t139 = load i32, ptr %l61, !tbaa !23
  %t140 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t138, i32 %t139)
  store i32 %t140, ptr %l62
  br label %bb14
bb14:
  %t141 = load i32, ptr %l62, !tbaa !23
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t146 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erunTime(ptr %v0, ptr %t142, i32 %t141)
  store i1 %t146, ptr %l65
  br label %bb15
bb15:
  %t147 = load i1, ptr %l65, !tbaa !21
  %t148 = xor i1 %t147, true
  br i1 %t148, label %bb16, label %bb17
bb16:
  %t150 = load ptr, ptr %lp12
  %t151 = load { i64, ptr }, ptr %t150, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t151, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t153 = load ptr, ptr %l0, !tbaa !29
  store ptr %t153, ptr %l68, !tbaa !29
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t156 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t157 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d241, i32 0, i32 1) }, 1
  %t158 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d241, i32 0, i32 1) }, 0
  %t160 = extractvalue { i64, ptr } %t155, 1
  %t161 = extractvalue { i64, ptr } %t155, 0
  %t162 = add i64 %t158, %t161
  %t163 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d242, i32 0, i32 1) }, 1
  %t164 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d242, i32 0, i32 1) }, 0
  %t165 = add i64 %t162, %t164
  %t167 = extractvalue { i64, ptr } %t156, 1
  %t168 = extractvalue { i64, ptr } %t156, 0
  %t169 = add i64 %t165, %t168
  %t170 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t169)
  call void @olang_textcopy(ptr %t170, ptr %t157, i64 %t158)
  %t171 = getelementptr i8, ptr %t170, i64 %t158
  call void @olang_textcopy(ptr %t171, ptr %t160, i64 %t161)
  %t172 = getelementptr i8, ptr %t171, i64 %t161
  call void @olang_textcopy(ptr %t172, ptr %t163, i64 %t164)
  %t173 = getelementptr i8, ptr %t172, i64 %t164
  call void @olang_textcopy(ptr %t173, ptr %t167, i64 %t168)
  %t174 = insertvalue { i64, ptr } undef, i64 %t169, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t170, 1
  %t177 = extractvalue { i64, ptr } %t175, 0
  %t178 = extractvalue { i64, ptr } %t175, 1
  %t179 = mul i64 %t177, 1
  %t180 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t179)
  call void @llvm.memcpy.p0.p0.i64(ptr %t180, ptr %t178, i64 %t179, i1 false)
  %t181 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  %t185 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t154, { i64, ptr } %t182)
  store { i64, ptr } %t185, ptr %l74
  br label %bb19
bb19:
  %t186 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t186, 0
  %t188 = extractvalue { i64, ptr } %t186, 1
  %t189 = mul i64 %t187, 1
  %t190 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t189)
  call void @llvm.memcpy.p0.p0.i64(ptr %t190, ptr %t188, i64 %t189, i1 false)
  %t191 = insertvalue { i64, ptr } undef, i64 %t187, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t190, 1
  %t193 = load ptr, ptr %lp12
  %t194 = load { i64, ptr }, ptr %t193, !tbaa !27
  %t195 = load ptr, ptr %l68, !tbaa !29
  %t198 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epair(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %t195, { i64, ptr } %t192, { i64, ptr } %t194)
  store { i64, ptr } %t198, ptr %l77
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t199 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t199, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2esuspend(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/mir:Range" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [4 x i64] }
  %l3 = alloca %"compiler/mir:Range"
  %l5 = alloca { i64, ptr }
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l15 = alloca { i64, [1 x i64] }
  %l16 = alloca i32
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca i64
  %l41 = alloca { i64, ptr }
  %l44 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l59 = alloca ptr
  %l60 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l76 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l81 = alloca i32
  %l84 = alloca i32
  %l110 = alloca { i64, [1 x i64] }
  %l119 = alloca i1
  %l121 = alloca i1
  %l125 = alloca i1
  %l127 = alloca i1
  %l132 = alloca %"compiler/mir:ScopeInfo"
  %l144 = alloca i64
  %l146 = alloca i64
  %l151 = alloca i64
  %l159 = alloca { i64, ptr }
  %l161 = alloca { i64, ptr }
  %l163 = alloca { i64, ptr }
  %l176 = alloca i64
  %l180 = alloca i64
  %l183 = alloca i64
  %l201 = alloca ptr
  %l203 = alloca i64
  %l207 = alloca i64
  %l208 = alloca ptr
  %l211 = alloca i32
  %l216 = alloca %"compiler/mir:ScopeInfo"
  %l221 = alloca ptr
  %l223 = alloca { i64, ptr }
  %l231 = alloca i64
  %l233 = alloca i64
  %l238 = alloca i64
  %l239 = alloca ptr
  %l240 = alloca i64
  %l244 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s22 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [4 x i64] } %a1, ptr %l1
  store %"compiler/mir:Range" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/emit:fnEm", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/mir:Fn", ptr %t13, i32 0, i32 1
  %t16 = load i32, ptr %t15, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %s0, ptr %t7, i32 %t16)
  store { i64, ptr } %t19, ptr %l41
  br label %bb1
bb1:
  %t20 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t20, ptr %l5, !tbaa !27
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/emit:fnEm", ptr %t21, i32 0, i32 11
  %t24 = load i1, ptr %t23, !tbaa !21
  br i1 %t24, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l44, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/emit:fnEm", ptr %t28, i32 0, i32 29
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  %t32 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d243, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d243, i32 0, i32 1) }, 0
  %t35 = extractvalue { i64, ptr } %t31, 1
  %t36 = extractvalue { i64, ptr } %t31, 0
  %t37 = add i64 %t33, %t36
  %t38 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d244, i32 0, i32 1) }, 1
  %t39 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d244, i32 0, i32 1) }, 0
  %t40 = add i64 %t37, %t39
  %t41 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t40)
  call void @olang_textcopy(ptr %t41, ptr %t32, i64 %t33)
  %t42 = getelementptr i8, ptr %t41, i64 %t33
  call void @olang_textcopy(ptr %t42, ptr %t35, i64 %t36)
  %t43 = getelementptr i8, ptr %t42, i64 %t36
  call void @olang_textcopy(ptr %t43, ptr %t38, i64 %t39)
  %t44 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t41, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = extractvalue { i64, ptr } %t45, 1
  %t49 = mul i64 %t47, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t49)
  call void @llvm.memcpy.p0.p0.i64(ptr %t50, ptr %t48, i64 %t49, i1 false)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  %t55 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s1, ptr %s1, ptr %t27, { i64, ptr } %t52)
  store { i64, ptr } %t55, ptr %l50
  br label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s3
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l59, !tbaa !29
  %t57 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t57, ptr %l60, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/emit:fnEm", ptr %t59, i32 0, i32 9
  %t62 = load i32, ptr %t61, !tbaa !23
  %t65 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s3, ptr %t58, i32 %t62)
  store { i64, ptr } %t65, ptr %l64
  br label %bb8
bb4:
  %t66 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  %t68 = extractvalue { i64, ptr } %t66, 1
  %t69 = mul i64 %t67, 1
  %t70 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t69)
  call void @llvm.memcpy.p0.p0.i64(ptr %t70, ptr %t68, i64 %t69, i1 false)
  %t71 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  %t73 = load ptr, ptr %l44, !tbaa !29
  %t75 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s1, ptr %s1, ptr %s1, ptr %s1, ptr %t73, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d245, i32 0, i32 1) }, { i64, ptr } %t72, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d197, i32 0, i32 1) })
  store { i64, ptr } %t75, ptr %l52
  br label %bb5
bb5:
  %t76 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/emit:fnEm", ptr %t79, i32 0, i32 9
  %t82 = load i32, ptr %t81, !tbaa !23
  %t83 = load { i64, [4 x i64] }, ptr %l1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eput(ptr %v0, ptr %s1, ptr %s1, ptr %t77, { i64, ptr } %t76, i32 %t82, { i64, [4 x i64] } %t83, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d246, i32 0, i32 1) })
  br label %bb6
bb6:
  %t88 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s1, ptr %s1, ptr %s1, ptr %s1, ptr %t88, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d247, i32 0, i32 1) }, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d248, i32 0, i32 1) }, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d249, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d250, i32 0, i32 1) })
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb12
bb8:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load { i64, [4 x i64] }, ptr %l1
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/emit:fnEm", ptr %t92, i32 0, i32 9
  %t95 = load i32, ptr %t94, !tbaa !23
  %t99 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s3, ptr %t90, { i64, [4 x i64] } %t91, i32 %t95)
  store { i64, ptr } %t99, ptr %l69
  br label %bb9
bb9:
  %t100 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d251, i32 0, i32 1) }, 1
  %t101 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d251, i32 0, i32 1) }, 0
  %t102 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 1
  %t104 = extractvalue { i64, ptr } %t102, 0
  %t105 = add i64 %t101, %t104
  %t106 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d252, i32 0, i32 1) }, 1
  %t107 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d252, i32 0, i32 1) }, 0
  %t108 = add i64 %t105, %t107
  %t109 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 1
  %t111 = extractvalue { i64, ptr } %t109, 0
  %t112 = add i64 %t108, %t111
  %t113 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d253, i32 0, i32 1) }, 1
  %t114 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d253, i32 0, i32 1) }, 0
  %t115 = add i64 %t112, %t114
  %t116 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t116, 1
  %t118 = extractvalue { i64, ptr } %t116, 0
  %t119 = add i64 %t115, %t118
  %t120 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d254, i32 0, i32 1) }, 1
  %t121 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d254, i32 0, i32 1) }, 0
  %t122 = add i64 %t119, %t121
  %t123 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t122)
  call void @olang_textcopy(ptr %t123, ptr %t100, i64 %t101)
  %t124 = getelementptr i8, ptr %t123, i64 %t101
  call void @olang_textcopy(ptr %t124, ptr %t103, i64 %t104)
  %t125 = getelementptr i8, ptr %t124, i64 %t104
  call void @olang_textcopy(ptr %t125, ptr %t106, i64 %t107)
  %t126 = getelementptr i8, ptr %t125, i64 %t107
  call void @olang_textcopy(ptr %t126, ptr %t110, i64 %t111)
  %t127 = getelementptr i8, ptr %t126, i64 %t111
  call void @olang_textcopy(ptr %t127, ptr %t113, i64 %t114)
  %t128 = getelementptr i8, ptr %t127, i64 %t114
  call void @olang_textcopy(ptr %t128, ptr %t117, i64 %t118)
  %t129 = getelementptr i8, ptr %t128, i64 %t118
  call void @olang_textcopy(ptr %t129, ptr %t120, i64 %t121)
  %t130 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t123, 1
  %t133 = extractvalue { i64, ptr } %t131, 0
  %t134 = extractvalue { i64, ptr } %t131, 1
  %t135 = mul i64 %t133, 1
  %t136 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t135)
  call void @llvm.memcpy.p0.p0.i64(ptr %t136, ptr %t134, i64 %t135, i1 false)
  %t137 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t136, 1
  %t139 = load ptr, ptr %l59, !tbaa !29
  %t141 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s3, ptr %s3, ptr %t139, { i64, ptr } %t138)
  store { i64, ptr } %t141, ptr %l72
  br label %bb10
bb10:
  %t142 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s3, ptr %s3, ptr %s3, ptr %t143, { i64, ptr } %t144, { i64, ptr } %t142, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d255, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d250, i32 0, i32 1) })
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  %t149 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t149, ptr %l76
  br label %bb13
bb13:
  %t150 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l76
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t150, ptr %l8
  store i32 0, ptr %l9, !tbaa !23
  %t151 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t152 = load i32, ptr %t151, !tbaa !23
  store i32 %t152, ptr %l10, !tbaa !23
  store i32 1, ptr %l11, !tbaa !23
  %t154 = load i32, ptr %l10, !tbaa !23
  %t155 = load i32, ptr %l9, !tbaa !23
  %t158 = icmp sgt i32 %t154, %t155
  br i1 %t158, label %bb14, label %bb15
bb14:
  %t160 = load i32, ptr %l11, !tbaa !23
  %t162 = icmp sgt i32 %t160, 0
  br i1 %t162, label %bb16, label %bb17
bb15:
  store i32 0, ptr %l81, !tbaa !23
  br label %bb19
bb16:
  %t164 = load i32, ptr %l10, !tbaa !23
  %t165 = load i32, ptr %l9, !tbaa !23
  %t168 = sub i32 %t164, %t165
  %t169 = load i32, ptr %l11, !tbaa !23
  %t172 = add i32 %t168, %t169
  %t174 = sub i32 %t172, 1
  %t175 = load i32, ptr %l11, !tbaa !23
  %t178 = sdiv i32 %t174, %t175
  store i32 %t178, ptr %l84, !tbaa !23
  br label %bb18
bb17:
  store i32 0, ptr %l84, !tbaa !23
  br label %bb18
bb18:
  %t180 = load i32, ptr %l84, !tbaa !23
  store i32 %t180, ptr %l81, !tbaa !23
  br label %bb19
bb19:
  %t181 = load i32, ptr %l81, !tbaa !23
  store i32 %t181, ptr %l12, !tbaa !23
  store i32 0, ptr %l13, !tbaa !23
  br label %bb20
bb20:
  %t182 = load i32, ptr %l13, !tbaa !23
  %t183 = load i32, ptr %l12, !tbaa !23
  %t186 = icmp slt i32 %t182, %t183
  %t188 = xor i1 %t186, true
  br i1 %t188, label %bb21, label %bb22
bb21:
  br label %bb48
bb22:
  br label %bb23
bb23:
  %t190 = load i32, ptr %l9, !tbaa !23
  %t191 = load i32, ptr %l13, !tbaa !23
  %t192 = load i32, ptr %l11, !tbaa !23
  %t195 = mul i32 %t191, %t192
  %t198 = add i32 %t190, %t195
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/emit:fnEm", ptr %t200, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !29
  %t205 = getelementptr %"compiler/mir:Fn", ptr %t203, i32 0, i32 12
  %t206 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 0
  %t207 = load i32, ptr %t206, !tbaa !23
  %t209 = sext i32 %t207 to i64
  %t212 = sext i32 %t198 to i64
  %t215 = add i64 %t209, %t212
  %t218 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t205, i64 %t215)
  store { i64, [1 x i64] } %t218, ptr %l110
  br label %bb24
bb24:
  %t219 = load { i64, [1 x i64] }, ptr %l110
  store { i64, [1 x i64] } %t219, ptr %l15
  %t220 = load { i64, [1 x i64] }, ptr %l15
  %t222 = extractvalue { i64, [1 x i64] } %t220, 0
  %t223 = icmp eq i64 %t222, 0
  br i1 %t223, label %bb25, label %bb26
bb25:
  %t225 = getelementptr { i64, [1 x i64] }, ptr %l15, i32 0, i32 1
  %t226 = getelementptr { i32 }, ptr %t225, i32 0, i32 0
  %t227 = load i32, ptr %t226
  store i32 %t227, ptr %l16, !tbaa !23
  br label %bb27
bb26:
  br label %bb41
bb27:
  %t229 = load i32, ptr %l16, !tbaa !23
  %t231 = sext i32 %t229 to i64
  store i64 %t231, ptr %l17, !tbaa !24
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t235 = getelementptr %"compiler/emit:fnEm", ptr %t233, i32 0, i32 25
  %t236 = load i64, ptr %l17, !tbaa !24
  %t239 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t235, i64 %t236)
  store i1 %t239, ptr %l119
  br label %bb28
bb28:
  %t240 = load i1, ptr %l119, !tbaa !21
  %t241 = xor i1 %t240, true
  br i1 %t241, label %bb29, label %bb30
bb29:
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t245 = getelementptr %"compiler/emit:fnEm", ptr %t243, i32 0, i32 24
  %t246 = load i64, ptr %l17, !tbaa !24
  %t249 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t245, i64 %t246)
  store i1 %t249, ptr %l125
  br label %bb31
bb30:
  store i1 false, ptr %l121, !tbaa !21
  br label %bb32
bb31:
  %t250 = load i1, ptr %l125, !tbaa !21
  %t251 = xor i1 %t250, true
  store i1 %t251, ptr %l121, !tbaa !21
  br label %bb32
bb32:
  %t253 = load i1, ptr %l121, !tbaa !21
  br i1 %t253, label %bb33, label %bb34
bb33:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = getelementptr %"compiler/emit:fnEm", ptr %t254, i32 0, i32 1
  %t257 = load ptr, ptr %t256, !tbaa !29
  %t259 = getelementptr %"compiler/mir:Fn", ptr %t257, i32 0, i32 8
  %t260 = load i64, ptr %l17, !tbaa !24
  %t263 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t259, i64 %t260)
  store %"compiler/mir:ScopeInfo" %t263, ptr %l132
  br label %bb35
bb34:
  store i1 false, ptr %l127, !tbaa !21
  br label %bb36
bb35:
  %t264 = getelementptr %"compiler/mir:ScopeInfo", ptr %l132, i32 0, i32 0
  %t265 = load i32, ptr %t264, !range !{i32 0, i32 7}
  %t267 = trunc i64 6 to i32
  %t268 = icmp eq i32 %t265, %t267
  %t270 = xor i1 %t268, true
  store i1 %t270, ptr %l127, !tbaa !21
  br label %bb36
bb36:
  %t272 = load i1, ptr %l127, !tbaa !21
  br i1 %t272, label %bb37, label %bb38
bb37:
  %t273 = load i64, ptr %l17, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l8, i64 %t273)
  br label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb40
bb40:
  br label %bb46
bb41:
  br i1 true, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_97d51a883f8cc986_4828fb3e43690a82)
  unreachable
bb46:
  br label %bb47
bb47:
  %t276 = load i32, ptr %l13, !tbaa !23
  %t278 = add i32 %t276, 1
  store i32 %t278, ptr %l13, !tbaa !23
  br label %bb20
bb48:
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = getelementptr %"compiler/emit:fnEm", ptr %t280, i32 0, i32 0
  %t283 = load ptr, ptr %t282, !tbaa !29
  %t285 = getelementptr %"compiler/emit:Emitter", ptr %t283, i32 0, i32 4
  %t286 = load i1, ptr %t285, !tbaa !21
  br i1 %t286, label %bb49, label %bb50
bb49:
  store ptr %l8, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb51
bb50:
  br label %bb60
bb51:
  %t289 = load i64, ptr %l19, !tbaa !24
  store i64 %t289, ptr %l144, !tbaa !24
  %t290 = load ptr, ptr %l18, !tbaa !29
  %t292 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t290)
  store i64 %t292, ptr %l146
  br label %bb52
bb52:
  %t293 = load i64, ptr %l144, !tbaa !24
  %t294 = load i64, ptr %l146, !tbaa !24
  %t295 = icmp slt i64 %t293, %t294
  %t297 = xor i1 %t295, true
  br i1 %t297, label %bb53, label %bb54
bb53:
  br label %bb59
bb54:
  br label %bb55
bb55:
  %t299 = load ptr, ptr %l18, !tbaa !29
  %t300 = load i64, ptr %l19, !tbaa !24
  %t303 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t299, i64 %t300)
  store i64 %t303, ptr %l151
  br label %bb56
bb56:
  %t304 = load i64, ptr %l151, !tbaa !24
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t308 = trunc i64 %t304 to i32
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eunwindPop(ptr %v0, ptr %t305, i32 %t308)
  br label %bb57
bb57:
  br label %bb58
bb58:
  %t312 = load i64, ptr %l19, !tbaa !24
  %t314 = add i64 %t312, 1
  store i64 %t314, ptr %l19, !tbaa !24
  br label %bb51
bb59:
  br label %bb60
bb60:
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t318 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t316, { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d256, i32 0, i32 1) })
  store { i64, ptr } %t318, ptr %l159
  br label %bb61
bb61:
  %t319 = load { i64, ptr }, ptr %l159, !tbaa !27
  store { i64, ptr } %t319, ptr %l21, !tbaa !27
  %t320 = load ptr, ptr %l0, !tbaa !29
  %t322 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s0, ptr %s0, ptr %t320, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d257, i32 0, i32 1) })
  store { i64, ptr } %t322, ptr %l161
  br label %bb62
bb62:
  %t323 = load { i64, ptr }, ptr %l161, !tbaa !27
  store { i64, ptr } %t323, ptr %l22, !tbaa !27
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t326 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s0, ptr %s0, ptr %t324, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d258, i32 0, i32 1) })
  store { i64, ptr } %t326, ptr %l163
  br label %bb63
bb63:
  %t327 = load { i64, ptr }, ptr %l163, !tbaa !27
  store { i64, ptr } %t327, ptr %l23, !tbaa !27
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t329 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t330 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t331 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t332 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d259, i32 0, i32 1) }, 1
  %t333 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d259, i32 0, i32 1) }, 0
  %t335 = extractvalue { i64, ptr } %t329, 1
  %t336 = extractvalue { i64, ptr } %t329, 0
  %t337 = add i64 %t333, %t336
  %t338 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d260, i32 0, i32 1) }, 1
  %t339 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d260, i32 0, i32 1) }, 0
  %t340 = add i64 %t337, %t339
  %t342 = extractvalue { i64, ptr } %t330, 1
  %t343 = extractvalue { i64, ptr } %t330, 0
  %t344 = add i64 %t340, %t343
  %t345 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d261, i32 0, i32 1) }, 1
  %t346 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d261, i32 0, i32 1) }, 0
  %t347 = add i64 %t344, %t346
  %t349 = extractvalue { i64, ptr } %t331, 1
  %t350 = extractvalue { i64, ptr } %t331, 0
  %t351 = add i64 %t347, %t350
  %t352 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d262, i32 0, i32 1) }, 1
  %t353 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d262, i32 0, i32 1) }, 0
  %t354 = add i64 %t351, %t353
  %t355 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t354)
  call void @olang_textcopy(ptr %t355, ptr %t332, i64 %t333)
  %t356 = getelementptr i8, ptr %t355, i64 %t333
  call void @olang_textcopy(ptr %t356, ptr %t335, i64 %t336)
  %t357 = getelementptr i8, ptr %t356, i64 %t336
  call void @olang_textcopy(ptr %t357, ptr %t338, i64 %t339)
  %t358 = getelementptr i8, ptr %t357, i64 %t339
  call void @olang_textcopy(ptr %t358, ptr %t342, i64 %t343)
  %t359 = getelementptr i8, ptr %t358, i64 %t343
  call void @olang_textcopy(ptr %t359, ptr %t345, i64 %t346)
  %t360 = getelementptr i8, ptr %t359, i64 %t346
  call void @olang_textcopy(ptr %t360, ptr %t349, i64 %t350)
  %t361 = getelementptr i8, ptr %t360, i64 %t350
  call void @olang_textcopy(ptr %t361, ptr %t352, i64 %t353)
  %t362 = insertvalue { i64, ptr } undef, i64 %t354, 0
  %t363 = insertvalue { i64, ptr } %t362, ptr %t355, 1
  %t365 = extractvalue { i64, ptr } %t363, 0
  %t366 = extractvalue { i64, ptr } %t363, 1
  %t367 = mul i64 %t365, 1
  %t368 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t367)
  call void @llvm.memcpy.p0.p0.i64(ptr %t368, ptr %t366, i64 %t367, i1 false)
  %t369 = insertvalue { i64, ptr } undef, i64 %t365, 0
  %t370 = insertvalue { i64, ptr } %t369, ptr %t368, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t328, { i64, ptr } %t370)
  br label %bb64
bb64:
  %t373 = load ptr, ptr %l0, !tbaa !29
  %t374 = load { i64, ptr }, ptr %l22, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s0, ptr %t373, { i64, ptr } %t374)
  br label %bb65
bb65:
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t379 = getelementptr %"compiler/emit:fnEm", ptr %t377, i32 0, i32 0
  %t380 = load ptr, ptr %t379, !tbaa !29
  %t382 = getelementptr %"compiler/emit:Emitter", ptr %t380, i32 0, i32 4
  %t383 = load i1, ptr %t382, !tbaa !21
  br i1 %t383, label %bb66, label %bb67
bb66:
  store i64 0, ptr %l24, !tbaa !24
  %t386 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l8)
  store i64 %t386, ptr %l176
  br label %bb68
bb67:
  br label %bb85
bb68:
  %t387 = load i64, ptr %l176, !tbaa !24
  store i64 %t387, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t388 = load i64, ptr %l25, !tbaa !24
  %t389 = load i64, ptr %l24, !tbaa !24
  %t392 = icmp sgt i64 %t388, %t389
  br i1 %t392, label %bb69, label %bb70
bb69:
  %t394 = load i64, ptr %l26, !tbaa !24
  %t396 = icmp sgt i64 %t394, 0
  br i1 %t396, label %bb71, label %bb72
bb70:
  store i64 0, ptr %l180, !tbaa !24
  br label %bb74
bb71:
  %t398 = load i64, ptr %l25, !tbaa !24
  %t399 = load i64, ptr %l24, !tbaa !24
  %t402 = sub i64 %t398, %t399
  %t403 = load i64, ptr %l26, !tbaa !24
  %t406 = add i64 %t402, %t403
  %t408 = sub i64 %t406, 1
  %t409 = load i64, ptr %l26, !tbaa !24
  %t412 = sdiv i64 %t408, %t409
  store i64 %t412, ptr %l183, !tbaa !24
  br label %bb73
bb72:
  store i64 0, ptr %l183, !tbaa !24
  br label %bb73
bb73:
  %t414 = load i64, ptr %l183, !tbaa !24
  store i64 %t414, ptr %l180, !tbaa !24
  br label %bb74
bb74:
  %t415 = load i64, ptr %l180, !tbaa !24
  store i64 %t415, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb75
bb75:
  %t416 = load i64, ptr %l28, !tbaa !24
  %t417 = load i64, ptr %l27, !tbaa !24
  %t420 = icmp slt i64 %t416, %t417
  %t422 = xor i1 %t420, true
  br i1 %t422, label %bb76, label %bb77
bb76:
  br label %bb84
bb77:
  br label %bb78
bb78:
  %t424 = load i64, ptr %l24, !tbaa !24
  %t425 = load i64, ptr %l28, !tbaa !24
  %t426 = load i64, ptr %l26, !tbaa !24
  %t429 = mul i64 %t425, %t426
  %t432 = add i64 %t424, %t429
  store i64 %t432, ptr %l29, !tbaa !24
  store ptr %l8, ptr %l201, !tbaa !29
  %t435 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l8)
  store i64 %t435, ptr %l203
  br label %bb79
bb79:
  %t436 = load i64, ptr %l203, !tbaa !24
  %t437 = sub i64 %t436, 1
  %t438 = load i64, ptr %l29, !tbaa !24
  %t441 = sub i64 %t437, %t438
  %t442 = load ptr, ptr %l201, !tbaa !29
  %t444 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t442, i64 %t441)
  store i64 %t444, ptr %l207
  br label %bb80
bb80:
  %t445 = load i64, ptr %l207, !tbaa !24
  store i64 %t445, ptr %l30, !tbaa !24
  %t446 = load ptr, ptr %l0, !tbaa !29
  store ptr %t446, ptr %l208, !tbaa !29
  %t447 = load i64, ptr %l30, !tbaa !24
  %t449 = trunc i64 %t447 to i32
  store i32 %t449, ptr %l211, !tbaa !23
  %t451 = load ptr, ptr %l0, !tbaa !29
  %t453 = getelementptr %"compiler/emit:fnEm", ptr %t451, i32 0, i32 1
  %t454 = load ptr, ptr %t453, !tbaa !29
  %t456 = getelementptr %"compiler/mir:Fn", ptr %t454, i32 0, i32 8
  %t457 = load i64, ptr %l30, !tbaa !24
  %t460 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t456, i64 %t457)
  store %"compiler/mir:ScopeInfo" %t460, ptr %l216
  br label %bb81
bb81:
  %t461 = getelementptr %"compiler/mir:ScopeInfo", ptr %l216, i32 0, i32 0
  %t462 = load i32, ptr %t461, !range !{i32 0, i32 7}
  %t464 = trunc i64 3 to i32
  %t465 = icmp eq i32 %t462, %t464
  %t466 = load ptr, ptr %l208, !tbaa !29
  %t467 = load i32, ptr %l211, !tbaa !23
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eunwindPush(ptr %v0, ptr %t466, i32 %t467, i1 %t465)
  br label %bb82
bb82:
  br label %bb83
bb83:
  %t469 = load i64, ptr %l28, !tbaa !24
  %t471 = add i64 %t469, 1
  store i64 %t471, ptr %l28, !tbaa !24
  br label %bb75
bb84:
  br label %bb85
bb85:
  %t473 = load ptr, ptr %l0, !tbaa !29
  store ptr %t473, ptr %l221, !tbaa !29
  %t476 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s0, i32 %a2)
  store { i64, ptr } %t476, ptr %l223
  br label %bb86
bb86:
  %t477 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d263, i32 0, i32 1) }, 1
  %t478 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d263, i32 0, i32 1) }, 0
  %t479 = load { i64, ptr }, ptr %l223, !tbaa !27
  %t480 = extractvalue { i64, ptr } %t479, 1
  %t481 = extractvalue { i64, ptr } %t479, 0
  %t482 = add i64 %t478, %t481
  %t483 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t482)
  call void @olang_textcopy(ptr %t483, ptr %t477, i64 %t478)
  %t484 = getelementptr i8, ptr %t483, i64 %t478
  call void @olang_textcopy(ptr %t484, ptr %t480, i64 %t481)
  %t485 = insertvalue { i64, ptr } undef, i64 %t482, 0
  %t486 = insertvalue { i64, ptr } %t485, ptr %t483, 1
  %t488 = extractvalue { i64, ptr } %t486, 0
  %t489 = extractvalue { i64, ptr } %t486, 1
  %t490 = mul i64 %t488, 1
  %t491 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t490)
  call void @llvm.memcpy.p0.p0.i64(ptr %t491, ptr %t489, i64 %t490, i1 false)
  %t492 = insertvalue { i64, ptr } undef, i64 %t488, 0
  %t493 = insertvalue { i64, ptr } %t492, ptr %t491, 1
  %t494 = load ptr, ptr %l221, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t494, { i64, ptr } %t493)
  br label %bb87
bb87:
  %t496 = load ptr, ptr %l0, !tbaa !29
  %t497 = load { i64, ptr }, ptr %l23, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s0, ptr %t496, { i64, ptr } %t497)
  br label %bb88
bb88:
  %t500 = load ptr, ptr %l0, !tbaa !29
  %t502 = getelementptr %"compiler/emit:fnEm", ptr %t500, i32 0, i32 0
  %t503 = load ptr, ptr %t502, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s0, ptr %t503, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d264, i32 0, i32 1) })
  br label %bb89
bb89:
  store ptr %l8, ptr %l31, !tbaa !29
  store i64 0, ptr %l32, !tbaa !24
  br label %bb90
bb90:
  store %olang.scope zeroinitializer, ptr %s22
  %t506 = load i64, ptr %l32, !tbaa !24
  store i64 %t506, ptr %l231, !tbaa !24
  %t507 = load ptr, ptr %l31, !tbaa !29
  %t509 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t507)
  store i64 %t509, ptr %l233
  br label %bb91
bb91:
  %t510 = load i64, ptr %l231, !tbaa !24
  %t511 = load i64, ptr %l233, !tbaa !24
  %t512 = icmp slt i64 %t510, %t511
  %t514 = xor i1 %t512, true
  br i1 %t514, label %bb92, label %bb93
bb92:
  call void @__olang_scope_close(ptr %s22)
  br label %bb100
bb93:
  br label %bb94
bb94:
  %t516 = load ptr, ptr %l31, !tbaa !29
  %t517 = load i64, ptr %l32, !tbaa !24
  %t520 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t516, i64 %t517)
  store i64 %t520, ptr %l238
  br label %bb95
bb95:
  %t521 = load i64, ptr %l238, !tbaa !24
  store i64 %t521, ptr %l33, !tbaa !24
  %t522 = load ptr, ptr %l0, !tbaa !29
  store ptr %t522, ptr %l239, !tbaa !29
  %t523 = load i64, ptr %l33, !tbaa !24
  store i64 %t523, ptr %l240, !tbaa !24
  %t524 = load ptr, ptr %l0, !tbaa !29
  %t525 = load ptr, ptr %l0, !tbaa !29
  %t527 = getelementptr %"compiler/emit:fnEm", ptr %t525, i32 0, i32 34
  %t528 = load i64, ptr %t527, !tbaa !24
  %t531 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ewalkKey(ptr %v0, ptr %t524, i64 %t528, i64 -1)
  store i64 %t531, ptr %l244
  br label %bb96
bb96:
  %t532 = load ptr, ptr %l239, !tbaa !29
  %t533 = load i64, ptr %l240, !tbaa !24
  %t534 = load i64, ptr %l244, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ewalkEnd(ptr %v0, ptr %t532, i64 %t533, i64 %t534)
  br label %bb97
bb97:
  %t535 = load ptr, ptr %l0, !tbaa !29
  %t536 = load i64, ptr %l33, !tbaa !24
  %t537 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d265, i32 0, i32 1) }, 1
  %t538 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d265, i32 0, i32 1) }, 0
  %t540 = call i64 @__olang_fmt_i64(ptr null, i64 %t536)
  %t541 = add i64 %t538, %t540
  %t542 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d266, i32 0, i32 1) }, 1
  %t543 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d266, i32 0, i32 1) }, 0
  %t544 = add i64 %t541, %t543
  %t545 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t544)
  call void @olang_textcopy(ptr %t545, ptr %t537, i64 %t538)
  %t546 = getelementptr i8, ptr %t545, i64 %t538
  %t547 = call i64 @__olang_fmt_i64(ptr %t546, i64 %t536)
  %t548 = getelementptr i8, ptr %t546, i64 %t540
  call void @olang_textcopy(ptr %t548, ptr %t542, i64 %t543)
  %t549 = insertvalue { i64, ptr } undef, i64 %t544, 0
  %t550 = insertvalue { i64, ptr } %t549, ptr %t545, 1
  %t552 = extractvalue { i64, ptr } %t550, 0
  %t553 = extractvalue { i64, ptr } %t550, 1
  %t554 = mul i64 %t552, 1
  %t555 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t554)
  call void @llvm.memcpy.p0.p0.i64(ptr %t555, ptr %t553, i64 %t554, i1 false)
  %t556 = insertvalue { i64, ptr } undef, i64 %t552, 0
  %t557 = insertvalue { i64, ptr } %t556, ptr %t555, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s22, ptr %t535, { i64, ptr } %t557)
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s22)
  br label %bb99
bb99:
  %t560 = load i64, ptr %l32, !tbaa !24
  %t562 = add i64 %t560, 1
  store i64 %t562, ptr %l32, !tbaa !24
  br label %bb90
bb100:
  %t564 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %t564, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d267, i32 0, i32 1) })
  br label %bb101
bb101:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2eterm(ptr %v0, ptr %a0, { i64, [8 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [8 x i64] }
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca %"compiler/mir:Range"
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %l20 = alloca %"compiler/mir:Case"
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca { i64, [4 x i64] }
  %l24 = alloca { i64, ptr }
  %l26 = alloca { i64, [4 x i64] }
  %l27 = alloca i32
  %l28 = alloca %"compiler/mir:Range"
  %l29 = alloca %"compiler/source:Span"
  %l30 = alloca { i64, [4 x i64] }
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca i32
  %l34 = alloca i32
  %l35 = alloca i32
  %l36 = alloca i32
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l40 = alloca %"compiler/source:Span"
  %l41 = alloca i32
  %l42 = alloca { i64, [4 x i64] }
  %l49 = alloca ptr
  %l51 = alloca %"compiler/source:Span"
  %l58 = alloca ptr
  %l60 = alloca { i64, ptr }
  %l68 = alloca ptr
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l86 = alloca i32
  %l89 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l94 = alloca %"std/prelude/text:StringBuilder"
  %l95 = alloca ptr
  %l96 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l106 = alloca i32
  %l109 = alloca i32
  %l135 = alloca %"compiler/mir:Case"
  %l136 = alloca ptr
  %l137 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l144 = alloca { i64, ptr }
  %l150 = alloca ptr
  %l152 = alloca { i64, ptr }
  %l159 = alloca ptr
  %l165 = alloca %"compiler/mir:Call"
  %l172 = alloca ptr
  %l178 = alloca %"compiler/mir:Call"
  %l186 = alloca { i64, ptr }
  %l203 = alloca ptr
  %l204 = alloca { i64, ptr }
  %l208 = alloca { i64, ptr }
  %l213 = alloca { i64, ptr }
  %l216 = alloca { i64, ptr }
  %l221 = alloca i1
  %l223 = alloca ptr
  %l224 = alloca { i64, ptr }
  %l229 = alloca { i64, ptr }
  %l251 = alloca { i64, ptr }
  %l255 = alloca { i64, ptr }
  %l257 = alloca i1
  %l260 = alloca ptr
  %l261 = alloca { i64, ptr }
  %l267 = alloca { i64, ptr }
  %l282 = alloca { i64, ptr }
  %l286 = alloca ptr
  %l288 = alloca { i64, ptr }
  %l295 = alloca { i64, ptr }
  %l299 = alloca ptr
  %l300 = alloca { i64, ptr }
  %l303 = alloca { i64, ptr }
  %l309 = alloca { i64, ptr }
  %l310 = alloca ptr
  %l311 = alloca { i64, ptr }
  %l313 = alloca { i64, ptr }
  %l315 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s40 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [8 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/emit:fnEm", ptr %t9, i32 0, i32 18
  %t12 = load i64, ptr %t11, !tbaa !24
  %t14 = icmp sge i64 %t12, 0
  br i1 %t14, label %bb1, label %bb2
bb1:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l49, !tbaa !29
  %t17 = load { i64, [8 x i64] }, ptr %l1
  %t19 = call %"compiler/source:Span" @compiler_2femit_2etermSpan({ i64, [8 x i64] } %t17)
  store %"compiler/source:Span" %t19, ptr %l51
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t20 = load ptr, ptr %l49, !tbaa !29
  %t21 = load %"compiler/source:Span", ptr %l51
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elocate(ptr %v0, ptr %t20, %"compiler/source:Span" %t21)
  br label %bb4
bb4:
  br label %bb5
bb5:
  %t22 = load { i64, [8 x i64] }, ptr %l1
  %t24 = extractvalue { i64, [8 x i64] } %t22, 0
  %t25 = icmp eq i64 %t24, 0
  br i1 %t25, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb10
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t27 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s2, ptr %t27, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d268, i32 0, i32 1) })
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb148
bb10:
  %t29 = load { i64, [8 x i64] }, ptr %l1
  %t31 = extractvalue { i64, [8 x i64] } %t29, 0
  %t32 = icmp eq i64 %t31, 1
  br i1 %t32, label %bb11, label %bb12
bb11:
  %t34 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t35 = getelementptr { i32 }, ptr %t34, i32 0, i32 0
  %t36 = load i32, ptr %t35
  store i32 %t36, ptr %l3, !tbaa !23
  br label %bb13
bb12:
  br label %bb16
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l58, !tbaa !29
  %t39 = load i32, ptr %l3, !tbaa !23
  %t41 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s3, i32 %t39)
  store { i64, ptr } %t41, ptr %l60
  br label %bb14
bb14:
  %t42 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d269, i32 0, i32 1) }, 1
  %t43 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d269, i32 0, i32 1) }, 0
  %t44 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t44, 1
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t47 = add i64 %t43, %t46
  %t48 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t47)
  call void @olang_textcopy(ptr %t48, ptr %t42, i64 %t43)
  %t49 = getelementptr i8, ptr %t48, i64 %t43
  call void @olang_textcopy(ptr %t49, ptr %t45, i64 %t46)
  %t50 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t48, 1
  %t53 = extractvalue { i64, ptr } %t51, 0
  %t54 = extractvalue { i64, ptr } %t51, 1
  %t55 = mul i64 %t53, 1
  %t56 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t55)
  call void @llvm.memcpy.p0.p0.i64(ptr %t56, ptr %t54, i64 %t55, i1 false)
  %t57 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  %t59 = load ptr, ptr %l58, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s3, ptr %t59, { i64, ptr } %t58)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb148
bb16:
  %t61 = load { i64, [8 x i64] }, ptr %l1
  %t63 = extractvalue { i64, [8 x i64] } %t61, 0
  %t64 = icmp eq i64 %t63, 2
  br i1 %t64, label %bb17, label %bb18
bb17:
  %t66 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t67 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t66, i32 0, i32 0
  %t68 = load { i64, [4 x i64] }, ptr %t67
  store { i64, [4 x i64] } %t68, ptr %l4
  %t70 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t71 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t70, i32 0, i32 1
  %t72 = load i32, ptr %t71
  store i32 %t72, ptr %l5, !tbaa !23
  %t74 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t75 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t74, i32 0, i32 2
  %t76 = load i32, ptr %t75
  store i32 %t76, ptr %l6, !tbaa !23
  br label %bb19
bb18:
  br label %bb24
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l68, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load { i64, [4 x i64] }, ptr %l4
  %t81 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t85 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s5, ptr %t79, { i64, [4 x i64] } %t80, i32 %t81)
  store { i64, ptr } %t85, ptr %l72
  br label %bb20
bb20:
  %t86 = load i32, ptr %l5, !tbaa !23
  %t88 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s5, i32 %t86)
  store { i64, ptr } %t88, ptr %l74
  br label %bb21
bb21:
  %t89 = load i32, ptr %l6, !tbaa !23
  %t91 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s5, i32 %t89)
  store { i64, ptr } %t91, ptr %l76
  br label %bb22
bb22:
  %t92 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d270, i32 0, i32 1) }, 1
  %t93 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d270, i32 0, i32 1) }, 0
  %t94 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 1
  %t96 = extractvalue { i64, ptr } %t94, 0
  %t97 = add i64 %t93, %t96
  %t98 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d271, i32 0, i32 1) }, 1
  %t99 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d271, i32 0, i32 1) }, 0
  %t100 = add i64 %t97, %t99
  %t101 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 1
  %t103 = extractvalue { i64, ptr } %t101, 0
  %t104 = add i64 %t100, %t103
  %t105 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d271, i32 0, i32 1) }, 1
  %t106 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d271, i32 0, i32 1) }, 0
  %t107 = add i64 %t104, %t106
  %t108 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t108, 1
  %t110 = extractvalue { i64, ptr } %t108, 0
  %t111 = add i64 %t107, %t110
  %t112 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t111)
  call void @olang_textcopy(ptr %t112, ptr %t92, i64 %t93)
  %t113 = getelementptr i8, ptr %t112, i64 %t93
  call void @olang_textcopy(ptr %t113, ptr %t95, i64 %t96)
  %t114 = getelementptr i8, ptr %t113, i64 %t96
  call void @olang_textcopy(ptr %t114, ptr %t98, i64 %t99)
  %t115 = getelementptr i8, ptr %t114, i64 %t99
  call void @olang_textcopy(ptr %t115, ptr %t102, i64 %t103)
  %t116 = getelementptr i8, ptr %t115, i64 %t103
  call void @olang_textcopy(ptr %t116, ptr %t105, i64 %t106)
  %t117 = getelementptr i8, ptr %t116, i64 %t106
  call void @olang_textcopy(ptr %t117, ptr %t109, i64 %t110)
  %t118 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t112, 1
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t122 = extractvalue { i64, ptr } %t119, 1
  %t123 = mul i64 %t121, 1
  %t124 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t123)
  call void @llvm.memcpy.p0.p0.i64(ptr %t124, ptr %t122, i64 %t123, i1 false)
  %t125 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t124, 1
  %t127 = load ptr, ptr %l68, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s5, ptr %t127, { i64, ptr } %t126)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s5)
  br label %bb148
bb24:
  %t129 = load { i64, [8 x i64] }, ptr %l1
  %t131 = extractvalue { i64, [8 x i64] } %t129, 0
  %t132 = icmp eq i64 %t131, 3
  br i1 %t132, label %bb25, label %bb26
bb25:
  %t134 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t135 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t134, i32 0, i32 0
  %t136 = load { i64, [4 x i64] }, ptr %t135
  store { i64, [4 x i64] } %t136, ptr %l7
  %t138 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t139 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t138, i32 0, i32 1
  %t140 = load %"compiler/mir:Range", ptr %t139
  store %"compiler/mir:Range" %t140, ptr %l8
  %t142 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t143 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t142, i32 0, i32 2
  %t144 = load i32, ptr %t143
  store i32 %t144, ptr %l9, !tbaa !23
  br label %bb27
bb26:
  br label %bb53
bb27:
  store %olang.scope zeroinitializer, ptr %s7
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load { i64, [4 x i64] }, ptr %l7
  %t150 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t146, { i64, [4 x i64] } %t147)
  store i32 %t150, ptr %l86
  br label %bb28
bb28:
  %t151 = load i32, ptr %l86, !tbaa !23
  store i32 %t151, ptr %l10, !tbaa !23
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load i32, ptr %l10, !tbaa !23
  %t156 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s7, ptr %t152, i32 %t153)
  store { i64, ptr } %t156, ptr %l89
  br label %bb29
bb29:
  %t157 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t157, ptr %l11, !tbaa !27
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load { i64, [4 x i64] }, ptr %l7
  %t160 = load i32, ptr %l10, !tbaa !23
  %t164 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s7, ptr %t158, { i64, [4 x i64] } %t159, i32 %t160)
  store { i64, ptr } %t164, ptr %l93
  br label %bb30
bb30:
  %t165 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t165, ptr %l12, !tbaa !27
  %t166 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s7)
  store %"std/prelude/text:StringBuilder" %t166, ptr %l94
  br label %bb31
bb31:
  %t167 = load %"std/prelude/text:StringBuilder", ptr %l94
  store %"std/prelude/text:StringBuilder" %t167, ptr %l13
  store ptr %l13, ptr %l95, !tbaa !29
  %t168 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t168, ptr %l96, !tbaa !27
  %t169 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t169, ptr %l97, !tbaa !27
  %t170 = load i32, ptr %l9, !tbaa !23
  %t172 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s7, i32 %t170)
  store { i64, ptr } %t172, ptr %l99
  br label %bb32
bb32:
  %t173 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d272, i32 0, i32 1) }, 1
  %t174 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d272, i32 0, i32 1) }, 0
  %t175 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t176 = extractvalue { i64, ptr } %t175, 1
  %t177 = extractvalue { i64, ptr } %t175, 0
  %t178 = add i64 %t174, %t177
  %t179 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d273, i32 0, i32 1) }, 1
  %t180 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d273, i32 0, i32 1) }, 0
  %t181 = add i64 %t178, %t180
  %t182 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t182, 1
  %t184 = extractvalue { i64, ptr } %t182, 0
  %t185 = add i64 %t181, %t184
  %t186 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d274, i32 0, i32 1) }, 1
  %t187 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d274, i32 0, i32 1) }, 0
  %t188 = add i64 %t185, %t187
  %t189 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t189, 1
  %t191 = extractvalue { i64, ptr } %t189, 0
  %t192 = add i64 %t188, %t191
  %t193 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d275, i32 0, i32 1) }, 1
  %t194 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d275, i32 0, i32 1) }, 0
  %t195 = add i64 %t192, %t194
  %t196 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t195)
  call void @olang_textcopy(ptr %t196, ptr %t173, i64 %t174)
  %t197 = getelementptr i8, ptr %t196, i64 %t174
  call void @olang_textcopy(ptr %t197, ptr %t176, i64 %t177)
  %t198 = getelementptr i8, ptr %t197, i64 %t177
  call void @olang_textcopy(ptr %t198, ptr %t179, i64 %t180)
  %t199 = getelementptr i8, ptr %t198, i64 %t180
  call void @olang_textcopy(ptr %t199, ptr %t183, i64 %t184)
  %t200 = getelementptr i8, ptr %t199, i64 %t184
  call void @olang_textcopy(ptr %t200, ptr %t186, i64 %t187)
  %t201 = getelementptr i8, ptr %t200, i64 %t187
  call void @olang_textcopy(ptr %t201, ptr %t190, i64 %t191)
  %t202 = getelementptr i8, ptr %t201, i64 %t191
  call void @olang_textcopy(ptr %t202, ptr %t193, i64 %t194)
  %t203 = insertvalue { i64, ptr } undef, i64 %t195, 0
  %t204 = insertvalue { i64, ptr } %t203, ptr %t196, 1
  %t206 = extractvalue { i64, ptr } %t204, 0
  %t207 = extractvalue { i64, ptr } %t204, 1
  %t208 = mul i64 %t206, 1
  %t209 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t208)
  call void @llvm.memcpy.p0.p0.i64(ptr %t209, ptr %t207, i64 %t208, i1 false)
  %t210 = insertvalue { i64, ptr } undef, i64 %t206, 0
  %t211 = insertvalue { i64, ptr } %t210, ptr %t209, 1
  %t212 = load ptr, ptr %l95, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s7, ptr %s7, ptr %t212, { i64, ptr } %t211)
  br label %bb33
bb33:
  store i32 0, ptr %l14, !tbaa !23
  %t214 = getelementptr %"compiler/mir:Range", ptr %l8, i32 0, i32 1
  %t215 = load i32, ptr %t214, !tbaa !23
  store i32 %t215, ptr %l15, !tbaa !23
  store i32 1, ptr %l16, !tbaa !23
  %t217 = load i32, ptr %l15, !tbaa !23
  %t218 = load i32, ptr %l14, !tbaa !23
  %t221 = icmp sgt i32 %t217, %t218
  br i1 %t221, label %bb34, label %bb35
bb34:
  %t223 = load i32, ptr %l16, !tbaa !23
  %t225 = icmp sgt i32 %t223, 0
  br i1 %t225, label %bb36, label %bb37
bb35:
  store i32 0, ptr %l106, !tbaa !23
  br label %bb39
bb36:
  %t227 = load i32, ptr %l15, !tbaa !23
  %t228 = load i32, ptr %l14, !tbaa !23
  %t231 = sub i32 %t227, %t228
  %t232 = load i32, ptr %l16, !tbaa !23
  %t235 = add i32 %t231, %t232
  %t237 = sub i32 %t235, 1
  %t238 = load i32, ptr %l16, !tbaa !23
  %t241 = sdiv i32 %t237, %t238
  store i32 %t241, ptr %l109, !tbaa !23
  br label %bb38
bb37:
  store i32 0, ptr %l109, !tbaa !23
  br label %bb38
bb38:
  %t243 = load i32, ptr %l109, !tbaa !23
  store i32 %t243, ptr %l106, !tbaa !23
  br label %bb39
bb39:
  %t244 = load i32, ptr %l106, !tbaa !23
  store i32 %t244, ptr %l17, !tbaa !23
  store i32 0, ptr %l18, !tbaa !23
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s10
  %t245 = load i32, ptr %l18, !tbaa !23
  %t246 = load i32, ptr %l17, !tbaa !23
  %t249 = icmp slt i32 %t245, %t246
  %t251 = xor i1 %t249, true
  br i1 %t251, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s10)
  br label %bb49
bb42:
  br label %bb43
bb43:
  %t253 = load i32, ptr %l14, !tbaa !23
  %t254 = load i32, ptr %l18, !tbaa !23
  %t255 = load i32, ptr %l16, !tbaa !23
  %t258 = mul i32 %t254, %t255
  %t261 = add i32 %t253, %t258
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = getelementptr %"compiler/emit:fnEm", ptr %t263, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !29
  %t268 = getelementptr %"compiler/mir:Fn", ptr %t266, i32 0, i32 15
  %t269 = getelementptr %"compiler/mir:Range", ptr %l8, i32 0, i32 0
  %t270 = load i32, ptr %t269, !tbaa !23
  %t272 = sext i32 %t270 to i64
  %t275 = sext i32 %t261 to i64
  %t278 = add i64 %t272, %t275
  %t281 = call %"compiler/mir:Case" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eAt_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %t268, i64 %t278)
  store %"compiler/mir:Case" %t281, ptr %l135
  br label %bb44
bb44:
  %t282 = load %"compiler/mir:Case", ptr %l135
  store %"compiler/mir:Case" %t282, ptr %l20
  store ptr %l13, ptr %l136, !tbaa !29
  %t283 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t283, ptr %l137, !tbaa !27
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t286 = getelementptr %"compiler/emit:fnEm", ptr %t284, i32 0, i32 0
  %t287 = load ptr, ptr %t286, !tbaa !29
  %t288 = load i32, ptr %l10, !tbaa !23
  %t289 = getelementptr %"compiler/mir:Case", ptr %l20, i32 0, i32 0
  %t290 = load i64, ptr %t289, !tbaa !24
  %t294 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2econstText(ptr %v0, ptr %s10, ptr %t287, i32 %t288, i64 %t290)
  store { i64, ptr } %t294, ptr %l142
  br label %bb45
bb45:
  %t295 = getelementptr %"compiler/mir:Case", ptr %l20, i32 0, i32 1
  %t296 = load i32, ptr %t295, !tbaa !23
  %t298 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s10, i32 %t296)
  store { i64, ptr } %t298, ptr %l144
  br label %bb46
bb46:
  %t299 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d276, i32 0, i32 1) }, 1
  %t300 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d276, i32 0, i32 1) }, 0
  %t301 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t302 = extractvalue { i64, ptr } %t301, 1
  %t303 = extractvalue { i64, ptr } %t301, 0
  %t304 = add i64 %t300, %t303
  %t305 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d276, i32 0, i32 1) }, 1
  %t306 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d276, i32 0, i32 1) }, 0
  %t307 = add i64 %t304, %t306
  %t308 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t309 = extractvalue { i64, ptr } %t308, 1
  %t310 = extractvalue { i64, ptr } %t308, 0
  %t311 = add i64 %t307, %t310
  %t312 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d277, i32 0, i32 1) }, 1
  %t313 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d277, i32 0, i32 1) }, 0
  %t314 = add i64 %t311, %t313
  %t315 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t316 = extractvalue { i64, ptr } %t315, 1
  %t317 = extractvalue { i64, ptr } %t315, 0
  %t318 = add i64 %t314, %t317
  %t319 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t318)
  call void @olang_textcopy(ptr %t319, ptr %t299, i64 %t300)
  %t320 = getelementptr i8, ptr %t319, i64 %t300
  call void @olang_textcopy(ptr %t320, ptr %t302, i64 %t303)
  %t321 = getelementptr i8, ptr %t320, i64 %t303
  call void @olang_textcopy(ptr %t321, ptr %t305, i64 %t306)
  %t322 = getelementptr i8, ptr %t321, i64 %t306
  call void @olang_textcopy(ptr %t322, ptr %t309, i64 %t310)
  %t323 = getelementptr i8, ptr %t322, i64 %t310
  call void @olang_textcopy(ptr %t323, ptr %t312, i64 %t313)
  %t324 = getelementptr i8, ptr %t323, i64 %t313
  call void @olang_textcopy(ptr %t324, ptr %t316, i64 %t317)
  %t325 = insertvalue { i64, ptr } undef, i64 %t318, 0
  %t326 = insertvalue { i64, ptr } %t325, ptr %t319, 1
  %t328 = extractvalue { i64, ptr } %t326, 0
  %t329 = extractvalue { i64, ptr } %t326, 1
  %t330 = mul i64 %t328, 1
  %t331 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t330)
  call void @llvm.memcpy.p0.p0.i64(ptr %t331, ptr %t329, i64 %t330, i1 false)
  %t332 = insertvalue { i64, ptr } undef, i64 %t328, 0
  %t333 = insertvalue { i64, ptr } %t332, ptr %t331, 1
  %t334 = load ptr, ptr %l136, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s7, ptr %s10, ptr %t334, { i64, ptr } %t333)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s10)
  br label %bb48
bb48:
  %t336 = load i32, ptr %l18, !tbaa !23
  %t338 = add i32 %t336, 1
  store i32 %t338, ptr %l18, !tbaa !23
  br label %bb40
bb49:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s7, ptr %s7, ptr %l13, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d278, i32 0, i32 1) })
  br label %bb50
bb50:
  %t341 = load ptr, ptr %l0, !tbaa !29
  store ptr %t341, ptr %l150, !tbaa !29
  %t343 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s7, ptr %s7, ptr %l13)
  store { i64, ptr } %t343, ptr %l152
  br label %bb51
bb51:
  %t344 = load ptr, ptr %l150, !tbaa !29
  %t345 = load { i64, ptr }, ptr %l152, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s7, ptr %t344, { i64, ptr } %t345)
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s7)
  br label %bb148
bb53:
  %t346 = load { i64, [8 x i64] }, ptr %l1
  %t348 = extractvalue { i64, [8 x i64] } %t346, 0
  %t349 = icmp eq i64 %t348, 4
  br i1 %t349, label %bb54, label %bb55
bb54:
  %t351 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t352 = getelementptr { %"compiler/source:Span", i32 }, ptr %t351, i32 0, i32 1
  %t353 = load i32, ptr %t352
  store i32 %t353, ptr %l21, !tbaa !23
  br label %bb56
bb55:
  br label %bb59
bb56:
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t356 = load i32, ptr %l21, !tbaa !23
  %t358 = sext i32 %t356 to i64
  %t361 = getelementptr %"compiler/emit:fnEm", ptr %t355, i32 0, i32 36
  store i64 %t358, ptr %t361, !tbaa !24
  %t362 = load ptr, ptr %l0, !tbaa !29
  store ptr %t362, ptr %l159, !tbaa !29
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t365 = getelementptr %"compiler/emit:fnEm", ptr %t363, i32 0, i32 1
  %t366 = load ptr, ptr %t365, !tbaa !29
  %t368 = getelementptr %"compiler/mir:Fn", ptr %t366, i32 0, i32 14
  %t369 = load i32, ptr %l21, !tbaa !23
  %t371 = sext i32 %t369 to i64
  %t374 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t368, i64 %t371)
  store %"compiler/mir:Call" %t374, ptr %l165
  br label %bb57
bb57:
  %t375 = load ptr, ptr %l159, !tbaa !29
  %t376 = load %"compiler/mir:Call", ptr %l165
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ecall(ptr %v0, ptr %t375, %"compiler/mir:Call" %t376)
  br label %bb58
bb58:
  br label %bb148
bb59:
  %t377 = load { i64, [8 x i64] }, ptr %l1
  %t379 = extractvalue { i64, [8 x i64] } %t377, 0
  %t380 = icmp eq i64 %t379, 6
  br i1 %t380, label %bb60, label %bb61
bb60:
  %t382 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t383 = getelementptr { %"compiler/source:Span", i32 }, ptr %t382, i32 0, i32 1
  %t384 = load i32, ptr %t383
  store i32 %t384, ptr %l22, !tbaa !23
  br label %bb62
bb61:
  br label %bb65
bb62:
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t387 = load i32, ptr %l22, !tbaa !23
  %t389 = sext i32 %t387 to i64
  %t392 = getelementptr %"compiler/emit:fnEm", ptr %t386, i32 0, i32 36
  store i64 %t389, ptr %t392, !tbaa !24
  %t393 = load ptr, ptr %l0, !tbaa !29
  store ptr %t393, ptr %l172, !tbaa !29
  %t394 = load ptr, ptr %l0, !tbaa !29
  %t396 = getelementptr %"compiler/emit:fnEm", ptr %t394, i32 0, i32 1
  %t397 = load ptr, ptr %t396, !tbaa !29
  %t399 = getelementptr %"compiler/mir:Fn", ptr %t397, i32 0, i32 14
  %t400 = load i32, ptr %l22, !tbaa !23
  %t402 = sext i32 %t400 to i64
  %t405 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t399, i64 %t402)
  store %"compiler/mir:Call" %t405, ptr %l178
  br label %bb63
bb63:
  %t406 = load ptr, ptr %l172, !tbaa !29
  %t407 = load %"compiler/mir:Call", ptr %l178
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2etailCall(ptr %v0, ptr %t406, %"compiler/mir:Call" %t407)
  br label %bb64
bb64:
  br label %bb148
bb65:
  %t408 = load { i64, [8 x i64] }, ptr %l1
  %t410 = extractvalue { i64, [8 x i64] } %t408, 0
  %t411 = icmp eq i64 %t410, 5
  br i1 %t411, label %bb66, label %bb67
bb66:
  %t413 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t414 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t413, i32 0, i32 1
  %t415 = load { i64, [4 x i64] }, ptr %t414
  store { i64, [4 x i64] } %t415, ptr %l23
  br label %bb68
bb67:
  br label %bb96
bb68:
  store %olang.scope zeroinitializer, ptr %s15
  %t417 = load ptr, ptr %l2, !tbaa !29
  %t418 = load ptr, ptr %l0, !tbaa !29
  %t420 = getelementptr %"compiler/emit:fnEm", ptr %t418, i32 0, i32 1
  %t421 = load ptr, ptr %t420, !tbaa !29
  %t423 = getelementptr %"compiler/mir:Fn", ptr %t421, i32 0, i32 1
  %t424 = load i32, ptr %t423, !tbaa !23
  %t427 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %s15, ptr %t417, i32 %t424)
  store { i64, ptr } %t427, ptr %l186
  br label %bb69
bb69:
  %t428 = load { i64, ptr }, ptr %l186, !tbaa !27
  store { i64, ptr } %t428, ptr %l24, !tbaa !27
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t431 = getelementptr %"compiler/emit:fnEm", ptr %t429, i32 0, i32 11
  %t432 = load i1, ptr %t431, !tbaa !21
  br i1 %t432, label %bb70, label %bb71
bb70:
  store %olang.scope zeroinitializer, ptr %s16
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t437 = getelementptr %"compiler/emit:fnEm", ptr %t435, i32 0, i32 9
  %t438 = load i32, ptr %t437, !tbaa !23
  %t439 = load { i64, [4 x i64] }, ptr %l23
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eput(ptr %v0, ptr %s16, ptr %s16, ptr %t434, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d279, i32 0, i32 1) }, i32 %t438, { i64, [4 x i64] } %t439, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d246, i32 0, i32 1) })
  br label %bb72
bb71:
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t445 = getelementptr %"compiler/emit:fnEm", ptr %t443, i32 0, i32 10
  %t446 = load i1, ptr %t445, !tbaa !21
  br i1 %t446, label %bb77, label %bb78
bb72:
  %t448 = load ptr, ptr %l0, !tbaa !29
  %t450 = getelementptr %"compiler/emit:fnEm", ptr %t448, i32 0, i32 10
  %t451 = load i1, ptr %t450, !tbaa !21
  br i1 %t451, label %bb73, label %bb74
bb73:
  store %olang.scope zeroinitializer, ptr %s17
  %t453 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s17, ptr %s17, ptr %s17, ptr %s17, ptr %t453, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d280, i32 0, i32 1) }, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d281, i32 0, i32 1) }, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d282, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d250, i32 0, i32 1) })
  br label %bb75
bb74:
  br label %bb76
bb75:
  call void @__olang_scope_close(ptr %s17)
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s16)
  br label %bb94
bb77:
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t457 = getelementptr %"compiler/emit:fnEm", ptr %t455, i32 0, i32 9
  %t458 = load i32, ptr %t457, !tbaa !23
  %t459 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t462 = icmp eq i32 %t458, %t459
  br i1 %t462, label %bb79, label %bb80
bb78:
  store %olang.scope zeroinitializer, ptr %s23
  %t464 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t466 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s15, ptr %s23, { i64, ptr } %t464, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d283, i32 0, i32 1) })
  store i1 %t466, ptr %l221
  br label %bb87
bb79:
  store %olang.scope zeroinitializer, ptr %s20
  %t467 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s20, ptr %s20, ptr %s20, ptr %s20, ptr %t467, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d284, i32 0, i32 1) }, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d285, i32 0, i32 1) }, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d286, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d250, i32 0, i32 1) })
  br label %bb81
bb80:
  store %olang.scope zeroinitializer, ptr %s21
  %t469 = load ptr, ptr %l0, !tbaa !29
  store ptr %t469, ptr %l203, !tbaa !29
  %t470 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t470, ptr %l204, !tbaa !27
  %t471 = load ptr, ptr %l0, !tbaa !29
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t474 = getelementptr %"compiler/emit:fnEm", ptr %t472, i32 0, i32 9
  %t475 = load i32, ptr %t474, !tbaa !23
  %t478 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s21, ptr %t471, i32 %t475)
  store { i64, ptr } %t478, ptr %l208
  br label %bb82
bb81:
  call void @__olang_scope_close(ptr %s20)
  br label %bb86
bb82:
  %t479 = load ptr, ptr %l0, !tbaa !29
  %t480 = load { i64, [4 x i64] }, ptr %l23
  %t481 = load ptr, ptr %l0, !tbaa !29
  %t483 = getelementptr %"compiler/emit:fnEm", ptr %t481, i32 0, i32 9
  %t484 = load i32, ptr %t483, !tbaa !23
  %t488 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s21, ptr %t479, { i64, [4 x i64] } %t480, i32 %t484)
  store { i64, ptr } %t488, ptr %l213
  br label %bb83
bb83:
  %t489 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d287, i32 0, i32 1) }, 1
  %t490 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d287, i32 0, i32 1) }, 0
  %t491 = load { i64, ptr }, ptr %l204, !tbaa !27
  %t492 = extractvalue { i64, ptr } %t491, 1
  %t493 = extractvalue { i64, ptr } %t491, 0
  %t494 = add i64 %t490, %t493
  %t495 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d288, i32 0, i32 1) }, 1
  %t496 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d288, i32 0, i32 1) }, 0
  %t497 = add i64 %t494, %t496
  %t498 = load { i64, ptr }, ptr %l208, !tbaa !27
  %t499 = extractvalue { i64, ptr } %t498, 1
  %t500 = extractvalue { i64, ptr } %t498, 0
  %t501 = add i64 %t497, %t500
  %t502 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d289, i32 0, i32 1) }, 1
  %t503 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d289, i32 0, i32 1) }, 0
  %t504 = add i64 %t501, %t503
  %t505 = load { i64, ptr }, ptr %l213, !tbaa !27
  %t506 = extractvalue { i64, ptr } %t505, 1
  %t507 = extractvalue { i64, ptr } %t505, 0
  %t508 = add i64 %t504, %t507
  %t509 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d290, i32 0, i32 1) }, 1
  %t510 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d290, i32 0, i32 1) }, 0
  %t511 = add i64 %t508, %t510
  %t512 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t511)
  call void @olang_textcopy(ptr %t512, ptr %t489, i64 %t490)
  %t513 = getelementptr i8, ptr %t512, i64 %t490
  call void @olang_textcopy(ptr %t513, ptr %t492, i64 %t493)
  %t514 = getelementptr i8, ptr %t513, i64 %t493
  call void @olang_textcopy(ptr %t514, ptr %t495, i64 %t496)
  %t515 = getelementptr i8, ptr %t514, i64 %t496
  call void @olang_textcopy(ptr %t515, ptr %t499, i64 %t500)
  %t516 = getelementptr i8, ptr %t515, i64 %t500
  call void @olang_textcopy(ptr %t516, ptr %t502, i64 %t503)
  %t517 = getelementptr i8, ptr %t516, i64 %t503
  call void @olang_textcopy(ptr %t517, ptr %t506, i64 %t507)
  %t518 = getelementptr i8, ptr %t517, i64 %t507
  call void @olang_textcopy(ptr %t518, ptr %t509, i64 %t510)
  %t519 = insertvalue { i64, ptr } undef, i64 %t511, 0
  %t520 = insertvalue { i64, ptr } %t519, ptr %t512, 1
  %t522 = extractvalue { i64, ptr } %t520, 0
  %t523 = extractvalue { i64, ptr } %t520, 1
  %t524 = mul i64 %t522, 1
  %t525 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t524)
  call void @llvm.memcpy.p0.p0.i64(ptr %t525, ptr %t523, i64 %t524, i1 false)
  %t526 = insertvalue { i64, ptr } undef, i64 %t522, 0
  %t527 = insertvalue { i64, ptr } %t526, ptr %t525, 1
  %t528 = load ptr, ptr %l203, !tbaa !29
  %t530 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s21, ptr %s21, ptr %t528, { i64, ptr } %t527)
  store { i64, ptr } %t530, ptr %l216
  br label %bb84
bb84:
  %t531 = load { i64, ptr }, ptr %l216, !tbaa !27
  %t532 = load ptr, ptr %l0, !tbaa !29
  %t533 = load { i64, ptr }, ptr %l24, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s15, ptr %s21, ptr %s21, ptr %s21, ptr %t532, { i64, ptr } %t533, { i64, ptr } %t531, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d291, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d250, i32 0, i32 1) })
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s21)
  br label %bb86
bb86:
  br label %bb93
bb87:
  %t538 = load i1, ptr %l221, !tbaa !21
  %t539 = xor i1 %t538, true
  br i1 %t539, label %bb88, label %bb89
bb88:
  store %olang.scope zeroinitializer, ptr %s24
  %t541 = load ptr, ptr %l0, !tbaa !29
  store ptr %t541, ptr %l223, !tbaa !29
  %t542 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t542, ptr %l224, !tbaa !27
  %t543 = load ptr, ptr %l0, !tbaa !29
  %t544 = load { i64, [4 x i64] }, ptr %l23
  %t545 = load ptr, ptr %l0, !tbaa !29
  %t547 = getelementptr %"compiler/emit:fnEm", ptr %t545, i32 0, i32 9
  %t548 = load i32, ptr %t547, !tbaa !23
  %t552 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s24, ptr %t543, { i64, [4 x i64] } %t544, i32 %t548)
  store { i64, ptr } %t552, ptr %l229
  br label %bb90
bb89:
  br label %bb92
bb90:
  %t553 = load { i64, ptr }, ptr %l229, !tbaa !27
  %t554 = extractvalue { i64, ptr } %t553, 0
  %t555 = extractvalue { i64, ptr } %t553, 1
  %t556 = mul i64 %t554, 1
  %t557 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t556)
  call void @llvm.memcpy.p0.p0.i64(ptr %t557, ptr %t555, i64 %t556, i1 false)
  %t558 = insertvalue { i64, ptr } undef, i64 %t554, 0
  %t559 = insertvalue { i64, ptr } %t558, ptr %t557, 1
  %t560 = load ptr, ptr %l223, !tbaa !29
  %t561 = load { i64, ptr }, ptr %l224, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s15, ptr %s24, ptr %s24, ptr %s24, ptr %t560, { i64, ptr } %t561, { i64, ptr } %t559, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d292, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d250, i32 0, i32 1) })
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s24)
  br label %bb92
bb92:
  call void @__olang_scope_close(ptr %s23)
  br label %bb93
bb93:
  br label %bb94
bb94:
  %t563 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s15, ptr %t563, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d293, i32 0, i32 1) })
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s15)
  br label %bb148
bb96:
  %t565 = load { i64, [8 x i64] }, ptr %l1
  %t567 = extractvalue { i64, [8 x i64] } %t565, 0
  %t568 = icmp eq i64 %t567, 11
  br i1 %t568, label %bb97, label %bb98
bb97:
  %t570 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t571 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t570, i32 0, i32 1
  %t572 = load { i64, [4 x i64] }, ptr %t571
  store { i64, [4 x i64] } %t572, ptr %l26
  %t574 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t575 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t574, i32 0, i32 2
  %t576 = load i32, ptr %t575
  store i32 %t576, ptr %l27, !tbaa !23
  %t578 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t579 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t578, i32 0, i32 3
  %t580 = load %"compiler/mir:Range", ptr %t579
  store %"compiler/mir:Range" %t580, ptr %l28
  br label %bb99
bb98:
  br label %bb101
bb99:
  %t582 = load ptr, ptr %l0, !tbaa !29
  %t583 = load { i64, [4 x i64] }, ptr %l26
  %t584 = load i32, ptr %l27, !tbaa !23
  %t585 = load %"compiler/mir:Range", ptr %l28
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2esuspend(ptr %v0, ptr %t582, { i64, [4 x i64] } %t583, i32 %t584, %"compiler/mir:Range" %t585)
  br label %bb100
bb100:
  br label %bb148
bb101:
  %t590 = load { i64, [8 x i64] }, ptr %l1
  %t592 = extractvalue { i64, [8 x i64] } %t590, 0
  %t593 = icmp eq i64 %t592, 7
  br i1 %t593, label %bb102, label %bb103
bb102:
  %t595 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t596 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t595, i32 0, i32 0
  %t597 = load %"compiler/source:Span", ptr %t596
  store %"compiler/source:Span" %t597, ptr %l29
  %t599 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t600 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t599, i32 0, i32 1
  %t601 = load { i64, [4 x i64] }, ptr %t600
  store { i64, [4 x i64] } %t601, ptr %l30
  br label %bb104
bb103:
  br label %bb116
bb104:
  store %olang.scope zeroinitializer, ptr %s26
  %t603 = load ptr, ptr %l0, !tbaa !29
  %t604 = load %"compiler/source:Span", ptr %l29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2etrace(ptr %v0, ptr %t603, %"compiler/source:Span" %t604)
  br label %bb105
bb105:
  %t607 = load ptr, ptr %l2, !tbaa !29
  %t608 = load ptr, ptr %l0, !tbaa !29
  %t610 = getelementptr %"compiler/emit:fnEm", ptr %t608, i32 0, i32 1
  %t611 = load ptr, ptr %t610, !tbaa !29
  %t613 = getelementptr %"compiler/mir:Fn", ptr %t611, i32 0, i32 1
  %t614 = load i32, ptr %t613, !tbaa !23
  %t617 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %s26, ptr %t607, i32 %t614)
  store { i64, ptr } %t617, ptr %l251
  br label %bb106
bb106:
  %t618 = load { i64, ptr }, ptr %l251, !tbaa !27
  store { i64, ptr } %t618, ptr %l31, !tbaa !27
  %t619 = load ptr, ptr %l0, !tbaa !29
  %t620 = load { i64, [4 x i64] }, ptr %l30
  %t621 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t625 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s26, ptr %t619, { i64, [4 x i64] } %t620, i32 %t621)
  store { i64, ptr } %t625, ptr %l255
  br label %bb107
bb107:
  %t626 = load { i64, ptr }, ptr %l255, !tbaa !27
  store { i64, ptr } %t626, ptr %l32, !tbaa !27
  %t627 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t629 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s26, ptr %s26, { i64, ptr } %t627, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d294, i32 0, i32 1) })
  store i1 %t629, ptr %l257
  br label %bb108
bb108:
  %t630 = load i1, ptr %l257, !tbaa !21
  br i1 %t630, label %bb109, label %bb110
bb109:
  store %olang.scope zeroinitializer, ptr %s27
  %t631 = load ptr, ptr %l0, !tbaa !29
  %t632 = load { i64, ptr }, ptr %l32, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s27, ptr %s26, ptr %s27, ptr %s27, ptr %t631, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d295, i32 0, i32 1) }, { i64, ptr } %t632, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d296, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d250, i32 0, i32 1) })
  br label %bb111
bb110:
  store %olang.scope zeroinitializer, ptr %s28
  %t635 = load ptr, ptr %l0, !tbaa !29
  store ptr %t635, ptr %l260, !tbaa !29
  %t636 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t636, ptr %l261, !tbaa !27
  %t637 = load ptr, ptr %l0, !tbaa !29
  %t638 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t639 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t640 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d297, i32 0, i32 1) }, 1
  %t641 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d297, i32 0, i32 1) }, 0
  %t643 = extractvalue { i64, ptr } %t638, 1
  %t644 = extractvalue { i64, ptr } %t638, 0
  %t645 = add i64 %t641, %t644
  %t646 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d298, i32 0, i32 1) }, 1
  %t647 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d298, i32 0, i32 1) }, 0
  %t648 = add i64 %t645, %t647
  %t650 = extractvalue { i64, ptr } %t639, 1
  %t651 = extractvalue { i64, ptr } %t639, 0
  %t652 = add i64 %t648, %t651
  %t653 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d299, i32 0, i32 1) }, 1
  %t654 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d299, i32 0, i32 1) }, 0
  %t655 = add i64 %t652, %t654
  %t656 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t655)
  call void @olang_textcopy(ptr %t656, ptr %t640, i64 %t641)
  %t657 = getelementptr i8, ptr %t656, i64 %t641
  call void @olang_textcopy(ptr %t657, ptr %t643, i64 %t644)
  %t658 = getelementptr i8, ptr %t657, i64 %t644
  call void @olang_textcopy(ptr %t658, ptr %t646, i64 %t647)
  %t659 = getelementptr i8, ptr %t658, i64 %t647
  call void @olang_textcopy(ptr %t659, ptr %t650, i64 %t651)
  %t660 = getelementptr i8, ptr %t659, i64 %t651
  call void @olang_textcopy(ptr %t660, ptr %t653, i64 %t654)
  %t661 = insertvalue { i64, ptr } undef, i64 %t655, 0
  %t662 = insertvalue { i64, ptr } %t661, ptr %t656, 1
  %t664 = extractvalue { i64, ptr } %t662, 0
  %t665 = extractvalue { i64, ptr } %t662, 1
  %t666 = mul i64 %t664, 1
  %t667 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t666)
  call void @llvm.memcpy.p0.p0.i64(ptr %t667, ptr %t665, i64 %t666, i1 false)
  %t668 = insertvalue { i64, ptr } undef, i64 %t664, 0
  %t669 = insertvalue { i64, ptr } %t668, ptr %t667, 1
  %t672 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s28, ptr %s28, ptr %t637, { i64, ptr } %t669)
  store { i64, ptr } %t672, ptr %l267
  br label %bb112
bb111:
  call void @__olang_scope_close(ptr %s27)
  br label %bb114
bb112:
  %t673 = load { i64, ptr }, ptr %l267, !tbaa !27
  %t674 = extractvalue { i64, ptr } %t673, 0
  %t675 = extractvalue { i64, ptr } %t673, 1
  %t676 = mul i64 %t674, 1
  %t677 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t676)
  call void @llvm.memcpy.p0.p0.i64(ptr %t677, ptr %t675, i64 %t676, i1 false)
  %t678 = insertvalue { i64, ptr } undef, i64 %t674, 0
  %t679 = insertvalue { i64, ptr } %t678, ptr %t677, 1
  %t680 = load ptr, ptr %l260, !tbaa !29
  %t681 = load { i64, ptr }, ptr %l261, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s26, ptr %s28, ptr %s28, ptr %s28, ptr %t680, { i64, ptr } %t681, { i64, ptr } %t679, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d300, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d250, i32 0, i32 1) })
  br label %bb113
bb113:
  call void @__olang_scope_close(ptr %s28)
  br label %bb114
bb114:
  %t683 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s26, ptr %t683, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d301, i32 0, i32 1) })
  br label %bb115
bb115:
  call void @__olang_scope_close(ptr %s26)
  br label %bb148
bb116:
  %t685 = load { i64, [8 x i64] }, ptr %l1
  %t687 = extractvalue { i64, [8 x i64] } %t685, 0
  %t688 = icmp eq i64 %t687, 8
  br i1 %t688, label %bb117, label %bb118
bb117:
  %t690 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t691 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t690, i32 0, i32 1
  %t692 = load i32, ptr %t691
  store i32 %t692, ptr %l33, !tbaa !23
  %t694 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t695 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t694, i32 0, i32 2
  %t696 = load i32, ptr %t695
  store i32 %t696, ptr %l34, !tbaa !23
  %t698 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t699 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t698, i32 0, i32 3
  %t700 = load i32, ptr %t699
  store i32 %t700, ptr %l35, !tbaa !23
  %t702 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t703 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t702, i32 0, i32 4
  %t704 = load i32, ptr %t703
  store i32 %t704, ptr %l36, !tbaa !23
  br label %bb119
bb118:
  br label %bb137
bb119:
  store %olang.scope zeroinitializer, ptr %s30
  %t706 = load ptr, ptr %l0, !tbaa !29
  %t708 = getelementptr %"compiler/emit:fnEm", ptr %t706, i32 0, i32 0
  %t709 = load ptr, ptr %t708, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s30, ptr %s30, ptr %t709, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d302, i32 0, i32 1) }, { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d303, i32 0, i32 1) })
  br label %bb120
bb120:
  %t711 = load ptr, ptr %l0, !tbaa !29
  %t712 = load i32, ptr %l33, !tbaa !23
  %t713 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d304, i32 0, i32 1) }, 1
  %t714 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d304, i32 0, i32 1) }, 0
  %t716 = sext i32 %t712 to i64
  %t717 = call i64 @__olang_fmt_i64(ptr null, i64 %t716)
  %t718 = add i64 %t714, %t717
  %t719 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d305, i32 0, i32 1) }, 1
  %t720 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d305, i32 0, i32 1) }, 0
  %t721 = add i64 %t718, %t720
  %t722 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t721)
  call void @olang_textcopy(ptr %t722, ptr %t713, i64 %t714)
  %t723 = getelementptr i8, ptr %t722, i64 %t714
  %t724 = call i64 @__olang_fmt_i64(ptr %t723, i64 %t716)
  %t725 = getelementptr i8, ptr %t723, i64 %t717
  call void @olang_textcopy(ptr %t725, ptr %t719, i64 %t720)
  %t726 = insertvalue { i64, ptr } undef, i64 %t721, 0
  %t727 = insertvalue { i64, ptr } %t726, ptr %t722, 1
  %t729 = extractvalue { i64, ptr } %t727, 0
  %t730 = extractvalue { i64, ptr } %t727, 1
  %t731 = mul i64 %t729, 1
  %t732 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t731)
  call void @llvm.memcpy.p0.p0.i64(ptr %t732, ptr %t730, i64 %t731, i1 false)
  %t733 = insertvalue { i64, ptr } undef, i64 %t729, 0
  %t734 = insertvalue { i64, ptr } %t733, ptr %t732, 1
  %t737 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s30, ptr %s30, ptr %t711, { i64, ptr } %t734)
  store { i64, ptr } %t737, ptr %l282
  br label %bb121
bb121:
  %t738 = load { i64, ptr }, ptr %l282, !tbaa !27
  store { i64, ptr } %t738, ptr %l37, !tbaa !27
  %t739 = load i32, ptr %l36, !tbaa !23
  %t740 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t743 = icmp eq i32 %t739, %t740
  br i1 %t743, label %bb122, label %bb123
bb122:
  store %olang.scope zeroinitializer, ptr %s32
  %t745 = load ptr, ptr %l0, !tbaa !29
  store ptr %t745, ptr %l286, !tbaa !29
  %t746 = load i32, ptr %l34, !tbaa !23
  %t748 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s32, i32 %t746)
  store { i64, ptr } %t748, ptr %l288
  br label %bb124
bb123:
  store %olang.scope zeroinitializer, ptr %s34
  %t749 = load ptr, ptr %l0, !tbaa !29
  %t750 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t751 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d306, i32 0, i32 1) }, 1
  %t752 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d306, i32 0, i32 1) }, 0
  %t754 = extractvalue { i64, ptr } %t750, 1
  %t755 = extractvalue { i64, ptr } %t750, 0
  %t756 = add i64 %t752, %t755
  %t757 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d307, i32 0, i32 1) }, 1
  %t758 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d307, i32 0, i32 1) }, 0
  %t759 = add i64 %t756, %t758
  %t760 = call ptr @__olang_scope_alloc(ptr %s34, i64 %t759)
  call void @olang_textcopy(ptr %t760, ptr %t751, i64 %t752)
  %t761 = getelementptr i8, ptr %t760, i64 %t752
  call void @olang_textcopy(ptr %t761, ptr %t754, i64 %t755)
  %t762 = getelementptr i8, ptr %t761, i64 %t755
  call void @olang_textcopy(ptr %t762, ptr %t757, i64 %t758)
  %t763 = insertvalue { i64, ptr } undef, i64 %t759, 0
  %t764 = insertvalue { i64, ptr } %t763, ptr %t760, 1
  %t766 = extractvalue { i64, ptr } %t764, 0
  %t767 = extractvalue { i64, ptr } %t764, 1
  %t768 = mul i64 %t766, 1
  %t769 = call ptr @__olang_scope_alloc(ptr %s34, i64 %t768)
  call void @llvm.memcpy.p0.p0.i64(ptr %t769, ptr %t767, i64 %t768, i1 false)
  %t770 = insertvalue { i64, ptr } undef, i64 %t766, 0
  %t771 = insertvalue { i64, ptr } %t770, ptr %t769, 1
  %t774 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s34, ptr %s34, ptr %t749, { i64, ptr } %t771)
  store { i64, ptr } %t774, ptr %l295
  br label %bb126
bb124:
  %t775 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d308, i32 0, i32 1) }, 1
  %t776 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d308, i32 0, i32 1) }, 0
  %t777 = load { i64, ptr }, ptr %l288, !tbaa !27
  %t778 = extractvalue { i64, ptr } %t777, 1
  %t779 = extractvalue { i64, ptr } %t777, 0
  %t780 = add i64 %t776, %t779
  %t781 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t780)
  call void @olang_textcopy(ptr %t781, ptr %t775, i64 %t776)
  %t782 = getelementptr i8, ptr %t781, i64 %t776
  call void @olang_textcopy(ptr %t782, ptr %t778, i64 %t779)
  %t783 = insertvalue { i64, ptr } undef, i64 %t780, 0
  %t784 = insertvalue { i64, ptr } %t783, ptr %t781, 1
  %t786 = extractvalue { i64, ptr } %t784, 0
  %t787 = extractvalue { i64, ptr } %t784, 1
  %t788 = mul i64 %t786, 1
  %t789 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t788)
  call void @llvm.memcpy.p0.p0.i64(ptr %t789, ptr %t787, i64 %t788, i1 false)
  %t790 = insertvalue { i64, ptr } undef, i64 %t786, 0
  %t791 = insertvalue { i64, ptr } %t790, ptr %t789, 1
  %t792 = load ptr, ptr %l286, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s32, ptr %t792, { i64, ptr } %t791)
  br label %bb125
bb125:
  call void @__olang_scope_close(ptr %s32)
  br label %bb136
bb126:
  %t794 = load { i64, ptr }, ptr %l295, !tbaa !27
  store { i64, ptr } %t794, ptr %l38, !tbaa !27
  %t795 = load i32, ptr %l35, !tbaa !23
  %t796 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t799 = icmp ne i32 %t795, %t796
  br i1 %t799, label %bb127, label %bb128
bb127:
  store %olang.scope zeroinitializer, ptr %s36
  %t801 = load ptr, ptr %l0, !tbaa !29
  store ptr %t801, ptr %l299, !tbaa !29
  %t802 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t802, ptr %l300, !tbaa !27
  %t803 = load ptr, ptr %l0, !tbaa !29
  %t804 = load i32, ptr %l35, !tbaa !23
  %t807 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalAt(ptr %v0, ptr %s36, ptr %t803, i32 %t804)
  store { i64, ptr } %t807, ptr %l303
  br label %bb129
bb128:
  br label %bb131
bb129:
  %t808 = load { i64, ptr }, ptr %l303, !tbaa !27
  %t809 = extractvalue { i64, ptr } %t808, 0
  %t810 = extractvalue { i64, ptr } %t808, 1
  %t811 = mul i64 %t809, 1
  %t812 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t811)
  call void @llvm.memcpy.p0.p0.i64(ptr %t812, ptr %t810, i64 %t811, i1 false)
  %t813 = insertvalue { i64, ptr } undef, i64 %t809, 0
  %t814 = insertvalue { i64, ptr } %t813, ptr %t812, 1
  %t815 = load ptr, ptr %l299, !tbaa !29
  %t816 = load { i64, ptr }, ptr %l300, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s36, ptr %s34, ptr %s36, ptr %s36, ptr %t815, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d309, i32 0, i32 1) }, { i64, ptr } %t816, { i64, ptr } %t814, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d250, i32 0, i32 1) })
  br label %bb130
bb130:
  call void @__olang_scope_close(ptr %s36)
  br label %bb131
bb131:
  %t818 = load ptr, ptr %l0, !tbaa !29
  %t819 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t820 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d310, i32 0, i32 1) }, 1
  %t821 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d310, i32 0, i32 1) }, 0
  %t823 = extractvalue { i64, ptr } %t819, 1
  %t824 = extractvalue { i64, ptr } %t819, 0
  %t825 = add i64 %t821, %t824
  %t826 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d311, i32 0, i32 1) }, 1
  %t827 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d311, i32 0, i32 1) }, 0
  %t828 = add i64 %t825, %t827
  %t829 = call ptr @__olang_scope_alloc(ptr %s34, i64 %t828)
  call void @olang_textcopy(ptr %t829, ptr %t820, i64 %t821)
  %t830 = getelementptr i8, ptr %t829, i64 %t821
  call void @olang_textcopy(ptr %t830, ptr %t823, i64 %t824)
  %t831 = getelementptr i8, ptr %t830, i64 %t824
  call void @olang_textcopy(ptr %t831, ptr %t826, i64 %t827)
  %t832 = insertvalue { i64, ptr } undef, i64 %t828, 0
  %t833 = insertvalue { i64, ptr } %t832, ptr %t829, 1
  %t835 = extractvalue { i64, ptr } %t833, 0
  %t836 = extractvalue { i64, ptr } %t833, 1
  %t837 = mul i64 %t835, 1
  %t838 = call ptr @__olang_scope_alloc(ptr %s34, i64 %t837)
  call void @llvm.memcpy.p0.p0.i64(ptr %t838, ptr %t836, i64 %t837, i1 false)
  %t839 = insertvalue { i64, ptr } undef, i64 %t835, 0
  %t840 = insertvalue { i64, ptr } %t839, ptr %t838, 1
  %t843 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s34, ptr %s34, ptr %t818, { i64, ptr } %t840)
  store { i64, ptr } %t843, ptr %l309
  br label %bb132
bb132:
  %t844 = load { i64, ptr }, ptr %l309, !tbaa !27
  %t845 = load ptr, ptr %l0, !tbaa !29
  store ptr %t845, ptr %l310, !tbaa !29
  store { i64, ptr } %t844, ptr %l311, !tbaa !27
  %t847 = load i32, ptr %l36, !tbaa !23
  %t849 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s34, i32 %t847)
  store { i64, ptr } %t849, ptr %l313
  br label %bb133
bb133:
  %t850 = load i32, ptr %l34, !tbaa !23
  %t852 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s34, i32 %t850)
  store { i64, ptr } %t852, ptr %l315
  br label %bb134
bb134:
  %t853 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d312, i32 0, i32 1) }, 1
  %t854 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d312, i32 0, i32 1) }, 0
  %t855 = load { i64, ptr }, ptr %l311, !tbaa !27
  %t856 = extractvalue { i64, ptr } %t855, 1
  %t857 = extractvalue { i64, ptr } %t855, 0
  %t858 = add i64 %t854, %t857
  %t859 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d313, i32 0, i32 1) }, 1
  %t860 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d313, i32 0, i32 1) }, 0
  %t861 = add i64 %t858, %t860
  %t862 = load { i64, ptr }, ptr %l313, !tbaa !27
  %t863 = extractvalue { i64, ptr } %t862, 1
  %t864 = extractvalue { i64, ptr } %t862, 0
  %t865 = add i64 %t861, %t864
  %t866 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d313, i32 0, i32 1) }, 1
  %t867 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d313, i32 0, i32 1) }, 0
  %t868 = add i64 %t865, %t867
  %t869 = load { i64, ptr }, ptr %l315, !tbaa !27
  %t870 = extractvalue { i64, ptr } %t869, 1
  %t871 = extractvalue { i64, ptr } %t869, 0
  %t872 = add i64 %t868, %t871
  %t873 = call ptr @__olang_scope_alloc(ptr %s34, i64 %t872)
  call void @olang_textcopy(ptr %t873, ptr %t853, i64 %t854)
  %t874 = getelementptr i8, ptr %t873, i64 %t854
  call void @olang_textcopy(ptr %t874, ptr %t856, i64 %t857)
  %t875 = getelementptr i8, ptr %t874, i64 %t857
  call void @olang_textcopy(ptr %t875, ptr %t859, i64 %t860)
  %t876 = getelementptr i8, ptr %t875, i64 %t860
  call void @olang_textcopy(ptr %t876, ptr %t863, i64 %t864)
  %t877 = getelementptr i8, ptr %t876, i64 %t864
  call void @olang_textcopy(ptr %t877, ptr %t866, i64 %t867)
  %t878 = getelementptr i8, ptr %t877, i64 %t867
  call void @olang_textcopy(ptr %t878, ptr %t870, i64 %t871)
  %t879 = insertvalue { i64, ptr } undef, i64 %t872, 0
  %t880 = insertvalue { i64, ptr } %t879, ptr %t873, 1
  %t882 = extractvalue { i64, ptr } %t880, 0
  %t883 = extractvalue { i64, ptr } %t880, 1
  %t884 = mul i64 %t882, 1
  %t885 = call ptr @__olang_scope_alloc(ptr %s34, i64 %t884)
  call void @llvm.memcpy.p0.p0.i64(ptr %t885, ptr %t883, i64 %t884, i1 false)
  %t886 = insertvalue { i64, ptr } undef, i64 %t882, 0
  %t887 = insertvalue { i64, ptr } %t886, ptr %t885, 1
  %t888 = load ptr, ptr %l310, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s34, ptr %t888, { i64, ptr } %t887)
  br label %bb135
bb135:
  call void @__olang_scope_close(ptr %s34)
  br label %bb136
bb136:
  call void @__olang_scope_close(ptr %s30)
  br label %bb148
bb137:
  %t890 = load { i64, [8 x i64] }, ptr %l1
  %t892 = extractvalue { i64, [8 x i64] } %t890, 0
  %t893 = icmp eq i64 %t892, 9
  br i1 %t893, label %bb138, label %bb139
bb138:
  %t895 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t896 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t895, i32 0, i32 0
  %t897 = load %"compiler/source:Span", ptr %t896
  store %"compiler/source:Span" %t897, ptr %l40
  %t899 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t900 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t899, i32 0, i32 1
  %t901 = load i32, ptr %t900, !range !{i32 0, i32 15}
  store i32 %t901, ptr %l41
  %t903 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t904 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t903, i32 0, i32 2
  %t905 = load { i64, [4 x i64] }, ptr %t904
  store { i64, [4 x i64] } %t905, ptr %l42
  br label %bb140
bb139:
  br label %bb142
bb140:
  %t907 = load ptr, ptr %l0, !tbaa !29
  %t908 = load %"compiler/source:Span", ptr %l40
  %t909 = load i32, ptr %l41, !range !{i32 0, i32 15}
  %t910 = load { i64, [4 x i64] }, ptr %l42
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eexit(ptr %v0, ptr %t907, %"compiler/source:Span" %t908, i32 %t909, { i64, [4 x i64] } %t910)
  br label %bb141
bb141:
  br label %bb148
bb142:
  %t915 = load { i64, [8 x i64] }, ptr %l1
  %t917 = extractvalue { i64, [8 x i64] } %t915, 0
  %t918 = icmp eq i64 %t917, 10
  br i1 %t918, label %bb143, label %bb144
bb143:
  br label %bb145
bb144:
  br label %bb147
bb145:
  store %olang.scope zeroinitializer, ptr %s40
  %t920 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s40, ptr %t920, { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d314, i32 0, i32 1) })
  br label %bb146
bb146:
  call void @__olang_scope_close(ptr %s40)
  br label %bb148
bb147:
  call void @__olang_check_failed(ptr @olang_loc_7633dd9d24c54174_280dfd74a77e9550)
  unreachable
bb148:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2eunwindPop(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d315, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d315, i32 0, i32 1) }, 0
  %t7 = sext i32 %a1 to i64
  %t8 = call i64 @__olang_fmt_i64(ptr null, i64 %t7)
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d316, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d316, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  %t15 = call i64 @__olang_fmt_i64(ptr %t14, i64 %t7)
  %t16 = getelementptr i8, ptr %t14, i64 %t8
  call void @olang_textcopy(ptr %t16, ptr %t10, i64 %t11)
  %t17 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t13, 1
  %t20 = extractvalue { i64, ptr } %t18, 0
  %t21 = extractvalue { i64, ptr } %t18, 1
  %t22 = mul i64 %t20, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t21, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  %t28 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t2, { i64, ptr } %t25)
  store { i64, ptr } %t28, ptr %l8
  br label %bb1
bb1:
  %t29 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 0
  %t31 = extractvalue { i64, ptr } %t29, 1
  %t32 = mul i64 %t30, 1
  %t33 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t32)
  call void @llvm.memcpy.p0.p0.i64(ptr %t33, ptr %t31, i64 %t32, i1 false)
  %t34 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t33, 1
  %t36 = load ptr, ptr %l3, !tbaa !29
  %t38 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t36, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d317, i32 0, i32 1) }, { i64, ptr } %t35, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d197, i32 0, i32 1) })
  store { i64, ptr } %t38, ptr %l10
  br label %bb2
bb2:
  %t39 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t40 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t40, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d318, i32 0, i32 1) }, { i64, ptr } %t39, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d319, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d250, i32 0, i32 1) })
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2evalueTarget(ptr %v0, ptr %a0, %"compiler/mir:Task" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Task"
  %l3 = alloca ptr
  %l4 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l20 = alloca %"compiler/mir:Lvalue"
  %l21 = alloca i32
  %l22 = alloca i32
  %l25 = alloca i32
  %l28 = alloca i1
  %l31 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/mir:Task" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/mir:Task", ptr %l1, i32 0, i32 7
  %t2 = getelementptr %"compiler/mir:Range", ptr %t1, i32 0, i32 1
  %t3 = load i32, ptr %t2, !tbaa !23
  %t5 = icmp eq i32 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/emit:fnEm", ptr %t8, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/emit:Emitter", ptr %t11, i32 0, i32 3
  %t14 = load ptr, ptr %t13, !tbaa !29
  store ptr %t14, ptr %l3, !tbaa !29
  %t16 = load ptr, ptr %l3, !tbaa !29
  store ptr %t16, ptr %l11, !tbaa !29
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l12, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/emit:fnEm", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/mir:Fn", ptr %t21, i32 0, i32 13
  %t24 = getelementptr %"compiler/mir:Task", ptr %l1, i32 0, i32 3
  %t25 = getelementptr %"compiler/mir:Range", ptr %t24, i32 0, i32 0
  %t26 = load i32, ptr %t25, !tbaa !23
  %t28 = sext i32 %t26 to i64
  %t32 = add i64 %t28, %a2
  %t35 = call %"compiler/mir:Lvalue" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e_2eAt_3ccompiler_2fmir_3aLvalue_3e(ptr %v0, ptr %t23, i64 %t32)
  store %"compiler/mir:Lvalue" %t35, ptr %l20
  br label %bb4
bb4:
  %t36 = load ptr, ptr %l12, !tbaa !29
  %t37 = load %"compiler/mir:Lvalue", ptr %l20
  %t38 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eplaceType(ptr %v0, ptr %t36, %"compiler/mir:Lvalue" %t37)
  store i32 %t38, ptr %l21
  br label %bb5
bb5:
  %t39 = load ptr, ptr %l11, !tbaa !29
  %t40 = load i32, ptr %l21, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t41, ptr %l22
  br label %bb6
bb6:
  %t42 = load i32, ptr %l22, !tbaa !23
  store i32 %t42, ptr %l4, !tbaa !23
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t44 = load i32, ptr %l4, !tbaa !23
  %t47 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t43, i32 %t44)
  store i32 %t47, ptr %l25
  br label %bb7
bb7:
  %t48 = load i32, ptr %l25, !range !{i32 0, i32 33}
  %t50 = trunc i64 19 to i32
  %t51 = icmp eq i32 %t48, %t50
  br i1 %t51, label %bb8, label %bb9
bb8:
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t54 = load i32, ptr %l4, !tbaa !23
  %t57 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t53, i32 %t54)
  store i32 %t57, ptr %l31
  br label %bb10
bb9:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb11
bb10:
  %t58 = load i32, ptr %l31, !tbaa !23
  %t59 = icmp eq i32 %t58, 0
  store i1 %t59, ptr %l28, !tbaa !21
  br label %bb11
bb11:
  %t61 = load i1, ptr %l28, !tbaa !21
  store i1 %t61, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2edeclaredSymbol(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l21 = alloca i1
  %l25 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d320, i32 0, i32 1) })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l6
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store i64 %t4, ptr %l5
  br label %bb1
bb1:
  %t8 = load i64, ptr %l5, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d321, i32 0, i32 1) }, ptr %l7, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t9, ptr %l8, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l9, !tbaa !24
  %t12 = load i64, ptr %l9, !tbaa !24
  %t13 = mul i64 %t12, 1
  %t14 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l10, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = load i64, ptr %l9, !tbaa !24
  %t22 = mul i64 %t21, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t18, ptr %t20, i64 %t22, i1 false)
  %t23 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t23, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t24 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t24, ptr %rv
  br label %ret
bb4:
  %t25 = load i64, ptr %l3, !tbaa !24
  store i64 %t25, ptr %l1, !tbaa !24
  %t26 = load i64, ptr %l1, !tbaa !24
  %t28 = add i64 %t26, 1
  store i64 %t28, ptr %l2, !tbaa !24
  br label %bb5
bb5:
  %t30 = load i64, ptr %l2, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t36 = icmp slt i64 %t30, %t33
  br i1 %t36, label %bb6, label %bb7
bb6:
  %t38 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t38, ptr %l18, !tbaa !27
  %t39 = load i64, ptr %l2, !tbaa !24
  %t41 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr i8, ptr %t42, i64 %t39
  %t44 = load i8, ptr %t43, !tbaa !32
  %t46 = call i1 @compiler_2femit_2esymbolChar(i8 %t44)
  store i1 %t46, ptr %l21
  br label %bb8
bb7:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb9
bb8:
  %t47 = load i1, ptr %l21, !tbaa !21
  store i1 %t47, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t48 = load i1, ptr %l17, !tbaa !21
  %t49 = xor i1 %t48, true
  br i1 %t49, label %bb10, label %bb11
bb10:
  br label %bb14
bb11:
  br label %bb12
bb12:
  %t51 = load i64, ptr %l2, !tbaa !24
  %t53 = add i64 %t51, 1
  store i64 %t53, ptr %l2, !tbaa !24
  br label %bb13
bb13:
  br label %bb5
bb14:
  %t55 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t55, ptr %l25, !tbaa !27
  %t56 = load i64, ptr %l1, !tbaa !24
  %t58 = add i64 %t56, 1
  store i64 %t58, ptr %l27, !tbaa !24
  %t59 = load i64, ptr %l2, !tbaa !24
  store i64 %t59, ptr %l28, !tbaa !24
  %t60 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t60, 0
  store i64 %t61, ptr %l29, !tbaa !24
  %t62 = load i64, ptr %l27, !tbaa !24
  %t63 = icmp sge i64 %t62, 0
  br i1 %t63, label %bb15, label %bb16
bb15:
  %t65 = load i64, ptr %l27, !tbaa !24
  %t66 = load i64, ptr %l28, !tbaa !24
  %t67 = icmp sle i64 %t65, %t66
  br i1 %t67, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_f695fddd526749db_a8fb91cf3e060dd7)
  unreachable
bb17:
  %t69 = load i64, ptr %l28, !tbaa !24
  %t70 = load i64, ptr %l29, !tbaa !24
  %t71 = icmp sle i64 %t69, %t70
  br i1 %t71, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_f695fddd526749db_a8fb91cf3e060dd7)
  unreachable
bb19:
  %t73 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = load i64, ptr %l27, !tbaa !24
  %t76 = load i64, ptr %l28, !tbaa !24
  %t77 = getelementptr i8, ptr %t74, i64 %t75
  %t78 = sub i64 %t76, %t75
  %t79 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t77, 1
  %t82 = extractvalue { i64, ptr } %t80, 1
  %t83 = extractvalue { i64, ptr } %t80, 0
  %t84 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t83)
  call void @olang_textcopy(ptr %t84, ptr %t82, i64 %t83)
  %t85 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t86, ptr %rv
  br label %ret
bb20:
  call void @__olang_check_failed(ptr @olang_loc_f695fddd526749db_a8fb91cf3e060dd7)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2efuzzSlug(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i8
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca { i64, ptr }
  %l19 = alloca i1
  %l20 = alloca i1
  %l22 = alloca i1
  %l24 = alloca i1
  %l26 = alloca i64
  %l34 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l7
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store i1 false, ptr %l2, !tbaa !21
  store { i64, ptr } %a0, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l4, !tbaa !24
  %t10 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb24
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t17, ptr %l15, !tbaa !27
  %t18 = load i64, ptr %l4, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 %t18
  %t23 = load i8, ptr %t22, !tbaa !32
  store i8 %t23, ptr %l6, !tbaa !22
  %t25 = load i8, ptr %l6, !tbaa !22
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t25)
  store i1 %t27, ptr %l19
  br label %bb6
bb6:
  %t28 = load i1, ptr %l19, !tbaa !21
  br i1 %t28, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb10
bb8:
  %t29 = load i8, ptr %l6, !tbaa !22
  %t31 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t29)
  store i1 %t31, ptr %l22
  br label %bb9
bb9:
  %t32 = load i1, ptr %l22, !tbaa !21
  store i1 %t32, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t33 = load i1, ptr %l20, !tbaa !21
  br i1 %t33, label %bb11, label %bb12
bb11:
  %t34 = load i1, ptr %l2, !tbaa !21
  br i1 %t34, label %bb13, label %bb14
bb12:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb22
bb13:
  %t37 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l1)
  store i64 %t37, ptr %l26
  br label %bb15
bb14:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb16
bb15:
  %t38 = load i64, ptr %l26, !tbaa !24
  %t39 = icmp sgt i64 %t38, 0
  store i1 %t39, ptr %l24, !tbaa !21
  br label %bb16
bb16:
  %t41 = load i1, ptr %l24, !tbaa !21
  br i1 %t41, label %bb17, label %bb18
bb17:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 95)
  br label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb20
bb20:
  %t43 = load i8, ptr %l6, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 %t43)
  br label %bb21
bb21:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t46 = load i64, ptr %l4, !tbaa !24
  %t48 = add i64 %t46, 1
  store i64 %t48, ptr %l4, !tbaa !24
  br label %bb2
bb24:
  %t51 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l1)
  store i64 %t51, ptr %l34
  br label %bb25
bb25:
  %t52 = load i64, ptr %l34, !tbaa !24
  %t53 = icmp eq i64 %t52, 0
  br i1 %t53, label %bb26, label %bb27
bb26:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d322, i32 0, i32 1) }, ptr %l36, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t55, ptr %l37, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t56, 0
  store i64 %t57, ptr %l38, !tbaa !24
  %t58 = load i64, ptr %l38, !tbaa !24
  %t59 = mul i64 %t58, 1
  %t60 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t59)
  %t61 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  store { i64, ptr } %t62, ptr %l39, !tbaa !27
  %t63 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = load i64, ptr %l38, !tbaa !24
  %t68 = mul i64 %t67, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t64, ptr %t66, i64 %t68, i1 false)
  %t69 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t69, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t70 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t70, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t72 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t72, ptr %l41
  br label %bb29
bb29:
  %t73 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t73, ptr %l42, !tbaa !27
  %t74 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t74, 0
  store i64 %t75, ptr %l43, !tbaa !24
  %t76 = load i64, ptr %l43, !tbaa !24
  %t77 = mul i64 %t76, 1
  %t78 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t77)
  %t79 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t78, 1
  store { i64, ptr } %t80, ptr %l44, !tbaa !27
  %t81 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = load i64, ptr %l43, !tbaa !24
  %t86 = mul i64 %t85, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t82, ptr %t84, i64 %t86, i1 false)
  %t87 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t87, ptr %l42, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t88 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t88, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/emit:Object" @compiler_2femit_3aObject_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %rv = alloca %"compiler/emit:Object"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/emit:Object" undef, { i64, ptr } %a0, 0
  %t10 = insertvalue %"compiler/emit:Object" %t8, i32 %a1, 1
  %t12 = insertvalue %"compiler/emit:Object" %t10, { i64, ptr } %a2, 2
  %t14 = insertvalue %"compiler/emit:Object" %t12, i64 -1, 3
  store %"compiler/emit:Object" %t14, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/emit:Object", ptr %rv
  ret %"compiler/emit:Object" %rr
}

define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d0 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c".destruct" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d1 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c".lambda" }>, align 8
@.d2 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"test" }>, align 8
@.d3 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".init" }>, align 8
@.d4 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c".contract" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
@.d5 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c".adapter" }>, align 8
@.d6 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"olang.table." }>, align 8
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d7 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"ptr @" }>, align 8
@.d8 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c", ptr @" }>, align 8
@.d9 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c", ptr @" }>, align 8
@.d10 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d11 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c" = linkonce_odr constant [" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d12 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" x ptr] [" }>, align 8
@.d13 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"]\0A" }>, align 8
@.d14 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d16 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d17 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".k" }>, align 8
@.d18 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"global" }>, align 8
@.d19 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"constant" }>, align 8
@.d20 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"internal constant" }>, align 8
@.d21 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"internal global" }>, align 8
@.d22 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d23 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d24 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d25 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" x i8]" }>, align 8
@.d26 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d27 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" x i8] c\22" }>, align 8
@.d28 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\22" }>, align 8
@.d29 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d30 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d31 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d32 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d33 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".k" }>, align 8
@.d34 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".k" }>, align 8
@.d35 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d36 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ptr " }>, align 8
@.d37 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"ptr getelementptr (i8, ptr " }>, align 8
@.d38 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d39 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d40 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d41 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" <{ " }>, align 8
@.d42 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" }> <{ " }>, align 8
@.d43 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c" }>, align " }>, align 8
@.d44 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d45 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"llvm.coro.id" }>, align 8
@.d46 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"token @llvm.coro.id(i32, ptr, ptr, ptr)" }>, align 8
@.d47 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"llvm.coro.alloc" }>, align 8
@.d48 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"i1 @llvm.coro.alloc(token)" }>, align 8
@.d49 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"llvm.coro.size.i64" }>, align 8
@.d50 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"i64 @llvm.coro.size.i64()" }>, align 8
@.d51 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"llvm.coro.align.i64" }>, align 8
@.d52 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"i64 @llvm.coro.align.i64()" }>, align 8
@.d53 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"llvm.coro.begin" }>, align 8
@.d54 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"ptr @llvm.coro.begin(token, ptr)" }>, align 8
@.d55 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"llvm.coro.suspend" }>, align 8
@.d56 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"i8 @llvm.coro.suspend(token, i1)" }>, align 8
@.d57 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"llvm.coro.end" }>, align 8
@.d58 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"i1 @llvm.coro.end(ptr, i1, token)" }>, align 8
@.d59 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"llvm.coro.free" }>, align 8
@.d60 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"ptr @llvm.coro.free(token, ptr)" }>, align 8
@.d61 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"llvm.coro.resume" }>, align 8
@.d62 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"void @llvm.coro.resume(ptr)" }>, align 8
@.d63 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"llvm.coro.destroy" }>, align 8
@.d64 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"void @llvm.coro.destroy(ptr)" }>, align 8
@.d65 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"llvm.coro.done" }>, align 8
@.d66 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"i1 @llvm.coro.done(ptr)" }>, align 8
@.d67 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"llvm.coro.promise" }>, align 8
@.d68 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"ptr @llvm.coro.promise(ptr, i32, i1)" }>, align 8
@.d69 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d70 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"declare " }>, align 8
@.d71 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d72 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".walk" }>, align 8
@.d73 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d74 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d75 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d76 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d77 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d78 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d79 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d80 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" (" }>, align 8
@.d81 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d82 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"not lowered: " }>, align 8
@.d83 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"entry:\0A  ret void\0A}\0A\0A" }>, align 8
@.d84 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"__olang_check_failed" }>, align 8
@.d85 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"not lowered" }>, align 8
@.d86 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"not lowered" }>, align 8
@.d87 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".walk" }>, align 8
@.d88 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" alwaysinline" }>, align 8
@.d89 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".walk" }>, align 8
@.d90 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"olang_test_" }>, align 8
@.d91 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"main" }>, align 8
declare void @__olang_ert_req_clear()
@.d92 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"G_2e" }>, align 8
@.d93 = private constant <{ i64, [66 x i8] }> <{ i64 0, [66 x i8] c"the runtime's text (std/runtime/runtime.ll could not be filled in)" }>, align 8
@.d94 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d95 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d96 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d97 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d98 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"%" }>, align 8
@.d99 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d100 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"define " }>, align 8
@.d101 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d102 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c"%olang.builder = type { ptr, i64, i64, ptr, ptr }\0A" }>, align 8
@.d103 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"__olang_san_init" }>, align 8
@.d104 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"  call void @__olang_san_init()\0A" }>, align 8
@.d105 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"entry:\0A" }>, align 8
@.d106 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"ptr %env" }>, align 8
@.d107 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d108 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"ptr %out" }>, align 8
@.d109 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d110 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"ptr %v" }>, align 8
@.d111 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"__olang_prog_scope" }>, align 8
@.d112 = private constant <{ i64, [67 x i8] }> <{ i64 0, [67 x i8] c"@__olang_prog_scope = external thread_local(initialexec) global ptr" }>, align 8
@.d113 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"  %g" }>, align 8
@.d114 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c" = load ptr, ptr @__olang_prog_scope\0A" }>, align 8
@.d115 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"ptr %g" }>, align 8
@.d116 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d117 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"ptr %a" }>, align 8
@.d118 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"ptr %a" }>, align 8
@.d119 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"c, ptr %a" }>, align 8
@.d120 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"e" }>, align 8
@.d121 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" %a" }>, align 8
@.d122 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d123 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"  call void @" }>, align 8
@.d124 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d125 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")\0A" }>, align 8
@.d126 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d127 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"  ret void\0A}\0A\0A" }>, align 8
@.d128 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"  ret i32 0\0A}\0A\0A" }>, align 8
@.d129 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"  %r = call " }>, align 8
@.d130 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" @" }>, align 8
@.d131 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d132 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")\0A" }>, align 8
@.d133 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"  ret " }>, align 8
@.d134 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" %r\0A}\0A\0A" }>, align 8
@.d135 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
@.d136 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"%r" }>, align 8
@.d137 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"extractvalue " }>, align 8
@.d138 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" %r, 0" }>, align 8
@.d139 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
@.d140 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i32" }>, align 8
@.d141 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"ret i32 " }>, align 8
@.d142 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"extractvalue " }>, align 8
@.d143 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" %r, 1" }>, align 8
@.d144 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"%r" }>, align 8
@.d145 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ret " }>, align 8
@.d146 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d147 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"extractvalue " }>, align 8
@.d148 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" %r, 1" }>, align 8
@.d149 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"%r" }>, align 8
@.d150 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"insertvalue " }>, align 8
@.d151 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c" zeroinitializer, i32 " }>, align 8
@.d152 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d153 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"insertvalue " }>, align 8
@.d154 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d155 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d156 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d157 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ret " }>, align 8
@.d158 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d159 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"}\0A\0A" }>, align 8
@.d160 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"__olang_scope_alloc_zeroed_min" }>, align 8
@.d161 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"__olang_scope_alloc_min" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d162 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"call ptr @" }>, align 8
@.d163 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(ptr " }>, align 8
@.d164 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d165 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d166 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"__olang_scope_alloc_zeroed" }>, align 8
@.d167 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_scope_alloc" }>, align 8
@.d168 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"call ptr @" }>, align 8
@.d169 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(ptr " }>, align 8
@.d170 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d171 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d172 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"bfloat" }>, align 8
@.d173 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"half" }>, align 8
@.d174 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"bitcast " }>, align 8
@.d175 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d176 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" to " }>, align 8
@.d177 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"half" }>, align 8
@.d178 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"a constant element of a " }>, align 8
@.d179 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"zeroinitializer" }>, align 8
@.d180 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d181 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"{ i64 " }>, align 8
@.d182 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d183 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" }" }>, align 8
@.d184 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"an index into no array" }>, align 8
@.d185 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"getelementptr " }>, align 8
@.d186 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d187 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", i64 0, i64 " }>, align 8
@.d188 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"getelementptr { i64, ptr }, ptr " }>, align 8
@.d189 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", i32 0, i32 1" }>, align 8
@.d190 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d191 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"getelementptr " }>, align 8
@.d192 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d193 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d194 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"%l" }>, align 8
@.d195 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%lp" }>, align 8
@.d196 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d197 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d198 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"undef" }>, align 8
@.d199 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"insertvalue " }>, align 8
@.d200 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d201 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d202 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"zeroinitializer" }>, align 8
@.d203 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"__olang_rd_quote" }>, align 8
@.d204 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"__olang_sb_room" }>, align 8
@.d205 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"__olang_sb_add" }>, align 8
@.d206 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c"call i64 @__olang_rd_quote(ptr null, i64 0, ptr " }>, align 8
@.d207 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d208 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c", i8 " }>, align 8
@.d209 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d210 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"call ptr @__olang_sb_room(ptr " }>, align 8
@.d211 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d212 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d213 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"call i64 @__olang_rd_quote(ptr " }>, align 8
@.d214 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", i64 0, ptr " }>, align 8
@.d215 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d216 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c", i8 " }>, align 8
@.d217 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d218 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"call void @__olang_sb_add(ptr " }>, align 8
@.d219 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d220 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d221 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"lshr i32 " }>, align 8
@.d222 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c", 16" }>, align 8
@.d223 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"and i32 " }>, align 8
@.d224 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c", 65535" }>, align 8
@.d225 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
@.d226 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"icmp eq i32 " }>, align 8
@.d227 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d228 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"select i1 " }>, align 8
@.d229 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i32 " }>, align 8
@.d230 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"icmp eq i32 " }>, align 8
@.d231 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d232 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"shl i32 " }>, align 8
@.d233 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c", 16" }>, align 8
@.d234 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"or i32 " }>, align 8
@.d235 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d236 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"select i1 " }>, align 8
@.d237 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", i32 0, i32 " }>, align 8
@.d238 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"getelementptr " }>, align 8
@.d239 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d240 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d241 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"sub i64 " }>, align 8
@.d242 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d243 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"getelementptr " }>, align 8
@.d244 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c", ptr %prom, i32 0, i32 2" }>, align 8
@.d245 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d246 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d247 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i32" }>, align 8
@.d248 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
@.d249 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%rv" }>, align 8
@.d250 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d251 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"insertvalue " }>, align 8
@.d252 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c" zeroinitializer, " }>, align 8
@.d253 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d254 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d255 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%rv" }>, align 8
@.d256 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c"call i8 @llvm.coro.suspend(token none, i1 false)" }>, align 8
@.d257 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"gen.res" }>, align 8
@.d258 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"gen.drop" }>, align 8
@.d259 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"switch i8 " }>, align 8
@.d260 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c", label %gen.end [ i8 0, label %" }>, align 8
@.d261 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c" i8 1, label %" }>, align 8
@.d262 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" ]" }>, align 8
@.d263 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"br label %" }>, align 8
@.d264 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_scope_close" }>, align 8
@.d265 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"call void @__olang_scope_close(ptr %s" }>, align 8
@.d266 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d267 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"br label %gen.free" }>, align 8
@.d268 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"unreachable" }>, align 8
@.d269 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"br label %" }>, align 8
@.d270 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"br i1 " }>, align 8
@.d271 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", label %" }>, align 8
@.d272 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"switch " }>, align 8
@.d273 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d274 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", label %" }>, align 8
@.d275 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" [" }>, align 8
@.d276 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d277 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", label %" }>, align 8
@.d278 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" ]" }>, align 8
@.d279 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"%out" }>, align 8
@.d280 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i32" }>, align 8
@.d281 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
@.d282 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%rv" }>, align 8
@.d283 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d284 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i32" }>, align 8
@.d285 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
@.d286 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%rv" }>, align 8
@.d287 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"insertvalue " }>, align 8
@.d288 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c" zeroinitializer, " }>, align 8
@.d289 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d290 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d291 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%rv" }>, align 8
@.d292 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%rv" }>, align 8
@.d293 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"br label %ret" }>, align 8
@.d294 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i32" }>, align 8
@.d295 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i32" }>, align 8
@.d296 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%rv" }>, align 8
@.d297 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"insertvalue " }>, align 8
@.d298 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c" zeroinitializer, i32 " }>, align 8
@.d299 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d300 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%rv" }>, align 8
@.d301 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"br label %ret" }>, align 8
@.d302 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"__olang_join_tasks" }>, align 8
@.d303 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"i64 @__olang_join_tasks(ptr)" }>, align 8
@.d304 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"call i64 @__olang_join_tasks(ptr %jh" }>, align 8
@.d305 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d306 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"trunc i64 " }>, align 8
@.d307 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" to i32" }>, align 8
@.d308 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"br label %" }>, align 8
@.d309 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i32" }>, align 8
@.d310 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"icmp ne i32 " }>, align 8
@.d311 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d312 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"br i1 " }>, align 8
@.d313 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", label %" }>, align 8
@.d314 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"a cleanup (interpret's)" }>, align 8
@.d315 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"getelementptr %olang.unwind, ptr %u" }>, align 8
@.d316 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", i32 0, i32 0" }>, align 8
@.d317 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d318 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d319 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"@__olang_unwind_top" }>, align 8
@.d320 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d321 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d322 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"test" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %a0)
declare i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToUpper(i8 %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2einstanceProfName(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ereadableTypes(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fload_2eErrQualifier(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1)
@olang_loc_708d0e5229213e92_b8dbbceffe09cee = external constant [0 x i8]
@olang_loc_adcc4a96e8e96893_813fe5cdd5223daf = external constant [0 x i8]
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eemitAll(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehead(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fio_2estd_2fio_3aWriter_2eWrite(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2edbgTail(ptr %v0, i64 %a0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eattributes(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etableName(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehas(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2eRef_H53de96b937c1888202b72d022fb4696d(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etypeid(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewant(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [2 x i64] } @compiler_2flower_2ecompiler_2flower_3aLowerer_2eCodeOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eAnySlotBase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i64 %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2eLen_3ccompiler_2feval_3aBlob_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2eRef_3ccompiler_2feval_3aBlob_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eLen_3cU8_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
declare i8 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eAt_3cU8_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ehexByte(ptr %v0, i8 %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, i32 %a3)
declare i32 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecodeType(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehasEnv(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2epassedOf(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2)
declare i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ethunkSym(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i1 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgType(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efnItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, { i64, ptr } %a3, i64 %a4, i1 %a5, { i64, ptr } %a6)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisGenFn(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePayloadSize(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3aEmitter_2earrayOfE(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_672626b841abebed_e9d6bd273cfd5371 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehomeOf(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2flower_2ecompiler_2flower_3aLowerer_2eLowerKey(ptr %out, ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1)
declare { i64, ptr } @compiler_2femit_2elinkFor(ptr %v0, i64 %a0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eheader(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, { i64, ptr } %a3, i64 %a4, i1 %a5, { i64, ptr } %a6, { i64, ptr } %a7)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eVerify(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2egap(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisGlobalInit(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2estub(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewalkStub(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, { i64, ptr } %a3, i64 %a4, i1 %a5, { i64, ptr } %a6)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewriteBody(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [2 x i64] } %a1, ptr %a2, { i64, ptr } %a3, i64 %a4, i1 %a5, { i64, ptr } %a6, i1 %a7)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare { { i64, ptr }, { i64, ptr } } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etestParts(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_Hb3133f486435530b533aaf49461c92b5(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H64d9be73b6c9bed004c541bdf7f0ca0a(ptr %v0, ptr %a0, i32 %a1, i1 %a2)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eEmbedded(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_ef8ce655497c6e66_70bdfc36b0b8c4fa = external constant [0 x i8]
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ealiased(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eHash(ptr %v0, { i64, ptr } %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @compiler_2fruntime_2eText(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1, i1 %a2, i1 %a3)
declare { i64, ptr } @compiler_2fruntime_2eDecls(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePassing(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_afcb0129fb824946_88799b4b9f9e7b3a = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare void @compiler_2fmir_3aFn_2ector(ptr %out, ptr %v0, { i64, [2 x i64] } %a0, i32 %a1, i64 %a2, %"compiler/source:Span" %a3)
declare void @compiler_2femit_3afnEm_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2femit_2erefsIn(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_6f064da57090b2af_17093dce158f11fb = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2fmir_2eNoLocal = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
@olang_loc_ed162375e135a06c_e406bb0ac0d59940 = external constant [0 x i8]
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2ederefs(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %a1)
declare { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1, i64 %a2)
declare i1 @compiler_2fmir_2ecompiler_2fmir_3aLvalue_2eBaseIs(%"compiler/mir:Lvalue" %a0, i32 %a1)
@olang_loc_5f9c6fbf78b3e51d_e9dc61b8da3e01d1 = external constant [0 x i8]
@olang_loc_afa6164151ba006_66d817e1c679673a = external constant [0 x i8]
declare i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ealign(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ebf16Bits(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i1 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eopaque16(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2eAt_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2econstText(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare { { i64, ptr }, { i64, ptr }, i64 } @compiler_2femit_2ecompiler_2femit_3afnEm_2econstInit(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare { { i64, ptr }, i64 } @compiler_2femit_2ecompiler_2femit_3afnEm_2econstGlobal(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, i32 %a2, { i64, ptr } %a3)
@olang_loc_3de177096d03f952_4b04555d717d3dfe = external constant [0 x i8]
@olang_loc_a00373ca27d5619a_9315010cb9ead296 = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eisFrame(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edbgLine(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %v1, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eposition(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eplaceType(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edataPtr(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Lvalue" %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eindex(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erunTime(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epair(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2eput(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, [4 x i64] } %a3, { i64, ptr } %a4)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_97d51a883f8cc986_4828fb3e43690a82 = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2eunwindPush(ptr %v0, ptr %a0, i32 %a1, i1 %a2)
declare { i64, ptr } @compiler_2femit_2eblockName(ptr %v0, i32 %a0)
declare i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ewalkKey(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2ewalkEnd(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare %"compiler/source:Span" @compiler_2femit_2etermSpan({ i64, [8 x i64] } %a0)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare %"compiler/mir:Case" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eAt_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2ecall(ptr %v0, ptr %a0, %"compiler/mir:Call" %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2etailCall(ptr %v0, ptr %a0, %"compiler/mir:Call" %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2etrace(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
@G_2ecompiler_2fmir_2eI32T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\05\00\00\00" }>, align 8
@G_2ecompiler_2fmir_2eNoBlock = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2eexit(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, [4 x i64] } %a3)
@olang_loc_7633dd9d24c54174_280dfd74a77e9550 = external constant [0 x i8]
declare %"compiler/mir:Lvalue" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLvalue_3e_2eAt_3ccompiler_2fmir_3aLvalue_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2femit_2esymbolChar(i8 %a0)
@olang_loc_f695fddd526749db_a8fb91cf3e060dd7 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
