; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/emit:Emitter" = type { ptr, ptr, ptr, ptr, i1, i1, i1, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, i64, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i1, i1, { i64, ptr }, i1, i64, i64, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/lower:Lowerer" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i32, i32, i32 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr } }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/emit:Object" = type { { i64, ptr }, i32, { i64, ptr }, i64 }
%"compiler/mir:Place" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/emit:fnEm" = type { ptr, ptr, { i64, [1 x i64] }, %"std/prelude/text:StringBuilder", %"std/prelude/text:StringBuilder", %"std/prelude/text:StringBuilder", i64, i64, i64, i32, i1, i1, i1, i1, { i64, ptr }, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/text:StringBuilder", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/mir:Task" = type { { i64, [5 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/source:Span" }
%"compiler/mir:TaskClause" = type { %"compiler/mir:Range", i1, { i64, [4 x i64] } }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/mir:Fn" = type { { i64, [1 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/mir:BasicBlock" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [7 x i64] } }
%"compiler/mir:ScopeInfo" = type { i32, i32, i32, %"compiler/source:Span", i32 }
%"compiler/mir:Local" = type { i32, %"compiler/source:Span", i32, i32, { i64, [1 x i64] } }
%"compiler/mir:Case" = type { i64, i32 }
%"compiler/mir:Call" = type { { i64, [5 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Place", i1, i32, i32, i32 }
@G_2ecompiler_2femit_2eHomeInst = constant <{ [8 x i8] }> <{ [8 x i8] c"\FD\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2femit_2eHomeLoc = constant <{ [8 x i8] }> <{ [8 x i8] c"\FC\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2femit_2eHomeLocal = constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2femit_2eHomeShared = constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2femit_2ePartSize = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\10\00\00\00\00\00" }>, align 8
@G_2ecompiler_2femit_2ePartSizeDev = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\08\00\00\00\00\00" }>, align 8
@G_2ecompiler_2femit_2emathExact = constant <{ ptr }> <{ ptr @G_2ecompiler_2femit_2emathExact.k1 }>, align 8
@G_2ecompiler_2femit_2emathExact.k1 = internal global <{ [8 x i8], ptr, [16 x i8] }> <{ [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k2, [16 x i8] c"\09\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2femit_2emathExact.k2 = internal global <{ [40 x i8], ptr, [8 x i8], ptr, ptr, [16 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [40 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k3, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k4, ptr @G_2ecompiler_2femit_2emathExact.k5, [16 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k6, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k7, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k8 }>, align 64
@G_2ecompiler_2femit_2emathExact.k3 = internal global <{ [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k9, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k10 }>, align 32
@G_2ecompiler_2femit_2emathExact.k4 = internal global <{ [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k11, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k12 }>, align 32
@G_2ecompiler_2femit_2emathExact.k5 = internal global <{ [8 x i8], ptr, [16 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k13, [16 x i8] c"\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2femit_2emathExact.k6 = internal global <{ [8 x i8], ptr, [16 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k14, [16 x i8] c"\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2femit_2emathExact.k7 = internal global <{ [8 x i8], ptr, [16 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k15, [16 x i8] c"\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2femit_2emathExact.k8 = internal global <{ [8 x i8], ptr, [16 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k16, [16 x i8] c"\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2femit_2emathExact.k9 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\63\6F\70\79\73\69\67\6E" }>, align 8
@G_2ecompiler_2femit_2emathExact.k10 = internal global <{ [8 x i8], ptr, [16 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k17, [16 x i8] c"\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2femit_2emathExact.k11 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\66\6D\61" }>, align 8
@G_2ecompiler_2femit_2emathExact.k12 = internal global <{ [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k18, [8 x i8] c"\01\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k19 }>, align 32
@G_2ecompiler_2femit_2emathExact.k13 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\63\65\69\6C" }>, align 8
@G_2ecompiler_2femit_2emathExact.k14 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\72\6F\75\6E\64" }>, align 8
@G_2ecompiler_2femit_2emathExact.k15 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\66\6C\6F\6F\72" }>, align 8
@G_2ecompiler_2femit_2emathExact.k16 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\73\71\72\74" }>, align 8
@G_2ecompiler_2femit_2emathExact.k17 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\74\72\75\6E\63" }>, align 8
@G_2ecompiler_2femit_2emathExact.k18 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\72\6F\75\6E\64\65\76\65\6E" }>, align 8
@G_2ecompiler_2femit_2emathExact.k19 = internal global <{ [8 x i8], ptr, [16 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathExact.k20, [16 x i8] c"\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2femit_2emathExact.k20 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\66\61\62\73" }>, align 8
@G_2ecompiler_2femit_2emathInexact = constant <{ ptr }> <{ ptr @G_2ecompiler_2femit_2emathInexact.k1 }>, align 8
@G_2ecompiler_2femit_2emathInexact.k1 = internal global <{ [8 x i8], ptr, [16 x i8] }> <{ [8 x i8] c"\40\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k2, [16 x i8] c"\2C\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2femit_2emathInexact.k2 = internal global <{ ptr, [8 x i8], ptr, [40 x i8], ptr, ptr, [24 x i8], ptr, ptr, [8 x i8], ptr, [32 x i8], ptr, ptr, [8 x i8], ptr, ptr, ptr, ptr, ptr, ptr, [8 x i8], ptr, [16 x i8], ptr, ptr, ptr, ptr, ptr, [24 x i8], ptr, [16 x i8], ptr, [16 x i8], ptr, ptr, [24 x i8], ptr, [8 x i8], ptr, ptr, [16 x i8], ptr, [24 x i8], ptr }> <{ ptr @G_2ecompiler_2femit_2emathInexact.k3, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k4, [40 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k5, ptr @G_2ecompiler_2femit_2emathInexact.k6, [24 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k7, ptr @G_2ecompiler_2femit_2emathInexact.k8, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k9, [32 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k10, ptr @G_2ecompiler_2femit_2emathInexact.k11, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k12, ptr @G_2ecompiler_2femit_2emathInexact.k13, ptr @G_2ecompiler_2femit_2emathInexact.k14, ptr @G_2ecompiler_2femit_2emathInexact.k15, ptr @G_2ecompiler_2femit_2emathInexact.k16, ptr @G_2ecompiler_2femit_2emathInexact.k17, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k18, [16 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k19, ptr @G_2ecompiler_2femit_2emathInexact.k20, ptr @G_2ecompiler_2femit_2emathInexact.k21, ptr @G_2ecompiler_2femit_2emathInexact.k22, ptr @G_2ecompiler_2femit_2emathInexact.k23, [24 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k24, [16 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k25, [16 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k26, ptr @G_2ecompiler_2femit_2emathInexact.k27, [24 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k28, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k29, ptr @G_2ecompiler_2femit_2emathInexact.k30, [16 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k31, [24 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k32 }>, align 64
@G_2ecompiler_2femit_2emathInexact.k3 = internal global <{ [8 x i8], ptr, [16 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k33, [16 x i8] c"\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2femit_2emathInexact.k4 = internal global <{ [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k34, [8 x i8] c"\01\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k35 }>, align 32
@G_2ecompiler_2femit_2emathInexact.k5 = internal global <{ [8 x i8], ptr, [16 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k36, [16 x i8] c"\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2femit_2emathInexact.k6 = internal global <{ [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k37, [8 x i8] c"\01\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k38 }>, align 32
@G_2ecompiler_2femit_2emathInexact.k7 = internal global <{ [8 x i8], ptr, [16 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k39, [16 x i8] c"\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2femit_2emathInexact.k8 = internal global <{ [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k40, [8 x i8] c"\01\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k41 }>, align 32
@G_2ecompiler_2femit_2emathInexact.k9 = internal global <{ [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k42, [8 x i8] c"\01\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k43 }>, align 32
@G_2ecompiler_2femit_2emathInexact.k10 = internal global <{ [8 x i8], ptr, [16 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k44, [16 x i8] c"\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2femit_2emathInexact.k11 = internal global <{ [8 x i8], ptr, [16 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k45, [16 x i8] c"\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2femit_2emathInexact.k12 = internal global <{ [8 x i8], ptr, [16 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k46, [16 x i8] c"\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2femit_2emathInexact.k13 = internal global <{ [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k47, [8 x i8] c"\01\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k48 }>, align 32
@G_2ecompiler_2femit_2emathInexact.k14 = internal global <{ [8 x i8], ptr, [16 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k49, [16 x i8] c"\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2femit_2emathInexact.k15 = internal global <{ [8 x i8], ptr, [16 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k50, [16 x i8] c"\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2femit_2emathInexact.k16 = internal global <{ [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k51, [8 x i8] c"\01\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k52 }>, align 32
@G_2ecompiler_2femit_2emathInexact.k17 = internal global <{ [8 x i8], ptr, [16 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k53, [16 x i8] c"\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2femit_2emathInexact.k18 = internal global <{ [8 x i8], ptr, [16 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k54, [16 x i8] c"\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2femit_2emathInexact.k19 = internal global <{ [8 x i8], ptr, [16 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k55, [16 x i8] c"\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2femit_2emathInexact.k20 = internal global <{ [8 x i8], ptr, [16 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k56, [16 x i8] c"\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2femit_2emathInexact.k21 = internal global <{ [8 x i8], ptr, [16 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k57, [16 x i8] c"\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2femit_2emathInexact.k22 = internal global <{ [8 x i8], ptr, [16 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k58, [16 x i8] c"\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2femit_2emathInexact.k23 = internal global <{ [8 x i8], ptr, [16 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k59, [16 x i8] c"\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2femit_2emathInexact.k24 = internal global <{ [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k60, [8 x i8] c"\01\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k61 }>, align 32
@G_2ecompiler_2femit_2emathInexact.k25 = internal global <{ [8 x i8], ptr, [16 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k62, [16 x i8] c"\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2femit_2emathInexact.k26 = internal global <{ [8 x i8], ptr, [16 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k63, [16 x i8] c"\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2femit_2emathInexact.k27 = internal global <{ [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k64, [8 x i8] c"\01\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k65 }>, align 32
@G_2ecompiler_2femit_2emathInexact.k28 = internal global <{ [8 x i8], ptr, [16 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k66, [16 x i8] c"\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2femit_2emathInexact.k29 = internal global <{ [8 x i8], ptr, [16 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k67, [16 x i8] c"\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2femit_2emathInexact.k30 = internal global <{ [8 x i8], ptr, [16 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k68, [16 x i8] c"\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2femit_2emathInexact.k31 = internal global <{ [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k69, [8 x i8] c"\01\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k70 }>, align 32
@G_2ecompiler_2femit_2emathInexact.k32 = internal global <{ [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k71, [8 x i8] c"\01\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k72 }>, align 32
@G_2ecompiler_2femit_2emathInexact.k33 = internal global <{ [5 x i8] }> <{ [5 x i8] c"\61\73\69\6E\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k34 = internal global <{ [5 x i8] }> <{ [5 x i8] c"\74\61\6E\68\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k35 = internal global <{ [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k73, [8 x i8] c"\01\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k74 }>, align 32
@G_2ecompiler_2femit_2emathInexact.k36 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\65\78\70" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k37 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\65\72\66\63" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k38 = internal global <{ [8 x i8], ptr, [16 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k75, [16 x i8] c"\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2femit_2emathInexact.k39 = internal global <{ [5 x i8] }> <{ [5 x i8] c"\6C\6F\67\32\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k40 = internal global <{ [5 x i8] }> <{ [5 x i8] c"\63\6F\73\68\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k41 = internal global <{ [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k76, [8 x i8] c"\01\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k77 }>, align 32
@G_2ecompiler_2femit_2emathInexact.k42 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\74\61\6E\68" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k43 = internal global <{ [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k78, [8 x i8] c"\01\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k79 }>, align 32
@G_2ecompiler_2femit_2emathInexact.k44 = internal global <{ [4 x i8] }> <{ [4 x i8] c"\6C\6F\67\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k45 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\63\62\72\74" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k46 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\74\61\6E" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k47 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\6C\6F\67\32" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k48 = internal global <{ [8 x i8], ptr, [16 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k80, [16 x i8] c"\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2femit_2emathInexact.k49 = internal global <{ [4 x i8] }> <{ [4 x i8] c"\74\61\6E\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k50 = internal global <{ [5 x i8] }> <{ [5 x i8] c"\61\74\61\6E\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k51 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\63\6F\73\68" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k52 = internal global <{ [8 x i8], ptr, [16 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k81, [16 x i8] c"\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2femit_2emathInexact.k53 = internal global <{ [5 x i8] }> <{ [5 x i8] c"\65\72\66\63\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k54 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\61\74\61\6E" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k55 = internal global <{ [4 x i8] }> <{ [4 x i8] c"\65\72\66\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k56 = internal global <{ [6 x i8] }> <{ [6 x i8] c"\61\74\61\6E\32\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k57 = internal global <{ [6 x i8] }> <{ [6 x i8] c"\65\78\70\6D\31\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k58 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\68\79\70\6F\74" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k59 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\61\73\69\6E" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k60 = internal global <{ [4 x i8] }> <{ [4 x i8] c"\65\78\70\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k61 = internal global <{ [8 x i8], ptr, [16 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k82, [16 x i8] c"\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2femit_2emathInexact.k62 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\73\69\6E" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k63 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\65\72\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k64 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\6C\6F\67" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k65 = internal global <{ [8 x i8], ptr, [16 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k83, [16 x i8] c"\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2femit_2emathInexact.k66 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\70\6F\77" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k67 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\61\74\61\6E\32" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k68 = internal global <{ [5 x i8] }> <{ [5 x i8] c"\65\78\70\32\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k69 = internal global <{ [5 x i8] }> <{ [5 x i8] c"\73\69\6E\68\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k70 = internal global <{ [8 x i8], ptr, [16 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k84, [16 x i8] c"\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2femit_2emathInexact.k71 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\73\69\6E\68" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k72 = internal global <{ [8 x i8], ptr, [16 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k85, [16 x i8] c"\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2femit_2emathInexact.k73 = internal global <{ [6 x i8] }> <{ [6 x i8] c"\6C\6F\67\31\30\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k74 = internal global <{ [8 x i8], ptr, [16 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k86, [16 x i8] c"\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2femit_2emathInexact.k75 = internal global <{ [4 x i8] }> <{ [4 x i8] c"\70\6F\77\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k76 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\65\78\70\32" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k77 = internal global <{ [8 x i8], ptr, [16 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k87, [16 x i8] c"\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2femit_2emathInexact.k78 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\6C\6F\67\31\30" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k79 = internal global <{ [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k88, [8 x i8] c"\01\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k89 }>, align 32
@G_2ecompiler_2femit_2emathInexact.k80 = internal global <{ [6 x i8] }> <{ [6 x i8] c"\68\79\70\6F\74\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k81 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\63\6F\73" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k82 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\65\78\70\6D\31" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k83 = internal global <{ [4 x i8] }> <{ [4 x i8] c"\73\69\6E\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k84 = internal global <{ [5 x i8] }> <{ [5 x i8] c"\61\63\6F\73\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k85 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\61\63\6F\73" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k86 = internal global <{ [6 x i8] }> <{ [6 x i8] c"\6C\6F\67\31\70\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k87 = internal global <{ [4 x i8] }> <{ [4 x i8] c"\63\6F\73\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k88 = internal global <{ [5 x i8] }> <{ [5 x i8] c"\63\62\72\74\66" }>, align 8
@G_2ecompiler_2femit_2emathInexact.k89 = internal global <{ [8 x i8], ptr, [16 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2emathInexact.k90, [16 x i8] c"\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 32
@G_2ecompiler_2femit_2emathInexact.k90 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\6C\6F\67\31\70" }>, align 8
@G_2ecompiler_2femit_2etbaaElem = constant <{ [120 x i8] }> <{ [120 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\1F\00\00\00\00\00\00\00\51\00\00\00\00\00\00\00\52\00\00\00\00\00\00\00\21\00\00\00\00\00\00\00\22\00\00\00\00\00\00\00\20\00\00\00\00\00\00\00\53\00\00\00\00\00\00\00\54\00\00\00\00\00\00\00\55\00\00\00\00\00\00\00\56\00\00\00\00\00\00\00\57\00\00\00\00\00\00\00\23\00\00\00\00\00\00\00\24\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2femit_2etbaaField = constant <{ [120 x i8] }> <{ [120 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\15\00\00\00\00\00\00\00\3D\00\00\00\00\00\00\00\3E\00\00\00\00\00\00\00\17\00\00\00\00\00\00\00\18\00\00\00\00\00\00\00\16\00\00\00\00\00\00\00\3F\00\00\00\00\00\00\00\40\00\00\00\00\00\00\00\41\00\00\00\00\00\00\00\42\00\00\00\00\00\00\00\43\00\00\00\00\00\00\00\19\00\00\00\00\00\00\00\1A\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2femit_2etbaaName = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k1, [8 x i8] c"\00\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k2, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k3, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k4, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k5, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k6, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k7, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k8, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k9, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k10, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k11, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k12, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k13, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k14, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaName.k15 }>, align 64
@G_2ecompiler_2femit_2etbaaName.k1 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2femit_2etbaaName.k2 = internal constant <{  }> <{  }>, align 8
@G_2ecompiler_2femit_2etbaaName.k3 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\62\6F\6F\6C" }>, align 8
@G_2ecompiler_2femit_2etbaaName.k4 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\69\38" }>, align 8
@G_2ecompiler_2femit_2etbaaName.k5 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\69\31\36" }>, align 8
@G_2ecompiler_2femit_2etbaaName.k6 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\69\6E\74\33\32" }>, align 8
@G_2ecompiler_2femit_2etbaaName.k7 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\69\6E\74\36\34" }>, align 8
@G_2ecompiler_2femit_2etbaaName.k8 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\62\79\74\65" }>, align 8
@G_2ecompiler_2femit_2etbaaName.k9 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\75\31\36" }>, align 8
@G_2ecompiler_2femit_2etbaaName.k10 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\75\33\32" }>, align 8
@G_2ecompiler_2femit_2etbaaName.k11 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\75\36\34" }>, align 8
@G_2ecompiler_2femit_2etbaaName.k12 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\66\31\36" }>, align 8
@G_2ecompiler_2femit_2etbaaName.k13 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\62\66\31\36" }>, align 8
@G_2ecompiler_2femit_2etbaaName.k14 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\66\6C\6F\61\74\33\32" }>, align 8
@G_2ecompiler_2femit_2etbaaName.k15 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\66\6C\6F\61\74\36\34" }>, align 8
@G_2ecompiler_2femit_2etbaaTree = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\3D\07\00\00\00\00\00\00", ptr @G_2ecompiler_2femit_2etbaaTree.k1 }>, align 8
@G_2ecompiler_2femit_2etbaaTree.k1 = internal constant <{ [1853 x i8] }> <{ [1853 x i8] c"\0A\21\32\30\20\3D\20\21\7B\21\22\6F\6C\61\6E\67\22\7D\0A\21\34\39\20\3D\20\21\7B\21\22\73\63\6F\70\65\68\64\72\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\35\30\20\3D\20\21\7B\21\22\63\68\75\6E\6B\68\64\72\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\35\39\20\3D\20\21\7B\21\34\39\2C\20\21\34\39\2C\20\69\36\34\20\30\7D\0A\21\36\30\20\3D\20\21\7B\21\35\30\2C\20\21\35\30\2C\20\69\36\34\20\30\7D\0A\21\31\37\20\3D\20\21\7B\21\22\61\72\72\61\79\64\65\73\63\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\31\38\20\3D\20\21\7B\21\22\63\6C\6F\73\75\72\65\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\34\37\20\3D\20\21\7B\21\22\61\72\72\61\79\64\65\73\63\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\31\39\20\3D\20\21\7B\21\22\72\65\66\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\34\38\20\3D\20\21\7B\21\22\72\65\66\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\32\39\20\3D\20\21\7B\21\31\39\2C\20\21\31\39\2C\20\69\36\34\20\30\7D\0A\21\33\39\20\3D\20\21\7B\21\34\38\2C\20\21\34\38\2C\20\69\36\34\20\30\7D\0A\21\32\37\20\3D\20\21\7B\21\31\37\2C\20\21\31\37\2C\20\69\36\34\20\30\7D\0A\21\32\38\20\3D\20\21\7B\21\31\38\2C\20\21\31\38\2C\20\69\36\34\20\30\7D\0A\21\33\37\20\3D\20\21\7B\21\34\37\2C\20\21\34\37\2C\20\69\36\34\20\30\7D\0A\21\31\31\20\3D\20\21\7B\21\22\62\6F\6F\6C\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\32\31\20\3D\20\21\7B\21\31\31\2C\20\21\31\31\2C\20\69\36\34\20\30\7D\0A\21\34\31\20\3D\20\21\7B\21\22\62\6F\6F\6C\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\33\31\20\3D\20\21\7B\21\34\31\2C\20\21\34\31\2C\20\69\36\34\20\30\7D\0A\21\35\31\20\3D\20\21\7B\21\22\69\38\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\36\31\20\3D\20\21\7B\21\35\31\2C\20\21\35\31\2C\20\69\36\34\20\30\7D\0A\21\39\31\20\3D\20\21\7B\21\22\69\38\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\38\31\20\3D\20\21\7B\21\39\31\2C\20\21\39\31\2C\20\69\36\34\20\30\7D\0A\21\35\32\20\3D\20\21\7B\21\22\69\31\36\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\36\32\20\3D\20\21\7B\21\35\32\2C\20\21\35\32\2C\20\69\36\34\20\30\7D\0A\21\39\32\20\3D\20\21\7B\21\22\69\31\36\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\38\32\20\3D\20\21\7B\21\39\32\2C\20\21\39\32\2C\20\69\36\34\20\30\7D\0A\21\31\33\20\3D\20\21\7B\21\22\69\6E\74\33\32\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\32\33\20\3D\20\21\7B\21\31\33\2C\20\21\31\33\2C\20\69\36\34\20\30\7D\0A\21\34\33\20\3D\20\21\7B\21\22\69\6E\74\33\32\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\33\33\20\3D\20\21\7B\21\34\33\2C\20\21\34\33\2C\20\69\36\34\20\30\7D\0A\21\31\34\20\3D\20\21\7B\21\22\69\6E\74\36\34\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\32\34\20\3D\20\21\7B\21\31\34\2C\20\21\31\34\2C\20\69\36\34\20\30\7D\0A\21\34\34\20\3D\20\21\7B\21\22\69\6E\74\36\34\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\33\34\20\3D\20\21\7B\21\34\34\2C\20\21\34\34\2C\20\69\36\34\20\30\7D\0A\21\31\32\20\3D\20\21\7B\21\22\62\79\74\65\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\32\32\20\3D\20\21\7B\21\31\32\2C\20\21\31\32\2C\20\69\36\34\20\30\7D\0A\21\34\32\20\3D\20\21\7B\21\22\62\79\74\65\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\33\32\20\3D\20\21\7B\21\34\32\2C\20\21\34\32\2C\20\69\36\34\20\30\7D\0A\21\35\33\20\3D\20\21\7B\21\22\75\31\36\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\36\33\20\3D\20\21\7B\21\35\33\2C\20\21\35\33\2C\20\69\36\34\20\30\7D\0A\21\39\33\20\3D\20\21\7B\21\22\75\31\36\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\38\33\20\3D\20\21\7B\21\39\33\2C\20\21\39\33\2C\20\69\36\34\20\30\7D\0A\21\35\34\20\3D\20\21\7B\21\22\75\33\32\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\36\34\20\3D\20\21\7B\21\35\34\2C\20\21\35\34\2C\20\69\36\34\20\30\7D\0A\21\39\34\20\3D\20\21\7B\21\22\75\33\32\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\38\34\20\3D\20\21\7B\21\39\34\2C\20\21\39\34\2C\20\69\36\34\20\30\7D\0A\21\35\35\20\3D\20\21\7B\21\22\75\36\34\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\36\35\20\3D\20\21\7B\21\35\35\2C\20\21\35\35\2C\20\69\36\34\20\30\7D\0A\21\39\35\20\3D\20\21\7B\21\22\75\36\34\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\38\35\20\3D\20\21\7B\21\39\35\2C\20\21\39\35\2C\20\69\36\34\20\30\7D\0A\21\35\36\20\3D\20\21\7B\21\22\66\31\36\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\36\36\20\3D\20\21\7B\21\35\36\2C\20\21\35\36\2C\20\69\36\34\20\30\7D\0A\21\39\36\20\3D\20\21\7B\21\22\66\31\36\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\38\36\20\3D\20\21\7B\21\39\36\2C\20\21\39\36\2C\20\69\36\34\20\30\7D\0A\21\35\37\20\3D\20\21\7B\21\22\62\66\31\36\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\36\37\20\3D\20\21\7B\21\35\37\2C\20\21\35\37\2C\20\69\36\34\20\30\7D\0A\21\39\37\20\3D\20\21\7B\21\22\62\66\31\36\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\38\37\20\3D\20\21\7B\21\39\37\2C\20\21\39\37\2C\20\69\36\34\20\30\7D\0A\21\31\35\20\3D\20\21\7B\21\22\66\6C\6F\61\74\33\32\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\32\35\20\3D\20\21\7B\21\31\35\2C\20\21\31\35\2C\20\69\36\34\20\30\7D\0A\21\34\35\20\3D\20\21\7B\21\22\66\6C\6F\61\74\33\32\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\33\35\20\3D\20\21\7B\21\34\35\2C\20\21\34\35\2C\20\69\36\34\20\30\7D\0A\21\31\36\20\3D\20\21\7B\21\22\66\6C\6F\61\74\36\34\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\32\36\20\3D\20\21\7B\21\31\36\2C\20\21\31\36\2C\20\69\36\34\20\30\7D\0A\21\34\36\20\3D\20\21\7B\21\22\66\6C\6F\61\74\36\34\5B\5D\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\33\36\20\3D\20\21\7B\21\34\36\2C\20\21\34\36\2C\20\69\36\34\20\30\7D\0A\0A" }>, align 64
define dso_local void @compiler_2femit_2ePartSize_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 1048576, ptr @G_2ecompiler_2femit_2ePartSize, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2eblockName(ptr %v0, i32 %a0) #0 {
entry:
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 2, ptr @.d0 }, 1
  %t3 = extractvalue { i64, ptr } { i64 2, ptr @.d0 }, 0
  %t5 = sext i32 %a0 to i64
  %t6 = call i64 @__olang_fmt_i64(ptr null, i64 %t5)
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  %t10 = call i64 @__olang_fmt_i64(ptr %t9, i64 %t5)
  %t11 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t8, 1
  store { i64, ptr } %t12, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecapVars(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i32
  %l36 = alloca { i64, ptr }
  %l52 = alloca ptr
  %l54 = alloca ptr
  %l60 = alloca ptr
  %l63 = alloca i32
  %l64 = alloca { i64, ptr }
  %l68 = alloca i1
  %l71 = alloca { i64, ptr }
  %l73 = alloca i1
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load { i64, [1 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [1 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  br label %bb29
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/emit:Emitter", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/lower:Lowerer", ptr %t13, i32 0, i32 1
  %t16 = load i32, ptr %l3, !tbaa !23
  %t18 = sext i32 %t16 to i64
  %t21 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t15, i64 %t18)
  store ptr %t21, ptr %l20
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l20, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Body", ptr %t22, i32 0, i32 6
  store ptr %t24, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t27 = load i64, ptr %l5, !tbaa !24
  %t30 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2eRu_Hba7f56c70b20c8f60a4a5345f2cfd0c9(ptr %v0, ptr %t26, i64 %t27)
  %t31 = extractvalue { i32, { i64, ptr } } %t30, 1
  %t32 = extractvalue { i32, { i64, ptr } } %t30, 0
  store i32 %t32, ptr %l27
  %t33 = icmp ne i32 %t32, 0
  br i1 %t33, label %bb7, label %ok.34
ok.34:
  store { i64, ptr } %t31, ptr %l26
  br label %bb6
bb6:
  %t35 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t35, ptr %l23, !tbaa !27
  br label %bb11
bb7:
  %t36 = load i32, ptr %l27, !tbaa !23
  %t37 = ashr i32 %t36, 16
  %t39 = icmp eq i32 %t37, 1
  br i1 %t39, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_9506350913203bfc_41d6488afcc367c0)
  unreachable
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb28
bb11:
  %t41 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t41, ptr %l6, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  store i64 %t44, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t46 = load i64, ptr %l8, !tbaa !24
  %t47 = load i64, ptr %l7, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s4)
  br label %bb26
bb14:
  br label %bb15
bb15:
  %t54 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t54, ptr %l36, !tbaa !27
  %t55 = load i64, ptr %l8, !tbaa !24
  %t57 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr { i64, [1 x i64] }, ptr %t58, i64 %t55
  %t60 = load { i64, [1 x i64] }, ptr %t59
  %t64 = extractvalue { i64, [1 x i64] } %t60, 0
  %t65 = icmp eq i64 %t64, 4
  br i1 %t65, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t67 = load i64, ptr %l2, !tbaa !24
  %t69 = add i64 %t67, 1
  store i64 %t69, ptr %l2, !tbaa !24
  br label %bb24
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_2a2725b2da5e1bad_47abef39162bd051)
  unreachable
bb24:
  call void @__olang_scope_close(ptr %s4)
  br label %bb25
bb25:
  %t71 = load i64, ptr %l8, !tbaa !24
  %t73 = add i64 %t71, 1
  store i64 %t73, ptr %l8, !tbaa !24
  br label %bb12
bb26:
  %t75 = load i64, ptr %l5, !tbaa !24
  %t76 = load i64, ptr %l7, !tbaa !24
  %t79 = add i64 %t75, %t76
  store i64 %t79, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb27
bb27:
  br label %bb5
bb28:
  br label %bb48
bb29:
  %t81 = load { i64, [1 x i64] }, ptr %l1
  %t83 = extractvalue { i64, [1 x i64] } %t81, 0
  %t84 = icmp eq i64 %t83, 1
  br i1 %t84, label %bb30, label %bb31
bb30:
  %t86 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t87 = getelementptr { i32 }, ptr %t86, i32 0, i32 0
  %t88 = load i32, ptr %t87
  store i32 %t88, ptr %l10, !tbaa !23
  br label %bb32
bb31:
  br label %bb43
bb32:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/emit:Emitter", ptr %t90, i32 0, i32 3
  %t93 = load ptr, ptr %t92, !tbaa !29
  store ptr %t93, ptr %l52, !tbaa !29
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/emit:Emitter", ptr %t94, i32 0, i32 3
  %t97 = load ptr, ptr %t96, !tbaa !29
  store ptr %t97, ptr %l54, !tbaa !29
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/emit:Emitter", ptr %t98, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t103 = getelementptr %"compiler/lower:Lowerer", ptr %t101, i32 0, i32 1
  %t104 = load i32, ptr %l10, !tbaa !23
  %t106 = sext i32 %t104 to i64
  %t109 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t103, i64 %t106)
  store ptr %t109, ptr %l60
  br label %bb33
bb33:
  %t110 = load ptr, ptr %l60, !tbaa !29
  %t112 = getelementptr %"compiler/typed:Body", ptr %t110, i32 0, i32 2
  %t113 = load i32, ptr %t112, !tbaa !23
  %t114 = load ptr, ptr %l54, !tbaa !29
  %t116 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t114, i32 %t113)
  store i32 %t116, ptr %l63
  br label %bb34
bb34:
  %t117 = load ptr, ptr %l52, !tbaa !29
  %t118 = load i32, ptr %l63, !tbaa !23
  %t119 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t117, i32 %t118)
  store { i64, ptr } %t119, ptr %l64
  br label %bb35
bb35:
  %t120 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t120, ptr %l11, !tbaa !27
  %t121 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t121, 0
  %t125 = icmp sgt i64 %t123, 0
  br i1 %t125, label %bb36, label %bb37
bb36:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/emit:Emitter", ptr %t127, i32 0, i32 3
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t131 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t131, ptr %l71, !tbaa !27
  %t132 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr i32, ptr %t133, i64 0
  %t135 = load i32, ptr %t134, !tbaa !33
  %t138 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t130, i32 %t135)
  store i1 %t138, ptr %l73
  br label %bb38
bb37:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb39
bb38:
  %t139 = load i1, ptr %l73, !tbaa !21
  store i1 %t139, ptr %l68, !tbaa !21
  br label %bb39
bb39:
  %t140 = load i1, ptr %l68, !tbaa !21
  br i1 %t140, label %bb40, label %bb41
bb40:
  store i64 1, ptr %l2, !tbaa !24
  br label %bb42
bb41:
  br label %bb42
bb42:
  br label %bb48
bb43:
  br i1 true, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_98184d77b87c9296_c4a7a562026735ba)
  unreachable
bb48:
  %t141 = load i64, ptr %l2, !tbaa !24
  store i64 %t141, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgBytes(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l1, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/emit:Emitter", ptr %t2, i32 0, i32 3
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t7 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t5, { i64, ptr } { i64 2, ptr @.d1 })
  store i32 %t7, ptr %l4
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t9 = load i32, ptr %l4, !tbaa !23
  %t10 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgType(ptr %v0, ptr %t8, i32 %t9)
  store i64 %t10, ptr %l5
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t11 = load i64, ptr %l5, !tbaa !24
  store i64 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l1 = alloca i64
  %s0 = alloca %olang.scope
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t2 = load i64, ptr %l1, !tbaa !24
  %t3 = extractvalue { i64, ptr } { i64 1, ptr @.d2 }, 1
  %t4 = extractvalue { i64, ptr } { i64 1, ptr @.d2 }, 0
  %t6 = call i64 @__olang_fmt_i64(ptr null, i64 %t2)
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  %t10 = call i64 @__olang_fmt_i64(ptr %t9, i64 %t2)
  %t11 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t8, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t15 = extractvalue { i64, ptr } %t12, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  %t20 = load i64, ptr @G_2ecompiler_2femit_2eHomeShared, !tbaa !24
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = extractvalue { i64, ptr } { i64 1, ptr @.d3 }, 1
  %t24 = extractvalue { i64, ptr } { i64 1, ptr @.d3 }, 0
  %t26 = call i64 @__olang_fmt_i64(ptr null, i64 %t21)
  %t27 = add i64 %t24, %t26
  %t28 = extractvalue { i64, ptr } { i64 3, ptr @.d4 }, 1
  %t29 = extractvalue { i64, ptr } { i64 3, ptr @.d4 }, 0
  %t30 = add i64 %t27, %t29
  %t32 = extractvalue { i64, ptr } %a2, 1
  %t33 = extractvalue { i64, ptr } %a2, 0
  %t34 = add i64 %t30, %t33
  %t35 = extractvalue { i64, ptr } { i64 1, ptr @.d5 }, 1
  %t36 = extractvalue { i64, ptr } { i64 1, ptr @.d5 }, 0
  %t37 = add i64 %t34, %t36
  %t38 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t37)
  call void @olang_textcopy(ptr %t38, ptr %t23, i64 %t24)
  %t39 = getelementptr i8, ptr %t38, i64 %t24
  %t40 = call i64 @__olang_fmt_i64(ptr %t39, i64 %t21)
  %t41 = getelementptr i8, ptr %t39, i64 %t26
  call void @olang_textcopy(ptr %t41, ptr %t28, i64 %t29)
  %t42 = getelementptr i8, ptr %t41, i64 %t29
  call void @olang_textcopy(ptr %t42, ptr %t32, i64 %t33)
  %t43 = getelementptr i8, ptr %t42, i64 %t33
  call void @olang_textcopy(ptr %t43, ptr %t35, i64 %t36)
  %t44 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t38, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = extractvalue { i64, ptr } %t45, 1
  %t49 = mul i64 %t47, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t49)
  call void @llvm.memcpy.p0.p0.i64(ptr %t50, ptr %t48, i64 %t49, i1 false)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %a0, { i64, ptr } %t19, i64 %t20, { i64, ptr } %t52, { i64, ptr } { i64 0, ptr @.d6 })
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t4 = extractvalue { i64, ptr } { i64 8, ptr @.d7 }, 1
  %t5 = extractvalue { i64, ptr } { i64 8, ptr @.d7 }, 0
  %t7 = extractvalue { i64, ptr } %a2, 1
  %t8 = extractvalue { i64, ptr } %a2, 0
  %t9 = add i64 %t5, %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t9)
  call void @olang_textcopy(ptr %t10, ptr %t4, i64 %t5)
  %t11 = getelementptr i8, ptr %t10, i64 %t5
  call void @olang_textcopy(ptr %t11, ptr %t7, i64 %t8)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t10, 1
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t16 = extractvalue { i64, ptr } %t13, 1
  %t17 = mul i64 %t15, 1
  %t18 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t16, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %v1, ptr %s0, ptr %a0, { i64, ptr } %a1, { i64, ptr } %t20)
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclared(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l6 = alloca { i64, ptr }
  %l10 = alloca i1
  %l13 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca { i64, [1 x i64] }
  %l16 = alloca i32
  %l17 = alloca { i64, ptr }
  %l21 = alloca i64
  %l24 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load { i64, [1 x i64] }, ptr %l1
  %t5 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s0, ptr %t1, { i64, [1 x i64] } %t2)
  store { i64, ptr } %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/emit:Emitter", ptr %t7, i32 0, i32 18
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t13 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %s0, ptr %t9, { i64, ptr } %t10)
  store i1 %t13, ptr %l10
  br label %bb2
bb2:
  %t14 = load i1, ptr %l10, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load { i64, [1 x i64] }, ptr %l1
  %t19 = call i32 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecodeType(ptr %v0, ptr %t15, { i64, [1 x i64] } %t16)
  store i32 %t19, ptr %l13
  br label %bb6
bb6:
  %t20 = load i32, ptr %l13, !tbaa !23
  store i32 %t20, ptr %l3, !tbaa !23
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l14, !tbaa !29
  %t22 = load { i64, [1 x i64] }, ptr %l1
  store { i64, [1 x i64] } %t22, ptr %l15
  %t23 = load i32, ptr %l3, !tbaa !23
  store i32 %t23, ptr %l16, !tbaa !23
  %t24 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t24, ptr %l17, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load { i64, [1 x i64] }, ptr %l1
  %t27 = load i32, ptr %l3, !tbaa !23
  %t31 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2epassedOf(ptr %v0, ptr %t25, { i64, [1 x i64] } %t26, i32 %t27)
  store i64 %t31, ptr %l21
  br label %bb7
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load { i64, [1 x i64] }, ptr %l1
  %t36 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehasEnv(ptr %v0, ptr %t32, { i64, [1 x i64] } %t33)
  store i1 %t36, ptr %l24
  br label %bb8
bb8:
  %t37 = load ptr, ptr %l14, !tbaa !29
  %t38 = load { i64, [1 x i64] }, ptr %l15
  %t39 = load i32, ptr %l16, !tbaa !23
  %t40 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t41 = load i64, ptr %l21, !tbaa !24
  %t42 = load i1, ptr %l24, !tbaa !21
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efnItem(ptr %v0, ptr %s0, ptr %s0, ptr %t37, { i64, [1 x i64] } %t38, i32 %t39, { i64, ptr } %t40, i64 %t41, i1 %t42, { i64, ptr } { i64 0, ptr @.d8 })
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eemitAll(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca { i64, [2 x i64] }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca { i64, [1 x i64] }
  %l28 = alloca { i64, [2 x i64] }
  %l29 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l42 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca ptr
  %l57 = alloca i64
  %l58 = alloca { i64, ptr }
  %l59 = alloca i64
  %l60 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i32
  %l64 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca i64
  %l69 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l79 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l81 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l83 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l87 = alloca i32
  %l96 = alloca { i64, ptr }
  %l102 = alloca i1
  %l116 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l120 = alloca i64
  %l124 = alloca i64
  %l127 = alloca i64
  %l149 = alloca ptr
  %l156 = alloca i1
  %l161 = alloca ptr
  %l173 = alloca i64
  %l176 = alloca i64
  %l181 = alloca i1
  %l182 = alloca ptr
  %l185 = alloca ptr
  %l188 = alloca { i64, ptr }
  %l189 = alloca i1
  %l196 = alloca i64
  %l200 = alloca i64
  %l203 = alloca i64
  %l229 = alloca ptr
  %l244 = alloca ptr
  %l250 = alloca i64
  %l254 = alloca i1
  %l265 = alloca i1
  %l273 = alloca { i64, ptr }
  %l276 = alloca { i64, ptr }
  %l277 = alloca i32
  %l286 = alloca { i64, ptr }
  %l301 = alloca { i64, ptr }
  %l304 = alloca { i64, ptr }
  %l305 = alloca i32
  %l314 = alloca { i64, ptr }
  %l334 = alloca i64
  %l337 = alloca i64
  %l343 = alloca { i64, [1 x i64] }
  %l353 = alloca i64
  %l357 = alloca i64
  %l360 = alloca i64
  %l378 = alloca ptr
  %l382 = alloca { i64, [1 x i64] }
  %l386 = alloca i32
  %l391 = alloca i64
  %l395 = alloca i64
  %l398 = alloca i64
  %l416 = alloca ptr
  %l420 = alloca i32
  %l424 = alloca i32
  %l429 = alloca { i64, ptr }
  %l432 = alloca { i64, ptr }
  %l433 = alloca i32
  %l442 = alloca { i64, ptr }
  %l463 = alloca i64
  %l466 = alloca i64
  %l472 = alloca i32
  %l478 = alloca { i64, ptr }
  %l482 = alloca { i64, ptr }
  %l490 = alloca { i64, ptr }
  %l500 = alloca { i64, ptr }
  %l501 = alloca { i64, ptr }
  %l504 = alloca i64
  %l505 = alloca i64
  %l513 = alloca i1
  %l515 = alloca ptr
  %l518 = alloca { i64, ptr }
  %l521 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s42 = alloca %olang.scope
  %s45 = alloca %olang.scope
  %s46 = alloca %olang.scope
  %s53 = alloca %olang.scope
  %s54 = alloca %olang.scope
  %s55 = alloca %olang.scope
  %t85 = alloca { i64, [1 x i64] }, align 8
  %t322 = alloca { i64, [1 x i64] }, align 8
  %t538 = alloca { i64, [1 x i64] }, align 8
  %t561 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 40
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/emit:Emitter", ptr %t6, i32 0, i32 40
  store i1 true, ptr %t8, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntimeItems(ptr %v0, ptr %t9)
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eindex(ptr %v0, ptr %t11)
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/emit:Emitter", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  store ptr %t16, ptr %l1, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2ereusing(ptr %v0, ptr %s0, ptr %t18)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t20, ptr %l79
  br label %bb6
bb6:
  %t21 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l79
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, ptr %l2
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2einitOrder(ptr %v0, ptr %s0, ptr %t22)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l81
  br label %bb7
bb7:
  %t25 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l81
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l3
  store ptr %l3, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t27 = load ptr, ptr %l4, !tbaa !29
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s0, ptr %t27, i64 %t28)
  %t32 = extractvalue { i32, { i64, ptr } } %t31, 1
  %t33 = extractvalue { i32, { i64, ptr } } %t31, 0
  store i32 %t33, ptr %l87
  %t34 = icmp ne i32 %t33, 0
  br i1 %t34, label %bb10, label %ok.35
ok.35:
  store { i64, ptr } %t32, ptr %l86
  br label %bb9
bb9:
  %t36 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t36, ptr %l83, !tbaa !27
  br label %bb14
bb10:
  %t37 = load i32, ptr %l87, !tbaa !23
  %t38 = ashr i32 %t37, 16
  %t40 = icmp eq i32 %t38, 1
  br i1 %t40, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_ca7da4b07cdf4cec_48bb1648ef269dd0)
  unreachable
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb29
bb14:
  %t42 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t42, ptr %l6, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  store i64 %t45, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t47 = load i64, ptr %l8, !tbaa !24
  %t48 = load i64, ptr %l7, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s4)
  br label %bb27
bb17:
  br label %bb18
bb18:
  %t55 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t55, ptr %l96, !tbaa !27
  %t56 = load i64, ptr %l8, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i64, ptr %t59, i64 %t56
  %t61 = load i64, ptr %t60, !tbaa !34
  store i64 %t61, ptr %l9, !tbaa !24
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/emit:Emitter", ptr %t63, i32 0, i32 37
  %t66 = load i1, ptr %t65, !tbaa !21
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l102, !tbaa !21
  br label %bb21
bb20:
  %t70 = load i64, ptr %l9, !tbaa !24
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr %"compiler/generic:Program", ptr %t71, i32 0, i32 0
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/load:Loader", ptr %t74, i32 0, i32 7
  %t77 = load i64, ptr %t76, !tbaa !24
  %t80 = icmp eq i64 %t70, %t77
  store i1 %t80, ptr %l102, !tbaa !21
  br label %bb21
bb21:
  %t82 = load i1, ptr %l102, !tbaa !21
  br i1 %t82, label %bb22, label %bb23
bb22:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i64, ptr %l9, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t85
  %t86 = getelementptr { i64, [1 x i64] }, ptr %t85, i32 0, i32 0
  store i64 3, ptr %t86
  %t88 = insertvalue { i64 } undef, i64 %t84, 0
  %t89 = getelementptr { i64, [1 x i64] }, ptr %t85, i32 0, i32 1
  store { i64 } %t88, ptr %t89
  %t90 = load { i64, [1 x i64] }, ptr %t85
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewant(ptr %v0, ptr %t83, { i64, [1 x i64] } %t90)
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s4)
  br label %bb26
bb26:
  %t93 = load i64, ptr %l8, !tbaa !24
  %t95 = add i64 %t93, 1
  store i64 %t95, ptr %l8, !tbaa !24
  br label %bb15
bb27:
  %t97 = load i64, ptr %l5, !tbaa !24
  %t98 = load i64, ptr %l7, !tbaa !24
  %t101 = add i64 %t97, %t98
  store i64 %t101, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb28
bb28:
  br label %bb8
bb29:
  %t103 = load ptr, ptr @__olang_prog_scope
  %t104 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t103)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t104, ptr %l116
  br label %bb30
bb30:
  %t105 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l116
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t105, ptr %l10
  store i64 -1, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/emit:Emitter", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/lower:Lowerer", ptr %t109, i32 0, i32 1
  %t113 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %t111)
  store i64 %t113, ptr %l120
  br label %bb31
bb31:
  %t114 = load i64, ptr %l120, !tbaa !24
  store i64 %t114, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t115 = load i64, ptr %l13, !tbaa !24
  %t116 = load i64, ptr %l12, !tbaa !24
  %t119 = icmp sgt i64 %t115, %t116
  br i1 %t119, label %bb32, label %bb33
bb32:
  %t121 = load i64, ptr %l14, !tbaa !24
  %t123 = icmp sgt i64 %t121, 0
  br i1 %t123, label %bb34, label %bb35
bb33:
  store i64 0, ptr %l124, !tbaa !24
  br label %bb37
bb34:
  %t125 = load i64, ptr %l13, !tbaa !24
  %t126 = load i64, ptr %l12, !tbaa !24
  %t129 = sub i64 %t125, %t126
  %t130 = load i64, ptr %l14, !tbaa !24
  %t133 = add i64 %t129, %t130
  %t135 = sub i64 %t133, 1
  %t136 = load i64, ptr %l14, !tbaa !24
  %t139 = sdiv i64 %t135, %t136
  store i64 %t139, ptr %l127, !tbaa !24
  br label %bb36
bb35:
  store i64 0, ptr %l127, !tbaa !24
  br label %bb36
bb36:
  %t141 = load i64, ptr %l127, !tbaa !24
  store i64 %t141, ptr %l124, !tbaa !24
  br label %bb37
bb37:
  %t142 = load i64, ptr %l124, !tbaa !24
  store i64 %t142, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s8
  %t143 = load i64, ptr %l16, !tbaa !24
  %t144 = load i64, ptr %l15, !tbaa !24
  %t147 = icmp slt i64 %t143, %t144
  %t149 = xor i1 %t147, true
  br i1 %t149, label %bb39, label %bb40
bb39:
  call void @__olang_scope_close(ptr %s8)
  br label %bb76
bb40:
  br label %bb41
bb41:
  %t151 = load i64, ptr %l12, !tbaa !24
  %t152 = load i64, ptr %l16, !tbaa !24
  %t153 = load i64, ptr %l14, !tbaa !24
  %t156 = mul i64 %t152, %t153
  %t159 = add i64 %t151, %t156
  store i64 %t159, ptr %l17, !tbaa !24
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/emit:Emitter", ptr %t161, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !29
  %t166 = getelementptr %"compiler/lower:Lowerer", ptr %t164, i32 0, i32 1
  %t167 = load i64, ptr %l17, !tbaa !24
  %t170 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t166, i64 %t167)
  store ptr %t170, ptr %l149
  br label %bb42
bb42:
  %t171 = load ptr, ptr %l149, !tbaa !29
  %t173 = getelementptr %"compiler/typed:Body", ptr %t171, i32 0, i32 1
  %t174 = load { i64, [2 x i64] }, ptr %t173
  store { i64, [2 x i64] } %t174, ptr %l18
  %t176 = load { i64, [2 x i64] }, ptr %l18
  %t178 = extractvalue { i64, [2 x i64] } %t176, 0
  %t179 = icmp eq i64 %t178, 5
  br i1 %t179, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb54
bb45:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/emit:Emitter", ptr %t181, i32 0, i32 4
  %t184 = load i1, ptr %t183, !tbaa !21
  br i1 %t184, label %bb46, label %bb47
bb46:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = getelementptr %"compiler/emit:Emitter", ptr %t186, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !29
  %t191 = getelementptr %"compiler/lower:Lowerer", ptr %t189, i32 0, i32 1
  %t192 = load i64, ptr %l17, !tbaa !24
  %t195 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t191, i64 %t192)
  store ptr %t195, ptr %l161
  br label %bb48
bb47:
  store i1 false, ptr %l156, !tbaa !21
  br label %bb49
bb48:
  %t196 = load ptr, ptr %l161, !tbaa !29
  %t198 = getelementptr %"compiler/typed:Body", ptr %t196, i32 0, i32 11
  %t199 = load ptr, ptr %t198, !tbaa !29
  %t201 = icmp eq ptr %t199, null
  %t203 = xor i1 %t201, true
  store i1 %t203, ptr %l156, !tbaa !21
  br label %bb49
bb49:
  %t205 = load i1, ptr %l156, !tbaa !21
  br i1 %t205, label %bb50, label %bb51
bb50:
  %t206 = load i64, ptr %l17, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l10, i64 %t206)
  br label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb53
bb53:
  br label %bb74
bb54:
  %t209 = load { i64, [2 x i64] }, ptr %l18
  %t211 = extractvalue { i64, [2 x i64] } %t209, 0
  %t212 = icmp eq i64 %t211, 0
  br i1 %t212, label %bb55, label %bb56
bb55:
  %t214 = getelementptr { i64, [2 x i64] }, ptr %l18, i32 0, i32 1
  %t215 = getelementptr { i64 }, ptr %t214, i32 0, i32 0
  %t216 = load i64, ptr %t215
  store i64 %t216, ptr %l19, !tbaa !24
  br label %bb57
bb56:
  br label %bb69
bb57:
  store %olang.scope zeroinitializer, ptr %s11
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t219 = load i64, ptr %l19, !tbaa !24
  %t222 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t218, i64 %t219)
  store i64 %t222, ptr %l173
  br label %bb58
bb58:
  %t223 = load i64, ptr %l173, !tbaa !24
  store i64 %t223, ptr %l20, !tbaa !24
  %t224 = load ptr, ptr %l1, !tbaa !29
  %t225 = load i64, ptr %l20, !tbaa !24
  %t228 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t224, i64 %t225)
  store i64 %t228, ptr %l176
  br label %bb59
bb59:
  %t229 = load ptr, ptr %l1, !tbaa !29
  %t231 = getelementptr %"compiler/generic:Program", ptr %t229, i32 0, i32 0
  %t232 = load ptr, ptr %t231, !tbaa !29
  %t234 = getelementptr %"compiler/load:Loader", ptr %t232, i32 0, i32 7
  %t235 = load i64, ptr %t234, !tbaa !24
  %t236 = load i64, ptr %l176, !tbaa !24
  %t238 = icmp eq i64 %t236, %t235
  br i1 %t238, label %bb60, label %bb61
bb60:
  %t240 = load ptr, ptr %l0, !tbaa !29
  store ptr %t240, ptr %l182, !tbaa !29
  %t241 = load ptr, ptr %l1, !tbaa !29
  %t242 = load i64, ptr %l20, !tbaa !24
  %t245 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t241, i64 %t242)
  store ptr %t245, ptr %l185
  br label %bb62
bb61:
  store i1 false, ptr %l181, !tbaa !21
  br label %bb65
bb62:
  %t246 = load ptr, ptr %l185, !tbaa !29
  %t248 = getelementptr %"compiler/ast:Func", ptr %t246, i32 0, i32 2
  %t249 = load i32, ptr %t248, !tbaa !23
  %t250 = load ptr, ptr %l182, !tbaa !29
  %t252 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %t250, i32 %t249)
  store { i64, ptr } %t252, ptr %l188
  br label %bb63
bb63:
  %t253 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t254 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s11, { i64, ptr } %t253, { i64, ptr } { i64 4, ptr @.d9 })
  store i1 %t254, ptr %l189
  br label %bb64
bb64:
  %t255 = load i1, ptr %l189, !tbaa !21
  store i1 %t255, ptr %l181, !tbaa !21
  br label %bb65
bb65:
  %t256 = load i1, ptr %l181, !tbaa !21
  br i1 %t256, label %bb66, label %bb67
bb66:
  %t257 = load i64, ptr %l17, !tbaa !24
  store i64 %t257, ptr %l11, !tbaa !24
  br label %bb68
bb67:
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s11)
  br label %bb74
bb69:
  br i1 true, label %bb70, label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb74
bb73:
  call void @__olang_check_failed(ptr @olang_loc_3d03f0fa145d919d_fe5358f320913361)
  unreachable
bb74:
  call void @__olang_scope_close(ptr %s8)
  br label %bb75
bb75:
  %t259 = load i64, ptr %l16, !tbaa !24
  %t261 = add i64 %t259, 1
  store i64 %t261, ptr %l16, !tbaa !24
  br label %bb38
bb76:
  store i64 0, ptr %l21, !tbaa !24
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = getelementptr %"compiler/emit:Emitter", ptr %t263, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !29
  %t268 = getelementptr %"compiler/lower:Lowerer", ptr %t266, i32 0, i32 1
  %t270 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %t268)
  store i64 %t270, ptr %l196
  br label %bb77
bb77:
  %t271 = load i64, ptr %l196, !tbaa !24
  store i64 %t271, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t272 = load i64, ptr %l22, !tbaa !24
  %t273 = load i64, ptr %l21, !tbaa !24
  %t276 = icmp sgt i64 %t272, %t273
  br i1 %t276, label %bb78, label %bb79
bb78:
  %t278 = load i64, ptr %l23, !tbaa !24
  %t280 = icmp sgt i64 %t278, 0
  br i1 %t280, label %bb80, label %bb81
bb79:
  store i64 0, ptr %l200, !tbaa !24
  br label %bb83
bb80:
  %t282 = load i64, ptr %l22, !tbaa !24
  %t283 = load i64, ptr %l21, !tbaa !24
  %t286 = sub i64 %t282, %t283
  %t287 = load i64, ptr %l23, !tbaa !24
  %t290 = add i64 %t286, %t287
  %t292 = sub i64 %t290, 1
  %t293 = load i64, ptr %l23, !tbaa !24
  %t296 = sdiv i64 %t292, %t293
  store i64 %t296, ptr %l203, !tbaa !24
  br label %bb82
bb81:
  store i64 0, ptr %l203, !tbaa !24
  br label %bb82
bb82:
  %t298 = load i64, ptr %l203, !tbaa !24
  store i64 %t298, ptr %l200, !tbaa !24
  br label %bb83
bb83:
  %t299 = load i64, ptr %l200, !tbaa !24
  store i64 %t299, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb84
bb84:
  store %olang.scope zeroinitializer, ptr %s16
  %t300 = load i64, ptr %l25, !tbaa !24
  %t301 = load i64, ptr %l24, !tbaa !24
  %t304 = icmp slt i64 %t300, %t301
  %t306 = xor i1 %t304, true
  br i1 %t306, label %bb85, label %bb86
bb85:
  call void @__olang_scope_close(ptr %s16)
  br label %bb122
bb86:
  br label %bb87
bb87:
  %t308 = load i64, ptr %l21, !tbaa !24
  %t309 = load i64, ptr %l25, !tbaa !24
  %t310 = load i64, ptr %l23, !tbaa !24
  %t313 = mul i64 %t309, %t310
  %t316 = add i64 %t308, %t313
  store i64 %t316, ptr %l26, !tbaa !24
  %t318 = load i64, ptr %l26, !tbaa !24
  %t320 = trunc i64 %t318 to i32
  store { i64, [1 x i64] } zeroinitializer, ptr %t322
  %t323 = getelementptr { i64, [1 x i64] }, ptr %t322, i32 0, i32 0
  store i64 0, ptr %t323
  %t325 = insertvalue { i32 } undef, i32 %t320, 0
  %t326 = getelementptr { i64, [1 x i64] }, ptr %t322, i32 0, i32 1
  store { i32 } %t325, ptr %t326
  %t327 = load { i64, [1 x i64] }, ptr %t322
  store { i64, [1 x i64] } %t327, ptr %l27
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t331 = getelementptr %"compiler/emit:Emitter", ptr %t329, i32 0, i32 1
  %t332 = load ptr, ptr %t331, !tbaa !29
  %t334 = getelementptr %"compiler/lower:Lowerer", ptr %t332, i32 0, i32 1
  %t335 = load i64, ptr %l26, !tbaa !24
  %t338 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t334, i64 %t335)
  store ptr %t338, ptr %l229
  br label %bb88
bb88:
  %t339 = load ptr, ptr %l229, !tbaa !29
  %t341 = getelementptr %"compiler/typed:Body", ptr %t339, i32 0, i32 1
  %t342 = load { i64, [2 x i64] }, ptr %t341
  store { i64, [2 x i64] } %t342, ptr %l28
  %t344 = load { i64, [2 x i64] }, ptr %l28
  %t346 = extractvalue { i64, [2 x i64] } %t344, 0
  %t347 = icmp eq i64 %t346, 0
  br i1 %t347, label %bb89, label %bb90
bb89:
  br label %bb97
bb90:
  %t349 = load { i64, [2 x i64] }, ptr %l28
  %t351 = extractvalue { i64, [2 x i64] } %t349, 0
  %t352 = icmp eq i64 %t351, 1
  br i1 %t352, label %bb91, label %bb92
bb91:
  br label %bb97
bb92:
  %t354 = load { i64, [2 x i64] }, ptr %l28
  %t356 = extractvalue { i64, [2 x i64] } %t354, 0
  %t357 = icmp eq i64 %t356, 3
  br i1 %t357, label %bb93, label %bb94
bb93:
  br label %bb97
bb94:
  %t359 = load { i64, [2 x i64] }, ptr %l28
  %t361 = extractvalue { i64, [2 x i64] } %t359, 0
  %t362 = icmp eq i64 %t361, 6
  br i1 %t362, label %bb95, label %bb96
bb95:
  br label %bb97
bb96:
  br label %bb115
bb97:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t366 = getelementptr %"compiler/emit:Emitter", ptr %t364, i32 0, i32 1
  %t367 = load ptr, ptr %t366, !tbaa !29
  %t369 = getelementptr %"compiler/lower:Lowerer", ptr %t367, i32 0, i32 1
  %t370 = load i64, ptr %l26, !tbaa !24
  %t373 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t369, i64 %t370)
  store ptr %t373, ptr %l244
  br label %bb98
bb98:
  %t374 = load ptr, ptr %l244, !tbaa !29
  %t376 = getelementptr %"compiler/typed:Body", ptr %t374, i32 0, i32 11
  %t377 = load ptr, ptr %t376, !tbaa !29
  %t379 = icmp eq ptr %t377, null
  br i1 %t379, label %bb99, label %bb100
bb99:
  call void @__olang_scope_close(ptr %s16)
  br label %bb121
bb100:
  br label %bb101
bb101:
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t382 = load { i64, [1 x i64] }, ptr %l27
  %t385 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehomeOf(ptr %v0, ptr %t381, { i64, [1 x i64] } %t382)
  store i64 %t385, ptr %l250
  br label %bb102
bb102:
  %t386 = load i64, ptr %l250, !tbaa !24
  store i64 %t386, ptr %l29, !tbaa !24
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t389 = getelementptr %"compiler/emit:Emitter", ptr %t387, i32 0, i32 60
  %t390 = load i64, ptr %l29, !tbaa !24
  %t393 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t389, i64 %t390)
  store i1 %t393, ptr %l254
  br label %bb103
bb103:
  %t394 = load i1, ptr %l254, !tbaa !21
  br i1 %t394, label %bb104, label %bb105
bb104:
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t396 = load { i64, [1 x i64] }, ptr %l27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclared(ptr %v0, ptr %t395, { i64, [1 x i64] } %t396)
  br label %bb106
bb105:
  %t399 = load i64, ptr %l29, !tbaa !24
  %t400 = load ptr, ptr %l1, !tbaa !29
  %t402 = getelementptr %"compiler/generic:Program", ptr %t400, i32 0, i32 0
  %t403 = load ptr, ptr %t402, !tbaa !29
  %t405 = getelementptr %"compiler/load:Loader", ptr %t403, i32 0, i32 7
  %t406 = load i64, ptr %t405, !tbaa !24
  %t409 = icmp eq i64 %t399, %t406
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t412 = getelementptr %"compiler/emit:Emitter", ptr %t410, i32 0, i32 37
  %t413 = load i1, ptr %t412, !tbaa !21
  %t416 = icmp eq i1 %t409, %t413
  br i1 %t416, label %bb107, label %bb108
bb106:
  br label %bb114
bb107:
  %t418 = load i64, ptr %l29, !tbaa !24
  %t420 = icmp sge i64 %t418, 0
  store i1 %t420, ptr %l265, !tbaa !21
  br label %bb109
bb108:
  store i1 false, ptr %l265, !tbaa !21
  br label %bb109
bb109:
  %t422 = load i1, ptr %l265, !tbaa !21
  br i1 %t422, label %bb110, label %bb111
bb110:
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t424 = load { i64, [1 x i64] }, ptr %l27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewant(ptr %v0, ptr %t423, { i64, [1 x i64] } %t424)
  br label %bb112
bb111:
  br label %bb113
bb112:
  br label %bb113
bb113:
  br label %bb114
bb114:
  br label %bb120
bb115:
  br i1 true, label %bb116, label %bb117
bb116:
  br label %bb118
bb117:
  br label %bb119
bb118:
  br label %bb120
bb119:
  call void @__olang_check_failed(ptr @olang_loc_e861e29eb0c54c86_5bd3b462adfe92ca)
  unreachable
bb120:
  call void @__olang_scope_close(ptr %s16)
  br label %bb121
bb121:
  %t427 = load i64, ptr %l25, !tbaa !24
  %t429 = add i64 %t427, 1
  store i64 %t429, ptr %l25, !tbaa !24
  br label %bb84
bb122:
  store ptr %l2, ptr %l30, !tbaa !29
  store i64 0, ptr %l31, !tbaa !24
  br label %bb123
bb123:
  store %olang.scope zeroinitializer, ptr %s25
  %t432 = load ptr, ptr %l30, !tbaa !29
  %t433 = load i64, ptr %l31, !tbaa !24
  %t436 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2eRunFrom_3ccompiler_2fmir_3aFnKey_3e(ptr %s0, ptr %t432, i64 %t433)
  %t437 = extractvalue { i32, { i64, ptr } } %t436, 1
  %t438 = extractvalue { i32, { i64, ptr } } %t436, 0
  store i32 %t438, ptr %l277
  %t439 = icmp ne i32 %t438, 0
  br i1 %t439, label %bb125, label %ok.440
ok.440:
  store { i64, ptr } %t437, ptr %l276
  br label %bb124
bb124:
  %t441 = load { i64, ptr }, ptr %l276, !tbaa !27
  store { i64, ptr } %t441, ptr %l273, !tbaa !27
  br label %bb129
bb125:
  %t442 = load i32, ptr %l277, !tbaa !23
  %t443 = ashr i32 %t442, 16
  %t445 = icmp eq i32 %t443, 1
  br i1 %t445, label %bb126, label %bb127
bb126:
  br label %bb128
bb127:
  call void @__olang_check_failed(ptr @olang_loc_9cb730421d055767_147ce7dab62cfd0b)
  unreachable
bb128:
  call void @__olang_scope_close(ptr %s25)
  br label %bb138
bb129:
  %t447 = load { i64, ptr }, ptr %l273, !tbaa !27
  store { i64, ptr } %t447, ptr %l32, !tbaa !27
  %t448 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t450 = extractvalue { i64, ptr } %t448, 0
  store i64 %t450, ptr %l33, !tbaa !24
  store i64 0, ptr %l34, !tbaa !24
  br label %bb130
bb130:
  store %olang.scope zeroinitializer, ptr %s26
  %t452 = load i64, ptr %l34, !tbaa !24
  %t453 = load i64, ptr %l33, !tbaa !24
  %t456 = icmp slt i64 %t452, %t453
  %t458 = xor i1 %t456, true
  br i1 %t458, label %bb131, label %bb132
bb131:
  call void @__olang_scope_close(ptr %s26)
  br label %bb136
bb132:
  br label %bb133
bb133:
  %t460 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t460, ptr %l286, !tbaa !27
  %t461 = load i64, ptr %l34, !tbaa !24
  %t463 = getelementptr { i64, ptr }, ptr %l286, i32 0, i32 1
  %t464 = load ptr, ptr %t463, !tbaa !27
  %t465 = getelementptr { i64, [1 x i64] }, ptr %t464, i64 %t461
  %t466 = load { i64, [1 x i64] }, ptr %t465
  %t468 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewant(ptr %v0, ptr %t468, { i64, [1 x i64] } %t466)
  br label %bb134
bb134:
  call void @__olang_scope_close(ptr %s26)
  br label %bb135
bb135:
  %t472 = load i64, ptr %l34, !tbaa !24
  %t474 = add i64 %t472, 1
  store i64 %t474, ptr %l34, !tbaa !24
  br label %bb130
bb136:
  %t476 = load i64, ptr %l31, !tbaa !24
  %t477 = load i64, ptr %l33, !tbaa !24
  %t480 = add i64 %t476, %t477
  store i64 %t480, ptr %l31, !tbaa !24
  call void @__olang_scope_close(ptr %s25)
  br label %bb137
bb137:
  br label %bb123
bb138:
  %t482 = load ptr, ptr %l0, !tbaa !29
  %t484 = getelementptr %"compiler/emit:Emitter", ptr %t482, i32 0, i32 37
  %t485 = load i1, ptr %t484, !tbaa !21
  br i1 %t485, label %bb139, label %bb140
bb139:
  br label %bb164
bb140:
  %t487 = load ptr, ptr %l0, !tbaa !29
  %t489 = getelementptr %"compiler/emit:Emitter", ptr %t487, i32 0, i32 4
  %t490 = load i1, ptr %t489, !tbaa !21
  br i1 %t490, label %bb141, label %bb142
bb141:
  store ptr %l10, ptr %l36, !tbaa !29
  store i64 0, ptr %l37, !tbaa !24
  br label %bb143
bb142:
  %t493 = load i64, ptr %l11, !tbaa !24
  %t495 = icmp sge i64 %t493, 0
  br i1 %t495, label %bb159, label %bb160
bb143:
  store %olang.scope zeroinitializer, ptr %s32
  %t497 = load ptr, ptr %l36, !tbaa !29
  %t498 = load i64, ptr %l37, !tbaa !24
  %t501 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s0, ptr %t497, i64 %t498)
  %t502 = extractvalue { i32, { i64, ptr } } %t501, 1
  %t503 = extractvalue { i32, { i64, ptr } } %t501, 0
  store i32 %t503, ptr %l305
  %t504 = icmp ne i32 %t503, 0
  br i1 %t504, label %bb145, label %ok.505
ok.505:
  store { i64, ptr } %t502, ptr %l304
  br label %bb144
bb144:
  %t506 = load { i64, ptr }, ptr %l304, !tbaa !27
  store { i64, ptr } %t506, ptr %l301, !tbaa !27
  br label %bb149
bb145:
  %t507 = load i32, ptr %l305, !tbaa !23
  %t508 = ashr i32 %t507, 16
  %t510 = icmp eq i32 %t508, 1
  br i1 %t510, label %bb146, label %bb147
bb146:
  br label %bb148
bb147:
  call void @__olang_check_failed(ptr @olang_loc_64b7f3da640c4c50_ae80c71f07f99e6c)
  unreachable
bb148:
  call void @__olang_scope_close(ptr %s32)
  br label %bb158
bb149:
  %t512 = load { i64, ptr }, ptr %l301, !tbaa !27
  store { i64, ptr } %t512, ptr %l38, !tbaa !27
  %t513 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t515 = extractvalue { i64, ptr } %t513, 0
  store i64 %t515, ptr %l39, !tbaa !24
  store i64 0, ptr %l40, !tbaa !24
  br label %bb150
bb150:
  store %olang.scope zeroinitializer, ptr %s33
  %t517 = load i64, ptr %l40, !tbaa !24
  %t518 = load i64, ptr %l39, !tbaa !24
  %t521 = icmp slt i64 %t517, %t518
  %t523 = xor i1 %t521, true
  br i1 %t523, label %bb151, label %bb152
bb151:
  call void @__olang_scope_close(ptr %s33)
  br label %bb156
bb152:
  br label %bb153
bb153:
  %t525 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t525, ptr %l314, !tbaa !27
  %t526 = load i64, ptr %l40, !tbaa !24
  %t528 = getelementptr { i64, ptr }, ptr %l314, i32 0, i32 1
  %t529 = load ptr, ptr %t528, !tbaa !27
  %t530 = getelementptr i64, ptr %t529, i64 %t526
  %t531 = load i64, ptr %t530, !tbaa !34
  %t533 = load ptr, ptr %l0, !tbaa !29
  %t536 = trunc i64 %t531 to i32
  store { i64, [1 x i64] } zeroinitializer, ptr %t538
  %t539 = getelementptr { i64, [1 x i64] }, ptr %t538, i32 0, i32 0
  store i64 0, ptr %t539
  %t541 = insertvalue { i32 } undef, i32 %t536, 0
  %t542 = getelementptr { i64, [1 x i64] }, ptr %t538, i32 0, i32 1
  store { i32 } %t541, ptr %t542
  %t543 = load { i64, [1 x i64] }, ptr %t538
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewant(ptr %v0, ptr %t533, { i64, [1 x i64] } %t543)
  br label %bb154
bb154:
  call void @__olang_scope_close(ptr %s33)
  br label %bb155
bb155:
  %t546 = load i64, ptr %l40, !tbaa !24
  %t548 = add i64 %t546, 1
  store i64 %t548, ptr %l40, !tbaa !24
  br label %bb150
bb156:
  %t550 = load i64, ptr %l37, !tbaa !24
  %t551 = load i64, ptr %l39, !tbaa !24
  %t554 = add i64 %t550, %t551
  store i64 %t554, ptr %l37, !tbaa !24
  call void @__olang_scope_close(ptr %s32)
  br label %bb157
bb157:
  br label %bb143
bb158:
  br label %bb163
bb159:
  %t556 = load ptr, ptr %l0, !tbaa !29
  %t557 = load i64, ptr %l11, !tbaa !24
  %t559 = trunc i64 %t557 to i32
  store { i64, [1 x i64] } zeroinitializer, ptr %t561
  %t562 = getelementptr { i64, [1 x i64] }, ptr %t561, i32 0, i32 0
  store i64 0, ptr %t562
  %t564 = insertvalue { i32 } undef, i32 %t559, 0
  %t565 = getelementptr { i64, [1 x i64] }, ptr %t561, i32 0, i32 1
  store { i32 } %t564, ptr %t565
  %t566 = load { i64, [1 x i64] }, ptr %t561
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewant(ptr %v0, ptr %t556, { i64, [1 x i64] } %t566)
  br label %bb161
bb160:
  br label %bb162
bb161:
  br label %bb162
bb162:
  br label %bb163
bb163:
  br label %bb164
bb164:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb165
bb165:
  store %olang.scope zeroinitializer, ptr %s37
  %t569 = load i64, ptr %l42, !tbaa !24
  store i64 %t569, ptr %l334, !tbaa !24
  %t570 = load ptr, ptr %l0, !tbaa !29
  %t572 = getelementptr %"compiler/emit:Emitter", ptr %t570, i32 0, i32 9
  %t574 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2eLen_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %t572)
  store i64 %t574, ptr %l337
  br label %bb166
bb166:
  %t575 = load i64, ptr %l334, !tbaa !24
  %t576 = load i64, ptr %l337, !tbaa !24
  %t577 = icmp slt i64 %t575, %t576
  %t579 = xor i1 %t577, true
  br i1 %t579, label %bb167, label %bb168
bb167:
  call void @__olang_scope_close(ptr %s37)
  br label %bb173
bb168:
  br label %bb169
bb169:
  %t581 = load ptr, ptr %l0, !tbaa !29
  %t583 = getelementptr %"compiler/emit:Emitter", ptr %t581, i32 0, i32 9
  %t584 = load i64, ptr %l42, !tbaa !24
  %t587 = call { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2eAt_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %t583, i64 %t584)
  store { i64, [1 x i64] } %t587, ptr %l343
  br label %bb170
bb170:
  %t588 = load { i64, [1 x i64] }, ptr %l343
  %t589 = load ptr, ptr %l0, !tbaa !29
  %t590 = load i64, ptr %l42, !tbaa !24
  %t593 = getelementptr %"compiler/emit:Emitter", ptr %t589, i32 0, i32 11
  store i64 %t590, ptr %t593, !tbaa !24
  %t594 = load i64, ptr %l42, !tbaa !24
  %t596 = add i64 %t594, 1
  store i64 %t596, ptr %l42, !tbaa !24
  %t598 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efunction(ptr %v0, ptr %t598, { i64, [1 x i64] } %t588)
  br label %bb171
bb171:
  call void @__olang_scope_close(ptr %s37)
  br label %bb172
bb172:
  br label %bb165
bb173:
  %t602 = load ptr, ptr %l0, !tbaa !29
  %t604 = getelementptr %"compiler/emit:Emitter", ptr %t602, i32 0, i32 11
  store i64 -1, ptr %t604, !tbaa !24
  store i64 0, ptr %l44, !tbaa !24
  %t605 = load ptr, ptr %l0, !tbaa !29
  %t607 = getelementptr %"compiler/emit:Emitter", ptr %t605, i32 0, i32 27
  %t609 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2eLen_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %t607)
  store i64 %t609, ptr %l353
  br label %bb174
bb174:
  %t610 = load i64, ptr %l353, !tbaa !24
  store i64 %t610, ptr %l45, !tbaa !24
  store i64 1, ptr %l46, !tbaa !24
  %t611 = load i64, ptr %l45, !tbaa !24
  %t612 = load i64, ptr %l44, !tbaa !24
  %t615 = icmp sgt i64 %t611, %t612
  br i1 %t615, label %bb175, label %bb176
bb175:
  %t617 = load i64, ptr %l46, !tbaa !24
  %t619 = icmp sgt i64 %t617, 0
  br i1 %t619, label %bb177, label %bb178
bb176:
  store i64 0, ptr %l357, !tbaa !24
  br label %bb180
bb177:
  %t621 = load i64, ptr %l45, !tbaa !24
  %t622 = load i64, ptr %l44, !tbaa !24
  %t625 = sub i64 %t621, %t622
  %t626 = load i64, ptr %l46, !tbaa !24
  %t629 = add i64 %t625, %t626
  %t631 = sub i64 %t629, 1
  %t632 = load i64, ptr %l46, !tbaa !24
  %t635 = sdiv i64 %t631, %t632
  store i64 %t635, ptr %l360, !tbaa !24
  br label %bb179
bb178:
  store i64 0, ptr %l360, !tbaa !24
  br label %bb179
bb179:
  %t637 = load i64, ptr %l360, !tbaa !24
  store i64 %t637, ptr %l357, !tbaa !24
  br label %bb180
bb180:
  %t638 = load i64, ptr %l357, !tbaa !24
  store i64 %t638, ptr %l47, !tbaa !24
  store i64 0, ptr %l48, !tbaa !24
  br label %bb181
bb181:
  store %olang.scope zeroinitializer, ptr %s39
  %t639 = load i64, ptr %l48, !tbaa !24
  %t640 = load i64, ptr %l47, !tbaa !24
  %t643 = icmp slt i64 %t639, %t640
  %t645 = xor i1 %t643, true
  br i1 %t645, label %bb182, label %bb183
bb182:
  call void @__olang_scope_close(ptr %s39)
  br label %bb189
bb183:
  br label %bb184
bb184:
  %t647 = load i64, ptr %l44, !tbaa !24
  %t648 = load i64, ptr %l48, !tbaa !24
  %t649 = load i64, ptr %l46, !tbaa !24
  %t652 = mul i64 %t648, %t649
  %t655 = add i64 %t647, %t652
  store i64 %t655, ptr %l49, !tbaa !24
  %t657 = load ptr, ptr %l0, !tbaa !29
  store ptr %t657, ptr %l378, !tbaa !29
  %t658 = load ptr, ptr %l0, !tbaa !29
  %t660 = getelementptr %"compiler/emit:Emitter", ptr %t658, i32 0, i32 27
  %t661 = load i64, ptr %l49, !tbaa !24
  %t664 = call { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2eAt_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %t660, i64 %t661)
  store { i64, [1 x i64] } %t664, ptr %l382
  br label %bb185
bb185:
  %t665 = load ptr, ptr %l0, !tbaa !29
  %t667 = getelementptr %"compiler/emit:Emitter", ptr %t665, i32 0, i32 28
  %t668 = load i64, ptr %l49, !tbaa !24
  %t671 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t667, i64 %t668)
  store i32 %t671, ptr %l386
  br label %bb186
bb186:
  %t672 = load ptr, ptr %l378, !tbaa !29
  %t673 = load { i64, [1 x i64] }, ptr %l382
  %t674 = load i32, ptr %l386, !tbaa !23
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ethunk(ptr %v0, ptr %t672, { i64, [1 x i64] } %t673, i32 %t674)
  br label %bb187
bb187:
  call void @__olang_scope_close(ptr %s39)
  br label %bb188
bb188:
  %t675 = load i64, ptr %l48, !tbaa !24
  %t677 = add i64 %t675, 1
  store i64 %t677, ptr %l48, !tbaa !24
  br label %bb181
bb189:
  store i64 0, ptr %l50, !tbaa !24
  %t679 = load ptr, ptr %l0, !tbaa !29
  %t681 = getelementptr %"compiler/emit:Emitter", ptr %t679, i32 0, i32 29
  %t683 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t681)
  store i64 %t683, ptr %l391
  br label %bb190
bb190:
  %t684 = load i64, ptr %l391, !tbaa !24
  store i64 %t684, ptr %l51, !tbaa !24
  store i64 1, ptr %l52, !tbaa !24
  %t685 = load i64, ptr %l51, !tbaa !24
  %t686 = load i64, ptr %l50, !tbaa !24
  %t689 = icmp sgt i64 %t685, %t686
  br i1 %t689, label %bb191, label %bb192
bb191:
  %t691 = load i64, ptr %l52, !tbaa !24
  %t693 = icmp sgt i64 %t691, 0
  br i1 %t693, label %bb193, label %bb194
bb192:
  store i64 0, ptr %l395, !tbaa !24
  br label %bb196
bb193:
  %t695 = load i64, ptr %l51, !tbaa !24
  %t696 = load i64, ptr %l50, !tbaa !24
  %t699 = sub i64 %t695, %t696
  %t700 = load i64, ptr %l52, !tbaa !24
  %t703 = add i64 %t699, %t700
  %t705 = sub i64 %t703, 1
  %t706 = load i64, ptr %l52, !tbaa !24
  %t709 = sdiv i64 %t705, %t706
  store i64 %t709, ptr %l398, !tbaa !24
  br label %bb195
bb194:
  store i64 0, ptr %l398, !tbaa !24
  br label %bb195
bb195:
  %t711 = load i64, ptr %l398, !tbaa !24
  store i64 %t711, ptr %l395, !tbaa !24
  br label %bb196
bb196:
  %t712 = load i64, ptr %l395, !tbaa !24
  store i64 %t712, ptr %l53, !tbaa !24
  store i64 0, ptr %l54, !tbaa !24
  br label %bb197
bb197:
  store %olang.scope zeroinitializer, ptr %s42
  %t713 = load i64, ptr %l54, !tbaa !24
  %t714 = load i64, ptr %l53, !tbaa !24
  %t717 = icmp slt i64 %t713, %t714
  %t719 = xor i1 %t717, true
  br i1 %t719, label %bb198, label %bb199
bb198:
  call void @__olang_scope_close(ptr %s42)
  br label %bb205
bb199:
  br label %bb200
bb200:
  %t721 = load i64, ptr %l50, !tbaa !24
  %t722 = load i64, ptr %l54, !tbaa !24
  %t723 = load i64, ptr %l52, !tbaa !24
  %t726 = mul i64 %t722, %t723
  %t729 = add i64 %t721, %t726
  store i64 %t729, ptr %l55, !tbaa !24
  %t731 = load ptr, ptr %l0, !tbaa !29
  store ptr %t731, ptr %l416, !tbaa !29
  %t732 = load ptr, ptr %l0, !tbaa !29
  %t734 = getelementptr %"compiler/emit:Emitter", ptr %t732, i32 0, i32 29
  %t735 = load i64, ptr %l55, !tbaa !24
  %t738 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t734, i64 %t735)
  store i32 %t738, ptr %l420
  br label %bb201
bb201:
  %t739 = load ptr, ptr %l0, !tbaa !29
  %t741 = getelementptr %"compiler/emit:Emitter", ptr %t739, i32 0, i32 30
  %t742 = load i64, ptr %l55, !tbaa !24
  %t745 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t741, i64 %t742)
  store i32 %t745, ptr %l424
  br label %bb202
bb202:
  %t746 = load ptr, ptr %l416, !tbaa !29
  %t747 = load i32, ptr %l420, !tbaa !23
  %t748 = load i32, ptr %l424, !tbaa !23
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efvAdapter(ptr %v0, ptr %t746, i32 %t747, i32 %t748)
  br label %bb203
bb203:
  call void @__olang_scope_close(ptr %s42)
  br label %bb204
bb204:
  %t749 = load i64, ptr %l54, !tbaa !24
  %t751 = add i64 %t749, 1
  store i64 %t751, ptr %l54, !tbaa !24
  br label %bb197
bb205:
  %t753 = load ptr, ptr %l0, !tbaa !29
  %t755 = getelementptr %"compiler/emit:Emitter", ptr %t753, i32 0, i32 32
  store ptr %t755, ptr %l56, !tbaa !29
  store i64 0, ptr %l57, !tbaa !24
  br label %bb206
bb206:
  store %olang.scope zeroinitializer, ptr %s45
  %t757 = load ptr, ptr %l56, !tbaa !29
  %t758 = load i64, ptr %l57, !tbaa !24
  %t761 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2eRunFrom_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %t757, i64 %t758)
  %t762 = extractvalue { i32, { i64, ptr } } %t761, 1
  %t763 = extractvalue { i32, { i64, ptr } } %t761, 0
  store i32 %t763, ptr %l433
  %t764 = icmp ne i32 %t763, 0
  br i1 %t764, label %bb208, label %ok.765
ok.765:
  store { i64, ptr } %t762, ptr %l432
  br label %bb207
bb207:
  %t766 = load { i64, ptr }, ptr %l432, !tbaa !27
  store { i64, ptr } %t766, ptr %l429, !tbaa !27
  br label %bb212
bb208:
  %t767 = load i32, ptr %l433, !tbaa !23
  %t768 = ashr i32 %t767, 16
  %t770 = icmp eq i32 %t768, 1
  br i1 %t770, label %bb209, label %bb210
bb209:
  br label %bb211
bb210:
  call void @__olang_check_failed(ptr @olang_loc_1a5036849576e1e1_210713689f77e31d)
  unreachable
bb211:
  call void @__olang_scope_close(ptr %s45)
  br label %bb221
bb212:
  %t772 = load { i64, ptr }, ptr %l429, !tbaa !27
  store { i64, ptr } %t772, ptr %l58, !tbaa !27
  %t773 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t775 = extractvalue { i64, ptr } %t773, 0
  store i64 %t775, ptr %l59, !tbaa !24
  store i64 0, ptr %l60, !tbaa !24
  br label %bb213
bb213:
  store %olang.scope zeroinitializer, ptr %s46
  %t777 = load i64, ptr %l60, !tbaa !24
  %t778 = load i64, ptr %l59, !tbaa !24
  %t781 = icmp slt i64 %t777, %t778
  %t783 = xor i1 %t781, true
  br i1 %t783, label %bb214, label %bb215
bb214:
  call void @__olang_scope_close(ptr %s46)
  br label %bb219
bb215:
  br label %bb216
bb216:
  %t785 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t785, ptr %l442, !tbaa !27
  %t786 = load i64, ptr %l60, !tbaa !24
  %t788 = getelementptr { i64, ptr }, ptr %l442, i32 0, i32 1
  %t789 = load ptr, ptr %t788, !tbaa !27
  %t790 = getelementptr { i64, [1 x i64] }, ptr %t789, i64 %t786
  %t791 = load { i64, [1 x i64] }, ptr %t790
  %t793 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edtorThunk(ptr %v0, ptr %t793, { i64, [1 x i64] } %t791)
  br label %bb217
bb217:
  call void @__olang_scope_close(ptr %s46)
  br label %bb218
bb218:
  %t797 = load i64, ptr %l60, !tbaa !24
  %t799 = add i64 %t797, 1
  store i64 %t799, ptr %l60, !tbaa !24
  br label %bb213
bb219:
  %t801 = load i64, ptr %l57, !tbaa !24
  %t802 = load i64, ptr %l59, !tbaa !24
  %t805 = add i64 %t801, %t802
  store i64 %t805, ptr %l57, !tbaa !24
  call void @__olang_scope_close(ptr %s45)
  br label %bb220
bb220:
  br label %bb206
bb221:
  %t807 = load ptr, ptr %l0, !tbaa !29
  %t809 = getelementptr %"compiler/emit:Emitter", ptr %t807, i32 0, i32 37
  %t810 = load i1, ptr %t809, !tbaa !21
  br i1 %t810, label %bb222, label %bb223
bb222:
  br label %bb232
bb223:
  %t812 = load ptr, ptr %l0, !tbaa !29
  %t814 = getelementptr %"compiler/emit:Emitter", ptr %t812, i32 0, i32 4
  %t815 = load i1, ptr %t814, !tbaa !21
  br i1 %t815, label %bb224, label %bb225
bb224:
  %t817 = load ptr, ptr %l0, !tbaa !29
  %t818 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eharness(ptr %v0, ptr %s0, ptr %t817, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t818)
  br label %bb226
bb225:
  %t821 = load i64, ptr %l11, !tbaa !24
  %t823 = icmp sge i64 %t821, 0
  br i1 %t823, label %bb227, label %bb228
bb226:
  br label %bb231
bb227:
  %t825 = load ptr, ptr %l0, !tbaa !29
  %t826 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  %t827 = load i64, ptr %l11, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eentry(ptr %v0, ptr %s0, ptr %t825, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t826, i64 %t827)
  br label %bb229
bb228:
  br label %bb230
bb229:
  br label %bb230
bb230:
  br label %bb231
bb231:
  br label %bb232
bb232:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb233
bb233:
  store %olang.scope zeroinitializer, ptr %s53
  %t831 = load i64, ptr %l62, !tbaa !24
  store i64 %t831, ptr %l463, !tbaa !24
  %t832 = load ptr, ptr %l0, !tbaa !29
  %t834 = getelementptr %"compiler/emit:Emitter", ptr %t832, i32 0, i32 12
  %t836 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t834)
  store i64 %t836, ptr %l466
  br label %bb234
bb234:
  %t837 = load i64, ptr %l463, !tbaa !24
  %t838 = load i64, ptr %l466, !tbaa !24
  %t839 = icmp slt i64 %t837, %t838
  %t841 = xor i1 %t839, true
  br i1 %t841, label %bb235, label %bb236
bb235:
  call void @__olang_scope_close(ptr %s53)
  br label %bb263
bb236:
  br label %bb237
bb237:
  %t843 = load ptr, ptr %l0, !tbaa !29
  %t845 = getelementptr %"compiler/emit:Emitter", ptr %t843, i32 0, i32 12
  %t846 = load i64, ptr %l62, !tbaa !24
  %t849 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t845, i64 %t846)
  store i32 %t849, ptr %l472
  br label %bb238
bb238:
  %t850 = load i32, ptr %l472, !tbaa !23
  store i32 %t850, ptr %l63, !tbaa !23
  %t851 = load i64, ptr %l62, !tbaa !24
  %t853 = add i64 %t851, 1
  store i64 %t853, ptr %l62, !tbaa !24
  %t855 = load ptr, ptr %l0, !tbaa !29
  %t857 = getelementptr %"compiler/emit:Emitter", ptr %t855, i32 0, i32 3
  %t858 = load ptr, ptr %t857, !tbaa !29
  %t859 = load i32, ptr %l63, !tbaa !23
  %t862 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eStructBody(ptr %v0, ptr %s53, ptr %t858, i32 %t859)
  store { i64, ptr } %t862, ptr %l478
  br label %bb239
bb239:
  %t863 = load { i64, ptr }, ptr %l478, !tbaa !27
  store { i64, ptr } %t863, ptr %l64, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s54
  %t864 = load ptr, ptr %l0, !tbaa !29
  %t866 = getelementptr %"compiler/emit:Emitter", ptr %t864, i32 0, i32 3
  %t867 = load ptr, ptr %t866, !tbaa !29
  %t868 = load i32, ptr %l63, !tbaa !23
  %t871 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eEmbedded(ptr %v0, ptr %s54, ptr %t867, i32 %t868)
  store { i64, ptr } %t871, ptr %l482
  br label %bb240
bb240:
  %t872 = load { i64, ptr }, ptr %l482, !tbaa !27
  %t873 = extractvalue { i64, ptr } %t872, 0
  %t874 = extractvalue { i64, ptr } %t872, 1
  %t875 = mul i64 %t873, 4
  %t876 = call ptr @__olang_scope_alloc(ptr %s54, i64 %t875)
  call void @llvm.memcpy.p0.p0.i64(ptr %t876, ptr %t874, i64 %t875, i1 false)
  %t877 = insertvalue { i64, ptr } undef, i64 %t873, 0
  %t878 = insertvalue { i64, ptr } %t877, ptr %t876, 1
  store { i64, ptr } %t878, ptr %l65, !tbaa !27
  store i64 0, ptr %l66, !tbaa !24
  %t880 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t882 = extractvalue { i64, ptr } %t880, 0
  store i64 %t882, ptr %l67, !tbaa !24
  br label %bb241
bb241:
  store %olang.scope zeroinitializer, ptr %s55
  %t884 = load i64, ptr %l66, !tbaa !24
  %t885 = load i64, ptr %l67, !tbaa !24
  %t888 = icmp slt i64 %t884, %t885
  %t890 = xor i1 %t888, true
  br i1 %t890, label %bb242, label %bb243
bb242:
  call void @__olang_scope_close(ptr %s55)
  br label %bb247
bb243:
  br label %bb244
bb244:
  %t892 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t892, ptr %l490, !tbaa !27
  %t893 = load i64, ptr %l66, !tbaa !24
  %t895 = getelementptr { i64, ptr }, ptr %l490, i32 0, i32 1
  %t896 = load ptr, ptr %t895, !tbaa !27
  %t897 = getelementptr i32, ptr %t896, i64 %t893
  %t898 = load i32, ptr %t897, !tbaa !33
  %t900 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eneed(ptr %v0, ptr %t900, i32 %t898)
  br label %bb245
bb245:
  call void @__olang_scope_close(ptr %s55)
  br label %bb246
bb246:
  %t904 = load i64, ptr %l66, !tbaa !24
  %t906 = add i64 %t904, 1
  store i64 %t906, ptr %l66, !tbaa !24
  br label %bb241
bb247:
  call void @__olang_scope_close(ptr %s54)
  %t908 = load ptr, ptr %l0, !tbaa !29
  %t910 = getelementptr %"compiler/emit:Emitter", ptr %t908, i32 0, i32 3
  %t911 = load ptr, ptr %t910, !tbaa !29
  %t912 = load i32, ptr %l63, !tbaa !23
  %t915 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %t911, i32 %t912)
  store { i64, ptr } %t915, ptr %l500
  br label %bb248
bb248:
  %t916 = load { i64, ptr }, ptr %l500, !tbaa !27
  store { i64, ptr } %t916, ptr %l69, !tbaa !27
  %t917 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t917, ptr %l501, !tbaa !27
  %t918 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t920 = extractvalue { i64, ptr } %t918, 0
  %t922 = sub i64 %t920, 1
  store i64 %t922, ptr %l504, !tbaa !24
  %t923 = load { i64, ptr }, ptr %l501, !tbaa !27
  %t924 = extractvalue { i64, ptr } %t923, 0
  store i64 %t924, ptr %l505, !tbaa !24
  %t925 = icmp sge i64 2, 0
  br i1 %t925, label %bb249, label %bb250
bb249:
  %t927 = load i64, ptr %l504, !tbaa !24
  %t928 = icmp sle i64 2, %t927
  br i1 %t928, label %bb251, label %bb252
bb250:
  call void @__olang_check_failed(ptr @olang_loc_4fc93e498ee23529_4b147f0de2788105)
  unreachable
bb251:
  %t930 = load i64, ptr %l504, !tbaa !24
  %t931 = load i64, ptr %l505, !tbaa !24
  %t932 = icmp sle i64 %t930, %t931
  br i1 %t932, label %bb253, label %bb254
bb252:
  call void @__olang_check_failed(ptr @olang_loc_4fc93e498ee23529_4b147f0de2788105)
  unreachable
bb253:
  %t934 = getelementptr { i64, ptr }, ptr %l501, i32 0, i32 1
  %t935 = load ptr, ptr %t934, !tbaa !27
  %t936 = load i64, ptr %l504, !tbaa !24
  %t937 = getelementptr i8, ptr %t935, i64 2
  %t938 = sub i64 %t936, 2
  %t939 = insertvalue { i64, ptr } undef, i64 %t938, 0
  %t940 = insertvalue { i64, ptr } %t939, ptr %t937, 1
  store { i64, ptr } %t940, ptr %l70, !tbaa !27
  %t942 = load ptr, ptr %l0, !tbaa !29
  %t944 = getelementptr %"compiler/emit:Emitter", ptr %t942, i32 0, i32 42
  %t945 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t948 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v0, ptr %t944, { i64, ptr } %t945)
  store i1 %t948, ptr %l513
  br label %bb255
bb254:
  call void @__olang_check_failed(ptr @olang_loc_4fc93e498ee23529_4b147f0de2788105)
  unreachable
bb255:
  %t949 = load i1, ptr %l513, !tbaa !21
  br i1 %t949, label %bb256, label %bb257
bb256:
  call void @__olang_scope_close(ptr %s53)
  br label %bb262
bb257:
  br label %bb258
bb258:
  %t950 = load ptr, ptr %l0, !tbaa !29
  %t952 = getelementptr %"compiler/emit:Emitter", ptr %t950, i32 0, i32 42
  store ptr %t952, ptr %l515, !tbaa !29
  %t953 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t955 = extractvalue { i64, ptr } %t953, 1
  %t956 = extractvalue { i64, ptr } %t953, 0
  %t957 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t956)
  call void @olang_textcopy(ptr %t957, ptr %t955, i64 %t956)
  %t958 = insertvalue { i64, ptr } undef, i64 %t956, 0
  %t959 = insertvalue { i64, ptr } %t958, ptr %t957, 1
  %t961 = extractvalue { i64, ptr } %t959, 0
  %t962 = extractvalue { i64, ptr } %t959, 1
  %t963 = mul i64 %t961, 1
  %t964 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t963)
  call void @llvm.memcpy.p0.p0.i64(ptr %t964, ptr %t962, i64 %t963, i1 false)
  %t965 = insertvalue { i64, ptr } undef, i64 %t961, 0
  %t966 = insertvalue { i64, ptr } %t965, ptr %t964, 1
  store { i64, ptr } %t966, ptr %l518, !tbaa !27
  %t967 = load ptr, ptr %l0, !tbaa !29
  %t969 = getelementptr %"compiler/emit:Emitter", ptr %t967, i32 0, i32 41
  %t971 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t969)
  store i64 %t971, ptr %l521
  br label %bb259
bb259:
  %t972 = load ptr, ptr %l515, !tbaa !29
  %t973 = load { i64, ptr }, ptr %l518, !tbaa !27
  %t974 = load i64, ptr %l521, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t972, { i64, ptr } %t973, i64 %t974)
  br label %bb260
bb260:
  %t975 = load ptr, ptr %l0, !tbaa !29
  %t977 = getelementptr %"compiler/emit:Emitter", ptr %t975, i32 0, i32 41
  %t978 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t979 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t981 = extractvalue { i64, ptr } %t978, 1
  %t982 = extractvalue { i64, ptr } %t978, 0
  %t983 = extractvalue { i64, ptr } { i64 8, ptr @.d10 }, 1
  %t984 = extractvalue { i64, ptr } { i64 8, ptr @.d10 }, 0
  %t985 = add i64 %t982, %t984
  %t987 = extractvalue { i64, ptr } %t979, 1
  %t988 = extractvalue { i64, ptr } %t979, 0
  %t989 = add i64 %t985, %t988
  %t990 = extractvalue { i64, ptr } { i64 1, ptr @.d11 }, 1
  %t991 = extractvalue { i64, ptr } { i64 1, ptr @.d11 }, 0
  %t992 = add i64 %t989, %t991
  %t993 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t992)
  call void @olang_textcopy(ptr %t993, ptr %t981, i64 %t982)
  %t994 = getelementptr i8, ptr %t993, i64 %t982
  call void @olang_textcopy(ptr %t994, ptr %t983, i64 %t984)
  %t995 = getelementptr i8, ptr %t994, i64 %t984
  call void @olang_textcopy(ptr %t995, ptr %t987, i64 %t988)
  %t996 = getelementptr i8, ptr %t995, i64 %t988
  call void @olang_textcopy(ptr %t996, ptr %t990, i64 %t991)
  %t997 = insertvalue { i64, ptr } undef, i64 %t992, 0
  %t998 = insertvalue { i64, ptr } %t997, ptr %t993, 1
  %t1000 = extractvalue { i64, ptr } %t998, 0
  %t1001 = extractvalue { i64, ptr } %t998, 1
  %t1002 = mul i64 %t1000, 1
  %t1003 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t1002)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1003, ptr %t1001, i64 %t1002, i1 false)
  %t1004 = insertvalue { i64, ptr } undef, i64 %t1000, 0
  %t1005 = insertvalue { i64, ptr } %t1004, ptr %t1003, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t977, { i64, ptr } %t1005)
  br label %bb261
bb261:
  call void @__olang_scope_close(ptr %s53)
  br label %bb262
bb262:
  br label %bb233
bb263:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eenumWords(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i1
  %l7 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  %t8 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t4, i32 %t5)
  store i1 %t8, ptr %l5
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/emit:Emitter", ptr %t9, i32 0, i32 3
  %t12 = load ptr, ptr %t11, !tbaa !29
  store ptr %t12, ptr %l7, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/emit:Emitter", ptr %t13, i32 0, i32 3
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t17 = load i32, ptr %l1, !tbaa !23
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t16, i32 %t17)
  store i32 %t20, ptr %l11
  br label %bb2
bb2:
  %t21 = load ptr, ptr %l7, !tbaa !29
  %t22 = load i32, ptr %l11, !tbaa !23
  %t23 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePayloadSize(ptr %v0, ptr %t21, i32 %t22)
  store i64 %t23, ptr %l12
  br label %bb3
bb3:
  %t24 = load i64, ptr %l12, !tbaa !24
  %t25 = icmp sge i64 %t24, 0
  store i1 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eextern(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %lp4 = alloca ptr
  %lp5 = alloca ptr
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i32
  %l18 = alloca ptr
  %l22 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l32 = alloca i1
  %l36 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l52 = alloca i1
  %l54 = alloca %"std/prelude/text:StringBuilder"
  %l55 = alloca ptr
  %l58 = alloca { i64, ptr }
  %l62 = alloca ptr
  %l65 = alloca i32
  %l66 = alloca { i64, ptr }
  %l72 = alloca i64
  %l75 = alloca i64
  %l97 = alloca { i64, ptr }
  %l100 = alloca i32
  %l103 = alloca i1
  %l104 = alloca i32
  %l107 = alloca i32
  %l111 = alloca i32
  %l115 = alloca ptr
  %l118 = alloca i32
  %l119 = alloca i32
  %l123 = alloca ptr
  %l126 = alloca { i64, ptr }
  %l133 = alloca i1
  %l134 = alloca i1
  %l137 = alloca { i64, ptr }
  %l139 = alloca i1
  %l142 = alloca ptr
  %l143 = alloca { i64, ptr }
  %l145 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l18, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/emit:Emitter", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t14 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t10, i64 %a1)
  store ptr %t14, ptr %l22
  br label %bb1
bb1:
  %t15 = load ptr, ptr %l22, !tbaa !29
  %t17 = getelementptr %"compiler/ast:Func", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %t17, !tbaa !23
  %t19 = load ptr, ptr %l18, !tbaa !29
  %t21 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %t19, i32 %t18)
  store { i64, ptr } %t21, ptr %l25
  br label %bb2
bb2:
  %t22 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 1
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t25 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t24)
  call void @olang_textcopy(ptr %t25, ptr %t23, i64 %t24)
  %t26 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  %t28 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t28, ptr %lp4
  %t30 = load ptr, ptr %lp4
  store { i64, ptr } %t27, ptr %t30, !tbaa !27
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %lp4
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  %t34 = load i32, ptr %l2, !tbaa !23
  %t38 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2emathIntrinsic(ptr %v0, ptr %v1, ptr %v1, ptr %t31, { i64, ptr } %t33, i32 %t34)
  store { i64, ptr } %t38, ptr %l30
  br label %bb3
bb3:
  %t39 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t39, ptr %lp5
  %t40 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t41 = load ptr, ptr %lp5
  store { i64, ptr } %t40, ptr %t41, !tbaa !27
  %t42 = load ptr, ptr %lp5
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  %t45 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t43, { i64, ptr } { i64 0, ptr @.d12 })
  store i1 %t45, ptr %l32
  br label %bb4
bb4:
  %t46 = load i1, ptr %l32, !tbaa !21
  %t47 = xor i1 %t46, true
  br i1 %t47, label %bb5, label %bb6
bb5:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load ptr, ptr %lp5
  %t51 = load { i64, ptr }, ptr %t50, !tbaa !27
  %t54 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehas(ptr %v0, ptr %v1, ptr %t49, { i64, ptr } %t51)
  store i1 %t54, ptr %l36
  br label %bb7
bb6:
  br label %bb14
bb7:
  %t55 = load i1, ptr %l36, !tbaa !21
  %t56 = xor i1 %t55, true
  br i1 %t56, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l38, !tbaa !29
  %t59 = load ptr, ptr %lp5
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  store { i64, ptr } %t60, ptr %l39, !tbaa !27
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i32, ptr %l2, !tbaa !23
  %t65 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eexternRet(ptr %v0, ptr %s3, ptr %t61, i32 %t62)
  store { i64, ptr } %t65, ptr %l42
  br label %bb10
bb9:
  br label %bb13
bb10:
  %t66 = load ptr, ptr %lp5
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !27
  store { i64, ptr } %t67, ptr %l43, !tbaa !27
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i32, ptr %l2, !tbaa !23
  %t72 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2emathParams(ptr %v0, ptr %s3, ptr %t68, i32 %t69)
  store { i64, ptr } %t72, ptr %l46
  br label %bb11
bb11:
  %t73 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 1
  %t75 = extractvalue { i64, ptr } %t73, 0
  %t76 = extractvalue { i64, ptr } { i64 2, ptr @.d13 }, 1
  %t77 = extractvalue { i64, ptr } { i64 2, ptr @.d13 }, 0
  %t78 = add i64 %t75, %t77
  %t79 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 1
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t82 = add i64 %t78, %t81
  %t83 = extractvalue { i64, ptr } { i64 1, ptr @.d14 }, 1
  %t84 = extractvalue { i64, ptr } { i64 1, ptr @.d14 }, 0
  %t85 = add i64 %t82, %t84
  %t86 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = add i64 %t85, %t88
  %t90 = extractvalue { i64, ptr } { i64 1, ptr @.d15 }, 1
  %t91 = extractvalue { i64, ptr } { i64 1, ptr @.d15 }, 0
  %t92 = add i64 %t89, %t91
  %t93 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t92)
  call void @olang_textcopy(ptr %t93, ptr %t74, i64 %t75)
  %t94 = getelementptr i8, ptr %t93, i64 %t75
  call void @olang_textcopy(ptr %t94, ptr %t76, i64 %t77)
  %t95 = getelementptr i8, ptr %t94, i64 %t77
  call void @olang_textcopy(ptr %t95, ptr %t80, i64 %t81)
  %t96 = getelementptr i8, ptr %t95, i64 %t81
  call void @olang_textcopy(ptr %t96, ptr %t83, i64 %t84)
  %t97 = getelementptr i8, ptr %t96, i64 %t84
  call void @olang_textcopy(ptr %t97, ptr %t87, i64 %t88)
  %t98 = getelementptr i8, ptr %t97, i64 %t88
  call void @olang_textcopy(ptr %t98, ptr %t90, i64 %t91)
  %t99 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t93, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = extractvalue { i64, ptr } %t100, 1
  %t104 = mul i64 %t102, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t104)
  call void @llvm.memcpy.p0.p0.i64(ptr %t105, ptr %t103, i64 %t104, i1 false)
  %t106 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  %t108 = load ptr, ptr %l38, !tbaa !29
  %t109 = load { i64, ptr }, ptr %l39, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %v1, ptr %s3, ptr %t108, { i64, ptr } %t109, { i64, ptr } %t107)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb13:
  %t111 = load ptr, ptr %lp5
  %t112 = load { i64, ptr }, ptr %t111, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t112, ptr %rv
  br label %ret
bb14:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load ptr, ptr %lp4
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  %t119 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehas(ptr %v0, ptr %v1, ptr %t114, { i64, ptr } %t116)
  store i1 %t119, ptr %l52
  br label %bb15
bb15:
  %t120 = load i1, ptr %l52, !tbaa !21
  br i1 %t120, label %bb16, label %bb17
bb16:
  %t121 = load ptr, ptr %lp4
  %t122 = load { i64, ptr }, ptr %t121, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t122, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t124 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t124, ptr %l54
  br label %bb19
bb19:
  %t125 = load %"std/prelude/text:StringBuilder", ptr %l54
  store %"std/prelude/text:StringBuilder" %t125, ptr %l6
  store ptr %l6, ptr %l55, !tbaa !29
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load i32, ptr %l2, !tbaa !23
  %t130 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eexternRet(ptr %v0, ptr %s0, ptr %t126, i32 %t127)
  store { i64, ptr } %t130, ptr %l58
  br label %bb20
bb20:
  %t131 = load ptr, ptr %lp4
  %t132 = load { i64, ptr }, ptr %t131, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 1
  %t135 = extractvalue { i64, ptr } %t133, 0
  %t136 = extractvalue { i64, ptr } { i64 2, ptr @.d16 }, 1
  %t137 = extractvalue { i64, ptr } { i64 2, ptr @.d16 }, 0
  %t138 = add i64 %t135, %t137
  %t140 = extractvalue { i64, ptr } %t132, 1
  %t141 = extractvalue { i64, ptr } %t132, 0
  %t142 = add i64 %t138, %t141
  %t143 = extractvalue { i64, ptr } { i64 1, ptr @.d17 }, 1
  %t144 = extractvalue { i64, ptr } { i64 1, ptr @.d17 }, 0
  %t145 = add i64 %t142, %t144
  %t146 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t145)
  call void @olang_textcopy(ptr %t146, ptr %t134, i64 %t135)
  %t147 = getelementptr i8, ptr %t146, i64 %t135
  call void @olang_textcopy(ptr %t147, ptr %t136, i64 %t137)
  %t148 = getelementptr i8, ptr %t147, i64 %t137
  call void @olang_textcopy(ptr %t148, ptr %t140, i64 %t141)
  %t149 = getelementptr i8, ptr %t148, i64 %t141
  call void @olang_textcopy(ptr %t149, ptr %t143, i64 %t144)
  %t150 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t146, 1
  %t153 = extractvalue { i64, ptr } %t151, 0
  %t154 = extractvalue { i64, ptr } %t151, 1
  %t155 = mul i64 %t153, 1
  %t156 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t155)
  call void @llvm.memcpy.p0.p0.i64(ptr %t156, ptr %t154, i64 %t155, i1 false)
  %t157 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t156, 1
  %t159 = load ptr, ptr %l55, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t159, { i64, ptr } %t158)
  br label %bb21
bb21:
  %t161 = load ptr, ptr %l3, !tbaa !29
  store ptr %t161, ptr %l62, !tbaa !29
  %t162 = load ptr, ptr %l3, !tbaa !29
  %t163 = load i32, ptr %l2, !tbaa !23
  %t166 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t162, i32 %t163)
  store i32 %t166, ptr %l65
  br label %bb22
bb22:
  %t167 = load ptr, ptr %l62, !tbaa !29
  %t168 = load i32, ptr %l65, !tbaa !23
  %t169 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t167, i32 %t168)
  store { i64, ptr } %t169, ptr %l66
  br label %bb23
bb23:
  %t170 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t170, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t171 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t173 = extractvalue { i64, ptr } %t171, 0
  store i64 %t173, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t175 = load i64, ptr %l9, !tbaa !24
  %t176 = load i64, ptr %l8, !tbaa !24
  %t179 = icmp sgt i64 %t175, %t176
  br i1 %t179, label %bb24, label %bb25
bb24:
  %t181 = load i64, ptr %l10, !tbaa !24
  %t183 = icmp sgt i64 %t181, 0
  br i1 %t183, label %bb26, label %bb27
bb25:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb29
bb26:
  %t185 = load i64, ptr %l9, !tbaa !24
  %t186 = load i64, ptr %l8, !tbaa !24
  %t189 = sub i64 %t185, %t186
  %t190 = load i64, ptr %l10, !tbaa !24
  %t193 = add i64 %t189, %t190
  %t195 = sub i64 %t193, 1
  %t196 = load i64, ptr %l10, !tbaa !24
  %t199 = sdiv i64 %t195, %t196
  store i64 %t199, ptr %l75, !tbaa !24
  br label %bb28
bb27:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb28
bb28:
  %t201 = load i64, ptr %l75, !tbaa !24
  store i64 %t201, ptr %l72, !tbaa !24
  br label %bb29
bb29:
  %t202 = load i64, ptr %l72, !tbaa !24
  store i64 %t202, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s8
  %t203 = load i64, ptr %l12, !tbaa !24
  %t204 = load i64, ptr %l11, !tbaa !24
  %t207 = icmp slt i64 %t203, %t204
  %t209 = xor i1 %t207, true
  br i1 %t209, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s8)
  br label %bb58
bb32:
  br label %bb33
bb33:
  %t211 = load i64, ptr %l8, !tbaa !24
  %t212 = load i64, ptr %l12, !tbaa !24
  %t213 = load i64, ptr %l10, !tbaa !24
  %t216 = mul i64 %t212, %t213
  %t219 = add i64 %t211, %t216
  store i64 %t219, ptr %l13, !tbaa !24
  %t221 = load i64, ptr %l13, !tbaa !24
  %t223 = icmp sgt i64 %t221, 0
  br i1 %t223, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s9
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s9, ptr %l6, { i64, ptr } { i64 2, ptr @.d18 })
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_scope_close(ptr %s9)
  br label %bb37
bb37:
  %t226 = load ptr, ptr %l3, !tbaa !29
  %t227 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t227, ptr %l97, !tbaa !27
  %t228 = load i64, ptr %l13, !tbaa !24
  %t230 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !27
  %t232 = getelementptr i32, ptr %t231, i64 %t228
  %t233 = load i32, ptr %t232, !tbaa !33
  %t236 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t226, i32 %t233)
  store i32 %t236, ptr %l100
  br label %bb38
bb38:
  %t237 = load i32, ptr %l100, !tbaa !23
  store i32 %t237, ptr %l14, !tbaa !23
  %t238 = load ptr, ptr %l3, !tbaa !29
  %t239 = load i32, ptr %l14, !tbaa !23
  %t242 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t238, i32 %t239)
  store i1 %t242, ptr %l103
  br label %bb39
bb39:
  %t243 = load i1, ptr %l103, !tbaa !21
  br i1 %t243, label %bb40, label %bb41
bb40:
  %t244 = load ptr, ptr %l3, !tbaa !29
  %t245 = load i32, ptr %l14, !tbaa !23
  %t248 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t244, i32 %t245)
  store i32 %t248, ptr %l107
  br label %bb42
bb41:
  %t249 = load i32, ptr %l14, !tbaa !23
  store i32 %t249, ptr %l104, !tbaa !23
  br label %bb43
bb42:
  %t251 = load i32, ptr %l107, !tbaa !23
  store i32 %t251, ptr %l104, !tbaa !23
  br label %bb43
bb43:
  %t252 = load i32, ptr %l104, !tbaa !23
  store i32 %t252, ptr %l15, !tbaa !23
  %t253 = load ptr, ptr %l3, !tbaa !29
  %t254 = load i32, ptr %l14, !tbaa !23
  %t257 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t253, i32 %t254)
  store i32 %t257, ptr %l111
  br label %bb44
bb44:
  %t258 = load i32, ptr %l111
  %t260 = trunc i64 21 to i32
  %t261 = icmp eq i32 %t258, %t260
  br i1 %t261, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s10
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s10, ptr %l6, { i64, ptr } { i64 8, ptr @.d19 })
  br label %bb47
bb46:
  %t264 = load ptr, ptr %l3, !tbaa !29
  store ptr %t264, ptr %l115, !tbaa !29
  %t265 = load ptr, ptr %l3, !tbaa !29
  %t266 = load i32, ptr %l15, !tbaa !23
  %t269 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t265, i32 %t266)
  store i32 %t269, ptr %l118
  br label %bb48
bb47:
  call void @__olang_scope_close(ptr %s10)
  br label %bb56
bb48:
  %t270 = load ptr, ptr %l115, !tbaa !29
  %t271 = load i32, ptr %l118, !tbaa !23
  %t272 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t270, i32 %t271)
  store i32 %t272, ptr %l119
  br label %bb49
bb49:
  %t273 = load i32, ptr %l119
  %t275 = trunc i64 19 to i32
  %t276 = icmp eq i32 %t273, %t275
  br i1 %t276, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s12
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s12, ptr %l6, { i64, ptr } { i64 3, ptr @.d20 })
  br label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s13
  store ptr %l6, ptr %l123, !tbaa !29
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t280 = load i32, ptr %l14, !tbaa !23
  %t283 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s13, ptr %t279, i32 %t280)
  store { i64, ptr } %t283, ptr %l126
  br label %bb53
bb52:
  call void @__olang_scope_close(ptr %s12)
  br label %bb55
bb53:
  %t284 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t285 = extractvalue { i64, ptr } %t284, 0
  %t286 = extractvalue { i64, ptr } %t284, 1
  %t287 = mul i64 %t285, 1
  %t288 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t287)
  call void @llvm.memcpy.p0.p0.i64(ptr %t288, ptr %t286, i64 %t287, i1 false)
  %t289 = insertvalue { i64, ptr } undef, i64 %t285, 0
  %t290 = insertvalue { i64, ptr } %t289, ptr %t288, 1
  %t291 = load ptr, ptr %l123, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s13, ptr %t291, { i64, ptr } %t290)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s13)
  br label %bb55
bb55:
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s8)
  br label %bb57
bb57:
  %t293 = load i64, ptr %l12, !tbaa !24
  %t295 = add i64 %t293, 1
  store i64 %t295, ptr %l12, !tbaa !24
  br label %bb30
bb58:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } { i64 1, ptr @.d21 })
  br label %bb59
bb59:
  %t298 = load ptr, ptr %lp4
  %t299 = load { i64, ptr }, ptr %t298, !tbaa !27
  %t300 = load ptr, ptr @__olang_prog_scope
  %t303 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %t300, ptr %v1, ptr @G_2ecompiler_2femit_2emathInexact, { i64, ptr } %t299)
  store i1 %t303, ptr %l133
  br label %bb60
bb60:
  %t304 = load i1, ptr %l133, !tbaa !21
  br i1 %t304, label %bb61, label %bb62
bb61:
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t306 = load i32, ptr %l2, !tbaa !23
  %t309 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2emathParams(ptr %v0, ptr %s0, ptr %t305, i32 %t306)
  store { i64, ptr } %t309, ptr %l137
  br label %bb63
bb62:
  store i1 false, ptr %l134, !tbaa !21
  br label %bb65
bb63:
  %t310 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t311 = extractvalue { i64, ptr } %t310, 0
  %t312 = extractvalue { i64, ptr } %t310, 1
  %t313 = mul i64 %t311, 1
  %t314 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t313)
  call void @llvm.memcpy.p0.p0.i64(ptr %t314, ptr %t312, i64 %t313, i1 false)
  %t315 = insertvalue { i64, ptr } undef, i64 %t311, 0
  %t316 = insertvalue { i64, ptr } %t315, ptr %t314, 1
  %t318 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t316, { i64, ptr } { i64 0, ptr @.d22 })
  store i1 %t318, ptr %l139
  br label %bb64
bb64:
  %t319 = load i1, ptr %l139, !tbaa !21
  %t320 = xor i1 %t319, true
  store i1 %t320, ptr %l134, !tbaa !21
  br label %bb65
bb65:
  %t322 = load i1, ptr %l134, !tbaa !21
  br i1 %t322, label %bb66, label %bb67
bb66:
  store %olang.scope zeroinitializer, ptr %s15
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s15, ptr %l6, { i64, ptr } { i64 24, ptr @.d23 })
  br label %bb68
bb67:
  br label %bb69
bb68:
  call void @__olang_scope_close(ptr %s15)
  br label %bb69
bb69:
  %t324 = load ptr, ptr %l0, !tbaa !29
  store ptr %t324, ptr %l142, !tbaa !29
  %t325 = load ptr, ptr %lp4
  %t326 = load { i64, ptr }, ptr %t325, !tbaa !27
  store { i64, ptr } %t326, ptr %l143, !tbaa !27
  %t328 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l6)
  store { i64, ptr } %t328, ptr %l145
  br label %bb70
bb70:
  %t329 = load ptr, ptr %l142, !tbaa !29
  %t330 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t331 = load { i64, ptr }, ptr %l145, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %v1, ptr %s0, ptr %t329, { i64, ptr } %t330, { i64, ptr } %t331)
  br label %bb71
bb71:
  %t332 = load ptr, ptr %lp4
  %t333 = load { i64, ptr }, ptr %t332, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t333, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobalSym(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l8 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 5
  %t13 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t9, i64 %a1)
  store ptr %t13, ptr %l8
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t16 = getelementptr %"compiler/load:Module", ptr %t14, i32 0, i32 2
  %t17 = load { i64, ptr }, ptr %t16, !tbaa !27
  store { i64, ptr } %t17, ptr %l10, !tbaa !27
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t22 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %t18, i32 %a2)
  store { i64, ptr } %t22, ptr %l13
  br label %bb2
bb2:
  %t23 = extractvalue { i64, ptr } { i64 2, ptr @.d24 }, 1
  %t24 = extractvalue { i64, ptr } { i64 2, ptr @.d24 }, 0
  %t25 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t25, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = add i64 %t24, %t27
  %t29 = extractvalue { i64, ptr } { i64 1, ptr @.d25 }, 1
  %t30 = extractvalue { i64, ptr } { i64 1, ptr @.d25 }, 0
  %t31 = add i64 %t28, %t30
  %t32 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 1
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t35 = add i64 %t31, %t34
  %t36 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t35)
  call void @olang_textcopy(ptr %t36, ptr %t23, i64 %t24)
  %t37 = getelementptr i8, ptr %t36, i64 %t24
  call void @olang_textcopy(ptr %t37, ptr %t26, i64 %t27)
  %t38 = getelementptr i8, ptr %t37, i64 %t27
  call void @olang_textcopy(ptr %t38, ptr %t29, i64 %t30)
  %t39 = getelementptr i8, ptr %t38, i64 %t30
  call void @olang_textcopy(ptr %t39, ptr %t33, i64 %t34)
  %t40 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t36, 1
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t44 = extractvalue { i64, ptr } %t41, 1
  %t45 = mul i64 %t43, 1
  %t46 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t45)
  call void @llvm.memcpy.p0.p0.i64(ptr %t46, ptr %t44, i64 %t45, i1 false)
  %t47 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  %t50 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v1, ptr %v1, { i64, ptr } %t48)
  store { i64, ptr } %t50, ptr %l16
  br label %bb3
bb3:
  %t51 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t51, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2egroupOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 14
  %t7 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store { i64, ptr } %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t11 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t9, { i64, ptr } { i64 11, ptr @.d26 })
  store i1 %t11, ptr %l8
  br label %bb2
bb2:
  %t12 = load i1, ptr %l8, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb6
bb4:
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t15 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t13, { i64, ptr } { i64 4, ptr @.d27 })
  store i1 %t15, ptr %l11
  br label %bb5
bb5:
  %t16 = load i1, ptr %l11, !tbaa !21
  store i1 %t16, ptr %l9, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l9, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i64 1, ptr %l12, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l12, !tbaa !24
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t18 = load i64, ptr %l12, !tbaa !24
  store i64 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehead(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 20
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t5 = extractvalue { i64, ptr } { i64 85, ptr @.d28 }, 1
  %t6 = extractvalue { i64, ptr } { i64 85, ptr @.d28 }, 0
  %t8 = extractvalue { i64, ptr } %t4, 1
  %t9 = extractvalue { i64, ptr } %t4, 0
  %t10 = add i64 %t6, %t9
  %t11 = extractvalue { i64, ptr } { i64 3, ptr @.d29 }, 1
  %t12 = extractvalue { i64, ptr } { i64 3, ptr @.d29 }, 0
  %t13 = add i64 %t10, %t12
  %t14 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t13)
  call void @olang_textcopy(ptr %t14, ptr %t5, i64 %t6)
  %t15 = getelementptr i8, ptr %t14, i64 %t6
  call void @olang_textcopy(ptr %t15, ptr %t8, i64 %t9)
  %t16 = getelementptr i8, ptr %t15, i64 %t9
  call void @olang_textcopy(ptr %t16, ptr %t11, i64 %t12)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t14, 1
  store { i64, ptr } %t18, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehomeOf(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i64
  %l22 = alloca ptr
  %l30 = alloca i32
  %l32 = alloca i64
  %l34 = alloca ptr
  %l37 = alloca i64
  %l38 = alloca i64
  %l45 = alloca i64
  %l49 = alloca i64
  %l55 = alloca i64
  %l75 = alloca i64
  %rv = alloca i64
  %t147 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load { i64, [1 x i64] }, ptr %l1
  %t8 = extractvalue { i64, [1 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  store i32 %t13, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  br label %bb40
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/emit:Emitter", ptr %t15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/lower:Lowerer", ptr %t18, i32 0, i32 1
  %t21 = load i32, ptr %l3, !tbaa !23
  %t23 = sext i32 %t21 to i64
  %t26 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t20, i64 %t23)
  store ptr %t26, ptr %l22
  br label %bb4
bb4:
  %t27 = load ptr, ptr %l22, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Body", ptr %t27, i32 0, i32 1
  %t30 = load { i64, [2 x i64] }, ptr %t29
  store { i64, [2 x i64] } %t30, ptr %l4
  %t32 = load { i64, [2 x i64] }, ptr %l4
  %t34 = extractvalue { i64, [2 x i64] } %t32, 0
  %t35 = icmp eq i64 %t34, 0
  br i1 %t35, label %bb5, label %bb6
bb5:
  %t37 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t38 = getelementptr { i64 }, ptr %t37, i32 0, i32 0
  %t39 = load i64, ptr %t38
  store i64 %t39, ptr %l5, !tbaa !24
  br label %bb7
bb6:
  br label %bb14
bb7:
  %t41 = load ptr, ptr %l2, !tbaa !29
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t41, i64 %t42)
  store i32 %t45, ptr %l30
  br label %bb8
bb8:
  %t46 = load i32, ptr %l30, !tbaa !23
  %t47 = icmp ne i32 %t46, 0
  br i1 %t47, label %bb9, label %bb10
bb9:
  %t49 = load i64, ptr @G_2ecompiler_2femit_2eHomeInst, !tbaa !24
  store i64 %t49, ptr %l32, !tbaa !24
  br label %bb13
bb10:
  %t51 = load ptr, ptr %l2, !tbaa !29
  store ptr %t51, ptr %l34, !tbaa !29
  %t52 = load ptr, ptr %l2, !tbaa !29
  %t53 = load i64, ptr %l5, !tbaa !24
  %t56 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t52, i64 %t53)
  store i64 %t56, ptr %l37
  br label %bb11
bb11:
  %t57 = load ptr, ptr %l34, !tbaa !29
  %t58 = load i64, ptr %l37, !tbaa !24
  %t59 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t57, i64 %t58)
  store i64 %t59, ptr %l38
  br label %bb12
bb12:
  %t60 = load i64, ptr %l38, !tbaa !24
  store i64 %t60, ptr %l32, !tbaa !24
  br label %bb13
bb13:
  %t61 = load i64, ptr %l32, !tbaa !24
  store i64 %t61, ptr %rv
  br label %ret
bb14:
  %t62 = load { i64, [2 x i64] }, ptr %l4
  %t64 = extractvalue { i64, [2 x i64] } %t62, 0
  %t65 = icmp eq i64 %t64, 1
  br i1 %t65, label %bb15, label %bb16
bb15:
  %t67 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t68 = getelementptr { i32, i32 }, ptr %t67, i32 0, i32 0
  %t69 = load i32, ptr %t68
  store i32 %t69, ptr %l6, !tbaa !23
  %t71 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t72 = getelementptr { i32, i32 }, ptr %t71, i32 0, i32 1
  %t73 = load i32, ptr %t72
  store i32 %t73, ptr %l7, !tbaa !23
  br label %bb17
bb16:
  br label %bb22
bb17:
  %t75 = load i32, ptr %l7, !tbaa !23
  %t77 = icmp ne i32 %t75, 0
  br i1 %t77, label %bb18, label %bb19
bb18:
  %t79 = load i64, ptr @G_2ecompiler_2femit_2eHomeInst, !tbaa !24
  store i64 %t79, ptr %l45, !tbaa !24
  br label %bb21
bb19:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load i32, ptr %l6, !tbaa !23
  %t85 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2etypeHome(ptr %v0, ptr %t81, i32 %t82)
  store i64 %t85, ptr %l49
  br label %bb20
bb20:
  %t86 = load i64, ptr %l49, !tbaa !24
  store i64 %t86, ptr %l45, !tbaa !24
  br label %bb21
bb21:
  %t87 = load i64, ptr %l45, !tbaa !24
  store i64 %t87, ptr %rv
  br label %ret
bb22:
  %t88 = load { i64, [2 x i64] }, ptr %l4
  %t90 = extractvalue { i64, [2 x i64] } %t88, 0
  %t91 = icmp eq i64 %t90, 3
  br i1 %t91, label %bb23, label %bb24
bb23:
  %t93 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t94 = getelementptr { i32 }, ptr %t93, i32 0, i32 0
  %t95 = load i32, ptr %t94
  store i32 %t95, ptr %l8, !tbaa !23
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load i32, ptr %l8, !tbaa !23
  %t101 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2etypeHome(ptr %v0, ptr %t97, i32 %t98)
  store i64 %t101, ptr %l55
  br label %bb26
bb26:
  %t102 = load i64, ptr %l55, !tbaa !24
  store i64 %t102, ptr %rv
  br label %ret
bb27:
  %t103 = load { i64, [2 x i64] }, ptr %l4
  %t105 = extractvalue { i64, [2 x i64] } %t103, 0
  %t106 = icmp eq i64 %t105, 6
  br i1 %t106, label %bb28, label %bb29
bb28:
  %t108 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t109 = getelementptr { i64, i32 }, ptr %t108, i32 0, i32 0
  %t110 = load i64, ptr %t109
  store i64 %t110, ptr %l9, !tbaa !24
  br label %bb30
bb29:
  br label %bb31
bb30:
  %t112 = load i64, ptr %l9, !tbaa !24
  store i64 %t112, ptr %rv
  br label %ret
bb31:
  %t114 = load { i64, [2 x i64] }, ptr %l4
  %t116 = extractvalue { i64, [2 x i64] } %t114, 0
  %t117 = icmp eq i64 %t116, 5
  br i1 %t117, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  %t119 = load ptr, ptr %l2, !tbaa !29
  %t121 = getelementptr %"compiler/generic:Program", ptr %t119, i32 0, i32 0
  %t122 = load ptr, ptr %t121, !tbaa !29
  %t124 = getelementptr %"compiler/load:Loader", ptr %t122, i32 0, i32 7
  %t125 = load i64, ptr %t124, !tbaa !24
  store i64 %t125, ptr %rv
  br label %ret
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  %t127 = load i64, ptr @G_2ecompiler_2femit_2eHomeLocal, !tbaa !24
  store i64 %t127, ptr %rv
  br label %ret
bb39:
  call void @__olang_check_failed(ptr @olang_loc_884b1f134ce8f58_4f25fcbaf6ee0184)
  unreachable
bb40:
  %t129 = load { i64, [1 x i64] }, ptr %l1
  %t131 = extractvalue { i64, [1 x i64] } %t129, 0
  %t132 = icmp eq i64 %t131, 2
  br i1 %t132, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  %t134 = load i64, ptr @G_2ecompiler_2femit_2eHomeShared, !tbaa !24
  store i64 %t134, ptr %rv
  br label %ret
bb44:
  %t136 = load { i64, [1 x i64] }, ptr %l1
  %t138 = extractvalue { i64, [1 x i64] } %t136, 0
  %t139 = icmp eq i64 %t138, 1
  br i1 %t139, label %bb45, label %bb46
bb45:
  %t141 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t142 = getelementptr { i32 }, ptr %t141, i32 0, i32 0
  %t143 = load i32, ptr %t142
  store i32 %t143, ptr %l10, !tbaa !23
  br label %bb47
bb46:
  br label %bb49
bb47:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load i32, ptr %l10, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t147
  %t148 = getelementptr { i64, [1 x i64] }, ptr %t147, i32 0, i32 0
  store i64 0, ptr %t148
  %t150 = insertvalue { i32 } undef, i32 %t146, 0
  %t151 = getelementptr { i64, [1 x i64] }, ptr %t147, i32 0, i32 1
  store { i32 } %t150, ptr %t151
  %t152 = load { i64, [1 x i64] }, ptr %t147
  %t155 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehomeOf(ptr %v0, ptr %t145, { i64, [1 x i64] } %t152)
  store i64 %t155, ptr %l75
  br label %bb48
bb48:
  %t156 = load i64, ptr %l75, !tbaa !24
  store i64 %t156, ptr %rv
  br label %ret
bb49:
  %t157 = load { i64, [1 x i64] }, ptr %l1
  %t159 = extractvalue { i64, [1 x i64] } %t157, 0
  %t160 = icmp eq i64 %t159, 3
  br i1 %t160, label %bb50, label %bb51
bb50:
  %t162 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t163 = getelementptr { i64 }, ptr %t162, i32 0, i32 0
  %t164 = load i64, ptr %t163
  store i64 %t164, ptr %l11, !tbaa !24
  br label %bb52
bb51:
  br label %bb53
bb52:
  %t166 = load i64, ptr %l11, !tbaa !24
  store i64 %t166, ptr %rv
  br label %ret
bb53:
  call void @__olang_check_failed(ptr @olang_loc_77c745ca54276229_8072b8e8f7d66d75)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2einitOrder(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l2 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %lp11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l21 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l23 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l29 = alloca i64
  %l33 = alloca i64
  %l36 = alloca i64
  %l56 = alloca ptr
  %l72 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l74 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l78 = alloca i32
  %l87 = alloca { i64, ptr }
  %l93 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2flower_2ecompiler_2flower_3aLowerer_2eInitModules(ptr %v0, ptr %s0, ptr %t4)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l21
  br label %bb1
bb1:
  %t7 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l21
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l1
  %t8 = load ptr, ptr @__olang_prog_scope
  %t9 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t8)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l22
  br label %bb2
bb2:
  %t10 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l22
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l2
  %t11 = load ptr, ptr @__olang_prog_scope
  %t12 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t11)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l23
  br label %bb3
bb3:
  %t13 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l23
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l3
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/emit:Emitter", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 0
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/load:Loader", ptr %t20, i32 0, i32 5
  %t23 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t22
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %l4
  store i64 0, ptr %l5, !tbaa !24
  %t26 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %l4)
  store i64 %t26, ptr %l29
  br label %bb4
bb4:
  %t27 = load i64, ptr %l29, !tbaa !24
  store i64 %t27, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t28 = load i64, ptr %l6, !tbaa !24
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = icmp sgt i64 %t28, %t29
  br i1 %t32, label %bb5, label %bb6
bb5:
  %t34 = load i64, ptr %l7, !tbaa !24
  %t36 = icmp sgt i64 %t34, 0
  br i1 %t36, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb10
bb7:
  %t38 = load i64, ptr %l6, !tbaa !24
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = sub i64 %t38, %t39
  %t43 = load i64, ptr %l7, !tbaa !24
  %t46 = add i64 %t42, %t43
  %t48 = sub i64 %t46, 1
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = sdiv i64 %t48, %t49
  store i64 %t52, ptr %l36, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb9
bb9:
  %t54 = load i64, ptr %l36, !tbaa !24
  store i64 %t54, ptr %l33, !tbaa !24
  br label %bb10
bb10:
  %t55 = load i64, ptr %l33, !tbaa !24
  store i64 %t55, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t56 = load i64, ptr %l9, !tbaa !24
  %t57 = load i64, ptr %l8, !tbaa !24
  %t60 = icmp slt i64 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb13:
  br label %bb14
bb14:
  %t64 = load i64, ptr %l5, !tbaa !24
  %t65 = load i64, ptr %l9, !tbaa !24
  %t66 = load i64, ptr %l7, !tbaa !24
  %t69 = mul i64 %t65, %t66
  %t72 = add i64 %t64, %t69
  store i64 %t72, ptr %l10, !tbaa !24
  %t74 = load i64, ptr %l10, !tbaa !24
  %t77 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %l4, i64 %t74)
  store ptr %t77, ptr %l56
  br label %bb15
bb15:
  %t78 = load ptr, ptr %l56, !tbaa !29
  %t80 = getelementptr %"compiler/load:Module", ptr %t78, i32 0, i32 3
  %t81 = load i1, ptr %t80, !tbaa !21
  br i1 %t81, label %bb16, label %bb17
bb16:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i64, ptr %l10, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2evisit(ptr %v0, ptr %s0, ptr %s0, ptr %t83, i64 %t84, ptr %l2, ptr %l3)
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  %t89 = load i64, ptr %l9, !tbaa !24
  %t91 = add i64 %t89, 1
  store i64 %t91, ptr %l9, !tbaa !24
  br label %bb11
bb21:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/emit:Emitter", ptr %t94, i32 0, i32 0
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t99 = getelementptr %"compiler/generic:Program", ptr %t97, i32 0, i32 0
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/load:Loader", ptr %t100, i32 0, i32 7
  %t103 = load i64, ptr %t102, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2evisit(ptr %v0, ptr %s0, ptr %s0, ptr %t93, i64 %t103, ptr %l2, ptr %l3)
  br label %bb22
bb22:
  %t108 = load ptr, ptr @__olang_prog_scope
  %t109 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t108)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t109, ptr %l72
  br label %bb23
bb23:
  %t110 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t110, ptr %lp11
  %t111 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l72
  %t112 = load ptr, ptr %lp11
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t111, ptr %t112
  store ptr %l3, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s6
  %t114 = load ptr, ptr %l12, !tbaa !29
  %t115 = load i64, ptr %l13, !tbaa !24
  %t118 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s0, ptr %t114, i64 %t115)
  %t119 = extractvalue { i32, { i64, ptr } } %t118, 1
  %t120 = extractvalue { i32, { i64, ptr } } %t118, 0
  store i32 %t120, ptr %l78
  %t121 = icmp ne i32 %t120, 0
  br i1 %t121, label %bb26, label %ok.122
ok.122:
  store { i64, ptr } %t119, ptr %l77
  br label %bb25
bb25:
  %t123 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t123, ptr %l74, !tbaa !27
  br label %bb30
bb26:
  %t124 = load i32, ptr %l78, !tbaa !23
  %t125 = ashr i32 %t124, 16
  %t127 = icmp eq i32 %t125, 1
  br i1 %t127, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_7e34c17454aff800_e19f636b4fbc434)
  unreachable
bb29:
  call void @__olang_scope_close(ptr %s6)
  br label %bb43
bb30:
  %t129 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t129, ptr %l14, !tbaa !27
  %t130 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t130, 0
  store i64 %t132, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s7
  %t134 = load i64, ptr %l16, !tbaa !24
  %t135 = load i64, ptr %l15, !tbaa !24
  %t138 = icmp slt i64 %t134, %t135
  %t140 = xor i1 %t138, true
  br i1 %t140, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s7)
  br label %bb41
bb33:
  br label %bb34
bb34:
  %t142 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t142, ptr %l87, !tbaa !27
  %t143 = load i64, ptr %l16, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr i64, ptr %t146, i64 %t143
  %t148 = load i64, ptr %t147, !tbaa !34
  store i64 %t148, ptr %l17, !tbaa !24
  %t150 = load i64, ptr %l17, !tbaa !24
  %t155 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eHas_3cI64_3e(ptr %s0, ptr %l1, i64 %t150)
  store i1 %t155, ptr %l93
  br label %bb35
bb35:
  %t156 = load i1, ptr %l93, !tbaa !21
  br i1 %t156, label %bb36, label %bb37
bb36:
  %t157 = load ptr, ptr %lp11
  %t158 = load i64, ptr %l17, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t157, i64 %t158)
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s7)
  br label %bb40
bb40:
  %t161 = load i64, ptr %l16, !tbaa !24
  %t163 = add i64 %t161, 1
  store i64 %t163, ptr %l16, !tbaa !24
  br label %bb31
bb41:
  %t165 = load i64, ptr %l13, !tbaa !24
  %t166 = load i64, ptr %l15, !tbaa !24
  %t169 = add i64 %t165, %t166
  store i64 %t169, ptr %l13, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb42
bb42:
  br label %bb24
bb43:
  %t171 = load ptr, ptr %lp11
  %t172 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t171
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t172, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2einstGroupOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %a0, i32 0, i32 65
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %a1)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l7
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11
ok.11:
  store i64 %t8, ptr %l6
  br label %bb1
bb1:
  %t12 = load i64, ptr %l6, !tbaa !24
  store i64 %t12, ptr %l2, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l2, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l2, !tbaa !24
  store i64 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2emergeSame(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l23 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l34 = alloca { i64, ptr }
  %l35 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l45 = alloca %"std/prelude/text:StringBuilder"
  %l46 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca { i64, ptr }
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca { i64, ptr }
  %l62 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca %"std/prelude/text:StringBuilder"
  %l70 = alloca { i64, ptr }
  %l71 = alloca i64
  %l72 = alloca i64
  %l74 = alloca { i64, ptr }
  %l75 = alloca i64
  %l76 = alloca { i64, ptr }
  %l77 = alloca i64
  %l78 = alloca i64
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca i64
  %l83 = alloca i64
  %l84 = alloca i64
  %l85 = alloca i64
  %l86 = alloca i64
  %l87 = alloca i64
  %l88 = alloca i64
  %l89 = alloca i64
  %l90 = alloca i64
  %l91 = alloca i64
  %l92 = alloca i64
  %l100 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l101 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l104 = alloca i64
  %l108 = alloca i64
  %l111 = alloca i64
  %l132 = alloca i64
  %l136 = alloca i1
  %l146 = alloca i64
  %l148 = alloca i64
  %l153 = alloca i64
  %l159 = alloca { i64, ptr }
  %l162 = alloca { i64, ptr }
  %l168 = alloca i64
  %l171 = alloca i64
  %l189 = alloca { i64, ptr }
  %l193 = alloca i64
  %l195 = alloca ptr
  %l196 = alloca { i64, ptr }
  %l197 = alloca { i64, ptr }
  %l200 = alloca i64
  %l201 = alloca { i64, ptr }
  %l204 = alloca i64
  %l205 = alloca i64
  %l210 = alloca i64
  %l211 = alloca i32
  %l214 = alloca i1
  %l217 = alloca i1
  %l218 = alloca i1
  %l222 = alloca i64
  %l225 = alloca i1
  %l229 = alloca i64
  %l238 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l239 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l242 = alloca i64
  %l246 = alloca i64
  %l249 = alloca i64
  %l270 = alloca i64
  %l274 = alloca { i64, ptr }
  %l277 = alloca i1
  %l282 = alloca i1
  %l284 = alloca i1
  %l285 = alloca i1
  %l289 = alloca i1
  %l291 = alloca i1
  %l292 = alloca ptr
  %l293 = alloca i64
  %l295 = alloca i64
  %l301 = alloca i64
  %l304 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l305 = alloca i64
  %l309 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l314 = alloca i64
  %l317 = alloca i64
  %l337 = alloca i64
  %l341 = alloca { i64, ptr }
  %l344 = alloca { i64, ptr }
  %l345 = alloca %"std/prelude/text:StringBuilder"
  %l346 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l352 = alloca i64
  %l355 = alloca i64
  %l373 = alloca { i64, ptr }
  %l377 = alloca i64
  %l379 = alloca ptr
  %l380 = alloca { i64, ptr }
  %l381 = alloca { i64, ptr }
  %l384 = alloca i64
  %l385 = alloca { i64, ptr }
  %l388 = alloca i64
  %l389 = alloca i64
  %l394 = alloca i64
  %l395 = alloca i32
  %l398 = alloca i1
  %l402 = alloca i64
  %l405 = alloca ptr
  %l406 = alloca { i64, ptr }
  %l407 = alloca i64
  %l408 = alloca { i64, ptr }
  %l411 = alloca i64
  %l412 = alloca i64
  %l420 = alloca { i64, ptr }
  %l421 = alloca i64
  %l423 = alloca i64
  %l424 = alloca i32
  %l425 = alloca ptr
  %l426 = alloca { i64, ptr }
  %l427 = alloca i64
  %l430 = alloca i64
  %l431 = alloca i64
  %l436 = alloca { i64, ptr }
  %l440 = alloca i64
  %l443 = alloca i64
  %l444 = alloca i32
  %l447 = alloca ptr
  %l448 = alloca { i64, ptr }
  %l449 = alloca i64
  %l450 = alloca { i64, ptr }
  %l453 = alloca i64
  %l454 = alloca i64
  %l459 = alloca { i64, ptr }
  %l467 = alloca ptr
  %l468 = alloca { i64, ptr }
  %l469 = alloca i64
  %l472 = alloca i64
  %l473 = alloca i64
  %l479 = alloca { i64, ptr }
  %l480 = alloca i64
  %l483 = alloca i64
  %l484 = alloca i32
  %l488 = alloca i64
  %l496 = alloca ptr
  %l498 = alloca { i64, ptr }
  %l502 = alloca i64
  %l507 = alloca i64
  %l511 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l516 = alloca i64
  %l519 = alloca i64
  %l537 = alloca %"std/prelude/text:StringBuilder"
  %l545 = alloca { i64, ptr }
  %l552 = alloca { i64, ptr }
  %l563 = alloca { i64, ptr }
  %l564 = alloca i64
  %l567 = alloca i64
  %l568 = alloca i32
  %l572 = alloca i64
  %l582 = alloca { i64, ptr }
  %l584 = alloca i64
  %l586 = alloca i64
  %l587 = alloca { i64, ptr }
  %l589 = alloca i64
  %l593 = alloca i64
  %l594 = alloca i64
  %l602 = alloca i64
  %l605 = alloca i64
  %l631 = alloca ptr
  %l634 = alloca i64
  %l635 = alloca i64
  %l636 = alloca ptr
  %l639 = alloca i64
  %l640 = alloca i64
  %l644 = alloca i1
  %l648 = alloca i1
  %l650 = alloca ptr
  %l653 = alloca i64
  %l654 = alloca { i64, ptr }
  %l656 = alloca ptr
  %l659 = alloca i64
  %l660 = alloca { i64, ptr }
  %l661 = alloca i1
  %l671 = alloca i64
  %l674 = alloca i64
  %l699 = alloca ptr
  %l702 = alloca i64
  %l705 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s42 = alloca %olang.scope
  %s48 = alloca %olang.scope
  %t1130 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 58
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/emit:Emitter", ptr %t6, i32 0, i32 58
  store i1 true, ptr %t8, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/emit:Emitter", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/generic:Program", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/load:Loader", ptr %t15, i32 0, i32 7
  %t18 = load i64, ptr %t17, !tbaa !24
  store i64 %t18, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr @__olang_prog_scope
  %t21 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t20)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, ptr %l100
  br label %bb4
bb4:
  %t22 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l100
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l2
  %t23 = load ptr, ptr @__olang_prog_scope
  %t24 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t23)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l101
  br label %bb5
bb5:
  %t25 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l101
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/emit:Emitter", ptr %t26, i32 0, i32 14
  %t30 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t28)
  store i64 %t30, ptr %l104
  br label %bb6
bb6:
  %t31 = load i64, ptr %l104, !tbaa !24
  store i64 %t31, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t32 = load i64, ptr %l5, !tbaa !24
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = icmp sgt i64 %t32, %t33
  br i1 %t36, label %bb7, label %bb8
bb7:
  %t38 = load i64, ptr %l6, !tbaa !24
  %t40 = icmp sgt i64 %t38, 0
  br i1 %t40, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l108, !tbaa !24
  br label %bb12
bb9:
  %t42 = load i64, ptr %l5, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = sub i64 %t42, %t43
  %t47 = load i64, ptr %l6, !tbaa !24
  %t50 = add i64 %t46, %t47
  %t52 = sub i64 %t50, 1
  %t53 = load i64, ptr %l6, !tbaa !24
  %t56 = sdiv i64 %t52, %t53
  store i64 %t56, ptr %l111, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l111, !tbaa !24
  br label %bb11
bb11:
  %t58 = load i64, ptr %l111, !tbaa !24
  store i64 %t58, ptr %l108, !tbaa !24
  br label %bb12
bb12:
  %t59 = load i64, ptr %l108, !tbaa !24
  store i64 %t59, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t60 = load i64, ptr %l8, !tbaa !24
  %t61 = load i64, ptr %l7, !tbaa !24
  %t64 = icmp slt i64 %t60, %t61
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb27
bb15:
  br label %bb16
bb16:
  %t68 = load i64, ptr %l4, !tbaa !24
  %t69 = load i64, ptr %l8, !tbaa !24
  %t70 = load i64, ptr %l6, !tbaa !24
  %t73 = mul i64 %t69, %t70
  %t76 = add i64 %t68, %t73
  store i64 %t76, ptr %l9, !tbaa !24
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/emit:Emitter", ptr %t78, i32 0, i32 16
  %t81 = load i64, ptr %l9, !tbaa !24
  %t84 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t80, i64 %t81)
  store i64 %t84, ptr %l132
  br label %bb17
bb17:
  %t85 = load i64, ptr %l132, !tbaa !24
  store i64 %t85, ptr %l10, !tbaa !24
  %t86 = load i64, ptr %l10, !tbaa !24
  %t87 = load i64, ptr @G_2ecompiler_2femit_2eHomeInst, !tbaa !24
  %t90 = icmp eq i64 %t86, %t87
  br i1 %t90, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l136, !tbaa !21
  br label %bb20
bb19:
  %t92 = load i64, ptr %l10, !tbaa !24
  %t93 = load i64, ptr %l1, !tbaa !24
  %t96 = icmp eq i64 %t92, %t93
  store i1 %t96, ptr %l136, !tbaa !21
  br label %bb20
bb20:
  %t98 = load i1, ptr %l136, !tbaa !21
  br i1 %t98, label %bb21, label %bb22
bb21:
  %t99 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s0, ptr %l2, i64 %t99, i1 true)
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t102 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t102)
  br label %bb24
bb24:
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s3)
  br label %bb26
bb26:
  %t105 = load i64, ptr %l8, !tbaa !24
  %t107 = add i64 %t105, 1
  store i64 %t107, ptr %l8, !tbaa !24
  br label %bb13
bb27:
  store i64 0, ptr %l11, !tbaa !24
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s6
  %t109 = load i64, ptr %l11, !tbaa !24
  store i64 %t109, ptr %l146, !tbaa !24
  %t111 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l3)
  store i64 %t111, ptr %l148
  br label %bb29
bb29:
  %t112 = load i64, ptr %l146, !tbaa !24
  %t113 = load i64, ptr %l148, !tbaa !24
  %t114 = icmp slt i64 %t112, %t113
  %t116 = xor i1 %t114, true
  br i1 %t116, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s6)
  br label %bb79
bb31:
  br label %bb32
bb32:
  %t118 = load i64, ptr %l11, !tbaa !24
  %t121 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l3, i64 %t118)
  store i64 %t121, ptr %l153
  br label %bb33
bb33:
  %t122 = load i64, ptr %l153, !tbaa !24
  store i64 %t122, ptr %l12, !tbaa !24
  %t123 = load i64, ptr %l11, !tbaa !24
  %t125 = add i64 %t123, 1
  store i64 %t125, ptr %l11, !tbaa !24
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/emit:Emitter", ptr %t127, i32 0, i32 15
  %t130 = load i64, ptr %l12, !tbaa !24
  %t133 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t129, i64 %t130)
  store { i64, ptr } %t133, ptr %l159
  br label %bb34
bb34:
  %t134 = load { i64, ptr }, ptr %l159, !tbaa !27
  store { i64, ptr } %t134, ptr %l13, !tbaa !27
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load i64, ptr %l12, !tbaa !24
  %t139 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2erefs(ptr %v0, ptr %t135, i64 %t136)
  store { i64, ptr } %t139, ptr %l162
  br label %bb35
bb35:
  %t140 = load { i64, ptr }, ptr %l162, !tbaa !27
  store { i64, ptr } %t140, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t141 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t141, 0
  store i64 %t143, ptr %l16, !tbaa !24
  store i64 3, ptr %l17, !tbaa !24
  %t145 = load i64, ptr %l16, !tbaa !24
  %t146 = load i64, ptr %l15, !tbaa !24
  %t149 = icmp sgt i64 %t145, %t146
  br i1 %t149, label %bb36, label %bb37
bb36:
  %t151 = load i64, ptr %l17, !tbaa !24
  %t153 = icmp sgt i64 %t151, 0
  br i1 %t153, label %bb38, label %bb39
bb37:
  store i64 0, ptr %l168, !tbaa !24
  br label %bb41
bb38:
  %t155 = load i64, ptr %l16, !tbaa !24
  %t156 = load i64, ptr %l15, !tbaa !24
  %t159 = sub i64 %t155, %t156
  %t160 = load i64, ptr %l17, !tbaa !24
  %t163 = add i64 %t159, %t160
  %t165 = sub i64 %t163, 1
  %t166 = load i64, ptr %l17, !tbaa !24
  %t169 = sdiv i64 %t165, %t166
  store i64 %t169, ptr %l171, !tbaa !24
  br label %bb40
bb39:
  store i64 0, ptr %l171, !tbaa !24
  br label %bb40
bb40:
  %t171 = load i64, ptr %l171, !tbaa !24
  store i64 %t171, ptr %l168, !tbaa !24
  br label %bb41
bb41:
  %t172 = load i64, ptr %l168, !tbaa !24
  store i64 %t172, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb42
bb42:
  store %olang.scope zeroinitializer, ptr %s8
  %t173 = load i64, ptr %l19, !tbaa !24
  %t174 = load i64, ptr %l18, !tbaa !24
  %t177 = icmp slt i64 %t173, %t174
  %t179 = xor i1 %t177, true
  br i1 %t179, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s8)
  br label %bb77
bb44:
  br label %bb45
bb45:
  %t181 = load i64, ptr %l15, !tbaa !24
  %t182 = load i64, ptr %l19, !tbaa !24
  %t183 = load i64, ptr %l17, !tbaa !24
  %t186 = mul i64 %t182, %t183
  %t189 = add i64 %t181, %t186
  store i64 %t189, ptr %l20, !tbaa !24
  %t191 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t191, ptr %l189, !tbaa !27
  %t192 = load i64, ptr %l20, !tbaa !24
  %t194 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !27
  %t196 = getelementptr i64, ptr %t195, i64 %t192
  %t197 = load i64, ptr %t196, !tbaa !34
  %t199 = icmp ne i64 %t197, 0
  br i1 %t199, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s8)
  br label %bb76
bb47:
  br label %bb48
bb48:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"compiler/emit:Emitter", ptr %t201, i32 0, i32 18
  store ptr %t203, ptr %l195, !tbaa !29
  %t204 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t204, ptr %l196, !tbaa !27
  %t205 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t205, ptr %l197, !tbaa !27
  %t206 = load i64, ptr %l20, !tbaa !24
  %t208 = add i64 %t206, 1
  %t210 = getelementptr { i64, ptr }, ptr %l197, i32 0, i32 1
  %t211 = load ptr, ptr %t210, !tbaa !27
  %t212 = getelementptr i64, ptr %t211, i64 %t208
  %t213 = load i64, ptr %t212, !tbaa !34
  store i64 %t213, ptr %l200, !tbaa !24
  %t214 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t214, ptr %l201, !tbaa !27
  %t215 = load i64, ptr %l20, !tbaa !24
  %t217 = add i64 %t215, 2
  %t219 = getelementptr { i64, ptr }, ptr %l201, i32 0, i32 1
  %t220 = load ptr, ptr %t219, !tbaa !27
  %t221 = getelementptr i64, ptr %t220, i64 %t217
  %t222 = load i64, ptr %t221, !tbaa !34
  store i64 %t222, ptr %l204, !tbaa !24
  %t223 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t224 = extractvalue { i64, ptr } %t223, 0
  store i64 %t224, ptr %l205, !tbaa !24
  %t225 = load i64, ptr %l200, !tbaa !24
  %t226 = icmp sge i64 %t225, 0
  br i1 %t226, label %bb49, label %bb50
bb49:
  %t228 = load i64, ptr %l200, !tbaa !24
  %t229 = load i64, ptr %l204, !tbaa !24
  %t230 = icmp sle i64 %t228, %t229
  br i1 %t230, label %bb51, label %bb52
bb50:
  call void @__olang_check_failed(ptr @olang_loc_de92fa5f00317f7b_3680b631254dc667)
  unreachable
bb51:
  %t232 = load i64, ptr %l204, !tbaa !24
  %t233 = load i64, ptr %l205, !tbaa !24
  %t234 = icmp sle i64 %t232, %t233
  br i1 %t234, label %bb53, label %bb54
bb52:
  call void @__olang_check_failed(ptr @olang_loc_de92fa5f00317f7b_3680b631254dc667)
  unreachable
bb53:
  %t236 = getelementptr { i64, ptr }, ptr %l196, i32 0, i32 1
  %t237 = load ptr, ptr %t236, !tbaa !27
  %t238 = load i64, ptr %l200, !tbaa !24
  %t239 = load i64, ptr %l204, !tbaa !24
  %t240 = getelementptr i8, ptr %t237, i64 %t238
  %t241 = sub i64 %t239, %t238
  %t242 = insertvalue { i64, ptr } undef, i64 %t241, 0
  %t243 = insertvalue { i64, ptr } %t242, ptr %t240, 1
  %t244 = load ptr, ptr %l195, !tbaa !29
  %t246 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v0, ptr %t244, { i64, ptr } %t243)
  %t247 = extractvalue { i32, i64 } %t246, 1
  %t248 = extractvalue { i32, i64 } %t246, 0
  store i32 %t248, ptr %l211
  %t249 = icmp ne i32 %t248, 0
  br i1 %t249, label %bb56, label %ok.250
ok.250:
  store i64 %t247, ptr %l210
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_de92fa5f00317f7b_3680b631254dc667)
  unreachable
bb55:
  %t251 = load i64, ptr %l210, !tbaa !24
  store i64 %t251, ptr %l193, !tbaa !24
  br label %bb58
bb56:
  br label %bb57
bb57:
  store i64 -1, ptr %l193, !tbaa !24
  br label %bb58
bb58:
  %t252 = load i64, ptr %l193, !tbaa !24
  store i64 %t252, ptr %l21, !tbaa !24
  %t253 = load i64, ptr %l21, !tbaa !24
  %t255 = icmp slt i64 %t253, 0
  br i1 %t255, label %bb59, label %bb60
bb59:
  store i1 true, ptr %l214, !tbaa !21
  br label %bb62
bb60:
  %t257 = load i64, ptr %l21, !tbaa !24
  %t260 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %l2, i64 %t257)
  store i1 %t260, ptr %l217
  br label %bb61
bb61:
  %t261 = load i1, ptr %l217, !tbaa !21
  store i1 %t261, ptr %l214, !tbaa !21
  br label %bb62
bb62:
  %t262 = load i1, ptr %l214, !tbaa !21
  br i1 %t262, label %bb63, label %bb64
bb63:
  store i1 true, ptr %l218, !tbaa !21
  br label %bb70
bb64:
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = getelementptr %"compiler/emit:Emitter", ptr %t263, i32 0, i32 16
  %t266 = load i64, ptr %l21, !tbaa !24
  %t269 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t265, i64 %t266)
  store i64 %t269, ptr %l222
  br label %bb65
bb65:
  %t270 = load i64, ptr @G_2ecompiler_2femit_2eHomeShared, !tbaa !24
  %t271 = load i64, ptr %l222, !tbaa !24
  %t273 = icmp ne i64 %t271, %t270
  br i1 %t273, label %bb66, label %bb67
bb66:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t277 = getelementptr %"compiler/emit:Emitter", ptr %t275, i32 0, i32 16
  %t278 = load i64, ptr %l21, !tbaa !24
  %t281 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t277, i64 %t278)
  store i64 %t281, ptr %l229
  br label %bb68
bb67:
  store i1 false, ptr %l225, !tbaa !21
  br label %bb69
bb68:
  %t282 = load i64, ptr @G_2ecompiler_2femit_2eHomeLocal, !tbaa !24
  %t283 = load i64, ptr %l229, !tbaa !24
  %t285 = icmp ne i64 %t283, %t282
  store i1 %t285, ptr %l225, !tbaa !21
  br label %bb69
bb69:
  %t287 = load i1, ptr %l225, !tbaa !21
  store i1 %t287, ptr %l218, !tbaa !21
  br label %bb70
bb70:
  %t288 = load i1, ptr %l218, !tbaa !21
  br i1 %t288, label %bb71, label %bb72
bb71:
  call void @__olang_scope_close(ptr %s8)
  br label %bb76
bb72:
  br label %bb73
bb73:
  %t289 = load i64, ptr %l21, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s0, ptr %l2, i64 %t289, i1 true)
  br label %bb74
bb74:
  %t292 = load i64, ptr %l21, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t292)
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s8)
  br label %bb76
bb76:
  %t295 = load i64, ptr %l19, !tbaa !24
  %t297 = add i64 %t295, 1
  store i64 %t297, ptr %l19, !tbaa !24
  br label %bb42
bb77:
  call void @__olang_scope_close(ptr %s6)
  br label %bb78
bb78:
  br label %bb28
bb79:
  %t299 = load ptr, ptr @__olang_prog_scope
  %t300 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t299)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t300, ptr %l238
  br label %bb80
bb80:
  %t301 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l238
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t301, ptr %l22
  %t302 = load ptr, ptr @__olang_prog_scope
  %t303 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t302)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t303, ptr %l239
  br label %bb81
bb81:
  %t304 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l239
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t304, ptr %l23
  store i64 0, ptr %l24, !tbaa !24
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t307 = getelementptr %"compiler/emit:Emitter", ptr %t305, i32 0, i32 14
  %t309 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t307)
  store i64 %t309, ptr %l242
  br label %bb82
bb82:
  %t310 = load i64, ptr %l242, !tbaa !24
  store i64 %t310, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t311 = load i64, ptr %l25, !tbaa !24
  %t312 = load i64, ptr %l24, !tbaa !24
  %t315 = icmp sgt i64 %t311, %t312
  br i1 %t315, label %bb83, label %bb84
bb83:
  %t317 = load i64, ptr %l26, !tbaa !24
  %t319 = icmp sgt i64 %t317, 0
  br i1 %t319, label %bb85, label %bb86
bb84:
  store i64 0, ptr %l246, !tbaa !24
  br label %bb88
bb85:
  %t321 = load i64, ptr %l25, !tbaa !24
  %t322 = load i64, ptr %l24, !tbaa !24
  %t325 = sub i64 %t321, %t322
  %t326 = load i64, ptr %l26, !tbaa !24
  %t329 = add i64 %t325, %t326
  %t331 = sub i64 %t329, 1
  %t332 = load i64, ptr %l26, !tbaa !24
  %t335 = sdiv i64 %t331, %t332
  store i64 %t335, ptr %l249, !tbaa !24
  br label %bb87
bb86:
  store i64 0, ptr %l249, !tbaa !24
  br label %bb87
bb87:
  %t337 = load i64, ptr %l249, !tbaa !24
  store i64 %t337, ptr %l246, !tbaa !24
  br label %bb88
bb88:
  %t338 = load i64, ptr %l246, !tbaa !24
  store i64 %t338, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb89
bb89:
  store %olang.scope zeroinitializer, ptr %s13
  %t339 = load i64, ptr %l28, !tbaa !24
  %t340 = load i64, ptr %l27, !tbaa !24
  %t343 = icmp slt i64 %t339, %t340
  %t345 = xor i1 %t343, true
  br i1 %t345, label %bb90, label %bb91
bb90:
  call void @__olang_scope_close(ptr %s13)
  br label %bb117
bb91:
  br label %bb92
bb92:
  %t347 = load i64, ptr %l24, !tbaa !24
  %t348 = load i64, ptr %l28, !tbaa !24
  %t349 = load i64, ptr %l26, !tbaa !24
  %t352 = mul i64 %t348, %t349
  %t355 = add i64 %t347, %t352
  store i64 %t355, ptr %l29, !tbaa !24
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t359 = getelementptr %"compiler/emit:Emitter", ptr %t357, i32 0, i32 16
  %t360 = load i64, ptr %l29, !tbaa !24
  %t363 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t359, i64 %t360)
  store i64 %t363, ptr %l270
  br label %bb93
bb93:
  %t364 = load i64, ptr %l270, !tbaa !24
  store i64 %t364, ptr %l30, !tbaa !24
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t367 = getelementptr %"compiler/emit:Emitter", ptr %t365, i32 0, i32 15
  %t368 = load i64, ptr %l29, !tbaa !24
  %t371 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t367, i64 %t368)
  store { i64, ptr } %t371, ptr %l274
  br label %bb94
bb94:
  %t372 = load { i64, ptr }, ptr %l274, !tbaa !27
  store { i64, ptr } %t372, ptr %l31, !tbaa !27
  %t373 = load i64, ptr %l29, !tbaa !24
  %t376 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %l2, i64 %t373)
  store i1 %t376, ptr %l277
  br label %bb95
bb95:
  %t377 = load i1, ptr %l277, !tbaa !21
  %t378 = xor i1 %t377, true
  br i1 %t378, label %bb96, label %bb97
bb96:
  call void @__olang_scope_close(ptr %s13)
  br label %bb116
bb97:
  br label %bb98
bb98:
  %t380 = load i64, ptr %l30, !tbaa !24
  %t381 = load i64, ptr @G_2ecompiler_2femit_2eHomeInst, !tbaa !24
  %t384 = icmp eq i64 %t380, %t381
  br i1 %t384, label %bb99, label %bb100
bb99:
  %t386 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t388 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s13, { i64, ptr } %t386, { i64, ptr } { i64 17, ptr @.d30 })
  store i1 %t388, ptr %l284
  br label %bb101
bb100:
  store i1 false, ptr %l282, !tbaa !21
  br label %bb102
bb101:
  %t389 = load i1, ptr %l284, !tbaa !21
  store i1 %t389, ptr %l282, !tbaa !21
  br label %bb102
bb102:
  %t390 = load i1, ptr %l282, !tbaa !21
  br i1 %t390, label %bb103, label %bb104
bb103:
  store i1 true, ptr %l285, !tbaa !21
  br label %bb109
bb104:
  %t391 = load i64, ptr %l30, !tbaa !24
  %t392 = load i64, ptr @G_2ecompiler_2femit_2eHomeShared, !tbaa !24
  %t395 = icmp eq i64 %t391, %t392
  br i1 %t395, label %bb105, label %bb106
bb105:
  %t397 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t399 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s13, { i64, ptr } %t397, { i64, ptr } { i64 20, ptr @.d31 })
  store i1 %t399, ptr %l291
  br label %bb107
bb106:
  store i1 false, ptr %l289, !tbaa !21
  br label %bb108
bb107:
  %t400 = load i1, ptr %l291, !tbaa !21
  store i1 %t400, ptr %l289, !tbaa !21
  br label %bb108
bb108:
  %t401 = load i1, ptr %l289, !tbaa !21
  store i1 %t401, ptr %l285, !tbaa !21
  br label %bb109
bb109:
  %t402 = load i1, ptr %l285, !tbaa !21
  br i1 %t402, label %bb110, label %bb111
bb110:
  store ptr %l23, ptr %l292, !tbaa !29
  %t403 = load i64, ptr %l29, !tbaa !24
  store i64 %t403, ptr %l293, !tbaa !24
  %t405 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l22)
  store i64 %t405, ptr %l295
  br label %bb112
bb111:
  br label %bb115
bb112:
  %t406 = load ptr, ptr %l292, !tbaa !29
  %t407 = load i64, ptr %l293, !tbaa !24
  %t408 = load i64, ptr %l295, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %s0, ptr %t406, i64 %t407, i64 %t408)
  br label %bb113
bb113:
  %t409 = load i64, ptr %l29, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l22, i64 %t409)
  br label %bb114
bb114:
  br label %bb115
bb115:
  call void @__olang_scope_close(ptr %s13)
  br label %bb116
bb116:
  %t412 = load i64, ptr %l28, !tbaa !24
  %t414 = add i64 %t412, 1
  store i64 %t414, ptr %l28, !tbaa !24
  br label %bb89
bb117:
  %t417 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l22)
  store i64 %t417, ptr %l301
  br label %bb118
bb118:
  %t418 = load i64, ptr %l301, !tbaa !24
  store i64 %t418, ptr %l32, !tbaa !24
  %t419 = load i64, ptr %l32, !tbaa !24
  %t421 = icmp slt i64 %t419, 2
  br i1 %t421, label %bb119, label %bb120
bb119:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb120:
  br label %bb121
bb121:
  %t423 = load ptr, ptr @__olang_prog_scope
  %t424 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e(ptr %t423)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t424, ptr %l304
  br label %bb122
bb122:
  %t425 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l304
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t425, ptr %l33
  %t426 = load i64, ptr %l32, !tbaa !24
  store i64 %t426, ptr %l305, !tbaa !24
  %t427 = load i64, ptr %l305, !tbaa !24
  %t428 = icmp sge i64 %t427, 0
  br i1 %t428, label %bb123, label %bb124
bb123:
  %t430 = load i64, ptr %l305, !tbaa !24
  %t431 = icmp sle i64 %t430, 1152921504606846975
  br i1 %t431, label %bb125, label %bb126
bb124:
  call void @__olang_check_failed(ptr @olang_loc_ce826338cbf4afde_5a793f5031108f92)
  unreachable
bb125:
  %t433 = load i64, ptr %l305, !tbaa !24
  %t434 = mul i64 %t433, 8
  %t435 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t434)
  %t436 = insertvalue { i64, ptr } undef, i64 %t433, 0
  %t437 = insertvalue { i64, ptr } %t436, ptr %t435, 1
  store { i64, ptr } %t437, ptr %l34, !tbaa !27
  %t439 = load ptr, ptr @__olang_prog_scope
  %t440 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %t439)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t440, ptr %l309
  br label %bb127
bb126:
  call void @__olang_check_failed(ptr @olang_loc_ce826338cbf4afde_5a793f5031108f92)
  unreachable
bb127:
  %t441 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l309
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t441, ptr %l35
  store i64 0, ptr %l36, !tbaa !24
  %t442 = load i64, ptr %l32, !tbaa !24
  store i64 %t442, ptr %l37, !tbaa !24
  store i64 1, ptr %l38, !tbaa !24
  %t444 = load i64, ptr %l37, !tbaa !24
  %t445 = load i64, ptr %l36, !tbaa !24
  %t448 = icmp sgt i64 %t444, %t445
  br i1 %t448, label %bb128, label %bb129
bb128:
  %t450 = load i64, ptr %l38, !tbaa !24
  %t452 = icmp sgt i64 %t450, 0
  br i1 %t452, label %bb130, label %bb131
bb129:
  store i64 0, ptr %l314, !tbaa !24
  br label %bb133
bb130:
  %t454 = load i64, ptr %l37, !tbaa !24
  %t455 = load i64, ptr %l36, !tbaa !24
  %t458 = sub i64 %t454, %t455
  %t459 = load i64, ptr %l38, !tbaa !24
  %t462 = add i64 %t458, %t459
  %t464 = sub i64 %t462, 1
  %t465 = load i64, ptr %l38, !tbaa !24
  %t468 = sdiv i64 %t464, %t465
  store i64 %t468, ptr %l317, !tbaa !24
  br label %bb132
bb131:
  store i64 0, ptr %l317, !tbaa !24
  br label %bb132
bb132:
  %t470 = load i64, ptr %l317, !tbaa !24
  store i64 %t470, ptr %l314, !tbaa !24
  br label %bb133
bb133:
  %t471 = load i64, ptr %l314, !tbaa !24
  store i64 %t471, ptr %l39, !tbaa !24
  store i64 0, ptr %l40, !tbaa !24
  br label %bb134
bb134:
  store %olang.scope zeroinitializer, ptr %s19
  %t472 = load i64, ptr %l40, !tbaa !24
  %t473 = load i64, ptr %l39, !tbaa !24
  %t476 = icmp slt i64 %t472, %t473
  %t478 = xor i1 %t476, true
  br i1 %t478, label %bb135, label %bb136
bb135:
  call void @__olang_scope_close(ptr %s19)
  br label %bb229
bb136:
  br label %bb137
bb137:
  %t480 = load i64, ptr %l36, !tbaa !24
  %t481 = load i64, ptr %l40, !tbaa !24
  %t482 = load i64, ptr %l38, !tbaa !24
  %t485 = mul i64 %t481, %t482
  %t488 = add i64 %t480, %t485
  store i64 %t488, ptr %l41, !tbaa !24
  %t490 = load i64, ptr %l41, !tbaa !24
  %t493 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l22, i64 %t490)
  store i64 %t493, ptr %l337
  br label %bb138
bb138:
  %t494 = load i64, ptr %l337, !tbaa !24
  store i64 %t494, ptr %l42, !tbaa !24
  %t495 = load ptr, ptr %l0, !tbaa !29
  %t497 = getelementptr %"compiler/emit:Emitter", ptr %t495, i32 0, i32 15
  %t498 = load i64, ptr %l42, !tbaa !24
  %t501 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t497, i64 %t498)
  store { i64, ptr } %t501, ptr %l341
  br label %bb139
bb139:
  %t502 = load { i64, ptr }, ptr %l341, !tbaa !27
  store { i64, ptr } %t502, ptr %l43, !tbaa !27
  %t503 = load ptr, ptr %l0, !tbaa !29
  %t504 = load i64, ptr %l42, !tbaa !24
  %t507 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2erefs(ptr %v0, ptr %t503, i64 %t504)
  store { i64, ptr } %t507, ptr %l344
  br label %bb140
bb140:
  %t508 = load { i64, ptr }, ptr %l344, !tbaa !27
  store { i64, ptr } %t508, ptr %l44, !tbaa !27
  %t509 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s19)
  store %"std/prelude/text:StringBuilder" %t509, ptr %l345
  br label %bb141
bb141:
  %t510 = load %"std/prelude/text:StringBuilder", ptr %l345
  store %"std/prelude/text:StringBuilder" %t510, ptr %l45
  %t511 = load ptr, ptr @__olang_prog_scope
  %t512 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t511)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t512, ptr %l346
  br label %bb142
bb142:
  %t513 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l346
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t513, ptr %l46
  store i64 0, ptr %l47, !tbaa !24
  store i64 0, ptr %l48, !tbaa !24
  %t514 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t516 = extractvalue { i64, ptr } %t514, 0
  store i64 %t516, ptr %l49, !tbaa !24
  store i64 3, ptr %l50, !tbaa !24
  %t518 = load i64, ptr %l49, !tbaa !24
  %t519 = load i64, ptr %l48, !tbaa !24
  %t522 = icmp sgt i64 %t518, %t519
  br i1 %t522, label %bb143, label %bb144
bb143:
  %t524 = load i64, ptr %l50, !tbaa !24
  %t526 = icmp sgt i64 %t524, 0
  br i1 %t526, label %bb145, label %bb146
bb144:
  store i64 0, ptr %l352, !tbaa !24
  br label %bb148
bb145:
  %t528 = load i64, ptr %l49, !tbaa !24
  %t529 = load i64, ptr %l48, !tbaa !24
  %t532 = sub i64 %t528, %t529
  %t533 = load i64, ptr %l50, !tbaa !24
  %t536 = add i64 %t532, %t533
  %t538 = sub i64 %t536, 1
  %t539 = load i64, ptr %l50, !tbaa !24
  %t542 = sdiv i64 %t538, %t539
  store i64 %t542, ptr %l355, !tbaa !24
  br label %bb147
bb146:
  store i64 0, ptr %l355, !tbaa !24
  br label %bb147
bb147:
  %t544 = load i64, ptr %l355, !tbaa !24
  store i64 %t544, ptr %l352, !tbaa !24
  br label %bb148
bb148:
  %t545 = load i64, ptr %l352, !tbaa !24
  store i64 %t545, ptr %l51, !tbaa !24
  store i64 0, ptr %l52, !tbaa !24
  br label %bb149
bb149:
  store %olang.scope zeroinitializer, ptr %s21
  %t546 = load i64, ptr %l52, !tbaa !24
  %t547 = load i64, ptr %l51, !tbaa !24
  %t550 = icmp slt i64 %t546, %t547
  %t552 = xor i1 %t550, true
  br i1 %t552, label %bb150, label %bb151
bb150:
  call void @__olang_scope_close(ptr %s21)
  br label %bb208
bb151:
  br label %bb152
bb152:
  %t554 = load i64, ptr %l48, !tbaa !24
  %t555 = load i64, ptr %l52, !tbaa !24
  %t556 = load i64, ptr %l50, !tbaa !24
  %t559 = mul i64 %t555, %t556
  %t562 = add i64 %t554, %t559
  store i64 %t562, ptr %l53, !tbaa !24
  %t564 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t564, ptr %l373, !tbaa !27
  %t565 = load i64, ptr %l53, !tbaa !24
  %t567 = getelementptr { i64, ptr }, ptr %l373, i32 0, i32 1
  %t568 = load ptr, ptr %t567, !tbaa !27
  %t569 = getelementptr i64, ptr %t568, i64 %t565
  %t570 = load i64, ptr %t569, !tbaa !34
  %t572 = icmp ne i64 %t570, 0
  br i1 %t572, label %bb153, label %bb154
bb153:
  call void @__olang_scope_close(ptr %s21)
  br label %bb207
bb154:
  br label %bb155
bb155:
  %t574 = load ptr, ptr %l0, !tbaa !29
  %t576 = getelementptr %"compiler/emit:Emitter", ptr %t574, i32 0, i32 18
  store ptr %t576, ptr %l379, !tbaa !29
  %t577 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t577, ptr %l380, !tbaa !27
  %t578 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t578, ptr %l381, !tbaa !27
  %t579 = load i64, ptr %l53, !tbaa !24
  %t581 = add i64 %t579, 1
  %t583 = getelementptr { i64, ptr }, ptr %l381, i32 0, i32 1
  %t584 = load ptr, ptr %t583, !tbaa !27
  %t585 = getelementptr i64, ptr %t584, i64 %t581
  %t586 = load i64, ptr %t585, !tbaa !34
  store i64 %t586, ptr %l384, !tbaa !24
  %t587 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t587, ptr %l385, !tbaa !27
  %t588 = load i64, ptr %l53, !tbaa !24
  %t590 = add i64 %t588, 2
  %t592 = getelementptr { i64, ptr }, ptr %l385, i32 0, i32 1
  %t593 = load ptr, ptr %t592, !tbaa !27
  %t594 = getelementptr i64, ptr %t593, i64 %t590
  %t595 = load i64, ptr %t594, !tbaa !34
  store i64 %t595, ptr %l388, !tbaa !24
  %t596 = load { i64, ptr }, ptr %l380, !tbaa !27
  %t597 = extractvalue { i64, ptr } %t596, 0
  store i64 %t597, ptr %l389, !tbaa !24
  %t598 = load i64, ptr %l384, !tbaa !24
  %t599 = icmp sge i64 %t598, 0
  br i1 %t599, label %bb156, label %bb157
bb156:
  %t601 = load i64, ptr %l384, !tbaa !24
  %t602 = load i64, ptr %l388, !tbaa !24
  %t603 = icmp sle i64 %t601, %t602
  br i1 %t603, label %bb158, label %bb159
bb157:
  call void @__olang_check_failed(ptr @olang_loc_71a9e12f05a3bddd_baac335f863186a9)
  unreachable
bb158:
  %t605 = load i64, ptr %l388, !tbaa !24
  %t606 = load i64, ptr %l389, !tbaa !24
  %t607 = icmp sle i64 %t605, %t606
  br i1 %t607, label %bb160, label %bb161
bb159:
  call void @__olang_check_failed(ptr @olang_loc_71a9e12f05a3bddd_baac335f863186a9)
  unreachable
bb160:
  %t609 = getelementptr { i64, ptr }, ptr %l380, i32 0, i32 1
  %t610 = load ptr, ptr %t609, !tbaa !27
  %t611 = load i64, ptr %l384, !tbaa !24
  %t612 = load i64, ptr %l388, !tbaa !24
  %t613 = getelementptr i8, ptr %t610, i64 %t611
  %t614 = sub i64 %t612, %t611
  %t615 = insertvalue { i64, ptr } undef, i64 %t614, 0
  %t616 = insertvalue { i64, ptr } %t615, ptr %t613, 1
  %t617 = load ptr, ptr %l379, !tbaa !29
  %t619 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v0, ptr %t617, { i64, ptr } %t616)
  %t620 = extractvalue { i32, i64 } %t619, 1
  %t621 = extractvalue { i32, i64 } %t619, 0
  store i32 %t621, ptr %l395
  %t622 = icmp ne i32 %t621, 0
  br i1 %t622, label %bb163, label %ok.623
ok.623:
  store i64 %t620, ptr %l394
  br label %bb162
bb161:
  call void @__olang_check_failed(ptr @olang_loc_71a9e12f05a3bddd_baac335f863186a9)
  unreachable
bb162:
  %t624 = load i64, ptr %l394, !tbaa !24
  store i64 %t624, ptr %l377, !tbaa !24
  br label %bb165
bb163:
  br label %bb164
bb164:
  store i64 -1, ptr %l377, !tbaa !24
  br label %bb165
bb165:
  %t625 = load i64, ptr %l377, !tbaa !24
  store i64 %t625, ptr %l54, !tbaa !24
  %t626 = load i64, ptr %l54, !tbaa !24
  %t628 = icmp sge i64 %t626, 0
  br i1 %t628, label %bb166, label %bb167
bb166:
  %t630 = load ptr, ptr %l0, !tbaa !29
  %t632 = getelementptr %"compiler/emit:Emitter", ptr %t630, i32 0, i32 16
  %t633 = load i64, ptr %l54, !tbaa !24
  %t636 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t632, i64 %t633)
  store i64 %t636, ptr %l402
  br label %bb168
bb167:
  store i1 false, ptr %l398, !tbaa !21
  br label %bb169
bb168:
  %t637 = load i64, ptr @G_2ecompiler_2femit_2eHomeLoc, !tbaa !24
  %t638 = load i64, ptr %l402, !tbaa !24
  %t640 = icmp eq i64 %t638, %t637
  store i1 %t640, ptr %l398, !tbaa !21
  br label %bb169
bb169:
  %t642 = load i1, ptr %l398, !tbaa !21
  br i1 %t642, label %bb170, label %bb171
bb170:
  store %olang.scope zeroinitializer, ptr %s23
  store ptr %l45, ptr %l405, !tbaa !29
  %t643 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t643, ptr %l406, !tbaa !27
  %t644 = load i64, ptr %l47, !tbaa !24
  store i64 %t644, ptr %l407, !tbaa !24
  %t645 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t645, ptr %l408, !tbaa !27
  %t646 = load i64, ptr %l53, !tbaa !24
  %t648 = add i64 %t646, 1
  %t650 = getelementptr { i64, ptr }, ptr %l408, i32 0, i32 1
  %t651 = load ptr, ptr %t650, !tbaa !27
  %t652 = getelementptr i64, ptr %t651, i64 %t648
  %t653 = load i64, ptr %t652, !tbaa !34
  store i64 %t653, ptr %l411, !tbaa !24
  %t654 = load { i64, ptr }, ptr %l406, !tbaa !27
  %t655 = extractvalue { i64, ptr } %t654, 0
  store i64 %t655, ptr %l412, !tbaa !24
  %t656 = load i64, ptr %l407, !tbaa !24
  %t657 = icmp sge i64 %t656, 0
  br i1 %t657, label %bb172, label %bb173
bb171:
  br label %bb191
bb172:
  %t659 = load i64, ptr %l407, !tbaa !24
  %t660 = load i64, ptr %l411, !tbaa !24
  %t661 = icmp sle i64 %t659, %t660
  br i1 %t661, label %bb174, label %bb175
bb173:
  call void @__olang_check_failed(ptr @olang_loc_2d324f4199cd7780_534dee4d2a64aebc)
  unreachable
bb174:
  %t663 = load i64, ptr %l411, !tbaa !24
  %t664 = load i64, ptr %l412, !tbaa !24
  %t665 = icmp sle i64 %t663, %t664
  br i1 %t665, label %bb176, label %bb177
bb175:
  call void @__olang_check_failed(ptr @olang_loc_2d324f4199cd7780_534dee4d2a64aebc)
  unreachable
bb176:
  %t667 = getelementptr { i64, ptr }, ptr %l406, i32 0, i32 1
  %t668 = load ptr, ptr %t667, !tbaa !27
  %t669 = load i64, ptr %l407, !tbaa !24
  %t670 = load i64, ptr %l411, !tbaa !24
  %t671 = getelementptr i8, ptr %t668, i64 %t669
  %t672 = sub i64 %t670, %t669
  %t673 = insertvalue { i64, ptr } undef, i64 %t672, 0
  %t674 = insertvalue { i64, ptr } %t673, ptr %t671, 1
  %t675 = load ptr, ptr %l405, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s19, ptr %v0, ptr %t675, { i64, ptr } %t674)
  br label %bb178
bb177:
  call void @__olang_check_failed(ptr @olang_loc_2d324f4199cd7780_534dee4d2a64aebc)
  unreachable
bb178:
  %t677 = load ptr, ptr %l0, !tbaa !29
  %t679 = getelementptr %"compiler/emit:Emitter", ptr %t677, i32 0, i32 15
  %t680 = load i64, ptr %l54, !tbaa !24
  %t683 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t679, i64 %t680)
  store { i64, ptr } %t683, ptr %l420
  br label %bb179
bb179:
  %t684 = load { i64, ptr }, ptr %l420, !tbaa !27
  store { i64, ptr } %t684, ptr %l55, !tbaa !27
  %t685 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t687 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s23, { i64, ptr } %t685, { i64, ptr } { i64 3, ptr @.d32 })
  %t688 = extractvalue { i32, i64 } %t687, 1
  %t689 = extractvalue { i32, i64 } %t687, 0
  store i32 %t689, ptr %l424
  %t690 = icmp ne i32 %t689, 0
  br i1 %t690, label %bb181, label %ok.691
ok.691:
  store i64 %t688, ptr %l423
  br label %bb180
bb180:
  %t692 = load i64, ptr %l423, !tbaa !24
  store i64 %t692, ptr %l421, !tbaa !24
  br label %bb183
bb181:
  br label %bb182
bb182:
  store i64 0, ptr %l421, !tbaa !24
  br label %bb183
bb183:
  %t693 = load i64, ptr %l421, !tbaa !24
  store ptr %l45, ptr %l425, !tbaa !29
  %t694 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t694, ptr %l426, !tbaa !27
  store i64 %t693, ptr %l427, !tbaa !24
  %t696 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t699 = extractvalue { i64, ptr } %t696, 0
  store i64 %t699, ptr %l430, !tbaa !24
  %t700 = load { i64, ptr }, ptr %l426, !tbaa !27
  %t701 = extractvalue { i64, ptr } %t700, 0
  store i64 %t701, ptr %l431, !tbaa !24
  %t702 = load i64, ptr %l427, !tbaa !24
  %t703 = icmp sge i64 %t702, 0
  br i1 %t703, label %bb184, label %bb185
bb184:
  %t705 = load i64, ptr %l427, !tbaa !24
  %t706 = load i64, ptr %l430, !tbaa !24
  %t707 = icmp sle i64 %t705, %t706
  br i1 %t707, label %bb186, label %bb187
bb185:
  call void @__olang_check_failed(ptr @olang_loc_ccd5cb87339e775f_a8ec88fdee920643)
  unreachable
bb186:
  %t709 = load i64, ptr %l430, !tbaa !24
  %t710 = load i64, ptr %l431, !tbaa !24
  %t711 = icmp sle i64 %t709, %t710
  br i1 %t711, label %bb188, label %bb189
bb187:
  call void @__olang_check_failed(ptr @olang_loc_ccd5cb87339e775f_a8ec88fdee920643)
  unreachable
bb188:
  %t713 = getelementptr { i64, ptr }, ptr %l426, i32 0, i32 1
  %t714 = load ptr, ptr %t713, !tbaa !27
  %t715 = load i64, ptr %l427, !tbaa !24
  %t716 = load i64, ptr %l430, !tbaa !24
  %t717 = getelementptr i8, ptr %t714, i64 %t715
  %t718 = sub i64 %t716, %t715
  %t719 = insertvalue { i64, ptr } undef, i64 %t718, 0
  %t720 = insertvalue { i64, ptr } %t719, ptr %t717, 1
  %t721 = load ptr, ptr %l425, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s19, ptr %v0, ptr %t721, { i64, ptr } %t720)
  br label %bb190
bb189:
  call void @__olang_check_failed(ptr @olang_loc_ccd5cb87339e775f_a8ec88fdee920643)
  unreachable
bb190:
  %t723 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t723, ptr %l436, !tbaa !27
  %t724 = load i64, ptr %l53, !tbaa !24
  %t726 = add i64 %t724, 2
  %t728 = getelementptr { i64, ptr }, ptr %l436, i32 0, i32 1
  %t729 = load ptr, ptr %t728, !tbaa !27
  %t730 = getelementptr i64, ptr %t729, i64 %t726
  %t731 = load i64, ptr %t730, !tbaa !34
  store i64 %t731, ptr %l47, !tbaa !24
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s21)
  br label %bb207
bb191:
  %t733 = load i64, ptr %l54, !tbaa !24
  %t736 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %s0, ptr %l23, i64 %t733)
  %t737 = extractvalue { i32, i64 } %t736, 1
  %t738 = extractvalue { i32, i64 } %t736, 0
  store i32 %t738, ptr %l444
  %t739 = icmp ne i32 %t738, 0
  br i1 %t739, label %bb193, label %ok.740
ok.740:
  store i64 %t737, ptr %l443
  br label %bb192
bb192:
  %t741 = load i64, ptr %l443, !tbaa !24
  store i64 %t741, ptr %l440, !tbaa !24
  br label %bb195
bb193:
  br label %bb194
bb194:
  store i64 -1, ptr %l440, !tbaa !24
  br label %bb195
bb195:
  %t742 = load i64, ptr %l440, !tbaa !24
  store i64 %t742, ptr %l57, !tbaa !24
  %t743 = load i64, ptr %l57, !tbaa !24
  %t745 = icmp slt i64 %t743, 0
  br i1 %t745, label %bb196, label %bb197
bb196:
  call void @__olang_scope_close(ptr %s21)
  br label %bb207
bb197:
  br label %bb198
bb198:
  store ptr %l45, ptr %l447, !tbaa !29
  %t747 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t747, ptr %l448, !tbaa !27
  %t748 = load i64, ptr %l47, !tbaa !24
  store i64 %t748, ptr %l449, !tbaa !24
  %t749 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t749, ptr %l450, !tbaa !27
  %t750 = load i64, ptr %l53, !tbaa !24
  %t752 = add i64 %t750, 1
  %t754 = getelementptr { i64, ptr }, ptr %l450, i32 0, i32 1
  %t755 = load ptr, ptr %t754, !tbaa !27
  %t756 = getelementptr i64, ptr %t755, i64 %t752
  %t757 = load i64, ptr %t756, !tbaa !34
  store i64 %t757, ptr %l453, !tbaa !24
  %t758 = load { i64, ptr }, ptr %l448, !tbaa !27
  %t759 = extractvalue { i64, ptr } %t758, 0
  store i64 %t759, ptr %l454, !tbaa !24
  %t760 = load i64, ptr %l449, !tbaa !24
  %t761 = icmp sge i64 %t760, 0
  br i1 %t761, label %bb199, label %bb200
bb199:
  %t763 = load i64, ptr %l449, !tbaa !24
  %t764 = load i64, ptr %l453, !tbaa !24
  %t765 = icmp sle i64 %t763, %t764
  br i1 %t765, label %bb201, label %bb202
bb200:
  call void @__olang_check_failed(ptr @olang_loc_502634e55cf63fe2_bb9ce6600b3e98e6)
  unreachable
bb201:
  %t767 = load i64, ptr %l453, !tbaa !24
  %t768 = load i64, ptr %l454, !tbaa !24
  %t769 = icmp sle i64 %t767, %t768
  br i1 %t769, label %bb203, label %bb204
bb202:
  call void @__olang_check_failed(ptr @olang_loc_502634e55cf63fe2_bb9ce6600b3e98e6)
  unreachable
bb203:
  %t771 = getelementptr { i64, ptr }, ptr %l448, i32 0, i32 1
  %t772 = load ptr, ptr %t771, !tbaa !27
  %t773 = load i64, ptr %l449, !tbaa !24
  %t774 = load i64, ptr %l453, !tbaa !24
  %t775 = getelementptr i8, ptr %t772, i64 %t773
  %t776 = sub i64 %t774, %t773
  %t777 = insertvalue { i64, ptr } undef, i64 %t776, 0
  %t778 = insertvalue { i64, ptr } %t777, ptr %t775, 1
  %t779 = load ptr, ptr %l447, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s19, ptr %v0, ptr %t779, { i64, ptr } %t778)
  br label %bb205
bb204:
  call void @__olang_check_failed(ptr @olang_loc_502634e55cf63fe2_bb9ce6600b3e98e6)
  unreachable
bb205:
  %t781 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t781, ptr %l459, !tbaa !27
  %t782 = load i64, ptr %l53, !tbaa !24
  %t784 = add i64 %t782, 2
  %t786 = getelementptr { i64, ptr }, ptr %l459, i32 0, i32 1
  %t787 = load ptr, ptr %t786, !tbaa !27
  %t788 = getelementptr i64, ptr %t787, i64 %t784
  %t789 = load i64, ptr %t788, !tbaa !34
  store i64 %t789, ptr %l47, !tbaa !24
  %t791 = load i64, ptr %l57, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s19, ptr %l46, i64 %t791)
  br label %bb206
bb206:
  call void @__olang_scope_close(ptr %s21)
  br label %bb207
bb207:
  %t794 = load i64, ptr %l52, !tbaa !24
  %t796 = add i64 %t794, 1
  store i64 %t796, ptr %l52, !tbaa !24
  br label %bb149
bb208:
  store ptr %l45, ptr %l467, !tbaa !29
  %t798 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t798, ptr %l468, !tbaa !27
  %t799 = load i64, ptr %l47, !tbaa !24
  store i64 %t799, ptr %l469, !tbaa !24
  %t800 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t803 = extractvalue { i64, ptr } %t800, 0
  store i64 %t803, ptr %l472, !tbaa !24
  %t804 = load { i64, ptr }, ptr %l468, !tbaa !27
  %t805 = extractvalue { i64, ptr } %t804, 0
  store i64 %t805, ptr %l473, !tbaa !24
  %t806 = load i64, ptr %l469, !tbaa !24
  %t807 = icmp sge i64 %t806, 0
  br i1 %t807, label %bb209, label %bb210
bb209:
  %t809 = load i64, ptr %l469, !tbaa !24
  %t810 = load i64, ptr %l472, !tbaa !24
  %t811 = icmp sle i64 %t809, %t810
  br i1 %t811, label %bb211, label %bb212
bb210:
  call void @__olang_check_failed(ptr @olang_loc_b7179de695e5661_8fd10db64c62ad05)
  unreachable
bb211:
  %t813 = load i64, ptr %l472, !tbaa !24
  %t814 = load i64, ptr %l473, !tbaa !24
  %t815 = icmp sle i64 %t813, %t814
  br i1 %t815, label %bb213, label %bb214
bb212:
  call void @__olang_check_failed(ptr @olang_loc_b7179de695e5661_8fd10db64c62ad05)
  unreachable
bb213:
  %t817 = getelementptr { i64, ptr }, ptr %l468, i32 0, i32 1
  %t818 = load ptr, ptr %t817, !tbaa !27
  %t819 = load i64, ptr %l469, !tbaa !24
  %t820 = load i64, ptr %l472, !tbaa !24
  %t821 = getelementptr i8, ptr %t818, i64 %t819
  %t822 = sub i64 %t820, %t819
  %t823 = insertvalue { i64, ptr } undef, i64 %t822, 0
  %t824 = insertvalue { i64, ptr } %t823, ptr %t821, 1
  %t825 = load ptr, ptr %l467, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s19, ptr %v0, ptr %t825, { i64, ptr } %t824)
  br label %bb215
bb214:
  call void @__olang_check_failed(ptr @olang_loc_b7179de695e5661_8fd10db64c62ad05)
  unreachable
bb215:
  %t828 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s19, ptr %s19, ptr %l45)
  store { i64, ptr } %t828, ptr %l479
  br label %bb216
bb216:
  %t829 = load { i64, ptr }, ptr %l479, !tbaa !27
  store { i64, ptr } %t829, ptr %l58, !tbaa !27
  %t830 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t833 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %s0, ptr %s19, ptr %l35, { i64, ptr } %t830)
  %t834 = extractvalue { i32, i64 } %t833, 1
  %t835 = extractvalue { i32, i64 } %t833, 0
  store i32 %t835, ptr %l484
  %t836 = icmp ne i32 %t835, 0
  br i1 %t836, label %bb218, label %ok.837
ok.837:
  store i64 %t834, ptr %l483
  br label %bb217
bb217:
  %t838 = load i64, ptr %l483, !tbaa !24
  store i64 %t838, ptr %l480, !tbaa !24
  br label %bb220
bb218:
  br label %bb219
bb219:
  store i64 -1, ptr %l480, !tbaa !24
  br label %bb220
bb220:
  %t839 = load i64, ptr %l480, !tbaa !24
  store i64 %t839, ptr %l59, !tbaa !24
  %t840 = load i64, ptr %l59, !tbaa !24
  %t842 = icmp slt i64 %t840, 0
  br i1 %t842, label %bb221, label %bb222
bb221:
  %t845 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_He890afa3b14bd52c6ea464bca4cef525(ptr %s0, ptr %l35)
  store i64 %t845, ptr %l488
  br label %bb223
bb222:
  br label %bb225
bb223:
  %t846 = load i64, ptr %l488, !tbaa !24
  store i64 %t846, ptr %l59, !tbaa !24
  %t847 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t849 = extractvalue { i64, ptr } %t847, 1
  %t850 = extractvalue { i64, ptr } %t847, 0
  %t851 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t850)
  call void @olang_textcopy(ptr %t851, ptr %t849, i64 %t850)
  %t852 = insertvalue { i64, ptr } undef, i64 %t850, 0
  %t853 = insertvalue { i64, ptr } %t852, ptr %t851, 1
  %t855 = extractvalue { i64, ptr } %t853, 0
  %t856 = extractvalue { i64, ptr } %t853, 1
  %t857 = mul i64 %t855, 1
  %t858 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t857)
  call void @llvm.memcpy.p0.p0.i64(ptr %t858, ptr %t856, i64 %t857, i1 false)
  %t859 = insertvalue { i64, ptr } undef, i64 %t855, 0
  %t860 = insertvalue { i64, ptr } %t859, ptr %t858, 1
  %t861 = load i64, ptr %l59, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %s0, ptr %s0, ptr %l35, { i64, ptr } %t860, i64 %t861)
  br label %bb224
bb224:
  br label %bb225
bb225:
  %t865 = load i64, ptr %l41, !tbaa !24
  %t866 = load i64, ptr %l59, !tbaa !24
  %t869 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t870 = load ptr, ptr %t869, !tbaa !27
  %t871 = getelementptr i64, ptr %t870, i64 %t865
  store i64 %t866, ptr %t871, !tbaa !34
  store ptr %l33, ptr %l496, !tbaa !29
  %t873 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eToArray_3cI64_3e(ptr %s19, ptr %s0, ptr %l46)
  store { i64, ptr } %t873, ptr %l498
  br label %bb226
bb226:
  %t874 = load ptr, ptr %l496, !tbaa !29
  %t875 = load { i64, ptr }, ptr %l498, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %s0, ptr %s0, ptr %t874, { i64, ptr } %t875)
  br label %bb227
bb227:
  call void @__olang_scope_close(ptr %s19)
  br label %bb228
bb228:
  %t876 = load i64, ptr %l40, !tbaa !24
  %t878 = add i64 %t876, 1
  store i64 %t878, ptr %l40, !tbaa !24
  br label %bb134
bb229:
  %t881 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_He890afa3b14bd52c6ea464bca4cef525(ptr %s0, ptr %l35)
  store i64 %t881, ptr %l502
  br label %bb230
bb230:
  %t882 = load i64, ptr %l502, !tbaa !24
  store i64 %t882, ptr %l60, !tbaa !24
  br label %bb231
bb231:
  store %olang.scope zeroinitializer, ptr %s29
  %t883 = load i64, ptr %l60, !tbaa !24
  %t884 = load i64, ptr %l32, !tbaa !24
  %t887 = icmp slt i64 %t883, %t884
  %t889 = xor i1 %t887, true
  br i1 %t889, label %bb232, label %bb233
bb232:
  call void @__olang_scope_close(ptr %s29)
  br label %bb281
bb233:
  br label %bb234
bb234:
  %t891 = load i64, ptr %l32, !tbaa !24
  store i64 %t891, ptr %l507, !tbaa !24
  %t892 = load i64, ptr %l507, !tbaa !24
  %t893 = icmp sge i64 %t892, 0
  br i1 %t893, label %bb235, label %bb236
bb235:
  %t895 = load i64, ptr %l507, !tbaa !24
  %t896 = icmp sle i64 %t895, 1152921504606846975
  br i1 %t896, label %bb237, label %bb238
bb236:
  call void @__olang_check_failed(ptr @olang_loc_80d737cc9290fb3c_d5f23604b0833618)
  unreachable
bb237:
  %t898 = load i64, ptr %l507, !tbaa !24
  %t899 = mul i64 %t898, 8
  %t900 = call ptr @__olang_scope_alloc_zeroed(ptr %s29, i64 %t899)
  %t901 = insertvalue { i64, ptr } undef, i64 %t898, 0
  %t902 = insertvalue { i64, ptr } %t901, ptr %t900, 1
  store { i64, ptr } %t902, ptr %l61, !tbaa !27
  %t904 = load ptr, ptr @__olang_prog_scope
  %t905 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %t904)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t905, ptr %l511
  br label %bb239
bb238:
  call void @__olang_check_failed(ptr @olang_loc_80d737cc9290fb3c_d5f23604b0833618)
  unreachable
bb239:
  %t906 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l511
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t906, ptr %l62
  store i64 0, ptr %l63, !tbaa !24
  %t907 = load i64, ptr %l32, !tbaa !24
  store i64 %t907, ptr %l64, !tbaa !24
  store i64 1, ptr %l65, !tbaa !24
  %t909 = load i64, ptr %l64, !tbaa !24
  %t910 = load i64, ptr %l63, !tbaa !24
  %t913 = icmp sgt i64 %t909, %t910
  br i1 %t913, label %bb240, label %bb241
bb240:
  %t915 = load i64, ptr %l65, !tbaa !24
  %t917 = icmp sgt i64 %t915, 0
  br i1 %t917, label %bb242, label %bb243
bb241:
  store i64 0, ptr %l516, !tbaa !24
  br label %bb245
bb242:
  %t919 = load i64, ptr %l64, !tbaa !24
  %t920 = load i64, ptr %l63, !tbaa !24
  %t923 = sub i64 %t919, %t920
  %t924 = load i64, ptr %l65, !tbaa !24
  %t927 = add i64 %t923, %t924
  %t929 = sub i64 %t927, 1
  %t930 = load i64, ptr %l65, !tbaa !24
  %t933 = sdiv i64 %t929, %t930
  store i64 %t933, ptr %l519, !tbaa !24
  br label %bb244
bb243:
  store i64 0, ptr %l519, !tbaa !24
  br label %bb244
bb244:
  %t935 = load i64, ptr %l519, !tbaa !24
  store i64 %t935, ptr %l516, !tbaa !24
  br label %bb245
bb245:
  %t936 = load i64, ptr %l516, !tbaa !24
  store i64 %t936, ptr %l66, !tbaa !24
  store i64 0, ptr %l67, !tbaa !24
  br label %bb246
bb246:
  store %olang.scope zeroinitializer, ptr %s31
  %t937 = load i64, ptr %l67, !tbaa !24
  %t938 = load i64, ptr %l66, !tbaa !24
  %t941 = icmp slt i64 %t937, %t938
  %t943 = xor i1 %t941, true
  br i1 %t943, label %bb247, label %bb248
bb247:
  call void @__olang_scope_close(ptr %s31)
  br label %bb271
bb248:
  br label %bb249
bb249:
  %t945 = load i64, ptr %l63, !tbaa !24
  %t946 = load i64, ptr %l67, !tbaa !24
  %t947 = load i64, ptr %l65, !tbaa !24
  %t950 = mul i64 %t946, %t947
  %t953 = add i64 %t945, %t950
  store i64 %t953, ptr %l68, !tbaa !24
  %t955 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s31)
  store %"std/prelude/text:StringBuilder" %t955, ptr %l537
  br label %bb250
bb250:
  %t956 = load %"std/prelude/text:StringBuilder", ptr %l537
  store %"std/prelude/text:StringBuilder" %t956, ptr %l69
  %t957 = load i64, ptr %l68, !tbaa !24
  %t959 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t960 = load ptr, ptr %t959, !tbaa !27
  %t961 = getelementptr i64, ptr %t960, i64 %t957
  %t962 = load i64, ptr %t961, !tbaa !34
  %t964 = call i64 @__olang_fmt_i64(ptr null, i64 %t962)
  %t965 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t964)
  %t966 = call i64 @__olang_fmt_i64(ptr %t965, i64 %t962)
  %t967 = insertvalue { i64, ptr } undef, i64 %t964, 0
  %t968 = insertvalue { i64, ptr } %t967, ptr %t965, 1
  %t970 = extractvalue { i64, ptr } %t968, 0
  %t971 = extractvalue { i64, ptr } %t968, 1
  %t972 = mul i64 %t970, 1
  %t973 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t972)
  call void @llvm.memcpy.p0.p0.i64(ptr %t973, ptr %t971, i64 %t972, i1 false)
  %t974 = insertvalue { i64, ptr } undef, i64 %t970, 0
  %t975 = insertvalue { i64, ptr } %t974, ptr %t973, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s31, ptr %s31, ptr %l69, { i64, ptr } %t975)
  br label %bb251
bb251:
  %t978 = load i64, ptr %l68, !tbaa !24
  %t981 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %s0, ptr %s0, ptr %l33, i64 %t978)
  store { i64, ptr } %t981, ptr %l545
  br label %bb252
bb252:
  %t982 = load { i64, ptr }, ptr %l545, !tbaa !27
  store { i64, ptr } %t982, ptr %l70, !tbaa !27
  store i64 0, ptr %l71, !tbaa !24
  %t983 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t985 = extractvalue { i64, ptr } %t983, 0
  store i64 %t985, ptr %l72, !tbaa !24
  br label %bb253
bb253:
  store %olang.scope zeroinitializer, ptr %s34
  %t987 = load i64, ptr %l71, !tbaa !24
  %t988 = load i64, ptr %l72, !tbaa !24
  %t991 = icmp slt i64 %t987, %t988
  %t993 = xor i1 %t991, true
  br i1 %t993, label %bb254, label %bb255
bb254:
  call void @__olang_scope_close(ptr %s34)
  br label %bb259
bb255:
  br label %bb256
bb256:
  %t995 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t995, ptr %l552, !tbaa !27
  %t996 = load i64, ptr %l71, !tbaa !24
  %t998 = getelementptr { i64, ptr }, ptr %l552, i32 0, i32 1
  %t999 = load ptr, ptr %t998, !tbaa !27
  %t1000 = getelementptr i64, ptr %t999, i64 %t996
  %t1001 = load i64, ptr %t1000, !tbaa !34
  %t1005 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t1006 = load ptr, ptr %t1005, !tbaa !27
  %t1007 = getelementptr i64, ptr %t1006, i64 %t1001
  %t1008 = load i64, ptr %t1007, !tbaa !34
  %t1009 = extractvalue { i64, ptr } { i64 1, ptr @.d33 }, 1
  %t1010 = extractvalue { i64, ptr } { i64 1, ptr @.d33 }, 0
  %t1012 = call i64 @__olang_fmt_i64(ptr null, i64 %t1008)
  %t1013 = add i64 %t1010, %t1012
  %t1014 = call ptr @__olang_scope_alloc(ptr %s34, i64 %t1013)
  call void @olang_textcopy(ptr %t1014, ptr %t1009, i64 %t1010)
  %t1015 = getelementptr i8, ptr %t1014, i64 %t1010
  %t1016 = call i64 @__olang_fmt_i64(ptr %t1015, i64 %t1008)
  %t1017 = insertvalue { i64, ptr } undef, i64 %t1013, 0
  %t1018 = insertvalue { i64, ptr } %t1017, ptr %t1014, 1
  %t1020 = extractvalue { i64, ptr } %t1018, 0
  %t1021 = extractvalue { i64, ptr } %t1018, 1
  %t1022 = mul i64 %t1020, 1
  %t1023 = call ptr @__olang_scope_alloc(ptr %s34, i64 %t1022)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1023, ptr %t1021, i64 %t1022, i1 false)
  %t1024 = insertvalue { i64, ptr } undef, i64 %t1020, 0
  %t1025 = insertvalue { i64, ptr } %t1024, ptr %t1023, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s31, ptr %s34, ptr %l69, { i64, ptr } %t1025)
  br label %bb257
bb257:
  call void @__olang_scope_close(ptr %s34)
  br label %bb258
bb258:
  %t1028 = load i64, ptr %l71, !tbaa !24
  %t1030 = add i64 %t1028, 1
  store i64 %t1030, ptr %l71, !tbaa !24
  br label %bb253
bb259:
  %t1033 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s31, ptr %s31, ptr %l69)
  store { i64, ptr } %t1033, ptr %l563
  br label %bb260
bb260:
  %t1034 = load { i64, ptr }, ptr %l563, !tbaa !27
  store { i64, ptr } %t1034, ptr %l74, !tbaa !27
  %t1035 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t1038 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %s29, ptr %s31, ptr %l62, { i64, ptr } %t1035)
  %t1039 = extractvalue { i32, i64 } %t1038, 1
  %t1040 = extractvalue { i32, i64 } %t1038, 0
  store i32 %t1040, ptr %l568
  %t1041 = icmp ne i32 %t1040, 0
  br i1 %t1041, label %bb262, label %ok.1042
ok.1042:
  store i64 %t1039, ptr %l567
  br label %bb261
bb261:
  %t1043 = load i64, ptr %l567, !tbaa !24
  store i64 %t1043, ptr %l564, !tbaa !24
  br label %bb264
bb262:
  br label %bb263
bb263:
  store i64 -1, ptr %l564, !tbaa !24
  br label %bb264
bb264:
  %t1044 = load i64, ptr %l564, !tbaa !24
  store i64 %t1044, ptr %l75, !tbaa !24
  %t1045 = load i64, ptr %l75, !tbaa !24
  %t1047 = icmp slt i64 %t1045, 0
  br i1 %t1047, label %bb265, label %bb266
bb265:
  %t1050 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_He890afa3b14bd52c6ea464bca4cef525(ptr %s29, ptr %l62)
  store i64 %t1050, ptr %l572
  br label %bb267
bb266:
  br label %bb269
bb267:
  %t1051 = load i64, ptr %l572, !tbaa !24
  store i64 %t1051, ptr %l75, !tbaa !24
  %t1052 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t1054 = extractvalue { i64, ptr } %t1052, 1
  %t1055 = extractvalue { i64, ptr } %t1052, 0
  %t1056 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t1055)
  call void @olang_textcopy(ptr %t1056, ptr %t1054, i64 %t1055)
  %t1057 = insertvalue { i64, ptr } undef, i64 %t1055, 0
  %t1058 = insertvalue { i64, ptr } %t1057, ptr %t1056, 1
  %t1060 = extractvalue { i64, ptr } %t1058, 0
  %t1061 = extractvalue { i64, ptr } %t1058, 1
  %t1062 = mul i64 %t1060, 1
  %t1063 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t1062)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1063, ptr %t1061, i64 %t1062, i1 false)
  %t1064 = insertvalue { i64, ptr } undef, i64 %t1060, 0
  %t1065 = insertvalue { i64, ptr } %t1064, ptr %t1063, 1
  %t1066 = load i64, ptr %l75, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %s29, ptr %s29, ptr %l62, { i64, ptr } %t1065, i64 %t1066)
  br label %bb268
bb268:
  br label %bb269
bb269:
  %t1070 = load i64, ptr %l68, !tbaa !24
  %t1071 = load i64, ptr %l75, !tbaa !24
  %t1074 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t1075 = load ptr, ptr %t1074, !tbaa !27
  %t1076 = getelementptr i64, ptr %t1075, i64 %t1070
  store i64 %t1071, ptr %t1076, !tbaa !34
  call void @__olang_scope_close(ptr %s31)
  br label %bb270
bb270:
  %t1077 = load i64, ptr %l67, !tbaa !24
  %t1079 = add i64 %t1077, 1
  store i64 %t1079, ptr %l67, !tbaa !24
  br label %bb246
bb271:
  %t1081 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t1081, ptr %l582, !tbaa !27
  %t1082 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t1083 = extractvalue { i64, ptr } %t1082, 0
  %t1084 = load { i64, ptr }, ptr %l582, !tbaa !27
  %t1085 = extractvalue { i64, ptr } %t1084, 0
  store i64 %t1085, ptr %l584, !tbaa !24
  %t1087 = load i64, ptr %l584, !tbaa !24
  %t1088 = icmp eq i64 %t1083, %t1087
  br i1 %t1088, label %bb272, label %bb273
bb272:
  %t1090 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t1091 = load ptr, ptr %t1090, !tbaa !27
  %t1092 = getelementptr { i64, ptr }, ptr %l582, i32 0, i32 1
  %t1093 = load ptr, ptr %t1092, !tbaa !27
  %t1094 = load i64, ptr %l584, !tbaa !24
  %t1095 = mul i64 %t1094, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t1091, ptr %t1093, i64 %t1095, i1 false)
  br label %bb274
bb273:
  %t1096 = load { i64, ptr }, ptr %l582, !tbaa !27
  %t1097 = extractvalue { i64, ptr } %t1096, 0
  store i64 %t1097, ptr %l586, !tbaa !24
  %t1098 = load i64, ptr %l586, !tbaa !24
  %t1099 = mul i64 %t1098, 8
  %t1100 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t1099)
  %t1101 = insertvalue { i64, ptr } undef, i64 %t1098, 0
  %t1102 = insertvalue { i64, ptr } %t1101, ptr %t1100, 1
  store { i64, ptr } %t1102, ptr %l587, !tbaa !27
  %t1103 = getelementptr { i64, ptr }, ptr %l587, i32 0, i32 1
  %t1104 = load ptr, ptr %t1103, !tbaa !27
  %t1105 = getelementptr { i64, ptr }, ptr %l582, i32 0, i32 1
  %t1106 = load ptr, ptr %t1105, !tbaa !27
  %t1107 = load i64, ptr %l586, !tbaa !24
  %t1108 = mul i64 %t1107, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t1104, ptr %t1106, i64 %t1108, i1 false)
  %t1109 = load { i64, ptr }, ptr %l587, !tbaa !27
  store { i64, ptr } %t1109, ptr %l34, !tbaa !27
  br label %bb274
bb274:
  %t1111 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_He890afa3b14bd52c6ea464bca4cef525(ptr %s29, ptr %l62)
  store i64 %t1111, ptr %l589
  br label %bb275
bb275:
  %t1112 = load i64, ptr %l60, !tbaa !24
  %t1113 = load i64, ptr %l589, !tbaa !24
  %t1115 = icmp eq i64 %t1113, %t1112
  br i1 %t1115, label %bb276, label %bb277
bb276:
  call void @__olang_scope_close(ptr %s29)
  br label %bb281
bb277:
  br label %bb278
bb278:
  %t1118 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_He890afa3b14bd52c6ea464bca4cef525(ptr %s29, ptr %l62)
  store i64 %t1118, ptr %l593
  br label %bb279
bb279:
  %t1119 = load i64, ptr %l593, !tbaa !24
  store i64 %t1119, ptr %l60, !tbaa !24
  call void @__olang_scope_close(ptr %s29)
  br label %bb280
bb280:
  br label %bb231
bb281:
  %t1120 = load i64, ptr %l60, !tbaa !24
  store i64 %t1120, ptr %l594, !tbaa !24
  %t1121 = load i64, ptr %l594, !tbaa !24
  %t1122 = icmp sge i64 %t1121, 0
  br i1 %t1122, label %bb282, label %bb283
bb282:
  %t1124 = load i64, ptr %l594, !tbaa !24
  %t1125 = icmp sle i64 %t1124, 1152921504606846975
  br i1 %t1125, label %bb284, label %bb285
bb283:
  call void @__olang_check_failed(ptr @olang_loc_50d6af1e4a9d3e1b_3bae03e7ad9fa57f)
  unreachable
bb284:
  %t1127 = load i64, ptr %l594, !tbaa !24
  %t1128 = mul i64 %t1127, 8
  %t1129 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1128)
  store i64 0, ptr %t1130
  br label %fill.1131
fill.1131:
  %t1134 = load i64, ptr %t1130
  %t1135 = icmp slt i64 %t1134, %t1127
  br i1 %t1135, label %fillb.1132, label %filld.1133
fillb.1132:
  %t1136 = getelementptr i64, ptr %t1129, i64 %t1134
  store i64 -1, ptr %t1136
  %t1137 = add i64 %t1134, 1
  store i64 %t1137, ptr %t1130
  br label %fill.1131
filld.1133:
  %t1138 = insertvalue { i64, ptr } undef, i64 %t1127, 0
  %t1139 = insertvalue { i64, ptr } %t1138, ptr %t1129, 1
  store { i64, ptr } %t1139, ptr %l76, !tbaa !27
  store i64 0, ptr %l77, !tbaa !24
  %t1141 = load i64, ptr %l32, !tbaa !24
  store i64 %t1141, ptr %l78, !tbaa !24
  store i64 1, ptr %l79, !tbaa !24
  %t1143 = load i64, ptr %l78, !tbaa !24
  %t1144 = load i64, ptr %l77, !tbaa !24
  %t1147 = icmp sgt i64 %t1143, %t1144
  br i1 %t1147, label %bb286, label %bb287
bb285:
  call void @__olang_check_failed(ptr @olang_loc_50d6af1e4a9d3e1b_3bae03e7ad9fa57f)
  unreachable
bb286:
  %t1149 = load i64, ptr %l79, !tbaa !24
  %t1151 = icmp sgt i64 %t1149, 0
  br i1 %t1151, label %bb288, label %bb289
bb287:
  store i64 0, ptr %l602, !tbaa !24
  br label %bb291
bb288:
  %t1153 = load i64, ptr %l78, !tbaa !24
  %t1154 = load i64, ptr %l77, !tbaa !24
  %t1157 = sub i64 %t1153, %t1154
  %t1158 = load i64, ptr %l79, !tbaa !24
  %t1161 = add i64 %t1157, %t1158
  %t1163 = sub i64 %t1161, 1
  %t1164 = load i64, ptr %l79, !tbaa !24
  %t1167 = sdiv i64 %t1163, %t1164
  store i64 %t1167, ptr %l605, !tbaa !24
  br label %bb290
bb289:
  store i64 0, ptr %l605, !tbaa !24
  br label %bb290
bb290:
  %t1169 = load i64, ptr %l605, !tbaa !24
  store i64 %t1169, ptr %l602, !tbaa !24
  br label %bb291
bb291:
  %t1170 = load i64, ptr %l602, !tbaa !24
  store i64 %t1170, ptr %l80, !tbaa !24
  store i64 0, ptr %l81, !tbaa !24
  br label %bb292
bb292:
  store %olang.scope zeroinitializer, ptr %s42
  %t1171 = load i64, ptr %l81, !tbaa !24
  %t1172 = load i64, ptr %l80, !tbaa !24
  %t1175 = icmp slt i64 %t1171, %t1172
  %t1177 = xor i1 %t1175, true
  br i1 %t1177, label %bb293, label %bb294
bb293:
  call void @__olang_scope_close(ptr %s42)
  br label %bb318
bb294:
  br label %bb295
bb295:
  %t1179 = load i64, ptr %l77, !tbaa !24
  %t1180 = load i64, ptr %l81, !tbaa !24
  %t1181 = load i64, ptr %l79, !tbaa !24
  %t1184 = mul i64 %t1180, %t1181
  %t1187 = add i64 %t1179, %t1184
  store i64 %t1187, ptr %l82, !tbaa !24
  %t1189 = load i64, ptr %l82, !tbaa !24
  %t1191 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t1192 = load ptr, ptr %t1191, !tbaa !27
  %t1193 = getelementptr i64, ptr %t1192, i64 %t1189
  %t1194 = load i64, ptr %t1193, !tbaa !34
  %t1196 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t1197 = load ptr, ptr %t1196, !tbaa !27
  %t1198 = getelementptr i64, ptr %t1197, i64 %t1194
  %t1199 = load i64, ptr %t1198, !tbaa !34
  store i64 %t1199, ptr %l83, !tbaa !24
  %t1201 = load i64, ptr %l83, !tbaa !24
  %t1203 = icmp slt i64 %t1201, 0
  br i1 %t1203, label %bb296, label %bb297
bb296:
  %t1205 = load i64, ptr %l82, !tbaa !24
  %t1207 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t1208 = load ptr, ptr %t1207, !tbaa !27
  %t1209 = getelementptr i64, ptr %t1208, i64 %t1205
  %t1210 = load i64, ptr %t1209, !tbaa !34
  %t1211 = load i64, ptr %l82, !tbaa !24
  %t1214 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t1215 = load ptr, ptr %t1214, !tbaa !27
  %t1216 = getelementptr i64, ptr %t1215, i64 %t1210
  store i64 %t1211, ptr %t1216, !tbaa !34
  br label %bb316
bb297:
  %t1217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1217, ptr %l631, !tbaa !29
  %t1218 = load i64, ptr %l82, !tbaa !24
  %t1221 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l22, i64 %t1218)
  store i64 %t1221, ptr %l634
  br label %bb298
bb298:
  %t1222 = load ptr, ptr %l631, !tbaa !29
  %t1223 = load i64, ptr %l634, !tbaa !24
  %t1224 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2egroupRank(ptr %v0, ptr %t1222, i64 %t1223)
  store i64 %t1224, ptr %l635
  br label %bb299
bb299:
  %t1225 = load i64, ptr %l635, !tbaa !24
  store i64 %t1225, ptr %l84, !tbaa !24
  %t1226 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1226, ptr %l636, !tbaa !29
  %t1227 = load i64, ptr %l83, !tbaa !24
  %t1230 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l22, i64 %t1227)
  store i64 %t1230, ptr %l639
  br label %bb300
bb300:
  %t1231 = load ptr, ptr %l636, !tbaa !29
  %t1232 = load i64, ptr %l639, !tbaa !24
  %t1233 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2egroupRank(ptr %v0, ptr %t1231, i64 %t1232)
  store i64 %t1233, ptr %l640
  br label %bb301
bb301:
  %t1234 = load i64, ptr %l640, !tbaa !24
  store i64 %t1234, ptr %l85, !tbaa !24
  %t1235 = load i64, ptr %l84, !tbaa !24
  %t1236 = load i64, ptr %l85, !tbaa !24
  %t1239 = icmp slt i64 %t1235, %t1236
  br i1 %t1239, label %bb302, label %bb303
bb302:
  store i1 true, ptr %l644, !tbaa !21
  br label %bb312
bb303:
  %t1241 = load i64, ptr %l84, !tbaa !24
  %t1242 = load i64, ptr %l85, !tbaa !24
  %t1245 = icmp eq i64 %t1241, %t1242
  br i1 %t1245, label %bb304, label %bb305
bb304:
  %t1247 = load ptr, ptr %l0, !tbaa !29
  %t1249 = getelementptr %"compiler/emit:Emitter", ptr %t1247, i32 0, i32 14
  store ptr %t1249, ptr %l650, !tbaa !29
  %t1250 = load i64, ptr %l82, !tbaa !24
  %t1253 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l22, i64 %t1250)
  store i64 %t1253, ptr %l653
  br label %bb306
bb305:
  store i1 false, ptr %l648, !tbaa !21
  br label %bb311
bb306:
  %t1254 = load ptr, ptr %l650, !tbaa !29
  %t1255 = load i64, ptr %l653, !tbaa !24
  %t1256 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t1254, i64 %t1255)
  store { i64, ptr } %t1256, ptr %l654
  br label %bb307
bb307:
  %t1257 = load ptr, ptr %l0, !tbaa !29
  %t1259 = getelementptr %"compiler/emit:Emitter", ptr %t1257, i32 0, i32 14
  store ptr %t1259, ptr %l656, !tbaa !29
  %t1260 = load i64, ptr %l83, !tbaa !24
  %t1263 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l22, i64 %t1260)
  store i64 %t1263, ptr %l659
  br label %bb308
bb308:
  %t1264 = load ptr, ptr %l656, !tbaa !29
  %t1265 = load i64, ptr %l659, !tbaa !24
  %t1266 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t1264, i64 %t1265)
  store { i64, ptr } %t1266, ptr %l660
  br label %bb309
bb309:
  %t1267 = load { i64, ptr }, ptr %l654, !tbaa !27
  %t1268 = load { i64, ptr }, ptr %l660, !tbaa !27
  %t1269 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v0, { i64, ptr } %t1267, { i64, ptr } %t1268)
  store i1 %t1269, ptr %l661
  br label %bb310
bb310:
  %t1270 = load i1, ptr %l661, !tbaa !21
  store i1 %t1270, ptr %l648, !tbaa !21
  br label %bb311
bb311:
  %t1271 = load i1, ptr %l648, !tbaa !21
  store i1 %t1271, ptr %l644, !tbaa !21
  br label %bb312
bb312:
  %t1272 = load i1, ptr %l644, !tbaa !21
  br i1 %t1272, label %bb313, label %bb314
bb313:
  %t1273 = load i64, ptr %l82, !tbaa !24
  %t1275 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t1276 = load ptr, ptr %t1275, !tbaa !27
  %t1277 = getelementptr i64, ptr %t1276, i64 %t1273
  %t1278 = load i64, ptr %t1277, !tbaa !34
  %t1279 = load i64, ptr %l82, !tbaa !24
  %t1282 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t1283 = load ptr, ptr %t1282, !tbaa !27
  %t1284 = getelementptr i64, ptr %t1283, i64 %t1278
  store i64 %t1279, ptr %t1284, !tbaa !34
  br label %bb315
bb314:
  br label %bb315
bb315:
  br label %bb316
bb316:
  call void @__olang_scope_close(ptr %s42)
  br label %bb317
bb317:
  %t1285 = load i64, ptr %l81, !tbaa !24
  %t1287 = add i64 %t1285, 1
  store i64 %t1287, ptr %l81, !tbaa !24
  br label %bb292
bb318:
  store i64 0, ptr %l86, !tbaa !24
  %t1289 = load i64, ptr %l32, !tbaa !24
  store i64 %t1289, ptr %l87, !tbaa !24
  store i64 1, ptr %l88, !tbaa !24
  %t1291 = load i64, ptr %l87, !tbaa !24
  %t1292 = load i64, ptr %l86, !tbaa !24
  %t1295 = icmp sgt i64 %t1291, %t1292
  br i1 %t1295, label %bb319, label %bb320
bb319:
  %t1297 = load i64, ptr %l88, !tbaa !24
  %t1299 = icmp sgt i64 %t1297, 0
  br i1 %t1299, label %bb321, label %bb322
bb320:
  store i64 0, ptr %l671, !tbaa !24
  br label %bb324
bb321:
  %t1301 = load i64, ptr %l87, !tbaa !24
  %t1302 = load i64, ptr %l86, !tbaa !24
  %t1305 = sub i64 %t1301, %t1302
  %t1306 = load i64, ptr %l88, !tbaa !24
  %t1309 = add i64 %t1305, %t1306
  %t1311 = sub i64 %t1309, 1
  %t1312 = load i64, ptr %l88, !tbaa !24
  %t1315 = sdiv i64 %t1311, %t1312
  store i64 %t1315, ptr %l674, !tbaa !24
  br label %bb323
bb322:
  store i64 0, ptr %l674, !tbaa !24
  br label %bb323
bb323:
  %t1317 = load i64, ptr %l674, !tbaa !24
  store i64 %t1317, ptr %l671, !tbaa !24
  br label %bb324
bb324:
  %t1318 = load i64, ptr %l671, !tbaa !24
  store i64 %t1318, ptr %l89, !tbaa !24
  store i64 0, ptr %l90, !tbaa !24
  br label %bb325
bb325:
  store %olang.scope zeroinitializer, ptr %s48
  %t1319 = load i64, ptr %l90, !tbaa !24
  %t1320 = load i64, ptr %l89, !tbaa !24
  %t1323 = icmp slt i64 %t1319, %t1320
  %t1325 = xor i1 %t1323, true
  br i1 %t1325, label %bb326, label %bb327
bb326:
  call void @__olang_scope_close(ptr %s48)
  br label %bb336
bb327:
  br label %bb328
bb328:
  %t1327 = load i64, ptr %l86, !tbaa !24
  %t1328 = load i64, ptr %l90, !tbaa !24
  %t1329 = load i64, ptr %l88, !tbaa !24
  %t1332 = mul i64 %t1328, %t1329
  %t1335 = add i64 %t1327, %t1332
  store i64 %t1335, ptr %l91, !tbaa !24
  %t1337 = load i64, ptr %l91, !tbaa !24
  %t1339 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t1340 = load ptr, ptr %t1339, !tbaa !27
  %t1341 = getelementptr i64, ptr %t1340, i64 %t1337
  %t1342 = load i64, ptr %t1341, !tbaa !34
  %t1344 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t1345 = load ptr, ptr %t1344, !tbaa !27
  %t1346 = getelementptr i64, ptr %t1345, i64 %t1342
  %t1347 = load i64, ptr %t1346, !tbaa !34
  store i64 %t1347, ptr %l92, !tbaa !24
  %t1349 = load i64, ptr %l92, !tbaa !24
  %t1350 = load i64, ptr %l91, !tbaa !24
  %t1353 = icmp ne i64 %t1349, %t1350
  br i1 %t1353, label %bb329, label %bb330
bb329:
  %t1355 = load ptr, ptr %l0, !tbaa !29
  %t1357 = getelementptr %"compiler/emit:Emitter", ptr %t1355, i32 0, i32 56
  store ptr %t1357, ptr %l699, !tbaa !29
  %t1358 = load i64, ptr %l91, !tbaa !24
  %t1361 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l22, i64 %t1358)
  store i64 %t1361, ptr %l702
  br label %bb331
bb330:
  br label %bb334
bb331:
  %t1362 = load i64, ptr %l92, !tbaa !24
  %t1365 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l22, i64 %t1362)
  store i64 %t1365, ptr %l705
  br label %bb332
bb332:
  %t1366 = load ptr, ptr %l699, !tbaa !29
  %t1367 = load i64, ptr %l702, !tbaa !24
  %t1368 = load i64, ptr %l705, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t1366, i64 %t1367, i64 %t1368)
  br label %bb333
bb333:
  br label %bb334
bb334:
  call void @__olang_scope_close(ptr %s48)
  br label %bb335
bb335:
  %t1369 = load i64, ptr %l90, !tbaa !24
  %t1371 = add i64 %t1369, 1
  store i64 %t1371, ptr %l90, !tbaa !24
  br label %bb325
bb336:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eparts(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, i32 %a3, i64 %a4, i1 %a5, i1 %a6, ptr %a7, i64 %a8) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca i1
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l37 = alloca i1
  %l40 = alloca i1
  %l48 = alloca i64
  %l49 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l54 = alloca i64
  %l57 = alloca i64
  %l76 = alloca i64
  %l80 = alloca i64
  %l84 = alloca i64
  %l87 = alloca i64
  %l108 = alloca i64
  %l112 = alloca i1
  %l114 = alloca i1
  %l118 = alloca i1
  %l121 = alloca i1
  %l124 = alloca i64
  %l127 = alloca i1
  %l130 = alloca i1
  %l133 = alloca i64
  %l136 = alloca i64
  %l140 = alloca { i64, ptr }
  %l147 = alloca i64
  %l154 = alloca i64
  %l165 = alloca i1
  %l172 = alloca i64
  %l175 = alloca i64
  %l195 = alloca { i64, ptr }
  %l198 = alloca { i64, ptr }
  %l207 = alloca ptr
  %l210 = alloca { i64, ptr }
  %l211 = alloca i32
  %l221 = alloca { i64, ptr }
  %l223 = alloca %"compiler/emit:Object"
  %l229 = alloca i64
  %l231 = alloca ptr
  %l232 = alloca { i64, ptr }
  %l235 = alloca { i64, ptr }
  %l237 = alloca { i64, ptr }
  %l238 = alloca i32
  %l241 = alloca { i64, ptr }
  %l243 = alloca %"compiler/emit:Object"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i64 %a4, ptr %l4
  store i1 %a5, ptr %l5
  store i1 %a6, ptr %l6
  store i64 %a8, ptr %l8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i1, ptr %l6, !tbaa !21
  br i1 %t1, label %bb1, label %bb2
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/emit:Emitter", ptr %t3, i32 0, i32 4
  %t6 = load i1, ptr %t5, !tbaa !21
  store i1 %t6, ptr %l37, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb3
bb3:
  %t8 = load i1, ptr %l37, !tbaa !21
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t9 = load i64, ptr %l4, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/emit:Emitter", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/load:Loader", ptr %t16, i32 0, i32 7
  %t19 = load i64, ptr %t18, !tbaa !24
  %t22 = icmp eq i64 %t9, %t19
  store i1 %t22, ptr %l40, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l40, !tbaa !21
  store i1 %t24, ptr %l9, !tbaa !21
  %t25 = load i1, ptr %l9, !tbaa !21
  br i1 %t25, label %bb7, label %bb8
bb7:
  store i64 2, ptr %l48, !tbaa !24
  br label %bb9
bb8:
  store i64 1, ptr %l48, !tbaa !24
  br label %bb9
bb9:
  %t27 = load i64, ptr %l48, !tbaa !24
  store i64 %t27, ptr %l10, !tbaa !24
  %t28 = load ptr, ptr @__olang_prog_scope
  %t29 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t28)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t29, ptr %l49
  br label %bb10
bb10:
  %t30 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l49
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t30, ptr %l11
  store i64 0, ptr %l12, !tbaa !24
  %t31 = load i64, ptr %l10, !tbaa !24
  store i64 %t31, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t33 = load i64, ptr %l13, !tbaa !24
  %t34 = load i64, ptr %l12, !tbaa !24
  %t37 = icmp sgt i64 %t33, %t34
  br i1 %t37, label %bb11, label %bb12
bb11:
  %t39 = load i64, ptr %l14, !tbaa !24
  %t41 = icmp sgt i64 %t39, 0
  br i1 %t41, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb16
bb13:
  %t43 = load i64, ptr %l13, !tbaa !24
  %t44 = load i64, ptr %l12, !tbaa !24
  %t47 = sub i64 %t43, %t44
  %t48 = load i64, ptr %l14, !tbaa !24
  %t51 = add i64 %t47, %t48
  %t53 = sub i64 %t51, 1
  %t54 = load i64, ptr %l14, !tbaa !24
  %t57 = sdiv i64 %t53, %t54
  store i64 %t57, ptr %l57, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb15
bb15:
  %t59 = load i64, ptr %l57, !tbaa !24
  store i64 %t59, ptr %l54, !tbaa !24
  br label %bb16
bb16:
  %t60 = load i64, ptr %l54, !tbaa !24
  store i64 %t60, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s2
  %t61 = load i64, ptr %l16, !tbaa !24
  %t62 = load i64, ptr %l15, !tbaa !24
  %t65 = icmp slt i64 %t61, %t62
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb99
bb19:
  br label %bb20
bb20:
  %t69 = load i64, ptr %l12, !tbaa !24
  %t70 = load i64, ptr %l16, !tbaa !24
  %t71 = load i64, ptr %l14, !tbaa !24
  %t74 = mul i64 %t70, %t71
  %t77 = add i64 %t69, %t74
  store i64 %t77, ptr %l17, !tbaa !24
  %t79 = load i1, ptr %l9, !tbaa !21
  br i1 %t79, label %bb21, label %bb22
bb21:
  %t81 = load i64, ptr %l17, !tbaa !24
  store i64 %t81, ptr %l76, !tbaa !24
  br label %bb23
bb22:
  store i64 -1, ptr %l76, !tbaa !24
  br label %bb23
bb23:
  %t83 = load i64, ptr %l76, !tbaa !24
  store i64 %t83, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/emit:Emitter", ptr %t84, i32 0, i32 14
  %t88 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t86)
  store i64 %t88, ptr %l80
  br label %bb24
bb24:
  %t89 = load i64, ptr %l80, !tbaa !24
  store i64 %t89, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t90 = load i64, ptr %l21, !tbaa !24
  %t91 = load i64, ptr %l20, !tbaa !24
  %t94 = icmp sgt i64 %t90, %t91
  br i1 %t94, label %bb25, label %bb26
bb25:
  %t96 = load i64, ptr %l22, !tbaa !24
  %t98 = icmp sgt i64 %t96, 0
  br i1 %t98, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l84, !tbaa !24
  br label %bb30
bb27:
  %t100 = load i64, ptr %l21, !tbaa !24
  %t101 = load i64, ptr %l20, !tbaa !24
  %t104 = sub i64 %t100, %t101
  %t105 = load i64, ptr %l22, !tbaa !24
  %t108 = add i64 %t104, %t105
  %t110 = sub i64 %t108, 1
  %t111 = load i64, ptr %l22, !tbaa !24
  %t114 = sdiv i64 %t110, %t111
  store i64 %t114, ptr %l87, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb29
bb29:
  %t116 = load i64, ptr %l87, !tbaa !24
  store i64 %t116, ptr %l84, !tbaa !24
  br label %bb30
bb30:
  %t117 = load i64, ptr %l84, !tbaa !24
  store i64 %t117, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s4
  %t118 = load i64, ptr %l24, !tbaa !24
  %t119 = load i64, ptr %l23, !tbaa !24
  %t122 = icmp slt i64 %t118, %t119
  %t124 = xor i1 %t122, true
  br i1 %t124, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s4)
  br label %bb61
bb33:
  br label %bb34
bb34:
  %t126 = load i64, ptr %l20, !tbaa !24
  %t127 = load i64, ptr %l24, !tbaa !24
  %t128 = load i64, ptr %l22, !tbaa !24
  %t131 = mul i64 %t127, %t128
  %t134 = add i64 %t126, %t131
  store i64 %t134, ptr %l25, !tbaa !24
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/emit:Emitter", ptr %t136, i32 0, i32 16
  %t139 = load i64, ptr %l25, !tbaa !24
  %t142 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t138, i64 %t139)
  store i64 %t142, ptr %l108
  br label %bb35
bb35:
  %t143 = load i64, ptr %l108, !tbaa !24
  store i64 %t143, ptr %l26, !tbaa !24
  %t144 = load i64, ptr %l26, !tbaa !24
  %t145 = load i64, ptr %l4, !tbaa !24
  %t148 = icmp eq i64 %t144, %t145
  br i1 %t148, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l112, !tbaa !21
  br label %bb41
bb37:
  %t150 = load i1, ptr %l5, !tbaa !21
  br i1 %t150, label %bb38, label %bb39
bb38:
  %t152 = load i64, ptr %l26, !tbaa !24
  %t153 = load i64, ptr @G_2ecompiler_2femit_2eHomeInst, !tbaa !24
  %t156 = icmp eq i64 %t152, %t153
  store i1 %t156, ptr %l114, !tbaa !21
  br label %bb40
bb39:
  store i1 false, ptr %l114, !tbaa !21
  br label %bb40
bb40:
  %t158 = load i1, ptr %l114, !tbaa !21
  store i1 %t158, ptr %l112, !tbaa !21
  br label %bb41
bb41:
  %t159 = load i1, ptr %l112, !tbaa !21
  br i1 %t159, label %bb42, label %bb43
bb42:
  %t160 = load i64, ptr %l18, !tbaa !24
  %t162 = icmp slt i64 %t160, 0
  br i1 %t162, label %bb44, label %bb45
bb43:
  store i1 false, ptr %l118, !tbaa !21
  br label %bb48
bb44:
  store i1 true, ptr %l121, !tbaa !21
  br label %bb47
bb45:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load i64, ptr %l25, !tbaa !24
  %t168 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2egroupOf(ptr %v0, ptr %t164, i64 %t165)
  store i64 %t168, ptr %l124
  br label %bb46
bb46:
  %t169 = load i64, ptr %l18, !tbaa !24
  %t170 = load i64, ptr %l124, !tbaa !24
  %t172 = icmp eq i64 %t170, %t169
  store i1 %t172, ptr %l121, !tbaa !21
  br label %bb47
bb47:
  %t174 = load i1, ptr %l121, !tbaa !21
  store i1 %t174, ptr %l118, !tbaa !21
  br label %bb48
bb48:
  %t175 = load i1, ptr %l118, !tbaa !21
  br i1 %t175, label %bb49, label %bb50
bb49:
  %t176 = load i64, ptr %l8, !tbaa !24
  %t178 = icmp slt i64 %t176, 0
  br i1 %t178, label %bb51, label %bb52
bb50:
  store i1 false, ptr %l127, !tbaa !21
  br label %bb55
bb51:
  store i1 true, ptr %l130, !tbaa !21
  br label %bb54
bb52:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load i64, ptr %l25, !tbaa !24
  %t184 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2einstGroupOf(ptr %v0, ptr %t180, i64 %t181)
  store i64 %t184, ptr %l133
  br label %bb53
bb53:
  %t185 = load i64, ptr %l8, !tbaa !24
  %t186 = load i64, ptr %l133, !tbaa !24
  %t188 = icmp eq i64 %t186, %t185
  store i1 %t188, ptr %l130, !tbaa !21
  br label %bb54
bb54:
  %t190 = load i1, ptr %l130, !tbaa !21
  store i1 %t190, ptr %l127, !tbaa !21
  br label %bb55
bb55:
  %t191 = load i1, ptr %l127, !tbaa !21
  br i1 %t191, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s5
  %t192 = load i64, ptr %l19, !tbaa !24
  store i64 %t192, ptr %l136, !tbaa !24
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/emit:Emitter", ptr %t193, i32 0, i32 15
  %t196 = load i64, ptr %l25, !tbaa !24
  %t199 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %s5, ptr %t195, i64 %t196)
  store { i64, ptr } %t199, ptr %l140
  br label %bb58
bb57:
  br label %bb59
bb58:
  %t200 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t201 = extractvalue { i64, ptr } %t200, 0
  %t202 = load i64, ptr %l136, !tbaa !24
  %t204 = add i64 %t202, %t201
  store i64 %t204, ptr %l19, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s4)
  br label %bb60
bb60:
  %t206 = load i64, ptr %l24, !tbaa !24
  %t208 = add i64 %t206, 1
  store i64 %t208, ptr %l24, !tbaa !24
  br label %bb31
bb61:
  %t210 = load i64, ptr %l18, !tbaa !24
  %t212 = icmp eq i64 %t210, 1
  br i1 %t212, label %bb62, label %bb63
bb62:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/emit:Emitter", ptr %t214, i32 0, i32 39
  %t217 = load i64, ptr %t216, !tbaa !24
  %t219 = sdiv i64 %t217, 4
  store i64 %t219, ptr %l147, !tbaa !24
  br label %bb64
bb63:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/emit:Emitter", ptr %t221, i32 0, i32 39
  %t224 = load i64, ptr %t223, !tbaa !24
  store i64 %t224, ptr %l147, !tbaa !24
  br label %bb64
bb64:
  %t226 = load i64, ptr %l147, !tbaa !24
  store i64 %t226, ptr %l27, !tbaa !24
  %t227 = load i1, ptr %l6, !tbaa !21
  br i1 %t227, label %bb65, label %bb66
bb65:
  %t229 = load i64, ptr %l19, !tbaa !24
  %t230 = load i64, ptr %l27, !tbaa !24
  %t233 = add i64 %t229, %t230
  %t235 = sub i64 %t233, 1
  %t236 = load i64, ptr %l27, !tbaa !24
  %t239 = sdiv i64 %t235, %t236
  store i64 %t239, ptr %l154, !tbaa !24
  br label %bb67
bb66:
  store i64 1, ptr %l154, !tbaa !24
  br label %bb67
bb67:
  %t241 = load i64, ptr %l154, !tbaa !24
  store i64 %t241, ptr %l28, !tbaa !24
  %t242 = load i64, ptr %l28, !tbaa !24
  %t244 = icmp slt i64 %t242, 1
  br i1 %t244, label %bb68, label %bb69
bb68:
  store i64 1, ptr %l28, !tbaa !24
  br label %bb70
bb69:
  br label %bb70
bb70:
  %t246 = load i64, ptr %l18, !tbaa !24
  %t248 = icmp eq i64 %t246, 1
  br i1 %t248, label %bb71, label %bb72
bb71:
  %t250 = load i64, ptr %l19, !tbaa !24
  %t252 = icmp eq i64 %t250, 0
  store i1 %t252, ptr %l165, !tbaa !21
  br label %bb73
bb72:
  store i1 false, ptr %l165, !tbaa !21
  br label %bb73
bb73:
  %t254 = load i1, ptr %l165, !tbaa !21
  br i1 %t254, label %bb74, label %bb75
bb74:
  call void @__olang_scope_close(ptr %s2)
  br label %bb98
bb75:
  br label %bb76
bb76:
  store i64 0, ptr %l29, !tbaa !24
  %t255 = load i64, ptr %l28, !tbaa !24
  store i64 %t255, ptr %l30, !tbaa !24
  store i64 1, ptr %l31, !tbaa !24
  %t257 = load i64, ptr %l30, !tbaa !24
  %t258 = load i64, ptr %l29, !tbaa !24
  %t261 = icmp sgt i64 %t257, %t258
  br i1 %t261, label %bb77, label %bb78
bb77:
  %t263 = load i64, ptr %l31, !tbaa !24
  %t265 = icmp sgt i64 %t263, 0
  br i1 %t265, label %bb79, label %bb80
bb78:
  store i64 0, ptr %l172, !tbaa !24
  br label %bb82
bb79:
  %t267 = load i64, ptr %l30, !tbaa !24
  %t268 = load i64, ptr %l29, !tbaa !24
  %t271 = sub i64 %t267, %t268
  %t272 = load i64, ptr %l31, !tbaa !24
  %t275 = add i64 %t271, %t272
  %t277 = sub i64 %t275, 1
  %t278 = load i64, ptr %l31, !tbaa !24
  %t281 = sdiv i64 %t277, %t278
  store i64 %t281, ptr %l175, !tbaa !24
  br label %bb81
bb80:
  store i64 0, ptr %l175, !tbaa !24
  br label %bb81
bb81:
  %t283 = load i64, ptr %l175, !tbaa !24
  store i64 %t283, ptr %l172, !tbaa !24
  br label %bb82
bb82:
  %t284 = load i64, ptr %l172, !tbaa !24
  store i64 %t284, ptr %l32, !tbaa !24
  store i64 0, ptr %l33, !tbaa !24
  br label %bb83
bb83:
  store %olang.scope zeroinitializer, ptr %s10
  %t285 = load i64, ptr %l33, !tbaa !24
  %t286 = load i64, ptr %l32, !tbaa !24
  %t289 = icmp slt i64 %t285, %t286
  %t291 = xor i1 %t289, true
  br i1 %t291, label %bb84, label %bb85
bb84:
  call void @__olang_scope_close(ptr %s10)
  br label %bb97
bb85:
  br label %bb86
bb86:
  %t293 = load i64, ptr %l29, !tbaa !24
  %t294 = load i64, ptr %l33, !tbaa !24
  %t295 = load i64, ptr %l31, !tbaa !24
  %t298 = mul i64 %t294, %t295
  %t301 = add i64 %t293, %t298
  store i64 %t301, ptr %l34, !tbaa !24
  %t303 = load i64, ptr %l18, !tbaa !24
  %t305 = icmp ne i64 %t303, 1
  br i1 %t305, label %bb87, label %bb88
bb87:
  %t307 = load i64, ptr %l34, !tbaa !24
  %t309 = icmp eq i64 %t307, 0
  br i1 %t309, label %bb89, label %bb90
bb88:
  %t311 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t312 = load i64, ptr %l34, !tbaa !24
  %t314 = extractvalue { i64, ptr } %t311, 1
  %t315 = extractvalue { i64, ptr } %t311, 0
  %t316 = extractvalue { i64, ptr } { i64 2, ptr @.d34 }, 1
  %t317 = extractvalue { i64, ptr } { i64 2, ptr @.d34 }, 0
  %t318 = add i64 %t315, %t317
  %t320 = call i64 @__olang_fmt_i64(ptr null, i64 %t312)
  %t321 = add i64 %t318, %t320
  %t322 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t321)
  call void @olang_textcopy(ptr %t322, ptr %t314, i64 %t315)
  %t323 = getelementptr i8, ptr %t322, i64 %t315
  call void @olang_textcopy(ptr %t323, ptr %t316, i64 %t317)
  %t324 = getelementptr i8, ptr %t323, i64 %t317
  %t325 = call i64 @__olang_fmt_i64(ptr %t324, i64 %t312)
  %t326 = insertvalue { i64, ptr } undef, i64 %t321, 0
  %t327 = insertvalue { i64, ptr } %t326, ptr %t322, 1
  store { i64, ptr } %t327, ptr %l195, !tbaa !27
  br label %bb92
bb89:
  %t329 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t331 = extractvalue { i64, ptr } %t329, 1
  %t332 = extractvalue { i64, ptr } %t329, 0
  %t333 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t332)
  call void @olang_textcopy(ptr %t333, ptr %t331, i64 %t332)
  %t334 = insertvalue { i64, ptr } undef, i64 %t332, 0
  %t335 = insertvalue { i64, ptr } %t334, ptr %t333, 1
  store { i64, ptr } %t335, ptr %l198, !tbaa !27
  br label %bb91
bb90:
  %t337 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t338 = load i64, ptr %l34, !tbaa !24
  %t340 = extractvalue { i64, ptr } %t337, 1
  %t341 = extractvalue { i64, ptr } %t337, 0
  %t342 = extractvalue { i64, ptr } { i64 1, ptr @.d35 }, 1
  %t343 = extractvalue { i64, ptr } { i64 1, ptr @.d35 }, 0
  %t344 = add i64 %t341, %t343
  %t346 = call i64 @__olang_fmt_i64(ptr null, i64 %t338)
  %t347 = add i64 %t344, %t346
  %t348 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t347)
  call void @olang_textcopy(ptr %t348, ptr %t340, i64 %t341)
  %t349 = getelementptr i8, ptr %t348, i64 %t341
  call void @olang_textcopy(ptr %t349, ptr %t342, i64 %t343)
  %t350 = getelementptr i8, ptr %t349, i64 %t343
  %t351 = call i64 @__olang_fmt_i64(ptr %t350, i64 %t338)
  %t352 = insertvalue { i64, ptr } undef, i64 %t347, 0
  %t353 = insertvalue { i64, ptr } %t352, ptr %t348, 1
  store { i64, ptr } %t353, ptr %l198, !tbaa !27
  br label %bb91
bb91:
  %t355 = load { i64, ptr }, ptr %l198, !tbaa !27
  store { i64, ptr } %t355, ptr %l195, !tbaa !27
  br label %bb92
bb92:
  %t356 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t357 = load ptr, ptr %l1, !tbaa !29
  store ptr %t357, ptr %l207, !tbaa !29
  %t360 = extractvalue { i64, ptr } %t356, 1
  %t361 = extractvalue { i64, ptr } %t356, 0
  %t362 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t361)
  call void @olang_textcopy(ptr %t362, ptr %t360, i64 %t361)
  %t363 = insertvalue { i64, ptr } undef, i64 %t361, 0
  %t364 = insertvalue { i64, ptr } %t363, ptr %t362, 1
  %t366 = extractvalue { i64, ptr } %t364, 0
  %t367 = extractvalue { i64, ptr } %t364, 1
  %t368 = mul i64 %t366, 1
  %t369 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t368)
  call void @llvm.memcpy.p0.p0.i64(ptr %t369, ptr %t367, i64 %t368, i1 false)
  %t370 = insertvalue { i64, ptr } undef, i64 %t366, 0
  %t371 = insertvalue { i64, ptr } %t370, ptr %t369, 1
  store { i64, ptr } %t371, ptr %l210, !tbaa !27
  %t372 = load i32, ptr %l3
  store i32 %t372, ptr %l211
  %t373 = load ptr, ptr %l0, !tbaa !29
  %t374 = load i64, ptr %l4, !tbaa !24
  %t375 = load i1, ptr %l5, !tbaa !21
  %t376 = load i64, ptr %l34, !tbaa !24
  %t377 = load i64, ptr %l28, !tbaa !24
  %t379 = load i64, ptr %l18, !tbaa !24
  %t380 = load i64, ptr %l8, !tbaa !24
  %t390 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eassemble(ptr %v0, ptr %v3, ptr %s0, ptr %v1, ptr %t373, i64 %t374, i1 %t375, i64 %t376, i64 %t377, ptr %a7, i64 %t379, ptr %l11, i64 %t380)
  store { i64, ptr } %t390, ptr %l221
  br label %bb93
bb93:
  %t391 = load { i64, ptr }, ptr %l221, !tbaa !27
  %t392 = extractvalue { i64, ptr } %t391, 0
  %t393 = extractvalue { i64, ptr } %t391, 1
  %t394 = mul i64 %t392, 1
  %t395 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t394)
  call void @llvm.memcpy.p0.p0.i64(ptr %t395, ptr %t393, i64 %t394, i1 false)
  %t396 = insertvalue { i64, ptr } undef, i64 %t392, 0
  %t397 = insertvalue { i64, ptr } %t396, ptr %t395, 1
  %t398 = load { i64, ptr }, ptr %l210, !tbaa !27
  %t399 = load i32, ptr %l211
  %t401 = call %"compiler/emit:Object" @compiler_2femit_3aObject_2ector(ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t398, i32 %t399, { i64, ptr } %t397)
  store %"compiler/emit:Object" %t401, ptr %l223
  br label %bb94
bb94:
  %t402 = load ptr, ptr %l207, !tbaa !29
  %t403 = load %"compiler/emit:Object", ptr %l223
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2ePush_3ccompiler_2femit_3aObject_3e(ptr %v1, ptr %v1, ptr %t402, %"compiler/emit:Object" %t403)
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s10)
  br label %bb96
bb96:
  %t404 = load i64, ptr %l33, !tbaa !24
  %t406 = add i64 %t404, 1
  store i64 %t406, ptr %l33, !tbaa !24
  br label %bb83
bb97:
  call void @__olang_scope_close(ptr %s2)
  br label %bb98
bb98:
  %t408 = load i64, ptr %l16, !tbaa !24
  %t410 = add i64 %t408, 1
  store i64 %t410, ptr %l16, !tbaa !24
  br label %bb17
bb99:
  %t413 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eLen_3cI64_2c_20Bool_3e(ptr %s0, ptr %l11)
  store i64 %t413, ptr %l229
  br label %bb100
bb100:
  %t414 = load i64, ptr %l229, !tbaa !24
  %t415 = icmp sgt i64 %t414, 0
  br i1 %t415, label %bb101, label %bb102
bb101:
  %t417 = load ptr, ptr %l1, !tbaa !29
  store ptr %t417, ptr %l231, !tbaa !29
  %t418 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t418, ptr %l232, !tbaa !27
  %t419 = load i32, ptr %l3
  %t421 = trunc i64 3 to i32
  %t422 = icmp eq i32 %t419, %t421
  br i1 %t422, label %bb103, label %bb104
bb102:
  br label %bb109
bb103:
  store { i64, ptr } { i64 2, ptr @.d36 }, ptr %l235, !tbaa !27
  br label %bb105
bb104:
  store { i64, ptr } { i64 0, ptr @.d37 }, ptr %l235, !tbaa !27
  br label %bb105
bb105:
  %t424 = load { i64, ptr }, ptr %l232, !tbaa !27
  %t425 = extractvalue { i64, ptr } %t424, 1
  %t426 = extractvalue { i64, ptr } %t424, 0
  %t427 = load { i64, ptr }, ptr %l235, !tbaa !27
  %t428 = extractvalue { i64, ptr } %t427, 1
  %t429 = extractvalue { i64, ptr } %t427, 0
  %t430 = add i64 %t426, %t429
  %t431 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t430)
  call void @olang_textcopy(ptr %t431, ptr %t425, i64 %t426)
  %t432 = getelementptr i8, ptr %t431, i64 %t426
  call void @olang_textcopy(ptr %t432, ptr %t428, i64 %t429)
  %t433 = insertvalue { i64, ptr } undef, i64 %t430, 0
  %t434 = insertvalue { i64, ptr } %t433, ptr %t431, 1
  %t436 = extractvalue { i64, ptr } %t434, 0
  %t437 = extractvalue { i64, ptr } %t434, 1
  %t438 = mul i64 %t436, 1
  %t439 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t438)
  call void @llvm.memcpy.p0.p0.i64(ptr %t439, ptr %t437, i64 %t438, i1 false)
  %t440 = insertvalue { i64, ptr } undef, i64 %t436, 0
  %t441 = insertvalue { i64, ptr } %t440, ptr %t439, 1
  store { i64, ptr } %t441, ptr %l237, !tbaa !27
  store i32 4, ptr %l238
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t445 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2elocations(ptr %v0, ptr %s0, ptr %v1, ptr %t442, ptr %l11)
  store { i64, ptr } %t445, ptr %l241
  br label %bb106
bb106:
  %t446 = load { i64, ptr }, ptr %l241, !tbaa !27
  %t447 = extractvalue { i64, ptr } %t446, 0
  %t448 = extractvalue { i64, ptr } %t446, 1
  %t449 = mul i64 %t447, 1
  %t450 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t449)
  call void @llvm.memcpy.p0.p0.i64(ptr %t450, ptr %t448, i64 %t449, i1 false)
  %t451 = insertvalue { i64, ptr } undef, i64 %t447, 0
  %t452 = insertvalue { i64, ptr } %t451, ptr %t450, 1
  %t453 = load { i64, ptr }, ptr %l237, !tbaa !27
  %t454 = load i32, ptr %l238
  %t456 = call %"compiler/emit:Object" @compiler_2femit_3aObject_2ector(ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t453, i32 %t454, { i64, ptr } %t452)
  store %"compiler/emit:Object" %t456, ptr %l243
  br label %bb107
bb107:
  %t457 = load ptr, ptr %l231, !tbaa !29
  %t458 = load %"compiler/emit:Object", ptr %l243
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2ePush_3ccompiler_2femit_3aObject_3e(ptr %v1, ptr %v1, ptr %t457, %"compiler/emit:Object" %t458)
  br label %bb108
bb108:
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2erefs(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l5 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l17 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 19
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %s0, ptr %t3, i64 %t4)
  store { i64, ptr } %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  %t11 = icmp eq i64 %t9, 0
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/emit:Emitter", ptr %t13, i32 0, i32 19
  store ptr %t15, ptr %l9, !tbaa !29
  %t16 = load i64, ptr %l1, !tbaa !24
  store i64 %t16, ptr %l10, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/emit:Emitter", ptr %t17, i32 0, i32 15
  %t20 = load i64, ptr %l1, !tbaa !24
  %t23 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t19, i64 %t20)
  store { i64, ptr } %t23, ptr %l14
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t24 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t25 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2erefsIn(ptr %v0, ptr %v0, { i64, ptr } %t24)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l15
  br label %bb5
bb5:
  %t26 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l15
  %t27 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t26, ptr %t27
  %t29 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v0, ptr %t27)
  store { i64, ptr } %t29, ptr %l17
  br label %bb6
bb6:
  %t30 = load ptr, ptr %l9, !tbaa !29
  %t31 = load i64, ptr %l10, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l17, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eSetAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t30, i64 %t31, { i64, ptr } %t32)
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/emit:Emitter", ptr %t33, i32 0, i32 19
  %t36 = load i64, ptr %l1, !tbaa !24
  %t39 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t35, i64 %t36)
  store { i64, ptr } %t39, ptr %l21
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t40 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t40, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2esignature(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l10 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca i32
  %l20 = alloca i32
  %l24 = alloca i1
  %l31 = alloca i1
  %l32 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l49 = alloca i1
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l10, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l13
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l10, !tbaa !29
  %t13 = load i32, ptr %l13, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t14, ptr %l14
  br label %bb2
bb2:
  %t15 = load i32, ptr %l14
  %t17 = trunc i64 21 to i32
  %t18 = icmp eq i32 %t15, %t17
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb3, label %bb4
bb3:
  br label %ret
bb4:
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t23 = load i32, ptr %l1, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t26, ptr %l20
  br label %bb6
bb6:
  %t27 = load i32, ptr %l20, !tbaa !23
  store i32 %t27, ptr %l3, !tbaa !23
  %t28 = load i32, ptr %l3, !tbaa !23
  %t29 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t32 = icmp ne i32 %t28, %t29
  br i1 %t32, label %bb7, label %bb8
bb7:
  %t34 = load i32, ptr %l3, !tbaa !23
  %t35 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t38 = icmp ne i32 %t34, %t35
  store i1 %t38, ptr %l24, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb9
bb9:
  %t40 = load i1, ptr %l24, !tbaa !21
  br i1 %t40, label %bb10, label %bb11
bb10:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/emit:Emitter", ptr %t41, i32 0, i32 0
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t45 = load i32, ptr %l3, !tbaa !23
  %t48 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t44, i32 %t45)
  store i1 %t48, ptr %l31
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb13
bb13:
  %t49 = load ptr, ptr %l2, !tbaa !29
  store ptr %t49, ptr %l32, !tbaa !29
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t51 = load i32, ptr %l1, !tbaa !23
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t50, i32 %t51)
  store i32 %t54, ptr %l35
  br label %bb14
bb14:
  %t55 = load ptr, ptr %l32, !tbaa !29
  %t56 = load i32, ptr %l35, !tbaa !23
  %t57 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t55, i32 %t56)
  store { i64, ptr } %t57, ptr %l36
  br label %bb15
bb15:
  %t58 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t58, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t59 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  store i64 %t61, ptr %l6, !tbaa !24
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  %t63 = load i64, ptr %l5, !tbaa !24
  %t64 = load i64, ptr %l6, !tbaa !24
  %t67 = icmp slt i64 %t63, %t64
  %t69 = xor i1 %t67, true
  br i1 %t69, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb18:
  br label %bb19
bb19:
  %t71 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t71, ptr %l43, !tbaa !27
  %t72 = load i64, ptr %l5, !tbaa !24
  %t74 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr i32, ptr %t75, i64 %t72
  %t77 = load i32, ptr %t76, !tbaa !33
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/emit:Emitter", ptr %t79, i32 0, i32 0
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t86 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t82, i32 %t77)
  store i1 %t86, ptr %l49
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb21:
  %t87 = load i64, ptr %l5, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l5, !tbaa !24
  br label %bb16
bb22:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2etextCopy(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i1
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l22 = alloca ptr
  %l23 = alloca i64
  %l25 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehas(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 14, ptr @.d38 })
  store i1 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t5 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t5, { i64, ptr } { i64 21, ptr @.d39 }, { i64, ptr } { i64 46, ptr @.d40 })
  br label %bb5
bb5:
  %t7 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t7, ptr %l5
  br label %bb6
bb6:
  %t8 = load %"std/prelude/text:StringBuilder", ptr %l5
  store %"std/prelude/text:StringBuilder" %t8, ptr %l1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 94, ptr @.d41 })
  br label %bb7
bb7:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 66, ptr @.d42 })
  br label %bb8
bb8:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 86, ptr @.d43 })
  br label %bb9
bb9:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 67, ptr @.d44 })
  br label %bb10
bb10:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 103, ptr @.d45 })
  br label %bb11
bb11:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 112, ptr @.d46 })
  br label %bb12
bb12:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 46, ptr @.d47 })
  br label %bb13
bb13:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 67, ptr @.d48 })
  br label %bb14
bb14:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 103, ptr @.d49 })
  br label %bb15
bb15:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 112, ptr @.d50 })
  br label %bb16
bb16:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 46, ptr @.d51 })
  br label %bb17
bb17:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 70, ptr @.d52 })
  br label %bb18
bb18:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 113, ptr @.d53 })
  br label %bb19
bb19:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 115, ptr @.d54 })
  br label %bb20
bb20:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 107, ptr @.d55 })
  br label %bb21
bb21:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 60, ptr @.d56 })
  br label %bb22
bb22:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l22, !tbaa !29
  %t26 = load i64, ptr @G_2ecompiler_2femit_2eHomeShared, !tbaa !24
  store i64 %t26, ptr %l23, !tbaa !24
  %t28 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l1)
  store { i64, ptr } %t28, ptr %l25
  br label %bb23
bb23:
  %t29 = load ptr, ptr %l22, !tbaa !29
  %t30 = load i64, ptr %l23, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l25, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t29, { i64, ptr } { i64 14, ptr @.d57 }, i64 %t30, { i64, ptr } %t31, { i64, ptr } { i64 0, ptr @.d58 })
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewant(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [1 x i64] }
  %l2 = alloca i64
  %l3 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l13 = alloca i64
  store ptr %a0, ptr %l0
  store { i64, [1 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 10
  %t4 = load { i64, [1 x i64] }, ptr %l1
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e_2eG_H6ffe2eb17daa971b2c9d564ad72358b1(ptr %v0, ptr %t3, { i64, [1 x i64] } %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l8
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11
ok.11:
  store i64 %t8, ptr %l7
  br label %bb1
bb1:
  %t12 = load i64, ptr %l7, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l3, !tbaa !24
  store i64 %t13, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp slt i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/emit:Emitter", ptr %t18, i32 0, i32 9
  %t22 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2eLen_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %t20)
  store i64 %t22, ptr %l13
  br label %bb7
bb6:
  br label %bb10
bb7:
  %t23 = load i64, ptr %l13, !tbaa !24
  store i64 %t23, ptr %l2, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/emit:Emitter", ptr %t24, i32 0, i32 10
  %t27 = load { i64, [1 x i64] }, ptr %l1
  %t28 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e_2eP_H79a97b7337c7adf08bdd37311af7e171(ptr %v0, ptr %t26, { i64, [1 x i64] } %t27, i64 %t28)
  br label %bb8
bb8:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/emit:Emitter", ptr %t32, i32 0, i32 9
  %t35 = load { i64, [1 x i64] }, ptr %l1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %t34, { i64, [1 x i64] } %t35)
  br label %bb9
bb9:
  br label %bb10
bb10:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewantType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l20 = alloca { i64, ptr }
  %l22 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i64
  %l51 = alloca i64
  %l53 = alloca i64
  %l55 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l60 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i32
  %l74 = alloca i1
  %l77 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v2, ptr %t1, i64 %t2, i1 true)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t5, i64 %t6)
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/emit:Emitter", ptr %t9, i32 0, i32 41
  %t12 = load i64, ptr %l1, !tbaa !24
  %t15 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t11, i64 %t12)
  store { i64, ptr } %t15, ptr %l20
  br label %bb3
bb3:
  %t16 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t16, ptr %l4, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2erefsIn(ptr %v0, ptr %s0, { i64, ptr } %t17)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, ptr %l22
  br label %bb4
bb4:
  %t20 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l22
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t20, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  %t22 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l5)
  store i64 %t22, ptr %l24
  br label %bb5
bb5:
  %t23 = load i64, ptr %l24, !tbaa !24
  store i64 %t23, ptr %l7, !tbaa !24
  store i64 3, ptr %l8, !tbaa !24
  %t24 = load i64, ptr %l7, !tbaa !24
  %t25 = load i64, ptr %l6, !tbaa !24
  %t28 = icmp sgt i64 %t24, %t25
  br i1 %t28, label %bb6, label %bb7
bb6:
  %t30 = load i64, ptr %l8, !tbaa !24
  %t32 = icmp sgt i64 %t30, 0
  br i1 %t32, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb11
bb8:
  %t34 = load i64, ptr %l7, !tbaa !24
  %t35 = load i64, ptr %l6, !tbaa !24
  %t38 = sub i64 %t34, %t35
  %t39 = load i64, ptr %l8, !tbaa !24
  %t42 = add i64 %t38, %t39
  %t44 = sub i64 %t42, 1
  %t45 = load i64, ptr %l8, !tbaa !24
  %t48 = sdiv i64 %t44, %t45
  store i64 %t48, ptr %l31, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb10
bb10:
  %t50 = load i64, ptr %l31, !tbaa !24
  store i64 %t50, ptr %l28, !tbaa !24
  br label %bb11
bb11:
  %t51 = load i64, ptr %l28, !tbaa !24
  store i64 %t51, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t52 = load i64, ptr %l10, !tbaa !24
  %t53 = load i64, ptr %l9, !tbaa !24
  %t56 = icmp slt i64 %t52, %t53
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb41
bb14:
  br label %bb15
bb15:
  %t60 = load i64, ptr %l6, !tbaa !24
  %t61 = load i64, ptr %l10, !tbaa !24
  %t62 = load i64, ptr %l8, !tbaa !24
  %t65 = mul i64 %t61, %t62
  %t68 = add i64 %t60, %t65
  store i64 %t68, ptr %l11, !tbaa !24
  %t70 = load i64, ptr %l11, !tbaa !24
  %t73 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l5, i64 %t70)
  store i64 %t73, ptr %l51
  br label %bb16
bb16:
  %t74 = load i64, ptr %l51, !tbaa !24
  %t75 = icmp ne i64 %t74, 1
  br i1 %t75, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb40
bb18:
  br label %bb19
bb19:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/emit:Emitter", ptr %t77, i32 0, i32 42
  store ptr %t79, ptr %l55, !tbaa !29
  %t80 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t80, ptr %l56, !tbaa !27
  %t81 = load i64, ptr %l11, !tbaa !24
  %t83 = add i64 %t81, 1
  %t86 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l5, i64 %t83)
  store i64 %t86, ptr %l60
  br label %bb20
bb20:
  %t87 = load i64, ptr %l11, !tbaa !24
  %t89 = add i64 %t87, 2
  %t92 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l5, i64 %t89)
  store i64 %t92, ptr %l64
  br label %bb21
bb21:
  %t93 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 0
  store i64 %t94, ptr %l65, !tbaa !24
  %t95 = load i64, ptr %l60, !tbaa !24
  %t96 = icmp sge i64 %t95, 0
  br i1 %t96, label %bb22, label %bb23
bb22:
  %t98 = load i64, ptr %l60, !tbaa !24
  %t99 = load i64, ptr %l64, !tbaa !24
  %t100 = icmp sle i64 %t98, %t99
  br i1 %t100, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_6f064da57090b2af_17093dce158f11fb)
  unreachable
bb24:
  %t102 = load i64, ptr %l64, !tbaa !24
  %t103 = load i64, ptr %l65, !tbaa !24
  %t104 = icmp sle i64 %t102, %t103
  br i1 %t104, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_6f064da57090b2af_17093dce158f11fb)
  unreachable
bb26:
  %t106 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = load i64, ptr %l60, !tbaa !24
  %t109 = load i64, ptr %l64, !tbaa !24
  %t110 = getelementptr i8, ptr %t107, i64 %t108
  %t111 = sub i64 %t109, %t108
  %t112 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t110, 1
  %t114 = load ptr, ptr %l55, !tbaa !29
  %t116 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v0, ptr %t114, { i64, ptr } %t113)
  %t117 = extractvalue { i32, i64 } %t116, 1
  %t118 = extractvalue { i32, i64 } %t116, 0
  store i32 %t118, ptr %l71
  %t119 = icmp ne i32 %t118, 0
  br i1 %t119, label %bb29, label %ok.120
ok.120:
  store i64 %t117, ptr %l70
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_6f064da57090b2af_17093dce158f11fb)
  unreachable
bb28:
  %t121 = load i64, ptr %l70, !tbaa !24
  store i64 %t121, ptr %l53, !tbaa !24
  br label %bb31
bb29:
  br label %bb30
bb30:
  store i64 -1, ptr %l53, !tbaa !24
  br label %bb31
bb31:
  %t122 = load i64, ptr %l53, !tbaa !24
  store i64 %t122, ptr %l12, !tbaa !24
  %t123 = load i64, ptr %l12, !tbaa !24
  %t125 = icmp sge i64 %t123, 0
  br i1 %t125, label %bb32, label %bb33
bb32:
  %t127 = load ptr, ptr %l3, !tbaa !29
  %t128 = load i64, ptr %l12, !tbaa !24
  %t131 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v2, ptr %t127, i64 %t128)
  store i1 %t131, ptr %l77
  br label %bb34
bb33:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb35
bb34:
  %t132 = load i1, ptr %l77, !tbaa !21
  %t133 = xor i1 %t132, true
  store i1 %t133, ptr %l74, !tbaa !21
  br label %bb35
bb35:
  %t135 = load i1, ptr %l74, !tbaa !21
  br i1 %t135, label %bb36, label %bb37
bb36:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load i64, ptr %l12, !tbaa !24
  %t138 = load ptr, ptr %l2, !tbaa !29
  %t139 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewantType(ptr %v0, ptr %v1, ptr %v2, ptr %t136, i64 %t137, ptr %t138, ptr %t139)
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s2)
  br label %bb40
bb40:
  %t144 = load i64, ptr %l10, !tbaa !24
  %t146 = add i64 %t144, 1
  store i64 %t146, ptr %l10, !tbaa !24
  br label %bb12
bb41:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eapart(ptr %v0, ptr %a0, %"compiler/mir:Place" %a1, %"compiler/mir:Range" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Place"
  %l2 = alloca %"compiler/mir:Range"
  %l3 = alloca i32
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l12 = alloca { i64, [4 x i64] }
  %l13 = alloca %"compiler/mir:Place"
  %l24 = alloca i1
  %l30 = alloca i32
  %l33 = alloca i32
  %l55 = alloca { i64, [4 x i64] }
  %l61 = alloca i1
  %l62 = alloca i1
  %l66 = alloca i1
  %s5 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/mir:Place" %a1, ptr %l1
  store %"compiler/mir:Range" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  store i32 %t1, ptr %l3, !tbaa !23
  %t3 = getelementptr %"compiler/mir:Place", ptr %l1, i32 0, i32 0
  %t4 = load { i64, [2 x i64] }, ptr %t3
  store { i64, [2 x i64] } %t4, ptr %l4
  %t6 = load { i64, [2 x i64] }, ptr %l4
  %t8 = extractvalue { i64, [2 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 1
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  store i32 %t13, ptr %l5, !tbaa !23
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t15 = load i32, ptr %l5, !tbaa !23
  store i32 %t15, ptr %l3, !tbaa !23
  br label %bb9
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 false, ptr %rv
  br label %ret
bb8:
  call void @__olang_check_failed(ptr @olang_loc_ed162375e135a06c_e406bb0ac0d59940)
  unreachable
bb9:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load %"compiler/mir:Place", ptr %l1
  %t22 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2ederefs(ptr %v0, ptr %t18, %"compiler/mir:Place" %t19)
  store i1 %t22, ptr %l24
  br label %bb10
bb10:
  %t23 = load i1, ptr %l24, !tbaa !21
  br i1 %t23, label %bb11, label %bb12
bb11:
  store i1 false, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  store i32 0, ptr %l6, !tbaa !23
  %t25 = getelementptr %"compiler/mir:Range", ptr %l2, i32 0, i32 1
  %t26 = load i32, ptr %t25, !tbaa !23
  store i32 %t26, ptr %l7, !tbaa !23
  store i32 1, ptr %l8, !tbaa !23
  %t28 = load i32, ptr %l7, !tbaa !23
  %t29 = load i32, ptr %l6, !tbaa !23
  %t32 = icmp sgt i32 %t28, %t29
  br i1 %t32, label %bb14, label %bb15
bb14:
  %t34 = load i32, ptr %l8, !tbaa !23
  %t36 = icmp sgt i32 %t34, 0
  br i1 %t36, label %bb16, label %bb17
bb15:
  store i32 0, ptr %l30, !tbaa !23
  br label %bb19
bb16:
  %t38 = load i32, ptr %l7, !tbaa !23
  %t39 = load i32, ptr %l6, !tbaa !23
  %t42 = sub i32 %t38, %t39
  %t43 = load i32, ptr %l8, !tbaa !23
  %t46 = add i32 %t42, %t43
  %t48 = sub i32 %t46, 1
  %t49 = load i32, ptr %l8, !tbaa !23
  %t52 = sdiv i32 %t48, %t49
  store i32 %t52, ptr %l33, !tbaa !23
  br label %bb18
bb17:
  store i32 0, ptr %l33, !tbaa !23
  br label %bb18
bb18:
  %t54 = load i32, ptr %l33, !tbaa !23
  store i32 %t54, ptr %l30, !tbaa !23
  br label %bb19
bb19:
  %t55 = load i32, ptr %l30, !tbaa !23
  store i32 %t55, ptr %l9, !tbaa !23
  store i32 0, ptr %l10, !tbaa !23
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s5
  %t56 = load i32, ptr %l10, !tbaa !23
  %t57 = load i32, ptr %l9, !tbaa !23
  %t60 = icmp slt i32 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s5)
  br label %bb52
bb22:
  br label %bb23
bb23:
  %t64 = load i32, ptr %l6, !tbaa !23
  %t65 = load i32, ptr %l10, !tbaa !23
  %t66 = load i32, ptr %l8, !tbaa !23
  %t69 = mul i32 %t65, %t66
  %t72 = add i32 %t64, %t69
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load %"compiler/mir:Range", ptr %l2
  %t78 = sext i32 %t72 to i64
  %t82 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t74, %"compiler/mir:Range" %t75, i64 %t78)
  store { i64, [4 x i64] } %t82, ptr %l55
  br label %bb24
bb24:
  %t83 = load { i64, [4 x i64] }, ptr %l55
  store { i64, [4 x i64] } %t83, ptr %l12
  %t84 = load { i64, [4 x i64] }, ptr %l12
  %t86 = extractvalue { i64, [4 x i64] } %t84, 0
  %t87 = icmp eq i64 %t86, 1
  br i1 %t87, label %bb25, label %bb26
bb25:
  %t89 = getelementptr { i64, [4 x i64] }, ptr %l12, i32 0, i32 1
  %t90 = getelementptr { %"compiler/mir:Place" }, ptr %t89, i32 0, i32 0
  %t91 = load %"compiler/mir:Place", ptr %t90
  store %"compiler/mir:Place" %t91, ptr %l13
  br label %bb27
bb26:
  br label %bb45
bb27:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load %"compiler/mir:Place", ptr %l13
  %t97 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2ederefs(ptr %v0, ptr %t93, %"compiler/mir:Place" %t94)
  store i1 %t97, ptr %l61
  br label %bb28
bb28:
  %t98 = load i1, ptr %l61, !tbaa !21
  br i1 %t98, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb32
bb30:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load %"compiler/mir:Place", ptr %l13
  %t101 = load i32, ptr %l3, !tbaa !23
  %t105 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2ebaseIs(ptr %v0, ptr %t99, %"compiler/mir:Place" %t100, i32 %t101)
  store i1 %t105, ptr %l66
  br label %bb31
bb31:
  %t106 = load i1, ptr %l66, !tbaa !21
  store i1 %t106, ptr %l62, !tbaa !21
  br label %bb32
bb32:
  %t107 = load i1, ptr %l62, !tbaa !21
  br i1 %t107, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s5)
  store i1 false, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t109 = getelementptr %"compiler/mir:Place", ptr %l13, i32 0, i32 0
  %t110 = load { i64, [2 x i64] }, ptr %t109
  %t114 = extractvalue { i64, [2 x i64] } %t110, 0
  %t115 = icmp eq i64 %t114, 1
  br i1 %t115, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb44
bb39:
  br i1 true, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  call void @__olang_scope_close(ptr %s5)
  store i1 false, ptr %rv
  br label %ret
bb43:
  call void @__olang_check_failed(ptr @olang_loc_5f9c6fbf78b3e51d_e9dc61b8da3e01d1)
  unreachable
bb44:
  br label %bb50
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_afa6164151ba006_66d817e1c679673a)
  unreachable
bb50:
  call void @__olang_scope_close(ptr %s5)
  br label %bb51
bb51:
  %t118 = load i32, ptr %l10, !tbaa !23
  %t120 = add i32 %t118, 1
  store i32 %t120, ptr %l10, !tbaa !23
  br label %bb20
bb52:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2ebuildInto(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2, %"compiler/mir:Range" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca %"compiler/mir:Range"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l27 = alloca i32
  %l30 = alloca { i64, ptr }
  %l33 = alloca i32
  %l39 = alloca i32
  %l42 = alloca i64
  %l46 = alloca i64
  %l49 = alloca i64
  %l67 = alloca ptr
  %l74 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l76 = alloca i32
  %l80 = alloca { i64, [4 x i64] }
  %l84 = alloca { i64, ptr }
  %l88 = alloca ptr
  %l91 = alloca i32
  %l92 = alloca { i64, ptr }
  %l98 = alloca i64
  %l101 = alloca i64
  %l119 = alloca ptr
  %l126 = alloca { i64, ptr }
  %l127 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l130 = alloca i32
  %l134 = alloca { i64, [4 x i64] }
  %l137 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store %"compiler/mir:Range" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t9, i32 %a2)
  store i32 %t13, ptr %l27
  br label %bb1
bb1:
  %t14 = load i32, ptr %l27, !tbaa !23
  store i32 %t14, ptr %l5, !tbaa !23
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l5, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s0, ptr %t15, i32 %t16)
  store { i64, ptr } %t19, ptr %l30
  br label %bb2
bb2:
  %t20 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t20, ptr %l6, !tbaa !27
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l5, !tbaa !23
  %t25 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l33
  br label %bb3
bb3:
  %t26 = load i32, ptr %l33, !tbaa !23
  store i32 %t26, ptr %l7, !tbaa !23
  %t27 = load i32, ptr %l7, !tbaa !23
  %t28 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t31 = icmp ne i32 %t27, %t28
  br i1 %t31, label %bb4, label %bb5
bb4:
  %t33 = load ptr, ptr %l4, !tbaa !29
  %t34 = load i32, ptr %l7, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l39
  br label %bb6
bb5:
  br label %bb24
bb6:
  %t38 = load i32, ptr %l39, !tbaa !23
  store i32 %t38, ptr %l8, !tbaa !23
  store i64 0, ptr %l9, !tbaa !24
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load i32, ptr %l7, !tbaa !23
  %t43 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixedLen(ptr %v0, ptr %t39, i32 %t40)
  store i64 %t43, ptr %l42
  br label %bb7
bb7:
  %t44 = load i64, ptr %l42, !tbaa !24
  store i64 %t44, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t45 = load i64, ptr %l10, !tbaa !24
  %t46 = load i64, ptr %l9, !tbaa !24
  %t49 = icmp sgt i64 %t45, %t46
  br i1 %t49, label %bb8, label %bb9
bb8:
  %t51 = load i64, ptr %l11, !tbaa !24
  %t53 = icmp sgt i64 %t51, 0
  br i1 %t53, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb13
bb10:
  %t55 = load i64, ptr %l10, !tbaa !24
  %t56 = load i64, ptr %l9, !tbaa !24
  %t59 = sub i64 %t55, %t56
  %t60 = load i64, ptr %l11, !tbaa !24
  %t63 = add i64 %t59, %t60
  %t65 = sub i64 %t63, 1
  %t66 = load i64, ptr %l11, !tbaa !24
  %t69 = sdiv i64 %t65, %t66
  store i64 %t69, ptr %l49, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb12
bb12:
  %t71 = load i64, ptr %l49, !tbaa !24
  store i64 %t71, ptr %l46, !tbaa !24
  br label %bb13
bb13:
  %t72 = load i64, ptr %l46, !tbaa !24
  store i64 %t72, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t73 = load i64, ptr %l13, !tbaa !24
  %t74 = load i64, ptr %l12, !tbaa !24
  %t77 = icmp slt i64 %t73, %t74
  %t79 = xor i1 %t77, true
  br i1 %t79, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb16:
  br label %bb17
bb17:
  %t81 = load i64, ptr %l9, !tbaa !24
  %t82 = load i64, ptr %l13, !tbaa !24
  %t83 = load i64, ptr %l11, !tbaa !24
  %t86 = mul i64 %t82, %t83
  %t89 = add i64 %t81, %t86
  store i64 %t89, ptr %l14, !tbaa !24
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l67, !tbaa !29
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t95 = load i64, ptr %l14, !tbaa !24
  %t96 = extractvalue { i64, ptr } { i64 14, ptr @.d59 }, 1
  %t97 = extractvalue { i64, ptr } { i64 14, ptr @.d59 }, 0
  %t99 = extractvalue { i64, ptr } %t93, 1
  %t100 = extractvalue { i64, ptr } %t93, 0
  %t101 = add i64 %t97, %t100
  %t102 = extractvalue { i64, ptr } { i64 6, ptr @.d60 }, 1
  %t103 = extractvalue { i64, ptr } { i64 6, ptr @.d60 }, 0
  %t104 = add i64 %t101, %t103
  %t106 = extractvalue { i64, ptr } %t94, 1
  %t107 = extractvalue { i64, ptr } %t94, 0
  %t108 = add i64 %t104, %t107
  %t109 = extractvalue { i64, ptr } { i64 13, ptr @.d61 }, 1
  %t110 = extractvalue { i64, ptr } { i64 13, ptr @.d61 }, 0
  %t111 = add i64 %t108, %t110
  %t113 = call i64 @__olang_fmt_i64(ptr null, i64 %t95)
  %t114 = add i64 %t111, %t113
  %t115 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t114)
  call void @olang_textcopy(ptr %t115, ptr %t96, i64 %t97)
  %t116 = getelementptr i8, ptr %t115, i64 %t97
  call void @olang_textcopy(ptr %t116, ptr %t99, i64 %t100)
  %t117 = getelementptr i8, ptr %t116, i64 %t100
  call void @olang_textcopy(ptr %t117, ptr %t102, i64 %t103)
  %t118 = getelementptr i8, ptr %t117, i64 %t103
  call void @olang_textcopy(ptr %t118, ptr %t106, i64 %t107)
  %t119 = getelementptr i8, ptr %t118, i64 %t107
  call void @olang_textcopy(ptr %t119, ptr %t109, i64 %t110)
  %t120 = getelementptr i8, ptr %t119, i64 %t110
  %t121 = call i64 @__olang_fmt_i64(ptr %t120, i64 %t95)
  %t122 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t115, 1
  %t125 = extractvalue { i64, ptr } %t123, 0
  %t126 = extractvalue { i64, ptr } %t123, 1
  %t127 = mul i64 %t125, 1
  %t128 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t127)
  call void @llvm.memcpy.p0.p0.i64(ptr %t128, ptr %t126, i64 %t127, i1 false)
  %t129 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t128, 1
  %t133 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s3, ptr %s3, ptr %t92, { i64, ptr } %t130)
  store { i64, ptr } %t133, ptr %l74
  br label %bb18
bb18:
  %t134 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t134, 0
  %t136 = extractvalue { i64, ptr } %t134, 1
  %t137 = mul i64 %t135, 1
  %t138 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t137)
  call void @llvm.memcpy.p0.p0.i64(ptr %t138, ptr %t136, i64 %t137, i1 false)
  %t139 = insertvalue { i64, ptr } undef, i64 %t135, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr %t138, 1
  store { i64, ptr } %t140, ptr %l75, !tbaa !27
  %t141 = load i32, ptr %l8, !tbaa !23
  store i32 %t141, ptr %l76, !tbaa !23
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load %"compiler/mir:Range", ptr %l3
  %t144 = load i64, ptr %l14, !tbaa !24
  %t148 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t142, %"compiler/mir:Range" %t143, i64 %t144)
  store { i64, [4 x i64] } %t148, ptr %l80
  br label %bb19
bb19:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/emit:fnEm", ptr %t149, i32 0, i32 0
  %t152 = load ptr, ptr %t151, !tbaa !29
  %t153 = load i32, ptr %l8, !tbaa !23
  %t156 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etbaa(ptr %v0, ptr %s3, ptr %t152, i32 %t153, i1 true)
  store { i64, ptr } %t156, ptr %l84
  br label %bb20
bb20:
  %t157 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t157, 0
  %t159 = extractvalue { i64, ptr } %t157, 1
  %t160 = mul i64 %t158, 1
  %t161 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t160)
  call void @llvm.memcpy.p0.p0.i64(ptr %t161, ptr %t159, i64 %t160, i1 false)
  %t162 = insertvalue { i64, ptr } undef, i64 %t158, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t161, 1
  %t164 = load ptr, ptr %l67, !tbaa !29
  %t165 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t166 = load i32, ptr %l76, !tbaa !23
  %t167 = load { i64, [4 x i64] }, ptr %l80
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eput(ptr %v0, ptr %s3, ptr %s3, ptr %t164, { i64, ptr } %t165, i32 %t166, { i64, [4 x i64] } %t167, { i64, ptr } %t163)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb22:
  %t169 = load i64, ptr %l13, !tbaa !24
  %t171 = add i64 %t169, 1
  store i64 %t171, ptr %l13, !tbaa !24
  br label %bb14
bb23:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb24:
  %t173 = load ptr, ptr %l4, !tbaa !29
  store ptr %t173, ptr %l88, !tbaa !29
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load i32, ptr %l5, !tbaa !23
  %t178 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2efieldList(ptr %v0, ptr %t174, i32 %t175)
  store i32 %t178, ptr %l91
  br label %bb25
bb25:
  %t179 = load ptr, ptr %l88, !tbaa !29
  %t180 = load i32, ptr %l91, !tbaa !23
  %t181 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t179, i32 %t180)
  store { i64, ptr } %t181, ptr %l92
  br label %bb26
bb26:
  %t182 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t182, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t183 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t183, 0
  store i64 %t185, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t187 = load i64, ptr %l17, !tbaa !24
  %t188 = load i64, ptr %l16, !tbaa !24
  %t191 = icmp sgt i64 %t187, %t188
  br i1 %t191, label %bb27, label %bb28
bb27:
  %t193 = load i64, ptr %l18, !tbaa !24
  %t195 = icmp sgt i64 %t193, 0
  br i1 %t195, label %bb29, label %bb30
bb28:
  store i64 0, ptr %l98, !tbaa !24
  br label %bb32
bb29:
  %t197 = load i64, ptr %l17, !tbaa !24
  %t198 = load i64, ptr %l16, !tbaa !24
  %t201 = sub i64 %t197, %t198
  %t202 = load i64, ptr %l18, !tbaa !24
  %t205 = add i64 %t201, %t202
  %t207 = sub i64 %t205, 1
  %t208 = load i64, ptr %l18, !tbaa !24
  %t211 = sdiv i64 %t207, %t208
  store i64 %t211, ptr %l101, !tbaa !24
  br label %bb31
bb30:
  store i64 0, ptr %l101, !tbaa !24
  br label %bb31
bb31:
  %t213 = load i64, ptr %l101, !tbaa !24
  store i64 %t213, ptr %l98, !tbaa !24
  br label %bb32
bb32:
  %t214 = load i64, ptr %l98, !tbaa !24
  store i64 %t214, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s7
  %t215 = load i64, ptr %l20, !tbaa !24
  %t216 = load i64, ptr %l19, !tbaa !24
  %t219 = icmp slt i64 %t215, %t216
  %t221 = xor i1 %t219, true
  br i1 %t221, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s7)
  br label %bb42
bb35:
  br label %bb36
bb36:
  %t223 = load i64, ptr %l16, !tbaa !24
  %t224 = load i64, ptr %l20, !tbaa !24
  %t225 = load i64, ptr %l18, !tbaa !24
  %t228 = mul i64 %t224, %t225
  %t231 = add i64 %t223, %t228
  store i64 %t231, ptr %l21, !tbaa !24
  %t233 = load ptr, ptr %l0, !tbaa !29
  store ptr %t233, ptr %l119, !tbaa !29
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t236 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t237 = load i64, ptr %l21, !tbaa !24
  %t238 = extractvalue { i64, ptr } { i64 14, ptr @.d62 }, 1
  %t239 = extractvalue { i64, ptr } { i64 14, ptr @.d62 }, 0
  %t241 = extractvalue { i64, ptr } %t235, 1
  %t242 = extractvalue { i64, ptr } %t235, 0
  %t243 = add i64 %t239, %t242
  %t244 = extractvalue { i64, ptr } { i64 6, ptr @.d63 }, 1
  %t245 = extractvalue { i64, ptr } { i64 6, ptr @.d63 }, 0
  %t246 = add i64 %t243, %t245
  %t248 = extractvalue { i64, ptr } %t236, 1
  %t249 = extractvalue { i64, ptr } %t236, 0
  %t250 = add i64 %t246, %t249
  %t251 = extractvalue { i64, ptr } { i64 13, ptr @.d64 }, 1
  %t252 = extractvalue { i64, ptr } { i64 13, ptr @.d64 }, 0
  %t253 = add i64 %t250, %t252
  %t255 = call i64 @__olang_fmt_i64(ptr null, i64 %t237)
  %t256 = add i64 %t253, %t255
  %t257 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t256)
  call void @olang_textcopy(ptr %t257, ptr %t238, i64 %t239)
  %t258 = getelementptr i8, ptr %t257, i64 %t239
  call void @olang_textcopy(ptr %t258, ptr %t241, i64 %t242)
  %t259 = getelementptr i8, ptr %t258, i64 %t242
  call void @olang_textcopy(ptr %t259, ptr %t244, i64 %t245)
  %t260 = getelementptr i8, ptr %t259, i64 %t245
  call void @olang_textcopy(ptr %t260, ptr %t248, i64 %t249)
  %t261 = getelementptr i8, ptr %t260, i64 %t249
  call void @olang_textcopy(ptr %t261, ptr %t251, i64 %t252)
  %t262 = getelementptr i8, ptr %t261, i64 %t252
  %t263 = call i64 @__olang_fmt_i64(ptr %t262, i64 %t237)
  %t264 = insertvalue { i64, ptr } undef, i64 %t256, 0
  %t265 = insertvalue { i64, ptr } %t264, ptr %t257, 1
  %t267 = extractvalue { i64, ptr } %t265, 0
  %t268 = extractvalue { i64, ptr } %t265, 1
  %t269 = mul i64 %t267, 1
  %t270 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t269)
  call void @llvm.memcpy.p0.p0.i64(ptr %t270, ptr %t268, i64 %t269, i1 false)
  %t271 = insertvalue { i64, ptr } undef, i64 %t267, 0
  %t272 = insertvalue { i64, ptr } %t271, ptr %t270, 1
  %t275 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s7, ptr %s7, ptr %t234, { i64, ptr } %t272)
  store { i64, ptr } %t275, ptr %l126
  br label %bb37
bb37:
  %t276 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t277 = extractvalue { i64, ptr } %t276, 0
  %t278 = extractvalue { i64, ptr } %t276, 1
  %t279 = mul i64 %t277, 1
  %t280 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t279)
  call void @llvm.memcpy.p0.p0.i64(ptr %t280, ptr %t278, i64 %t279, i1 false)
  %t281 = insertvalue { i64, ptr } undef, i64 %t277, 0
  %t282 = insertvalue { i64, ptr } %t281, ptr %t280, 1
  store { i64, ptr } %t282, ptr %l127, !tbaa !27
  %t283 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t283, ptr %l128, !tbaa !27
  %t284 = load i64, ptr %l21, !tbaa !24
  %t286 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t287 = load ptr, ptr %t286, !tbaa !27
  %t288 = getelementptr i32, ptr %t287, i64 %t284
  %t289 = load i32, ptr %t288, !tbaa !33
  store i32 %t289, ptr %l130, !tbaa !23
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t291 = load %"compiler/mir:Range", ptr %l3
  %t292 = load i64, ptr %l21, !tbaa !24
  %t296 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t290, %"compiler/mir:Range" %t291, i64 %t292)
  store { i64, [4 x i64] } %t296, ptr %l134
  br label %bb38
bb38:
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t299 = getelementptr %"compiler/emit:fnEm", ptr %t297, i32 0, i32 0
  %t300 = load ptr, ptr %t299, !tbaa !29
  %t301 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t301, ptr %l137, !tbaa !27
  %t302 = load i64, ptr %l21, !tbaa !24
  %t304 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t305 = load ptr, ptr %t304, !tbaa !27
  %t306 = getelementptr i32, ptr %t305, i64 %t302
  %t307 = load i32, ptr %t306, !tbaa !33
  %t310 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etbaa(ptr %v0, ptr %s7, ptr %t300, i32 %t307, i1 false)
  store { i64, ptr } %t310, ptr %l140
  br label %bb39
bb39:
  %t311 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t311, 0
  %t313 = extractvalue { i64, ptr } %t311, 1
  %t314 = mul i64 %t312, 1
  %t315 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t314)
  call void @llvm.memcpy.p0.p0.i64(ptr %t315, ptr %t313, i64 %t314, i1 false)
  %t316 = insertvalue { i64, ptr } undef, i64 %t312, 0
  %t317 = insertvalue { i64, ptr } %t316, ptr %t315, 1
  %t318 = load ptr, ptr %l119, !tbaa !29
  %t319 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t320 = load i32, ptr %l130, !tbaa !23
  %t321 = load { i64, [4 x i64] }, ptr %l134
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eput(ptr %v0, ptr %s7, ptr %s7, ptr %t318, { i64, ptr } %t319, i32 %t320, { i64, [4 x i64] } %t321, { i64, ptr } %t317)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s7)
  br label %bb41
bb41:
  %t323 = load i64, ptr %l20, !tbaa !24
  %t325 = add i64 %t323, 1
  store i64 %t325, ptr %l20, !tbaa !24
  br label %bb33
bb42:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2eclauses(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, %"compiler/mir:Task" %a3, i32 %a4, i64 %a5, i64 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"compiler/mir:Task"
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca %"compiler/mir:TaskClause"
  %l18 = alloca { i64, ptr }
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca %"compiler/typed:Item"
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca i32
  %l29 = alloca %"std/prelude/text:StringBuilder"
  %l30 = alloca i32
  %l31 = alloca i1
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i32
  %l42 = alloca i32
  %l43 = alloca i32
  %l44 = alloca i32
  %l45 = alloca i32
  %l46 = alloca i32
  %l53 = alloca i32
  %l59 = alloca i32
  %l62 = alloca i32
  %l88 = alloca %"compiler/mir:TaskClause"
  %l89 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l91 = alloca i64
  %l92 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l98 = alloca i64
  %l100 = alloca i64
  %l101 = alloca { i64, ptr }
  %l106 = alloca i32
  %l109 = alloca i32
  %l135 = alloca %"compiler/typed:Item"
  %l139 = alloca i64
  %l169 = alloca { i64, ptr }
  %l171 = alloca i64
  %l187 = alloca i32
  %l202 = alloca %"std/prelude/text:StringBuilder"
  %l209 = alloca i32
  %l213 = alloca i1
  %l217 = alloca i1
  %l220 = alloca i1
  %l222 = alloca ptr
  %l223 = alloca i32
  %l226 = alloca { i64, ptr }
  %l237 = alloca i64
  %l241 = alloca i64
  %l244 = alloca i64
  %l277 = alloca { i64, ptr }
  %l278 = alloca { i64, ptr }
  %l279 = alloca { i64, ptr }
  %l280 = alloca i64
  %l281 = alloca { i64, ptr }
  %l283 = alloca i1
  %l284 = alloca ptr
  %l285 = alloca i32
  %l287 = alloca { i64, ptr }
  %l290 = alloca ptr
  %l291 = alloca i32
  %l292 = alloca { i64, ptr }
  %l293 = alloca i32
  %l295 = alloca { i64, ptr }
  %l299 = alloca { i64, ptr }
  %l301 = alloca i64
  %l304 = alloca ptr
  %l305 = alloca i32
  %l308 = alloca { i64, ptr }
  %l313 = alloca { i64, ptr }
  %l315 = alloca i64
  %l318 = alloca i1
  %l320 = alloca i1
  %l325 = alloca ptr
  %l326 = alloca i32
  %l327 = alloca i64
  %l330 = alloca { i64, ptr }
  %l335 = alloca ptr
  %l336 = alloca ptr
  %l339 = alloca i32
  %l340 = alloca i32
  %l341 = alloca { i64, ptr }
  %l346 = alloca i32
  %l349 = alloca i32
  %l376 = alloca ptr
  %l377 = alloca i32
  %l378 = alloca i32
  %l381 = alloca { i64, ptr }
  %l386 = alloca ptr
  %l388 = alloca { i64, ptr }
  %l391 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %t725 = alloca { i64, [4 x i64] }, align 8
  %t728 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store %"compiler/mir:Task" %a3, ptr %l3
  store i64 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l7, !tbaa !29
  %t6 = load ptr, ptr %l7, !tbaa !29
  %t8 = getelementptr %"compiler/emit:Emitter", ptr %t6, i32 0, i32 3
  %t9 = load ptr, ptr %t8, !tbaa !29
  store ptr %t9, ptr %l8, !tbaa !29
  %t11 = load ptr, ptr %l8, !tbaa !29
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t11, i32 %a4)
  store i32 %t15, ptr %l53
  br label %bb1
bb1:
  %t16 = load i32, ptr %l53, !tbaa !23
  store i32 %t16, ptr %l9, !tbaa !23
  store i64 %a5, ptr %l10, !tbaa !24
  store i32 0, ptr %l11, !tbaa !23
  %t19 = getelementptr %"compiler/mir:Task", ptr %l3, i32 0, i32 4
  %t20 = getelementptr %"compiler/mir:Range", ptr %t19, i32 0, i32 1
  %t21 = load i32, ptr %t20, !tbaa !23
  store i32 %t21, ptr %l12, !tbaa !23
  store i32 1, ptr %l13, !tbaa !23
  %t23 = load i32, ptr %l12, !tbaa !23
  %t24 = load i32, ptr %l11, !tbaa !23
  %t27 = icmp sgt i32 %t23, %t24
  br i1 %t27, label %bb2, label %bb3
bb2:
  %t29 = load i32, ptr %l13, !tbaa !23
  %t31 = icmp sgt i32 %t29, 0
  br i1 %t31, label %bb4, label %bb5
bb3:
  store i32 0, ptr %l59, !tbaa !23
  br label %bb7
bb4:
  %t33 = load i32, ptr %l12, !tbaa !23
  %t34 = load i32, ptr %l11, !tbaa !23
  %t37 = sub i32 %t33, %t34
  %t38 = load i32, ptr %l13, !tbaa !23
  %t41 = add i32 %t37, %t38
  %t43 = sub i32 %t41, 1
  %t44 = load i32, ptr %l13, !tbaa !23
  %t47 = sdiv i32 %t43, %t44
  store i32 %t47, ptr %l62, !tbaa !23
  br label %bb6
bb5:
  store i32 0, ptr %l62, !tbaa !23
  br label %bb6
bb6:
  %t49 = load i32, ptr %l62, !tbaa !23
  store i32 %t49, ptr %l59, !tbaa !23
  br label %bb7
bb7:
  %t50 = load i32, ptr %l59, !tbaa !23
  store i32 %t50, ptr %l14, !tbaa !23
  store i32 0, ptr %l15, !tbaa !23
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t51 = load i32, ptr %l15, !tbaa !23
  %t52 = load i32, ptr %l14, !tbaa !23
  %t55 = icmp slt i32 %t51, %t52
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb136
bb10:
  br label %bb11
bb11:
  %t59 = load i32, ptr %l11, !tbaa !23
  %t60 = load i32, ptr %l15, !tbaa !23
  %t61 = load i32, ptr %l13, !tbaa !23
  %t64 = mul i32 %t60, %t61
  %t67 = add i32 %t59, %t64
  store i32 %t67, ptr %l16, !tbaa !23
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/emit:fnEm", ptr %t69, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/mir:Fn", ptr %t72, i32 0, i32 17
  %t75 = getelementptr %"compiler/mir:Task", ptr %l3, i32 0, i32 4
  %t76 = getelementptr %"compiler/mir:Range", ptr %t75, i32 0, i32 0
  %t77 = load i32, ptr %t76, !tbaa !23
  %t79 = sext i32 %t77 to i64
  %t80 = load i32, ptr %l16, !tbaa !23
  %t82 = sext i32 %t80 to i64
  %t85 = add i64 %t79, %t82
  %t88 = call %"compiler/mir:TaskClause" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTaskClause_3e_2eAt_H2a51e389d978bc4a54496c3113cf8f80(ptr %v0, ptr %t74, i64 %t85)
  store %"compiler/mir:TaskClause" %t88, ptr %l88
  br label %bb12
bb12:
  %t89 = load %"compiler/mir:TaskClause", ptr %l88
  store %"compiler/mir:TaskClause" %t89, ptr %l17
  store { i64, ptr } { i64 4, ptr @.d65 }, ptr %l89, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t90, ptr %l90, !tbaa !27
  %t91 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t91, 0
  store i64 %t92, ptr %l91, !tbaa !24
  %t93 = load i64, ptr %l91, !tbaa !24
  %t94 = mul i64 %t93, 1
  %t95 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t94)
  %t96 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t95, 1
  store { i64, ptr } %t97, ptr %l92, !tbaa !27
  %t98 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = load i64, ptr %l91, !tbaa !24
  %t103 = mul i64 %t102, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t99, ptr %t101, i64 %t103, i1 false)
  %t104 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t104, ptr %l18, !tbaa !27
  %t105 = getelementptr %"compiler/mir:TaskClause", ptr %l17, i32 0, i32 1
  %t106 = load i1, ptr %t105, !tbaa !21
  %t108 = xor i1 %t106, true
  br i1 %t108, label %bb13, label %bb14
bb13:
  store { i64, ptr } { i64 5, ptr @.d66 }, ptr %l95, !tbaa !27
  %t110 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t110, ptr %l96, !tbaa !27
  %t111 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 0
  %t113 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  store i64 %t114, ptr %l98, !tbaa !24
  %t116 = load i64, ptr %l98, !tbaa !24
  %t117 = icmp eq i64 %t112, %t116
  br i1 %t117, label %bb15, label %bb16
bb14:
  br label %bb41
bb15:
  %t119 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = load i64, ptr %l98, !tbaa !24
  %t124 = mul i64 %t123, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t120, ptr %t122, i64 %t124, i1 false)
  br label %bb17
bb16:
  %t125 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t125, 0
  store i64 %t126, ptr %l100, !tbaa !24
  %t127 = load i64, ptr %l100, !tbaa !24
  %t128 = mul i64 %t127, 1
  %t129 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t128)
  %t130 = insertvalue { i64, ptr } undef, i64 %t127, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t129, 1
  store { i64, ptr } %t131, ptr %l101, !tbaa !27
  %t132 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = load i64, ptr %l100, !tbaa !24
  %t137 = mul i64 %t136, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t133, ptr %t135, i64 %t137, i1 false)
  %t138 = load { i64, ptr }, ptr %l101, !tbaa !27
  store { i64, ptr } %t138, ptr %l18, !tbaa !27
  br label %bb17
bb17:
  store i32 0, ptr %l19, !tbaa !23
  %t139 = getelementptr %"compiler/mir:TaskClause", ptr %l17, i32 0, i32 0
  %t140 = getelementptr %"compiler/mir:Range", ptr %t139, i32 0, i32 1
  %t141 = load i32, ptr %t140, !tbaa !23
  store i32 %t141, ptr %l20, !tbaa !23
  store i32 1, ptr %l21, !tbaa !23
  %t143 = load i32, ptr %l20, !tbaa !23
  %t144 = load i32, ptr %l19, !tbaa !23
  %t147 = icmp sgt i32 %t143, %t144
  br i1 %t147, label %bb18, label %bb19
bb18:
  %t149 = load i32, ptr %l21, !tbaa !23
  %t151 = icmp sgt i32 %t149, 0
  br i1 %t151, label %bb20, label %bb21
bb19:
  store i32 0, ptr %l106, !tbaa !23
  br label %bb23
bb20:
  %t153 = load i32, ptr %l20, !tbaa !23
  %t154 = load i32, ptr %l19, !tbaa !23
  %t157 = sub i32 %t153, %t154
  %t158 = load i32, ptr %l21, !tbaa !23
  %t161 = add i32 %t157, %t158
  %t163 = sub i32 %t161, 1
  %t164 = load i32, ptr %l21, !tbaa !23
  %t167 = sdiv i32 %t163, %t164
  store i32 %t167, ptr %l109, !tbaa !23
  br label %bb22
bb21:
  store i32 0, ptr %l109, !tbaa !23
  br label %bb22
bb22:
  %t169 = load i32, ptr %l109, !tbaa !23
  store i32 %t169, ptr %l106, !tbaa !23
  br label %bb23
bb23:
  %t170 = load i32, ptr %l106, !tbaa !23
  store i32 %t170, ptr %l22, !tbaa !23
  store i32 0, ptr %l23, !tbaa !23
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  %t171 = load i32, ptr %l23, !tbaa !23
  %t172 = load i32, ptr %l22, !tbaa !23
  %t175 = icmp slt i32 %t171, %t172
  %t177 = xor i1 %t175, true
  br i1 %t177, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s5)
  br label %bb40
bb26:
  br label %bb27
bb27:
  %t179 = load i32, ptr %l19, !tbaa !23
  %t180 = load i32, ptr %l23, !tbaa !23
  %t181 = load i32, ptr %l21, !tbaa !23
  %t184 = mul i32 %t180, %t181
  %t187 = add i32 %t179, %t184
  store i32 %t187, ptr %l24, !tbaa !23
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/emit:fnEm", ptr %t189, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t194 = getelementptr %"compiler/mir:Fn", ptr %t192, i32 0, i32 18
  %t195 = getelementptr %"compiler/mir:TaskClause", ptr %l17, i32 0, i32 0
  %t196 = getelementptr %"compiler/mir:Range", ptr %t195, i32 0, i32 0
  %t197 = load i32, ptr %t196, !tbaa !23
  %t199 = sext i32 %t197 to i64
  %t200 = load i32, ptr %l24, !tbaa !23
  %t202 = sext i32 %t200 to i64
  %t205 = add i64 %t199, %t202
  %t208 = call %"compiler/typed:Item" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aItem_3e_2eAt_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %t194, i64 %t205)
  store %"compiler/typed:Item" %t208, ptr %l135
  br label %bb28
bb28:
  %t209 = load %"compiler/typed:Item", ptr %l135
  store %"compiler/typed:Item" %t209, ptr %l25
  %t210 = load ptr, ptr %l7, !tbaa !29
  %t211 = load i32, ptr %l9, !tbaa !23
  %t212 = getelementptr %"compiler/typed:Item", ptr %l25, i32 0, i32 0
  %t213 = load i32, ptr %t212, !tbaa !23
  %t217 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eposition(ptr %v0, ptr %t210, i32 %t211, i32 %t213)
  store i64 %t217, ptr %l139
  br label %bb29
bb29:
  %t218 = load i64, ptr %l139, !tbaa !24
  store i64 %t218, ptr %l26, !tbaa !24
  %t219 = load i32, ptr %l16, !tbaa !23
  %t220 = load i32, ptr %l24, !tbaa !23
  %t221 = extractvalue { i64, ptr } { i64 2, ptr @.d67 }, 1
  %t222 = extractvalue { i64, ptr } { i64 2, ptr @.d67 }, 0
  %t224 = sext i32 %t219 to i64
  %t225 = call i64 @__olang_fmt_i64(ptr null, i64 %t224)
  %t226 = add i64 %t222, %t225
  %t227 = extractvalue { i64, ptr } { i64 1, ptr @.d68 }, 1
  %t228 = extractvalue { i64, ptr } { i64 1, ptr @.d68 }, 0
  %t229 = add i64 %t226, %t228
  %t231 = sext i32 %t220 to i64
  %t232 = call i64 @__olang_fmt_i64(ptr null, i64 %t231)
  %t233 = add i64 %t229, %t232
  %t234 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t233)
  call void @olang_textcopy(ptr %t234, ptr %t221, i64 %t222)
  %t235 = getelementptr i8, ptr %t234, i64 %t222
  %t236 = call i64 @__olang_fmt_i64(ptr %t235, i64 %t224)
  %t237 = getelementptr i8, ptr %t235, i64 %t225
  call void @olang_textcopy(ptr %t237, ptr %t227, i64 %t228)
  %t238 = getelementptr i8, ptr %t237, i64 %t228
  %t239 = call i64 @__olang_fmt_i64(ptr %t238, i64 %t231)
  %t240 = insertvalue { i64, ptr } undef, i64 %t233, 0
  %t241 = insertvalue { i64, ptr } %t240, ptr %t234, 1
  store { i64, ptr } %t241, ptr %l27, !tbaa !27
  %t243 = getelementptr %"compiler/typed:Item", ptr %l25, i32 0, i32 1
  %t244 = load i64, ptr %t243, !tbaa !24
  %t246 = icmp slt i64 %t244, 0
  br i1 %t246, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s7
  %t248 = load ptr, ptr %l1, !tbaa !29
  %t249 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t250 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t251 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t252 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t253 = load i64, ptr %l26, !tbaa !24
  %t254 = extractvalue { i64, ptr } { i64 2, ptr @.d69 }, 1
  %t255 = extractvalue { i64, ptr } { i64 2, ptr @.d69 }, 0
  %t257 = extractvalue { i64, ptr } %t249, 1
  %t258 = extractvalue { i64, ptr } %t249, 0
  %t259 = add i64 %t255, %t258
  %t260 = extractvalue { i64, ptr } { i64 13, ptr @.d70 }, 1
  %t261 = extractvalue { i64, ptr } { i64 13, ptr @.d70 }, 0
  %t262 = add i64 %t259, %t261
  %t264 = extractvalue { i64, ptr } %t250, 1
  %t265 = extractvalue { i64, ptr } %t250, 0
  %t266 = add i64 %t262, %t265
  %t267 = extractvalue { i64, ptr } { i64 7, ptr @.d71 }, 1
  %t268 = extractvalue { i64, ptr } { i64 7, ptr @.d71 }, 0
  %t269 = add i64 %t266, %t268
  %t271 = extractvalue { i64, ptr } %t251, 1
  %t272 = extractvalue { i64, ptr } %t251, 0
  %t273 = add i64 %t269, %t272
  %t274 = extractvalue { i64, ptr } { i64 15, ptr @.d72 }, 1
  %t275 = extractvalue { i64, ptr } { i64 15, ptr @.d72 }, 0
  %t276 = add i64 %t273, %t275
  %t278 = extractvalue { i64, ptr } %t252, 1
  %t279 = extractvalue { i64, ptr } %t252, 0
  %t280 = add i64 %t276, %t279
  %t281 = extractvalue { i64, ptr } { i64 3, ptr @.d73 }, 1
  %t282 = extractvalue { i64, ptr } { i64 3, ptr @.d73 }, 0
  %t283 = add i64 %t280, %t282
  %t285 = call i64 @__olang_fmt_i64(ptr null, i64 %t253)
  %t286 = add i64 %t283, %t285
  %t287 = extractvalue { i64, ptr } { i64 1, ptr @.d74 }, 1
  %t288 = extractvalue { i64, ptr } { i64 1, ptr @.d74 }, 0
  %t289 = add i64 %t286, %t288
  %t290 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t289)
  call void @olang_textcopy(ptr %t290, ptr %t254, i64 %t255)
  %t291 = getelementptr i8, ptr %t290, i64 %t255
  call void @olang_textcopy(ptr %t291, ptr %t257, i64 %t258)
  %t292 = getelementptr i8, ptr %t291, i64 %t258
  call void @olang_textcopy(ptr %t292, ptr %t260, i64 %t261)
  %t293 = getelementptr i8, ptr %t292, i64 %t261
  call void @olang_textcopy(ptr %t293, ptr %t264, i64 %t265)
  %t294 = getelementptr i8, ptr %t293, i64 %t265
  call void @olang_textcopy(ptr %t294, ptr %t267, i64 %t268)
  %t295 = getelementptr i8, ptr %t294, i64 %t268
  call void @olang_textcopy(ptr %t295, ptr %t271, i64 %t272)
  %t296 = getelementptr i8, ptr %t295, i64 %t272
  call void @olang_textcopy(ptr %t296, ptr %t274, i64 %t275)
  %t297 = getelementptr i8, ptr %t296, i64 %t275
  call void @olang_textcopy(ptr %t297, ptr %t278, i64 %t279)
  %t298 = getelementptr i8, ptr %t297, i64 %t279
  call void @olang_textcopy(ptr %t298, ptr %t281, i64 %t282)
  %t299 = getelementptr i8, ptr %t298, i64 %t282
  %t300 = call i64 @__olang_fmt_i64(ptr %t299, i64 %t253)
  %t301 = getelementptr i8, ptr %t299, i64 %t285
  call void @olang_textcopy(ptr %t301, ptr %t287, i64 %t288)
  %t302 = insertvalue { i64, ptr } undef, i64 %t289, 0
  %t303 = insertvalue { i64, ptr } %t302, ptr %t290, 1
  %t305 = extractvalue { i64, ptr } %t303, 0
  %t306 = extractvalue { i64, ptr } %t303, 1
  %t307 = mul i64 %t305, 1
  %t308 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t307)
  call void @llvm.memcpy.p0.p0.i64(ptr %t308, ptr %t306, i64 %t307, i1 false)
  %t309 = insertvalue { i64, ptr } undef, i64 %t305, 0
  %t310 = insertvalue { i64, ptr } %t309, ptr %t308, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s7, ptr %t248, { i64, ptr } %t310)
  br label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s9
  %t313 = load ptr, ptr %l1, !tbaa !29
  %t314 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t315 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t316 = load i64, ptr %l26, !tbaa !24
  %t318 = shl i64 %t316, 16
  %t319 = getelementptr %"compiler/typed:Item", ptr %l25, i32 0, i32 1
  %t320 = load i64, ptr %t319, !tbaa !24
  %t323 = or i64 %t318, %t320
  %t324 = extractvalue { i64, ptr } { i64 2, ptr @.d75 }, 1
  %t325 = extractvalue { i64, ptr } { i64 2, ptr @.d75 }, 0
  %t327 = extractvalue { i64, ptr } %t314, 1
  %t328 = extractvalue { i64, ptr } %t314, 0
  %t329 = add i64 %t325, %t328
  %t330 = extractvalue { i64, ptr } { i64 15, ptr @.d76 }, 1
  %t331 = extractvalue { i64, ptr } { i64 15, ptr @.d76 }, 0
  %t332 = add i64 %t329, %t331
  %t334 = extractvalue { i64, ptr } %t315, 1
  %t335 = extractvalue { i64, ptr } %t315, 0
  %t336 = add i64 %t332, %t335
  %t337 = extractvalue { i64, ptr } { i64 2, ptr @.d77 }, 1
  %t338 = extractvalue { i64, ptr } { i64 2, ptr @.d77 }, 0
  %t339 = add i64 %t336, %t338
  %t341 = call i64 @__olang_fmt_i64(ptr null, i64 %t323)
  %t342 = add i64 %t339, %t341
  %t343 = extractvalue { i64, ptr } { i64 1, ptr @.d78 }, 1
  %t344 = extractvalue { i64, ptr } { i64 1, ptr @.d78 }, 0
  %t345 = add i64 %t342, %t344
  %t346 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t345)
  call void @olang_textcopy(ptr %t346, ptr %t324, i64 %t325)
  %t347 = getelementptr i8, ptr %t346, i64 %t325
  call void @olang_textcopy(ptr %t347, ptr %t327, i64 %t328)
  %t348 = getelementptr i8, ptr %t347, i64 %t328
  call void @olang_textcopy(ptr %t348, ptr %t330, i64 %t331)
  %t349 = getelementptr i8, ptr %t348, i64 %t331
  call void @olang_textcopy(ptr %t349, ptr %t334, i64 %t335)
  %t350 = getelementptr i8, ptr %t349, i64 %t335
  call void @olang_textcopy(ptr %t350, ptr %t337, i64 %t338)
  %t351 = getelementptr i8, ptr %t350, i64 %t338
  %t352 = call i64 @__olang_fmt_i64(ptr %t351, i64 %t323)
  %t353 = getelementptr i8, ptr %t351, i64 %t341
  call void @olang_textcopy(ptr %t353, ptr %t343, i64 %t344)
  %t354 = insertvalue { i64, ptr } undef, i64 %t345, 0
  %t355 = insertvalue { i64, ptr } %t354, ptr %t346, 1
  %t357 = extractvalue { i64, ptr } %t355, 0
  %t358 = extractvalue { i64, ptr } %t355, 1
  %t359 = mul i64 %t357, 1
  %t360 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t359)
  call void @llvm.memcpy.p0.p0.i64(ptr %t360, ptr %t358, i64 %t359, i1 false)
  %t361 = insertvalue { i64, ptr } undef, i64 %t357, 0
  %t362 = insertvalue { i64, ptr } %t361, ptr %t360, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s9, ptr %t313, { i64, ptr } %t362)
  br label %bb33
bb32:
  call void @__olang_scope_close(ptr %s7)
  br label %bb34
bb33:
  call void @__olang_scope_close(ptr %s9)
  br label %bb34
bb34:
  %t365 = load ptr, ptr %l1, !tbaa !29
  %t366 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t367 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t368 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t369 = extractvalue { i64, ptr } { i64 2, ptr @.d79 }, 1
  %t370 = extractvalue { i64, ptr } { i64 2, ptr @.d79 }, 0
  %t372 = extractvalue { i64, ptr } %t366, 1
  %t373 = extractvalue { i64, ptr } %t366, 0
  %t374 = add i64 %t370, %t373
  %t375 = extractvalue { i64, ptr } { i64 10, ptr @.d80 }, 1
  %t376 = extractvalue { i64, ptr } { i64 10, ptr @.d80 }, 0
  %t377 = add i64 %t374, %t376
  %t379 = extractvalue { i64, ptr } %t367, 1
  %t380 = extractvalue { i64, ptr } %t367, 0
  %t381 = add i64 %t377, %t380
  %t382 = extractvalue { i64, ptr } { i64 2, ptr @.d81 }, 1
  %t383 = extractvalue { i64, ptr } { i64 2, ptr @.d81 }, 0
  %t384 = add i64 %t381, %t383
  %t386 = extractvalue { i64, ptr } %t368, 1
  %t387 = extractvalue { i64, ptr } %t368, 0
  %t388 = add i64 %t384, %t387
  %t389 = extractvalue { i64, ptr } { i64 1, ptr @.d82 }, 1
  %t390 = extractvalue { i64, ptr } { i64 1, ptr @.d82 }, 0
  %t391 = add i64 %t388, %t390
  %t392 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t391)
  call void @olang_textcopy(ptr %t392, ptr %t369, i64 %t370)
  %t393 = getelementptr i8, ptr %t392, i64 %t370
  call void @olang_textcopy(ptr %t393, ptr %t372, i64 %t373)
  %t394 = getelementptr i8, ptr %t393, i64 %t373
  call void @olang_textcopy(ptr %t394, ptr %t375, i64 %t376)
  %t395 = getelementptr i8, ptr %t394, i64 %t376
  call void @olang_textcopy(ptr %t395, ptr %t379, i64 %t380)
  %t396 = getelementptr i8, ptr %t395, i64 %t380
  call void @olang_textcopy(ptr %t396, ptr %t382, i64 %t383)
  %t397 = getelementptr i8, ptr %t396, i64 %t383
  call void @olang_textcopy(ptr %t397, ptr %t386, i64 %t387)
  %t398 = getelementptr i8, ptr %t397, i64 %t387
  call void @olang_textcopy(ptr %t398, ptr %t389, i64 %t390)
  %t399 = insertvalue { i64, ptr } undef, i64 %t391, 0
  %t400 = insertvalue { i64, ptr } %t399, ptr %t392, 1
  %t402 = extractvalue { i64, ptr } %t400, 0
  %t403 = extractvalue { i64, ptr } %t400, 1
  %t404 = mul i64 %t402, 1
  %t405 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t404)
  call void @llvm.memcpy.p0.p0.i64(ptr %t405, ptr %t403, i64 %t404, i1 false)
  %t406 = insertvalue { i64, ptr } undef, i64 %t402, 0
  %t407 = insertvalue { i64, ptr } %t406, ptr %t405, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s5, ptr %t365, { i64, ptr } %t407)
  br label %bb35
bb35:
  %t410 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t412 = extractvalue { i64, ptr } %t410, 1
  %t413 = extractvalue { i64, ptr } %t410, 0
  %t414 = extractvalue { i64, ptr } { i64 1, ptr @.d83 }, 1
  %t415 = extractvalue { i64, ptr } { i64 1, ptr @.d83 }, 0
  %t416 = add i64 %t413, %t415
  %t417 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t416)
  call void @olang_textcopy(ptr %t417, ptr %t412, i64 %t413)
  %t418 = getelementptr i8, ptr %t417, i64 %t413
  call void @olang_textcopy(ptr %t418, ptr %t414, i64 %t415)
  %t419 = insertvalue { i64, ptr } undef, i64 %t416, 0
  %t420 = insertvalue { i64, ptr } %t419, ptr %t417, 1
  store { i64, ptr } %t420, ptr %l169, !tbaa !27
  %t421 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t422 = extractvalue { i64, ptr } %t421, 0
  %t423 = load { i64, ptr }, ptr %l169, !tbaa !27
  %t424 = extractvalue { i64, ptr } %t423, 0
  store i64 %t424, ptr %l171, !tbaa !24
  %t426 = load i64, ptr %l171, !tbaa !24
  %t427 = icmp eq i64 %t422, %t426
  br i1 %t427, label %bb36, label %bb37
bb36:
  %t429 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t430 = load ptr, ptr %t429, !tbaa !27
  %t431 = getelementptr { i64, ptr }, ptr %l169, i32 0, i32 1
  %t432 = load ptr, ptr %t431, !tbaa !27
  %t433 = load i64, ptr %l171, !tbaa !24
  %t434 = mul i64 %t433, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t430, ptr %t432, i64 %t434, i1 false)
  br label %bb38
bb37:
  %t435 = load { i64, ptr }, ptr %l169, !tbaa !27
  store { i64, ptr } %t435, ptr %l18, !tbaa !27
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s5)
  br label %bb39
bb39:
  %t436 = load i32, ptr %l23, !tbaa !23
  %t438 = add i32 %t436, 1
  store i32 %t438, ptr %l23, !tbaa !23
  br label %bb24
bb40:
  br label %bb41
bb41:
  %t440 = load ptr, ptr %l1, !tbaa !29
  %t441 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t442 = load i32, ptr %l16, !tbaa !23
  %t443 = load i32, ptr %l16, !tbaa !23
  %t444 = load i32, ptr %l16, !tbaa !23
  %t445 = extractvalue { i64, ptr } { i64 8, ptr @.d84 }, 1
  %t446 = extractvalue { i64, ptr } { i64 8, ptr @.d84 }, 0
  %t448 = extractvalue { i64, ptr } %t441, 1
  %t449 = extractvalue { i64, ptr } %t441, 0
  %t450 = add i64 %t446, %t449
  %t451 = extractvalue { i64, ptr } { i64 13, ptr @.d85 }, 1
  %t452 = extractvalue { i64, ptr } { i64 13, ptr @.d85 }, 0
  %t453 = add i64 %t450, %t452
  %t455 = sext i32 %t442 to i64
  %t456 = call i64 @__olang_fmt_i64(ptr null, i64 %t455)
  %t457 = add i64 %t453, %t456
  %t458 = extractvalue { i64, ptr } { i64 13, ptr @.d86 }, 1
  %t459 = extractvalue { i64, ptr } { i64 13, ptr @.d86 }, 0
  %t460 = add i64 %t457, %t459
  %t462 = sext i32 %t443 to i64
  %t463 = call i64 @__olang_fmt_i64(ptr null, i64 %t462)
  %t464 = add i64 %t460, %t463
  %t465 = extractvalue { i64, ptr } { i64 5, ptr @.d87 }, 1
  %t466 = extractvalue { i64, ptr } { i64 5, ptr @.d87 }, 0
  %t467 = add i64 %t464, %t466
  %t469 = sext i32 %t444 to i64
  %t470 = call i64 @__olang_fmt_i64(ptr null, i64 %t469)
  %t471 = add i64 %t467, %t470
  %t472 = extractvalue { i64, ptr } { i64 2, ptr @.d88 }, 1
  %t473 = extractvalue { i64, ptr } { i64 2, ptr @.d88 }, 0
  %t474 = add i64 %t471, %t473
  %t475 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t474)
  call void @olang_textcopy(ptr %t475, ptr %t445, i64 %t446)
  %t476 = getelementptr i8, ptr %t475, i64 %t446
  call void @olang_textcopy(ptr %t476, ptr %t448, i64 %t449)
  %t477 = getelementptr i8, ptr %t476, i64 %t449
  call void @olang_textcopy(ptr %t477, ptr %t451, i64 %t452)
  %t478 = getelementptr i8, ptr %t477, i64 %t452
  %t479 = call i64 @__olang_fmt_i64(ptr %t478, i64 %t455)
  %t480 = getelementptr i8, ptr %t478, i64 %t456
  call void @olang_textcopy(ptr %t480, ptr %t458, i64 %t459)
  %t481 = getelementptr i8, ptr %t480, i64 %t459
  %t482 = call i64 @__olang_fmt_i64(ptr %t481, i64 %t462)
  %t483 = getelementptr i8, ptr %t481, i64 %t463
  call void @olang_textcopy(ptr %t483, ptr %t465, i64 %t466)
  %t484 = getelementptr i8, ptr %t483, i64 %t466
  %t485 = call i64 @__olang_fmt_i64(ptr %t484, i64 %t469)
  %t486 = getelementptr i8, ptr %t484, i64 %t470
  call void @olang_textcopy(ptr %t486, ptr %t472, i64 %t473)
  %t487 = insertvalue { i64, ptr } undef, i64 %t474, 0
  %t488 = insertvalue { i64, ptr } %t487, ptr %t475, 1
  %t490 = extractvalue { i64, ptr } %t488, 0
  %t491 = extractvalue { i64, ptr } %t488, 1
  %t492 = mul i64 %t490, 1
  %t493 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t492)
  call void @llvm.memcpy.p0.p0.i64(ptr %t493, ptr %t491, i64 %t492, i1 false)
  %t494 = insertvalue { i64, ptr } undef, i64 %t490, 0
  %t495 = insertvalue { i64, ptr } %t494, ptr %t493, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t440, { i64, ptr } %t495)
  br label %bb42
bb42:
  %t498 = getelementptr %"compiler/mir:TaskClause", ptr %l17, i32 0, i32 2
  %t499 = load { i64, [4 x i64] }, ptr %t498
  %t501 = extractvalue { i64, [4 x i64] } %t499, 0
  %t502 = icmp eq i64 %t501, 0
  %t504 = xor i1 %t502, true
  br i1 %t504, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s15
  %t506 = load ptr, ptr %l0, !tbaa !29
  %t507 = getelementptr %"compiler/mir:TaskClause", ptr %l17, i32 0, i32 2
  %t508 = load { i64, [4 x i64] }, ptr %t507
  %t511 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t506, { i64, [4 x i64] } %t508)
  store i32 %t511, ptr %l187
  br label %bb45
bb44:
  br label %bb133
bb45:
  %t512 = load i32, ptr %l187, !tbaa !23
  store i32 %t512, ptr %l28, !tbaa !23
  %t513 = load ptr, ptr %l7, !tbaa !29
  %t514 = load i32, ptr %l28, !tbaa !23
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2esignature(ptr %v0, ptr %t513, i32 %t514)
  br label %bb46
bb46:
  %t517 = load ptr, ptr %l1, !tbaa !29
  %t518 = load i32, ptr %l16, !tbaa !23
  %t519 = load i64, ptr %l10, !tbaa !24
  %t520 = extractvalue { i64, ptr } { i64 5, ptr @.d89 }, 1
  %t521 = extractvalue { i64, ptr } { i64 5, ptr @.d89 }, 0
  %t523 = sext i32 %t518 to i64
  %t524 = call i64 @__olang_fmt_i64(ptr null, i64 %t523)
  %t525 = add i64 %t521, %t524
  %t526 = extractvalue { i64, ptr } { i64 28, ptr @.d90 }, 1
  %t527 = extractvalue { i64, ptr } { i64 28, ptr @.d90 }, 0
  %t528 = add i64 %t525, %t527
  %t530 = call i64 @__olang_fmt_i64(ptr null, i64 %t519)
  %t531 = add i64 %t528, %t530
  %t532 = extractvalue { i64, ptr } { i64 1, ptr @.d91 }, 1
  %t533 = extractvalue { i64, ptr } { i64 1, ptr @.d91 }, 0
  %t534 = add i64 %t531, %t533
  %t535 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t534)
  call void @olang_textcopy(ptr %t535, ptr %t520, i64 %t521)
  %t536 = getelementptr i8, ptr %t535, i64 %t521
  %t537 = call i64 @__olang_fmt_i64(ptr %t536, i64 %t523)
  %t538 = getelementptr i8, ptr %t536, i64 %t524
  call void @olang_textcopy(ptr %t538, ptr %t526, i64 %t527)
  %t539 = getelementptr i8, ptr %t538, i64 %t527
  %t540 = call i64 @__olang_fmt_i64(ptr %t539, i64 %t519)
  %t541 = getelementptr i8, ptr %t539, i64 %t530
  call void @olang_textcopy(ptr %t541, ptr %t532, i64 %t533)
  %t542 = insertvalue { i64, ptr } undef, i64 %t534, 0
  %t543 = insertvalue { i64, ptr } %t542, ptr %t535, 1
  %t545 = extractvalue { i64, ptr } %t543, 0
  %t546 = extractvalue { i64, ptr } %t543, 1
  %t547 = mul i64 %t545, 1
  %t548 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t547)
  call void @llvm.memcpy.p0.p0.i64(ptr %t548, ptr %t546, i64 %t547, i1 false)
  %t549 = insertvalue { i64, ptr } undef, i64 %t545, 0
  %t550 = insertvalue { i64, ptr } %t549, ptr %t548, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s15, ptr %t517, { i64, ptr } %t550)
  br label %bb47
bb47:
  %t553 = load ptr, ptr %l1, !tbaa !29
  %t554 = load i32, ptr %l16, !tbaa !23
  %t555 = load i32, ptr %l16, !tbaa !23
  %t556 = load i32, ptr %l16, !tbaa !23
  %t557 = load i32, ptr %l16, !tbaa !23
  %t558 = extractvalue { i64, ptr } { i64 5, ptr @.d92 }, 1
  %t559 = extractvalue { i64, ptr } { i64 5, ptr @.d92 }, 0
  %t561 = sext i32 %t554 to i64
  %t562 = call i64 @__olang_fmt_i64(ptr null, i64 %t561)
  %t563 = add i64 %t559, %t562
  %t564 = extractvalue { i64, ptr } { i64 32, ptr @.d93 }, 1
  %t565 = extractvalue { i64, ptr } { i64 32, ptr @.d93 }, 0
  %t566 = add i64 %t563, %t565
  %t568 = sext i32 %t555 to i64
  %t569 = call i64 @__olang_fmt_i64(ptr null, i64 %t568)
  %t570 = add i64 %t566, %t569
  %t571 = extractvalue { i64, ptr } { i64 9, ptr @.d94 }, 1
  %t572 = extractvalue { i64, ptr } { i64 9, ptr @.d94 }, 0
  %t573 = add i64 %t570, %t572
  %t575 = sext i32 %t556 to i64
  %t576 = call i64 @__olang_fmt_i64(ptr null, i64 %t575)
  %t577 = add i64 %t573, %t576
  %t578 = extractvalue { i64, ptr } { i64 32, ptr @.d95 }, 1
  %t579 = extractvalue { i64, ptr } { i64 32, ptr @.d95 }, 0
  %t580 = add i64 %t577, %t579
  %t582 = sext i32 %t557 to i64
  %t583 = call i64 @__olang_fmt_i64(ptr null, i64 %t582)
  %t584 = add i64 %t580, %t583
  %t585 = extractvalue { i64, ptr } { i64 4, ptr @.d96 }, 1
  %t586 = extractvalue { i64, ptr } { i64 4, ptr @.d96 }, 0
  %t587 = add i64 %t584, %t586
  %t588 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t587)
  call void @olang_textcopy(ptr %t588, ptr %t558, i64 %t559)
  %t589 = getelementptr i8, ptr %t588, i64 %t559
  %t590 = call i64 @__olang_fmt_i64(ptr %t589, i64 %t561)
  %t591 = getelementptr i8, ptr %t589, i64 %t562
  call void @olang_textcopy(ptr %t591, ptr %t564, i64 %t565)
  %t592 = getelementptr i8, ptr %t591, i64 %t565
  %t593 = call i64 @__olang_fmt_i64(ptr %t592, i64 %t568)
  %t594 = getelementptr i8, ptr %t592, i64 %t569
  call void @olang_textcopy(ptr %t594, ptr %t571, i64 %t572)
  %t595 = getelementptr i8, ptr %t594, i64 %t572
  %t596 = call i64 @__olang_fmt_i64(ptr %t595, i64 %t575)
  %t597 = getelementptr i8, ptr %t595, i64 %t576
  call void @olang_textcopy(ptr %t597, ptr %t578, i64 %t579)
  %t598 = getelementptr i8, ptr %t597, i64 %t579
  %t599 = call i64 @__olang_fmt_i64(ptr %t598, i64 %t582)
  %t600 = getelementptr i8, ptr %t598, i64 %t583
  call void @olang_textcopy(ptr %t600, ptr %t585, i64 %t586)
  %t601 = insertvalue { i64, ptr } undef, i64 %t587, 0
  %t602 = insertvalue { i64, ptr } %t601, ptr %t588, 1
  %t604 = extractvalue { i64, ptr } %t602, 0
  %t605 = extractvalue { i64, ptr } %t602, 1
  %t606 = mul i64 %t604, 1
  %t607 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t606)
  call void @llvm.memcpy.p0.p0.i64(ptr %t607, ptr %t605, i64 %t606, i1 false)
  %t608 = insertvalue { i64, ptr } undef, i64 %t604, 0
  %t609 = insertvalue { i64, ptr } %t608, ptr %t607, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s15, ptr %t553, { i64, ptr } %t609)
  br label %bb48
bb48:
  %t612 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s15)
  store %"std/prelude/text:StringBuilder" %t612, ptr %l202
  br label %bb49
bb49:
  %t613 = load %"std/prelude/text:StringBuilder", ptr %l202
  store %"std/prelude/text:StringBuilder" %t613, ptr %l29
  %t614 = load i32, ptr %l16, !tbaa !23
  %t615 = extractvalue { i64, ptr } { i64 7, ptr @.d97 }, 1
  %t616 = extractvalue { i64, ptr } { i64 7, ptr @.d97 }, 0
  %t618 = sext i32 %t614 to i64
  %t619 = call i64 @__olang_fmt_i64(ptr null, i64 %t618)
  %t620 = add i64 %t616, %t619
  %t621 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t620)
  call void @olang_textcopy(ptr %t621, ptr %t615, i64 %t616)
  %t622 = getelementptr i8, ptr %t621, i64 %t616
  %t623 = call i64 @__olang_fmt_i64(ptr %t622, i64 %t618)
  %t624 = insertvalue { i64, ptr } undef, i64 %t620, 0
  %t625 = insertvalue { i64, ptr } %t624, ptr %t621, 1
  %t627 = extractvalue { i64, ptr } %t625, 0
  %t628 = extractvalue { i64, ptr } %t625, 1
  %t629 = mul i64 %t627, 1
  %t630 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t629)
  call void @llvm.memcpy.p0.p0.i64(ptr %t630, ptr %t628, i64 %t629, i1 false)
  %t631 = insertvalue { i64, ptr } undef, i64 %t627, 0
  %t632 = insertvalue { i64, ptr } %t631, ptr %t630, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s15, ptr %s15, ptr %l29, { i64, ptr } %t632)
  br label %bb50
bb50:
  %t635 = load ptr, ptr %l8, !tbaa !29
  %t636 = load i32, ptr %l28, !tbaa !23
  %t639 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t635, i32 %t636)
  store i32 %t639, ptr %l209
  br label %bb51
bb51:
  %t640 = load i32, ptr %l209, !tbaa !23
  store i32 %t640, ptr %l30, !tbaa !23
  %t641 = load i32, ptr %l30, !tbaa !23
  %t642 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t645 = icmp ne i32 %t641, %t642
  br i1 %t645, label %bb52, label %bb53
bb52:
  %t647 = load i32, ptr %l30, !tbaa !23
  %t648 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t651 = icmp ne i32 %t647, %t648
  store i1 %t651, ptr %l213, !tbaa !21
  br label %bb54
bb53:
  store i1 false, ptr %l213, !tbaa !21
  br label %bb54
bb54:
  %t653 = load i1, ptr %l213, !tbaa !21
  br i1 %t653, label %bb55, label %bb56
bb55:
  %t654 = load ptr, ptr %l8, !tbaa !29
  %t655 = load i32, ptr %l30, !tbaa !23
  %t658 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %t654, i32 %t655)
  store i1 %t658, ptr %l220
  br label %bb57
bb56:
  store i1 false, ptr %l217, !tbaa !21
  br label %bb58
bb57:
  %t659 = load i1, ptr %l220, !tbaa !21
  store i1 %t659, ptr %l217, !tbaa !21
  br label %bb58
bb58:
  %t660 = load i1, ptr %l217, !tbaa !21
  store i1 %t660, ptr %l31, !tbaa !21
  %t661 = load i1, ptr %l31, !tbaa !21
  br i1 %t661, label %bb59, label %bb60
bb59:
  store %olang.scope zeroinitializer, ptr %s19
  %t663 = load ptr, ptr %l1, !tbaa !29
  store ptr %t663, ptr %l222, !tbaa !29
  %t664 = load i32, ptr %l16, !tbaa !23
  store i32 %t664, ptr %l223, !tbaa !23
  %t665 = load ptr, ptr %l7, !tbaa !29
  %t666 = load i32, ptr %l30, !tbaa !23
  %t669 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s19, ptr %t665, i32 %t666)
  store { i64, ptr } %t669, ptr %l226
  br label %bb61
bb60:
  br label %bb64
bb61:
  %t670 = extractvalue { i64, ptr } { i64 5, ptr @.d98 }, 1
  %t671 = extractvalue { i64, ptr } { i64 5, ptr @.d98 }, 0
  %t672 = load i32, ptr %l223, !tbaa !23
  %t673 = sext i32 %t672 to i64
  %t674 = call i64 @__olang_fmt_i64(ptr null, i64 %t673)
  %t675 = add i64 %t671, %t674
  %t676 = extractvalue { i64, ptr } { i64 10, ptr @.d99 }, 1
  %t677 = extractvalue { i64, ptr } { i64 10, ptr @.d99 }, 0
  %t678 = add i64 %t675, %t677
  %t679 = load { i64, ptr }, ptr %l226, !tbaa !27
  %t680 = extractvalue { i64, ptr } %t679, 1
  %t681 = extractvalue { i64, ptr } %t679, 0
  %t682 = add i64 %t678, %t681
  %t683 = extractvalue { i64, ptr } { i64 1, ptr @.d100 }, 1
  %t684 = extractvalue { i64, ptr } { i64 1, ptr @.d100 }, 0
  %t685 = add i64 %t682, %t684
  %t686 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t685)
  call void @olang_textcopy(ptr %t686, ptr %t670, i64 %t671)
  %t687 = getelementptr i8, ptr %t686, i64 %t671
  %t688 = call i64 @__olang_fmt_i64(ptr %t687, i64 %t673)
  %t689 = getelementptr i8, ptr %t687, i64 %t674
  call void @olang_textcopy(ptr %t689, ptr %t676, i64 %t677)
  %t690 = getelementptr i8, ptr %t689, i64 %t677
  call void @olang_textcopy(ptr %t690, ptr %t680, i64 %t681)
  %t691 = getelementptr i8, ptr %t690, i64 %t681
  call void @olang_textcopy(ptr %t691, ptr %t683, i64 %t684)
  %t692 = insertvalue { i64, ptr } undef, i64 %t685, 0
  %t693 = insertvalue { i64, ptr } %t692, ptr %t686, 1
  %t695 = extractvalue { i64, ptr } %t693, 0
  %t696 = extractvalue { i64, ptr } %t693, 1
  %t697 = mul i64 %t695, 1
  %t698 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t697)
  call void @llvm.memcpy.p0.p0.i64(ptr %t698, ptr %t696, i64 %t697, i1 false)
  %t699 = insertvalue { i64, ptr } undef, i64 %t695, 0
  %t700 = insertvalue { i64, ptr } %t699, ptr %t698, 1
  %t701 = load ptr, ptr %l222, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s19, ptr %t701, { i64, ptr } %t700)
  br label %bb62
bb62:
  %t703 = load i32, ptr %l16, !tbaa !23
  %t704 = extractvalue { i64, ptr } { i64 9, ptr @.d101 }, 1
  %t705 = extractvalue { i64, ptr } { i64 9, ptr @.d101 }, 0
  %t707 = sext i32 %t703 to i64
  %t708 = call i64 @__olang_fmt_i64(ptr null, i64 %t707)
  %t709 = add i64 %t705, %t708
  %t710 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t709)
  call void @olang_textcopy(ptr %t710, ptr %t704, i64 %t705)
  %t711 = getelementptr i8, ptr %t710, i64 %t705
  %t712 = call i64 @__olang_fmt_i64(ptr %t711, i64 %t707)
  %t713 = insertvalue { i64, ptr } undef, i64 %t709, 0
  %t714 = insertvalue { i64, ptr } %t713, ptr %t710, 1
  %t716 = extractvalue { i64, ptr } %t714, 0
  %t717 = extractvalue { i64, ptr } %t714, 1
  %t718 = mul i64 %t716, 1
  %t719 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t718)
  call void @llvm.memcpy.p0.p0.i64(ptr %t719, ptr %t717, i64 %t718, i1 false)
  %t720 = insertvalue { i64, ptr } undef, i64 %t716, 0
  %t721 = insertvalue { i64, ptr } %t720, ptr %t719, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s15, ptr %s19, ptr %l29, { i64, ptr } %t721)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s19)
  br label %bb64
bb64:
  store i64 0, ptr %l32, !tbaa !24
  %t724 = load ptr, ptr %l8, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t725
  %t726 = getelementptr { i64, [4 x i64] }, ptr %t725, i32 0, i32 0
  store i64 0, ptr %t726
  %t727 = load { i64, [4 x i64] }, ptr %t725
  store { i64, [5 x i64] } zeroinitializer, ptr %t728
  %t729 = getelementptr { i64, [5 x i64] }, ptr %t728, i32 0, i32 0
  store i64 2, ptr %t729
  %t731 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t727, 0
  %t732 = getelementptr { i64, [5 x i64] }, ptr %t728, i32 0, i32 1
  store { { i64, [4 x i64] } } %t731, ptr %t732
  %t733 = load { i64, [5 x i64] }, ptr %t728
  %t734 = load i32, ptr %l28, !tbaa !23
  %t738 = call i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %t724, { i64, [5 x i64] } %t733, i32 %t734)
  store i64 %t738, ptr %l237
  br label %bb65
bb65:
  %t739 = load i64, ptr %l237, !tbaa !24
  store i64 %t739, ptr %l33, !tbaa !24
  store i64 1, ptr %l34, !tbaa !24
  %t740 = load i64, ptr %l33, !tbaa !24
  %t741 = load i64, ptr %l32, !tbaa !24
  %t744 = icmp sgt i64 %t740, %t741
  br i1 %t744, label %bb66, label %bb67
bb66:
  %t746 = load i64, ptr %l34, !tbaa !24
  %t748 = icmp sgt i64 %t746, 0
  br i1 %t748, label %bb68, label %bb69
bb67:
  store i64 0, ptr %l241, !tbaa !24
  br label %bb71
bb68:
  %t750 = load i64, ptr %l33, !tbaa !24
  %t751 = load i64, ptr %l32, !tbaa !24
  %t754 = sub i64 %t750, %t751
  %t755 = load i64, ptr %l34, !tbaa !24
  %t758 = add i64 %t754, %t755
  %t760 = sub i64 %t758, 1
  %t761 = load i64, ptr %l34, !tbaa !24
  %t764 = sdiv i64 %t760, %t761
  store i64 %t764, ptr %l244, !tbaa !24
  br label %bb70
bb69:
  store i64 0, ptr %l244, !tbaa !24
  br label %bb70
bb70:
  %t766 = load i64, ptr %l244, !tbaa !24
  store i64 %t766, ptr %l241, !tbaa !24
  br label %bb71
bb71:
  %t767 = load i64, ptr %l241, !tbaa !24
  store i64 %t767, ptr %l35, !tbaa !24
  store i64 0, ptr %l36, !tbaa !24
  br label %bb72
bb72:
  store %olang.scope zeroinitializer, ptr %s23
  %t768 = load i64, ptr %l36, !tbaa !24
  %t769 = load i64, ptr %l35, !tbaa !24
  %t772 = icmp slt i64 %t768, %t769
  %t774 = xor i1 %t772, true
  br i1 %t774, label %bb73, label %bb74
bb73:
  call void @__olang_scope_close(ptr %s23)
  br label %bb80
bb74:
  br label %bb75
bb75:
  %t776 = load i64, ptr %l32, !tbaa !24
  %t777 = load i64, ptr %l36, !tbaa !24
  %t778 = load i64, ptr %l34, !tbaa !24
  %t781 = mul i64 %t777, %t778
  %t784 = add i64 %t776, %t781
  store i64 %t784, ptr %l37, !tbaa !24
  %t786 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %s23, ptr %s23, ptr %t786, { i64, ptr } { i64 18, ptr @.d102 }, { i64, ptr } { i64 67, ptr @.d103 })
  br label %bb76
bb76:
  %t788 = load ptr, ptr %l1, !tbaa !29
  %t789 = load i32, ptr %l16, !tbaa !23
  %t790 = load i64, ptr %l37, !tbaa !24
  %t791 = extractvalue { i64, ptr } { i64 5, ptr @.d104 }, 1
  %t792 = extractvalue { i64, ptr } { i64 5, ptr @.d104 }, 0
  %t794 = sext i32 %t789 to i64
  %t795 = call i64 @__olang_fmt_i64(ptr null, i64 %t794)
  %t796 = add i64 %t792, %t795
  %t797 = extractvalue { i64, ptr } { i64 1, ptr @.d105 }, 1
  %t798 = extractvalue { i64, ptr } { i64 1, ptr @.d105 }, 0
  %t799 = add i64 %t796, %t798
  %t801 = call i64 @__olang_fmt_i64(ptr null, i64 %t790)
  %t802 = add i64 %t799, %t801
  %t803 = extractvalue { i64, ptr } { i64 37, ptr @.d106 }, 1
  %t804 = extractvalue { i64, ptr } { i64 37, ptr @.d106 }, 0
  %t805 = add i64 %t802, %t804
  %t806 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t805)
  call void @olang_textcopy(ptr %t806, ptr %t791, i64 %t792)
  %t807 = getelementptr i8, ptr %t806, i64 %t792
  %t808 = call i64 @__olang_fmt_i64(ptr %t807, i64 %t794)
  %t809 = getelementptr i8, ptr %t807, i64 %t795
  call void @olang_textcopy(ptr %t809, ptr %t797, i64 %t798)
  %t810 = getelementptr i8, ptr %t809, i64 %t798
  %t811 = call i64 @__olang_fmt_i64(ptr %t810, i64 %t790)
  %t812 = getelementptr i8, ptr %t810, i64 %t801
  call void @olang_textcopy(ptr %t812, ptr %t803, i64 %t804)
  %t813 = insertvalue { i64, ptr } undef, i64 %t805, 0
  %t814 = insertvalue { i64, ptr } %t813, ptr %t806, 1
  %t816 = extractvalue { i64, ptr } %t814, 0
  %t817 = extractvalue { i64, ptr } %t814, 1
  %t818 = mul i64 %t816, 1
  %t819 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t818)
  call void @llvm.memcpy.p0.p0.i64(ptr %t819, ptr %t817, i64 %t818, i1 false)
  %t820 = insertvalue { i64, ptr } undef, i64 %t816, 0
  %t821 = insertvalue { i64, ptr } %t820, ptr %t819, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s23, ptr %t788, { i64, ptr } %t821)
  br label %bb77
bb77:
  %t824 = load i32, ptr %l16, !tbaa !23
  %t825 = load i64, ptr %l37, !tbaa !24
  %t826 = extractvalue { i64, ptr } { i64 9, ptr @.d107 }, 1
  %t827 = extractvalue { i64, ptr } { i64 9, ptr @.d107 }, 0
  %t829 = sext i32 %t824 to i64
  %t830 = call i64 @__olang_fmt_i64(ptr null, i64 %t829)
  %t831 = add i64 %t827, %t830
  %t832 = extractvalue { i64, ptr } { i64 1, ptr @.d108 }, 1
  %t833 = extractvalue { i64, ptr } { i64 1, ptr @.d108 }, 0
  %t834 = add i64 %t831, %t833
  %t836 = call i64 @__olang_fmt_i64(ptr null, i64 %t825)
  %t837 = add i64 %t834, %t836
  %t838 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t837)
  call void @olang_textcopy(ptr %t838, ptr %t826, i64 %t827)
  %t839 = getelementptr i8, ptr %t838, i64 %t827
  %t840 = call i64 @__olang_fmt_i64(ptr %t839, i64 %t829)
  %t841 = getelementptr i8, ptr %t839, i64 %t830
  call void @olang_textcopy(ptr %t841, ptr %t832, i64 %t833)
  %t842 = getelementptr i8, ptr %t841, i64 %t833
  %t843 = call i64 @__olang_fmt_i64(ptr %t842, i64 %t825)
  %t844 = insertvalue { i64, ptr } undef, i64 %t837, 0
  %t845 = insertvalue { i64, ptr } %t844, ptr %t838, 1
  %t847 = extractvalue { i64, ptr } %t845, 0
  %t848 = extractvalue { i64, ptr } %t845, 1
  %t849 = mul i64 %t847, 1
  %t850 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t849)
  call void @llvm.memcpy.p0.p0.i64(ptr %t850, ptr %t848, i64 %t849, i1 false)
  %t851 = insertvalue { i64, ptr } undef, i64 %t847, 0
  %t852 = insertvalue { i64, ptr } %t851, ptr %t850, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s15, ptr %s23, ptr %l29, { i64, ptr } %t852)
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s23)
  br label %bb79
bb79:
  %t855 = load i64, ptr %l36, !tbaa !24
  %t857 = add i64 %t855, 1
  store i64 %t857, ptr %l36, !tbaa !24
  br label %bb72
bb80:
  %t859 = load ptr, ptr %l8, !tbaa !29
  %t860 = load i32, ptr %l28, !tbaa !23
  %t863 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %s15, ptr %t859, i32 %t860)
  store { i64, ptr } %t863, ptr %l277
  br label %bb81
bb81:
  %t864 = load { i64, ptr }, ptr %l277, !tbaa !27
  store { i64, ptr } %t864, ptr %l38, !tbaa !27
  store { i64, ptr } { i64 0, ptr @.d109 }, ptr %l278, !tbaa !27
  %t865 = load { i64, ptr }, ptr %l278, !tbaa !27
  store { i64, ptr } %t865, ptr %l279, !tbaa !27
  %t866 = load { i64, ptr }, ptr %l279, !tbaa !27
  %t867 = extractvalue { i64, ptr } %t866, 0
  store i64 %t867, ptr %l280, !tbaa !24
  %t868 = load i64, ptr %l280, !tbaa !24
  %t869 = mul i64 %t868, 1
  %t870 = call ptr @__olang_scope_alloc_zeroed(ptr %s15, i64 %t869)
  %t871 = insertvalue { i64, ptr } undef, i64 %t868, 0
  %t872 = insertvalue { i64, ptr } %t871, ptr %t870, 1
  store { i64, ptr } %t872, ptr %l281, !tbaa !27
  %t873 = getelementptr { i64, ptr }, ptr %l281, i32 0, i32 1
  %t874 = load ptr, ptr %t873, !tbaa !27
  %t875 = getelementptr { i64, ptr }, ptr %l279, i32 0, i32 1
  %t876 = load ptr, ptr %t875, !tbaa !27
  %t877 = load i64, ptr %l280, !tbaa !24
  %t878 = mul i64 %t877, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t874, ptr %t876, i64 %t878, i1 false)
  %t879 = load { i64, ptr }, ptr %l281, !tbaa !27
  store { i64, ptr } %t879, ptr %l39, !tbaa !27
  %t880 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t882 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s15, ptr %s15, { i64, ptr } %t880, { i64, ptr } { i64 4, ptr @.d110 })
  store i1 %t882, ptr %l283
  br label %bb82
bb82:
  %t883 = load i1, ptr %l283, !tbaa !21
  br i1 %t883, label %bb83, label %bb84
bb83:
  store %olang.scope zeroinitializer, ptr %s27
  %t884 = load ptr, ptr %l1, !tbaa !29
  store ptr %t884, ptr %l284, !tbaa !29
  %t885 = load i32, ptr %l16, !tbaa !23
  store i32 %t885, ptr %l285, !tbaa !23
  %t887 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s15, ptr %s27, ptr %l29)
  store { i64, ptr } %t887, ptr %l287
  br label %bb85
bb84:
  store %olang.scope zeroinitializer, ptr %s29
  %t888 = load ptr, ptr %l1, !tbaa !29
  store ptr %t888, ptr %l290, !tbaa !29
  %t889 = load i32, ptr %l16, !tbaa !23
  store i32 %t889, ptr %l291, !tbaa !23
  %t890 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t890, ptr %l292, !tbaa !27
  %t891 = load i32, ptr %l16, !tbaa !23
  store i32 %t891, ptr %l293, !tbaa !23
  %t893 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s15, ptr %s29, ptr %l29)
  store { i64, ptr } %t893, ptr %l295
  br label %bb87
bb85:
  %t894 = extractvalue { i64, ptr } { i64 15, ptr @.d111 }, 1
  %t895 = extractvalue { i64, ptr } { i64 15, ptr @.d111 }, 0
  %t896 = load i32, ptr %l285, !tbaa !23
  %t897 = sext i32 %t896 to i64
  %t898 = call i64 @__olang_fmt_i64(ptr null, i64 %t897)
  %t899 = add i64 %t895, %t898
  %t900 = extractvalue { i64, ptr } { i64 1, ptr @.d112 }, 1
  %t901 = extractvalue { i64, ptr } { i64 1, ptr @.d112 }, 0
  %t902 = add i64 %t899, %t901
  %t903 = load { i64, ptr }, ptr %l287, !tbaa !27
  %t904 = extractvalue { i64, ptr } %t903, 1
  %t905 = extractvalue { i64, ptr } %t903, 0
  %t906 = add i64 %t902, %t905
  %t907 = extractvalue { i64, ptr } { i64 2, ptr @.d113 }, 1
  %t908 = extractvalue { i64, ptr } { i64 2, ptr @.d113 }, 0
  %t909 = add i64 %t906, %t908
  %t910 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t909)
  call void @olang_textcopy(ptr %t910, ptr %t894, i64 %t895)
  %t911 = getelementptr i8, ptr %t910, i64 %t895
  %t912 = call i64 @__olang_fmt_i64(ptr %t911, i64 %t897)
  %t913 = getelementptr i8, ptr %t911, i64 %t898
  call void @olang_textcopy(ptr %t913, ptr %t900, i64 %t901)
  %t914 = getelementptr i8, ptr %t913, i64 %t901
  call void @olang_textcopy(ptr %t914, ptr %t904, i64 %t905)
  %t915 = getelementptr i8, ptr %t914, i64 %t905
  call void @olang_textcopy(ptr %t915, ptr %t907, i64 %t908)
  %t916 = insertvalue { i64, ptr } undef, i64 %t909, 0
  %t917 = insertvalue { i64, ptr } %t916, ptr %t910, 1
  %t919 = extractvalue { i64, ptr } %t917, 0
  %t920 = extractvalue { i64, ptr } %t917, 1
  %t921 = mul i64 %t919, 1
  %t922 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t921)
  call void @llvm.memcpy.p0.p0.i64(ptr %t922, ptr %t920, i64 %t921, i1 false)
  %t923 = insertvalue { i64, ptr } undef, i64 %t919, 0
  %t924 = insertvalue { i64, ptr } %t923, ptr %t922, 1
  %t925 = load ptr, ptr %l284, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s27, ptr %t925, { i64, ptr } %t924)
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s27)
  br label %bb92
bb87:
  %t927 = extractvalue { i64, ptr } { i64 5, ptr @.d114 }, 1
  %t928 = extractvalue { i64, ptr } { i64 5, ptr @.d114 }, 0
  %t929 = load i32, ptr %l291, !tbaa !23
  %t930 = sext i32 %t929 to i64
  %t931 = call i64 @__olang_fmt_i64(ptr null, i64 %t930)
  %t932 = add i64 %t928, %t931
  %t933 = extractvalue { i64, ptr } { i64 8, ptr @.d115 }, 1
  %t934 = extractvalue { i64, ptr } { i64 8, ptr @.d115 }, 0
  %t935 = add i64 %t932, %t934
  %t936 = load { i64, ptr }, ptr %l292, !tbaa !27
  %t937 = extractvalue { i64, ptr } %t936, 1
  %t938 = extractvalue { i64, ptr } %t936, 0
  %t939 = add i64 %t935, %t938
  %t940 = extractvalue { i64, ptr } { i64 4, ptr @.d116 }, 1
  %t941 = extractvalue { i64, ptr } { i64 4, ptr @.d116 }, 0
  %t942 = add i64 %t939, %t941
  %t943 = load i32, ptr %l293, !tbaa !23
  %t944 = sext i32 %t943 to i64
  %t945 = call i64 @__olang_fmt_i64(ptr null, i64 %t944)
  %t946 = add i64 %t942, %t945
  %t947 = extractvalue { i64, ptr } { i64 1, ptr @.d117 }, 1
  %t948 = extractvalue { i64, ptr } { i64 1, ptr @.d117 }, 0
  %t949 = add i64 %t946, %t948
  %t950 = load { i64, ptr }, ptr %l295, !tbaa !27
  %t951 = extractvalue { i64, ptr } %t950, 1
  %t952 = extractvalue { i64, ptr } %t950, 0
  %t953 = add i64 %t949, %t952
  %t954 = extractvalue { i64, ptr } { i64 2, ptr @.d118 }, 1
  %t955 = extractvalue { i64, ptr } { i64 2, ptr @.d118 }, 0
  %t956 = add i64 %t953, %t955
  %t957 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t956)
  call void @olang_textcopy(ptr %t957, ptr %t927, i64 %t928)
  %t958 = getelementptr i8, ptr %t957, i64 %t928
  %t959 = call i64 @__olang_fmt_i64(ptr %t958, i64 %t930)
  %t960 = getelementptr i8, ptr %t958, i64 %t931
  call void @olang_textcopy(ptr %t960, ptr %t933, i64 %t934)
  %t961 = getelementptr i8, ptr %t960, i64 %t934
  call void @olang_textcopy(ptr %t961, ptr %t937, i64 %t938)
  %t962 = getelementptr i8, ptr %t961, i64 %t938
  call void @olang_textcopy(ptr %t962, ptr %t940, i64 %t941)
  %t963 = getelementptr i8, ptr %t962, i64 %t941
  %t964 = call i64 @__olang_fmt_i64(ptr %t963, i64 %t944)
  %t965 = getelementptr i8, ptr %t963, i64 %t945
  call void @olang_textcopy(ptr %t965, ptr %t947, i64 %t948)
  %t966 = getelementptr i8, ptr %t965, i64 %t948
  call void @olang_textcopy(ptr %t966, ptr %t951, i64 %t952)
  %t967 = getelementptr i8, ptr %t966, i64 %t952
  call void @olang_textcopy(ptr %t967, ptr %t954, i64 %t955)
  %t968 = insertvalue { i64, ptr } undef, i64 %t956, 0
  %t969 = insertvalue { i64, ptr } %t968, ptr %t957, 1
  %t971 = extractvalue { i64, ptr } %t969, 0
  %t972 = extractvalue { i64, ptr } %t969, 1
  %t973 = mul i64 %t971, 1
  %t974 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t973)
  call void @llvm.memcpy.p0.p0.i64(ptr %t974, ptr %t972, i64 %t973, i1 false)
  %t975 = insertvalue { i64, ptr } undef, i64 %t971, 0
  %t976 = insertvalue { i64, ptr } %t975, ptr %t974, 1
  %t977 = load ptr, ptr %l290, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s29, ptr %t977, { i64, ptr } %t976)
  br label %bb88
bb88:
  %t979 = load i32, ptr %l16, !tbaa !23
  %t980 = extractvalue { i64, ptr } { i64 3, ptr @.d119 }, 1
  %t981 = extractvalue { i64, ptr } { i64 3, ptr @.d119 }, 0
  %t983 = sext i32 %t979 to i64
  %t984 = call i64 @__olang_fmt_i64(ptr null, i64 %t983)
  %t985 = add i64 %t981, %t984
  %t986 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t985)
  call void @olang_textcopy(ptr %t986, ptr %t980, i64 %t981)
  %t987 = getelementptr i8, ptr %t986, i64 %t981
  %t988 = call i64 @__olang_fmt_i64(ptr %t987, i64 %t983)
  %t989 = insertvalue { i64, ptr } undef, i64 %t985, 0
  %t990 = insertvalue { i64, ptr } %t989, ptr %t986, 1
  store { i64, ptr } %t990, ptr %l299, !tbaa !27
  %t991 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t992 = extractvalue { i64, ptr } %t991, 0
  %t993 = load { i64, ptr }, ptr %l299, !tbaa !27
  %t994 = extractvalue { i64, ptr } %t993, 0
  store i64 %t994, ptr %l301, !tbaa !24
  %t996 = load i64, ptr %l301, !tbaa !24
  %t997 = icmp eq i64 %t992, %t996
  br i1 %t997, label %bb89, label %bb90
bb89:
  %t999 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t1000 = load ptr, ptr %t999, !tbaa !27
  %t1001 = getelementptr { i64, ptr }, ptr %l299, i32 0, i32 1
  %t1002 = load ptr, ptr %t1001, !tbaa !27
  %t1003 = load i64, ptr %l301, !tbaa !24
  %t1004 = mul i64 %t1003, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1000, ptr %t1002, i64 %t1004, i1 false)
  br label %bb91
bb90:
  %t1005 = load { i64, ptr }, ptr %l299, !tbaa !27
  store { i64, ptr } %t1005, ptr %l39, !tbaa !27
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s29)
  br label %bb92
bb92:
  %t1006 = load i1, ptr %l31, !tbaa !21
  br i1 %t1006, label %bb93, label %bb94
bb93:
  store %olang.scope zeroinitializer, ptr %s32
  %t1008 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1008, ptr %l304, !tbaa !29
  %t1009 = load i32, ptr %l16, !tbaa !23
  store i32 %t1009, ptr %l305, !tbaa !23
  %t1010 = load ptr, ptr %l7, !tbaa !29
  %t1011 = load i32, ptr %l30, !tbaa !23
  %t1014 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s32, ptr %t1010, i32 %t1011)
  store { i64, ptr } %t1014, ptr %l308
  br label %bb95
bb94:
  br label %bb100
bb95:
  %t1015 = load i32, ptr %l16, !tbaa !23
  %t1016 = extractvalue { i64, ptr } { i64 5, ptr @.d120 }, 1
  %t1017 = extractvalue { i64, ptr } { i64 5, ptr @.d120 }, 0
  %t1018 = load i32, ptr %l305, !tbaa !23
  %t1019 = sext i32 %t1018 to i64
  %t1020 = call i64 @__olang_fmt_i64(ptr null, i64 %t1019)
  %t1021 = add i64 %t1017, %t1020
  %t1022 = extractvalue { i64, ptr } { i64 8, ptr @.d121 }, 1
  %t1023 = extractvalue { i64, ptr } { i64 8, ptr @.d121 }, 0
  %t1024 = add i64 %t1021, %t1023
  %t1025 = load { i64, ptr }, ptr %l308, !tbaa !27
  %t1026 = extractvalue { i64, ptr } %t1025, 1
  %t1027 = extractvalue { i64, ptr } %t1025, 0
  %t1028 = add i64 %t1024, %t1027
  %t1029 = extractvalue { i64, ptr } { i64 9, ptr @.d122 }, 1
  %t1030 = extractvalue { i64, ptr } { i64 9, ptr @.d122 }, 0
  %t1031 = add i64 %t1028, %t1030
  %t1033 = sext i32 %t1015 to i64
  %t1034 = call i64 @__olang_fmt_i64(ptr null, i64 %t1033)
  %t1035 = add i64 %t1031, %t1034
  %t1036 = extractvalue { i64, ptr } { i64 1, ptr @.d123 }, 1
  %t1037 = extractvalue { i64, ptr } { i64 1, ptr @.d123 }, 0
  %t1038 = add i64 %t1035, %t1037
  %t1039 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t1038)
  call void @olang_textcopy(ptr %t1039, ptr %t1016, i64 %t1017)
  %t1040 = getelementptr i8, ptr %t1039, i64 %t1017
  %t1041 = call i64 @__olang_fmt_i64(ptr %t1040, i64 %t1019)
  %t1042 = getelementptr i8, ptr %t1040, i64 %t1020
  call void @olang_textcopy(ptr %t1042, ptr %t1022, i64 %t1023)
  %t1043 = getelementptr i8, ptr %t1042, i64 %t1023
  call void @olang_textcopy(ptr %t1043, ptr %t1026, i64 %t1027)
  %t1044 = getelementptr i8, ptr %t1043, i64 %t1027
  call void @olang_textcopy(ptr %t1044, ptr %t1029, i64 %t1030)
  %t1045 = getelementptr i8, ptr %t1044, i64 %t1030
  %t1046 = call i64 @__olang_fmt_i64(ptr %t1045, i64 %t1033)
  %t1047 = getelementptr i8, ptr %t1045, i64 %t1034
  call void @olang_textcopy(ptr %t1047, ptr %t1036, i64 %t1037)
  %t1048 = insertvalue { i64, ptr } undef, i64 %t1038, 0
  %t1049 = insertvalue { i64, ptr } %t1048, ptr %t1039, 1
  %t1051 = extractvalue { i64, ptr } %t1049, 0
  %t1052 = extractvalue { i64, ptr } %t1049, 1
  %t1053 = mul i64 %t1051, 1
  %t1054 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t1053)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1054, ptr %t1052, i64 %t1053, i1 false)
  %t1055 = insertvalue { i64, ptr } undef, i64 %t1051, 0
  %t1056 = insertvalue { i64, ptr } %t1055, ptr %t1054, 1
  %t1057 = load ptr, ptr %l304, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s32, ptr %t1057, { i64, ptr } %t1056)
  br label %bb96
bb96:
  %t1059 = load i32, ptr %l16, !tbaa !23
  %t1060 = extractvalue { i64, ptr } { i64 3, ptr @.d124 }, 1
  %t1061 = extractvalue { i64, ptr } { i64 3, ptr @.d124 }, 0
  %t1063 = sext i32 %t1059 to i64
  %t1064 = call i64 @__olang_fmt_i64(ptr null, i64 %t1063)
  %t1065 = add i64 %t1061, %t1064
  %t1066 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t1065)
  call void @olang_textcopy(ptr %t1066, ptr %t1060, i64 %t1061)
  %t1067 = getelementptr i8, ptr %t1066, i64 %t1061
  %t1068 = call i64 @__olang_fmt_i64(ptr %t1067, i64 %t1063)
  %t1069 = insertvalue { i64, ptr } undef, i64 %t1065, 0
  %t1070 = insertvalue { i64, ptr } %t1069, ptr %t1066, 1
  store { i64, ptr } %t1070, ptr %l313, !tbaa !27
  %t1071 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t1072 = extractvalue { i64, ptr } %t1071, 0
  %t1073 = load { i64, ptr }, ptr %l313, !tbaa !27
  %t1074 = extractvalue { i64, ptr } %t1073, 0
  store i64 %t1074, ptr %l315, !tbaa !24
  %t1076 = load i64, ptr %l315, !tbaa !24
  %t1077 = icmp eq i64 %t1072, %t1076
  br i1 %t1077, label %bb97, label %bb98
bb97:
  %t1079 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t1080 = load ptr, ptr %t1079, !tbaa !27
  %t1081 = getelementptr { i64, ptr }, ptr %l313, i32 0, i32 1
  %t1082 = load ptr, ptr %t1081, !tbaa !27
  %t1083 = load i64, ptr %l315, !tbaa !24
  %t1084 = mul i64 %t1083, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1080, ptr %t1082, i64 %t1084, i1 false)
  br label %bb99
bb98:
  %t1085 = load { i64, ptr }, ptr %l313, !tbaa !27
  store { i64, ptr } %t1085, ptr %l39, !tbaa !27
  br label %bb99
bb99:
  call void @__olang_scope_close(ptr %s32)
  br label %bb100
bb100:
  %t1086 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t1088 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s15, ptr %s15, { i64, ptr } %t1086, { i64, ptr } { i64 0, ptr @.d125 })
  store i1 %t1088, ptr %l318
  br label %bb101
bb101:
  %t1089 = load i1, ptr %l318, !tbaa !21
  %t1090 = xor i1 %t1089, true
  br i1 %t1090, label %bb102, label %bb103
bb102:
  %t1092 = getelementptr %"compiler/mir:Task", ptr %l3, i32 0, i32 3
  %t1093 = getelementptr %"compiler/mir:Range", ptr %t1092, i32 0, i32 1
  %t1094 = load i32, ptr %t1093, !tbaa !23
  %t1096 = icmp sgt i32 %t1094, 0
  store i1 %t1096, ptr %l320, !tbaa !21
  br label %bb104
bb103:
  store i1 false, ptr %l320, !tbaa !21
  br label %bb104
bb104:
  %t1098 = load i1, ptr %l320, !tbaa !21
  br i1 %t1098, label %bb105, label %bb106
bb105:
  %t1099 = getelementptr %"compiler/mir:Task", ptr %l3, i32 0, i32 3
  %t1100 = getelementptr %"compiler/mir:Range", ptr %t1099, i32 0, i32 1
  %t1101 = load i32, ptr %t1100, !tbaa !23
  %t1103 = icmp eq i32 %t1101, 1
  br i1 %t1103, label %bb107, label %bb108
bb106:
  br label %bb132
bb107:
  store %olang.scope zeroinitializer, ptr %s36
  %t1105 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1105, ptr %l325, !tbaa !29
  %t1106 = load i32, ptr %l16, !tbaa !23
  store i32 %t1106, ptr %l326, !tbaa !23
  %t1107 = load i64, ptr %l6, !tbaa !24
  store i64 %t1107, ptr %l327, !tbaa !24
  %t1108 = load ptr, ptr %l7, !tbaa !29
  %t1109 = load i32, ptr %l30, !tbaa !23
  %t1112 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s36, ptr %t1108, i32 %t1109)
  store { i64, ptr } %t1112, ptr %l330
  br label %bb109
bb108:
  %t1113 = load ptr, ptr %l8, !tbaa !29
  store ptr %t1113, ptr %l335, !tbaa !29
  %t1114 = load ptr, ptr %l8, !tbaa !29
  store ptr %t1114, ptr %l336, !tbaa !29
  %t1115 = load ptr, ptr %l8, !tbaa !29
  %t1116 = load i32, ptr %l30, !tbaa !23
  %t1119 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1115, i32 %t1116)
  store i32 %t1119, ptr %l339
  br label %bb111
bb109:
  %t1120 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t1121 = load i32, ptr %l16, !tbaa !23
  %t1122 = extractvalue { i64, ptr } { i64 5, ptr @.d126 }, 1
  %t1123 = extractvalue { i64, ptr } { i64 5, ptr @.d126 }, 0
  %t1124 = load i32, ptr %l326, !tbaa !23
  %t1125 = sext i32 %t1124 to i64
  %t1126 = call i64 @__olang_fmt_i64(ptr null, i64 %t1125)
  %t1127 = add i64 %t1123, %t1126
  %t1128 = extractvalue { i64, ptr } { i64 19, ptr @.d127 }, 1
  %t1129 = extractvalue { i64, ptr } { i64 19, ptr @.d127 }, 0
  %t1130 = add i64 %t1127, %t1129
  %t1131 = load i64, ptr %l327, !tbaa !24
  %t1132 = call i64 @__olang_fmt_i64(ptr null, i64 %t1131)
  %t1133 = add i64 %t1130, %t1132
  %t1134 = extractvalue { i64, ptr } { i64 9, ptr @.d128 }, 1
  %t1135 = extractvalue { i64, ptr } { i64 9, ptr @.d128 }, 0
  %t1136 = add i64 %t1133, %t1135
  %t1137 = load { i64, ptr }, ptr %l330, !tbaa !27
  %t1138 = extractvalue { i64, ptr } %t1137, 1
  %t1139 = extractvalue { i64, ptr } %t1137, 0
  %t1140 = add i64 %t1136, %t1139
  %t1141 = extractvalue { i64, ptr } { i64 1, ptr @.d129 }, 1
  %t1142 = extractvalue { i64, ptr } { i64 1, ptr @.d129 }, 0
  %t1143 = add i64 %t1140, %t1142
  %t1145 = extractvalue { i64, ptr } %t1120, 1
  %t1146 = extractvalue { i64, ptr } %t1120, 0
  %t1147 = add i64 %t1143, %t1146
  %t1148 = extractvalue { i64, ptr } { i64 9, ptr @.d130 }, 1
  %t1149 = extractvalue { i64, ptr } { i64 9, ptr @.d130 }, 0
  %t1150 = add i64 %t1147, %t1149
  %t1152 = sext i32 %t1121 to i64
  %t1153 = call i64 @__olang_fmt_i64(ptr null, i64 %t1152)
  %t1154 = add i64 %t1150, %t1153
  %t1155 = extractvalue { i64, ptr } { i64 1, ptr @.d131 }, 1
  %t1156 = extractvalue { i64, ptr } { i64 1, ptr @.d131 }, 0
  %t1157 = add i64 %t1154, %t1156
  %t1158 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t1157)
  call void @olang_textcopy(ptr %t1158, ptr %t1122, i64 %t1123)
  %t1159 = getelementptr i8, ptr %t1158, i64 %t1123
  %t1160 = call i64 @__olang_fmt_i64(ptr %t1159, i64 %t1125)
  %t1161 = getelementptr i8, ptr %t1159, i64 %t1126
  call void @olang_textcopy(ptr %t1161, ptr %t1128, i64 %t1129)
  %t1162 = getelementptr i8, ptr %t1161, i64 %t1129
  %t1163 = call i64 @__olang_fmt_i64(ptr %t1162, i64 %t1131)
  %t1164 = getelementptr i8, ptr %t1162, i64 %t1132
  call void @olang_textcopy(ptr %t1164, ptr %t1134, i64 %t1135)
  %t1165 = getelementptr i8, ptr %t1164, i64 %t1135
  call void @olang_textcopy(ptr %t1165, ptr %t1138, i64 %t1139)
  %t1166 = getelementptr i8, ptr %t1165, i64 %t1139
  call void @olang_textcopy(ptr %t1166, ptr %t1141, i64 %t1142)
  %t1167 = getelementptr i8, ptr %t1166, i64 %t1142
  call void @olang_textcopy(ptr %t1167, ptr %t1145, i64 %t1146)
  %t1168 = getelementptr i8, ptr %t1167, i64 %t1146
  call void @olang_textcopy(ptr %t1168, ptr %t1148, i64 %t1149)
  %t1169 = getelementptr i8, ptr %t1168, i64 %t1149
  %t1170 = call i64 @__olang_fmt_i64(ptr %t1169, i64 %t1152)
  %t1171 = getelementptr i8, ptr %t1169, i64 %t1153
  call void @olang_textcopy(ptr %t1171, ptr %t1155, i64 %t1156)
  %t1172 = insertvalue { i64, ptr } undef, i64 %t1157, 0
  %t1173 = insertvalue { i64, ptr } %t1172, ptr %t1158, 1
  %t1175 = extractvalue { i64, ptr } %t1173, 0
  %t1176 = extractvalue { i64, ptr } %t1173, 1
  %t1177 = mul i64 %t1175, 1
  %t1178 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t1177)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1178, ptr %t1176, i64 %t1177, i1 false)
  %t1179 = insertvalue { i64, ptr } undef, i64 %t1175, 0
  %t1180 = insertvalue { i64, ptr } %t1179, ptr %t1178, 1
  %t1181 = load ptr, ptr %l325, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s36, ptr %t1181, { i64, ptr } %t1180)
  br label %bb110
bb110:
  call void @__olang_scope_close(ptr %s36)
  br label %bb131
bb111:
  %t1183 = load ptr, ptr %l336, !tbaa !29
  %t1184 = load i32, ptr %l339, !tbaa !23
  %t1185 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t1183, i32 %t1184)
  store i32 %t1185, ptr %l340
  br label %bb112
bb112:
  %t1186 = load ptr, ptr %l335, !tbaa !29
  %t1187 = load i32, ptr %l340, !tbaa !23
  %t1188 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t1186, i32 %t1187)
  store { i64, ptr } %t1188, ptr %l341
  br label %bb113
bb113:
  %t1189 = load { i64, ptr }, ptr %l341, !tbaa !27
  store { i64, ptr } %t1189, ptr %l40, !tbaa !27
  store i32 0, ptr %l41, !tbaa !23
  %t1190 = getelementptr %"compiler/mir:Task", ptr %l3, i32 0, i32 3
  %t1191 = getelementptr %"compiler/mir:Range", ptr %t1190, i32 0, i32 1
  %t1192 = load i32, ptr %t1191, !tbaa !23
  store i32 %t1192, ptr %l42, !tbaa !23
  store i32 1, ptr %l43, !tbaa !23
  %t1194 = load i32, ptr %l42, !tbaa !23
  %t1195 = load i32, ptr %l41, !tbaa !23
  %t1198 = icmp sgt i32 %t1194, %t1195
  br i1 %t1198, label %bb114, label %bb115
bb114:
  %t1200 = load i32, ptr %l43, !tbaa !23
  %t1202 = icmp sgt i32 %t1200, 0
  br i1 %t1202, label %bb116, label %bb117
bb115:
  store i32 0, ptr %l346, !tbaa !23
  br label %bb119
bb116:
  %t1204 = load i32, ptr %l42, !tbaa !23
  %t1205 = load i32, ptr %l41, !tbaa !23
  %t1208 = sub i32 %t1204, %t1205
  %t1209 = load i32, ptr %l43, !tbaa !23
  %t1212 = add i32 %t1208, %t1209
  %t1214 = sub i32 %t1212, 1
  %t1215 = load i32, ptr %l43, !tbaa !23
  %t1218 = sdiv i32 %t1214, %t1215
  store i32 %t1218, ptr %l349, !tbaa !23
  br label %bb118
bb117:
  store i32 0, ptr %l349, !tbaa !23
  br label %bb118
bb118:
  %t1220 = load i32, ptr %l349, !tbaa !23
  store i32 %t1220, ptr %l346, !tbaa !23
  br label %bb119
bb119:
  %t1221 = load i32, ptr %l346, !tbaa !23
  store i32 %t1221, ptr %l44, !tbaa !23
  store i32 0, ptr %l45, !tbaa !23
  br label %bb120
bb120:
  store %olang.scope zeroinitializer, ptr %s40
  %t1222 = load i32, ptr %l45, !tbaa !23
  %t1223 = load i32, ptr %l44, !tbaa !23
  %t1226 = icmp slt i32 %t1222, %t1223
  %t1228 = xor i1 %t1226, true
  br i1 %t1228, label %bb121, label %bb122
bb121:
  call void @__olang_scope_close(ptr %s40)
  br label %bb130
bb122:
  br label %bb123
bb123:
  %t1230 = load i32, ptr %l41, !tbaa !23
  %t1231 = load i32, ptr %l45, !tbaa !23
  %t1232 = load i32, ptr %l43, !tbaa !23
  %t1235 = mul i32 %t1231, %t1232
  %t1238 = add i32 %t1230, %t1235
  store i32 %t1238, ptr %l46, !tbaa !23
  %t1240 = load ptr, ptr %l1, !tbaa !29
  %t1241 = load i32, ptr %l16, !tbaa !23
  %t1242 = load i32, ptr %l46, !tbaa !23
  %t1243 = load i64, ptr %l6, !tbaa !24
  %t1244 = load i32, ptr %l46, !tbaa !23
  %t1246 = sext i32 %t1244 to i64
  %t1249 = add i64 %t1243, %t1246
  %t1250 = extractvalue { i64, ptr } { i64 5, ptr @.d132 }, 1
  %t1251 = extractvalue { i64, ptr } { i64 5, ptr @.d132 }, 0
  %t1253 = sext i32 %t1241 to i64
  %t1254 = call i64 @__olang_fmt_i64(ptr null, i64 %t1253)
  %t1255 = add i64 %t1251, %t1254
  %t1256 = extractvalue { i64, ptr } { i64 1, ptr @.d133 }, 1
  %t1257 = extractvalue { i64, ptr } { i64 1, ptr @.d133 }, 0
  %t1258 = add i64 %t1255, %t1257
  %t1260 = sext i32 %t1242 to i64
  %t1261 = call i64 @__olang_fmt_i64(ptr null, i64 %t1260)
  %t1262 = add i64 %t1258, %t1261
  %t1263 = extractvalue { i64, ptr } { i64 19, ptr @.d134 }, 1
  %t1264 = extractvalue { i64, ptr } { i64 19, ptr @.d134 }, 0
  %t1265 = add i64 %t1262, %t1264
  %t1267 = call i64 @__olang_fmt_i64(ptr null, i64 %t1249)
  %t1268 = add i64 %t1265, %t1267
  %t1269 = extractvalue { i64, ptr } { i64 1, ptr @.d135 }, 1
  %t1270 = extractvalue { i64, ptr } { i64 1, ptr @.d135 }, 0
  %t1271 = add i64 %t1268, %t1270
  %t1272 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t1271)
  call void @olang_textcopy(ptr %t1272, ptr %t1250, i64 %t1251)
  %t1273 = getelementptr i8, ptr %t1272, i64 %t1251
  %t1274 = call i64 @__olang_fmt_i64(ptr %t1273, i64 %t1253)
  %t1275 = getelementptr i8, ptr %t1273, i64 %t1254
  call void @olang_textcopy(ptr %t1275, ptr %t1256, i64 %t1257)
  %t1276 = getelementptr i8, ptr %t1275, i64 %t1257
  %t1277 = call i64 @__olang_fmt_i64(ptr %t1276, i64 %t1260)
  %t1278 = getelementptr i8, ptr %t1276, i64 %t1261
  call void @olang_textcopy(ptr %t1278, ptr %t1263, i64 %t1264)
  %t1279 = getelementptr i8, ptr %t1278, i64 %t1264
  %t1280 = call i64 @__olang_fmt_i64(ptr %t1279, i64 %t1249)
  %t1281 = getelementptr i8, ptr %t1279, i64 %t1267
  call void @olang_textcopy(ptr %t1281, ptr %t1269, i64 %t1270)
  %t1282 = insertvalue { i64, ptr } undef, i64 %t1271, 0
  %t1283 = insertvalue { i64, ptr } %t1282, ptr %t1272, 1
  %t1285 = extractvalue { i64, ptr } %t1283, 0
  %t1286 = extractvalue { i64, ptr } %t1283, 1
  %t1287 = mul i64 %t1285, 1
  %t1288 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t1287)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1288, ptr %t1286, i64 %t1287, i1 false)
  %t1289 = insertvalue { i64, ptr } undef, i64 %t1285, 0
  %t1290 = insertvalue { i64, ptr } %t1289, ptr %t1288, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s40, ptr %t1240, { i64, ptr } %t1290)
  br label %bb124
bb124:
  %t1293 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1293, ptr %l376, !tbaa !29
  %t1294 = load i32, ptr %l16, !tbaa !23
  store i32 %t1294, ptr %l377, !tbaa !23
  %t1295 = load i32, ptr %l46, !tbaa !23
  store i32 %t1295, ptr %l378, !tbaa !23
  %t1296 = load ptr, ptr %l7, !tbaa !29
  %t1297 = load i32, ptr %l30, !tbaa !23
  %t1300 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s40, ptr %t1296, i32 %t1297)
  store { i64, ptr } %t1300, ptr %l381
  br label %bb125
bb125:
  %t1301 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t1302 = load i32, ptr %l46, !tbaa !23
  %t1303 = extractvalue { i64, ptr } { i64 5, ptr @.d136 }, 1
  %t1304 = extractvalue { i64, ptr } { i64 5, ptr @.d136 }, 0
  %t1305 = load i32, ptr %l377, !tbaa !23
  %t1306 = sext i32 %t1305 to i64
  %t1307 = call i64 @__olang_fmt_i64(ptr null, i64 %t1306)
  %t1308 = add i64 %t1304, %t1307
  %t1309 = extractvalue { i64, ptr } { i64 1, ptr @.d137 }, 1
  %t1310 = extractvalue { i64, ptr } { i64 1, ptr @.d137 }, 0
  %t1311 = add i64 %t1308, %t1310
  %t1312 = load i32, ptr %l378, !tbaa !23
  %t1313 = sext i32 %t1312 to i64
  %t1314 = call i64 @__olang_fmt_i64(ptr null, i64 %t1313)
  %t1315 = add i64 %t1311, %t1314
  %t1316 = extractvalue { i64, ptr } { i64 16, ptr @.d138 }, 1
  %t1317 = extractvalue { i64, ptr } { i64 16, ptr @.d138 }, 0
  %t1318 = add i64 %t1315, %t1317
  %t1319 = load { i64, ptr }, ptr %l381, !tbaa !27
  %t1320 = extractvalue { i64, ptr } %t1319, 1
  %t1321 = extractvalue { i64, ptr } %t1319, 0
  %t1322 = add i64 %t1318, %t1321
  %t1323 = extractvalue { i64, ptr } { i64 1, ptr @.d139 }, 1
  %t1324 = extractvalue { i64, ptr } { i64 1, ptr @.d139 }, 0
  %t1325 = add i64 %t1322, %t1324
  %t1327 = extractvalue { i64, ptr } %t1301, 1
  %t1328 = extractvalue { i64, ptr } %t1301, 0
  %t1329 = add i64 %t1325, %t1328
  %t1330 = extractvalue { i64, ptr } { i64 2, ptr @.d140 }, 1
  %t1331 = extractvalue { i64, ptr } { i64 2, ptr @.d140 }, 0
  %t1332 = add i64 %t1329, %t1331
  %t1334 = sext i32 %t1302 to i64
  %t1335 = call i64 @__olang_fmt_i64(ptr null, i64 %t1334)
  %t1336 = add i64 %t1332, %t1335
  %t1337 = extractvalue { i64, ptr } { i64 1, ptr @.d141 }, 1
  %t1338 = extractvalue { i64, ptr } { i64 1, ptr @.d141 }, 0
  %t1339 = add i64 %t1336, %t1338
  %t1340 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t1339)
  call void @olang_textcopy(ptr %t1340, ptr %t1303, i64 %t1304)
  %t1341 = getelementptr i8, ptr %t1340, i64 %t1304
  %t1342 = call i64 @__olang_fmt_i64(ptr %t1341, i64 %t1306)
  %t1343 = getelementptr i8, ptr %t1341, i64 %t1307
  call void @olang_textcopy(ptr %t1343, ptr %t1309, i64 %t1310)
  %t1344 = getelementptr i8, ptr %t1343, i64 %t1310
  %t1345 = call i64 @__olang_fmt_i64(ptr %t1344, i64 %t1313)
  %t1346 = getelementptr i8, ptr %t1344, i64 %t1314
  call void @olang_textcopy(ptr %t1346, ptr %t1316, i64 %t1317)
  %t1347 = getelementptr i8, ptr %t1346, i64 %t1317
  call void @olang_textcopy(ptr %t1347, ptr %t1320, i64 %t1321)
  %t1348 = getelementptr i8, ptr %t1347, i64 %t1321
  call void @olang_textcopy(ptr %t1348, ptr %t1323, i64 %t1324)
  %t1349 = getelementptr i8, ptr %t1348, i64 %t1324
  call void @olang_textcopy(ptr %t1349, ptr %t1327, i64 %t1328)
  %t1350 = getelementptr i8, ptr %t1349, i64 %t1328
  call void @olang_textcopy(ptr %t1350, ptr %t1330, i64 %t1331)
  %t1351 = getelementptr i8, ptr %t1350, i64 %t1331
  %t1352 = call i64 @__olang_fmt_i64(ptr %t1351, i64 %t1334)
  %t1353 = getelementptr i8, ptr %t1351, i64 %t1335
  call void @olang_textcopy(ptr %t1353, ptr %t1337, i64 %t1338)
  %t1354 = insertvalue { i64, ptr } undef, i64 %t1339, 0
  %t1355 = insertvalue { i64, ptr } %t1354, ptr %t1340, 1
  %t1357 = extractvalue { i64, ptr } %t1355, 0
  %t1358 = extractvalue { i64, ptr } %t1355, 1
  %t1359 = mul i64 %t1357, 1
  %t1360 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t1359)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1360, ptr %t1358, i64 %t1359, i1 false)
  %t1361 = insertvalue { i64, ptr } undef, i64 %t1357, 0
  %t1362 = insertvalue { i64, ptr } %t1361, ptr %t1360, 1
  %t1363 = load ptr, ptr %l376, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s40, ptr %t1363, { i64, ptr } %t1362)
  br label %bb126
bb126:
  %t1365 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1365, ptr %l386, !tbaa !29
  %t1366 = load ptr, ptr %l7, !tbaa !29
  %t1367 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t1367, ptr %l388, !tbaa !27
  %t1368 = load i32, ptr %l46, !tbaa !23
  %t1370 = sext i32 %t1368 to i64
  %t1371 = getelementptr { i64, ptr }, ptr %l388, i32 0, i32 1
  %t1372 = load ptr, ptr %t1371, !tbaa !27
  %t1373 = getelementptr i32, ptr %t1372, i64 %t1370
  %t1374 = load i32, ptr %t1373, !tbaa !33
  %t1377 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s40, ptr %t1366, i32 %t1374)
  store { i64, ptr } %t1377, ptr %l391
  br label %bb127
bb127:
  %t1378 = load i32, ptr %l16, !tbaa !23
  %t1379 = load i32, ptr %l46, !tbaa !23
  %t1380 = load i32, ptr %l16, !tbaa !23
  %t1381 = load i32, ptr %l46, !tbaa !23
  %t1382 = extractvalue { i64, ptr } { i64 8, ptr @.d142 }, 1
  %t1383 = extractvalue { i64, ptr } { i64 8, ptr @.d142 }, 0
  %t1384 = load { i64, ptr }, ptr %l391, !tbaa !27
  %t1385 = extractvalue { i64, ptr } %t1384, 1
  %t1386 = extractvalue { i64, ptr } %t1384, 0
  %t1387 = add i64 %t1383, %t1386
  %t1388 = extractvalue { i64, ptr } { i64 4, ptr @.d143 }, 1
  %t1389 = extractvalue { i64, ptr } { i64 4, ptr @.d143 }, 0
  %t1390 = add i64 %t1387, %t1389
  %t1392 = sext i32 %t1378 to i64
  %t1393 = call i64 @__olang_fmt_i64(ptr null, i64 %t1392)
  %t1394 = add i64 %t1390, %t1393
  %t1395 = extractvalue { i64, ptr } { i64 1, ptr @.d144 }, 1
  %t1396 = extractvalue { i64, ptr } { i64 1, ptr @.d144 }, 0
  %t1397 = add i64 %t1394, %t1396
  %t1399 = sext i32 %t1379 to i64
  %t1400 = call i64 @__olang_fmt_i64(ptr null, i64 %t1399)
  %t1401 = add i64 %t1397, %t1400
  %t1402 = extractvalue { i64, ptr } { i64 9, ptr @.d145 }, 1
  %t1403 = extractvalue { i64, ptr } { i64 9, ptr @.d145 }, 0
  %t1404 = add i64 %t1401, %t1403
  %t1406 = sext i32 %t1380 to i64
  %t1407 = call i64 @__olang_fmt_i64(ptr null, i64 %t1406)
  %t1408 = add i64 %t1404, %t1407
  %t1409 = extractvalue { i64, ptr } { i64 1, ptr @.d146 }, 1
  %t1410 = extractvalue { i64, ptr } { i64 1, ptr @.d146 }, 0
  %t1411 = add i64 %t1408, %t1410
  %t1413 = sext i32 %t1381 to i64
  %t1414 = call i64 @__olang_fmt_i64(ptr null, i64 %t1413)
  %t1415 = add i64 %t1411, %t1414
  %t1416 = extractvalue { i64, ptr } { i64 1, ptr @.d147 }, 1
  %t1417 = extractvalue { i64, ptr } { i64 1, ptr @.d147 }, 0
  %t1418 = add i64 %t1415, %t1417
  %t1419 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t1418)
  call void @olang_textcopy(ptr %t1419, ptr %t1382, i64 %t1383)
  %t1420 = getelementptr i8, ptr %t1419, i64 %t1383
  call void @olang_textcopy(ptr %t1420, ptr %t1385, i64 %t1386)
  %t1421 = getelementptr i8, ptr %t1420, i64 %t1386
  call void @olang_textcopy(ptr %t1421, ptr %t1388, i64 %t1389)
  %t1422 = getelementptr i8, ptr %t1421, i64 %t1389
  %t1423 = call i64 @__olang_fmt_i64(ptr %t1422, i64 %t1392)
  %t1424 = getelementptr i8, ptr %t1422, i64 %t1393
  call void @olang_textcopy(ptr %t1424, ptr %t1395, i64 %t1396)
  %t1425 = getelementptr i8, ptr %t1424, i64 %t1396
  %t1426 = call i64 @__olang_fmt_i64(ptr %t1425, i64 %t1399)
  %t1427 = getelementptr i8, ptr %t1425, i64 %t1400
  call void @olang_textcopy(ptr %t1427, ptr %t1402, i64 %t1403)
  %t1428 = getelementptr i8, ptr %t1427, i64 %t1403
  %t1429 = call i64 @__olang_fmt_i64(ptr %t1428, i64 %t1406)
  %t1430 = getelementptr i8, ptr %t1428, i64 %t1407
  call void @olang_textcopy(ptr %t1430, ptr %t1409, i64 %t1410)
  %t1431 = getelementptr i8, ptr %t1430, i64 %t1410
  %t1432 = call i64 @__olang_fmt_i64(ptr %t1431, i64 %t1413)
  %t1433 = getelementptr i8, ptr %t1431, i64 %t1414
  call void @olang_textcopy(ptr %t1433, ptr %t1416, i64 %t1417)
  %t1434 = insertvalue { i64, ptr } undef, i64 %t1418, 0
  %t1435 = insertvalue { i64, ptr } %t1434, ptr %t1419, 1
  %t1437 = extractvalue { i64, ptr } %t1435, 0
  %t1438 = extractvalue { i64, ptr } %t1435, 1
  %t1439 = mul i64 %t1437, 1
  %t1440 = call ptr @__olang_scope_alloc(ptr %s40, i64 %t1439)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1440, ptr %t1438, i64 %t1439, i1 false)
  %t1441 = insertvalue { i64, ptr } undef, i64 %t1437, 0
  %t1442 = insertvalue { i64, ptr } %t1441, ptr %t1440, 1
  %t1443 = load ptr, ptr %l386, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s40, ptr %t1443, { i64, ptr } %t1442)
  br label %bb128
bb128:
  call void @__olang_scope_close(ptr %s40)
  br label %bb129
bb129:
  %t1445 = load i32, ptr %l45, !tbaa !23
  %t1447 = add i32 %t1445, 1
  store i32 %t1447, ptr %l45, !tbaa !23
  br label %bb120
bb130:
  br label %bb131
bb131:
  br label %bb132
bb132:
  %t1449 = load i64, ptr %l10, !tbaa !24
  %t1451 = add i64 %t1449, 1
  store i64 %t1451, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s15)
  br label %bb133
bb133:
  %t1453 = load ptr, ptr %l1, !tbaa !29
  %t1454 = load i32, ptr %l16, !tbaa !23
  %t1455 = extractvalue { i64, ptr } { i64 19, ptr @.d148 }, 1
  %t1456 = extractvalue { i64, ptr } { i64 19, ptr @.d148 }, 0
  %t1458 = sext i32 %t1454 to i64
  %t1459 = call i64 @__olang_fmt_i64(ptr null, i64 %t1458)
  %t1460 = add i64 %t1456, %t1459
  %t1461 = extractvalue { i64, ptr } { i64 2, ptr @.d149 }, 1
  %t1462 = extractvalue { i64, ptr } { i64 2, ptr @.d149 }, 0
  %t1463 = add i64 %t1460, %t1462
  %t1464 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t1463)
  call void @olang_textcopy(ptr %t1464, ptr %t1455, i64 %t1456)
  %t1465 = getelementptr i8, ptr %t1464, i64 %t1456
  %t1466 = call i64 @__olang_fmt_i64(ptr %t1465, i64 %t1458)
  %t1467 = getelementptr i8, ptr %t1465, i64 %t1459
  call void @olang_textcopy(ptr %t1467, ptr %t1461, i64 %t1462)
  %t1468 = insertvalue { i64, ptr } undef, i64 %t1463, 0
  %t1469 = insertvalue { i64, ptr } %t1468, ptr %t1464, 1
  %t1471 = extractvalue { i64, ptr } %t1469, 0
  %t1472 = extractvalue { i64, ptr } %t1469, 1
  %t1473 = mul i64 %t1471, 1
  %t1474 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t1473)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1474, ptr %t1472, i64 %t1473, i1 false)
  %t1475 = insertvalue { i64, ptr } undef, i64 %t1471, 0
  %t1476 = insertvalue { i64, ptr } %t1475, ptr %t1474, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t1453, { i64, ptr } %t1476)
  br label %bb134
bb134:
  call void @__olang_scope_close(ptr %s2)
  br label %bb135
bb135:
  %t1479 = load i32, ptr %l15, !tbaa !23
  %t1481 = add i32 %t1479, 1
  store i32 %t1481, ptr %l15, !tbaa !23
  br label %bb8
bb136:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ecopyArray(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [1 x i64] } %a1, { i64, ptr } %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t6 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %v2, ptr %t2, { i64, [1 x i64] } %a1)
  store { i64, ptr } %t6, ptr %l7
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  %t9 = extractvalue { i64, ptr } %t7, 1
  %t10 = mul i64 %t8, 1
  %t11 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t10)
  call void @llvm.memcpy.p0.p0.i64(ptr %t11, ptr %t9, i64 %t10, i1 false)
  %t12 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t20 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ecopyArrayIn(ptr %v0, ptr %v2, ptr %v1, ptr %v2, ptr %t16, { i64, ptr } %t13, { i64, ptr } %a2, i32 %a3)
  store { i64, ptr } %t20, ptr %l11
  br label %bb2
bb2:
  %t21 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t21, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edataPtr(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Place" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { { i64, ptr }, i32 }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i32
  %l8 = alloca { { i64, ptr }, i32 }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l15 = alloca i32
  %l19 = alloca i1
  %l22 = alloca i1
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s0, ptr %t1, %"compiler/mir:Place" %a1)
  store { { i64, ptr }, i32 } %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load { { i64, ptr }, i32 }, ptr %l8
  store { { i64, ptr }, i32 } %t6, ptr %l2
  %t7 = getelementptr { { i64, ptr }, i32 }, ptr %l2, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l9, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l10, !tbaa !24
  %t11 = load i64, ptr %l10, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l11, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = load i64, ptr %l10, !tbaa !24
  %t21 = mul i64 %t20, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %t19, i64 %t21, i1 false)
  %t22 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t22, ptr %l3, !tbaa !27
  %t23 = getelementptr { { i64, ptr }, i32 }, ptr %l2, i32 0, i32 1
  %t24 = load i32, ptr %t23, !tbaa !23
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t30 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %t26, i32 %t24)
  store i32 %t30, ptr %l15
  br label %bb2
bb2:
  %t31 = load i32, ptr %l15, !tbaa !23
  store i32 %t31, ptr %l5, !tbaa !23
  %t32 = load i32, ptr %l5, !tbaa !23
  %t33 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t36 = icmp ne i32 %t32, %t33
  br i1 %t36, label %bb3, label %bb4
bb3:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i32, ptr %l5, !tbaa !23
  %t42 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixed(ptr %v0, ptr %t38, i32 %t39)
  store i1 %t42, ptr %l22
  br label %bb5
bb4:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb6
bb5:
  %t43 = load i1, ptr %l22, !tbaa !21
  store i1 %t43, ptr %l19, !tbaa !21
  br label %bb6
bb6:
  %t44 = load i1, ptr %l19, !tbaa !21
  br i1 %t44, label %bb7, label %bb8
bb7:
  %t45 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t45, ptr %l23, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 0
  store i64 %t47, ptr %l24, !tbaa !24
  %t48 = load i64, ptr %l24, !tbaa !24
  %t49 = mul i64 %t48, 1
  %t50 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t49)
  %t51 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  store { i64, ptr } %t52, ptr %l25, !tbaa !27
  %t53 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = load i64, ptr %l24, !tbaa !24
  %t58 = mul i64 %t57, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t54, ptr %t56, i64 %t58, i1 false)
  %t59 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t59, ptr %l23, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t60 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t60, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l26, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t64 = extractvalue { i64, ptr } { i64 32, ptr @.d150 }, 1
  %t65 = extractvalue { i64, ptr } { i64 32, ptr @.d150 }, 0
  %t67 = extractvalue { i64, ptr } %t63, 1
  %t68 = extractvalue { i64, ptr } %t63, 0
  %t69 = add i64 %t65, %t68
  %t70 = extractvalue { i64, ptr } { i64 14, ptr @.d151 }, 1
  %t71 = extractvalue { i64, ptr } { i64 14, ptr @.d151 }, 0
  %t72 = add i64 %t69, %t71
  %t73 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t72)
  call void @olang_textcopy(ptr %t73, ptr %t64, i64 %t65)
  %t74 = getelementptr i8, ptr %t73, i64 %t65
  call void @olang_textcopy(ptr %t74, ptr %t67, i64 %t68)
  %t75 = getelementptr i8, ptr %t74, i64 %t68
  call void @olang_textcopy(ptr %t75, ptr %t70, i64 %t71)
  %t76 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t73, 1
  %t79 = extractvalue { i64, ptr } %t77, 0
  %t80 = extractvalue { i64, ptr } %t77, 1
  %t81 = mul i64 %t79, 1
  %t82 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t81)
  call void @llvm.memcpy.p0.p0.i64(ptr %t82, ptr %t80, i64 %t81, i1 false)
  %t83 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  %t87 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t62, { i64, ptr } %t84)
  store { i64, ptr } %t87, ptr %l31
  br label %bb10
bb10:
  %t88 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t88, 0
  %t90 = extractvalue { i64, ptr } %t88, 1
  %t91 = mul i64 %t89, 1
  %t92 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t91)
  call void @llvm.memcpy.p0.p0.i64(ptr %t92, ptr %t90, i64 %t91, i1 false)
  %t93 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/emit:fnEm", ptr %t95, i32 0, i32 14
  %t98 = load { i64, ptr }, ptr %t97, !tbaa !27
  %t99 = load ptr, ptr %l26, !tbaa !29
  %t102 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %v1, ptr %v1, ptr %v0, ptr %v1, ptr %t99, { i64, ptr } { i64 3, ptr @.d152 }, { i64, ptr } %t94, { i64, ptr } %t98)
  store { i64, ptr } %t102, ptr %l35
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t103 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t103, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2edirectRef(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1) #0 {
entry:
  %l1 = alloca { i64, [1 x i64] }
  %l2 = alloca i32
  %l3 = alloca i1
  %l11 = alloca i1
  %rv = alloca i1
  store { i64, [1 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [1 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [1 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [1 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t12 = getelementptr %"compiler/emit:fnEm", ptr %a0, i32 0, i32 23
  %t13 = load i32, ptr %l2, !tbaa !23
  %t15 = sext i32 %t13 to i64
  %t18 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t12, i64 %t15)
  store i1 %t18, ptr %l11
  br label %bb4
bb4:
  %t19 = load i1, ptr %l11, !tbaa !21
  store i1 %t19, ptr %l3, !tbaa !21
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_2b2f6fb90634cfa0_5bc60e788a752af4)
  unreachable
bb10:
  %t20 = load i1, ptr %l3, !tbaa !21
  store i1 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edirectText(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, [4 x i64] }
  %l13 = alloca i32
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l16 = alloca { { i64, ptr }, { i64, ptr } }
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i32
  %l30 = alloca i64
  %l31 = alloca i64
  %l35 = alloca i64
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %l47 = alloca i64
  %l50 = alloca i64
  %l71 = alloca { i64, [4 x i64] }
  %l74 = alloca i32
  %l78 = alloca { i64, ptr }
  %l82 = alloca i32
  %l88 = alloca { { i64, ptr }, { i64, ptr } }
  %l89 = alloca { i64, ptr }
  %l90 = alloca i64
  %l91 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l93 = alloca i64
  %l94 = alloca { i64, ptr }
  %l114 = alloca i64
  %l115 = alloca ptr
  %l116 = alloca { i64, ptr }
  %l119 = alloca { i64, ptr }
  %l122 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l128 = alloca i64
  %l133 = alloca { i64, ptr }
  %l138 = alloca i64
  %l142 = alloca { i64, ptr }
  %l147 = alloca i64
  %l153 = alloca { i64, ptr }
  %l156 = alloca i64
  %l160 = alloca { i64, ptr }
  %l165 = alloca i64
  %l171 = alloca { i64, ptr }
  %l176 = alloca { i64, ptr }
  %l186 = alloca { i64, ptr }
  %l188 = alloca i64
  %l194 = alloca ptr
  %l197 = alloca { i64, ptr }
  %l201 = alloca { i64, ptr }
  %l202 = alloca { i64, ptr }
  %l203 = alloca i64
  %l204 = alloca { i64, ptr }
  %l209 = alloca i64
  %l212 = alloca i64
  %l233 = alloca i32
  %l248 = alloca { i64, ptr }
  %l257 = alloca { i64, ptr }
  %l278 = alloca { i64, ptr }
  %l280 = alloca i64
  %l287 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t17 = alloca i64
  %t38 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 26
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e_2eLen_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l30
  br label %bb1
bb1:
  %t6 = load i64, ptr %l30, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  store i64 %t7, ptr %l31, !tbaa !24
  %t8 = load i64, ptr %l31, !tbaa !24
  %t9 = icmp sge i64 %t8, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l31, !tbaa !24
  %t12 = icmp sle i64 %t11, 576460752303423487
  br i1 %t12, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_cf8290f43b8cf4bf_3d9bfdc06546f1cb)
  unreachable
bb4:
  %t14 = load i64, ptr %l31, !tbaa !24
  %t15 = mul i64 %t14, 16
  %t16 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t15)
  store i64 0, ptr %t17
  br label %fill.18
fill.18:
  %t21 = load i64, ptr %t17
  %t22 = icmp slt i64 %t21, %t14
  br i1 %t22, label %fillb.19, label %filld.20
fillb.19:
  %t23 = getelementptr { i64, ptr }, ptr %t16, i64 %t21
  store { i64, ptr } { i64 0, ptr @.d153 }, ptr %t23
  %t24 = add i64 %t21, 1
  store i64 %t24, ptr %t17
  br label %fill.18
filld.20:
  %t25 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t16, 1
  store { i64, ptr } %t26, ptr %l3, !tbaa !27
  %t28 = load i64, ptr %l2, !tbaa !24
  store i64 %t28, ptr %l35, !tbaa !24
  %t29 = load i64, ptr %l35, !tbaa !24
  %t30 = icmp sge i64 %t29, 0
  br i1 %t30, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_cf8290f43b8cf4bf_3d9bfdc06546f1cb)
  unreachable
bb6:
  %t32 = load i64, ptr %l35, !tbaa !24
  %t33 = icmp sle i64 %t32, 576460752303423487
  br i1 %t33, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_1966eb58572a69ea_7a4114e6fad4d136)
  unreachable
bb8:
  %t35 = load i64, ptr %l35, !tbaa !24
  %t36 = mul i64 %t35, 16
  %t37 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t36)
  store i64 0, ptr %t38
  br label %fill.39
fill.39:
  %t42 = load i64, ptr %t38
  %t43 = icmp slt i64 %t42, %t35
  br i1 %t43, label %fillb.40, label %filld.41
fillb.40:
  %t44 = getelementptr { i64, ptr }, ptr %t37, i64 %t42
  store { i64, ptr } { i64 0, ptr @.d154 }, ptr %t44
  %t45 = add i64 %t42, 1
  store i64 %t45, ptr %t38
  br label %fill.39
filld.41:
  %t46 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t37, 1
  store { i64, ptr } %t47, ptr %l4, !tbaa !27
  store { i64, ptr } { i64 1, ptr @.d155 }, ptr %l39, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t49, ptr %l40, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t50, 0
  store i64 %t51, ptr %l41, !tbaa !24
  %t52 = load i64, ptr %l41, !tbaa !24
  %t53 = mul i64 %t52, 1
  %t54 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t53)
  %t55 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t54, 1
  store { i64, ptr } %t56, ptr %l42, !tbaa !27
  %t57 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = load i64, ptr %l41, !tbaa !24
  %t62 = mul i64 %t61, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t58, ptr %t60, i64 %t62, i1 false)
  %t63 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t63, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t64 = load i64, ptr %l2, !tbaa !24
  store i64 %t64, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t66 = load i64, ptr %l7, !tbaa !24
  %t67 = load i64, ptr %l6, !tbaa !24
  %t70 = icmp sgt i64 %t66, %t67
  br i1 %t70, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_1966eb58572a69ea_7a4114e6fad4d136)
  unreachable
bb10:
  %t72 = load i64, ptr %l8, !tbaa !24
  %t74 = icmp sgt i64 %t72, 0
  br i1 %t74, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb15
bb12:
  %t76 = load i64, ptr %l7, !tbaa !24
  %t77 = load i64, ptr %l6, !tbaa !24
  %t80 = sub i64 %t76, %t77
  %t81 = load i64, ptr %l8, !tbaa !24
  %t84 = add i64 %t80, %t81
  %t86 = sub i64 %t84, 1
  %t87 = load i64, ptr %l8, !tbaa !24
  %t90 = sdiv i64 %t86, %t87
  store i64 %t90, ptr %l50, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l50, !tbaa !24
  br label %bb14
bb14:
  %t92 = load i64, ptr %l50, !tbaa !24
  store i64 %t92, ptr %l47, !tbaa !24
  br label %bb15
bb15:
  %t93 = load i64, ptr %l47, !tbaa !24
  store i64 %t93, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s2
  %t94 = load i64, ptr %l10, !tbaa !24
  %t95 = load i64, ptr %l9, !tbaa !24
  %t98 = icmp slt i64 %t94, %t95
  %t100 = xor i1 %t98, true
  br i1 %t100, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb64
bb18:
  br label %bb19
bb19:
  %t102 = load i64, ptr %l6, !tbaa !24
  %t103 = load i64, ptr %l10, !tbaa !24
  %t104 = load i64, ptr %l8, !tbaa !24
  %t107 = mul i64 %t103, %t104
  %t110 = add i64 %t102, %t107
  store i64 %t110, ptr %l11, !tbaa !24
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/emit:fnEm", ptr %t112, i32 0, i32 26
  %t115 = load i64, ptr %l11, !tbaa !24
  %t118 = call { i64, [4 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t114, i64 %t115)
  store { i64, [4 x i64] } %t118, ptr %l71
  br label %bb20
bb20:
  %t119 = load { i64, [4 x i64] }, ptr %l71
  store { i64, [4 x i64] } %t119, ptr %l12
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load { i64, [4 x i64] }, ptr %l12
  %t124 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t120, { i64, [4 x i64] } %t121)
  store i32 %t124, ptr %l74
  br label %bb21
bb21:
  %t125 = load i32, ptr %l74, !tbaa !23
  store i32 %t125, ptr %l13, !tbaa !23
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load { i64, [4 x i64] }, ptr %l12
  %t128 = load i32, ptr %l13, !tbaa !23
  %t132 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s2, ptr %t126, { i64, [4 x i64] } %t127, i32 %t128)
  store { i64, ptr } %t132, ptr %l78
  br label %bb22
bb22:
  %t133 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t133, ptr %l14, !tbaa !27
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/emit:fnEm", ptr %t134, i32 0, i32 25
  %t137 = load i64, ptr %l11, !tbaa !24
  %t140 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aWriteKind_3e_2eAt_3ccompiler_2fmir_3aWriteKind_3e(ptr %v0, ptr %t136, i64 %t137)
  store i32 %t140, ptr %l82
  br label %bb23
bb23:
  %t141 = load i32, ptr %l82
  store i32 %t141, ptr %l15
  %t142 = load i32, ptr %l15
  %t144 = trunc i64 0 to i32
  %t145 = icmp eq i32 %t142, %t144
  br i1 %t145, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb28
bb26:
  store %olang.scope zeroinitializer, ptr %s3
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t149 = load i32, ptr %l13, !tbaa !23
  %t153 = call { { i64, ptr }, { i64, ptr } } @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayParts(ptr %v0, ptr %s2, ptr %s3, ptr %t147, { i64, ptr } %t148, i32 %t149)
  store { { i64, ptr }, { i64, ptr } } %t153, ptr %l88
  br label %bb27
bb27:
  %t154 = load { { i64, ptr }, { i64, ptr } }, ptr %l88
  store { { i64, ptr }, { i64, ptr } } %t154, ptr %l16
  %t155 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l16, i32 0, i32 0
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  store { i64, ptr } %t156, ptr %l89, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t157, 0
  store i64 %t158, ptr %l90, !tbaa !24
  %t159 = load i64, ptr %l90, !tbaa !24
  %t160 = mul i64 %t159, 1
  %t161 = call ptr @__olang_scope_alloc_zeroed(ptr %s3, i64 %t160)
  %t162 = insertvalue { i64, ptr } undef, i64 %t159, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t161, 1
  store { i64, ptr } %t163, ptr %l91, !tbaa !27
  %t164 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !27
  %t166 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = load i64, ptr %l90, !tbaa !24
  %t169 = mul i64 %t168, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t165, ptr %t167, i64 %t169, i1 false)
  %t170 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t171 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l16, i32 0, i32 1
  %t172 = load { i64, ptr }, ptr %t171, !tbaa !27
  store { i64, ptr } %t172, ptr %l92, !tbaa !27
  %t173 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t174 = extractvalue { i64, ptr } %t173, 0
  store i64 %t174, ptr %l93, !tbaa !24
  %t175 = load i64, ptr %l93, !tbaa !24
  %t176 = mul i64 %t175, 1
  %t177 = call ptr @__olang_scope_alloc_zeroed(ptr %s3, i64 %t176)
  %t178 = insertvalue { i64, ptr } undef, i64 %t175, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %t177, 1
  store { i64, ptr } %t179, ptr %l94, !tbaa !27
  %t180 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !27
  %t182 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !27
  %t184 = load i64, ptr %l93, !tbaa !24
  %t185 = mul i64 %t184, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t181, ptr %t183, i64 %t185, i1 false)
  %t186 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t187 = load i64, ptr %l11, !tbaa !24
  %t190 = extractvalue { i64, ptr } %t170, 1
  %t191 = extractvalue { i64, ptr } %t170, 0
  %t192 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t191)
  call void @olang_textcopy(ptr %t192, ptr %t190, i64 %t191)
  %t193 = insertvalue { i64, ptr } undef, i64 %t191, 0
  %t194 = insertvalue { i64, ptr } %t193, ptr %t192, 1
  %t196 = extractvalue { i64, ptr } %t194, 0
  %t197 = extractvalue { i64, ptr } %t194, 1
  %t198 = mul i64 %t196, 1
  %t199 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t198)
  call void @llvm.memcpy.p0.p0.i64(ptr %t199, ptr %t197, i64 %t198, i1 false)
  %t200 = insertvalue { i64, ptr } undef, i64 %t196, 0
  %t201 = insertvalue { i64, ptr } %t200, ptr %t199, 1
  %t204 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !27
  %t206 = getelementptr { i64, ptr }, ptr %t205, i64 %t187
  store { i64, ptr } %t201, ptr %t206, !tbaa !37
  %t207 = load i64, ptr %l11, !tbaa !24
  %t210 = extractvalue { i64, ptr } %t186, 1
  %t211 = extractvalue { i64, ptr } %t186, 0
  %t212 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t211)
  call void @olang_textcopy(ptr %t212, ptr %t210, i64 %t211)
  %t213 = insertvalue { i64, ptr } undef, i64 %t211, 0
  %t214 = insertvalue { i64, ptr } %t213, ptr %t212, 1
  %t216 = extractvalue { i64, ptr } %t214, 0
  %t217 = extractvalue { i64, ptr } %t214, 1
  %t218 = mul i64 %t216, 1
  %t219 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t218)
  call void @llvm.memcpy.p0.p0.i64(ptr %t219, ptr %t217, i64 %t218, i1 false)
  %t220 = insertvalue { i64, ptr } undef, i64 %t216, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr %t219, 1
  %t224 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !27
  %t226 = getelementptr { i64, ptr }, ptr %t225, i64 %t207
  store { i64, ptr } %t221, ptr %t226, !tbaa !37
  call void @__olang_scope_close(ptr %s3)
  br label %bb55
bb28:
  %t227 = load i32, ptr %l15
  %t229 = trunc i64 2 to i32
  %t230 = icmp eq i32 %t227, %t229
  br i1 %t230, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  %t232 = load i64, ptr %l11, !tbaa !24
  %t233 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t235 = extractvalue { i64, ptr } %t233, 1
  %t236 = extractvalue { i64, ptr } %t233, 0
  %t237 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t236)
  call void @olang_textcopy(ptr %t237, ptr %t235, i64 %t236)
  %t238 = insertvalue { i64, ptr } undef, i64 %t236, 0
  %t239 = insertvalue { i64, ptr } %t238, ptr %t237, 1
  %t241 = extractvalue { i64, ptr } %t239, 0
  %t242 = extractvalue { i64, ptr } %t239, 1
  %t243 = mul i64 %t241, 1
  %t244 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t243)
  call void @llvm.memcpy.p0.p0.i64(ptr %t244, ptr %t242, i64 %t243, i1 false)
  %t245 = insertvalue { i64, ptr } undef, i64 %t241, 0
  %t246 = insertvalue { i64, ptr } %t245, ptr %t244, 1
  %t249 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !27
  %t251 = getelementptr { i64, ptr }, ptr %t250, i64 %t232
  store { i64, ptr } %t246, ptr %t251, !tbaa !37
  %t252 = load i64, ptr %l11, !tbaa !24
  %t253 = extractvalue { i64, ptr } { i64 1, ptr @.d156 }, 1
  %t254 = extractvalue { i64, ptr } { i64 1, ptr @.d156 }, 0
  %t255 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t254)
  call void @olang_textcopy(ptr %t255, ptr %t253, i64 %t254)
  %t256 = insertvalue { i64, ptr } undef, i64 %t254, 0
  %t257 = insertvalue { i64, ptr } %t256, ptr %t255, 1
  %t259 = extractvalue { i64, ptr } %t257, 0
  %t260 = extractvalue { i64, ptr } %t257, 1
  %t261 = mul i64 %t259, 1
  %t262 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t261)
  call void @llvm.memcpy.p0.p0.i64(ptr %t262, ptr %t260, i64 %t261, i1 false)
  %t263 = insertvalue { i64, ptr } undef, i64 %t259, 0
  %t264 = insertvalue { i64, ptr } %t263, ptr %t262, 1
  %t267 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t268 = load ptr, ptr %t267, !tbaa !27
  %t269 = getelementptr { i64, ptr }, ptr %t268, i64 %t252
  store { i64, ptr } %t264, ptr %t269, !tbaa !37
  br label %bb55
bb32:
  %t270 = load i32, ptr %l15
  %t272 = trunc i64 7 to i32
  %t273 = icmp eq i32 %t270, %t272
  br i1 %t273, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb40
bb35:
  store %olang.scope zeroinitializer, ptr %s9
  %t275 = load i64, ptr %l11, !tbaa !24
  store i64 %t275, ptr %l114, !tbaa !24
  %t276 = load ptr, ptr %l0, !tbaa !29
  store ptr %t276, ptr %l115, !tbaa !29
  %t277 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t277, ptr %l116, !tbaa !27
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr %"compiler/emit:fnEm", ptr %t278, i32 0, i32 0
  %t281 = load ptr, ptr %t280, !tbaa !29
  %t283 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %s9, ptr %s9, ptr %t281, { i64, ptr } { i64 4, ptr @.d157 })
  store { i64, ptr } %t283, ptr %l119
  br label %bb36
bb36:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t286 = getelementptr %"compiler/emit:fnEm", ptr %t284, i32 0, i32 0
  %t287 = load ptr, ptr %t286, !tbaa !29
  %t289 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %s9, ptr %s9, ptr %t287, { i64, ptr } { i64 5, ptr @.d158 })
  store { i64, ptr } %t289, ptr %l122
  br label %bb37
bb37:
  %t290 = extractvalue { i64, ptr } { i64 10, ptr @.d159 }, 1
  %t291 = extractvalue { i64, ptr } { i64 10, ptr @.d159 }, 0
  %t292 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t293 = extractvalue { i64, ptr } %t292, 1
  %t294 = extractvalue { i64, ptr } %t292, 0
  %t295 = add i64 %t291, %t294
  %t296 = extractvalue { i64, ptr } { i64 6, ptr @.d160 }, 1
  %t297 = extractvalue { i64, ptr } { i64 6, ptr @.d160 }, 0
  %t298 = add i64 %t295, %t297
  %t299 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t300 = extractvalue { i64, ptr } %t299, 1
  %t301 = extractvalue { i64, ptr } %t299, 0
  %t302 = add i64 %t298, %t301
  %t303 = extractvalue { i64, ptr } { i64 6, ptr @.d161 }, 1
  %t304 = extractvalue { i64, ptr } { i64 6, ptr @.d161 }, 0
  %t305 = add i64 %t302, %t304
  %t306 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t307 = extractvalue { i64, ptr } %t306, 1
  %t308 = extractvalue { i64, ptr } %t306, 0
  %t309 = add i64 %t305, %t308
  %t310 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t309)
  call void @olang_textcopy(ptr %t310, ptr %t290, i64 %t291)
  %t311 = getelementptr i8, ptr %t310, i64 %t291
  call void @olang_textcopy(ptr %t311, ptr %t293, i64 %t294)
  %t312 = getelementptr i8, ptr %t311, i64 %t294
  call void @olang_textcopy(ptr %t312, ptr %t296, i64 %t297)
  %t313 = getelementptr i8, ptr %t312, i64 %t297
  call void @olang_textcopy(ptr %t313, ptr %t300, i64 %t301)
  %t314 = getelementptr i8, ptr %t313, i64 %t301
  call void @olang_textcopy(ptr %t314, ptr %t303, i64 %t304)
  %t315 = getelementptr i8, ptr %t314, i64 %t304
  call void @olang_textcopy(ptr %t315, ptr %t307, i64 %t308)
  %t316 = insertvalue { i64, ptr } undef, i64 %t309, 0
  %t317 = insertvalue { i64, ptr } %t316, ptr %t310, 1
  %t319 = extractvalue { i64, ptr } %t317, 0
  %t320 = extractvalue { i64, ptr } %t317, 1
  %t321 = mul i64 %t319, 1
  %t322 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t321)
  call void @llvm.memcpy.p0.p0.i64(ptr %t322, ptr %t320, i64 %t321, i1 false)
  %t323 = insertvalue { i64, ptr } undef, i64 %t319, 0
  %t324 = insertvalue { i64, ptr } %t323, ptr %t322, 1
  %t325 = load ptr, ptr %l115, !tbaa !29
  %t327 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s9, ptr %s9, ptr %t325, { i64, ptr } %t324)
  store { i64, ptr } %t327, ptr %l125
  br label %bb38
bb38:
  %t328 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t329 = extractvalue { i64, ptr } %t328, 1
  %t330 = extractvalue { i64, ptr } %t328, 0
  %t331 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t330)
  call void @olang_textcopy(ptr %t331, ptr %t329, i64 %t330)
  %t332 = insertvalue { i64, ptr } undef, i64 %t330, 0
  %t333 = insertvalue { i64, ptr } %t332, ptr %t331, 1
  %t335 = extractvalue { i64, ptr } %t333, 0
  %t336 = extractvalue { i64, ptr } %t333, 1
  %t337 = mul i64 %t335, 1
  %t338 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t337)
  call void @llvm.memcpy.p0.p0.i64(ptr %t338, ptr %t336, i64 %t337, i1 false)
  %t339 = insertvalue { i64, ptr } undef, i64 %t335, 0
  %t340 = insertvalue { i64, ptr } %t339, ptr %t338, 1
  %t342 = load i64, ptr %l114, !tbaa !24
  %t343 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t344 = load ptr, ptr %t343, !tbaa !27
  %t345 = getelementptr { i64, ptr }, ptr %t344, i64 %t342
  store { i64, ptr } %t340, ptr %t345, !tbaa !37
  %t346 = load i64, ptr %l11, !tbaa !24
  store i64 %t346, ptr %l128, !tbaa !24
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t348 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t349 = extractvalue { i64, ptr } { i64 10, ptr @.d162 }, 1
  %t350 = extractvalue { i64, ptr } { i64 10, ptr @.d162 }, 0
  %t352 = extractvalue { i64, ptr } %t348, 1
  %t353 = extractvalue { i64, ptr } %t348, 0
  %t354 = add i64 %t350, %t353
  %t355 = extractvalue { i64, ptr } { i64 14, ptr @.d163 }, 1
  %t356 = extractvalue { i64, ptr } { i64 14, ptr @.d163 }, 0
  %t357 = add i64 %t354, %t356
  %t358 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t357)
  call void @olang_textcopy(ptr %t358, ptr %t349, i64 %t350)
  %t359 = getelementptr i8, ptr %t358, i64 %t350
  call void @olang_textcopy(ptr %t359, ptr %t352, i64 %t353)
  %t360 = getelementptr i8, ptr %t359, i64 %t353
  call void @olang_textcopy(ptr %t360, ptr %t355, i64 %t356)
  %t361 = insertvalue { i64, ptr } undef, i64 %t357, 0
  %t362 = insertvalue { i64, ptr } %t361, ptr %t358, 1
  %t364 = extractvalue { i64, ptr } %t362, 0
  %t365 = extractvalue { i64, ptr } %t362, 1
  %t366 = mul i64 %t364, 1
  %t367 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t366)
  call void @llvm.memcpy.p0.p0.i64(ptr %t367, ptr %t365, i64 %t366, i1 false)
  %t368 = insertvalue { i64, ptr } undef, i64 %t364, 0
  %t369 = insertvalue { i64, ptr } %t368, ptr %t367, 1
  %t372 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s9, ptr %s9, ptr %t347, { i64, ptr } %t369)
  store { i64, ptr } %t372, ptr %l133
  br label %bb39
bb39:
  %t373 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t374 = extractvalue { i64, ptr } %t373, 1
  %t375 = extractvalue { i64, ptr } %t373, 0
  %t376 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t375)
  call void @olang_textcopy(ptr %t376, ptr %t374, i64 %t375)
  %t377 = insertvalue { i64, ptr } undef, i64 %t375, 0
  %t378 = insertvalue { i64, ptr } %t377, ptr %t376, 1
  %t380 = extractvalue { i64, ptr } %t378, 0
  %t381 = extractvalue { i64, ptr } %t378, 1
  %t382 = mul i64 %t380, 1
  %t383 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t382)
  call void @llvm.memcpy.p0.p0.i64(ptr %t383, ptr %t381, i64 %t382, i1 false)
  %t384 = insertvalue { i64, ptr } undef, i64 %t380, 0
  %t385 = insertvalue { i64, ptr } %t384, ptr %t383, 1
  %t387 = load i64, ptr %l128, !tbaa !24
  %t388 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t389 = load ptr, ptr %t388, !tbaa !27
  %t390 = getelementptr { i64, ptr }, ptr %t389, i64 %t387
  store { i64, ptr } %t385, ptr %t390, !tbaa !37
  call void @__olang_scope_close(ptr %s9)
  br label %bb55
bb40:
  %t391 = load i32, ptr %l15
  %t393 = trunc i64 5 to i32
  %t394 = icmp eq i32 %t391, %t393
  br i1 %t394, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb47
bb43:
  store %olang.scope zeroinitializer, ptr %s14
  %t396 = load i64, ptr %l11, !tbaa !24
  store i64 %t396, ptr %l138, !tbaa !24
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t398 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t399 = load i32, ptr %l13, !tbaa !23
  %t403 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ezext64(ptr %v0, ptr %s2, ptr %s14, ptr %t397, { i64, ptr } %t398, i32 %t399)
  store { i64, ptr } %t403, ptr %l142
  br label %bb44
bb44:
  %t404 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t405 = extractvalue { i64, ptr } %t404, 1
  %t406 = extractvalue { i64, ptr } %t404, 0
  %t407 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t406)
  call void @olang_textcopy(ptr %t407, ptr %t405, i64 %t406)
  %t408 = insertvalue { i64, ptr } undef, i64 %t406, 0
  %t409 = insertvalue { i64, ptr } %t408, ptr %t407, 1
  %t411 = extractvalue { i64, ptr } %t409, 0
  %t412 = extractvalue { i64, ptr } %t409, 1
  %t413 = mul i64 %t411, 1
  %t414 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t413)
  call void @llvm.memcpy.p0.p0.i64(ptr %t414, ptr %t412, i64 %t413, i1 false)
  %t415 = insertvalue { i64, ptr } undef, i64 %t411, 0
  %t416 = insertvalue { i64, ptr } %t415, ptr %t414, 1
  %t418 = load i64, ptr %l138, !tbaa !24
  %t419 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t420 = load ptr, ptr %t419, !tbaa !27
  %t421 = getelementptr { i64, ptr }, ptr %t420, i64 %t418
  store { i64, ptr } %t416, ptr %t421, !tbaa !37
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t424 = getelementptr %"compiler/emit:fnEm", ptr %t422, i32 0, i32 0
  %t425 = load ptr, ptr %t424, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s14, ptr %t425, { i64, ptr } { i64 15, ptr @.d164 })
  br label %bb45
bb45:
  %t427 = load i64, ptr %l11, !tbaa !24
  store i64 %t427, ptr %l147, !tbaa !24
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t429 = load i64, ptr %l11, !tbaa !24
  %t431 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t432 = load ptr, ptr %t431, !tbaa !27
  %t433 = getelementptr { i64, ptr }, ptr %t432, i64 %t429
  %t434 = load { i64, ptr }, ptr %t433, !tbaa !37
  %t435 = extractvalue { i64, ptr } { i64 40, ptr @.d165 }, 1
  %t436 = extractvalue { i64, ptr } { i64 40, ptr @.d165 }, 0
  %t438 = extractvalue { i64, ptr } %t434, 1
  %t439 = extractvalue { i64, ptr } %t434, 0
  %t440 = add i64 %t436, %t439
  %t441 = extractvalue { i64, ptr } { i64 1, ptr @.d166 }, 1
  %t442 = extractvalue { i64, ptr } { i64 1, ptr @.d166 }, 0
  %t443 = add i64 %t440, %t442
  %t444 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t443)
  call void @olang_textcopy(ptr %t444, ptr %t435, i64 %t436)
  %t445 = getelementptr i8, ptr %t444, i64 %t436
  call void @olang_textcopy(ptr %t445, ptr %t438, i64 %t439)
  %t446 = getelementptr i8, ptr %t445, i64 %t439
  call void @olang_textcopy(ptr %t446, ptr %t441, i64 %t442)
  %t447 = insertvalue { i64, ptr } undef, i64 %t443, 0
  %t448 = insertvalue { i64, ptr } %t447, ptr %t444, 1
  %t450 = extractvalue { i64, ptr } %t448, 0
  %t451 = extractvalue { i64, ptr } %t448, 1
  %t452 = mul i64 %t450, 1
  %t453 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t452)
  call void @llvm.memcpy.p0.p0.i64(ptr %t453, ptr %t451, i64 %t452, i1 false)
  %t454 = insertvalue { i64, ptr } undef, i64 %t450, 0
  %t455 = insertvalue { i64, ptr } %t454, ptr %t453, 1
  %t458 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s14, ptr %s14, ptr %t428, { i64, ptr } %t455)
  store { i64, ptr } %t458, ptr %l153
  br label %bb46
bb46:
  %t459 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t460 = extractvalue { i64, ptr } %t459, 1
  %t461 = extractvalue { i64, ptr } %t459, 0
  %t462 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t461)
  call void @olang_textcopy(ptr %t462, ptr %t460, i64 %t461)
  %t463 = insertvalue { i64, ptr } undef, i64 %t461, 0
  %t464 = insertvalue { i64, ptr } %t463, ptr %t462, 1
  %t466 = extractvalue { i64, ptr } %t464, 0
  %t467 = extractvalue { i64, ptr } %t464, 1
  %t468 = mul i64 %t466, 1
  %t469 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t468)
  call void @llvm.memcpy.p0.p0.i64(ptr %t469, ptr %t467, i64 %t468, i1 false)
  %t470 = insertvalue { i64, ptr } undef, i64 %t466, 0
  %t471 = insertvalue { i64, ptr } %t470, ptr %t469, 1
  %t473 = load i64, ptr %l147, !tbaa !24
  %t474 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t475 = load ptr, ptr %t474, !tbaa !27
  %t476 = getelementptr { i64, ptr }, ptr %t475, i64 %t473
  store { i64, ptr } %t471, ptr %t476, !tbaa !37
  call void @__olang_scope_close(ptr %s14)
  br label %bb55
bb47:
  br i1 true, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb54
bb50:
  store %olang.scope zeroinitializer, ptr %s18
  %t477 = load i64, ptr %l11, !tbaa !24
  store i64 %t477, ptr %l156, !tbaa !24
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t479 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t480 = load i32, ptr %l13, !tbaa !23
  %t484 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eindex(ptr %v0, ptr %s2, ptr %s18, ptr %t478, { i64, ptr } %t479, i32 %t480)
  store { i64, ptr } %t484, ptr %l160
  br label %bb51
bb51:
  %t485 = load { i64, ptr }, ptr %l160, !tbaa !27
  %t486 = extractvalue { i64, ptr } %t485, 1
  %t487 = extractvalue { i64, ptr } %t485, 0
  %t488 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t487)
  call void @olang_textcopy(ptr %t488, ptr %t486, i64 %t487)
  %t489 = insertvalue { i64, ptr } undef, i64 %t487, 0
  %t490 = insertvalue { i64, ptr } %t489, ptr %t488, 1
  %t492 = extractvalue { i64, ptr } %t490, 0
  %t493 = extractvalue { i64, ptr } %t490, 1
  %t494 = mul i64 %t492, 1
  %t495 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t494)
  call void @llvm.memcpy.p0.p0.i64(ptr %t495, ptr %t493, i64 %t494, i1 false)
  %t496 = insertvalue { i64, ptr } undef, i64 %t492, 0
  %t497 = insertvalue { i64, ptr } %t496, ptr %t495, 1
  %t499 = load i64, ptr %l156, !tbaa !24
  %t500 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t501 = load ptr, ptr %t500, !tbaa !27
  %t502 = getelementptr { i64, ptr }, ptr %t501, i64 %t499
  store { i64, ptr } %t497, ptr %t502, !tbaa !37
  %t503 = load ptr, ptr %l0, !tbaa !29
  %t505 = getelementptr %"compiler/emit:fnEm", ptr %t503, i32 0, i32 0
  %t506 = load ptr, ptr %t505, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s18, ptr %t506, { i64, ptr } { i64 15, ptr @.d167 })
  br label %bb52
bb52:
  %t508 = load i64, ptr %l11, !tbaa !24
  store i64 %t508, ptr %l165, !tbaa !24
  %t509 = load ptr, ptr %l0, !tbaa !29
  %t510 = load i64, ptr %l11, !tbaa !24
  %t512 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t513 = load ptr, ptr %t512, !tbaa !27
  %t514 = getelementptr { i64, ptr }, ptr %t513, i64 %t510
  %t515 = load { i64, ptr }, ptr %t514, !tbaa !37
  %t516 = extractvalue { i64, ptr } { i64 40, ptr @.d168 }, 1
  %t517 = extractvalue { i64, ptr } { i64 40, ptr @.d168 }, 0
  %t519 = extractvalue { i64, ptr } %t515, 1
  %t520 = extractvalue { i64, ptr } %t515, 0
  %t521 = add i64 %t517, %t520
  %t522 = extractvalue { i64, ptr } { i64 1, ptr @.d169 }, 1
  %t523 = extractvalue { i64, ptr } { i64 1, ptr @.d169 }, 0
  %t524 = add i64 %t521, %t523
  %t525 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t524)
  call void @olang_textcopy(ptr %t525, ptr %t516, i64 %t517)
  %t526 = getelementptr i8, ptr %t525, i64 %t517
  call void @olang_textcopy(ptr %t526, ptr %t519, i64 %t520)
  %t527 = getelementptr i8, ptr %t526, i64 %t520
  call void @olang_textcopy(ptr %t527, ptr %t522, i64 %t523)
  %t528 = insertvalue { i64, ptr } undef, i64 %t524, 0
  %t529 = insertvalue { i64, ptr } %t528, ptr %t525, 1
  %t531 = extractvalue { i64, ptr } %t529, 0
  %t532 = extractvalue { i64, ptr } %t529, 1
  %t533 = mul i64 %t531, 1
  %t534 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t533)
  call void @llvm.memcpy.p0.p0.i64(ptr %t534, ptr %t532, i64 %t533, i1 false)
  %t535 = insertvalue { i64, ptr } undef, i64 %t531, 0
  %t536 = insertvalue { i64, ptr } %t535, ptr %t534, 1
  %t539 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s18, ptr %s18, ptr %t509, { i64, ptr } %t536)
  store { i64, ptr } %t539, ptr %l171
  br label %bb53
bb53:
  %t540 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t541 = extractvalue { i64, ptr } %t540, 1
  %t542 = extractvalue { i64, ptr } %t540, 0
  %t543 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t542)
  call void @olang_textcopy(ptr %t543, ptr %t541, i64 %t542)
  %t544 = insertvalue { i64, ptr } undef, i64 %t542, 0
  %t545 = insertvalue { i64, ptr } %t544, ptr %t543, 1
  %t547 = extractvalue { i64, ptr } %t545, 0
  %t548 = extractvalue { i64, ptr } %t545, 1
  %t549 = mul i64 %t547, 1
  %t550 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t549)
  call void @llvm.memcpy.p0.p0.i64(ptr %t550, ptr %t548, i64 %t549, i1 false)
  %t551 = insertvalue { i64, ptr } undef, i64 %t547, 0
  %t552 = insertvalue { i64, ptr } %t551, ptr %t550, 1
  %t554 = load i64, ptr %l165, !tbaa !24
  %t555 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t556 = load ptr, ptr %t555, !tbaa !27
  %t557 = getelementptr { i64, ptr }, ptr %t556, i64 %t554
  store { i64, ptr } %t552, ptr %t557, !tbaa !37
  call void @__olang_scope_close(ptr %s18)
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_5356cb2f84f9732_b3351f2e3cf54f16)
  unreachable
bb55:
  %t558 = load i64, ptr %l11, !tbaa !24
  %t560 = icmp eq i64 %t558, 0
  br i1 %t560, label %bb56, label %bb57
bb56:
  %t562 = load i64, ptr %l11, !tbaa !24
  %t564 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t565 = load ptr, ptr %t564, !tbaa !27
  %t566 = getelementptr { i64, ptr }, ptr %t565, i64 %t562
  %t567 = load { i64, ptr }, ptr %t566, !tbaa !37
  %t569 = extractvalue { i64, ptr } %t567, 1
  %t570 = extractvalue { i64, ptr } %t567, 0
  %t571 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t570)
  call void @olang_textcopy(ptr %t571, ptr %t569, i64 %t570)
  %t572 = insertvalue { i64, ptr } undef, i64 %t570, 0
  %t573 = insertvalue { i64, ptr } %t572, ptr %t571, 1
  store { i64, ptr } %t573, ptr %l176, !tbaa !27
  br label %bb59
bb57:
  %t575 = load ptr, ptr %l0, !tbaa !29
  %t576 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t577 = load i64, ptr %l11, !tbaa !24
  %t579 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t580 = load ptr, ptr %t579, !tbaa !27
  %t581 = getelementptr { i64, ptr }, ptr %t580, i64 %t577
  %t582 = load { i64, ptr }, ptr %t581, !tbaa !37
  %t583 = extractvalue { i64, ptr } { i64 8, ptr @.d170 }, 1
  %t584 = extractvalue { i64, ptr } { i64 8, ptr @.d170 }, 0
  %t586 = extractvalue { i64, ptr } %t576, 1
  %t587 = extractvalue { i64, ptr } %t576, 0
  %t588 = add i64 %t584, %t587
  %t589 = extractvalue { i64, ptr } { i64 2, ptr @.d171 }, 1
  %t590 = extractvalue { i64, ptr } { i64 2, ptr @.d171 }, 0
  %t591 = add i64 %t588, %t590
  %t593 = extractvalue { i64, ptr } %t582, 1
  %t594 = extractvalue { i64, ptr } %t582, 0
  %t595 = add i64 %t591, %t594
  %t596 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t595)
  call void @olang_textcopy(ptr %t596, ptr %t583, i64 %t584)
  %t597 = getelementptr i8, ptr %t596, i64 %t584
  call void @olang_textcopy(ptr %t597, ptr %t586, i64 %t587)
  %t598 = getelementptr i8, ptr %t597, i64 %t587
  call void @olang_textcopy(ptr %t598, ptr %t589, i64 %t590)
  %t599 = getelementptr i8, ptr %t598, i64 %t590
  call void @olang_textcopy(ptr %t599, ptr %t593, i64 %t594)
  %t600 = insertvalue { i64, ptr } undef, i64 %t595, 0
  %t601 = insertvalue { i64, ptr } %t600, ptr %t596, 1
  %t603 = extractvalue { i64, ptr } %t601, 0
  %t604 = extractvalue { i64, ptr } %t601, 1
  %t605 = mul i64 %t603, 1
  %t606 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t605)
  call void @llvm.memcpy.p0.p0.i64(ptr %t606, ptr %t604, i64 %t605, i1 false)
  %t607 = insertvalue { i64, ptr } undef, i64 %t603, 0
  %t608 = insertvalue { i64, ptr } %t607, ptr %t606, 1
  %t611 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t575, { i64, ptr } %t608)
  store { i64, ptr } %t611, ptr %l186
  br label %bb58
bb58:
  %t612 = load { i64, ptr }, ptr %l186, !tbaa !27
  store { i64, ptr } %t612, ptr %l176, !tbaa !27
  br label %bb59
bb59:
  %t613 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t614 = extractvalue { i64, ptr } %t613, 0
  %t615 = load { i64, ptr }, ptr %l176, !tbaa !27
  %t616 = extractvalue { i64, ptr } %t615, 0
  store i64 %t616, ptr %l188, !tbaa !24
  %t618 = load i64, ptr %l188, !tbaa !24
  %t619 = icmp eq i64 %t614, %t618
  br i1 %t619, label %bb60, label %bb61
bb60:
  %t621 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t622 = load ptr, ptr %t621, !tbaa !27
  %t623 = getelementptr { i64, ptr }, ptr %l176, i32 0, i32 1
  %t624 = load ptr, ptr %t623, !tbaa !27
  %t625 = load i64, ptr %l188, !tbaa !24
  %t626 = mul i64 %t625, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t622, ptr %t624, i64 %t626, i1 false)
  br label %bb62
bb61:
  %t627 = load { i64, ptr }, ptr %l176, !tbaa !27
  store { i64, ptr } %t627, ptr %l5, !tbaa !27
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s2)
  br label %bb63
bb63:
  %t628 = load i64, ptr %l10, !tbaa !24
  %t630 = add i64 %t628, 1
  store i64 %t630, ptr %l10, !tbaa !24
  br label %bb16
bb64:
  %t632 = load ptr, ptr %l0, !tbaa !29
  %t634 = getelementptr %"compiler/emit:fnEm", ptr %t632, i32 0, i32 0
  %t635 = load ptr, ptr %t634, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s0, ptr %t635, { i64, ptr } { i64 19, ptr @.d172 })
  br label %bb65
bb65:
  %t637 = load ptr, ptr %l0, !tbaa !29
  store ptr %t637, ptr %l194, !tbaa !29
  %t638 = load ptr, ptr %l0, !tbaa !29
  %t642 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %s0, ptr %t638, { i64, [1 x i64] } %a1)
  store { i64, ptr } %t642, ptr %l197
  br label %bb66
bb66:
  %t643 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t644 = extractvalue { i64, ptr } { i64 34, ptr @.d173 }, 1
  %t645 = extractvalue { i64, ptr } { i64 34, ptr @.d173 }, 0
  %t646 = load { i64, ptr }, ptr %l197, !tbaa !27
  %t647 = extractvalue { i64, ptr } %t646, 1
  %t648 = extractvalue { i64, ptr } %t646, 0
  %t649 = add i64 %t645, %t648
  %t650 = extractvalue { i64, ptr } { i64 6, ptr @.d174 }, 1
  %t651 = extractvalue { i64, ptr } { i64 6, ptr @.d174 }, 0
  %t652 = add i64 %t649, %t651
  %t654 = extractvalue { i64, ptr } %t643, 1
  %t655 = extractvalue { i64, ptr } %t643, 0
  %t656 = add i64 %t652, %t655
  %t657 = extractvalue { i64, ptr } { i64 1, ptr @.d175 }, 1
  %t658 = extractvalue { i64, ptr } { i64 1, ptr @.d175 }, 0
  %t659 = add i64 %t656, %t658
  %t660 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t659)
  call void @olang_textcopy(ptr %t660, ptr %t644, i64 %t645)
  %t661 = getelementptr i8, ptr %t660, i64 %t645
  call void @olang_textcopy(ptr %t661, ptr %t647, i64 %t648)
  %t662 = getelementptr i8, ptr %t661, i64 %t648
  call void @olang_textcopy(ptr %t662, ptr %t650, i64 %t651)
  %t663 = getelementptr i8, ptr %t662, i64 %t651
  call void @olang_textcopy(ptr %t663, ptr %t654, i64 %t655)
  %t664 = getelementptr i8, ptr %t663, i64 %t655
  call void @olang_textcopy(ptr %t664, ptr %t657, i64 %t658)
  %t665 = insertvalue { i64, ptr } undef, i64 %t659, 0
  %t666 = insertvalue { i64, ptr } %t665, ptr %t660, 1
  %t668 = extractvalue { i64, ptr } %t666, 0
  %t669 = extractvalue { i64, ptr } %t666, 1
  %t670 = mul i64 %t668, 1
  %t671 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t670)
  call void @llvm.memcpy.p0.p0.i64(ptr %t671, ptr %t669, i64 %t670, i1 false)
  %t672 = insertvalue { i64, ptr } undef, i64 %t668, 0
  %t673 = insertvalue { i64, ptr } %t672, ptr %t671, 1
  %t674 = load ptr, ptr %l194, !tbaa !29
  %t676 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t674, { i64, ptr } %t673)
  store { i64, ptr } %t676, ptr %l201
  br label %bb67
bb67:
  %t677 = load { i64, ptr }, ptr %l201, !tbaa !27
  store { i64, ptr } %t677, ptr %l19, !tbaa !27
  %t678 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t678, ptr %l202, !tbaa !27
  %t679 = load { i64, ptr }, ptr %l202, !tbaa !27
  %t680 = extractvalue { i64, ptr } %t679, 0
  store i64 %t680, ptr %l203, !tbaa !24
  %t681 = load i64, ptr %l203, !tbaa !24
  %t682 = mul i64 %t681, 1
  %t683 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t682)
  %t684 = insertvalue { i64, ptr } undef, i64 %t681, 0
  %t685 = insertvalue { i64, ptr } %t684, ptr %t683, 1
  store { i64, ptr } %t685, ptr %l204, !tbaa !27
  %t686 = getelementptr { i64, ptr }, ptr %l204, i32 0, i32 1
  %t687 = load ptr, ptr %t686, !tbaa !27
  %t688 = getelementptr { i64, ptr }, ptr %l202, i32 0, i32 1
  %t689 = load ptr, ptr %t688, !tbaa !27
  %t690 = load i64, ptr %l203, !tbaa !24
  %t691 = mul i64 %t690, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t687, ptr %t689, i64 %t691, i1 false)
  %t692 = load { i64, ptr }, ptr %l204, !tbaa !27
  store { i64, ptr } %t692, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t693 = load i64, ptr %l2, !tbaa !24
  store i64 %t693, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t695 = load i64, ptr %l22, !tbaa !24
  %t696 = load i64, ptr %l21, !tbaa !24
  %t699 = icmp sgt i64 %t695, %t696
  br i1 %t699, label %bb68, label %bb69
bb68:
  %t701 = load i64, ptr %l23, !tbaa !24
  %t703 = icmp sgt i64 %t701, 0
  br i1 %t703, label %bb70, label %bb71
bb69:
  store i64 0, ptr %l209, !tbaa !24
  br label %bb73
bb70:
  %t705 = load i64, ptr %l22, !tbaa !24
  %t706 = load i64, ptr %l21, !tbaa !24
  %t709 = sub i64 %t705, %t706
  %t710 = load i64, ptr %l23, !tbaa !24
  %t713 = add i64 %t709, %t710
  %t715 = sub i64 %t713, 1
  %t716 = load i64, ptr %l23, !tbaa !24
  %t719 = sdiv i64 %t715, %t716
  store i64 %t719, ptr %l212, !tbaa !24
  br label %bb72
bb71:
  store i64 0, ptr %l212, !tbaa !24
  br label %bb72
bb72:
  %t721 = load i64, ptr %l212, !tbaa !24
  store i64 %t721, ptr %l209, !tbaa !24
  br label %bb73
bb73:
  %t722 = load i64, ptr %l209, !tbaa !24
  store i64 %t722, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb74
bb74:
  store %olang.scope zeroinitializer, ptr %s27
  %t723 = load i64, ptr %l25, !tbaa !24
  %t724 = load i64, ptr %l24, !tbaa !24
  %t727 = icmp slt i64 %t723, %t724
  %t729 = xor i1 %t727, true
  br i1 %t729, label %bb75, label %bb76
bb75:
  call void @__olang_scope_close(ptr %s27)
  br label %bb109
bb76:
  br label %bb77
bb77:
  %t731 = load i64, ptr %l21, !tbaa !24
  %t732 = load i64, ptr %l25, !tbaa !24
  %t733 = load i64, ptr %l23, !tbaa !24
  %t736 = mul i64 %t732, %t733
  %t739 = add i64 %t731, %t736
  store i64 %t739, ptr %l26, !tbaa !24
  %t741 = load ptr, ptr %l0, !tbaa !29
  %t743 = getelementptr %"compiler/emit:fnEm", ptr %t741, i32 0, i32 25
  %t744 = load i64, ptr %l26, !tbaa !24
  %t747 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aWriteKind_3e_2eAt_3ccompiler_2fmir_3aWriteKind_3e(ptr %v0, ptr %t743, i64 %t744)
  store i32 %t747, ptr %l233
  br label %bb78
bb78:
  %t748 = load i32, ptr %l233
  store i32 %t748, ptr %l27
  %t749 = load i32, ptr %l27
  %t751 = trunc i64 2 to i32
  %t752 = icmp eq i32 %t749, %t751
  br i1 %t752, label %bb79, label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb83
bb81:
  store %olang.scope zeroinitializer, ptr %s28
  %t754 = load ptr, ptr %l0, !tbaa !29
  %t755 = load i64, ptr %l26, !tbaa !24
  %t757 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t758 = load ptr, ptr %t757, !tbaa !27
  %t759 = getelementptr { i64, ptr }, ptr %t758, i64 %t755
  %t760 = load { i64, ptr }, ptr %t759, !tbaa !37
  %t761 = load { i64, ptr }, ptr %l20, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s28, ptr %s0, ptr %s0, ptr %s28, ptr %t754, { i64, ptr } { i64 2, ptr @.d176 }, { i64, ptr } %t760, { i64, ptr } %t761, { i64, ptr } { i64 0, ptr @.d177 })
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s28)
  br label %bb100
bb83:
  %t765 = load i32, ptr %l27
  %t767 = trunc i64 5 to i32
  %t768 = icmp eq i32 %t765, %t767
  br i1 %t768, label %bb84, label %bb85
bb84:
  br label %bb86
bb85:
  br label %bb88
bb86:
  store %olang.scope zeroinitializer, ptr %s29
  %t770 = load ptr, ptr %l0, !tbaa !29
  %t771 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t772 = load i64, ptr %l26, !tbaa !24
  %t774 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t775 = load ptr, ptr %t774, !tbaa !27
  %t776 = getelementptr { i64, ptr }, ptr %t775, i64 %t772
  %t777 = load { i64, ptr }, ptr %t776, !tbaa !37
  %t778 = extractvalue { i64, ptr } { i64 30, ptr @.d178 }, 1
  %t779 = extractvalue { i64, ptr } { i64 30, ptr @.d178 }, 0
  %t781 = extractvalue { i64, ptr } %t771, 1
  %t782 = extractvalue { i64, ptr } %t771, 0
  %t783 = add i64 %t779, %t782
  %t784 = extractvalue { i64, ptr } { i64 6, ptr @.d179 }, 1
  %t785 = extractvalue { i64, ptr } { i64 6, ptr @.d179 }, 0
  %t786 = add i64 %t783, %t785
  %t788 = extractvalue { i64, ptr } %t777, 1
  %t789 = extractvalue { i64, ptr } %t777, 0
  %t790 = add i64 %t786, %t789
  %t791 = extractvalue { i64, ptr } { i64 1, ptr @.d180 }, 1
  %t792 = extractvalue { i64, ptr } { i64 1, ptr @.d180 }, 0
  %t793 = add i64 %t790, %t792
  %t794 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t793)
  call void @olang_textcopy(ptr %t794, ptr %t778, i64 %t779)
  %t795 = getelementptr i8, ptr %t794, i64 %t779
  call void @olang_textcopy(ptr %t795, ptr %t781, i64 %t782)
  %t796 = getelementptr i8, ptr %t795, i64 %t782
  call void @olang_textcopy(ptr %t796, ptr %t784, i64 %t785)
  %t797 = getelementptr i8, ptr %t796, i64 %t785
  call void @olang_textcopy(ptr %t797, ptr %t788, i64 %t789)
  %t798 = getelementptr i8, ptr %t797, i64 %t789
  call void @olang_textcopy(ptr %t798, ptr %t791, i64 %t792)
  %t799 = insertvalue { i64, ptr } undef, i64 %t793, 0
  %t800 = insertvalue { i64, ptr } %t799, ptr %t794, 1
  %t802 = extractvalue { i64, ptr } %t800, 0
  %t803 = extractvalue { i64, ptr } %t800, 1
  %t804 = mul i64 %t802, 1
  %t805 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t804)
  call void @llvm.memcpy.p0.p0.i64(ptr %t805, ptr %t803, i64 %t804, i1 false)
  %t806 = insertvalue { i64, ptr } undef, i64 %t802, 0
  %t807 = insertvalue { i64, ptr } %t806, ptr %t805, 1
  %t810 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s29, ptr %s29, ptr %t770, { i64, ptr } %t807)
  store { i64, ptr } %t810, ptr %l248
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s29)
  br label %bb100
bb88:
  %t811 = load i32, ptr %l27
  %t813 = trunc i64 4 to i32
  %t814 = icmp eq i32 %t811, %t813
  br i1 %t814, label %bb89, label %bb90
bb89:
  br label %bb91
bb90:
  br label %bb93
bb91:
  store %olang.scope zeroinitializer, ptr %s31
  %t816 = load ptr, ptr %l0, !tbaa !29
  %t817 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t818 = load i64, ptr %l26, !tbaa !24
  %t820 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t821 = load ptr, ptr %t820, !tbaa !27
  %t822 = getelementptr { i64, ptr }, ptr %t821, i64 %t818
  %t823 = load { i64, ptr }, ptr %t822, !tbaa !37
  %t824 = extractvalue { i64, ptr } { i64 30, ptr @.d181 }, 1
  %t825 = extractvalue { i64, ptr } { i64 30, ptr @.d181 }, 0
  %t827 = extractvalue { i64, ptr } %t817, 1
  %t828 = extractvalue { i64, ptr } %t817, 0
  %t829 = add i64 %t825, %t828
  %t830 = extractvalue { i64, ptr } { i64 6, ptr @.d182 }, 1
  %t831 = extractvalue { i64, ptr } { i64 6, ptr @.d182 }, 0
  %t832 = add i64 %t829, %t831
  %t834 = extractvalue { i64, ptr } %t823, 1
  %t835 = extractvalue { i64, ptr } %t823, 0
  %t836 = add i64 %t832, %t835
  %t837 = extractvalue { i64, ptr } { i64 1, ptr @.d183 }, 1
  %t838 = extractvalue { i64, ptr } { i64 1, ptr @.d183 }, 0
  %t839 = add i64 %t836, %t838
  %t840 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t839)
  call void @olang_textcopy(ptr %t840, ptr %t824, i64 %t825)
  %t841 = getelementptr i8, ptr %t840, i64 %t825
  call void @olang_textcopy(ptr %t841, ptr %t827, i64 %t828)
  %t842 = getelementptr i8, ptr %t841, i64 %t828
  call void @olang_textcopy(ptr %t842, ptr %t830, i64 %t831)
  %t843 = getelementptr i8, ptr %t842, i64 %t831
  call void @olang_textcopy(ptr %t843, ptr %t834, i64 %t835)
  %t844 = getelementptr i8, ptr %t843, i64 %t835
  call void @olang_textcopy(ptr %t844, ptr %t837, i64 %t838)
  %t845 = insertvalue { i64, ptr } undef, i64 %t839, 0
  %t846 = insertvalue { i64, ptr } %t845, ptr %t840, 1
  %t848 = extractvalue { i64, ptr } %t846, 0
  %t849 = extractvalue { i64, ptr } %t846, 1
  %t850 = mul i64 %t848, 1
  %t851 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t850)
  call void @llvm.memcpy.p0.p0.i64(ptr %t851, ptr %t849, i64 %t850, i1 false)
  %t852 = insertvalue { i64, ptr } undef, i64 %t848, 0
  %t853 = insertvalue { i64, ptr } %t852, ptr %t851, 1
  %t856 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s31, ptr %s31, ptr %t816, { i64, ptr } %t853)
  store { i64, ptr } %t856, ptr %l257
  br label %bb92
bb92:
  call void @__olang_scope_close(ptr %s31)
  br label %bb100
bb93:
  br i1 true, label %bb94, label %bb95
bb94:
  br label %bb96
bb95:
  br label %bb99
bb96:
  store %olang.scope zeroinitializer, ptr %s33
  %t857 = load ptr, ptr %l0, !tbaa !29
  %t859 = getelementptr %"compiler/emit:fnEm", ptr %t857, i32 0, i32 0
  %t860 = load ptr, ptr %t859, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2etextCopy(ptr %v0, ptr %t860)
  br label %bb97
bb97:
  %t862 = load ptr, ptr %l0, !tbaa !29
  %t863 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t864 = load i64, ptr %l26, !tbaa !24
  %t866 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t867 = load ptr, ptr %t866, !tbaa !27
  %t868 = getelementptr { i64, ptr }, ptr %t867, i64 %t864
  %t869 = load { i64, ptr }, ptr %t868, !tbaa !37
  %t870 = load i64, ptr %l26, !tbaa !24
  %t872 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t873 = load ptr, ptr %t872, !tbaa !27
  %t874 = getelementptr { i64, ptr }, ptr %t873, i64 %t870
  %t875 = load { i64, ptr }, ptr %t874, !tbaa !37
  %t876 = extractvalue { i64, ptr } { i64 30, ptr @.d184 }, 1
  %t877 = extractvalue { i64, ptr } { i64 30, ptr @.d184 }, 0
  %t879 = extractvalue { i64, ptr } %t863, 1
  %t880 = extractvalue { i64, ptr } %t863, 0
  %t881 = add i64 %t877, %t880
  %t882 = extractvalue { i64, ptr } { i64 6, ptr @.d185 }, 1
  %t883 = extractvalue { i64, ptr } { i64 6, ptr @.d185 }, 0
  %t884 = add i64 %t881, %t883
  %t886 = extractvalue { i64, ptr } %t869, 1
  %t887 = extractvalue { i64, ptr } %t869, 0
  %t888 = add i64 %t884, %t887
  %t889 = extractvalue { i64, ptr } { i64 6, ptr @.d186 }, 1
  %t890 = extractvalue { i64, ptr } { i64 6, ptr @.d186 }, 0
  %t891 = add i64 %t888, %t890
  %t893 = extractvalue { i64, ptr } %t875, 1
  %t894 = extractvalue { i64, ptr } %t875, 0
  %t895 = add i64 %t891, %t894
  %t896 = extractvalue { i64, ptr } { i64 1, ptr @.d187 }, 1
  %t897 = extractvalue { i64, ptr } { i64 1, ptr @.d187 }, 0
  %t898 = add i64 %t895, %t897
  %t899 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t898)
  call void @olang_textcopy(ptr %t899, ptr %t876, i64 %t877)
  %t900 = getelementptr i8, ptr %t899, i64 %t877
  call void @olang_textcopy(ptr %t900, ptr %t879, i64 %t880)
  %t901 = getelementptr i8, ptr %t900, i64 %t880
  call void @olang_textcopy(ptr %t901, ptr %t882, i64 %t883)
  %t902 = getelementptr i8, ptr %t901, i64 %t883
  call void @olang_textcopy(ptr %t902, ptr %t886, i64 %t887)
  %t903 = getelementptr i8, ptr %t902, i64 %t887
  call void @olang_textcopy(ptr %t903, ptr %t889, i64 %t890)
  %t904 = getelementptr i8, ptr %t903, i64 %t890
  call void @olang_textcopy(ptr %t904, ptr %t893, i64 %t894)
  %t905 = getelementptr i8, ptr %t904, i64 %t894
  call void @olang_textcopy(ptr %t905, ptr %t896, i64 %t897)
  %t906 = insertvalue { i64, ptr } undef, i64 %t898, 0
  %t907 = insertvalue { i64, ptr } %t906, ptr %t899, 1
  %t909 = extractvalue { i64, ptr } %t907, 0
  %t910 = extractvalue { i64, ptr } %t907, 1
  %t911 = mul i64 %t909, 1
  %t912 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t911)
  call void @llvm.memcpy.p0.p0.i64(ptr %t912, ptr %t910, i64 %t911, i1 false)
  %t913 = insertvalue { i64, ptr } undef, i64 %t909, 0
  %t914 = insertvalue { i64, ptr } %t913, ptr %t912, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s33, ptr %t862, { i64, ptr } %t914)
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s33)
  br label %bb100
bb99:
  call void @__olang_check_failed(ptr @olang_loc_d4d3fc4bcd6b40b3_c2e6c5c87babde37)
  unreachable
bb100:
  %t917 = load i64, ptr %l26, !tbaa !24
  %t919 = add i64 %t917, 1
  %t920 = load i64, ptr %l2, !tbaa !24
  %t923 = icmp slt i64 %t919, %t920
  br i1 %t923, label %bb101, label %bb102
bb101:
  %t925 = load ptr, ptr %l0, !tbaa !29
  %t926 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t927 = load i64, ptr %l26, !tbaa !24
  %t929 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t930 = load ptr, ptr %t929, !tbaa !27
  %t931 = getelementptr { i64, ptr }, ptr %t930, i64 %t927
  %t932 = load { i64, ptr }, ptr %t931, !tbaa !37
  %t933 = extractvalue { i64, ptr } { i64 22, ptr @.d188 }, 1
  %t934 = extractvalue { i64, ptr } { i64 22, ptr @.d188 }, 0
  %t936 = extractvalue { i64, ptr } %t926, 1
  %t937 = extractvalue { i64, ptr } %t926, 0
  %t938 = add i64 %t934, %t937
  %t939 = extractvalue { i64, ptr } { i64 6, ptr @.d189 }, 1
  %t940 = extractvalue { i64, ptr } { i64 6, ptr @.d189 }, 0
  %t941 = add i64 %t938, %t940
  %t943 = extractvalue { i64, ptr } %t932, 1
  %t944 = extractvalue { i64, ptr } %t932, 0
  %t945 = add i64 %t941, %t944
  %t946 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t945)
  call void @olang_textcopy(ptr %t946, ptr %t933, i64 %t934)
  %t947 = getelementptr i8, ptr %t946, i64 %t934
  call void @olang_textcopy(ptr %t947, ptr %t936, i64 %t937)
  %t948 = getelementptr i8, ptr %t947, i64 %t937
  call void @olang_textcopy(ptr %t948, ptr %t939, i64 %t940)
  %t949 = getelementptr i8, ptr %t948, i64 %t940
  call void @olang_textcopy(ptr %t949, ptr %t943, i64 %t944)
  %t950 = insertvalue { i64, ptr } undef, i64 %t945, 0
  %t951 = insertvalue { i64, ptr } %t950, ptr %t946, 1
  %t953 = extractvalue { i64, ptr } %t951, 0
  %t954 = extractvalue { i64, ptr } %t951, 1
  %t955 = mul i64 %t953, 1
  %t956 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t955)
  call void @llvm.memcpy.p0.p0.i64(ptr %t956, ptr %t954, i64 %t955, i1 false)
  %t957 = insertvalue { i64, ptr } undef, i64 %t953, 0
  %t958 = insertvalue { i64, ptr } %t957, ptr %t956, 1
  %t961 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t925, { i64, ptr } %t958)
  store { i64, ptr } %t961, ptr %l278
  br label %bb103
bb102:
  br label %bb107
bb103:
  %t962 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t963 = extractvalue { i64, ptr } %t962, 0
  %t964 = load { i64, ptr }, ptr %l278, !tbaa !27
  %t965 = extractvalue { i64, ptr } %t964, 0
  store i64 %t965, ptr %l280, !tbaa !24
  %t967 = load i64, ptr %l280, !tbaa !24
  %t968 = icmp eq i64 %t963, %t967
  br i1 %t968, label %bb104, label %bb105
bb104:
  %t970 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t971 = load ptr, ptr %t970, !tbaa !27
  %t972 = getelementptr { i64, ptr }, ptr %l278, i32 0, i32 1
  %t973 = load ptr, ptr %t972, !tbaa !27
  %t974 = load i64, ptr %l280, !tbaa !24
  %t975 = mul i64 %t974, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t971, ptr %t973, i64 %t975, i1 false)
  br label %bb106
bb105:
  %t976 = load { i64, ptr }, ptr %l278, !tbaa !27
  store { i64, ptr } %t976, ptr %l20, !tbaa !27
  br label %bb106
bb106:
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s27)
  br label %bb108
bb108:
  %t977 = load i64, ptr %l25, !tbaa !24
  %t979 = add i64 %t977, 1
  store i64 %t979, ptr %l25, !tbaa !24
  br label %bb74
bb109:
  %t981 = load ptr, ptr %l0, !tbaa !29
  %t982 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t983 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t987 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epair(ptr %v0, ptr %s0, ptr %s0, ptr %v1, ptr %t981, { i64, ptr } %t982, { i64, ptr } %t983)
  store { i64, ptr } %t987, ptr %l287
  br label %bb110
bb110:
  call void @__olang_scope_close(ptr %s0)
  %t988 = load { i64, ptr }, ptr %l287, !tbaa !27
  store { i64, ptr } %t988, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eelemAt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l14 = alloca i32
  %l25 = alloca i32
  %l28 = alloca i1
  %l29 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l40 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, i32 }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l5, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t13 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %t9, i32 %a2)
  store i32 %t13, ptr %l14
  br label %bb1
bb1:
  %t14 = load i32, ptr %l14, !tbaa !23
  store i32 %t14, ptr %l6, !tbaa !23
  %t15 = load i32, ptr %l6, !tbaa !23
  %t16 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t19 = icmp eq i32 %t15, %t16
  br i1 %t19, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t21 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s1, ptr %t21, { i64, ptr } { i64 22, ptr @.d190 })
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = extractvalue { i64, ptr } %t23, 0
  %t27 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t25, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  %t30 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t32 = insertvalue { { i64, ptr }, i32 } undef, { i64, ptr } %t29, 0
  %t34 = insertvalue { { i64, ptr }, i32 } %t32, i32 %t30, 1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i32 } %t34, ptr %rv
  br label %ret
bb5:
  %t36 = load ptr, ptr %l5, !tbaa !29
  %t37 = load i32, ptr %l6, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t40, ptr %l25
  br label %bb6
bb6:
  %t41 = load i32, ptr %l25, !tbaa !23
  store i32 %t41, ptr %l7, !tbaa !23
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l6, !tbaa !23
  %t46 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixed(ptr %v0, ptr %t42, i32 %t43)
  store i1 %t46, ptr %l28
  br label %bb7
bb7:
  %t47 = load i1, ptr %l28, !tbaa !21
  br i1 %t47, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l29, !tbaa !29
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i32, ptr %l6, !tbaa !23
  %t53 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s3, ptr %t49, i32 %t50)
  store { i64, ptr } %t53, ptr %l32
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t54 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t56 = extractvalue { i64, ptr } { i64 14, ptr @.d191 }, 1
  %t57 = extractvalue { i64, ptr } { i64 14, ptr @.d191 }, 0
  %t58 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t58, 1
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t61 = add i64 %t57, %t60
  %t62 = extractvalue { i64, ptr } { i64 6, ptr @.d192 }, 1
  %t63 = extractvalue { i64, ptr } { i64 6, ptr @.d192 }, 0
  %t64 = add i64 %t61, %t63
  %t66 = extractvalue { i64, ptr } %t54, 1
  %t67 = extractvalue { i64, ptr } %t54, 0
  %t68 = add i64 %t64, %t67
  %t69 = extractvalue { i64, ptr } { i64 13, ptr @.d193 }, 1
  %t70 = extractvalue { i64, ptr } { i64 13, ptr @.d193 }, 0
  %t71 = add i64 %t68, %t70
  %t73 = extractvalue { i64, ptr } %t55, 1
  %t74 = extractvalue { i64, ptr } %t55, 0
  %t75 = add i64 %t71, %t74
  %t76 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t75)
  call void @olang_textcopy(ptr %t76, ptr %t56, i64 %t57)
  %t77 = getelementptr i8, ptr %t76, i64 %t57
  call void @olang_textcopy(ptr %t77, ptr %t59, i64 %t60)
  %t78 = getelementptr i8, ptr %t77, i64 %t60
  call void @olang_textcopy(ptr %t78, ptr %t62, i64 %t63)
  %t79 = getelementptr i8, ptr %t78, i64 %t63
  call void @olang_textcopy(ptr %t79, ptr %t66, i64 %t67)
  %t80 = getelementptr i8, ptr %t79, i64 %t67
  call void @olang_textcopy(ptr %t80, ptr %t69, i64 %t70)
  %t81 = getelementptr i8, ptr %t80, i64 %t70
  call void @olang_textcopy(ptr %t81, ptr %t73, i64 %t74)
  %t82 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t76, 1
  %t85 = extractvalue { i64, ptr } %t83, 0
  %t86 = extractvalue { i64, ptr } %t83, 1
  %t87 = mul i64 %t85, 1
  %t88 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t87)
  call void @llvm.memcpy.p0.p0.i64(ptr %t88, ptr %t86, i64 %t87, i1 false)
  %t89 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  %t91 = load ptr, ptr %l29, !tbaa !29
  %t93 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v4, ptr %v4, ptr %t91, { i64, ptr } %t90)
  store { i64, ptr } %t93, ptr %l37
  br label %bb11
bb11:
  %t94 = load i32, ptr %l7, !tbaa !23
  %t95 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t96 = insertvalue { { i64, ptr }, i32 } undef, { i64, ptr } %t95, 0
  %t98 = insertvalue { { i64, ptr }, i32 } %t96, i32 %t94, 1
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i32 } %t98, ptr %rv
  br label %ret
bb12:
  %t100 = load ptr, ptr %l0, !tbaa !29
  store ptr %t100, ptr %l40, !tbaa !29
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t103 = extractvalue { i64, ptr } { i64 32, ptr @.d194 }, 1
  %t104 = extractvalue { i64, ptr } { i64 32, ptr @.d194 }, 0
  %t106 = extractvalue { i64, ptr } %t102, 1
  %t107 = extractvalue { i64, ptr } %t102, 0
  %t108 = add i64 %t104, %t107
  %t109 = extractvalue { i64, ptr } { i64 14, ptr @.d195 }, 1
  %t110 = extractvalue { i64, ptr } { i64 14, ptr @.d195 }, 0
  %t111 = add i64 %t108, %t110
  %t112 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t111)
  call void @olang_textcopy(ptr %t112, ptr %t103, i64 %t104)
  %t113 = getelementptr i8, ptr %t112, i64 %t104
  call void @olang_textcopy(ptr %t113, ptr %t106, i64 %t107)
  %t114 = getelementptr i8, ptr %t113, i64 %t107
  call void @olang_textcopy(ptr %t114, ptr %t109, i64 %t110)
  %t115 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t112, 1
  %t118 = extractvalue { i64, ptr } %t116, 0
  %t119 = extractvalue { i64, ptr } %t116, 1
  %t120 = mul i64 %t118, 1
  %t121 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t120)
  call void @llvm.memcpy.p0.p0.i64(ptr %t121, ptr %t119, i64 %t120, i1 false)
  %t122 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t121, 1
  %t126 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %t101, { i64, ptr } %t123)
  store { i64, ptr } %t126, ptr %l45
  br label %bb13
bb13:
  %t127 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t127, 0
  %t129 = extractvalue { i64, ptr } %t127, 1
  %t130 = mul i64 %t128, 1
  %t131 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t130)
  call void @llvm.memcpy.p0.p0.i64(ptr %t131, ptr %t129, i64 %t130, i1 false)
  %t132 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr %t131, 1
  %t135 = load ptr, ptr %l40, !tbaa !29
  %t138 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s0, ptr %s0, ptr %v3, ptr %s0, ptr %t135, { i64, ptr } { i64 3, ptr @.d196 }, { i64, ptr } %t133, { i64, ptr } %a4)
  store { i64, ptr } %t138, ptr %l48
  br label %bb14
bb14:
  %t139 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t139, ptr %l8, !tbaa !27
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l49, !tbaa !29
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load i32, ptr %l7, !tbaa !23
  %t145 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s0, ptr %t141, i32 %t142)
  store { i64, ptr } %t145, ptr %l52
  br label %bb15
bb15:
  %t146 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t147 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t148 = extractvalue { i64, ptr } { i64 14, ptr @.d197 }, 1
  %t149 = extractvalue { i64, ptr } { i64 14, ptr @.d197 }, 0
  %t150 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t151 = extractvalue { i64, ptr } %t150, 1
  %t152 = extractvalue { i64, ptr } %t150, 0
  %t153 = add i64 %t149, %t152
  %t154 = extractvalue { i64, ptr } { i64 6, ptr @.d198 }, 1
  %t155 = extractvalue { i64, ptr } { i64 6, ptr @.d198 }, 0
  %t156 = add i64 %t153, %t155
  %t158 = extractvalue { i64, ptr } %t146, 1
  %t159 = extractvalue { i64, ptr } %t146, 0
  %t160 = add i64 %t156, %t159
  %t161 = extractvalue { i64, ptr } { i64 6, ptr @.d199 }, 1
  %t162 = extractvalue { i64, ptr } { i64 6, ptr @.d199 }, 0
  %t163 = add i64 %t160, %t162
  %t165 = extractvalue { i64, ptr } %t147, 1
  %t166 = extractvalue { i64, ptr } %t147, 0
  %t167 = add i64 %t163, %t166
  %t168 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t167)
  call void @olang_textcopy(ptr %t168, ptr %t148, i64 %t149)
  %t169 = getelementptr i8, ptr %t168, i64 %t149
  call void @olang_textcopy(ptr %t169, ptr %t151, i64 %t152)
  %t170 = getelementptr i8, ptr %t169, i64 %t152
  call void @olang_textcopy(ptr %t170, ptr %t154, i64 %t155)
  %t171 = getelementptr i8, ptr %t170, i64 %t155
  call void @olang_textcopy(ptr %t171, ptr %t158, i64 %t159)
  %t172 = getelementptr i8, ptr %t171, i64 %t159
  call void @olang_textcopy(ptr %t172, ptr %t161, i64 %t162)
  %t173 = getelementptr i8, ptr %t172, i64 %t162
  call void @olang_textcopy(ptr %t173, ptr %t165, i64 %t166)
  %t174 = insertvalue { i64, ptr } undef, i64 %t167, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t168, 1
  %t177 = extractvalue { i64, ptr } %t175, 0
  %t178 = extractvalue { i64, ptr } %t175, 1
  %t179 = mul i64 %t177, 1
  %t180 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t179)
  call void @llvm.memcpy.p0.p0.i64(ptr %t180, ptr %t178, i64 %t179, i1 false)
  %t181 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  %t183 = load ptr, ptr %l49, !tbaa !29
  %t185 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v4, ptr %v4, ptr %t183, { i64, ptr } %t182)
  store { i64, ptr } %t185, ptr %l57
  br label %bb16
bb16:
  %t186 = load i32, ptr %l7, !tbaa !23
  %t187 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t188 = insertvalue { { i64, ptr }, i32 } undef, { i64, ptr } %t187, 0
  %t190 = insertvalue { { i64, ptr }, i32 } %t188, i32 %t186, 1
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i32 } %t190, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, i32 }, ptr %rv
  ret { { i64, ptr }, i32 } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eexternArg(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i32
  %l6 = alloca { { i64, ptr }, { i64, ptr } }
  %l13 = alloca i32
  %l16 = alloca i32
  %l23 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l32 = alloca i1
  %l33 = alloca i32
  %l36 = alloca i32
  %l40 = alloca i32
  %l46 = alloca { { i64, ptr }, { i64, ptr } }
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t10 = load i32, ptr %l2, !tbaa !23
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t9, i32 %t10)
  store i32 %t13, ptr %l13
  br label %bb1
bb1:
  %t14 = load i32, ptr %l13, !tbaa !23
  store i32 %t14, ptr %l4, !tbaa !23
  %t15 = load ptr, ptr %l3, !tbaa !29
  %t16 = load i32, ptr %l4, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t19, ptr %l16
  br label %bb2
bb2:
  %t20 = load i32, ptr %l16
  %t22 = trunc i64 21 to i32
  %t23 = icmp eq i32 %t20, %t22
  br i1 %t23, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t27 = extractvalue { i64, ptr } { i64 26, ptr @.d200 }, 1
  %t28 = extractvalue { i64, ptr } { i64 26, ptr @.d200 }, 0
  %t30 = extractvalue { i64, ptr } %t26, 1
  %t31 = extractvalue { i64, ptr } %t26, 0
  %t32 = add i64 %t28, %t31
  %t33 = extractvalue { i64, ptr } { i64 3, ptr @.d201 }, 1
  %t34 = extractvalue { i64, ptr } { i64 3, ptr @.d201 }, 0
  %t35 = add i64 %t32, %t34
  %t36 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t35)
  call void @olang_textcopy(ptr %t36, ptr %t27, i64 %t28)
  %t37 = getelementptr i8, ptr %t36, i64 %t28
  call void @olang_textcopy(ptr %t37, ptr %t30, i64 %t31)
  %t38 = getelementptr i8, ptr %t37, i64 %t31
  call void @olang_textcopy(ptr %t38, ptr %t33, i64 %t34)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t36, 1
  %t42 = extractvalue { i64, ptr } %t40, 0
  %t43 = extractvalue { i64, ptr } %t40, 1
  %t44 = mul i64 %t42, 1
  %t45 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t44)
  call void @llvm.memcpy.p0.p0.i64(ptr %t45, ptr %t43, i64 %t44, i1 false)
  %t46 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  %t50 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s1, ptr %s1, ptr %t25, { i64, ptr } %t47)
  store { i64, ptr } %t50, ptr %l23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t53 = extractvalue { i64, ptr } { i64 26, ptr @.d202 }, 1
  %t54 = extractvalue { i64, ptr } { i64 26, ptr @.d202 }, 0
  %t56 = extractvalue { i64, ptr } %t52, 1
  %t57 = extractvalue { i64, ptr } %t52, 0
  %t58 = add i64 %t54, %t57
  %t59 = extractvalue { i64, ptr } { i64 3, ptr @.d203 }, 1
  %t60 = extractvalue { i64, ptr } { i64 3, ptr @.d203 }, 0
  %t61 = add i64 %t58, %t60
  %t62 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t61)
  call void @olang_textcopy(ptr %t62, ptr %t53, i64 %t54)
  %t63 = getelementptr i8, ptr %t62, i64 %t54
  call void @olang_textcopy(ptr %t63, ptr %t56, i64 %t57)
  %t64 = getelementptr i8, ptr %t63, i64 %t57
  call void @olang_textcopy(ptr %t64, ptr %t59, i64 %t60)
  %t65 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t62, 1
  %t68 = extractvalue { i64, ptr } %t66, 0
  %t69 = extractvalue { i64, ptr } %t66, 1
  %t70 = mul i64 %t68, 1
  %t71 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t70)
  call void @llvm.memcpy.p0.p0.i64(ptr %t71, ptr %t69, i64 %t70, i1 false)
  %t72 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t71, 1
  %t76 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s1, ptr %s1, ptr %t51, { i64, ptr } %t73)
  store { i64, ptr } %t76, ptr %l28
  br label %bb6
bb6:
  %t77 = extractvalue { i64, ptr } { i64 4, ptr @.d204 }, 1
  %t78 = extractvalue { i64, ptr } { i64 4, ptr @.d204 }, 0
  %t79 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 1
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t82 = add i64 %t78, %t81
  %t83 = extractvalue { i64, ptr } { i64 6, ptr @.d205 }, 1
  %t84 = extractvalue { i64, ptr } { i64 6, ptr @.d205 }, 0
  %t85 = add i64 %t82, %t84
  %t86 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = add i64 %t85, %t88
  %t90 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t89)
  call void @olang_textcopy(ptr %t90, ptr %t77, i64 %t78)
  %t91 = getelementptr i8, ptr %t90, i64 %t78
  call void @olang_textcopy(ptr %t91, ptr %t80, i64 %t81)
  %t92 = getelementptr i8, ptr %t91, i64 %t81
  call void @olang_textcopy(ptr %t92, ptr %t83, i64 %t84)
  %t93 = getelementptr i8, ptr %t92, i64 %t84
  call void @olang_textcopy(ptr %t93, ptr %t87, i64 %t88)
  %t94 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t90, 1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t95, ptr %rv
  br label %ret
bb7:
  %t97 = load ptr, ptr %l3, !tbaa !29
  %t98 = load i32, ptr %l4, !tbaa !23
  %t101 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t97, i32 %t98)
  store i1 %t101, ptr %l32
  br label %bb8
bb8:
  %t102 = load i1, ptr %l32, !tbaa !21
  br i1 %t102, label %bb9, label %bb10
bb9:
  %t103 = load ptr, ptr %l3, !tbaa !29
  %t104 = load i32, ptr %l4, !tbaa !23
  %t107 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t103, i32 %t104)
  store i32 %t107, ptr %l36
  br label %bb11
bb10:
  %t108 = load i32, ptr %l4, !tbaa !23
  store i32 %t108, ptr %l33, !tbaa !23
  br label %bb12
bb11:
  %t110 = load i32, ptr %l36, !tbaa !23
  store i32 %t110, ptr %l33, !tbaa !23
  br label %bb12
bb12:
  %t111 = load i32, ptr %l33, !tbaa !23
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t116 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %t112, i32 %t111)
  store i32 %t116, ptr %l40
  br label %bb13
bb13:
  %t117 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t118 = load i32, ptr %l40, !tbaa !23
  %t120 = icmp ne i32 %t118, %t117
  br i1 %t120, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s5
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t124 = load i32, ptr %l2, !tbaa !23
  %t128 = call { { i64, ptr }, { i64, ptr } } @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayParts(ptr %v0, ptr %v1, ptr %s5, ptr %t122, { i64, ptr } %t123, i32 %t124)
  store { { i64, ptr }, { i64, ptr } } %t128, ptr %l46
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t129 = load { { i64, ptr }, { i64, ptr } }, ptr %l46
  store { { i64, ptr }, { i64, ptr } } %t129, ptr %l6
  %t130 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l6, i32 0, i32 0
  %t131 = load { i64, ptr }, ptr %t130, !tbaa !27
  store { i64, ptr } %t131, ptr %l47, !tbaa !27
  %t132 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t132, 0
  store i64 %t133, ptr %l48, !tbaa !24
  %t134 = load i64, ptr %l48, !tbaa !24
  %t135 = mul i64 %t134, 1
  %t136 = call ptr @__olang_scope_alloc_zeroed(ptr %s5, i64 %t135)
  %t137 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t136, 1
  store { i64, ptr } %t138, ptr %l49, !tbaa !27
  %t139 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !27
  %t141 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = load i64, ptr %l48, !tbaa !24
  %t144 = mul i64 %t143, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t140, ptr %t142, i64 %t144, i1 false)
  %t145 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t147 = extractvalue { i64, ptr } { i64 4, ptr @.d206 }, 1
  %t148 = extractvalue { i64, ptr } { i64 4, ptr @.d206 }, 0
  %t150 = extractvalue { i64, ptr } %t145, 1
  %t151 = extractvalue { i64, ptr } %t145, 0
  %t152 = add i64 %t148, %t151
  %t153 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t152)
  call void @olang_textcopy(ptr %t153, ptr %t147, i64 %t148)
  %t154 = getelementptr i8, ptr %t153, i64 %t148
  call void @olang_textcopy(ptr %t154, ptr %t150, i64 %t151)
  %t155 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t153, 1
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t156, ptr %rv
  br label %ret
bb17:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load i32, ptr %l4, !tbaa !23
  %t162 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s0, ptr %t158, i32 %t159)
  store { i64, ptr } %t162, ptr %l54
  br label %bb18
bb18:
  %t163 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t164 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t164, 1
  %t166 = extractvalue { i64, ptr } %t164, 0
  %t167 = extractvalue { i64, ptr } { i64 1, ptr @.d207 }, 1
  %t168 = extractvalue { i64, ptr } { i64 1, ptr @.d207 }, 0
  %t169 = add i64 %t166, %t168
  %t171 = extractvalue { i64, ptr } %t163, 1
  %t172 = extractvalue { i64, ptr } %t163, 0
  %t173 = add i64 %t169, %t172
  %t174 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t173)
  call void @olang_textcopy(ptr %t174, ptr %t165, i64 %t166)
  %t175 = getelementptr i8, ptr %t174, i64 %t166
  call void @olang_textcopy(ptr %t175, ptr %t167, i64 %t168)
  %t176 = getelementptr i8, ptr %t175, i64 %t168
  call void @olang_textcopy(ptr %t176, ptr %t171, i64 %t172)
  %t177 = insertvalue { i64, ptr } undef, i64 %t173, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t174, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t178, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2efindDirect(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca %"compiler/mir:BasicBlock"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, [21 x i64] }
  %l16 = alloca i32
  %l17 = alloca i64
  %l18 = alloca { i64, [21 x i64] }
  %l19 = alloca { i64, [15 x i64] }
  %l20 = alloca { i64, [1 x i64] }
  %l21 = alloca i1
  %l22 = alloca { i64, [21 x i64] }
  %l23 = alloca i32
  %l24 = alloca i1
  %l28 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca i32
  %l41 = alloca { i64, ptr }
  %l45 = alloca i64
  %l50 = alloca i64
  %l53 = alloca i64
  %l73 = alloca { i64, [21 x i64] }
  %l74 = alloca { i64, [21 x i64] }
  %l82 = alloca %"compiler/mir:ScopeInfo"
  %l94 = alloca i1
  %l95 = alloca ptr
  %l98 = alloca { i64, [21 x i64] }
  %l101 = alloca i1
  %l111 = alloca { i64, [21 x i64] }
  %l112 = alloca i1
  %l113 = alloca { i64, [21 x i64] }
  %l116 = alloca i1
  %l123 = alloca i1
  %l127 = alloca { i64, [21 x i64] }
  %l128 = alloca i1
  %l129 = alloca { i64, [21 x i64] }
  %l137 = alloca i1
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/mir:Fn", ptr %t4, i32 0, i32 9
  store ptr %t6, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eRu_H05f2a0ad75f6ffeece9ab76b4dcd7cb0(ptr %v0, ptr %t8, i64 %t9)
  %t13 = extractvalue { i32, { i64, ptr } } %t12, 1
  %t14 = extractvalue { i32, { i64, ptr } } %t12, 0
  store i32 %t14, ptr %l32
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb3, label %ok.16
ok.16:
  store { i64, ptr } %t13, ptr %l31
  br label %bb2
bb2:
  %t17 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t17, ptr %l28, !tbaa !27
  br label %bb7
bb3:
  %t18 = load i32, ptr %l32, !tbaa !23
  %t19 = ashr i32 %t18, 16
  %t21 = icmp eq i32 %t19, 1
  br i1 %t21, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_8a0f087481b95ab0_a13f080fe7b316d4)
  unreachable
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb96
bb7:
  %t23 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t23, ptr %l3, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  store i64 %t26, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t28 = load i64, ptr %l5, !tbaa !24
  %t29 = load i64, ptr %l4, !tbaa !24
  %t32 = icmp slt i64 %t28, %t29
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb94
bb10:
  br label %bb11
bb11:
  %t36 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t36, ptr %l41, !tbaa !27
  %t37 = load i64, ptr %l5, !tbaa !24
  %t39 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr %"compiler/mir:BasicBlock", ptr %t40, i64 %t37
  %t42 = load %"compiler/mir:BasicBlock", ptr %t41
  store %"compiler/mir:BasicBlock" %t42, ptr %l6
  %t44 = getelementptr %"compiler/mir:BasicBlock", ptr %l6, i32 0, i32 0
  %t46 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t44)
  store i64 %t46, ptr %l45
  br label %bb12
bb12:
  %t47 = load i64, ptr %l45, !tbaa !24
  store i64 %t47, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t48 = load i64, ptr %l7, !tbaa !24
  store i64 %t48, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = load i64, ptr %l8, !tbaa !24
  %t54 = icmp sgt i64 %t50, %t51
  br i1 %t54, label %bb13, label %bb14
bb13:
  %t56 = load i64, ptr %l10, !tbaa !24
  %t58 = icmp sgt i64 %t56, 0
  br i1 %t58, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l50, !tbaa !24
  br label %bb18
bb15:
  %t60 = load i64, ptr %l9, !tbaa !24
  %t61 = load i64, ptr %l8, !tbaa !24
  %t64 = sub i64 %t60, %t61
  %t65 = load i64, ptr %l10, !tbaa !24
  %t68 = add i64 %t64, %t65
  %t70 = sub i64 %t68, 1
  %t71 = load i64, ptr %l10, !tbaa !24
  %t74 = sdiv i64 %t70, %t71
  store i64 %t74, ptr %l53, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l53, !tbaa !24
  br label %bb17
bb17:
  %t76 = load i64, ptr %l53, !tbaa !24
  store i64 %t76, ptr %l50, !tbaa !24
  br label %bb18
bb18:
  %t77 = load i64, ptr %l50, !tbaa !24
  store i64 %t77, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  %t78 = load i64, ptr %l12, !tbaa !24
  %t79 = load i64, ptr %l11, !tbaa !24
  %t82 = icmp slt i64 %t78, %t79
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s5)
  br label %bb92
bb21:
  br label %bb22
bb22:
  %t86 = load i64, ptr %l8, !tbaa !24
  %t87 = load i64, ptr %l12, !tbaa !24
  %t88 = load i64, ptr %l10, !tbaa !24
  %t91 = mul i64 %t87, %t88
  %t94 = add i64 %t86, %t91
  store i64 %t94, ptr %l13, !tbaa !24
  store i64 -1, ptr %l14, !tbaa !24
  %t96 = getelementptr %"compiler/mir:BasicBlock", ptr %l6, i32 0, i32 0
  %t97 = load i64, ptr %l13, !tbaa !24
  %t100 = call { i64, [21 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t96, i64 %t97)
  store { i64, [21 x i64] } %t100, ptr %l73
  br label %bb23
bb23:
  call void @llvm.memmove.p0.p0.i64(ptr %l15, ptr %l73, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l74, ptr %l15, i64 176, i1 false)
  %t101 = load { i64, [21 x i64] }, ptr %l74
  %t102 = extractvalue { i64, [21 x i64] } %t101, 0
  %t103 = icmp eq i64 %t102, 3
  br i1 %t103, label %bb24, label %bb25
bb24:
  %t105 = getelementptr { i64, [21 x i64] }, ptr %l15, i32 0, i32 1
  %t106 = getelementptr { %"compiler/source:Span", i32 }, ptr %t105, i32 0, i32 1
  %t107 = load i32, ptr %t106
  store i32 %t107, ptr %l16, !tbaa !23
  br label %bb26
bb25:
  br label %bb31
bb26:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/emit:fnEm", ptr %t109, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = getelementptr %"compiler/mir:Fn", ptr %t112, i32 0, i32 8
  %t115 = load i32, ptr %l16, !tbaa !23
  %t117 = sext i32 %t115 to i64
  %t120 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t114, i64 %t117)
  store %"compiler/mir:ScopeInfo" %t120, ptr %l82
  br label %bb27
bb27:
  %t121 = getelementptr %"compiler/mir:ScopeInfo", ptr %l82, i32 0, i32 0
  %t122 = load i32, ptr %t121
  %t124 = trunc i64 6 to i32
  %t125 = icmp eq i32 %t122, %t124
  br i1 %t125, label %bb28, label %bb29
bb28:
  %t127 = load i32, ptr %l16, !tbaa !23
  %t129 = sext i32 %t127 to i64
  store i64 %t129, ptr %l14, !tbaa !24
  br label %bb30
bb29:
  br label %bb30
bb30:
  br label %bb36
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_9d64128d60439a41_20f9e6973a71ad85)
  unreachable
bb36:
  %t131 = load i64, ptr %l14, !tbaa !24
  %t133 = icmp slt i64 %t131, 0
  br i1 %t133, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s5)
  br label %bb91
bb38:
  br label %bb39
bb39:
  %t135 = load i64, ptr %l13, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l17, !tbaa !24
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s10
  %t139 = load i64, ptr %l17, !tbaa !24
  %t140 = load i64, ptr %l7, !tbaa !24
  %t143 = icmp slt i64 %t139, %t140
  br i1 %t143, label %bb41, label %bb42
bb41:
  %t145 = load ptr, ptr %l0, !tbaa !29
  store ptr %t145, ptr %l95, !tbaa !29
  %t146 = getelementptr %"compiler/mir:BasicBlock", ptr %l6, i32 0, i32 0
  %t147 = load i64, ptr %l17, !tbaa !24
  %t150 = call { i64, [21 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t146, i64 %t147)
  store { i64, [21 x i64] } %t150, ptr %l98
  br label %bb43
bb42:
  store i1 false, ptr %l94, !tbaa !21
  br label %bb45
bb43:
  %t151 = load { i64, [21 x i64] }, ptr %l98
  %t152 = call ptr @__olang_scope_alloc_a(ptr %s10, i64 176, i64 8)
  store { i64, [21 x i64] } %t151, ptr %t152
  %t153 = load i64, ptr %l14, !tbaa !24
  %t154 = load ptr, ptr %l95, !tbaa !29
  %t157 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eplainWrite(ptr %v0, ptr %s10, ptr %t154, ptr %t152, i64 %t153)
  store i1 %t157, ptr %l101
  br label %bb44
bb44:
  %t158 = load i1, ptr %l101, !tbaa !21
  store i1 %t158, ptr %l94, !tbaa !21
  br label %bb45
bb45:
  %t159 = load i1, ptr %l94, !tbaa !21
  %t160 = xor i1 %t159, true
  br i1 %t160, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s10)
  br label %bb50
bb47:
  br label %bb48
bb48:
  %t162 = load i64, ptr %l17, !tbaa !24
  %t164 = add i64 %t162, 1
  store i64 %t164, ptr %l17, !tbaa !24
  call void @__olang_scope_close(ptr %s10)
  br label %bb49
bb49:
  br label %bb40
bb50:
  %t166 = load i64, ptr %l17, !tbaa !24
  %t168 = add i64 %t166, 1
  %t169 = load i64, ptr %l7, !tbaa !24
  %t172 = icmp sge i64 %t168, %t169
  br i1 %t172, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s5)
  br label %bb91
bb52:
  br label %bb53
bb53:
  %t174 = getelementptr %"compiler/mir:BasicBlock", ptr %l6, i32 0, i32 0
  %t175 = load i64, ptr %l17, !tbaa !24
  %t178 = call { i64, [21 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t174, i64 %t175)
  store { i64, [21 x i64] } %t178, ptr %l111
  br label %bb54
bb54:
  call void @llvm.memmove.p0.p0.i64(ptr %l18, ptr %l111, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l113, ptr %l18, i64 176, i1 false)
  %t179 = load { i64, [21 x i64] }, ptr %l113
  %t180 = extractvalue { i64, [21 x i64] } %t179, 0
  %t181 = icmp eq i64 %t180, 0
  br i1 %t181, label %bb55, label %bb56
bb55:
  %t183 = getelementptr { i64, [21 x i64] }, ptr %l18, i32 0, i32 1
  %t184 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } }, ptr %t183, i32 0, i32 2
  %t185 = load { i64, [15 x i64] }, ptr %t184
  store { i64, [15 x i64] } %t185, ptr %l19
  br label %bb57
bb56:
  br label %bb68
bb57:
  %t187 = load { i64, [15 x i64] }, ptr %l19
  %t189 = extractvalue { i64, [15 x i64] } %t187, 0
  %t190 = icmp eq i64 %t189, 12
  br i1 %t190, label %bb58, label %bb59
bb58:
  %t192 = getelementptr { i64, [15 x i64] }, ptr %l19, i32 0, i32 1
  %t193 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t192, i32 0, i32 0
  %t194 = load { i64, [1 x i64] }, ptr %t193
  store { i64, [1 x i64] } %t194, ptr %l20
  br label %bb60
bb59:
  br label %bb62
bb60:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load { i64, [1 x i64] }, ptr %l20
  %t198 = load i64, ptr %l14, !tbaa !24
  %t202 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erefIs(ptr %v0, ptr %t196, { i64, [1 x i64] } %t197, i64 %t198)
  store i1 %t202, ptr %l123
  br label %bb61
bb61:
  %t203 = load i1, ptr %l123, !tbaa !21
  store i1 %t203, ptr %l116, !tbaa !21
  br label %bb67
bb62:
  br i1 true, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb66
bb65:
  store i1 false, ptr %l116, !tbaa !21
  br label %bb67
bb66:
  call void @__olang_check_failed(ptr @olang_loc_28dd7919903bc2a_4577237eccb57ce)
  unreachable
bb67:
  %t204 = load i1, ptr %l116, !tbaa !21
  store i1 %t204, ptr %l112, !tbaa !21
  br label %bb73
bb68:
  br i1 true, label %bb69, label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb72
bb71:
  store i1 false, ptr %l112, !tbaa !21
  br label %bb73
bb72:
  call void @__olang_check_failed(ptr @olang_loc_6846df2bf697eaeb_3c0ad43c6c9a3c0f)
  unreachable
bb73:
  %t205 = load i1, ptr %l112, !tbaa !21
  store i1 %t205, ptr %l21, !tbaa !21
  %t206 = getelementptr %"compiler/mir:BasicBlock", ptr %l6, i32 0, i32 0
  %t207 = load i64, ptr %l17, !tbaa !24
  %t209 = add i64 %t207, 1
  %t212 = call { i64, [21 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t206, i64 %t209)
  store { i64, [21 x i64] } %t212, ptr %l127
  br label %bb74
bb74:
  call void @llvm.memmove.p0.p0.i64(ptr %l22, ptr %l127, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l129, ptr %l22, i64 176, i1 false)
  %t213 = load { i64, [21 x i64] }, ptr %l129
  %t214 = extractvalue { i64, [21 x i64] } %t213, 0
  %t215 = icmp eq i64 %t214, 4
  br i1 %t215, label %bb75, label %bb76
bb75:
  %t217 = getelementptr { i64, [21 x i64] }, ptr %l22, i32 0, i32 1
  %t218 = getelementptr { %"compiler/source:Span", i32 }, ptr %t217, i32 0, i32 1
  %t219 = load i32, ptr %t218
  store i32 %t219, ptr %l23, !tbaa !23
  br label %bb77
bb76:
  br label %bb78
bb77:
  %t221 = load i32, ptr %l23, !tbaa !23
  %t223 = sext i32 %t221 to i64
  %t224 = load i64, ptr %l14, !tbaa !24
  %t227 = icmp eq i64 %t223, %t224
  store i1 %t227, ptr %l128, !tbaa !21
  br label %bb83
bb78:
  br i1 true, label %bb79, label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb82
bb81:
  store i1 false, ptr %l128, !tbaa !21
  br label %bb83
bb82:
  call void @__olang_check_failed(ptr @olang_loc_2bfcda938bdeba4c_88387621cebbefd8)
  unreachable
bb83:
  %t229 = load i1, ptr %l128, !tbaa !21
  store i1 %t229, ptr %l24, !tbaa !21
  %t230 = load i1, ptr %l21, !tbaa !21
  br i1 %t230, label %bb84, label %bb85
bb84:
  %t232 = load i1, ptr %l24, !tbaa !21
  store i1 %t232, ptr %l137, !tbaa !21
  br label %bb86
bb85:
  store i1 false, ptr %l137, !tbaa !21
  br label %bb86
bb86:
  %t234 = load i1, ptr %l137, !tbaa !21
  br i1 %t234, label %bb87, label %bb88
bb87:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/emit:fnEm", ptr %t235, i32 0, i32 23
  %t238 = load i64, ptr %l14, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t237, i64 %t238, i1 true)
  br label %bb89
bb88:
  br label %bb90
bb89:
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s5)
  br label %bb91
bb91:
  %t241 = load i64, ptr %l12, !tbaa !24
  %t243 = add i64 %t241, 1
  store i64 %t243, ptr %l12, !tbaa !24
  br label %bb19
bb92:
  call void @__olang_scope_close(ptr %s3)
  br label %bb93
bb93:
  %t245 = load i64, ptr %l5, !tbaa !24
  %t247 = add i64 %t245, 1
  store i64 %t247, ptr %l5, !tbaa !24
  br label %bb8
bb94:
  %t249 = load i64, ptr %l2, !tbaa !24
  %t250 = load i64, ptr %l4, !tbaa !24
  %t253 = add i64 %t249, %t250
  store i64 %t253, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb95
bb95:
  br label %bb1
bb96:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixed(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t7, i32 %a1)
  store i32 %t11, ptr %l6
  br label %bb1
bb1:
  %t12 = load i32, ptr %l6, !tbaa !23
  %t13 = icmp ne i32 %t12, 0
  store i1 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %t3, { i64, ptr } %a1)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/emit:fnEm", ptr %t7, i32 0, i32 5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t9, { i64, ptr } { i64 2, ptr @.d208 })
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalAt(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l8 = alloca %"compiler/mir:Local"
  %l10 = alloca i1
  %l17 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/emit:fnEm", ptr %t2, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t7 = getelementptr %"compiler/mir:Fn", ptr %t5, i32 0, i32 7
  %t8 = load i32, ptr %l1, !tbaa !23
  %t10 = sext i32 %t8 to i64
  %t13 = call %"compiler/mir:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t7, i64 %t10)
  store %"compiler/mir:Local" %t13, ptr %l8
  br label %bb1
bb1:
  %t14 = getelementptr %"compiler/mir:Local", ptr %l8, i32 0, i32 4
  %t15 = load { i64, [1 x i64] }, ptr %t14
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eisFrame(ptr %v0, ptr %t16, { i64, [1 x i64] } %t15)
  store i1 %t18, ptr %l10
  br label %bb2
bb2:
  %t19 = load i1, ptr %l10, !tbaa !21
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t20 = load i32, ptr %l1, !tbaa !23
  %t21 = extractvalue { i64, ptr } { i64 2, ptr @.d209 }, 1
  %t22 = extractvalue { i64, ptr } { i64 2, ptr @.d209 }, 0
  %t24 = sext i32 %t20 to i64
  %t25 = call i64 @__olang_fmt_i64(ptr null, i64 %t24)
  %t26 = add i64 %t22, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t21, i64 %t22)
  %t28 = getelementptr i8, ptr %t27, i64 %t22
  %t29 = call i64 @__olang_fmt_i64(ptr %t28, i64 %t24)
  %t30 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t27, 1
  store { i64, ptr } %t31, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l1, !tbaa !23
  %t35 = extractvalue { i64, ptr } { i64 3, ptr @.d210 }, 1
  %t36 = extractvalue { i64, ptr } { i64 3, ptr @.d210 }, 0
  %t38 = sext i32 %t34 to i64
  %t39 = call i64 @__olang_fmt_i64(ptr null, i64 %t38)
  %t40 = add i64 %t36, %t39
  %t41 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t40)
  call void @olang_textcopy(ptr %t41, ptr %t35, i64 %t36)
  %t42 = getelementptr i8, ptr %t41, i64 %t36
  %t43 = call i64 @__olang_fmt_i64(ptr %t42, i64 %t38)
  %t44 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t41, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = extractvalue { i64, ptr } %t45, 1
  %t49 = mul i64 %t47, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t49)
  call void @llvm.memcpy.p0.p0.i64(ptr %t50, ptr %t48, i64 %t49, i1 false)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  %t55 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %t33, { i64, ptr } { i64 3, ptr @.d211 }, { i64, ptr } %t52, { i64, ptr } { i64 0, ptr @.d212 })
  store { i64, ptr } %t55, ptr %l17
  br label %bb6
bb6:
  %t56 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t56, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2elocate(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l4 = alloca i1
  %l12 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t2 = load i32, ptr %t1, !tbaa !23
  %t4 = icmp eq i32 %t2, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t7 = load i32, ptr %t6, !tbaa !23
  %t9 = icmp eq i32 %t7, 0
  store i1 %t9, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l4, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t12 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t13 = load i32, ptr %t12, !tbaa !23
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/emit:fnEm", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/mir:Fn", ptr %t17, i32 0, i32 3
  %t20 = getelementptr %"compiler/source:Span", ptr %t19, i32 0, i32 0
  %t21 = load i32, ptr %t20, !tbaa !23
  %t24 = icmp eq i32 %t13, %t21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t26 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t27 = load i32, ptr %t26, !tbaa !23
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/emit:fnEm", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/mir:Fn", ptr %t31, i32 0, i32 3
  %t34 = getelementptr %"compiler/source:Span", ptr %t33, i32 0, i32 1
  %t35 = load i32, ptr %t34, !tbaa !23
  %t38 = icmp eq i32 %t27, %t35
  store i1 %t38, ptr %l12, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb9
bb9:
  %t40 = load i1, ptr %l12, !tbaa !21
  br i1 %t40, label %bb10, label %bb11
bb10:
  br label %ret
bb11:
  br label %bb12
bb12:
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l18, !tbaa !29
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l19, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/emit:fnEm", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/emit:Emitter", ptr %t46, i32 0, i32 2
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/emit:fnEm", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/mir:Fn", ptr %t53, i32 0, i32 2
  %t56 = load i64, ptr %t55, !tbaa !24
  %t57 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t58 = load i32, ptr %t57, !tbaa !23
  %t60 = sext i32 %t58 to i64
  %t64 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %t49, i64 %t56, i64 %t60)
  store i64 %t64, ptr %l28
  br label %bb13
bb13:
  %t65 = load ptr, ptr %l19, !tbaa !29
  %t66 = load i64, ptr %l28, !tbaa !24
  %t67 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edbgLine(ptr %v0, ptr %v0, ptr %t65, i64 %t66)
  store { i64, ptr } %t67, ptr %l29
  br label %bb14
bb14:
  %t68 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  %t70 = extractvalue { i64, ptr } %t68, 1
  %t71 = mul i64 %t69, 1
  %t72 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t70, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  %t76 = load ptr, ptr %l18, !tbaa !29
  %t77 = getelementptr %"compiler/emit:fnEm", ptr %t76, i32 0, i32 18
  store { i64, ptr } %t74, ptr %t77, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocated(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca i32
  %l33 = alloca i1
  %l40 = alloca { i64, ptr }
  %l45 = alloca ptr
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i32
  %l55 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i32
  %l61 = alloca { i64, ptr }
  %l66 = alloca i1
  %l68 = alloca { i64, ptr }
  %l71 = alloca i64
  %l73 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/emit:fnEm", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/mir:Fn", ptr %t10, i32 0, i32 2
  %t13 = load i64, ptr %t12, !tbaa !24
  %t18 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewhere(ptr %v0, ptr %s0, ptr %t6, i64 %t13, %"compiler/source:Span" %a1)
  store { i64, ptr } %t18, ptr %l17
  br label %bb1
bb1:
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 1
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t24 = extractvalue { i64, ptr } %t19, 1
  %t25 = extractvalue { i64, ptr } %t19, 0
  %t26 = add i64 %t22, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t21, i64 %t22)
  %t28 = getelementptr i8, ptr %t27, i64 %t22
  call void @olang_textcopy(ptr %t28, ptr %t24, i64 %t25)
  %t29 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t27, 1
  store { i64, ptr } %t30, ptr %l4, !tbaa !27
  %t32 = load ptr, ptr %l3, !tbaa !29
  %t34 = getelementptr %"compiler/emit:Emitter", ptr %t32, i32 0, i32 64
  %t35 = load i1, ptr %t34, !tbaa !21
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb2, label %bb3
bb2:
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t40 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t43 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %s0, ptr %v2, ptr %t39, { i64, ptr } %t40)
  store { i64, ptr } %t43, ptr %l25
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t44 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t44, ptr %rv
  br label %ret
bb5:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/emit:fnEm", ptr %t45, i32 0, i32 16
  %t48 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t51 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %s0, ptr %v0, ptr %t47, { i64, ptr } %t48)
  %t52 = extractvalue { i32, { i64, ptr } } %t51, 1
  %t53 = extractvalue { i32, { i64, ptr } } %t51, 0
  store i32 %t53, ptr %l31
  %t54 = icmp ne i32 %t53, 0
  br i1 %t54, label %bb7, label %ok.55
ok.55:
  store { i64, ptr } %t52, ptr %l30
  br label %bb6
bb6:
  %t56 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t56, ptr %l26, !tbaa !27
  br label %bb9
bb7:
  br label %bb8
bb8:
  store { i64, ptr } { i64 0, ptr @.d213 }, ptr %l26, !tbaa !27
  br label %bb9
bb9:
  %t57 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t57, ptr %l5, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t60 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t58, { i64, ptr } { i64 0, ptr @.d214 })
  store i1 %t60, ptr %l33
  br label %bb10
bb10:
  %t61 = load i1, ptr %l33, !tbaa !21
  %t62 = xor i1 %t61, true
  br i1 %t62, label %bb11, label %bb12
bb11:
  %t64 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t64, 1
  %t67 = extractvalue { i64, ptr } %t64, 0
  %t68 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t67)
  call void @olang_textcopy(ptr %t68, ptr %t66, i64 %t67)
  %t69 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t68, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t70, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t72 = load ptr, ptr %l3, !tbaa !29
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/emit:fnEm", ptr %t73, i32 0, i32 2
  %t76 = load { i64, [1 x i64] }, ptr %t75
  %t79 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2elocBase(ptr %v0, ptr %s0, ptr %t72, { i64, [1 x i64] } %t76)
  store { i64, ptr } %t79, ptr %l40
  br label %bb14
bb14:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/emit:fnEm", ptr %t80, i32 0, i32 15
  %t83 = load i64, ptr %t82, !tbaa !24
  %t84 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 1
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t88 = extractvalue { i64, ptr } { i64 1, ptr @.d215 }, 1
  %t89 = extractvalue { i64, ptr } { i64 1, ptr @.d215 }, 0
  %t90 = add i64 %t87, %t89
  %t92 = call i64 @__olang_fmt_i64(ptr null, i64 %t83)
  %t93 = add i64 %t90, %t92
  %t94 = extractvalue { i64, ptr } { i64 1, ptr @.d216 }, 1
  %t95 = extractvalue { i64, ptr } { i64 1, ptr @.d216 }, 0
  %t96 = add i64 %t93, %t95
  %t98 = extractvalue { i64, ptr } %t84, 1
  %t99 = extractvalue { i64, ptr } %t84, 0
  %t100 = add i64 %t96, %t99
  %t101 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t100)
  call void @olang_textcopy(ptr %t101, ptr %t86, i64 %t87)
  %t102 = getelementptr i8, ptr %t101, i64 %t87
  call void @olang_textcopy(ptr %t102, ptr %t88, i64 %t89)
  %t103 = getelementptr i8, ptr %t102, i64 %t89
  %t104 = call i64 @__olang_fmt_i64(ptr %t103, i64 %t83)
  %t105 = getelementptr i8, ptr %t103, i64 %t92
  call void @olang_textcopy(ptr %t105, ptr %t94, i64 %t95)
  %t106 = getelementptr i8, ptr %t105, i64 %t95
  call void @olang_textcopy(ptr %t106, ptr %t98, i64 %t99)
  %t107 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t101, 1
  store { i64, ptr } %t108, ptr %l6, !tbaa !27
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l45, !tbaa !29
  %t111 = load ptr, ptr %l45, !tbaa !29
  %t112 = getelementptr %"compiler/emit:fnEm", ptr %t111, i32 0, i32 15
  %t113 = load i64, ptr %t112, !tbaa !24
  %t115 = add i64 %t113, 1
  %t117 = load ptr, ptr %l45, !tbaa !29
  %t118 = getelementptr %"compiler/emit:fnEm", ptr %t117, i32 0, i32 15
  store i64 %t115, ptr %t118, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t120 = extractvalue { i64, ptr } { i64 1, ptr @.d217 }, 1
  %t121 = extractvalue { i64, ptr } { i64 1, ptr @.d217 }, 0
  %t123 = extractvalue { i64, ptr } %t119, 1
  %t124 = extractvalue { i64, ptr } %t119, 0
  %t125 = add i64 %t121, %t124
  %t126 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t125)
  call void @olang_textcopy(ptr %t126, ptr %t120, i64 %t121)
  %t127 = getelementptr i8, ptr %t126, i64 %t121
  call void @olang_textcopy(ptr %t127, ptr %t123, i64 %t124)
  %t128 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t126, 1
  store { i64, ptr } %t129, ptr %l7, !tbaa !27
  %t131 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t133 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eHash(ptr %s0, { i64, ptr } %t131)
  store i64 %t133, ptr %l51
  br label %bb15
bb15:
  %t134 = load i64, ptr %l51, !tbaa !24
  store i64 %t134, ptr %l52, !tbaa !65
  %t135 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 16)
  %t136 = extractvalue { i32, i64 } %t135, 1
  %t137 = extractvalue { i32, i64 } %t135, 0
  store i32 %t137, ptr %l54
  %t138 = icmp ne i32 %t137, 0
  br i1 %t138, label %bb17, label %ok.139
ok.139:
  store i64 %t136, ptr %l53
  br label %bb16
bb16:
  %t140 = load i64, ptr %l52, !tbaa !65
  %t141 = load i64, ptr %l53, !tbaa !24
  %t142 = call { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %s0, i64 %t140, i64 %t141)
  store { i64, ptr } %t142, ptr %l55
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_6a1c0f36bb2af484_15693b919ea68168)
  unreachable
bb18:
  %t143 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t145 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eHash(ptr %s0, { i64, ptr } %t143)
  store i64 %t145, ptr %l57
  br label %bb19
bb19:
  %t146 = load i64, ptr %l57, !tbaa !24
  store i64 %t146, ptr %l58, !tbaa !65
  %t147 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 16)
  %t148 = extractvalue { i32, i64 } %t147, 1
  %t149 = extractvalue { i32, i64 } %t147, 0
  store i32 %t149, ptr %l60
  %t150 = icmp ne i32 %t149, 0
  br i1 %t150, label %bb21, label %ok.151
ok.151:
  store i64 %t148, ptr %l59
  br label %bb20
bb20:
  %t152 = load i64, ptr %l58, !tbaa !65
  %t153 = load i64, ptr %l59, !tbaa !24
  %t154 = call { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %s0, i64 %t152, i64 %t153)
  store { i64, ptr } %t154, ptr %l61
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_6a1c0f36bb2af484_15693b919ea68168)
  unreachable
bb22:
  %t155 = extractvalue { i64, ptr } { i64 10, ptr @.d218 }, 1
  %t156 = extractvalue { i64, ptr } { i64 10, ptr @.d218 }, 0
  %t157 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t157, 1
  %t159 = extractvalue { i64, ptr } %t157, 0
  %t160 = add i64 %t156, %t159
  %t161 = extractvalue { i64, ptr } { i64 1, ptr @.d219 }, 1
  %t162 = extractvalue { i64, ptr } { i64 1, ptr @.d219 }, 0
  %t163 = add i64 %t160, %t162
  %t164 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t164, 1
  %t166 = extractvalue { i64, ptr } %t164, 0
  %t167 = add i64 %t163, %t166
  %t168 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t167)
  call void @olang_textcopy(ptr %t168, ptr %t155, i64 %t156)
  %t169 = getelementptr i8, ptr %t168, i64 %t156
  call void @olang_textcopy(ptr %t169, ptr %t158, i64 %t159)
  %t170 = getelementptr i8, ptr %t169, i64 %t159
  call void @olang_textcopy(ptr %t170, ptr %t161, i64 %t162)
  %t171 = getelementptr i8, ptr %t170, i64 %t162
  call void @olang_textcopy(ptr %t171, ptr %t165, i64 %t166)
  %t172 = insertvalue { i64, ptr } undef, i64 %t167, 0
  %t173 = insertvalue { i64, ptr } %t172, ptr %t168, 1
  store { i64, ptr } %t173, ptr %l8, !tbaa !27
  %t175 = load ptr, ptr %l3, !tbaa !29
  %t177 = getelementptr %"compiler/emit:Emitter", ptr %t175, i32 0, i32 18
  %t178 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t181 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %s0, ptr %t177, { i64, ptr } %t178)
  store i1 %t181, ptr %l66
  br label %bb23
bb23:
  %t182 = load i1, ptr %l66, !tbaa !21
  %t183 = xor i1 %t182, true
  br i1 %t183, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s8
  %t185 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t185, ptr %l68, !tbaa !27
  %t186 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t186, 0
  %t190 = add i64 %t188, 1
  store i64 %t190, ptr %l71, !tbaa !24
  %t191 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t193 = call { i64, ptr } @compiler_2femit_2eescape(ptr %s0, ptr %s8, { i64, ptr } %t191)
  store { i64, ptr } %t193, ptr %l73
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t194 = extractvalue { i64, ptr } { i64 1, ptr @.d220 }, 1
  %t195 = extractvalue { i64, ptr } { i64 1, ptr @.d220 }, 0
  %t196 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t197 = extractvalue { i64, ptr } %t196, 1
  %t198 = extractvalue { i64, ptr } %t196, 0
  %t199 = add i64 %t195, %t198
  %t200 = extractvalue { i64, ptr } { i64 22, ptr @.d221 }, 1
  %t201 = extractvalue { i64, ptr } { i64 22, ptr @.d221 }, 0
  %t202 = add i64 %t199, %t201
  %t203 = load i64, ptr %l71, !tbaa !24
  %t204 = call i64 @__olang_fmt_i64(ptr null, i64 %t203)
  %t205 = add i64 %t202, %t204
  %t206 = extractvalue { i64, ptr } { i64 9, ptr @.d222 }, 1
  %t207 = extractvalue { i64, ptr } { i64 9, ptr @.d222 }, 0
  %t208 = add i64 %t205, %t207
  %t209 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t210 = extractvalue { i64, ptr } %t209, 1
  %t211 = extractvalue { i64, ptr } %t209, 0
  %t212 = add i64 %t208, %t211
  %t213 = extractvalue { i64, ptr } { i64 5, ptr @.d223 }, 1
  %t214 = extractvalue { i64, ptr } { i64 5, ptr @.d223 }, 0
  %t215 = add i64 %t212, %t214
  %t216 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t215)
  call void @olang_textcopy(ptr %t216, ptr %t194, i64 %t195)
  %t217 = getelementptr i8, ptr %t216, i64 %t195
  call void @olang_textcopy(ptr %t217, ptr %t197, i64 %t198)
  %t218 = getelementptr i8, ptr %t217, i64 %t198
  call void @olang_textcopy(ptr %t218, ptr %t200, i64 %t201)
  %t219 = getelementptr i8, ptr %t218, i64 %t201
  %t220 = call i64 @__olang_fmt_i64(ptr %t219, i64 %t203)
  %t221 = getelementptr i8, ptr %t219, i64 %t204
  call void @olang_textcopy(ptr %t221, ptr %t206, i64 %t207)
  %t222 = getelementptr i8, ptr %t221, i64 %t207
  call void @olang_textcopy(ptr %t222, ptr %t210, i64 %t211)
  %t223 = getelementptr i8, ptr %t222, i64 %t211
  call void @olang_textcopy(ptr %t223, ptr %t213, i64 %t214)
  %t224 = insertvalue { i64, ptr } undef, i64 %t215, 0
  %t225 = insertvalue { i64, ptr } %t224, ptr %t216, 1
  %t227 = load ptr, ptr %l3, !tbaa !29
  %t228 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t229 = load i64, ptr @G_2ecompiler_2femit_2eHomeLoc, !tbaa !24
  %t231 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t232 = extractvalue { i64, ptr } { i64 1, ptr @.d224 }, 1
  %t233 = extractvalue { i64, ptr } { i64 1, ptr @.d224 }, 0
  %t235 = extractvalue { i64, ptr } %t231, 1
  %t236 = extractvalue { i64, ptr } %t231, 0
  %t237 = add i64 %t233, %t236
  %t238 = extractvalue { i64, ptr } { i64 30, ptr @.d225 }, 1
  %t239 = extractvalue { i64, ptr } { i64 30, ptr @.d225 }, 0
  %t240 = add i64 %t237, %t239
  %t241 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t240)
  call void @olang_textcopy(ptr %t241, ptr %t232, i64 %t233)
  %t242 = getelementptr i8, ptr %t241, i64 %t233
  call void @olang_textcopy(ptr %t242, ptr %t235, i64 %t236)
  %t243 = getelementptr i8, ptr %t242, i64 %t236
  call void @olang_textcopy(ptr %t243, ptr %t238, i64 %t239)
  %t244 = insertvalue { i64, ptr } undef, i64 %t240, 0
  %t245 = insertvalue { i64, ptr } %t244, ptr %t241, 1
  %t247 = extractvalue { i64, ptr } %t245, 0
  %t248 = extractvalue { i64, ptr } %t245, 1
  %t249 = mul i64 %t247, 1
  %t250 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t249)
  call void @llvm.memcpy.p0.p0.i64(ptr %t250, ptr %t248, i64 %t249, i1 false)
  %t251 = insertvalue { i64, ptr } undef, i64 %t247, 0
  %t252 = insertvalue { i64, ptr } %t251, ptr %t250, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %s0, ptr %s8, ptr %s8, ptr %t227, { i64, ptr } %t228, i64 %t229, { i64, ptr } %t225, { i64, ptr } %t252)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s8)
  br label %bb28
bb28:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t260 = getelementptr %"compiler/emit:fnEm", ptr %t258, i32 0, i32 16
  %t261 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t263 = extractvalue { i64, ptr } %t261, 1
  %t264 = extractvalue { i64, ptr } %t261, 0
  %t265 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t264)
  call void @olang_textcopy(ptr %t265, ptr %t263, i64 %t264)
  %t266 = insertvalue { i64, ptr } undef, i64 %t264, 0
  %t267 = insertvalue { i64, ptr } %t266, ptr %t265, 1
  %t269 = extractvalue { i64, ptr } %t267, 0
  %t270 = extractvalue { i64, ptr } %t267, 1
  %t271 = mul i64 %t269, 1
  %t272 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t271)
  call void @llvm.memcpy.p0.p0.i64(ptr %t272, ptr %t270, i64 %t271, i1 false)
  %t273 = insertvalue { i64, ptr } undef, i64 %t269, 0
  %t274 = insertvalue { i64, ptr } %t273, ptr %t272, 1
  %t275 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t276 = extractvalue { i64, ptr } { i64 1, ptr @.d226 }, 1
  %t277 = extractvalue { i64, ptr } { i64 1, ptr @.d226 }, 0
  %t279 = extractvalue { i64, ptr } %t275, 1
  %t280 = extractvalue { i64, ptr } %t275, 0
  %t281 = add i64 %t277, %t280
  %t282 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t281)
  call void @olang_textcopy(ptr %t282, ptr %t276, i64 %t277)
  %t283 = getelementptr i8, ptr %t282, i64 %t277
  call void @olang_textcopy(ptr %t283, ptr %t279, i64 %t280)
  %t284 = insertvalue { i64, ptr } undef, i64 %t281, 0
  %t285 = insertvalue { i64, ptr } %t284, ptr %t282, 1
  %t287 = extractvalue { i64, ptr } %t285, 0
  %t288 = extractvalue { i64, ptr } %t285, 1
  %t289 = mul i64 %t287, 1
  %t290 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t289)
  call void @llvm.memcpy.p0.p0.i64(ptr %t290, ptr %t288, i64 %t289, i1 false)
  %t291 = insertvalue { i64, ptr } undef, i64 %t287, 0
  %t292 = insertvalue { i64, ptr } %t291, ptr %t290, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v0, ptr %v0, ptr %v0, ptr %t260, { i64, ptr } %t274, { i64, ptr } %t292)
  br label %bb29
bb29:
  %t296 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t297 = extractvalue { i64, ptr } { i64 1, ptr @.d227 }, 1
  %t298 = extractvalue { i64, ptr } { i64 1, ptr @.d227 }, 0
  %t300 = extractvalue { i64, ptr } %t296, 1
  %t301 = extractvalue { i64, ptr } %t296, 0
  %t302 = add i64 %t298, %t301
  %t303 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t302)
  call void @olang_textcopy(ptr %t303, ptr %t297, i64 %t298)
  %t304 = getelementptr i8, ptr %t303, i64 %t298
  call void @olang_textcopy(ptr %t304, ptr %t300, i64 %t301)
  %t305 = insertvalue { i64, ptr } undef, i64 %t302, 0
  %t306 = insertvalue { i64, ptr } %t305, ptr %t303, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t306, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eparts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, %"compiler/mir:Range" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %lp5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l25 = alloca i64
  %l28 = alloca i64
  %l46 = alloca ptr
  %l50 = alloca { i64, [4 x i64] }
  %l51 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l69 = alloca i64
  %l76 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l78 = alloca i64
  %l79 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s0, ptr %t1, i32 %a1)
  store { i64, ptr } %t5, ptr %l15
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t6, ptr %l4, !tbaa !27
  store { i64, ptr } { i64 5, ptr @.d228 }, ptr %l16, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t7, ptr %l17, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l18, !tbaa !24
  %t10 = load i64, ptr %l18, !tbaa !24
  %t11 = mul i64 %t10, 1
  %t12 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l19, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l18, !tbaa !24
  %t20 = mul i64 %t19, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %t18, i64 %t20, i1 false)
  %t21 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t21, ptr %lp5
  %t22 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t23 = load ptr, ptr %lp5
  store { i64, ptr } %t22, ptr %t23, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t24 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  store i64 %t26, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t28 = load i64, ptr %l7, !tbaa !24
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = icmp sgt i64 %t28, %t29
  br i1 %t32, label %bb2, label %bb3
bb2:
  %t34 = load i64, ptr %l8, !tbaa !24
  %t36 = icmp sgt i64 %t34, 0
  br i1 %t36, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb7
bb4:
  %t38 = load i64, ptr %l7, !tbaa !24
  %t39 = load i64, ptr %l6, !tbaa !24
  %t42 = sub i64 %t38, %t39
  %t43 = load i64, ptr %l8, !tbaa !24
  %t46 = add i64 %t42, %t43
  %t48 = sub i64 %t46, 1
  %t49 = load i64, ptr %l8, !tbaa !24
  %t52 = sdiv i64 %t48, %t49
  store i64 %t52, ptr %l28, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb6
bb6:
  %t54 = load i64, ptr %l28, !tbaa !24
  store i64 %t54, ptr %l25, !tbaa !24
  br label %bb7
bb7:
  %t55 = load i64, ptr %l25, !tbaa !24
  store i64 %t55, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t56 = load i64, ptr %l10, !tbaa !24
  %t57 = load i64, ptr %l9, !tbaa !24
  %t60 = icmp slt i64 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb10:
  br label %bb11
bb11:
  %t64 = load i64, ptr %l6, !tbaa !24
  %t65 = load i64, ptr %l10, !tbaa !24
  %t66 = load i64, ptr %l8, !tbaa !24
  %t69 = mul i64 %t65, %t66
  %t72 = add i64 %t64, %t69
  store i64 %t72, ptr %l11, !tbaa !24
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l46, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = load i64, ptr %l11, !tbaa !24
  %t81 = call { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %t75, %"compiler/mir:Range" %a3, i64 %t77)
  store { i64, [4 x i64] } %t81, ptr %l50
  br label %bb12
bb12:
  %t82 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t82, ptr %l51, !tbaa !27
  %t83 = load i64, ptr %l11, !tbaa !24
  %t85 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr i32, ptr %t86, i64 %t83
  %t88 = load i32, ptr %t87, !tbaa !33
  %t89 = load ptr, ptr %l46, !tbaa !29
  %t90 = load { i64, [4 x i64] }, ptr %l50
  %t92 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s2, ptr %t89, { i64, [4 x i64] } %t90, i32 %t88)
  store { i64, ptr } %t92, ptr %l54
  br label %bb13
bb13:
  %t93 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t93, ptr %l12, !tbaa !27
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l55, !tbaa !29
  %t95 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t95, ptr %l56, !tbaa !27
  %t96 = load ptr, ptr %lp5
  %t97 = load { i64, ptr }, ptr %t96, !tbaa !27
  store { i64, ptr } %t97, ptr %l57, !tbaa !27
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t99, ptr %l59, !tbaa !27
  %t100 = load i64, ptr %l11, !tbaa !24
  %t102 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr i32, ptr %t103, i64 %t100
  %t105 = load i32, ptr %t104, !tbaa !33
  %t108 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s2, ptr %t98, i32 %t105)
  store { i64, ptr } %t108, ptr %l62
  br label %bb14
bb14:
  %t109 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t110 = load i64, ptr %l11, !tbaa !24
  %t111 = extractvalue { i64, ptr } { i64 12, ptr @.d229 }, 1
  %t112 = extractvalue { i64, ptr } { i64 12, ptr @.d229 }, 0
  %t113 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 1
  %t115 = extractvalue { i64, ptr } %t113, 0
  %t116 = add i64 %t112, %t115
  %t117 = extractvalue { i64, ptr } { i64 1, ptr @.d230 }, 1
  %t118 = extractvalue { i64, ptr } { i64 1, ptr @.d230 }, 0
  %t119 = add i64 %t116, %t118
  %t120 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t120, 1
  %t122 = extractvalue { i64, ptr } %t120, 0
  %t123 = add i64 %t119, %t122
  %t124 = extractvalue { i64, ptr } { i64 2, ptr @.d231 }, 1
  %t125 = extractvalue { i64, ptr } { i64 2, ptr @.d231 }, 0
  %t126 = add i64 %t123, %t125
  %t127 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t127, 1
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t130 = add i64 %t126, %t129
  %t131 = extractvalue { i64, ptr } { i64 1, ptr @.d232 }, 1
  %t132 = extractvalue { i64, ptr } { i64 1, ptr @.d232 }, 0
  %t133 = add i64 %t130, %t132
  %t135 = extractvalue { i64, ptr } %t109, 1
  %t136 = extractvalue { i64, ptr } %t109, 0
  %t137 = add i64 %t133, %t136
  %t138 = extractvalue { i64, ptr } { i64 2, ptr @.d233 }, 1
  %t139 = extractvalue { i64, ptr } { i64 2, ptr @.d233 }, 0
  %t140 = add i64 %t137, %t139
  %t142 = call i64 @__olang_fmt_i64(ptr null, i64 %t110)
  %t143 = add i64 %t140, %t142
  %t144 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t143)
  call void @olang_textcopy(ptr %t144, ptr %t111, i64 %t112)
  %t145 = getelementptr i8, ptr %t144, i64 %t112
  call void @olang_textcopy(ptr %t145, ptr %t114, i64 %t115)
  %t146 = getelementptr i8, ptr %t145, i64 %t115
  call void @olang_textcopy(ptr %t146, ptr %t117, i64 %t118)
  %t147 = getelementptr i8, ptr %t146, i64 %t118
  call void @olang_textcopy(ptr %t147, ptr %t121, i64 %t122)
  %t148 = getelementptr i8, ptr %t147, i64 %t122
  call void @olang_textcopy(ptr %t148, ptr %t124, i64 %t125)
  %t149 = getelementptr i8, ptr %t148, i64 %t125
  call void @olang_textcopy(ptr %t149, ptr %t128, i64 %t129)
  %t150 = getelementptr i8, ptr %t149, i64 %t129
  call void @olang_textcopy(ptr %t150, ptr %t131, i64 %t132)
  %t151 = getelementptr i8, ptr %t150, i64 %t132
  call void @olang_textcopy(ptr %t151, ptr %t135, i64 %t136)
  %t152 = getelementptr i8, ptr %t151, i64 %t136
  call void @olang_textcopy(ptr %t152, ptr %t138, i64 %t139)
  %t153 = getelementptr i8, ptr %t152, i64 %t139
  %t154 = call i64 @__olang_fmt_i64(ptr %t153, i64 %t110)
  %t155 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t144, 1
  %t158 = extractvalue { i64, ptr } %t156, 0
  %t159 = extractvalue { i64, ptr } %t156, 1
  %t160 = mul i64 %t158, 1
  %t161 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t160)
  call void @llvm.memcpy.p0.p0.i64(ptr %t161, ptr %t159, i64 %t160, i1 false)
  %t162 = insertvalue { i64, ptr } undef, i64 %t158, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t161, 1
  %t164 = load ptr, ptr %l55, !tbaa !29
  %t166 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v2, ptr %v2, ptr %t164, { i64, ptr } %t163)
  store { i64, ptr } %t166, ptr %l67
  br label %bb15
bb15:
  %t167 = load ptr, ptr %lp5
  %t168 = load { i64, ptr }, ptr %t167, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t168, 0
  %t170 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t170, 0
  store i64 %t171, ptr %l69, !tbaa !24
  %t173 = load i64, ptr %l69, !tbaa !24
  %t174 = icmp eq i64 %t169, %t173
  br i1 %t174, label %bb16, label %bb17
bb16:
  %t176 = load ptr, ptr %lp5
  %t177 = getelementptr { i64, ptr }, ptr %t176, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !27
  %t181 = load i64, ptr %l69, !tbaa !24
  %t182 = mul i64 %t181, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t178, ptr %t180, i64 %t182, i1 false)
  br label %bb18
bb17:
  %t183 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t184 = load ptr, ptr %lp5
  store { i64, ptr } %t183, ptr %t184, !tbaa !27
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t185 = load i64, ptr %l10, !tbaa !24
  %t187 = add i64 %t185, 1
  store i64 %t187, ptr %l10, !tbaa !24
  br label %bb8
bb20:
  %t189 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t189, 0
  %t193 = icmp eq i64 %t191, 0
  br i1 %t193, label %bb21, label %bb22
bb21:
  store { i64, ptr } { i64 15, ptr @.d234 }, ptr %l76, !tbaa !27
  %t195 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t195, ptr %l77, !tbaa !27
  %t196 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t197 = extractvalue { i64, ptr } %t196, 0
  store i64 %t197, ptr %l78, !tbaa !24
  %t198 = load i64, ptr %l78, !tbaa !24
  %t199 = mul i64 %t198, 1
  %t200 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t199)
  %t201 = insertvalue { i64, ptr } undef, i64 %t198, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t200, 1
  store { i64, ptr } %t202, ptr %l79, !tbaa !27
  %t203 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !27
  %t205 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !27
  %t207 = load i64, ptr %l78, !tbaa !24
  %t208 = mul i64 %t207, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t204, ptr %t206, i64 %t208, i1 false)
  %t209 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t209, ptr %l77, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t210 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t210, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t211 = load ptr, ptr %lp5
  %t212 = load { i64, ptr }, ptr %t211, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t212, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eslice(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Place" %a1, { i64, [4 x i64] } %a2, { i64, [4 x i64] } %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Place"
  %l2 = alloca { i64, [4 x i64] }
  %l3 = alloca { i64, [4 x i64] }
  %l5 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %lp12 = alloca ptr
  %l19 = alloca i32
  %l22 = alloca i32
  %l25 = alloca i32
  %l28 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l37 = alloca i32
  %l38 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l43 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l47 = alloca i32
  %l48 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca ptr
  %l61 = alloca i32
  %l62 = alloca i32
  %l65 = alloca i1
  %l68 = alloca ptr
  %l74 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/mir:Place" %a1, ptr %l1
  store { i64, [4 x i64] } %a2, ptr %l2
  store { i64, [4 x i64] } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l5, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load %"compiler/mir:Place", ptr %l1
  %t13 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eplaceType(ptr %v0, ptr %t9, %"compiler/mir:Place" %t10)
  store i32 %t13, ptr %l19
  br label %bb1
bb1:
  %t14 = load i32, ptr %l19, !tbaa !23
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t19 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %t15, i32 %t14)
  store i32 %t19, ptr %l22
  br label %bb2
bb2:
  %t20 = load i32, ptr %l22, !tbaa !23
  %t21 = load ptr, ptr %l5, !tbaa !29
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t21, i32 %t20)
  store i32 %t25, ptr %l25
  br label %bb3
bb3:
  %t26 = load i32, ptr %l25, !tbaa !23
  store i32 %t26, ptr %l8, !tbaa !23
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load %"compiler/mir:Place", ptr %l1
  %t31 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edataPtr(ptr %v0, ptr %s0, ptr %t27, %"compiler/mir:Place" %t28)
  store { i64, ptr } %t31, ptr %l28
  br label %bb4
bb4:
  %t32 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t32, ptr %l9, !tbaa !27
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l29, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load { i64, [4 x i64] }, ptr %l2
  %t36 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t40 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s0, ptr %t34, { i64, [4 x i64] } %t35, i32 %t36)
  store { i64, ptr } %t40, ptr %l33
  br label %bb5
bb5:
  %t41 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 0
  %t43 = extractvalue { i64, ptr } %t41, 1
  %t44 = mul i64 %t42, 1
  %t45 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t44)
  call void @llvm.memcpy.p0.p0.i64(ptr %t45, ptr %t43, i64 %t44, i1 false)
  %t46 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  store { i64, ptr } %t47, ptr %l34, !tbaa !27
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load { i64, [4 x i64] }, ptr %l2
  %t52 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t48, { i64, [4 x i64] } %t49)
  store i32 %t52, ptr %l37
  br label %bb6
bb6:
  %t53 = load ptr, ptr %l29, !tbaa !29
  %t54 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t55 = load i32, ptr %l37, !tbaa !23
  %t56 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eindex(ptr %v0, ptr %s0, ptr %s0, ptr %t53, { i64, ptr } %t54, i32 %t55)
  store { i64, ptr } %t56, ptr %l38
  br label %bb7
bb7:
  %t57 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t57, ptr %l10, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l39, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load { i64, [4 x i64] }, ptr %l3
  %t61 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t65 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s0, ptr %t59, { i64, [4 x i64] } %t60, i32 %t61)
  store { i64, ptr } %t65, ptr %l43
  br label %bb8
bb8:
  %t66 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  %t68 = extractvalue { i64, ptr } %t66, 1
  %t69 = mul i64 %t67, 1
  %t70 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t69)
  call void @llvm.memcpy.p0.p0.i64(ptr %t70, ptr %t68, i64 %t69, i1 false)
  %t71 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  store { i64, ptr } %t72, ptr %l44, !tbaa !27
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load { i64, [4 x i64] }, ptr %l3
  %t77 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t73, { i64, [4 x i64] } %t74)
  store i32 %t77, ptr %l47
  br label %bb9
bb9:
  %t78 = load ptr, ptr %l39, !tbaa !29
  %t79 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t80 = load i32, ptr %l47, !tbaa !23
  %t81 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eindex(ptr %v0, ptr %s0, ptr %s0, ptr %t78, { i64, ptr } %t79, i32 %t80)
  store { i64, ptr } %t81, ptr %l48
  br label %bb10
bb10:
  %t82 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t82, ptr %l11, !tbaa !27
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l49, !tbaa !29
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i32, ptr %l8, !tbaa !23
  %t88 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s0, ptr %t84, i32 %t85)
  store { i64, ptr } %t88, ptr %l52
  br label %bb11
bb11:
  %t89 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t91 = extractvalue { i64, ptr } { i64 14, ptr @.d235 }, 1
  %t92 = extractvalue { i64, ptr } { i64 14, ptr @.d235 }, 0
  %t93 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 1
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t96 = add i64 %t92, %t95
  %t97 = extractvalue { i64, ptr } { i64 6, ptr @.d236 }, 1
  %t98 = extractvalue { i64, ptr } { i64 6, ptr @.d236 }, 0
  %t99 = add i64 %t96, %t98
  %t101 = extractvalue { i64, ptr } %t89, 1
  %t102 = extractvalue { i64, ptr } %t89, 0
  %t103 = add i64 %t99, %t102
  %t104 = extractvalue { i64, ptr } { i64 6, ptr @.d237 }, 1
  %t105 = extractvalue { i64, ptr } { i64 6, ptr @.d237 }, 0
  %t106 = add i64 %t103, %t105
  %t108 = extractvalue { i64, ptr } %t90, 1
  %t109 = extractvalue { i64, ptr } %t90, 0
  %t110 = add i64 %t106, %t109
  %t111 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t110)
  call void @olang_textcopy(ptr %t111, ptr %t91, i64 %t92)
  %t112 = getelementptr i8, ptr %t111, i64 %t92
  call void @olang_textcopy(ptr %t112, ptr %t94, i64 %t95)
  %t113 = getelementptr i8, ptr %t112, i64 %t95
  call void @olang_textcopy(ptr %t113, ptr %t97, i64 %t98)
  %t114 = getelementptr i8, ptr %t113, i64 %t98
  call void @olang_textcopy(ptr %t114, ptr %t101, i64 %t102)
  %t115 = getelementptr i8, ptr %t114, i64 %t102
  call void @olang_textcopy(ptr %t115, ptr %t104, i64 %t105)
  %t116 = getelementptr i8, ptr %t115, i64 %t105
  call void @olang_textcopy(ptr %t116, ptr %t108, i64 %t109)
  %t117 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t111, 1
  %t120 = extractvalue { i64, ptr } %t118, 0
  %t121 = extractvalue { i64, ptr } %t118, 1
  %t122 = mul i64 %t120, 1
  %t123 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t122)
  call void @llvm.memcpy.p0.p0.i64(ptr %t123, ptr %t121, i64 %t122, i1 false)
  %t124 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t123, 1
  %t126 = load ptr, ptr %l49, !tbaa !29
  %t128 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t126, { i64, ptr } %t125)
  store { i64, ptr } %t128, ptr %l57
  br label %bb12
bb12:
  %t129 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t129, ptr %lp12
  %t130 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t131 = load ptr, ptr %lp12
  store { i64, ptr } %t130, ptr %t131, !tbaa !27
  %t132 = load ptr, ptr %l5, !tbaa !29
  store ptr %t132, ptr %l58, !tbaa !29
  %t133 = load ptr, ptr %l5, !tbaa !29
  %t137 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t133, i32 %a4)
  store i32 %t137, ptr %l61
  br label %bb13
bb13:
  %t138 = load ptr, ptr %l58, !tbaa !29
  %t139 = load i32, ptr %l61, !tbaa !23
  %t140 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t138, i32 %t139)
  store i32 %t140, ptr %l62
  br label %bb14
bb14:
  %t141 = load i32, ptr %l62, !tbaa !23
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t146 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erunTime(ptr %v0, ptr %t142, i32 %t141)
  store i1 %t146, ptr %l65
  br label %bb15
bb15:
  %t147 = load i1, ptr %l65, !tbaa !21
  %t148 = xor i1 %t147, true
  br i1 %t148, label %bb16, label %bb17
bb16:
  %t150 = load ptr, ptr %lp12
  %t151 = load { i64, ptr }, ptr %t150, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t151, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t153 = load ptr, ptr %l0, !tbaa !29
  store ptr %t153, ptr %l68, !tbaa !29
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t156 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t157 = extractvalue { i64, ptr } { i64 8, ptr @.d238 }, 1
  %t158 = extractvalue { i64, ptr } { i64 8, ptr @.d238 }, 0
  %t160 = extractvalue { i64, ptr } %t155, 1
  %t161 = extractvalue { i64, ptr } %t155, 0
  %t162 = add i64 %t158, %t161
  %t163 = extractvalue { i64, ptr } { i64 2, ptr @.d239 }, 1
  %t164 = extractvalue { i64, ptr } { i64 2, ptr @.d239 }, 0
  %t165 = add i64 %t162, %t164
  %t167 = extractvalue { i64, ptr } %t156, 1
  %t168 = extractvalue { i64, ptr } %t156, 0
  %t169 = add i64 %t165, %t168
  %t170 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t169)
  call void @olang_textcopy(ptr %t170, ptr %t157, i64 %t158)
  %t171 = getelementptr i8, ptr %t170, i64 %t158
  call void @olang_textcopy(ptr %t171, ptr %t160, i64 %t161)
  %t172 = getelementptr i8, ptr %t171, i64 %t161
  call void @olang_textcopy(ptr %t172, ptr %t163, i64 %t164)
  %t173 = getelementptr i8, ptr %t172, i64 %t164
  call void @olang_textcopy(ptr %t173, ptr %t167, i64 %t168)
  %t174 = insertvalue { i64, ptr } undef, i64 %t169, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t170, 1
  %t177 = extractvalue { i64, ptr } %t175, 0
  %t178 = extractvalue { i64, ptr } %t175, 1
  %t179 = mul i64 %t177, 1
  %t180 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t179)
  call void @llvm.memcpy.p0.p0.i64(ptr %t180, ptr %t178, i64 %t179, i1 false)
  %t181 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  %t185 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v1, ptr %t154, { i64, ptr } %t182)
  store { i64, ptr } %t185, ptr %l74
  br label %bb19
bb19:
  %t186 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t186, 0
  %t188 = extractvalue { i64, ptr } %t186, 1
  %t189 = mul i64 %t187, 1
  %t190 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t189)
  call void @llvm.memcpy.p0.p0.i64(ptr %t190, ptr %t188, i64 %t189, i1 false)
  %t191 = insertvalue { i64, ptr } undef, i64 %t187, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t190, 1
  %t193 = load ptr, ptr %lp12
  %t194 = load { i64, ptr }, ptr %t193, !tbaa !27
  %t195 = load ptr, ptr %l68, !tbaa !29
  %t198 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epair(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %t195, { i64, ptr } %t192, { i64, ptr } %t194)
  store { i64, ptr } %t198, ptr %l77
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t199 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t199, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/mir:Place"
  %l4 = alloca { i64, [15 x i64] }
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca { { i64, ptr }, i32 }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %l10 = alloca { i64, [1 x i64] }
  %l11 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i1
  %l15 = alloca i32
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca %"compiler/source:Span"
  %l21 = alloca { i64, [1 x i64] }
  %l22 = alloca i32
  %l23 = alloca { i64, [4 x i64] }
  %l24 = alloca i64
  %l25 = alloca { i64, [1 x i64] }
  %l26 = alloca { i64, [1 x i64] }
  %l27 = alloca i32
  %l28 = alloca { i64, [4 x i64] }
  %l29 = alloca %"compiler/mir:Place"
  %l30 = alloca %"compiler/mir:Place"
  %l31 = alloca { i64, [4 x i64] }
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i32
  %l35 = alloca { i64, ptr }
  %l36 = alloca i32
  %l37 = alloca i32
  %l44 = alloca ptr
  %l46 = alloca %"compiler/source:Span"
  %l47 = alloca ptr
  %l48 = alloca i1
  %l57 = alloca i32
  %l62 = alloca i1
  %l65 = alloca i1
  %l66 = alloca i1
  %l71 = alloca i1
  %l75 = alloca { i64, ptr }
  %l79 = alloca i1
  %l85 = alloca { { i64, ptr }, i32 }
  %l86 = alloca { i64, ptr }
  %l87 = alloca i64
  %l88 = alloca { i64, ptr }
  %l89 = alloca ptr
  %l92 = alloca { i64, ptr }
  %l98 = alloca ptr
  %l99 = alloca i1
  %l109 = alloca %"compiler/mir:Local"
  %l113 = alloca i1
  %l117 = alloca i32
  %l118 = alloca ptr
  %l119 = alloca { i64, [1 x i64] }
  %l122 = alloca i64
  %l124 = alloca { i64, ptr }
  %l127 = alloca i64
  %l128 = alloca { i64, ptr }
  %l134 = alloca ptr
  %l135 = alloca i1
  %l138 = alloca ptr
  %l139 = alloca i1
  %l148 = alloca i1
  %l153 = alloca i1
  %l163 = alloca %"compiler/mir:ScopeInfo"
  %l180 = alloca %"compiler/mir:ScopeInfo"
  %l193 = alloca %"compiler/mir:ScopeInfo"
  %l207 = alloca ptr
  %l208 = alloca i1
  %l217 = alloca i1
  %l218 = alloca i1
  %l223 = alloca i1
  %l229 = alloca %"compiler/mir:ScopeInfo"
  %l234 = alloca ptr
  %l239 = alloca { i64, ptr }
  %l241 = alloca { i64, ptr }
  %l246 = alloca { i64, ptr }
  %l248 = alloca { i64, ptr }
  %l250 = alloca { i64, ptr }
  %l280 = alloca ptr
  %l281 = alloca i1
  %l285 = alloca ptr
  %l286 = alloca i1
  %l293 = alloca ptr
  %l294 = alloca i1
  %l298 = alloca ptr
  %l299 = alloca i1
  %l308 = alloca i64
  %l313 = alloca i64
  %l314 = alloca i32
  %l317 = alloca ptr
  %l320 = alloca { i64, ptr }
  %l334 = alloca i1
  %l346 = alloca ptr
  %l349 = alloca { i64, ptr }
  %l353 = alloca { i64, ptr }
  %l357 = alloca { i64, ptr }
  %l360 = alloca ptr
  %l361 = alloca i1
  %l365 = alloca ptr
  %l366 = alloca i1
  %l370 = alloca ptr
  %l371 = alloca i1
  %l382 = alloca i1
  %l389 = alloca ptr
  %l392 = alloca { i64, ptr }
  %l396 = alloca ptr
  %l397 = alloca i1
  %l408 = alloca { i64, ptr }
  %l411 = alloca { i64, ptr }
  %l412 = alloca ptr
  %l413 = alloca ptr
  %l416 = alloca i32
  %l417 = alloca i32
  %l418 = alloca i32
  %l419 = alloca ptr
  %l420 = alloca ptr
  %l424 = alloca { i64, ptr }
  %l425 = alloca { i64, ptr }
  %l428 = alloca i32
  %l429 = alloca { i64, ptr }
  %l432 = alloca i64
  %l435 = alloca { i64, ptr }
  %l444 = alloca ptr
  %l445 = alloca i1
  %l452 = alloca ptr
  %l453 = alloca i32
  %l459 = alloca %"compiler/mir:Task"
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %s42 = alloca %olang.scope
  %s43 = alloca %olang.scope
  %s44 = alloca %olang.scope
  %s46 = alloca %olang.scope
  %t854 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/emit:fnEm", ptr %t9, i32 0, i32 17
  %t12 = load i64, ptr %t11, !tbaa !24
  %t14 = icmp sge i64 %t12, 0
  br i1 %t14, label %bb1, label %bb2
bb1:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l44, !tbaa !29
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = call %"compiler/source:Span" @compiler_2femit_2estmtSpan(ptr %v1, ptr %t17)
  store %"compiler/source:Span" %t19, ptr %l46
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t20 = load ptr, ptr %l44, !tbaa !29
  %t21 = load %"compiler/source:Span", ptr %l46
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elocate(ptr %v0, ptr %t20, %"compiler/source:Span" %t21)
  br label %bb4
bb4:
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t23 = load ptr, ptr %l47, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = load ptr, ptr %l47, !tbaa !29
  %t27 = load i64, ptr %t26
  %t29 = icmp eq i64 %t27, 0
  store i1 %t29, ptr %l48, !tbaa !21
  br label %bb7
bb7:
  %t30 = load i1, ptr %l48, !tbaa !21
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [21 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } }, ptr %t33, i32 0, i32 1
  %t35 = load %"compiler/mir:Place", ptr %t34
  store %"compiler/mir:Place" %t35, ptr %l3
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [21 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } }, ptr %t39, i32 0, i32 2
  %t41 = load { i64, [15 x i64] }, ptr %t40
  store { i64, [15 x i64] } %t41, ptr %l4
  br label %bb10
bb9:
  br label %bb34
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load %"compiler/mir:Place", ptr %l3
  %t47 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eplaceType(ptr %v0, ptr %t43, %"compiler/mir:Place" %t44)
  store i32 %t47, ptr %l57
  br label %bb11
bb11:
  %t48 = load i32, ptr %l57, !tbaa !23
  store i32 %t48, ptr %l5, !tbaa !23
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load %"compiler/mir:Place", ptr %l3
  %t51 = load i32, ptr %l5, !tbaa !23
  %t52 = load { i64, [15 x i64] }, ptr %l4
  %t57 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efillInPlace(ptr %v0, ptr %t49, %"compiler/mir:Place" %t50, i32 %t51, { i64, [15 x i64] } %t52)
  store i1 %t57, ptr %l62
  br label %bb12
bb12:
  %t58 = load i1, ptr %l62, !tbaa !21
  br i1 %t58, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb14:
  br label %bb15
bb15:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i32, ptr %l5, !tbaa !23
  %t63 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eviaMem(ptr %v0, ptr %t59, i32 %t60)
  store i1 %t63, ptr %l65
  br label %bb16
bb16:
  %t64 = load i1, ptr %l65, !tbaa !21
  br i1 %t64, label %bb17, label %bb18
bb17:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load %"compiler/mir:Place", ptr %l3
  %t67 = load i32, ptr %l5, !tbaa !23
  %t68 = load { i64, [15 x i64] }, ptr %l4
  %t73 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eintoPlace(ptr %v0, ptr %t65, %"compiler/mir:Place" %t66, i32 %t67, { i64, [15 x i64] } %t68)
  store i1 %t73, ptr %l71
  br label %bb19
bb18:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb20
bb19:
  %t74 = load i1, ptr %l71, !tbaa !21
  store i1 %t74, ptr %l66, !tbaa !21
  br label %bb20
bb20:
  %t75 = load i1, ptr %l66, !tbaa !21
  br i1 %t75, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb22:
  br label %bb23
bb23:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load { i64, [15 x i64] }, ptr %l4
  %t78 = load i32, ptr %l5, !tbaa !23
  %t82 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ervalue(ptr %v0, ptr %s2, ptr %t76, { i64, [15 x i64] } %t77, i32 %t78)
  store { i64, ptr } %t82, ptr %l75
  br label %bb24
bb24:
  %t83 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t83, ptr %l6, !tbaa !27
  %t84 = load i32, ptr %l5, !tbaa !23
  %t85 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t88 = icmp eq i32 %t84, %t85
  br i1 %t88, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb27
bb26:
  %t90 = load i32, ptr %l5, !tbaa !23
  %t91 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t94 = icmp eq i32 %t90, %t91
  store i1 %t94, ptr %l79, !tbaa !21
  br label %bb27
bb27:
  %t96 = load i1, ptr %l79, !tbaa !21
  br i1 %t96, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb29:
  br label %bb30
bb30:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load %"compiler/mir:Place", ptr %l3
  %t101 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %s2, ptr %t97, %"compiler/mir:Place" %t98)
  store { { i64, ptr }, i32 } %t101, ptr %l85
  br label %bb31
bb31:
  %t102 = load { { i64, ptr }, i32 }, ptr %l85
  store { { i64, ptr }, i32 } %t102, ptr %l7
  %t103 = getelementptr { { i64, ptr }, i32 }, ptr %l7, i32 0, i32 0
  %t104 = load { i64, ptr }, ptr %t103, !tbaa !27
  store { i64, ptr } %t104, ptr %l86, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t105, 0
  store i64 %t106, ptr %l87, !tbaa !24
  %t107 = load i64, ptr %l87, !tbaa !24
  %t108 = mul i64 %t107, 1
  %t109 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t108)
  %t110 = insertvalue { i64, ptr } undef, i64 %t107, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  store { i64, ptr } %t111, ptr %l88, !tbaa !27
  %t112 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = load i64, ptr %l87, !tbaa !24
  %t117 = mul i64 %t116, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t113, ptr %t115, i64 %t117, i1 false)
  %t118 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t118, ptr %l8, !tbaa !27
  %t119 = load ptr, ptr %l0, !tbaa !29
  store ptr %t119, ptr %l89, !tbaa !29
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load i32, ptr %l5, !tbaa !23
  %t124 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s2, ptr %t120, i32 %t121)
  store { i64, ptr } %t124, ptr %l92
  br label %bb32
bb32:
  %t125 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t125, 0
  %t127 = extractvalue { i64, ptr } %t125, 1
  %t128 = mul i64 %t126, 1
  %t129 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t128)
  call void @llvm.memcpy.p0.p0.i64(ptr %t129, ptr %t127, i64 %t128, i1 false)
  %t130 = insertvalue { i64, ptr } undef, i64 %t126, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t129, 1
  %t132 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/emit:fnEm", ptr %t134, i32 0, i32 14
  %t137 = load { i64, ptr }, ptr %t136, !tbaa !27
  %t138 = load ptr, ptr %l89, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s2, ptr %s2, ptr %s2, ptr %v0, ptr %t138, { i64, ptr } %t131, { i64, ptr } %t132, { i64, ptr } %t133, { i64, ptr } %t137)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s2)
  br label %bb231
bb34:
  %t143 = load ptr, ptr %l1, !tbaa !29
  store ptr %t143, ptr %l98, !tbaa !29
  store i1 false, ptr %l99, !tbaa !21
  %t144 = load ptr, ptr %l98, !tbaa !29
  %t145 = icmp ne ptr %t144, null
  br i1 %t145, label %bb35, label %bb36
bb35:
  %t147 = load ptr, ptr %l98, !tbaa !29
  %t148 = load i64, ptr %t147
  %t150 = icmp eq i64 %t148, 1
  store i1 %t150, ptr %l99, !tbaa !21
  br label %bb36
bb36:
  %t151 = load i1, ptr %l99, !tbaa !21
  br i1 %t151, label %bb37, label %bb38
bb37:
  %t152 = load ptr, ptr %l1, !tbaa !29
  %t154 = getelementptr { i64, [21 x i64] }, ptr %t152, i32 0, i32 1
  %t155 = getelementptr { %"compiler/source:Span", i32 }, ptr %t154, i32 0, i32 1
  %t156 = load i32, ptr %t155
  store i32 %t156, ptr %l9, !tbaa !23
  br label %bb39
bb38:
  br label %bb50
bb39:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/emit:fnEm", ptr %t158, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = getelementptr %"compiler/mir:Fn", ptr %t161, i32 0, i32 7
  %t164 = load i32, ptr %l9, !tbaa !23
  %t166 = sext i32 %t164 to i64
  %t169 = call %"compiler/mir:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t163, i64 %t166)
  store %"compiler/mir:Local" %t169, ptr %l109
  br label %bb40
bb40:
  %t170 = getelementptr %"compiler/mir:Local", ptr %l109, i32 0, i32 4
  %t171 = load { i64, [1 x i64] }, ptr %t170
  store { i64, [1 x i64] } %t171, ptr %l10
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load { i64, [1 x i64] }, ptr %l10
  %t177 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eisFrame(ptr %v0, ptr %t173, { i64, [1 x i64] } %t174)
  store i1 %t177, ptr %l113
  br label %bb41
bb41:
  %t178 = load i1, ptr %l113, !tbaa !21
  %t179 = xor i1 %t178, true
  br i1 %t179, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s7
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load i32, ptr %l9, !tbaa !23
  %t185 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalType(ptr %v0, ptr %t181, i32 %t182)
  store i32 %t185, ptr %l117
  br label %bb44
bb43:
  br label %bb49
bb44:
  %t186 = load i32, ptr %l117, !tbaa !23
  store i32 %t186, ptr %l11, !tbaa !23
  %t187 = load ptr, ptr %l0, !tbaa !29
  store ptr %t187, ptr %l118, !tbaa !29
  %t188 = load { i64, [1 x i64] }, ptr %l10
  store { i64, [1 x i64] } %t188, ptr %l119
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load i32, ptr %l11, !tbaa !23
  %t193 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t189, i32 %t190)
  store i64 %t193, ptr %l122
  br label %bb45
bb45:
  %t194 = load i64, ptr %l122, !tbaa !24
  %t195 = call i64 @__olang_fmt_i64(ptr null, i64 %t194)
  %t196 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t195)
  %t197 = call i64 @__olang_fmt_i64(ptr %t196, i64 %t194)
  %t198 = insertvalue { i64, ptr } undef, i64 %t195, 0
  %t199 = insertvalue { i64, ptr } %t198, ptr %t196, 1
  %t201 = extractvalue { i64, ptr } %t199, 0
  %t202 = extractvalue { i64, ptr } %t199, 1
  %t203 = mul i64 %t201, 1
  %t204 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t203)
  call void @llvm.memcpy.p0.p0.i64(ptr %t204, ptr %t202, i64 %t203, i1 false)
  %t205 = insertvalue { i64, ptr } undef, i64 %t201, 0
  %t206 = insertvalue { i64, ptr } %t205, ptr %t204, 1
  store { i64, ptr } %t206, ptr %l124, !tbaa !27
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load i32, ptr %l11, !tbaa !23
  %t211 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ealign(ptr %v0, ptr %t207, i32 %t208)
  store i64 %t211, ptr %l127
  br label %bb46
bb46:
  %t212 = load ptr, ptr %l118, !tbaa !29
  %t213 = load { i64, [1 x i64] }, ptr %l119
  %t214 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t215 = load i64, ptr %l127, !tbaa !24
  %t216 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloc(ptr %v0, ptr %s7, ptr %s7, ptr %s7, ptr %t212, { i64, [1 x i64] } %t213, { i64, ptr } %t214, i64 %t215, { i64, ptr } { i64 0, ptr @.d240 })
  store { i64, ptr } %t216, ptr %l128
  br label %bb47
bb47:
  %t217 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t220 = load i32, ptr %l9, !tbaa !23
  %t221 = extractvalue { i64, ptr } { i64 3, ptr @.d241 }, 1
  %t222 = extractvalue { i64, ptr } { i64 3, ptr @.d241 }, 0
  %t224 = sext i32 %t220 to i64
  %t225 = call i64 @__olang_fmt_i64(ptr null, i64 %t224)
  %t226 = add i64 %t222, %t225
  %t227 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t226)
  call void @olang_textcopy(ptr %t227, ptr %t221, i64 %t222)
  %t228 = getelementptr i8, ptr %t227, i64 %t222
  %t229 = call i64 @__olang_fmt_i64(ptr %t228, i64 %t224)
  %t230 = insertvalue { i64, ptr } undef, i64 %t226, 0
  %t231 = insertvalue { i64, ptr } %t230, ptr %t227, 1
  %t233 = extractvalue { i64, ptr } %t231, 0
  %t234 = extractvalue { i64, ptr } %t231, 1
  %t235 = mul i64 %t233, 1
  %t236 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t235)
  call void @llvm.memcpy.p0.p0.i64(ptr %t236, ptr %t234, i64 %t235, i1 false)
  %t237 = insertvalue { i64, ptr } undef, i64 %t233, 0
  %t238 = insertvalue { i64, ptr } %t237, ptr %t236, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s7, ptr %s7, ptr %s7, ptr %s7, ptr %t218, { i64, ptr } { i64 3, ptr @.d242 }, { i64, ptr } %t217, { i64, ptr } %t238, { i64, ptr } { i64 0, ptr @.d243 })
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s7)
  br label %bb49
bb49:
  br label %bb231
bb50:
  %t242 = load ptr, ptr %l1, !tbaa !29
  store ptr %t242, ptr %l134, !tbaa !29
  store i1 false, ptr %l135, !tbaa !21
  %t243 = load ptr, ptr %l134, !tbaa !29
  %t244 = icmp ne ptr %t243, null
  br i1 %t244, label %bb51, label %bb52
bb51:
  %t246 = load ptr, ptr %l134, !tbaa !29
  %t247 = load i64, ptr %t246
  %t249 = icmp eq i64 %t247, 2
  store i1 %t249, ptr %l135, !tbaa !21
  br label %bb52
bb52:
  %t250 = load i1, ptr %l135, !tbaa !21
  br i1 %t250, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb231
bb56:
  %t251 = load ptr, ptr %l1, !tbaa !29
  store ptr %t251, ptr %l138, !tbaa !29
  store i1 false, ptr %l139, !tbaa !21
  %t252 = load ptr, ptr %l138, !tbaa !29
  %t253 = icmp ne ptr %t252, null
  br i1 %t253, label %bb57, label %bb58
bb57:
  %t255 = load ptr, ptr %l138, !tbaa !29
  %t256 = load i64, ptr %t255
  %t258 = icmp eq i64 %t256, 3
  store i1 %t258, ptr %l139, !tbaa !21
  br label %bb58
bb58:
  %t259 = load i1, ptr %l139, !tbaa !21
  br i1 %t259, label %bb59, label %bb60
bb59:
  %t260 = load ptr, ptr %l1, !tbaa !29
  %t262 = getelementptr { i64, [21 x i64] }, ptr %t260, i32 0, i32 1
  %t263 = getelementptr { %"compiler/source:Span", i32 }, ptr %t262, i32 0, i32 1
  %t264 = load i32, ptr %t263
  store i32 %t264, ptr %l13, !tbaa !23
  br label %bb61
bb60:
  br label %bb93
bb61:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t268 = getelementptr %"compiler/emit:fnEm", ptr %t266, i32 0, i32 24
  %t269 = load i32, ptr %l13, !tbaa !23
  %t271 = sext i32 %t269 to i64
  %t274 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t268, i64 %t271)
  store i1 %t274, ptr %l148
  br label %bb62
bb62:
  %t275 = load i1, ptr %l148, !tbaa !21
  br i1 %t275, label %bb63, label %bb64
bb63:
  br label %ret
bb64:
  br label %bb65
bb65:
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t278 = getelementptr %"compiler/emit:fnEm", ptr %t276, i32 0, i32 23
  %t279 = load i32, ptr %l13, !tbaa !23
  %t281 = sext i32 %t279 to i64
  %t284 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t278, i64 %t281)
  store i1 %t284, ptr %l153
  br label %bb66
bb66:
  %t285 = load i1, ptr %l153, !tbaa !21
  br i1 %t285, label %bb67, label %bb68
bb67:
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = getelementptr %"compiler/emit:fnEm", ptr %t286, i32 0, i32 25
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aWriteKind_3e_2eCle_H5b7b223941fd921209e2fd14e30a86e3(ptr %v0, ptr %t288)
  br label %bb69
bb68:
  br label %bb71
bb69:
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t292 = getelementptr %"compiler/emit:fnEm", ptr %t290, i32 0, i32 26
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e_2eClear_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t292)
  br label %bb70
bb70:
  br label %ret
bb71:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t296 = getelementptr %"compiler/emit:fnEm", ptr %t294, i32 0, i32 1
  %t297 = load ptr, ptr %t296, !tbaa !29
  %t299 = getelementptr %"compiler/mir:Fn", ptr %t297, i32 0, i32 8
  %t300 = load i32, ptr %l13, !tbaa !23
  %t302 = sext i32 %t300 to i64
  %t305 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t299, i64 %t302)
  store %"compiler/mir:ScopeInfo" %t305, ptr %l163
  br label %bb72
bb72:
  %t306 = getelementptr %"compiler/mir:ScopeInfo", ptr %l163, i32 0, i32 0
  %t307 = load i32, ptr %t306
  %t309 = trunc i64 6 to i32
  %t310 = icmp eq i32 %t307, %t309
  br i1 %t310, label %bb73, label %bb74
bb73:
  store %olang.scope zeroinitializer, ptr %s14
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t313 = load i32, ptr %l13, !tbaa !23
  %t314 = extractvalue { i64, ptr } { i64 76, ptr @.d244 }, 1
  %t315 = extractvalue { i64, ptr } { i64 76, ptr @.d244 }, 0
  %t317 = sext i32 %t313 to i64
  %t318 = call i64 @__olang_fmt_i64(ptr null, i64 %t317)
  %t319 = add i64 %t315, %t318
  %t320 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t319)
  call void @olang_textcopy(ptr %t320, ptr %t314, i64 %t315)
  %t321 = getelementptr i8, ptr %t320, i64 %t315
  %t322 = call i64 @__olang_fmt_i64(ptr %t321, i64 %t317)
  %t323 = insertvalue { i64, ptr } undef, i64 %t319, 0
  %t324 = insertvalue { i64, ptr } %t323, ptr %t320, 1
  %t326 = extractvalue { i64, ptr } %t324, 0
  %t327 = extractvalue { i64, ptr } %t324, 1
  %t328 = mul i64 %t326, 1
  %t329 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t328)
  call void @llvm.memcpy.p0.p0.i64(ptr %t329, ptr %t327, i64 %t328, i1 false)
  %t330 = insertvalue { i64, ptr } undef, i64 %t326, 0
  %t331 = insertvalue { i64, ptr } %t330, ptr %t329, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s14, ptr %t312, { i64, ptr } %t331)
  br label %bb75
bb74:
  store %olang.scope zeroinitializer, ptr %s17
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t336 = getelementptr %"compiler/emit:fnEm", ptr %t334, i32 0, i32 1
  %t337 = load ptr, ptr %t336, !tbaa !29
  %t339 = getelementptr %"compiler/mir:Fn", ptr %t337, i32 0, i32 8
  %t340 = load i32, ptr %l13, !tbaa !23
  %t342 = sext i32 %t340 to i64
  %t345 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t339, i64 %t342)
  store %"compiler/mir:ScopeInfo" %t345, ptr %l180
  br label %bb77
bb75:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t347 = load i32, ptr %l13, !tbaa !23
  %t348 = load i32, ptr %l13, !tbaa !23
  %t349 = extractvalue { i64, ptr } { i64 12, ptr @.d245 }, 1
  %t350 = extractvalue { i64, ptr } { i64 12, ptr @.d245 }, 0
  %t352 = sext i32 %t347 to i64
  %t353 = call i64 @__olang_fmt_i64(ptr null, i64 %t352)
  %t354 = add i64 %t350, %t353
  %t355 = extractvalue { i64, ptr } { i64 12, ptr @.d246 }, 1
  %t356 = extractvalue { i64, ptr } { i64 12, ptr @.d246 }, 0
  %t357 = add i64 %t354, %t356
  %t359 = sext i32 %t348 to i64
  %t360 = call i64 @__olang_fmt_i64(ptr null, i64 %t359)
  %t361 = add i64 %t357, %t360
  %t362 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t361)
  call void @olang_textcopy(ptr %t362, ptr %t349, i64 %t350)
  %t363 = getelementptr i8, ptr %t362, i64 %t350
  %t364 = call i64 @__olang_fmt_i64(ptr %t363, i64 %t352)
  %t365 = getelementptr i8, ptr %t363, i64 %t353
  call void @olang_textcopy(ptr %t365, ptr %t355, i64 %t356)
  %t366 = getelementptr i8, ptr %t365, i64 %t356
  %t367 = call i64 @__olang_fmt_i64(ptr %t366, i64 %t359)
  %t368 = insertvalue { i64, ptr } undef, i64 %t361, 0
  %t369 = insertvalue { i64, ptr } %t368, ptr %t362, 1
  %t371 = extractvalue { i64, ptr } %t369, 0
  %t372 = extractvalue { i64, ptr } %t369, 1
  %t373 = mul i64 %t371, 1
  %t374 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t373)
  call void @llvm.memcpy.p0.p0.i64(ptr %t374, ptr %t372, i64 %t373, i1 false)
  %t375 = insertvalue { i64, ptr } undef, i64 %t371, 0
  %t376 = insertvalue { i64, ptr } %t375, ptr %t374, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s14, ptr %t346, { i64, ptr } %t376)
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s14)
  br label %bb92
bb77:
  %t379 = getelementptr %"compiler/mir:ScopeInfo", ptr %l180, i32 0, i32 0
  %t380 = load i32, ptr %t379
  %t382 = trunc i64 4 to i32
  %t383 = icmp eq i32 %t380, %t382
  br i1 %t383, label %bb78, label %bb79
bb78:
  store %olang.scope zeroinitializer, ptr %s18
  %t385 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s18, ptr %t385, { i64, ptr } { i64 8, ptr @.d247 })
  br label %bb80
bb79:
  br label %bb81
bb80:
  call void @__olang_scope_close(ptr %s18)
  br label %bb81
bb81:
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t388 = load i32, ptr %l13, !tbaa !23
  %t389 = extractvalue { i64, ptr } { i64 42, ptr @.d248 }, 1
  %t390 = extractvalue { i64, ptr } { i64 42, ptr @.d248 }, 0
  %t392 = sext i32 %t388 to i64
  %t393 = call i64 @__olang_fmt_i64(ptr null, i64 %t392)
  %t394 = add i64 %t390, %t393
  %t395 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t394)
  call void @olang_textcopy(ptr %t395, ptr %t389, i64 %t390)
  %t396 = getelementptr i8, ptr %t395, i64 %t390
  %t397 = call i64 @__olang_fmt_i64(ptr %t396, i64 %t392)
  %t398 = insertvalue { i64, ptr } undef, i64 %t394, 0
  %t399 = insertvalue { i64, ptr } %t398, ptr %t395, 1
  %t401 = extractvalue { i64, ptr } %t399, 0
  %t402 = extractvalue { i64, ptr } %t399, 1
  %t403 = mul i64 %t401, 1
  %t404 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t403)
  call void @llvm.memcpy.p0.p0.i64(ptr %t404, ptr %t402, i64 %t403, i1 false)
  %t405 = insertvalue { i64, ptr } undef, i64 %t401, 0
  %t406 = insertvalue { i64, ptr } %t405, ptr %t404, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s17, ptr %t387, { i64, ptr } %t406)
  br label %bb82
bb82:
  %t409 = load ptr, ptr %l0, !tbaa !29
  %t411 = getelementptr %"compiler/emit:fnEm", ptr %t409, i32 0, i32 1
  %t412 = load ptr, ptr %t411, !tbaa !29
  %t414 = getelementptr %"compiler/mir:Fn", ptr %t412, i32 0, i32 8
  %t415 = load i32, ptr %l13, !tbaa !23
  %t417 = sext i32 %t415 to i64
  %t420 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t414, i64 %t417)
  store %"compiler/mir:ScopeInfo" %t420, ptr %l193
  br label %bb83
bb83:
  %t421 = getelementptr %"compiler/mir:ScopeInfo", ptr %l193, i32 0, i32 0
  %t422 = load i32, ptr %t421
  %t424 = trunc i64 3 to i32
  %t425 = icmp eq i32 %t422, %t424
  store i1 %t425, ptr %l14, !tbaa !21
  %t427 = load i1, ptr %l14, !tbaa !21
  br i1 %t427, label %bb84, label %bb85
bb84:
  store %olang.scope zeroinitializer, ptr %s20
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t430 = load i32, ptr %l13, !tbaa !23
  %t431 = extractvalue { i64, ptr } { i64 23, ptr @.d249 }, 1
  %t432 = extractvalue { i64, ptr } { i64 23, ptr @.d249 }, 0
  %t434 = sext i32 %t430 to i64
  %t435 = call i64 @__olang_fmt_i64(ptr null, i64 %t434)
  %t436 = add i64 %t432, %t435
  %t437 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t436)
  call void @olang_textcopy(ptr %t437, ptr %t431, i64 %t432)
  %t438 = getelementptr i8, ptr %t437, i64 %t432
  %t439 = call i64 @__olang_fmt_i64(ptr %t438, i64 %t434)
  %t440 = insertvalue { i64, ptr } undef, i64 %t436, 0
  %t441 = insertvalue { i64, ptr } %t440, ptr %t437, 1
  %t443 = extractvalue { i64, ptr } %t441, 0
  %t444 = extractvalue { i64, ptr } %t441, 1
  %t445 = mul i64 %t443, 1
  %t446 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t445)
  call void @llvm.memcpy.p0.p0.i64(ptr %t446, ptr %t444, i64 %t445, i1 false)
  %t447 = insertvalue { i64, ptr } undef, i64 %t443, 0
  %t448 = insertvalue { i64, ptr } %t447, ptr %t446, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s20, ptr %t429, { i64, ptr } %t448)
  br label %bb86
bb85:
  br label %bb87
bb86:
  call void @__olang_scope_close(ptr %s20)
  br label %bb87
bb87:
  %t451 = load ptr, ptr %l0, !tbaa !29
  %t453 = getelementptr %"compiler/emit:fnEm", ptr %t451, i32 0, i32 0
  %t454 = load ptr, ptr %t453, !tbaa !29
  %t456 = getelementptr %"compiler/emit:Emitter", ptr %t454, i32 0, i32 4
  %t457 = load i1, ptr %t456, !tbaa !21
  br i1 %t457, label %bb88, label %bb89
bb88:
  %t459 = load ptr, ptr %l0, !tbaa !29
  %t460 = load i32, ptr %l13, !tbaa !23
  %t461 = load i1, ptr %l14, !tbaa !21
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eunwindPush(ptr %v0, ptr %t459, i32 %t460, i1 %t461)
  br label %bb90
bb89:
  br label %bb91
bb90:
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s17)
  br label %bb92
bb92:
  br label %bb231
bb93:
  %t465 = load ptr, ptr %l1, !tbaa !29
  store ptr %t465, ptr %l207, !tbaa !29
  store i1 false, ptr %l208, !tbaa !21
  %t466 = load ptr, ptr %l207, !tbaa !29
  %t467 = icmp ne ptr %t466, null
  br i1 %t467, label %bb94, label %bb95
bb94:
  %t469 = load ptr, ptr %l207, !tbaa !29
  %t470 = load i64, ptr %t469
  %t472 = icmp eq i64 %t470, 4
  store i1 %t472, ptr %l208, !tbaa !21
  br label %bb95
bb95:
  %t473 = load i1, ptr %l208, !tbaa !21
  br i1 %t473, label %bb96, label %bb97
bb96:
  %t474 = load ptr, ptr %l1, !tbaa !29
  %t476 = getelementptr { i64, [21 x i64] }, ptr %t474, i32 0, i32 1
  %t477 = getelementptr { %"compiler/source:Span", i32 }, ptr %t476, i32 0, i32 1
  %t478 = load i32, ptr %t477
  store i32 %t478, ptr %l15, !tbaa !23
  br label %bb98
bb97:
  br label %bb128
bb98:
  %t480 = load ptr, ptr %l0, !tbaa !29
  %t482 = getelementptr %"compiler/emit:fnEm", ptr %t480, i32 0, i32 23
  %t483 = load i32, ptr %l15, !tbaa !23
  %t485 = sext i32 %t483 to i64
  %t488 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t482, i64 %t485)
  store i1 %t488, ptr %l217
  br label %bb99
bb99:
  %t489 = load i1, ptr %l217, !tbaa !21
  br i1 %t489, label %bb100, label %bb101
bb100:
  store i1 true, ptr %l218, !tbaa !21
  br label %bb103
bb101:
  %t490 = load ptr, ptr %l0, !tbaa !29
  %t492 = getelementptr %"compiler/emit:fnEm", ptr %t490, i32 0, i32 24
  %t493 = load i32, ptr %l15, !tbaa !23
  %t495 = sext i32 %t493 to i64
  %t498 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t492, i64 %t495)
  store i1 %t498, ptr %l223
  br label %bb102
bb102:
  %t499 = load i1, ptr %l223, !tbaa !21
  store i1 %t499, ptr %l218, !tbaa !21
  br label %bb103
bb103:
  %t500 = load i1, ptr %l218, !tbaa !21
  br i1 %t500, label %bb104, label %bb105
bb104:
  br label %ret
bb105:
  br label %bb106
bb106:
  %t501 = load ptr, ptr %l0, !tbaa !29
  %t503 = getelementptr %"compiler/emit:fnEm", ptr %t501, i32 0, i32 1
  %t504 = load ptr, ptr %t503, !tbaa !29
  %t506 = getelementptr %"compiler/mir:Fn", ptr %t504, i32 0, i32 8
  %t507 = load i32, ptr %l15, !tbaa !23
  %t509 = sext i32 %t507 to i64
  %t512 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %t506, i64 %t509)
  store %"compiler/mir:ScopeInfo" %t512, ptr %l229
  br label %bb107
bb107:
  %t513 = getelementptr %"compiler/mir:ScopeInfo", ptr %l229, i32 0, i32 0
  %t514 = load i32, ptr %t513
  %t516 = trunc i64 6 to i32
  %t517 = icmp eq i32 %t514, %t516
  br i1 %t517, label %bb108, label %bb109
bb108:
  store %olang.scope zeroinitializer, ptr %s25
  %t519 = load ptr, ptr %l0, !tbaa !29
  %t521 = getelementptr %"compiler/emit:fnEm", ptr %t519, i32 0, i32 0
  %t522 = load ptr, ptr %t521, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s25, ptr %t522, { i64, ptr } { i64 15, ptr @.d250 })
  br label %bb110
bb109:
  store %olang.scope zeroinitializer, ptr %s31
  %t524 = load ptr, ptr %l0, !tbaa !29
  %t526 = getelementptr %"compiler/emit:fnEm", ptr %t524, i32 0, i32 0
  %t527 = load ptr, ptr %t526, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s31, ptr %t527, { i64, ptr } { i64 19, ptr @.d251 })
  br label %bb121
bb110:
  %t529 = load ptr, ptr %l0, !tbaa !29
  store ptr %t529, ptr %l234, !tbaa !29
  %t530 = load ptr, ptr %l0, !tbaa !29
  %t531 = load i32, ptr %l15, !tbaa !23
  %t532 = extractvalue { i64, ptr } { i64 36, ptr @.d252 }, 1
  %t533 = extractvalue { i64, ptr } { i64 36, ptr @.d252 }, 0
  %t535 = sext i32 %t531 to i64
  %t536 = call i64 @__olang_fmt_i64(ptr null, i64 %t535)
  %t537 = add i64 %t533, %t536
  %t538 = extractvalue { i64, ptr } { i64 14, ptr @.d253 }, 1
  %t539 = extractvalue { i64, ptr } { i64 14, ptr @.d253 }, 0
  %t540 = add i64 %t537, %t539
  %t541 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t540)
  call void @olang_textcopy(ptr %t541, ptr %t532, i64 %t533)
  %t542 = getelementptr i8, ptr %t541, i64 %t533
  %t543 = call i64 @__olang_fmt_i64(ptr %t542, i64 %t535)
  %t544 = getelementptr i8, ptr %t542, i64 %t536
  call void @olang_textcopy(ptr %t544, ptr %t538, i64 %t539)
  %t545 = insertvalue { i64, ptr } undef, i64 %t540, 0
  %t546 = insertvalue { i64, ptr } %t545, ptr %t541, 1
  %t548 = extractvalue { i64, ptr } %t546, 0
  %t549 = extractvalue { i64, ptr } %t546, 1
  %t550 = mul i64 %t548, 1
  %t551 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t550)
  call void @llvm.memcpy.p0.p0.i64(ptr %t551, ptr %t549, i64 %t550, i1 false)
  %t552 = insertvalue { i64, ptr } undef, i64 %t548, 0
  %t553 = insertvalue { i64, ptr } %t552, ptr %t551, 1
  %t556 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s25, ptr %s25, ptr %t530, { i64, ptr } %t553)
  store { i64, ptr } %t556, ptr %l239
  br label %bb111
bb111:
  %t557 = load { i64, ptr }, ptr %l239, !tbaa !27
  %t558 = extractvalue { i64, ptr } %t557, 0
  %t559 = extractvalue { i64, ptr } %t557, 1
  %t560 = mul i64 %t558, 1
  %t561 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t560)
  call void @llvm.memcpy.p0.p0.i64(ptr %t561, ptr %t559, i64 %t560, i1 false)
  %t562 = insertvalue { i64, ptr } undef, i64 %t558, 0
  %t563 = insertvalue { i64, ptr } %t562, ptr %t561, 1
  %t564 = load ptr, ptr %l234, !tbaa !29
  %t566 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s25, ptr %s25, ptr %s25, ptr %s25, ptr %t564, { i64, ptr } { i64 3, ptr @.d254 }, { i64, ptr } %t563, { i64, ptr } { i64 0, ptr @.d255 })
  store { i64, ptr } %t566, ptr %l241
  br label %bb112
bb112:
  %t567 = load { i64, ptr }, ptr %l241, !tbaa !27
  %t568 = load ptr, ptr %l0, !tbaa !29
  %t570 = extractvalue { i64, ptr } { i64 12, ptr @.d256 }, 1
  %t571 = extractvalue { i64, ptr } { i64 12, ptr @.d256 }, 0
  %t573 = extractvalue { i64, ptr } %t567, 1
  %t574 = extractvalue { i64, ptr } %t567, 0
  %t575 = add i64 %t571, %t574
  %t576 = extractvalue { i64, ptr } { i64 6, ptr @.d257 }, 1
  %t577 = extractvalue { i64, ptr } { i64 6, ptr @.d257 }, 0
  %t578 = add i64 %t575, %t577
  %t579 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t578)
  call void @olang_textcopy(ptr %t579, ptr %t570, i64 %t571)
  %t580 = getelementptr i8, ptr %t579, i64 %t571
  call void @olang_textcopy(ptr %t580, ptr %t573, i64 %t574)
  %t581 = getelementptr i8, ptr %t580, i64 %t574
  call void @olang_textcopy(ptr %t581, ptr %t576, i64 %t577)
  %t582 = insertvalue { i64, ptr } undef, i64 %t578, 0
  %t583 = insertvalue { i64, ptr } %t582, ptr %t579, 1
  %t585 = extractvalue { i64, ptr } %t583, 0
  %t586 = extractvalue { i64, ptr } %t583, 1
  %t587 = mul i64 %t585, 1
  %t588 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t587)
  call void @llvm.memcpy.p0.p0.i64(ptr %t588, ptr %t586, i64 %t587, i1 false)
  %t589 = insertvalue { i64, ptr } undef, i64 %t585, 0
  %t590 = insertvalue { i64, ptr } %t589, ptr %t588, 1
  %t593 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s25, ptr %s25, ptr %t568, { i64, ptr } %t590)
  store { i64, ptr } %t593, ptr %l246
  br label %bb113
bb113:
  %t594 = load { i64, ptr }, ptr %l246, !tbaa !27
  store { i64, ptr } %t594, ptr %l17, !tbaa !27
  %t595 = load ptr, ptr %l0, !tbaa !29
  %t597 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s25, ptr %s25, ptr %t595, { i64, ptr } { i64 6, ptr @.d258 })
  store { i64, ptr } %t597, ptr %l248
  br label %bb114
bb114:
  %t598 = load { i64, ptr }, ptr %l248, !tbaa !27
  store { i64, ptr } %t598, ptr %l18, !tbaa !27
  %t599 = load ptr, ptr %l0, !tbaa !29
  %t601 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s25, ptr %s25, ptr %t599, { i64, ptr } { i64 6, ptr @.d259 })
  store { i64, ptr } %t601, ptr %l250
  br label %bb115
bb115:
  %t602 = load { i64, ptr }, ptr %l250, !tbaa !27
  store { i64, ptr } %t602, ptr %l19, !tbaa !27
  %t603 = load ptr, ptr %l0, !tbaa !29
  %t604 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t605 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t606 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t607 = extractvalue { i64, ptr } { i64 6, ptr @.d260 }, 1
  %t608 = extractvalue { i64, ptr } { i64 6, ptr @.d260 }, 0
  %t610 = extractvalue { i64, ptr } %t604, 1
  %t611 = extractvalue { i64, ptr } %t604, 0
  %t612 = add i64 %t608, %t611
  %t613 = extractvalue { i64, ptr } { i64 9, ptr @.d261 }, 1
  %t614 = extractvalue { i64, ptr } { i64 9, ptr @.d261 }, 0
  %t615 = add i64 %t612, %t614
  %t617 = extractvalue { i64, ptr } %t605, 1
  %t618 = extractvalue { i64, ptr } %t605, 0
  %t619 = add i64 %t615, %t618
  %t620 = extractvalue { i64, ptr } { i64 9, ptr @.d262 }, 1
  %t621 = extractvalue { i64, ptr } { i64 9, ptr @.d262 }, 0
  %t622 = add i64 %t619, %t621
  %t624 = extractvalue { i64, ptr } %t606, 1
  %t625 = extractvalue { i64, ptr } %t606, 0
  %t626 = add i64 %t622, %t625
  %t627 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t626)
  call void @olang_textcopy(ptr %t627, ptr %t607, i64 %t608)
  %t628 = getelementptr i8, ptr %t627, i64 %t608
  call void @olang_textcopy(ptr %t628, ptr %t610, i64 %t611)
  %t629 = getelementptr i8, ptr %t628, i64 %t611
  call void @olang_textcopy(ptr %t629, ptr %t613, i64 %t614)
  %t630 = getelementptr i8, ptr %t629, i64 %t614
  call void @olang_textcopy(ptr %t630, ptr %t617, i64 %t618)
  %t631 = getelementptr i8, ptr %t630, i64 %t618
  call void @olang_textcopy(ptr %t631, ptr %t620, i64 %t621)
  %t632 = getelementptr i8, ptr %t631, i64 %t621
  call void @olang_textcopy(ptr %t632, ptr %t624, i64 %t625)
  %t633 = insertvalue { i64, ptr } undef, i64 %t626, 0
  %t634 = insertvalue { i64, ptr } %t633, ptr %t627, 1
  %t636 = extractvalue { i64, ptr } %t634, 0
  %t637 = extractvalue { i64, ptr } %t634, 1
  %t638 = mul i64 %t636, 1
  %t639 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t638)
  call void @llvm.memcpy.p0.p0.i64(ptr %t639, ptr %t637, i64 %t638, i1 false)
  %t640 = insertvalue { i64, ptr } undef, i64 %t636, 0
  %t641 = insertvalue { i64, ptr } %t640, ptr %t639, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s25, ptr %t603, { i64, ptr } %t641)
  br label %bb116
bb116:
  %t644 = load ptr, ptr %l0, !tbaa !29
  %t645 = load { i64, ptr }, ptr %l18, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s25, ptr %t644, { i64, ptr } %t645)
  br label %bb117
bb117:
  %t648 = load ptr, ptr %l0, !tbaa !29
  %t649 = load i32, ptr %l15, !tbaa !23
  %t650 = extractvalue { i64, ptr } { i64 33, ptr @.d263 }, 1
  %t651 = extractvalue { i64, ptr } { i64 33, ptr @.d263 }, 0
  %t653 = sext i32 %t649 to i64
  %t654 = call i64 @__olang_fmt_i64(ptr null, i64 %t653)
  %t655 = add i64 %t651, %t654
  %t656 = extractvalue { i64, ptr } { i64 1, ptr @.d264 }, 1
  %t657 = extractvalue { i64, ptr } { i64 1, ptr @.d264 }, 0
  %t658 = add i64 %t655, %t657
  %t659 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t658)
  call void @olang_textcopy(ptr %t659, ptr %t650, i64 %t651)
  %t660 = getelementptr i8, ptr %t659, i64 %t651
  %t661 = call i64 @__olang_fmt_i64(ptr %t660, i64 %t653)
  %t662 = getelementptr i8, ptr %t660, i64 %t654
  call void @olang_textcopy(ptr %t662, ptr %t656, i64 %t657)
  %t663 = insertvalue { i64, ptr } undef, i64 %t658, 0
  %t664 = insertvalue { i64, ptr } %t663, ptr %t659, 1
  %t666 = extractvalue { i64, ptr } %t664, 0
  %t667 = extractvalue { i64, ptr } %t664, 1
  %t668 = mul i64 %t666, 1
  %t669 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t668)
  call void @llvm.memcpy.p0.p0.i64(ptr %t669, ptr %t667, i64 %t668, i1 false)
  %t670 = insertvalue { i64, ptr } undef, i64 %t666, 0
  %t671 = insertvalue { i64, ptr } %t670, ptr %t669, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s25, ptr %t648, { i64, ptr } %t671)
  br label %bb118
bb118:
  %t674 = load ptr, ptr %l0, !tbaa !29
  %t675 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t676 = extractvalue { i64, ptr } { i64 10, ptr @.d265 }, 1
  %t677 = extractvalue { i64, ptr } { i64 10, ptr @.d265 }, 0
  %t679 = extractvalue { i64, ptr } %t675, 1
  %t680 = extractvalue { i64, ptr } %t675, 0
  %t681 = add i64 %t677, %t680
  %t682 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t681)
  call void @olang_textcopy(ptr %t682, ptr %t676, i64 %t677)
  %t683 = getelementptr i8, ptr %t682, i64 %t677
  call void @olang_textcopy(ptr %t683, ptr %t679, i64 %t680)
  %t684 = insertvalue { i64, ptr } undef, i64 %t681, 0
  %t685 = insertvalue { i64, ptr } %t684, ptr %t682, 1
  %t687 = extractvalue { i64, ptr } %t685, 0
  %t688 = extractvalue { i64, ptr } %t685, 1
  %t689 = mul i64 %t687, 1
  %t690 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t689)
  call void @llvm.memcpy.p0.p0.i64(ptr %t690, ptr %t688, i64 %t689, i1 false)
  %t691 = insertvalue { i64, ptr } undef, i64 %t687, 0
  %t692 = insertvalue { i64, ptr } %t691, ptr %t690, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s25, ptr %t674, { i64, ptr } %t692)
  br label %bb119
bb119:
  %t695 = load ptr, ptr %l0, !tbaa !29
  %t696 = load { i64, ptr }, ptr %l19, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s25, ptr %t695, { i64, ptr } %t696)
  br label %bb120
bb120:
  call void @__olang_scope_close(ptr %s25)
  br label %bb127
bb121:
  %t699 = load ptr, ptr %l0, !tbaa !29
  %t700 = load i32, ptr %l15, !tbaa !23
  %t701 = extractvalue { i64, ptr } { i64 37, ptr @.d266 }, 1
  %t702 = extractvalue { i64, ptr } { i64 37, ptr @.d266 }, 0
  %t704 = sext i32 %t700 to i64
  %t705 = call i64 @__olang_fmt_i64(ptr null, i64 %t704)
  %t706 = add i64 %t702, %t705
  %t707 = extractvalue { i64, ptr } { i64 1, ptr @.d267 }, 1
  %t708 = extractvalue { i64, ptr } { i64 1, ptr @.d267 }, 0
  %t709 = add i64 %t706, %t708
  %t710 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t709)
  call void @olang_textcopy(ptr %t710, ptr %t701, i64 %t702)
  %t711 = getelementptr i8, ptr %t710, i64 %t702
  %t712 = call i64 @__olang_fmt_i64(ptr %t711, i64 %t704)
  %t713 = getelementptr i8, ptr %t711, i64 %t705
  call void @olang_textcopy(ptr %t713, ptr %t707, i64 %t708)
  %t714 = insertvalue { i64, ptr } undef, i64 %t709, 0
  %t715 = insertvalue { i64, ptr } %t714, ptr %t710, 1
  %t717 = extractvalue { i64, ptr } %t715, 0
  %t718 = extractvalue { i64, ptr } %t715, 1
  %t719 = mul i64 %t717, 1
  %t720 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t719)
  call void @llvm.memcpy.p0.p0.i64(ptr %t720, ptr %t718, i64 %t719, i1 false)
  %t721 = insertvalue { i64, ptr } undef, i64 %t717, 0
  %t722 = insertvalue { i64, ptr } %t721, ptr %t720, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s31, ptr %t699, { i64, ptr } %t722)
  br label %bb122
bb122:
  %t725 = load ptr, ptr %l0, !tbaa !29
  %t727 = getelementptr %"compiler/emit:fnEm", ptr %t725, i32 0, i32 0
  %t728 = load ptr, ptr %t727, !tbaa !29
  %t730 = getelementptr %"compiler/emit:Emitter", ptr %t728, i32 0, i32 4
  %t731 = load i1, ptr %t730, !tbaa !21
  br i1 %t731, label %bb123, label %bb124
bb123:
  %t733 = load ptr, ptr %l0, !tbaa !29
  %t734 = load i32, ptr %l15, !tbaa !23
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eunwindPop(ptr %v0, ptr %t733, i32 %t734)
  br label %bb125
bb124:
  br label %bb126
bb125:
  br label %bb126
bb126:
  call void @__olang_scope_close(ptr %s31)
  br label %bb127
bb127:
  br label %bb231
bb128:
  %t737 = load ptr, ptr %l1, !tbaa !29
  store ptr %t737, ptr %l280, !tbaa !29
  store i1 false, ptr %l281, !tbaa !21
  %t738 = load ptr, ptr %l280, !tbaa !29
  %t739 = icmp ne ptr %t738, null
  br i1 %t739, label %bb129, label %bb130
bb129:
  %t741 = load ptr, ptr %l280, !tbaa !29
  %t742 = load i64, ptr %t741
  %t744 = icmp eq i64 %t742, 5
  store i1 %t744, ptr %l281, !tbaa !21
  br label %bb130
bb130:
  %t745 = load i1, ptr %l281, !tbaa !21
  br i1 %t745, label %bb131, label %bb132
bb131:
  br label %bb133
bb132:
  br label %bb135
bb133:
  store %olang.scope zeroinitializer, ptr %s34
  %t746 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s34, ptr %t746, { i64, ptr } { i64 4, ptr @.d268 })
  br label %bb134
bb134:
  call void @__olang_scope_close(ptr %s34)
  br label %bb231
bb135:
  %t748 = load ptr, ptr %l1, !tbaa !29
  store ptr %t748, ptr %l285, !tbaa !29
  store i1 false, ptr %l286, !tbaa !21
  %t749 = load ptr, ptr %l285, !tbaa !29
  %t750 = icmp ne ptr %t749, null
  br i1 %t750, label %bb136, label %bb137
bb136:
  %t752 = load ptr, ptr %l285, !tbaa !29
  %t753 = load i64, ptr %t752
  %t755 = icmp eq i64 %t753, 12
  store i1 %t755, ptr %l286, !tbaa !21
  br label %bb137
bb137:
  %t756 = load i1, ptr %l286, !tbaa !21
  br i1 %t756, label %bb138, label %bb139
bb138:
  %t757 = load ptr, ptr %l1, !tbaa !29
  %t759 = getelementptr { i64, [21 x i64] }, ptr %t757, i32 0, i32 1
  %t760 = getelementptr { %"compiler/source:Span" }, ptr %t759, i32 0, i32 0
  %t761 = load %"compiler/source:Span", ptr %t760
  store %"compiler/source:Span" %t761, ptr %l20
  br label %bb140
bb139:
  br label %bb142
bb140:
  %t763 = load ptr, ptr %l0, !tbaa !29
  %t764 = load %"compiler/source:Span", ptr %l20
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2etrace(ptr %v0, ptr %t763, %"compiler/source:Span" %t764)
  br label %bb141
bb141:
  br label %bb231
bb142:
  %t767 = load ptr, ptr %l1, !tbaa !29
  store ptr %t767, ptr %l293, !tbaa !29
  store i1 false, ptr %l294, !tbaa !21
  %t768 = load ptr, ptr %l293, !tbaa !29
  %t769 = icmp ne ptr %t768, null
  br i1 %t769, label %bb143, label %bb144
bb143:
  %t771 = load ptr, ptr %l293, !tbaa !29
  %t772 = load i64, ptr %t771
  %t774 = icmp eq i64 %t772, 13
  store i1 %t774, ptr %l294, !tbaa !21
  br label %bb144
bb144:
  %t775 = load i1, ptr %l294, !tbaa !21
  br i1 %t775, label %bb145, label %bb146
bb145:
  br label %bb147
bb146:
  br label %bb149
bb147:
  store %olang.scope zeroinitializer, ptr %s36
  %t776 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s36, ptr %t776, { i64, ptr } { i64 23, ptr @.d269 })
  br label %bb148
bb148:
  call void @__olang_scope_close(ptr %s36)
  br label %bb231
bb149:
  %t778 = load ptr, ptr %l1, !tbaa !29
  store ptr %t778, ptr %l298, !tbaa !29
  store i1 false, ptr %l299, !tbaa !21
  %t779 = load ptr, ptr %l298, !tbaa !29
  %t780 = icmp ne ptr %t779, null
  br i1 %t780, label %bb150, label %bb151
bb150:
  %t782 = load ptr, ptr %l298, !tbaa !29
  %t783 = load i64, ptr %t782
  %t785 = icmp eq i64 %t783, 6
  store i1 %t785, ptr %l299, !tbaa !21
  br label %bb151
bb151:
  %t786 = load i1, ptr %l299, !tbaa !21
  br i1 %t786, label %bb152, label %bb153
bb152:
  %t787 = load ptr, ptr %l1, !tbaa !29
  %t789 = getelementptr { i64, [21 x i64] }, ptr %t787, i32 0, i32 1
  %t790 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t789, i32 0, i32 1
  %t791 = load { i64, [1 x i64] }, ptr %t790
  store { i64, [1 x i64] } %t791, ptr %l21
  %t793 = load ptr, ptr %l1, !tbaa !29
  %t795 = getelementptr { i64, [21 x i64] }, ptr %t793, i32 0, i32 1
  %t796 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t795, i32 0, i32 2
  %t797 = load i32, ptr %t796
  store i32 %t797, ptr %l22, !tbaa !23
  %t799 = load ptr, ptr %l1, !tbaa !29
  %t801 = getelementptr { i64, [21 x i64] }, ptr %t799, i32 0, i32 1
  %t802 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t801, i32 0, i32 3
  %t803 = load { i64, [4 x i64] }, ptr %t802
  store { i64, [4 x i64] } %t803, ptr %l23
  br label %bb154
bb153:
  br label %bb176
bb154:
  store %olang.scope zeroinitializer, ptr %s37
  %t805 = load ptr, ptr %l0, !tbaa !29
  %t807 = getelementptr %"compiler/emit:fnEm", ptr %t805, i32 0, i32 0
  %t808 = load ptr, ptr %t807, !tbaa !29
  %t810 = getelementptr %"compiler/emit:Emitter", ptr %t808, i32 0, i32 35
  %t811 = load i32, ptr %l22, !tbaa !23
  %t814 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %t810, i32 %t811)
  %t815 = extractvalue { i32, i64 } %t814, 1
  %t816 = extractvalue { i32, i64 } %t814, 0
  store i32 %t816, ptr %l314
  %t817 = icmp ne i32 %t816, 0
  br i1 %t817, label %bb156, label %ok.818
ok.818:
  store i64 %t815, ptr %l313
  br label %bb155
bb155:
  %t819 = load i64, ptr %l313, !tbaa !24
  store i64 %t819, ptr %l308, !tbaa !24
  br label %bb158
bb156:
  br label %bb157
bb157:
  store i64 -1, ptr %l308, !tbaa !24
  br label %bb158
bb158:
  %t820 = load i64, ptr %l308, !tbaa !24
  store i64 %t820, ptr %l24, !tbaa !24
  %t821 = load i64, ptr %l24, !tbaa !24
  %t823 = icmp slt i64 %t821, 0
  br i1 %t823, label %bb159, label %bb160
bb159:
  store %olang.scope zeroinitializer, ptr %s38
  %t825 = load ptr, ptr %l0, !tbaa !29
  store ptr %t825, ptr %l317, !tbaa !29
  %t826 = load ptr, ptr %l2, !tbaa !29
  %t827 = load i32, ptr %l22, !tbaa !23
  %t830 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s38, ptr %t826, i32 %t827)
  store { i64, ptr } %t830, ptr %l320
  br label %bb161
bb160:
  br label %bb163
bb161:
  %t831 = extractvalue { i64, ptr } { i64 24, ptr @.d270 }, 1
  %t832 = extractvalue { i64, ptr } { i64 24, ptr @.d270 }, 0
  %t833 = load { i64, ptr }, ptr %l320, !tbaa !27
  %t834 = extractvalue { i64, ptr } %t833, 1
  %t835 = extractvalue { i64, ptr } %t833, 0
  %t836 = add i64 %t832, %t835
  %t837 = call ptr @__olang_scope_alloc(ptr %s38, i64 %t836)
  call void @olang_textcopy(ptr %t837, ptr %t831, i64 %t832)
  %t838 = getelementptr i8, ptr %t837, i64 %t832
  call void @olang_textcopy(ptr %t838, ptr %t834, i64 %t835)
  %t839 = insertvalue { i64, ptr } undef, i64 %t836, 0
  %t840 = insertvalue { i64, ptr } %t839, ptr %t837, 1
  %t842 = extractvalue { i64, ptr } %t840, 0
  %t843 = extractvalue { i64, ptr } %t840, 1
  %t844 = mul i64 %t842, 1
  %t845 = call ptr @__olang_scope_alloc(ptr %s38, i64 %t844)
  call void @llvm.memcpy.p0.p0.i64(ptr %t845, ptr %t843, i64 %t844, i1 false)
  %t846 = insertvalue { i64, ptr } undef, i64 %t842, 0
  %t847 = insertvalue { i64, ptr } %t846, ptr %t845, 1
  %t848 = load ptr, ptr %l317, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s38, ptr %t848, { i64, ptr } %t847)
  br label %bb162
bb162:
  call void @__olang_scope_close(ptr %s38)
  call void @__olang_scope_close(ptr %s37)
  br label %ret
bb163:
  %t850 = load i64, ptr %l24, !tbaa !24
  %t852 = trunc i64 %t850 to i32
  store { i64, [1 x i64] } zeroinitializer, ptr %t854
  %t855 = getelementptr { i64, [1 x i64] }, ptr %t854, i32 0, i32 0
  store i64 0, ptr %t855
  %t857 = insertvalue { i32 } undef, i32 %t852, 0
  %t858 = getelementptr { i64, [1 x i64] }, ptr %t854, i32 0, i32 1
  store { i32 } %t857, ptr %t858
  %t859 = load { i64, [1 x i64] }, ptr %t854
  store { i64, [1 x i64] } %t859, ptr %l25
  %t861 = load ptr, ptr %l0, !tbaa !29
  %t863 = getelementptr %"compiler/emit:fnEm", ptr %t861, i32 0, i32 0
  %t864 = load ptr, ptr %t863, !tbaa !29
  %t865 = load { i64, [1 x i64] }, ptr %l25
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewant(ptr %v0, ptr %t864, { i64, [1 x i64] } %t865)
  br label %bb164
bb164:
  %t868 = load ptr, ptr %l0, !tbaa !29
  %t870 = getelementptr %"compiler/emit:fnEm", ptr %t868, i32 0, i32 0
  %t871 = load ptr, ptr %t870, !tbaa !29
  %t873 = getelementptr %"compiler/emit:Emitter", ptr %t871, i32 0, i32 33
  %t874 = load { i64, [1 x i64] }, ptr %l25
  %t877 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_Hf0a5beca6f8aee4731a76bd327ae0a99(ptr %v0, ptr %t873, { i64, [1 x i64] } %t874)
  store i1 %t877, ptr %l334
  br label %bb165
bb165:
  %t878 = load i1, ptr %l334, !tbaa !21
  %t879 = xor i1 %t878, true
  br i1 %t879, label %bb166, label %bb167
bb166:
  %t881 = load ptr, ptr %l0, !tbaa !29
  %t883 = getelementptr %"compiler/emit:fnEm", ptr %t881, i32 0, i32 0
  %t884 = load ptr, ptr %t883, !tbaa !29
  %t886 = getelementptr %"compiler/emit:Emitter", ptr %t884, i32 0, i32 33
  %t887 = load { i64, [1 x i64] }, ptr %l25
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_He6968003b8dd5762fa82ec44b4ee1fc9(ptr %v0, ptr %t886, { i64, [1 x i64] } %t887, i1 true)
  br label %bb168
bb167:
  br label %bb170
bb168:
  %t890 = load ptr, ptr %l0, !tbaa !29
  %t892 = getelementptr %"compiler/emit:fnEm", ptr %t890, i32 0, i32 0
  %t893 = load ptr, ptr %t892, !tbaa !29
  %t895 = getelementptr %"compiler/emit:Emitter", ptr %t893, i32 0, i32 32
  %t896 = load { i64, [1 x i64] }, ptr %l25
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %t895, { i64, [1 x i64] } %t896)
  br label %bb169
bb169:
  br label %bb170
bb170:
  %t899 = load ptr, ptr %l0, !tbaa !29
  %t901 = getelementptr %"compiler/emit:fnEm", ptr %t899, i32 0, i32 0
  %t902 = load ptr, ptr %t901, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s37, ptr %t902, { i64, ptr } { i64 27, ptr @.d271 })
  br label %bb171
bb171:
  %t904 = load ptr, ptr %l0, !tbaa !29
  store ptr %t904, ptr %l346, !tbaa !29
  %t905 = load ptr, ptr %l0, !tbaa !29
  %t906 = load { i64, [1 x i64] }, ptr %l21
  %t909 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %s37, ptr %t905, { i64, [1 x i64] } %t906)
  store { i64, ptr } %t909, ptr %l349
  br label %bb172
bb172:
  %t910 = load ptr, ptr %l0, !tbaa !29
  %t911 = load { i64, [4 x i64] }, ptr %l23
  %t912 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t916 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s37, ptr %t910, { i64, [4 x i64] } %t911, i32 %t912)
  store { i64, ptr } %t916, ptr %l353
  br label %bb173
bb173:
  %t917 = load ptr, ptr %l0, !tbaa !29
  %t919 = getelementptr %"compiler/emit:fnEm", ptr %t917, i32 0, i32 0
  %t920 = load ptr, ptr %t919, !tbaa !29
  %t921 = load { i64, [1 x i64] }, ptr %l25
  %t924 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s37, ptr %t920, { i64, [1 x i64] } %t921)
  store { i64, ptr } %t924, ptr %l357
  br label %bb174
bb174:
  %t925 = extractvalue { i64, ptr } { i64 43, ptr @.d272 }, 1
  %t926 = extractvalue { i64, ptr } { i64 43, ptr @.d272 }, 0
  %t927 = load { i64, ptr }, ptr %l349, !tbaa !27
  %t928 = extractvalue { i64, ptr } %t927, 1
  %t929 = extractvalue { i64, ptr } %t927, 0
  %t930 = add i64 %t926, %t929
  %t931 = extractvalue { i64, ptr } { i64 6, ptr @.d273 }, 1
  %t932 = extractvalue { i64, ptr } { i64 6, ptr @.d273 }, 0
  %t933 = add i64 %t930, %t932
  %t934 = load { i64, ptr }, ptr %l353, !tbaa !27
  %t935 = extractvalue { i64, ptr } %t934, 1
  %t936 = extractvalue { i64, ptr } %t934, 0
  %t937 = add i64 %t933, %t936
  %t938 = extractvalue { i64, ptr } { i64 7, ptr @.d274 }, 1
  %t939 = extractvalue { i64, ptr } { i64 7, ptr @.d274 }, 0
  %t940 = add i64 %t937, %t939
  %t941 = load { i64, ptr }, ptr %l357, !tbaa !27
  %t942 = extractvalue { i64, ptr } %t941, 1
  %t943 = extractvalue { i64, ptr } %t941, 0
  %t944 = add i64 %t940, %t943
  %t945 = extractvalue { i64, ptr } { i64 4, ptr @.d275 }, 1
  %t946 = extractvalue { i64, ptr } { i64 4, ptr @.d275 }, 0
  %t947 = add i64 %t944, %t946
  %t948 = call ptr @__olang_scope_alloc(ptr %s37, i64 %t947)
  call void @olang_textcopy(ptr %t948, ptr %t925, i64 %t926)
  %t949 = getelementptr i8, ptr %t948, i64 %t926
  call void @olang_textcopy(ptr %t949, ptr %t928, i64 %t929)
  %t950 = getelementptr i8, ptr %t949, i64 %t929
  call void @olang_textcopy(ptr %t950, ptr %t931, i64 %t932)
  %t951 = getelementptr i8, ptr %t950, i64 %t932
  call void @olang_textcopy(ptr %t951, ptr %t935, i64 %t936)
  %t952 = getelementptr i8, ptr %t951, i64 %t936
  call void @olang_textcopy(ptr %t952, ptr %t938, i64 %t939)
  %t953 = getelementptr i8, ptr %t952, i64 %t939
  call void @olang_textcopy(ptr %t953, ptr %t942, i64 %t943)
  %t954 = getelementptr i8, ptr %t953, i64 %t943
  call void @olang_textcopy(ptr %t954, ptr %t945, i64 %t946)
  %t955 = insertvalue { i64, ptr } undef, i64 %t947, 0
  %t956 = insertvalue { i64, ptr } %t955, ptr %t948, 1
  %t958 = extractvalue { i64, ptr } %t956, 0
  %t959 = extractvalue { i64, ptr } %t956, 1
  %t960 = mul i64 %t958, 1
  %t961 = call ptr @__olang_scope_alloc(ptr %s37, i64 %t960)
  call void @llvm.memcpy.p0.p0.i64(ptr %t961, ptr %t959, i64 %t960, i1 false)
  %t962 = insertvalue { i64, ptr } undef, i64 %t958, 0
  %t963 = insertvalue { i64, ptr } %t962, ptr %t961, 1
  %t964 = load ptr, ptr %l346, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s37, ptr %t964, { i64, ptr } %t963)
  br label %bb175
bb175:
  call void @__olang_scope_close(ptr %s37)
  br label %bb231
bb176:
  %t966 = load ptr, ptr %l1, !tbaa !29
  store ptr %t966, ptr %l360, !tbaa !29
  store i1 false, ptr %l361, !tbaa !21
  %t967 = load ptr, ptr %l360, !tbaa !29
  %t968 = icmp ne ptr %t967, null
  br i1 %t968, label %bb177, label %bb178
bb177:
  %t970 = load ptr, ptr %l360, !tbaa !29
  %t971 = load i64, ptr %t970
  %t973 = icmp eq i64 %t971, 7
  store i1 %t973, ptr %l361, !tbaa !21
  br label %bb178
bb178:
  %t974 = load i1, ptr %l361, !tbaa !21
  br i1 %t974, label %bb179, label %bb180
bb179:
  br label %bb181
bb180:
  br label %bb183
bb181:
  store %olang.scope zeroinitializer, ptr %s42
  %t975 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s42, ptr %t975, { i64, ptr } { i64 13, ptr @.d276 })
  br label %bb182
bb182:
  call void @__olang_scope_close(ptr %s42)
  br label %bb231
bb183:
  %t977 = load ptr, ptr %l1, !tbaa !29
  store ptr %t977, ptr %l365, !tbaa !29
  store i1 false, ptr %l366, !tbaa !21
  %t978 = load ptr, ptr %l365, !tbaa !29
  %t979 = icmp ne ptr %t978, null
  br i1 %t979, label %bb184, label %bb185
bb184:
  %t981 = load ptr, ptr %l365, !tbaa !29
  %t982 = load i64, ptr %t981
  %t984 = icmp eq i64 %t982, 8
  store i1 %t984, ptr %l366, !tbaa !21
  br label %bb185
bb185:
  %t985 = load i1, ptr %l366, !tbaa !21
  br i1 %t985, label %bb186, label %bb187
bb186:
  br label %bb188
bb187:
  br label %bb190
bb188:
  store %olang.scope zeroinitializer, ptr %s43
  %t986 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s43, ptr %t986, { i64, ptr } { i64 7, ptr @.d277 })
  br label %bb189
bb189:
  call void @__olang_scope_close(ptr %s43)
  br label %bb231
bb190:
  %t988 = load ptr, ptr %l1, !tbaa !29
  store ptr %t988, ptr %l370, !tbaa !29
  store i1 false, ptr %l371, !tbaa !21
  %t989 = load ptr, ptr %l370, !tbaa !29
  %t990 = icmp ne ptr %t989, null
  br i1 %t990, label %bb191, label %bb192
bb191:
  %t992 = load ptr, ptr %l370, !tbaa !29
  %t993 = load i64, ptr %t992
  %t995 = icmp eq i64 %t993, 9
  store i1 %t995, ptr %l371, !tbaa !21
  br label %bb192
bb192:
  %t996 = load i1, ptr %l371, !tbaa !21
  br i1 %t996, label %bb193, label %bb194
bb193:
  %t997 = load ptr, ptr %l1, !tbaa !29
  %t999 = getelementptr { i64, [21 x i64] }, ptr %t997, i32 0, i32 1
  %t1000 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t999, i32 0, i32 1
  %t1001 = load { i64, [1 x i64] }, ptr %t1000
  store { i64, [1 x i64] } %t1001, ptr %l26
  %t1003 = load ptr, ptr %l1, !tbaa !29
  %t1005 = getelementptr { i64, [21 x i64] }, ptr %t1003, i32 0, i32 1
  %t1006 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t1005, i32 0, i32 2
  %t1007 = load i32, ptr %t1006
  store i32 %t1007, ptr %l27
  %t1009 = load ptr, ptr %l1, !tbaa !29
  %t1011 = getelementptr { i64, [21 x i64] }, ptr %t1009, i32 0, i32 1
  %t1012 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t1011, i32 0, i32 3
  %t1013 = load { i64, [4 x i64] }, ptr %t1012
  store { i64, [4 x i64] } %t1013, ptr %l28
  br label %bb195
bb194:
  br label %bb204
bb195:
  store %olang.scope zeroinitializer, ptr %s44
  %t1015 = load ptr, ptr %l0, !tbaa !29
  %t1016 = load { i64, [1 x i64] }, ptr %l26
  %t1019 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2edirectRef(ptr %v0, ptr %t1015, { i64, [1 x i64] } %t1016)
  store i1 %t1019, ptr %l382
  br label %bb196
bb196:
  %t1020 = load i1, ptr %l382, !tbaa !21
  br i1 %t1020, label %bb197, label %bb198
bb197:
  %t1021 = load ptr, ptr %l0, !tbaa !29
  %t1023 = getelementptr %"compiler/emit:fnEm", ptr %t1021, i32 0, i32 25
  %t1024 = load i32, ptr %l27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aWriteKind_3e_2ePus_Hb3977af45b838e23bffe750970901b09(ptr %v0, ptr %t1023, i32 %t1024)
  br label %bb199
bb198:
  br label %bb201
bb199:
  %t1027 = load ptr, ptr %l0, !tbaa !29
  %t1029 = getelementptr %"compiler/emit:fnEm", ptr %t1027, i32 0, i32 26
  %t1030 = load { i64, [4 x i64] }, ptr %l28
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e_2ePush_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t1029, { i64, [4 x i64] } %t1030)
  br label %bb200
bb200:
  call void @__olang_scope_close(ptr %s44)
  br label %ret
bb201:
  %t1033 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1033, ptr %l389, !tbaa !29
  %t1034 = load ptr, ptr %l0, !tbaa !29
  %t1035 = load { i64, [1 x i64] }, ptr %l26
  %t1038 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %s44, ptr %t1034, { i64, [1 x i64] } %t1035)
  store { i64, ptr } %t1038, ptr %l392
  br label %bb202
bb202:
  %t1039 = load { i64, ptr }, ptr %l392, !tbaa !27
  %t1040 = extractvalue { i64, ptr } %t1039, 0
  %t1041 = extractvalue { i64, ptr } %t1039, 1
  %t1042 = mul i64 %t1040, 1
  %t1043 = call ptr @__olang_scope_alloc(ptr %s44, i64 %t1042)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1043, ptr %t1041, i64 %t1042, i1 false)
  %t1044 = insertvalue { i64, ptr } undef, i64 %t1040, 0
  %t1045 = insertvalue { i64, ptr } %t1044, ptr %t1043, 1
  %t1046 = load i32, ptr %l27
  %t1047 = load { i64, [4 x i64] }, ptr %l28
  %t1048 = load ptr, ptr %l389, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ewrite(ptr %v0, ptr %s44, ptr %t1048, { i64, ptr } %t1045, i32 %t1046, { i64, [4 x i64] } %t1047)
  br label %bb203
bb203:
  call void @__olang_scope_close(ptr %s44)
  br label %bb231
bb204:
  %t1052 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1052, ptr %l396, !tbaa !29
  store i1 false, ptr %l397, !tbaa !21
  %t1053 = load ptr, ptr %l396, !tbaa !29
  %t1054 = icmp ne ptr %t1053, null
  br i1 %t1054, label %bb205, label %bb206
bb205:
  %t1056 = load ptr, ptr %l396, !tbaa !29
  %t1057 = load i64, ptr %t1056
  %t1059 = icmp eq i64 %t1057, 10
  store i1 %t1059, ptr %l397, !tbaa !21
  br label %bb206
bb206:
  %t1060 = load i1, ptr %l397, !tbaa !21
  br i1 %t1060, label %bb207, label %bb208
bb207:
  %t1061 = load ptr, ptr %l1, !tbaa !29
  %t1063 = getelementptr { i64, [21 x i64] }, ptr %t1061, i32 0, i32 1
  %t1064 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } }, ptr %t1063, i32 0, i32 1
  %t1065 = load %"compiler/mir:Place", ptr %t1064
  store %"compiler/mir:Place" %t1065, ptr %l29
  %t1067 = load ptr, ptr %l1, !tbaa !29
  %t1069 = getelementptr { i64, [21 x i64] }, ptr %t1067, i32 0, i32 1
  %t1070 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } }, ptr %t1069, i32 0, i32 2
  %t1071 = load %"compiler/mir:Place", ptr %t1070
  store %"compiler/mir:Place" %t1071, ptr %l30
  %t1073 = load ptr, ptr %l1, !tbaa !29
  %t1075 = getelementptr { i64, [21 x i64] }, ptr %t1073, i32 0, i32 1
  %t1076 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } }, ptr %t1075, i32 0, i32 3
  %t1077 = load { i64, [4 x i64] }, ptr %t1076
  store { i64, [4 x i64] } %t1077, ptr %l31
  br label %bb209
bb208:
  br label %bb222
bb209:
  store %olang.scope zeroinitializer, ptr %s46
  %t1079 = load ptr, ptr %l0, !tbaa !29
  %t1080 = load %"compiler/mir:Place", ptr %l29
  %t1083 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edataPtr(ptr %v0, ptr %s46, ptr %t1079, %"compiler/mir:Place" %t1080)
  store { i64, ptr } %t1083, ptr %l408
  br label %bb210
bb210:
  %t1084 = load { i64, ptr }, ptr %l408, !tbaa !27
  store { i64, ptr } %t1084, ptr %l32, !tbaa !27
  %t1085 = load ptr, ptr %l0, !tbaa !29
  %t1086 = load %"compiler/mir:Place", ptr %l30
  %t1089 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edataPtr(ptr %v0, ptr %s46, ptr %t1085, %"compiler/mir:Place" %t1086)
  store { i64, ptr } %t1089, ptr %l411
  br label %bb211
bb211:
  %t1090 = load { i64, ptr }, ptr %l411, !tbaa !27
  store { i64, ptr } %t1090, ptr %l33, !tbaa !27
  %t1091 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1091, ptr %l412, !tbaa !29
  %t1092 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1092, ptr %l413, !tbaa !29
  %t1093 = load ptr, ptr %l0, !tbaa !29
  %t1094 = load %"compiler/mir:Place", ptr %l29
  %t1097 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eplaceType(ptr %v0, ptr %t1093, %"compiler/mir:Place" %t1094)
  store i32 %t1097, ptr %l416
  br label %bb212
bb212:
  %t1098 = load ptr, ptr %l413, !tbaa !29
  %t1099 = load i32, ptr %l416, !tbaa !23
  %t1100 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %t1098, i32 %t1099)
  store i32 %t1100, ptr %l417
  br label %bb213
bb213:
  %t1101 = load ptr, ptr %l412, !tbaa !29
  %t1102 = load i32, ptr %l417, !tbaa !23
  %t1103 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t1101, i32 %t1102)
  store i32 %t1103, ptr %l418
  br label %bb214
bb214:
  %t1104 = load i32, ptr %l418, !tbaa !23
  store i32 %t1104, ptr %l34, !tbaa !23
  %t1105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1105, ptr %l419, !tbaa !29
  %t1106 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1106, ptr %l420, !tbaa !29
  %t1107 = load ptr, ptr %l0, !tbaa !29
  %t1108 = load { i64, [4 x i64] }, ptr %l31
  %t1109 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t1113 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s46, ptr %t1107, { i64, [4 x i64] } %t1108, i32 %t1109)
  store { i64, ptr } %t1113, ptr %l424
  br label %bb215
bb215:
  %t1114 = load { i64, ptr }, ptr %l424, !tbaa !27
  %t1115 = extractvalue { i64, ptr } %t1114, 0
  %t1116 = extractvalue { i64, ptr } %t1114, 1
  %t1117 = mul i64 %t1115, 1
  %t1118 = call ptr @__olang_scope_alloc(ptr %s46, i64 %t1117)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1118, ptr %t1116, i64 %t1117, i1 false)
  %t1119 = insertvalue { i64, ptr } undef, i64 %t1115, 0
  %t1120 = insertvalue { i64, ptr } %t1119, ptr %t1118, 1
  store { i64, ptr } %t1120, ptr %l425, !tbaa !27
  %t1121 = load ptr, ptr %l0, !tbaa !29
  %t1122 = load { i64, [4 x i64] }, ptr %l31
  %t1125 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t1121, { i64, [4 x i64] } %t1122)
  store i32 %t1125, ptr %l428
  br label %bb216
bb216:
  %t1126 = load ptr, ptr %l420, !tbaa !29
  %t1127 = load { i64, ptr }, ptr %l425, !tbaa !27
  %t1128 = load i32, ptr %l428, !tbaa !23
  %t1129 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eindex(ptr %v0, ptr %s46, ptr %s46, ptr %t1126, { i64, ptr } %t1127, i32 %t1128)
  store { i64, ptr } %t1129, ptr %l429
  br label %bb217
bb217:
  %t1130 = load ptr, ptr %l0, !tbaa !29
  %t1131 = load i32, ptr %l34, !tbaa !23
  %t1134 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %t1130, i32 %t1131)
  store i64 %t1134, ptr %l432
  br label %bb218
bb218:
  %t1135 = extractvalue { i64, ptr } { i64 8, ptr @.d278 }, 1
  %t1136 = extractvalue { i64, ptr } { i64 8, ptr @.d278 }, 0
  %t1137 = load { i64, ptr }, ptr %l429, !tbaa !27
  %t1138 = extractvalue { i64, ptr } %t1137, 1
  %t1139 = extractvalue { i64, ptr } %t1137, 0
  %t1140 = add i64 %t1136, %t1139
  %t1141 = extractvalue { i64, ptr } { i64 2, ptr @.d279 }, 1
  %t1142 = extractvalue { i64, ptr } { i64 2, ptr @.d279 }, 0
  %t1143 = add i64 %t1140, %t1142
  %t1144 = load i64, ptr %l432, !tbaa !24
  %t1145 = call i64 @__olang_fmt_i64(ptr null, i64 %t1144)
  %t1146 = add i64 %t1143, %t1145
  %t1147 = call ptr @__olang_scope_alloc(ptr %s46, i64 %t1146)
  call void @olang_textcopy(ptr %t1147, ptr %t1135, i64 %t1136)
  %t1148 = getelementptr i8, ptr %t1147, i64 %t1136
  call void @olang_textcopy(ptr %t1148, ptr %t1138, i64 %t1139)
  %t1149 = getelementptr i8, ptr %t1148, i64 %t1139
  call void @olang_textcopy(ptr %t1149, ptr %t1141, i64 %t1142)
  %t1150 = getelementptr i8, ptr %t1149, i64 %t1142
  %t1151 = call i64 @__olang_fmt_i64(ptr %t1150, i64 %t1144)
  %t1152 = insertvalue { i64, ptr } undef, i64 %t1146, 0
  %t1153 = insertvalue { i64, ptr } %t1152, ptr %t1147, 1
  %t1155 = extractvalue { i64, ptr } %t1153, 0
  %t1156 = extractvalue { i64, ptr } %t1153, 1
  %t1157 = mul i64 %t1155, 1
  %t1158 = call ptr @__olang_scope_alloc(ptr %s46, i64 %t1157)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1158, ptr %t1156, i64 %t1157, i1 false)
  %t1159 = insertvalue { i64, ptr } undef, i64 %t1155, 0
  %t1160 = insertvalue { i64, ptr } %t1159, ptr %t1158, 1
  %t1161 = load ptr, ptr %l419, !tbaa !29
  %t1163 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s46, ptr %s46, ptr %t1161, { i64, ptr } %t1160)
  store { i64, ptr } %t1163, ptr %l435
  br label %bb219
bb219:
  %t1164 = load { i64, ptr }, ptr %l435, !tbaa !27
  store { i64, ptr } %t1164, ptr %l35, !tbaa !27
  %t1165 = load ptr, ptr %l0, !tbaa !29
  %t1167 = getelementptr %"compiler/emit:fnEm", ptr %t1165, i32 0, i32 0
  %t1168 = load ptr, ptr %t1167, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s46, ptr %s46, ptr %t1168, { i64, ptr } { i64 22, ptr @.d280 }, { i64, ptr } { i64 47, ptr @.d281 })
  br label %bb220
bb220:
  %t1170 = load ptr, ptr %l0, !tbaa !29
  %t1171 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t1172 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t1173 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t1174 = extractvalue { i64, ptr } { i64 38, ptr @.d282 }, 1
  %t1175 = extractvalue { i64, ptr } { i64 38, ptr @.d282 }, 0
  %t1177 = extractvalue { i64, ptr } %t1171, 1
  %t1178 = extractvalue { i64, ptr } %t1171, 0
  %t1179 = add i64 %t1175, %t1178
  %t1180 = extractvalue { i64, ptr } { i64 6, ptr @.d283 }, 1
  %t1181 = extractvalue { i64, ptr } { i64 6, ptr @.d283 }, 0
  %t1182 = add i64 %t1179, %t1181
  %t1184 = extractvalue { i64, ptr } %t1172, 1
  %t1185 = extractvalue { i64, ptr } %t1172, 0
  %t1186 = add i64 %t1182, %t1185
  %t1187 = extractvalue { i64, ptr } { i64 6, ptr @.d284 }, 1
  %t1188 = extractvalue { i64, ptr } { i64 6, ptr @.d284 }, 0
  %t1189 = add i64 %t1186, %t1188
  %t1191 = extractvalue { i64, ptr } %t1173, 1
  %t1192 = extractvalue { i64, ptr } %t1173, 0
  %t1193 = add i64 %t1189, %t1192
  %t1194 = extractvalue { i64, ptr } { i64 11, ptr @.d285 }, 1
  %t1195 = extractvalue { i64, ptr } { i64 11, ptr @.d285 }, 0
  %t1196 = add i64 %t1193, %t1195
  %t1197 = call ptr @__olang_scope_alloc(ptr %s46, i64 %t1196)
  call void @olang_textcopy(ptr %t1197, ptr %t1174, i64 %t1175)
  %t1198 = getelementptr i8, ptr %t1197, i64 %t1175
  call void @olang_textcopy(ptr %t1198, ptr %t1177, i64 %t1178)
  %t1199 = getelementptr i8, ptr %t1198, i64 %t1178
  call void @olang_textcopy(ptr %t1199, ptr %t1180, i64 %t1181)
  %t1200 = getelementptr i8, ptr %t1199, i64 %t1181
  call void @olang_textcopy(ptr %t1200, ptr %t1184, i64 %t1185)
  %t1201 = getelementptr i8, ptr %t1200, i64 %t1185
  call void @olang_textcopy(ptr %t1201, ptr %t1187, i64 %t1188)
  %t1202 = getelementptr i8, ptr %t1201, i64 %t1188
  call void @olang_textcopy(ptr %t1202, ptr %t1191, i64 %t1192)
  %t1203 = getelementptr i8, ptr %t1202, i64 %t1192
  call void @olang_textcopy(ptr %t1203, ptr %t1194, i64 %t1195)
  %t1204 = insertvalue { i64, ptr } undef, i64 %t1196, 0
  %t1205 = insertvalue { i64, ptr } %t1204, ptr %t1197, 1
  %t1207 = extractvalue { i64, ptr } %t1205, 0
  %t1208 = extractvalue { i64, ptr } %t1205, 1
  %t1209 = mul i64 %t1207, 1
  %t1210 = call ptr @__olang_scope_alloc(ptr %s46, i64 %t1209)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1210, ptr %t1208, i64 %t1209, i1 false)
  %t1211 = insertvalue { i64, ptr } undef, i64 %t1207, 0
  %t1212 = insertvalue { i64, ptr } %t1211, ptr %t1210, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s46, ptr %t1170, { i64, ptr } %t1212)
  br label %bb221
bb221:
  call void @__olang_scope_close(ptr %s46)
  br label %bb231
bb222:
  %t1215 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1215, ptr %l444, !tbaa !29
  store i1 false, ptr %l445, !tbaa !21
  %t1216 = load ptr, ptr %l444, !tbaa !29
  %t1217 = icmp ne ptr %t1216, null
  br i1 %t1217, label %bb223, label %bb224
bb223:
  %t1219 = load ptr, ptr %l444, !tbaa !29
  %t1220 = load i64, ptr %t1219
  %t1222 = icmp eq i64 %t1220, 11
  store i1 %t1222, ptr %l445, !tbaa !21
  br label %bb224
bb224:
  %t1223 = load i1, ptr %l445, !tbaa !21
  br i1 %t1223, label %bb225, label %bb226
bb225:
  %t1224 = load ptr, ptr %l1, !tbaa !29
  %t1226 = getelementptr { i64, [21 x i64] }, ptr %t1224, i32 0, i32 1
  %t1227 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t1226, i32 0, i32 1
  %t1228 = load i32, ptr %t1227
  store i32 %t1228, ptr %l36, !tbaa !23
  %t1230 = load ptr, ptr %l1, !tbaa !29
  %t1232 = getelementptr { i64, [21 x i64] }, ptr %t1230, i32 0, i32 1
  %t1233 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t1232, i32 0, i32 2
  %t1234 = load i32, ptr %t1233
  store i32 %t1234, ptr %l37, !tbaa !23
  br label %bb227
bb226:
  br label %bb230
bb227:
  %t1236 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1236, ptr %l452, !tbaa !29
  %t1237 = load i32, ptr %l36, !tbaa !23
  store i32 %t1237, ptr %l453, !tbaa !23
  %t1238 = load ptr, ptr %l0, !tbaa !29
  %t1240 = getelementptr %"compiler/emit:fnEm", ptr %t1238, i32 0, i32 1
  %t1241 = load ptr, ptr %t1240, !tbaa !29
  %t1243 = getelementptr %"compiler/mir:Fn", ptr %t1241, i32 0, i32 16
  %t1244 = load i32, ptr %l37, !tbaa !23
  %t1246 = sext i32 %t1244 to i64
  %t1249 = call %"compiler/mir:Task" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %t1243, i64 %t1246)
  store %"compiler/mir:Task" %t1249, ptr %l459
  br label %bb228
bb228:
  %t1250 = load ptr, ptr %l452, !tbaa !29
  %t1251 = load i32, ptr %l453, !tbaa !23
  %t1252 = load %"compiler/mir:Task", ptr %l459
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2espawn(ptr %v0, ptr %t1250, i32 %t1251, %"compiler/mir:Task" %t1252)
  br label %bb229
bb229:
  br label %bb231
bb230:
  call void @__olang_check_failed(ptr @olang_loc_73cacc8093766858_2881ed4d4d5af0d4)
  unreachable
bb231:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2esubprogram(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l10 = alloca i1
  %l14 = alloca i1
  %l23 = alloca i64
  %l31 = alloca i64
  %l32 = alloca ptr
  %l34 = alloca i64
  %l36 = alloca ptr
  %l38 = alloca i64
  %l42 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l52 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/mir:Fn", ptr %t6, i32 0, i32 2
  %t9 = load i64, ptr %t8, !tbaa !24
  %t11 = icmp slt i64 %t9, 0
  br i1 %t11, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb6
bb2:
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/mir:Fn", ptr %t13, i32 0, i32 3
  %t16 = getelementptr %"compiler/source:Span", ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16, !tbaa !23
  %t19 = icmp eq i32 %t17, 0
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/mir:Fn", ptr %t21, i32 0, i32 3
  %t24 = getelementptr %"compiler/source:Span", ptr %t23, i32 0, i32 1
  %t25 = load i32, ptr %t24, !tbaa !23
  %t27 = icmp eq i32 %t25, 0
  store i1 %t27, ptr %l14, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t29 = load i1, ptr %l14, !tbaa !21
  store i1 %t29, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t30 = load i1, ptr %l10, !tbaa !21
  br i1 %t30, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  br label %bb9
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/emit:fnEm", ptr %t31, i32 0, i32 0
  %t34 = load ptr, ptr %t33, !tbaa !29
  store ptr %t34, ptr %l2, !tbaa !29
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr %"compiler/mir:Fn", ptr %t37, i32 0, i32 2
  %t40 = load i64, ptr %t39, !tbaa !24
  %t43 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgFile(ptr %v0, ptr %t36, i64 %t40)
  store i64 %t43, ptr %l23
  br label %bb10
bb10:
  %t44 = load i64, ptr %l23, !tbaa !24
  store i64 %t44, ptr %l3, !tbaa !24
  %t45 = load ptr, ptr %l2, !tbaa !29
  %t47 = getelementptr %"compiler/emit:Emitter", ptr %t45, i32 0, i32 2
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr %"compiler/mir:Fn", ptr %t49, i32 0, i32 2
  %t52 = load i64, ptr %t51, !tbaa !24
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr %"compiler/mir:Fn", ptr %t53, i32 0, i32 3
  %t56 = getelementptr %"compiler/source:Span", ptr %t55, i32 0, i32 0
  %t57 = load i32, ptr %t56, !tbaa !23
  %t59 = sext i32 %t57 to i64
  %t63 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %t48, i64 %t52, i64 %t59)
  store i64 %t63, ptr %l31
  br label %bb11
bb11:
  %t64 = load i64, ptr %l31, !tbaa !24
  store i64 %t64, ptr %l4, !tbaa !24
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l32, !tbaa !29
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t68 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t66)
  store i64 %t68, ptr %l34
  br label %bb12
bb12:
  %t69 = load i64, ptr %l34, !tbaa !24
  %t70 = load ptr, ptr %l32, !tbaa !29
  %t71 = getelementptr %"compiler/emit:fnEm", ptr %t70, i32 0, i32 17
  store i64 %t69, ptr %t71, !tbaa !24
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/emit:fnEm", ptr %t72, i32 0, i32 20
  store ptr %t74, ptr %l36, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/emit:fnEm", ptr %t75, i32 0, i32 17
  %t78 = load i64, ptr %t77, !tbaa !24
  store i64 %t78, ptr %l38, !tbaa !24
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t82 = getelementptr %"compiler/mir:Fn", ptr %t80, i32 0, i32 0
  %t83 = load { i64, [1 x i64] }, ptr %t82
  %t86 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgName(ptr %v0, ptr %s0, ptr %t79, { i64, [1 x i64] } %t83)
  store { i64, ptr } %t86, ptr %l42
  br label %bb13
bb13:
  %t87 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  %t89 = extractvalue { i64, ptr } %t87, 1
  %t90 = mul i64 %t88, 1
  %t91 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t90)
  call void @llvm.memcpy.p0.p0.i64(ptr %t91, ptr %t89, i64 %t90, i1 false)
  %t92 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  %t95 = call { i64, ptr } @compiler_2femit_2eescape(ptr %s0, ptr %s0, { i64, ptr } %t93)
  store { i64, ptr } %t95, ptr %l44
  br label %bb14
bb14:
  %t96 = load i64, ptr %l3, !tbaa !24
  store i64 %t96, ptr %l45, !tbaa !24
  %t97 = load i64, ptr %l3, !tbaa !24
  store i64 %t97, ptr %l46, !tbaa !24
  %t98 = load i64, ptr %l4, !tbaa !24
  store i64 %t98, ptr %l47, !tbaa !24
  %t99 = load ptr, ptr %l2, !tbaa !29
  %t101 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgSubTy(ptr %v0, ptr %t99)
  store i64 %t101, ptr %l49
  br label %bb15
bb15:
  %t102 = load i64, ptr %l4, !tbaa !24
  store i64 %t102, ptr %l50, !tbaa !24
  %t103 = load ptr, ptr %l2, !tbaa !29
  %t105 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgCu(ptr %v0, ptr %t103)
  store i64 %t105, ptr %l52
  br label %bb16
bb16:
  %t106 = extractvalue { i64, ptr } { i64 1, ptr @.d286 }, 1
  %t107 = extractvalue { i64, ptr } { i64 1, ptr @.d286 }, 0
  %t108 = load i64, ptr %l38, !tbaa !24
  %t109 = call i64 @__olang_fmt_i64(ptr null, i64 %t108)
  %t110 = add i64 %t107, %t109
  %t111 = extractvalue { i64, ptr } { i64 33, ptr @.d287 }, 1
  %t112 = extractvalue { i64, ptr } { i64 33, ptr @.d287 }, 0
  %t113 = add i64 %t110, %t112
  %t114 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t114, 1
  %t116 = extractvalue { i64, ptr } %t114, 0
  %t117 = add i64 %t113, %t116
  %t118 = extractvalue { i64, ptr } { i64 11, ptr @.d288 }, 1
  %t119 = extractvalue { i64, ptr } { i64 11, ptr @.d288 }, 0
  %t120 = add i64 %t117, %t119
  %t121 = load i64, ptr %l45, !tbaa !24
  %t122 = call i64 @__olang_fmt_i64(ptr null, i64 %t121)
  %t123 = add i64 %t120, %t122
  %t124 = extractvalue { i64, ptr } { i64 9, ptr @.d289 }, 1
  %t125 = extractvalue { i64, ptr } { i64 9, ptr @.d289 }, 0
  %t126 = add i64 %t123, %t125
  %t127 = load i64, ptr %l46, !tbaa !24
  %t128 = call i64 @__olang_fmt_i64(ptr null, i64 %t127)
  %t129 = add i64 %t126, %t128
  %t130 = extractvalue { i64, ptr } { i64 8, ptr @.d290 }, 1
  %t131 = extractvalue { i64, ptr } { i64 8, ptr @.d290 }, 0
  %t132 = add i64 %t129, %t131
  %t133 = load i64, ptr %l47, !tbaa !24
  %t134 = call i64 @__olang_fmt_i64(ptr null, i64 %t133)
  %t135 = add i64 %t132, %t134
  %t136 = extractvalue { i64, ptr } { i64 9, ptr @.d291 }, 1
  %t137 = extractvalue { i64, ptr } { i64 9, ptr @.d291 }, 0
  %t138 = add i64 %t135, %t137
  %t139 = load i64, ptr %l49, !tbaa !24
  %t140 = call i64 @__olang_fmt_i64(ptr null, i64 %t139)
  %t141 = add i64 %t138, %t140
  %t142 = extractvalue { i64, ptr } { i64 13, ptr @.d292 }, 1
  %t143 = extractvalue { i64, ptr } { i64 13, ptr @.d292 }, 0
  %t144 = add i64 %t141, %t143
  %t145 = load i64, ptr %l50, !tbaa !24
  %t146 = call i64 @__olang_fmt_i64(ptr null, i64 %t145)
  %t147 = add i64 %t144, %t146
  %t148 = extractvalue { i64, ptr } { i64 38, ptr @.d293 }, 1
  %t149 = extractvalue { i64, ptr } { i64 38, ptr @.d293 }, 0
  %t150 = add i64 %t147, %t149
  %t151 = load i64, ptr %l52, !tbaa !24
  %t152 = call i64 @__olang_fmt_i64(ptr null, i64 %t151)
  %t153 = add i64 %t150, %t152
  %t154 = extractvalue { i64, ptr } { i64 2, ptr @.d294 }, 1
  %t155 = extractvalue { i64, ptr } { i64 2, ptr @.d294 }, 0
  %t156 = add i64 %t153, %t155
  %t157 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t156)
  call void @olang_textcopy(ptr %t157, ptr %t106, i64 %t107)
  %t158 = getelementptr i8, ptr %t157, i64 %t107
  %t159 = call i64 @__olang_fmt_i64(ptr %t158, i64 %t108)
  %t160 = getelementptr i8, ptr %t158, i64 %t109
  call void @olang_textcopy(ptr %t160, ptr %t111, i64 %t112)
  %t161 = getelementptr i8, ptr %t160, i64 %t112
  call void @olang_textcopy(ptr %t161, ptr %t115, i64 %t116)
  %t162 = getelementptr i8, ptr %t161, i64 %t116
  call void @olang_textcopy(ptr %t162, ptr %t118, i64 %t119)
  %t163 = getelementptr i8, ptr %t162, i64 %t119
  %t164 = call i64 @__olang_fmt_i64(ptr %t163, i64 %t121)
  %t165 = getelementptr i8, ptr %t163, i64 %t122
  call void @olang_textcopy(ptr %t165, ptr %t124, i64 %t125)
  %t166 = getelementptr i8, ptr %t165, i64 %t125
  %t167 = call i64 @__olang_fmt_i64(ptr %t166, i64 %t127)
  %t168 = getelementptr i8, ptr %t166, i64 %t128
  call void @olang_textcopy(ptr %t168, ptr %t130, i64 %t131)
  %t169 = getelementptr i8, ptr %t168, i64 %t131
  %t170 = call i64 @__olang_fmt_i64(ptr %t169, i64 %t133)
  %t171 = getelementptr i8, ptr %t169, i64 %t134
  call void @olang_textcopy(ptr %t171, ptr %t136, i64 %t137)
  %t172 = getelementptr i8, ptr %t171, i64 %t137
  %t173 = call i64 @__olang_fmt_i64(ptr %t172, i64 %t139)
  %t174 = getelementptr i8, ptr %t172, i64 %t140
  call void @olang_textcopy(ptr %t174, ptr %t142, i64 %t143)
  %t175 = getelementptr i8, ptr %t174, i64 %t143
  %t176 = call i64 @__olang_fmt_i64(ptr %t175, i64 %t145)
  %t177 = getelementptr i8, ptr %t175, i64 %t146
  call void @olang_textcopy(ptr %t177, ptr %t148, i64 %t149)
  %t178 = getelementptr i8, ptr %t177, i64 %t149
  %t179 = call i64 @__olang_fmt_i64(ptr %t178, i64 %t151)
  %t180 = getelementptr i8, ptr %t178, i64 %t152
  call void @olang_textcopy(ptr %t180, ptr %t154, i64 %t155)
  %t181 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t157, 1
  %t184 = extractvalue { i64, ptr } %t182, 0
  %t185 = extractvalue { i64, ptr } %t182, 1
  %t186 = mul i64 %t184, 1
  %t187 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t186)
  call void @llvm.memcpy.p0.p0.i64(ptr %t187, ptr %t185, i64 %t186, i1 false)
  %t188 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t187, 1
  %t190 = load ptr, ptr %l36, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t190, { i64, ptr } %t189)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2eterm(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [7 x i64] }
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca %"compiler/mir:Range"
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %l20 = alloca %"compiler/mir:Case"
  %l21 = alloca i32
  %l22 = alloca { i64, [4 x i64] }
  %l23 = alloca { i64, ptr }
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca { i64, [4 x i64] }
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i32
  %l32 = alloca i32
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l36 = alloca %"compiler/source:Span"
  %l37 = alloca i32
  %l38 = alloca { i64, [4 x i64] }
  %l45 = alloca ptr
  %l47 = alloca %"compiler/source:Span"
  %l54 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l64 = alloca ptr
  %l68 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l82 = alloca i32
  %l85 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l90 = alloca %"std/prelude/text:StringBuilder"
  %l91 = alloca ptr
  %l92 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l102 = alloca i32
  %l105 = alloca i32
  %l131 = alloca %"compiler/mir:Case"
  %l132 = alloca ptr
  %l133 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %l146 = alloca ptr
  %l148 = alloca { i64, ptr }
  %l152 = alloca ptr
  %l158 = alloca %"compiler/mir:Call"
  %l166 = alloca { i64, ptr }
  %l183 = alloca ptr
  %l184 = alloca { i64, ptr }
  %l188 = alloca { i64, ptr }
  %l193 = alloca { i64, ptr }
  %l196 = alloca { i64, ptr }
  %l201 = alloca i1
  %l203 = alloca ptr
  %l204 = alloca { i64, ptr }
  %l209 = alloca { i64, ptr }
  %l222 = alloca { i64, ptr }
  %l226 = alloca { i64, ptr }
  %l228 = alloca i1
  %l231 = alloca ptr
  %l232 = alloca { i64, ptr }
  %l238 = alloca { i64, ptr }
  %l253 = alloca { i64, ptr }
  %l257 = alloca ptr
  %l259 = alloca { i64, ptr }
  %l266 = alloca { i64, ptr }
  %l270 = alloca ptr
  %l271 = alloca { i64, ptr }
  %l274 = alloca { i64, ptr }
  %l280 = alloca { i64, ptr }
  %l281 = alloca ptr
  %l282 = alloca { i64, ptr }
  %l284 = alloca { i64, ptr }
  %l286 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s38 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [7 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/emit:fnEm", ptr %t9, i32 0, i32 17
  %t12 = load i64, ptr %t11, !tbaa !24
  %t14 = icmp sge i64 %t12, 0
  br i1 %t14, label %bb1, label %bb2
bb1:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l45, !tbaa !29
  %t17 = load { i64, [7 x i64] }, ptr %l1
  %t19 = call %"compiler/source:Span" @compiler_2femit_2etermSpan({ i64, [7 x i64] } %t17)
  store %"compiler/source:Span" %t19, ptr %l47
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t20 = load ptr, ptr %l45, !tbaa !29
  %t21 = load %"compiler/source:Span", ptr %l47
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elocate(ptr %v0, ptr %t20, %"compiler/source:Span" %t21)
  br label %bb4
bb4:
  br label %bb5
bb5:
  %t22 = load { i64, [7 x i64] }, ptr %l1
  %t24 = extractvalue { i64, [7 x i64] } %t22, 0
  %t25 = icmp eq i64 %t24, 0
  br i1 %t25, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb10
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t27 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s2, ptr %t27, { i64, ptr } { i64 11, ptr @.d295 })
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb137
bb10:
  %t29 = load { i64, [7 x i64] }, ptr %l1
  %t31 = extractvalue { i64, [7 x i64] } %t29, 0
  %t32 = icmp eq i64 %t31, 1
  br i1 %t32, label %bb11, label %bb12
bb11:
  %t34 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t35 = getelementptr { i32 }, ptr %t34, i32 0, i32 0
  %t36 = load i32, ptr %t35
  store i32 %t36, ptr %l3, !tbaa !23
  br label %bb13
bb12:
  br label %bb16
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l54, !tbaa !29
  %t39 = load i32, ptr %l3, !tbaa !23
  %t41 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s3, i32 %t39)
  store { i64, ptr } %t41, ptr %l56
  br label %bb14
bb14:
  %t42 = extractvalue { i64, ptr } { i64 10, ptr @.d296 }, 1
  %t43 = extractvalue { i64, ptr } { i64 10, ptr @.d296 }, 0
  %t44 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t44, 1
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t47 = add i64 %t43, %t46
  %t48 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t47)
  call void @olang_textcopy(ptr %t48, ptr %t42, i64 %t43)
  %t49 = getelementptr i8, ptr %t48, i64 %t43
  call void @olang_textcopy(ptr %t49, ptr %t45, i64 %t46)
  %t50 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t48, 1
  %t53 = extractvalue { i64, ptr } %t51, 0
  %t54 = extractvalue { i64, ptr } %t51, 1
  %t55 = mul i64 %t53, 1
  %t56 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t55)
  call void @llvm.memcpy.p0.p0.i64(ptr %t56, ptr %t54, i64 %t55, i1 false)
  %t57 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  %t59 = load ptr, ptr %l54, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s3, ptr %t59, { i64, ptr } %t58)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb137
bb16:
  %t61 = load { i64, [7 x i64] }, ptr %l1
  %t63 = extractvalue { i64, [7 x i64] } %t61, 0
  %t64 = icmp eq i64 %t63, 2
  br i1 %t64, label %bb17, label %bb18
bb17:
  %t66 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t67 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t66, i32 0, i32 0
  %t68 = load { i64, [4 x i64] }, ptr %t67
  store { i64, [4 x i64] } %t68, ptr %l4
  %t70 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t71 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t70, i32 0, i32 1
  %t72 = load i32, ptr %t71
  store i32 %t72, ptr %l5, !tbaa !23
  %t74 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t75 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t74, i32 0, i32 2
  %t76 = load i32, ptr %t75
  store i32 %t76, ptr %l6, !tbaa !23
  br label %bb19
bb18:
  br label %bb24
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l64, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load { i64, [4 x i64] }, ptr %l4
  %t81 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t85 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s5, ptr %t79, { i64, [4 x i64] } %t80, i32 %t81)
  store { i64, ptr } %t85, ptr %l68
  br label %bb20
bb20:
  %t86 = load i32, ptr %l5, !tbaa !23
  %t88 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s5, i32 %t86)
  store { i64, ptr } %t88, ptr %l70
  br label %bb21
bb21:
  %t89 = load i32, ptr %l6, !tbaa !23
  %t91 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s5, i32 %t89)
  store { i64, ptr } %t91, ptr %l72
  br label %bb22
bb22:
  %t92 = extractvalue { i64, ptr } { i64 6, ptr @.d297 }, 1
  %t93 = extractvalue { i64, ptr } { i64 6, ptr @.d297 }, 0
  %t94 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 1
  %t96 = extractvalue { i64, ptr } %t94, 0
  %t97 = add i64 %t93, %t96
  %t98 = extractvalue { i64, ptr } { i64 9, ptr @.d298 }, 1
  %t99 = extractvalue { i64, ptr } { i64 9, ptr @.d298 }, 0
  %t100 = add i64 %t97, %t99
  %t101 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 1
  %t103 = extractvalue { i64, ptr } %t101, 0
  %t104 = add i64 %t100, %t103
  %t105 = extractvalue { i64, ptr } { i64 9, ptr @.d299 }, 1
  %t106 = extractvalue { i64, ptr } { i64 9, ptr @.d299 }, 0
  %t107 = add i64 %t104, %t106
  %t108 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t108, 1
  %t110 = extractvalue { i64, ptr } %t108, 0
  %t111 = add i64 %t107, %t110
  %t112 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t111)
  call void @olang_textcopy(ptr %t112, ptr %t92, i64 %t93)
  %t113 = getelementptr i8, ptr %t112, i64 %t93
  call void @olang_textcopy(ptr %t113, ptr %t95, i64 %t96)
  %t114 = getelementptr i8, ptr %t113, i64 %t96
  call void @olang_textcopy(ptr %t114, ptr %t98, i64 %t99)
  %t115 = getelementptr i8, ptr %t114, i64 %t99
  call void @olang_textcopy(ptr %t115, ptr %t102, i64 %t103)
  %t116 = getelementptr i8, ptr %t115, i64 %t103
  call void @olang_textcopy(ptr %t116, ptr %t105, i64 %t106)
  %t117 = getelementptr i8, ptr %t116, i64 %t106
  call void @olang_textcopy(ptr %t117, ptr %t109, i64 %t110)
  %t118 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t112, 1
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t122 = extractvalue { i64, ptr } %t119, 1
  %t123 = mul i64 %t121, 1
  %t124 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t123)
  call void @llvm.memcpy.p0.p0.i64(ptr %t124, ptr %t122, i64 %t123, i1 false)
  %t125 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t124, 1
  %t127 = load ptr, ptr %l64, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s5, ptr %t127, { i64, ptr } %t126)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s5)
  br label %bb137
bb24:
  %t129 = load { i64, [7 x i64] }, ptr %l1
  %t131 = extractvalue { i64, [7 x i64] } %t129, 0
  %t132 = icmp eq i64 %t131, 3
  br i1 %t132, label %bb25, label %bb26
bb25:
  %t134 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t135 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t134, i32 0, i32 0
  %t136 = load { i64, [4 x i64] }, ptr %t135
  store { i64, [4 x i64] } %t136, ptr %l7
  %t138 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t139 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t138, i32 0, i32 1
  %t140 = load %"compiler/mir:Range", ptr %t139
  store %"compiler/mir:Range" %t140, ptr %l8
  %t142 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t143 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t142, i32 0, i32 2
  %t144 = load i32, ptr %t143
  store i32 %t144, ptr %l9, !tbaa !23
  br label %bb27
bb26:
  br label %bb53
bb27:
  store %olang.scope zeroinitializer, ptr %s7
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load { i64, [4 x i64] }, ptr %l7
  %t150 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %t146, { i64, [4 x i64] } %t147)
  store i32 %t150, ptr %l82
  br label %bb28
bb28:
  %t151 = load i32, ptr %l82, !tbaa !23
  store i32 %t151, ptr %l10, !tbaa !23
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load i32, ptr %l10, !tbaa !23
  %t156 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s7, ptr %t152, i32 %t153)
  store { i64, ptr } %t156, ptr %l85
  br label %bb29
bb29:
  %t157 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t157, ptr %l11, !tbaa !27
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load { i64, [4 x i64] }, ptr %l7
  %t160 = load i32, ptr %l10, !tbaa !23
  %t164 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s7, ptr %t158, { i64, [4 x i64] } %t159, i32 %t160)
  store { i64, ptr } %t164, ptr %l89
  br label %bb30
bb30:
  %t165 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t165, ptr %l12, !tbaa !27
  %t166 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s7)
  store %"std/prelude/text:StringBuilder" %t166, ptr %l90
  br label %bb31
bb31:
  %t167 = load %"std/prelude/text:StringBuilder", ptr %l90
  store %"std/prelude/text:StringBuilder" %t167, ptr %l13
  store ptr %l13, ptr %l91, !tbaa !29
  %t168 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t168, ptr %l92, !tbaa !27
  %t169 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t169, ptr %l93, !tbaa !27
  %t170 = load i32, ptr %l9, !tbaa !23
  %t172 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s7, i32 %t170)
  store { i64, ptr } %t172, ptr %l95
  br label %bb32
bb32:
  %t173 = extractvalue { i64, ptr } { i64 7, ptr @.d300 }, 1
  %t174 = extractvalue { i64, ptr } { i64 7, ptr @.d300 }, 0
  %t175 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t176 = extractvalue { i64, ptr } %t175, 1
  %t177 = extractvalue { i64, ptr } %t175, 0
  %t178 = add i64 %t174, %t177
  %t179 = extractvalue { i64, ptr } { i64 1, ptr @.d301 }, 1
  %t180 = extractvalue { i64, ptr } { i64 1, ptr @.d301 }, 0
  %t181 = add i64 %t178, %t180
  %t182 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t182, 1
  %t184 = extractvalue { i64, ptr } %t182, 0
  %t185 = add i64 %t181, %t184
  %t186 = extractvalue { i64, ptr } { i64 9, ptr @.d302 }, 1
  %t187 = extractvalue { i64, ptr } { i64 9, ptr @.d302 }, 0
  %t188 = add i64 %t185, %t187
  %t189 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t189, 1
  %t191 = extractvalue { i64, ptr } %t189, 0
  %t192 = add i64 %t188, %t191
  %t193 = extractvalue { i64, ptr } { i64 2, ptr @.d303 }, 1
  %t194 = extractvalue { i64, ptr } { i64 2, ptr @.d303 }, 0
  %t195 = add i64 %t192, %t194
  %t196 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t195)
  call void @olang_textcopy(ptr %t196, ptr %t173, i64 %t174)
  %t197 = getelementptr i8, ptr %t196, i64 %t174
  call void @olang_textcopy(ptr %t197, ptr %t176, i64 %t177)
  %t198 = getelementptr i8, ptr %t197, i64 %t177
  call void @olang_textcopy(ptr %t198, ptr %t179, i64 %t180)
  %t199 = getelementptr i8, ptr %t198, i64 %t180
  call void @olang_textcopy(ptr %t199, ptr %t183, i64 %t184)
  %t200 = getelementptr i8, ptr %t199, i64 %t184
  call void @olang_textcopy(ptr %t200, ptr %t186, i64 %t187)
  %t201 = getelementptr i8, ptr %t200, i64 %t187
  call void @olang_textcopy(ptr %t201, ptr %t190, i64 %t191)
  %t202 = getelementptr i8, ptr %t201, i64 %t191
  call void @olang_textcopy(ptr %t202, ptr %t193, i64 %t194)
  %t203 = insertvalue { i64, ptr } undef, i64 %t195, 0
  %t204 = insertvalue { i64, ptr } %t203, ptr %t196, 1
  %t206 = extractvalue { i64, ptr } %t204, 0
  %t207 = extractvalue { i64, ptr } %t204, 1
  %t208 = mul i64 %t206, 1
  %t209 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t208)
  call void @llvm.memcpy.p0.p0.i64(ptr %t209, ptr %t207, i64 %t208, i1 false)
  %t210 = insertvalue { i64, ptr } undef, i64 %t206, 0
  %t211 = insertvalue { i64, ptr } %t210, ptr %t209, 1
  %t212 = load ptr, ptr %l91, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s7, ptr %s7, ptr %t212, { i64, ptr } %t211)
  br label %bb33
bb33:
  store i32 0, ptr %l14, !tbaa !23
  %t214 = getelementptr %"compiler/mir:Range", ptr %l8, i32 0, i32 1
  %t215 = load i32, ptr %t214, !tbaa !23
  store i32 %t215, ptr %l15, !tbaa !23
  store i32 1, ptr %l16, !tbaa !23
  %t217 = load i32, ptr %l15, !tbaa !23
  %t218 = load i32, ptr %l14, !tbaa !23
  %t221 = icmp sgt i32 %t217, %t218
  br i1 %t221, label %bb34, label %bb35
bb34:
  %t223 = load i32, ptr %l16, !tbaa !23
  %t225 = icmp sgt i32 %t223, 0
  br i1 %t225, label %bb36, label %bb37
bb35:
  store i32 0, ptr %l102, !tbaa !23
  br label %bb39
bb36:
  %t227 = load i32, ptr %l15, !tbaa !23
  %t228 = load i32, ptr %l14, !tbaa !23
  %t231 = sub i32 %t227, %t228
  %t232 = load i32, ptr %l16, !tbaa !23
  %t235 = add i32 %t231, %t232
  %t237 = sub i32 %t235, 1
  %t238 = load i32, ptr %l16, !tbaa !23
  %t241 = sdiv i32 %t237, %t238
  store i32 %t241, ptr %l105, !tbaa !23
  br label %bb38
bb37:
  store i32 0, ptr %l105, !tbaa !23
  br label %bb38
bb38:
  %t243 = load i32, ptr %l105, !tbaa !23
  store i32 %t243, ptr %l102, !tbaa !23
  br label %bb39
bb39:
  %t244 = load i32, ptr %l102, !tbaa !23
  store i32 %t244, ptr %l17, !tbaa !23
  store i32 0, ptr %l18, !tbaa !23
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s10
  %t245 = load i32, ptr %l18, !tbaa !23
  %t246 = load i32, ptr %l17, !tbaa !23
  %t249 = icmp slt i32 %t245, %t246
  %t251 = xor i1 %t249, true
  br i1 %t251, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s10)
  br label %bb49
bb42:
  br label %bb43
bb43:
  %t253 = load i32, ptr %l14, !tbaa !23
  %t254 = load i32, ptr %l18, !tbaa !23
  %t255 = load i32, ptr %l16, !tbaa !23
  %t258 = mul i32 %t254, %t255
  %t261 = add i32 %t253, %t258
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = getelementptr %"compiler/emit:fnEm", ptr %t263, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !29
  %t268 = getelementptr %"compiler/mir:Fn", ptr %t266, i32 0, i32 15
  %t269 = getelementptr %"compiler/mir:Range", ptr %l8, i32 0, i32 0
  %t270 = load i32, ptr %t269, !tbaa !23
  %t272 = sext i32 %t270 to i64
  %t275 = sext i32 %t261 to i64
  %t278 = add i64 %t272, %t275
  %t281 = call %"compiler/mir:Case" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCase_3e_2eAt_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %t268, i64 %t278)
  store %"compiler/mir:Case" %t281, ptr %l131
  br label %bb44
bb44:
  %t282 = load %"compiler/mir:Case", ptr %l131
  store %"compiler/mir:Case" %t282, ptr %l20
  store ptr %l13, ptr %l132, !tbaa !29
  %t283 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t283, ptr %l133, !tbaa !27
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t286 = getelementptr %"compiler/emit:fnEm", ptr %t284, i32 0, i32 0
  %t287 = load ptr, ptr %t286, !tbaa !29
  %t288 = load i32, ptr %l10, !tbaa !23
  %t289 = getelementptr %"compiler/mir:Case", ptr %l20, i32 0, i32 0
  %t290 = load i64, ptr %t289, !tbaa !24
  %t294 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2econstText(ptr %v0, ptr %s10, ptr %t287, i32 %t288, i64 %t290)
  store { i64, ptr } %t294, ptr %l138
  br label %bb45
bb45:
  %t295 = getelementptr %"compiler/mir:Case", ptr %l20, i32 0, i32 1
  %t296 = load i32, ptr %t295, !tbaa !23
  %t298 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s10, i32 %t296)
  store { i64, ptr } %t298, ptr %l140
  br label %bb46
bb46:
  %t299 = extractvalue { i64, ptr } { i64 1, ptr @.d304 }, 1
  %t300 = extractvalue { i64, ptr } { i64 1, ptr @.d304 }, 0
  %t301 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t302 = extractvalue { i64, ptr } %t301, 1
  %t303 = extractvalue { i64, ptr } %t301, 0
  %t304 = add i64 %t300, %t303
  %t305 = extractvalue { i64, ptr } { i64 1, ptr @.d305 }, 1
  %t306 = extractvalue { i64, ptr } { i64 1, ptr @.d305 }, 0
  %t307 = add i64 %t304, %t306
  %t308 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t309 = extractvalue { i64, ptr } %t308, 1
  %t310 = extractvalue { i64, ptr } %t308, 0
  %t311 = add i64 %t307, %t310
  %t312 = extractvalue { i64, ptr } { i64 9, ptr @.d306 }, 1
  %t313 = extractvalue { i64, ptr } { i64 9, ptr @.d306 }, 0
  %t314 = add i64 %t311, %t313
  %t315 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t316 = extractvalue { i64, ptr } %t315, 1
  %t317 = extractvalue { i64, ptr } %t315, 0
  %t318 = add i64 %t314, %t317
  %t319 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t318)
  call void @olang_textcopy(ptr %t319, ptr %t299, i64 %t300)
  %t320 = getelementptr i8, ptr %t319, i64 %t300
  call void @olang_textcopy(ptr %t320, ptr %t302, i64 %t303)
  %t321 = getelementptr i8, ptr %t320, i64 %t303
  call void @olang_textcopy(ptr %t321, ptr %t305, i64 %t306)
  %t322 = getelementptr i8, ptr %t321, i64 %t306
  call void @olang_textcopy(ptr %t322, ptr %t309, i64 %t310)
  %t323 = getelementptr i8, ptr %t322, i64 %t310
  call void @olang_textcopy(ptr %t323, ptr %t312, i64 %t313)
  %t324 = getelementptr i8, ptr %t323, i64 %t313
  call void @olang_textcopy(ptr %t324, ptr %t316, i64 %t317)
  %t325 = insertvalue { i64, ptr } undef, i64 %t318, 0
  %t326 = insertvalue { i64, ptr } %t325, ptr %t319, 1
  %t328 = extractvalue { i64, ptr } %t326, 0
  %t329 = extractvalue { i64, ptr } %t326, 1
  %t330 = mul i64 %t328, 1
  %t331 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t330)
  call void @llvm.memcpy.p0.p0.i64(ptr %t331, ptr %t329, i64 %t330, i1 false)
  %t332 = insertvalue { i64, ptr } undef, i64 %t328, 0
  %t333 = insertvalue { i64, ptr } %t332, ptr %t331, 1
  %t334 = load ptr, ptr %l132, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s7, ptr %s10, ptr %t334, { i64, ptr } %t333)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s10)
  br label %bb48
bb48:
  %t336 = load i32, ptr %l18, !tbaa !23
  %t338 = add i32 %t336, 1
  store i32 %t338, ptr %l18, !tbaa !23
  br label %bb40
bb49:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s7, ptr %s7, ptr %l13, { i64, ptr } { i64 2, ptr @.d307 })
  br label %bb50
bb50:
  %t341 = load ptr, ptr %l0, !tbaa !29
  store ptr %t341, ptr %l146, !tbaa !29
  %t343 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s7, ptr %s7, ptr %l13)
  store { i64, ptr } %t343, ptr %l148
  br label %bb51
bb51:
  %t344 = load ptr, ptr %l146, !tbaa !29
  %t345 = load { i64, ptr }, ptr %l148, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s7, ptr %t344, { i64, ptr } %t345)
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s7)
  br label %bb137
bb53:
  %t346 = load { i64, [7 x i64] }, ptr %l1
  %t348 = extractvalue { i64, [7 x i64] } %t346, 0
  %t349 = icmp eq i64 %t348, 4
  br i1 %t349, label %bb54, label %bb55
bb54:
  %t351 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t352 = getelementptr { %"compiler/source:Span", i32 }, ptr %t351, i32 0, i32 1
  %t353 = load i32, ptr %t352
  store i32 %t353, ptr %l21, !tbaa !23
  br label %bb56
bb55:
  br label %bb59
bb56:
  %t355 = load ptr, ptr %l0, !tbaa !29
  store ptr %t355, ptr %l152, !tbaa !29
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t358 = getelementptr %"compiler/emit:fnEm", ptr %t356, i32 0, i32 1
  %t359 = load ptr, ptr %t358, !tbaa !29
  %t361 = getelementptr %"compiler/mir:Fn", ptr %t359, i32 0, i32 14
  %t362 = load i32, ptr %l21, !tbaa !23
  %t364 = sext i32 %t362 to i64
  %t367 = call %"compiler/mir:Call" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t361, i64 %t364)
  store %"compiler/mir:Call" %t367, ptr %l158
  br label %bb57
bb57:
  %t368 = load ptr, ptr %l152, !tbaa !29
  %t369 = load %"compiler/mir:Call", ptr %l158
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ecall(ptr %v0, ptr %t368, %"compiler/mir:Call" %t369)
  br label %bb58
bb58:
  br label %bb137
bb59:
  %t370 = load { i64, [7 x i64] }, ptr %l1
  %t372 = extractvalue { i64, [7 x i64] } %t370, 0
  %t373 = icmp eq i64 %t372, 5
  br i1 %t373, label %bb60, label %bb61
bb60:
  %t375 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t376 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t375, i32 0, i32 1
  %t377 = load { i64, [4 x i64] }, ptr %t376
  store { i64, [4 x i64] } %t377, ptr %l22
  br label %bb62
bb61:
  br label %bb90
bb62:
  store %olang.scope zeroinitializer, ptr %s14
  %t379 = load ptr, ptr %l2, !tbaa !29
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t382 = getelementptr %"compiler/emit:fnEm", ptr %t380, i32 0, i32 1
  %t383 = load ptr, ptr %t382, !tbaa !29
  %t385 = getelementptr %"compiler/mir:Fn", ptr %t383, i32 0, i32 1
  %t386 = load i32, ptr %t385, !tbaa !23
  %t389 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %s14, ptr %t379, i32 %t386)
  store { i64, ptr } %t389, ptr %l166
  br label %bb63
bb63:
  %t390 = load { i64, ptr }, ptr %l166, !tbaa !27
  store { i64, ptr } %t390, ptr %l23, !tbaa !27
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t393 = getelementptr %"compiler/emit:fnEm", ptr %t391, i32 0, i32 11
  %t394 = load i1, ptr %t393, !tbaa !21
  br i1 %t394, label %bb64, label %bb65
bb64:
  store %olang.scope zeroinitializer, ptr %s15
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t399 = getelementptr %"compiler/emit:fnEm", ptr %t397, i32 0, i32 9
  %t400 = load i32, ptr %t399, !tbaa !23
  %t401 = load { i64, [4 x i64] }, ptr %l22
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eput(ptr %v0, ptr %s15, ptr %s15, ptr %t396, { i64, ptr } { i64 4, ptr @.d308 }, i32 %t400, { i64, [4 x i64] } %t401, { i64, ptr } { i64 0, ptr @.d309 })
  br label %bb66
bb65:
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t407 = getelementptr %"compiler/emit:fnEm", ptr %t405, i32 0, i32 10
  %t408 = load i1, ptr %t407, !tbaa !21
  br i1 %t408, label %bb71, label %bb72
bb66:
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t412 = getelementptr %"compiler/emit:fnEm", ptr %t410, i32 0, i32 10
  %t413 = load i1, ptr %t412, !tbaa !21
  br i1 %t413, label %bb67, label %bb68
bb67:
  store %olang.scope zeroinitializer, ptr %s16
  %t415 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s16, ptr %s16, ptr %s16, ptr %s16, ptr %t415, { i64, ptr } { i64 3, ptr @.d310 }, { i64, ptr } { i64 1, ptr @.d311 }, { i64, ptr } { i64 3, ptr @.d312 }, { i64, ptr } { i64 0, ptr @.d313 })
  br label %bb69
bb68:
  br label %bb70
bb69:
  call void @__olang_scope_close(ptr %s16)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s15)
  br label %bb88
bb71:
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t419 = getelementptr %"compiler/emit:fnEm", ptr %t417, i32 0, i32 9
  %t420 = load i32, ptr %t419, !tbaa !23
  %t421 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t424 = icmp eq i32 %t420, %t421
  br i1 %t424, label %bb73, label %bb74
bb72:
  store %olang.scope zeroinitializer, ptr %s22
  %t426 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t428 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s14, ptr %s22, { i64, ptr } %t426, { i64, ptr } { i64 4, ptr @.d314 })
  store i1 %t428, ptr %l201
  br label %bb81
bb73:
  store %olang.scope zeroinitializer, ptr %s19
  %t429 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s19, ptr %s19, ptr %s19, ptr %s19, ptr %t429, { i64, ptr } { i64 3, ptr @.d315 }, { i64, ptr } { i64 1, ptr @.d316 }, { i64, ptr } { i64 3, ptr @.d317 }, { i64, ptr } { i64 0, ptr @.d318 })
  br label %bb75
bb74:
  store %olang.scope zeroinitializer, ptr %s20
  %t431 = load ptr, ptr %l0, !tbaa !29
  store ptr %t431, ptr %l183, !tbaa !29
  %t432 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t432, ptr %l184, !tbaa !27
  %t433 = load ptr, ptr %l0, !tbaa !29
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t436 = getelementptr %"compiler/emit:fnEm", ptr %t434, i32 0, i32 9
  %t437 = load i32, ptr %t436, !tbaa !23
  %t440 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s20, ptr %t433, i32 %t437)
  store { i64, ptr } %t440, ptr %l188
  br label %bb76
bb75:
  call void @__olang_scope_close(ptr %s19)
  br label %bb80
bb76:
  %t441 = load ptr, ptr %l0, !tbaa !29
  %t442 = load { i64, [4 x i64] }, ptr %l22
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t445 = getelementptr %"compiler/emit:fnEm", ptr %t443, i32 0, i32 9
  %t446 = load i32, ptr %t445, !tbaa !23
  %t450 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s20, ptr %t441, { i64, [4 x i64] } %t442, i32 %t446)
  store { i64, ptr } %t450, ptr %l193
  br label %bb77
bb77:
  %t451 = extractvalue { i64, ptr } { i64 12, ptr @.d319 }, 1
  %t452 = extractvalue { i64, ptr } { i64 12, ptr @.d319 }, 0
  %t453 = load { i64, ptr }, ptr %l184, !tbaa !27
  %t454 = extractvalue { i64, ptr } %t453, 1
  %t455 = extractvalue { i64, ptr } %t453, 0
  %t456 = add i64 %t452, %t455
  %t457 = extractvalue { i64, ptr } { i64 18, ptr @.d320 }, 1
  %t458 = extractvalue { i64, ptr } { i64 18, ptr @.d320 }, 0
  %t459 = add i64 %t456, %t458
  %t460 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t461 = extractvalue { i64, ptr } %t460, 1
  %t462 = extractvalue { i64, ptr } %t460, 0
  %t463 = add i64 %t459, %t462
  %t464 = extractvalue { i64, ptr } { i64 1, ptr @.d321 }, 1
  %t465 = extractvalue { i64, ptr } { i64 1, ptr @.d321 }, 0
  %t466 = add i64 %t463, %t465
  %t467 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t468 = extractvalue { i64, ptr } %t467, 1
  %t469 = extractvalue { i64, ptr } %t467, 0
  %t470 = add i64 %t466, %t469
  %t471 = extractvalue { i64, ptr } { i64 3, ptr @.d322 }, 1
  %t472 = extractvalue { i64, ptr } { i64 3, ptr @.d322 }, 0
  %t473 = add i64 %t470, %t472
  %t474 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t473)
  call void @olang_textcopy(ptr %t474, ptr %t451, i64 %t452)
  %t475 = getelementptr i8, ptr %t474, i64 %t452
  call void @olang_textcopy(ptr %t475, ptr %t454, i64 %t455)
  %t476 = getelementptr i8, ptr %t475, i64 %t455
  call void @olang_textcopy(ptr %t476, ptr %t457, i64 %t458)
  %t477 = getelementptr i8, ptr %t476, i64 %t458
  call void @olang_textcopy(ptr %t477, ptr %t461, i64 %t462)
  %t478 = getelementptr i8, ptr %t477, i64 %t462
  call void @olang_textcopy(ptr %t478, ptr %t464, i64 %t465)
  %t479 = getelementptr i8, ptr %t478, i64 %t465
  call void @olang_textcopy(ptr %t479, ptr %t468, i64 %t469)
  %t480 = getelementptr i8, ptr %t479, i64 %t469
  call void @olang_textcopy(ptr %t480, ptr %t471, i64 %t472)
  %t481 = insertvalue { i64, ptr } undef, i64 %t473, 0
  %t482 = insertvalue { i64, ptr } %t481, ptr %t474, 1
  %t484 = extractvalue { i64, ptr } %t482, 0
  %t485 = extractvalue { i64, ptr } %t482, 1
  %t486 = mul i64 %t484, 1
  %t487 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t486)
  call void @llvm.memcpy.p0.p0.i64(ptr %t487, ptr %t485, i64 %t486, i1 false)
  %t488 = insertvalue { i64, ptr } undef, i64 %t484, 0
  %t489 = insertvalue { i64, ptr } %t488, ptr %t487, 1
  %t490 = load ptr, ptr %l183, !tbaa !29
  %t492 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s20, ptr %s20, ptr %t490, { i64, ptr } %t489)
  store { i64, ptr } %t492, ptr %l196
  br label %bb78
bb78:
  %t493 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t494 = load ptr, ptr %l0, !tbaa !29
  %t495 = load { i64, ptr }, ptr %l23, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s14, ptr %s20, ptr %s20, ptr %s20, ptr %t494, { i64, ptr } %t495, { i64, ptr } %t493, { i64, ptr } { i64 3, ptr @.d323 }, { i64, ptr } { i64 0, ptr @.d324 })
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s20)
  br label %bb80
bb80:
  br label %bb87
bb81:
  %t500 = load i1, ptr %l201, !tbaa !21
  %t501 = xor i1 %t500, true
  br i1 %t501, label %bb82, label %bb83
bb82:
  store %olang.scope zeroinitializer, ptr %s23
  %t503 = load ptr, ptr %l0, !tbaa !29
  store ptr %t503, ptr %l203, !tbaa !29
  %t504 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t504, ptr %l204, !tbaa !27
  %t505 = load ptr, ptr %l0, !tbaa !29
  %t506 = load { i64, [4 x i64] }, ptr %l22
  %t507 = load ptr, ptr %l0, !tbaa !29
  %t509 = getelementptr %"compiler/emit:fnEm", ptr %t507, i32 0, i32 9
  %t510 = load i32, ptr %t509, !tbaa !23
  %t514 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s23, ptr %t505, { i64, [4 x i64] } %t506, i32 %t510)
  store { i64, ptr } %t514, ptr %l209
  br label %bb84
bb83:
  br label %bb86
bb84:
  %t515 = load { i64, ptr }, ptr %l209, !tbaa !27
  %t516 = extractvalue { i64, ptr } %t515, 0
  %t517 = extractvalue { i64, ptr } %t515, 1
  %t518 = mul i64 %t516, 1
  %t519 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t518)
  call void @llvm.memcpy.p0.p0.i64(ptr %t519, ptr %t517, i64 %t518, i1 false)
  %t520 = insertvalue { i64, ptr } undef, i64 %t516, 0
  %t521 = insertvalue { i64, ptr } %t520, ptr %t519, 1
  %t522 = load ptr, ptr %l203, !tbaa !29
  %t523 = load { i64, ptr }, ptr %l204, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s14, ptr %s23, ptr %s23, ptr %s23, ptr %t522, { i64, ptr } %t523, { i64, ptr } %t521, { i64, ptr } { i64 3, ptr @.d325 }, { i64, ptr } { i64 0, ptr @.d326 })
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s23)
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s22)
  br label %bb87
bb87:
  br label %bb88
bb88:
  %t525 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s14, ptr %t525, { i64, ptr } { i64 13, ptr @.d327 })
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s14)
  br label %bb137
bb90:
  %t527 = load { i64, [7 x i64] }, ptr %l1
  %t529 = extractvalue { i64, [7 x i64] } %t527, 0
  %t530 = icmp eq i64 %t529, 6
  br i1 %t530, label %bb91, label %bb92
bb91:
  %t532 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t533 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t532, i32 0, i32 0
  %t534 = load %"compiler/source:Span", ptr %t533
  store %"compiler/source:Span" %t534, ptr %l25
  %t536 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t537 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t536, i32 0, i32 1
  %t538 = load { i64, [4 x i64] }, ptr %t537
  store { i64, [4 x i64] } %t538, ptr %l26
  br label %bb93
bb92:
  br label %bb105
bb93:
  store %olang.scope zeroinitializer, ptr %s24
  %t540 = load ptr, ptr %l0, !tbaa !29
  %t541 = load %"compiler/source:Span", ptr %l25
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2etrace(ptr %v0, ptr %t540, %"compiler/source:Span" %t541)
  br label %bb94
bb94:
  %t544 = load ptr, ptr %l2, !tbaa !29
  %t545 = load ptr, ptr %l0, !tbaa !29
  %t547 = getelementptr %"compiler/emit:fnEm", ptr %t545, i32 0, i32 1
  %t548 = load ptr, ptr %t547, !tbaa !29
  %t550 = getelementptr %"compiler/mir:Fn", ptr %t548, i32 0, i32 1
  %t551 = load i32, ptr %t550, !tbaa !23
  %t554 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %s24, ptr %t544, i32 %t551)
  store { i64, ptr } %t554, ptr %l222
  br label %bb95
bb95:
  %t555 = load { i64, ptr }, ptr %l222, !tbaa !27
  store { i64, ptr } %t555, ptr %l27, !tbaa !27
  %t556 = load ptr, ptr %l0, !tbaa !29
  %t557 = load { i64, [4 x i64] }, ptr %l26
  %t558 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t562 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s24, ptr %t556, { i64, [4 x i64] } %t557, i32 %t558)
  store { i64, ptr } %t562, ptr %l226
  br label %bb96
bb96:
  %t563 = load { i64, ptr }, ptr %l226, !tbaa !27
  store { i64, ptr } %t563, ptr %l28, !tbaa !27
  %t564 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t566 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s24, ptr %s24, { i64, ptr } %t564, { i64, ptr } { i64 3, ptr @.d328 })
  store i1 %t566, ptr %l228
  br label %bb97
bb97:
  %t567 = load i1, ptr %l228, !tbaa !21
  br i1 %t567, label %bb98, label %bb99
bb98:
  store %olang.scope zeroinitializer, ptr %s25
  %t568 = load ptr, ptr %l0, !tbaa !29
  %t569 = load { i64, ptr }, ptr %l28, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s25, ptr %s24, ptr %s25, ptr %s25, ptr %t568, { i64, ptr } { i64 3, ptr @.d329 }, { i64, ptr } %t569, { i64, ptr } { i64 3, ptr @.d330 }, { i64, ptr } { i64 0, ptr @.d331 })
  br label %bb100
bb99:
  store %olang.scope zeroinitializer, ptr %s26
  %t572 = load ptr, ptr %l0, !tbaa !29
  store ptr %t572, ptr %l231, !tbaa !29
  %t573 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t573, ptr %l232, !tbaa !27
  %t574 = load ptr, ptr %l0, !tbaa !29
  %t575 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t576 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t577 = extractvalue { i64, ptr } { i64 12, ptr @.d332 }, 1
  %t578 = extractvalue { i64, ptr } { i64 12, ptr @.d332 }, 0
  %t580 = extractvalue { i64, ptr } %t575, 1
  %t581 = extractvalue { i64, ptr } %t575, 0
  %t582 = add i64 %t578, %t581
  %t583 = extractvalue { i64, ptr } { i64 22, ptr @.d333 }, 1
  %t584 = extractvalue { i64, ptr } { i64 22, ptr @.d333 }, 0
  %t585 = add i64 %t582, %t584
  %t587 = extractvalue { i64, ptr } %t576, 1
  %t588 = extractvalue { i64, ptr } %t576, 0
  %t589 = add i64 %t585, %t588
  %t590 = extractvalue { i64, ptr } { i64 3, ptr @.d334 }, 1
  %t591 = extractvalue { i64, ptr } { i64 3, ptr @.d334 }, 0
  %t592 = add i64 %t589, %t591
  %t593 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t592)
  call void @olang_textcopy(ptr %t593, ptr %t577, i64 %t578)
  %t594 = getelementptr i8, ptr %t593, i64 %t578
  call void @olang_textcopy(ptr %t594, ptr %t580, i64 %t581)
  %t595 = getelementptr i8, ptr %t594, i64 %t581
  call void @olang_textcopy(ptr %t595, ptr %t583, i64 %t584)
  %t596 = getelementptr i8, ptr %t595, i64 %t584
  call void @olang_textcopy(ptr %t596, ptr %t587, i64 %t588)
  %t597 = getelementptr i8, ptr %t596, i64 %t588
  call void @olang_textcopy(ptr %t597, ptr %t590, i64 %t591)
  %t598 = insertvalue { i64, ptr } undef, i64 %t592, 0
  %t599 = insertvalue { i64, ptr } %t598, ptr %t593, 1
  %t601 = extractvalue { i64, ptr } %t599, 0
  %t602 = extractvalue { i64, ptr } %t599, 1
  %t603 = mul i64 %t601, 1
  %t604 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t603)
  call void @llvm.memcpy.p0.p0.i64(ptr %t604, ptr %t602, i64 %t603, i1 false)
  %t605 = insertvalue { i64, ptr } undef, i64 %t601, 0
  %t606 = insertvalue { i64, ptr } %t605, ptr %t604, 1
  %t609 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s26, ptr %s26, ptr %t574, { i64, ptr } %t606)
  store { i64, ptr } %t609, ptr %l238
  br label %bb101
bb100:
  call void @__olang_scope_close(ptr %s25)
  br label %bb103
bb101:
  %t610 = load { i64, ptr }, ptr %l238, !tbaa !27
  %t611 = extractvalue { i64, ptr } %t610, 0
  %t612 = extractvalue { i64, ptr } %t610, 1
  %t613 = mul i64 %t611, 1
  %t614 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t613)
  call void @llvm.memcpy.p0.p0.i64(ptr %t614, ptr %t612, i64 %t613, i1 false)
  %t615 = insertvalue { i64, ptr } undef, i64 %t611, 0
  %t616 = insertvalue { i64, ptr } %t615, ptr %t614, 1
  %t617 = load ptr, ptr %l231, !tbaa !29
  %t618 = load { i64, ptr }, ptr %l232, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s24, ptr %s26, ptr %s26, ptr %s26, ptr %t617, { i64, ptr } %t618, { i64, ptr } %t616, { i64, ptr } { i64 3, ptr @.d335 }, { i64, ptr } { i64 0, ptr @.d336 })
  br label %bb102
bb102:
  call void @__olang_scope_close(ptr %s26)
  br label %bb103
bb103:
  %t620 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s24, ptr %t620, { i64, ptr } { i64 13, ptr @.d337 })
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s24)
  br label %bb137
bb105:
  %t622 = load { i64, [7 x i64] }, ptr %l1
  %t624 = extractvalue { i64, [7 x i64] } %t622, 0
  %t625 = icmp eq i64 %t624, 7
  br i1 %t625, label %bb106, label %bb107
bb106:
  %t627 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t628 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t627, i32 0, i32 1
  %t629 = load i32, ptr %t628
  store i32 %t629, ptr %l29, !tbaa !23
  %t631 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t632 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t631, i32 0, i32 2
  %t633 = load i32, ptr %t632
  store i32 %t633, ptr %l30, !tbaa !23
  %t635 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t636 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t635, i32 0, i32 3
  %t637 = load i32, ptr %t636
  store i32 %t637, ptr %l31, !tbaa !23
  %t639 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t640 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t639, i32 0, i32 4
  %t641 = load i32, ptr %t640
  store i32 %t641, ptr %l32, !tbaa !23
  br label %bb108
bb107:
  br label %bb126
bb108:
  store %olang.scope zeroinitializer, ptr %s28
  %t643 = load ptr, ptr %l0, !tbaa !29
  %t645 = getelementptr %"compiler/emit:fnEm", ptr %t643, i32 0, i32 0
  %t646 = load ptr, ptr %t645, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s28, ptr %s28, ptr %t646, { i64, ptr } { i64 18, ptr @.d338 }, { i64, ptr } { i64 28, ptr @.d339 })
  br label %bb109
bb109:
  %t648 = load ptr, ptr %l0, !tbaa !29
  %t649 = load i32, ptr %l29, !tbaa !23
  %t650 = extractvalue { i64, ptr } { i64 36, ptr @.d340 }, 1
  %t651 = extractvalue { i64, ptr } { i64 36, ptr @.d340 }, 0
  %t653 = sext i32 %t649 to i64
  %t654 = call i64 @__olang_fmt_i64(ptr null, i64 %t653)
  %t655 = add i64 %t651, %t654
  %t656 = extractvalue { i64, ptr } { i64 1, ptr @.d341 }, 1
  %t657 = extractvalue { i64, ptr } { i64 1, ptr @.d341 }, 0
  %t658 = add i64 %t655, %t657
  %t659 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t658)
  call void @olang_textcopy(ptr %t659, ptr %t650, i64 %t651)
  %t660 = getelementptr i8, ptr %t659, i64 %t651
  %t661 = call i64 @__olang_fmt_i64(ptr %t660, i64 %t653)
  %t662 = getelementptr i8, ptr %t660, i64 %t654
  call void @olang_textcopy(ptr %t662, ptr %t656, i64 %t657)
  %t663 = insertvalue { i64, ptr } undef, i64 %t658, 0
  %t664 = insertvalue { i64, ptr } %t663, ptr %t659, 1
  %t666 = extractvalue { i64, ptr } %t664, 0
  %t667 = extractvalue { i64, ptr } %t664, 1
  %t668 = mul i64 %t666, 1
  %t669 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t668)
  call void @llvm.memcpy.p0.p0.i64(ptr %t669, ptr %t667, i64 %t668, i1 false)
  %t670 = insertvalue { i64, ptr } undef, i64 %t666, 0
  %t671 = insertvalue { i64, ptr } %t670, ptr %t669, 1
  %t674 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s28, ptr %s28, ptr %t648, { i64, ptr } %t671)
  store { i64, ptr } %t674, ptr %l253
  br label %bb110
bb110:
  %t675 = load { i64, ptr }, ptr %l253, !tbaa !27
  store { i64, ptr } %t675, ptr %l33, !tbaa !27
  %t676 = load i32, ptr %l32, !tbaa !23
  %t677 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t680 = icmp eq i32 %t676, %t677
  br i1 %t680, label %bb111, label %bb112
bb111:
  store %olang.scope zeroinitializer, ptr %s30
  %t682 = load ptr, ptr %l0, !tbaa !29
  store ptr %t682, ptr %l257, !tbaa !29
  %t683 = load i32, ptr %l30, !tbaa !23
  %t685 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s30, i32 %t683)
  store { i64, ptr } %t685, ptr %l259
  br label %bb113
bb112:
  store %olang.scope zeroinitializer, ptr %s32
  %t686 = load ptr, ptr %l0, !tbaa !29
  %t687 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t688 = extractvalue { i64, ptr } { i64 10, ptr @.d342 }, 1
  %t689 = extractvalue { i64, ptr } { i64 10, ptr @.d342 }, 0
  %t691 = extractvalue { i64, ptr } %t687, 1
  %t692 = extractvalue { i64, ptr } %t687, 0
  %t693 = add i64 %t689, %t692
  %t694 = extractvalue { i64, ptr } { i64 7, ptr @.d343 }, 1
  %t695 = extractvalue { i64, ptr } { i64 7, ptr @.d343 }, 0
  %t696 = add i64 %t693, %t695
  %t697 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t696)
  call void @olang_textcopy(ptr %t697, ptr %t688, i64 %t689)
  %t698 = getelementptr i8, ptr %t697, i64 %t689
  call void @olang_textcopy(ptr %t698, ptr %t691, i64 %t692)
  %t699 = getelementptr i8, ptr %t698, i64 %t692
  call void @olang_textcopy(ptr %t699, ptr %t694, i64 %t695)
  %t700 = insertvalue { i64, ptr } undef, i64 %t696, 0
  %t701 = insertvalue { i64, ptr } %t700, ptr %t697, 1
  %t703 = extractvalue { i64, ptr } %t701, 0
  %t704 = extractvalue { i64, ptr } %t701, 1
  %t705 = mul i64 %t703, 1
  %t706 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t705)
  call void @llvm.memcpy.p0.p0.i64(ptr %t706, ptr %t704, i64 %t705, i1 false)
  %t707 = insertvalue { i64, ptr } undef, i64 %t703, 0
  %t708 = insertvalue { i64, ptr } %t707, ptr %t706, 1
  %t711 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s32, ptr %s32, ptr %t686, { i64, ptr } %t708)
  store { i64, ptr } %t711, ptr %l266
  br label %bb115
bb113:
  %t712 = extractvalue { i64, ptr } { i64 10, ptr @.d344 }, 1
  %t713 = extractvalue { i64, ptr } { i64 10, ptr @.d344 }, 0
  %t714 = load { i64, ptr }, ptr %l259, !tbaa !27
  %t715 = extractvalue { i64, ptr } %t714, 1
  %t716 = extractvalue { i64, ptr } %t714, 0
  %t717 = add i64 %t713, %t716
  %t718 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t717)
  call void @olang_textcopy(ptr %t718, ptr %t712, i64 %t713)
  %t719 = getelementptr i8, ptr %t718, i64 %t713
  call void @olang_textcopy(ptr %t719, ptr %t715, i64 %t716)
  %t720 = insertvalue { i64, ptr } undef, i64 %t717, 0
  %t721 = insertvalue { i64, ptr } %t720, ptr %t718, 1
  %t723 = extractvalue { i64, ptr } %t721, 0
  %t724 = extractvalue { i64, ptr } %t721, 1
  %t725 = mul i64 %t723, 1
  %t726 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t725)
  call void @llvm.memcpy.p0.p0.i64(ptr %t726, ptr %t724, i64 %t725, i1 false)
  %t727 = insertvalue { i64, ptr } undef, i64 %t723, 0
  %t728 = insertvalue { i64, ptr } %t727, ptr %t726, 1
  %t729 = load ptr, ptr %l257, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s30, ptr %t729, { i64, ptr } %t728)
  br label %bb114
bb114:
  call void @__olang_scope_close(ptr %s30)
  br label %bb125
bb115:
  %t731 = load { i64, ptr }, ptr %l266, !tbaa !27
  store { i64, ptr } %t731, ptr %l34, !tbaa !27
  %t732 = load i32, ptr %l31, !tbaa !23
  %t733 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t736 = icmp ne i32 %t732, %t733
  br i1 %t736, label %bb116, label %bb117
bb116:
  store %olang.scope zeroinitializer, ptr %s34
  %t738 = load ptr, ptr %l0, !tbaa !29
  store ptr %t738, ptr %l270, !tbaa !29
  %t739 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t739, ptr %l271, !tbaa !27
  %t740 = load ptr, ptr %l0, !tbaa !29
  %t741 = load i32, ptr %l31, !tbaa !23
  %t744 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalAt(ptr %v0, ptr %s34, ptr %t740, i32 %t741)
  store { i64, ptr } %t744, ptr %l274
  br label %bb118
bb117:
  br label %bb120
bb118:
  %t745 = load { i64, ptr }, ptr %l274, !tbaa !27
  %t746 = extractvalue { i64, ptr } %t745, 0
  %t747 = extractvalue { i64, ptr } %t745, 1
  %t748 = mul i64 %t746, 1
  %t749 = call ptr @__olang_scope_alloc(ptr %s34, i64 %t748)
  call void @llvm.memcpy.p0.p0.i64(ptr %t749, ptr %t747, i64 %t748, i1 false)
  %t750 = insertvalue { i64, ptr } undef, i64 %t746, 0
  %t751 = insertvalue { i64, ptr } %t750, ptr %t749, 1
  %t752 = load ptr, ptr %l270, !tbaa !29
  %t753 = load { i64, ptr }, ptr %l271, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s34, ptr %s32, ptr %s34, ptr %s34, ptr %t752, { i64, ptr } { i64 3, ptr @.d345 }, { i64, ptr } %t753, { i64, ptr } %t751, { i64, ptr } { i64 0, ptr @.d346 })
  br label %bb119
bb119:
  call void @__olang_scope_close(ptr %s34)
  br label %bb120
bb120:
  %t755 = load ptr, ptr %l0, !tbaa !29
  %t756 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t757 = extractvalue { i64, ptr } { i64 12, ptr @.d347 }, 1
  %t758 = extractvalue { i64, ptr } { i64 12, ptr @.d347 }, 0
  %t760 = extractvalue { i64, ptr } %t756, 1
  %t761 = extractvalue { i64, ptr } %t756, 0
  %t762 = add i64 %t758, %t761
  %t763 = extractvalue { i64, ptr } { i64 3, ptr @.d348 }, 1
  %t764 = extractvalue { i64, ptr } { i64 3, ptr @.d348 }, 0
  %t765 = add i64 %t762, %t764
  %t766 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t765)
  call void @olang_textcopy(ptr %t766, ptr %t757, i64 %t758)
  %t767 = getelementptr i8, ptr %t766, i64 %t758
  call void @olang_textcopy(ptr %t767, ptr %t760, i64 %t761)
  %t768 = getelementptr i8, ptr %t767, i64 %t761
  call void @olang_textcopy(ptr %t768, ptr %t763, i64 %t764)
  %t769 = insertvalue { i64, ptr } undef, i64 %t765, 0
  %t770 = insertvalue { i64, ptr } %t769, ptr %t766, 1
  %t772 = extractvalue { i64, ptr } %t770, 0
  %t773 = extractvalue { i64, ptr } %t770, 1
  %t774 = mul i64 %t772, 1
  %t775 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t774)
  call void @llvm.memcpy.p0.p0.i64(ptr %t775, ptr %t773, i64 %t774, i1 false)
  %t776 = insertvalue { i64, ptr } undef, i64 %t772, 0
  %t777 = insertvalue { i64, ptr } %t776, ptr %t775, 1
  %t780 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s32, ptr %s32, ptr %t755, { i64, ptr } %t777)
  store { i64, ptr } %t780, ptr %l280
  br label %bb121
bb121:
  %t781 = load { i64, ptr }, ptr %l280, !tbaa !27
  %t782 = load ptr, ptr %l0, !tbaa !29
  store ptr %t782, ptr %l281, !tbaa !29
  store { i64, ptr } %t781, ptr %l282, !tbaa !27
  %t784 = load i32, ptr %l32, !tbaa !23
  %t786 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s32, i32 %t784)
  store { i64, ptr } %t786, ptr %l284
  br label %bb122
bb122:
  %t787 = load i32, ptr %l30, !tbaa !23
  %t789 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s32, i32 %t787)
  store { i64, ptr } %t789, ptr %l286
  br label %bb123
bb123:
  %t790 = extractvalue { i64, ptr } { i64 6, ptr @.d349 }, 1
  %t791 = extractvalue { i64, ptr } { i64 6, ptr @.d349 }, 0
  %t792 = load { i64, ptr }, ptr %l282, !tbaa !27
  %t793 = extractvalue { i64, ptr } %t792, 1
  %t794 = extractvalue { i64, ptr } %t792, 0
  %t795 = add i64 %t791, %t794
  %t796 = extractvalue { i64, ptr } { i64 9, ptr @.d350 }, 1
  %t797 = extractvalue { i64, ptr } { i64 9, ptr @.d350 }, 0
  %t798 = add i64 %t795, %t797
  %t799 = load { i64, ptr }, ptr %l284, !tbaa !27
  %t800 = extractvalue { i64, ptr } %t799, 1
  %t801 = extractvalue { i64, ptr } %t799, 0
  %t802 = add i64 %t798, %t801
  %t803 = extractvalue { i64, ptr } { i64 9, ptr @.d351 }, 1
  %t804 = extractvalue { i64, ptr } { i64 9, ptr @.d351 }, 0
  %t805 = add i64 %t802, %t804
  %t806 = load { i64, ptr }, ptr %l286, !tbaa !27
  %t807 = extractvalue { i64, ptr } %t806, 1
  %t808 = extractvalue { i64, ptr } %t806, 0
  %t809 = add i64 %t805, %t808
  %t810 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t809)
  call void @olang_textcopy(ptr %t810, ptr %t790, i64 %t791)
  %t811 = getelementptr i8, ptr %t810, i64 %t791
  call void @olang_textcopy(ptr %t811, ptr %t793, i64 %t794)
  %t812 = getelementptr i8, ptr %t811, i64 %t794
  call void @olang_textcopy(ptr %t812, ptr %t796, i64 %t797)
  %t813 = getelementptr i8, ptr %t812, i64 %t797
  call void @olang_textcopy(ptr %t813, ptr %t800, i64 %t801)
  %t814 = getelementptr i8, ptr %t813, i64 %t801
  call void @olang_textcopy(ptr %t814, ptr %t803, i64 %t804)
  %t815 = getelementptr i8, ptr %t814, i64 %t804
  call void @olang_textcopy(ptr %t815, ptr %t807, i64 %t808)
  %t816 = insertvalue { i64, ptr } undef, i64 %t809, 0
  %t817 = insertvalue { i64, ptr } %t816, ptr %t810, 1
  %t819 = extractvalue { i64, ptr } %t817, 0
  %t820 = extractvalue { i64, ptr } %t817, 1
  %t821 = mul i64 %t819, 1
  %t822 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t821)
  call void @llvm.memcpy.p0.p0.i64(ptr %t822, ptr %t820, i64 %t821, i1 false)
  %t823 = insertvalue { i64, ptr } undef, i64 %t819, 0
  %t824 = insertvalue { i64, ptr } %t823, ptr %t822, 1
  %t825 = load ptr, ptr %l281, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s32, ptr %t825, { i64, ptr } %t824)
  br label %bb124
bb124:
  call void @__olang_scope_close(ptr %s32)
  br label %bb125
bb125:
  call void @__olang_scope_close(ptr %s28)
  br label %bb137
bb126:
  %t827 = load { i64, [7 x i64] }, ptr %l1
  %t829 = extractvalue { i64, [7 x i64] } %t827, 0
  %t830 = icmp eq i64 %t829, 8
  br i1 %t830, label %bb127, label %bb128
bb127:
  %t832 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t833 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t832, i32 0, i32 0
  %t834 = load %"compiler/source:Span", ptr %t833
  store %"compiler/source:Span" %t834, ptr %l36
  %t836 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t837 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t836, i32 0, i32 1
  %t838 = load i32, ptr %t837
  store i32 %t838, ptr %l37
  %t840 = getelementptr { i64, [7 x i64] }, ptr %l1, i32 0, i32 1
  %t841 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t840, i32 0, i32 2
  %t842 = load { i64, [4 x i64] }, ptr %t841
  store { i64, [4 x i64] } %t842, ptr %l38
  br label %bb129
bb128:
  br label %bb131
bb129:
  %t844 = load ptr, ptr %l0, !tbaa !29
  %t845 = load %"compiler/source:Span", ptr %l36
  %t846 = load i32, ptr %l37
  %t847 = load { i64, [4 x i64] }, ptr %l38
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eexit(ptr %v0, ptr %t844, %"compiler/source:Span" %t845, i32 %t846, { i64, [4 x i64] } %t847)
  br label %bb130
bb130:
  br label %bb137
bb131:
  %t852 = load { i64, [7 x i64] }, ptr %l1
  %t854 = extractvalue { i64, [7 x i64] } %t852, 0
  %t855 = icmp eq i64 %t854, 9
  br i1 %t855, label %bb132, label %bb133
bb132:
  br label %bb134
bb133:
  br label %bb136
bb134:
  store %olang.scope zeroinitializer, ptr %s38
  %t857 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s38, ptr %t857, { i64, ptr } { i64 23, ptr @.d352 })
  br label %bb135
bb135:
  call void @__olang_scope_close(ptr %s38)
  br label %bb137
bb136:
  call void @__olang_check_failed(ptr @olang_loc_7633dd9d24c54174_280dfd74a77e9550)
  unreachable
bb137:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2ewritesInto(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/mir:BasicBlock"
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, [21 x i64] }
  %l15 = alloca %"compiler/mir:Place"
  %l16 = alloca { i64, [15 x i64] }
  %l17 = alloca %"compiler/mir:Place"
  %l18 = alloca i32
  %l19 = alloca %"compiler/mir:Place"
  %l20 = alloca i32
  %l21 = alloca %"compiler/mir:Place"
  %l26 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i32
  %l39 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca i32
  %l56 = alloca { i64, ptr }
  %l58 = alloca { i64, [21 x i64] }
  %l59 = alloca { i64, [21 x i64] }
  %l65 = alloca i1
  %l69 = alloca i1
  %l78 = alloca i1
  %l79 = alloca i1
  %l82 = alloca ptr
  %l87 = alloca i32
  %l88 = alloca i64
  %l100 = alloca i1
  %l101 = alloca i1
  %l104 = alloca ptr
  %l109 = alloca i32
  %l110 = alloca i64
  %l115 = alloca { i64, [21 x i64] }
  %l121 = alloca i1
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = getelementptr %"compiler/mir:Fn", ptr %t4, i32 0, i32 9
  store ptr %t8, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eRu_H05f2a0ad75f6ffeece9ab76b4dcd7cb0(ptr %v0, ptr %t10, i64 %t11)
  %t15 = extractvalue { i32, { i64, ptr } } %t14, 1
  %t16 = extractvalue { i32, { i64, ptr } } %t14, 0
  store i32 %t16, ptr %l30
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb3, label %ok.18
ok.18:
  store { i64, ptr } %t15, ptr %l29
  br label %bb2
bb2:
  %t19 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t19, ptr %l26, !tbaa !27
  br label %bb7
bb3:
  %t20 = load i32, ptr %l30, !tbaa !23
  %t21 = ashr i32 %t20, 16
  %t23 = icmp eq i32 %t21, 1
  br i1 %t23, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_5dfa9b7395be5458_e24cfc313725a25c)
  unreachable
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb85
bb7:
  %t25 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t25, ptr %l5, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t30 = load i64, ptr %l7, !tbaa !24
  %t31 = load i64, ptr %l6, !tbaa !24
  %t34 = icmp slt i64 %t30, %t31
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb83
bb10:
  br label %bb11
bb11:
  %t38 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t38, ptr %l39, !tbaa !27
  %t39 = load i64, ptr %l7, !tbaa !24
  %t41 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr %"compiler/mir:BasicBlock", ptr %t42, i64 %t39
  %t44 = load %"compiler/mir:BasicBlock", ptr %t43
  store %"compiler/mir:BasicBlock" %t44, ptr %l8
  %t46 = getelementptr %"compiler/mir:BasicBlock", ptr %l8, i32 0, i32 0
  store ptr %t46, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s5
  %t48 = load ptr, ptr %l9, !tbaa !29
  %t49 = load i64, ptr %l10, !tbaa !24
  %t52 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2eRunFrom_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %t48, i64 %t49)
  %t53 = extractvalue { i32, { i64, ptr } } %t52, 1
  %t54 = extractvalue { i32, { i64, ptr } } %t52, 0
  store i32 %t54, ptr %l47
  %t55 = icmp ne i32 %t54, 0
  br i1 %t55, label %bb14, label %ok.56
ok.56:
  store { i64, ptr } %t53, ptr %l46
  br label %bb13
bb13:
  %t57 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t57, ptr %l43, !tbaa !27
  br label %bb18
bb14:
  %t58 = load i32, ptr %l47, !tbaa !23
  %t59 = ashr i32 %t58, 16
  %t61 = icmp eq i32 %t59, 1
  br i1 %t61, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_cd3d2f4cb5172729_796de8126c3e3b8d)
  unreachable
bb17:
  call void @__olang_scope_close(ptr %s5)
  br label %bb81
bb18:
  %t63 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t63, ptr %l11, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t64, 0
  store i64 %t66, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s6
  %t68 = load i64, ptr %l13, !tbaa !24
  %t69 = load i64, ptr %l12, !tbaa !24
  %t72 = icmp slt i64 %t68, %t69
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s6)
  br label %bb79
bb21:
  br label %bb22
bb22:
  %t76 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t76, ptr %l56, !tbaa !27
  %t77 = load i64, ptr %l13, !tbaa !24
  %t79 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr { i64, [21 x i64] }, ptr %t80, i64 %t77
  call void @llvm.memmove.p0.p0.i64(ptr %l58, ptr %t81, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l14, ptr %l58, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l59, ptr %l14, i64 176, i1 false)
  %t82 = load { i64, [21 x i64] }, ptr %l59
  %t83 = extractvalue { i64, [21 x i64] } %t82, 0
  %t84 = icmp eq i64 %t83, 0
  br i1 %t84, label %bb23, label %bb24
bb23:
  %t86 = getelementptr { i64, [21 x i64] }, ptr %l14, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } }, ptr %t86, i32 0, i32 1
  %t88 = load %"compiler/mir:Place", ptr %t87
  store %"compiler/mir:Place" %t88, ptr %l15
  %t90 = getelementptr { i64, [21 x i64] }, ptr %l14, i32 0, i32 1
  %t91 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } }, ptr %t90, i32 0, i32 2
  %t92 = load { i64, [15 x i64] }, ptr %t91
  store { i64, [15 x i64] } %t92, ptr %l16
  br label %bb25
bb24:
  br label %bb64
bb25:
  %t94 = getelementptr %"compiler/mir:Place", ptr %l15, i32 0, i32 1
  %t95 = getelementptr %"compiler/mir:Range", ptr %t94, i32 0, i32 1
  %t96 = load i32, ptr %t95, !tbaa !23
  %t98 = icmp sgt i32 %t96, 0
  br i1 %t98, label %bb26, label %bb27
bb26:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load %"compiler/mir:Place", ptr %l15
  %t102 = load i32, ptr %l1, !tbaa !23
  %t106 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2ebaseIs(ptr %v0, ptr %t100, %"compiler/mir:Place" %t101, i32 %t102)
  store i1 %t106, ptr %l69
  br label %bb28
bb27:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb29
bb28:
  %t107 = load i1, ptr %l69, !tbaa !21
  store i1 %t107, ptr %l65, !tbaa !21
  br label %bb29
bb29:
  %t108 = load i1, ptr %l65, !tbaa !21
  br i1 %t108, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t110 = load { i64, [15 x i64] }, ptr %l16
  %t112 = extractvalue { i64, [15 x i64] } %t110, 0
  %t113 = icmp eq i64 %t112, 1
  br i1 %t113, label %bb33, label %bb34
bb33:
  %t115 = getelementptr { i64, [15 x i64] }, ptr %l16, i32 0, i32 1
  %t116 = getelementptr { %"compiler/mir:Place", i32 }, ptr %t115, i32 0, i32 0
  %t117 = load %"compiler/mir:Place", ptr %t116
  store %"compiler/mir:Place" %t117, ptr %l17
  %t119 = getelementptr { i64, [15 x i64] }, ptr %l16, i32 0, i32 1
  %t120 = getelementptr { %"compiler/mir:Place", i32 }, ptr %t119, i32 0, i32 1
  %t121 = load i32, ptr %t120
  store i32 %t121, ptr %l18, !tbaa !23
  br label %bb35
bb34:
  br label %bb45
bb35:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load %"compiler/mir:Place", ptr %l17
  %t125 = load i32, ptr %l1, !tbaa !23
  %t129 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2ebaseIs(ptr %v0, ptr %t123, %"compiler/mir:Place" %t124, i32 %t125)
  store i1 %t129, ptr %l78
  br label %bb36
bb36:
  %t130 = load i1, ptr %l78, !tbaa !21
  br i1 %t130, label %bb37, label %bb38
bb37:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/emit:fnEm", ptr %t131, i32 0, i32 0
  %t134 = load ptr, ptr %t133, !tbaa !29
  %t136 = getelementptr %"compiler/emit:Emitter", ptr %t134, i32 0, i32 3
  %t137 = load ptr, ptr %t136, !tbaa !29
  store ptr %t137, ptr %l82, !tbaa !29
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/emit:fnEm", ptr %t138, i32 0, i32 0
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t143 = getelementptr %"compiler/emit:Emitter", ptr %t141, i32 0, i32 3
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t145 = load i32, ptr %l18, !tbaa !23
  %t148 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t144, i32 %t145)
  store i32 %t148, ptr %l87
  br label %bb39
bb38:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb41
bb39:
  %t149 = load ptr, ptr %l82, !tbaa !29
  %t150 = load i32, ptr %l87, !tbaa !23
  %t151 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t149, i32 %t150)
  store i64 %t151, ptr %l88
  br label %bb40
bb40:
  %t152 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t153 = load i64, ptr %l88, !tbaa !24
  %t155 = and i64 %t153, %t152
  %t157 = icmp ne i64 %t155, 0
  store i1 %t157, ptr %l79, !tbaa !21
  br label %bb41
bb41:
  %t159 = load i1, ptr %l79, !tbaa !21
  br i1 %t159, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  br label %bb63
bb45:
  %t161 = load { i64, [15 x i64] }, ptr %l16
  %t163 = extractvalue { i64, [15 x i64] } %t161, 0
  %t164 = icmp eq i64 %t163, 9
  br i1 %t164, label %bb46, label %bb47
bb46:
  %t166 = getelementptr { i64, [15 x i64] }, ptr %l16, i32 0, i32 1
  %t167 = getelementptr { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t166, i32 0, i32 0
  %t168 = load %"compiler/mir:Place", ptr %t167
  store %"compiler/mir:Place" %t168, ptr %l19
  %t170 = getelementptr { i64, [15 x i64] }, ptr %l16, i32 0, i32 1
  %t171 = getelementptr { %"compiler/mir:Place", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t170, i32 0, i32 3
  %t172 = load i32, ptr %t171
  store i32 %t172, ptr %l20, !tbaa !23
  br label %bb48
bb47:
  br label %bb58
bb48:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load %"compiler/mir:Place", ptr %l19
  %t176 = load i32, ptr %l1, !tbaa !23
  %t180 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2ebaseIs(ptr %v0, ptr %t174, %"compiler/mir:Place" %t175, i32 %t176)
  store i1 %t180, ptr %l100
  br label %bb49
bb49:
  %t181 = load i1, ptr %l100, !tbaa !21
  br i1 %t181, label %bb50, label %bb51
bb50:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/emit:fnEm", ptr %t182, i32 0, i32 0
  %t185 = load ptr, ptr %t184, !tbaa !29
  %t187 = getelementptr %"compiler/emit:Emitter", ptr %t185, i32 0, i32 3
  %t188 = load ptr, ptr %t187, !tbaa !29
  store ptr %t188, ptr %l104, !tbaa !29
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/emit:fnEm", ptr %t189, i32 0, i32 0
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t194 = getelementptr %"compiler/emit:Emitter", ptr %t192, i32 0, i32 3
  %t195 = load ptr, ptr %t194, !tbaa !29
  %t196 = load i32, ptr %l20, !tbaa !23
  %t199 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t195, i32 %t196)
  store i32 %t199, ptr %l109
  br label %bb52
bb51:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb54
bb52:
  %t200 = load ptr, ptr %l104, !tbaa !29
  %t201 = load i32, ptr %l109, !tbaa !23
  %t202 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t200, i32 %t201)
  store i64 %t202, ptr %l110
  br label %bb53
bb53:
  %t203 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t204 = load i64, ptr %l110, !tbaa !24
  %t206 = and i64 %t204, %t203
  %t208 = icmp ne i64 %t206, 0
  store i1 %t208, ptr %l101, !tbaa !21
  br label %bb54
bb54:
  %t210 = load i1, ptr %l101, !tbaa !21
  br i1 %t210, label %bb55, label %bb56
bb55:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb56:
  br label %bb57
bb57:
  br label %bb63
bb58:
  br i1 true, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb63
bb62:
  call void @__olang_check_failed(ptr @olang_loc_aa77627ec6eb5ef2_35c32f6dd172e1f6)
  unreachable
bb63:
  br label %bb77
bb64:
  call void @llvm.memmove.p0.p0.i64(ptr %l115, ptr %l14, i64 176, i1 false)
  %t212 = load { i64, [21 x i64] }, ptr %l115
  %t213 = extractvalue { i64, [21 x i64] } %t212, 0
  %t214 = icmp eq i64 %t213, 10
  br i1 %t214, label %bb65, label %bb66
bb65:
  %t216 = getelementptr { i64, [21 x i64] }, ptr %l14, i32 0, i32 1
  %t217 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } }, ptr %t216, i32 0, i32 1
  %t218 = load %"compiler/mir:Place", ptr %t217
  store %"compiler/mir:Place" %t218, ptr %l21
  br label %bb67
bb66:
  br label %bb72
bb67:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load %"compiler/mir:Place", ptr %l21
  %t222 = load i32, ptr %l1, !tbaa !23
  %t226 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2ebaseIs(ptr %v0, ptr %t220, %"compiler/mir:Place" %t221, i32 %t222)
  store i1 %t226, ptr %l121
  br label %bb68
bb68:
  %t227 = load i1, ptr %l121, !tbaa !21
  br i1 %t227, label %bb69, label %bb70
bb69:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb70:
  br label %bb71
bb71:
  br label %bb77
bb72:
  br i1 true, label %bb73, label %bb74
bb73:
  br label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb77
bb76:
  call void @__olang_check_failed(ptr @olang_loc_adfc2b4e0bd5373_1e3a8de6ffd7da97)
  unreachable
bb77:
  call void @__olang_scope_close(ptr %s6)
  br label %bb78
bb78:
  %t229 = load i64, ptr %l13, !tbaa !24
  %t231 = add i64 %t229, 1
  store i64 %t231, ptr %l13, !tbaa !24
  br label %bb19
bb79:
  %t233 = load i64, ptr %l10, !tbaa !24
  %t234 = load i64, ptr %l12, !tbaa !24
  %t237 = add i64 %t233, %t234
  store i64 %t237, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb80
bb80:
  br label %bb12
bb81:
  call void @__olang_scope_close(ptr %s3)
  br label %bb82
bb82:
  %t239 = load i64, ptr %l7, !tbaa !24
  %t241 = add i64 %t239, 1
  store i64 %t241, ptr %l7, !tbaa !24
  br label %bb8
bb83:
  %t243 = load i64, ptr %l4, !tbaa !24
  %t244 = load i64, ptr %l6, !tbaa !24
  %t247 = add i64 %t243, %t244
  store i64 %t247, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb84
bb84:
  br label %bb1
bb85:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2edeclaredSymbol(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l21 = alloca i1
  %l25 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 1, ptr @.d353 })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l6
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store i64 %t4, ptr %l5
  br label %bb1
bb1:
  %t8 = load i64, ptr %l5, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store { i64, ptr } { i64 0, ptr @.d354 }, ptr %l7, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t9, ptr %l8, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l9, !tbaa !24
  %t12 = load i64, ptr %l9, !tbaa !24
  %t13 = mul i64 %t12, 1
  %t14 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l10, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = load i64, ptr %l9, !tbaa !24
  %t22 = mul i64 %t21, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t18, ptr %t20, i64 %t22, i1 false)
  %t23 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t23, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t24 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t24, ptr %rv
  br label %ret
bb4:
  %t25 = load i64, ptr %l3, !tbaa !24
  store i64 %t25, ptr %l1, !tbaa !24
  %t26 = load i64, ptr %l1, !tbaa !24
  %t28 = add i64 %t26, 1
  store i64 %t28, ptr %l2, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t30 = load i64, ptr %l2, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t36 = icmp slt i64 %t30, %t33
  br i1 %t36, label %bb6, label %bb7
bb6:
  %t38 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t38, ptr %l18, !tbaa !27
  %t39 = load i64, ptr %l2, !tbaa !24
  %t41 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr i8, ptr %t42, i64 %t39
  %t44 = load i8, ptr %t43, !tbaa !32
  %t46 = call i1 @compiler_2femit_2esymbolChar(i8 %t44)
  store i1 %t46, ptr %l21
  br label %bb8
bb7:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb9
bb8:
  %t47 = load i1, ptr %l21, !tbaa !21
  store i1 %t47, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t48 = load i1, ptr %l17, !tbaa !21
  %t49 = xor i1 %t48, true
  br i1 %t49, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb11:
  br label %bb12
bb12:
  %t51 = load i64, ptr %l2, !tbaa !24
  %t53 = add i64 %t51, 1
  store i64 %t53, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  br label %bb5
bb14:
  %t55 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t55, ptr %l25, !tbaa !27
  %t56 = load i64, ptr %l1, !tbaa !24
  %t58 = add i64 %t56, 1
  store i64 %t58, ptr %l27, !tbaa !24
  %t59 = load i64, ptr %l2, !tbaa !24
  store i64 %t59, ptr %l28, !tbaa !24
  %t60 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t60, 0
  store i64 %t61, ptr %l29, !tbaa !24
  %t62 = load i64, ptr %l27, !tbaa !24
  %t63 = icmp sge i64 %t62, 0
  br i1 %t63, label %bb15, label %bb16
bb15:
  %t65 = load i64, ptr %l27, !tbaa !24
  %t66 = load i64, ptr %l28, !tbaa !24
  %t67 = icmp sle i64 %t65, %t66
  br i1 %t67, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_f695fddd526749db_a8fb91cf3e060dd7)
  unreachable
bb17:
  %t69 = load i64, ptr %l28, !tbaa !24
  %t70 = load i64, ptr %l29, !tbaa !24
  %t71 = icmp sle i64 %t69, %t70
  br i1 %t71, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_f695fddd526749db_a8fb91cf3e060dd7)
  unreachable
bb19:
  %t73 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = load i64, ptr %l27, !tbaa !24
  %t76 = load i64, ptr %l28, !tbaa !24
  %t77 = getelementptr i8, ptr %t74, i64 %t75
  %t78 = sub i64 %t76, %t75
  %t79 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t77, 1
  %t82 = extractvalue { i64, ptr } %t80, 1
  %t83 = extractvalue { i64, ptr } %t80, 0
  %t84 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t83)
  call void @olang_textcopy(ptr %t84, ptr %t82, i64 %t83)
  %t85 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t86, ptr %rv
  br label %ret
bb20:
  call void @__olang_check_failed(ptr @olang_loc_f695fddd526749db_a8fb91cf3e060dd7)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2emathInexact_2einit() #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2emathInexactTable(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr @G_2ecompiler_2femit_2emathInexact
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2femit_2estmtSpan(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i1
  %l89 = alloca ptr
  %l90 = alloca i1
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [21 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", { i64, [15 x i64] } }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l1
  br label %bb17
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 1
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [21 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32 }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l1
  br label %bb17
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l19, !tbaa !29
  %t36 = load i64, ptr %t35
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l20, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr { i64, [21 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32 }, ptr %t42, i32 0, i32 0
  %t44 = load %"compiler/source:Span", ptr %t43
  store %"compiler/source:Span" %t44, ptr %l1
  br label %bb17
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t47 = load ptr, ptr %l25, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l25, !tbaa !29
  %t51 = load i64, ptr %t50
  %t53 = icmp eq i64 %t51, 3
  store i1 %t53, ptr %l26, !tbaa !21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l26, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr { i64, [21 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32 }, ptr %t57, i32 0, i32 0
  %t59 = load %"compiler/source:Span", ptr %t58
  store %"compiler/source:Span" %t59, ptr %l1
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t61 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t61, ptr %l6
  br label %bb67
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t64 = load ptr, ptr %l32, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l32, !tbaa !29
  %t68 = load i64, ptr %t67
  %t70 = icmp eq i64 %t68, 4
  store i1 %t70, ptr %l33, !tbaa !21
  br label %bb20
bb20:
  %t71 = load i1, ptr %l33, !tbaa !21
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr { i64, [21 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32 }, ptr %t74, i32 0, i32 0
  %t76 = load %"compiler/source:Span", ptr %t75
  store %"compiler/source:Span" %t76, ptr %l2
  br label %bb31
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t79 = load ptr, ptr %l38, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = load i64, ptr %t82
  %t85 = icmp eq i64 %t83, 5
  store i1 %t85, ptr %l39, !tbaa !21
  br label %bb24
bb24:
  %t86 = load i1, ptr %l39, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [21 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32 }, ptr %t89, i32 0, i32 0
  %t91 = load %"compiler/source:Span", ptr %t90
  store %"compiler/source:Span" %t91, ptr %l2
  br label %bb31
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t94 = load ptr, ptr %l44, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l44, !tbaa !29
  %t98 = load i64, ptr %t97
  %t100 = icmp eq i64 %t98, 6
  store i1 %t100, ptr %l45, !tbaa !21
  br label %bb28
bb28:
  %t101 = load i1, ptr %l45, !tbaa !21
  br i1 %t101, label %bb29, label %bb30
bb29:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr { i64, [21 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t104, i32 0, i32 0
  %t106 = load %"compiler/source:Span", ptr %t105
  store %"compiler/source:Span" %t106, ptr %l2
  br label %bb31
bb30:
  br label %bb32
bb31:
  %t108 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t108, ptr %l6
  br label %bb67
bb32:
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t111 = load ptr, ptr %l51, !tbaa !29
  %t112 = icmp ne ptr %t111, null
  br i1 %t112, label %bb33, label %bb34
bb33:
  %t114 = load ptr, ptr %l51, !tbaa !29
  %t115 = load i64, ptr %t114
  %t117 = icmp eq i64 %t115, 7
  store i1 %t117, ptr %l52, !tbaa !21
  br label %bb34
bb34:
  %t118 = load i1, ptr %l52, !tbaa !21
  br i1 %t118, label %bb35, label %bb36
bb35:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr { i64, [21 x i64] }, ptr %t119, i32 0, i32 1
  %t122 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, %"compiler/mir:Place" }, ptr %t121, i32 0, i32 0
  %t123 = load %"compiler/source:Span", ptr %t122
  store %"compiler/source:Span" %t123, ptr %l3
  br label %bb45
bb36:
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t126 = load ptr, ptr %l57, !tbaa !29
  %t127 = icmp ne ptr %t126, null
  br i1 %t127, label %bb37, label %bb38
bb37:
  %t129 = load ptr, ptr %l57, !tbaa !29
  %t130 = load i64, ptr %t129
  %t132 = icmp eq i64 %t130, 8
  store i1 %t132, ptr %l58, !tbaa !21
  br label %bb38
bb38:
  %t133 = load i1, ptr %l58, !tbaa !21
  br i1 %t133, label %bb39, label %bb40
bb39:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr { i64, [21 x i64] }, ptr %t134, i32 0, i32 1
  %t137 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place" }, ptr %t136, i32 0, i32 0
  %t138 = load %"compiler/source:Span", ptr %t137
  store %"compiler/source:Span" %t138, ptr %l3
  br label %bb45
bb40:
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t141 = load ptr, ptr %l63, !tbaa !29
  %t142 = icmp ne ptr %t141, null
  br i1 %t142, label %bb41, label %bb42
bb41:
  %t144 = load ptr, ptr %l63, !tbaa !29
  %t145 = load i64, ptr %t144
  %t147 = icmp eq i64 %t145, 9
  store i1 %t147, ptr %l64, !tbaa !21
  br label %bb42
bb42:
  %t148 = load i1, ptr %l64, !tbaa !21
  br i1 %t148, label %bb43, label %bb44
bb43:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr { i64, [21 x i64] }, ptr %t149, i32 0, i32 1
  %t152 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t151, i32 0, i32 0
  %t153 = load %"compiler/source:Span", ptr %t152
  store %"compiler/source:Span" %t153, ptr %l3
  br label %bb45
bb44:
  br label %bb46
bb45:
  %t155 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t155, ptr %l6
  br label %bb67
bb46:
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t158 = load ptr, ptr %l70, !tbaa !29
  %t159 = icmp ne ptr %t158, null
  br i1 %t159, label %bb47, label %bb48
bb47:
  %t161 = load ptr, ptr %l70, !tbaa !29
  %t162 = load i64, ptr %t161
  %t164 = icmp eq i64 %t162, 10
  store i1 %t164, ptr %l71, !tbaa !21
  br label %bb48
bb48:
  %t165 = load i1, ptr %l71, !tbaa !21
  br i1 %t165, label %bb49, label %bb50
bb49:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr { i64, [21 x i64] }, ptr %t166, i32 0, i32 1
  %t169 = getelementptr { %"compiler/source:Span", %"compiler/mir:Place", %"compiler/mir:Place", { i64, [4 x i64] } }, ptr %t168, i32 0, i32 0
  %t170 = load %"compiler/source:Span", ptr %t169
  store %"compiler/source:Span" %t170, ptr %l4
  br label %bb59
bb50:
  %t172 = load ptr, ptr %l0, !tbaa !29
  store ptr %t172, ptr %l76, !tbaa !29
  store i1 false, ptr %l77, !tbaa !21
  %t173 = load ptr, ptr %l76, !tbaa !29
  %t174 = icmp ne ptr %t173, null
  br i1 %t174, label %bb51, label %bb52
bb51:
  %t176 = load ptr, ptr %l76, !tbaa !29
  %t177 = load i64, ptr %t176
  %t179 = icmp eq i64 %t177, 11
  store i1 %t179, ptr %l77, !tbaa !21
  br label %bb52
bb52:
  %t180 = load i1, ptr %l77, !tbaa !21
  br i1 %t180, label %bb53, label %bb54
bb53:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr { i64, [21 x i64] }, ptr %t181, i32 0, i32 1
  %t184 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t183, i32 0, i32 0
  %t185 = load %"compiler/source:Span", ptr %t184
  store %"compiler/source:Span" %t185, ptr %l4
  br label %bb59
bb54:
  %t187 = load ptr, ptr %l0, !tbaa !29
  store ptr %t187, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t188 = load ptr, ptr %l82, !tbaa !29
  %t189 = icmp ne ptr %t188, null
  br i1 %t189, label %bb55, label %bb56
bb55:
  %t191 = load ptr, ptr %l82, !tbaa !29
  %t192 = load i64, ptr %t191
  %t194 = icmp eq i64 %t192, 12
  store i1 %t194, ptr %l83, !tbaa !21
  br label %bb56
bb56:
  %t195 = load i1, ptr %l83, !tbaa !21
  br i1 %t195, label %bb57, label %bb58
bb57:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr { i64, [21 x i64] }, ptr %t196, i32 0, i32 1
  %t199 = getelementptr { %"compiler/source:Span" }, ptr %t198, i32 0, i32 0
  %t200 = load %"compiler/source:Span", ptr %t199
  store %"compiler/source:Span" %t200, ptr %l4
  br label %bb59
bb58:
  br label %bb60
bb59:
  %t202 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t202, ptr %l6
  br label %bb67
bb60:
  %t204 = load ptr, ptr %l0, !tbaa !29
  store ptr %t204, ptr %l89, !tbaa !29
  store i1 false, ptr %l90, !tbaa !21
  %t205 = load ptr, ptr %l89, !tbaa !29
  %t206 = icmp ne ptr %t205, null
  br i1 %t206, label %bb61, label %bb62
bb61:
  %t208 = load ptr, ptr %l89, !tbaa !29
  %t209 = load i64, ptr %t208
  %t211 = icmp eq i64 %t209, 13
  store i1 %t211, ptr %l90, !tbaa !21
  br label %bb62
bb62:
  %t212 = load i1, ptr %l90, !tbaa !21
  br i1 %t212, label %bb63, label %bb64
bb63:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr { i64, [21 x i64] }, ptr %t213, i32 0, i32 1
  %t216 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t215, i32 0, i32 0
  %t217 = load %"compiler/source:Span", ptr %t216
  store %"compiler/source:Span" %t217, ptr %l5
  br label %bb65
bb64:
  br label %bb66
bb65:
  %t219 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t219, ptr %l6
  br label %bb67
bb66:
  call void @__olang_check_failed(ptr @olang_loc_f86c3108d396390c_a897abfaa875b378)
  unreachable
bb67:
  %t221 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t221, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local void @compiler_2femit_2etbaaField_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [15 x i64] undef, i64 0, 0
  %t2 = insertvalue [15 x i64] %t1, i64 0, 1
  %t3 = insertvalue [15 x i64] %t2, i64 21, 2
  %t4 = insertvalue [15 x i64] %t3, i64 61, 3
  %t5 = insertvalue [15 x i64] %t4, i64 62, 4
  %t6 = insertvalue [15 x i64] %t5, i64 23, 5
  %t7 = insertvalue [15 x i64] %t6, i64 24, 6
  %t8 = insertvalue [15 x i64] %t7, i64 22, 7
  %t9 = insertvalue [15 x i64] %t8, i64 63, 8
  %t10 = insertvalue [15 x i64] %t9, i64 64, 9
  %t11 = insertvalue [15 x i64] %t10, i64 65, 10
  %t12 = insertvalue [15 x i64] %t11, i64 66, 11
  %t13 = insertvalue [15 x i64] %t12, i64 67, 12
  %t14 = insertvalue [15 x i64] %t13, i64 25, 13
  %t15 = insertvalue [15 x i64] %t14, i64 26, 14
  store [15 x i64] %t15, ptr @G_2ecompiler_2femit_2etbaaField
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2etbaaTree_2einit() #0 {
entry:
  %l0 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call { i64, ptr } @compiler_2femit_2etbaaLeaves(ptr %t1)
  store { i64, ptr } %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = extractvalue { i64, ptr } { i64 19, ptr @.d355 }, 1
  %t4 = extractvalue { i64, ptr } { i64 19, ptr @.d355 }, 0
  %t5 = extractvalue { i64, ptr } { i64 66, ptr @.d356 }, 1
  %t6 = extractvalue { i64, ptr } { i64 66, ptr @.d356 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = extractvalue { i64, ptr } { i64 50, ptr @.d357 }, 1
  %t9 = extractvalue { i64, ptr } { i64 50, ptr @.d357 }, 0
  %t10 = add i64 %t7, %t9
  %t11 = extractvalue { i64, ptr } { i64 66, ptr @.d358 }, 1
  %t12 = extractvalue { i64, ptr } { i64 66, ptr @.d358 }, 0
  %t13 = add i64 %t10, %t12
  %t14 = extractvalue { i64, ptr } { i64 64, ptr @.d359 }, 1
  %t15 = extractvalue { i64, ptr } { i64 64, ptr @.d359 }, 0
  %t16 = add i64 %t13, %t15
  %t17 = extractvalue { i64, ptr } { i64 80, ptr @.d360 }, 1
  %t18 = extractvalue { i64, ptr } { i64 80, ptr @.d360 }, 0
  %t19 = add i64 %t16, %t18
  %t20 = extractvalue { i64, ptr } { i64 75, ptr @.d361 }, 1
  %t21 = extractvalue { i64, ptr } { i64 75, ptr @.d361 }, 0
  %t22 = add i64 %t19, %t21
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 1
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t26 = add i64 %t22, %t25
  %t27 = extractvalue { i64, ptr } { i64 1, ptr @.d362 }, 1
  %t28 = extractvalue { i64, ptr } { i64 1, ptr @.d362 }, 0
  %t29 = add i64 %t26, %t28
  %t30 = load ptr, ptr @__olang_prog_scope
  %t31 = call ptr @__olang_scope_alloc(ptr %t30, i64 %t29)
  call void @olang_textcopy(ptr %t31, ptr %t3, i64 %t4)
  %t32 = getelementptr i8, ptr %t31, i64 %t4
  call void @olang_textcopy(ptr %t32, ptr %t5, i64 %t6)
  %t33 = getelementptr i8, ptr %t32, i64 %t6
  call void @olang_textcopy(ptr %t33, ptr %t8, i64 %t9)
  %t34 = getelementptr i8, ptr %t33, i64 %t9
  call void @olang_textcopy(ptr %t34, ptr %t11, i64 %t12)
  %t35 = getelementptr i8, ptr %t34, i64 %t12
  call void @olang_textcopy(ptr %t35, ptr %t14, i64 %t15)
  %t36 = getelementptr i8, ptr %t35, i64 %t15
  call void @olang_textcopy(ptr %t36, ptr %t17, i64 %t18)
  %t37 = getelementptr i8, ptr %t36, i64 %t18
  call void @olang_textcopy(ptr %t37, ptr %t20, i64 %t21)
  %t38 = getelementptr i8, ptr %t37, i64 %t21
  call void @olang_textcopy(ptr %t38, ptr %t24, i64 %t25)
  %t39 = getelementptr i8, ptr %t38, i64 %t25
  call void @olang_textcopy(ptr %t39, ptr %t27, i64 %t28)
  %t40 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t31, 1
  %t43 = load ptr, ptr @__olang_prog_scope
  %t44 = extractvalue { i64, ptr } %t41, 0
  %t45 = extractvalue { i64, ptr } %t41, 1
  %t46 = mul i64 %t44, 1
  %t47 = call ptr @__olang_scope_alloc(ptr %t43, i64 %t46)
  call void @llvm.memcpy.p0.p0.i64(ptr %t47, ptr %t45, i64 %t46, i1 false)
  %t48 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  store { i64, ptr } %t49, ptr @G_2ecompiler_2femit_2etbaaTree, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2femit_2etermSpan({ i64, [7 x i64] } %a0) #0 {
entry:
  %l0 = alloca { i64, [7 x i64] }
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l21 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store { i64, [7 x i64] } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, [7 x i64] }, ptr %l0
  %t3 = extractvalue { i64, [7 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 4
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [7 x i64] }, ptr %l0, i32 0, i32 1
  %t7 = getelementptr { %"compiler/source:Span", i32 }, ptr %t6, i32 0, i32 0
  %t8 = load %"compiler/source:Span", ptr %t7
  store %"compiler/source:Span" %t8, ptr %l1
  br label %bb7
bb2:
  %t10 = load { i64, [7 x i64] }, ptr %l0
  %t12 = extractvalue { i64, [7 x i64] } %t10, 0
  %t13 = icmp eq i64 %t12, 5
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = getelementptr { i64, [7 x i64] }, ptr %l0, i32 0, i32 1
  %t16 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t15, i32 0, i32 0
  %t17 = load %"compiler/source:Span", ptr %t16
  store %"compiler/source:Span" %t17, ptr %l1
  br label %bb7
bb4:
  %t19 = load { i64, [7 x i64] }, ptr %l0
  %t21 = extractvalue { i64, [7 x i64] } %t19, 0
  %t22 = icmp eq i64 %t21, 6
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t24 = getelementptr { i64, [7 x i64] }, ptr %l0, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t24, i32 0, i32 0
  %t26 = load %"compiler/source:Span", ptr %t25
  store %"compiler/source:Span" %t26, ptr %l1
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t28 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t28, ptr %l3
  br label %bb20
bb8:
  %t30 = load { i64, [7 x i64] }, ptr %l0
  %t32 = extractvalue { i64, [7 x i64] } %t30, 0
  %t33 = icmp eq i64 %t32, 7
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = getelementptr { i64, [7 x i64] }, ptr %l0, i32 0, i32 1
  %t36 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t35, i32 0, i32 0
  %t37 = load %"compiler/source:Span", ptr %t36
  store %"compiler/source:Span" %t37, ptr %l2
  br label %bb13
bb10:
  %t39 = load { i64, [7 x i64] }, ptr %l0
  %t41 = extractvalue { i64, [7 x i64] } %t39, 0
  %t42 = icmp eq i64 %t41, 8
  br i1 %t42, label %bb11, label %bb12
bb11:
  %t44 = getelementptr { i64, [7 x i64] }, ptr %l0, i32 0, i32 1
  %t45 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t44, i32 0, i32 0
  %t46 = load %"compiler/source:Span", ptr %t45
  store %"compiler/source:Span" %t46, ptr %l2
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t48 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t48, ptr %l3
  br label %bb20
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t50 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t50, ptr %l21
  br label %bb18
bb18:
  %t51 = load %"compiler/source:Span", ptr %l21
  store %"compiler/source:Span" %t51, ptr %l3
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_a69d5bfe0a165b0_62b4fff2e0b246dc)
  unreachable
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t52 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t52, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

@.d0 = private constant [2 x i8] c"bb"
declare i64 @__olang_fmt_i64(ptr, i64)
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d1 = private constant [2 x i8] c"U8"
@.d2 = private constant [1 x i8] c"!"
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d3 = private constant [1 x i8] c"!"
@.d4 = private constant [3 x i8] c" = "
@.d5 = private constant [1 x i8] c"\0A"
@.d6 = private constant [0 x i8] c""
@.d7 = private constant [8 x i8] c"declare "
@.d8 = private constant [0 x i8] c""
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d9 = private constant [4 x i8] c"main"
@.d10 = private constant [8 x i8] c" = type "
@.d11 = private constant [1 x i8] c"\0A"
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.d12 = private constant [0 x i8] c""
@.d13 = private constant [2 x i8] c" @"
@.d14 = private constant [1 x i8] c"("
@.d15 = private constant [1 x i8] c")"
@.d16 = private constant [2 x i8] c" @"
@.d17 = private constant [1 x i8] c"("
@.d18 = private constant [2 x i8] c", "
@.d19 = private constant [8 x i8] c"ptr, ptr"
@.d20 = private constant [3 x i8] c"ptr"
@.d21 = private constant [1 x i8] c")"
@.d22 = private constant [0 x i8] c""
@.d23 = private constant [24 x i8] c" nobuiltin memory(write)"
@.d24 = private constant [2 x i8] c"G."
@.d25 = private constant [1 x i8] c"."
@.d26 = private constant [11 x i8] c"olang_test_"
@.d27 = private constant [4 x i8] c"main"
@.d28 = private constant [85 x i8] c"; olang - emitted by the self-hosted compiler (compiler/emit.olang)\0Atarget triple = \22"
@.d29 = private constant [3 x i8] c"\22\0A\0A"
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d30 = private constant [17 x i8] c"define dso_local "
@.d31 = private constant [20 x i8] c"define linkonce_odr "
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d32 = private constant [3 x i8] c" = "
@.d33 = private constant [1 x i8] c" "
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d34 = private constant [2 x i8] c"-t"
@.d35 = private constant [1 x i8] c"-"
@.d36 = private constant [2 x i8] c"-i"
@.d37 = private constant [0 x i8] c""
@.d38 = private constant [14 x i8] c"olang_textcopy"
@.d39 = private constant [21 x i8] c"llvm.memcpy.p0.p0.i64"
@.d40 = private constant [46 x i8] c"void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)"
@.d41 = private constant [94 x i8] c"define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {\0Aentry:\0A"
@.d42 = private constant [66 x i8] c"  %big = icmp ugt i64 %n, 16\0A  br i1 %big, label %call, label %s8\0A"
@.d43 = private constant [86 x i8] c"call:\0A  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)\0A  ret void\0A"
@.d44 = private constant [67 x i8] c"s8:\0A  %ge8 = icmp uge i64 %n, 8\0A  br i1 %ge8, label %w8, label %s4\0A"
@.d45 = private constant [103 x i8] c"w8:\0A  %e8 = sub i64 %n, 8\0A  %a8 = load i64, ptr %s, align 1\0A  %sb8 = getelementptr i8, ptr %s, i64 %e8\0A"
@.d46 = private constant [112 x i8] c"  %b8 = load i64, ptr %sb8, align 1\0A  store i64 %a8, ptr %d, align 1\0A  %db8 = getelementptr i8, ptr %d, i64 %e8\0A"
@.d47 = private constant [46 x i8] c"  store i64 %b8, ptr %db8, align 1\0A  ret void\0A"
@.d48 = private constant [67 x i8] c"s4:\0A  %ge4 = icmp uge i64 %n, 4\0A  br i1 %ge4, label %w4, label %s1\0A"
@.d49 = private constant [103 x i8] c"w4:\0A  %e4 = sub i64 %n, 4\0A  %a4 = load i32, ptr %s, align 1\0A  %sb4 = getelementptr i8, ptr %s, i64 %e4\0A"
@.d50 = private constant [112 x i8] c"  %b4 = load i32, ptr %sb4, align 1\0A  store i32 %a4, ptr %d, align 1\0A  %db4 = getelementptr i8, ptr %d, i64 %e4\0A"
@.d51 = private constant [46 x i8] c"  store i32 %b4, ptr %db4, align 1\0A  ret void\0A"
@.d52 = private constant [70 x i8] c"s1:\0A  %none = icmp eq i64 %n, 0\0A  br i1 %none, label %done, label %w1\0A"
@.d53 = private constant [113 x i8] c"w1:\0A  %h = lshr i64 %n, 1\0A  %e1 = sub i64 %n, 1\0A  %a1 = load i8, ptr %s\0A  %sh = getelementptr i8, ptr %s, i64 %h\0A"
@.d54 = private constant [115 x i8] c"  %m1 = load i8, ptr %sh\0A  %se = getelementptr i8, ptr %s, i64 %e1\0A  %z1 = load i8, ptr %se\0A  store i8 %a1, ptr %d\0A"
@.d55 = private constant [107 x i8] c"  %dh = getelementptr i8, ptr %d, i64 %h\0A  store i8 %m1, ptr %dh\0A  %de = getelementptr i8, ptr %d, i64 %e1\0A"
@.d56 = private constant [60 x i8] c"  store i8 %z1, ptr %de\0A  br label %done\0Adone:\0A  ret void\0A}\0A"
@.d57 = private constant [14 x i8] c"olang_textcopy"
@.d58 = private constant [0 x i8] c""
@.d59 = private constant [14 x i8] c"getelementptr "
@.d60 = private constant [6 x i8] c", ptr "
@.d61 = private constant [13 x i8] c", i64 0, i64 "
@.d62 = private constant [14 x i8] c"getelementptr "
@.d63 = private constant [6 x i8] c", ptr "
@.d64 = private constant [13 x i8] c", i32 0, i32 "
@.d65 = private constant [4 x i8] c"true"
@.d66 = private constant [5 x i8] c"false"
@.d67 = private constant [2 x i8] c"%k"
@.d68 = private constant [1 x i8] c"_"
@.d69 = private constant [2 x i8] c"  "
@.d70 = private constant [13 x i8] c"h = lshr i32 "
@.d71 = private constant [7 x i8] c", 16\0A  "
@.d72 = private constant [15 x i8] c" = icmp eq i32 "
@.d73 = private constant [3 x i8] c"h, "
@.d74 = private constant [1 x i8] c"\0A"
@.d75 = private constant [2 x i8] c"  "
@.d76 = private constant [15 x i8] c" = icmp eq i32 "
@.d77 = private constant [2 x i8] c", "
@.d78 = private constant [1 x i8] c"\0A"
@.d79 = private constant [2 x i8] c"  "
@.d80 = private constant [10 x i8] c"o = or i1 "
@.d81 = private constant [2 x i8] c", "
@.d82 = private constant [1 x i8] c"\0A"
@.d83 = private constant [1 x i8] c"o"
@.d84 = private constant [8 x i8] c"  br i1 "
@.d85 = private constant [13 x i8] c", label %take"
@.d86 = private constant [13 x i8] c", label %pass"
@.d87 = private constant [5 x i8] c"\0Atake"
@.d88 = private constant [2 x i8] c":\0A"
@.d89 = private constant [5 x i8] c"  %hv"
@.d90 = private constant [28 x i8] c" = load { ptr, ptr }, ptr %f"
@.d91 = private constant [1 x i8] c"\0A"
@.d92 = private constant [5 x i8] c"  %hc"
@.d93 = private constant [32 x i8] c" = extractvalue { ptr, ptr } %hv"
@.d94 = private constant [9 x i8] c", 0\0A  %he"
@.d95 = private constant [32 x i8] c" = extractvalue { ptr, ptr } %hv"
@.d96 = private constant [4 x i8] c", 1\0A"
@.d97 = private constant [7 x i8] c"ptr %he"
@.d98 = private constant [5 x i8] c"  %ho"
@.d99 = private constant [10 x i8] c" = alloca "
@.d100 = private constant [1 x i8] c"\0A"
@.d101 = private constant [9 x i8] c", ptr %ho"
@.d102 = private constant [18 x i8] c"__olang_prog_scope"
@.d103 = private constant [67 x i8] c"@__olang_prog_scope = external thread_local(initialexec) global ptr"
@.d104 = private constant [5 x i8] c"  %hs"
@.d105 = private constant [1 x i8] c"_"
@.d106 = private constant [37 x i8] c" = load ptr, ptr @__olang_prog_scope\0A"
@.d107 = private constant [9 x i8] c", ptr %hs"
@.d108 = private constant [1 x i8] c"_"
@.d109 = private constant [0 x i8] c""
@.d110 = private constant [4 x i8] c"void"
@.d111 = private constant [15 x i8] c"  call void %hc"
@.d112 = private constant [1 x i8] c"("
@.d113 = private constant [2 x i8] c")\0A"
@.d114 = private constant [5 x i8] c"  %hr"
@.d115 = private constant [8 x i8] c" = call "
@.d116 = private constant [4 x i8] c" %hc"
@.d117 = private constant [1 x i8] c"("
@.d118 = private constant [2 x i8] c")\0A"
@.d119 = private constant [3 x i8] c"%hr"
@.d120 = private constant [5 x i8] c"  %hl"
@.d121 = private constant [8 x i8] c" = load "
@.d122 = private constant [9 x i8] c", ptr %ho"
@.d123 = private constant [1 x i8] c"\0A"
@.d124 = private constant [3 x i8] c"%hl"
@.d125 = private constant [0 x i8] c""
@.d126 = private constant [5 x i8] c"  %hd"
@.d127 = private constant [19 x i8] c" = load ptr, ptr %f"
@.d128 = private constant [9 x i8] c"\0A  store "
@.d129 = private constant [1 x i8] c" "
@.d130 = private constant [9 x i8] c", ptr %hd"
@.d131 = private constant [1 x i8] c"\0A"
@.d132 = private constant [5 x i8] c"  %hd"
@.d133 = private constant [1 x i8] c"_"
@.d134 = private constant [19 x i8] c" = load ptr, ptr %f"
@.d135 = private constant [1 x i8] c"\0A"
@.d136 = private constant [5 x i8] c"  %hx"
@.d137 = private constant [1 x i8] c"_"
@.d138 = private constant [16 x i8] c" = extractvalue "
@.d139 = private constant [1 x i8] c" "
@.d140 = private constant [2 x i8] c", "
@.d141 = private constant [1 x i8] c"\0A"
@.d142 = private constant [8 x i8] c"  store "
@.d143 = private constant [4 x i8] c" %hx"
@.d144 = private constant [1 x i8] c"_"
@.d145 = private constant [9 x i8] c", ptr %hd"
@.d146 = private constant [1 x i8] c"_"
@.d147 = private constant [1 x i8] c"\0A"
@.d148 = private constant [19 x i8] c"  ret ptr null\0Apass"
@.d149 = private constant [2 x i8] c":\0A"
@.d150 = private constant [32 x i8] c"getelementptr { i64, ptr }, ptr "
@.d151 = private constant [14 x i8] c", i32 0, i32 1"
@.d152 = private constant [3 x i8] c"ptr"
@.d153 = private constant [0 x i8] c""
@.d154 = private constant [0 x i8] c""
@.d155 = private constant [1 x i8] c"0"
@.d156 = private constant [1 x i8] c"1"
@.d157 = private constant [4 x i8] c"true"
@.d158 = private constant [5 x i8] c"false"
@.d159 = private constant [10 x i8] c"select i1 "
@.d160 = private constant [6 x i8] c", ptr "
@.d161 = private constant [6 x i8] c", ptr "
@.d162 = private constant [10 x i8] c"select i1 "
@.d163 = private constant [14 x i8] c", i64 4, i64 5"
@.d164 = private constant [15 x i8] c"__olang_fmt_u64"
@.d165 = private constant [40 x i8] c"call i64 @__olang_fmt_u64(ptr null, i64 "
@.d166 = private constant [1 x i8] c")"
@.d167 = private constant [15 x i8] c"__olang_fmt_i64"
@.d168 = private constant [40 x i8] c"call i64 @__olang_fmt_i64(ptr null, i64 "
@.d169 = private constant [1 x i8] c")"
@.d170 = private constant [8 x i8] c"add i64 "
@.d171 = private constant [2 x i8] c", "
@.d172 = private constant [19 x i8] c"__olang_scope_alloc"
@.d173 = private constant [34 x i8] c"call ptr @__olang_scope_alloc(ptr "
@.d174 = private constant [6 x i8] c", i64 "
@.d175 = private constant [1 x i8] c")"
@.d176 = private constant [2 x i8] c"i8"
@.d177 = private constant [0 x i8] c""
@.d178 = private constant [30 x i8] c"call i64 @__olang_fmt_u64(ptr "
@.d179 = private constant [6 x i8] c", i64 "
@.d180 = private constant [1 x i8] c")"
@.d181 = private constant [30 x i8] c"call i64 @__olang_fmt_i64(ptr "
@.d182 = private constant [6 x i8] c", i64 "
@.d183 = private constant [1 x i8] c")"
@.d184 = private constant [30 x i8] c"call void @olang_textcopy(ptr "
@.d185 = private constant [6 x i8] c", ptr "
@.d186 = private constant [6 x i8] c", i64 "
@.d187 = private constant [1 x i8] c")"
@.d188 = private constant [22 x i8] c"getelementptr i8, ptr "
@.d189 = private constant [6 x i8] c", i64 "
@.d190 = private constant [22 x i8] c"an index into no array"
@.d191 = private constant [14 x i8] c"getelementptr "
@.d192 = private constant [6 x i8] c", ptr "
@.d193 = private constant [13 x i8] c", i64 0, i64 "
@.d194 = private constant [32 x i8] c"getelementptr { i64, ptr }, ptr "
@.d195 = private constant [14 x i8] c", i32 0, i32 1"
@.d196 = private constant [3 x i8] c"ptr"
@.d197 = private constant [14 x i8] c"getelementptr "
@.d198 = private constant [6 x i8] c", ptr "
@.d199 = private constant [6 x i8] c", i64 "
@.d200 = private constant [26 x i8] c"extractvalue { ptr, ptr } "
@.d201 = private constant [3 x i8] c", 0"
@.d202 = private constant [26 x i8] c"extractvalue { ptr, ptr } "
@.d203 = private constant [3 x i8] c", 1"
@.d204 = private constant [4 x i8] c"ptr "
@.d205 = private constant [6 x i8] c", ptr "
@.d206 = private constant [4 x i8] c"ptr "
@.d207 = private constant [1 x i8] c" "
@.d208 = private constant [2 x i8] c":\0A"
@.d209 = private constant [2 x i8] c"%l"
@.d210 = private constant [3 x i8] c"%lp"
@.d211 = private constant [3 x i8] c"ptr"
@.d212 = private constant [0 x i8] c""
@.d213 = private constant [0 x i8] c""
@.d214 = private constant [0 x i8] c""
@.d215 = private constant [1 x i8] c"|"
@.d216 = private constant [1 x i8] c"|"
@.d217 = private constant [1 x i8] c"~"
@.d218 = private constant [10 x i8] c"olang_loc_"
@.d219 = private constant [1 x i8] c"_"
@.d220 = private constant [1 x i8] c"@"
@.d221 = private constant [22 x i8] c" = weak_odr constant ["
@.d222 = private constant [9 x i8] c" x i8] c\22"
@.d223 = private constant [5 x i8] c"\5C00\22\0A"
@.d224 = private constant [1 x i8] c"@"
@.d225 = private constant [30 x i8] c" = external constant [0 x i8]\0A"
@.d226 = private constant [1 x i8] c"@"
@.d227 = private constant [1 x i8] c"@"
@.d228 = private constant [5 x i8] c"undef"
@.d229 = private constant [12 x i8] c"insertvalue "
@.d230 = private constant [1 x i8] c" "
@.d231 = private constant [2 x i8] c", "
@.d232 = private constant [1 x i8] c" "
@.d233 = private constant [2 x i8] c", "
@.d234 = private constant [15 x i8] c"zeroinitializer"
@.d235 = private constant [14 x i8] c"getelementptr "
@.d236 = private constant [6 x i8] c", ptr "
@.d237 = private constant [6 x i8] c", i64 "
@.d238 = private constant [8 x i8] c"sub i64 "
@.d239 = private constant [2 x i8] c", "
@.d240 = private constant [0 x i8] c""
@.d241 = private constant [3 x i8] c"%lp"
@.d242 = private constant [3 x i8] c"ptr"
@.d243 = private constant [0 x i8] c""
@.d244 = private constant [76 x i8] c"store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s"
@.d245 = private constant [12 x i8] c"store ptr %s"
@.d246 = private constant [12 x i8] c"room, ptr %s"
@.d247 = private constant [8 x i8] c"a region"
@.d248 = private constant [42 x i8] c"store %olang.scope zeroinitializer, ptr %s"
@.d249 = private constant [23 x i8] c"store ptr null, ptr %jh"
@.d250 = private constant [15 x i8] c"__olang_sb_done"
@.d251 = private constant [19 x i8] c"__olang_scope_close"
@.d252 = private constant [36 x i8] c"getelementptr %olang.builder, ptr %s"
@.d253 = private constant [14 x i8] c", i32 0, i32 3"
@.d254 = private constant [3 x i8] c"ptr"
@.d255 = private constant [0 x i8] c""
@.d256 = private constant [12 x i8] c"icmp ne ptr "
@.d257 = private constant [6 x i8] c", null"
@.d258 = private constant [6 x i8] c"sbgrew"
@.d259 = private constant [6 x i8] c"sbdone"
@.d260 = private constant [6 x i8] c"br i1 "
@.d261 = private constant [9 x i8] c", label %"
@.d262 = private constant [9 x i8] c", label %"
@.d263 = private constant [33 x i8] c"call void @__olang_sb_done(ptr %s"
@.d264 = private constant [1 x i8] c")"
@.d265 = private constant [10 x i8] c"br label %"
@.d266 = private constant [37 x i8] c"call void @__olang_scope_close(ptr %s"
@.d267 = private constant [1 x i8] c")"
@.d268 = private constant [4 x i8] c"Give"
@.d269 = private constant [23 x i8] c"a cleanup (interpret's)"
@.d270 = private constant [24 x i8] c"a destructor not found: "
@.d271 = private constant [27 x i8] c"__olang_scope_register_dtor"
@.d272 = private constant [43 x i8] c"call void @__olang_scope_register_dtor(ptr "
@.d273 = private constant [6 x i8] c", ptr "
@.d274 = private constant [7 x i8] c", ptr @"
@.d275 = private constant [4 x i8] c"_rt)"
@.d276 = private constant [13 x i8] c"RegisterOwner"
@.d277 = private constant [7 x i8] c"Release"
@.d278 = private constant [8 x i8] c"mul i64 "
@.d279 = private constant [2 x i8] c", "
@.d280 = private constant [22 x i8] c"llvm.memmove.p0.p0.i64"
@.d281 = private constant [47 x i8] c"void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)"
@.d282 = private constant [38 x i8] c"call void @llvm.memmove.p0.p0.i64(ptr "
@.d283 = private constant [6 x i8] c", ptr "
@.d284 = private constant [6 x i8] c", i64 "
@.d285 = private constant [11 x i8] c", i1 false)"
@.d286 = private constant [1 x i8] c"!"
@.d287 = private constant [33 x i8] c" = distinct !DISubprogram(name: \22"
@.d288 = private constant [11 x i8] c"\22, scope: !"
@.d289 = private constant [9 x i8] c", file: !"
@.d290 = private constant [8 x i8] c", line: "
@.d291 = private constant [9 x i8] c", type: !"
@.d292 = private constant [13 x i8] c", scopeLine: "
@.d293 = private constant [38 x i8] c", spFlags: DISPFlagDefinition, unit: !"
@.d294 = private constant [2 x i8] c")\0A"
@.d295 = private constant [11 x i8] c"unreachable"
@.d296 = private constant [10 x i8] c"br label %"
@.d297 = private constant [6 x i8] c"br i1 "
@.d298 = private constant [9 x i8] c", label %"
@.d299 = private constant [9 x i8] c", label %"
@.d300 = private constant [7 x i8] c"switch "
@.d301 = private constant [1 x i8] c" "
@.d302 = private constant [9 x i8] c", label %"
@.d303 = private constant [2 x i8] c" ["
@.d304 = private constant [1 x i8] c" "
@.d305 = private constant [1 x i8] c" "
@.d306 = private constant [9 x i8] c", label %"
@.d307 = private constant [2 x i8] c" ]"
@.d308 = private constant [4 x i8] c"%out"
@.d309 = private constant [0 x i8] c""
@.d310 = private constant [3 x i8] c"i32"
@.d311 = private constant [1 x i8] c"0"
@.d312 = private constant [3 x i8] c"%rv"
@.d313 = private constant [0 x i8] c""
@.d314 = private constant [4 x i8] c"void"
@.d315 = private constant [3 x i8] c"i32"
@.d316 = private constant [1 x i8] c"0"
@.d317 = private constant [3 x i8] c"%rv"
@.d318 = private constant [0 x i8] c""
@.d319 = private constant [12 x i8] c"insertvalue "
@.d320 = private constant [18 x i8] c" zeroinitializer, "
@.d321 = private constant [1 x i8] c" "
@.d322 = private constant [3 x i8] c", 1"
@.d323 = private constant [3 x i8] c"%rv"
@.d324 = private constant [0 x i8] c""
@.d325 = private constant [3 x i8] c"%rv"
@.d326 = private constant [0 x i8] c""
@.d327 = private constant [13 x i8] c"br label %ret"
@.d328 = private constant [3 x i8] c"i32"
@.d329 = private constant [3 x i8] c"i32"
@.d330 = private constant [3 x i8] c"%rv"
@.d331 = private constant [0 x i8] c""
@.d332 = private constant [12 x i8] c"insertvalue "
@.d333 = private constant [22 x i8] c" zeroinitializer, i32 "
@.d334 = private constant [3 x i8] c", 0"
@.d335 = private constant [3 x i8] c"%rv"
@.d336 = private constant [0 x i8] c""
@.d337 = private constant [13 x i8] c"br label %ret"
@.d338 = private constant [18 x i8] c"__olang_join_tasks"
@.d339 = private constant [28 x i8] c"i64 @__olang_join_tasks(ptr)"
@.d340 = private constant [36 x i8] c"call i64 @__olang_join_tasks(ptr %jh"
@.d341 = private constant [1 x i8] c")"
@.d342 = private constant [10 x i8] c"trunc i64 "
@.d343 = private constant [7 x i8] c" to i32"
@.d344 = private constant [10 x i8] c"br label %"
@.d345 = private constant [3 x i8] c"i32"
@.d346 = private constant [0 x i8] c""
@.d347 = private constant [12 x i8] c"icmp ne i32 "
@.d348 = private constant [3 x i8] c", 0"
@.d349 = private constant [6 x i8] c"br i1 "
@.d350 = private constant [9 x i8] c", label %"
@.d351 = private constant [9 x i8] c", label %"
@.d352 = private constant [23 x i8] c"a cleanup (interpret's)"
@.d353 = private constant [1 x i8] c"@"
@.d354 = private constant [0 x i8] c""
@.d355 = private constant [19 x i8] c"\0A!20 = !{!\22olang\22}\0A"
@.d356 = private constant [66 x i8] c"!49 = !{!\22scopehdr\22, !20, i64 0}\0A!50 = !{!\22chunkhdr\22, !20, i64 0}\0A"
@.d357 = private constant [50 x i8] c"!59 = !{!49, !49, i64 0}\0A!60 = !{!50, !50, i64 0}\0A"
@.d358 = private constant [66 x i8] c"!17 = !{!\22arraydesc\22, !20, i64 0}\0A!18 = !{!\22closure\22, !20, i64 0}\0A"
@.d359 = private constant [64 x i8] c"!47 = !{!\22arraydesc[]\22, !20, i64 0}\0A!19 = !{!\22ref\22, !20, i64 0}\0A"
@.d360 = private constant [80 x i8] c"!48 = !{!\22ref[]\22, !20, i64 0}\0A!29 = !{!19, !19, i64 0}\0A!39 = !{!48, !48, i64 0}\0A"
@.d361 = private constant [75 x i8] c"!27 = !{!17, !17, i64 0}\0A!28 = !{!18, !18, i64 0}\0A!37 = !{!47, !47, i64 0}\0A"
@.d362 = private constant [1 x i8] c"\0A"
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2eRu_Hba7f56c70b20c8f60a4a5345f2cfd0c9(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_9506350913203bfc_41d6488afcc367c0 = external constant [0 x i8]
@olang_loc_2a2725b2da5e1bad_47abef39162bd051 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_98184d77b87c9296_c4a7a562026735ba = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgType(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i64 %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecodeType(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2epassedOf(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1, i32 %a2)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehasEnv(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efnItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [1 x i64] } %a1, i32 %a2, { i64, ptr } %a3, i64 %a4, i1 %a5, { i64, ptr } %a6)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntimeItems(ptr %v0, ptr %a0)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eindex(ptr %v0, ptr %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2ecompiler_2femit_3aEmitter_2ereusing(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_ca7da4b07cdf4cec_48bb1648ef269dd0 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_3d03f0fa145d919d_fe5358f320913361 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_e861e29eb0c54c86_5bd3b462adfe92ca = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2eRunFrom_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_9cb730421d055767_147ce7dab62cfd0b = external constant [0 x i8]
@olang_loc_64b7f3da640c4c50_ae80c71f07f99e6c = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2eLen_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0)
declare { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2eAt_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efunction(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ethunk(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1, i32 %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2efvAdapter(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_1a5036849576e1e1_210713689f77e31d = external constant [0 x i8]
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edtorThunk(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eharness(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eentry(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, i64 %a2)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eStructBody(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eEmbedded(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eneed(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_4fc93e498ee23529_4b147f0de2788105 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePayloadSize(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2emathIntrinsic(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehas(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eexternRet(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2emathParams(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2etypeHome(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_884b1f134ce8f58_4f25fcbaf6ee0184 = external constant [0 x i8]
@olang_loc_77c745ca54276229_8072b8e8f7d66d75 = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2flower_2ecompiler_2flower_3aLowerer_2eInitModules(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %a0)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2evisit(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3)
@olang_loc_7e34c17454aff800_e19f636b4fbc434 = external constant [0 x i8]
declare i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_de92fa5f00317f7b_3680b631254dc667 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_ce826338cbf4afde_5a793f5031108f92 = external constant [0 x i8]
@olang_loc_71a9e12f05a3bddd_baac335f863186a9 = external constant [0 x i8]
@olang_loc_2d324f4199cd7780_534dee4d2a64aebc = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_ccd5cb87339e775f_a8ec88fdee920643 = external constant [0 x i8]
@olang_loc_502634e55cf63fe2_bb9ce6600b3e98e6 = external constant [0 x i8]
@olang_loc_b7179de695e5661_8fd10db64c62ad05 = external constant [0 x i8]
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_He890afa3b14bd52c6ea464bca4cef525(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_80d737cc9290fb3c_d5f23604b0833618 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_50d6af1e4a9d3e1b_3bae03e7ad9fa57f = external constant [0 x i8]
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2egroupRank(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eassemble(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, i1 %a2, i64 %a3, i64 %a4, ptr %a5, i64 %a6, ptr %a7, i64 %a8)
declare %"compiler/emit:Object" @compiler_2femit_3aObject_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i32 %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2ePush_3ccompiler_2femit_3aObject_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/emit:Object" %a1)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eLen_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2elocations(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2erefsIn(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eSetAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e_2eG_H6ffe2eb17daa971b2c9d564ad72358b1(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e_2eP_H79a97b7337c7adf08bdd37311af7e171(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1, i64 %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
@olang_loc_6f064da57090b2af_17093dce158f11fb = external constant [0 x i8]
@G_2ecompiler_2fmir_2eNoLocal = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
@olang_loc_ed162375e135a06c_e406bb0ac0d59940 = external constant [0 x i8]
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2ederefs(ptr %v0, ptr %a0, %"compiler/mir:Place" %a1)
declare { i64, [4 x i64] } @compiler_2femit_2ecompiler_2femit_3afnEm_2earg(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1, i64 %a2)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2ebaseIs(ptr %v0, ptr %a0, %"compiler/mir:Place" %a1, i32 %a2)
@olang_loc_5f9c6fbf78b3e51d_e9dc61b8da3e01d1 = external constant [0 x i8]
@olang_loc_afa6164151ba006_66d817e1c679673a = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixedLen(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etbaa(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i1 %a2)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2eput(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, [4 x i64] } %a3, { i64, ptr } %a4)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2efieldList(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/mir:TaskClause" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTaskClause_3e_2eAt_H2a51e389d978bc4a54496c3113cf8f80(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Item" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aItem_3e_2eAt_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eposition(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %a0, { i64, [5 x i64] } %a1, i32 %a2)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2escope(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ecopyArrayIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i32 %a3)
declare { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %v1, ptr %a0, %"compiler/mir:Place" %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
@olang_loc_2b2f6fb90634cfa0_5bc60e788a752af4 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e_2eLen_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0)
@olang_loc_cf8290f43b8cf4bf_3d9bfdc06546f1cb = external constant [0 x i8]
@olang_loc_1966eb58572a69ea_7a4114e6fad4d136 = external constant [0 x i8]
declare { i64, [4 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %v1, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aWriteKind_3e_2eAt_3ccompiler_2fmir_3aWriteKind_3e(ptr %v0, ptr %a0, i64 %a1)
declare { { i64, ptr }, { i64, ptr } } @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayParts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ezext64(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eindex(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2)
@olang_loc_5356cb2f84f9732_b3351f2e3cf54f16 = external constant [0 x i8]
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_d4d3fc4bcd6b40b3_c2e6c5c87babde37 = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2epair(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aBasicBlock_3e_2eRu_H05f2a0ad75f6ffeece9ab76b4dcd7cb0(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_8a0f087481b95ab0_a13f080fe7b316d4 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0)
declare { i64, [21 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/mir:ScopeInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_9d64128d60439a41_20f9e6973a71ad85 = external constant [0 x i8]
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eplainWrite(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erefIs(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1, i64 %a2)
@olang_loc_28dd7919903bc2a_4577237eccb57ce = external constant [0 x i8]
@olang_loc_6846df2bf697eaeb_3c0ad43c6c9a3c0f = external constant [0 x i8]
@olang_loc_2bfcda938bdeba4c_88387621cebbefd8 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/mir:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eisFrame(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edbgLine(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewhere(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2elocBase(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eHash(ptr %v0, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %v0, i64 %a0, i64 %a1)
@olang_loc_6a1c0f36bb2af484_15693b919ea68168 = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2eescape(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eplaceType(ptr %v0, ptr %a0, %"compiler/mir:Place" %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erunTime(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efillInPlace(ptr %v0, ptr %a0, %"compiler/mir:Place" %a1, i32 %a2, { i64, [15 x i64] } %a3)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eviaMem(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eintoPlace(ptr %v0, ptr %a0, %"compiler/mir:Place" %a1, i32 %a2, { i64, [15 x i64] } %a3)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ervalue(ptr %v0, ptr %v1, ptr %a0, { i64, [15 x i64] } %a1, i32 %a2)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalType(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ealign(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloc(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [1 x i64] } %a1, { i64, ptr } %a2, i64 %a3, { i64, ptr } %a4)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aWriteKind_3e_2eCle_H5b7b223941fd921209e2fd14e30a86e3(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e_2eClear_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2eunwindPush(ptr %v0, ptr %a0, i32 %a1, i1 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2eunwindPop(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2etrace(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_Hf0a5beca6f8aee4731a76bd327ae0a99(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_He6968003b8dd5762fa82ec44b4ee1fc9(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1, i1 %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aWriteKind_3e_2ePus_Hb3977af45b838e23bffe750970901b09(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aOperand_3e_2ePush_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2ewrite(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, [4 x i64] } %a3)
declare %"compiler/mir:Task" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2espawn(ptr %v0, ptr %a0, i32 %a1, %"compiler/mir:Task" %a2)
@olang_loc_73cacc8093766858_2881ed4d4d5af0d4 = external constant [0 x i8]
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgFile(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgName(ptr %v0, ptr %v1, ptr %a0, { i64, [1 x i64] } %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgSubTy(ptr %v0, ptr %a0)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgCu(ptr %v0, ptr %a0)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare %"compiler/mir:Case" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCase_3e_2eAt_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2econstText(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare %"compiler/mir:Call" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2ecall(ptr %v0, ptr %a0, %"compiler/mir:Call" %a1)
@G_2ecompiler_2fmir_2eI32T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\05\00\00\00" }>, align 8
@G_2ecompiler_2fmir_2eNoBlock = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2eexit(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, [4 x i64] } %a3)
@olang_loc_7633dd9d24c54174_280dfd74a77e9550 = external constant [0 x i8]
@olang_loc_5dfa9b7395be5458_e24cfc313725a25c = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fmir_3aStmt_3e_2eRunFrom_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_cd3d2f4cb5172729_796de8126c3e3b8d = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@olang_loc_aa77627ec6eb5ef2_35c32f6dd172e1f6 = external constant [0 x i8]
@olang_loc_adfc2b4e0bd5373_1e3a8de6ffd7da97 = external constant [0 x i8]
declare i1 @compiler_2femit_2esymbolChar(i8 %a0)
@olang_loc_f695fddd526749db_a8fb91cf3e060dd7 = external constant [0 x i8]
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2femit_2emathInexactTable(ptr %v0)
@olang_loc_f86c3108d396390c_a897abfaa875b378 = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2etbaaLeaves(ptr %v0)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
@olang_loc_a69d5bfe0a165b0_62b4fff2e0b246dc = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
