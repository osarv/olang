; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/profile:Sample" = type { i64, i64, i64 }
%"compiler/profile:node" = type { i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/profile:Frame" = type { i64, i64, i64 }
%"compiler/profile:Profile" = type { i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr } }
%"compiler/profile:Places" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/profile:Tally" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/profile:mapping" = type { i64, i64, i64, { i64, ptr } }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
%"compiler/profile:elfFn" = type { i64, i64, { i64, ptr } }
@G_2ecompiler_2fprofile_2eFlameScript = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\07\04\00\00\00\00\00\00", ptr @G_2ecompiler_2fprofile_2eFlameScript.k1 }>, align 8
@G_2ecompiler_2fprofile_2eFlameScript.k1 = internal constant <{ [1031 x i8] }> <{ [1031 x i8] c"\3C\73\63\72\69\70\74\3E\0A\28\66\75\6E\63\74\69\6F\6E\28\29\7B\0A\20\20\76\61\72\20\73\76\67\3D\64\6F\63\75\6D\65\6E\74\2E\67\65\74\45\6C\65\6D\65\6E\74\42\79\49\64\28\22\66\67\22\29\2C\57\3D\73\76\67\2E\67\65\74\41\74\74\72\69\62\75\74\65\28\22\77\69\64\74\68\22\29\2A\31\2C\67\73\3D\73\76\67\2E\71\75\65\72\79\53\65\6C\65\63\74\6F\72\41\6C\6C\28\22\67\2E\66\22\29\3B\0A\20\20\66\75\6E\63\74\69\6F\6E\20\73\68\6F\77\28\78\30\2C\77\30\2C\64\30\29\7B\0A\20\20\20\20\66\6F\72\28\76\61\72\20\69\3D\30\3B\69\3C\67\73\2E\6C\65\6E\67\74\68\3B\69\2B\2B\29\7B\0A\20\20\20\20\20\20\76\61\72\20\67\3D\67\73\5B\69\5D\2C\78\3D\67\2E\64\61\74\61\73\65\74\2E\78\2A\31\2C\77\3D\67\2E\64\61\74\61\73\65\74\2E\77\2A\31\2C\64\3D\67\2E\64\61\74\61\73\65\74\2E\64\2A\31\2C\72\3D\67\2E\71\75\65\72\79\53\65\6C\65\63\74\6F\72\28\22\72\65\63\74\22\29\2C\74\3D\67\2E\71\75\65\72\79\53\65\6C\65\63\74\6F\72\28\22\74\65\78\74\22\29\3B\0A\20\20\20\20\20\20\76\61\72\20\69\6E\73\69\64\65\3D\78\3E\3D\78\30\26\26\78\2B\77\3C\3D\78\30\2B\77\30\2C\75\6E\64\65\72\3D\64\3C\64\30\26\26\78\3C\3D\78\30\26\26\78\2B\77\3E\3D\78\30\2B\77\30\3B\0A\20\20\20\20\20\20\69\66\28\21\28\69\6E\73\69\64\65\26\26\64\3E\3D\64\30\29\26\26\21\75\6E\64\65\72\29\7B\67\2E\73\74\79\6C\65\2E\64\69\73\70\6C\61\79\3D\22\6E\6F\6E\65\22\3B\63\6F\6E\74\69\6E\75\65\7D\0A\20\20\20\20\20\20\67\2E\73\74\79\6C\65\2E\64\69\73\70\6C\61\79\3D\22\22\3B\0A\20\20\20\20\20\20\76\61\72\20\70\78\3D\75\6E\64\65\72\3F\30\3A\28\78\2D\78\30\29\2F\77\30\2A\57\2C\70\77\3D\75\6E\64\65\72\3F\57\3A\77\2F\77\30\2A\57\3B\0A\20\20\20\20\20\20\72\2E\73\65\74\41\74\74\72\69\62\75\74\65\28\22\78\22\2C\70\78\29\3B\72\2E\73\65\74\41\74\74\72\69\62\75\74\65\28\22\77\69\64\74\68\22\2C\4D\61\74\68\2E\6D\61\78\28\70\77\2D\31\2C\30\2E\35\29\29\3B\74\2E\73\65\74\41\74\74\72\69\62\75\74\65\28\22\78\22\2C\70\78\2B\33\29\3B\0A\20\20\20\20\20\20\76\61\72\20\66\75\6C\6C\3D\67\2E\71\75\65\72\79\53\65\6C\65\63\74\6F\72\28\22\74\69\74\6C\65\22\29\2E\74\65\78\74\43\6F\6E\74\65\6E\74\2E\72\65\70\6C\61\63\65\28\2F\20\2D\20\5B\30\2D\39\2E\5D\2B\20\6D\73\2C\20\2E\2A\24\2F\2C\22\22\29\2C\6E\3D\4D\61\74\68\2E\66\6C\6F\6F\72\28\28\70\77\2D\36\29\2F\37\29\3B\0A\20\20\20\20\20\20\74\2E\74\65\78\74\43\6F\6E\74\65\6E\74\3D\6E\3C\33\3F\22\22\3A\28\66\75\6C\6C\2E\6C\65\6E\67\74\68\3C\3D\6E\3F\66\75\6C\6C\3A\66\75\6C\6C\2E\73\6C\69\63\65\28\30\2C\6E\2D\32\29\2B\22\2E\2E\22\29\3B\0A\20\20\20\20\7D\0A\20\20\7D\0A\20\20\66\6F\72\28\76\61\72\20\69\3D\30\3B\69\3C\67\73\2E\6C\65\6E\67\74\68\3B\69\2B\2B\29\7B\67\73\5B\69\5D\2E\61\64\64\45\76\65\6E\74\4C\69\73\74\65\6E\65\72\28\22\63\6C\69\63\6B\22\2C\66\75\6E\63\74\69\6F\6E\28\29\7B\0A\20\20\20\20\76\61\72\20\64\3D\74\68\69\73\2E\64\61\74\61\73\65\74\2E\64\2A\31\3B\73\68\6F\77\28\74\68\69\73\2E\64\61\74\61\73\65\74\2E\78\2A\31\2C\4D\61\74\68\2E\6D\61\78\28\74\68\69\73\2E\64\61\74\61\73\65\74\2E\77\2A\31\2C\31\29\2C\64\3D\3D\30\3F\30\3A\64\29\7D\29\7D\0A\20\20\73\68\6F\77\28\30\2C\4D\61\74\68\2E\6D\61\78\28\73\76\67\2E\64\61\74\61\73\65\74\2E\74\6F\74\61\6C\2A\31\2C\31\29\2C\30\29\3B\0A\7D\29\28\29\3B\0A\3C\2F\73\63\72\69\70\74\3E" }>, align 64
@G_2ecompiler_2fprofile_2eFlameWidth = constant <{ [8 x i8] }> <{ [8 x i8] c"\B0\04\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fprofile_2eFrameHeight = constant <{ [8 x i8] }> <{ [8 x i8] c"\12\00\00\00\00\00\00\00" }>, align 8
define dso_local { i64, ptr } @compiler_2fprofile_2eFlameGraph(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/profile:Sample"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca i64
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca %"compiler/profile:node"
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca %"std/prelude/text:StringBuilder"
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca ptr
  %l31 = alloca i64
  %l32 = alloca %"compiler/profile:node"
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l36 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca %"std/prelude/text:StringBuilder"
  %l52 = alloca double
  %l53 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l54 = alloca ptr
  %l55 = alloca %"compiler/profile:node"
  %l58 = alloca i64
  %l60 = alloca i64
  %l65 = alloca %"compiler/profile:Sample"
  %l69 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l73 = alloca ptr
  %l74 = alloca ptr
  %l79 = alloca i64
  %l85 = alloca ptr
  %l88 = alloca i64
  %l89 = alloca %"compiler/profile:Frame"
  %l93 = alloca %"compiler/profile:node"
  %l95 = alloca %"compiler/profile:node"
  %l97 = alloca i64
  %l99 = alloca i64
  %l104 = alloca i64
  %l107 = alloca %"compiler/profile:node"
  %l117 = alloca i64
  %l118 = alloca ptr
  %l119 = alloca i64
  %l122 = alloca %"compiler/profile:node"
  %l125 = alloca %"compiler/profile:node"
  %l128 = alloca ptr
  %l136 = alloca ptr
  %l137 = alloca ptr
  %l147 = alloca i64
  %l149 = alloca i64
  %l154 = alloca %"compiler/profile:node"
  %l162 = alloca %"compiler/profile:node"
  %l169 = alloca %"std/prelude/text:StringBuilder"
  %l170 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l172 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l174 = alloca i64
  %l176 = alloca i64
  %l181 = alloca %"compiler/profile:node"
  %l183 = alloca %"compiler/profile:node"
  %l187 = alloca i64
  %l189 = alloca i64
  %l194 = alloca i64
  %l197 = alloca %"compiler/profile:node"
  %l199 = alloca %"compiler/profile:node"
  %l200 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l202 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l209 = alloca i64
  %l211 = alloca i64
  %l213 = alloca i64
  %l218 = alloca i64
  %l222 = alloca i64
  %l225 = alloca %"compiler/profile:node"
  %l235 = alloca i64
  %l237 = alloca i64
  %l242 = alloca i64
  %l245 = alloca ptr
  %l248 = alloca { i64, ptr }
  %l253 = alloca { i64, ptr }
  %l254 = alloca { i64, ptr }
  %l259 = alloca { i64, ptr }
  %l263 = alloca { i64, ptr }
  %l266 = alloca i64
  %l286 = alloca ptr
  %l289 = alloca i64
  %l291 = alloca i64
  %l293 = alloca i64
  %l295 = alloca { i64, ptr }
  %l296 = alloca i64
  %l298 = alloca i64
  %l299 = alloca i64
  %l300 = alloca i64
  %l301 = alloca i64
  %l304 = alloca { i64, ptr }
  %l306 = alloca { i64, ptr }
  %l311 = alloca %"std/prelude/text:StringBuilder"
  %l312 = alloca ptr
  %l314 = alloca { i64, ptr }
  %l319 = alloca i64
  %l326 = alloca ptr
  %l328 = alloca { i64, ptr }
  %l331 = alloca i64
  %l333 = alloca { i64, ptr }
  %l336 = alloca ptr
  %l337 = alloca i64
  %l338 = alloca i64
  %l339 = alloca i64
  %l341 = alloca { i64, ptr }
  %l348 = alloca { i64, ptr }
  %l349 = alloca { i64, ptr }
  %l350 = alloca i64
  %l351 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t286 = alloca { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr }, align 8
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l53
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l53
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l3
  store ptr %l3, ptr %l54, !tbaa !29
  %t3 = call %"compiler/profile:node" @compiler_2fprofile_3anode_2ector(ptr %s0, i64 -1, i64 0)
  store %"compiler/profile:node" %t3, ptr %l55
  br label %bb2
bb2:
  %t4 = load ptr, ptr %l54, !tbaa !29
  %t5 = load %"compiler/profile:node", ptr %l55
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2ePush_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s0, ptr %t4, %"compiler/profile:node" %t5)
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/profile:Profile", ptr %t6, i32 0, i32 3
  store ptr %t8, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = load i64, ptr %l5, !tbaa !24
  store i64 %t10, ptr %l58, !tbaa !24
  %t11 = load ptr, ptr %l4, !tbaa !29
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2eLen_3ccompiler_2fprofile_3aSample_3e(ptr %v1, ptr %t11)
  store i64 %t13, ptr %l60
  br label %bb5
bb5:
  %t14 = load i64, ptr %l58, !tbaa !24
  %t15 = load i64, ptr %l60, !tbaa !24
  %t16 = icmp slt i64 %t14, %t15
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb46
bb7:
  br label %bb8
bb8:
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t21 = load i64, ptr %l5, !tbaa !24
  %t24 = call %"compiler/profile:Sample" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2eAt_3ccompiler_2fprofile_3aSample_3e(ptr %v1, ptr %t20, i64 %t21)
  store %"compiler/profile:Sample" %t24, ptr %l65
  br label %bb9
bb9:
  %t25 = load %"compiler/profile:Sample", ptr %l65
  store %"compiler/profile:Sample" %t25, ptr %l6
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t28 = load %"compiler/profile:Sample", ptr %l6
  %t32 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2estack(ptr %v2, ptr %v1, ptr %s2, ptr %t26, ptr %t27, %"compiler/profile:Sample" %t28)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %l69
  br label %bb10
bb10:
  %t33 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l69
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t33, ptr %l7
  store i64 0, ptr %l8, !tbaa !24
  %t34 = getelementptr %"compiler/profile:Sample", ptr %l6, i32 0, i32 0
  %t35 = load i64, ptr %t34, !tbaa !24
  store i64 %t35, ptr %l10, !tbaa !24
  %t40 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eRefMut_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s0, ptr %l3, i64 0)
  store ptr %t40, ptr %l73
  br label %bb11
bb11:
  %t41 = load ptr, ptr %l73, !tbaa !29
  store ptr %t41, ptr %l74, !tbaa !29
  %t43 = load ptr, ptr %l74, !tbaa !29
  %t44 = getelementptr %"compiler/profile:node", ptr %t43, i32 0, i32 2
  %t45 = load i64, ptr %t44, !tbaa !24
  %t46 = load i64, ptr %l10, !tbaa !24
  %t49 = add i64 %t45, %t46
  %t51 = load ptr, ptr %l74, !tbaa !29
  %t52 = getelementptr %"compiler/profile:node", ptr %t51, i32 0, i32 2
  store i64 %t49, ptr %t52, !tbaa !24
  %t54 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s2, ptr %l7)
  store i64 %t54, ptr %l79
  br label %bb12
bb12:
  %t55 = load i64, ptr %l79, !tbaa !24
  %t56 = sub i64 %t55, 1
  store i64 %t56, ptr %l12, !tbaa !24
  br label %bb13
bb13:
  %t58 = load i64, ptr %l12, !tbaa !24
  %t60 = icmp sge i64 %t58, 0
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb14, label %bb15
bb14:
  br label %bb44
bb15:
  br label %bb16
bb16:
  %t64 = load ptr, ptr %l2, !tbaa !29
  %t66 = getelementptr %"compiler/profile:Places", ptr %t64, i32 0, i32 2
  store ptr %t66, ptr %l85, !tbaa !29
  %t67 = load i64, ptr %l12, !tbaa !24
  %t70 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %l7, i64 %t67)
  store i64 %t70, ptr %l88
  br label %bb17
bb17:
  %t71 = load ptr, ptr %l85, !tbaa !29
  %t72 = load i64, ptr %l88, !tbaa !24
  %t73 = call %"compiler/profile:Frame" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2eAt_3ccompiler_2fprofile_3aFrame_3e(ptr %v2, ptr %t71, i64 %t72)
  store %"compiler/profile:Frame" %t73, ptr %l89
  br label %bb18
bb18:
  %t74 = getelementptr %"compiler/profile:Frame", ptr %l89, i32 0, i32 0
  %t75 = load i64, ptr %t74, !tbaa !24
  store i64 %t75, ptr %l13, !tbaa !24
  store i64 -1, ptr %l14, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s4
  %t77 = load i64, ptr %l8, !tbaa !24
  %t80 = call %"compiler/profile:node" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eAt_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s0, ptr %l3, i64 %t77)
  store %"compiler/profile:node" %t80, ptr %l93
  br label %bb19
bb19:
  %t82 = call %"compiler/profile:node" @olang_2eHelperKind_2eCopy_2ecompiler_2fprofile_3anode(ptr %s0, ptr %l93)
  store %"compiler/profile:node" %t82, ptr %l95
  br label %bb20
bb20:
  %t83 = getelementptr %"compiler/profile:node", ptr %l95, i32 0, i32 3
  store ptr %t83, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s5
  %t85 = load i64, ptr %l16, !tbaa !24
  store i64 %t85, ptr %l97, !tbaa !24
  %t86 = load ptr, ptr %l15, !tbaa !29
  %t88 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s4, ptr %t86)
  store i64 %t88, ptr %l99
  br label %bb22
bb22:
  %t89 = load i64, ptr %l97, !tbaa !24
  %t90 = load i64, ptr %l99, !tbaa !24
  %t91 = icmp slt i64 %t89, %t90
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s5)
  br label %bb32
bb24:
  br label %bb25
bb25:
  %t95 = load ptr, ptr %l15, !tbaa !29
  %t96 = load i64, ptr %l16, !tbaa !24
  %t99 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s4, ptr %t95, i64 %t96)
  store i64 %t99, ptr %l104
  br label %bb26
bb26:
  %t100 = load i64, ptr %l104, !tbaa !24
  store i64 %t100, ptr %l17, !tbaa !24
  %t101 = load i64, ptr %l17, !tbaa !24
  %t104 = call %"compiler/profile:node" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eAt_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s5, ptr %l3, i64 %t101)
  store %"compiler/profile:node" %t104, ptr %l107
  br label %bb27
bb27:
  %t105 = getelementptr %"compiler/profile:node", ptr %l107, i32 0, i32 0
  %t106 = load i64, ptr %t105, !tbaa !24
  %t107 = load i64, ptr %l13, !tbaa !24
  %t110 = icmp eq i64 %t106, %t107
  br i1 %t110, label %bb28, label %bb29
bb28:
  %t112 = load i64, ptr %l17, !tbaa !24
  store i64 %t112, ptr %l14, !tbaa !24
  br label %bb30
bb29:
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb31:
  %t114 = load i64, ptr %l16, !tbaa !24
  %t116 = add i64 %t114, 1
  store i64 %t116, ptr %l16, !tbaa !24
  br label %bb21
bb32:
  call void @__olang_scope_close(ptr %s4)
  %t118 = load i64, ptr %l14, !tbaa !24
  %t120 = icmp slt i64 %t118, 0
  br i1 %t120, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s8
  %t123 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eLen_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %l3)
  store i64 %t123, ptr %l117
  br label %bb35
bb34:
  br label %bb41
bb35:
  %t124 = load i64, ptr %l117, !tbaa !24
  store i64 %t124, ptr %l14, !tbaa !24
  store ptr %l3, ptr %l118, !tbaa !29
  %t125 = load i64, ptr %l13, !tbaa !24
  store i64 %t125, ptr %l119, !tbaa !24
  %t126 = load i64, ptr %l8, !tbaa !24
  %t129 = call %"compiler/profile:node" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eAt_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s8, ptr %l3, i64 %t126)
  store %"compiler/profile:node" %t129, ptr %l122
  br label %bb36
bb36:
  %t130 = getelementptr %"compiler/profile:node", ptr %l122, i32 0, i32 1
  %t131 = load i64, ptr %t130, !tbaa !24
  %t133 = add i64 %t131, 1
  %t134 = load i64, ptr %l119, !tbaa !24
  %t136 = call %"compiler/profile:node" @compiler_2fprofile_3anode_2ector(ptr %s8, i64 %t134, i64 %t133)
  store %"compiler/profile:node" %t136, ptr %l125
  br label %bb37
bb37:
  %t137 = load ptr, ptr %l118, !tbaa !29
  %t138 = load %"compiler/profile:node", ptr %l125
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2ePush_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s8, ptr %t137, %"compiler/profile:node" %t138)
  br label %bb38
bb38:
  %t139 = load i64, ptr %l8, !tbaa !24
  %t142 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eRefMut_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s0, ptr %l3, i64 %t139)
  store ptr %t142, ptr %l128
  br label %bb39
bb39:
  %t143 = load ptr, ptr %l128, !tbaa !29
  %t145 = getelementptr %"compiler/profile:node", ptr %t143, i32 0, i32 3
  %t146 = load i64, ptr %l14, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t145, i64 %t146)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s8)
  br label %bb41
bb41:
  %t149 = load i64, ptr %l14, !tbaa !24
  %t151 = getelementptr %"compiler/profile:Sample", ptr %l6, i32 0, i32 0
  %t152 = load i64, ptr %t151, !tbaa !24
  store i64 %t152, ptr %l19, !tbaa !24
  %t157 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eRefMut_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s0, ptr %l3, i64 %t149)
  store ptr %t157, ptr %l136
  br label %bb42
bb42:
  %t158 = load ptr, ptr %l136, !tbaa !29
  store ptr %t158, ptr %l137, !tbaa !29
  %t160 = load ptr, ptr %l137, !tbaa !29
  %t161 = getelementptr %"compiler/profile:node", ptr %t160, i32 0, i32 2
  %t162 = load i64, ptr %t161, !tbaa !24
  %t163 = load i64, ptr %l19, !tbaa !24
  %t166 = add i64 %t162, %t163
  %t168 = load ptr, ptr %l137, !tbaa !29
  %t169 = getelementptr %"compiler/profile:node", ptr %t168, i32 0, i32 2
  store i64 %t166, ptr %t169, !tbaa !24
  %t170 = load i64, ptr %l14, !tbaa !24
  store i64 %t170, ptr %l8, !tbaa !24
  %t172 = load i64, ptr %l12, !tbaa !24
  %t174 = sub i64 %t172, 1
  store i64 %t174, ptr %l12, !tbaa !24
  br label %bb43
bb43:
  br label %bb13
bb44:
  call void @__olang_scope_close(ptr %s2)
  br label %bb45
bb45:
  %t176 = load i64, ptr %l5, !tbaa !24
  %t178 = add i64 %t176, 1
  store i64 %t178, ptr %l5, !tbaa !24
  br label %bb4
bb46:
  store i64 0, ptr %l21, !tbaa !24
  store ptr %l3, ptr %l22, !tbaa !29
  store i64 0, ptr %l23, !tbaa !24
  br label %bb47
bb47:
  %t181 = load i64, ptr %l23, !tbaa !24
  store i64 %t181, ptr %l147, !tbaa !24
  %t182 = load ptr, ptr %l22, !tbaa !29
  %t184 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eLen_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %t182)
  store i64 %t184, ptr %l149
  br label %bb48
bb48:
  %t185 = load i64, ptr %l147, !tbaa !24
  %t186 = load i64, ptr %l149, !tbaa !24
  %t187 = icmp slt i64 %t185, %t186
  %t189 = xor i1 %t187, true
  br i1 %t189, label %bb49, label %bb50
bb49:
  br label %bb57
bb50:
  br label %bb51
bb51:
  %t191 = load ptr, ptr %l22, !tbaa !29
  %t192 = load i64, ptr %l23, !tbaa !24
  %t195 = call %"compiler/profile:node" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eAt_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s0, ptr %t191, i64 %t192)
  store %"compiler/profile:node" %t195, ptr %l154
  br label %bb52
bb52:
  %t196 = load %"compiler/profile:node", ptr %l154
  store %"compiler/profile:node" %t196, ptr %l24
  %t197 = getelementptr %"compiler/profile:node", ptr %l24, i32 0, i32 1
  %t198 = load i64, ptr %t197, !tbaa !24
  %t199 = load i64, ptr %l21, !tbaa !24
  %t202 = icmp sgt i64 %t198, %t199
  br i1 %t202, label %bb53, label %bb54
bb53:
  %t204 = getelementptr %"compiler/profile:node", ptr %l24, i32 0, i32 1
  %t205 = load i64, ptr %t204, !tbaa !24
  store i64 %t205, ptr %l21, !tbaa !24
  br label %bb55
bb54:
  br label %bb55
bb55:
  br label %bb56
bb56:
  %t207 = load i64, ptr %l23, !tbaa !24
  %t209 = add i64 %t207, 1
  store i64 %t209, ptr %l23, !tbaa !24
  br label %bb47
bb57:
  %t212 = call %"compiler/profile:node" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eAt_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s0, ptr %l3, i64 0)
  store %"compiler/profile:node" %t212, ptr %l162
  br label %bb58
bb58:
  %t213 = getelementptr %"compiler/profile:node", ptr %l162, i32 0, i32 2
  %t214 = load i64, ptr %t213, !tbaa !24
  store i64 %t214, ptr %l25, !tbaa !24
  %t216 = load i64, ptr %l21, !tbaa !24
  %t218 = add i64 %t216, 1
  %t219 = load i64, ptr @G_2ecompiler_2fprofile_2eFrameHeight, !tbaa !24
  %t222 = mul i64 %t218, %t219
  %t224 = add i64 %t222, 40
  store i64 %t224, ptr %l26, !tbaa !24
  %t226 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t226, ptr %l169
  br label %bb59
bb59:
  %t227 = load %"std/prelude/text:StringBuilder", ptr %l169
  store %"std/prelude/text:StringBuilder" %t227, ptr %l27
  %t228 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t228, ptr %l170
  br label %bb60
bb60:
  %t229 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l170
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t229, ptr %l28
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l28, i64 0)
  br label %bb61
bb61:
  %t231 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t231, ptr %l172
  br label %bb62
bb62:
  %t232 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l172
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t232, ptr %l29
  store ptr %l3, ptr %l30, !tbaa !29
  store i64 0, ptr %l31, !tbaa !24
  br label %bb63
bb63:
  store %olang.scope zeroinitializer, ptr %s15
  %t234 = load i64, ptr %l31, !tbaa !24
  store i64 %t234, ptr %l174, !tbaa !24
  %t235 = load ptr, ptr %l30, !tbaa !29
  %t237 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eLen_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %t235)
  store i64 %t237, ptr %l176
  br label %bb64
bb64:
  %t238 = load i64, ptr %l174, !tbaa !24
  %t239 = load i64, ptr %l176, !tbaa !24
  %t240 = icmp slt i64 %t238, %t239
  %t242 = xor i1 %t240, true
  br i1 %t242, label %bb65, label %bb66
bb65:
  call void @__olang_scope_close(ptr %s15)
  br label %bb72
bb66:
  br label %bb67
bb67:
  %t244 = load ptr, ptr %l30, !tbaa !29
  %t245 = load i64, ptr %l31, !tbaa !24
  %t248 = call %"compiler/profile:node" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eAt_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s0, ptr %t244, i64 %t245)
  store %"compiler/profile:node" %t248, ptr %l181
  br label %bb68
bb68:
  %t250 = call %"compiler/profile:node" @olang_2eHelperKind_2eCopy_2ecompiler_2fprofile_3anode(ptr %s15, ptr %l181)
  store %"compiler/profile:node" %t250, ptr %l183
  br label %bb69
bb69:
  %t251 = load %"compiler/profile:node", ptr %l183
  store %"compiler/profile:node" %t251, ptr %l32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l29, i64 0)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s15)
  br label %bb71
bb71:
  %t253 = load i64, ptr %l31, !tbaa !24
  %t255 = add i64 %t253, 1
  store i64 %t255, ptr %l31, !tbaa !24
  br label %bb63
bb72:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb73
bb73:
  store %olang.scope zeroinitializer, ptr %s18
  %t257 = load i64, ptr %l33, !tbaa !24
  store i64 %t257, ptr %l187, !tbaa !24
  %t259 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l28)
  store i64 %t259, ptr %l189
  br label %bb74
bb74:
  %t260 = load i64, ptr %l187, !tbaa !24
  %t261 = load i64, ptr %l189, !tbaa !24
  %t262 = icmp slt i64 %t260, %t261
  %t264 = xor i1 %t262, true
  br i1 %t264, label %bb75, label %bb76
bb75:
  call void @__olang_scope_close(ptr %s18)
  br label %bb96
bb76:
  br label %bb77
bb77:
  %t266 = load i64, ptr %l33, !tbaa !24
  %t269 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l28, i64 %t266)
  store i64 %t269, ptr %l194
  br label %bb78
bb78:
  %t270 = load i64, ptr %l194, !tbaa !24
  store i64 %t270, ptr %l34, !tbaa !24
  %t271 = load i64, ptr %l34, !tbaa !24
  %t274 = call %"compiler/profile:node" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eAt_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s0, ptr %l3, i64 %t271)
  store %"compiler/profile:node" %t274, ptr %l197
  br label %bb79
bb79:
  %t276 = call %"compiler/profile:node" @olang_2eHelperKind_2eCopy_2ecompiler_2fprofile_3anode(ptr %s0, ptr %l197)
  store %"compiler/profile:node" %t276, ptr %l199
  br label %bb80
bb80:
  %t277 = getelementptr %"compiler/profile:node", ptr %l199, i32 0, i32 3
  %t278 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t277
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t278, ptr %l200
  %t280 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s18, ptr %l200)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t280, ptr %l202
  br label %bb81
bb81:
  %t281 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l202
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t281, ptr %l35
  %t282 = load ptr, ptr %l2, !tbaa !29
  %t283 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t284 = getelementptr { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr }, ptr null, i32 1
  %t285 = ptrtoint ptr %t284 to i64
  %t287 = getelementptr { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr }, ptr %t286, i32 0, i32 0
  store ptr %t282, ptr %t287, !tbaa !28
  %t289 = getelementptr { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr }, ptr %t286, i32 0, i32 1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t283, ptr %t289, !tbaa !28
  call void @__olang_scope_escape(ptr %v2)
  %t291 = getelementptr { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr }, ptr %t286, i32 0, i32 2
  store ptr %v2, ptr %t291, !tbaa !28
  call void @__olang_scope_escape(ptr %s0)
  %t292 = getelementptr { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr }, ptr %t286, i32 0, i32 3
  store ptr %s0, ptr %t292, !tbaa !28
  %t293 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_0, 0
  %t294 = insertvalue { ptr, ptr } %t293, ptr %t286, 1
  %t297 = extractvalue { ptr, ptr } %t294, 0
  %t298 = extractvalue { ptr, ptr } %t294, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %s18, ptr %s18, ptr %l35, ptr %t297, ptr %t298)
  br label %bb82
bb82:
  %t299 = load i64, ptr %l34, !tbaa !24
  %t302 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l29, i64 %t299)
  store i64 %t302, ptr %l209
  br label %bb83
bb83:
  %t303 = load i64, ptr %l209, !tbaa !24
  store i64 %t303, ptr %l36, !tbaa !24
  store ptr %l35, ptr %l37, !tbaa !29
  store i64 0, ptr %l38, !tbaa !24
  br label %bb84
bb84:
  store %olang.scope zeroinitializer, ptr %s20
  %t305 = load i64, ptr %l38, !tbaa !24
  store i64 %t305, ptr %l211, !tbaa !24
  %t306 = load ptr, ptr %l37, !tbaa !29
  %t308 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s18, ptr %t306)
  store i64 %t308, ptr %l213
  br label %bb85
bb85:
  %t309 = load i64, ptr %l211, !tbaa !24
  %t310 = load i64, ptr %l213, !tbaa !24
  %t311 = icmp slt i64 %t309, %t310
  %t313 = xor i1 %t311, true
  br i1 %t313, label %bb86, label %bb87
bb86:
  call void @__olang_scope_close(ptr %s20)
  br label %bb94
bb87:
  br label %bb88
bb88:
  %t315 = load ptr, ptr %l37, !tbaa !29
  %t316 = load i64, ptr %l38, !tbaa !24
  %t319 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s18, ptr %t315, i64 %t316)
  store i64 %t319, ptr %l218
  br label %bb89
bb89:
  %t320 = load i64, ptr %l218, !tbaa !24
  store i64 %t320, ptr %l39, !tbaa !24
  %t321 = load i64, ptr %l39, !tbaa !24
  %t322 = load i64, ptr %l36, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %s0, ptr %l29, i64 %t321, i64 %t322)
  br label %bb90
bb90:
  %t326 = load i64, ptr %l36, !tbaa !24
  store i64 %t326, ptr %l222, !tbaa !24
  %t327 = load i64, ptr %l39, !tbaa !24
  %t330 = call %"compiler/profile:node" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eAt_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s20, ptr %l3, i64 %t327)
  store %"compiler/profile:node" %t330, ptr %l225
  br label %bb91
bb91:
  %t331 = getelementptr %"compiler/profile:node", ptr %l225, i32 0, i32 2
  %t332 = load i64, ptr %t331, !tbaa !24
  %t333 = load i64, ptr %l222, !tbaa !24
  %t335 = add i64 %t333, %t332
  store i64 %t335, ptr %l36, !tbaa !24
  %t337 = load i64, ptr %l39, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l28, i64 %t337)
  br label %bb92
bb92:
  call void @__olang_scope_close(ptr %s20)
  br label %bb93
bb93:
  %t340 = load i64, ptr %l38, !tbaa !24
  %t342 = add i64 %t340, 1
  store i64 %t342, ptr %l38, !tbaa !24
  br label %bb84
bb94:
  call void @__olang_scope_close(ptr %s18)
  br label %bb95
bb95:
  %t344 = load i64, ptr %l33, !tbaa !24
  %t346 = add i64 %t344, 1
  store i64 %t346, ptr %l33, !tbaa !24
  br label %bb73
bb96:
  store ptr %l28, ptr %l40, !tbaa !29
  store i64 0, ptr %l41, !tbaa !24
  br label %bb97
bb97:
  store %olang.scope zeroinitializer, ptr %s24
  %t349 = load i64, ptr %l41, !tbaa !24
  store i64 %t349, ptr %l235, !tbaa !24
  %t350 = load ptr, ptr %l40, !tbaa !29
  %t352 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t350)
  store i64 %t352, ptr %l237
  br label %bb98
bb98:
  %t353 = load i64, ptr %l235, !tbaa !24
  %t354 = load i64, ptr %l237, !tbaa !24
  %t355 = icmp slt i64 %t353, %t354
  %t357 = xor i1 %t355, true
  br i1 %t357, label %bb99, label %bb100
bb99:
  call void @__olang_scope_close(ptr %s24)
  br label %bb116
bb100:
  br label %bb101
bb101:
  %t359 = load ptr, ptr %l40, !tbaa !29
  %t360 = load i64, ptr %l41, !tbaa !24
  %t363 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t359, i64 %t360)
  store i64 %t363, ptr %l242
  br label %bb102
bb102:
  %t364 = load i64, ptr %l242, !tbaa !24
  store i64 %t364, ptr %l42, !tbaa !24
  %t365 = load i64, ptr %l42, !tbaa !24
  %t368 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eRef_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s0, ptr %l3, i64 %t365)
  store ptr %t368, ptr %l245
  br label %bb103
bb103:
  %t369 = load ptr, ptr %l245, !tbaa !29
  store ptr %t369, ptr %l43, !tbaa !29
  %t370 = load i64, ptr %l42, !tbaa !24
  %t372 = icmp eq i64 %t370, 0
  br i1 %t372, label %bb104, label %bb105
bb104:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l248, !tbaa !27
  br label %bb107
bb105:
  %t374 = load ptr, ptr %l2, !tbaa !29
  %t376 = getelementptr %"compiler/profile:Places", ptr %t374, i32 0, i32 0
  %t377 = load ptr, ptr %l43, !tbaa !29
  %t379 = getelementptr %"compiler/profile:node", ptr %t377, i32 0, i32 0
  %t380 = load i64, ptr %t379, !tbaa !24
  %t383 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %s24, ptr %t376, i64 %t380)
  store { i64, ptr } %t383, ptr %l253
  br label %bb106
bb106:
  %t384 = load { i64, ptr }, ptr %l253, !tbaa !27
  store { i64, ptr } %t384, ptr %l248, !tbaa !27
  br label %bb107
bb107:
  %t385 = load { i64, ptr }, ptr %l248, !tbaa !27
  store { i64, ptr } %t385, ptr %l44, !tbaa !27
  %t386 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t386, ptr %l254, !tbaa !27
  %t387 = load ptr, ptr %l43, !tbaa !29
  %t389 = getelementptr %"compiler/profile:node", ptr %t387, i32 0, i32 2
  %t390 = load i64, ptr %t389, !tbaa !24
  %t391 = load ptr, ptr %l1, !tbaa !29
  %t393 = getelementptr %"compiler/profile:Profile", ptr %t391, i32 0, i32 0
  %t394 = load i64, ptr %t393, !tbaa !24
  %t397 = call { i64, ptr } @compiler_2fprofile_2emillis(ptr %s24, i64 %t390, i64 %t394)
  store { i64, ptr } %t397, ptr %l259
  br label %bb108
bb108:
  %t398 = load ptr, ptr %l43, !tbaa !29
  %t400 = getelementptr %"compiler/profile:node", ptr %t398, i32 0, i32 2
  %t401 = load i64, ptr %t400, !tbaa !24
  %t402 = load i64, ptr %l25, !tbaa !24
  %t405 = call { i64, ptr } @compiler_2fprofile_2epct(ptr %s24, i64 %t401, i64 %t402)
  store { i64, ptr } %t405, ptr %l263
  br label %bb109
bb109:
  %t406 = load { i64, ptr }, ptr %l254, !tbaa !27
  %t407 = extractvalue { i64, ptr } %t406, 1
  %t408 = extractvalue { i64, ptr } %t406, 0
  %t409 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t410 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t411 = add i64 %t408, %t410
  %t412 = load { i64, ptr }, ptr %l259, !tbaa !27
  %t413 = extractvalue { i64, ptr } %t412, 1
  %t414 = extractvalue { i64, ptr } %t412, 0
  %t415 = add i64 %t411, %t414
  %t416 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t417 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t418 = add i64 %t415, %t417
  %t419 = load { i64, ptr }, ptr %l263, !tbaa !27
  %t420 = extractvalue { i64, ptr } %t419, 1
  %t421 = extractvalue { i64, ptr } %t419, 0
  %t422 = add i64 %t418, %t421
  %t423 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t422)
  call void @olang_textcopy(ptr %t423, ptr %t407, i64 %t408)
  %t424 = getelementptr i8, ptr %t423, i64 %t408
  call void @olang_textcopy(ptr %t424, ptr %t409, i64 %t410)
  %t425 = getelementptr i8, ptr %t424, i64 %t410
  call void @olang_textcopy(ptr %t425, ptr %t413, i64 %t414)
  %t426 = getelementptr i8, ptr %t425, i64 %t414
  call void @olang_textcopy(ptr %t426, ptr %t416, i64 %t417)
  %t427 = getelementptr i8, ptr %t426, i64 %t417
  call void @olang_textcopy(ptr %t427, ptr %t420, i64 %t421)
  %t428 = insertvalue { i64, ptr } undef, i64 %t422, 0
  %t429 = insertvalue { i64, ptr } %t428, ptr %t423, 1
  store { i64, ptr } %t429, ptr %l45, !tbaa !27
  %t431 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t433 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eHash(ptr %s24, { i64, ptr } %t431)
  store i64 %t433, ptr %l266
  br label %bb110
bb110:
  %t434 = load i64, ptr %l266, !tbaa !24
  %t435 = and i64 %t434, 65535
  store i64 %t435, ptr %l46, !tbaa !24
  %t437 = load i64, ptr %l46, !tbaa !24
  %t439 = srem i64 %t437, 50
  %t441 = add i64 205, %t439
  store i64 %t441, ptr %l47, !tbaa !24
  %t443 = load i64, ptr %l46, !tbaa !24
  %t445 = sdiv i64 %t443, 50
  %t447 = srem i64 %t445, 140
  %t449 = add i64 90, %t447
  store i64 %t449, ptr %l48, !tbaa !24
  %t451 = load i64, ptr %l46, !tbaa !24
  %t453 = sdiv i64 %t451, 7000
  %t455 = srem i64 %t453, 55
  store i64 %t455, ptr %l49, !tbaa !24
  %t457 = load i64, ptr %l26, !tbaa !24
  %t459 = sub i64 %t457, 20
  %t460 = load ptr, ptr %l43, !tbaa !29
  %t462 = getelementptr %"compiler/profile:node", ptr %t460, i32 0, i32 1
  %t463 = load i64, ptr %t462, !tbaa !24
  %t465 = add i64 %t463, 1
  %t466 = load i64, ptr @G_2ecompiler_2fprofile_2eFrameHeight, !tbaa !24
  %t469 = mul i64 %t465, %t466
  %t472 = sub i64 %t459, %t469
  store i64 %t472, ptr %l50, !tbaa !24
  store ptr %l27, ptr %l286, !tbaa !29
  %t474 = load i64, ptr %l42, !tbaa !24
  %t477 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l29, i64 %t474)
  store i64 %t477, ptr %l289
  br label %bb111
bb111:
  %t478 = load ptr, ptr %l43, !tbaa !29
  %t480 = getelementptr %"compiler/profile:node", ptr %t478, i32 0, i32 2
  %t481 = load i64, ptr %t480, !tbaa !24
  store i64 %t481, ptr %l291, !tbaa !24
  %t482 = load ptr, ptr %l43, !tbaa !29
  %t484 = getelementptr %"compiler/profile:node", ptr %t482, i32 0, i32 1
  %t485 = load i64, ptr %t484, !tbaa !24
  store i64 %t485, ptr %l293, !tbaa !24
  %t486 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t488 = call { i64, ptr } @compiler_2fprofile_2eescapeXml(ptr %s24, ptr %s24, { i64, ptr } %t486)
  store { i64, ptr } %t488, ptr %l295
  br label %bb112
bb112:
  %t489 = load i64, ptr %l50, !tbaa !24
  store i64 %t489, ptr %l296, !tbaa !24
  %t490 = load i64, ptr @G_2ecompiler_2fprofile_2eFrameHeight, !tbaa !24
  %t492 = sub i64 %t490, 1
  store i64 %t492, ptr %l298, !tbaa !24
  %t493 = load i64, ptr %l47, !tbaa !24
  store i64 %t493, ptr %l299, !tbaa !24
  %t494 = load i64, ptr %l48, !tbaa !24
  store i64 %t494, ptr %l300, !tbaa !24
  %t495 = load i64, ptr %l49, !tbaa !24
  store i64 %t495, ptr %l301, !tbaa !24
  %t496 = load i64, ptr %l50, !tbaa !24
  %t498 = add i64 %t496, 13
  %t500 = call i64 @__olang_fmt_i64(ptr null, i64 %t498)
  %t501 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t500)
  %t502 = call i64 @__olang_fmt_i64(ptr %t501, i64 %t498)
  %t503 = insertvalue { i64, ptr } undef, i64 %t500, 0
  %t504 = insertvalue { i64, ptr } %t503, ptr %t501, 1
  store { i64, ptr } %t504, ptr %l304, !tbaa !27
  %t505 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t507 = call { i64, ptr } @compiler_2fprofile_2eescapeXml(ptr %s24, ptr %s24, { i64, ptr } %t505)
  store { i64, ptr } %t507, ptr %l306
  br label %bb113
bb113:
  %t508 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t509 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t510 = load i64, ptr %l289, !tbaa !24
  %t511 = call i64 @__olang_fmt_i64(ptr null, i64 %t510)
  %t512 = add i64 %t509, %t511
  %t513 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t514 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t515 = add i64 %t512, %t514
  %t516 = load i64, ptr %l291, !tbaa !24
  %t517 = call i64 @__olang_fmt_i64(ptr null, i64 %t516)
  %t518 = add i64 %t515, %t517
  %t519 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t520 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t521 = add i64 %t518, %t520
  %t522 = load i64, ptr %l293, !tbaa !24
  %t523 = call i64 @__olang_fmt_i64(ptr null, i64 %t522)
  %t524 = add i64 %t521, %t523
  %t525 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t526 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t527 = add i64 %t524, %t526
  %t528 = load { i64, ptr }, ptr %l295, !tbaa !27
  %t529 = extractvalue { i64, ptr } %t528, 1
  %t530 = extractvalue { i64, ptr } %t528, 0
  %t531 = add i64 %t527, %t530
  %t532 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t533 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t534 = add i64 %t531, %t533
  %t535 = load i64, ptr %l296, !tbaa !24
  %t536 = call i64 @__olang_fmt_i64(ptr null, i64 %t535)
  %t537 = add i64 %t534, %t536
  %t538 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t539 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t540 = add i64 %t537, %t539
  %t541 = load i64, ptr %l298, !tbaa !24
  %t542 = call i64 @__olang_fmt_i64(ptr null, i64 %t541)
  %t543 = add i64 %t540, %t542
  %t544 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t545 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t546 = add i64 %t543, %t545
  %t547 = load i64, ptr %l299, !tbaa !24
  %t548 = call i64 @__olang_fmt_i64(ptr null, i64 %t547)
  %t549 = add i64 %t546, %t548
  %t550 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t551 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t552 = add i64 %t549, %t551
  %t553 = load i64, ptr %l300, !tbaa !24
  %t554 = call i64 @__olang_fmt_i64(ptr null, i64 %t553)
  %t555 = add i64 %t552, %t554
  %t556 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t557 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t558 = add i64 %t555, %t557
  %t559 = load i64, ptr %l301, !tbaa !24
  %t560 = call i64 @__olang_fmt_i64(ptr null, i64 %t559)
  %t561 = add i64 %t558, %t560
  %t562 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t563 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t564 = add i64 %t561, %t563
  %t565 = load { i64, ptr }, ptr %l304, !tbaa !27
  %t566 = extractvalue { i64, ptr } %t565, 1
  %t567 = extractvalue { i64, ptr } %t565, 0
  %t568 = add i64 %t564, %t567
  %t569 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t570 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t571 = add i64 %t568, %t570
  %t572 = load { i64, ptr }, ptr %l306, !tbaa !27
  %t573 = extractvalue { i64, ptr } %t572, 1
  %t574 = extractvalue { i64, ptr } %t572, 0
  %t575 = add i64 %t571, %t574
  %t576 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t577 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t578 = add i64 %t575, %t577
  %t579 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t578)
  call void @olang_textcopy(ptr %t579, ptr %t508, i64 %t509)
  %t580 = getelementptr i8, ptr %t579, i64 %t509
  %t581 = call i64 @__olang_fmt_i64(ptr %t580, i64 %t510)
  %t582 = getelementptr i8, ptr %t580, i64 %t511
  call void @olang_textcopy(ptr %t582, ptr %t513, i64 %t514)
  %t583 = getelementptr i8, ptr %t582, i64 %t514
  %t584 = call i64 @__olang_fmt_i64(ptr %t583, i64 %t516)
  %t585 = getelementptr i8, ptr %t583, i64 %t517
  call void @olang_textcopy(ptr %t585, ptr %t519, i64 %t520)
  %t586 = getelementptr i8, ptr %t585, i64 %t520
  %t587 = call i64 @__olang_fmt_i64(ptr %t586, i64 %t522)
  %t588 = getelementptr i8, ptr %t586, i64 %t523
  call void @olang_textcopy(ptr %t588, ptr %t525, i64 %t526)
  %t589 = getelementptr i8, ptr %t588, i64 %t526
  call void @olang_textcopy(ptr %t589, ptr %t529, i64 %t530)
  %t590 = getelementptr i8, ptr %t589, i64 %t530
  call void @olang_textcopy(ptr %t590, ptr %t532, i64 %t533)
  %t591 = getelementptr i8, ptr %t590, i64 %t533
  %t592 = call i64 @__olang_fmt_i64(ptr %t591, i64 %t535)
  %t593 = getelementptr i8, ptr %t591, i64 %t536
  call void @olang_textcopy(ptr %t593, ptr %t538, i64 %t539)
  %t594 = getelementptr i8, ptr %t593, i64 %t539
  %t595 = call i64 @__olang_fmt_i64(ptr %t594, i64 %t541)
  %t596 = getelementptr i8, ptr %t594, i64 %t542
  call void @olang_textcopy(ptr %t596, ptr %t544, i64 %t545)
  %t597 = getelementptr i8, ptr %t596, i64 %t545
  %t598 = call i64 @__olang_fmt_i64(ptr %t597, i64 %t547)
  %t599 = getelementptr i8, ptr %t597, i64 %t548
  call void @olang_textcopy(ptr %t599, ptr %t550, i64 %t551)
  %t600 = getelementptr i8, ptr %t599, i64 %t551
  %t601 = call i64 @__olang_fmt_i64(ptr %t600, i64 %t553)
  %t602 = getelementptr i8, ptr %t600, i64 %t554
  call void @olang_textcopy(ptr %t602, ptr %t556, i64 %t557)
  %t603 = getelementptr i8, ptr %t602, i64 %t557
  %t604 = call i64 @__olang_fmt_i64(ptr %t603, i64 %t559)
  %t605 = getelementptr i8, ptr %t603, i64 %t560
  call void @olang_textcopy(ptr %t605, ptr %t562, i64 %t563)
  %t606 = getelementptr i8, ptr %t605, i64 %t563
  call void @olang_textcopy(ptr %t606, ptr %t566, i64 %t567)
  %t607 = getelementptr i8, ptr %t606, i64 %t567
  call void @olang_textcopy(ptr %t607, ptr %t569, i64 %t570)
  %t608 = getelementptr i8, ptr %t607, i64 %t570
  call void @olang_textcopy(ptr %t608, ptr %t573, i64 %t574)
  %t609 = getelementptr i8, ptr %t608, i64 %t574
  call void @olang_textcopy(ptr %t609, ptr %t576, i64 %t577)
  %t610 = insertvalue { i64, ptr } undef, i64 %t578, 0
  %t611 = insertvalue { i64, ptr } %t610, ptr %t579, 1
  %t613 = extractvalue { i64, ptr } %t611, 0
  %t614 = extractvalue { i64, ptr } %t611, 1
  %t615 = mul i64 %t613, 1
  %t616 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t615)
  call void @llvm.memcpy.p0.p0.i64(ptr %t616, ptr %t614, i64 %t615, i1 false)
  %t617 = insertvalue { i64, ptr } undef, i64 %t613, 0
  %t618 = insertvalue { i64, ptr } %t617, ptr %t616, 1
  %t619 = load ptr, ptr %l286, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s24, ptr %t619, { i64, ptr } %t618)
  br label %bb114
bb114:
  call void @__olang_scope_close(ptr %s24)
  br label %bb115
bb115:
  %t621 = load i64, ptr %l41, !tbaa !24
  %t623 = add i64 %t621, 1
  store i64 %t623, ptr %l41, !tbaa !24
  br label %bb97
bb116:
  %t625 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t625, ptr %l311
  br label %bb117
bb117:
  %t626 = load %"std/prelude/text:StringBuilder", ptr %l311
  store %"std/prelude/text:StringBuilder" %t626, ptr %l51
  store ptr %l51, ptr %l312, !tbaa !29
  %t627 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t629 = call { i64, ptr } @compiler_2fprofile_2eescapeXml(ptr %v0, ptr %s0, { i64, ptr } %t627)
  store { i64, ptr } %t629, ptr %l314
  br label %bb118
bb118:
  %t630 = extractvalue { i64, ptr } { i64 57, ptr getelementptr inbounds (<{ i64, [57 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t631 = extractvalue { i64, ptr } { i64 57, ptr getelementptr inbounds (<{ i64, [57 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t632 = load { i64, ptr }, ptr %l314, !tbaa !27
  %t633 = extractvalue { i64, ptr } %t632, 1
  %t634 = extractvalue { i64, ptr } %t632, 0
  %t635 = add i64 %t631, %t634
  %t636 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t637 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t638 = add i64 %t635, %t637
  %t639 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t638)
  call void @olang_textcopy(ptr %t639, ptr %t630, i64 %t631)
  %t640 = getelementptr i8, ptr %t639, i64 %t631
  call void @olang_textcopy(ptr %t640, ptr %t633, i64 %t634)
  %t641 = getelementptr i8, ptr %t640, i64 %t634
  call void @olang_textcopy(ptr %t641, ptr %t636, i64 %t637)
  %t642 = insertvalue { i64, ptr } undef, i64 %t638, 0
  %t643 = insertvalue { i64, ptr } %t642, ptr %t639, 1
  %t645 = extractvalue { i64, ptr } %t643, 0
  %t646 = extractvalue { i64, ptr } %t643, 1
  %t647 = mul i64 %t645, 1
  %t648 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t647)
  call void @llvm.memcpy.p0.p0.i64(ptr %t648, ptr %t646, i64 %t647, i1 false)
  %t649 = insertvalue { i64, ptr } undef, i64 %t645, 0
  %t650 = insertvalue { i64, ptr } %t649, ptr %t648, 1
  %t651 = load ptr, ptr %l312, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t651, { i64, ptr } %t650)
  br label %bb119
bb119:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l51, { i64, ptr } { i64 213, ptr getelementptr inbounds (<{ i64, [213 x i8] }>, ptr @.d17, i32 0, i32 1) })
  br label %bb120
bb120:
  %t654 = load ptr, ptr %l1, !tbaa !29
  %t656 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aProfile_2eTotal(ptr %v1, ptr %t654)
  store i64 %t656, ptr %l319
  br label %bb121
bb121:
  %t657 = load i64, ptr %l319, !tbaa !24
  %t658 = sitofp i64 %t657 to double
  %t659 = load ptr, ptr %l1, !tbaa !29
  %t661 = getelementptr %"compiler/profile:Profile", ptr %t659, i32 0, i32 0
  %t662 = load i64, ptr %t661, !tbaa !24
  %t664 = sitofp i64 %t662 to double
  %t667 = fmul double %t658, %t664
  %t669 = fdiv double %t667, 0x41cdcd6500000000
  store double %t669, ptr %l52, !tbaa !26
  store ptr %l51, ptr %l326, !tbaa !29
  %t671 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t673 = call { i64, ptr } @compiler_2fprofile_2eescapeXml(ptr %v0, ptr %s0, { i64, ptr } %t671)
  store { i64, ptr } %t673, ptr %l328
  br label %bb122
bb122:
  %t674 = load ptr, ptr %l1, !tbaa !29
  %t676 = getelementptr %"compiler/profile:Profile", ptr %t674, i32 0, i32 3
  %t678 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2eLen_3ccompiler_2fprofile_3aSample_3e(ptr %v1, ptr %t676)
  store i64 %t678, ptr %l331
  br label %bb123
bb123:
  %t679 = load double, ptr %l52, !tbaa !26
  %t681 = call { i64, ptr } @std_2fprelude_2ffloat_2eF64_2eFixed(ptr %s0, double %t679, i64 3)
  store { i64, ptr } %t681, ptr %l333
  br label %bb124
bb124:
  %t682 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t683 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t684 = load { i64, ptr }, ptr %l328, !tbaa !27
  %t685 = extractvalue { i64, ptr } %t684, 1
  %t686 = extractvalue { i64, ptr } %t684, 0
  %t687 = add i64 %t683, %t686
  %t688 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t689 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t690 = add i64 %t687, %t689
  %t691 = load i64, ptr %l331, !tbaa !24
  %t692 = call i64 @__olang_fmt_i64(ptr null, i64 %t691)
  %t693 = add i64 %t690, %t692
  %t694 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t695 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t696 = add i64 %t693, %t695
  %t697 = load { i64, ptr }, ptr %l333, !tbaa !27
  %t698 = extractvalue { i64, ptr } %t697, 1
  %t699 = extractvalue { i64, ptr } %t697, 0
  %t700 = add i64 %t696, %t699
  %t701 = extractvalue { i64, ptr } { i64 78, ptr getelementptr inbounds (<{ i64, [78 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t702 = extractvalue { i64, ptr } { i64 78, ptr getelementptr inbounds (<{ i64, [78 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t703 = add i64 %t700, %t702
  %t704 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t703)
  call void @olang_textcopy(ptr %t704, ptr %t682, i64 %t683)
  %t705 = getelementptr i8, ptr %t704, i64 %t683
  call void @olang_textcopy(ptr %t705, ptr %t685, i64 %t686)
  %t706 = getelementptr i8, ptr %t705, i64 %t686
  call void @olang_textcopy(ptr %t706, ptr %t688, i64 %t689)
  %t707 = getelementptr i8, ptr %t706, i64 %t689
  %t708 = call i64 @__olang_fmt_i64(ptr %t707, i64 %t691)
  %t709 = getelementptr i8, ptr %t707, i64 %t692
  call void @olang_textcopy(ptr %t709, ptr %t694, i64 %t695)
  %t710 = getelementptr i8, ptr %t709, i64 %t695
  call void @olang_textcopy(ptr %t710, ptr %t698, i64 %t699)
  %t711 = getelementptr i8, ptr %t710, i64 %t699
  call void @olang_textcopy(ptr %t711, ptr %t701, i64 %t702)
  %t712 = insertvalue { i64, ptr } undef, i64 %t703, 0
  %t713 = insertvalue { i64, ptr } %t712, ptr %t704, 1
  %t715 = extractvalue { i64, ptr } %t713, 0
  %t716 = extractvalue { i64, ptr } %t713, 1
  %t717 = mul i64 %t715, 1
  %t718 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t717)
  call void @llvm.memcpy.p0.p0.i64(ptr %t718, ptr %t716, i64 %t717, i1 false)
  %t719 = insertvalue { i64, ptr } undef, i64 %t715, 0
  %t720 = insertvalue { i64, ptr } %t719, ptr %t718, 1
  %t721 = load ptr, ptr %l326, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t721, { i64, ptr } %t720)
  br label %bb125
bb125:
  store ptr %l51, ptr %l336, !tbaa !29
  %t723 = load i64, ptr @G_2ecompiler_2fprofile_2eFlameWidth, !tbaa !24
  store i64 %t723, ptr %l337, !tbaa !24
  %t724 = load i64, ptr %l26, !tbaa !24
  store i64 %t724, ptr %l338, !tbaa !24
  %t725 = load i64, ptr %l25, !tbaa !24
  store i64 %t725, ptr %l339, !tbaa !24
  %t727 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l27)
  store { i64, ptr } %t727, ptr %l341
  br label %bb126
bb126:
  %t728 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t729 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t730 = load i64, ptr %l337, !tbaa !24
  %t731 = call i64 @__olang_fmt_i64(ptr null, i64 %t730)
  %t732 = add i64 %t729, %t731
  %t733 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t734 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t735 = add i64 %t732, %t734
  %t736 = load i64, ptr %l338, !tbaa !24
  %t737 = call i64 @__olang_fmt_i64(ptr null, i64 %t736)
  %t738 = add i64 %t735, %t737
  %t739 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t740 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t741 = add i64 %t738, %t740
  %t742 = load i64, ptr %l339, !tbaa !24
  %t743 = call i64 @__olang_fmt_i64(ptr null, i64 %t742)
  %t744 = add i64 %t741, %t743
  %t745 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t746 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t747 = add i64 %t744, %t746
  %t748 = load { i64, ptr }, ptr %l341, !tbaa !27
  %t749 = extractvalue { i64, ptr } %t748, 1
  %t750 = extractvalue { i64, ptr } %t748, 0
  %t751 = add i64 %t747, %t750
  %t752 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t753 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t754 = add i64 %t751, %t753
  %t755 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t754)
  call void @olang_textcopy(ptr %t755, ptr %t728, i64 %t729)
  %t756 = getelementptr i8, ptr %t755, i64 %t729
  %t757 = call i64 @__olang_fmt_i64(ptr %t756, i64 %t730)
  %t758 = getelementptr i8, ptr %t756, i64 %t731
  call void @olang_textcopy(ptr %t758, ptr %t733, i64 %t734)
  %t759 = getelementptr i8, ptr %t758, i64 %t734
  %t760 = call i64 @__olang_fmt_i64(ptr %t759, i64 %t736)
  %t761 = getelementptr i8, ptr %t759, i64 %t737
  call void @olang_textcopy(ptr %t761, ptr %t739, i64 %t740)
  %t762 = getelementptr i8, ptr %t761, i64 %t740
  %t763 = call i64 @__olang_fmt_i64(ptr %t762, i64 %t742)
  %t764 = getelementptr i8, ptr %t762, i64 %t743
  call void @olang_textcopy(ptr %t764, ptr %t745, i64 %t746)
  %t765 = getelementptr i8, ptr %t764, i64 %t746
  call void @olang_textcopy(ptr %t765, ptr %t749, i64 %t750)
  %t766 = getelementptr i8, ptr %t765, i64 %t750
  call void @olang_textcopy(ptr %t766, ptr %t752, i64 %t753)
  %t767 = insertvalue { i64, ptr } undef, i64 %t754, 0
  %t768 = insertvalue { i64, ptr } %t767, ptr %t755, 1
  %t770 = extractvalue { i64, ptr } %t768, 0
  %t771 = extractvalue { i64, ptr } %t768, 1
  %t772 = mul i64 %t770, 1
  %t773 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t772)
  call void @llvm.memcpy.p0.p0.i64(ptr %t773, ptr %t771, i64 %t772, i1 false)
  %t774 = insertvalue { i64, ptr } undef, i64 %t770, 0
  %t775 = insertvalue { i64, ptr } %t774, ptr %t773, 1
  %t776 = load ptr, ptr %l336, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t776, { i64, ptr } %t775)
  br label %bb127
bb127:
  %t778 = load { i64, ptr }, ptr @G_2ecompiler_2fprofile_2eFlameScript, !tbaa !27
  %t779 = load ptr, ptr @__olang_prog_scope
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %t779, ptr %l51, { i64, ptr } %t778)
  br label %bb128
bb128:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l51, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d27, i32 0, i32 1) })
  br label %bb129
bb129:
  %t784 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v3, ptr %l51)
  store { i64, ptr } %t784, ptr %l348
  br label %bb130
bb130:
  %t785 = load { i64, ptr }, ptr %l348, !tbaa !27
  store { i64, ptr } %t785, ptr %l349, !tbaa !27
  %t786 = load { i64, ptr }, ptr %l349, !tbaa !27
  %t787 = extractvalue { i64, ptr } %t786, 0
  store i64 %t787, ptr %l350, !tbaa !24
  %t788 = load i64, ptr %l350, !tbaa !24
  %t789 = mul i64 %t788, 1
  %t790 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t789)
  %t791 = insertvalue { i64, ptr } undef, i64 %t788, 0
  %t792 = insertvalue { i64, ptr } %t791, ptr %t790, 1
  store { i64, ptr } %t792, ptr %l351, !tbaa !27
  %t793 = getelementptr { i64, ptr }, ptr %l351, i32 0, i32 1
  %t794 = load ptr, ptr %t793, !tbaa !27
  %t795 = getelementptr { i64, ptr }, ptr %l349, i32 0, i32 1
  %t796 = load ptr, ptr %t795, !tbaa !27
  %t797 = load i64, ptr %l350, !tbaa !24
  %t798 = mul i64 %t797, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t794, ptr %t796, i64 %t798, i1 false)
  %t799 = load { i64, ptr }, ptr %l351, !tbaa !27
  store { i64, ptr } %t799, ptr %l349, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t800 = load { i64, ptr }, ptr %l349, !tbaa !27
  store { i64, ptr } %t800, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, %"compiler/profile:Profile" } @compiler_2fprofile_2eRead(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %lp1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca %"compiler/profile:Profile"
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l23 = alloca [8 x i8]
  %l24 = alloca { i64, ptr }
  %l26 = alloca i1
  %l30 = alloca i64
  %l32 = alloca i64
  %l34 = alloca i64
  %l36 = alloca i64
  %l39 = alloca i1
  %l54 = alloca i64
  %l59 = alloca i1
  %l62 = alloca i1
  %l69 = alloca ptr
  %l71 = alloca i64
  %l73 = alloca i64
  %l75 = alloca %"compiler/profile:Sample"
  %l80 = alloca i64
  %l83 = alloca i64
  %l101 = alloca ptr
  %l108 = alloca i64
  %l115 = alloca { i64, ptr }
  %l118 = alloca i64
  %l121 = alloca i64
  %l122 = alloca i64
  %l127 = alloca { i64, ptr }
  %l128 = alloca i64
  %l129 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/profile:Profile" }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/profile:Profile" @compiler_2fprofile_3aProfile_2ector(ptr %v1)
  store %"compiler/profile:Profile" %t1, ptr %l12
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 104, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"compiler/profile:Profile", ptr %l12
  %t4 = load ptr, ptr %lp1
  store %"compiler/profile:Profile" %t3, ptr %t4
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t9 = icmp slt i64 %t7, 40
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb11
bb3:
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t11, ptr %l17, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  store i64 %t13, ptr %l18, !tbaa !24
  %t14 = icmp sge i64 0, 0
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t16 = icmp sle i64 0, 8
  br i1 %t16, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_c23c40ac9fceed99_19c8ab4fbd7fcba5)
  unreachable
bb6:
  %t18 = load i64, ptr %l18, !tbaa !24
  %t19 = icmp sle i64 8, %t18
  br i1 %t19, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_c23c40ac9fceed99_19c8ab4fbd7fcba5)
  unreachable
bb8:
  %t21 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr i8, ptr %t22, i64 0
  %t25 = load [8 x i8], ptr %t23
  store [8 x i8] %t25, ptr %l23
  %t26 = mul i64 8, 1
  %t27 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 8, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  store { i64, ptr } %t29, ptr %l24, !tbaa !27
  %t30 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = mul i64 8, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t31, ptr %l23, i64 %t32, i1 false)
  %t33 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  %t35 = extractvalue { i64, ptr } %t33, 1
  %t36 = mul i64 %t34, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t36)
  call void @llvm.memcpy.p0.p0.i64(ptr %t37, ptr %t35, i64 %t36, i1 false)
  %t38 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  %t41 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t39, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d28, i32 0, i32 1) })
  store i1 %t41, ptr %l26
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_c23c40ac9fceed99_19c8ab4fbd7fcba5)
  unreachable
bb10:
  %t42 = load i1, ptr %l26, !tbaa !21
  %t43 = xor i1 %t42, true
  store i1 %t43, ptr %l16, !tbaa !21
  br label %bb11
bb11:
  %t45 = load i1, ptr %l16, !tbaa !21
  br i1 %t45, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s0)
  %t47 = insertvalue { i32, %"compiler/profile:Profile" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/profile:Profile" } %t47, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t48 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t50 = call i64 @compiler_2fprofile_2eword(ptr %v0, { i64, ptr } %t48, i64 1)
  store i64 %t50, ptr %l30
  br label %bb15
bb15:
  %t51 = load i64, ptr %l30, !tbaa !24
  %t52 = load ptr, ptr %lp1
  %t53 = getelementptr %"compiler/profile:Profile", ptr %t52, i32 0, i32 0
  store i64 %t51, ptr %t53, !tbaa !24
  %t54 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t56 = call i64 @compiler_2fprofile_2eword(ptr %v0, { i64, ptr } %t54, i64 2)
  store i64 %t56, ptr %l32
  br label %bb16
bb16:
  %t57 = load i64, ptr %l32, !tbaa !24
  store i64 %t57, ptr %l2, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t60 = call i64 @compiler_2fprofile_2eword(ptr %v0, { i64, ptr } %t58, i64 3)
  store i64 %t60, ptr %l34
  br label %bb17
bb17:
  %t61 = load i64, ptr %l34, !tbaa !24
  %t62 = load ptr, ptr %lp1
  %t63 = getelementptr %"compiler/profile:Profile", ptr %t62, i32 0, i32 1
  store i64 %t61, ptr %t63, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t66 = call i64 @compiler_2fprofile_2eword(ptr %v0, { i64, ptr } %t64, i64 4)
  store i64 %t66, ptr %l36
  br label %bb18
bb18:
  %t67 = load i64, ptr %l36, !tbaa !24
  %t68 = load ptr, ptr %lp1
  %t69 = getelementptr %"compiler/profile:Profile", ptr %t68, i32 0, i32 2
  store i64 %t67, ptr %t69, !tbaa !24
  %t70 = load i64, ptr %l2, !tbaa !24
  %t72 = icmp slt i64 %t70, 0
  br i1 %t72, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb21
bb20:
  %t74 = load i64, ptr %l2, !tbaa !24
  %t76 = mul i64 %t74, 8
  %t78 = add i64 40, %t76
  %t79 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t84 = icmp sgt i64 %t78, %t81
  store i1 %t84, ptr %l39, !tbaa !21
  br label %bb21
bb21:
  %t86 = load i1, ptr %l39, !tbaa !21
  br i1 %t86, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t88 = insertvalue { i32, %"compiler/profile:Profile" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/profile:Profile" } %t88, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  store i64 0, ptr %l3, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s3
  %t89 = load i64, ptr %l3, !tbaa !24
  %t90 = load i64, ptr %l2, !tbaa !24
  %t93 = icmp slt i64 %t89, %t90
  %t95 = xor i1 %t93, true
  br i1 %t95, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s3)
  br label %bb57
bb27:
  br label %bb28
bb28:
  %t97 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t98 = load i64, ptr %l3, !tbaa !24
  %t100 = add i64 5, %t98
  %t103 = call i64 @compiler_2fprofile_2eword(ptr %v0, { i64, ptr } %t97, i64 %t100)
  store i64 %t103, ptr %l54
  br label %bb29
bb29:
  %t104 = load i64, ptr %l54, !tbaa !24
  store i64 %t104, ptr %l4, !tbaa !24
  %t105 = load i64, ptr %l4, !tbaa !24
  %t107 = and i64 %t105, 255
  store i64 %t107, ptr %l5, !tbaa !24
  %t109 = load i64, ptr %l4, !tbaa !24
  %t111 = icmp eq i64 %t109, 0
  br i1 %t111, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l59, !tbaa !21
  br label %bb32
bb31:
  %t113 = load i64, ptr %l5, !tbaa !24
  %t115 = icmp eq i64 %t113, 0
  store i1 %t115, ptr %l59, !tbaa !21
  br label %bb32
bb32:
  %t117 = load i1, ptr %l59, !tbaa !21
  br i1 %t117, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb35
bb34:
  %t118 = load i64, ptr %l3, !tbaa !24
  %t120 = add i64 %t118, 1
  %t121 = load i64, ptr %l5, !tbaa !24
  %t124 = add i64 %t120, %t121
  %t125 = load i64, ptr %l2, !tbaa !24
  %t128 = icmp sgt i64 %t124, %t125
  store i1 %t128, ptr %l62, !tbaa !21
  br label %bb35
bb35:
  %t130 = load i1, ptr %l62, !tbaa !21
  br i1 %t130, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s3)
  br label %bb57
bb37:
  br label %bb38
bb38:
  %t131 = load ptr, ptr %lp1
  %t132 = getelementptr %"compiler/profile:Profile", ptr %t131, i32 0, i32 3
  store ptr %t132, ptr %l69, !tbaa !29
  %t133 = load i64, ptr %l4, !tbaa !24
  %t135 = ashr i64 %t133, 8
  store i64 %t135, ptr %l71, !tbaa !24
  %t136 = load ptr, ptr %lp1
  %t137 = getelementptr %"compiler/profile:Profile", ptr %t136, i32 0, i32 4
  %t139 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t137)
  store i64 %t139, ptr %l73
  br label %bb39
bb39:
  %t140 = load i64, ptr %l5, !tbaa !24
  %t141 = load i64, ptr %l71, !tbaa !24
  %t142 = load i64, ptr %l73, !tbaa !24
  %t144 = call %"compiler/profile:Sample" @compiler_2fprofile_3aSample_2ector(ptr %s3, i64 %t141, i64 %t142, i64 %t140)
  store %"compiler/profile:Sample" %t144, ptr %l75
  br label %bb40
bb40:
  %t145 = load ptr, ptr %l69, !tbaa !29
  %t146 = load %"compiler/profile:Sample", ptr %l75
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2ePush_3ccompiler_2fprofile_3aSample_3e(ptr %v1, ptr %t145, %"compiler/profile:Sample" %t146)
  br label %bb41
bb41:
  store i64 0, ptr %l6, !tbaa !24
  %t147 = load i64, ptr %l5, !tbaa !24
  store i64 %t147, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t149 = load i64, ptr %l7, !tbaa !24
  %t150 = load i64, ptr %l6, !tbaa !24
  %t153 = icmp sgt i64 %t149, %t150
  br i1 %t153, label %bb42, label %bb43
bb42:
  %t155 = load i64, ptr %l8, !tbaa !24
  %t157 = icmp sgt i64 %t155, 0
  br i1 %t157, label %bb44, label %bb45
bb43:
  store i64 0, ptr %l80, !tbaa !24
  br label %bb47
bb44:
  %t159 = load i64, ptr %l7, !tbaa !24
  %t160 = load i64, ptr %l6, !tbaa !24
  %t163 = sub i64 %t159, %t160
  %t164 = load i64, ptr %l8, !tbaa !24
  %t167 = add i64 %t163, %t164
  %t169 = sub i64 %t167, 1
  %t170 = load i64, ptr %l8, !tbaa !24
  %t173 = sdiv i64 %t169, %t170
  store i64 %t173, ptr %l83, !tbaa !24
  br label %bb46
bb45:
  store i64 0, ptr %l83, !tbaa !24
  br label %bb46
bb46:
  %t175 = load i64, ptr %l83, !tbaa !24
  store i64 %t175, ptr %l80, !tbaa !24
  br label %bb47
bb47:
  %t176 = load i64, ptr %l80, !tbaa !24
  store i64 %t176, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb48
bb48:
  %t177 = load i64, ptr %l10, !tbaa !24
  %t178 = load i64, ptr %l9, !tbaa !24
  %t181 = icmp slt i64 %t177, %t178
  %t183 = xor i1 %t181, true
  br i1 %t183, label %bb49, label %bb50
bb49:
  br label %bb55
bb50:
  br label %bb51
bb51:
  %t185 = load i64, ptr %l6, !tbaa !24
  %t186 = load i64, ptr %l10, !tbaa !24
  %t187 = load i64, ptr %l8, !tbaa !24
  %t190 = mul i64 %t186, %t187
  %t193 = add i64 %t185, %t190
  %t195 = load ptr, ptr %lp1
  %t196 = getelementptr %"compiler/profile:Profile", ptr %t195, i32 0, i32 4
  store ptr %t196, ptr %l101, !tbaa !29
  %t197 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t198 = load i64, ptr %l3, !tbaa !24
  %t200 = add i64 5, %t198
  %t202 = add i64 %t200, 1
  %t206 = add i64 %t202, %t193
  %t209 = call i64 @compiler_2fprofile_2eword(ptr %v0, { i64, ptr } %t197, i64 %t206)
  store i64 %t209, ptr %l108
  br label %bb52
bb52:
  %t210 = load ptr, ptr %l101, !tbaa !29
  %t211 = load i64, ptr %l108, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t210, i64 %t211)
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t212 = load i64, ptr %l10, !tbaa !24
  %t214 = add i64 %t212, 1
  store i64 %t214, ptr %l10, !tbaa !24
  br label %bb48
bb55:
  %t216 = load i64, ptr %l3, !tbaa !24
  %t217 = load i64, ptr %l5, !tbaa !24
  %t219 = add i64 %t217, 1
  %t222 = add i64 %t216, %t219
  store i64 %t222, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb56
bb56:
  br label %bb25
bb57:
  %t224 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t224, ptr %l115, !tbaa !27
  %t225 = load i64, ptr %l2, !tbaa !24
  %t227 = mul i64 %t225, 8
  %t229 = add i64 40, %t227
  store i64 %t229, ptr %l118, !tbaa !24
  %t230 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t233 = extractvalue { i64, ptr } %t230, 0
  store i64 %t233, ptr %l121, !tbaa !24
  %t234 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t235 = extractvalue { i64, ptr } %t234, 0
  store i64 %t235, ptr %l122, !tbaa !24
  %t236 = load i64, ptr %l118, !tbaa !24
  %t237 = icmp sge i64 %t236, 0
  br i1 %t237, label %bb58, label %bb59
bb58:
  %t239 = load i64, ptr %l118, !tbaa !24
  %t240 = load i64, ptr %l121, !tbaa !24
  %t241 = icmp sle i64 %t239, %t240
  br i1 %t241, label %bb60, label %bb61
bb59:
  call void @__olang_check_failed(ptr @olang_loc_ebd4d37101874eec_6116e20ed9489b48)
  unreachable
bb60:
  %t243 = load i64, ptr %l121, !tbaa !24
  %t244 = load i64, ptr %l122, !tbaa !24
  %t245 = icmp sle i64 %t243, %t244
  br i1 %t245, label %bb62, label %bb63
bb61:
  call void @__olang_check_failed(ptr @olang_loc_ebd4d37101874eec_6116e20ed9489b48)
  unreachable
bb62:
  %t247 = getelementptr { i64, ptr }, ptr %l115, i32 0, i32 1
  %t248 = load ptr, ptr %t247, !tbaa !27
  %t249 = load i64, ptr %l118, !tbaa !24
  %t250 = load i64, ptr %l121, !tbaa !24
  %t251 = getelementptr i8, ptr %t248, i64 %t249
  %t252 = sub i64 %t250, %t249
  %t253 = insertvalue { i64, ptr } undef, i64 %t252, 0
  %t254 = insertvalue { i64, ptr } %t253, ptr %t251, 1
  store { i64, ptr } %t254, ptr %l127, !tbaa !27
  %t256 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t257 = extractvalue { i64, ptr } %t256, 0
  store i64 %t257, ptr %l128, !tbaa !24
  %t258 = load i64, ptr %l128, !tbaa !24
  %t259 = mul i64 %t258, 1
  %t260 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t259)
  %t261 = insertvalue { i64, ptr } undef, i64 %t258, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t260, 1
  store { i64, ptr } %t262, ptr %l129, !tbaa !27
  %t263 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !27
  %t265 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = load i64, ptr %l128, !tbaa !24
  %t268 = mul i64 %t267, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t264, ptr %t266, i64 %t268, i1 false)
  %t269 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t271 = extractvalue { i64, ptr } %t269, 0
  %t272 = extractvalue { i64, ptr } %t269, 1
  %t273 = mul i64 %t271, 1
  %t274 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t273)
  call void @llvm.memcpy.p0.p0.i64(ptr %t274, ptr %t272, i64 %t273, i1 false)
  %t275 = insertvalue { i64, ptr } undef, i64 %t271, 0
  %t276 = insertvalue { i64, ptr } %t275, ptr %t274, 1
  %t278 = load ptr, ptr %lp1
  %t279 = getelementptr %"compiler/profile:Profile", ptr %t278, i32 0, i32 5
  store { i64, ptr } %t276, ptr %t279, !tbaa !27
  %t280 = load ptr, ptr %lp1
  %t281 = load %"compiler/profile:Profile", ptr %t280
  call void @__olang_scope_close(ptr %s0)
  %t283 = insertvalue { i32, %"compiler/profile:Profile" } zeroinitializer, %"compiler/profile:Profile" %t281, 1
  store { i32, %"compiler/profile:Profile" } %t283, ptr %rv
  br label %ret
bb63:
  call void @__olang_check_failed(ptr @olang_loc_ebd4d37101874eec_6116e20ed9489b48)
  unreachable
ret:
  %rr = load { i32, %"compiler/profile:Profile" }, ptr %rv
  ret { i32, %"compiler/profile:Profile" } %rr
}

define dso_local { i64, ptr } @compiler_2fprofile_2eReadable(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %lp1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l27 = alloca i1
  %l28 = alloca i1
  %l29 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l37 = alloca i1
  %l39 = alloca i64
  %l40 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l48 = alloca i1
  %l49 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i32
  %l64 = alloca { i64, ptr }
  %l65 = alloca i64
  %l66 = alloca { i64, ptr }
  %l71 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i64
  %l79 = alloca i64
  %l80 = alloca i64
  %l86 = alloca { i64, ptr }
  %l87 = alloca i64
  %l89 = alloca i64
  %l90 = alloca i32
  %l91 = alloca i64
  %l93 = alloca i64
  %l94 = alloca i32
  %l99 = alloca i1
  %l103 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l106 = alloca i64
  %l108 = alloca i64
  %l109 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d29, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t5 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } %t4)
  store i1 %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load i1, ptr %l13, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 1
  %t12 = extractvalue { i64, ptr } %t9, 0
  %t13 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t11, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t15, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = call { i64, ptr } @compiler_2ftypes_2eDemangle(ptr %v0, ptr %v1, { i64, ptr } %t17)
  store { i64, ptr } %t19, ptr %l18
  br label %bb5
bb5:
  %t20 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t20, ptr %lp1
  %t21 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t22 = load ptr, ptr %lp1
  store { i64, ptr } %t21, ptr %t22, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t23 = load i64, ptr %l2, !tbaa !24
  store i64 %t23, ptr %l19, !tbaa !24
  %t24 = load ptr, ptr %lp1
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  store i64 %t27, ptr %l21, !tbaa !24
  %t28 = load ptr, ptr %lp1
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 0
  store i64 %t30, ptr %l22, !tbaa !24
  %t31 = load i64, ptr %l19, !tbaa !24
  %t32 = icmp sge i64 %t31, 0
  br i1 %t32, label %bb7, label %bb8
bb7:
  %t34 = load i64, ptr %l19, !tbaa !24
  %t35 = load i64, ptr %l21, !tbaa !24
  %t36 = icmp sle i64 %t34, %t35
  br i1 %t36, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_3603727fe313055_49dd245dfeecf61)
  unreachable
bb9:
  %t38 = load i64, ptr %l21, !tbaa !24
  %t39 = load i64, ptr %l22, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_3603727fe313055_49dd245dfeecf61)
  unreachable
bb11:
  %t42 = load ptr, ptr %lp1
  %t43 = getelementptr { i64, ptr }, ptr %t42, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = load i64, ptr %l19, !tbaa !24
  %t46 = load i64, ptr %l21, !tbaa !24
  %t47 = getelementptr i8, ptr %t44, i64 %t45
  %t48 = sub i64 %t46, %t45
  %t49 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t47, 1
  %t52 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s3, { i64, ptr } %t50, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store i1 %t52, ptr %l27
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_3603727fe313055_49dd245dfeecf61)
  unreachable
bb13:
  %t53 = load i1, ptr %l27, !tbaa !21
  br i1 %t53, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb23
bb15:
  %t54 = load i64, ptr %l2, !tbaa !24
  store i64 %t54, ptr %l29, !tbaa !24
  %t55 = load ptr, ptr %lp1
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t56, 0
  store i64 %t58, ptr %l31, !tbaa !24
  %t59 = load ptr, ptr %lp1
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t60, 0
  store i64 %t61, ptr %l32, !tbaa !24
  %t62 = load i64, ptr %l29, !tbaa !24
  %t63 = icmp sge i64 %t62, 0
  br i1 %t63, label %bb16, label %bb17
bb16:
  %t65 = load i64, ptr %l29, !tbaa !24
  %t66 = load i64, ptr %l31, !tbaa !24
  %t67 = icmp sle i64 %t65, %t66
  br i1 %t67, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_3603727fe313055_49dd245dfeecf61)
  unreachable
bb18:
  %t69 = load i64, ptr %l31, !tbaa !24
  %t70 = load i64, ptr %l32, !tbaa !24
  %t71 = icmp sle i64 %t69, %t70
  br i1 %t71, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_3603727fe313055_49dd245dfeecf61)
  unreachable
bb20:
  %t73 = load ptr, ptr %lp1
  %t74 = getelementptr { i64, ptr }, ptr %t73, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = load i64, ptr %l29, !tbaa !24
  %t77 = load i64, ptr %l31, !tbaa !24
  %t78 = getelementptr i8, ptr %t75, i64 %t76
  %t79 = sub i64 %t77, %t76
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  %t83 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s3, { i64, ptr } %t81, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store i1 %t83, ptr %l37
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_3603727fe313055_49dd245dfeecf61)
  unreachable
bb22:
  %t84 = load i1, ptr %l37, !tbaa !21
  store i1 %t84, ptr %l28, !tbaa !21
  br label %bb23
bb23:
  %t85 = load i1, ptr %l28, !tbaa !21
  %t86 = xor i1 %t85, true
  br i1 %t86, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s3)
  br label %bb38
bb25:
  br label %bb26
bb26:
  %t88 = load i64, ptr %l2, !tbaa !24
  store i64 %t88, ptr %l39, !tbaa !24
  %t89 = load i64, ptr %l2, !tbaa !24
  store i64 %t89, ptr %l40, !tbaa !24
  %t90 = load ptr, ptr %lp1
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t91, 0
  store i64 %t93, ptr %l42, !tbaa !24
  %t94 = load ptr, ptr %lp1
  %t95 = load { i64, ptr }, ptr %t94, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t95, 0
  store i64 %t96, ptr %l43, !tbaa !24
  %t97 = load i64, ptr %l40, !tbaa !24
  %t98 = icmp sge i64 %t97, 0
  br i1 %t98, label %bb27, label %bb28
bb27:
  %t100 = load i64, ptr %l40, !tbaa !24
  %t101 = load i64, ptr %l42, !tbaa !24
  %t102 = icmp sle i64 %t100, %t101
  br i1 %t102, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_3603727fe313055_49dd245dfeecf61)
  unreachable
bb29:
  %t104 = load i64, ptr %l42, !tbaa !24
  %t105 = load i64, ptr %l43, !tbaa !24
  %t106 = icmp sle i64 %t104, %t105
  br i1 %t106, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_3603727fe313055_49dd245dfeecf61)
  unreachable
bb31:
  %t108 = load ptr, ptr %lp1
  %t109 = getelementptr { i64, ptr }, ptr %t108, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = load i64, ptr %l40, !tbaa !24
  %t112 = load i64, ptr %l42, !tbaa !24
  %t113 = getelementptr i8, ptr %t110, i64 %t111
  %t114 = sub i64 %t112, %t111
  %t115 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t113, 1
  %t118 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s3, { i64, ptr } %t116, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d32, i32 0, i32 1) })
  store i1 %t118, ptr %l48
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_3603727fe313055_49dd245dfeecf61)
  unreachable
bb33:
  %t119 = load i1, ptr %l48, !tbaa !21
  br i1 %t119, label %bb34, label %bb35
bb34:
  store i64 2, ptr %l49, !tbaa !24
  br label %bb36
bb35:
  store i64 3, ptr %l49, !tbaa !24
  br label %bb36
bb36:
  %t120 = load i64, ptr %l39, !tbaa !24
  %t121 = load i64, ptr %l49, !tbaa !24
  %t122 = add i64 %t120, %t121
  store i64 %t122, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb37
bb37:
  br label %bb6
bb38:
  %t124 = load i64, ptr %l2, !tbaa !24
  store i64 %t124, ptr %l52, !tbaa !24
  %t125 = load ptr, ptr %lp1
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t126, 0
  store i64 %t128, ptr %l54, !tbaa !24
  %t129 = load ptr, ptr %lp1
  %t130 = load { i64, ptr }, ptr %t129, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 0
  store i64 %t131, ptr %l55, !tbaa !24
  %t132 = load i64, ptr %l52, !tbaa !24
  %t133 = icmp sge i64 %t132, 0
  br i1 %t133, label %bb39, label %bb40
bb39:
  %t135 = load i64, ptr %l52, !tbaa !24
  %t136 = load i64, ptr %l54, !tbaa !24
  %t137 = icmp sle i64 %t135, %t136
  br i1 %t137, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_e16765c4a8f41078_55e216e6a7163174)
  unreachable
bb41:
  %t139 = load i64, ptr %l54, !tbaa !24
  %t140 = load i64, ptr %l55, !tbaa !24
  %t141 = icmp sle i64 %t139, %t140
  br i1 %t141, label %bb43, label %bb44
bb42:
  call void @__olang_check_failed(ptr @olang_loc_e16765c4a8f41078_55e216e6a7163174)
  unreachable
bb43:
  %t143 = load ptr, ptr %lp1
  %t144 = getelementptr { i64, ptr }, ptr %t143, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = load i64, ptr %l52, !tbaa !24
  %t147 = load i64, ptr %l54, !tbaa !24
  %t148 = getelementptr i8, ptr %t145, i64 %t146
  %t149 = sub i64 %t147, %t146
  %t150 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t148, 1
  %t153 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s0, { i64, ptr } %t151, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) })
  %t154 = extractvalue { i32, i64 } %t153, 1
  %t155 = extractvalue { i32, i64 } %t153, 0
  store i32 %t155, ptr %l61
  %t156 = icmp ne i32 %t155, 0
  br i1 %t156, label %bb46, label %ok.157, !prof !99
ok.157:
  store i64 %t154, ptr %l60
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_e16765c4a8f41078_55e216e6a7163174)
  unreachable
bb45:
  %t158 = load i64, ptr %l60, !tbaa !24
  store i64 %t158, ptr %l51, !tbaa !24
  br label %bb48
bb46:
  br label %bb47
bb47:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l51, !tbaa !24
  br label %bb48
bb48:
  %t159 = load i64, ptr %l51, !tbaa !24
  store i64 %t159, ptr %l3, !tbaa !24
  %t160 = load i64, ptr %l3, !tbaa !24
  %t162 = icmp slt i64 %t160, 0
  br i1 %t162, label %bb49, label %bb50
bb49:
  %t164 = load ptr, ptr %lp1
  %t165 = load { i64, ptr }, ptr %t164, !tbaa !27
  store { i64, ptr } %t165, ptr %l64, !tbaa !27
  %t166 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t167 = extractvalue { i64, ptr } %t166, 0
  store i64 %t167, ptr %l65, !tbaa !24
  %t168 = load i64, ptr %l65, !tbaa !24
  %t169 = mul i64 %t168, 1
  %t170 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t169)
  %t171 = insertvalue { i64, ptr } undef, i64 %t168, 0
  %t172 = insertvalue { i64, ptr } %t171, ptr %t170, 1
  store { i64, ptr } %t172, ptr %l66, !tbaa !27
  %t173 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !27
  %t175 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !27
  %t177 = load i64, ptr %l65, !tbaa !24
  %t178 = mul i64 %t177, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t174, ptr %t176, i64 %t178, i1 false)
  %t179 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t179, ptr %l64, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t180 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t180, ptr %rv
  br label %ret
bb50:
  br label %bb51
bb51:
  %t181 = load i64, ptr %l2, !tbaa !24
  %t182 = load i64, ptr %l3, !tbaa !24
  %t185 = add i64 %t181, %t182
  store i64 %t185, ptr %l4, !tbaa !24
  %t187 = load i64, ptr %l4, !tbaa !24
  %t189 = add i64 %t187, 1
  store i64 %t189, ptr %l71, !tbaa !24
  %t190 = load ptr, ptr %lp1
  %t191 = load { i64, ptr }, ptr %t190, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t191, 0
  store i64 %t193, ptr %l73, !tbaa !24
  %t194 = load ptr, ptr %lp1
  %t195 = load { i64, ptr }, ptr %t194, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t195, 0
  store i64 %t196, ptr %l74, !tbaa !24
  %t197 = load i64, ptr %l71, !tbaa !24
  %t198 = icmp sge i64 %t197, 0
  br i1 %t198, label %bb52, label %bb53
bb52:
  %t200 = load i64, ptr %l71, !tbaa !24
  %t201 = load i64, ptr %l73, !tbaa !24
  %t202 = icmp sle i64 %t200, %t201
  br i1 %t202, label %bb54, label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_a05021294fe2b6d3_c60223eeaa2ef05f)
  unreachable
bb54:
  %t204 = load i64, ptr %l73, !tbaa !24
  %t205 = load i64, ptr %l74, !tbaa !24
  %t206 = icmp sle i64 %t204, %t205
  br i1 %t206, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_a05021294fe2b6d3_c60223eeaa2ef05f)
  unreachable
bb56:
  %t208 = load ptr, ptr %lp1
  %t209 = getelementptr { i64, ptr }, ptr %t208, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !27
  %t211 = load i64, ptr %l71, !tbaa !24
  %t212 = load i64, ptr %l73, !tbaa !24
  %t213 = getelementptr i8, ptr %t210, i64 %t211
  %t214 = sub i64 %t212, %t211
  %t215 = insertvalue { i64, ptr } undef, i64 %t214, 0
  %t216 = insertvalue { i64, ptr } %t215, ptr %t213, 1
  store { i64, ptr } %t216, ptr %l5, !tbaa !27
  %t218 = load i64, ptr %l4, !tbaa !24
  store i64 %t218, ptr %l79, !tbaa !24
  %t219 = load ptr, ptr %lp1
  %t220 = load { i64, ptr }, ptr %t219, !tbaa !27
  %t221 = extractvalue { i64, ptr } %t220, 0
  store i64 %t221, ptr %l80, !tbaa !24
  %t222 = icmp sge i64 0, 0
  br i1 %t222, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @olang_loc_a05021294fe2b6d3_c60223eeaa2ef05f)
  unreachable
bb58:
  %t224 = load i64, ptr %l79, !tbaa !24
  %t225 = icmp sle i64 0, %t224
  br i1 %t225, label %bb60, label %bb61
bb59:
  call void @__olang_check_failed(ptr @olang_loc_efed15e4a0150676_49528d4cd386b8e2)
  unreachable
bb60:
  %t227 = load i64, ptr %l79, !tbaa !24
  %t228 = load i64, ptr %l80, !tbaa !24
  %t229 = icmp sle i64 %t227, %t228
  br i1 %t229, label %bb62, label %bb63
bb61:
  call void @__olang_check_failed(ptr @olang_loc_efed15e4a0150676_49528d4cd386b8e2)
  unreachable
bb62:
  %t231 = load ptr, ptr %lp1
  %t232 = getelementptr { i64, ptr }, ptr %t231, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !27
  %t234 = load i64, ptr %l79, !tbaa !24
  %t235 = getelementptr i8, ptr %t233, i64 0
  %t236 = sub i64 %t234, 0
  %t237 = insertvalue { i64, ptr } undef, i64 %t236, 0
  %t238 = insertvalue { i64, ptr } %t237, ptr %t235, 1
  %t242 = call { i64, ptr } @compiler_2fprofile_2equalifier(ptr %v1, ptr %s0, { i64, ptr } %t238)
  store { i64, ptr } %t242, ptr %l86
  br label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_efed15e4a0150676_49528d4cd386b8e2)
  unreachable
bb64:
  %t243 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t243, ptr %l7, !tbaa !27
  %t244 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t246 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s0, { i64, ptr } %t244, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) })
  %t247 = extractvalue { i32, i64 } %t246, 1
  %t248 = extractvalue { i32, i64 } %t246, 0
  store i32 %t248, ptr %l90
  %t249 = icmp ne i32 %t248, 0
  br i1 %t249, label %bb66, label %ok.250, !prof !99
ok.250:
  store i64 %t247, ptr %l89
  br label %bb65
bb65:
  %t251 = load i64, ptr %l89, !tbaa !24
  store i64 %t251, ptr %l87, !tbaa !24
  br label %bb68
bb66:
  br label %bb67
bb67:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l87, !tbaa !24
  br label %bb68
bb68:
  %t252 = load i64, ptr %l87, !tbaa !24
  store i64 %t252, ptr %l8, !tbaa !24
  %t253 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t255 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s0, { i64, ptr } %t253, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) })
  %t256 = extractvalue { i32, i64 } %t255, 1
  %t257 = extractvalue { i32, i64 } %t255, 0
  store i32 %t257, ptr %l94
  %t258 = icmp ne i32 %t257, 0
  br i1 %t258, label %bb70, label %ok.259, !prof !99
ok.259:
  store i64 %t256, ptr %l93
  br label %bb69
bb69:
  %t260 = load i64, ptr %l93, !tbaa !24
  store i64 %t260, ptr %l91, !tbaa !24
  br label %bb72
bb70:
  br label %bb71
bb71:
  call void @__olang_ert_req_clear()
  %t261 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t263 = extractvalue { i64, ptr } %t261, 0
  store i64 %t263, ptr %l91, !tbaa !24
  br label %bb72
bb72:
  %t265 = load i64, ptr %l91, !tbaa !24
  store i64 %t265, ptr %l9, !tbaa !24
  %t266 = load i64, ptr %l8, !tbaa !24
  %t268 = icmp sge i64 %t266, 0
  br i1 %t268, label %bb73, label %bb74
bb73:
  %t270 = load i64, ptr %l8, !tbaa !24
  %t271 = load i64, ptr %l9, !tbaa !24
  %t274 = icmp slt i64 %t270, %t271
  store i1 %t274, ptr %l99, !tbaa !21
  br label %bb75
bb74:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb75
bb75:
  %t276 = load i1, ptr %l99, !tbaa !21
  br i1 %t276, label %bb76, label %bb77
bb76:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d36, i32 0, i32 1) }, ptr %l103, !tbaa !27
  %t277 = load { i64, ptr }, ptr %l103, !tbaa !27
  store { i64, ptr } %t277, ptr %l104, !tbaa !27
  %t278 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t279 = extractvalue { i64, ptr } %t278, 0
  %t280 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t281 = extractvalue { i64, ptr } %t280, 0
  store i64 %t281, ptr %l106, !tbaa !24
  %t283 = load i64, ptr %l106, !tbaa !24
  %t284 = icmp eq i64 %t279, %t283
  br i1 %t284, label %bb78, label %bb79
bb77:
  br label %bb81
bb78:
  %t286 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t287 = load ptr, ptr %t286, !tbaa !27
  %t288 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t289 = load ptr, ptr %t288, !tbaa !27
  %t290 = load i64, ptr %l106, !tbaa !24
  %t291 = mul i64 %t290, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t287, ptr %t289, i64 %t291, i1 false)
  br label %bb80
bb79:
  %t292 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t293 = extractvalue { i64, ptr } %t292, 0
  store i64 %t293, ptr %l108, !tbaa !24
  %t294 = load i64, ptr %l108, !tbaa !24
  %t295 = mul i64 %t294, 1
  %t296 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t295)
  %t297 = insertvalue { i64, ptr } undef, i64 %t294, 0
  %t298 = insertvalue { i64, ptr } %t297, ptr %t296, 1
  store { i64, ptr } %t298, ptr %l109, !tbaa !27
  %t299 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t300 = load ptr, ptr %t299, !tbaa !27
  %t301 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t302 = load ptr, ptr %t301, !tbaa !27
  %t303 = load i64, ptr %l108, !tbaa !24
  %t304 = mul i64 %t303, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t300, ptr %t302, i64 %t304, i1 false)
  %t305 = load { i64, ptr }, ptr %l109, !tbaa !27
  store { i64, ptr } %t305, ptr %l7, !tbaa !27
  br label %bb80
bb80:
  br label %bb81
bb81:
  %t306 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t306, ptr %l110, !tbaa !27
  %t307 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t309 = call { i64, ptr } @compiler_2fprofile_2etypesRead(ptr %v1, ptr %s0, { i64, ptr } %t307)
  store { i64, ptr } %t309, ptr %l112
  br label %bb82
bb82:
  %t310 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t311 = extractvalue { i64, ptr } %t310, 1
  %t312 = extractvalue { i64, ptr } %t310, 0
  %t313 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t314 = extractvalue { i64, ptr } %t313, 1
  %t315 = extractvalue { i64, ptr } %t313, 0
  %t316 = add i64 %t312, %t315
  %t317 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t316)
  call void @olang_textcopy(ptr %t317, ptr %t311, i64 %t312)
  %t318 = getelementptr i8, ptr %t317, i64 %t312
  call void @olang_textcopy(ptr %t318, ptr %t314, i64 %t315)
  %t319 = insertvalue { i64, ptr } undef, i64 %t316, 0
  %t320 = insertvalue { i64, ptr } %t319, ptr %t317, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t320, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fprofile_2eReport(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/profile:Tally"
  %l4 = alloca i64
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l6 = alloca double
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca i64
  %l31 = alloca i64
  %l33 = alloca i64
  %l34 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca ptr
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l39 = alloca ptr
  %l40 = alloca i64
  %l41 = alloca i64
  %l44 = alloca %"compiler/profile:Tally"
  %l46 = alloca i64
  %l47 = alloca %"std/prelude/text:StringBuilder"
  %l55 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l59 = alloca i64
  %l61 = alloca { i64, ptr }
  %l63 = alloca i64
  %l67 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l84 = alloca i64
  %l85 = alloca { i64, ptr }
  %l86 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l88 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l90 = alloca %"compiler/profile:Tally"
  %l95 = alloca i64
  %l97 = alloca i64
  %l102 = alloca i64
  %l103 = alloca i64
  %l106 = alloca i64
  %l107 = alloca i32
  %l110 = alloca i1
  %l115 = alloca i64
  %l118 = alloca i64
  %l119 = alloca i32
  %l120 = alloca ptr
  %l123 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l130 = alloca { i64, ptr }
  %l134 = alloca { i64, ptr }
  %l141 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l143 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l145 = alloca %"compiler/profile:Tally"
  %l148 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l150 = alloca i64
  %l152 = alloca i64
  %l157 = alloca i64
  %l158 = alloca i64
  %l161 = alloca i64
  %l162 = alloca i32
  %l164 = alloca i64
  %l166 = alloca i1
  %l174 = alloca { i64, ptr }
  %l175 = alloca i1
  %l181 = alloca i64
  %l183 = alloca i64
  %l188 = alloca i64
  %l192 = alloca { i64, ptr }
  %l193 = alloca { i64, ptr }
  %l200 = alloca { i64, ptr }
  %l201 = alloca { i64, ptr }
  %l205 = alloca ptr
  %l207 = alloca { i64, ptr }
  %l211 = alloca i64
  %l213 = alloca i64
  %l218 = alloca i64
  %l219 = alloca i64
  %l222 = alloca i64
  %l223 = alloca i32
  %l224 = alloca i64
  %l227 = alloca i64
  %l228 = alloca i32
  %l229 = alloca ptr
  %l232 = alloca { i64, ptr }
  %l234 = alloca { i64, ptr }
  %l238 = alloca { i64, ptr }
  %l239 = alloca { i64, ptr }
  %l242 = alloca { i64, ptr }
  %l246 = alloca { i64, ptr }
  %l253 = alloca i64
  %l255 = alloca i64
  %l260 = alloca i64
  %l263 = alloca i64
  %l266 = alloca i64
  %l267 = alloca i32
  %l272 = alloca i64
  %l275 = alloca i64
  %l276 = alloca i32
  %l277 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l279 = alloca i64
  %l281 = alloca i64
  %l286 = alloca i64
  %l292 = alloca i1
  %l298 = alloca %"compiler/profile:Tally"
  %l302 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l304 = alloca i64
  %l306 = alloca i64
  %l311 = alloca i64
  %l313 = alloca i64
  %l315 = alloca ptr
  %l319 = alloca { i64, ptr }
  %l320 = alloca i64
  %l326 = alloca i64
  %l327 = alloca i32
  %l329 = alloca { i64, ptr }
  %l334 = alloca ptr
  %l338 = alloca { i64, ptr }
  %l340 = alloca i64
  %l342 = alloca { i64, ptr }
  %l344 = alloca { i64, ptr }
  %l351 = alloca { i64, ptr }
  %l352 = alloca { i64, ptr }
  %l353 = alloca i64
  %l354 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t3 = alloca %"compiler/profile:Tally", align 8
  %t167 = alloca { %"compiler/profile:Tally", ptr, ptr, ptr }, align 8
  %t324 = alloca { %"compiler/profile:Tally", ptr, ptr, ptr }, align 8
  %t692 = alloca { %"compiler/profile:Tally", i64, ptr, ptr, ptr }, align 8
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fprofile_2eTallied(ptr %t3, ptr %v1, ptr %v2, ptr %s0, ptr %t1, ptr %t2)
  call void @llvm.memmove.p0.p0.i64(ptr %l44, ptr %t3, i64 424, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %l44, i64 424, i1 false)
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aProfile_2eTotal(ptr %v1, ptr %t6)
  store i64 %t8, ptr %l46
  br label %bb2
bb2:
  %t9 = load i64, ptr %l46, !tbaa !24
  store i64 %t9, ptr %l4, !tbaa !24
  %t10 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t10, ptr %l47
  br label %bb3
bb3:
  %t11 = load %"std/prelude/text:StringBuilder", ptr %l47
  store %"std/prelude/text:StringBuilder" %t11, ptr %l5
  %t12 = load i64, ptr %l4, !tbaa !24
  %t14 = sitofp i64 %t12 to double
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/profile:Profile", ptr %t15, i32 0, i32 0
  %t18 = load i64, ptr %t17, !tbaa !24
  %t20 = sitofp i64 %t18 to double
  %t23 = fmul double %t14, %t20
  %t25 = fdiv double %t23, 0x41cdcd6500000000
  store double %t25, ptr %l6, !tbaa !26
  store ptr %l5, ptr %l55, !tbaa !29
  store { i64, ptr } %a0, ptr %l56, !tbaa !27
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"compiler/profile:Profile", ptr %t28, i32 0, i32 3
  %t32 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2eLen_3ccompiler_2fprofile_3aSample_3e(ptr %v1, ptr %t30)
  store i64 %t32, ptr %l59
  br label %bb4
bb4:
  %t33 = load double, ptr %l6, !tbaa !26
  %t35 = call { i64, ptr } @std_2fprelude_2ffloat_2eF64_2eFixed(ptr %s0, double %t33, i64 3)
  store { i64, ptr } %t35, ptr %l61
  br label %bb5
bb5:
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = getelementptr %"compiler/profile:Profile", ptr %t36, i32 0, i32 2
  %t39 = load i64, ptr %t38, !tbaa !24
  store i64 %t39, ptr %l63, !tbaa !24
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr %"compiler/profile:Profile", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t45 = icmp eq i64 %t43, 1
  br i1 %t45, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d37, i32 0, i32 1) }, ptr %l67, !tbaa !27
  br label %bb8
bb7:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l67, !tbaa !27
  br label %bb8
bb8:
  %t47 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t48 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t49 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 1
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t52 = add i64 %t48, %t51
  %t53 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t54 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  %t55 = add i64 %t52, %t54
  %t56 = load i64, ptr %l59, !tbaa !24
  %t57 = call i64 @__olang_fmt_i64(ptr null, i64 %t56)
  %t58 = add i64 %t55, %t57
  %t59 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t61 = add i64 %t58, %t60
  %t62 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t62, 1
  %t64 = extractvalue { i64, ptr } %t62, 0
  %t65 = add i64 %t61, %t64
  %t66 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t67 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t68 = add i64 %t65, %t67
  %t69 = load i64, ptr %l63, !tbaa !24
  %t70 = call i64 @__olang_fmt_i64(ptr null, i64 %t69)
  %t71 = add i64 %t68, %t70
  %t72 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 1
  %t74 = extractvalue { i64, ptr } %t72, 0
  %t75 = add i64 %t71, %t74
  %t76 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t77 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t78 = add i64 %t75, %t77
  %t79 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t78)
  call void @olang_textcopy(ptr %t79, ptr %t47, i64 %t48)
  %t80 = getelementptr i8, ptr %t79, i64 %t48
  call void @olang_textcopy(ptr %t80, ptr %t50, i64 %t51)
  %t81 = getelementptr i8, ptr %t80, i64 %t51
  call void @olang_textcopy(ptr %t81, ptr %t53, i64 %t54)
  %t82 = getelementptr i8, ptr %t81, i64 %t54
  %t83 = call i64 @__olang_fmt_i64(ptr %t82, i64 %t56)
  %t84 = getelementptr i8, ptr %t82, i64 %t57
  call void @olang_textcopy(ptr %t84, ptr %t59, i64 %t60)
  %t85 = getelementptr i8, ptr %t84, i64 %t60
  call void @olang_textcopy(ptr %t85, ptr %t63, i64 %t64)
  %t86 = getelementptr i8, ptr %t85, i64 %t64
  call void @olang_textcopy(ptr %t86, ptr %t66, i64 %t67)
  %t87 = getelementptr i8, ptr %t86, i64 %t67
  %t88 = call i64 @__olang_fmt_i64(ptr %t87, i64 %t69)
  %t89 = getelementptr i8, ptr %t87, i64 %t70
  call void @olang_textcopy(ptr %t89, ptr %t73, i64 %t74)
  %t90 = getelementptr i8, ptr %t89, i64 %t74
  call void @olang_textcopy(ptr %t90, ptr %t76, i64 %t77)
  %t91 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t79, 1
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t95 = extractvalue { i64, ptr } %t92, 1
  %t96 = mul i64 %t94, 1
  %t97 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t96)
  call void @llvm.memcpy.p0.p0.i64(ptr %t97, ptr %t95, i64 %t96, i1 false)
  %t98 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t97, 1
  %t100 = load ptr, ptr %l55, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t100, { i64, ptr } %t99)
  br label %bb9
bb9:
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t104 = getelementptr %"compiler/profile:Profile", ptr %t102, i32 0, i32 1
  %t105 = load i64, ptr %t104, !tbaa !24
  %t107 = icmp sgt i64 %t105, 0
  br i1 %t107, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t109 = load ptr, ptr %l1, !tbaa !29
  %t111 = getelementptr %"compiler/profile:Profile", ptr %t109, i32 0, i32 1
  %t112 = load i64, ptr %t111, !tbaa !24
  %t113 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t114 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t116 = call i64 @__olang_fmt_i64(ptr null, i64 %t112)
  %t117 = add i64 %t114, %t116
  %t118 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t119 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t120 = add i64 %t117, %t119
  %t121 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t120)
  call void @olang_textcopy(ptr %t121, ptr %t113, i64 %t114)
  %t122 = getelementptr i8, ptr %t121, i64 %t114
  %t123 = call i64 @__olang_fmt_i64(ptr %t122, i64 %t112)
  %t124 = getelementptr i8, ptr %t122, i64 %t116
  call void @olang_textcopy(ptr %t124, ptr %t118, i64 %t119)
  %t125 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t121, 1
  %t128 = extractvalue { i64, ptr } %t126, 0
  %t129 = extractvalue { i64, ptr } %t126, 1
  %t130 = mul i64 %t128, 1
  %t131 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t130)
  call void @llvm.memcpy.p0.p0.i64(ptr %t131, ptr %t129, i64 %t130, i1 false)
  %t132 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr %t131, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l5, { i64, ptr } %t133)
  br label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  %t136 = load i64, ptr %l4, !tbaa !24
  %t138 = icmp eq i64 %t136, 0
  br i1 %t138, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l5, { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d46, i32 0, i32 1) })
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t142 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v3, ptr %l5)
  store { i64, ptr } %t142, ptr %l82
  br label %bb17
bb17:
  %t143 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t143, ptr %l83, !tbaa !27
  %t144 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t144, 0
  store i64 %t145, ptr %l84, !tbaa !24
  %t146 = load i64, ptr %l84, !tbaa !24
  %t147 = mul i64 %t146, 1
  %t148 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t147)
  %t149 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t148, 1
  store { i64, ptr } %t150, ptr %l85, !tbaa !27
  %t151 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = load i64, ptr %l84, !tbaa !24
  %t156 = mul i64 %t155, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t152, ptr %t154, i64 %t156, i1 false)
  %t157 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t157, ptr %l83, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t158 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t158, ptr %rv
  br label %ret
bb18:
  %t159 = getelementptr %"compiler/profile:Tally", ptr %l3, i32 0, i32 5
  %t160 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t159
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t160, ptr %l86
  %t162 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s0, ptr %l86)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t162, ptr %l88
  br label %bb19
bb19:
  %t163 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l88
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t163, ptr %l7
  call void @llvm.memmove.p0.p0.i64(ptr %l90, ptr %l3, i64 424, i1 false)
  %t164 = load ptr, ptr %l2, !tbaa !29
  %t165 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr null, i32 1
  %t166 = ptrtoint ptr %t165 to i64
  %t168 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %t167, i32 0, i32 0
  call void @llvm.memmove.p0.p0.i64(ptr %t168, ptr %l90, i64 424, i1 false)
  %t169 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %t167, i32 0, i32 1
  store ptr %t164, ptr %t169, !tbaa !28
  call void @__olang_scope_escape(ptr %s0)
  %t171 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %t167, i32 0, i32 2
  store ptr %s0, ptr %t171, !tbaa !28
  call void @__olang_scope_escape(ptr %v2)
  %t172 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %t167, i32 0, i32 3
  store ptr %v2, ptr %t172, !tbaa !28
  %t173 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_47, 0
  %t174 = insertvalue { ptr, ptr } %t173, ptr %t167, 1
  %t177 = extractvalue { ptr, ptr } %t174, 0
  %t178 = extractvalue { ptr, ptr } %t174, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %s0, ptr %s0, ptr %l7, ptr %t177, ptr %t178)
  br label %bb20
bb20:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l5, { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d48, i32 0, i32 1) })
  br label %bb21
bb21:
  store i64 0, ptr %l8, !tbaa !24
  store ptr %l7, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s6
  %t181 = load i64, ptr %l10, !tbaa !24
  store i64 %t181, ptr %l95, !tbaa !24
  %t182 = load ptr, ptr %l9, !tbaa !29
  %t184 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t182)
  store i64 %t184, ptr %l97
  br label %bb23
bb23:
  %t185 = load i64, ptr %l95, !tbaa !24
  %t186 = load i64, ptr %l97, !tbaa !24
  %t187 = icmp slt i64 %t185, %t186
  %t189 = xor i1 %t187, true
  br i1 %t189, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s6)
  br label %bb49
bb25:
  br label %bb26
bb26:
  %t191 = load ptr, ptr %l9, !tbaa !29
  %t192 = load i64, ptr %l10, !tbaa !24
  %t195 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t191, i64 %t192)
  store i64 %t195, ptr %l102
  br label %bb27
bb27:
  %t196 = load i64, ptr %l102, !tbaa !24
  store i64 %t196, ptr %l11, !tbaa !24
  %t197 = getelementptr %"compiler/profile:Tally", ptr %l3, i32 0, i32 0
  %t198 = load i64, ptr %l11, !tbaa !24
  %t201 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %s0, ptr %t197, i64 %t198)
  %t202 = extractvalue { i32, i64 } %t201, 1
  %t203 = extractvalue { i32, i64 } %t201, 0
  store i32 %t203, ptr %l107
  %t204 = icmp ne i32 %t203, 0
  br i1 %t204, label %bb29, label %ok.205, !prof !99
ok.205:
  store i64 %t202, ptr %l106
  br label %bb28
bb28:
  %t206 = load i64, ptr %l106, !tbaa !24
  store i64 %t206, ptr %l103, !tbaa !24
  br label %bb31
bb29:
  br label %bb30
bb30:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l103, !tbaa !24
  br label %bb31
bb31:
  %t207 = load i64, ptr %l103, !tbaa !24
  store i64 %t207, ptr %l12, !tbaa !24
  %t208 = load i64, ptr %l8, !tbaa !24
  %t210 = icmp sge i64 %t208, 25
  br i1 %t210, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l110, !tbaa !21
  br label %bb34
bb33:
  %t212 = load i64, ptr %l12, !tbaa !24
  %t214 = mul i64 %t212, 200
  %t215 = load i64, ptr %l4, !tbaa !24
  %t218 = icmp slt i64 %t214, %t215
  store i1 %t218, ptr %l110, !tbaa !21
  br label %bb34
bb34:
  %t220 = load i1, ptr %l110, !tbaa !21
  br i1 %t220, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s6)
  br label %bb49
bb36:
  br label %bb37
bb37:
  %t221 = getelementptr %"compiler/profile:Tally", ptr %l3, i32 0, i32 1
  %t222 = load i64, ptr %l11, !tbaa !24
  %t225 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %s0, ptr %t221, i64 %t222)
  %t226 = extractvalue { i32, i64 } %t225, 1
  %t227 = extractvalue { i32, i64 } %t225, 0
  store i32 %t227, ptr %l119
  %t228 = icmp ne i32 %t227, 0
  br i1 %t228, label %bb39, label %ok.229, !prof !99
ok.229:
  store i64 %t226, ptr %l118
  br label %bb38
bb38:
  %t230 = load i64, ptr %l118, !tbaa !24
  store i64 %t230, ptr %l115, !tbaa !24
  br label %bb41
bb39:
  br label %bb40
bb40:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l115, !tbaa !24
  br label %bb41
bb41:
  %t231 = load i64, ptr %l115, !tbaa !24
  store i64 %t231, ptr %l13, !tbaa !24
  store ptr %l5, ptr %l120, !tbaa !29
  %t232 = load i64, ptr %l12, !tbaa !24
  %t233 = load i64, ptr %l4, !tbaa !24
  %t236 = call { i64, ptr } @compiler_2fprofile_2epct(ptr %s6, i64 %t232, i64 %t233)
  store { i64, ptr } %t236, ptr %l123
  br label %bb42
bb42:
  %t237 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t238 = extractvalue { i64, ptr } %t237, 0
  %t239 = extractvalue { i64, ptr } %t237, 1
  %t240 = mul i64 %t238, 1
  %t241 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t240)
  call void @llvm.memcpy.p0.p0.i64(ptr %t241, ptr %t239, i64 %t240, i1 false)
  %t242 = insertvalue { i64, ptr } undef, i64 %t238, 0
  %t243 = insertvalue { i64, ptr } %t242, ptr %t241, 1
  %t245 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %s6, ptr %s6, { i64, ptr } %t243, i64 6, i8 32)
  store { i64, ptr } %t245, ptr %l125
  br label %bb43
bb43:
  %t246 = load i64, ptr %l13, !tbaa !24
  %t247 = load i64, ptr %l4, !tbaa !24
  %t250 = call { i64, ptr } @compiler_2fprofile_2epct(ptr %s6, i64 %t246, i64 %t247)
  store { i64, ptr } %t250, ptr %l128
  br label %bb44
bb44:
  %t251 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t251, 0
  %t253 = extractvalue { i64, ptr } %t251, 1
  %t254 = mul i64 %t252, 1
  %t255 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t254)
  call void @llvm.memcpy.p0.p0.i64(ptr %t255, ptr %t253, i64 %t254, i1 false)
  %t256 = insertvalue { i64, ptr } undef, i64 %t252, 0
  %t257 = insertvalue { i64, ptr } %t256, ptr %t255, 1
  %t259 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %s6, ptr %s6, { i64, ptr } %t257, i64 6, i8 32)
  store { i64, ptr } %t259, ptr %l130
  br label %bb45
bb45:
  %t260 = load ptr, ptr %l2, !tbaa !29
  %t262 = getelementptr %"compiler/profile:Places", ptr %t260, i32 0, i32 0
  %t263 = load i64, ptr %l11, !tbaa !24
  %t266 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %s6, ptr %t262, i64 %t263)
  store { i64, ptr } %t266, ptr %l134
  br label %bb46
bb46:
  %t267 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t268 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t269 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t270 = extractvalue { i64, ptr } %t269, 1
  %t271 = extractvalue { i64, ptr } %t269, 0
  %t272 = add i64 %t268, %t271
  %t273 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t274 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t275 = add i64 %t272, %t274
  %t276 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t277 = extractvalue { i64, ptr } %t276, 1
  %t278 = extractvalue { i64, ptr } %t276, 0
  %t279 = add i64 %t275, %t278
  %t280 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t281 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  %t282 = add i64 %t279, %t281
  %t283 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t284 = extractvalue { i64, ptr } %t283, 1
  %t285 = extractvalue { i64, ptr } %t283, 0
  %t286 = add i64 %t282, %t285
  %t287 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t288 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t289 = add i64 %t286, %t288
  %t290 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t289)
  call void @olang_textcopy(ptr %t290, ptr %t267, i64 %t268)
  %t291 = getelementptr i8, ptr %t290, i64 %t268
  call void @olang_textcopy(ptr %t291, ptr %t270, i64 %t271)
  %t292 = getelementptr i8, ptr %t291, i64 %t271
  call void @olang_textcopy(ptr %t292, ptr %t273, i64 %t274)
  %t293 = getelementptr i8, ptr %t292, i64 %t274
  call void @olang_textcopy(ptr %t293, ptr %t277, i64 %t278)
  %t294 = getelementptr i8, ptr %t293, i64 %t278
  call void @olang_textcopy(ptr %t294, ptr %t280, i64 %t281)
  %t295 = getelementptr i8, ptr %t294, i64 %t281
  call void @olang_textcopy(ptr %t295, ptr %t284, i64 %t285)
  %t296 = getelementptr i8, ptr %t295, i64 %t285
  call void @olang_textcopy(ptr %t296, ptr %t287, i64 %t288)
  %t297 = insertvalue { i64, ptr } undef, i64 %t289, 0
  %t298 = insertvalue { i64, ptr } %t297, ptr %t290, 1
  %t300 = extractvalue { i64, ptr } %t298, 0
  %t301 = extractvalue { i64, ptr } %t298, 1
  %t302 = mul i64 %t300, 1
  %t303 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t302)
  call void @llvm.memcpy.p0.p0.i64(ptr %t303, ptr %t301, i64 %t302, i1 false)
  %t304 = insertvalue { i64, ptr } undef, i64 %t300, 0
  %t305 = insertvalue { i64, ptr } %t304, ptr %t303, 1
  %t306 = load ptr, ptr %l120, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %t306, { i64, ptr } %t305)
  br label %bb47
bb47:
  %t308 = load i64, ptr %l8, !tbaa !24
  %t310 = add i64 %t308, 1
  store i64 %t310, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb48
bb48:
  %t312 = load i64, ptr %l10, !tbaa !24
  %t314 = add i64 %t312, 1
  store i64 %t314, ptr %l10, !tbaa !24
  br label %bb22
bb49:
  %t316 = getelementptr %"compiler/profile:Tally", ptr %l3, i32 0, i32 6
  %t317 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t316
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t317, ptr %l141
  %t319 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s0, ptr %l141)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t319, ptr %l143
  br label %bb50
bb50:
  %t320 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l143
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t320, ptr %l14
  call void @llvm.memmove.p0.p0.i64(ptr %l145, ptr %l3, i64 424, i1 false)
  %t321 = load ptr, ptr %l2, !tbaa !29
  %t322 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr null, i32 1
  %t323 = ptrtoint ptr %t322 to i64
  %t325 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %t324, i32 0, i32 0
  call void @llvm.memmove.p0.p0.i64(ptr %t325, ptr %l145, i64 424, i1 false)
  %t326 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %t324, i32 0, i32 1
  store ptr %t321, ptr %t326, !tbaa !28
  call void @__olang_scope_escape(ptr %s0)
  %t328 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %t324, i32 0, i32 2
  store ptr %s0, ptr %t328, !tbaa !28
  call void @__olang_scope_escape(ptr %v2)
  %t329 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %t324, i32 0, i32 3
  store ptr %v2, ptr %t329, !tbaa !28
  %t330 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_53, 0
  %t331 = insertvalue { ptr, ptr } %t330, ptr %t324, 1
  %t334 = extractvalue { ptr, ptr } %t331, 0
  %t335 = extractvalue { ptr, ptr } %t331, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %s0, ptr %s0, ptr %l14, ptr %t334, ptr %t335)
  br label %bb51
bb51:
  %t336 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t336, ptr %l148
  br label %bb52
bb52:
  %t337 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l148
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t337, ptr %l15
  store ptr %l14, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb53
bb53:
  store %olang.scope zeroinitializer, ptr %s11
  %t339 = load i64, ptr %l17, !tbaa !24
  store i64 %t339, ptr %l150, !tbaa !24
  %t340 = load ptr, ptr %l16, !tbaa !29
  %t342 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t340)
  store i64 %t342, ptr %l152
  br label %bb54
bb54:
  %t343 = load i64, ptr %l150, !tbaa !24
  %t344 = load i64, ptr %l152, !tbaa !24
  %t345 = icmp slt i64 %t343, %t344
  %t347 = xor i1 %t345, true
  br i1 %t347, label %bb55, label %bb56
bb55:
  call void @__olang_scope_close(ptr %s11)
  br label %bb77
bb56:
  br label %bb57
bb57:
  %t349 = load ptr, ptr %l16, !tbaa !29
  %t350 = load i64, ptr %l17, !tbaa !24
  %t353 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t349, i64 %t350)
  store i64 %t353, ptr %l157
  br label %bb58
bb58:
  %t354 = load i64, ptr %l157, !tbaa !24
  store i64 %t354, ptr %l18, !tbaa !24
  %t355 = getelementptr %"compiler/profile:Tally", ptr %l3, i32 0, i32 2
  %t356 = load i64, ptr %l18, !tbaa !24
  %t359 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %s0, ptr %t355, i64 %t356)
  %t360 = extractvalue { i32, i64 } %t359, 1
  %t361 = extractvalue { i32, i64 } %t359, 0
  store i32 %t361, ptr %l162
  %t362 = icmp ne i32 %t361, 0
  br i1 %t362, label %bb60, label %ok.363, !prof !99
ok.363:
  store i64 %t360, ptr %l161
  br label %bb59
bb59:
  %t364 = load i64, ptr %l161, !tbaa !24
  store i64 %t364, ptr %l158, !tbaa !24
  br label %bb62
bb60:
  br label %bb61
bb61:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l158, !tbaa !24
  br label %bb62
bb62:
  %t365 = load i64, ptr %l158, !tbaa !24
  store i64 %t365, ptr %l19, !tbaa !24
  %t367 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l15)
  store i64 %t367, ptr %l164
  br label %bb63
bb63:
  %t368 = load i64, ptr %l164, !tbaa !24
  %t369 = icmp sge i64 %t368, 15
  br i1 %t369, label %bb64, label %bb65
bb64:
  store i1 true, ptr %l166, !tbaa !21
  br label %bb66
bb65:
  %t371 = load i64, ptr %l19, !tbaa !24
  %t373 = mul i64 %t371, 200
  %t374 = load i64, ptr %l4, !tbaa !24
  %t377 = icmp slt i64 %t373, %t374
  store i1 %t377, ptr %l166, !tbaa !21
  br label %bb66
bb66:
  %t379 = load i1, ptr %l166, !tbaa !21
  br i1 %t379, label %bb67, label %bb68
bb67:
  call void @__olang_scope_close(ptr %s11)
  br label %bb77
bb68:
  br label %bb69
bb69:
  %t380 = load ptr, ptr %l2, !tbaa !29
  %t382 = getelementptr %"compiler/profile:Places", ptr %t380, i32 0, i32 0
  %t383 = load i64, ptr %l18, !tbaa !24
  %t386 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %v2, ptr %t382, i64 %t383)
  store { i64, ptr } %t386, ptr %l174
  br label %bb70
bb70:
  %t387 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t388 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v2, ptr %s11, { i64, ptr } %t387, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d54, i32 0, i32 1) })
  store i1 %t388, ptr %l175
  br label %bb71
bb71:
  %t389 = load i1, ptr %l175, !tbaa !21
  br i1 %t389, label %bb72, label %bb73
bb72:
  call void @__olang_scope_close(ptr %s11)
  br label %bb76
bb73:
  br label %bb74
bb74:
  %t390 = load i64, ptr %l18, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l15, i64 %t390)
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s11)
  br label %bb76
bb76:
  %t393 = load i64, ptr %l17, !tbaa !24
  %t395 = add i64 %t393, 1
  store i64 %t395, ptr %l17, !tbaa !24
  br label %bb53
bb77:
  store i64 4, ptr %l20, !tbaa !24
  store ptr %l15, ptr %l21, !tbaa !29
  store i64 0, ptr %l22, !tbaa !24
  br label %bb78
bb78:
  store %olang.scope zeroinitializer, ptr %s16
  %t398 = load i64, ptr %l22, !tbaa !24
  store i64 %t398, ptr %l181, !tbaa !24
  %t399 = load ptr, ptr %l21, !tbaa !29
  %t401 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t399)
  store i64 %t401, ptr %l183
  br label %bb79
bb79:
  %t402 = load i64, ptr %l181, !tbaa !24
  %t403 = load i64, ptr %l183, !tbaa !24
  %t404 = icmp slt i64 %t402, %t403
  %t406 = xor i1 %t404, true
  br i1 %t406, label %bb80, label %bb81
bb80:
  call void @__olang_scope_close(ptr %s16)
  br label %bb92
bb81:
  br label %bb82
bb82:
  %t408 = load ptr, ptr %l21, !tbaa !29
  %t409 = load i64, ptr %l22, !tbaa !24
  %t412 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t408, i64 %t409)
  store i64 %t412, ptr %l188
  br label %bb83
bb83:
  %t413 = load i64, ptr %l188, !tbaa !24
  store i64 %t413, ptr %l23, !tbaa !24
  %t414 = load ptr, ptr %l2, !tbaa !29
  %t416 = getelementptr %"compiler/profile:Places", ptr %t414, i32 0, i32 0
  %t417 = load i64, ptr %l23, !tbaa !24
  %t420 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %v2, ptr %t416, i64 %t417)
  store { i64, ptr } %t420, ptr %l192
  br label %bb84
bb84:
  %t421 = load { i64, ptr }, ptr %l192, !tbaa !27
  %t422 = call { i64, ptr } @compiler_2fprofile_2eshortPath(ptr %v2, ptr %s16, { i64, ptr } %t421)
  store { i64, ptr } %t422, ptr %l193
  br label %bb85
bb85:
  %t423 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t424 = extractvalue { i64, ptr } %t423, 0
  %t425 = load i64, ptr %l20, !tbaa !24
  %t428 = icmp sgt i64 %t424, %t425
  br i1 %t428, label %bb86, label %bb87
bb86:
  store %olang.scope zeroinitializer, ptr %s17
  %t430 = load ptr, ptr %l2, !tbaa !29
  %t432 = getelementptr %"compiler/profile:Places", ptr %t430, i32 0, i32 0
  %t433 = load i64, ptr %l23, !tbaa !24
  %t436 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %v2, ptr %t432, i64 %t433)
  store { i64, ptr } %t436, ptr %l200
  br label %bb88
bb87:
  br label %bb90
bb88:
  %t437 = load { i64, ptr }, ptr %l200, !tbaa !27
  %t438 = call { i64, ptr } @compiler_2fprofile_2eshortPath(ptr %v2, ptr %s17, { i64, ptr } %t437)
  store { i64, ptr } %t438, ptr %l201
  br label %bb89
bb89:
  %t439 = load { i64, ptr }, ptr %l201, !tbaa !27
  %t440 = extractvalue { i64, ptr } %t439, 0
  store i64 %t440, ptr %l20, !tbaa !24
  call void @__olang_scope_close(ptr %s17)
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s16)
  br label %bb91
bb91:
  %t442 = load i64, ptr %l22, !tbaa !24
  %t444 = add i64 %t442, 1
  store i64 %t444, ptr %l22, !tbaa !24
  br label %bb78
bb92:
  store ptr %l5, ptr %l205, !tbaa !29
  %t446 = load i64, ptr %l20, !tbaa !24
  %t448 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadEnd(ptr %s0, ptr %s0, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d55, i32 0, i32 1) }, i64 %t446, i8 32)
  store { i64, ptr } %t448, ptr %l207
  br label %bb93
bb93:
  %t449 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t450 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t451 = load { i64, ptr }, ptr %l207, !tbaa !27
  %t452 = extractvalue { i64, ptr } %t451, 1
  %t453 = extractvalue { i64, ptr } %t451, 0
  %t454 = add i64 %t450, %t453
  %t455 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d57, i32 0, i32 1) }, 1
  %t456 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d57, i32 0, i32 1) }, 0
  %t457 = add i64 %t454, %t456
  %t458 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t457)
  call void @olang_textcopy(ptr %t458, ptr %t449, i64 %t450)
  %t459 = getelementptr i8, ptr %t458, i64 %t450
  call void @olang_textcopy(ptr %t459, ptr %t452, i64 %t453)
  %t460 = getelementptr i8, ptr %t459, i64 %t453
  call void @olang_textcopy(ptr %t460, ptr %t455, i64 %t456)
  %t461 = insertvalue { i64, ptr } undef, i64 %t457, 0
  %t462 = insertvalue { i64, ptr } %t461, ptr %t458, 1
  %t464 = extractvalue { i64, ptr } %t462, 0
  %t465 = extractvalue { i64, ptr } %t462, 1
  %t466 = mul i64 %t464, 1
  %t467 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t466)
  call void @llvm.memcpy.p0.p0.i64(ptr %t467, ptr %t465, i64 %t466, i1 false)
  %t468 = insertvalue { i64, ptr } undef, i64 %t464, 0
  %t469 = insertvalue { i64, ptr } %t468, ptr %t467, 1
  %t470 = load ptr, ptr %l205, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t470, { i64, ptr } %t469)
  br label %bb94
bb94:
  store ptr %l15, ptr %l24, !tbaa !29
  store i64 0, ptr %l25, !tbaa !24
  br label %bb95
bb95:
  store %olang.scope zeroinitializer, ptr %s21
  %t473 = load i64, ptr %l25, !tbaa !24
  store i64 %t473, ptr %l211, !tbaa !24
  %t474 = load ptr, ptr %l24, !tbaa !29
  %t476 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t474)
  store i64 %t476, ptr %l213
  br label %bb96
bb96:
  %t477 = load i64, ptr %l211, !tbaa !24
  %t478 = load i64, ptr %l213, !tbaa !24
  %t479 = icmp slt i64 %t477, %t478
  %t481 = xor i1 %t479, true
  br i1 %t481, label %bb97, label %bb98
bb97:
  call void @__olang_scope_close(ptr %s21)
  br label %bb117
bb98:
  br label %bb99
bb99:
  %t483 = load ptr, ptr %l24, !tbaa !29
  %t484 = load i64, ptr %l25, !tbaa !24
  %t487 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t483, i64 %t484)
  store i64 %t487, ptr %l218
  br label %bb100
bb100:
  %t488 = load i64, ptr %l218, !tbaa !24
  store i64 %t488, ptr %l26, !tbaa !24
  %t489 = getelementptr %"compiler/profile:Tally", ptr %l3, i32 0, i32 2
  %t490 = load i64, ptr %l26, !tbaa !24
  %t493 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %s0, ptr %t489, i64 %t490)
  %t494 = extractvalue { i32, i64 } %t493, 1
  %t495 = extractvalue { i32, i64 } %t493, 0
  store i32 %t495, ptr %l223
  %t496 = icmp ne i32 %t495, 0
  br i1 %t496, label %bb102, label %ok.497, !prof !99
ok.497:
  store i64 %t494, ptr %l222
  br label %bb101
bb101:
  %t498 = load i64, ptr %l222, !tbaa !24
  store i64 %t498, ptr %l219, !tbaa !24
  br label %bb104
bb102:
  br label %bb103
bb103:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l219, !tbaa !24
  br label %bb104
bb104:
  %t499 = load i64, ptr %l219, !tbaa !24
  store i64 %t499, ptr %l27, !tbaa !24
  %t500 = getelementptr %"compiler/profile:Tally", ptr %l3, i32 0, i32 3
  %t501 = load i64, ptr %l26, !tbaa !24
  %t504 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %s0, ptr %t500, i64 %t501)
  %t505 = extractvalue { i32, i64 } %t504, 1
  %t506 = extractvalue { i32, i64 } %t504, 0
  store i32 %t506, ptr %l228
  %t507 = icmp ne i32 %t506, 0
  br i1 %t507, label %bb106, label %ok.508, !prof !99
ok.508:
  store i64 %t505, ptr %l227
  br label %bb105
bb105:
  %t509 = load i64, ptr %l227, !tbaa !24
  store i64 %t509, ptr %l224, !tbaa !24
  br label %bb108
bb106:
  br label %bb107
bb107:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l224, !tbaa !24
  br label %bb108
bb108:
  %t510 = load i64, ptr %l224, !tbaa !24
  store i64 %t510, ptr %l28, !tbaa !24
  store ptr %l5, ptr %l229, !tbaa !29
  %t511 = load i64, ptr %l27, !tbaa !24
  %t512 = load i64, ptr %l4, !tbaa !24
  %t515 = call { i64, ptr } @compiler_2fprofile_2epct(ptr %s21, i64 %t511, i64 %t512)
  store { i64, ptr } %t515, ptr %l232
  br label %bb109
bb109:
  %t516 = load { i64, ptr }, ptr %l232, !tbaa !27
  %t517 = extractvalue { i64, ptr } %t516, 0
  %t518 = extractvalue { i64, ptr } %t516, 1
  %t519 = mul i64 %t517, 1
  %t520 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t519)
  call void @llvm.memcpy.p0.p0.i64(ptr %t520, ptr %t518, i64 %t519, i1 false)
  %t521 = insertvalue { i64, ptr } undef, i64 %t517, 0
  %t522 = insertvalue { i64, ptr } %t521, ptr %t520, 1
  %t524 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %s21, ptr %s21, { i64, ptr } %t522, i64 6, i8 32)
  store { i64, ptr } %t524, ptr %l234
  br label %bb110
bb110:
  %t525 = load ptr, ptr %l2, !tbaa !29
  %t527 = getelementptr %"compiler/profile:Places", ptr %t525, i32 0, i32 0
  %t528 = load i64, ptr %l26, !tbaa !24
  %t531 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %v2, ptr %t527, i64 %t528)
  store { i64, ptr } %t531, ptr %l238
  br label %bb111
bb111:
  %t532 = load { i64, ptr }, ptr %l238, !tbaa !27
  %t533 = call { i64, ptr } @compiler_2fprofile_2eshortPath(ptr %v2, ptr %s21, { i64, ptr } %t532)
  store { i64, ptr } %t533, ptr %l239
  br label %bb112
bb112:
  %t534 = load { i64, ptr }, ptr %l239, !tbaa !27
  %t535 = extractvalue { i64, ptr } %t534, 0
  %t536 = extractvalue { i64, ptr } %t534, 1
  %t537 = mul i64 %t535, 1
  %t538 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t537)
  call void @llvm.memcpy.p0.p0.i64(ptr %t538, ptr %t536, i64 %t537, i1 false)
  %t539 = insertvalue { i64, ptr } undef, i64 %t535, 0
  %t540 = insertvalue { i64, ptr } %t539, ptr %t538, 1
  %t541 = load i64, ptr %l20, !tbaa !24
  %t544 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadEnd(ptr %s21, ptr %s21, { i64, ptr } %t540, i64 %t541, i8 32)
  store { i64, ptr } %t544, ptr %l242
  br label %bb113
bb113:
  %t545 = load ptr, ptr %l2, !tbaa !29
  %t547 = getelementptr %"compiler/profile:Places", ptr %t545, i32 0, i32 0
  %t548 = load i64, ptr %l28, !tbaa !24
  %t551 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %s21, ptr %t547, i64 %t548)
  store { i64, ptr } %t551, ptr %l246
  br label %bb114
bb114:
  %t552 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t553 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  %t554 = load { i64, ptr }, ptr %l234, !tbaa !27
  %t555 = extractvalue { i64, ptr } %t554, 1
  %t556 = extractvalue { i64, ptr } %t554, 0
  %t557 = add i64 %t553, %t556
  %t558 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t559 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t560 = add i64 %t557, %t559
  %t561 = load { i64, ptr }, ptr %l242, !tbaa !27
  %t562 = extractvalue { i64, ptr } %t561, 1
  %t563 = extractvalue { i64, ptr } %t561, 0
  %t564 = add i64 %t560, %t563
  %t565 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t566 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t567 = add i64 %t564, %t566
  %t568 = load { i64, ptr }, ptr %l246, !tbaa !27
  %t569 = extractvalue { i64, ptr } %t568, 1
  %t570 = extractvalue { i64, ptr } %t568, 0
  %t571 = add i64 %t567, %t570
  %t572 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t573 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t574 = add i64 %t571, %t573
  %t575 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t574)
  call void @olang_textcopy(ptr %t575, ptr %t552, i64 %t553)
  %t576 = getelementptr i8, ptr %t575, i64 %t553
  call void @olang_textcopy(ptr %t576, ptr %t555, i64 %t556)
  %t577 = getelementptr i8, ptr %t576, i64 %t556
  call void @olang_textcopy(ptr %t577, ptr %t558, i64 %t559)
  %t578 = getelementptr i8, ptr %t577, i64 %t559
  call void @olang_textcopy(ptr %t578, ptr %t562, i64 %t563)
  %t579 = getelementptr i8, ptr %t578, i64 %t563
  call void @olang_textcopy(ptr %t579, ptr %t565, i64 %t566)
  %t580 = getelementptr i8, ptr %t579, i64 %t566
  call void @olang_textcopy(ptr %t580, ptr %t569, i64 %t570)
  %t581 = getelementptr i8, ptr %t580, i64 %t570
  call void @olang_textcopy(ptr %t581, ptr %t572, i64 %t573)
  %t582 = insertvalue { i64, ptr } undef, i64 %t574, 0
  %t583 = insertvalue { i64, ptr } %t582, ptr %t575, 1
  %t585 = extractvalue { i64, ptr } %t583, 0
  %t586 = extractvalue { i64, ptr } %t583, 1
  %t587 = mul i64 %t585, 1
  %t588 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t587)
  call void @llvm.memcpy.p0.p0.i64(ptr %t588, ptr %t586, i64 %t587, i1 false)
  %t589 = insertvalue { i64, ptr } undef, i64 %t585, 0
  %t590 = insertvalue { i64, ptr } %t589, ptr %t588, 1
  %t591 = load ptr, ptr %l229, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s21, ptr %t591, { i64, ptr } %t590)
  br label %bb115
bb115:
  call void @__olang_scope_close(ptr %s21)
  br label %bb116
bb116:
  %t593 = load i64, ptr %l25, !tbaa !24
  %t595 = add i64 %t593, 1
  store i64 %t595, ptr %l25, !tbaa !24
  br label %bb95
bb117:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l5, { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d61, i32 0, i32 1) })
  br label %bb118
bb118:
  store i64 0, ptr %l8, !tbaa !24
  store ptr %l7, ptr %l29, !tbaa !29
  store i64 0, ptr %l30, !tbaa !24
  br label %bb119
bb119:
  store %olang.scope zeroinitializer, ptr %s25
  %t599 = load i64, ptr %l30, !tbaa !24
  store i64 %t599, ptr %l253, !tbaa !24
  %t600 = load ptr, ptr %l29, !tbaa !29
  %t602 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t600)
  store i64 %t602, ptr %l255
  br label %bb120
bb120:
  %t603 = load i64, ptr %l253, !tbaa !24
  %t604 = load i64, ptr %l255, !tbaa !24
  %t605 = icmp slt i64 %t603, %t604
  %t607 = xor i1 %t605, true
  br i1 %t607, label %bb121, label %bb122
bb121:
  call void @__olang_scope_close(ptr %s25)
  br label %bb182
bb122:
  br label %bb123
bb123:
  %t609 = load ptr, ptr %l29, !tbaa !29
  %t610 = load i64, ptr %l30, !tbaa !24
  %t613 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t609, i64 %t610)
  store i64 %t613, ptr %l260
  br label %bb124
bb124:
  %t614 = load i64, ptr %l260, !tbaa !24
  store i64 %t614, ptr %l31, !tbaa !24
  %t615 = load i64, ptr %l8, !tbaa !24
  %t617 = icmp sge i64 %t615, 5
  br i1 %t617, label %bb125, label %bb126
bb125:
  call void @__olang_scope_close(ptr %s25)
  br label %bb182
bb126:
  br label %bb127
bb127:
  %t619 = getelementptr %"compiler/profile:Tally", ptr %l3, i32 0, i32 0
  %t620 = load i64, ptr %l31, !tbaa !24
  %t623 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %s0, ptr %t619, i64 %t620)
  %t624 = extractvalue { i32, i64 } %t623, 1
  %t625 = extractvalue { i32, i64 } %t623, 0
  store i32 %t625, ptr %l267
  %t626 = icmp ne i32 %t625, 0
  br i1 %t626, label %bb129, label %ok.627, !prof !99
ok.627:
  store i64 %t624, ptr %l266
  br label %bb128
bb128:
  %t628 = load i64, ptr %l266, !tbaa !24
  store i64 %t628, ptr %l263, !tbaa !24
  br label %bb131
bb129:
  br label %bb130
bb130:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l263, !tbaa !24
  br label %bb131
bb131:
  %t629 = load i64, ptr %l263, !tbaa !24
  %t632 = icmp eq i64 %t629, 0
  br i1 %t632, label %bb132, label %bb133
bb132:
  call void @__olang_scope_close(ptr %s25)
  br label %bb182
bb133:
  br label %bb134
bb134:
  %t634 = load i64, ptr %l8, !tbaa !24
  %t636 = add i64 %t634, 1
  store i64 %t636, ptr %l8, !tbaa !24
  %t638 = getelementptr %"compiler/profile:Tally", ptr %l3, i32 0, i32 1
  %t639 = load i64, ptr %l31, !tbaa !24
  %t642 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %s0, ptr %t638, i64 %t639)
  %t643 = extractvalue { i32, i64 } %t642, 1
  %t644 = extractvalue { i32, i64 } %t642, 0
  store i32 %t644, ptr %l276
  %t645 = icmp ne i32 %t644, 0
  br i1 %t645, label %bb136, label %ok.646, !prof !99
ok.646:
  store i64 %t643, ptr %l275
  br label %bb135
bb135:
  %t647 = load i64, ptr %l275, !tbaa !24
  store i64 %t647, ptr %l272, !tbaa !24
  br label %bb138
bb136:
  br label %bb137
bb137:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l272, !tbaa !24
  br label %bb138
bb138:
  %t648 = load i64, ptr %l272, !tbaa !24
  store i64 %t648, ptr %l33, !tbaa !24
  %t649 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s25, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t649, ptr %l277
  br label %bb139
bb139:
  %t650 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l277
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t650, ptr %l34
  %t651 = getelementptr %"compiler/profile:Tally", ptr %l3, i32 0, i32 5
  store ptr %t651, ptr %l35, !tbaa !29
  store i64 0, ptr %l36, !tbaa !24
  br label %bb140
bb140:
  %t653 = load i64, ptr %l36, !tbaa !24
  store i64 %t653, ptr %l279, !tbaa !24
  %t654 = load ptr, ptr %l35, !tbaa !29
  %t656 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t654)
  store i64 %t656, ptr %l281
  br label %bb141
bb141:
  %t657 = load i64, ptr %l279, !tbaa !24
  %t658 = load i64, ptr %l281, !tbaa !24
  %t659 = icmp slt i64 %t657, %t658
  %t661 = xor i1 %t659, true
  br i1 %t661, label %bb142, label %bb143
bb142:
  br label %bb152
bb143:
  br label %bb144
bb144:
  %t663 = load ptr, ptr %l35, !tbaa !29
  %t664 = load i64, ptr %l36, !tbaa !24
  %t667 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t663, i64 %t664)
  store i64 %t667, ptr %l286
  br label %bb145
bb145:
  %t668 = load i64, ptr %l286, !tbaa !24
  store i64 %t668, ptr %l37, !tbaa !24
  %t669 = getelementptr %"compiler/profile:Tally", ptr %l3, i32 0, i32 4
  %t670 = load i64, ptr %l31, !tbaa !24
  %t672 = mul i64 %t670, 16777216
  %t673 = load i64, ptr %l37, !tbaa !24
  %t676 = add i64 %t672, %t673
  %t679 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %s0, ptr %t669, i64 %t676)
  store i1 %t679, ptr %l292
  br label %bb146
bb146:
  %t680 = load i1, ptr %l292, !tbaa !21
  br i1 %t680, label %bb147, label %bb148
bb147:
  %t681 = load i64, ptr %l37, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s25, ptr %l34, i64 %t681)
  br label %bb149
bb148:
  br label %bb150
bb149:
  br label %bb150
bb150:
  br label %bb151
bb151:
  %t684 = load i64, ptr %l36, !tbaa !24
  %t686 = add i64 %t684, 1
  store i64 %t686, ptr %l36, !tbaa !24
  br label %bb140
bb152:
  call void @llvm.memmove.p0.p0.i64(ptr %l298, ptr %l3, i64 424, i1 false)
  %t688 = load i64, ptr %l31, !tbaa !24
  %t689 = load ptr, ptr %l2, !tbaa !29
  %t690 = getelementptr { %"compiler/profile:Tally", i64, ptr, ptr, ptr }, ptr null, i32 1
  %t691 = ptrtoint ptr %t690 to i64
  %t693 = getelementptr { %"compiler/profile:Tally", i64, ptr, ptr, ptr }, ptr %t692, i32 0, i32 0
  call void @llvm.memmove.p0.p0.i64(ptr %t693, ptr %l298, i64 424, i1 false)
  %t694 = getelementptr { %"compiler/profile:Tally", i64, ptr, ptr, ptr }, ptr %t692, i32 0, i32 1
  store i64 %t688, ptr %t694, !tbaa !28
  %t696 = getelementptr { %"compiler/profile:Tally", i64, ptr, ptr, ptr }, ptr %t692, i32 0, i32 2
  store ptr %t689, ptr %t696, !tbaa !28
  call void @__olang_scope_escape(ptr %s0)
  %t698 = getelementptr { %"compiler/profile:Tally", i64, ptr, ptr, ptr }, ptr %t692, i32 0, i32 3
  store ptr %s0, ptr %t698, !tbaa !28
  call void @__olang_scope_escape(ptr %v2)
  %t699 = getelementptr { %"compiler/profile:Tally", i64, ptr, ptr, ptr }, ptr %t692, i32 0, i32 4
  store ptr %v2, ptr %t699, !tbaa !28
  %t700 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_62, 0
  %t701 = insertvalue { ptr, ptr } %t700, ptr %t692, 1
  %t704 = extractvalue { ptr, ptr } %t701, 0
  %t705 = extractvalue { ptr, ptr } %t701, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %s25, ptr %s25, ptr %l34, ptr %t704, ptr %t705)
  br label %bb153
bb153:
  %t706 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s25, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t706, ptr %l302
  br label %bb154
bb154:
  %t707 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l302
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t707, ptr %l38
  store ptr %l34, ptr %l39, !tbaa !29
  store i64 0, ptr %l40, !tbaa !24
  br label %bb155
bb155:
  store %olang.scope zeroinitializer, ptr %s33
  %t709 = load i64, ptr %l40, !tbaa !24
  store i64 %t709, ptr %l304, !tbaa !24
  %t710 = load ptr, ptr %l39, !tbaa !29
  %t712 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s25, ptr %t710)
  store i64 %t712, ptr %l306
  br label %bb156
bb156:
  %t713 = load i64, ptr %l304, !tbaa !24
  %t714 = load i64, ptr %l306, !tbaa !24
  %t715 = icmp slt i64 %t713, %t714
  %t717 = xor i1 %t715, true
  br i1 %t717, label %bb157, label %bb158
bb157:
  call void @__olang_scope_close(ptr %s33)
  br label %bb173
bb158:
  br label %bb159
bb159:
  %t719 = load ptr, ptr %l39, !tbaa !29
  %t720 = load i64, ptr %l40, !tbaa !24
  %t723 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s25, ptr %t719, i64 %t720)
  store i64 %t723, ptr %l311
  br label %bb160
bb160:
  %t724 = load i64, ptr %l311, !tbaa !24
  store i64 %t724, ptr %l41, !tbaa !24
  %t726 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s25, ptr %l38)
  store i64 %t726, ptr %l313
  br label %bb161
bb161:
  %t727 = load i64, ptr %l313, !tbaa !24
  %t728 = icmp sge i64 %t727, 4
  br i1 %t728, label %bb162, label %bb163
bb162:
  call void @__olang_scope_close(ptr %s33)
  br label %bb173
bb163:
  br label %bb164
bb164:
  store ptr %l38, ptr %l315, !tbaa !29
  %t730 = load ptr, ptr %l2, !tbaa !29
  %t732 = getelementptr %"compiler/profile:Places", ptr %t730, i32 0, i32 0
  %t733 = load i64, ptr %l41, !tbaa !24
  %t736 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %s33, ptr %t732, i64 %t733)
  store { i64, ptr } %t736, ptr %l319
  br label %bb165
bb165:
  %t737 = getelementptr %"compiler/profile:Tally", ptr %l3, i32 0, i32 4
  %t738 = load i64, ptr %l31, !tbaa !24
  %t740 = mul i64 %t738, 16777216
  %t741 = load i64, ptr %l41, !tbaa !24
  %t744 = add i64 %t740, %t741
  %t747 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %s0, ptr %t737, i64 %t744)
  %t748 = extractvalue { i32, i64 } %t747, 1
  %t749 = extractvalue { i32, i64 } %t747, 0
  store i32 %t749, ptr %l327
  %t750 = icmp ne i32 %t749, 0
  br i1 %t750, label %bb167, label %ok.751, !prof !99
ok.751:
  store i64 %t748, ptr %l326
  br label %bb166
bb166:
  %t752 = load i64, ptr %l326, !tbaa !24
  store i64 %t752, ptr %l320, !tbaa !24
  br label %bb169
bb167:
  br label %bb168
bb168:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l320, !tbaa !24
  br label %bb169
bb169:
  %t753 = load i64, ptr %l33, !tbaa !24
  %t754 = load i64, ptr %l320, !tbaa !24
  %t756 = call { i64, ptr } @compiler_2fprofile_2epct(ptr %s33, i64 %t754, i64 %t753)
  store { i64, ptr } %t756, ptr %l329
  br label %bb170
bb170:
  %t757 = load { i64, ptr }, ptr %l319, !tbaa !27
  %t758 = extractvalue { i64, ptr } %t757, 1
  %t759 = extractvalue { i64, ptr } %t757, 0
  %t760 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t761 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  %t762 = add i64 %t759, %t761
  %t763 = load { i64, ptr }, ptr %l329, !tbaa !27
  %t764 = extractvalue { i64, ptr } %t763, 1
  %t765 = extractvalue { i64, ptr } %t763, 0
  %t766 = add i64 %t762, %t765
  %t767 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t766)
  call void @olang_textcopy(ptr %t767, ptr %t758, i64 %t759)
  %t768 = getelementptr i8, ptr %t767, i64 %t759
  call void @olang_textcopy(ptr %t768, ptr %t760, i64 %t761)
  %t769 = getelementptr i8, ptr %t768, i64 %t761
  call void @olang_textcopy(ptr %t769, ptr %t764, i64 %t765)
  %t770 = insertvalue { i64, ptr } undef, i64 %t766, 0
  %t771 = insertvalue { i64, ptr } %t770, ptr %t767, 1
  %t773 = extractvalue { i64, ptr } %t771, 0
  %t774 = extractvalue { i64, ptr } %t771, 1
  %t775 = mul i64 %t773, 1
  %t776 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t775)
  call void @llvm.memcpy.p0.p0.i64(ptr %t776, ptr %t774, i64 %t775, i1 false)
  %t777 = insertvalue { i64, ptr } undef, i64 %t773, 0
  %t778 = insertvalue { i64, ptr } %t777, ptr %t776, 1
  %t779 = load ptr, ptr %l315, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s25, ptr %s25, ptr %t779, { i64, ptr } %t778)
  br label %bb171
bb171:
  call void @__olang_scope_close(ptr %s33)
  br label %bb172
bb172:
  %t781 = load i64, ptr %l40, !tbaa !24
  %t783 = add i64 %t781, 1
  store i64 %t783, ptr %l40, !tbaa !24
  br label %bb155
bb173:
  store ptr %l5, ptr %l334, !tbaa !29
  %t785 = load ptr, ptr %l2, !tbaa !29
  %t787 = getelementptr %"compiler/profile:Places", ptr %t785, i32 0, i32 0
  %t788 = load i64, ptr %l31, !tbaa !24
  %t791 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %s25, ptr %t787, i64 %t788)
  store { i64, ptr } %t791, ptr %l338
  br label %bb174
bb174:
  %t793 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s25, ptr %l38)
  store i64 %t793, ptr %l340
  br label %bb175
bb175:
  %t794 = load i64, ptr %l340, !tbaa !24
  %t795 = icmp eq i64 %t794, 0
  br i1 %t795, label %bb176, label %bb177
bb176:
  store { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d64, i32 0, i32 1) }, ptr %l342, !tbaa !27
  br label %bb179
bb177:
  %t798 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s25, ptr %s25, ptr %s25, ptr %l38, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d65, i32 0, i32 1) })
  store { i64, ptr } %t798, ptr %l344
  br label %bb178
bb178:
  %t799 = load { i64, ptr }, ptr %l344, !tbaa !27
  %t800 = extractvalue { i64, ptr } %t799, 0
  %t801 = extractvalue { i64, ptr } %t799, 1
  %t802 = mul i64 %t800, 1
  %t803 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t802)
  call void @llvm.memcpy.p0.p0.i64(ptr %t803, ptr %t801, i64 %t802, i1 false)
  %t804 = insertvalue { i64, ptr } undef, i64 %t800, 0
  %t805 = insertvalue { i64, ptr } %t804, ptr %t803, 1
  store { i64, ptr } %t805, ptr %l342, !tbaa !27
  br label %bb179
bb179:
  %t807 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t808 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t809 = load { i64, ptr }, ptr %l338, !tbaa !27
  %t810 = extractvalue { i64, ptr } %t809, 1
  %t811 = extractvalue { i64, ptr } %t809, 0
  %t812 = add i64 %t808, %t811
  %t813 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t814 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t815 = add i64 %t812, %t814
  %t816 = load { i64, ptr }, ptr %l342, !tbaa !27
  %t817 = extractvalue { i64, ptr } %t816, 1
  %t818 = extractvalue { i64, ptr } %t816, 0
  %t819 = add i64 %t815, %t818
  %t820 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t821 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  %t822 = add i64 %t819, %t821
  %t823 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t822)
  call void @olang_textcopy(ptr %t823, ptr %t807, i64 %t808)
  %t824 = getelementptr i8, ptr %t823, i64 %t808
  call void @olang_textcopy(ptr %t824, ptr %t810, i64 %t811)
  %t825 = getelementptr i8, ptr %t824, i64 %t811
  call void @olang_textcopy(ptr %t825, ptr %t813, i64 %t814)
  %t826 = getelementptr i8, ptr %t825, i64 %t814
  call void @olang_textcopy(ptr %t826, ptr %t817, i64 %t818)
  %t827 = getelementptr i8, ptr %t826, i64 %t818
  call void @olang_textcopy(ptr %t827, ptr %t820, i64 %t821)
  %t828 = insertvalue { i64, ptr } undef, i64 %t822, 0
  %t829 = insertvalue { i64, ptr } %t828, ptr %t823, 1
  %t831 = extractvalue { i64, ptr } %t829, 0
  %t832 = extractvalue { i64, ptr } %t829, 1
  %t833 = mul i64 %t831, 1
  %t834 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t833)
  call void @llvm.memcpy.p0.p0.i64(ptr %t834, ptr %t832, i64 %t833, i1 false)
  %t835 = insertvalue { i64, ptr } undef, i64 %t831, 0
  %t836 = insertvalue { i64, ptr } %t835, ptr %t834, 1
  %t837 = load ptr, ptr %l334, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s25, ptr %t837, { i64, ptr } %t836)
  br label %bb180
bb180:
  call void @__olang_scope_close(ptr %s25)
  br label %bb181
bb181:
  %t839 = load i64, ptr %l30, !tbaa !24
  %t841 = add i64 %t839, 1
  store i64 %t841, ptr %l30, !tbaa !24
  br label %bb119
bb182:
  %t844 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v3, ptr %l5)
  store { i64, ptr } %t844, ptr %l351
  br label %bb183
bb183:
  %t845 = load { i64, ptr }, ptr %l351, !tbaa !27
  store { i64, ptr } %t845, ptr %l352, !tbaa !27
  %t846 = load { i64, ptr }, ptr %l352, !tbaa !27
  %t847 = extractvalue { i64, ptr } %t846, 0
  store i64 %t847, ptr %l353, !tbaa !24
  %t848 = load i64, ptr %l353, !tbaa !24
  %t849 = mul i64 %t848, 1
  %t850 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t849)
  %t851 = insertvalue { i64, ptr } undef, i64 %t848, 0
  %t852 = insertvalue { i64, ptr } %t851, ptr %t850, 1
  store { i64, ptr } %t852, ptr %l354, !tbaa !27
  %t853 = getelementptr { i64, ptr }, ptr %l354, i32 0, i32 1
  %t854 = load ptr, ptr %t853, !tbaa !27
  %t855 = getelementptr { i64, ptr }, ptr %l352, i32 0, i32 1
  %t856 = load ptr, ptr %t855, !tbaa !27
  %t857 = load i64, ptr %l353, !tbaa !24
  %t858 = mul i64 %t857, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t854, ptr %t856, i64 %t858, i1 false)
  %t859 = load { i64, ptr }, ptr %l354, !tbaa !27
  store { i64, ptr } %t859, ptr %l352, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t860 = load { i64, ptr }, ptr %l352, !tbaa !27
  store { i64, ptr } %t860, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fprofile_2eResolve(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %lp2 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca %"compiler/profile:Sample"
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca %"compiler/profile:mapping"
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca %"std/prelude/text:StringBuilder"
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca [3 x { i64, ptr }]
  %l44 = alloca %"std/os:Output"
  %l45 = alloca %"std/prelude/text:LineIter"
  %l47 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca { i64, ptr }
  %l58 = alloca { { i64, ptr }, i64 }
  %l59 = alloca { i64, ptr }
  %l60 = alloca i64
  %l63 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l65 = alloca %"compiler/profile:Places"
  %l68 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l69 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l70 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l73 = alloca i64
  %l75 = alloca i64
  %l80 = alloca %"compiler/profile:Sample"
  %l85 = alloca i64
  %l88 = alloca i64
  %l111 = alloca i64
  %l114 = alloca i64
  %l118 = alloca i1
  %l120 = alloca ptr
  %l121 = alloca i64
  %l123 = alloca i64
  %l130 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l131 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l133 = alloca i64
  %l135 = alloca i64
  %l140 = alloca i64
  %l141 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l143 = alloca i64
  %l144 = alloca { i64, ptr }
  %l146 = alloca i64
  %l148 = alloca i64
  %l153 = alloca %"compiler/profile:mapping"
  %l157 = alloca i1
  %l162 = alloca { i64, ptr }
  %l164 = alloca i64
  %l172 = alloca i1
  %l175 = alloca i1
  %l177 = alloca ptr
  %l180 = alloca { i64, ptr }
  %l182 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l183 = alloca ptr
  %l186 = alloca ptr
  %l187 = alloca i32
  %l188 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l191 = alloca i64
  %l195 = alloca i64
  %l198 = alloca i64
  %l216 = alloca i64
  %l219 = alloca i64
  %l221 = alloca i1
  %l222 = alloca i64
  %l225 = alloca i64
  %l229 = alloca i64
  %l232 = alloca i64
  %l235 = alloca i64
  %l236 = alloca i64
  %l240 = alloca i64
  %l254 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l256 = alloca i1
  %l258 = alloca %"std/prelude/text:StringBuilder"
  %l260 = alloca i64
  %l264 = alloca i64
  %l267 = alloca i64
  %l287 = alloca i64
  %l289 = alloca ptr
  %l292 = alloca { i64, ptr }
  %l295 = alloca i64
  %l296 = alloca i64
  %l297 = alloca i64
  %l298 = alloca i32
  %l299 = alloca { i64, ptr }
  %l308 = alloca %"std/os:Output"
  %l314 = alloca { i64, ptr }
  %l316 = alloca { i64, ptr }
  %l318 = alloca %"std/os:Output"
  %l319 = alloca i32
  %l321 = alloca i1
  %l322 = alloca %"std/os:Output"
  %l326 = alloca %"std/prelude/text:LineIter"
  %l327 = alloca { i64, ptr }
  %l329 = alloca { i64, ptr }
  %l330 = alloca i32
  %l332 = alloca i1
  %l337 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l339 = alloca i64
  %l343 = alloca i64
  %l346 = alloca i64
  %l364 = alloca ptr
  %l366 = alloca i64
  %l369 = alloca i64
  %l371 = alloca i1
  %l372 = alloca i64
  %l374 = alloca i64
  %l377 = alloca i64
  %l379 = alloca i64
  %l381 = alloca i1
  %l384 = alloca { i64, ptr }
  %l385 = alloca i1
  %l390 = alloca { i64, ptr }
  %l394 = alloca { i64, ptr }
  %l398 = alloca { { i64, ptr }, i64 }
  %l402 = alloca i1
  %l403 = alloca i1
  %l406 = alloca { i64, ptr }
  %l407 = alloca i1
  %l408 = alloca ptr
  %l411 = alloca { i64, ptr }
  %l412 = alloca i1
  %l414 = alloca ptr
  %l417 = alloca { i64, ptr }
  %l419 = alloca { i64, ptr }
  %l422 = alloca { i64, ptr }
  %l423 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l424 = alloca ptr
  %l425 = alloca ptr
  %l428 = alloca { i64, ptr }
  %l429 = alloca ptr
  %l430 = alloca i32
  %l431 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l433 = alloca ptr
  %l436 = alloca i64
  %l437 = alloca { i64, ptr }
  %l440 = alloca i1
  %l442 = alloca i1
  %l445 = alloca i64
  %l446 = alloca i64
  %l447 = alloca i64
  %l448 = alloca i32
  %l449 = alloca { i64, ptr }
  %l452 = alloca { i64, ptr }
  %l453 = alloca { i64, ptr }
  %l457 = alloca { i64, ptr }
  %l459 = alloca ptr
  %l462 = alloca i64
  %l465 = alloca i64
  %l467 = alloca %"compiler/profile:Frame"
  %l474 = alloca i1
  %l477 = alloca i64
  %l479 = alloca i1
  %l482 = alloca { i64, ptr }
  %l483 = alloca i1
  %l484 = alloca ptr
  %l487 = alloca { i64, ptr }
  %l488 = alloca i1
  %l490 = alloca ptr
  %l493 = alloca { i64, ptr }
  %l495 = alloca { i64, ptr }
  %l498 = alloca { i64, ptr }
  %l499 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l500 = alloca ptr
  %l501 = alloca ptr
  %l504 = alloca { i64, ptr }
  %l505 = alloca ptr
  %l506 = alloca i32
  %l507 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l509 = alloca ptr
  %l512 = alloca i64
  %l513 = alloca { i64, ptr }
  %l515 = alloca i1
  %l517 = alloca ptr
  %l518 = alloca ptr
  %l520 = alloca { i64, ptr }
  %l522 = alloca i64
  %l524 = alloca i64
  %l525 = alloca %"compiler/profile:Frame"
  %l530 = alloca { i64, ptr }
  %l531 = alloca i1
  %l533 = alloca { i64, ptr }
  %l536 = alloca { i64, ptr }
  %l537 = alloca { i64, ptr }
  %l538 = alloca ptr
  %l539 = alloca ptr
  %l542 = alloca i64
  %l543 = alloca i64
  %l544 = alloca i64
  %l545 = alloca i32
  %l546 = alloca { i64, ptr }
  %l550 = alloca i64
  %l552 = alloca i64
  %l553 = alloca %"compiler/profile:Frame"
  %l558 = alloca %"compiler/profile:Places"
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %s44 = alloca %olang.scope
  %s47 = alloca %olang.scope
  %s48 = alloca %olang.scope
  %s50 = alloca %olang.scope
  %s51 = alloca %olang.scope
  %t1 = alloca %"compiler/profile:Places", align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @compiler_2fprofile_3aPlaces_2ector(ptr %t1, ptr %v2)
  call void @llvm.memmove.p0.p0.i64(ptr %l65, ptr %t1, i64 272, i1 false)
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 272, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %t3, ptr %l65, i64 272, i1 false)
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/profile:Profile", ptr %t4, i32 0, i32 5
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fprofile_2emappings(ptr %v0, ptr %s0, { i64, ptr } %t7)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l68
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l68
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l3
  %t11 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_H672d76f1ccd7b9b901b64baf95956196(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t11, ptr %l69
  br label %bb3
bb3:
  %t12 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l69
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t12, ptr %l4
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l70
  br label %bb4
bb4:
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l70
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l5
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/profile:Profile", ptr %t15, i32 0, i32 3
  store ptr %t17, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb5
bb5:
  %t19 = load i64, ptr %l7, !tbaa !24
  store i64 %t19, ptr %l73, !tbaa !24
  %t20 = load ptr, ptr %l6, !tbaa !29
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2eLen_3ccompiler_2fprofile_3aSample_3e(ptr %v0, ptr %t20)
  store i64 %t22, ptr %l75
  br label %bb6
bb6:
  %t23 = load i64, ptr %l73, !tbaa !24
  %t24 = load i64, ptr %l75, !tbaa !24
  %t25 = icmp slt i64 %t23, %t24
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb7, label %bb8
bb7:
  br label %bb35
bb8:
  br label %bb9
bb9:
  %t29 = load ptr, ptr %l6, !tbaa !29
  %t30 = load i64, ptr %l7, !tbaa !24
  %t33 = call %"compiler/profile:Sample" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2eAt_3ccompiler_2fprofile_3aSample_3e(ptr %v0, ptr %t29, i64 %t30)
  store %"compiler/profile:Sample" %t33, ptr %l80
  br label %bb10
bb10:
  %t34 = load %"compiler/profile:Sample", ptr %l80
  store %"compiler/profile:Sample" %t34, ptr %l8
  store i64 0, ptr %l9, !tbaa !24
  %t35 = getelementptr %"compiler/profile:Sample", ptr %l8, i32 0, i32 2
  %t36 = load i64, ptr %t35, !tbaa !24
  store i64 %t36, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t38 = load i64, ptr %l10, !tbaa !24
  %t39 = load i64, ptr %l9, !tbaa !24
  %t42 = icmp sgt i64 %t38, %t39
  br i1 %t42, label %bb11, label %bb12
bb11:
  %t44 = load i64, ptr %l11, !tbaa !24
  %t46 = icmp sgt i64 %t44, 0
  br i1 %t46, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l85, !tbaa !24
  br label %bb16
bb13:
  %t48 = load i64, ptr %l10, !tbaa !24
  %t49 = load i64, ptr %l9, !tbaa !24
  %t52 = sub i64 %t48, %t49
  %t53 = load i64, ptr %l11, !tbaa !24
  %t56 = add i64 %t52, %t53
  %t58 = sub i64 %t56, 1
  %t59 = load i64, ptr %l11, !tbaa !24
  %t62 = sdiv i64 %t58, %t59
  store i64 %t62, ptr %l88, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l88, !tbaa !24
  br label %bb15
bb15:
  %t64 = load i64, ptr %l88, !tbaa !24
  store i64 %t64, ptr %l85, !tbaa !24
  br label %bb16
bb16:
  %t65 = load i64, ptr %l85, !tbaa !24
  store i64 %t65, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb17
bb17:
  %t66 = load i64, ptr %l13, !tbaa !24
  %t67 = load i64, ptr %l12, !tbaa !24
  %t70 = icmp slt i64 %t66, %t67
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb18, label %bb19
bb18:
  br label %bb33
bb19:
  br label %bb20
bb20:
  %t74 = load i64, ptr %l9, !tbaa !24
  %t75 = load i64, ptr %l13, !tbaa !24
  %t76 = load i64, ptr %l11, !tbaa !24
  %t79 = mul i64 %t75, %t76
  %t82 = add i64 %t74, %t79
  store i64 %t82, ptr %l14, !tbaa !24
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/profile:Profile", ptr %t84, i32 0, i32 4
  %t87 = getelementptr %"compiler/profile:Sample", ptr %l8, i32 0, i32 1
  %t88 = load i64, ptr %t87, !tbaa !24
  %t89 = load i64, ptr %l14, !tbaa !24
  %t92 = add i64 %t88, %t89
  %t95 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t86, i64 %t92)
  store i64 %t95, ptr %l111
  br label %bb21
bb21:
  %t96 = load i64, ptr %l14, !tbaa !24
  %t98 = icmp eq i64 %t96, 0
  br i1 %t98, label %bb22, label %bb23
bb22:
  store i64 0, ptr %l114, !tbaa !24
  br label %bb24
bb23:
  store i64 1, ptr %l114, !tbaa !24
  br label %bb24
bb24:
  %t100 = load i64, ptr %l111, !tbaa !24
  %t101 = load i64, ptr %l114, !tbaa !24
  %t102 = sub i64 %t100, %t101
  store i64 %t102, ptr %l15, !tbaa !24
  %t104 = load ptr, ptr %lp2
  %t105 = getelementptr %"compiler/profile:Places", ptr %t104, i32 0, i32 5
  %t106 = load i64, ptr %l15, !tbaa !24
  %t109 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v2, ptr %t105, i64 %t106)
  store i1 %t109, ptr %l118
  br label %bb25
bb25:
  %t110 = load i1, ptr %l118, !tbaa !21
  %t111 = xor i1 %t110, true
  br i1 %t111, label %bb26, label %bb27
bb26:
  %t113 = load ptr, ptr %lp2
  %t114 = getelementptr %"compiler/profile:Places", ptr %t113, i32 0, i32 5
  store ptr %t114, ptr %l120, !tbaa !29
  %t115 = load i64, ptr %l15, !tbaa !24
  store i64 %t115, ptr %l121, !tbaa !24
  %t117 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l5)
  store i64 %t117, ptr %l123
  br label %bb28
bb27:
  br label %bb31
bb28:
  %t118 = load ptr, ptr %l120, !tbaa !29
  %t119 = load i64, ptr %l121, !tbaa !24
  %t120 = load i64, ptr %l123, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v2, ptr %t118, i64 %t119, i64 %t120)
  br label %bb29
bb29:
  %t121 = load i64, ptr %l15, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l5, i64 %t121)
  br label %bb30
bb30:
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t124 = load i64, ptr %l13, !tbaa !24
  %t126 = add i64 %t124, 1
  store i64 %t126, ptr %l13, !tbaa !24
  br label %bb17
bb33:
  br label %bb34
bb34:
  %t128 = load i64, ptr %l7, !tbaa !24
  %t130 = add i64 %t128, 1
  store i64 %t130, ptr %l7, !tbaa !24
  br label %bb5
bb35:
  %t132 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t132, ptr %l130
  br label %bb36
bb36:
  %t133 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l130
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t133, ptr %l16
  %t134 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t134, ptr %l131
  br label %bb37
bb37:
  %t135 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l131
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t135, ptr %l17
  store ptr %l5, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s9
  %t137 = load i64, ptr %l19, !tbaa !24
  store i64 %t137, ptr %l133, !tbaa !24
  %t138 = load ptr, ptr %l18, !tbaa !29
  %t140 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t138)
  store i64 %t140, ptr %l135
  br label %bb39
bb39:
  %t141 = load i64, ptr %l133, !tbaa !24
  %t142 = load i64, ptr %l135, !tbaa !24
  %t143 = icmp slt i64 %t141, %t142
  %t145 = xor i1 %t143, true
  br i1 %t145, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s9)
  br label %bb103
bb41:
  br label %bb42
bb42:
  %t147 = load ptr, ptr %l18, !tbaa !29
  %t148 = load i64, ptr %l19, !tbaa !24
  %t151 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t147, i64 %t148)
  store i64 %t151, ptr %l140
  br label %bb43
bb43:
  %t152 = load i64, ptr %l140, !tbaa !24
  store i64 %t152, ptr %l20, !tbaa !24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d69, i32 0, i32 1) }, ptr %l141, !tbaa !27
  %t153 = load { i64, ptr }, ptr %l141, !tbaa !27
  store { i64, ptr } %t153, ptr %l142, !tbaa !27
  %t154 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t154, 0
  store i64 %t155, ptr %l143, !tbaa !24
  %t156 = load i64, ptr %l143, !tbaa !24
  %t157 = mul i64 %t156, 1
  %t158 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t157)
  %t159 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t158, 1
  store { i64, ptr } %t160, ptr %l144, !tbaa !27
  %t161 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr { i64, ptr }, ptr %l142, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !27
  %t165 = load i64, ptr %l143, !tbaa !24
  %t166 = mul i64 %t165, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t162, ptr %t164, i64 %t166, i1 false)
  %t167 = load { i64, ptr }, ptr %l144, !tbaa !27
  store { i64, ptr } %t167, ptr %l21, !tbaa !27
  store i64 -1, ptr %l22, !tbaa !24
  store ptr %l3, ptr %l23, !tbaa !29
  store i64 0, ptr %l24, !tbaa !24
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s11
  %t169 = load i64, ptr %l24, !tbaa !24
  store i64 %t169, ptr %l146, !tbaa !24
  %t170 = load ptr, ptr %l23, !tbaa !29
  %t172 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3amapping_3e_2eLen__Heb6545c4cbf57678e5e8a74f397c9583(ptr %s0, ptr %t170)
  store i64 %t172, ptr %l148
  br label %bb45
bb45:
  %t173 = load i64, ptr %l146, !tbaa !24
  %t174 = load i64, ptr %l148, !tbaa !24
  %t175 = icmp slt i64 %t173, %t174
  %t177 = xor i1 %t175, true
  br i1 %t177, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s11)
  br label %bb99
bb47:
  br label %bb48
bb48:
  %t179 = load ptr, ptr %l23, !tbaa !29
  %t180 = load i64, ptr %l24, !tbaa !24
  %t183 = call %"compiler/profile:mapping" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3amapping_3e_2eAt_3ccompiler_2fprofile_3amapping_3e(ptr %s0, ptr %s0, ptr %t179, i64 %t180)
  store %"compiler/profile:mapping" %t183, ptr %l153
  br label %bb49
bb49:
  %t184 = load %"compiler/profile:mapping", ptr %l153
  store %"compiler/profile:mapping" %t184, ptr %l25
  %t185 = load i64, ptr %l20, !tbaa !24
  %t186 = getelementptr %"compiler/profile:mapping", ptr %l25, i32 0, i32 0
  %t187 = load i64, ptr %t186, !tbaa !24
  %t190 = icmp slt i64 %t185, %t187
  br i1 %t190, label %bb50, label %bb51
bb50:
  store i1 true, ptr %l157, !tbaa !21
  br label %bb52
bb51:
  %t192 = load i64, ptr %l20, !tbaa !24
  %t193 = getelementptr %"compiler/profile:mapping", ptr %l25, i32 0, i32 1
  %t194 = load i64, ptr %t193, !tbaa !24
  %t197 = icmp sge i64 %t192, %t194
  store i1 %t197, ptr %l157, !tbaa !21
  br label %bb52
bb52:
  %t199 = load i1, ptr %l157, !tbaa !21
  br i1 %t199, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s11)
  br label %bb98
bb54:
  br label %bb55
bb55:
  %t200 = getelementptr %"compiler/profile:mapping", ptr %l25, i32 0, i32 3
  %t201 = load { i64, ptr }, ptr %t200, !tbaa !27
  %t203 = extractvalue { i64, ptr } %t201, 1
  %t204 = extractvalue { i64, ptr } %t201, 0
  %t205 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t204)
  call void @olang_textcopy(ptr %t205, ptr %t203, i64 %t204)
  %t206 = insertvalue { i64, ptr } undef, i64 %t204, 0
  %t207 = insertvalue { i64, ptr } %t206, ptr %t205, 1
  store { i64, ptr } %t207, ptr %l162, !tbaa !27
  %t208 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t209 = extractvalue { i64, ptr } %t208, 0
  %t210 = load { i64, ptr }, ptr %l162, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t210, 0
  store i64 %t211, ptr %l164, !tbaa !24
  %t213 = load i64, ptr %l164, !tbaa !24
  %t214 = icmp eq i64 %t209, %t213
  br i1 %t214, label %bb56, label %bb57
bb56:
  %t216 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = getelementptr { i64, ptr }, ptr %l162, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !27
  %t220 = load i64, ptr %l164, !tbaa !24
  %t221 = mul i64 %t220, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t217, ptr %t219, i64 %t221, i1 false)
  br label %bb58
bb57:
  %t222 = load { i64, ptr }, ptr %l162, !tbaa !27
  store { i64, ptr } %t222, ptr %l21, !tbaa !27
  br label %bb58
bb58:
  %t223 = load i64, ptr %l20, !tbaa !24
  %t224 = getelementptr %"compiler/profile:mapping", ptr %l25, i32 0, i32 0
  %t225 = load i64, ptr %t224, !tbaa !24
  %t228 = sub i64 %t223, %t225
  %t229 = getelementptr %"compiler/profile:mapping", ptr %l25, i32 0, i32 2
  %t230 = load i64, ptr %t229, !tbaa !24
  %t233 = add i64 %t228, %t230
  store i64 %t233, ptr %l26, !tbaa !24
  %t235 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t237 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s9, ptr %s11, { i64, ptr } %t235, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d70, i32 0, i32 1) })
  store i1 %t237, ptr %l172
  br label %bb59
bb59:
  %t238 = load i1, ptr %l172, !tbaa !21
  br i1 %t238, label %bb60, label %bb61
bb60:
  %t239 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t242 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H67bc384d82ac3ceb3fdc5d6d25b5f02a(ptr %s0, ptr %s9, ptr %l4, { i64, ptr } %t239)
  store i1 %t242, ptr %l175
  br label %bb62
bb61:
  br label %bb97
bb62:
  %t243 = load i1, ptr %l175, !tbaa !21
  %t244 = xor i1 %t243, true
  br i1 %t244, label %bb63, label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s15
  store ptr %l4, ptr %l177, !tbaa !29
  %t246 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t248 = extractvalue { i64, ptr } %t246, 1
  %t249 = extractvalue { i64, ptr } %t246, 0
  %t250 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t249)
  call void @olang_textcopy(ptr %t250, ptr %t248, i64 %t249)
  %t251 = insertvalue { i64, ptr } undef, i64 %t249, 0
  %t252 = insertvalue { i64, ptr } %t251, ptr %t250, 1
  %t254 = extractvalue { i64, ptr } %t252, 0
  %t255 = extractvalue { i64, ptr } %t252, 1
  %t256 = mul i64 %t254, 1
  %t257 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t256)
  call void @llvm.memcpy.p0.p0.i64(ptr %t257, ptr %t255, i64 %t256, i1 false)
  %t258 = insertvalue { i64, ptr } undef, i64 %t254, 0
  %t259 = insertvalue { i64, ptr } %t258, ptr %t257, 1
  store { i64, ptr } %t259, ptr %l180, !tbaa !27
  %t260 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t262 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fprofile_2esegments(ptr %s9, ptr %s15, { i64, ptr } %t260)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t262, ptr %l182
  br label %bb65
bb64:
  br label %bb67
bb65:
  %t263 = load ptr, ptr %l177, !tbaa !29
  %t264 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t265 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l182
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Hd2a6d6393d72da4a22d0070783b9e545(ptr %s0, ptr %s0, ptr %s15, ptr %t263, { i64, ptr } %t264, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t265)
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s15)
  br label %bb67
bb67:
  %t266 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t269 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H613fddb0939c6e46b95f2b1f68ba1bdb(ptr %s0, ptr %s9, ptr %s0, ptr %l4, { i64, ptr } %t266)
  %t270 = extractvalue { i32, ptr } %t269, 1
  %t271 = extractvalue { i32, ptr } %t269, 0
  store i32 %t271, ptr %l187
  %t272 = icmp ne i32 %t271, 0
  br i1 %t272, label %bb69, label %ok.273, !prof !99
ok.273:
  store ptr %t270, ptr %l186
  br label %bb68
bb68:
  %t274 = load ptr, ptr %l186, !tbaa !29
  store ptr %t274, ptr %l183, !tbaa !29
  br label %bb72
bb69:
  br label %bb70
bb70:
  call void @__olang_ert_req_clear()
  %t275 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t275, ptr %l188
  br label %bb71
bb71:
  %t276 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l188
  %t277 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t276, ptr %t277
  store ptr %t277, ptr %l183, !tbaa !29
  br label %bb72
bb72:
  %t279 = load ptr, ptr %l183, !tbaa !29
  store ptr %t279, ptr %l27, !tbaa !29
  store i64 0, ptr %l28, !tbaa !24
  %t280 = load ptr, ptr %l27, !tbaa !29
  %t282 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t280)
  store i64 %t282, ptr %l191
  br label %bb73
bb73:
  %t283 = load i64, ptr %l191, !tbaa !24
  store i64 %t283, ptr %l29, !tbaa !24
  store i64 3, ptr %l30, !tbaa !24
  %t284 = load i64, ptr %l29, !tbaa !24
  %t285 = load i64, ptr %l28, !tbaa !24
  %t288 = icmp sgt i64 %t284, %t285
  br i1 %t288, label %bb74, label %bb75
bb74:
  %t290 = load i64, ptr %l30, !tbaa !24
  %t292 = icmp sgt i64 %t290, 0
  br i1 %t292, label %bb76, label %bb77
bb75:
  store i64 0, ptr %l195, !tbaa !24
  br label %bb79
bb76:
  %t294 = load i64, ptr %l29, !tbaa !24
  %t295 = load i64, ptr %l28, !tbaa !24
  %t298 = sub i64 %t294, %t295
  %t299 = load i64, ptr %l30, !tbaa !24
  %t302 = add i64 %t298, %t299
  %t304 = sub i64 %t302, 1
  %t305 = load i64, ptr %l30, !tbaa !24
  %t308 = sdiv i64 %t304, %t305
  store i64 %t308, ptr %l198, !tbaa !24
  br label %bb78
bb77:
  store i64 0, ptr %l198, !tbaa !24
  br label %bb78
bb78:
  %t310 = load i64, ptr %l198, !tbaa !24
  store i64 %t310, ptr %l195, !tbaa !24
  br label %bb79
bb79:
  %t311 = load i64, ptr %l195, !tbaa !24
  store i64 %t311, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  br label %bb80
bb80:
  %t312 = load i64, ptr %l32, !tbaa !24
  %t313 = load i64, ptr %l31, !tbaa !24
  %t316 = icmp slt i64 %t312, %t313
  %t318 = xor i1 %t316, true
  br i1 %t318, label %bb81, label %bb82
bb81:
  br label %bb96
bb82:
  br label %bb83
bb83:
  %t320 = load i64, ptr %l28, !tbaa !24
  %t321 = load i64, ptr %l32, !tbaa !24
  %t322 = load i64, ptr %l30, !tbaa !24
  %t325 = mul i64 %t321, %t322
  %t328 = add i64 %t320, %t325
  store i64 %t328, ptr %l33, !tbaa !24
  %t330 = load i64, ptr %l26, !tbaa !24
  store i64 %t330, ptr %l216, !tbaa !24
  %t331 = load ptr, ptr %l27, !tbaa !29
  %t332 = load i64, ptr %l33, !tbaa !24
  %t335 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t331, i64 %t332)
  store i64 %t335, ptr %l219
  br label %bb84
bb84:
  %t336 = load i64, ptr %l216, !tbaa !24
  %t337 = load i64, ptr %l219, !tbaa !24
  %t338 = icmp sge i64 %t336, %t337
  br i1 %t338, label %bb85, label %bb86
bb85:
  %t340 = load i64, ptr %l26, !tbaa !24
  store i64 %t340, ptr %l222, !tbaa !24
  %t341 = load ptr, ptr %l27, !tbaa !29
  %t342 = load i64, ptr %l33, !tbaa !24
  %t345 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t341, i64 %t342)
  store i64 %t345, ptr %l225
  br label %bb87
bb86:
  store i1 false, ptr %l221, !tbaa !21
  br label %bb89
bb87:
  %t346 = load ptr, ptr %l27, !tbaa !29
  %t347 = load i64, ptr %l33, !tbaa !24
  %t349 = add i64 %t347, 1
  %t352 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t346, i64 %t349)
  store i64 %t352, ptr %l229
  br label %bb88
bb88:
  %t353 = load i64, ptr %l225, !tbaa !24
  %t354 = load i64, ptr %l229, !tbaa !24
  %t355 = add i64 %t353, %t354
  %t356 = load i64, ptr %l222, !tbaa !24
  %t358 = icmp slt i64 %t356, %t355
  store i1 %t358, ptr %l221, !tbaa !21
  br label %bb89
bb89:
  %t360 = load i1, ptr %l221, !tbaa !21
  br i1 %t360, label %bb90, label %bb91
bb90:
  %t361 = load i64, ptr %l26, !tbaa !24
  store i64 %t361, ptr %l232, !tbaa !24
  %t362 = load ptr, ptr %l27, !tbaa !29
  %t363 = load i64, ptr %l33, !tbaa !24
  %t366 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t362, i64 %t363)
  store i64 %t366, ptr %l235
  br label %bb92
bb91:
  br label %bb94
bb92:
  %t367 = load i64, ptr %l232, !tbaa !24
  %t368 = load i64, ptr %l235, !tbaa !24
  %t369 = sub i64 %t367, %t368
  store i64 %t369, ptr %l236, !tbaa !24
  %t370 = load ptr, ptr %l27, !tbaa !29
  %t371 = load i64, ptr %l33, !tbaa !24
  %t373 = add i64 %t371, 2
  %t376 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t370, i64 %t373)
  store i64 %t376, ptr %l240
  br label %bb93
bb93:
  %t377 = load i64, ptr %l236, !tbaa !24
  %t378 = load i64, ptr %l240, !tbaa !24
  %t379 = add i64 %t377, %t378
  store i64 %t379, ptr %l22, !tbaa !24
  br label %bb94
bb94:
  br label %bb95
bb95:
  %t381 = load i64, ptr %l32, !tbaa !24
  %t383 = add i64 %t381, 1
  store i64 %t383, ptr %l32, !tbaa !24
  br label %bb80
bb96:
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s11)
  br label %bb99
bb98:
  %t385 = load i64, ptr %l24, !tbaa !24
  %t387 = add i64 %t385, 1
  store i64 %t387, ptr %l24, !tbaa !24
  br label %bb44
bb99:
  %t389 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t391 = extractvalue { i64, ptr } %t389, 1
  %t392 = extractvalue { i64, ptr } %t389, 0
  %t393 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t392)
  call void @olang_textcopy(ptr %t393, ptr %t391, i64 %t392)
  %t394 = insertvalue { i64, ptr } undef, i64 %t392, 0
  %t395 = insertvalue { i64, ptr } %t394, ptr %t393, 1
  %t397 = extractvalue { i64, ptr } %t395, 0
  %t398 = extractvalue { i64, ptr } %t395, 1
  %t399 = mul i64 %t397, 1
  %t400 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t399)
  call void @llvm.memcpy.p0.p0.i64(ptr %t400, ptr %t398, i64 %t399, i1 false)
  %t401 = insertvalue { i64, ptr } undef, i64 %t397, 0
  %t402 = insertvalue { i64, ptr } %t401, ptr %t400, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l16, { i64, ptr } %t402)
  br label %bb100
bb100:
  %t405 = load i64, ptr %l22, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l17, i64 %t405)
  br label %bb101
bb101:
  call void @__olang_scope_close(ptr %s9)
  br label %bb102
bb102:
  %t408 = load i64, ptr %l19, !tbaa !24
  %t410 = add i64 %t408, 1
  store i64 %t410, ptr %l19, !tbaa !24
  br label %bb38
bb103:
  %t412 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t412, ptr %l254
  br label %bb104
bb104:
  %t413 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l254
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t413, ptr %l34
  %t414 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t416 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t414, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d71, i32 0, i32 1) })
  store i1 %t416, ptr %l256
  br label %bb105
bb105:
  %t417 = load i1, ptr %l256, !tbaa !21
  %t418 = xor i1 %t417, true
  br i1 %t418, label %bb106, label %bb107
bb106:
  store %olang.scope zeroinitializer, ptr %s24
  %t420 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s24)
  store %"std/prelude/text:StringBuilder" %t420, ptr %l258
  br label %bb108
bb107:
  br label %bb153
bb108:
  %t421 = load %"std/prelude/text:StringBuilder", ptr %l258
  store %"std/prelude/text:StringBuilder" %t421, ptr %l35
  store i64 0, ptr %l36, !tbaa !24
  store i64 0, ptr %l37, !tbaa !24
  %t423 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l5)
  store i64 %t423, ptr %l260
  br label %bb109
bb109:
  %t424 = load i64, ptr %l260, !tbaa !24
  store i64 %t424, ptr %l38, !tbaa !24
  store i64 1, ptr %l39, !tbaa !24
  %t425 = load i64, ptr %l38, !tbaa !24
  %t426 = load i64, ptr %l37, !tbaa !24
  %t429 = icmp sgt i64 %t425, %t426
  br i1 %t429, label %bb110, label %bb111
bb110:
  %t431 = load i64, ptr %l39, !tbaa !24
  %t433 = icmp sgt i64 %t431, 0
  br i1 %t433, label %bb112, label %bb113
bb111:
  store i64 0, ptr %l264, !tbaa !24
  br label %bb115
bb112:
  %t435 = load i64, ptr %l38, !tbaa !24
  %t436 = load i64, ptr %l37, !tbaa !24
  %t439 = sub i64 %t435, %t436
  %t440 = load i64, ptr %l39, !tbaa !24
  %t443 = add i64 %t439, %t440
  %t445 = sub i64 %t443, 1
  %t446 = load i64, ptr %l39, !tbaa !24
  %t449 = sdiv i64 %t445, %t446
  store i64 %t449, ptr %l267, !tbaa !24
  br label %bb114
bb113:
  store i64 0, ptr %l267, !tbaa !24
  br label %bb114
bb114:
  %t451 = load i64, ptr %l267, !tbaa !24
  store i64 %t451, ptr %l264, !tbaa !24
  br label %bb115
bb115:
  %t452 = load i64, ptr %l264, !tbaa !24
  store i64 %t452, ptr %l40, !tbaa !24
  store i64 0, ptr %l41, !tbaa !24
  br label %bb116
bb116:
  store %olang.scope zeroinitializer, ptr %s26
  %t453 = load i64, ptr %l41, !tbaa !24
  %t454 = load i64, ptr %l40, !tbaa !24
  %t457 = icmp slt i64 %t453, %t454
  %t459 = xor i1 %t457, true
  br i1 %t459, label %bb117, label %bb118
bb117:
  call void @__olang_scope_close(ptr %s26)
  br label %bb131
bb118:
  br label %bb119
bb119:
  %t461 = load i64, ptr %l37, !tbaa !24
  %t462 = load i64, ptr %l41, !tbaa !24
  %t463 = load i64, ptr %l39, !tbaa !24
  %t466 = mul i64 %t462, %t463
  %t469 = add i64 %t461, %t466
  store i64 %t469, ptr %l42, !tbaa !24
  %t471 = load i64, ptr %l42, !tbaa !24
  %t474 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l17, i64 %t471)
  store i64 %t474, ptr %l287
  br label %bb120
bb120:
  %t475 = load i64, ptr %l287, !tbaa !24
  %t476 = icmp slt i64 %t475, 0
  br i1 %t476, label %bb121, label %bb122
bb121:
  call void @__olang_scope_close(ptr %s26)
  br label %bb130
bb122:
  br label %bb123
bb123:
  store ptr %l35, ptr %l289, !tbaa !29
  %t478 = load i64, ptr %l42, !tbaa !24
  %t481 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s26, ptr %l16, i64 %t478)
  store { i64, ptr } %t481, ptr %l292
  br label %bb124
bb124:
  %t482 = load i64, ptr %l42, !tbaa !24
  %t485 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l17, i64 %t482)
  store i64 %t485, ptr %l295
  br label %bb125
bb125:
  %t486 = load i64, ptr %l295, !tbaa !24
  store i64 %t486, ptr %l296, !tbaa !65
  %t487 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s26, i64 16)
  %t488 = extractvalue { i32, i64 } %t487, 1
  %t489 = extractvalue { i32, i64 } %t487, 0
  store i32 %t489, ptr %l298
  %t490 = icmp ne i32 %t489, 0
  br i1 %t490, label %bb127, label %ok.491, !prof !99
ok.491:
  store i64 %t488, ptr %l297
  br label %bb126
bb126:
  %t492 = load i64, ptr %l296, !tbaa !65
  %t493 = load i64, ptr %l297, !tbaa !24
  %t494 = call { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %s26, i64 %t492, i64 %t493)
  store { i64, ptr } %t494, ptr %l299
  br label %bb128
bb127:
  call void @__olang_check_failed(ptr @olang_loc_d50f4fab691edd32_66973f8664df657e)
  unreachable
bb128:
  %t495 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t496 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  %t497 = load { i64, ptr }, ptr %l292, !tbaa !27
  %t498 = extractvalue { i64, ptr } %t497, 1
  %t499 = extractvalue { i64, ptr } %t497, 0
  %t500 = add i64 %t496, %t499
  %t501 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t502 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  %t503 = add i64 %t500, %t502
  %t504 = load { i64, ptr }, ptr %l299, !tbaa !27
  %t505 = extractvalue { i64, ptr } %t504, 1
  %t506 = extractvalue { i64, ptr } %t504, 0
  %t507 = add i64 %t503, %t506
  %t508 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t509 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t510 = add i64 %t507, %t509
  %t511 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t510)
  call void @olang_textcopy(ptr %t511, ptr %t495, i64 %t496)
  %t512 = getelementptr i8, ptr %t511, i64 %t496
  call void @olang_textcopy(ptr %t512, ptr %t498, i64 %t499)
  %t513 = getelementptr i8, ptr %t512, i64 %t499
  call void @olang_textcopy(ptr %t513, ptr %t501, i64 %t502)
  %t514 = getelementptr i8, ptr %t513, i64 %t502
  call void @olang_textcopy(ptr %t514, ptr %t505, i64 %t506)
  %t515 = getelementptr i8, ptr %t514, i64 %t506
  call void @olang_textcopy(ptr %t515, ptr %t508, i64 %t509)
  %t516 = insertvalue { i64, ptr } undef, i64 %t510, 0
  %t517 = insertvalue { i64, ptr } %t516, ptr %t511, 1
  %t519 = extractvalue { i64, ptr } %t517, 0
  %t520 = extractvalue { i64, ptr } %t517, 1
  %t521 = mul i64 %t519, 1
  %t522 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t521)
  call void @llvm.memcpy.p0.p0.i64(ptr %t522, ptr %t520, i64 %t521, i1 false)
  %t523 = insertvalue { i64, ptr } undef, i64 %t519, 0
  %t524 = insertvalue { i64, ptr } %t523, ptr %t522, 1
  %t525 = load ptr, ptr %l289, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s24, ptr %s26, ptr %t525, { i64, ptr } %t524)
  br label %bb129
bb129:
  %t527 = load i64, ptr %l36, !tbaa !24
  %t529 = add i64 %t527, 1
  store i64 %t529, ptr %l36, !tbaa !24
  call void @__olang_scope_close(ptr %s26)
  br label %bb130
bb130:
  %t531 = load i64, ptr %l41, !tbaa !24
  %t533 = add i64 %t531, 1
  store i64 %t533, ptr %l41, !tbaa !24
  br label %bb116
bb131:
  %t535 = load i64, ptr %l36, !tbaa !24
  %t537 = icmp sgt i64 %t535, 0
  br i1 %t537, label %bb132, label %bb133
bb132:
  store %olang.scope zeroinitializer, ptr %s30
  %t539 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t541 = extractvalue { i64, ptr } %t539, 1
  %t542 = extractvalue { i64, ptr } %t539, 0
  %t543 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t542)
  call void @olang_textcopy(ptr %t543, ptr %t541, i64 %t542)
  %t544 = insertvalue { i64, ptr } undef, i64 %t542, 0
  %t545 = insertvalue { i64, ptr } %t544, ptr %t543, 1
  %t547 = extractvalue { i64, ptr } %t545, 0
  %t548 = extractvalue { i64, ptr } %t545, 1
  %t549 = mul i64 %t547, 1
  %t550 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t549)
  call void @llvm.memcpy.p0.p0.i64(ptr %t550, ptr %t548, i64 %t549, i1 false)
  %t551 = insertvalue { i64, ptr } undef, i64 %t547, 0
  %t552 = insertvalue { i64, ptr } %t551, ptr %t550, 1
  %t554 = insertvalue [3 x { i64, ptr }] undef, { i64, ptr } %t552, 0
  %t555 = insertvalue [3 x { i64, ptr }] %t554, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d75, i32 0, i32 1) }, 1
  %t556 = insertvalue [3 x { i64, ptr }] %t555, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d76, i32 0, i32 1) }, 2
  store [3 x { i64, ptr }] %t556, ptr %l43
  %t559 = insertvalue { i64, ptr } undef, i64 3, 0
  %t560 = insertvalue { i64, ptr } %t559, ptr %l43, 1
  store { i64, ptr } %t560, ptr %l314, !tbaa !27
  %t562 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s24, ptr %s30, ptr %l35)
  store { i64, ptr } %t562, ptr %l316
  br label %bb134
bb133:
  br label %bb152
bb134:
  %t563 = load { i64, ptr }, ptr %l316, !tbaa !27
  %t564 = load { i64, ptr }, ptr %l314, !tbaa !27
  %t566 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s30, ptr %s30, ptr %s30, ptr %s30, { i64, ptr } %t564, { i64, ptr } %t563, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d77, i32 0, i32 1) })
  %t567 = extractvalue { i32, %"std/os:Output" } %t566, 1
  %t568 = extractvalue { i32, %"std/os:Output" } %t566, 0
  store i32 %t568, ptr %l319
  %t569 = icmp ne i32 %t568, 0
  br i1 %t569, label %bb136, label %ok.570, !prof !99
ok.570:
  store %"std/os:Output" %t567, ptr %l318
  br label %bb135
bb135:
  %t571 = load %"std/os:Output", ptr %l318
  store %"std/os:Output" %t571, ptr %l308
  br label %bb139
bb136:
  %t572 = load i32, ptr %l319, !tbaa !23
  %t573 = ashr i32 %t572, 16
  %t575 = icmp eq i32 %t573, 1
  store i1 %t575, ptr %l321, !tbaa !21
  br label %bb137
bb137:
  call void @__olang_ert_req_clear()
  %t576 = call %"std/os:Output" @std_2fos_3aOutput_2ector(ptr %s30, ptr %s30, ptr %s30, i32 1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d78, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d79, i32 0, i32 1) })
  store %"std/os:Output" %t576, ptr %l322
  br label %bb138
bb138:
  %t577 = load %"std/os:Output", ptr %l322
  store %"std/os:Output" %t577, ptr %l308
  br label %bb139
bb139:
  %t578 = load %"std/os:Output", ptr %l308
  store %"std/os:Output" %t578, ptr %l44
  %t579 = getelementptr %"std/os:Output", ptr %l44, i32 0, i32 0
  %t580 = load i32, ptr %t579, !tbaa !23
  %t582 = icmp eq i32 %t580, 0
  br i1 %t582, label %bb140, label %bb141
bb140:
  %t584 = getelementptr %"std/os:Output", ptr %l44, i32 0, i32 1
  %t585 = load { i64, ptr }, ptr %t584, !tbaa !27
  %t587 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %s30, ptr %s30, { i64, ptr } %t585)
  store %"std/prelude/text:LineIter" %t587, ptr %l326
  br label %bb142
bb141:
  br label %bb151
bb142:
  %t588 = load %"std/prelude/text:LineIter", ptr %l326
  store %"std/prelude/text:LineIter" %t588, ptr %l45
  br label %bb143
bb143:
  %t590 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %s30, ptr %s30, ptr %l45)
  %t591 = extractvalue { i32, { i64, ptr } } %t590, 1
  %t592 = extractvalue { i32, { i64, ptr } } %t590, 0
  store i32 %t592, ptr %l330
  %t593 = icmp ne i32 %t592, 0
  br i1 %t593, label %bb145, label %ok.594, !prof !99
ok.594:
  store { i64, ptr } %t591, ptr %l329
  br label %bb144
bb144:
  %t595 = load { i64, ptr }, ptr %l329, !tbaa !27
  store { i64, ptr } %t595, ptr %l327, !tbaa !27
  br label %bb147
bb145:
  %t596 = load i32, ptr %l330, !tbaa !23
  %t597 = ashr i32 %t596, 16
  %t599 = icmp eq i32 %t597, 1
  store i1 %t599, ptr %l332, !tbaa !21
  br label %bb146
bb146:
  call void @__olang_ert_req_clear()
  br label %bb150
bb147:
  %t600 = load { i64, ptr }, ptr %l327, !tbaa !27
  %t603 = extractvalue { i64, ptr } %t600, 1
  %t604 = extractvalue { i64, ptr } %t600, 0
  %t605 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t604)
  call void @olang_textcopy(ptr %t605, ptr %t603, i64 %t604)
  %t606 = insertvalue { i64, ptr } undef, i64 %t604, 0
  %t607 = insertvalue { i64, ptr } %t606, ptr %t605, 1
  %t609 = extractvalue { i64, ptr } %t607, 0
  %t610 = extractvalue { i64, ptr } %t607, 1
  %t611 = mul i64 %t609, 1
  %t612 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t611)
  call void @llvm.memcpy.p0.p0.i64(ptr %t612, ptr %t610, i64 %t611, i1 false)
  %t613 = insertvalue { i64, ptr } undef, i64 %t609, 0
  %t614 = insertvalue { i64, ptr } %t613, ptr %t612, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l34, { i64, ptr } %t614)
  br label %bb148
bb148:
  br label %bb149
bb149:
  br label %bb143
bb150:
  br label %bb151
bb151:
  call void @__olang_scope_close(ptr %s30)
  br label %bb152
bb152:
  call void @__olang_scope_close(ptr %s24)
  br label %bb153
bb153:
  %t617 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_H85afd28815ee4de4ef19d4ccaecd867e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t617, ptr %l337
  br label %bb154
bb154:
  %t618 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l337
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t618, ptr %l47
  store i64 0, ptr %l48, !tbaa !24
  store i64 0, ptr %l49, !tbaa !24
  %t620 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l5)
  store i64 %t620, ptr %l339
  br label %bb155
bb155:
  %t621 = load i64, ptr %l339, !tbaa !24
  store i64 %t621, ptr %l50, !tbaa !24
  store i64 1, ptr %l51, !tbaa !24
  %t622 = load i64, ptr %l50, !tbaa !24
  %t623 = load i64, ptr %l49, !tbaa !24
  %t626 = icmp sgt i64 %t622, %t623
  br i1 %t626, label %bb156, label %bb157
bb156:
  %t628 = load i64, ptr %l51, !tbaa !24
  %t630 = icmp sgt i64 %t628, 0
  br i1 %t630, label %bb158, label %bb159
bb157:
  store i64 0, ptr %l343, !tbaa !24
  br label %bb161
bb158:
  %t632 = load i64, ptr %l50, !tbaa !24
  %t633 = load i64, ptr %l49, !tbaa !24
  %t636 = sub i64 %t632, %t633
  %t637 = load i64, ptr %l51, !tbaa !24
  %t640 = add i64 %t636, %t637
  %t642 = sub i64 %t640, 1
  %t643 = load i64, ptr %l51, !tbaa !24
  %t646 = sdiv i64 %t642, %t643
  store i64 %t646, ptr %l346, !tbaa !24
  br label %bb160
bb159:
  store i64 0, ptr %l346, !tbaa !24
  br label %bb160
bb160:
  %t648 = load i64, ptr %l346, !tbaa !24
  store i64 %t648, ptr %l343, !tbaa !24
  br label %bb161
bb161:
  %t649 = load i64, ptr %l343, !tbaa !24
  store i64 %t649, ptr %l52, !tbaa !24
  store i64 0, ptr %l53, !tbaa !24
  br label %bb162
bb162:
  store %olang.scope zeroinitializer, ptr %s37
  %t650 = load i64, ptr %l53, !tbaa !24
  %t651 = load i64, ptr %l52, !tbaa !24
  %t654 = icmp slt i64 %t650, %t651
  %t656 = xor i1 %t654, true
  br i1 %t656, label %bb163, label %bb164
bb163:
  call void @__olang_scope_close(ptr %s37)
  br label %bb294
bb164:
  br label %bb165
bb165:
  %t658 = load i64, ptr %l49, !tbaa !24
  %t659 = load i64, ptr %l53, !tbaa !24
  %t660 = load i64, ptr %l51, !tbaa !24
  %t663 = mul i64 %t659, %t660
  %t666 = add i64 %t658, %t663
  store i64 %t666, ptr %l54, !tbaa !24
  %t668 = load ptr, ptr %lp2
  %t669 = getelementptr %"compiler/profile:Places", ptr %t668, i32 0, i32 3
  store ptr %t669, ptr %l364, !tbaa !29
  %t670 = load ptr, ptr %lp2
  %t671 = getelementptr %"compiler/profile:Places", ptr %t670, i32 0, i32 2
  %t673 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2eLen_3ccompiler_2fprofile_3aFrame_3e(ptr %v2, ptr %t671)
  store i64 %t673, ptr %l366
  br label %bb166
bb166:
  %t674 = load ptr, ptr %l364, !tbaa !29
  %t675 = load i64, ptr %l366, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t674, i64 %t675)
  br label %bb167
bb167:
  store i64 0, ptr %l55, !tbaa !24
  %t676 = load i64, ptr %l54, !tbaa !24
  %t679 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l17, i64 %t676)
  store i64 %t679, ptr %l369
  br label %bb168
bb168:
  %t680 = load i64, ptr %l369, !tbaa !24
  %t681 = icmp sge i64 %t680, 0
  br i1 %t681, label %bb169, label %bb170
bb169:
  %t683 = load i64, ptr %l48, !tbaa !24
  store i64 %t683, ptr %l372, !tbaa !24
  %t685 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l34)
  store i64 %t685, ptr %l374
  br label %bb171
bb170:
  store i1 false, ptr %l371, !tbaa !21
  br label %bb172
bb171:
  %t686 = load i64, ptr %l372, !tbaa !24
  %t687 = load i64, ptr %l374, !tbaa !24
  %t688 = icmp slt i64 %t686, %t687
  store i1 %t688, ptr %l371, !tbaa !21
  br label %bb172
bb172:
  %t690 = load i1, ptr %l371, !tbaa !21
  br i1 %t690, label %bb173, label %bb174
bb173:
  br label %bb175
bb174:
  br label %bb235
bb175:
  store %olang.scope zeroinitializer, ptr %s39
  %t691 = load i64, ptr %l48, !tbaa !24
  %t693 = add i64 %t691, 1
  store i64 %t693, ptr %l377, !tbaa !24
  %t695 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l34)
  store i64 %t695, ptr %l379
  br label %bb176
bb176:
  %t696 = load i64, ptr %l377, !tbaa !24
  %t697 = load i64, ptr %l379, !tbaa !24
  %t698 = icmp slt i64 %t696, %t697
  br i1 %t698, label %bb177, label %bb178
bb177:
  %t700 = load i64, ptr %l48, !tbaa !24
  %t703 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l34, i64 %t700)
  store { i64, ptr } %t703, ptr %l384
  br label %bb179
bb178:
  store i1 false, ptr %l381, !tbaa !21
  br label %bb181
bb179:
  %t704 = load { i64, ptr }, ptr %l384, !tbaa !27
  %t705 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s39, { i64, ptr } %t704, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d80, i32 0, i32 1) })
  store i1 %t705, ptr %l385
  br label %bb180
bb180:
  %t706 = load i1, ptr %l385, !tbaa !21
  %t707 = xor i1 %t706, true
  store i1 %t707, ptr %l381, !tbaa !21
  br label %bb181
bb181:
  %t709 = load i1, ptr %l381, !tbaa !21
  %t710 = xor i1 %t709, true
  br i1 %t710, label %bb182, label %bb183
bb182:
  call void @__olang_scope_close(ptr %s39)
  br label %bb234
bb183:
  br label %bb184
bb184:
  %t712 = load i64, ptr %l48, !tbaa !24
  %t715 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l34, i64 %t712)
  store { i64, ptr } %t715, ptr %l390
  br label %bb185
bb185:
  %t716 = load { i64, ptr }, ptr %l390, !tbaa !27
  store { i64, ptr } %t716, ptr %l56, !tbaa !27
  %t717 = load i64, ptr %l48, !tbaa !24
  %t719 = add i64 %t717, 1
  %t722 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l34, i64 %t719)
  store { i64, ptr } %t722, ptr %l394
  br label %bb186
bb186:
  %t723 = load { i64, ptr }, ptr %l394, !tbaa !27
  %t724 = load i64, ptr %l48, !tbaa !24
  %t726 = add i64 %t724, 2
  store i64 %t726, ptr %l48, !tbaa !24
  %t730 = call { { i64, ptr }, i64 } @compiler_2fprofile_2efileLine(ptr %s0, ptr %s39, { i64, ptr } %t723)
  store { { i64, ptr }, i64 } %t730, ptr %l398
  br label %bb187
bb187:
  %t731 = load { { i64, ptr }, i64 }, ptr %l398
  store { { i64, ptr }, i64 } %t731, ptr %l58
  %t732 = getelementptr { { i64, ptr }, i64 }, ptr %l58, i32 0, i32 0
  %t733 = load { i64, ptr }, ptr %t732, !tbaa !27
  store { i64, ptr } %t733, ptr %l59, !tbaa !27
  %t735 = getelementptr { { i64, ptr }, i64 }, ptr %l58, i32 0, i32 1
  %t736 = load i64, ptr %t735, !tbaa !24
  store i64 %t736, ptr %l60, !tbaa !24
  %t738 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t740 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s39, { i64, ptr } %t738, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d81, i32 0, i32 1) })
  store i1 %t740, ptr %l402
  br label %bb188
bb188:
  %t741 = load i1, ptr %l402, !tbaa !21
  br i1 %t741, label %bb189, label %bb190
bb189:
  %t742 = load i64, ptr %l54, !tbaa !24
  %t745 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l16, i64 %t742)
  store { i64, ptr } %t745, ptr %l406
  br label %bb191
bb190:
  store i1 false, ptr %l403, !tbaa !21
  br label %bb193
bb191:
  %t746 = load { i64, ptr }, ptr %l406, !tbaa !27
  %t747 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s39, { i64, ptr } %t746, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d82, i32 0, i32 1) })
  store i1 %t747, ptr %l407
  br label %bb192
bb192:
  %t748 = load i1, ptr %l407, !tbaa !21
  store i1 %t748, ptr %l403, !tbaa !21
  br label %bb193
bb193:
  %t749 = load i1, ptr %l403, !tbaa !21
  br i1 %t749, label %bb194, label %bb195
bb194:
  store %olang.scope zeroinitializer, ptr %s40
  store ptr %l47, ptr %l408, !tbaa !29
  %t750 = load i64, ptr %l54, !tbaa !24
  %t753 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l16, i64 %t750)
  store { i64, ptr } %t753, ptr %l411
  br label %bb196
bb195:
  br label %bb217
bb196:
  %t754 = load ptr, ptr %l408, !tbaa !29
  %t755 = load { i64, ptr }, ptr %l411, !tbaa !27
  %t756 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H509117e81ae737fb138b1f364b80e611(ptr %s0, ptr %s0, ptr %t754, { i64, ptr } %t755)
  store i1 %t756, ptr %l412
  br label %bb197
bb197:
  %t757 = load i1, ptr %l412, !tbaa !21
  %t758 = xor i1 %t757, true
  br i1 %t758, label %bb198, label %bb199
bb198:
  store %olang.scope zeroinitializer, ptr %s41
  store ptr %l47, ptr %l414, !tbaa !29
  %t760 = load i64, ptr %l54, !tbaa !24
  %t763 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s41, ptr %l16, i64 %t760)
  store { i64, ptr } %t763, ptr %l417
  br label %bb200
bb199:
  br label %bb204
bb200:
  %t764 = load { i64, ptr }, ptr %l417, !tbaa !27
  %t765 = extractvalue { i64, ptr } %t764, 1
  %t766 = extractvalue { i64, ptr } %t764, 0
  %t767 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t766)
  call void @olang_textcopy(ptr %t767, ptr %t765, i64 %t766)
  %t768 = insertvalue { i64, ptr } undef, i64 %t766, 0
  %t769 = insertvalue { i64, ptr } %t768, ptr %t767, 1
  %t771 = extractvalue { i64, ptr } %t769, 0
  %t772 = extractvalue { i64, ptr } %t769, 1
  %t773 = mul i64 %t771, 1
  %t774 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t773)
  call void @llvm.memcpy.p0.p0.i64(ptr %t774, ptr %t772, i64 %t773, i1 false)
  %t775 = insertvalue { i64, ptr } undef, i64 %t771, 0
  %t776 = insertvalue { i64, ptr } %t775, ptr %t774, 1
  store { i64, ptr } %t776, ptr %l419, !tbaa !27
  %t777 = load i64, ptr %l54, !tbaa !24
  %t780 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l16, i64 %t777)
  store { i64, ptr } %t780, ptr %l422
  br label %bb201
bb201:
  %t781 = load { i64, ptr }, ptr %l422, !tbaa !27
  %t782 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fprofile_2efunctionSymbols(ptr %s0, ptr %s0, { i64, ptr } %t781)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t782, ptr %l423
  br label %bb202
bb202:
  %t783 = load ptr, ptr %l414, !tbaa !29
  %t784 = load { i64, ptr }, ptr %l419, !tbaa !27
  %t785 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l423
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Hb4e1316c13adc554c531dbb9cf254a96(ptr %s0, ptr %s0, ptr %s0, ptr %t783, { i64, ptr } %t784, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t785)
  br label %bb203
bb203:
  call void @__olang_scope_close(ptr %s41)
  br label %bb204
bb204:
  store ptr %l47, ptr %l425, !tbaa !29
  %t786 = load i64, ptr %l54, !tbaa !24
  %t789 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l16, i64 %t786)
  store { i64, ptr } %t789, ptr %l428
  br label %bb205
bb205:
  %t790 = load ptr, ptr %l425, !tbaa !29
  %t791 = load { i64, ptr }, ptr %l428, !tbaa !27
  %t792 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Hfa095cf457cc3af0cc9715613212afd3(ptr %s0, ptr %s0, ptr %s0, ptr %t790, { i64, ptr } %t791)
  %t793 = extractvalue { i32, ptr } %t792, 1
  %t794 = extractvalue { i32, ptr } %t792, 0
  store i32 %t794, ptr %l430
  %t795 = icmp ne i32 %t794, 0
  br i1 %t795, label %bb207, label %ok.796, !prof !99
ok.796:
  store ptr %t793, ptr %l429
  br label %bb206
bb206:
  %t797 = load ptr, ptr %l429, !tbaa !29
  store ptr %t797, ptr %l424, !tbaa !29
  br label %bb210
bb207:
  br label %bb208
bb208:
  call void @__olang_ert_req_clear()
  %t798 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aelfFn_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t798, ptr %l431
  br label %bb209
bb209:
  %t799 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l431
  %t800 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t799, ptr %t800
  store ptr %t800, ptr %l424, !tbaa !29
  br label %bb210
bb210:
  %t802 = load ptr, ptr %l424, !tbaa !29
  store ptr %t802, ptr %l433, !tbaa !29
  %t804 = load i64, ptr %l54, !tbaa !24
  %t807 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l17, i64 %t804)
  store i64 %t807, ptr %l436
  br label %bb211
bb211:
  %t808 = load ptr, ptr %l433, !tbaa !29
  %t809 = load i64, ptr %l436, !tbaa !24
  %t810 = call { i64, ptr } @compiler_2fprofile_2esymbolAt(ptr %s0, ptr %s0, ptr %t808, i64 %t809)
  store { i64, ptr } %t810, ptr %l437
  br label %bb212
bb212:
  %t811 = load { i64, ptr }, ptr %l437, !tbaa !27
  %t812 = extractvalue { i64, ptr } %t811, 0
  %t813 = extractvalue { i64, ptr } %t811, 1
  %t814 = mul i64 %t812, 1
  %t815 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t814)
  call void @llvm.memcpy.p0.p0.i64(ptr %t815, ptr %t813, i64 %t814, i1 false)
  %t816 = insertvalue { i64, ptr } undef, i64 %t812, 0
  %t817 = insertvalue { i64, ptr } %t816, ptr %t815, 1
  store { i64, ptr } %t817, ptr %l56, !tbaa !27
  %t819 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t821 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s40, { i64, ptr } %t819, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d83, i32 0, i32 1) })
  store i1 %t821, ptr %l440
  br label %bb213
bb213:
  %t822 = load i1, ptr %l440, !tbaa !21
  br i1 %t822, label %bb214, label %bb215
bb214:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d84, i32 0, i32 1) }, ptr %l56, !tbaa !27
  br label %bb216
bb215:
  br label %bb216
bb216:
  call void @__olang_scope_close(ptr %s40)
  br label %bb217
bb217:
  %t823 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t825 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s39, { i64, ptr } %t823, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d85, i32 0, i32 1) })
  store i1 %t825, ptr %l442
  br label %bb218
bb218:
  %t826 = load i1, ptr %l442, !tbaa !21
  br i1 %t826, label %bb219, label %bb220
bb219:
  store %olang.scope zeroinitializer, ptr %s44
  %t827 = load i64, ptr %l54, !tbaa !24
  %t830 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l5, i64 %t827)
  store i64 %t830, ptr %l445
  br label %bb221
bb220:
  %t831 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t833 = call { i64, ptr } @compiler_2fprofile_2eReadable(ptr %s0, ptr %s0, { i64, ptr } %t831)
  store { i64, ptr } %t833, ptr %l457
  br label %bb227
bb221:
  %t834 = load i64, ptr %l445, !tbaa !24
  store i64 %t834, ptr %l446, !tbaa !65
  %t835 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s44, i64 16)
  %t836 = extractvalue { i32, i64 } %t835, 1
  %t837 = extractvalue { i32, i64 } %t835, 0
  store i32 %t837, ptr %l448
  %t838 = icmp ne i32 %t837, 0
  br i1 %t838, label %bb223, label %ok.839, !prof !99
ok.839:
  store i64 %t836, ptr %l447
  br label %bb222
bb222:
  %t840 = load i64, ptr %l446, !tbaa !65
  %t841 = load i64, ptr %l447, !tbaa !24
  %t842 = call { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %s44, i64 %t840, i64 %t841)
  store { i64, ptr } %t842, ptr %l449
  br label %bb224
bb223:
  call void @__olang_check_failed(ptr @olang_loc_a4addf443e3a86b3_5ebaaf6328319b7f)
  unreachable
bb224:
  %t843 = load i64, ptr %l54, !tbaa !24
  %t846 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l16, i64 %t843)
  store { i64, ptr } %t846, ptr %l452
  br label %bb225
bb225:
  %t847 = load { i64, ptr }, ptr %l452, !tbaa !27
  %t848 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %s0, ptr %s44, { i64, ptr } %t847)
  store { i64, ptr } %t848, ptr %l453
  br label %bb226
bb226:
  %t849 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d86, i32 0, i32 1) }, 1
  %t850 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d86, i32 0, i32 1) }, 0
  %t851 = load { i64, ptr }, ptr %l449, !tbaa !27
  %t852 = extractvalue { i64, ptr } %t851, 1
  %t853 = extractvalue { i64, ptr } %t851, 0
  %t854 = add i64 %t850, %t853
  %t855 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d87, i32 0, i32 1) }, 1
  %t856 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d87, i32 0, i32 1) }, 0
  %t857 = add i64 %t854, %t856
  %t858 = load { i64, ptr }, ptr %l453, !tbaa !27
  %t859 = extractvalue { i64, ptr } %t858, 1
  %t860 = extractvalue { i64, ptr } %t858, 0
  %t861 = add i64 %t857, %t860
  %t862 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d88, i32 0, i32 1) }, 1
  %t863 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d88, i32 0, i32 1) }, 0
  %t864 = add i64 %t861, %t863
  %t865 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t864)
  call void @olang_textcopy(ptr %t865, ptr %t849, i64 %t850)
  %t866 = getelementptr i8, ptr %t865, i64 %t850
  call void @olang_textcopy(ptr %t866, ptr %t852, i64 %t853)
  %t867 = getelementptr i8, ptr %t866, i64 %t853
  call void @olang_textcopy(ptr %t867, ptr %t855, i64 %t856)
  %t868 = getelementptr i8, ptr %t867, i64 %t856
  call void @olang_textcopy(ptr %t868, ptr %t859, i64 %t860)
  %t869 = getelementptr i8, ptr %t868, i64 %t860
  call void @olang_textcopy(ptr %t869, ptr %t862, i64 %t863)
  %t870 = insertvalue { i64, ptr } undef, i64 %t864, 0
  %t871 = insertvalue { i64, ptr } %t870, ptr %t865, 1
  %t873 = extractvalue { i64, ptr } %t871, 0
  %t874 = extractvalue { i64, ptr } %t871, 1
  %t875 = mul i64 %t873, 1
  %t876 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t875)
  call void @llvm.memcpy.p0.p0.i64(ptr %t876, ptr %t874, i64 %t875, i1 false)
  %t877 = insertvalue { i64, ptr } undef, i64 %t873, 0
  %t878 = insertvalue { i64, ptr } %t877, ptr %t876, 1
  store { i64, ptr } %t878, ptr %l56, !tbaa !27
  call void @__olang_scope_close(ptr %s44)
  br label %bb228
bb227:
  %t880 = load { i64, ptr }, ptr %l457, !tbaa !27
  %t881 = extractvalue { i64, ptr } %t880, 0
  %t882 = extractvalue { i64, ptr } %t880, 1
  %t883 = mul i64 %t881, 1
  %t884 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t883)
  call void @llvm.memcpy.p0.p0.i64(ptr %t884, ptr %t882, i64 %t883, i1 false)
  %t885 = insertvalue { i64, ptr } undef, i64 %t881, 0
  %t886 = insertvalue { i64, ptr } %t885, ptr %t884, 1
  store { i64, ptr } %t886, ptr %l56, !tbaa !27
  br label %bb228
bb228:
  %t888 = load ptr, ptr %lp2
  %t889 = getelementptr %"compiler/profile:Places", ptr %t888, i32 0, i32 2
  store ptr %t889, ptr %l459, !tbaa !29
  %t890 = load ptr, ptr %lp2
  %t891 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t894 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v2, ptr %s0, ptr %t890, { i64, ptr } %t891)
  store i64 %t894, ptr %l462
  br label %bb229
bb229:
  %t895 = load ptr, ptr %lp2
  %t896 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t899 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v2, ptr %s39, ptr %t895, { i64, ptr } %t896)
  store i64 %t899, ptr %l465
  br label %bb230
bb230:
  %t900 = load i64, ptr %l60, !tbaa !24
  %t901 = load i64, ptr %l462, !tbaa !24
  %t902 = load i64, ptr %l465, !tbaa !24
  %t904 = call %"compiler/profile:Frame" @compiler_2fprofile_3aFrame_2ector(ptr %s39, i64 %t901, i64 %t902, i64 %t900)
  store %"compiler/profile:Frame" %t904, ptr %l467
  br label %bb231
bb231:
  %t905 = load ptr, ptr %l459, !tbaa !29
  %t906 = load %"compiler/profile:Frame", ptr %l467
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2ePush_3ccompiler_2fprofile_3aFrame_3e(ptr %v2, ptr %t905, %"compiler/profile:Frame" %t906)
  br label %bb232
bb232:
  %t907 = load i64, ptr %l55, !tbaa !24
  %t909 = add i64 %t907, 1
  store i64 %t909, ptr %l55, !tbaa !24
  call void @__olang_scope_close(ptr %s39)
  br label %bb233
bb233:
  br label %bb175
bb234:
  %t911 = load i64, ptr %l48, !tbaa !24
  %t913 = add i64 %t911, 1
  store i64 %t913, ptr %l48, !tbaa !24
  br label %bb235
bb235:
  %t915 = load i64, ptr %l55, !tbaa !24
  %t917 = icmp eq i64 %t915, 0
  br i1 %t917, label %bb236, label %bb237
bb236:
  %t919 = load i64, ptr %l54, !tbaa !24
  %t922 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l17, i64 %t919)
  store i64 %t922, ptr %l477
  br label %bb238
bb237:
  store i1 false, ptr %l474, !tbaa !21
  br label %bb239
bb238:
  %t923 = load i64, ptr %l477, !tbaa !24
  %t924 = icmp sge i64 %t923, 0
  store i1 %t924, ptr %l474, !tbaa !21
  br label %bb239
bb239:
  %t926 = load i1, ptr %l474, !tbaa !21
  br i1 %t926, label %bb240, label %bb241
bb240:
  %t927 = load i64, ptr %l54, !tbaa !24
  %t930 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l16, i64 %t927)
  store { i64, ptr } %t930, ptr %l482
  br label %bb242
bb241:
  store i1 false, ptr %l479, !tbaa !21
  br label %bb244
bb242:
  %t931 = load { i64, ptr }, ptr %l482, !tbaa !27
  %t932 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s37, { i64, ptr } %t931, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d89, i32 0, i32 1) })
  store i1 %t932, ptr %l483
  br label %bb243
bb243:
  %t933 = load i1, ptr %l483, !tbaa !21
  store i1 %t933, ptr %l479, !tbaa !21
  br label %bb244
bb244:
  %t934 = load i1, ptr %l479, !tbaa !21
  br i1 %t934, label %bb245, label %bb246
bb245:
  store %olang.scope zeroinitializer, ptr %s47
  store ptr %l47, ptr %l484, !tbaa !29
  %t935 = load i64, ptr %l54, !tbaa !24
  %t938 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l16, i64 %t935)
  store { i64, ptr } %t938, ptr %l487
  br label %bb247
bb246:
  br label %bb273
bb247:
  %t939 = load ptr, ptr %l484, !tbaa !29
  %t940 = load { i64, ptr }, ptr %l487, !tbaa !27
  %t941 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H509117e81ae737fb138b1f364b80e611(ptr %s0, ptr %s0, ptr %t939, { i64, ptr } %t940)
  store i1 %t941, ptr %l488
  br label %bb248
bb248:
  %t942 = load i1, ptr %l488, !tbaa !21
  %t943 = xor i1 %t942, true
  br i1 %t943, label %bb249, label %bb250
bb249:
  store %olang.scope zeroinitializer, ptr %s48
  store ptr %l47, ptr %l490, !tbaa !29
  %t945 = load i64, ptr %l54, !tbaa !24
  %t948 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s48, ptr %l16, i64 %t945)
  store { i64, ptr } %t948, ptr %l493
  br label %bb251
bb250:
  br label %bb255
bb251:
  %t949 = load { i64, ptr }, ptr %l493, !tbaa !27
  %t950 = extractvalue { i64, ptr } %t949, 1
  %t951 = extractvalue { i64, ptr } %t949, 0
  %t952 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t951)
  call void @olang_textcopy(ptr %t952, ptr %t950, i64 %t951)
  %t953 = insertvalue { i64, ptr } undef, i64 %t951, 0
  %t954 = insertvalue { i64, ptr } %t953, ptr %t952, 1
  %t956 = extractvalue { i64, ptr } %t954, 0
  %t957 = extractvalue { i64, ptr } %t954, 1
  %t958 = mul i64 %t956, 1
  %t959 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t958)
  call void @llvm.memcpy.p0.p0.i64(ptr %t959, ptr %t957, i64 %t958, i1 false)
  %t960 = insertvalue { i64, ptr } undef, i64 %t956, 0
  %t961 = insertvalue { i64, ptr } %t960, ptr %t959, 1
  store { i64, ptr } %t961, ptr %l495, !tbaa !27
  %t962 = load i64, ptr %l54, !tbaa !24
  %t965 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l16, i64 %t962)
  store { i64, ptr } %t965, ptr %l498
  br label %bb252
bb252:
  %t966 = load { i64, ptr }, ptr %l498, !tbaa !27
  %t967 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fprofile_2efunctionSymbols(ptr %s0, ptr %s0, { i64, ptr } %t966)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t967, ptr %l499
  br label %bb253
bb253:
  %t968 = load ptr, ptr %l490, !tbaa !29
  %t969 = load { i64, ptr }, ptr %l495, !tbaa !27
  %t970 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l499
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Hb4e1316c13adc554c531dbb9cf254a96(ptr %s0, ptr %s0, ptr %s0, ptr %t968, { i64, ptr } %t969, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t970)
  br label %bb254
bb254:
  call void @__olang_scope_close(ptr %s48)
  br label %bb255
bb255:
  store ptr %l47, ptr %l501, !tbaa !29
  %t971 = load i64, ptr %l54, !tbaa !24
  %t974 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l16, i64 %t971)
  store { i64, ptr } %t974, ptr %l504
  br label %bb256
bb256:
  %t975 = load ptr, ptr %l501, !tbaa !29
  %t976 = load { i64, ptr }, ptr %l504, !tbaa !27
  %t977 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Hfa095cf457cc3af0cc9715613212afd3(ptr %s0, ptr %s0, ptr %s0, ptr %t975, { i64, ptr } %t976)
  %t978 = extractvalue { i32, ptr } %t977, 1
  %t979 = extractvalue { i32, ptr } %t977, 0
  store i32 %t979, ptr %l506
  %t980 = icmp ne i32 %t979, 0
  br i1 %t980, label %bb258, label %ok.981, !prof !99
ok.981:
  store ptr %t978, ptr %l505
  br label %bb257
bb257:
  %t982 = load ptr, ptr %l505, !tbaa !29
  store ptr %t982, ptr %l500, !tbaa !29
  br label %bb261
bb258:
  br label %bb259
bb259:
  call void @__olang_ert_req_clear()
  %t983 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aelfFn_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t983, ptr %l507
  br label %bb260
bb260:
  %t984 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l507
  %t985 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t984, ptr %t985
  store ptr %t985, ptr %l500, !tbaa !29
  br label %bb261
bb261:
  %t987 = load ptr, ptr %l500, !tbaa !29
  store ptr %t987, ptr %l509, !tbaa !29
  %t989 = load i64, ptr %l54, !tbaa !24
  %t992 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l17, i64 %t989)
  store i64 %t992, ptr %l512
  br label %bb262
bb262:
  %t993 = load ptr, ptr %l509, !tbaa !29
  %t994 = load i64, ptr %l512, !tbaa !24
  %t995 = call { i64, ptr } @compiler_2fprofile_2esymbolAt(ptr %s0, ptr %s47, ptr %t993, i64 %t994)
  store { i64, ptr } %t995, ptr %l513
  br label %bb263
bb263:
  %t996 = load { i64, ptr }, ptr %l513, !tbaa !27
  store { i64, ptr } %t996, ptr %l63, !tbaa !27
  %t997 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t999 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s47, ptr %s47, { i64, ptr } %t997, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d90, i32 0, i32 1) })
  store i1 %t999, ptr %l515
  br label %bb264
bb264:
  %t1000 = load i1, ptr %l515, !tbaa !21
  %t1001 = xor i1 %t1000, true
  br i1 %t1001, label %bb265, label %bb266
bb265:
  store %olang.scope zeroinitializer, ptr %s50
  %t1003 = load ptr, ptr %lp2
  %t1004 = getelementptr %"compiler/profile:Places", ptr %t1003, i32 0, i32 2
  store ptr %t1004, ptr %l517, !tbaa !29
  %t1005 = load ptr, ptr %lp2
  store ptr %t1005, ptr %l518, !tbaa !29
  %t1006 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t1008 = call { i64, ptr } @compiler_2fprofile_2eReadable(ptr %s47, ptr %s50, { i64, ptr } %t1006)
  store { i64, ptr } %t1008, ptr %l520
  br label %bb267
bb266:
  br label %bb272
bb267:
  %t1009 = load { i64, ptr }, ptr %l520, !tbaa !27
  %t1010 = extractvalue { i64, ptr } %t1009, 0
  %t1011 = extractvalue { i64, ptr } %t1009, 1
  %t1012 = mul i64 %t1010, 1
  %t1013 = call ptr @__olang_scope_alloc(ptr %s50, i64 %t1012)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1013, ptr %t1011, i64 %t1012, i1 false)
  %t1014 = insertvalue { i64, ptr } undef, i64 %t1010, 0
  %t1015 = insertvalue { i64, ptr } %t1014, ptr %t1013, 1
  %t1016 = load ptr, ptr %l518, !tbaa !29
  %t1018 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v2, ptr %s50, ptr %t1016, { i64, ptr } %t1015)
  store i64 %t1018, ptr %l522
  br label %bb268
bb268:
  %t1019 = load ptr, ptr %lp2
  %t1021 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v2, ptr %s50, ptr %t1019, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d91, i32 0, i32 1) })
  store i64 %t1021, ptr %l524
  br label %bb269
bb269:
  %t1022 = load i64, ptr %l522, !tbaa !24
  %t1023 = load i64, ptr %l524, !tbaa !24
  %t1024 = call %"compiler/profile:Frame" @compiler_2fprofile_3aFrame_2ector(ptr %s50, i64 %t1022, i64 %t1023, i64 0)
  store %"compiler/profile:Frame" %t1024, ptr %l525
  br label %bb270
bb270:
  %t1025 = load ptr, ptr %l517, !tbaa !29
  %t1026 = load %"compiler/profile:Frame", ptr %l525
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2ePush_3ccompiler_2fprofile_3aFrame_3e(ptr %v2, ptr %t1025, %"compiler/profile:Frame" %t1026)
  br label %bb271
bb271:
  store i64 1, ptr %l55, !tbaa !24
  call void @__olang_scope_close(ptr %s50)
  br label %bb272
bb272:
  call void @__olang_scope_close(ptr %s47)
  br label %bb273
bb273:
  %t1027 = load i64, ptr %l55, !tbaa !24
  %t1029 = icmp eq i64 %t1027, 0
  br i1 %t1029, label %bb274, label %bb275
bb274:
  store %olang.scope zeroinitializer, ptr %s51
  %t1031 = load i64, ptr %l54, !tbaa !24
  %t1034 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l16, i64 %t1031)
  store { i64, ptr } %t1034, ptr %l530
  br label %bb276
bb275:
  br label %bb291
bb276:
  %t1035 = load { i64, ptr }, ptr %l530, !tbaa !27
  %t1036 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s51, { i64, ptr } %t1035, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d92, i32 0, i32 1) })
  store i1 %t1036, ptr %l531
  br label %bb277
bb277:
  %t1037 = load i1, ptr %l531, !tbaa !21
  %t1038 = xor i1 %t1037, true
  br i1 %t1038, label %bb278, label %bb279
bb278:
  %t1040 = load i64, ptr %l54, !tbaa !24
  %t1043 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l16, i64 %t1040)
  store { i64, ptr } %t1043, ptr %l536
  br label %bb280
bb279:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d93, i32 0, i32 1) }, ptr %l533, !tbaa !27
  br label %bb282
bb280:
  %t1044 = load { i64, ptr }, ptr %l536, !tbaa !27
  %t1045 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %s0, ptr %s51, { i64, ptr } %t1044)
  store { i64, ptr } %t1045, ptr %l537
  br label %bb281
bb281:
  %t1046 = load { i64, ptr }, ptr %l537, !tbaa !27
  store { i64, ptr } %t1046, ptr %l533, !tbaa !27
  br label %bb282
bb282:
  %t1047 = load { i64, ptr }, ptr %l533, !tbaa !27
  store { i64, ptr } %t1047, ptr %l64, !tbaa !27
  %t1048 = load ptr, ptr %lp2
  %t1049 = getelementptr %"compiler/profile:Places", ptr %t1048, i32 0, i32 2
  store ptr %t1049, ptr %l538, !tbaa !29
  %t1050 = load ptr, ptr %lp2
  store ptr %t1050, ptr %l539, !tbaa !29
  %t1051 = load i64, ptr %l54, !tbaa !24
  %t1054 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l5, i64 %t1051)
  store i64 %t1054, ptr %l542
  br label %bb283
bb283:
  %t1055 = load i64, ptr %l542, !tbaa !24
  store i64 %t1055, ptr %l543, !tbaa !65
  %t1056 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s51, i64 16)
  %t1057 = extractvalue { i32, i64 } %t1056, 1
  %t1058 = extractvalue { i32, i64 } %t1056, 0
  store i32 %t1058, ptr %l545
  %t1059 = icmp ne i32 %t1058, 0
  br i1 %t1059, label %bb285, label %ok.1060, !prof !99
ok.1060:
  store i64 %t1057, ptr %l544
  br label %bb284
bb284:
  %t1061 = load i64, ptr %l543, !tbaa !65
  %t1062 = load i64, ptr %l544, !tbaa !24
  %t1063 = call { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %s51, i64 %t1061, i64 %t1062)
  store { i64, ptr } %t1063, ptr %l546
  br label %bb286
bb285:
  call void @__olang_check_failed(ptr @olang_loc_41e6651314f25f98_646ba62944647444)
  unreachable
bb286:
  %t1064 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t1065 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t1066 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  %t1067 = load { i64, ptr }, ptr %l546, !tbaa !27
  %t1068 = extractvalue { i64, ptr } %t1067, 1
  %t1069 = extractvalue { i64, ptr } %t1067, 0
  %t1070 = add i64 %t1066, %t1069
  %t1071 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d95, i32 0, i32 1) }, 1
  %t1072 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  %t1073 = add i64 %t1070, %t1072
  %t1075 = extractvalue { i64, ptr } %t1064, 1
  %t1076 = extractvalue { i64, ptr } %t1064, 0
  %t1077 = add i64 %t1073, %t1076
  %t1078 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d96, i32 0, i32 1) }, 1
  %t1079 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d96, i32 0, i32 1) }, 0
  %t1080 = add i64 %t1077, %t1079
  %t1081 = call ptr @__olang_scope_alloc(ptr %s51, i64 %t1080)
  call void @olang_textcopy(ptr %t1081, ptr %t1065, i64 %t1066)
  %t1082 = getelementptr i8, ptr %t1081, i64 %t1066
  call void @olang_textcopy(ptr %t1082, ptr %t1068, i64 %t1069)
  %t1083 = getelementptr i8, ptr %t1082, i64 %t1069
  call void @olang_textcopy(ptr %t1083, ptr %t1071, i64 %t1072)
  %t1084 = getelementptr i8, ptr %t1083, i64 %t1072
  call void @olang_textcopy(ptr %t1084, ptr %t1075, i64 %t1076)
  %t1085 = getelementptr i8, ptr %t1084, i64 %t1076
  call void @olang_textcopy(ptr %t1085, ptr %t1078, i64 %t1079)
  %t1086 = insertvalue { i64, ptr } undef, i64 %t1080, 0
  %t1087 = insertvalue { i64, ptr } %t1086, ptr %t1081, 1
  %t1089 = extractvalue { i64, ptr } %t1087, 0
  %t1090 = extractvalue { i64, ptr } %t1087, 1
  %t1091 = mul i64 %t1089, 1
  %t1092 = call ptr @__olang_scope_alloc(ptr %s51, i64 %t1091)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1092, ptr %t1090, i64 %t1091, i1 false)
  %t1093 = insertvalue { i64, ptr } undef, i64 %t1089, 0
  %t1094 = insertvalue { i64, ptr } %t1093, ptr %t1092, 1
  %t1095 = load ptr, ptr %l539, !tbaa !29
  %t1097 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v2, ptr %s51, ptr %t1095, { i64, ptr } %t1094)
  store i64 %t1097, ptr %l550
  br label %bb287
bb287:
  %t1098 = load ptr, ptr %lp2
  %t1100 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v2, ptr %s51, ptr %t1098, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d97, i32 0, i32 1) })
  store i64 %t1100, ptr %l552
  br label %bb288
bb288:
  %t1101 = load i64, ptr %l550, !tbaa !24
  %t1102 = load i64, ptr %l552, !tbaa !24
  %t1103 = call %"compiler/profile:Frame" @compiler_2fprofile_3aFrame_2ector(ptr %s51, i64 %t1101, i64 %t1102, i64 0)
  store %"compiler/profile:Frame" %t1103, ptr %l553
  br label %bb289
bb289:
  %t1104 = load ptr, ptr %l538, !tbaa !29
  %t1105 = load %"compiler/profile:Frame", ptr %l553
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2ePush_3ccompiler_2fprofile_3aFrame_3e(ptr %v2, ptr %t1104, %"compiler/profile:Frame" %t1105)
  br label %bb290
bb290:
  store i64 1, ptr %l55, !tbaa !24
  call void @__olang_scope_close(ptr %s51)
  br label %bb291
bb291:
  %t1106 = load ptr, ptr %lp2
  %t1107 = getelementptr %"compiler/profile:Places", ptr %t1106, i32 0, i32 4
  %t1108 = load i64, ptr %l55, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t1107, i64 %t1108)
  br label %bb292
bb292:
  call void @__olang_scope_close(ptr %s37)
  br label %bb293
bb293:
  %t1111 = load i64, ptr %l53, !tbaa !24
  %t1113 = add i64 %t1111, 1
  store i64 %t1113, ptr %l53, !tbaa !24
  br label %bb162
bb294:
  %t1115 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %l558, ptr %t1115, i64 272, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l558, i64 272, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fprofile_2eSymbolizer(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %lp7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l10 = alloca i1
  %l12 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i32
  %l19 = alloca i1
  %l22 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l27 = alloca i1
  %l42 = alloca { i64, ptr }
  %l44 = alloca i1
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i64, ptr } @compiler_2ftarget_2eFindClang(ptr %s0)
  store { i64, ptr } %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t2, ptr %l0, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t3, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d98, i32 0, i32 1) })
  store i1 %t5, ptr %l10
  br label %bb2
bb2:
  %t6 = load i1, ptr %l10, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t11 = call { i64, ptr } @compiler_2ftarget_2eWhereIs(ptr %s0, ptr %s1, { i64, ptr } %t9)
  store { i64, ptr } %t11, ptr %l14
  br label %bb5
bb4:
  br label %bb20
bb5:
  %t12 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  %t14 = extractvalue { i64, ptr } %t12, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t20 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %s1, ptr %s1, { i64, ptr } %t18)
  %t21 = extractvalue { i32, { i64, ptr } } %t20, 1
  %t22 = extractvalue { i32, { i64, ptr } } %t20, 0
  store i32 %t22, ptr %l17
  %t23 = icmp ne i32 %t22, 0
  br i1 %t23, label %bb7, label %ok.24, !prof !99
ok.24:
  store { i64, ptr } %t21, ptr %l16
  br label %bb6
bb6:
  %t25 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t25, ptr %l12, !tbaa !27
  br label %bb9
bb7:
  br label %bb8
bb8:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d99, i32 0, i32 1) }, ptr %l12, !tbaa !27
  br label %bb9
bb9:
  %t26 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t26, ptr %l1, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t29 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s1, { i64, ptr } %t27, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d100, i32 0, i32 1) })
  store i1 %t29, ptr %l19
  br label %bb10
bb10:
  %t30 = load i1, ptr %l19, !tbaa !21
  %t31 = xor i1 %t30, true
  br i1 %t31, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t35 = call { i64, ptr } @std_2ffilepath_2eDir(ptr %s1, ptr %s2, { i64, ptr } %t33)
  store { i64, ptr } %t35, ptr %l22
  br label %bb13
bb12:
  br label %bb19
bb13:
  %t36 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 1
  %t38 = extractvalue { i64, ptr } %t36, 0
  %t39 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d101, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d101, i32 0, i32 1) }, 0
  %t41 = add i64 %t38, %t40
  %t42 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t41)
  call void @olang_textcopy(ptr %t42, ptr %t37, i64 %t38)
  %t43 = getelementptr i8, ptr %t42, i64 %t38
  call void @olang_textcopy(ptr %t43, ptr %t39, i64 %t40)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t42, 1
  %t46 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t46, ptr %lp2
  %t48 = load ptr, ptr %lp2
  store { i64, ptr } %t45, ptr %t48, !tbaa !27
  %t49 = load ptr, ptr %lp2
  %t50 = load { i64, ptr }, ptr %t49, !tbaa !27
  %t52 = call { i64, ptr } @compiler_2ftarget_2eWhereIs(ptr %v0, ptr %s2, { i64, ptr } %t50)
  store { i64, ptr } %t52, ptr %l25
  br label %bb14
bb14:
  %t53 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t53, 0
  %t55 = extractvalue { i64, ptr } %t53, 1
  %t56 = mul i64 %t54, 1
  %t57 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t56)
  call void @llvm.memcpy.p0.p0.i64(ptr %t57, ptr %t55, i64 %t56, i1 false)
  %t58 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  %t61 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t59, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d102, i32 0, i32 1) })
  store i1 %t61, ptr %l27
  br label %bb15
bb15:
  %t62 = load i1, ptr %l27, !tbaa !21
  %t63 = xor i1 %t62, true
  br i1 %t63, label %bb16, label %bb17
bb16:
  %t65 = load ptr, ptr %lp2
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t66, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s1)
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s5
  %t68 = insertvalue [4 x { i64, ptr }] undef, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d103, i32 0, i32 1) }, 0
  %t69 = insertvalue [4 x { i64, ptr }] %t68, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d104, i32 0, i32 1) }, 1
  %t70 = insertvalue [4 x { i64, ptr }] %t69, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d105, i32 0, i32 1) }, 2
  %t71 = insertvalue [4 x { i64, ptr }] %t70, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d106, i32 0, i32 1) }, 3
  %t73 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 64, i64 8)
  store [4 x { i64, ptr }] %t71, ptr %t73
  store ptr %t73, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t75 = load ptr, ptr %l3
  store i64 4, ptr %l5, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s6
  %t78 = load i64, ptr %l4, !tbaa !24
  %t79 = load i64, ptr %l5, !tbaa !24
  %t82 = icmp slt i64 %t78, %t79
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s6)
  br label %bb31
bb23:
  br label %bb24
bb24:
  %t86 = load ptr, ptr %l3
  %t87 = load i64, ptr %l4, !tbaa !24
  %t90 = getelementptr [4 x { i64, ptr }], ptr %t86, i64 0, i64 %t87
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !37
  %t94 = load ptr, ptr @__olang_prog_scope
  %t96 = call { i64, ptr } @compiler_2ftarget_2eWhereIs(ptr %t94, ptr %v0, { i64, ptr } %t91)
  store { i64, ptr } %t96, ptr %l42
  br label %bb25
bb25:
  %t97 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t97, ptr %lp7
  %t98 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t99 = load ptr, ptr %lp7
  store { i64, ptr } %t98, ptr %t99, !tbaa !27
  %t100 = load ptr, ptr %lp7
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !27
  %t103 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s6, { i64, ptr } %t101, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d107, i32 0, i32 1) })
  store i1 %t103, ptr %l44
  br label %bb26
bb26:
  %t104 = load i1, ptr %l44, !tbaa !21
  %t105 = xor i1 %t104, true
  br i1 %t105, label %bb27, label %bb28
bb27:
  %t107 = load ptr, ptr %lp7
  %t108 = load { i64, ptr }, ptr %t107, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t108, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s6)
  br label %bb30
bb30:
  %t110 = load i64, ptr %l4, !tbaa !24
  %t112 = add i64 %t110, 1
  store i64 %t112, ptr %l4, !tbaa !24
  br label %bb21
bb31:
  call void @__olang_scope_close(ptr %s5)
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d108, i32 0, i32 1) }, ptr %l49, !tbaa !27
  %t114 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t114, ptr %l50, !tbaa !27
  %t115 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t115, 0
  store i64 %t116, ptr %l51, !tbaa !24
  %t117 = load i64, ptr %l51, !tbaa !24
  %t118 = mul i64 %t117, 1
  %t119 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t118)
  %t120 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t121 = insertvalue { i64, ptr } %t120, ptr %t119, 1
  store { i64, ptr } %t121, ptr %l52, !tbaa !27
  %t122 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = load i64, ptr %l51, !tbaa !24
  %t127 = mul i64 %t126, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t123, ptr %t125, i64 %t127, i1 false)
  %t128 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t128, ptr %l50, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t129 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t129, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fprofile_2eTallied(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/profile:Sample"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca i64
  %l8 = alloca %"compiler/profile:Frame"
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca i64
  %l17 = alloca %"compiler/profile:Tally"
  %l20 = alloca i64
  %l22 = alloca i64
  %l27 = alloca %"compiler/profile:Sample"
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca i64
  %l37 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca %"compiler/profile:Frame"
  %l43 = alloca i1
  %l45 = alloca i1
  %l48 = alloca i1
  %l55 = alloca ptr
  %l59 = alloca { i64, ptr }
  %l63 = alloca i64
  %l66 = alloca i1
  %l76 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l78 = alloca i64
  %l80 = alloca i64
  %l86 = alloca i64
  %l90 = alloca %"compiler/profile:Frame"
  %l95 = alloca i1
  %l100 = alloca i1
  %l102 = alloca i1
  %l105 = alloca i1
  %l113 = alloca i64
  %l115 = alloca i64
  %l117 = alloca ptr
  %l119 = alloca i64
  %l121 = alloca ptr
  %l125 = alloca i64
  %l126 = alloca %"compiler/profile:Frame"
  %l134 = alloca %"compiler/profile:Tally"
  %s2 = alloca %olang.scope
  %t1 = alloca %"compiler/profile:Tally", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fprofile_3aTally_2ector(ptr %t1, ptr %v2)
  call void @llvm.memmove.p0.p0.i64(ptr %l17, ptr %t1, i64 424, i1 false)
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 424, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %t3, ptr %l17, i64 424, i1 false)
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/profile:Profile", ptr %t4, i32 0, i32 3
  store ptr %t6, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = load i64, ptr %l4, !tbaa !24
  store i64 %t8, ptr %l20, !tbaa !24
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2eLen_3ccompiler_2fprofile_3aSample_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l22
  br label %bb3
bb3:
  %t12 = load i64, ptr %l20, !tbaa !24
  %t13 = load i64, ptr %l22, !tbaa !24
  %t14 = icmp slt i64 %t12, %t13
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb67
bb5:
  br label %bb6
bb6:
  %t18 = load ptr, ptr %l3, !tbaa !29
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = call %"compiler/profile:Sample" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2eAt_3ccompiler_2fprofile_3aSample_3e(ptr %v0, ptr %t18, i64 %t19)
  store %"compiler/profile:Sample" %t22, ptr %l27
  br label %bb7
bb7:
  %t23 = load %"compiler/profile:Sample", ptr %l27
  store %"compiler/profile:Sample" %t23, ptr %l5
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load %"compiler/profile:Sample", ptr %l5
  %t30 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2estack(ptr %v1, ptr %v0, ptr %s2, ptr %t24, ptr %t25, %"compiler/profile:Sample" %t26)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %l31
  br label %bb8
bb8:
  %t31 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t31, ptr %l6
  %t33 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s2, ptr %l6)
  store i64 %t33, ptr %l33
  br label %bb9
bb9:
  %t34 = load i64, ptr %l33, !tbaa !24
  %t35 = icmp eq i64 %t34, 0
  br i1 %t35, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb66
bb11:
  br label %bb12
bb12:
  %t37 = getelementptr %"compiler/profile:Sample", ptr %l5, i32 0, i32 0
  %t38 = load i64, ptr %t37, !tbaa !24
  store i64 %t38, ptr %l7, !tbaa !24
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr %"compiler/profile:Places", ptr %t40, i32 0, i32 2
  store ptr %t42, ptr %l37, !tbaa !29
  %t44 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %l6, i64 0)
  store i64 %t44, ptr %l39
  br label %bb13
bb13:
  %t45 = load ptr, ptr %l37, !tbaa !29
  %t46 = load i64, ptr %l39, !tbaa !24
  %t47 = call %"compiler/profile:Frame" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2eAt_3ccompiler_2fprofile_3aFrame_3e(ptr %v1, ptr %t45, i64 %t46)
  store %"compiler/profile:Frame" %t47, ptr %l40
  br label %bb14
bb14:
  %t48 = load %"compiler/profile:Frame", ptr %l40
  store %"compiler/profile:Frame" %t48, ptr %l8
  %t49 = load ptr, ptr %lp2
  %t50 = getelementptr %"compiler/profile:Tally", ptr %t49, i32 0, i32 1
  %t51 = getelementptr %"compiler/profile:Frame", ptr %l8, i32 0, i32 0
  %t52 = load i64, ptr %t51, !tbaa !24
  %t55 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v2, ptr %t50, i64 %t52)
  store i1 %t55, ptr %l43
  br label %bb15
bb15:
  %t56 = load i1, ptr %l43, !tbaa !21
  %t57 = xor i1 %t56, true
  br i1 %t57, label %bb16, label %bb17
bb16:
  %t59 = load ptr, ptr %lp2
  %t60 = getelementptr %"compiler/profile:Tally", ptr %t59, i32 0, i32 0
  %t61 = getelementptr %"compiler/profile:Frame", ptr %l8, i32 0, i32 0
  %t62 = load i64, ptr %t61, !tbaa !24
  %t65 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v2, ptr %t60, i64 %t62)
  store i1 %t65, ptr %l48
  br label %bb18
bb17:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb19
bb18:
  %t66 = load i1, ptr %l48, !tbaa !21
  %t67 = xor i1 %t66, true
  store i1 %t67, ptr %l45, !tbaa !21
  br label %bb19
bb19:
  %t69 = load i1, ptr %l45, !tbaa !21
  br i1 %t69, label %bb20, label %bb21
bb20:
  %t70 = load ptr, ptr %lp2
  %t71 = getelementptr %"compiler/profile:Tally", ptr %t70, i32 0, i32 5
  %t72 = getelementptr %"compiler/profile:Frame", ptr %l8, i32 0, i32 0
  %t73 = load i64, ptr %t72, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t71, i64 %t73)
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb23
bb23:
  %t76 = load ptr, ptr %lp2
  %t77 = getelementptr %"compiler/profile:Tally", ptr %t76, i32 0, i32 0
  %t78 = getelementptr %"compiler/profile:Frame", ptr %l8, i32 0, i32 0
  %t79 = load i64, ptr %t78, !tbaa !24
  %t80 = load i64, ptr %l7, !tbaa !24
  call void @compiler_2fprofile_2eadd(ptr %v2, ptr %t77, i64 %t79, i64 %t80)
  br label %bb24
bb24:
  %t84 = load ptr, ptr %l1, !tbaa !29
  store ptr %t84, ptr %l55, !tbaa !29
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr %"compiler/profile:Places", ptr %t85, i32 0, i32 0
  %t88 = getelementptr %"compiler/profile:Frame", ptr %l8, i32 0, i32 1
  %t89 = load i64, ptr %t88, !tbaa !24
  %t92 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %s2, ptr %t87, i64 %t89)
  store { i64, ptr } %t92, ptr %l59
  br label %bb25
bb25:
  %t93 = getelementptr %"compiler/profile:Frame", ptr %l8, i32 0, i32 2
  %t94 = load i64, ptr %t93, !tbaa !24
  %t95 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t95, 1
  %t97 = extractvalue { i64, ptr } %t95, 0
  %t98 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d109, i32 0, i32 1) }, 1
  %t99 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d109, i32 0, i32 1) }, 0
  %t100 = add i64 %t97, %t99
  %t102 = call i64 @__olang_fmt_i64(ptr null, i64 %t94)
  %t103 = add i64 %t100, %t102
  %t104 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t103)
  call void @olang_textcopy(ptr %t104, ptr %t96, i64 %t97)
  %t105 = getelementptr i8, ptr %t104, i64 %t97
  call void @olang_textcopy(ptr %t105, ptr %t98, i64 %t99)
  %t106 = getelementptr i8, ptr %t105, i64 %t99
  %t107 = call i64 @__olang_fmt_i64(ptr %t106, i64 %t94)
  %t108 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t104, 1
  %t111 = extractvalue { i64, ptr } %t109, 0
  %t112 = extractvalue { i64, ptr } %t109, 1
  %t113 = mul i64 %t111, 1
  %t114 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t113)
  call void @llvm.memcpy.p0.p0.i64(ptr %t114, ptr %t112, i64 %t113, i1 false)
  %t115 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t114, 1
  %t117 = load ptr, ptr %l55, !tbaa !29
  %t119 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v1, ptr %s2, ptr %t117, { i64, ptr } %t116)
  store i64 %t119, ptr %l63
  br label %bb26
bb26:
  %t120 = load i64, ptr %l63, !tbaa !24
  store i64 %t120, ptr %l9, !tbaa !24
  %t121 = load ptr, ptr %lp2
  %t122 = getelementptr %"compiler/profile:Tally", ptr %t121, i32 0, i32 2
  %t123 = load i64, ptr %l9, !tbaa !24
  %t126 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v2, ptr %t122, i64 %t123)
  store i1 %t126, ptr %l66
  br label %bb27
bb27:
  %t127 = load i1, ptr %l66, !tbaa !21
  %t128 = xor i1 %t127, true
  br i1 %t128, label %bb28, label %bb29
bb28:
  %t130 = load ptr, ptr %lp2
  %t131 = getelementptr %"compiler/profile:Tally", ptr %t130, i32 0, i32 6
  %t132 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t131, i64 %t132)
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb31
bb31:
  %t135 = load ptr, ptr %lp2
  %t136 = getelementptr %"compiler/profile:Tally", ptr %t135, i32 0, i32 2
  %t137 = load i64, ptr %l9, !tbaa !24
  %t138 = load i64, ptr %l7, !tbaa !24
  call void @compiler_2fprofile_2eadd(ptr %v2, ptr %t136, i64 %t137, i64 %t138)
  br label %bb32
bb32:
  %t142 = load ptr, ptr %lp2
  %t143 = getelementptr %"compiler/profile:Tally", ptr %t142, i32 0, i32 3
  %t144 = load i64, ptr %l9, !tbaa !24
  %t145 = getelementptr %"compiler/profile:Frame", ptr %l8, i32 0, i32 0
  %t146 = load i64, ptr %t145, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v2, ptr %t143, i64 %t144, i64 %t146)
  br label %bb33
bb33:
  %t150 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t150, ptr %l76
  br label %bb34
bb34:
  %t151 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l76
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t151, ptr %l10
  store ptr %l6, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb35
bb35:
  %t153 = load i64, ptr %l12, !tbaa !24
  store i64 %t153, ptr %l78, !tbaa !24
  %t154 = load ptr, ptr %l11, !tbaa !29
  %t156 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s2, ptr %t154)
  store i64 %t156, ptr %l80
  br label %bb36
bb36:
  %t157 = load i64, ptr %l78, !tbaa !24
  %t158 = load i64, ptr %l80, !tbaa !24
  %t159 = icmp slt i64 %t157, %t158
  %t161 = xor i1 %t159, true
  br i1 %t161, label %bb37, label %bb38
bb37:
  br label %bb65
bb38:
  br label %bb39
bb39:
  %t163 = load i64, ptr %l12, !tbaa !24
  store i64 %t163, ptr %l13, !tbaa !24
  %t165 = load ptr, ptr %l11, !tbaa !29
  %t166 = load i64, ptr %l12, !tbaa !24
  %t169 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %t165, i64 %t166)
  store i64 %t169, ptr %l86
  br label %bb40
bb40:
  %t170 = load i64, ptr %l86, !tbaa !24
  %t171 = load ptr, ptr %l1, !tbaa !29
  %t173 = getelementptr %"compiler/profile:Places", ptr %t171, i32 0, i32 2
  %t177 = call %"compiler/profile:Frame" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2eAt_3ccompiler_2fprofile_3aFrame_3e(ptr %v1, ptr %t173, i64 %t170)
  store %"compiler/profile:Frame" %t177, ptr %l90
  br label %bb41
bb41:
  %t178 = getelementptr %"compiler/profile:Frame", ptr %l90, i32 0, i32 0
  %t179 = load i64, ptr %t178, !tbaa !24
  store i64 %t179, ptr %l15, !tbaa !24
  %t181 = load i64, ptr %l15, !tbaa !24
  %t186 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %s2, ptr %l10, i64 %t181)
  store i1 %t186, ptr %l95
  br label %bb42
bb42:
  %t187 = load i1, ptr %l95, !tbaa !21
  br i1 %t187, label %bb43, label %bb44
bb43:
  br label %bb64
bb44:
  br label %bb45
bb45:
  %t188 = load i64, ptr %l15, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s2, ptr %l10, i64 %t188)
  br label %bb46
bb46:
  %t191 = load ptr, ptr %lp2
  %t192 = getelementptr %"compiler/profile:Tally", ptr %t191, i32 0, i32 1
  %t193 = load i64, ptr %l15, !tbaa !24
  %t196 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v2, ptr %t192, i64 %t193)
  store i1 %t196, ptr %l100
  br label %bb47
bb47:
  %t197 = load i1, ptr %l100, !tbaa !21
  %t198 = xor i1 %t197, true
  br i1 %t198, label %bb48, label %bb49
bb48:
  %t200 = load ptr, ptr %lp2
  %t201 = getelementptr %"compiler/profile:Tally", ptr %t200, i32 0, i32 0
  %t202 = load i64, ptr %l15, !tbaa !24
  %t205 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v2, ptr %t201, i64 %t202)
  store i1 %t205, ptr %l105
  br label %bb50
bb49:
  store i1 false, ptr %l102, !tbaa !21
  br label %bb51
bb50:
  %t206 = load i1, ptr %l105, !tbaa !21
  %t207 = xor i1 %t206, true
  store i1 %t207, ptr %l102, !tbaa !21
  br label %bb51
bb51:
  %t209 = load i1, ptr %l102, !tbaa !21
  br i1 %t209, label %bb52, label %bb53
bb52:
  %t210 = load ptr, ptr %lp2
  %t211 = getelementptr %"compiler/profile:Tally", ptr %t210, i32 0, i32 5
  %t212 = load i64, ptr %l15, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t211, i64 %t212)
  br label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb55
bb55:
  %t215 = load ptr, ptr %lp2
  %t216 = getelementptr %"compiler/profile:Tally", ptr %t215, i32 0, i32 1
  %t217 = load i64, ptr %l15, !tbaa !24
  %t218 = load i64, ptr %l7, !tbaa !24
  call void @compiler_2fprofile_2eadd(ptr %v2, ptr %t216, i64 %t217, i64 %t218)
  br label %bb56
bb56:
  %t222 = load i64, ptr %l13, !tbaa !24
  %t224 = add i64 %t222, 1
  store i64 %t224, ptr %l113, !tbaa !24
  %t226 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s2, ptr %l6)
  store i64 %t226, ptr %l115
  br label %bb57
bb57:
  %t227 = load i64, ptr %l113, !tbaa !24
  %t228 = load i64, ptr %l115, !tbaa !24
  %t229 = icmp slt i64 %t227, %t228
  br i1 %t229, label %bb58, label %bb59
bb58:
  %t231 = load ptr, ptr %lp2
  %t232 = getelementptr %"compiler/profile:Tally", ptr %t231, i32 0, i32 4
  store ptr %t232, ptr %l117, !tbaa !29
  %t233 = load i64, ptr %l15, !tbaa !24
  %t235 = mul i64 %t233, 16777216
  store i64 %t235, ptr %l119, !tbaa !24
  %t236 = load ptr, ptr %l1, !tbaa !29
  %t238 = getelementptr %"compiler/profile:Places", ptr %t236, i32 0, i32 2
  store ptr %t238, ptr %l121, !tbaa !29
  %t239 = load i64, ptr %l13, !tbaa !24
  %t241 = add i64 %t239, 1
  %t244 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %l6, i64 %t241)
  store i64 %t244, ptr %l125
  br label %bb60
bb59:
  br label %bb63
bb60:
  %t245 = load ptr, ptr %l121, !tbaa !29
  %t246 = load i64, ptr %l125, !tbaa !24
  %t247 = call %"compiler/profile:Frame" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2eAt_3ccompiler_2fprofile_3aFrame_3e(ptr %v1, ptr %t245, i64 %t246)
  store %"compiler/profile:Frame" %t247, ptr %l126
  br label %bb61
bb61:
  %t248 = getelementptr %"compiler/profile:Frame", ptr %l126, i32 0, i32 0
  %t249 = load i64, ptr %t248, !tbaa !24
  %t250 = load i64, ptr %l119, !tbaa !24
  %t252 = add i64 %t250, %t249
  %t253 = load i64, ptr %l7, !tbaa !24
  %t254 = load ptr, ptr %l117, !tbaa !29
  call void @compiler_2fprofile_2eadd(ptr %v2, ptr %t254, i64 %t252, i64 %t253)
  br label %bb62
bb62:
  br label %bb63
bb63:
  br label %bb64
bb64:
  %t257 = load i64, ptr %l12, !tbaa !24
  %t259 = add i64 %t257, 1
  store i64 %t259, ptr %l12, !tbaa !24
  br label %bb35
bb65:
  call void @__olang_scope_close(ptr %s2)
  br label %bb66
bb66:
  %t261 = load i64, ptr %l4, !tbaa !24
  %t263 = add i64 %t261, 1
  store i64 %t263, ptr %l4, !tbaa !24
  br label %bb2
bb67:
  %t265 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %l134, ptr %t265, i64 424, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l134, i64 424, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fprofile_2eadd(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  store i64 %t2, ptr %l4, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l9
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l8
  br label %bb1
bb1:
  %t12 = load i64, ptr %l8, !tbaa !24
  store i64 %t12, ptr %l5, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l5, !tbaa !24
  %t16 = add i64 %t14, %a2
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t18 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t17, i64 %t18, i64 %t16)
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l18 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l24 = alloca i64
  %l28 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/profile:Places", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %t3, { i64, ptr } %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l8
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l7
  br label %bb1
bb1:
  %t12 = load i64, ptr %l7, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l3, !tbaa !24
  store i64 %t13, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp sge i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load i64, ptr %l2, !tbaa !24
  store i64 %t18, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/profile:Places", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = extractvalue { i64, ptr } %t23, 0
  %t27 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t25, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = extractvalue { i64, ptr } %t29, 1
  %t33 = mul i64 %t31, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t33)
  call void @llvm.memcpy.p0.p0.i64(ptr %t34, ptr %t32, i64 %t33, i1 false)
  %t35 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t22, { i64, ptr } %t36)
  br label %bb8
bb8:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/profile:Places", ptr %t39, i32 0, i32 1
  store ptr %t41, ptr %l18, !tbaa !29
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 1
  %t45 = extractvalue { i64, ptr } %t42, 0
  %t46 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t45)
  call void @olang_textcopy(ptr %t46, ptr %t44, i64 %t45)
  %t47 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  %t50 = extractvalue { i64, ptr } %t48, 0
  %t51 = extractvalue { i64, ptr } %t48, 1
  %t52 = mul i64 %t50, 1
  %t53 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t52)
  call void @llvm.memcpy.p0.p0.i64(ptr %t53, ptr %t51, i64 %t52, i1 false)
  %t54 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  store { i64, ptr } %t55, ptr %l21, !tbaa !27
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/profile:Places", ptr %t56, i32 0, i32 0
  %t60 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t58)
  store i64 %t60, ptr %l24
  br label %bb9
bb9:
  %t61 = load i64, ptr %l24, !tbaa !24
  %t62 = sub i64 %t61, 1
  %t63 = load ptr, ptr %l18, !tbaa !29
  %t64 = load { i64, ptr }, ptr %l21, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t63, { i64, ptr } %t64, i64 %t62)
  br label %bb10
bb10:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/profile:Places", ptr %t66, i32 0, i32 0
  %t70 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t68)
  store i64 %t70, ptr %l28
  br label %bb11
bb11:
  %t71 = load i64, ptr %l28, !tbaa !24
  %t72 = sub i64 %t71, 1
  store i64 %t72, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2estack(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/profile:Sample" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/profile:Sample"
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca i64
  %l26 = alloca i64
  %l49 = alloca i64
  %l52 = alloca i64
  %l54 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i32
  %l65 = alloca i64
  %l69 = alloca i64
  %l72 = alloca i64
  %l90 = alloca ptr
  %l94 = alloca i64
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store %"compiler/profile:Sample" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l18
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t2, ptr %lp3
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  %t4 = load ptr, ptr %lp3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  store i64 0, ptr %l4, !tbaa !24
  %t5 = getelementptr %"compiler/profile:Sample", ptr %l2, i32 0, i32 2
  %t6 = load i64, ptr %t5, !tbaa !24
  store i64 %t6, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = load i64, ptr %l4, !tbaa !24
  %t12 = icmp sgt i64 %t8, %t9
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = load i64, ptr %l6, !tbaa !24
  %t16 = icmp sgt i64 %t14, 0
  br i1 %t16, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb4:
  %t18 = load i64, ptr %l5, !tbaa !24
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = sub i64 %t18, %t19
  %t23 = load i64, ptr %l6, !tbaa !24
  %t26 = add i64 %t22, %t23
  %t28 = sub i64 %t26, 1
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = sdiv i64 %t28, %t29
  store i64 %t32, ptr %l26, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb6
bb6:
  %t34 = load i64, ptr %l26, !tbaa !24
  store i64 %t34, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t35 = load i64, ptr %l23, !tbaa !24
  store i64 %t35, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  %t36 = load i64, ptr %l8, !tbaa !24
  %t37 = load i64, ptr %l7, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb9, label %bb10
bb9:
  br label %bb39
bb10:
  br label %bb11
bb11:
  %t44 = load i64, ptr %l4, !tbaa !24
  %t45 = load i64, ptr %l8, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t49 = mul i64 %t45, %t46
  %t52 = add i64 %t44, %t49
  store i64 %t52, ptr %l9, !tbaa !24
  %t56 = getelementptr %"compiler/profile:Profile", ptr %a1, i32 0, i32 4
  %t57 = getelementptr %"compiler/profile:Sample", ptr %l2, i32 0, i32 1
  %t58 = load i64, ptr %t57, !tbaa !24
  %t59 = load i64, ptr %l9, !tbaa !24
  %t62 = add i64 %t58, %t59
  %t65 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t56, i64 %t62)
  store i64 %t65, ptr %l49
  br label %bb12
bb12:
  %t66 = load i64, ptr %l9, !tbaa !24
  %t68 = icmp eq i64 %t66, 0
  br i1 %t68, label %bb13, label %bb14
bb13:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb15
bb14:
  store i64 1, ptr %l52, !tbaa !24
  br label %bb15
bb15:
  %t70 = load i64, ptr %l49, !tbaa !24
  %t71 = load i64, ptr %l52, !tbaa !24
  %t72 = sub i64 %t70, %t71
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/profile:Places", ptr %t74, i32 0, i32 5
  %t80 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t76, i64 %t72)
  %t81 = extractvalue { i32, i64 } %t80, 1
  %t82 = extractvalue { i32, i64 } %t80, 0
  store i32 %t82, ptr %l59
  %t83 = icmp ne i32 %t82, 0
  br i1 %t83, label %bb17, label %ok.84, !prof !99
ok.84:
  store i64 %t81, ptr %l58
  br label %bb16
bb16:
  %t85 = load i64, ptr %l58, !tbaa !24
  store i64 %t85, ptr %l54, !tbaa !24
  br label %bb19
bb17:
  br label %bb18
bb18:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l54, !tbaa !24
  br label %bb19
bb19:
  %t86 = load i64, ptr %l54, !tbaa !24
  store i64 %t86, ptr %l11, !tbaa !24
  %t87 = load i64, ptr %l11, !tbaa !24
  %t89 = icmp slt i64 %t87, 0
  br i1 %t89, label %bb20, label %bb21
bb20:
  br label %bb38
bb21:
  br label %bb22
bb22:
  store i64 0, ptr %l12, !tbaa !24
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/profile:Places", ptr %t91, i32 0, i32 4
  %t94 = load i64, ptr %l11, !tbaa !24
  %t97 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t93, i64 %t94)
  store i64 %t97, ptr %l65
  br label %bb23
bb23:
  %t98 = load i64, ptr %l65, !tbaa !24
  store i64 %t98, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t99 = load i64, ptr %l13, !tbaa !24
  %t100 = load i64, ptr %l12, !tbaa !24
  %t103 = icmp sgt i64 %t99, %t100
  br i1 %t103, label %bb24, label %bb25
bb24:
  %t105 = load i64, ptr %l14, !tbaa !24
  %t107 = icmp sgt i64 %t105, 0
  br i1 %t107, label %bb26, label %bb27
bb25:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb29
bb26:
  %t109 = load i64, ptr %l13, !tbaa !24
  %t110 = load i64, ptr %l12, !tbaa !24
  %t113 = sub i64 %t109, %t110
  %t114 = load i64, ptr %l14, !tbaa !24
  %t117 = add i64 %t113, %t114
  %t119 = sub i64 %t117, 1
  %t120 = load i64, ptr %l14, !tbaa !24
  %t123 = sdiv i64 %t119, %t120
  store i64 %t123, ptr %l72, !tbaa !24
  br label %bb28
bb27:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb28
bb28:
  %t125 = load i64, ptr %l72, !tbaa !24
  store i64 %t125, ptr %l69, !tbaa !24
  br label %bb29
bb29:
  %t126 = load i64, ptr %l69, !tbaa !24
  store i64 %t126, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb30
bb30:
  %t127 = load i64, ptr %l16, !tbaa !24
  %t128 = load i64, ptr %l15, !tbaa !24
  %t131 = icmp slt i64 %t127, %t128
  %t133 = xor i1 %t131, true
  br i1 %t133, label %bb31, label %bb32
bb31:
  br label %bb37
bb32:
  br label %bb33
bb33:
  %t135 = load i64, ptr %l12, !tbaa !24
  %t136 = load i64, ptr %l16, !tbaa !24
  %t137 = load i64, ptr %l14, !tbaa !24
  %t140 = mul i64 %t136, %t137
  %t143 = add i64 %t135, %t140
  store i64 %t143, ptr %l17, !tbaa !24
  %t145 = load ptr, ptr %lp3
  store ptr %t145, ptr %l90, !tbaa !29
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/profile:Places", ptr %t146, i32 0, i32 3
  %t149 = load i64, ptr %l11, !tbaa !24
  %t152 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t148, i64 %t149)
  store i64 %t152, ptr %l94
  br label %bb34
bb34:
  %t153 = load i64, ptr %l17, !tbaa !24
  %t154 = load i64, ptr %l94, !tbaa !24
  %t156 = add i64 %t154, %t153
  %t157 = load ptr, ptr %l90, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t157, i64 %t156)
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t159 = load i64, ptr %l16, !tbaa !24
  %t161 = add i64 %t159, 1
  store i64 %t161, ptr %l16, !tbaa !24
  br label %bb30
bb37:
  br label %bb38
bb38:
  %t163 = load i64, ptr %l8, !tbaa !24
  %t165 = add i64 %t163, 1
  store i64 %t165, ptr %l8, !tbaa !24
  br label %bb8
bb39:
  %t167 = load ptr, ptr %lp3
  %t168 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t167
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t168, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i64 @compiler_2fprofile_2ecompiler_2fprofile_3aProfile_2eTotal(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/profile:Sample"
  %l7 = alloca i64
  %l9 = alloca i64
  %l14 = alloca %"compiler/profile:Sample"
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t3 = getelementptr %"compiler/profile:Profile", ptr %a0, i32 0, i32 3
  store ptr %t3, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l3, !tbaa !24
  store i64 %t5, ptr %l7, !tbaa !24
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2eLen_3ccompiler_2fprofile_3aSample_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l9
  br label %bb2
bb2:
  %t9 = load i64, ptr %l7, !tbaa !24
  %t10 = load i64, ptr %l9, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = call %"compiler/profile:Sample" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2eAt_3ccompiler_2fprofile_3aSample_3e(ptr %v0, ptr %t15, i64 %t16)
  store %"compiler/profile:Sample" %t19, ptr %l14
  br label %bb6
bb6:
  %t20 = load %"compiler/profile:Sample", ptr %l14
  store %"compiler/profile:Sample" %t20, ptr %l4
  %t21 = load i64, ptr %l1, !tbaa !24
  %t22 = getelementptr %"compiler/profile:Sample", ptr %l4, i32 0, i32 0
  %t23 = load i64, ptr %t22, !tbaa !24
  %t26 = add i64 %t21, %t23
  store i64 %t26, ptr %l1, !tbaa !24
  br label %bb7
bb7:
  %t28 = load i64, ptr %l3, !tbaa !24
  %t30 = add i64 %t28, 1
  store i64 %t30, ptr %l3, !tbaa !24
  br label %bb1
bb8:
  %t32 = load i64, ptr %l1, !tbaa !24
  store i64 %t32, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fprofile_2eescapeXml(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb24
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l14, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 %t18
  %t23 = load i8, ptr %t22, !tbaa !32
  store i8 %t23, ptr %l5, !tbaa !22
  %t25 = load i8, ptr %l5, !tbaa !22
  %t27 = icmp eq i8 %t25, 60
  br i1 %t27, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d110, i32 0, i32 1) })
  br label %bb8
bb7:
  %t30 = load i8, ptr %l5, !tbaa !22
  %t32 = icmp eq i8 %t30, 62
  br i1 %t32, label %bb9, label %bb10
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb9:
  store %olang.scope zeroinitializer, ptr %s5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %l1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d111, i32 0, i32 1) })
  br label %bb11
bb10:
  %t35 = load i8, ptr %l5, !tbaa !22
  %t37 = icmp eq i8 %t35, 38
  br i1 %t37, label %bb12, label %bb13
bb11:
  call void @__olang_scope_close(ptr %s5)
  br label %bb21
bb12:
  store %olang.scope zeroinitializer, ptr %s7
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %l1, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d112, i32 0, i32 1) })
  br label %bb14
bb13:
  %t40 = load i8, ptr %l5, !tbaa !22
  %t42 = icmp eq i8 %t40, 34
  br i1 %t42, label %bb15, label %bb16
bb14:
  call void @__olang_scope_close(ptr %s7)
  br label %bb20
bb15:
  store %olang.scope zeroinitializer, ptr %s9
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s9, ptr %l1, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d113, i32 0, i32 1) })
  br label %bb17
bb16:
  %t45 = load i8, ptr %l5, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 %t45)
  br label %bb18
bb17:
  call void @__olang_scope_close(ptr %s9)
  br label %bb19
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t48 = load i64, ptr %l3, !tbaa !24
  %t50 = add i64 %t48, 1
  store i64 %t50, ptr %l3, !tbaa !24
  br label %bb2
bb24:
  %t53 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t53, ptr %l34
  br label %bb25
bb25:
  %t54 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t54, ptr %l35, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 0
  store i64 %t56, ptr %l36, !tbaa !24
  %t57 = load i64, ptr %l36, !tbaa !24
  %t58 = mul i64 %t57, 1
  %t59 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t58)
  %t60 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l37, !tbaa !27
  %t62 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = load i64, ptr %l36, !tbaa !24
  %t67 = mul i64 %t66, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t63, ptr %t65, i64 %t67, i1 false)
  %t68 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t68, ptr %l35, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t69 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t69, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { { i64, ptr }, i64 } @compiler_2fprofile_2efileLine(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l20 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i32
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l40 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca i32
  %l51 = alloca i64
  %l52 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, i64 }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d114, i32 0, i32 1) })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l7
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store i64 %t4, ptr %l6
  br label %bb1
bb1:
  %t8 = load i64, ptr %l6, !tbaa !24
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t9 = load i64, ptr %l4, !tbaa !24
  store i64 %t9, ptr %l1, !tbaa !24
  %t10 = load i64, ptr %l1, !tbaa !24
  %t12 = icmp slt i64 %t10, 0
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 1
  %t17 = extractvalue { i64, ptr } %t14, 0
  %t18 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t17)
  call void @olang_textcopy(ptr %t18, ptr %t16, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  %t22 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t20, 0
  %t23 = insertvalue { { i64, ptr }, i64 } %t22, i64 0, 1
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i64 } %t23, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t25 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t25, ptr %l13, !tbaa !27
  %t26 = load i64, ptr %l1, !tbaa !24
  store i64 %t26, ptr %l14, !tbaa !24
  %t27 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t27, 0
  store i64 %t28, ptr %l15, !tbaa !24
  %t29 = icmp sge i64 0, 0
  br i1 %t29, label %bb8, label %bb9
bb8:
  %t31 = load i64, ptr %l14, !tbaa !24
  %t32 = icmp sle i64 0, %t31
  br i1 %t32, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_7d2ae97c2364b59d_ce98559d67a1b5c9)
  unreachable
bb10:
  %t34 = load i64, ptr %l14, !tbaa !24
  %t35 = load i64, ptr %l15, !tbaa !24
  %t36 = icmp sle i64 %t34, %t35
  br i1 %t36, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_7d2ae97c2364b59d_ce98559d67a1b5c9)
  unreachable
bb12:
  %t38 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = load i64, ptr %l14, !tbaa !24
  %t41 = getelementptr i8, ptr %t39, i64 0
  %t42 = sub i64 %t40, 0
  %t43 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t41, 1
  store { i64, ptr } %t44, ptr %l2, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t48 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s0, { i64, ptr } %t46, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d115, i32 0, i32 1) })
  %t49 = extractvalue { i32, i64 } %t48, 1
  %t50 = extractvalue { i32, i64 } %t48, 0
  store i32 %t50, ptr %l23
  %t51 = icmp ne i32 %t50, 0
  br i1 %t51, label %bb15, label %ok.52, !prof !99
ok.52:
  store i64 %t49, ptr %l22
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_7d2ae97c2364b59d_ce98559d67a1b5c9)
  unreachable
bb14:
  %t53 = load i64, ptr %l22, !tbaa !24
  store i64 %t53, ptr %l20, !tbaa !24
  br label %bb17
bb15:
  br label %bb16
bb16:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l20, !tbaa !24
  br label %bb17
bb17:
  %t54 = load i64, ptr %l20, !tbaa !24
  store i64 %t54, ptr %l3, !tbaa !24
  %t55 = load i64, ptr %l3, !tbaa !24
  %t57 = icmp slt i64 %t55, 0
  br i1 %t57, label %bb18, label %bb19
bb18:
  %t59 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 1
  %t62 = extractvalue { i64, ptr } %t59, 0
  %t63 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t62)
  call void @olang_textcopy(ptr %t63, ptr %t61, i64 %t62)
  %t64 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  %t67 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t65, 0
  %t68 = insertvalue { { i64, ptr }, i64 } %t67, i64 0, 1
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i64 } %t68, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t70 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t70, ptr %l29, !tbaa !27
  %t71 = load i64, ptr %l3, !tbaa !24
  store i64 %t71, ptr %l30, !tbaa !24
  %t72 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 0
  store i64 %t73, ptr %l31, !tbaa !24
  %t74 = icmp sge i64 0, 0
  br i1 %t74, label %bb21, label %bb22
bb21:
  %t76 = load i64, ptr %l30, !tbaa !24
  %t77 = icmp sle i64 0, %t76
  br i1 %t77, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_ec3589048a52ea40_4feb0c814716a05c)
  unreachable
bb23:
  %t79 = load i64, ptr %l30, !tbaa !24
  %t80 = load i64, ptr %l31, !tbaa !24
  %t81 = icmp sle i64 %t79, %t80
  br i1 %t81, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_ec3589048a52ea40_4feb0c814716a05c)
  unreachable
bb25:
  %t83 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = load i64, ptr %l30, !tbaa !24
  %t86 = getelementptr i8, ptr %t84, i64 0
  %t87 = sub i64 %t85, 0
  %t88 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t86, 1
  %t91 = extractvalue { i64, ptr } %t89, 1
  %t92 = extractvalue { i64, ptr } %t89, 0
  %t93 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t92)
  call void @olang_textcopy(ptr %t93, ptr %t91, i64 %t92)
  %t94 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t93, 1
  store { i64, ptr } %t95, ptr %l36, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t96, ptr %l38, !tbaa !27
  %t97 = load i64, ptr %l3, !tbaa !24
  %t99 = add i64 %t97, 1
  store i64 %t99, ptr %l40, !tbaa !24
  %t100 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t100, 0
  store i64 %t103, ptr %l43, !tbaa !24
  %t104 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 0
  store i64 %t105, ptr %l44, !tbaa !24
  %t106 = load i64, ptr %l40, !tbaa !24
  %t107 = icmp sge i64 %t106, 0
  br i1 %t107, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_ec3589048a52ea40_4feb0c814716a05c)
  unreachable
bb27:
  %t109 = load i64, ptr %l40, !tbaa !24
  %t110 = load i64, ptr %l43, !tbaa !24
  %t111 = icmp sle i64 %t109, %t110
  br i1 %t111, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_ec3589048a52ea40_4feb0c814716a05c)
  unreachable
bb29:
  %t113 = load i64, ptr %l43, !tbaa !24
  %t114 = load i64, ptr %l44, !tbaa !24
  %t115 = icmp sle i64 %t113, %t114
  br i1 %t115, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_ec3589048a52ea40_4feb0c814716a05c)
  unreachable
bb31:
  %t117 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = load i64, ptr %l40, !tbaa !24
  %t120 = load i64, ptr %l43, !tbaa !24
  %t121 = getelementptr i8, ptr %t118, i64 %t119
  %t122 = sub i64 %t120, %t119
  %t123 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t121, 1
  store { i64, ptr } %t124, ptr %l48, !tbaa !27
  %t125 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 10)
  %t126 = extractvalue { i32, i64 } %t125, 1
  %t127 = extractvalue { i32, i64 } %t125, 0
  store i32 %t127, ptr %l50
  %t128 = icmp ne i32 %t127, 0
  br i1 %t128, label %bb34, label %ok.129, !prof !99
ok.129:
  store i64 %t126, ptr %l49
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_ec3589048a52ea40_4feb0c814716a05c)
  unreachable
bb33:
  %t130 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t131 = load i64, ptr %l49, !tbaa !24
  %t132 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %t130, i64 %t131)
  %t133 = extractvalue { i32, i64 } %t132, 1
  %t134 = extractvalue { i32, i64 } %t132, 0
  store i32 %t134, ptr %l52
  %t135 = icmp ne i32 %t134, 0
  br i1 %t135, label %bb37, label %ok.136, !prof !99
ok.136:
  store i64 %t133, ptr %l51
  br label %bb36
bb34:
  br label %bb35
bb35:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l37, !tbaa !24
  br label %bb38
bb36:
  %t137 = load i64, ptr %l51, !tbaa !24
  store i64 %t137, ptr %l37, !tbaa !24
  br label %bb38
bb37:
  br label %bb35
bb38:
  %t138 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t139 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t138, 0
  %t140 = load i64, ptr %l37, !tbaa !24
  %t141 = insertvalue { { i64, ptr }, i64 } %t139, i64 %t140, 1
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i64 } %t141, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, i64 }, ptr %rv
  ret { { i64, ptr }, i64 } %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fprofile_2efunctionSymbols(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %lp1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca i32
  %l35 = alloca i1
  %l40 = alloca i1
  %l41 = alloca { i64, ptr }
  %l45 = alloca i1
  %l46 = alloca { i64, ptr }
  %l51 = alloca i1
  %l52 = alloca { i64, ptr }
  %l59 = alloca i64
  %l62 = alloca i64
  %l65 = alloca i64
  %l70 = alloca i64
  %l73 = alloca i64
  %l105 = alloca i64
  %l108 = alloca i1
  %l115 = alloca i64
  %l120 = alloca i64
  %l125 = alloca i64
  %l130 = alloca i64
  %l139 = alloca i64
  %l142 = alloca i1
  %l155 = alloca i64
  %l158 = alloca i64
  %l185 = alloca i64
  %l186 = alloca { i64, ptr }
  %l193 = alloca i1
  %l196 = alloca i64
  %l200 = alloca i64
  %l207 = alloca i1
  %l208 = alloca { i64, ptr }
  %l216 = alloca ptr
  %l217 = alloca i64
  %l222 = alloca i64
  %l223 = alloca { i64, ptr }
  %l224 = alloca i64
  %l225 = alloca i64
  %l226 = alloca i64
  %l232 = alloca %"compiler/profile:elfFn"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aelfFn_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l29
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t7 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
  %t8 = extractvalue { i32, { i64, ptr } } %t7, 1
  %t9 = extractvalue { i32, { i64, ptr } } %t7, 0
  store i32 %t9, ptr %l33
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb3, label %ok.11, !prof !99
ok.11:
  store { i64, ptr } %t8, ptr %l32
  br label %bb2
bb2:
  %t12 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t12, ptr %l30, !tbaa !27
  br label %bb5
bb3:
  %t13 = load i32, ptr %l33, !tbaa !23
  %t14 = ashr i32 %t13, 16
  %t16 = icmp eq i32 %t14, 1
  store i1 %t16, ptr %l35, !tbaa !21
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  %t17 = load ptr, ptr %lp1
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t17
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %rv
  br label %ret
bb5:
  %t20 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t20, ptr %l2, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t25 = icmp slt i64 %t23, 64
  br i1 %t25, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb8
bb7:
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t27, ptr %l41, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr i8, ptr %t29, i64 0
  %t31 = load i8, ptr %t30, !tbaa !32
  %t34 = icmp ne i8 %t31, 127
  store i1 %t34, ptr %l40, !tbaa !21
  br label %bb8
bb8:
  %t36 = load i1, ptr %l40, !tbaa !21
  br i1 %t36, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb11
bb10:
  %t37 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t37, ptr %l46, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr i8, ptr %t39, i64 1
  %t41 = load i8, ptr %t40, !tbaa !32
  %t45 = icmp ne i8 %t41, 69
  store i1 %t45, ptr %l45, !tbaa !21
  br label %bb11
bb11:
  %t47 = load i1, ptr %l45, !tbaa !21
  br i1 %t47, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb14
bb13:
  %t48 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t48, ptr %l52, !tbaa !27
  %t49 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr i8, ptr %t50, i64 4
  %t52 = load i8, ptr %t51, !tbaa !32
  %t55 = icmp ne i8 %t52, 2
  store i1 %t55, ptr %l51, !tbaa !21
  br label %bb14
bb14:
  %t57 = load i1, ptr %l51, !tbaa !21
  br i1 %t57, label %bb15, label %bb16
bb15:
  %t58 = load ptr, ptr %lp1
  %t59 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t58
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t59, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t61 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t64 = call i64 @compiler_2fprofile_2ele(ptr %v1, { i64, ptr } %t61, i64 40, i64 8)
  store i64 %t64, ptr %l59
  br label %bb18
bb18:
  %t65 = load i64, ptr %l59, !tbaa !24
  store i64 %t65, ptr %l3, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t69 = call i64 @compiler_2fprofile_2ele(ptr %v1, { i64, ptr } %t66, i64 58, i64 2)
  store i64 %t69, ptr %l62
  br label %bb19
bb19:
  %t70 = load i64, ptr %l62, !tbaa !24
  store i64 %t70, ptr %l4, !tbaa !24
  %t71 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t74 = call i64 @compiler_2fprofile_2ele(ptr %v1, { i64, ptr } %t71, i64 60, i64 2)
  store i64 %t74, ptr %l65
  br label %bb20
bb20:
  %t75 = load i64, ptr %l65, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  store i64 %t75, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t78 = load i64, ptr %l7, !tbaa !24
  %t79 = load i64, ptr %l6, !tbaa !24
  %t82 = icmp sgt i64 %t78, %t79
  br i1 %t82, label %bb21, label %bb22
bb21:
  %t84 = load i64, ptr %l8, !tbaa !24
  %t86 = icmp sgt i64 %t84, 0
  br i1 %t86, label %bb23, label %bb24
bb22:
  store i64 0, ptr %l70, !tbaa !24
  br label %bb26
bb23:
  %t88 = load i64, ptr %l7, !tbaa !24
  %t89 = load i64, ptr %l6, !tbaa !24
  %t92 = sub i64 %t88, %t89
  %t93 = load i64, ptr %l8, !tbaa !24
  %t96 = add i64 %t92, %t93
  %t98 = sub i64 %t96, 1
  %t99 = load i64, ptr %l8, !tbaa !24
  %t102 = sdiv i64 %t98, %t99
  store i64 %t102, ptr %l73, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l73, !tbaa !24
  br label %bb25
bb25:
  %t104 = load i64, ptr %l73, !tbaa !24
  store i64 %t104, ptr %l70, !tbaa !24
  br label %bb26
bb26:
  %t105 = load i64, ptr %l70, !tbaa !24
  store i64 %t105, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb27
bb27:
  %t106 = load i64, ptr %l10, !tbaa !24
  %t107 = load i64, ptr %l9, !tbaa !24
  %t110 = icmp slt i64 %t106, %t107
  %t112 = xor i1 %t110, true
  br i1 %t112, label %bb28, label %bb29
bb28:
  br label %bb91
bb29:
  br label %bb30
bb30:
  %t114 = load i64, ptr %l6, !tbaa !24
  %t115 = load i64, ptr %l10, !tbaa !24
  %t116 = load i64, ptr %l8, !tbaa !24
  %t119 = mul i64 %t115, %t116
  %t122 = add i64 %t114, %t119
  %t124 = load i64, ptr %l3, !tbaa !24
  %t126 = load i64, ptr %l4, !tbaa !24
  %t129 = mul i64 %t122, %t126
  %t132 = add i64 %t124, %t129
  store i64 %t132, ptr %l12, !tbaa !24
  %t134 = load i64, ptr %l12, !tbaa !24
  %t136 = add i64 %t134, 64
  %t137 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t137, 0
  %t142 = icmp sgt i64 %t136, %t139
  br i1 %t142, label %bb31, label %bb32
bb31:
  br label %bb91
bb32:
  br label %bb33
bb33:
  %t144 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t146 = load i64, ptr %l12, !tbaa !24
  %t148 = add i64 %t146, 4
  %t151 = call i64 @compiler_2fprofile_2ele(ptr %v1, { i64, ptr } %t144, i64 %t148, i64 4)
  store i64 %t151, ptr %l105
  br label %bb34
bb34:
  %t152 = load i64, ptr %l105, !tbaa !24
  store i64 %t152, ptr %l13, !tbaa !24
  %t153 = load i64, ptr %l13, !tbaa !24
  %t155 = icmp ne i64 %t153, 2
  br i1 %t155, label %bb35, label %bb36
bb35:
  %t157 = load i64, ptr %l13, !tbaa !24
  %t159 = icmp ne i64 %t157, 11
  store i1 %t159, ptr %l108, !tbaa !21
  br label %bb37
bb36:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb37
bb37:
  %t161 = load i1, ptr %l108, !tbaa !21
  br i1 %t161, label %bb38, label %bb39
bb38:
  br label %bb90
bb39:
  br label %bb40
bb40:
  %t162 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t164 = load i64, ptr %l12, !tbaa !24
  %t166 = add i64 %t164, 24
  %t169 = call i64 @compiler_2fprofile_2ele(ptr %v1, { i64, ptr } %t162, i64 %t166, i64 8)
  store i64 %t169, ptr %l115
  br label %bb41
bb41:
  %t170 = load i64, ptr %l115, !tbaa !24
  store i64 %t170, ptr %l14, !tbaa !24
  %t171 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t173 = load i64, ptr %l12, !tbaa !24
  %t175 = add i64 %t173, 32
  %t178 = call i64 @compiler_2fprofile_2ele(ptr %v1, { i64, ptr } %t171, i64 %t175, i64 8)
  store i64 %t178, ptr %l120
  br label %bb42
bb42:
  %t179 = load i64, ptr %l120, !tbaa !24
  store i64 %t179, ptr %l15, !tbaa !24
  %t180 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t182 = load i64, ptr %l12, !tbaa !24
  %t184 = add i64 %t182, 40
  %t187 = call i64 @compiler_2fprofile_2ele(ptr %v1, { i64, ptr } %t180, i64 %t184, i64 4)
  store i64 %t187, ptr %l125
  br label %bb43
bb43:
  %t188 = load i64, ptr %l125, !tbaa !24
  store i64 %t188, ptr %l16, !tbaa !24
  %t189 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t191 = load i64, ptr %l12, !tbaa !24
  %t193 = add i64 %t191, 56
  %t196 = call i64 @compiler_2fprofile_2ele(ptr %v1, { i64, ptr } %t189, i64 %t193, i64 8)
  store i64 %t196, ptr %l130
  br label %bb44
bb44:
  %t197 = load i64, ptr %l130, !tbaa !24
  store i64 %t197, ptr %l17, !tbaa !24
  %t198 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t200 = load i64, ptr %l3, !tbaa !24
  %t201 = load i64, ptr %l16, !tbaa !24
  %t202 = load i64, ptr %l4, !tbaa !24
  %t205 = mul i64 %t201, %t202
  %t208 = add i64 %t200, %t205
  %t210 = add i64 %t208, 24
  %t213 = call i64 @compiler_2fprofile_2ele(ptr %v1, { i64, ptr } %t198, i64 %t210, i64 8)
  store i64 %t213, ptr %l139
  br label %bb45
bb45:
  %t214 = load i64, ptr %l139, !tbaa !24
  store i64 %t214, ptr %l18, !tbaa !24
  %t215 = load i64, ptr %l17, !tbaa !24
  %t217 = icmp slt i64 %t215, 24
  br i1 %t217, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l142, !tbaa !21
  br label %bb48
bb47:
  %t219 = load i64, ptr %l14, !tbaa !24
  %t220 = load i64, ptr %l15, !tbaa !24
  %t223 = add i64 %t219, %t220
  %t224 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t226 = extractvalue { i64, ptr } %t224, 0
  %t229 = icmp sgt i64 %t223, %t226
  store i1 %t229, ptr %l142, !tbaa !21
  br label %bb48
bb48:
  %t231 = load i1, ptr %l142, !tbaa !21
  br i1 %t231, label %bb49, label %bb50
bb49:
  br label %bb90
bb50:
  br label %bb51
bb51:
  store i64 0, ptr %l19, !tbaa !24
  %t232 = load i64, ptr %l15, !tbaa !24
  %t233 = load i64, ptr %l17, !tbaa !24
  %t236 = sdiv i64 %t232, %t233
  store i64 %t236, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t238 = load i64, ptr %l20, !tbaa !24
  %t239 = load i64, ptr %l19, !tbaa !24
  %t242 = icmp sgt i64 %t238, %t239
  br i1 %t242, label %bb52, label %bb53
bb52:
  %t244 = load i64, ptr %l21, !tbaa !24
  %t246 = icmp sgt i64 %t244, 0
  br i1 %t246, label %bb54, label %bb55
bb53:
  store i64 0, ptr %l155, !tbaa !24
  br label %bb57
bb54:
  %t248 = load i64, ptr %l20, !tbaa !24
  %t249 = load i64, ptr %l19, !tbaa !24
  %t252 = sub i64 %t248, %t249
  %t253 = load i64, ptr %l21, !tbaa !24
  %t256 = add i64 %t252, %t253
  %t258 = sub i64 %t256, 1
  %t259 = load i64, ptr %l21, !tbaa !24
  %t262 = sdiv i64 %t258, %t259
  store i64 %t262, ptr %l158, !tbaa !24
  br label %bb56
bb55:
  store i64 0, ptr %l158, !tbaa !24
  br label %bb56
bb56:
  %t264 = load i64, ptr %l158, !tbaa !24
  store i64 %t264, ptr %l155, !tbaa !24
  br label %bb57
bb57:
  %t265 = load i64, ptr %l155, !tbaa !24
  store i64 %t265, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb58
bb58:
  %t266 = load i64, ptr %l23, !tbaa !24
  %t267 = load i64, ptr %l22, !tbaa !24
  %t270 = icmp slt i64 %t266, %t267
  %t272 = xor i1 %t270, true
  br i1 %t272, label %bb59, label %bb60
bb59:
  br label %bb89
bb60:
  br label %bb61
bb61:
  %t274 = load i64, ptr %l19, !tbaa !24
  %t275 = load i64, ptr %l23, !tbaa !24
  %t276 = load i64, ptr %l21, !tbaa !24
  %t279 = mul i64 %t275, %t276
  %t282 = add i64 %t274, %t279
  %t284 = load i64, ptr %l14, !tbaa !24
  %t286 = load i64, ptr %l17, !tbaa !24
  %t289 = mul i64 %t282, %t286
  %t292 = add i64 %t284, %t289
  store i64 %t292, ptr %l25, !tbaa !24
  %t294 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t296 = load i64, ptr %l25, !tbaa !24
  %t298 = add i64 %t296, 8
  %t301 = call i64 @compiler_2fprofile_2ele(ptr %v1, { i64, ptr } %t294, i64 %t298, i64 8)
  store i64 %t301, ptr %l185
  br label %bb62
bb62:
  %t302 = load i64, ptr %l185, !tbaa !24
  store i64 %t302, ptr %l26, !tbaa !24
  %t303 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t303, ptr %l186, !tbaa !27
  %t304 = load i64, ptr %l25, !tbaa !24
  %t306 = add i64 %t304, 4
  %t308 = getelementptr { i64, ptr }, ptr %l186, i32 0, i32 1
  %t309 = load ptr, ptr %t308, !tbaa !27
  %t310 = getelementptr i8, ptr %t309, i64 %t306
  %t311 = load i8, ptr %t310, !tbaa !32
  %t313 = zext i8 %t311 to i64
  %t315 = and i64 %t313, 15
  %t317 = icmp ne i64 %t315, 2
  br i1 %t317, label %bb63, label %bb64
bb63:
  store i1 true, ptr %l193, !tbaa !21
  br label %bb65
bb64:
  %t319 = load i64, ptr %l26, !tbaa !24
  %t321 = icmp eq i64 %t319, 0
  store i1 %t321, ptr %l193, !tbaa !21
  br label %bb65
bb65:
  %t323 = load i1, ptr %l193, !tbaa !21
  br i1 %t323, label %bb66, label %bb67
bb66:
  br label %bb88
bb67:
  br label %bb68
bb68:
  %t324 = load i64, ptr %l18, !tbaa !24
  store i64 %t324, ptr %l196, !tbaa !24
  %t325 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t327 = load i64, ptr %l25, !tbaa !24
  %t330 = call i64 @compiler_2fprofile_2ele(ptr %v1, { i64, ptr } %t325, i64 %t327, i64 4)
  store i64 %t330, ptr %l200
  br label %bb69
bb69:
  %t331 = load i64, ptr %l196, !tbaa !24
  %t332 = load i64, ptr %l200, !tbaa !24
  %t333 = add i64 %t331, %t332
  store i64 %t333, ptr %l27, !tbaa !24
  %t335 = load i64, ptr %l27, !tbaa !24
  store i64 %t335, ptr %l28, !tbaa !24
  br label %bb70
bb70:
  %t337 = load i64, ptr %l28, !tbaa !24
  %t338 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t340 = extractvalue { i64, ptr } %t338, 0
  %t343 = icmp slt i64 %t337, %t340
  br i1 %t343, label %bb71, label %bb72
bb71:
  %t345 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t345, ptr %l208, !tbaa !27
  %t346 = load i64, ptr %l28, !tbaa !24
  %t348 = getelementptr { i64, ptr }, ptr %l208, i32 0, i32 1
  %t349 = load ptr, ptr %t348, !tbaa !27
  %t350 = getelementptr i8, ptr %t349, i64 %t346
  %t351 = load i8, ptr %t350, !tbaa !32
  %t354 = icmp ne i8 %t351, 0
  store i1 %t354, ptr %l207, !tbaa !21
  br label %bb73
bb72:
  store i1 false, ptr %l207, !tbaa !21
  br label %bb73
bb73:
  %t356 = load i1, ptr %l207, !tbaa !21
  %t357 = xor i1 %t356, true
  br i1 %t357, label %bb74, label %bb75
bb74:
  br label %bb78
bb75:
  br label %bb76
bb76:
  %t359 = load i64, ptr %l28, !tbaa !24
  %t361 = add i64 %t359, 1
  store i64 %t361, ptr %l28, !tbaa !24
  br label %bb77
bb77:
  br label %bb70
bb78:
  %t363 = load ptr, ptr %lp1
  store ptr %t363, ptr %l216, !tbaa !29
  %t364 = load i64, ptr %l26, !tbaa !24
  store i64 %t364, ptr %l217, !tbaa !24
  %t365 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t367 = load i64, ptr %l25, !tbaa !24
  %t369 = add i64 %t367, 16
  %t372 = call i64 @compiler_2fprofile_2ele(ptr %v1, { i64, ptr } %t365, i64 %t369, i64 8)
  store i64 %t372, ptr %l222
  br label %bb79
bb79:
  %t373 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t373, ptr %l223, !tbaa !27
  %t374 = load i64, ptr %l27, !tbaa !24
  store i64 %t374, ptr %l224, !tbaa !24
  %t375 = load i64, ptr %l28, !tbaa !24
  store i64 %t375, ptr %l225, !tbaa !24
  %t376 = load { i64, ptr }, ptr %l223, !tbaa !27
  %t377 = extractvalue { i64, ptr } %t376, 0
  store i64 %t377, ptr %l226, !tbaa !24
  %t378 = load i64, ptr %l224, !tbaa !24
  %t379 = icmp sge i64 %t378, 0
  br i1 %t379, label %bb80, label %bb81
bb80:
  %t381 = load i64, ptr %l224, !tbaa !24
  %t382 = load i64, ptr %l225, !tbaa !24
  %t383 = icmp sle i64 %t381, %t382
  br i1 %t383, label %bb82, label %bb83
bb81:
  call void @__olang_check_failed(ptr @olang_loc_47d41d181de998ca_407a2b261e632036)
  unreachable
bb82:
  %t385 = load i64, ptr %l225, !tbaa !24
  %t386 = load i64, ptr %l226, !tbaa !24
  %t387 = icmp sle i64 %t385, %t386
  br i1 %t387, label %bb84, label %bb85
bb83:
  call void @__olang_check_failed(ptr @olang_loc_47d41d181de998ca_407a2b261e632036)
  unreachable
bb84:
  %t389 = getelementptr { i64, ptr }, ptr %l223, i32 0, i32 1
  %t390 = load ptr, ptr %t389, !tbaa !27
  %t391 = load i64, ptr %l224, !tbaa !24
  %t392 = load i64, ptr %l225, !tbaa !24
  %t393 = getelementptr i8, ptr %t390, i64 %t391
  %t394 = sub i64 %t392, %t391
  %t395 = insertvalue { i64, ptr } undef, i64 %t394, 0
  %t396 = insertvalue { i64, ptr } %t395, ptr %t393, 1
  %t398 = load i64, ptr %l217, !tbaa !24
  %t399 = load i64, ptr %l222, !tbaa !24
  %t401 = call %"compiler/profile:elfFn" @compiler_2fprofile_3aelfFn_2ector(ptr %v1, ptr %v1, i64 %t398, i64 %t399, { i64, ptr } %t396)
  store %"compiler/profile:elfFn" %t401, ptr %l232
  br label %bb86
bb85:
  call void @__olang_check_failed(ptr @olang_loc_47d41d181de998ca_407a2b261e632036)
  unreachable
bb86:
  %t402 = load ptr, ptr %l216, !tbaa !29
  %t403 = load %"compiler/profile:elfFn", ptr %l232
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aelfFn_3e_2ePush_3ccompiler_2fprofile_3aelfFn_3e(ptr %v1, ptr %v1, ptr %t402, %"compiler/profile:elfFn" %t403)
  br label %bb87
bb87:
  br label %bb88
bb88:
  %t404 = load i64, ptr %l23, !tbaa !24
  %t406 = add i64 %t404, 1
  store i64 %t406, ptr %l23, !tbaa !24
  br label %bb58
bb89:
  br label %bb90
bb90:
  %t408 = load i64, ptr %l10, !tbaa !24
  %t410 = add i64 %t408, 1
  store i64 %t410, ptr %l10, !tbaa !24
  br label %bb27
bb91:
  %t412 = load ptr, ptr %lp1
  %t413 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_116, 0
  %t414 = insertvalue { ptr, ptr } %t413, ptr null, 1
  %t417 = extractvalue { ptr, ptr } %t414, 0
  %t418 = extractvalue { ptr, ptr } %t414, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aelfFn_3e_2eSort_3_H16cb1151e861568c30a5b57cf3c12bc1(ptr %v1, ptr %s0, ptr %t412, ptr %t417, ptr %t418)
  br label %bb92
bb92:
  %t419 = load ptr, ptr %lp1
  %t420 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t419
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t420, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i64 @compiler_2fprofile_2ehex(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  %t2 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 16)
  %t3 = extractvalue { i32, i64 } %t2, 1
  %t4 = extractvalue { i32, i64 } %t2, 0
  store i32 %t4, ptr %l4
  %t5 = icmp ne i32 %t4, 0
  br i1 %t5, label %bb2, label %ok.6, !prof !99
ok.6:
  store i64 %t3, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %t7, i64 %t8)
  %t10 = extractvalue { i32, i64 } %t9, 1
  %t11 = extractvalue { i32, i64 } %t9, 0
  store i32 %t11, ptr %l6
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb5, label %ok.13, !prof !99
ok.13:
  store i64 %t10, ptr %l5
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l1, !tbaa !24
  br label %bb6
bb4:
  %t14 = load i64, ptr %l5, !tbaa !24
  store i64 %t14, ptr %l1, !tbaa !24
  br label %bb6
bb5:
  br label %bb3
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t15 = load i64, ptr %l1, !tbaa !24
  store i64 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fprofile_2eidentityChar(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l2 = alloca i1
  %l3 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %rv = alloca i1
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l0, !tbaa !22
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t1)
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb5
bb3:
  %t5 = load i8, ptr %l0, !tbaa !22
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t5)
  store i1 %t7, ptr %l5
  br label %bb4
bb4:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb5
bb5:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb8
bb7:
  %t10 = load i8, ptr %l0, !tbaa !22
  %t12 = icmp eq i8 %t10, 95
  store i1 %t12, ptr %l6, !tbaa !21
  br label %bb8
bb8:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb11
bb10:
  %t15 = load i8, ptr %l0, !tbaa !22
  %t17 = icmp eq i8 %t15, 47
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb11
bb11:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb14
bb13:
  %t20 = load i8, ptr %l0, !tbaa !22
  %t22 = icmp eq i8 %t20, 45
  store i1 %t22, ptr %l12, !tbaa !21
  br label %bb14
bb14:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb17
bb16:
  %t25 = load i8, ptr %l0, !tbaa !22
  %t27 = icmp eq i8 %t25, 126
  store i1 %t27, ptr %l15, !tbaa !21
  br label %bb17
bb17:
  %t29 = load i1, ptr %l15, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fprofile_2ele(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l36 = alloca { i64, ptr }
  %l43 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  store i64 %a2, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t3 = load i64, ptr %l5, !tbaa !24
  %t4 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l6, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l6, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l6, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l17, !tbaa !24
  store i64 %t29, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l14, !tbaa !24
  store i64 %t30, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb7
bb7:
  %t31 = load i64, ptr %l8, !tbaa !24
  %t32 = load i64, ptr %l7, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t39 = load i64, ptr %l4, !tbaa !24
  %t40 = load i64, ptr %l8, !tbaa !24
  %t41 = load i64, ptr %l6, !tbaa !24
  %t44 = mul i64 %t40, %t41
  %t47 = add i64 %t39, %t44
  store i64 %t47, ptr %l9, !tbaa !24
  %t49 = load i64, ptr %l3, !tbaa !24
  store { i64, ptr } %a0, ptr %l36, !tbaa !27
  %t52 = load i64, ptr %l9, !tbaa !24
  %t55 = add i64 %a1, %t52
  %t57 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr i8, ptr %t58, i64 %t55
  %t60 = load i8, ptr %t59, !tbaa !32
  %t62 = zext i8 %t60 to i64
  %t63 = load i64, ptr %l9, !tbaa !24
  %t65 = mul i64 %t63, 8
  store i64 %t65, ptr %l43, !tbaa !24
  %t67 = load i64, ptr %l43, !tbaa !24
  %t68 = load i64, ptr %l43, !tbaa !24
  %t69 = shl i64 %t62, %t68
  %t72 = or i64 %t49, %t69
  store i64 %t72, ptr %l3, !tbaa !24
  br label %bb11
bb11:
  %t74 = load i64, ptr %l8, !tbaa !24
  %t76 = add i64 %t74, 1
  store i64 %t76, ptr %l8, !tbaa !24
  br label %bb7
bb12:
  %t78 = load i64, ptr %l3, !tbaa !24
  store i64 %t78, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fprofile_2emappings(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %lp1 = alloca ptr
  %l2 = alloca %"std/prelude/text:LineIter"
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/text:StringBuilder"
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/text:LineIter"
  %l20 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i32
  %l25 = alloca i1
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l39 = alloca i1
  %l48 = alloca i64
  %l50 = alloca i64
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca i32
  %l57 = alloca %"std/prelude/text:StringBuilder"
  %l59 = alloca i64
  %l63 = alloca i64
  %l66 = alloca i64
  %l87 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l93 = alloca ptr
  %l95 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l97 = alloca i64
  %l98 = alloca i64
  %l103 = alloca i64
  %l105 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  %l108 = alloca i64
  %l110 = alloca { i64, ptr }
  %l113 = alloca i64
  %l114 = alloca i64
  %l119 = alloca i64
  %l121 = alloca { i64, ptr }
  %l122 = alloca i64
  %l124 = alloca { i64, ptr }
  %l125 = alloca %"compiler/profile:mapping"
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3amapping_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l17
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t7 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store %"std/prelude/text:LineIter" %t7, ptr %l19
  br label %bb2
bb2:
  %t8 = load %"std/prelude/text:LineIter", ptr %l19
  store %"std/prelude/text:LineIter" %t8, ptr %l2
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v0, ptr %l2)
  %t11 = extractvalue { i32, { i64, ptr } } %t10, 1
  %t12 = extractvalue { i32, { i64, ptr } } %t10, 0
  store i32 %t12, ptr %l23
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb5, label %ok.14, !prof !99
ok.14:
  store { i64, ptr } %t11, ptr %l22
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t15, ptr %l20, !tbaa !27
  br label %bb7
bb5:
  %t16 = load i32, ptr %l23, !tbaa !23
  %t17 = ashr i32 %t16, 16
  %t19 = icmp eq i32 %t17, 1
  store i1 %t19, ptr %l25, !tbaa !21
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb76
bb7:
  %t20 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  %t21 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l26
  br label %bb8
bb8:
  %t22 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l4
  store %olang.scope zeroinitializer, ptr %s3
  %t23 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t25 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %s3, ptr %s3, { i64, ptr } %t23, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d117, i32 0, i32 1) })
  store { i64, ptr } %t25, ptr %l28
  br label %bb9
bb9:
  %t26 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t26, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t27 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  store i64 %t29, ptr %l7, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t31 = load i64, ptr %l6, !tbaa !24
  %t32 = load i64, ptr %l7, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s4)
  br label %bb20
bb12:
  br label %bb13
bb13:
  %t39 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t39, ptr %l35, !tbaa !27
  %t40 = load i64, ptr %l6, !tbaa !24
  %t42 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %t43, i64 %t40
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !37
  store { i64, ptr } %t45, ptr %l8, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t49 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s3, ptr %s4, { i64, ptr } %t47, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d118, i32 0, i32 1) })
  store i1 %t49, ptr %l39
  br label %bb14
bb14:
  %t50 = load i1, ptr %l39, !tbaa !21
  %t51 = xor i1 %t50, true
  br i1 %t51, label %bb15, label %bb16
bb15:
  %t53 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 1
  %t56 = extractvalue { i64, ptr } %t53, 0
  %t57 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t55, i64 %t56)
  %t58 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  %t61 = extractvalue { i64, ptr } %t59, 0
  %t62 = extractvalue { i64, ptr } %t59, 1
  %t63 = mul i64 %t61, 1
  %t64 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t63)
  call void @llvm.memcpy.p0.p0.i64(ptr %t64, ptr %t62, i64 %t63, i1 false)
  %t65 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t64, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s2, ptr %s2, ptr %l4, { i64, ptr } %t66)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb19
bb19:
  %t69 = load i64, ptr %l6, !tbaa !24
  %t71 = add i64 %t69, 1
  store i64 %t71, ptr %l6, !tbaa !24
  br label %bb10
bb20:
  call void @__olang_scope_close(ptr %s3)
  %t74 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s2, ptr %l4)
  store i64 %t74, ptr %l48
  br label %bb21
bb21:
  %t75 = load i64, ptr %l48, !tbaa !24
  %t76 = icmp slt i64 %t75, 6
  br i1 %t76, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s2)
  br label %bb75
bb23:
  br label %bb24
bb24:
  %t79 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s2, ptr %s2, ptr %l4, i64 0)
  store { i64, ptr } %t79, ptr %l52
  br label %bb25
bb25:
  %t80 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t81 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s2, ptr %s2, { i64, ptr } %t80, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d119, i32 0, i32 1) })
  %t82 = extractvalue { i32, i64 } %t81, 1
  %t83 = extractvalue { i32, i64 } %t81, 0
  store i32 %t83, ptr %l54
  %t84 = icmp ne i32 %t83, 0
  br i1 %t84, label %bb27, label %ok.85, !prof !99
ok.85:
  store i64 %t82, ptr %l53
  br label %bb26
bb26:
  %t86 = load i64, ptr %l53, !tbaa !24
  store i64 %t86, ptr %l50, !tbaa !24
  br label %bb29
bb27:
  br label %bb28
bb28:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l50, !tbaa !24
  br label %bb29
bb29:
  %t87 = load i64, ptr %l50, !tbaa !24
  store i64 %t87, ptr %l9, !tbaa !24
  %t88 = load i64, ptr %l9, !tbaa !24
  %t90 = icmp slt i64 %t88, 0
  br i1 %t90, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s2)
  br label %bb75
bb31:
  br label %bb32
bb32:
  %t92 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s2)
  store %"std/prelude/text:StringBuilder" %t92, ptr %l57
  br label %bb33
bb33:
  %t93 = load %"std/prelude/text:StringBuilder", ptr %l57
  store %"std/prelude/text:StringBuilder" %t93, ptr %l10
  store i64 5, ptr %l11, !tbaa !24
  %t95 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s2, ptr %l4)
  store i64 %t95, ptr %l59
  br label %bb34
bb34:
  %t96 = load i64, ptr %l59, !tbaa !24
  store i64 %t96, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t97 = load i64, ptr %l12, !tbaa !24
  %t98 = load i64, ptr %l11, !tbaa !24
  %t101 = icmp sgt i64 %t97, %t98
  br i1 %t101, label %bb35, label %bb36
bb35:
  %t103 = load i64, ptr %l13, !tbaa !24
  %t105 = icmp sgt i64 %t103, 0
  br i1 %t105, label %bb37, label %bb38
bb36:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb40
bb37:
  %t107 = load i64, ptr %l12, !tbaa !24
  %t108 = load i64, ptr %l11, !tbaa !24
  %t111 = sub i64 %t107, %t108
  %t112 = load i64, ptr %l13, !tbaa !24
  %t115 = add i64 %t111, %t112
  %t117 = sub i64 %t115, 1
  %t118 = load i64, ptr %l13, !tbaa !24
  %t121 = sdiv i64 %t117, %t118
  store i64 %t121, ptr %l66, !tbaa !24
  br label %bb39
bb38:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb39
bb39:
  %t123 = load i64, ptr %l66, !tbaa !24
  store i64 %t123, ptr %l63, !tbaa !24
  br label %bb40
bb40:
  %t124 = load i64, ptr %l63, !tbaa !24
  store i64 %t124, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb41
bb41:
  %t125 = load i64, ptr %l15, !tbaa !24
  %t126 = load i64, ptr %l14, !tbaa !24
  %t129 = icmp slt i64 %t125, %t126
  %t131 = xor i1 %t129, true
  br i1 %t131, label %bb42, label %bb43
bb42:
  br label %bb52
bb43:
  br label %bb44
bb44:
  %t133 = load i64, ptr %l11, !tbaa !24
  %t134 = load i64, ptr %l15, !tbaa !24
  %t135 = load i64, ptr %l13, !tbaa !24
  %t138 = mul i64 %t134, %t135
  %t141 = add i64 %t133, %t138
  store i64 %t141, ptr %l16, !tbaa !24
  %t143 = load i64, ptr %l16, !tbaa !24
  %t145 = icmp sgt i64 %t143, 5
  br i1 %t145, label %bb45, label %bb46
bb45:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s2, ptr %l10, i8 32)
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb48
bb48:
  store ptr %l10, ptr %l87, !tbaa !29
  %t148 = load i64, ptr %l16, !tbaa !24
  %t151 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s2, ptr %s2, ptr %l4, i64 %t148)
  store { i64, ptr } %t151, ptr %l90
  br label %bb49
bb49:
  %t152 = load ptr, ptr %l87, !tbaa !29
  %t153 = load { i64, ptr }, ptr %l90, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s2, ptr %s2, ptr %t152, { i64, ptr } %t153)
  br label %bb50
bb50:
  br label %bb51
bb51:
  %t154 = load i64, ptr %l15, !tbaa !24
  %t156 = add i64 %t154, 1
  store i64 %t156, ptr %l15, !tbaa !24
  br label %bb41
bb52:
  %t158 = load ptr, ptr %lp1
  store ptr %t158, ptr %l93, !tbaa !29
  %t160 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s2, ptr %s2, ptr %l4, i64 0)
  store { i64, ptr } %t160, ptr %l95
  br label %bb53
bb53:
  %t161 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t161, ptr %l96, !tbaa !27
  %t162 = load i64, ptr %l9, !tbaa !24
  store i64 %t162, ptr %l97, !tbaa !24
  %t163 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t164 = extractvalue { i64, ptr } %t163, 0
  store i64 %t164, ptr %l98, !tbaa !24
  %t165 = icmp sge i64 0, 0
  br i1 %t165, label %bb54, label %bb55
bb54:
  %t167 = load i64, ptr %l97, !tbaa !24
  %t168 = icmp sle i64 0, %t167
  br i1 %t168, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_49a351722641e944_c5b141a1c073228)
  unreachable
bb56:
  %t170 = load i64, ptr %l97, !tbaa !24
  %t171 = load i64, ptr %l98, !tbaa !24
  %t172 = icmp sle i64 %t170, %t171
  br i1 %t172, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @olang_loc_49a351722641e944_c5b141a1c073228)
  unreachable
bb58:
  %t174 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !27
  %t176 = load i64, ptr %l97, !tbaa !24
  %t177 = getelementptr i8, ptr %t175, i64 0
  %t178 = sub i64 %t176, 0
  %t179 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t180 = insertvalue { i64, ptr } %t179, ptr %t177, 1
  %t182 = call i64 @compiler_2fprofile_2ehex(ptr %s2, { i64, ptr } %t180)
  store i64 %t182, ptr %l103
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_49a351722641e944_c5b141a1c073228)
  unreachable
bb60:
  %t184 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s2, ptr %s2, ptr %l4, i64 0)
  store { i64, ptr } %t184, ptr %l105
  br label %bb61
bb61:
  %t185 = load { i64, ptr }, ptr %l105, !tbaa !27
  store { i64, ptr } %t185, ptr %l106, !tbaa !27
  %t186 = load i64, ptr %l9, !tbaa !24
  %t188 = add i64 %t186, 1
  store i64 %t188, ptr %l108, !tbaa !24
  %t190 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s2, ptr %s2, ptr %l4, i64 0)
  store { i64, ptr } %t190, ptr %l110
  br label %bb62
bb62:
  %t191 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t194 = extractvalue { i64, ptr } %t191, 0
  store i64 %t194, ptr %l113, !tbaa !24
  %t195 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t195, 0
  store i64 %t196, ptr %l114, !tbaa !24
  %t197 = load i64, ptr %l108, !tbaa !24
  %t198 = icmp sge i64 %t197, 0
  br i1 %t198, label %bb63, label %bb64
bb63:
  %t200 = load i64, ptr %l108, !tbaa !24
  %t201 = load i64, ptr %l113, !tbaa !24
  %t202 = icmp sle i64 %t200, %t201
  br i1 %t202, label %bb65, label %bb66
bb64:
  call void @__olang_check_failed(ptr @olang_loc_49a351722641e944_c5b141a1c073228)
  unreachable
bb65:
  %t204 = load i64, ptr %l113, !tbaa !24
  %t205 = load i64, ptr %l114, !tbaa !24
  %t206 = icmp sle i64 %t204, %t205
  br i1 %t206, label %bb67, label %bb68
bb66:
  call void @__olang_check_failed(ptr @olang_loc_49a351722641e944_c5b141a1c073228)
  unreachable
bb67:
  %t208 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = load i64, ptr %l108, !tbaa !24
  %t211 = load i64, ptr %l113, !tbaa !24
  %t212 = getelementptr i8, ptr %t209, i64 %t210
  %t213 = sub i64 %t211, %t210
  %t214 = insertvalue { i64, ptr } undef, i64 %t213, 0
  %t215 = insertvalue { i64, ptr } %t214, ptr %t212, 1
  %t217 = call i64 @compiler_2fprofile_2ehex(ptr %s2, { i64, ptr } %t215)
  store i64 %t217, ptr %l119
  br label %bb69
bb68:
  call void @__olang_check_failed(ptr @olang_loc_49a351722641e944_c5b141a1c073228)
  unreachable
bb69:
  %t219 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s2, ptr %s2, ptr %l4, i64 2)
  store { i64, ptr } %t219, ptr %l121
  br label %bb70
bb70:
  %t220 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t221 = call i64 @compiler_2fprofile_2ehex(ptr %s2, { i64, ptr } %t220)
  store i64 %t221, ptr %l122
  br label %bb71
bb71:
  %t223 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s2, ptr %v1, ptr %l10)
  store { i64, ptr } %t223, ptr %l124
  br label %bb72
bb72:
  %t224 = load i64, ptr %l103, !tbaa !24
  %t225 = load i64, ptr %l119, !tbaa !24
  %t226 = load i64, ptr %l122, !tbaa !24
  %t227 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t228 = call %"compiler/profile:mapping" @compiler_2fprofile_3amapping_2ector(ptr %v1, ptr %v1, i64 %t224, i64 %t225, i64 %t226, { i64, ptr } %t227)
  store %"compiler/profile:mapping" %t228, ptr %l125
  br label %bb73
bb73:
  %t229 = load ptr, ptr %l93, !tbaa !29
  %t230 = load %"compiler/profile:mapping", ptr %l125
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3amapping_3e_2ePush_Hc0dd0b8028ee4ec7edce99e352ae7bbd(ptr %v1, ptr %v1, ptr %t229, %"compiler/profile:mapping" %t230)
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s2)
  br label %bb75
bb75:
  br label %bb3
bb76:
  %t231 = load ptr, ptr %lp1
  %t232 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t231
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t232, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local { i64, ptr } @compiler_2fprofile_2emillis(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %l8 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = sitofp i64 %a0 to double
  %t6 = sitofp i64 %a1 to double
  %t9 = fmul double %t3, %t6
  %t11 = fdiv double %t9, 0x412e848000000000
  %t13 = call { i64, ptr } @std_2fprelude_2ffloat_2eF64_2eFixed(ptr %v0, double %t11, i64 1)
  store { i64, ptr } %t13, ptr %l8
  br label %bb1
bb1:
  %t14 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t14, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fprofile_2epct(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l4 = alloca double
  %l7 = alloca i64
  %l11 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = sitofp i64 %a0 to double
  %t5 = fmul double %t3, 0x4059000000000000
  store double %t5, ptr %l4, !tbaa !26
  %t6 = load i64, ptr %l1, !tbaa !24
  %t8 = icmp sgt i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i64, ptr %l1, !tbaa !24
  store i64 %t10, ptr %l7, !tbaa !24
  br label %bb3
bb2:
  store i64 1, ptr %l7, !tbaa !24
  br label %bb3
bb3:
  %t12 = load i64, ptr %l7, !tbaa !24
  %t13 = sitofp i64 %t12 to double
  %t14 = load double, ptr %l4, !tbaa !26
  %t16 = fdiv double %t14, %t13
  %t18 = call { i64, ptr } @std_2fprelude_2ffloat_2eF64_2eFixed(ptr %s0, double %t16, i64 1)
  store { i64, ptr } %t18, ptr %l11
  br label %bb4
bb4:
  %t19 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 1
  %t21 = extractvalue { i64, ptr } %t19, 0
  %t22 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d120, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d120, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t25 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t24)
  call void @olang_textcopy(ptr %t25, ptr %t20, i64 %t21)
  %t26 = getelementptr i8, ptr %t25, i64 %t21
  call void @olang_textcopy(ptr %t26, ptr %t22, i64 %t23)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t25, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t28, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fprofile_2equalifier(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l3 = alloca i1
  %l4 = alloca i1
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca { i64, ptr }
  %l17 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d121, i32 0, i32 1) })
  store i1 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb5
bb3:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d122, i32 0, i32 1) })
  store i1 %t7, ptr %l6
  br label %bb4
bb4:
  %t8 = load i1, ptr %l6, !tbaa !21
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb5
bb5:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d123, i32 0, i32 1) }, ptr %l7, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t10, ptr %l8, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  store i64 %t12, ptr %l9, !tbaa !24
  %t13 = load i64, ptr %l9, !tbaa !24
  %t14 = mul i64 %t13, 1
  %t15 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l10, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = load i64, ptr %l9, !tbaa !24
  %t23 = mul i64 %t22, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t19, ptr %t21, i64 %t23, i1 false)
  %t24 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t24, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t25 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t25, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t26 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t28 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s0, { i64, ptr } %t26, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d124, i32 0, i32 1) })
  %t29 = extractvalue { i32, i64 } %t28, 1
  %t30 = extractvalue { i32, i64 } %t28, 0
  store i32 %t30, ptr %l14
  %t31 = icmp ne i32 %t30, 0
  br i1 %t31, label %bb10, label %ok.32, !prof !99
ok.32:
  store i64 %t29, ptr %l13
  br label %bb9
bb9:
  %t33 = load i64, ptr %l13, !tbaa !24
  store i64 %t33, ptr %l11, !tbaa !24
  br label %bb12
bb10:
  br label %bb11
bb11:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l11, !tbaa !24
  br label %bb12
bb12:
  %t34 = load i64, ptr %l11, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t35, ptr %l15, !tbaa !27
  %t38 = add i64 %t34, 1
  store i64 %t38, ptr %l17, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t39, 0
  store i64 %t42, ptr %l20, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t43, 0
  store i64 %t44, ptr %l21, !tbaa !24
  %t45 = load i64, ptr %l17, !tbaa !24
  %t46 = icmp sge i64 %t45, 0
  br i1 %t46, label %bb13, label %bb14
bb13:
  %t48 = load i64, ptr %l17, !tbaa !24
  %t49 = load i64, ptr %l20, !tbaa !24
  %t50 = icmp sle i64 %t48, %t49
  br i1 %t50, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_8377dd777846f8d9_8488686b399fded)
  unreachable
bb15:
  %t52 = load i64, ptr %l20, !tbaa !24
  %t53 = load i64, ptr %l21, !tbaa !24
  %t54 = icmp sle i64 %t52, %t53
  br i1 %t54, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_8377dd777846f8d9_8488686b399fded)
  unreachable
bb17:
  %t56 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = load i64, ptr %l17, !tbaa !24
  %t59 = load i64, ptr %l20, !tbaa !24
  %t60 = getelementptr i8, ptr %t57, i64 %t58
  %t61 = sub i64 %t59, %t58
  %t62 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t60, 1
  %t65 = extractvalue { i64, ptr } %t63, 1
  %t66 = extractvalue { i64, ptr } %t63, 0
  %t67 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d125, i32 0, i32 1) }, 1
  %t68 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d125, i32 0, i32 1) }, 0
  %t69 = add i64 %t66, %t68
  %t70 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t69)
  call void @olang_textcopy(ptr %t70, ptr %t65, i64 %t66)
  %t71 = getelementptr i8, ptr %t70, i64 %t66
  call void @olang_textcopy(ptr %t71, ptr %t67, i64 %t68)
  %t72 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t70, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t73, ptr %rv
  br label %ret
bb18:
  call void @__olang_check_failed(ptr @olang_loc_8377dd777846f8d9_8488686b399fded)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fprofile_2erunProfiled(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca [1 x i32]
  %l13 = alloca i32
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l40 = alloca i32
  %l41 = alloca i32
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca i32
  %l51 = alloca i1
  %l52 = alloca { i64, ptr }
  %l54 = alloca i32
  %l58 = alloca i64
  %l59 = alloca i64
  %l64 = alloca i32
  %l70 = alloca i1
  %l73 = alloca i64
  %l75 = alloca i64
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l14
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l4
  %t5 = extractvalue { i64, ptr } %a1, 1
  %t6 = extractvalue { i64, ptr } %a1, 0
  %t7 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t6)
  call void @olang_textcopy(ptr %t7, ptr %t5, i64 %t6)
  %t8 = insertvalue { i64, ptr } undef, i64 %t6, 0
  %t9 = insertvalue { i64, ptr } %t8, ptr %t7, 1
  %t11 = extractvalue { i64, ptr } %t9, 0
  %t12 = extractvalue { i64, ptr } %t9, 1
  %t13 = mul i64 %t11, 1
  %t14 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t13)
  call void @llvm.memcpy.p0.p0.i64(ptr %t14, ptr %t12, i64 %t13, i1 false)
  %t15 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } %t16)
  br label %bb2
bb2:
  store { i64, ptr } %a2, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l7, !tbaa !24
  br label %bb3
bb3:
  %t25 = load i64, ptr %l6, !tbaa !24
  %t26 = load i64, ptr %l7, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb4, label %bb5
bb4:
  br label %bb9
bb5:
  br label %bb6
bb6:
  %t33 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t33, ptr %l26, !tbaa !27
  %t34 = load i64, ptr %l6, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %t37, i64 %t34
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !37
  %t43 = extractvalue { i64, ptr } %t39, 1
  %t44 = extractvalue { i64, ptr } %t39, 0
  %t45 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t44)
  call void @olang_textcopy(ptr %t45, ptr %t43, i64 %t44)
  %t46 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  %t49 = extractvalue { i64, ptr } %t47, 0
  %t50 = extractvalue { i64, ptr } %t47, 1
  %t51 = mul i64 %t49, 1
  %t52 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t51)
  call void @llvm.memcpy.p0.p0.i64(ptr %t52, ptr %t50, i64 %t51, i1 false)
  %t53 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } %t54)
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t57 = load i64, ptr %l6, !tbaa !24
  %t59 = add i64 %t57, 1
  store i64 %t59, ptr %l6, !tbaa !24
  br label %bb3
bb9:
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d126, i32 0, i32 1) }, ptr %l35, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t64 = extractvalue { i64, ptr } %a3, 1
  %t65 = extractvalue { i64, ptr } %a3, 0
  %t66 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d127, i32 0, i32 1) }, 1
  %t67 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d127, i32 0, i32 1) }, 0
  %t68 = add i64 %t65, %t67
  %t69 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t68)
  call void @olang_textcopy(ptr %t69, ptr %t64, i64 %t65)
  %t70 = getelementptr i8, ptr %t69, i64 %t65
  call void @olang_textcopy(ptr %t70, ptr %t66, i64 %t67)
  %t71 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t69, 1
  %t75 = extractvalue { i64, ptr } %t61, 1
  %t76 = extractvalue { i64, ptr } %t61, 0
  %t78 = extractvalue { i64, ptr } %t72, 1
  %t79 = extractvalue { i64, ptr } %t72, 0
  %t80 = call i32 @setenv(ptr %t75, ptr %t78, i32 1)
  store i32 %t80, ptr %l40
  br label %bb10
bb10:
  %t81 = call i32 @fork()
  store i32 %t81, ptr %l41
  br label %bb11
bb11:
  %t82 = load i32, ptr %l41, !tbaa !23
  store i32 %t82, ptr %l9, !tbaa !23
  %t83 = load i32, ptr %l9, !tbaa !23
  %t85 = icmp eq i32 %t83, 0
  br i1 %t85, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s7
  %t89 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %v0, ptr %s7, { i64, ptr } %a0)
  store { i64, ptr } %t89, ptr %l45
  br label %bb14
bb13:
  br label %bb21
bb14:
  %t90 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  %t92 = extractvalue { i64, ptr } %t90, 1
  %t93 = mul i64 %t91, 1
  %t94 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t93)
  call void @llvm.memcpy.p0.p0.i64(ptr %t94, ptr %t92, i64 %t93, i1 false)
  %t95 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  store { i64, ptr } %t96, ptr %l46, !tbaa !27
  %t98 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s0, ptr %s0, ptr %l4)
  store { i64, ptr } %t98, ptr %l48
  br label %bb15
bb15:
  %t99 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t101 = call i32 @std_2fos_2eExecInPlace(ptr %s7, ptr %s0, { i64, ptr } %t99, { i64, ptr } %t100)
  store i32 %t101, ptr %l49
  %t102 = icmp ne i32 %t101, 0
  br i1 %t102, label %bb17, label %ok.103, !prof !99
ok.103:
  br label %bb16
bb16:
  br label %bb19
bb17:
  %t104 = load i32, ptr %l49, !tbaa !23
  %t105 = ashr i32 %t104, 16
  %t107 = icmp eq i32 %t105, 1
  store i1 %t107, ptr %l51, !tbaa !21
  br label %bb18
bb18:
  call void @__olang_ert_req_clear()
  br label %bb19
bb19:
  call void @_exit(i32 127)
  unreachable
bb20:
  call void @__olang_check_failed(ptr @olang_loc_ec22c3592c386ac4_6a748f217c4c44c0)
  unreachable
bb21:
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d128, i32 0, i32 1) }, ptr %l52, !tbaa !27
  %t108 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t108, 1
  %t111 = extractvalue { i64, ptr } %t108, 0
  %t112 = call i32 @unsetenv(ptr %t110)
  store i32 %t112, ptr %l54
  br label %bb22
bb22:
  %t113 = load i32, ptr %l9, !tbaa !23
  %t115 = icmp slt i32 %t113, 0
  br i1 %t115, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s0)
  store i32 -1, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t118 = call i64 @signal(i32 2, i64 1)
  store i64 %t118, ptr %l58
  br label %bb26
bb26:
  %t119 = load i64, ptr %l58, !tbaa !24
  store i64 %t119, ptr %l10, !tbaa !24
  %t120 = call i64 @signal(i32 3, i64 1)
  store i64 %t120, ptr %l59
  br label %bb27
bb27:
  %t121 = load i64, ptr %l59, !tbaa !24
  store i64 %t121, ptr %l11, !tbaa !24
  %t122 = insertvalue [1 x i32] undef, i32 0, 0
  store [1 x i32] %t122, ptr %l12
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s10
  %t124 = load i32, ptr %l9, !tbaa !23
  %t126 = insertvalue { i64, ptr } undef, i64 1, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %l12, 1
  %t130 = extractvalue { i64, ptr } %t127, 1
  %t131 = extractvalue { i64, ptr } %t127, 0
  %t132 = call i32 @waitpid(i32 %t124, ptr %t130, i32 0)
  store i32 %t132, ptr %l64
  br label %bb29
bb29:
  %t133 = load i32, ptr %l64, !tbaa !23
  %t134 = icmp slt i32 %t133, 0
  %t136 = xor i1 %t134, true
  br i1 %t136, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s10)
  br label %bb38
bb31:
  br label %bb32
bb32:
  %t138 = load i32, ptr %l9, !tbaa !23
  %t139 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d129, i32 0, i32 1) }, 1
  %t140 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d129, i32 0, i32 1) }, 0
  %t142 = sext i32 %t138 to i64
  %t143 = call i64 @__olang_fmt_i64(ptr null, i64 %t142)
  %t144 = add i64 %t140, %t143
  %t145 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t144)
  call void @olang_textcopy(ptr %t145, ptr %t139, i64 %t140)
  %t146 = getelementptr i8, ptr %t145, i64 %t140
  %t147 = call i64 @__olang_fmt_i64(ptr %t146, i64 %t142)
  %t148 = insertvalue { i64, ptr } undef, i64 %t144, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t145, 1
  %t151 = extractvalue { i64, ptr } %t149, 0
  %t152 = extractvalue { i64, ptr } %t149, 1
  %t153 = mul i64 %t151, 1
  %t154 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t153)
  call void @llvm.memcpy.p0.p0.i64(ptr %t154, ptr %t152, i64 %t153, i1 false)
  %t155 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t154, 1
  %t158 = call i1 @std_2fos_2eExists(ptr %s10, { i64, ptr } %t156)
  store i1 %t158, ptr %l70
  br label %bb33
bb33:
  %t159 = load i1, ptr %l70, !tbaa !21
  %t160 = xor i1 %t159, true
  br i1 %t160, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s10)
  br label %bb38
bb35:
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s10)
  br label %bb37
bb37:
  br label %bb28
bb38:
  %t162 = load i64, ptr %l10, !tbaa !24
  %t164 = call i64 @signal(i32 2, i64 %t162)
  store i64 %t164, ptr %l73
  br label %bb39
bb39:
  %t165 = load i64, ptr %l11, !tbaa !24
  %t167 = call i64 @signal(i32 3, i64 %t165)
  store i64 %t167, ptr %l75
  br label %bb40
bb40:
  %t168 = getelementptr [1 x i32], ptr %l12, i64 0, i64 0
  %t169 = load i32, ptr %t168, !tbaa !33
  store i32 %t169, ptr %l13, !tbaa !23
  %t171 = load i32, ptr %l13, !tbaa !23
  %t173 = and i32 %t171, 127
  %t175 = icmp ne i32 %t173, 0
  br i1 %t175, label %bb41, label %bb42
bb41:
  %t177 = load i32, ptr %l13, !tbaa !23
  %t179 = and i32 %t177, 127
  %t181 = add i32 128, %t179
  call void @__olang_scope_close(ptr %s0)
  store i32 %t181, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  %t183 = load i32, ptr %l13, !tbaa !23
  %t185 = ashr i32 %t183, 8
  %t187 = and i32 %t185, 255
  call void @__olang_scope_close(ptr %s0)
  store i32 %t187, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fprofile_2esampleFile(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca { i64, ptr }
  %l62 = alloca i64
  %l65 = alloca i64
  %l86 = alloca i64
  %l101 = alloca { i64, ptr }
  %l107 = alloca i64
  %l110 = alloca i64
  %l131 = alloca i64
  %l146 = alloca { i64, ptr }
  %l155 = alloca { i64, ptr }
  %l156 = alloca { i64, ptr }
  %l157 = alloca i64
  %l158 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU8_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l31
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d130, i32 0, i32 1) }, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l38, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i8, ptr %t19, i64 %t16
  %t21 = load i8, ptr %t20, !tbaa !32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %s0, ptr %l2, i8 %t21)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t27 = load i64, ptr %l4, !tbaa !24
  %t29 = add i64 %t27, 1
  store i64 %t29, ptr %l4, !tbaa !24
  br label %bb2
bb8:
  store %olang.scope zeroinitializer, ptr %s4
  %t31 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = insertvalue [4 x i64] undef, i64 1000000, 0
  %t36 = insertvalue [4 x i64] %t34, i64 %t33, 1
  %t37 = insertvalue [4 x i64] %t36, i64 2, 2
  %t38 = insertvalue [4 x i64] %t37, i64 1, 3
  %t40 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 32, i64 8)
  store [4 x i64] %t38, ptr %t40
  store ptr %t40, ptr %l7
  store i64 0, ptr %l8, !tbaa !24
  %t42 = load ptr, ptr %l7
  store i64 4, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  %t45 = load i64, ptr %l8, !tbaa !24
  %t46 = load i64, ptr %l9, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb10, label %bb11
bb10:
  br label %bb27
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l7
  %t54 = load i64, ptr %l8, !tbaa !24
  %t57 = getelementptr [4 x i64], ptr %t53, i64 0, i64 %t54
  %t58 = load i64, ptr %t57, !tbaa !34
  store i64 %t58, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  store i64 8, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t60 = load i64, ptr %l12, !tbaa !24
  %t61 = load i64, ptr %l11, !tbaa !24
  %t64 = icmp sgt i64 %t60, %t61
  br i1 %t64, label %bb13, label %bb14
bb13:
  %t66 = load i64, ptr %l13, !tbaa !24
  %t68 = icmp sgt i64 %t66, 0
  br i1 %t68, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb18
bb15:
  %t70 = load i64, ptr %l12, !tbaa !24
  %t71 = load i64, ptr %l11, !tbaa !24
  %t74 = sub i64 %t70, %t71
  %t75 = load i64, ptr %l13, !tbaa !24
  %t78 = add i64 %t74, %t75
  %t80 = sub i64 %t78, 1
  %t81 = load i64, ptr %l13, !tbaa !24
  %t84 = sdiv i64 %t80, %t81
  store i64 %t84, ptr %l65, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l65, !tbaa !24
  br label %bb17
bb17:
  %t86 = load i64, ptr %l65, !tbaa !24
  store i64 %t86, ptr %l62, !tbaa !24
  br label %bb18
bb18:
  %t87 = load i64, ptr %l62, !tbaa !24
  store i64 %t87, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb19
bb19:
  %t88 = load i64, ptr %l15, !tbaa !24
  %t89 = load i64, ptr %l14, !tbaa !24
  %t92 = icmp slt i64 %t88, %t89
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb20, label %bb21
bb20:
  br label %bb25
bb21:
  br label %bb22
bb22:
  %t96 = load i64, ptr %l11, !tbaa !24
  %t97 = load i64, ptr %l15, !tbaa !24
  %t98 = load i64, ptr %l13, !tbaa !24
  %t101 = mul i64 %t97, %t98
  %t104 = add i64 %t96, %t101
  %t106 = load i64, ptr %l10, !tbaa !24
  %t109 = mul i64 %t104, 8
  store i64 %t109, ptr %l86, !tbaa !24
  %t111 = load i64, ptr %l86, !tbaa !24
  %t112 = load i64, ptr %l86, !tbaa !24
  %t113 = ashr i64 %t106, %t112
  %t115 = and i64 %t113, 255
  %t117 = trunc i64 %t115 to i8
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %s0, ptr %l2, i8 %t117)
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t120 = load i64, ptr %l15, !tbaa !24
  %t122 = add i64 %t120, 1
  store i64 %t122, ptr %l15, !tbaa !24
  br label %bb19
bb25:
  br label %bb26
bb26:
  %t124 = load i64, ptr %l8, !tbaa !24
  %t126 = add i64 %t124, 1
  store i64 %t126, ptr %l8, !tbaa !24
  br label %bb9
bb27:
  call void @__olang_scope_close(ptr %s4)
  %t128 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t128, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t130 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t130, 0
  store i64 %t132, ptr %l19, !tbaa !24
  br label %bb28
bb28:
  %t134 = load i64, ptr %l18, !tbaa !24
  %t135 = load i64, ptr %l19, !tbaa !24
  %t138 = icmp slt i64 %t134, %t135
  %t140 = xor i1 %t138, true
  br i1 %t140, label %bb29, label %bb30
bb29:
  br label %bb46
bb30:
  br label %bb31
bb31:
  %t142 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t142, ptr %l101, !tbaa !27
  %t143 = load i64, ptr %l18, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr i64, ptr %t146, i64 %t143
  %t148 = load i64, ptr %t147, !tbaa !34
  store i64 %t148, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  store i64 8, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t150 = load i64, ptr %l22, !tbaa !24
  %t151 = load i64, ptr %l21, !tbaa !24
  %t154 = icmp sgt i64 %t150, %t151
  br i1 %t154, label %bb32, label %bb33
bb32:
  %t156 = load i64, ptr %l23, !tbaa !24
  %t158 = icmp sgt i64 %t156, 0
  br i1 %t158, label %bb34, label %bb35
bb33:
  store i64 0, ptr %l107, !tbaa !24
  br label %bb37
bb34:
  %t160 = load i64, ptr %l22, !tbaa !24
  %t161 = load i64, ptr %l21, !tbaa !24
  %t164 = sub i64 %t160, %t161
  %t165 = load i64, ptr %l23, !tbaa !24
  %t168 = add i64 %t164, %t165
  %t170 = sub i64 %t168, 1
  %t171 = load i64, ptr %l23, !tbaa !24
  %t174 = sdiv i64 %t170, %t171
  store i64 %t174, ptr %l110, !tbaa !24
  br label %bb36
bb35:
  store i64 0, ptr %l110, !tbaa !24
  br label %bb36
bb36:
  %t176 = load i64, ptr %l110, !tbaa !24
  store i64 %t176, ptr %l107, !tbaa !24
  br label %bb37
bb37:
  %t177 = load i64, ptr %l107, !tbaa !24
  store i64 %t177, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb38
bb38:
  %t178 = load i64, ptr %l25, !tbaa !24
  %t179 = load i64, ptr %l24, !tbaa !24
  %t182 = icmp slt i64 %t178, %t179
  %t184 = xor i1 %t182, true
  br i1 %t184, label %bb39, label %bb40
bb39:
  br label %bb44
bb40:
  br label %bb41
bb41:
  %t186 = load i64, ptr %l21, !tbaa !24
  %t187 = load i64, ptr %l25, !tbaa !24
  %t188 = load i64, ptr %l23, !tbaa !24
  %t191 = mul i64 %t187, %t188
  %t194 = add i64 %t186, %t191
  %t196 = load i64, ptr %l20, !tbaa !24
  %t199 = mul i64 %t194, 8
  store i64 %t199, ptr %l131, !tbaa !24
  %t201 = load i64, ptr %l131, !tbaa !24
  %t202 = load i64, ptr %l131, !tbaa !24
  %t203 = ashr i64 %t196, %t202
  %t205 = and i64 %t203, 255
  %t207 = trunc i64 %t205 to i8
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %s0, ptr %l2, i8 %t207)
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t210 = load i64, ptr %l25, !tbaa !24
  %t212 = add i64 %t210, 1
  store i64 %t212, ptr %l25, !tbaa !24
  br label %bb38
bb44:
  br label %bb45
bb45:
  %t214 = load i64, ptr %l18, !tbaa !24
  %t216 = add i64 %t214, 1
  store i64 %t216, ptr %l18, !tbaa !24
  br label %bb28
bb46:
  store { i64, ptr } %a1, ptr %l27, !tbaa !27
  store i64 0, ptr %l28, !tbaa !24
  %t220 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t222 = extractvalue { i64, ptr } %t220, 0
  store i64 %t222, ptr %l29, !tbaa !24
  br label %bb47
bb47:
  %t224 = load i64, ptr %l28, !tbaa !24
  %t225 = load i64, ptr %l29, !tbaa !24
  %t228 = icmp slt i64 %t224, %t225
  %t230 = xor i1 %t228, true
  br i1 %t230, label %bb48, label %bb49
bb48:
  br label %bb53
bb49:
  br label %bb50
bb50:
  %t232 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t232, ptr %l146, !tbaa !27
  %t233 = load i64, ptr %l28, !tbaa !24
  %t235 = getelementptr { i64, ptr }, ptr %l146, i32 0, i32 1
  %t236 = load ptr, ptr %t235, !tbaa !27
  %t237 = getelementptr i8, ptr %t236, i64 %t233
  %t238 = load i8, ptr %t237, !tbaa !32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %s0, ptr %l2, i8 %t238)
  br label %bb51
bb51:
  br label %bb52
bb52:
  %t244 = load i64, ptr %l28, !tbaa !24
  %t246 = add i64 %t244, 1
  store i64 %t246, ptr %l28, !tbaa !24
  br label %bb47
bb53:
  %t249 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eToArray_3cU8_3e(ptr %s0, ptr %s0, ptr %l2)
  store { i64, ptr } %t249, ptr %l155
  br label %bb54
bb54:
  %t250 = load { i64, ptr }, ptr %l155, !tbaa !27
  store { i64, ptr } %t250, ptr %l156, !tbaa !27
  %t251 = load { i64, ptr }, ptr %l156, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t251, 0
  store i64 %t252, ptr %l157, !tbaa !24
  %t253 = load i64, ptr %l157, !tbaa !24
  %t254 = mul i64 %t253, 1
  %t255 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t254)
  %t256 = insertvalue { i64, ptr } undef, i64 %t253, 0
  %t257 = insertvalue { i64, ptr } %t256, ptr %t255, 1
  store { i64, ptr } %t257, ptr %l158, !tbaa !27
  %t258 = getelementptr { i64, ptr }, ptr %l158, i32 0, i32 1
  %t259 = load ptr, ptr %t258, !tbaa !27
  %t260 = getelementptr { i64, ptr }, ptr %l156, i32 0, i32 1
  %t261 = load ptr, ptr %t260, !tbaa !27
  %t262 = load i64, ptr %l157, !tbaa !24
  %t263 = mul i64 %t262, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t259, ptr %t261, i64 %t263, i1 false)
  %t264 = load { i64, ptr }, ptr %l158, !tbaa !27
  store { i64, ptr } %t264, ptr %l156, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t265 = load { i64, ptr }, ptr %l156, !tbaa !27
  store { i64, ptr } %t265, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fprofile_2esay(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca i32
  %l4 = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %a0)
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  br label %bb1
bb1:
  br label %bb4
bb2:
  %t6 = load i32, ptr %l2, !tbaa !23
  %t7 = ashr i32 %t6, 16
  %t9 = icmp eq i32 %t7, 1
  store i1 %t9, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  br label %bb4
bb4:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fprofile_2esegments(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %lp1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l20 = alloca i1
  %l25 = alloca i1
  %l26 = alloca { i64, ptr }
  %l30 = alloca i1
  %l31 = alloca { i64, ptr }
  %l36 = alloca i1
  %l37 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l65 = alloca i64
  %l68 = alloca i64
  %l96 = alloca i1
  %l105 = alloca i64
  %l108 = alloca ptr
  %l113 = alloca i64
  %l114 = alloca ptr
  %l119 = alloca i64
  %l120 = alloca ptr
  %l125 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l14
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t7 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %s0, { i64, ptr } %a0)
  %t8 = extractvalue { i32, { i64, ptr } } %t7, 1
  %t9 = extractvalue { i32, { i64, ptr } } %t7, 0
  store i32 %t9, ptr %l18
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb3, label %ok.11, !prof !99
ok.11:
  store { i64, ptr } %t8, ptr %l17
  br label %bb2
bb2:
  %t12 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t12, ptr %l15, !tbaa !27
  br label %bb5
bb3:
  %t13 = load i32, ptr %l18, !tbaa !23
  %t14 = ashr i32 %t13, 16
  %t16 = icmp eq i32 %t14, 1
  store i1 %t16, ptr %l20, !tbaa !21
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  %t17 = load ptr, ptr %lp1
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t17
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %rv
  br label %ret
bb5:
  %t20 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t20, ptr %l2, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t25 = icmp slt i64 %t23, 64
  br i1 %t25, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb8
bb7:
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t27, ptr %l26, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr i8, ptr %t29, i64 0
  %t31 = load i8, ptr %t30, !tbaa !32
  %t34 = icmp ne i8 %t31, 127
  store i1 %t34, ptr %l25, !tbaa !21
  br label %bb8
bb8:
  %t36 = load i1, ptr %l25, !tbaa !21
  br i1 %t36, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb11
bb10:
  %t37 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t37, ptr %l31, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr i8, ptr %t39, i64 1
  %t41 = load i8, ptr %t40, !tbaa !32
  %t45 = icmp ne i8 %t41, 69
  store i1 %t45, ptr %l30, !tbaa !21
  br label %bb11
bb11:
  %t47 = load i1, ptr %l30, !tbaa !21
  br i1 %t47, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb14
bb13:
  %t48 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t48, ptr %l37, !tbaa !27
  %t49 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr i8, ptr %t50, i64 4
  %t52 = load i8, ptr %t51, !tbaa !32
  %t55 = icmp ne i8 %t52, 2
  store i1 %t55, ptr %l36, !tbaa !21
  br label %bb14
bb14:
  %t57 = load i1, ptr %l36, !tbaa !21
  br i1 %t57, label %bb15, label %bb16
bb15:
  %t58 = load ptr, ptr %lp1
  %t59 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t58
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t59, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t61 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t64 = call i64 @compiler_2fprofile_2eword(ptr %s0, { i64, ptr } %t61, i64 4)
  store i64 %t64, ptr %l44
  br label %bb18
bb18:
  %t65 = load i64, ptr %l44, !tbaa !24
  store i64 %t65, ptr %l3, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t66, ptr %l45, !tbaa !27
  %t67 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr i8, ptr %t68, i64 54
  %t70 = load i8, ptr %t69, !tbaa !32
  %t72 = zext i8 %t70 to i64
  %t73 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t73, ptr %l48, !tbaa !27
  %t74 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr i8, ptr %t75, i64 55
  %t77 = load i8, ptr %t76, !tbaa !32
  %t79 = zext i8 %t77 to i64
  %t81 = shl i64 %t79, 8
  %t84 = or i64 %t72, %t81
  store i64 %t84, ptr %l4, !tbaa !24
  %t86 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t86, ptr %l53, !tbaa !27
  %t87 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr i8, ptr %t88, i64 56
  %t90 = load i8, ptr %t89, !tbaa !32
  %t92 = zext i8 %t90 to i64
  %t93 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t93, ptr %l56, !tbaa !27
  %t94 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr i8, ptr %t95, i64 57
  %t97 = load i8, ptr %t96, !tbaa !32
  %t99 = zext i8 %t97 to i64
  %t101 = shl i64 %t99, 8
  %t104 = or i64 %t92, %t101
  store i64 0, ptr %l6, !tbaa !24
  store i64 %t104, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t108 = load i64, ptr %l7, !tbaa !24
  %t109 = load i64, ptr %l6, !tbaa !24
  %t112 = icmp sgt i64 %t108, %t109
  br i1 %t112, label %bb19, label %bb20
bb19:
  %t114 = load i64, ptr %l8, !tbaa !24
  %t116 = icmp sgt i64 %t114, 0
  br i1 %t116, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l65, !tbaa !24
  br label %bb24
bb21:
  %t118 = load i64, ptr %l7, !tbaa !24
  %t119 = load i64, ptr %l6, !tbaa !24
  %t122 = sub i64 %t118, %t119
  %t123 = load i64, ptr %l8, !tbaa !24
  %t126 = add i64 %t122, %t123
  %t128 = sub i64 %t126, 1
  %t129 = load i64, ptr %l8, !tbaa !24
  %t132 = sdiv i64 %t128, %t129
  store i64 %t132, ptr %l68, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l68, !tbaa !24
  br label %bb23
bb23:
  %t134 = load i64, ptr %l68, !tbaa !24
  store i64 %t134, ptr %l65, !tbaa !24
  br label %bb24
bb24:
  %t135 = load i64, ptr %l65, !tbaa !24
  store i64 %t135, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb25
bb25:
  %t136 = load i64, ptr %l10, !tbaa !24
  %t137 = load i64, ptr %l9, !tbaa !24
  %t140 = icmp slt i64 %t136, %t137
  %t142 = xor i1 %t140, true
  br i1 %t142, label %bb26, label %bb27
bb26:
  br label %bb46
bb27:
  br label %bb28
bb28:
  %t144 = load i64, ptr %l6, !tbaa !24
  %t145 = load i64, ptr %l10, !tbaa !24
  %t146 = load i64, ptr %l8, !tbaa !24
  %t149 = mul i64 %t145, %t146
  %t152 = add i64 %t144, %t149
  %t154 = load i64, ptr %l3, !tbaa !24
  %t156 = load i64, ptr %l4, !tbaa !24
  %t159 = mul i64 %t152, %t156
  %t162 = add i64 %t154, %t159
  store i64 %t162, ptr %l12, !tbaa !24
  %t164 = load i64, ptr %l12, !tbaa !24
  %t166 = add i64 %t164, 56
  %t167 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t167, 0
  %t172 = icmp sgt i64 %t166, %t169
  br i1 %t172, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l96, !tbaa !21
  br label %bb31
bb30:
  %t174 = load i64, ptr %l12, !tbaa !24
  %t176 = srem i64 %t174, 8
  %t178 = icmp ne i64 %t176, 0
  store i1 %t178, ptr %l96, !tbaa !21
  br label %bb31
bb31:
  %t180 = load i1, ptr %l96, !tbaa !21
  br i1 %t180, label %bb32, label %bb33
bb32:
  br label %bb46
bb33:
  br label %bb34
bb34:
  %t181 = load i64, ptr %l12, !tbaa !24
  %t183 = sdiv i64 %t181, 8
  store i64 %t183, ptr %l13, !tbaa !24
  %t185 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t187 = load i64, ptr %l13, !tbaa !24
  %t190 = call i64 @compiler_2fprofile_2eword(ptr %s0, { i64, ptr } %t185, i64 %t187)
  store i64 %t190, ptr %l105
  br label %bb35
bb35:
  %t191 = load i64, ptr %l105, !tbaa !24
  %t192 = and i64 %t191, 4294967295
  %t194 = icmp ne i64 %t192, 1
  br i1 %t194, label %bb36, label %bb37
bb36:
  br label %bb45
bb37:
  br label %bb38
bb38:
  %t196 = load ptr, ptr %lp1
  store ptr %t196, ptr %l108, !tbaa !29
  %t197 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t199 = load i64, ptr %l13, !tbaa !24
  %t201 = add i64 %t199, 1
  %t204 = call i64 @compiler_2fprofile_2eword(ptr %s0, { i64, ptr } %t197, i64 %t201)
  store i64 %t204, ptr %l113
  br label %bb39
bb39:
  %t205 = load ptr, ptr %l108, !tbaa !29
  %t206 = load i64, ptr %l113, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t205, i64 %t206)
  br label %bb40
bb40:
  %t207 = load ptr, ptr %lp1
  store ptr %t207, ptr %l114, !tbaa !29
  %t208 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t210 = load i64, ptr %l13, !tbaa !24
  %t212 = add i64 %t210, 4
  %t215 = call i64 @compiler_2fprofile_2eword(ptr %s0, { i64, ptr } %t208, i64 %t212)
  store i64 %t215, ptr %l119
  br label %bb41
bb41:
  %t216 = load ptr, ptr %l114, !tbaa !29
  %t217 = load i64, ptr %l119, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t216, i64 %t217)
  br label %bb42
bb42:
  %t218 = load ptr, ptr %lp1
  store ptr %t218, ptr %l120, !tbaa !29
  %t219 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t221 = load i64, ptr %l13, !tbaa !24
  %t223 = add i64 %t221, 2
  %t226 = call i64 @compiler_2fprofile_2eword(ptr %s0, { i64, ptr } %t219, i64 %t223)
  store i64 %t226, ptr %l125
  br label %bb43
bb43:
  %t227 = load ptr, ptr %l120, !tbaa !29
  %t228 = load i64, ptr %l125, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t227, i64 %t228)
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t229 = load i64, ptr %l10, !tbaa !24
  %t231 = add i64 %t229, 1
  store i64 %t231, ptr %l10, !tbaa !24
  br label %bb25
bb46:
  %t233 = load ptr, ptr %lp1
  %t234 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t233
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t234, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local { i64, ptr } @compiler_2fprofile_2eshortPath(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l6 = alloca i1
  %l8 = alloca i1
  %l13 = alloca i1
  %l14 = alloca { i64, ptr }
  %l17 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %s0)
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l4
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  store { i64, ptr } %t2, ptr %l3
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d131, i32 0, i32 1) }, ptr %l2, !tbaa !27
  br label %bb4
bb4:
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t7, ptr %l1, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t10 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t8, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d132, i32 0, i32 1) })
  store i1 %t10, ptr %l6
  br label %bb5
bb5:
  %t11 = load i1, ptr %l6, !tbaa !21
  %t12 = xor i1 %t11, true
  br i1 %t12, label %bb6, label %bb7
bb6:
  %t14 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = extractvalue { i64, ptr } %t15, 0
  %t19 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d133, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d133, i32 0, i32 1) }, 0
  %t21 = add i64 %t18, %t20
  %t22 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t21)
  call void @olang_textcopy(ptr %t22, ptr %t17, i64 %t18)
  %t23 = getelementptr i8, ptr %t22, i64 %t18
  call void @olang_textcopy(ptr %t23, ptr %t19, i64 %t20)
  %t24 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t22, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t28 = extractvalue { i64, ptr } %t25, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t14, { i64, ptr } %t32)
  store i1 %t35, ptr %l13
  br label %bb8
bb7:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb9
bb8:
  %t36 = load i1, ptr %l13, !tbaa !21
  store i1 %t36, ptr %l8, !tbaa !21
  br label %bb9
bb9:
  %t37 = load i1, ptr %l8, !tbaa !21
  br i1 %t37, label %bb10, label %bb11
bb10:
  %t38 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t38, ptr %l14, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t43 = add i64 %t41, 1
  store i64 %t43, ptr %l17, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t44, 0
  store i64 %t47, ptr %l20, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 0
  store i64 %t49, ptr %l21, !tbaa !24
  %t50 = load i64, ptr %l17, !tbaa !24
  %t51 = icmp sge i64 %t50, 0
  br i1 %t51, label %bb12, label %bb13
bb11:
  br label %bb18
bb12:
  %t53 = load i64, ptr %l17, !tbaa !24
  %t54 = load i64, ptr %l20, !tbaa !24
  %t55 = icmp sle i64 %t53, %t54
  br i1 %t55, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_9b07e838cb7ed4ee_978ead1b2c1f88ba)
  unreachable
bb14:
  %t57 = load i64, ptr %l20, !tbaa !24
  %t58 = load i64, ptr %l21, !tbaa !24
  %t59 = icmp sle i64 %t57, %t58
  br i1 %t59, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_9b07e838cb7ed4ee_978ead1b2c1f88ba)
  unreachable
bb16:
  %t61 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = load i64, ptr %l17, !tbaa !24
  %t64 = load i64, ptr %l20, !tbaa !24
  %t65 = getelementptr i8, ptr %t62, i64 %t63
  %t66 = sub i64 %t64, %t63
  %t67 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t65, 1
  %t70 = extractvalue { i64, ptr } %t68, 1
  %t71 = extractvalue { i64, ptr } %t68, 0
  %t72 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t71)
  call void @olang_textcopy(ptr %t72, ptr %t70, i64 %t71)
  %t73 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t74, ptr %rv
  br label %ret
bb17:
  call void @__olang_check_failed(ptr @olang_loc_9b07e838cb7ed4ee_978ead1b2c1f88ba)
  unreachable
bb18:
  %t76 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t76, 1
  %t79 = extractvalue { i64, ptr } %t76, 0
  %t80 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t79)
  call void @olang_textcopy(ptr %t80, ptr %t78, i64 %t79)
  %t81 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t80, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t82, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fprofile_2esymbolAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca i64
  %l19 = alloca %"compiler/profile:elfFn"
  %l30 = alloca i1
  %l36 = alloca i64
  %l40 = alloca %"compiler/profile:elfFn"
  %l41 = alloca i64
  %l45 = alloca %"compiler/profile:elfFn"
  %l48 = alloca i64
  %l52 = alloca %"compiler/profile:elfFn"
  %l59 = alloca %"compiler/profile:elfFn"
  %l64 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aelfFn_3e_2eLen_3ccompiler_2fprofile_3aelfFn_3e(ptr %v0, ptr %t1)
  store i64 %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load i64, ptr %l7, !tbaa !24
  store i64 %t4, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp slt i64 %t5, %t6
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t13 = load i64, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = add i64 %t13, %t14
  %t19 = sdiv i64 %t17, 2
  store i64 %t19, ptr %l4, !tbaa !24
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i64, ptr %l4, !tbaa !24
  %t26 = call %"compiler/profile:elfFn" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aelfFn_3e_2eAt_3ccompiler_2fprofile_3aelfFn_3e(ptr %v0, ptr %s1, ptr %t21, i64 %t23)
  store %"compiler/profile:elfFn" %t26, ptr %l19
  br label %bb6
bb6:
  %t27 = getelementptr %"compiler/profile:elfFn", ptr %l19, i32 0, i32 0
  %t28 = load i64, ptr %t27, !tbaa !24
  %t29 = load i64, ptr %l1, !tbaa !24
  %t32 = icmp sle i64 %t28, %t29
  br i1 %t32, label %bb7, label %bb8
bb7:
  %t34 = load i64, ptr %l4, !tbaa !24
  %t36 = add i64 %t34, 1
  store i64 %t36, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  %t38 = load i64, ptr %l4, !tbaa !24
  store i64 %t38, ptr %l3, !tbaa !24
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb10:
  br label %bb2
bb11:
  %t40 = load i64, ptr %l2, !tbaa !24
  %t42 = sub i64 %t40, 1
  store i64 %t42, ptr %l5, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s5
  %t44 = load i64, ptr %l5, !tbaa !24
  %t46 = icmp sge i64 %t44, 0
  br i1 %t46, label %bb13, label %bb14
bb13:
  %t48 = load i64, ptr %l5, !tbaa !24
  %t49 = load i64, ptr %l2, !tbaa !24
  %t51 = sub i64 %t49, 4
  %t54 = icmp sge i64 %t48, %t51
  store i1 %t54, ptr %l30, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb15
bb15:
  %t56 = load i1, ptr %l30, !tbaa !21
  %t57 = xor i1 %t56, true
  br i1 %t57, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s5)
  br label %bb30
bb17:
  br label %bb18
bb18:
  %t59 = load i64, ptr %l1, !tbaa !24
  store i64 %t59, ptr %l36, !tbaa !24
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i64, ptr %l5, !tbaa !24
  %t65 = call %"compiler/profile:elfFn" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aelfFn_3e_2eAt_3ccompiler_2fprofile_3aelfFn_3e(ptr %v0, ptr %s5, ptr %t60, i64 %t62)
  store %"compiler/profile:elfFn" %t65, ptr %l40
  br label %bb19
bb19:
  %t66 = getelementptr %"compiler/profile:elfFn", ptr %l40, i32 0, i32 0
  %t67 = load i64, ptr %t66, !tbaa !24
  store i64 %t67, ptr %l41, !tbaa !24
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i64, ptr %l5, !tbaa !24
  %t73 = call %"compiler/profile:elfFn" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aelfFn_3e_2eAt_3ccompiler_2fprofile_3aelfFn_3e(ptr %v0, ptr %s5, ptr %t68, i64 %t70)
  store %"compiler/profile:elfFn" %t73, ptr %l45
  br label %bb20
bb20:
  %t74 = getelementptr %"compiler/profile:elfFn", ptr %l45, i32 0, i32 1
  %t75 = load i64, ptr %t74, !tbaa !24
  %t77 = icmp sgt i64 %t75, 0
  br i1 %t77, label %bb21, label %bb22
bb21:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i64, ptr %l5, !tbaa !24
  %t84 = call %"compiler/profile:elfFn" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aelfFn_3e_2eAt_3ccompiler_2fprofile_3aelfFn_3e(ptr %v0, ptr %s5, ptr %t79, i64 %t81)
  store %"compiler/profile:elfFn" %t84, ptr %l52
  br label %bb23
bb22:
  store i64 1, ptr %l48, !tbaa !24
  br label %bb24
bb23:
  %t85 = getelementptr %"compiler/profile:elfFn", ptr %l52, i32 0, i32 1
  %t86 = load i64, ptr %t85, !tbaa !24
  store i64 %t86, ptr %l48, !tbaa !24
  br label %bb24
bb24:
  %t88 = load i64, ptr %l41, !tbaa !24
  %t89 = load i64, ptr %l48, !tbaa !24
  %t90 = add i64 %t88, %t89
  %t91 = load i64, ptr %l36, !tbaa !24
  %t93 = icmp slt i64 %t91, %t90
  br i1 %t93, label %bb25, label %bb26
bb25:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = load i64, ptr %l5, !tbaa !24
  %t100 = call %"compiler/profile:elfFn" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aelfFn_3e_2eAt_3ccompiler_2fprofile_3aelfFn_3e(ptr %v0, ptr %v0, ptr %t95, i64 %t97)
  store %"compiler/profile:elfFn" %t100, ptr %l59
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t101 = getelementptr %"compiler/profile:elfFn", ptr %l59, i32 0, i32 2
  %t102 = load { i64, ptr }, ptr %t101, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t102, 1
  %t105 = extractvalue { i64, ptr } %t102, 0
  %t106 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t105)
  call void @olang_textcopy(ptr %t106, ptr %t104, i64 %t105)
  %t107 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  call void @__olang_scope_close(ptr %s5)
  store { i64, ptr } %t108, ptr %rv
  br label %ret
bb28:
  call void @__olang_scope_close(ptr %s5)
  br label %bb29
bb29:
  %t110 = load i64, ptr %l5, !tbaa !24
  %t112 = sub i64 %t110, 1
  store i64 %t112, ptr %l5, !tbaa !24
  br label %bb12
bb30:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d134, i32 0, i32 1) }, ptr %l64, !tbaa !27
  %t114 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t114, ptr %l65, !tbaa !27
  %t115 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t115, 0
  store i64 %t116, ptr %l66, !tbaa !24
  %t117 = load i64, ptr %l66, !tbaa !24
  %t118 = mul i64 %t117, 1
  %t119 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t118)
  %t120 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t121 = insertvalue { i64, ptr } %t120, ptr %t119, 1
  store { i64, ptr } %t121, ptr %l67, !tbaa !27
  %t122 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = load i64, ptr %l66, !tbaa !24
  %t127 = mul i64 %t126, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t123, ptr %t125, i64 %t127, i1 false)
  %t128 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t128, ptr %l65, !tbaa !27
  %t129 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t129, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fprofile_2etwoStacks(ptr %out, ptr %v0) #0 {
entry:
  %lp0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %lp5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca %"compiler/profile:Profile"
  %l12 = alloca ptr
  %l13 = alloca %"compiler/profile:Sample"
  %l14 = alloca ptr
  %l15 = alloca %"compiler/profile:Sample"
  %l31 = alloca %"compiler/profile:Places"
  %l52 = alloca ptr
  %l54 = alloca i64
  %l56 = alloca i64
  %l57 = alloca %"compiler/profile:Frame"
  %l58 = alloca ptr
  %l60 = alloca i64
  %l62 = alloca i64
  %l63 = alloca %"compiler/profile:Frame"
  %l64 = alloca ptr
  %l66 = alloca i64
  %l68 = alloca i64
  %l69 = alloca %"compiler/profile:Frame"
  %l71 = alloca %"compiler/profile:Places"
  %l72 = alloca { %"compiler/profile:Profile", %"compiler/profile:Places" }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %t51 = alloca %"compiler/profile:Places", align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/profile:Profile" @compiler_2fprofile_3aProfile_2ector(ptr %v0)
  store %"compiler/profile:Profile" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 104, i64 8)
  store ptr %t2, ptr %lp0
  %t3 = load %"compiler/profile:Profile", ptr %l11
  %t4 = load ptr, ptr %lp0
  store %"compiler/profile:Profile" %t3, ptr %t4
  %t5 = load ptr, ptr %lp0
  %t6 = getelementptr %"compiler/profile:Profile", ptr %t5, i32 0, i32 2
  store i64 1, ptr %t6, !tbaa !24
  %t7 = load ptr, ptr %lp0
  %t8 = getelementptr %"compiler/profile:Profile", ptr %t7, i32 0, i32 3
  store ptr %t8, ptr %l12, !tbaa !29
  %t9 = call %"compiler/profile:Sample" @compiler_2fprofile_3aSample_2ector(ptr %s0, i64 3, i64 0, i64 2)
  store %"compiler/profile:Sample" %t9, ptr %l13
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l12, !tbaa !29
  %t11 = load %"compiler/profile:Sample", ptr %l13
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2ePush_3ccompiler_2fprofile_3aSample_3e(ptr %v0, ptr %t10, %"compiler/profile:Sample" %t11)
  br label %bb3
bb3:
  %t12 = load ptr, ptr %lp0
  %t13 = getelementptr %"compiler/profile:Profile", ptr %t12, i32 0, i32 3
  store ptr %t13, ptr %l14, !tbaa !29
  %t14 = call %"compiler/profile:Sample" @compiler_2fprofile_3aSample_2ector(ptr %s0, i64 1, i64 2, i64 2)
  store %"compiler/profile:Sample" %t14, ptr %l15
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l14, !tbaa !29
  %t16 = load %"compiler/profile:Sample", ptr %l15
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2ePush_3ccompiler_2fprofile_3aSample_3e(ptr %v0, ptr %t15, %"compiler/profile:Sample" %t16)
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = insertvalue [4 x i64] undef, i64 100, 0
  %t18 = insertvalue [4 x i64] %t17, i64 201, 1
  %t19 = insertvalue [4 x i64] %t18, i64 300, 2
  %t20 = insertvalue [4 x i64] %t19, i64 201, 3
  %t22 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store [4 x i64] %t20, ptr %t22
  store ptr %t22, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t24 = load ptr, ptr %l1
  store i64 4, ptr %l3, !tbaa !24
  br label %bb6
bb6:
  %t27 = load i64, ptr %l2, !tbaa !24
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = icmp slt i64 %t27, %t28
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb7, label %bb8
bb7:
  br label %bb12
bb8:
  br label %bb9
bb9:
  %t35 = load ptr, ptr %l1
  %t36 = load i64, ptr %l2, !tbaa !24
  %t39 = getelementptr [4 x i64], ptr %t35, i64 0, i64 %t36
  %t40 = load i64, ptr %t39, !tbaa !34
  %t42 = load ptr, ptr %lp0
  %t43 = getelementptr %"compiler/profile:Profile", ptr %t42, i32 0, i32 4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t43, i64 %t40)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t47 = load i64, ptr %l2, !tbaa !24
  %t49 = add i64 %t47, 1
  store i64 %t49, ptr %l2, !tbaa !24
  br label %bb6
bb12:
  call void @__olang_scope_close(ptr %s1)
  call void @compiler_2fprofile_3aPlaces_2ector(ptr %t51, ptr %v0)
  call void @llvm.memmove.p0.p0.i64(ptr %l31, ptr %t51, i64 272, i1 false)
  br label %bb13
bb13:
  %t52 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 272, i64 8)
  store ptr %t52, ptr %lp5
  %t53 = load ptr, ptr %lp5
  call void @llvm.memmove.p0.p0.i64(ptr %t53, ptr %l31, i64 272, i1 false)
  store %olang.scope zeroinitializer, ptr %s4
  %t54 = insertvalue [3 x i64] undef, i64 100, 0
  %t55 = insertvalue [3 x i64] %t54, i64 200, 1
  %t56 = insertvalue [3 x i64] %t55, i64 300, 2
  %t58 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 24, i64 8)
  store [3 x i64] %t56, ptr %t58
  store ptr %t58, ptr %l6
  store i64 0, ptr %l7, !tbaa !24
  %t60 = load ptr, ptr %l6
  store i64 3, ptr %l8, !tbaa !24
  br label %bb14
bb14:
  %t63 = load i64, ptr %l7, !tbaa !24
  %t64 = load i64, ptr %l8, !tbaa !24
  %t67 = icmp slt i64 %t63, %t64
  %t69 = xor i1 %t67, true
  br i1 %t69, label %bb15, label %bb16
bb15:
  br label %bb22
bb16:
  br label %bb17
bb17:
  %t71 = load i64, ptr %l7, !tbaa !24
  store i64 %t71, ptr %l9, !tbaa !24
  %t73 = load ptr, ptr %l6
  %t74 = load i64, ptr %l7, !tbaa !24
  %t77 = getelementptr [3 x i64], ptr %t73, i64 0, i64 %t74
  %t78 = load i64, ptr %t77, !tbaa !34
  %t80 = load ptr, ptr %lp5
  %t81 = getelementptr %"compiler/profile:Places", ptr %t80, i32 0, i32 5
  %t83 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t81, i64 %t78, i64 %t83)
  br label %bb18
bb18:
  %t87 = load ptr, ptr %lp5
  %t88 = getelementptr %"compiler/profile:Places", ptr %t87, i32 0, i32 3
  %t89 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t88, i64 %t89)
  br label %bb19
bb19:
  %t92 = load ptr, ptr %lp5
  %t93 = getelementptr %"compiler/profile:Places", ptr %t92, i32 0, i32 4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t93, i64 1)
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t95 = load i64, ptr %l7, !tbaa !24
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l7, !tbaa !24
  br label %bb14
bb22:
  call void @__olang_scope_close(ptr %s4)
  %t99 = load ptr, ptr %lp5
  %t100 = getelementptr %"compiler/profile:Places", ptr %t99, i32 0, i32 2
  store ptr %t100, ptr %l52, !tbaa !29
  %t101 = load ptr, ptr %lp5
  %t103 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v0, ptr %s0, ptr %t101, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d135, i32 0, i32 1) })
  store i64 %t103, ptr %l54
  br label %bb23
bb23:
  %t104 = load ptr, ptr %lp5
  %t106 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v0, ptr %s0, ptr %t104, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d136, i32 0, i32 1) })
  store i64 %t106, ptr %l56
  br label %bb24
bb24:
  %t107 = load i64, ptr %l54, !tbaa !24
  %t108 = load i64, ptr %l56, !tbaa !24
  %t109 = call %"compiler/profile:Frame" @compiler_2fprofile_3aFrame_2ector(ptr %s0, i64 %t107, i64 %t108, i64 6)
  store %"compiler/profile:Frame" %t109, ptr %l57
  br label %bb25
bb25:
  %t110 = load ptr, ptr %l52, !tbaa !29
  %t111 = load %"compiler/profile:Frame", ptr %l57
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2ePush_3ccompiler_2fprofile_3aFrame_3e(ptr %v0, ptr %t110, %"compiler/profile:Frame" %t111)
  br label %bb26
bb26:
  %t112 = load ptr, ptr %lp5
  %t113 = getelementptr %"compiler/profile:Places", ptr %t112, i32 0, i32 2
  store ptr %t113, ptr %l58, !tbaa !29
  %t114 = load ptr, ptr %lp5
  %t116 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v0, ptr %s0, ptr %t114, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d137, i32 0, i32 1) })
  store i64 %t116, ptr %l60
  br label %bb27
bb27:
  %t117 = load ptr, ptr %lp5
  %t119 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v0, ptr %s0, ptr %t117, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d138, i32 0, i32 1) })
  store i64 %t119, ptr %l62
  br label %bb28
bb28:
  %t120 = load i64, ptr %l60, !tbaa !24
  %t121 = load i64, ptr %l62, !tbaa !24
  %t122 = call %"compiler/profile:Frame" @compiler_2fprofile_3aFrame_2ector(ptr %s0, i64 %t120, i64 %t121, i64 20)
  store %"compiler/profile:Frame" %t122, ptr %l63
  br label %bb29
bb29:
  %t123 = load ptr, ptr %l58, !tbaa !29
  %t124 = load %"compiler/profile:Frame", ptr %l63
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2ePush_3ccompiler_2fprofile_3aFrame_3e(ptr %v0, ptr %t123, %"compiler/profile:Frame" %t124)
  br label %bb30
bb30:
  %t125 = load ptr, ptr %lp5
  %t126 = getelementptr %"compiler/profile:Places", ptr %t125, i32 0, i32 2
  store ptr %t126, ptr %l64, !tbaa !29
  %t127 = load ptr, ptr %lp5
  %t129 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v0, ptr %s0, ptr %t127, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d139, i32 0, i32 1) })
  store i64 %t129, ptr %l66
  br label %bb31
bb31:
  %t130 = load ptr, ptr %lp5
  %t132 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v0, ptr %s0, ptr %t130, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d140, i32 0, i32 1) })
  store i64 %t132, ptr %l68
  br label %bb32
bb32:
  %t133 = load i64, ptr %l66, !tbaa !24
  %t134 = load i64, ptr %l68, !tbaa !24
  %t135 = call %"compiler/profile:Frame" @compiler_2fprofile_3aFrame_2ector(ptr %s0, i64 %t133, i64 %t134, i64 14)
  store %"compiler/profile:Frame" %t135, ptr %l69
  br label %bb33
bb33:
  %t136 = load ptr, ptr %l64, !tbaa !29
  %t137 = load %"compiler/profile:Frame", ptr %l69
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2ePush_3ccompiler_2fprofile_3aFrame_3e(ptr %v0, ptr %t136, %"compiler/profile:Frame" %t137)
  br label %bb34
bb34:
  %t138 = load ptr, ptr %lp0
  %t139 = load %"compiler/profile:Profile", ptr %t138
  %t140 = load ptr, ptr %lp5
  call void @llvm.memmove.p0.p0.i64(ptr %l71, ptr %t140, i64 272, i1 false)
  %t141 = getelementptr { %"compiler/profile:Profile", %"compiler/profile:Places" }, ptr %l72, i32 0, i32 0
  store %"compiler/profile:Profile" %t139, ptr %t141
  %t143 = getelementptr { %"compiler/profile:Profile", %"compiler/profile:Places" }, ptr %l72, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %t143, ptr %l71, i64 272, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l72, i64 376, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fprofile_2etypesRead(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l18 = alloca { i64, ptr }
  %l27 = alloca i1
  %l28 = alloca { i64, ptr }
  %l32 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l54 = alloca { i64, ptr }
  %l60 = alloca ptr
  %l61 = alloca { i64, ptr }
  %l62 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l72 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l74 = alloca i64
  %l75 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t3, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load i64, ptr %l4, !tbaa !24
  %t10 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb35
bb4:
  br label %bb5
bb5:
  %t17 = load i64, ptr %l4, !tbaa !24
  store i64 %t17, ptr %l6, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t19, ptr %l18, !tbaa !27
  %t20 = load i64, ptr %l4, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i8, ptr %t23, i64 %t20
  %t25 = load i8, ptr %t24, !tbaa !32
  %t29 = icmp ne i8 %t25, 58
  br i1 %t29, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb7:
  br label %bb8
bb8:
  %t31 = load i64, ptr %l6, !tbaa !24
  store i64 %t31, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  %t33 = load i64, ptr %l8, !tbaa !24
  %t34 = load i64, ptr %l2, !tbaa !24
  %t37 = icmp sgt i64 %t33, %t34
  br i1 %t37, label %bb10, label %bb11
bb10:
  %t39 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t39, ptr %l28, !tbaa !27
  %t40 = load i64, ptr %l8, !tbaa !24
  %t42 = sub i64 %t40, 1
  %t44 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr i8, ptr %t45, i64 %t42
  %t47 = load i8, ptr %t46, !tbaa !32
  %t49 = call i1 @compiler_2fprofile_2eidentityChar(i8 %t47)
  store i1 %t49, ptr %l32
  br label %bb12
bb11:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb13
bb12:
  %t50 = load i1, ptr %l32, !tbaa !21
  store i1 %t50, ptr %l27, !tbaa !21
  br label %bb13
bb13:
  %t51 = load i1, ptr %l27, !tbaa !21
  %t52 = xor i1 %t51, true
  br i1 %t52, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t54 = load i64, ptr %l8, !tbaa !24
  %t56 = sub i64 %t54, 1
  store i64 %t56, ptr %l8, !tbaa !24
  br label %bb17
bb17:
  br label %bb9
bb18:
  store ptr %l1, ptr %l36, !tbaa !29
  %t58 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t58, ptr %l37, !tbaa !27
  %t59 = load i64, ptr %l2, !tbaa !24
  store i64 %t59, ptr %l38, !tbaa !24
  %t60 = load i64, ptr %l8, !tbaa !24
  store i64 %t60, ptr %l39, !tbaa !24
  %t61 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t61, 0
  store i64 %t62, ptr %l40, !tbaa !24
  %t63 = load i64, ptr %l38, !tbaa !24
  %t64 = icmp sge i64 %t63, 0
  br i1 %t64, label %bb19, label %bb20
bb19:
  %t66 = load i64, ptr %l38, !tbaa !24
  %t67 = load i64, ptr %l39, !tbaa !24
  %t68 = icmp sle i64 %t66, %t67
  br i1 %t68, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_cc2e380c5cd0dda_c071bfd9a740ca6e)
  unreachable
bb21:
  %t70 = load i64, ptr %l39, !tbaa !24
  %t71 = load i64, ptr %l40, !tbaa !24
  %t72 = icmp sle i64 %t70, %t71
  br i1 %t72, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_cc2e380c5cd0dda_c071bfd9a740ca6e)
  unreachable
bb23:
  %t74 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = load i64, ptr %l38, !tbaa !24
  %t77 = load i64, ptr %l39, !tbaa !24
  %t78 = getelementptr i8, ptr %t75, i64 %t76
  %t79 = sub i64 %t77, %t76
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  %t82 = load ptr, ptr %l36, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t82, { i64, ptr } %t81)
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_cc2e380c5cd0dda_c071bfd9a740ca6e)
  unreachable
bb25:
  store ptr %l1, ptr %l45, !tbaa !29
  %t84 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t84, ptr %l46, !tbaa !27
  %t85 = load i64, ptr %l8, !tbaa !24
  store i64 %t85, ptr %l47, !tbaa !24
  %t86 = load i64, ptr %l6, !tbaa !24
  store i64 %t86, ptr %l48, !tbaa !24
  %t87 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  store i64 %t88, ptr %l49, !tbaa !24
  %t89 = load i64, ptr %l47, !tbaa !24
  %t90 = icmp sge i64 %t89, 0
  br i1 %t90, label %bb26, label %bb27
bb26:
  %t92 = load i64, ptr %l47, !tbaa !24
  %t93 = load i64, ptr %l48, !tbaa !24
  %t94 = icmp sle i64 %t92, %t93
  br i1 %t94, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_4bebebd3fadd2f37_94a97b9fa165786b)
  unreachable
bb28:
  %t96 = load i64, ptr %l48, !tbaa !24
  %t97 = load i64, ptr %l49, !tbaa !24
  %t98 = icmp sle i64 %t96, %t97
  br i1 %t98, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_4bebebd3fadd2f37_94a97b9fa165786b)
  unreachable
bb30:
  %t100 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = load i64, ptr %l47, !tbaa !24
  %t103 = load i64, ptr %l48, !tbaa !24
  %t104 = getelementptr i8, ptr %t101, i64 %t102
  %t105 = sub i64 %t103, %t102
  %t106 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t104, 1
  %t109 = call { i64, ptr } @compiler_2fprofile_2equalifier(ptr %v0, ptr %s2, { i64, ptr } %t107)
  store { i64, ptr } %t109, ptr %l54
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_4bebebd3fadd2f37_94a97b9fa165786b)
  unreachable
bb32:
  %t110 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t110, 0
  %t112 = extractvalue { i64, ptr } %t110, 1
  %t113 = mul i64 %t111, 1
  %t114 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t113)
  call void @llvm.memcpy.p0.p0.i64(ptr %t114, ptr %t112, i64 %t113, i1 false)
  %t115 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t114, 1
  %t117 = load ptr, ptr %l45, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t117, { i64, ptr } %t116)
  br label %bb33
bb33:
  %t119 = load i64, ptr %l6, !tbaa !24
  %t121 = add i64 %t119, 1
  store i64 %t121, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb34:
  %t123 = load i64, ptr %l4, !tbaa !24
  %t125 = add i64 %t123, 1
  store i64 %t125, ptr %l4, !tbaa !24
  br label %bb2
bb35:
  store ptr %l1, ptr %l60, !tbaa !29
  %t127 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t127, ptr %l61, !tbaa !27
  %t128 = load i64, ptr %l2, !tbaa !24
  store i64 %t128, ptr %l62, !tbaa !24
  %t129 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t129, 0
  store i64 %t132, ptr %l65, !tbaa !24
  %t133 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 0
  store i64 %t134, ptr %l66, !tbaa !24
  %t135 = load i64, ptr %l62, !tbaa !24
  %t136 = icmp sge i64 %t135, 0
  br i1 %t136, label %bb36, label %bb37
bb36:
  %t138 = load i64, ptr %l62, !tbaa !24
  %t139 = load i64, ptr %l65, !tbaa !24
  %t140 = icmp sle i64 %t138, %t139
  br i1 %t140, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_ea1fc1fa824e624c_c3d948fe5a073af0)
  unreachable
bb38:
  %t142 = load i64, ptr %l65, !tbaa !24
  %t143 = load i64, ptr %l66, !tbaa !24
  %t144 = icmp sle i64 %t142, %t143
  br i1 %t144, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_ea1fc1fa824e624c_c3d948fe5a073af0)
  unreachable
bb40:
  %t146 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = load i64, ptr %l62, !tbaa !24
  %t149 = load i64, ptr %l65, !tbaa !24
  %t150 = getelementptr i8, ptr %t147, i64 %t148
  %t151 = sub i64 %t149, %t148
  %t152 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t150, 1
  %t154 = load ptr, ptr %l60, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t154, { i64, ptr } %t153)
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_ea1fc1fa824e624c_c3d948fe5a073af0)
  unreachable
bb42:
  %t157 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t157, ptr %l72
  br label %bb43
bb43:
  %t158 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t158, ptr %l73, !tbaa !27
  %t159 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t159, 0
  store i64 %t160, ptr %l74, !tbaa !24
  %t161 = load i64, ptr %l74, !tbaa !24
  %t162 = mul i64 %t161, 1
  %t163 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t162)
  %t164 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t165 = insertvalue { i64, ptr } %t164, ptr %t163, 1
  store { i64, ptr } %t165, ptr %l75, !tbaa !27
  %t166 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = load i64, ptr %l74, !tbaa !24
  %t171 = mul i64 %t170, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t167, ptr %t169, i64 %t171, i1 false)
  %t172 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t172, ptr %l73, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t173 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t173, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fprofile_2eword(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i64
  %l34 = alloca { i64, ptr }
  %l42 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  store i64 8, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t1 = load i64, ptr %l4, !tbaa !24
  %t2 = load i64, ptr %l3, !tbaa !24
  %t5 = icmp sgt i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l5, !tbaa !24
  %t9 = icmp sgt i64 %t7, 0
  br i1 %t9, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l12, !tbaa !24
  br label %bb6
bb3:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t15 = sub i64 %t11, %t12
  %t16 = load i64, ptr %l5, !tbaa !24
  %t19 = add i64 %t15, %t16
  %t21 = sub i64 %t19, 1
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = sdiv i64 %t21, %t22
  store i64 %t25, ptr %l15, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb5
bb5:
  %t27 = load i64, ptr %l15, !tbaa !24
  store i64 %t27, ptr %l12, !tbaa !24
  br label %bb6
bb6:
  %t28 = load i64, ptr %l12, !tbaa !24
  store i64 %t28, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t29 = load i64, ptr %l7, !tbaa !24
  %t30 = load i64, ptr %l6, !tbaa !24
  %t33 = icmp slt i64 %t29, %t30
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb8, label %bb9
bb8:
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t37 = load i64, ptr %l3, !tbaa !24
  %t38 = load i64, ptr %l7, !tbaa !24
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = mul i64 %t38, %t39
  %t45 = add i64 %t37, %t42
  store i64 %t45, ptr %l8, !tbaa !24
  %t47 = load i64, ptr %l2, !tbaa !24
  store { i64, ptr } %a0, ptr %l34, !tbaa !27
  %t51 = mul i64 %a1, 8
  %t52 = load i64, ptr %l8, !tbaa !24
  %t55 = add i64 %t51, %t52
  %t57 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr i8, ptr %t58, i64 %t55
  %t60 = load i8, ptr %t59, !tbaa !32
  %t62 = zext i8 %t60 to i64
  %t63 = load i64, ptr %l8, !tbaa !24
  %t65 = mul i64 %t63, 8
  store i64 %t65, ptr %l42, !tbaa !24
  %t67 = load i64, ptr %l42, !tbaa !24
  %t68 = load i64, ptr %l42, !tbaa !24
  %t69 = shl i64 %t62, %t68
  %t72 = or i64 %t47, %t69
  store i64 %t72, ptr %l2, !tbaa !24
  br label %bb11
bb11:
  %t74 = load i64, ptr %l7, !tbaa !24
  %t76 = add i64 %t74, 1
  store i64 %t76, ptr %l7, !tbaa !24
  br label %bb7
bb12:
  %t78 = load i64, ptr %l2, !tbaa !24
  store i64 %t78, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/profile:Frame" @compiler_2fprofile_3aFrame_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2) #0 {
entry:
  %rv = alloca %"compiler/profile:Frame"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/profile:Frame" undef, i64 %a0, 0
  %t10 = insertvalue %"compiler/profile:Frame" %t8, i64 %a1, 1
  %t12 = insertvalue %"compiler/profile:Frame" %t10, i64 %a2, 2
  store %"compiler/profile:Frame" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/profile:Frame", ptr %rv
  ret %"compiler/profile:Frame" %rr
}

define dso_local void @compiler_2fprofile_3aPlaces_2ector(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l12 = alloca %"compiler/profile:Places"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l0
  %t3 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t3, ptr %l7
  br label %bb2
bb2:
  %t4 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l7
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t4, ptr %l1
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l8
  br label %bb3
bb3:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l2
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l9
  br label %bb4
bb4:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l3
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l10
  br label %bb5
bb5:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l4
  %t11 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t11, ptr %l11
  br label %bb6
bb6:
  %t12 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l11
  %t13 = getelementptr %"compiler/profile:Places", ptr %l12, i32 0, i32 0
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %t13
  %t15 = getelementptr %"compiler/profile:Places", ptr %l12, i32 0, i32 1
  %t16 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t16, ptr %t15
  %t17 = getelementptr %"compiler/profile:Places", ptr %l12, i32 0, i32 2
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %t17
  %t19 = getelementptr %"compiler/profile:Places", ptr %l12, i32 0, i32 3
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %t19
  %t21 = getelementptr %"compiler/profile:Places", ptr %l12, i32 0, i32 4
  %t22 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %t21
  %t23 = getelementptr %"compiler/profile:Places", ptr %l12, i32 0, i32 5
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t12, ptr %t23
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l12, i64 272, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/profile:Profile" @compiler_2fprofile_3aProfile_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/profile:Profile"
  br label %start
start:
  br label %bb0
bb0:
  store i64 1000000, ptr %l0, !tbaa !24
  store i64 0, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l3
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l7
  br label %bb2
bb2:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d141, i32 0, i32 1) }, ptr %l5, !tbaa !27
  %t5 = load i64, ptr %l0, !tbaa !24
  %t6 = insertvalue %"compiler/profile:Profile" undef, i64 %t5, 0
  %t7 = load i64, ptr %l1, !tbaa !24
  %t8 = insertvalue %"compiler/profile:Profile" %t6, i64 %t7, 1
  %t9 = load i64, ptr %l2, !tbaa !24
  %t10 = insertvalue %"compiler/profile:Profile" %t8, i64 %t9, 2
  %t11 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t12 = insertvalue %"compiler/profile:Profile" %t10, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, 3
  %t14 = insertvalue %"compiler/profile:Profile" %t12, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, 4
  %t15 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t16 = insertvalue %"compiler/profile:Profile" %t14, { i64, ptr } %t15, 5
  store %"compiler/profile:Profile" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/profile:Profile", ptr %rv
  ret %"compiler/profile:Profile" %rr
}

define dso_local %"compiler/profile:Sample" @compiler_2fprofile_3aSample_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2) #0 {
entry:
  %rv = alloca %"compiler/profile:Sample"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/profile:Sample" undef, i64 %a0, 0
  %t10 = insertvalue %"compiler/profile:Sample" %t8, i64 %a1, 1
  %t12 = insertvalue %"compiler/profile:Sample" %t10, i64 %a2, 2
  store %"compiler/profile:Sample" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/profile:Sample", ptr %rv
  ret %"compiler/profile:Sample" %rr
}

define dso_local void @compiler_2fprofile_3aTally_2ector(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l3 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l4 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l8 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l9 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l10 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l11 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"compiler/profile:Tally"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l7
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l0
  %t3 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t3, ptr %l8
  br label %bb2
bb2:
  %t4 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l8
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t4, ptr %l1
  %t5 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t5, ptr %l9
  br label %bb3
bb3:
  %t6 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l9
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t6, ptr %l2
  %t7 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t7, ptr %l10
  br label %bb4
bb4:
  %t8 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l10
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t8, ptr %l3
  %t9 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t9, ptr %l11
  br label %bb5
bb5:
  %t10 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l11
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t10, ptr %l4
  %t11 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l12
  br label %bb6
bb6:
  %t12 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %l5
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l13
  br label %bb7
bb7:
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  %t15 = getelementptr %"compiler/profile:Tally", ptr %l14, i32 0, i32 0
  %t16 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t16, ptr %t15
  %t17 = getelementptr %"compiler/profile:Tally", ptr %l14, i32 0, i32 1
  %t18 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t18, ptr %t17
  %t19 = getelementptr %"compiler/profile:Tally", ptr %l14, i32 0, i32 2
  %t20 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l2
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t20, ptr %t19
  %t21 = getelementptr %"compiler/profile:Tally", ptr %l14, i32 0, i32 3
  %t22 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l3
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t22, ptr %t21
  %t23 = getelementptr %"compiler/profile:Tally", ptr %l14, i32 0, i32 4
  %t24 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l4
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t24, ptr %t23
  %t25 = getelementptr %"compiler/profile:Tally", ptr %l14, i32 0, i32 5
  %t26 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %t25
  %t27 = getelementptr %"compiler/profile:Tally", ptr %l14, i32 0, i32 6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %t27
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l14, i64 424, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/profile:elfFn" @compiler_2fprofile_3aelfFn_2ector(ptr %v0, ptr %v1, i64 %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %rv = alloca %"compiler/profile:elfFn"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/profile:elfFn" undef, i64 %a0, 0
  %t10 = insertvalue %"compiler/profile:elfFn" %t8, i64 %a1, 1
  %t12 = insertvalue %"compiler/profile:elfFn" %t10, { i64, ptr } %a2, 2
  store %"compiler/profile:elfFn" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/profile:elfFn", ptr %rv
  ret %"compiler/profile:elfFn" %rr
}

define dso_local %"compiler/profile:mapping" @compiler_2fprofile_3amapping_2ector(ptr %v0, ptr %v1, i64 %a0, i64 %a1, i64 %a2, { i64, ptr } %a3) #0 {
entry:
  %rv = alloca %"compiler/profile:mapping"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/profile:mapping" undef, i64 %a0, 0
  %t12 = insertvalue %"compiler/profile:mapping" %t10, i64 %a1, 1
  %t14 = insertvalue %"compiler/profile:mapping" %t12, i64 %a2, 2
  %t16 = insertvalue %"compiler/profile:mapping" %t14, { i64, ptr } %a3, 3
  store %"compiler/profile:mapping" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/profile:mapping", ptr %rv
  ret %"compiler/profile:mapping" %rr
}

define dso_local %"compiler/profile:node" @compiler_2fprofile_3anode_2ector(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/profile:node"
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a0, ptr %l2, !tbaa !24
  store i64 %a1, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = insertvalue %"compiler/profile:node" undef, i64 %t7, 0
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = insertvalue %"compiler/profile:node" %t8, i64 %t9, 1
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = insertvalue %"compiler/profile:node" %t10, i64 %t11, 2
  %t14 = insertvalue %"compiler/profile:node" %t12, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, 3
  store %"compiler/profile:node" %t14, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/profile:node", ptr %rv
  ret %"compiler/profile:node" %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define linkonce_odr %"compiler/profile:node" @olang_2eHelperKind_2eCopy_2ecompiler_2fprofile_3anode(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/profile:node"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/profile:node"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/profile:node", ptr %a0
  store %"compiler/profile:node" %t2, ptr %l1
  %t3 = getelementptr %"compiler/profile:node", ptr %l1, i32 0, i32 3
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/profile:node", ptr %l1, i32 0, i32 3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"compiler/profile:node", ptr %l1
  store %"compiler/profile:node" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/profile:node", ptr %rv
  ret %"compiler/profile:node" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal i1 @olang_lambda_0(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca ptr
  %l8 = alloca %"compiler/profile:node"
  %l10 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l15 = alloca %"compiler/profile:node"
  %l17 = alloca { i64, ptr }
  %l18 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  %cp0 = getelementptr { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  store ptr %cv0, ptr %l2
  %cp1 = getelementptr { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr }, ptr %env, i32 0, i32 1
  %cv1 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %cp1, !tbaa !28
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %cv1, ptr %l3
  %vq0 = getelementptr { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr }, ptr %env, i32 0, i32 2
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  %vq1 = getelementptr { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr }, ptr %env, i32 0, i32 3
  %vr1 = load ptr, ptr %vq1, !tbaa !28
  %vc1 = call ptr @__olang_capture_scope(ptr %vr1)
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/profile:Places", ptr %t1, i32 0, i32 0
  store ptr %t3, ptr %l5, !tbaa !29
  %t7 = call %"compiler/profile:node" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eAt_3ccompiler_2fprofile_3anode_3e(ptr %vc1, ptr %s0, ptr %l3, i64 %a0)
  store %"compiler/profile:node" %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = getelementptr %"compiler/profile:node", ptr %l8, i32 0, i32 0
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l5, !tbaa !29
  %t12 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %vc0, ptr %vc0, ptr %t10, i64 %t9)
  store { i64, ptr } %t12, ptr %l10
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t15 = getelementptr %"compiler/profile:Places", ptr %t13, i32 0, i32 0
  store ptr %t15, ptr %l12, !tbaa !29
  %t19 = call %"compiler/profile:node" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eAt_3ccompiler_2fprofile_3anode_3e(ptr %vc1, ptr %s0, ptr %l3, i64 %a1)
  store %"compiler/profile:node" %t19, ptr %l15
  br label %bb3
bb3:
  %t20 = getelementptr %"compiler/profile:node", ptr %l15, i32 0, i32 0
  %t21 = load i64, ptr %t20, !tbaa !24
  %t22 = load ptr, ptr %l12, !tbaa !29
  %t24 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %vc0, ptr %vc0, ptr %t22, i64 %t21)
  store { i64, ptr } %t24, ptr %l17
  br label %bb4
bb4:
  %t25 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %vc0, ptr %vc0, { i64, ptr } %t25, { i64, ptr } %t26)
  store i1 %t27, ptr %l18
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load i1, ptr %l18, !tbaa !21
  store i1 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d1 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"all" }>, align 8
@.d2 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" - " }>, align 8
@.d3 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" ms, " }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare i64 @__olang_fmt_i64(ptr, i64)
@.d4 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"<g class=\22f\22 data-x=\22" }>, align 8
@.d5 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"\22 data-w=\22" }>, align 8
@.d6 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"\22 data-d=\22" }>, align 8
@.d7 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"\22><title>" }>, align 8
@.d8 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"</title><rect y=\22" }>, align 8
@.d9 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"\22 height=\22" }>, align 8
@.d10 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"\22 rx=\222\22 fill=\22rgb(" }>, align 8
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d12 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c")\22/><text y=\22" }>, align 8
@.d13 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\22>" }>, align 8
@.d14 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"</text></g>\0A" }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d15 = private constant <{ i64, [57 x i8] }> <{ i64 0, [57 x i8] c"<!doctype html>\0A<html><head><meta charset=\22utf-8\22><title>" }>, align 8
@.d16 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c" - olang profile</title>\0A" }>, align 8
@.d17 = private constant <{ i64, [213 x i8] }> <{ i64 0, [213 x i8] c"<style>body{margin:0;padding:10px;font:12px monospace;background:#fff}svg text{font:11px monospace;fill:#000;pointer-events:none}g.f{cursor:pointer}g.f:hover rect{stroke:#000;stroke-width:.5}</style></head><body>\0A" }>, align 8
@.d18 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"<div>" }>, align 8
@.d19 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d20 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" samples, " }>, align 8
@.d21 = private constant <{ i64, [78 x i8] }> <{ i64 0, [78 x i8] c" s of CPU time - a click on a frame zooms to it, on the bottom bar back</div>\0A" }>, align 8
@.d22 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"<svg id=\22fg\22 width=\22" }>, align 8
@.d23 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"\22 height=\22" }>, align 8
@.d24 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"\22 data-total=\22" }>, align 8
@.d25 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"\22>\0A" }>, align 8
@.d26 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"</svg>\0A" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d27 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"</body></html>\0A" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare void @__olang_check_failed(ptr) cold noreturn
@.d28 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"OLPROF01" }>, align 8
@.d29 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"_2e" }>, align 8
@.d30 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"./" }>, align 8
@.d31 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"../" }>, align 8
@.d32 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"./" }>, align 8
@.d33 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
declare void @__olang_ert_req_clear()
@.d34 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d35 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d36 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d37 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" thread" }>, align 8
@.d38 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" threads" }>, align 8
@.d39 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"\0Aolang profile: " }>, align 8
@.d40 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" - " }>, align 8
@.d41 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" samples, " }>, align 8
@.d42 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c" s of CPU time on " }>, align 8
@.d43 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d44 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"  (" }>, align 8
@.d45 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c" samples dropped: the buffer was full)\0A" }>, align 8
@.d46 = private constant <{ i64, [61 x i8] }> <{ i64 0, [61 x i8] c"  no samples: the program used less CPU time than one period\0A" }>, align 8
define internal i1 @olang_lambda_47(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca %"compiler/profile:Tally"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l24 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i32
  %l29 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i32
  %l43 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca i1
  %rv = alloca i1
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  %cp0 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %env, i32 0, i32 0
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %cp0, i64 424, i1 false)
  %cp1 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %env, i32 0, i32 1
  %cv1 = load ptr, ptr %cp1, !tbaa !28
  store ptr %cv1, ptr %l7
  %vq0 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %env, i32 0, i32 2
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  %vq1 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %env, i32 0, i32 3
  %vr1 = load ptr, ptr %vq1, !tbaa !28
  %vc1 = call ptr @__olang_capture_scope(ptr %vr1)
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/profile:Tally", ptr %l2, i32 0, i32 0
  %t2 = load i64, ptr %l0, !tbaa !24
  %t5 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %vc0, ptr %t1, i64 %t2)
  %t6 = extractvalue { i32, i64 } %t5, 1
  %t7 = extractvalue { i32, i64 } %t5, 0
  store i32 %t7, ptr %l12
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store i64 %t6, ptr %l11
  br label %bb1
bb1:
  %t10 = load i64, ptr %l11, !tbaa !24
  store i64 %t10, ptr %l8, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l8, !tbaa !24
  br label %bb4
bb4:
  %t11 = load i64, ptr %l8, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  %t12 = getelementptr %"compiler/profile:Tally", ptr %l2, i32 0, i32 0
  %t13 = load i64, ptr %l1, !tbaa !24
  %t16 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %vc0, ptr %t12, i64 %t13)
  %t17 = extractvalue { i32, i64 } %t16, 1
  %t18 = extractvalue { i32, i64 } %t16, 0
  store i32 %t18, ptr %l17
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb6, label %ok.20, !prof !99
ok.20:
  store i64 %t17, ptr %l16
  br label %bb5
bb5:
  %t21 = load i64, ptr %l16, !tbaa !24
  store i64 %t21, ptr %l13, !tbaa !24
  br label %bb8
bb6:
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l13, !tbaa !24
  br label %bb8
bb8:
  %t22 = load i64, ptr %l13, !tbaa !24
  store i64 %t22, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l3, !tbaa !24
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = icmp ne i64 %t23, %t24
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t29 = load i64, ptr %l3, !tbaa !24
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = icmp sgt i64 %t29, %t30
  store i1 %t33, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t35 = getelementptr %"compiler/profile:Tally", ptr %l2, i32 0, i32 1
  %t36 = load i64, ptr %l0, !tbaa !24
  %t39 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %vc0, ptr %t35, i64 %t36)
  %t40 = extractvalue { i32, i64 } %t39, 1
  %t41 = extractvalue { i32, i64 } %t39, 0
  store i32 %t41, ptr %l28
  %t42 = icmp ne i32 %t41, 0
  br i1 %t42, label %bb13, label %ok.43, !prof !99
ok.43:
  store i64 %t40, ptr %l27
  br label %bb12
bb12:
  %t44 = load i64, ptr %l27, !tbaa !24
  store i64 %t44, ptr %l24, !tbaa !24
  br label %bb15
bb13:
  br label %bb14
bb14:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l24, !tbaa !24
  br label %bb15
bb15:
  %t45 = load i64, ptr %l24, !tbaa !24
  store i64 %t45, ptr %l5, !tbaa !24
  %t46 = getelementptr %"compiler/profile:Tally", ptr %l2, i32 0, i32 1
  %t47 = load i64, ptr %l1, !tbaa !24
  %t50 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %vc0, ptr %t46, i64 %t47)
  %t51 = extractvalue { i32, i64 } %t50, 1
  %t52 = extractvalue { i32, i64 } %t50, 0
  store i32 %t52, ptr %l33
  %t53 = icmp ne i32 %t52, 0
  br i1 %t53, label %bb17, label %ok.54, !prof !99
ok.54:
  store i64 %t51, ptr %l32
  br label %bb16
bb16:
  %t55 = load i64, ptr %l32, !tbaa !24
  store i64 %t55, ptr %l29, !tbaa !24
  br label %bb19
bb17:
  br label %bb18
bb18:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l29, !tbaa !24
  br label %bb19
bb19:
  %t56 = load i64, ptr %l29, !tbaa !24
  store i64 %t56, ptr %l6, !tbaa !24
  %t57 = load i64, ptr %l5, !tbaa !24
  %t58 = load i64, ptr %l6, !tbaa !24
  %t61 = icmp ne i64 %t57, %t58
  br i1 %t61, label %bb20, label %bb21
bb20:
  %t63 = load i64, ptr %l5, !tbaa !24
  %t64 = load i64, ptr %l6, !tbaa !24
  %t67 = icmp sgt i64 %t63, %t64
  store i1 %t67, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t69 = load ptr, ptr %l7, !tbaa !29
  %t71 = getelementptr %"compiler/profile:Places", ptr %t69, i32 0, i32 0
  %t72 = load i64, ptr %l0, !tbaa !24
  %t75 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %vc1, ptr %vc1, ptr %t71, i64 %t72)
  store { i64, ptr } %t75, ptr %l43
  br label %bb23
bb23:
  %t76 = load ptr, ptr %l7, !tbaa !29
  %t78 = getelementptr %"compiler/profile:Places", ptr %t76, i32 0, i32 0
  %t79 = load i64, ptr %l1, !tbaa !24
  %t82 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %vc1, ptr %vc1, ptr %t78, i64 %t79)
  store { i64, ptr } %t82, ptr %l47
  br label %bb24
bb24:
  %t83 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t84 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t85 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %vc1, ptr %vc1, { i64, ptr } %t83, { i64, ptr } %t84)
  store i1 %t85, ptr %l48
  br label %bb25
bb25:
  %t86 = load i1, ptr %l48, !tbaa !21
  store i1 %t86, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d48 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"\0A   self   total  function\0A" }>, align 8
@.d49 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d50 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d51 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d52 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
define internal i1 @olang_lambda_53(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca %"compiler/profile:Tally"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l25 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i1
  %rv = alloca i1
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  %cp0 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %env, i32 0, i32 0
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %cp0, i64 424, i1 false)
  %cp1 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %env, i32 0, i32 1
  %cv1 = load ptr, ptr %cp1, !tbaa !28
  store ptr %cv1, ptr %l5
  %vq0 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %env, i32 0, i32 2
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  %vq1 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %env, i32 0, i32 3
  %vr1 = load ptr, ptr %vq1, !tbaa !28
  %vc1 = call ptr @__olang_capture_scope(ptr %vr1)
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/profile:Tally", ptr %l2, i32 0, i32 2
  %t2 = load i64, ptr %l0, !tbaa !24
  %t5 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %vc0, ptr %t1, i64 %t2)
  %t6 = extractvalue { i32, i64 } %t5, 1
  %t7 = extractvalue { i32, i64 } %t5, 0
  store i32 %t7, ptr %l10
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store i64 %t6, ptr %l9
  br label %bb1
bb1:
  %t10 = load i64, ptr %l9, !tbaa !24
  store i64 %t10, ptr %l6, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l6, !tbaa !24
  br label %bb4
bb4:
  %t11 = load i64, ptr %l6, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  %t12 = getelementptr %"compiler/profile:Tally", ptr %l2, i32 0, i32 2
  %t13 = load i64, ptr %l1, !tbaa !24
  %t16 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %vc0, ptr %t12, i64 %t13)
  %t17 = extractvalue { i32, i64 } %t16, 1
  %t18 = extractvalue { i32, i64 } %t16, 0
  store i32 %t18, ptr %l15
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb6, label %ok.20, !prof !99
ok.20:
  store i64 %t17, ptr %l14
  br label %bb5
bb5:
  %t21 = load i64, ptr %l14, !tbaa !24
  store i64 %t21, ptr %l11, !tbaa !24
  br label %bb8
bb6:
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l11, !tbaa !24
  br label %bb8
bb8:
  %t22 = load i64, ptr %l11, !tbaa !24
  store i64 %t22, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l3, !tbaa !24
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = icmp ne i64 %t23, %t24
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t29 = load i64, ptr %l3, !tbaa !24
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = icmp sgt i64 %t29, %t30
  store i1 %t33, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t35 = load ptr, ptr %l5, !tbaa !29
  %t37 = getelementptr %"compiler/profile:Places", ptr %t35, i32 0, i32 0
  %t38 = load i64, ptr %l0, !tbaa !24
  %t41 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %vc1, ptr %vc1, ptr %t37, i64 %t38)
  store { i64, ptr } %t41, ptr %l25
  br label %bb12
bb12:
  %t42 = load ptr, ptr %l5, !tbaa !29
  %t44 = getelementptr %"compiler/profile:Places", ptr %t42, i32 0, i32 0
  %t45 = load i64, ptr %l1, !tbaa !24
  %t48 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %vc1, ptr %vc1, ptr %t44, i64 %t45)
  store { i64, ptr } %t48, ptr %l29
  br label %bb13
bb13:
  %t49 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t51 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %vc1, ptr %vc1, { i64, ptr } %t49, { i64, ptr } %t50)
  store i1 %t51, ptr %l30
  br label %bb14
bb14:
  %t52 = load i1, ptr %l30, !tbaa !21
  store i1 %t52, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d54 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c":0" }>, align 8
@.d55 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"line" }>, align 8
@.d56 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"\0A   self  " }>, align 8
@.d57 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"  function\0A" }>, align 8
@.d58 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d59 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d60 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d61 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c"\0A  called from (the five hottest functions)\0A" }>, align 8
define internal i1 @olang_lambda_62(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca %"compiler/profile:Tally"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i32
  %l32 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca i1
  %rv = alloca i1
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  %cp0 = getelementptr { %"compiler/profile:Tally", i64, ptr, ptr, ptr }, ptr %env, i32 0, i32 0
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %cp0, i64 424, i1 false)
  %cp1 = getelementptr { %"compiler/profile:Tally", i64, ptr, ptr, ptr }, ptr %env, i32 0, i32 1
  %cv1 = load i64, ptr %cp1, !tbaa !28
  store i64 %cv1, ptr %l3
  %cp2 = getelementptr { %"compiler/profile:Tally", i64, ptr, ptr, ptr }, ptr %env, i32 0, i32 2
  %cv2 = load ptr, ptr %cp2, !tbaa !28
  store ptr %cv2, ptr %l6
  %vq0 = getelementptr { %"compiler/profile:Tally", i64, ptr, ptr, ptr }, ptr %env, i32 0, i32 3
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  %vq1 = getelementptr { %"compiler/profile:Tally", i64, ptr, ptr, ptr }, ptr %env, i32 0, i32 4
  %vr1 = load ptr, ptr %vq1, !tbaa !28
  %vc1 = call ptr @__olang_capture_scope(ptr %vr1)
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/profile:Tally", ptr %l2, i32 0, i32 4
  %t2 = load i64, ptr %l3, !tbaa !24
  %t4 = mul i64 %t2, 16777216
  %t5 = load i64, ptr %l0, !tbaa !24
  %t8 = add i64 %t4, %t5
  %t11 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %vc0, ptr %t1, i64 %t8)
  %t12 = extractvalue { i32, i64 } %t11, 1
  %t13 = extractvalue { i32, i64 } %t11, 0
  store i32 %t13, ptr %l14
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb2, label %ok.15, !prof !99
ok.15:
  store i64 %t12, ptr %l13
  br label %bb1
bb1:
  %t16 = load i64, ptr %l13, !tbaa !24
  store i64 %t16, ptr %l7, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  %t17 = load i64, ptr %l7, !tbaa !24
  store i64 %t17, ptr %l4, !tbaa !24
  %t18 = getelementptr %"compiler/profile:Tally", ptr %l2, i32 0, i32 4
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = mul i64 %t19, 16777216
  %t22 = load i64, ptr %l1, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t28 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %vc0, ptr %t18, i64 %t25)
  %t29 = extractvalue { i32, i64 } %t28, 1
  %t30 = extractvalue { i32, i64 } %t28, 0
  store i32 %t30, ptr %l22
  %t31 = icmp ne i32 %t30, 0
  br i1 %t31, label %bb6, label %ok.32, !prof !99
ok.32:
  store i64 %t29, ptr %l21
  br label %bb5
bb5:
  %t33 = load i64, ptr %l21, !tbaa !24
  store i64 %t33, ptr %l15, !tbaa !24
  br label %bb8
bb6:
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l15, !tbaa !24
  br label %bb8
bb8:
  %t34 = load i64, ptr %l15, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  %t35 = load i64, ptr %l4, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp ne i64 %t35, %t36
  br i1 %t39, label %bb9, label %bb10
bb9:
  %t41 = load i64, ptr %l4, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = icmp sgt i64 %t41, %t42
  store i1 %t45, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t47 = load ptr, ptr %l6, !tbaa !29
  %t49 = getelementptr %"compiler/profile:Places", ptr %t47, i32 0, i32 0
  %t50 = load i64, ptr %l0, !tbaa !24
  %t53 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %vc1, ptr %vc1, ptr %t49, i64 %t50)
  store { i64, ptr } %t53, ptr %l32
  br label %bb12
bb12:
  %t54 = load ptr, ptr %l6, !tbaa !29
  %t56 = getelementptr %"compiler/profile:Places", ptr %t54, i32 0, i32 0
  %t57 = load i64, ptr %l1, !tbaa !24
  %t60 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %vc1, ptr %vc1, ptr %t56, i64 %t57)
  store { i64, ptr } %t60, ptr %l36
  br label %bb13
bb13:
  %t61 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t63 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %vc1, ptr %vc1, { i64, ptr } %t61, { i64, ptr } %t62)
  store i1 %t63, ptr %l37
  br label %bb14
bb14:
  %t64 = load i1, ptr %l37, !tbaa !21
  store i1 %t64, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d63 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d64 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"(the thread's first frame)" }>, align 8
@.d65 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d66 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d67 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"  <-  " }>, align 8
@.d68 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_H672d76f1ccd7b9b901b64baf95956196(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d69 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d70 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d71 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d72 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\22" }>, align 8
@.d73 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"\22 0x" }>, align 8
@.d74 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d75 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"--inlining" }>, align 8
@.d76 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"--functions=short" }>, align 8
@.d77 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d78 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d79 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_H85afd28815ee4de4ef19d4ccaecd867e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2fvec_3a_Hdb387e679134e71bf5648ac6d1ce10ff(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d80 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d81 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"??" }>, align 8
@.d82 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d83 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d84 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"??" }>, align 8
@.d85 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"??" }>, align 8
@.d86 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"0x" }>, align 8
@.d87 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" (" }>, align 8
@.d88 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d89 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d90 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d91 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"??" }>, align 8
@.d92 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d93 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"no file" }>, align 8
@.d94 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"0x" }>, align 8
@.d95 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" (" }>, align 8
@.d96 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d97 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"??" }>, align 8
@.d98 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d99 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d100 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d101 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"/llvm-symbolizer" }>, align 8
@.d102 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d103 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"llvm-symbolizer-20" }>, align 8
@.d104 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"llvm-symbolizer-19" }>, align 8
@.d105 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"llvm-symbolizer-18" }>, align 8
@.d106 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"llvm-symbolizer" }>, align 8
@.d107 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d108 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d109 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d110 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"&lt;" }>, align 8
@.d111 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"&gt;" }>, align 8
@.d112 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"&amp;" }>, align 8
@.d113 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"&quot;" }>, align 8
@.d114 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d115 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
define internal i1 @olang_lambda_116(ptr %env, ptr %v0, ptr %v1, %"compiler/profile:elfFn" %a0, %"compiler/profile:elfFn" %a1) #0 {
entry:
  %l0 = alloca %"compiler/profile:elfFn"
  %l1 = alloca %"compiler/profile:elfFn"
  %rv = alloca i1
  store %"compiler/profile:elfFn" %a0, ptr %l0
  store %"compiler/profile:elfFn" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/profile:elfFn", ptr %l0, i32 0, i32 0
  %t2 = load i64, ptr %t1, !tbaa !24
  %t3 = getelementptr %"compiler/profile:elfFn", ptr %l1, i32 0, i32 0
  %t4 = load i64, ptr %t3, !tbaa !24
  %t7 = icmp slt i64 %t2, %t4
  store i1 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d117 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d118 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d119 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
@.d120 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"%" }>, align 8
@.d121 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"std/prelude" }>, align 8
@.d122 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d123 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d124 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d125 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d126 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"OLANG_PROFILE\00" }>, align 8
@.d127 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
declare i32 @setenv(ptr, ptr, i32)
declare i32 @fork()
declare void @_exit(i32)
@.d128 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"OLANG_PROFILE\00" }>, align 8
declare i32 @unsetenv(ptr)
declare i64 @signal(i32, i64)
declare i32 @waitpid(i32, ptr, i32)
@.d129 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"/proc/" }>, align 8
@.d130 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"OLPROF01" }>, align 8
@.d131 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d132 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d133 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d134 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d135 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"hot" }>, align 8
@.d136 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"hot.olang" }>, align 8
@.d137 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"main" }>, align 8
@.d138 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"hot.olang" }>, align 8
@.d139 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"Vec<I64>.Push" }>, align 8
@.d140 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"hot.olang" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d141 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2ePush_3ccompiler_2fprofile_3anode_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/profile:node" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2eLen_3ccompiler_2fprofile_3aSample_3e(ptr %v0, ptr %a0)
declare %"compiler/profile:Sample" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2eAt_3ccompiler_2fprofile_3aSample_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eRefMut_3ccompiler_2fprofile_3anode_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/profile:Frame" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2eAt_3ccompiler_2fprofile_3aFrame_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/profile:node" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eAt_3ccompiler_2fprofile_3anode_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eLen_3ccompiler_2fprofile_3anode_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1c, ptr %a1e)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eRef_3ccompiler_2fprofile_3anode_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eHash(ptr %v0, { i64, ptr } %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ffloat_2eF64_2eFixed(ptr %v0, double %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_c23c40ac9fceed99_19c8ab4fbd7fcba5 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2ePush_3ccompiler_2fprofile_3aSample_3e(ptr %v0, ptr %a0, %"compiler/profile:Sample" %a1)
@olang_loc_ebd4d37101874eec_6116e20ed9489b48 = external constant [0 x i8]
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2ftypes_2eDemangle(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_3603727fe313055_49dd245dfeecf61 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_e16765c4a8f41078_55e216e6a7163174 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_a05021294fe2b6d3_c60223eeaa2ef05f = external constant [0 x i8]
@olang_loc_efed15e4a0150676_49528d4cd386b8e2 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadEnd(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3amapping_3e_2eLen__Heb6545c4cbf57678e5e8a74f397c9583(ptr %v0, ptr %a0)
declare %"compiler/profile:mapping" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3amapping_3e_2eAt_3ccompiler_2fprofile_3amapping_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H67bc384d82ac3ceb3fdc5d6d25b5f02a(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Hd2a6d6393d72da4a22d0070783b9e545(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2)
declare { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H613fddb0939c6e46b95f2b1f68ba1bdb(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %v0, i64 %a0, i64 %a1)
@olang_loc_d50f4fab691edd32_66973f8664df657e = external constant [0 x i8]
declare { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
declare %"std/os:Output" @std_2fos_3aOutput_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2eLen_3ccompiler_2fprofile_3aFrame_3e(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H509117e81ae737fb138b1f364b80e611(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Hb4e1316c13adc554c531dbb9cf254a96(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2)
declare { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Hfa095cf457cc3af0cc9715613212afd3(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aelfFn_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_a4addf443e3a86b3_5ebaaf6328319b7f = external constant [0 x i8]
declare { i64, ptr } @std_2ffilepath_2eBase(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2ePush_3ccompiler_2fprofile_3aFrame_3e(ptr %v0, ptr %a0, %"compiler/profile:Frame" %a1)
@olang_loc_41e6651314f25f98_646ba62944647444 = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftarget_2eFindClang(ptr %v0)
declare { i64, ptr } @compiler_2ftarget_2eWhereIs(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2ffilepath_2eDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_7d2ae97c2364b59d_ce98559d67a1b5c9 = external constant [0 x i8]
@olang_loc_ec3589048a52ea40_4feb0c814716a05c = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_47d41d181de998ca_407a2b261e632036 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aelfFn_3e_2ePush_3ccompiler_2fprofile_3aelfFn_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/profile:elfFn" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aelfFn_3e_2eSort_3_H16cb1151e861568c30a5b57cf3c12bc1(ptr %v0, ptr %v1, ptr %a0, ptr %a1c, ptr %a1e)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3amapping_3e_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_49a351722641e944_c5b141a1c073228 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3amapping_3e_2ePush_Hc0dd0b8028ee4ec7edce99e352ae7bbd(ptr %v0, ptr %v1, ptr %a0, %"compiler/profile:mapping" %a1)
@olang_loc_8377dd777846f8d9_8488686b399fded = external constant [0 x i8]
declare { i64, ptr } @compiler_2fbuild_2eShown(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v1, ptr %a0)
declare i32 @std_2fos_2eExecInPlace(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_ec22c3592c386ac4_6a748f217c4c44c0 = external constant [0 x i8]
declare i1 @std_2fos_2eExists(ptr %v0, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU8_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eToArray_3cU8_3e(ptr %v0, ptr %v1, ptr %a0)
declare i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %v0)
@olang_loc_9b07e838cb7ed4ee_978ead1b2c1f88ba = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aelfFn_3e_2eLen_3ccompiler_2fprofile_3aelfFn_3e(ptr %v0, ptr %a0)
declare %"compiler/profile:elfFn" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aelfFn_3e_2eAt_3ccompiler_2fprofile_3aelfFn_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_cc2e380c5cd0dda_c071bfd9a740ca6e = external constant [0 x i8]
@olang_loc_4bebebd3fadd2f37_94a97b9fa165786b = external constant [0 x i8]
@olang_loc_ea1fc1fa824e624c_c3d948fe5a073af0 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2ector(ptr %v0, i64 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2fvec_3a_Hdb387e679134e71bf5648ac6d1ce10ff(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
