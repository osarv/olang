; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/profile:Sample" = type { i64, i64, i64 }
%"compiler/profile:node" = type { i64, i64, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/profile:Frame" = type { i64, i64, i64 }
%"compiler/profile:Profile" = type { i64, i64, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr } }
%"compiler/profile:Places" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/profile:Tally" = type { %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/profile:mapping" = type { i64, i64, i64, { i64, ptr } }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
%"compiler/profile:elfFn" = type { i64, i64, { i64, ptr } }
@G_2ecompiler_2fprofile_2eFlameScript = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\07\04\00\00\00\00\00\00", ptr @G_2ecompiler_2fprofile_2eFlameScript.k1 }>, align 8
@G_2ecompiler_2fprofile_2eFlameScript.k1 = internal constant <{ [1031 x i8] }> <{ [1031 x i8] c"\3C\73\63\72\69\70\74\3E\0A\28\66\75\6E\63\74\69\6F\6E\28\29\7B\0A\20\20\76\61\72\20\73\76\67\3D\64\6F\63\75\6D\65\6E\74\2E\67\65\74\45\6C\65\6D\65\6E\74\42\79\49\64\28\22\66\67\22\29\2C\57\3D\73\76\67\2E\67\65\74\41\74\74\72\69\62\75\74\65\28\22\77\69\64\74\68\22\29\2A\31\2C\67\73\3D\73\76\67\2E\71\75\65\72\79\53\65\6C\65\63\74\6F\72\41\6C\6C\28\22\67\2E\66\22\29\3B\0A\20\20\66\75\6E\63\74\69\6F\6E\20\73\68\6F\77\28\78\30\2C\77\30\2C\64\30\29\7B\0A\20\20\20\20\66\6F\72\28\76\61\72\20\69\3D\30\3B\69\3C\67\73\2E\6C\65\6E\67\74\68\3B\69\2B\2B\29\7B\0A\20\20\20\20\20\20\76\61\72\20\67\3D\67\73\5B\69\5D\2C\78\3D\67\2E\64\61\74\61\73\65\74\2E\78\2A\31\2C\77\3D\67\2E\64\61\74\61\73\65\74\2E\77\2A\31\2C\64\3D\67\2E\64\61\74\61\73\65\74\2E\64\2A\31\2C\72\3D\67\2E\71\75\65\72\79\53\65\6C\65\63\74\6F\72\28\22\72\65\63\74\22\29\2C\74\3D\67\2E\71\75\65\72\79\53\65\6C\65\63\74\6F\72\28\22\74\65\78\74\22\29\3B\0A\20\20\20\20\20\20\76\61\72\20\69\6E\73\69\64\65\3D\78\3E\3D\78\30\26\26\78\2B\77\3C\3D\78\30\2B\77\30\2C\75\6E\64\65\72\3D\64\3C\64\30\26\26\78\3C\3D\78\30\26\26\78\2B\77\3E\3D\78\30\2B\77\30\3B\0A\20\20\20\20\20\20\69\66\28\21\28\69\6E\73\69\64\65\26\26\64\3E\3D\64\30\29\26\26\21\75\6E\64\65\72\29\7B\67\2E\73\74\79\6C\65\2E\64\69\73\70\6C\61\79\3D\22\6E\6F\6E\65\22\3B\63\6F\6E\74\69\6E\75\65\7D\0A\20\20\20\20\20\20\67\2E\73\74\79\6C\65\2E\64\69\73\70\6C\61\79\3D\22\22\3B\0A\20\20\20\20\20\20\76\61\72\20\70\78\3D\75\6E\64\65\72\3F\30\3A\28\78\2D\78\30\29\2F\77\30\2A\57\2C\70\77\3D\75\6E\64\65\72\3F\57\3A\77\2F\77\30\2A\57\3B\0A\20\20\20\20\20\20\72\2E\73\65\74\41\74\74\72\69\62\75\74\65\28\22\78\22\2C\70\78\29\3B\72\2E\73\65\74\41\74\74\72\69\62\75\74\65\28\22\77\69\64\74\68\22\2C\4D\61\74\68\2E\6D\61\78\28\70\77\2D\31\2C\30\2E\35\29\29\3B\74\2E\73\65\74\41\74\74\72\69\62\75\74\65\28\22\78\22\2C\70\78\2B\33\29\3B\0A\20\20\20\20\20\20\76\61\72\20\66\75\6C\6C\3D\67\2E\71\75\65\72\79\53\65\6C\65\63\74\6F\72\28\22\74\69\74\6C\65\22\29\2E\74\65\78\74\43\6F\6E\74\65\6E\74\2E\72\65\70\6C\61\63\65\28\2F\20\2D\20\5B\30\2D\39\2E\5D\2B\20\6D\73\2C\20\2E\2A\24\2F\2C\22\22\29\2C\6E\3D\4D\61\74\68\2E\66\6C\6F\6F\72\28\28\70\77\2D\36\29\2F\37\29\3B\0A\20\20\20\20\20\20\74\2E\74\65\78\74\43\6F\6E\74\65\6E\74\3D\6E\3C\33\3F\22\22\3A\28\66\75\6C\6C\2E\6C\65\6E\67\74\68\3C\3D\6E\3F\66\75\6C\6C\3A\66\75\6C\6C\2E\73\6C\69\63\65\28\30\2C\6E\2D\32\29\2B\22\2E\2E\22\29\3B\0A\20\20\20\20\7D\0A\20\20\7D\0A\20\20\66\6F\72\28\76\61\72\20\69\3D\30\3B\69\3C\67\73\2E\6C\65\6E\67\74\68\3B\69\2B\2B\29\7B\67\73\5B\69\5D\2E\61\64\64\45\76\65\6E\74\4C\69\73\74\65\6E\65\72\28\22\63\6C\69\63\6B\22\2C\66\75\6E\63\74\69\6F\6E\28\29\7B\0A\20\20\20\20\76\61\72\20\64\3D\74\68\69\73\2E\64\61\74\61\73\65\74\2E\64\2A\31\3B\73\68\6F\77\28\74\68\69\73\2E\64\61\74\61\73\65\74\2E\78\2A\31\2C\4D\61\74\68\2E\6D\61\78\28\74\68\69\73\2E\64\61\74\61\73\65\74\2E\77\2A\31\2C\31\29\2C\64\3D\3D\30\3F\30\3A\64\29\7D\29\7D\0A\20\20\73\68\6F\77\28\30\2C\4D\61\74\68\2E\6D\61\78\28\73\76\67\2E\64\61\74\61\73\65\74\2E\74\6F\74\61\6C\2A\31\2C\31\29\2C\30\29\3B\0A\7D\29\28\29\3B\0A\3C\2F\73\63\72\69\70\74\3E" }>, align 64
@G_2ecompiler_2fprofile_2eFlameWidth = constant <{ [8 x i8] }> <{ [8 x i8] c"\B0\04\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fprofile_2eFrameHeight = constant <{ [8 x i8] }> <{ [8 x i8] c"\12\00\00\00\00\00\00\00" }>, align 8
define dso_local { i64, ptr } @compiler_2fprofile_2eFlameGraph(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/profile:Sample"
  %l7 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"compiler/profile:node"
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca %"compiler/profile:node"
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca %"compiler/profile:node"
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca %"std/prelude/text:StringBuilder"
  %l28 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l29 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l30 = alloca ptr
  %l31 = alloca i64
  %l32 = alloca %"compiler/profile:node"
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l36 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca %"compiler/profile:node"
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca %"std/prelude/text:StringBuilder"
  %l52 = alloca double
  %l53 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l54 = alloca ptr
  %l55 = alloca %"compiler/profile:node"
  %l58 = alloca i64
  %l60 = alloca i64
  %l65 = alloca %"compiler/profile:Sample"
  %l69 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l73 = alloca %"compiler/profile:node"
  %l81 = alloca i64
  %l87 = alloca ptr
  %l90 = alloca i64
  %l91 = alloca %"compiler/profile:Frame"
  %l95 = alloca %"compiler/profile:node"
  %l97 = alloca i64
  %l99 = alloca i64
  %l104 = alloca i64
  %l107 = alloca %"compiler/profile:node"
  %l117 = alloca i64
  %l118 = alloca ptr
  %l119 = alloca i64
  %l122 = alloca %"compiler/profile:node"
  %l125 = alloca %"compiler/profile:node"
  %l128 = alloca %"compiler/profile:node"
  %l135 = alloca %"compiler/profile:node"
  %l148 = alloca i64
  %l150 = alloca i64
  %l155 = alloca %"compiler/profile:node"
  %l163 = alloca %"compiler/profile:node"
  %l170 = alloca %"std/prelude/text:StringBuilder"
  %l171 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l173 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l175 = alloca i64
  %l177 = alloca i64
  %l182 = alloca %"compiler/profile:node"
  %l186 = alloca i64
  %l188 = alloca i64
  %l193 = alloca i64
  %l196 = alloca %"compiler/profile:node"
  %l198 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l205 = alloca i64
  %l207 = alloca i64
  %l209 = alloca i64
  %l214 = alloca i64
  %l218 = alloca i64
  %l221 = alloca %"compiler/profile:node"
  %l231 = alloca i64
  %l233 = alloca i64
  %l238 = alloca i64
  %l241 = alloca %"compiler/profile:node"
  %l244 = alloca { i64, ptr }
  %l248 = alloca { i64, ptr }
  %l249 = alloca { i64, ptr }
  %l253 = alloca { i64, ptr }
  %l256 = alloca { i64, ptr }
  %l259 = alloca i64
  %l278 = alloca ptr
  %l281 = alloca i64
  %l282 = alloca i64
  %l283 = alloca i64
  %l285 = alloca { i64, ptr }
  %l286 = alloca i64
  %l288 = alloca i64
  %l289 = alloca i64
  %l290 = alloca i64
  %l291 = alloca i64
  %l294 = alloca { i64, ptr }
  %l296 = alloca { i64, ptr }
  %l301 = alloca %"std/prelude/text:StringBuilder"
  %l302 = alloca ptr
  %l304 = alloca { i64, ptr }
  %l309 = alloca i64
  %l316 = alloca ptr
  %l318 = alloca { i64, ptr }
  %l321 = alloca i64
  %l323 = alloca { i64, ptr }
  %l326 = alloca ptr
  %l327 = alloca i64
  %l328 = alloca i64
  %l329 = alloca i64
  %l331 = alloca { i64, ptr }
  %l338 = alloca { i64, ptr }
  %l339 = alloca { i64, ptr }
  %l340 = alloca i64
  %l341 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t281 = alloca { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr }, align 8
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l53
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l53
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l3
  store ptr %l3, ptr %l54, !tbaa !29
  %t3 = call %"compiler/profile:node" @compiler_2fprofile_3anode_2ector(ptr %s0, i64 -1, i64 0)
  store %"compiler/profile:node" %t3, ptr %l55
  br label %bb2
bb2:
  %t4 = load ptr, ptr %l54, !tbaa !29
  %t5 = load %"compiler/profile:node", ptr %l55
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2ePush_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s0, ptr %t4, %"compiler/profile:node" %t5)
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/profile:Profile", ptr %t6, i32 0, i32 3
  store ptr %t8, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = load i64, ptr %l5, !tbaa !24
  store i64 %t10, ptr %l58, !tbaa !24
  %t11 = load ptr, ptr %l4, !tbaa !29
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2eLen_3ccompiler_2fprofile_3aSample_3e(ptr %v1, ptr %t11)
  store i64 %t13, ptr %l60
  br label %bb5
bb5:
  %t14 = load i64, ptr %l58, !tbaa !24
  %t15 = load i64, ptr %l60, !tbaa !24
  %t16 = icmp slt i64 %t14, %t15
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb47
bb7:
  br label %bb8
bb8:
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t21 = load i64, ptr %l5, !tbaa !24
  %t24 = call %"compiler/profile:Sample" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2eAt_3ccompiler_2fprofile_3aSample_3e(ptr %v1, ptr %t20, i64 %t21)
  store %"compiler/profile:Sample" %t24, ptr %l65
  br label %bb9
bb9:
  %t25 = load %"compiler/profile:Sample", ptr %l65
  store %"compiler/profile:Sample" %t25, ptr %l6
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t28 = load %"compiler/profile:Sample", ptr %l6
  %t32 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2estack(ptr %v2, ptr %v1, ptr %s2, ptr %t26, ptr %t27, %"compiler/profile:Sample" %t28)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %l69
  br label %bb10
bb10:
  %t33 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l69
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t33, ptr %l7
  store i64 0, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  %t34 = getelementptr %"compiler/profile:Sample", ptr %l6, i32 0, i32 0
  %t35 = load i64, ptr %t34, !tbaa !24
  store i64 %t35, ptr %l10, !tbaa !24
  %t37 = load i64, ptr %l9, !tbaa !24
  %t40 = call %"compiler/profile:node" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eAt_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s0, ptr %l3, i64 %t37)
  store %"compiler/profile:node" %t40, ptr %l73
  br label %bb11
bb11:
  %t41 = load %"compiler/profile:node", ptr %l73
  store %"compiler/profile:node" %t41, ptr %l11
  %t42 = getelementptr %"compiler/profile:node", ptr %l11, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t44 = load i64, ptr %l10, !tbaa !24
  %t47 = add i64 %t43, %t44
  %t49 = getelementptr %"compiler/profile:node", ptr %l11, i32 0, i32 2
  store i64 %t47, ptr %t49, !tbaa !24
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = load %"compiler/profile:node", ptr %l11
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eSetAt_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s0, ptr %l3, i64 %t50, %"compiler/profile:node" %t51)
  br label %bb12
bb12:
  %t56 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s2, ptr %l7)
  store i64 %t56, ptr %l81
  br label %bb13
bb13:
  %t57 = load i64, ptr %l81, !tbaa !24
  %t58 = sub i64 %t57, 1
  store i64 %t58, ptr %l12, !tbaa !24
  br label %bb14
bb14:
  %t60 = load i64, ptr %l12, !tbaa !24
  %t62 = icmp sge i64 %t60, 0
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb15, label %bb16
bb15:
  br label %bb45
bb16:
  br label %bb17
bb17:
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t68 = getelementptr %"compiler/profile:Places", ptr %t66, i32 0, i32 2
  store ptr %t68, ptr %l87, !tbaa !29
  %t69 = load i64, ptr %l12, !tbaa !24
  %t72 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %l7, i64 %t69)
  store i64 %t72, ptr %l90
  br label %bb18
bb18:
  %t73 = load ptr, ptr %l87, !tbaa !29
  %t74 = load i64, ptr %l90, !tbaa !24
  %t75 = call %"compiler/profile:Frame" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2eAt_3ccompiler_2fprofile_3aFrame_3e(ptr %v2, ptr %t73, i64 %t74)
  store %"compiler/profile:Frame" %t75, ptr %l91
  br label %bb19
bb19:
  %t76 = getelementptr %"compiler/profile:Frame", ptr %l91, i32 0, i32 0
  %t77 = load i64, ptr %t76, !tbaa !24
  store i64 %t77, ptr %l13, !tbaa !24
  store i64 -1, ptr %l14, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s4
  %t79 = load i64, ptr %l8, !tbaa !24
  %t82 = call %"compiler/profile:node" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eAt_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s0, ptr %l3, i64 %t79)
  store %"compiler/profile:node" %t82, ptr %l95
  br label %bb20
bb20:
  %t83 = getelementptr %"compiler/profile:node", ptr %l95, i32 0, i32 3
  store ptr %t83, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb21
bb21:
  %t85 = load i64, ptr %l16, !tbaa !24
  store i64 %t85, ptr %l97, !tbaa !24
  %t86 = load ptr, ptr %l15, !tbaa !29
  %t88 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s4, ptr %t86)
  store i64 %t88, ptr %l99
  br label %bb22
bb22:
  %t89 = load i64, ptr %l97, !tbaa !24
  %t90 = load i64, ptr %l99, !tbaa !24
  %t91 = icmp slt i64 %t89, %t90
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb23, label %bb24
bb23:
  br label %bb32
bb24:
  br label %bb25
bb25:
  %t95 = load ptr, ptr %l15, !tbaa !29
  %t96 = load i64, ptr %l16, !tbaa !24
  %t99 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s4, ptr %t95, i64 %t96)
  store i64 %t99, ptr %l104
  br label %bb26
bb26:
  %t100 = load i64, ptr %l104, !tbaa !24
  store i64 %t100, ptr %l17, !tbaa !24
  %t101 = load i64, ptr %l17, !tbaa !24
  %t104 = call %"compiler/profile:node" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eAt_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s0, ptr %l3, i64 %t101)
  store %"compiler/profile:node" %t104, ptr %l107
  br label %bb27
bb27:
  %t105 = getelementptr %"compiler/profile:node", ptr %l107, i32 0, i32 0
  %t106 = load i64, ptr %t105, !tbaa !24
  %t107 = load i64, ptr %l13, !tbaa !24
  %t110 = icmp eq i64 %t106, %t107
  br i1 %t110, label %bb28, label %bb29
bb28:
  %t112 = load i64, ptr %l17, !tbaa !24
  store i64 %t112, ptr %l14, !tbaa !24
  br label %bb30
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t114 = load i64, ptr %l16, !tbaa !24
  %t116 = add i64 %t114, 1
  store i64 %t116, ptr %l16, !tbaa !24
  br label %bb21
bb32:
  call void @__olang_scope_close(ptr %s4)
  %t118 = load i64, ptr %l14, !tbaa !24
  %t120 = icmp slt i64 %t118, 0
  br i1 %t120, label %bb33, label %bb34
bb33:
  %t123 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eLen_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %l3)
  store i64 %t123, ptr %l117
  br label %bb35
bb34:
  br label %bb41
bb35:
  %t124 = load i64, ptr %l117, !tbaa !24
  store i64 %t124, ptr %l14, !tbaa !24
  store ptr %l3, ptr %l118, !tbaa !29
  %t125 = load i64, ptr %l13, !tbaa !24
  store i64 %t125, ptr %l119, !tbaa !24
  %t126 = load i64, ptr %l8, !tbaa !24
  %t129 = call %"compiler/profile:node" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eAt_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s0, ptr %l3, i64 %t126)
  store %"compiler/profile:node" %t129, ptr %l122
  br label %bb36
bb36:
  %t130 = getelementptr %"compiler/profile:node", ptr %l122, i32 0, i32 1
  %t131 = load i64, ptr %t130, !tbaa !24
  %t133 = add i64 %t131, 1
  %t134 = load i64, ptr %l119, !tbaa !24
  %t136 = call %"compiler/profile:node" @compiler_2fprofile_3anode_2ector(ptr %s0, i64 %t134, i64 %t133)
  store %"compiler/profile:node" %t136, ptr %l125
  br label %bb37
bb37:
  %t137 = load ptr, ptr %l118, !tbaa !29
  %t138 = load %"compiler/profile:node", ptr %l125
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2ePush_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s0, ptr %t137, %"compiler/profile:node" %t138)
  br label %bb38
bb38:
  %t139 = load i64, ptr %l8, !tbaa !24
  %t142 = call %"compiler/profile:node" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eAt_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s0, ptr %l3, i64 %t139)
  store %"compiler/profile:node" %t142, ptr %l128
  br label %bb39
bb39:
  %t143 = getelementptr %"compiler/profile:node", ptr %l128, i32 0, i32 3
  %t144 = load i64, ptr %l14, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t143, i64 %t144)
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t147 = load i64, ptr %l14, !tbaa !24
  store i64 %t147, ptr %l18, !tbaa !24
  %t149 = getelementptr %"compiler/profile:Sample", ptr %l6, i32 0, i32 0
  %t150 = load i64, ptr %t149, !tbaa !24
  store i64 %t150, ptr %l19, !tbaa !24
  %t152 = load i64, ptr %l18, !tbaa !24
  %t155 = call %"compiler/profile:node" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eAt_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s0, ptr %l3, i64 %t152)
  store %"compiler/profile:node" %t155, ptr %l135
  br label %bb42
bb42:
  %t156 = load %"compiler/profile:node", ptr %l135
  store %"compiler/profile:node" %t156, ptr %l20
  %t157 = getelementptr %"compiler/profile:node", ptr %l20, i32 0, i32 2
  %t158 = load i64, ptr %t157, !tbaa !24
  %t159 = load i64, ptr %l19, !tbaa !24
  %t162 = add i64 %t158, %t159
  %t164 = getelementptr %"compiler/profile:node", ptr %l20, i32 0, i32 2
  store i64 %t162, ptr %t164, !tbaa !24
  %t165 = load i64, ptr %l18, !tbaa !24
  %t166 = load %"compiler/profile:node", ptr %l20
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eSetAt_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s0, ptr %l3, i64 %t165, %"compiler/profile:node" %t166)
  br label %bb43
bb43:
  %t170 = load i64, ptr %l14, !tbaa !24
  store i64 %t170, ptr %l8, !tbaa !24
  %t172 = load i64, ptr %l12, !tbaa !24
  %t174 = sub i64 %t172, 1
  store i64 %t174, ptr %l12, !tbaa !24
  br label %bb44
bb44:
  br label %bb14
bb45:
  call void @__olang_scope_close(ptr %s2)
  br label %bb46
bb46:
  %t176 = load i64, ptr %l5, !tbaa !24
  %t178 = add i64 %t176, 1
  store i64 %t178, ptr %l5, !tbaa !24
  br label %bb4
bb47:
  store i64 0, ptr %l21, !tbaa !24
  store ptr %l3, ptr %l22, !tbaa !29
  store i64 0, ptr %l23, !tbaa !24
  br label %bb48
bb48:
  %t181 = load i64, ptr %l23, !tbaa !24
  store i64 %t181, ptr %l148, !tbaa !24
  %t182 = load ptr, ptr %l22, !tbaa !29
  %t184 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eLen_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %t182)
  store i64 %t184, ptr %l150
  br label %bb49
bb49:
  %t185 = load i64, ptr %l148, !tbaa !24
  %t186 = load i64, ptr %l150, !tbaa !24
  %t187 = icmp slt i64 %t185, %t186
  %t189 = xor i1 %t187, true
  br i1 %t189, label %bb50, label %bb51
bb50:
  br label %bb58
bb51:
  br label %bb52
bb52:
  %t191 = load ptr, ptr %l22, !tbaa !29
  %t192 = load i64, ptr %l23, !tbaa !24
  %t195 = call %"compiler/profile:node" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eAt_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s0, ptr %t191, i64 %t192)
  store %"compiler/profile:node" %t195, ptr %l155
  br label %bb53
bb53:
  %t196 = load %"compiler/profile:node", ptr %l155
  store %"compiler/profile:node" %t196, ptr %l24
  %t197 = getelementptr %"compiler/profile:node", ptr %l24, i32 0, i32 1
  %t198 = load i64, ptr %t197, !tbaa !24
  %t199 = load i64, ptr %l21, !tbaa !24
  %t202 = icmp sgt i64 %t198, %t199
  br i1 %t202, label %bb54, label %bb55
bb54:
  %t204 = getelementptr %"compiler/profile:node", ptr %l24, i32 0, i32 1
  %t205 = load i64, ptr %t204, !tbaa !24
  store i64 %t205, ptr %l21, !tbaa !24
  br label %bb56
bb55:
  br label %bb56
bb56:
  br label %bb57
bb57:
  %t207 = load i64, ptr %l23, !tbaa !24
  %t209 = add i64 %t207, 1
  store i64 %t209, ptr %l23, !tbaa !24
  br label %bb48
bb58:
  %t212 = call %"compiler/profile:node" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eAt_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s0, ptr %l3, i64 0)
  store %"compiler/profile:node" %t212, ptr %l163
  br label %bb59
bb59:
  %t213 = getelementptr %"compiler/profile:node", ptr %l163, i32 0, i32 2
  %t214 = load i64, ptr %t213, !tbaa !24
  store i64 %t214, ptr %l25, !tbaa !24
  %t216 = load i64, ptr %l21, !tbaa !24
  %t218 = add i64 %t216, 1
  %t219 = load i64, ptr @G_2ecompiler_2fprofile_2eFrameHeight, !tbaa !24
  %t222 = mul i64 %t218, %t219
  %t224 = add i64 %t222, 40
  store i64 %t224, ptr %l26, !tbaa !24
  %t226 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t226, ptr %l170
  br label %bb60
bb60:
  %t227 = load %"std/prelude/text:StringBuilder", ptr %l170
  store %"std/prelude/text:StringBuilder" %t227, ptr %l27
  %t228 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t228, ptr %l171
  br label %bb61
bb61:
  %t229 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l171
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t229, ptr %l28
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l28, i64 0)
  br label %bb62
bb62:
  %t231 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t231, ptr %l173
  br label %bb63
bb63:
  %t232 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l173
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t232, ptr %l29
  store ptr %l3, ptr %l30, !tbaa !29
  store i64 0, ptr %l31, !tbaa !24
  br label %bb64
bb64:
  %t234 = load i64, ptr %l31, !tbaa !24
  store i64 %t234, ptr %l175, !tbaa !24
  %t235 = load ptr, ptr %l30, !tbaa !29
  %t237 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eLen_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %t235)
  store i64 %t237, ptr %l177
  br label %bb65
bb65:
  %t238 = load i64, ptr %l175, !tbaa !24
  %t239 = load i64, ptr %l177, !tbaa !24
  %t240 = icmp slt i64 %t238, %t239
  %t242 = xor i1 %t240, true
  br i1 %t242, label %bb66, label %bb67
bb66:
  br label %bb72
bb67:
  br label %bb68
bb68:
  %t244 = load ptr, ptr %l30, !tbaa !29
  %t245 = load i64, ptr %l31, !tbaa !24
  %t248 = call %"compiler/profile:node" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eAt_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s0, ptr %t244, i64 %t245)
  store %"compiler/profile:node" %t248, ptr %l182
  br label %bb69
bb69:
  %t249 = load %"compiler/profile:node", ptr %l182
  store %"compiler/profile:node" %t249, ptr %l32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l29, i64 0)
  br label %bb70
bb70:
  br label %bb71
bb71:
  %t251 = load i64, ptr %l31, !tbaa !24
  %t253 = add i64 %t251, 1
  store i64 %t253, ptr %l31, !tbaa !24
  br label %bb64
bb72:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb73
bb73:
  store %olang.scope zeroinitializer, ptr %s18
  %t255 = load i64, ptr %l33, !tbaa !24
  store i64 %t255, ptr %l186, !tbaa !24
  %t257 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l28)
  store i64 %t257, ptr %l188
  br label %bb74
bb74:
  %t258 = load i64, ptr %l186, !tbaa !24
  %t259 = load i64, ptr %l188, !tbaa !24
  %t260 = icmp slt i64 %t258, %t259
  %t262 = xor i1 %t260, true
  br i1 %t262, label %bb75, label %bb76
bb75:
  call void @__olang_scope_close(ptr %s18)
  br label %bb95
bb76:
  br label %bb77
bb77:
  %t264 = load i64, ptr %l33, !tbaa !24
  %t267 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l28, i64 %t264)
  store i64 %t267, ptr %l193
  br label %bb78
bb78:
  %t268 = load i64, ptr %l193, !tbaa !24
  store i64 %t268, ptr %l34, !tbaa !24
  %t269 = load i64, ptr %l34, !tbaa !24
  %t272 = call %"compiler/profile:node" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eAt_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s0, ptr %l3, i64 %t269)
  store %"compiler/profile:node" %t272, ptr %l196
  br label %bb79
bb79:
  %t273 = getelementptr %"compiler/profile:node", ptr %l196, i32 0, i32 3
  %t275 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClone_3cI64_3e(ptr %s0, ptr %s18, ptr %t273)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t275, ptr %l198
  br label %bb80
bb80:
  %t276 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l198
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t276, ptr %l35
  %t277 = load ptr, ptr %l2, !tbaa !29
  %t278 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  %t279 = getelementptr { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr }, ptr null, i32 1
  %t280 = ptrtoint ptr %t279 to i64
  %t282 = getelementptr { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr }, ptr %t281, i32 0, i32 0
  store ptr %t277, ptr %t282, !tbaa !28
  %t284 = getelementptr { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr }, ptr %t281, i32 0, i32 1
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t278, ptr %t284, !tbaa !28
  call void @__olang_scope_escape(ptr %v2)
  %t286 = getelementptr { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr }, ptr %t281, i32 0, i32 2
  store ptr %v2, ptr %t286, !tbaa !28
  call void @__olang_scope_escape(ptr %s0)
  %t287 = getelementptr { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr }, ptr %t281, i32 0, i32 3
  store ptr %s0, ptr %t287, !tbaa !28
  %t288 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_0, 0
  %t289 = insertvalue { ptr, ptr } %t288, ptr %t281, 1
  %t292 = extractvalue { ptr, ptr } %t289, 0
  %t293 = extractvalue { ptr, ptr } %t289, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %s18, ptr %s18, ptr %l35, ptr %t292, ptr %t293)
  br label %bb81
bb81:
  %t294 = load i64, ptr %l34, !tbaa !24
  %t297 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l29, i64 %t294)
  store i64 %t297, ptr %l205
  br label %bb82
bb82:
  %t298 = load i64, ptr %l205, !tbaa !24
  store i64 %t298, ptr %l36, !tbaa !24
  store ptr %l35, ptr %l37, !tbaa !29
  store i64 0, ptr %l38, !tbaa !24
  br label %bb83
bb83:
  %t300 = load i64, ptr %l38, !tbaa !24
  store i64 %t300, ptr %l207, !tbaa !24
  %t301 = load ptr, ptr %l37, !tbaa !29
  %t303 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s18, ptr %t301)
  store i64 %t303, ptr %l209
  br label %bb84
bb84:
  %t304 = load i64, ptr %l207, !tbaa !24
  %t305 = load i64, ptr %l209, !tbaa !24
  %t306 = icmp slt i64 %t304, %t305
  %t308 = xor i1 %t306, true
  br i1 %t308, label %bb85, label %bb86
bb85:
  br label %bb93
bb86:
  br label %bb87
bb87:
  %t310 = load ptr, ptr %l37, !tbaa !29
  %t311 = load i64, ptr %l38, !tbaa !24
  %t314 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s18, ptr %t310, i64 %t311)
  store i64 %t314, ptr %l214
  br label %bb88
bb88:
  %t315 = load i64, ptr %l214, !tbaa !24
  store i64 %t315, ptr %l39, !tbaa !24
  %t316 = load i64, ptr %l39, !tbaa !24
  %t317 = load i64, ptr %l36, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %s0, ptr %l29, i64 %t316, i64 %t317)
  br label %bb89
bb89:
  %t321 = load i64, ptr %l36, !tbaa !24
  store i64 %t321, ptr %l218, !tbaa !24
  %t322 = load i64, ptr %l39, !tbaa !24
  %t325 = call %"compiler/profile:node" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eAt_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s0, ptr %l3, i64 %t322)
  store %"compiler/profile:node" %t325, ptr %l221
  br label %bb90
bb90:
  %t326 = getelementptr %"compiler/profile:node", ptr %l221, i32 0, i32 2
  %t327 = load i64, ptr %t326, !tbaa !24
  %t328 = load i64, ptr %l218, !tbaa !24
  %t330 = add i64 %t328, %t327
  store i64 %t330, ptr %l36, !tbaa !24
  %t332 = load i64, ptr %l39, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l28, i64 %t332)
  br label %bb91
bb91:
  br label %bb92
bb92:
  %t335 = load i64, ptr %l38, !tbaa !24
  %t337 = add i64 %t335, 1
  store i64 %t337, ptr %l38, !tbaa !24
  br label %bb83
bb93:
  call void @__olang_scope_close(ptr %s18)
  br label %bb94
bb94:
  %t339 = load i64, ptr %l33, !tbaa !24
  %t341 = add i64 %t339, 1
  store i64 %t341, ptr %l33, !tbaa !24
  br label %bb73
bb95:
  store ptr %l28, ptr %l40, !tbaa !29
  store i64 0, ptr %l41, !tbaa !24
  br label %bb96
bb96:
  store %olang.scope zeroinitializer, ptr %s24
  %t344 = load i64, ptr %l41, !tbaa !24
  store i64 %t344, ptr %l231, !tbaa !24
  %t345 = load ptr, ptr %l40, !tbaa !29
  %t347 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t345)
  store i64 %t347, ptr %l233
  br label %bb97
bb97:
  %t348 = load i64, ptr %l231, !tbaa !24
  %t349 = load i64, ptr %l233, !tbaa !24
  %t350 = icmp slt i64 %t348, %t349
  %t352 = xor i1 %t350, true
  br i1 %t352, label %bb98, label %bb99
bb98:
  call void @__olang_scope_close(ptr %s24)
  br label %bb115
bb99:
  br label %bb100
bb100:
  %t354 = load ptr, ptr %l40, !tbaa !29
  %t355 = load i64, ptr %l41, !tbaa !24
  %t358 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t354, i64 %t355)
  store i64 %t358, ptr %l238
  br label %bb101
bb101:
  %t359 = load i64, ptr %l238, !tbaa !24
  store i64 %t359, ptr %l42, !tbaa !24
  %t360 = load i64, ptr %l42, !tbaa !24
  %t363 = call %"compiler/profile:node" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eAt_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s0, ptr %l3, i64 %t360)
  store %"compiler/profile:node" %t363, ptr %l241
  br label %bb102
bb102:
  %t364 = load %"compiler/profile:node", ptr %l241
  store %"compiler/profile:node" %t364, ptr %l43
  %t365 = load i64, ptr %l42, !tbaa !24
  %t367 = icmp eq i64 %t365, 0
  br i1 %t367, label %bb103, label %bb104
bb103:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l244, !tbaa !27
  br label %bb106
bb104:
  %t369 = load ptr, ptr %l2, !tbaa !29
  %t371 = getelementptr %"compiler/profile:Places", ptr %t369, i32 0, i32 0
  %t372 = getelementptr %"compiler/profile:node", ptr %l43, i32 0, i32 0
  %t373 = load i64, ptr %t372, !tbaa !24
  %t376 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %s24, ptr %t371, i64 %t373)
  store { i64, ptr } %t376, ptr %l248
  br label %bb105
bb105:
  %t377 = load { i64, ptr }, ptr %l248, !tbaa !27
  store { i64, ptr } %t377, ptr %l244, !tbaa !27
  br label %bb106
bb106:
  %t378 = load { i64, ptr }, ptr %l244, !tbaa !27
  store { i64, ptr } %t378, ptr %l44, !tbaa !27
  %t379 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t379, ptr %l249, !tbaa !27
  %t380 = getelementptr %"compiler/profile:node", ptr %l43, i32 0, i32 2
  %t381 = load i64, ptr %t380, !tbaa !24
  %t382 = load ptr, ptr %l1, !tbaa !29
  %t384 = getelementptr %"compiler/profile:Profile", ptr %t382, i32 0, i32 0
  %t385 = load i64, ptr %t384, !tbaa !24
  %t388 = call { i64, ptr } @compiler_2fprofile_2emillis(ptr %s24, i64 %t381, i64 %t385)
  store { i64, ptr } %t388, ptr %l253
  br label %bb107
bb107:
  %t389 = getelementptr %"compiler/profile:node", ptr %l43, i32 0, i32 2
  %t390 = load i64, ptr %t389, !tbaa !24
  %t391 = load i64, ptr %l25, !tbaa !24
  %t394 = call { i64, ptr } @compiler_2fprofile_2epct(ptr %s24, i64 %t390, i64 %t391)
  store { i64, ptr } %t394, ptr %l256
  br label %bb108
bb108:
  %t395 = load { i64, ptr }, ptr %l249, !tbaa !27
  %t396 = extractvalue { i64, ptr } %t395, 1
  %t397 = extractvalue { i64, ptr } %t395, 0
  %t398 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t399 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t400 = add i64 %t397, %t399
  %t401 = load { i64, ptr }, ptr %l253, !tbaa !27
  %t402 = extractvalue { i64, ptr } %t401, 1
  %t403 = extractvalue { i64, ptr } %t401, 0
  %t404 = add i64 %t400, %t403
  %t405 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t406 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t407 = add i64 %t404, %t406
  %t408 = load { i64, ptr }, ptr %l256, !tbaa !27
  %t409 = extractvalue { i64, ptr } %t408, 1
  %t410 = extractvalue { i64, ptr } %t408, 0
  %t411 = add i64 %t407, %t410
  %t412 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t411)
  call void @olang_textcopy(ptr %t412, ptr %t396, i64 %t397)
  %t413 = getelementptr i8, ptr %t412, i64 %t397
  call void @olang_textcopy(ptr %t413, ptr %t398, i64 %t399)
  %t414 = getelementptr i8, ptr %t413, i64 %t399
  call void @olang_textcopy(ptr %t414, ptr %t402, i64 %t403)
  %t415 = getelementptr i8, ptr %t414, i64 %t403
  call void @olang_textcopy(ptr %t415, ptr %t405, i64 %t406)
  %t416 = getelementptr i8, ptr %t415, i64 %t406
  call void @olang_textcopy(ptr %t416, ptr %t409, i64 %t410)
  %t417 = insertvalue { i64, ptr } undef, i64 %t411, 0
  %t418 = insertvalue { i64, ptr } %t417, ptr %t412, 1
  store { i64, ptr } %t418, ptr %l45, !tbaa !27
  %t420 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t422 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eHash(ptr %s24, { i64, ptr } %t420)
  store i64 %t422, ptr %l259
  br label %bb109
bb109:
  %t423 = load i64, ptr %l259, !tbaa !24
  %t424 = and i64 %t423, 65535
  store i64 %t424, ptr %l46, !tbaa !24
  %t426 = load i64, ptr %l46, !tbaa !24
  %t428 = srem i64 %t426, 50
  %t430 = add i64 205, %t428
  store i64 %t430, ptr %l47, !tbaa !24
  %t432 = load i64, ptr %l46, !tbaa !24
  %t434 = sdiv i64 %t432, 50
  %t436 = srem i64 %t434, 140
  %t438 = add i64 90, %t436
  store i64 %t438, ptr %l48, !tbaa !24
  %t440 = load i64, ptr %l46, !tbaa !24
  %t442 = sdiv i64 %t440, 7000
  %t444 = srem i64 %t442, 55
  store i64 %t444, ptr %l49, !tbaa !24
  %t446 = load i64, ptr %l26, !tbaa !24
  %t448 = sub i64 %t446, 20
  %t449 = getelementptr %"compiler/profile:node", ptr %l43, i32 0, i32 1
  %t450 = load i64, ptr %t449, !tbaa !24
  %t452 = add i64 %t450, 1
  %t453 = load i64, ptr @G_2ecompiler_2fprofile_2eFrameHeight, !tbaa !24
  %t456 = mul i64 %t452, %t453
  %t459 = sub i64 %t448, %t456
  store i64 %t459, ptr %l50, !tbaa !24
  store ptr %l27, ptr %l278, !tbaa !29
  %t461 = load i64, ptr %l42, !tbaa !24
  %t464 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l29, i64 %t461)
  store i64 %t464, ptr %l281
  br label %bb110
bb110:
  %t465 = getelementptr %"compiler/profile:node", ptr %l43, i32 0, i32 2
  %t466 = load i64, ptr %t465, !tbaa !24
  store i64 %t466, ptr %l282, !tbaa !24
  %t467 = getelementptr %"compiler/profile:node", ptr %l43, i32 0, i32 1
  %t468 = load i64, ptr %t467, !tbaa !24
  store i64 %t468, ptr %l283, !tbaa !24
  %t469 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t471 = call { i64, ptr } @compiler_2fprofile_2eescapeXml(ptr %s24, ptr %s24, { i64, ptr } %t469)
  store { i64, ptr } %t471, ptr %l285
  br label %bb111
bb111:
  %t472 = load i64, ptr %l50, !tbaa !24
  store i64 %t472, ptr %l286, !tbaa !24
  %t473 = load i64, ptr @G_2ecompiler_2fprofile_2eFrameHeight, !tbaa !24
  %t475 = sub i64 %t473, 1
  store i64 %t475, ptr %l288, !tbaa !24
  %t476 = load i64, ptr %l47, !tbaa !24
  store i64 %t476, ptr %l289, !tbaa !24
  %t477 = load i64, ptr %l48, !tbaa !24
  store i64 %t477, ptr %l290, !tbaa !24
  %t478 = load i64, ptr %l49, !tbaa !24
  store i64 %t478, ptr %l291, !tbaa !24
  %t479 = load i64, ptr %l50, !tbaa !24
  %t481 = add i64 %t479, 13
  %t483 = call i64 @__olang_fmt_i64(ptr null, i64 %t481)
  %t484 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t483)
  %t485 = call i64 @__olang_fmt_i64(ptr %t484, i64 %t481)
  %t486 = insertvalue { i64, ptr } undef, i64 %t483, 0
  %t487 = insertvalue { i64, ptr } %t486, ptr %t484, 1
  store { i64, ptr } %t487, ptr %l294, !tbaa !27
  %t488 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t490 = call { i64, ptr } @compiler_2fprofile_2eescapeXml(ptr %s24, ptr %s24, { i64, ptr } %t488)
  store { i64, ptr } %t490, ptr %l296
  br label %bb112
bb112:
  %t491 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t492 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t493 = load i64, ptr %l281, !tbaa !24
  %t494 = call i64 @__olang_fmt_i64(ptr null, i64 %t493)
  %t495 = add i64 %t492, %t494
  %t496 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t497 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t498 = add i64 %t495, %t497
  %t499 = load i64, ptr %l282, !tbaa !24
  %t500 = call i64 @__olang_fmt_i64(ptr null, i64 %t499)
  %t501 = add i64 %t498, %t500
  %t502 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t503 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t504 = add i64 %t501, %t503
  %t505 = load i64, ptr %l283, !tbaa !24
  %t506 = call i64 @__olang_fmt_i64(ptr null, i64 %t505)
  %t507 = add i64 %t504, %t506
  %t508 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t509 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t510 = add i64 %t507, %t509
  %t511 = load { i64, ptr }, ptr %l285, !tbaa !27
  %t512 = extractvalue { i64, ptr } %t511, 1
  %t513 = extractvalue { i64, ptr } %t511, 0
  %t514 = add i64 %t510, %t513
  %t515 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t516 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t517 = add i64 %t514, %t516
  %t518 = load i64, ptr %l286, !tbaa !24
  %t519 = call i64 @__olang_fmt_i64(ptr null, i64 %t518)
  %t520 = add i64 %t517, %t519
  %t521 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t522 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t523 = add i64 %t520, %t522
  %t524 = load i64, ptr %l288, !tbaa !24
  %t525 = call i64 @__olang_fmt_i64(ptr null, i64 %t524)
  %t526 = add i64 %t523, %t525
  %t527 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t528 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t529 = add i64 %t526, %t528
  %t530 = load i64, ptr %l289, !tbaa !24
  %t531 = call i64 @__olang_fmt_i64(ptr null, i64 %t530)
  %t532 = add i64 %t529, %t531
  %t533 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t534 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t535 = add i64 %t532, %t534
  %t536 = load i64, ptr %l290, !tbaa !24
  %t537 = call i64 @__olang_fmt_i64(ptr null, i64 %t536)
  %t538 = add i64 %t535, %t537
  %t539 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t540 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t541 = add i64 %t538, %t540
  %t542 = load i64, ptr %l291, !tbaa !24
  %t543 = call i64 @__olang_fmt_i64(ptr null, i64 %t542)
  %t544 = add i64 %t541, %t543
  %t545 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t546 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t547 = add i64 %t544, %t546
  %t548 = load { i64, ptr }, ptr %l294, !tbaa !27
  %t549 = extractvalue { i64, ptr } %t548, 1
  %t550 = extractvalue { i64, ptr } %t548, 0
  %t551 = add i64 %t547, %t550
  %t552 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t553 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t554 = add i64 %t551, %t553
  %t555 = load { i64, ptr }, ptr %l296, !tbaa !27
  %t556 = extractvalue { i64, ptr } %t555, 1
  %t557 = extractvalue { i64, ptr } %t555, 0
  %t558 = add i64 %t554, %t557
  %t559 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t560 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t561 = add i64 %t558, %t560
  %t562 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t561)
  call void @olang_textcopy(ptr %t562, ptr %t491, i64 %t492)
  %t563 = getelementptr i8, ptr %t562, i64 %t492
  %t564 = call i64 @__olang_fmt_i64(ptr %t563, i64 %t493)
  %t565 = getelementptr i8, ptr %t563, i64 %t494
  call void @olang_textcopy(ptr %t565, ptr %t496, i64 %t497)
  %t566 = getelementptr i8, ptr %t565, i64 %t497
  %t567 = call i64 @__olang_fmt_i64(ptr %t566, i64 %t499)
  %t568 = getelementptr i8, ptr %t566, i64 %t500
  call void @olang_textcopy(ptr %t568, ptr %t502, i64 %t503)
  %t569 = getelementptr i8, ptr %t568, i64 %t503
  %t570 = call i64 @__olang_fmt_i64(ptr %t569, i64 %t505)
  %t571 = getelementptr i8, ptr %t569, i64 %t506
  call void @olang_textcopy(ptr %t571, ptr %t508, i64 %t509)
  %t572 = getelementptr i8, ptr %t571, i64 %t509
  call void @olang_textcopy(ptr %t572, ptr %t512, i64 %t513)
  %t573 = getelementptr i8, ptr %t572, i64 %t513
  call void @olang_textcopy(ptr %t573, ptr %t515, i64 %t516)
  %t574 = getelementptr i8, ptr %t573, i64 %t516
  %t575 = call i64 @__olang_fmt_i64(ptr %t574, i64 %t518)
  %t576 = getelementptr i8, ptr %t574, i64 %t519
  call void @olang_textcopy(ptr %t576, ptr %t521, i64 %t522)
  %t577 = getelementptr i8, ptr %t576, i64 %t522
  %t578 = call i64 @__olang_fmt_i64(ptr %t577, i64 %t524)
  %t579 = getelementptr i8, ptr %t577, i64 %t525
  call void @olang_textcopy(ptr %t579, ptr %t527, i64 %t528)
  %t580 = getelementptr i8, ptr %t579, i64 %t528
  %t581 = call i64 @__olang_fmt_i64(ptr %t580, i64 %t530)
  %t582 = getelementptr i8, ptr %t580, i64 %t531
  call void @olang_textcopy(ptr %t582, ptr %t533, i64 %t534)
  %t583 = getelementptr i8, ptr %t582, i64 %t534
  %t584 = call i64 @__olang_fmt_i64(ptr %t583, i64 %t536)
  %t585 = getelementptr i8, ptr %t583, i64 %t537
  call void @olang_textcopy(ptr %t585, ptr %t539, i64 %t540)
  %t586 = getelementptr i8, ptr %t585, i64 %t540
  %t587 = call i64 @__olang_fmt_i64(ptr %t586, i64 %t542)
  %t588 = getelementptr i8, ptr %t586, i64 %t543
  call void @olang_textcopy(ptr %t588, ptr %t545, i64 %t546)
  %t589 = getelementptr i8, ptr %t588, i64 %t546
  call void @olang_textcopy(ptr %t589, ptr %t549, i64 %t550)
  %t590 = getelementptr i8, ptr %t589, i64 %t550
  call void @olang_textcopy(ptr %t590, ptr %t552, i64 %t553)
  %t591 = getelementptr i8, ptr %t590, i64 %t553
  call void @olang_textcopy(ptr %t591, ptr %t556, i64 %t557)
  %t592 = getelementptr i8, ptr %t591, i64 %t557
  call void @olang_textcopy(ptr %t592, ptr %t559, i64 %t560)
  %t593 = insertvalue { i64, ptr } undef, i64 %t561, 0
  %t594 = insertvalue { i64, ptr } %t593, ptr %t562, 1
  %t596 = extractvalue { i64, ptr } %t594, 0
  %t597 = extractvalue { i64, ptr } %t594, 1
  %t598 = mul i64 %t596, 1
  %t599 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t598)
  call void @llvm.memcpy.p0.p0.i64(ptr %t599, ptr %t597, i64 %t598, i1 false)
  %t600 = insertvalue { i64, ptr } undef, i64 %t596, 0
  %t601 = insertvalue { i64, ptr } %t600, ptr %t599, 1
  %t602 = load ptr, ptr %l278, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s24, ptr %t602, { i64, ptr } %t601)
  br label %bb113
bb113:
  call void @__olang_scope_close(ptr %s24)
  br label %bb114
bb114:
  %t604 = load i64, ptr %l41, !tbaa !24
  %t606 = add i64 %t604, 1
  store i64 %t606, ptr %l41, !tbaa !24
  br label %bb96
bb115:
  %t608 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t608, ptr %l301
  br label %bb116
bb116:
  %t609 = load %"std/prelude/text:StringBuilder", ptr %l301
  store %"std/prelude/text:StringBuilder" %t609, ptr %l51
  store ptr %l51, ptr %l302, !tbaa !29
  %t610 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t612 = call { i64, ptr } @compiler_2fprofile_2eescapeXml(ptr %v0, ptr %s0, { i64, ptr } %t610)
  store { i64, ptr } %t612, ptr %l304
  br label %bb117
bb117:
  %t613 = extractvalue { i64, ptr } { i64 57, ptr getelementptr inbounds (<{ i64, [57 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t614 = extractvalue { i64, ptr } { i64 57, ptr getelementptr inbounds (<{ i64, [57 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t615 = load { i64, ptr }, ptr %l304, !tbaa !27
  %t616 = extractvalue { i64, ptr } %t615, 1
  %t617 = extractvalue { i64, ptr } %t615, 0
  %t618 = add i64 %t614, %t617
  %t619 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t620 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t621 = add i64 %t618, %t620
  %t622 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t621)
  call void @olang_textcopy(ptr %t622, ptr %t613, i64 %t614)
  %t623 = getelementptr i8, ptr %t622, i64 %t614
  call void @olang_textcopy(ptr %t623, ptr %t616, i64 %t617)
  %t624 = getelementptr i8, ptr %t623, i64 %t617
  call void @olang_textcopy(ptr %t624, ptr %t619, i64 %t620)
  %t625 = insertvalue { i64, ptr } undef, i64 %t621, 0
  %t626 = insertvalue { i64, ptr } %t625, ptr %t622, 1
  %t628 = extractvalue { i64, ptr } %t626, 0
  %t629 = extractvalue { i64, ptr } %t626, 1
  %t630 = mul i64 %t628, 1
  %t631 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t630)
  call void @llvm.memcpy.p0.p0.i64(ptr %t631, ptr %t629, i64 %t630, i1 false)
  %t632 = insertvalue { i64, ptr } undef, i64 %t628, 0
  %t633 = insertvalue { i64, ptr } %t632, ptr %t631, 1
  %t634 = load ptr, ptr %l302, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t634, { i64, ptr } %t633)
  br label %bb118
bb118:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l51, { i64, ptr } { i64 213, ptr getelementptr inbounds (<{ i64, [213 x i8] }>, ptr @.d17, i32 0, i32 1) })
  br label %bb119
bb119:
  %t637 = load ptr, ptr %l1, !tbaa !29
  %t639 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aProfile_2eTotal(ptr %v1, ptr %t637)
  store i64 %t639, ptr %l309
  br label %bb120
bb120:
  %t640 = load i64, ptr %l309, !tbaa !24
  %t641 = sitofp i64 %t640 to double
  %t642 = load ptr, ptr %l1, !tbaa !29
  %t644 = getelementptr %"compiler/profile:Profile", ptr %t642, i32 0, i32 0
  %t645 = load i64, ptr %t644, !tbaa !24
  %t647 = sitofp i64 %t645 to double
  %t650 = fmul double %t641, %t647
  %t652 = fdiv double %t650, 0x41cdcd6500000000
  store double %t652, ptr %l52, !tbaa !26
  store ptr %l51, ptr %l316, !tbaa !29
  %t654 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t656 = call { i64, ptr } @compiler_2fprofile_2eescapeXml(ptr %v0, ptr %s0, { i64, ptr } %t654)
  store { i64, ptr } %t656, ptr %l318
  br label %bb121
bb121:
  %t657 = load ptr, ptr %l1, !tbaa !29
  %t659 = getelementptr %"compiler/profile:Profile", ptr %t657, i32 0, i32 3
  %t661 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2eLen_3ccompiler_2fprofile_3aSample_3e(ptr %v1, ptr %t659)
  store i64 %t661, ptr %l321
  br label %bb122
bb122:
  %t662 = load double, ptr %l52, !tbaa !26
  %t664 = call { i64, ptr } @std_2fprelude_2ffloat_2eF64_2eFixed(ptr %s0, double %t662, i64 3)
  store { i64, ptr } %t664, ptr %l323
  br label %bb123
bb123:
  %t665 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t666 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t667 = load { i64, ptr }, ptr %l318, !tbaa !27
  %t668 = extractvalue { i64, ptr } %t667, 1
  %t669 = extractvalue { i64, ptr } %t667, 0
  %t670 = add i64 %t666, %t669
  %t671 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t672 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t673 = add i64 %t670, %t672
  %t674 = load i64, ptr %l321, !tbaa !24
  %t675 = call i64 @__olang_fmt_i64(ptr null, i64 %t674)
  %t676 = add i64 %t673, %t675
  %t677 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t678 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t679 = add i64 %t676, %t678
  %t680 = load { i64, ptr }, ptr %l323, !tbaa !27
  %t681 = extractvalue { i64, ptr } %t680, 1
  %t682 = extractvalue { i64, ptr } %t680, 0
  %t683 = add i64 %t679, %t682
  %t684 = extractvalue { i64, ptr } { i64 78, ptr getelementptr inbounds (<{ i64, [78 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t685 = extractvalue { i64, ptr } { i64 78, ptr getelementptr inbounds (<{ i64, [78 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t686 = add i64 %t683, %t685
  %t687 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t686)
  call void @olang_textcopy(ptr %t687, ptr %t665, i64 %t666)
  %t688 = getelementptr i8, ptr %t687, i64 %t666
  call void @olang_textcopy(ptr %t688, ptr %t668, i64 %t669)
  %t689 = getelementptr i8, ptr %t688, i64 %t669
  call void @olang_textcopy(ptr %t689, ptr %t671, i64 %t672)
  %t690 = getelementptr i8, ptr %t689, i64 %t672
  %t691 = call i64 @__olang_fmt_i64(ptr %t690, i64 %t674)
  %t692 = getelementptr i8, ptr %t690, i64 %t675
  call void @olang_textcopy(ptr %t692, ptr %t677, i64 %t678)
  %t693 = getelementptr i8, ptr %t692, i64 %t678
  call void @olang_textcopy(ptr %t693, ptr %t681, i64 %t682)
  %t694 = getelementptr i8, ptr %t693, i64 %t682
  call void @olang_textcopy(ptr %t694, ptr %t684, i64 %t685)
  %t695 = insertvalue { i64, ptr } undef, i64 %t686, 0
  %t696 = insertvalue { i64, ptr } %t695, ptr %t687, 1
  %t698 = extractvalue { i64, ptr } %t696, 0
  %t699 = extractvalue { i64, ptr } %t696, 1
  %t700 = mul i64 %t698, 1
  %t701 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t700)
  call void @llvm.memcpy.p0.p0.i64(ptr %t701, ptr %t699, i64 %t700, i1 false)
  %t702 = insertvalue { i64, ptr } undef, i64 %t698, 0
  %t703 = insertvalue { i64, ptr } %t702, ptr %t701, 1
  %t704 = load ptr, ptr %l316, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t704, { i64, ptr } %t703)
  br label %bb124
bb124:
  store ptr %l51, ptr %l326, !tbaa !29
  %t706 = load i64, ptr @G_2ecompiler_2fprofile_2eFlameWidth, !tbaa !24
  store i64 %t706, ptr %l327, !tbaa !24
  %t707 = load i64, ptr %l26, !tbaa !24
  store i64 %t707, ptr %l328, !tbaa !24
  %t708 = load i64, ptr %l25, !tbaa !24
  store i64 %t708, ptr %l329, !tbaa !24
  %t710 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l27)
  store { i64, ptr } %t710, ptr %l331
  br label %bb125
bb125:
  %t711 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t712 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t713 = load i64, ptr %l327, !tbaa !24
  %t714 = call i64 @__olang_fmt_i64(ptr null, i64 %t713)
  %t715 = add i64 %t712, %t714
  %t716 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t717 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t718 = add i64 %t715, %t717
  %t719 = load i64, ptr %l328, !tbaa !24
  %t720 = call i64 @__olang_fmt_i64(ptr null, i64 %t719)
  %t721 = add i64 %t718, %t720
  %t722 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t723 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t724 = add i64 %t721, %t723
  %t725 = load i64, ptr %l329, !tbaa !24
  %t726 = call i64 @__olang_fmt_i64(ptr null, i64 %t725)
  %t727 = add i64 %t724, %t726
  %t728 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t729 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t730 = add i64 %t727, %t729
  %t731 = load { i64, ptr }, ptr %l331, !tbaa !27
  %t732 = extractvalue { i64, ptr } %t731, 1
  %t733 = extractvalue { i64, ptr } %t731, 0
  %t734 = add i64 %t730, %t733
  %t735 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t736 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t737 = add i64 %t734, %t736
  %t738 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t737)
  call void @olang_textcopy(ptr %t738, ptr %t711, i64 %t712)
  %t739 = getelementptr i8, ptr %t738, i64 %t712
  %t740 = call i64 @__olang_fmt_i64(ptr %t739, i64 %t713)
  %t741 = getelementptr i8, ptr %t739, i64 %t714
  call void @olang_textcopy(ptr %t741, ptr %t716, i64 %t717)
  %t742 = getelementptr i8, ptr %t741, i64 %t717
  %t743 = call i64 @__olang_fmt_i64(ptr %t742, i64 %t719)
  %t744 = getelementptr i8, ptr %t742, i64 %t720
  call void @olang_textcopy(ptr %t744, ptr %t722, i64 %t723)
  %t745 = getelementptr i8, ptr %t744, i64 %t723
  %t746 = call i64 @__olang_fmt_i64(ptr %t745, i64 %t725)
  %t747 = getelementptr i8, ptr %t745, i64 %t726
  call void @olang_textcopy(ptr %t747, ptr %t728, i64 %t729)
  %t748 = getelementptr i8, ptr %t747, i64 %t729
  call void @olang_textcopy(ptr %t748, ptr %t732, i64 %t733)
  %t749 = getelementptr i8, ptr %t748, i64 %t733
  call void @olang_textcopy(ptr %t749, ptr %t735, i64 %t736)
  %t750 = insertvalue { i64, ptr } undef, i64 %t737, 0
  %t751 = insertvalue { i64, ptr } %t750, ptr %t738, 1
  %t753 = extractvalue { i64, ptr } %t751, 0
  %t754 = extractvalue { i64, ptr } %t751, 1
  %t755 = mul i64 %t753, 1
  %t756 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t755)
  call void @llvm.memcpy.p0.p0.i64(ptr %t756, ptr %t754, i64 %t755, i1 false)
  %t757 = insertvalue { i64, ptr } undef, i64 %t753, 0
  %t758 = insertvalue { i64, ptr } %t757, ptr %t756, 1
  %t759 = load ptr, ptr %l326, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t759, { i64, ptr } %t758)
  br label %bb126
bb126:
  %t761 = load { i64, ptr }, ptr @G_2ecompiler_2fprofile_2eFlameScript, !tbaa !27
  %t762 = load ptr, ptr @__olang_prog_scope
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %t762, ptr %l51, { i64, ptr } %t761)
  br label %bb127
bb127:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l51, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d27, i32 0, i32 1) })
  br label %bb128
bb128:
  %t767 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v3, ptr %l51)
  store { i64, ptr } %t767, ptr %l338
  br label %bb129
bb129:
  %t768 = load { i64, ptr }, ptr %l338, !tbaa !27
  store { i64, ptr } %t768, ptr %l339, !tbaa !27
  %t769 = load { i64, ptr }, ptr %l339, !tbaa !27
  %t770 = extractvalue { i64, ptr } %t769, 0
  store i64 %t770, ptr %l340, !tbaa !24
  %t771 = load i64, ptr %l340, !tbaa !24
  %t772 = mul i64 %t771, 1
  %t773 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t772)
  %t774 = insertvalue { i64, ptr } undef, i64 %t771, 0
  %t775 = insertvalue { i64, ptr } %t774, ptr %t773, 1
  store { i64, ptr } %t775, ptr %l341, !tbaa !27
  %t776 = getelementptr { i64, ptr }, ptr %l341, i32 0, i32 1
  %t777 = load ptr, ptr %t776, !tbaa !27
  %t778 = getelementptr { i64, ptr }, ptr %l339, i32 0, i32 1
  %t779 = load ptr, ptr %t778, !tbaa !27
  %t780 = load i64, ptr %l340, !tbaa !24
  %t781 = mul i64 %t780, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t777, ptr %t779, i64 %t781, i1 false)
  %t782 = load { i64, ptr }, ptr %l341, !tbaa !27
  store { i64, ptr } %t782, ptr %l339, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t783 = load { i64, ptr }, ptr %l339, !tbaa !27
  store { i64, ptr } %t783, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fprofile_2eFlameScript_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 1031, ptr getelementptr inbounds (<{ i64, [1031 x i8] }>, ptr @.d28, i32 0, i32 1) }, ptr @G_2ecompiler_2fprofile_2eFlameScript, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fprofile_2eFlameWidth_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 1200, ptr @G_2ecompiler_2fprofile_2eFlameWidth, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fprofile_2eFrameHeight_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 18, ptr @G_2ecompiler_2fprofile_2eFrameHeight, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i32, %"compiler/profile:Profile" } @compiler_2fprofile_2eRead(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %lp1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca %"compiler/profile:Profile"
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l24 = alloca i1
  %l28 = alloca i64
  %l30 = alloca i64
  %l32 = alloca i64
  %l34 = alloca i64
  %l37 = alloca i1
  %l52 = alloca i64
  %l57 = alloca i1
  %l60 = alloca i1
  %l67 = alloca ptr
  %l69 = alloca i64
  %l71 = alloca i64
  %l73 = alloca %"compiler/profile:Sample"
  %l78 = alloca i64
  %l81 = alloca i64
  %l99 = alloca ptr
  %l106 = alloca i64
  %l113 = alloca { i64, ptr }
  %l116 = alloca i64
  %l119 = alloca i64
  %l120 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/profile:Profile" }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/profile:Profile" @compiler_2fprofile_3aProfile_2ector(ptr %v1)
  store %"compiler/profile:Profile" %t1, ptr %l12
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 56, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"compiler/profile:Profile", ptr %l12
  %t4 = load ptr, ptr %lp1
  store %"compiler/profile:Profile" %t3, ptr %t4
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t9 = icmp slt i64 %t7, 40
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb11
bb3:
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t11, ptr %l17, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  store i64 %t13, ptr %l18, !tbaa !24
  %t14 = icmp sge i64 0, 0
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t16 = icmp sle i64 0, 8
  br i1 %t16, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_c23c40ac9fceed99_19c8ab4fbd7fcba5)
  unreachable
bb6:
  %t18 = load i64, ptr %l18, !tbaa !24
  %t19 = icmp sle i64 8, %t18
  br i1 %t19, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_c23c40ac9fceed99_19c8ab4fbd7fcba5)
  unreachable
bb8:
  %t21 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr i8, ptr %t22, i64 0
  %t25 = insertvalue { i64, ptr } undef, i64 8, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t23, 1
  %t28 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t26, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store i1 %t28, ptr %l24
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_c23c40ac9fceed99_19c8ab4fbd7fcba5)
  unreachable
bb10:
  %t29 = load i1, ptr %l24, !tbaa !21
  %t30 = xor i1 %t29, true
  store i1 %t30, ptr %l16, !tbaa !21
  br label %bb11
bb11:
  %t32 = load i1, ptr %l16, !tbaa !21
  br i1 %t32, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s0)
  %t34 = insertvalue { i32, %"compiler/profile:Profile" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/profile:Profile" } %t34, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t35 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t37 = call i64 @compiler_2fprofile_2eword(ptr %v0, { i64, ptr } %t35, i64 1)
  store i64 %t37, ptr %l28
  br label %bb15
bb15:
  %t38 = load i64, ptr %l28, !tbaa !24
  %t39 = load ptr, ptr %lp1
  %t40 = getelementptr %"compiler/profile:Profile", ptr %t39, i32 0, i32 0
  store i64 %t38, ptr %t40, !tbaa !24
  %t41 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t43 = call i64 @compiler_2fprofile_2eword(ptr %v0, { i64, ptr } %t41, i64 2)
  store i64 %t43, ptr %l30
  br label %bb16
bb16:
  %t44 = load i64, ptr %l30, !tbaa !24
  store i64 %t44, ptr %l2, !tbaa !24
  %t45 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t47 = call i64 @compiler_2fprofile_2eword(ptr %v0, { i64, ptr } %t45, i64 3)
  store i64 %t47, ptr %l32
  br label %bb17
bb17:
  %t48 = load i64, ptr %l32, !tbaa !24
  %t49 = load ptr, ptr %lp1
  %t50 = getelementptr %"compiler/profile:Profile", ptr %t49, i32 0, i32 1
  store i64 %t48, ptr %t50, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t53 = call i64 @compiler_2fprofile_2eword(ptr %v0, { i64, ptr } %t51, i64 4)
  store i64 %t53, ptr %l34
  br label %bb18
bb18:
  %t54 = load i64, ptr %l34, !tbaa !24
  %t55 = load ptr, ptr %lp1
  %t56 = getelementptr %"compiler/profile:Profile", ptr %t55, i32 0, i32 2
  store i64 %t54, ptr %t56, !tbaa !24
  %t57 = load i64, ptr %l2, !tbaa !24
  %t59 = icmp slt i64 %t57, 0
  br i1 %t59, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb21
bb20:
  %t61 = load i64, ptr %l2, !tbaa !24
  %t63 = mul i64 %t61, 8
  %t65 = add i64 40, %t63
  %t66 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t66, 0
  %t71 = icmp sgt i64 %t65, %t68
  store i1 %t71, ptr %l37, !tbaa !21
  br label %bb21
bb21:
  %t73 = load i1, ptr %l37, !tbaa !21
  br i1 %t73, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t75 = insertvalue { i32, %"compiler/profile:Profile" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/profile:Profile" } %t75, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  store i64 0, ptr %l3, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s3
  %t76 = load i64, ptr %l3, !tbaa !24
  %t77 = load i64, ptr %l2, !tbaa !24
  %t80 = icmp slt i64 %t76, %t77
  %t82 = xor i1 %t80, true
  br i1 %t82, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s3)
  br label %bb57
bb27:
  br label %bb28
bb28:
  %t84 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t85 = load i64, ptr %l3, !tbaa !24
  %t87 = add i64 5, %t85
  %t90 = call i64 @compiler_2fprofile_2eword(ptr %v0, { i64, ptr } %t84, i64 %t87)
  store i64 %t90, ptr %l52
  br label %bb29
bb29:
  %t91 = load i64, ptr %l52, !tbaa !24
  store i64 %t91, ptr %l4, !tbaa !24
  %t92 = load i64, ptr %l4, !tbaa !24
  %t94 = and i64 %t92, 255
  store i64 %t94, ptr %l5, !tbaa !24
  %t96 = load i64, ptr %l4, !tbaa !24
  %t98 = icmp eq i64 %t96, 0
  br i1 %t98, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb32
bb31:
  %t100 = load i64, ptr %l5, !tbaa !24
  %t102 = icmp eq i64 %t100, 0
  store i1 %t102, ptr %l57, !tbaa !21
  br label %bb32
bb32:
  %t104 = load i1, ptr %l57, !tbaa !21
  br i1 %t104, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb35
bb34:
  %t105 = load i64, ptr %l3, !tbaa !24
  %t107 = add i64 %t105, 1
  %t108 = load i64, ptr %l5, !tbaa !24
  %t111 = add i64 %t107, %t108
  %t112 = load i64, ptr %l2, !tbaa !24
  %t115 = icmp sgt i64 %t111, %t112
  store i1 %t115, ptr %l60, !tbaa !21
  br label %bb35
bb35:
  %t117 = load i1, ptr %l60, !tbaa !21
  br i1 %t117, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s3)
  br label %bb57
bb37:
  br label %bb38
bb38:
  %t118 = load ptr, ptr %lp1
  %t119 = getelementptr %"compiler/profile:Profile", ptr %t118, i32 0, i32 3
  store ptr %t119, ptr %l67, !tbaa !29
  %t120 = load i64, ptr %l4, !tbaa !24
  %t122 = ashr i64 %t120, 8
  store i64 %t122, ptr %l69, !tbaa !24
  %t123 = load ptr, ptr %lp1
  %t124 = getelementptr %"compiler/profile:Profile", ptr %t123, i32 0, i32 4
  %t126 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t124)
  store i64 %t126, ptr %l71
  br label %bb39
bb39:
  %t127 = load i64, ptr %l5, !tbaa !24
  %t128 = load i64, ptr %l69, !tbaa !24
  %t129 = load i64, ptr %l71, !tbaa !24
  %t131 = call %"compiler/profile:Sample" @compiler_2fprofile_3aSample_2ector(ptr %s3, i64 %t128, i64 %t129, i64 %t127)
  store %"compiler/profile:Sample" %t131, ptr %l73
  br label %bb40
bb40:
  %t132 = load ptr, ptr %l67, !tbaa !29
  %t133 = load %"compiler/profile:Sample", ptr %l73
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2ePush_3ccompiler_2fprofile_3aSample_3e(ptr %v1, ptr %t132, %"compiler/profile:Sample" %t133)
  br label %bb41
bb41:
  store i64 0, ptr %l6, !tbaa !24
  %t134 = load i64, ptr %l5, !tbaa !24
  store i64 %t134, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t136 = load i64, ptr %l7, !tbaa !24
  %t137 = load i64, ptr %l6, !tbaa !24
  %t140 = icmp sgt i64 %t136, %t137
  br i1 %t140, label %bb42, label %bb43
bb42:
  %t142 = load i64, ptr %l8, !tbaa !24
  %t144 = icmp sgt i64 %t142, 0
  br i1 %t144, label %bb44, label %bb45
bb43:
  store i64 0, ptr %l78, !tbaa !24
  br label %bb47
bb44:
  %t146 = load i64, ptr %l7, !tbaa !24
  %t147 = load i64, ptr %l6, !tbaa !24
  %t150 = sub i64 %t146, %t147
  %t151 = load i64, ptr %l8, !tbaa !24
  %t154 = add i64 %t150, %t151
  %t156 = sub i64 %t154, 1
  %t157 = load i64, ptr %l8, !tbaa !24
  %t160 = sdiv i64 %t156, %t157
  store i64 %t160, ptr %l81, !tbaa !24
  br label %bb46
bb45:
  store i64 0, ptr %l81, !tbaa !24
  br label %bb46
bb46:
  %t162 = load i64, ptr %l81, !tbaa !24
  store i64 %t162, ptr %l78, !tbaa !24
  br label %bb47
bb47:
  %t163 = load i64, ptr %l78, !tbaa !24
  store i64 %t163, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb48
bb48:
  %t164 = load i64, ptr %l10, !tbaa !24
  %t165 = load i64, ptr %l9, !tbaa !24
  %t168 = icmp slt i64 %t164, %t165
  %t170 = xor i1 %t168, true
  br i1 %t170, label %bb49, label %bb50
bb49:
  br label %bb55
bb50:
  br label %bb51
bb51:
  %t172 = load i64, ptr %l6, !tbaa !24
  %t173 = load i64, ptr %l10, !tbaa !24
  %t174 = load i64, ptr %l8, !tbaa !24
  %t177 = mul i64 %t173, %t174
  %t180 = add i64 %t172, %t177
  %t182 = load ptr, ptr %lp1
  %t183 = getelementptr %"compiler/profile:Profile", ptr %t182, i32 0, i32 4
  store ptr %t183, ptr %l99, !tbaa !29
  %t184 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t185 = load i64, ptr %l3, !tbaa !24
  %t187 = add i64 5, %t185
  %t189 = add i64 %t187, 1
  %t193 = add i64 %t189, %t180
  %t196 = call i64 @compiler_2fprofile_2eword(ptr %v0, { i64, ptr } %t184, i64 %t193)
  store i64 %t196, ptr %l106
  br label %bb52
bb52:
  %t197 = load ptr, ptr %l99, !tbaa !29
  %t198 = load i64, ptr %l106, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t197, i64 %t198)
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t199 = load i64, ptr %l10, !tbaa !24
  %t201 = add i64 %t199, 1
  store i64 %t201, ptr %l10, !tbaa !24
  br label %bb48
bb55:
  %t203 = load i64, ptr %l3, !tbaa !24
  %t204 = load i64, ptr %l5, !tbaa !24
  %t206 = add i64 %t204, 1
  %t209 = add i64 %t203, %t206
  store i64 %t209, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb56
bb56:
  br label %bb25
bb57:
  %t211 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t211, ptr %l113, !tbaa !27
  %t212 = load i64, ptr %l2, !tbaa !24
  %t214 = mul i64 %t212, 8
  %t216 = add i64 40, %t214
  store i64 %t216, ptr %l116, !tbaa !24
  %t217 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t220 = extractvalue { i64, ptr } %t217, 0
  store i64 %t220, ptr %l119, !tbaa !24
  %t221 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t222 = extractvalue { i64, ptr } %t221, 0
  store i64 %t222, ptr %l120, !tbaa !24
  %t223 = load i64, ptr %l116, !tbaa !24
  %t224 = icmp sge i64 %t223, 0
  br i1 %t224, label %bb58, label %bb59
bb58:
  %t226 = load i64, ptr %l116, !tbaa !24
  %t227 = load i64, ptr %l119, !tbaa !24
  %t228 = icmp sle i64 %t226, %t227
  br i1 %t228, label %bb60, label %bb61
bb59:
  call void @__olang_check_failed(ptr @olang_loc_ebd4d37101874eec_6116e20ed9489b48)
  unreachable
bb60:
  %t230 = load i64, ptr %l119, !tbaa !24
  %t231 = load i64, ptr %l120, !tbaa !24
  %t232 = icmp sle i64 %t230, %t231
  br i1 %t232, label %bb62, label %bb63
bb61:
  call void @__olang_check_failed(ptr @olang_loc_ebd4d37101874eec_6116e20ed9489b48)
  unreachable
bb62:
  %t234 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = load i64, ptr %l116, !tbaa !24
  %t237 = load i64, ptr %l119, !tbaa !24
  %t238 = getelementptr i8, ptr %t235, i64 %t236
  %t239 = sub i64 %t237, %t236
  %t240 = insertvalue { i64, ptr } undef, i64 %t239, 0
  %t241 = insertvalue { i64, ptr } %t240, ptr %t238, 1
  %t244 = load ptr, ptr %lp1
  %t245 = getelementptr %"compiler/profile:Profile", ptr %t244, i32 0, i32 5
  store { i64, ptr } %t241, ptr %t245, !tbaa !27
  %t246 = load ptr, ptr %lp1
  %t247 = load %"compiler/profile:Profile", ptr %t246
  call void @__olang_scope_close(ptr %s0)
  %t249 = insertvalue { i32, %"compiler/profile:Profile" } zeroinitializer, %"compiler/profile:Profile" %t247, 1
  store { i32, %"compiler/profile:Profile" } %t249, ptr %rv
  br label %ret
bb63:
  call void @__olang_check_failed(ptr @olang_loc_ebd4d37101874eec_6116e20ed9489b48)
  unreachable
ret:
  %rr = load { i32, %"compiler/profile:Profile" }, ptr %rv
  ret { i32, %"compiler/profile:Profile" } %rr
}

define dso_local { i64, ptr } @compiler_2fprofile_2eReadable(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %lp1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l27 = alloca i1
  %l28 = alloca i1
  %l29 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l37 = alloca i1
  %l39 = alloca i64
  %l40 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l48 = alloca i1
  %l49 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i32
  %l64 = alloca { i64, ptr }
  %l65 = alloca i64
  %l66 = alloca { i64, ptr }
  %l71 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i64
  %l79 = alloca i64
  %l80 = alloca i64
  %l86 = alloca { i64, ptr }
  %l87 = alloca i64
  %l89 = alloca i64
  %l90 = alloca i32
  %l91 = alloca i64
  %l93 = alloca i64
  %l94 = alloca i32
  %l99 = alloca i1
  %l103 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l106 = alloca i64
  %l108 = alloca i64
  %l109 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d30, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t5 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } %t4)
  store i1 %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load i1, ptr %l13, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 1
  %t12 = extractvalue { i64, ptr } %t9, 0
  %t13 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t11, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t15, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = call { i64, ptr } @compiler_2ftypes_2eDemangle(ptr %v0, ptr %v1, { i64, ptr } %t17)
  store { i64, ptr } %t19, ptr %l18
  br label %bb5
bb5:
  %t20 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t20, ptr %lp1
  %t21 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t22 = load ptr, ptr %lp1
  store { i64, ptr } %t21, ptr %t22, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t23 = load i64, ptr %l2, !tbaa !24
  store i64 %t23, ptr %l19, !tbaa !24
  %t24 = load ptr, ptr %lp1
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  store i64 %t27, ptr %l21, !tbaa !24
  %t28 = load ptr, ptr %lp1
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 0
  store i64 %t30, ptr %l22, !tbaa !24
  %t31 = load i64, ptr %l19, !tbaa !24
  %t32 = icmp sge i64 %t31, 0
  br i1 %t32, label %bb7, label %bb8
bb7:
  %t34 = load i64, ptr %l19, !tbaa !24
  %t35 = load i64, ptr %l21, !tbaa !24
  %t36 = icmp sle i64 %t34, %t35
  br i1 %t36, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_3603727fe313055_49dd245dfeecf61)
  unreachable
bb9:
  %t38 = load i64, ptr %l21, !tbaa !24
  %t39 = load i64, ptr %l22, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_3603727fe313055_49dd245dfeecf61)
  unreachable
bb11:
  %t42 = load ptr, ptr %lp1
  %t43 = getelementptr { i64, ptr }, ptr %t42, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = load i64, ptr %l19, !tbaa !24
  %t46 = load i64, ptr %l21, !tbaa !24
  %t47 = getelementptr i8, ptr %t44, i64 %t45
  %t48 = sub i64 %t46, %t45
  %t49 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t47, 1
  %t52 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s3, { i64, ptr } %t50, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store i1 %t52, ptr %l27
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_3603727fe313055_49dd245dfeecf61)
  unreachable
bb13:
  %t53 = load i1, ptr %l27, !tbaa !21
  br i1 %t53, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb23
bb15:
  %t54 = load i64, ptr %l2, !tbaa !24
  store i64 %t54, ptr %l29, !tbaa !24
  %t55 = load ptr, ptr %lp1
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t56, 0
  store i64 %t58, ptr %l31, !tbaa !24
  %t59 = load ptr, ptr %lp1
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t60, 0
  store i64 %t61, ptr %l32, !tbaa !24
  %t62 = load i64, ptr %l29, !tbaa !24
  %t63 = icmp sge i64 %t62, 0
  br i1 %t63, label %bb16, label %bb17
bb16:
  %t65 = load i64, ptr %l29, !tbaa !24
  %t66 = load i64, ptr %l31, !tbaa !24
  %t67 = icmp sle i64 %t65, %t66
  br i1 %t67, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_3603727fe313055_49dd245dfeecf61)
  unreachable
bb18:
  %t69 = load i64, ptr %l31, !tbaa !24
  %t70 = load i64, ptr %l32, !tbaa !24
  %t71 = icmp sle i64 %t69, %t70
  br i1 %t71, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_3603727fe313055_49dd245dfeecf61)
  unreachable
bb20:
  %t73 = load ptr, ptr %lp1
  %t74 = getelementptr { i64, ptr }, ptr %t73, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = load i64, ptr %l29, !tbaa !24
  %t77 = load i64, ptr %l31, !tbaa !24
  %t78 = getelementptr i8, ptr %t75, i64 %t76
  %t79 = sub i64 %t77, %t76
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  %t83 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s3, { i64, ptr } %t81, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d32, i32 0, i32 1) })
  store i1 %t83, ptr %l37
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_3603727fe313055_49dd245dfeecf61)
  unreachable
bb22:
  %t84 = load i1, ptr %l37, !tbaa !21
  store i1 %t84, ptr %l28, !tbaa !21
  br label %bb23
bb23:
  %t85 = load i1, ptr %l28, !tbaa !21
  %t86 = xor i1 %t85, true
  br i1 %t86, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s3)
  br label %bb38
bb25:
  br label %bb26
bb26:
  %t88 = load i64, ptr %l2, !tbaa !24
  store i64 %t88, ptr %l39, !tbaa !24
  %t89 = load i64, ptr %l2, !tbaa !24
  store i64 %t89, ptr %l40, !tbaa !24
  %t90 = load ptr, ptr %lp1
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t91, 0
  store i64 %t93, ptr %l42, !tbaa !24
  %t94 = load ptr, ptr %lp1
  %t95 = load { i64, ptr }, ptr %t94, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t95, 0
  store i64 %t96, ptr %l43, !tbaa !24
  %t97 = load i64, ptr %l40, !tbaa !24
  %t98 = icmp sge i64 %t97, 0
  br i1 %t98, label %bb27, label %bb28
bb27:
  %t100 = load i64, ptr %l40, !tbaa !24
  %t101 = load i64, ptr %l42, !tbaa !24
  %t102 = icmp sle i64 %t100, %t101
  br i1 %t102, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_3603727fe313055_49dd245dfeecf61)
  unreachable
bb29:
  %t104 = load i64, ptr %l42, !tbaa !24
  %t105 = load i64, ptr %l43, !tbaa !24
  %t106 = icmp sle i64 %t104, %t105
  br i1 %t106, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_3603727fe313055_49dd245dfeecf61)
  unreachable
bb31:
  %t108 = load ptr, ptr %lp1
  %t109 = getelementptr { i64, ptr }, ptr %t108, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = load i64, ptr %l40, !tbaa !24
  %t112 = load i64, ptr %l42, !tbaa !24
  %t113 = getelementptr i8, ptr %t110, i64 %t111
  %t114 = sub i64 %t112, %t111
  %t115 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t113, 1
  %t118 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s3, { i64, ptr } %t116, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i1 %t118, ptr %l48
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_3603727fe313055_49dd245dfeecf61)
  unreachable
bb33:
  %t119 = load i1, ptr %l48, !tbaa !21
  br i1 %t119, label %bb34, label %bb35
bb34:
  store i64 2, ptr %l49, !tbaa !24
  br label %bb36
bb35:
  store i64 3, ptr %l49, !tbaa !24
  br label %bb36
bb36:
  %t120 = load i64, ptr %l39, !tbaa !24
  %t121 = load i64, ptr %l49, !tbaa !24
  %t122 = add i64 %t120, %t121
  store i64 %t122, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb37
bb37:
  br label %bb6
bb38:
  %t124 = load i64, ptr %l2, !tbaa !24
  store i64 %t124, ptr %l52, !tbaa !24
  %t125 = load ptr, ptr %lp1
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t126, 0
  store i64 %t128, ptr %l54, !tbaa !24
  %t129 = load ptr, ptr %lp1
  %t130 = load { i64, ptr }, ptr %t129, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 0
  store i64 %t131, ptr %l55, !tbaa !24
  %t132 = load i64, ptr %l52, !tbaa !24
  %t133 = icmp sge i64 %t132, 0
  br i1 %t133, label %bb39, label %bb40
bb39:
  %t135 = load i64, ptr %l52, !tbaa !24
  %t136 = load i64, ptr %l54, !tbaa !24
  %t137 = icmp sle i64 %t135, %t136
  br i1 %t137, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_e16765c4a8f41078_55e216e6a7163174)
  unreachable
bb41:
  %t139 = load i64, ptr %l54, !tbaa !24
  %t140 = load i64, ptr %l55, !tbaa !24
  %t141 = icmp sle i64 %t139, %t140
  br i1 %t141, label %bb43, label %bb44
bb42:
  call void @__olang_check_failed(ptr @olang_loc_e16765c4a8f41078_55e216e6a7163174)
  unreachable
bb43:
  %t143 = load ptr, ptr %lp1
  %t144 = getelementptr { i64, ptr }, ptr %t143, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = load i64, ptr %l52, !tbaa !24
  %t147 = load i64, ptr %l54, !tbaa !24
  %t148 = getelementptr i8, ptr %t145, i64 %t146
  %t149 = sub i64 %t147, %t146
  %t150 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t148, 1
  %t153 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s0, { i64, ptr } %t151, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) })
  %t154 = extractvalue { i32, i64 } %t153, 1
  %t155 = extractvalue { i32, i64 } %t153, 0
  store i32 %t155, ptr %l61
  %t156 = icmp ne i32 %t155, 0
  br i1 %t156, label %bb46, label %ok.157, !prof !99
ok.157:
  store i64 %t154, ptr %l60
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_e16765c4a8f41078_55e216e6a7163174)
  unreachable
bb45:
  %t158 = load i64, ptr %l60, !tbaa !24
  store i64 %t158, ptr %l51, !tbaa !24
  br label %bb48
bb46:
  br label %bb47
bb47:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l51, !tbaa !24
  br label %bb48
bb48:
  %t159 = load i64, ptr %l51, !tbaa !24
  store i64 %t159, ptr %l3, !tbaa !24
  %t160 = load i64, ptr %l3, !tbaa !24
  %t162 = icmp slt i64 %t160, 0
  br i1 %t162, label %bb49, label %bb50
bb49:
  %t164 = load ptr, ptr %lp1
  %t165 = load { i64, ptr }, ptr %t164, !tbaa !27
  store { i64, ptr } %t165, ptr %l64, !tbaa !27
  %t166 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t167 = extractvalue { i64, ptr } %t166, 0
  store i64 %t167, ptr %l65, !tbaa !24
  %t168 = load i64, ptr %l65, !tbaa !24
  %t169 = mul i64 %t168, 1
  %t170 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t169)
  %t171 = insertvalue { i64, ptr } undef, i64 %t168, 0
  %t172 = insertvalue { i64, ptr } %t171, ptr %t170, 1
  store { i64, ptr } %t172, ptr %l66, !tbaa !27
  %t173 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !27
  %t175 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !27
  %t177 = load i64, ptr %l65, !tbaa !24
  %t178 = mul i64 %t177, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t174, ptr %t176, i64 %t178, i1 false)
  %t179 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t179, ptr %l64, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t180 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t180, ptr %rv
  br label %ret
bb50:
  br label %bb51
bb51:
  %t181 = load i64, ptr %l2, !tbaa !24
  %t182 = load i64, ptr %l3, !tbaa !24
  %t185 = add i64 %t181, %t182
  store i64 %t185, ptr %l4, !tbaa !24
  %t187 = load i64, ptr %l4, !tbaa !24
  %t189 = add i64 %t187, 1
  store i64 %t189, ptr %l71, !tbaa !24
  %t190 = load ptr, ptr %lp1
  %t191 = load { i64, ptr }, ptr %t190, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t191, 0
  store i64 %t193, ptr %l73, !tbaa !24
  %t194 = load ptr, ptr %lp1
  %t195 = load { i64, ptr }, ptr %t194, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t195, 0
  store i64 %t196, ptr %l74, !tbaa !24
  %t197 = load i64, ptr %l71, !tbaa !24
  %t198 = icmp sge i64 %t197, 0
  br i1 %t198, label %bb52, label %bb53
bb52:
  %t200 = load i64, ptr %l71, !tbaa !24
  %t201 = load i64, ptr %l73, !tbaa !24
  %t202 = icmp sle i64 %t200, %t201
  br i1 %t202, label %bb54, label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_a05021294fe2b6d3_c60223eeaa2ef05f)
  unreachable
bb54:
  %t204 = load i64, ptr %l73, !tbaa !24
  %t205 = load i64, ptr %l74, !tbaa !24
  %t206 = icmp sle i64 %t204, %t205
  br i1 %t206, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_a05021294fe2b6d3_c60223eeaa2ef05f)
  unreachable
bb56:
  %t208 = load ptr, ptr %lp1
  %t209 = getelementptr { i64, ptr }, ptr %t208, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !27
  %t211 = load i64, ptr %l71, !tbaa !24
  %t212 = load i64, ptr %l73, !tbaa !24
  %t213 = getelementptr i8, ptr %t210, i64 %t211
  %t214 = sub i64 %t212, %t211
  %t215 = insertvalue { i64, ptr } undef, i64 %t214, 0
  %t216 = insertvalue { i64, ptr } %t215, ptr %t213, 1
  store { i64, ptr } %t216, ptr %l5, !tbaa !27
  %t218 = load i64, ptr %l4, !tbaa !24
  store i64 %t218, ptr %l79, !tbaa !24
  %t219 = load ptr, ptr %lp1
  %t220 = load { i64, ptr }, ptr %t219, !tbaa !27
  %t221 = extractvalue { i64, ptr } %t220, 0
  store i64 %t221, ptr %l80, !tbaa !24
  %t222 = icmp sge i64 0, 0
  br i1 %t222, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @olang_loc_a05021294fe2b6d3_c60223eeaa2ef05f)
  unreachable
bb58:
  %t224 = load i64, ptr %l79, !tbaa !24
  %t225 = icmp sle i64 0, %t224
  br i1 %t225, label %bb60, label %bb61
bb59:
  call void @__olang_check_failed(ptr @olang_loc_efed15e4a0150676_49528d4cd386b8e2)
  unreachable
bb60:
  %t227 = load i64, ptr %l79, !tbaa !24
  %t228 = load i64, ptr %l80, !tbaa !24
  %t229 = icmp sle i64 %t227, %t228
  br i1 %t229, label %bb62, label %bb63
bb61:
  call void @__olang_check_failed(ptr @olang_loc_efed15e4a0150676_49528d4cd386b8e2)
  unreachable
bb62:
  %t231 = load ptr, ptr %lp1
  %t232 = getelementptr { i64, ptr }, ptr %t231, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !27
  %t234 = load i64, ptr %l79, !tbaa !24
  %t235 = getelementptr i8, ptr %t233, i64 0
  %t236 = sub i64 %t234, 0
  %t237 = insertvalue { i64, ptr } undef, i64 %t236, 0
  %t238 = insertvalue { i64, ptr } %t237, ptr %t235, 1
  %t242 = call { i64, ptr } @compiler_2fprofile_2equalifier(ptr %v1, ptr %s0, { i64, ptr } %t238)
  store { i64, ptr } %t242, ptr %l86
  br label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_efed15e4a0150676_49528d4cd386b8e2)
  unreachable
bb64:
  %t243 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t243, ptr %l7, !tbaa !27
  %t244 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t246 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s0, { i64, ptr } %t244, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) })
  %t247 = extractvalue { i32, i64 } %t246, 1
  %t248 = extractvalue { i32, i64 } %t246, 0
  store i32 %t248, ptr %l90
  %t249 = icmp ne i32 %t248, 0
  br i1 %t249, label %bb66, label %ok.250, !prof !99
ok.250:
  store i64 %t247, ptr %l89
  br label %bb65
bb65:
  %t251 = load i64, ptr %l89, !tbaa !24
  store i64 %t251, ptr %l87, !tbaa !24
  br label %bb68
bb66:
  br label %bb67
bb67:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l87, !tbaa !24
  br label %bb68
bb68:
  %t252 = load i64, ptr %l87, !tbaa !24
  store i64 %t252, ptr %l8, !tbaa !24
  %t253 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t255 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s0, { i64, ptr } %t253, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) })
  %t256 = extractvalue { i32, i64 } %t255, 1
  %t257 = extractvalue { i32, i64 } %t255, 0
  store i32 %t257, ptr %l94
  %t258 = icmp ne i32 %t257, 0
  br i1 %t258, label %bb70, label %ok.259, !prof !99
ok.259:
  store i64 %t256, ptr %l93
  br label %bb69
bb69:
  %t260 = load i64, ptr %l93, !tbaa !24
  store i64 %t260, ptr %l91, !tbaa !24
  br label %bb72
bb70:
  br label %bb71
bb71:
  call void @__olang_ert_req_clear()
  %t261 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t263 = extractvalue { i64, ptr } %t261, 0
  store i64 %t263, ptr %l91, !tbaa !24
  br label %bb72
bb72:
  %t265 = load i64, ptr %l91, !tbaa !24
  store i64 %t265, ptr %l9, !tbaa !24
  %t266 = load i64, ptr %l8, !tbaa !24
  %t268 = icmp sge i64 %t266, 0
  br i1 %t268, label %bb73, label %bb74
bb73:
  %t270 = load i64, ptr %l8, !tbaa !24
  %t271 = load i64, ptr %l9, !tbaa !24
  %t274 = icmp slt i64 %t270, %t271
  store i1 %t274, ptr %l99, !tbaa !21
  br label %bb75
bb74:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb75
bb75:
  %t276 = load i1, ptr %l99, !tbaa !21
  br i1 %t276, label %bb76, label %bb77
bb76:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d37, i32 0, i32 1) }, ptr %l103, !tbaa !27
  %t277 = load { i64, ptr }, ptr %l103, !tbaa !27
  store { i64, ptr } %t277, ptr %l104, !tbaa !27
  %t278 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t279 = extractvalue { i64, ptr } %t278, 0
  %t280 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t281 = extractvalue { i64, ptr } %t280, 0
  store i64 %t281, ptr %l106, !tbaa !24
  %t283 = load i64, ptr %l106, !tbaa !24
  %t284 = icmp eq i64 %t279, %t283
  br i1 %t284, label %bb78, label %bb79
bb77:
  br label %bb81
bb78:
  %t286 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t287 = load ptr, ptr %t286, !tbaa !27
  %t288 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t289 = load ptr, ptr %t288, !tbaa !27
  %t290 = load i64, ptr %l106, !tbaa !24
  %t291 = mul i64 %t290, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t287, ptr %t289, i64 %t291, i1 false)
  br label %bb80
bb79:
  %t292 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t293 = extractvalue { i64, ptr } %t292, 0
  store i64 %t293, ptr %l108, !tbaa !24
  %t294 = load i64, ptr %l108, !tbaa !24
  %t295 = mul i64 %t294, 1
  %t296 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t295)
  %t297 = insertvalue { i64, ptr } undef, i64 %t294, 0
  %t298 = insertvalue { i64, ptr } %t297, ptr %t296, 1
  store { i64, ptr } %t298, ptr %l109, !tbaa !27
  %t299 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t300 = load ptr, ptr %t299, !tbaa !27
  %t301 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t302 = load ptr, ptr %t301, !tbaa !27
  %t303 = load i64, ptr %l108, !tbaa !24
  %t304 = mul i64 %t303, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t300, ptr %t302, i64 %t304, i1 false)
  %t305 = load { i64, ptr }, ptr %l109, !tbaa !27
  store { i64, ptr } %t305, ptr %l7, !tbaa !27
  br label %bb80
bb80:
  br label %bb81
bb81:
  %t306 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t306, ptr %l110, !tbaa !27
  %t307 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t309 = call { i64, ptr } @compiler_2fprofile_2etypesRead(ptr %v1, ptr %s0, { i64, ptr } %t307)
  store { i64, ptr } %t309, ptr %l112
  br label %bb82
bb82:
  %t310 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t311 = extractvalue { i64, ptr } %t310, 1
  %t312 = extractvalue { i64, ptr } %t310, 0
  %t313 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t314 = extractvalue { i64, ptr } %t313, 1
  %t315 = extractvalue { i64, ptr } %t313, 0
  %t316 = add i64 %t312, %t315
  %t317 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t316)
  call void @olang_textcopy(ptr %t317, ptr %t311, i64 %t312)
  %t318 = getelementptr i8, ptr %t317, i64 %t312
  call void @olang_textcopy(ptr %t318, ptr %t314, i64 %t315)
  %t319 = insertvalue { i64, ptr } undef, i64 %t316, 0
  %t320 = insertvalue { i64, ptr } %t319, ptr %t317, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t320, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fprofile_2eReport(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/profile:Tally"
  %l4 = alloca i64
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l6 = alloca double
  %l7 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca i64
  %l31 = alloca i64
  %l33 = alloca i64
  %l34 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l35 = alloca ptr
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l39 = alloca ptr
  %l40 = alloca i64
  %l41 = alloca i64
  %l44 = alloca %"compiler/profile:Tally"
  %l46 = alloca i64
  %l47 = alloca %"std/prelude/text:StringBuilder"
  %l55 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l59 = alloca i64
  %l61 = alloca { i64, ptr }
  %l63 = alloca i64
  %l67 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l84 = alloca i64
  %l85 = alloca { i64, ptr }
  %l87 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l94 = alloca i64
  %l96 = alloca i64
  %l101 = alloca i64
  %l102 = alloca i64
  %l105 = alloca i64
  %l106 = alloca i32
  %l109 = alloca i1
  %l114 = alloca i64
  %l117 = alloca i64
  %l118 = alloca i32
  %l119 = alloca ptr
  %l122 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l127 = alloca { i64, ptr }
  %l129 = alloca { i64, ptr }
  %l133 = alloca { i64, ptr }
  %l141 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l146 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l148 = alloca i64
  %l150 = alloca i64
  %l155 = alloca i64
  %l156 = alloca i64
  %l159 = alloca i64
  %l160 = alloca i32
  %l162 = alloca i64
  %l164 = alloca i1
  %l172 = alloca { i64, ptr }
  %l173 = alloca i1
  %l179 = alloca i64
  %l181 = alloca i64
  %l186 = alloca i64
  %l190 = alloca { i64, ptr }
  %l191 = alloca { i64, ptr }
  %l198 = alloca { i64, ptr }
  %l199 = alloca { i64, ptr }
  %l203 = alloca ptr
  %l205 = alloca { i64, ptr }
  %l209 = alloca i64
  %l211 = alloca i64
  %l216 = alloca i64
  %l217 = alloca i64
  %l220 = alloca i64
  %l221 = alloca i32
  %l222 = alloca i64
  %l225 = alloca i64
  %l226 = alloca i32
  %l227 = alloca ptr
  %l230 = alloca { i64, ptr }
  %l232 = alloca { i64, ptr }
  %l236 = alloca { i64, ptr }
  %l237 = alloca { i64, ptr }
  %l240 = alloca { i64, ptr }
  %l244 = alloca { i64, ptr }
  %l251 = alloca i64
  %l253 = alloca i64
  %l258 = alloca i64
  %l261 = alloca i64
  %l264 = alloca i64
  %l265 = alloca i32
  %l270 = alloca i64
  %l273 = alloca i64
  %l274 = alloca i32
  %l275 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l277 = alloca i64
  %l279 = alloca i64
  %l284 = alloca i64
  %l290 = alloca i1
  %l300 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l302 = alloca i64
  %l304 = alloca i64
  %l309 = alloca i64
  %l311 = alloca i64
  %l313 = alloca ptr
  %l317 = alloca { i64, ptr }
  %l318 = alloca i64
  %l324 = alloca i64
  %l325 = alloca i32
  %l327 = alloca { i64, ptr }
  %l332 = alloca ptr
  %l336 = alloca { i64, ptr }
  %l338 = alloca i64
  %l340 = alloca { i64, ptr }
  %l342 = alloca { i64, ptr }
  %l349 = alloca { i64, ptr }
  %l350 = alloca { i64, ptr }
  %l351 = alloca i64
  %l352 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t168 = alloca { %"compiler/profile:Tally", ptr, ptr, ptr }, align 8
  %t326 = alloca { %"compiler/profile:Tally", ptr, ptr, ptr }, align 8
  %t696 = alloca { %"compiler/profile:Tally", i64, ptr, ptr, ptr }, align 8
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t5 = call %"compiler/profile:Tally" @compiler_2fprofile_2eTallied(ptr %v1, ptr %v2, ptr %s0, ptr %t1, ptr %t2)
  store %"compiler/profile:Tally" %t5, ptr %l44
  br label %bb1
bb1:
  %t6 = load %"compiler/profile:Tally", ptr %l44
  store %"compiler/profile:Tally" %t6, ptr %l3
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aProfile_2eTotal(ptr %v1, ptr %t7)
  store i64 %t9, ptr %l46
  br label %bb2
bb2:
  %t10 = load i64, ptr %l46, !tbaa !24
  store i64 %t10, ptr %l4, !tbaa !24
  %t11 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t11, ptr %l47
  br label %bb3
bb3:
  %t12 = load %"std/prelude/text:StringBuilder", ptr %l47
  store %"std/prelude/text:StringBuilder" %t12, ptr %l5
  %t13 = load i64, ptr %l4, !tbaa !24
  %t15 = sitofp i64 %t13 to double
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/profile:Profile", ptr %t16, i32 0, i32 0
  %t19 = load i64, ptr %t18, !tbaa !24
  %t21 = sitofp i64 %t19 to double
  %t24 = fmul double %t15, %t21
  %t26 = fdiv double %t24, 0x41cdcd6500000000
  store double %t26, ptr %l6, !tbaa !26
  store ptr %l5, ptr %l55, !tbaa !29
  store { i64, ptr } %a0, ptr %l56, !tbaa !27
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/profile:Profile", ptr %t29, i32 0, i32 3
  %t33 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2eLen_3ccompiler_2fprofile_3aSample_3e(ptr %v1, ptr %t31)
  store i64 %t33, ptr %l59
  br label %bb4
bb4:
  %t34 = load double, ptr %l6, !tbaa !26
  %t36 = call { i64, ptr } @std_2fprelude_2ffloat_2eF64_2eFixed(ptr %s0, double %t34, i64 3)
  store { i64, ptr } %t36, ptr %l61
  br label %bb5
bb5:
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr %"compiler/profile:Profile", ptr %t37, i32 0, i32 2
  %t40 = load i64, ptr %t39, !tbaa !24
  store i64 %t40, ptr %l63, !tbaa !24
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr %"compiler/profile:Profile", ptr %t41, i32 0, i32 2
  %t44 = load i64, ptr %t43, !tbaa !24
  %t46 = icmp eq i64 %t44, 1
  br i1 %t46, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l67, !tbaa !27
  br label %bb8
bb7:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d39, i32 0, i32 1) }, ptr %l67, !tbaa !27
  br label %bb8
bb8:
  %t48 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  %t50 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t50, 1
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t53 = add i64 %t49, %t52
  %t54 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t55 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t56 = add i64 %t53, %t55
  %t57 = load i64, ptr %l59, !tbaa !24
  %t58 = call i64 @__olang_fmt_i64(ptr null, i64 %t57)
  %t59 = add i64 %t56, %t58
  %t60 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t61 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t62 = add i64 %t59, %t61
  %t63 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 1
  %t65 = extractvalue { i64, ptr } %t63, 0
  %t66 = add i64 %t62, %t65
  %t67 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t68 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t69 = add i64 %t66, %t68
  %t70 = load i64, ptr %l63, !tbaa !24
  %t71 = call i64 @__olang_fmt_i64(ptr null, i64 %t70)
  %t72 = add i64 %t69, %t71
  %t73 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 1
  %t75 = extractvalue { i64, ptr } %t73, 0
  %t76 = add i64 %t72, %t75
  %t77 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t78 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t79 = add i64 %t76, %t78
  %t80 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t79)
  call void @olang_textcopy(ptr %t80, ptr %t48, i64 %t49)
  %t81 = getelementptr i8, ptr %t80, i64 %t49
  call void @olang_textcopy(ptr %t81, ptr %t51, i64 %t52)
  %t82 = getelementptr i8, ptr %t81, i64 %t52
  call void @olang_textcopy(ptr %t82, ptr %t54, i64 %t55)
  %t83 = getelementptr i8, ptr %t82, i64 %t55
  %t84 = call i64 @__olang_fmt_i64(ptr %t83, i64 %t57)
  %t85 = getelementptr i8, ptr %t83, i64 %t58
  call void @olang_textcopy(ptr %t85, ptr %t60, i64 %t61)
  %t86 = getelementptr i8, ptr %t85, i64 %t61
  call void @olang_textcopy(ptr %t86, ptr %t64, i64 %t65)
  %t87 = getelementptr i8, ptr %t86, i64 %t65
  call void @olang_textcopy(ptr %t87, ptr %t67, i64 %t68)
  %t88 = getelementptr i8, ptr %t87, i64 %t68
  %t89 = call i64 @__olang_fmt_i64(ptr %t88, i64 %t70)
  %t90 = getelementptr i8, ptr %t88, i64 %t71
  call void @olang_textcopy(ptr %t90, ptr %t74, i64 %t75)
  %t91 = getelementptr i8, ptr %t90, i64 %t75
  call void @olang_textcopy(ptr %t91, ptr %t77, i64 %t78)
  %t92 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t80, 1
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t96 = extractvalue { i64, ptr } %t93, 1
  %t97 = mul i64 %t95, 1
  %t98 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t97)
  call void @llvm.memcpy.p0.p0.i64(ptr %t98, ptr %t96, i64 %t97, i1 false)
  %t99 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  %t101 = load ptr, ptr %l55, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t101, { i64, ptr } %t100)
  br label %bb9
bb9:
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t105 = getelementptr %"compiler/profile:Profile", ptr %t103, i32 0, i32 1
  %t106 = load i64, ptr %t105, !tbaa !24
  %t108 = icmp sgt i64 %t106, 0
  br i1 %t108, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t110 = load ptr, ptr %l1, !tbaa !29
  %t112 = getelementptr %"compiler/profile:Profile", ptr %t110, i32 0, i32 1
  %t113 = load i64, ptr %t112, !tbaa !24
  %t114 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t115 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t117 = call i64 @__olang_fmt_i64(ptr null, i64 %t113)
  %t118 = add i64 %t115, %t117
  %t119 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t120 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t121 = add i64 %t118, %t120
  %t122 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t121)
  call void @olang_textcopy(ptr %t122, ptr %t114, i64 %t115)
  %t123 = getelementptr i8, ptr %t122, i64 %t115
  %t124 = call i64 @__olang_fmt_i64(ptr %t123, i64 %t113)
  %t125 = getelementptr i8, ptr %t123, i64 %t117
  call void @olang_textcopy(ptr %t125, ptr %t119, i64 %t120)
  %t126 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t122, 1
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t130 = extractvalue { i64, ptr } %t127, 1
  %t131 = mul i64 %t129, 1
  %t132 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t131)
  call void @llvm.memcpy.p0.p0.i64(ptr %t132, ptr %t130, i64 %t131, i1 false)
  %t133 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t134 = insertvalue { i64, ptr } %t133, ptr %t132, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l5, { i64, ptr } %t134)
  br label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  %t137 = load i64, ptr %l4, !tbaa !24
  %t139 = icmp eq i64 %t137, 0
  br i1 %t139, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l5, { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d47, i32 0, i32 1) })
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t143 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v3, ptr %l5)
  store { i64, ptr } %t143, ptr %l82
  br label %bb17
bb17:
  %t144 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t144, ptr %l83, !tbaa !27
  %t145 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t145, 0
  store i64 %t146, ptr %l84, !tbaa !24
  %t147 = load i64, ptr %l84, !tbaa !24
  %t148 = mul i64 %t147, 1
  %t149 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t148)
  %t150 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  store { i64, ptr } %t151, ptr %l85, !tbaa !27
  %t152 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = load i64, ptr %l84, !tbaa !24
  %t157 = mul i64 %t156, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t153, ptr %t155, i64 %t157, i1 false)
  %t158 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t158, ptr %l83, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t159 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t159, ptr %rv
  br label %ret
bb18:
  %t160 = getelementptr %"compiler/profile:Tally", ptr %l3, i32 0, i32 5
  %t162 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClone_3cI64_3e(ptr %s0, ptr %s0, ptr %t160)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t162, ptr %l87
  br label %bb19
bb19:
  %t163 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l87
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t163, ptr %l7
  %t164 = load %"compiler/profile:Tally", ptr %l3
  %t165 = load ptr, ptr %l2, !tbaa !29
  %t166 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr null, i32 1
  %t167 = ptrtoint ptr %t166 to i64
  %t169 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %t168, i32 0, i32 0
  store %"compiler/profile:Tally" %t164, ptr %t169, !tbaa !28
  %t171 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %t168, i32 0, i32 1
  store ptr %t165, ptr %t171, !tbaa !28
  call void @__olang_scope_escape(ptr %s0)
  %t173 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %t168, i32 0, i32 2
  store ptr %s0, ptr %t173, !tbaa !28
  call void @__olang_scope_escape(ptr %v2)
  %t174 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %t168, i32 0, i32 3
  store ptr %v2, ptr %t174, !tbaa !28
  %t175 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_48, 0
  %t176 = insertvalue { ptr, ptr } %t175, ptr %t168, 1
  %t179 = extractvalue { ptr, ptr } %t176, 0
  %t180 = extractvalue { ptr, ptr } %t176, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %s0, ptr %s0, ptr %l7, ptr %t179, ptr %t180)
  br label %bb20
bb20:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l5, { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d49, i32 0, i32 1) })
  br label %bb21
bb21:
  store i64 0, ptr %l8, !tbaa !24
  store ptr %l7, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s6
  %t183 = load i64, ptr %l10, !tbaa !24
  store i64 %t183, ptr %l94, !tbaa !24
  %t184 = load ptr, ptr %l9, !tbaa !29
  %t186 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t184)
  store i64 %t186, ptr %l96
  br label %bb23
bb23:
  %t187 = load i64, ptr %l94, !tbaa !24
  %t188 = load i64, ptr %l96, !tbaa !24
  %t189 = icmp slt i64 %t187, %t188
  %t191 = xor i1 %t189, true
  br i1 %t191, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s6)
  br label %bb49
bb25:
  br label %bb26
bb26:
  %t193 = load ptr, ptr %l9, !tbaa !29
  %t194 = load i64, ptr %l10, !tbaa !24
  %t197 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t193, i64 %t194)
  store i64 %t197, ptr %l101
  br label %bb27
bb27:
  %t198 = load i64, ptr %l101, !tbaa !24
  store i64 %t198, ptr %l11, !tbaa !24
  %t199 = getelementptr %"compiler/profile:Tally", ptr %l3, i32 0, i32 0
  %t200 = load i64, ptr %l11, !tbaa !24
  %t203 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %s0, ptr %t199, i64 %t200)
  %t204 = extractvalue { i32, i64 } %t203, 1
  %t205 = extractvalue { i32, i64 } %t203, 0
  store i32 %t205, ptr %l106
  %t206 = icmp ne i32 %t205, 0
  br i1 %t206, label %bb29, label %ok.207, !prof !99
ok.207:
  store i64 %t204, ptr %l105
  br label %bb28
bb28:
  %t208 = load i64, ptr %l105, !tbaa !24
  store i64 %t208, ptr %l102, !tbaa !24
  br label %bb31
bb29:
  br label %bb30
bb30:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l102, !tbaa !24
  br label %bb31
bb31:
  %t209 = load i64, ptr %l102, !tbaa !24
  store i64 %t209, ptr %l12, !tbaa !24
  %t210 = load i64, ptr %l8, !tbaa !24
  %t212 = icmp sge i64 %t210, 25
  br i1 %t212, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb34
bb33:
  %t214 = load i64, ptr %l12, !tbaa !24
  %t216 = mul i64 %t214, 200
  %t217 = load i64, ptr %l4, !tbaa !24
  %t220 = icmp slt i64 %t216, %t217
  store i1 %t220, ptr %l109, !tbaa !21
  br label %bb34
bb34:
  %t222 = load i1, ptr %l109, !tbaa !21
  br i1 %t222, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s6)
  br label %bb49
bb36:
  br label %bb37
bb37:
  %t223 = getelementptr %"compiler/profile:Tally", ptr %l3, i32 0, i32 1
  %t224 = load i64, ptr %l11, !tbaa !24
  %t227 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %s0, ptr %t223, i64 %t224)
  %t228 = extractvalue { i32, i64 } %t227, 1
  %t229 = extractvalue { i32, i64 } %t227, 0
  store i32 %t229, ptr %l118
  %t230 = icmp ne i32 %t229, 0
  br i1 %t230, label %bb39, label %ok.231, !prof !99
ok.231:
  store i64 %t228, ptr %l117
  br label %bb38
bb38:
  %t232 = load i64, ptr %l117, !tbaa !24
  store i64 %t232, ptr %l114, !tbaa !24
  br label %bb41
bb39:
  br label %bb40
bb40:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l114, !tbaa !24
  br label %bb41
bb41:
  %t233 = load i64, ptr %l114, !tbaa !24
  store i64 %t233, ptr %l13, !tbaa !24
  store ptr %l5, ptr %l119, !tbaa !29
  %t234 = load i64, ptr %l12, !tbaa !24
  %t235 = load i64, ptr %l4, !tbaa !24
  %t238 = call { i64, ptr } @compiler_2fprofile_2epct(ptr %s6, i64 %t234, i64 %t235)
  store { i64, ptr } %t238, ptr %l122
  br label %bb42
bb42:
  %t239 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t240 = extractvalue { i64, ptr } %t239, 0
  %t241 = extractvalue { i64, ptr } %t239, 1
  %t242 = mul i64 %t240, 1
  %t243 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t242)
  call void @llvm.memcpy.p0.p0.i64(ptr %t243, ptr %t241, i64 %t242, i1 false)
  %t244 = insertvalue { i64, ptr } undef, i64 %t240, 0
  %t245 = insertvalue { i64, ptr } %t244, ptr %t243, 1
  %t247 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %s6, ptr %s6, { i64, ptr } %t245, i64 6, i8 32)
  store { i64, ptr } %t247, ptr %l124
  br label %bb43
bb43:
  %t248 = load i64, ptr %l13, !tbaa !24
  %t249 = load i64, ptr %l4, !tbaa !24
  %t252 = call { i64, ptr } @compiler_2fprofile_2epct(ptr %s6, i64 %t248, i64 %t249)
  store { i64, ptr } %t252, ptr %l127
  br label %bb44
bb44:
  %t253 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t254 = extractvalue { i64, ptr } %t253, 0
  %t255 = extractvalue { i64, ptr } %t253, 1
  %t256 = mul i64 %t254, 1
  %t257 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t256)
  call void @llvm.memcpy.p0.p0.i64(ptr %t257, ptr %t255, i64 %t256, i1 false)
  %t258 = insertvalue { i64, ptr } undef, i64 %t254, 0
  %t259 = insertvalue { i64, ptr } %t258, ptr %t257, 1
  %t261 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %s6, ptr %s6, { i64, ptr } %t259, i64 6, i8 32)
  store { i64, ptr } %t261, ptr %l129
  br label %bb45
bb45:
  %t262 = load ptr, ptr %l2, !tbaa !29
  %t264 = getelementptr %"compiler/profile:Places", ptr %t262, i32 0, i32 0
  %t265 = load i64, ptr %l11, !tbaa !24
  %t268 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %s6, ptr %t264, i64 %t265)
  store { i64, ptr } %t268, ptr %l133
  br label %bb46
bb46:
  %t269 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t270 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t271 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t272 = extractvalue { i64, ptr } %t271, 1
  %t273 = extractvalue { i64, ptr } %t271, 0
  %t274 = add i64 %t270, %t273
  %t275 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t276 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  %t277 = add i64 %t274, %t276
  %t278 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t279 = extractvalue { i64, ptr } %t278, 1
  %t280 = extractvalue { i64, ptr } %t278, 0
  %t281 = add i64 %t277, %t280
  %t282 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t283 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t284 = add i64 %t281, %t283
  %t285 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t286 = extractvalue { i64, ptr } %t285, 1
  %t287 = extractvalue { i64, ptr } %t285, 0
  %t288 = add i64 %t284, %t287
  %t289 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t290 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t291 = add i64 %t288, %t290
  %t292 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t291)
  call void @olang_textcopy(ptr %t292, ptr %t269, i64 %t270)
  %t293 = getelementptr i8, ptr %t292, i64 %t270
  call void @olang_textcopy(ptr %t293, ptr %t272, i64 %t273)
  %t294 = getelementptr i8, ptr %t293, i64 %t273
  call void @olang_textcopy(ptr %t294, ptr %t275, i64 %t276)
  %t295 = getelementptr i8, ptr %t294, i64 %t276
  call void @olang_textcopy(ptr %t295, ptr %t279, i64 %t280)
  %t296 = getelementptr i8, ptr %t295, i64 %t280
  call void @olang_textcopy(ptr %t296, ptr %t282, i64 %t283)
  %t297 = getelementptr i8, ptr %t296, i64 %t283
  call void @olang_textcopy(ptr %t297, ptr %t286, i64 %t287)
  %t298 = getelementptr i8, ptr %t297, i64 %t287
  call void @olang_textcopy(ptr %t298, ptr %t289, i64 %t290)
  %t299 = insertvalue { i64, ptr } undef, i64 %t291, 0
  %t300 = insertvalue { i64, ptr } %t299, ptr %t292, 1
  %t302 = extractvalue { i64, ptr } %t300, 0
  %t303 = extractvalue { i64, ptr } %t300, 1
  %t304 = mul i64 %t302, 1
  %t305 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t304)
  call void @llvm.memcpy.p0.p0.i64(ptr %t305, ptr %t303, i64 %t304, i1 false)
  %t306 = insertvalue { i64, ptr } undef, i64 %t302, 0
  %t307 = insertvalue { i64, ptr } %t306, ptr %t305, 1
  %t308 = load ptr, ptr %l119, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %t308, { i64, ptr } %t307)
  br label %bb47
bb47:
  %t310 = load i64, ptr %l8, !tbaa !24
  %t312 = add i64 %t310, 1
  store i64 %t312, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb48
bb48:
  %t314 = load i64, ptr %l10, !tbaa !24
  %t316 = add i64 %t314, 1
  store i64 %t316, ptr %l10, !tbaa !24
  br label %bb22
bb49:
  %t318 = getelementptr %"compiler/profile:Tally", ptr %l3, i32 0, i32 6
  %t320 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClone_3cI64_3e(ptr %s0, ptr %s0, ptr %t318)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t320, ptr %l141
  br label %bb50
bb50:
  %t321 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l141
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t321, ptr %l14
  %t322 = load %"compiler/profile:Tally", ptr %l3
  %t323 = load ptr, ptr %l2, !tbaa !29
  %t324 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr null, i32 1
  %t325 = ptrtoint ptr %t324 to i64
  %t327 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %t326, i32 0, i32 0
  store %"compiler/profile:Tally" %t322, ptr %t327, !tbaa !28
  %t329 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %t326, i32 0, i32 1
  store ptr %t323, ptr %t329, !tbaa !28
  call void @__olang_scope_escape(ptr %s0)
  %t331 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %t326, i32 0, i32 2
  store ptr %s0, ptr %t331, !tbaa !28
  call void @__olang_scope_escape(ptr %v2)
  %t332 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %t326, i32 0, i32 3
  store ptr %v2, ptr %t332, !tbaa !28
  %t333 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_54, 0
  %t334 = insertvalue { ptr, ptr } %t333, ptr %t326, 1
  %t337 = extractvalue { ptr, ptr } %t334, 0
  %t338 = extractvalue { ptr, ptr } %t334, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %s0, ptr %s0, ptr %l14, ptr %t337, ptr %t338)
  br label %bb51
bb51:
  %t339 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t339, ptr %l146
  br label %bb52
bb52:
  %t340 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l146
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t340, ptr %l15
  store ptr %l14, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb53
bb53:
  store %olang.scope zeroinitializer, ptr %s11
  %t342 = load i64, ptr %l17, !tbaa !24
  store i64 %t342, ptr %l148, !tbaa !24
  %t343 = load ptr, ptr %l16, !tbaa !29
  %t345 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t343)
  store i64 %t345, ptr %l150
  br label %bb54
bb54:
  %t346 = load i64, ptr %l148, !tbaa !24
  %t347 = load i64, ptr %l150, !tbaa !24
  %t348 = icmp slt i64 %t346, %t347
  %t350 = xor i1 %t348, true
  br i1 %t350, label %bb55, label %bb56
bb55:
  call void @__olang_scope_close(ptr %s11)
  br label %bb77
bb56:
  br label %bb57
bb57:
  %t352 = load ptr, ptr %l16, !tbaa !29
  %t353 = load i64, ptr %l17, !tbaa !24
  %t356 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t352, i64 %t353)
  store i64 %t356, ptr %l155
  br label %bb58
bb58:
  %t357 = load i64, ptr %l155, !tbaa !24
  store i64 %t357, ptr %l18, !tbaa !24
  %t358 = getelementptr %"compiler/profile:Tally", ptr %l3, i32 0, i32 2
  %t359 = load i64, ptr %l18, !tbaa !24
  %t362 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %s0, ptr %t358, i64 %t359)
  %t363 = extractvalue { i32, i64 } %t362, 1
  %t364 = extractvalue { i32, i64 } %t362, 0
  store i32 %t364, ptr %l160
  %t365 = icmp ne i32 %t364, 0
  br i1 %t365, label %bb60, label %ok.366, !prof !99
ok.366:
  store i64 %t363, ptr %l159
  br label %bb59
bb59:
  %t367 = load i64, ptr %l159, !tbaa !24
  store i64 %t367, ptr %l156, !tbaa !24
  br label %bb62
bb60:
  br label %bb61
bb61:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l156, !tbaa !24
  br label %bb62
bb62:
  %t368 = load i64, ptr %l156, !tbaa !24
  store i64 %t368, ptr %l19, !tbaa !24
  %t370 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l15)
  store i64 %t370, ptr %l162
  br label %bb63
bb63:
  %t371 = load i64, ptr %l162, !tbaa !24
  %t372 = icmp sge i64 %t371, 15
  br i1 %t372, label %bb64, label %bb65
bb64:
  store i1 true, ptr %l164, !tbaa !21
  br label %bb66
bb65:
  %t374 = load i64, ptr %l19, !tbaa !24
  %t376 = mul i64 %t374, 200
  %t377 = load i64, ptr %l4, !tbaa !24
  %t380 = icmp slt i64 %t376, %t377
  store i1 %t380, ptr %l164, !tbaa !21
  br label %bb66
bb66:
  %t382 = load i1, ptr %l164, !tbaa !21
  br i1 %t382, label %bb67, label %bb68
bb67:
  call void @__olang_scope_close(ptr %s11)
  br label %bb77
bb68:
  br label %bb69
bb69:
  %t383 = load ptr, ptr %l2, !tbaa !29
  %t385 = getelementptr %"compiler/profile:Places", ptr %t383, i32 0, i32 0
  %t386 = load i64, ptr %l18, !tbaa !24
  %t389 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %v2, ptr %t385, i64 %t386)
  store { i64, ptr } %t389, ptr %l172
  br label %bb70
bb70:
  %t390 = load { i64, ptr }, ptr %l172, !tbaa !27
  %t391 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v2, ptr %s11, { i64, ptr } %t390, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d55, i32 0, i32 1) })
  store i1 %t391, ptr %l173
  br label %bb71
bb71:
  %t392 = load i1, ptr %l173, !tbaa !21
  br i1 %t392, label %bb72, label %bb73
bb72:
  call void @__olang_scope_close(ptr %s11)
  br label %bb76
bb73:
  br label %bb74
bb74:
  %t393 = load i64, ptr %l18, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l15, i64 %t393)
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s11)
  br label %bb76
bb76:
  %t396 = load i64, ptr %l17, !tbaa !24
  %t398 = add i64 %t396, 1
  store i64 %t398, ptr %l17, !tbaa !24
  br label %bb53
bb77:
  store i64 4, ptr %l20, !tbaa !24
  store ptr %l15, ptr %l21, !tbaa !29
  store i64 0, ptr %l22, !tbaa !24
  br label %bb78
bb78:
  store %olang.scope zeroinitializer, ptr %s16
  %t401 = load i64, ptr %l22, !tbaa !24
  store i64 %t401, ptr %l179, !tbaa !24
  %t402 = load ptr, ptr %l21, !tbaa !29
  %t404 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t402)
  store i64 %t404, ptr %l181
  br label %bb79
bb79:
  %t405 = load i64, ptr %l179, !tbaa !24
  %t406 = load i64, ptr %l181, !tbaa !24
  %t407 = icmp slt i64 %t405, %t406
  %t409 = xor i1 %t407, true
  br i1 %t409, label %bb80, label %bb81
bb80:
  call void @__olang_scope_close(ptr %s16)
  br label %bb92
bb81:
  br label %bb82
bb82:
  %t411 = load ptr, ptr %l21, !tbaa !29
  %t412 = load i64, ptr %l22, !tbaa !24
  %t415 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t411, i64 %t412)
  store i64 %t415, ptr %l186
  br label %bb83
bb83:
  %t416 = load i64, ptr %l186, !tbaa !24
  store i64 %t416, ptr %l23, !tbaa !24
  %t417 = load ptr, ptr %l2, !tbaa !29
  %t419 = getelementptr %"compiler/profile:Places", ptr %t417, i32 0, i32 0
  %t420 = load i64, ptr %l23, !tbaa !24
  %t423 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %v2, ptr %t419, i64 %t420)
  store { i64, ptr } %t423, ptr %l190
  br label %bb84
bb84:
  %t424 = load { i64, ptr }, ptr %l190, !tbaa !27
  %t425 = call { i64, ptr } @compiler_2fprofile_2eshortPath(ptr %v2, ptr %s16, { i64, ptr } %t424)
  store { i64, ptr } %t425, ptr %l191
  br label %bb85
bb85:
  %t426 = load { i64, ptr }, ptr %l191, !tbaa !27
  %t427 = extractvalue { i64, ptr } %t426, 0
  %t428 = load i64, ptr %l20, !tbaa !24
  %t431 = icmp sgt i64 %t427, %t428
  br i1 %t431, label %bb86, label %bb87
bb86:
  store %olang.scope zeroinitializer, ptr %s17
  %t433 = load ptr, ptr %l2, !tbaa !29
  %t435 = getelementptr %"compiler/profile:Places", ptr %t433, i32 0, i32 0
  %t436 = load i64, ptr %l23, !tbaa !24
  %t439 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %v2, ptr %t435, i64 %t436)
  store { i64, ptr } %t439, ptr %l198
  br label %bb88
bb87:
  br label %bb90
bb88:
  %t440 = load { i64, ptr }, ptr %l198, !tbaa !27
  %t441 = call { i64, ptr } @compiler_2fprofile_2eshortPath(ptr %v2, ptr %s17, { i64, ptr } %t440)
  store { i64, ptr } %t441, ptr %l199
  br label %bb89
bb89:
  %t442 = load { i64, ptr }, ptr %l199, !tbaa !27
  %t443 = extractvalue { i64, ptr } %t442, 0
  store i64 %t443, ptr %l20, !tbaa !24
  call void @__olang_scope_close(ptr %s17)
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s16)
  br label %bb91
bb91:
  %t445 = load i64, ptr %l22, !tbaa !24
  %t447 = add i64 %t445, 1
  store i64 %t447, ptr %l22, !tbaa !24
  br label %bb78
bb92:
  store ptr %l5, ptr %l203, !tbaa !29
  %t449 = load i64, ptr %l20, !tbaa !24
  %t451 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadEnd(ptr %s0, ptr %s0, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d56, i32 0, i32 1) }, i64 %t449, i8 32)
  store { i64, ptr } %t451, ptr %l205
  br label %bb93
bb93:
  %t452 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d57, i32 0, i32 1) }, 1
  %t453 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d57, i32 0, i32 1) }, 0
  %t454 = load { i64, ptr }, ptr %l205, !tbaa !27
  %t455 = extractvalue { i64, ptr } %t454, 1
  %t456 = extractvalue { i64, ptr } %t454, 0
  %t457 = add i64 %t453, %t456
  %t458 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t459 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  %t460 = add i64 %t457, %t459
  %t461 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t460)
  call void @olang_textcopy(ptr %t461, ptr %t452, i64 %t453)
  %t462 = getelementptr i8, ptr %t461, i64 %t453
  call void @olang_textcopy(ptr %t462, ptr %t455, i64 %t456)
  %t463 = getelementptr i8, ptr %t462, i64 %t456
  call void @olang_textcopy(ptr %t463, ptr %t458, i64 %t459)
  %t464 = insertvalue { i64, ptr } undef, i64 %t460, 0
  %t465 = insertvalue { i64, ptr } %t464, ptr %t461, 1
  %t467 = extractvalue { i64, ptr } %t465, 0
  %t468 = extractvalue { i64, ptr } %t465, 1
  %t469 = mul i64 %t467, 1
  %t470 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t469)
  call void @llvm.memcpy.p0.p0.i64(ptr %t470, ptr %t468, i64 %t469, i1 false)
  %t471 = insertvalue { i64, ptr } undef, i64 %t467, 0
  %t472 = insertvalue { i64, ptr } %t471, ptr %t470, 1
  %t473 = load ptr, ptr %l203, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t473, { i64, ptr } %t472)
  br label %bb94
bb94:
  store ptr %l15, ptr %l24, !tbaa !29
  store i64 0, ptr %l25, !tbaa !24
  br label %bb95
bb95:
  store %olang.scope zeroinitializer, ptr %s21
  %t476 = load i64, ptr %l25, !tbaa !24
  store i64 %t476, ptr %l209, !tbaa !24
  %t477 = load ptr, ptr %l24, !tbaa !29
  %t479 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t477)
  store i64 %t479, ptr %l211
  br label %bb96
bb96:
  %t480 = load i64, ptr %l209, !tbaa !24
  %t481 = load i64, ptr %l211, !tbaa !24
  %t482 = icmp slt i64 %t480, %t481
  %t484 = xor i1 %t482, true
  br i1 %t484, label %bb97, label %bb98
bb97:
  call void @__olang_scope_close(ptr %s21)
  br label %bb117
bb98:
  br label %bb99
bb99:
  %t486 = load ptr, ptr %l24, !tbaa !29
  %t487 = load i64, ptr %l25, !tbaa !24
  %t490 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t486, i64 %t487)
  store i64 %t490, ptr %l216
  br label %bb100
bb100:
  %t491 = load i64, ptr %l216, !tbaa !24
  store i64 %t491, ptr %l26, !tbaa !24
  %t492 = getelementptr %"compiler/profile:Tally", ptr %l3, i32 0, i32 2
  %t493 = load i64, ptr %l26, !tbaa !24
  %t496 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %s0, ptr %t492, i64 %t493)
  %t497 = extractvalue { i32, i64 } %t496, 1
  %t498 = extractvalue { i32, i64 } %t496, 0
  store i32 %t498, ptr %l221
  %t499 = icmp ne i32 %t498, 0
  br i1 %t499, label %bb102, label %ok.500, !prof !99
ok.500:
  store i64 %t497, ptr %l220
  br label %bb101
bb101:
  %t501 = load i64, ptr %l220, !tbaa !24
  store i64 %t501, ptr %l217, !tbaa !24
  br label %bb104
bb102:
  br label %bb103
bb103:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l217, !tbaa !24
  br label %bb104
bb104:
  %t502 = load i64, ptr %l217, !tbaa !24
  store i64 %t502, ptr %l27, !tbaa !24
  %t503 = getelementptr %"compiler/profile:Tally", ptr %l3, i32 0, i32 3
  %t504 = load i64, ptr %l26, !tbaa !24
  %t507 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %s0, ptr %t503, i64 %t504)
  %t508 = extractvalue { i32, i64 } %t507, 1
  %t509 = extractvalue { i32, i64 } %t507, 0
  store i32 %t509, ptr %l226
  %t510 = icmp ne i32 %t509, 0
  br i1 %t510, label %bb106, label %ok.511, !prof !99
ok.511:
  store i64 %t508, ptr %l225
  br label %bb105
bb105:
  %t512 = load i64, ptr %l225, !tbaa !24
  store i64 %t512, ptr %l222, !tbaa !24
  br label %bb108
bb106:
  br label %bb107
bb107:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l222, !tbaa !24
  br label %bb108
bb108:
  %t513 = load i64, ptr %l222, !tbaa !24
  store i64 %t513, ptr %l28, !tbaa !24
  store ptr %l5, ptr %l227, !tbaa !29
  %t514 = load i64, ptr %l27, !tbaa !24
  %t515 = load i64, ptr %l4, !tbaa !24
  %t518 = call { i64, ptr } @compiler_2fprofile_2epct(ptr %s21, i64 %t514, i64 %t515)
  store { i64, ptr } %t518, ptr %l230
  br label %bb109
bb109:
  %t519 = load { i64, ptr }, ptr %l230, !tbaa !27
  %t520 = extractvalue { i64, ptr } %t519, 0
  %t521 = extractvalue { i64, ptr } %t519, 1
  %t522 = mul i64 %t520, 1
  %t523 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t522)
  call void @llvm.memcpy.p0.p0.i64(ptr %t523, ptr %t521, i64 %t522, i1 false)
  %t524 = insertvalue { i64, ptr } undef, i64 %t520, 0
  %t525 = insertvalue { i64, ptr } %t524, ptr %t523, 1
  %t527 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %s21, ptr %s21, { i64, ptr } %t525, i64 6, i8 32)
  store { i64, ptr } %t527, ptr %l232
  br label %bb110
bb110:
  %t528 = load ptr, ptr %l2, !tbaa !29
  %t530 = getelementptr %"compiler/profile:Places", ptr %t528, i32 0, i32 0
  %t531 = load i64, ptr %l26, !tbaa !24
  %t534 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %v2, ptr %t530, i64 %t531)
  store { i64, ptr } %t534, ptr %l236
  br label %bb111
bb111:
  %t535 = load { i64, ptr }, ptr %l236, !tbaa !27
  %t536 = call { i64, ptr } @compiler_2fprofile_2eshortPath(ptr %v2, ptr %s21, { i64, ptr } %t535)
  store { i64, ptr } %t536, ptr %l237
  br label %bb112
bb112:
  %t537 = load { i64, ptr }, ptr %l237, !tbaa !27
  %t538 = extractvalue { i64, ptr } %t537, 0
  %t539 = extractvalue { i64, ptr } %t537, 1
  %t540 = mul i64 %t538, 1
  %t541 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t540)
  call void @llvm.memcpy.p0.p0.i64(ptr %t541, ptr %t539, i64 %t540, i1 false)
  %t542 = insertvalue { i64, ptr } undef, i64 %t538, 0
  %t543 = insertvalue { i64, ptr } %t542, ptr %t541, 1
  %t544 = load i64, ptr %l20, !tbaa !24
  %t547 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadEnd(ptr %s21, ptr %s21, { i64, ptr } %t543, i64 %t544, i8 32)
  store { i64, ptr } %t547, ptr %l240
  br label %bb113
bb113:
  %t548 = load ptr, ptr %l2, !tbaa !29
  %t550 = getelementptr %"compiler/profile:Places", ptr %t548, i32 0, i32 0
  %t551 = load i64, ptr %l28, !tbaa !24
  %t554 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %s21, ptr %t550, i64 %t551)
  store { i64, ptr } %t554, ptr %l244
  br label %bb114
bb114:
  %t555 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t556 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t557 = load { i64, ptr }, ptr %l232, !tbaa !27
  %t558 = extractvalue { i64, ptr } %t557, 1
  %t559 = extractvalue { i64, ptr } %t557, 0
  %t560 = add i64 %t556, %t559
  %t561 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t562 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t563 = add i64 %t560, %t562
  %t564 = load { i64, ptr }, ptr %l240, !tbaa !27
  %t565 = extractvalue { i64, ptr } %t564, 1
  %t566 = extractvalue { i64, ptr } %t564, 0
  %t567 = add i64 %t563, %t566
  %t568 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t569 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t570 = add i64 %t567, %t569
  %t571 = load { i64, ptr }, ptr %l244, !tbaa !27
  %t572 = extractvalue { i64, ptr } %t571, 1
  %t573 = extractvalue { i64, ptr } %t571, 0
  %t574 = add i64 %t570, %t573
  %t575 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t576 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  %t577 = add i64 %t574, %t576
  %t578 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t577)
  call void @olang_textcopy(ptr %t578, ptr %t555, i64 %t556)
  %t579 = getelementptr i8, ptr %t578, i64 %t556
  call void @olang_textcopy(ptr %t579, ptr %t558, i64 %t559)
  %t580 = getelementptr i8, ptr %t579, i64 %t559
  call void @olang_textcopy(ptr %t580, ptr %t561, i64 %t562)
  %t581 = getelementptr i8, ptr %t580, i64 %t562
  call void @olang_textcopy(ptr %t581, ptr %t565, i64 %t566)
  %t582 = getelementptr i8, ptr %t581, i64 %t566
  call void @olang_textcopy(ptr %t582, ptr %t568, i64 %t569)
  %t583 = getelementptr i8, ptr %t582, i64 %t569
  call void @olang_textcopy(ptr %t583, ptr %t572, i64 %t573)
  %t584 = getelementptr i8, ptr %t583, i64 %t573
  call void @olang_textcopy(ptr %t584, ptr %t575, i64 %t576)
  %t585 = insertvalue { i64, ptr } undef, i64 %t577, 0
  %t586 = insertvalue { i64, ptr } %t585, ptr %t578, 1
  %t588 = extractvalue { i64, ptr } %t586, 0
  %t589 = extractvalue { i64, ptr } %t586, 1
  %t590 = mul i64 %t588, 1
  %t591 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t590)
  call void @llvm.memcpy.p0.p0.i64(ptr %t591, ptr %t589, i64 %t590, i1 false)
  %t592 = insertvalue { i64, ptr } undef, i64 %t588, 0
  %t593 = insertvalue { i64, ptr } %t592, ptr %t591, 1
  %t594 = load ptr, ptr %l227, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s21, ptr %t594, { i64, ptr } %t593)
  br label %bb115
bb115:
  call void @__olang_scope_close(ptr %s21)
  br label %bb116
bb116:
  %t596 = load i64, ptr %l25, !tbaa !24
  %t598 = add i64 %t596, 1
  store i64 %t598, ptr %l25, !tbaa !24
  br label %bb95
bb117:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l5, { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d62, i32 0, i32 1) })
  br label %bb118
bb118:
  store i64 0, ptr %l8, !tbaa !24
  store ptr %l7, ptr %l29, !tbaa !29
  store i64 0, ptr %l30, !tbaa !24
  br label %bb119
bb119:
  store %olang.scope zeroinitializer, ptr %s25
  %t602 = load i64, ptr %l30, !tbaa !24
  store i64 %t602, ptr %l251, !tbaa !24
  %t603 = load ptr, ptr %l29, !tbaa !29
  %t605 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t603)
  store i64 %t605, ptr %l253
  br label %bb120
bb120:
  %t606 = load i64, ptr %l251, !tbaa !24
  %t607 = load i64, ptr %l253, !tbaa !24
  %t608 = icmp slt i64 %t606, %t607
  %t610 = xor i1 %t608, true
  br i1 %t610, label %bb121, label %bb122
bb121:
  call void @__olang_scope_close(ptr %s25)
  br label %bb182
bb122:
  br label %bb123
bb123:
  %t612 = load ptr, ptr %l29, !tbaa !29
  %t613 = load i64, ptr %l30, !tbaa !24
  %t616 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t612, i64 %t613)
  store i64 %t616, ptr %l258
  br label %bb124
bb124:
  %t617 = load i64, ptr %l258, !tbaa !24
  store i64 %t617, ptr %l31, !tbaa !24
  %t618 = load i64, ptr %l8, !tbaa !24
  %t620 = icmp sge i64 %t618, 5
  br i1 %t620, label %bb125, label %bb126
bb125:
  call void @__olang_scope_close(ptr %s25)
  br label %bb182
bb126:
  br label %bb127
bb127:
  %t622 = getelementptr %"compiler/profile:Tally", ptr %l3, i32 0, i32 0
  %t623 = load i64, ptr %l31, !tbaa !24
  %t626 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %s0, ptr %t622, i64 %t623)
  %t627 = extractvalue { i32, i64 } %t626, 1
  %t628 = extractvalue { i32, i64 } %t626, 0
  store i32 %t628, ptr %l265
  %t629 = icmp ne i32 %t628, 0
  br i1 %t629, label %bb129, label %ok.630, !prof !99
ok.630:
  store i64 %t627, ptr %l264
  br label %bb128
bb128:
  %t631 = load i64, ptr %l264, !tbaa !24
  store i64 %t631, ptr %l261, !tbaa !24
  br label %bb131
bb129:
  br label %bb130
bb130:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l261, !tbaa !24
  br label %bb131
bb131:
  %t632 = load i64, ptr %l261, !tbaa !24
  %t635 = icmp eq i64 %t632, 0
  br i1 %t635, label %bb132, label %bb133
bb132:
  call void @__olang_scope_close(ptr %s25)
  br label %bb182
bb133:
  br label %bb134
bb134:
  %t637 = load i64, ptr %l8, !tbaa !24
  %t639 = add i64 %t637, 1
  store i64 %t639, ptr %l8, !tbaa !24
  %t641 = getelementptr %"compiler/profile:Tally", ptr %l3, i32 0, i32 1
  %t642 = load i64, ptr %l31, !tbaa !24
  %t645 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %s0, ptr %t641, i64 %t642)
  %t646 = extractvalue { i32, i64 } %t645, 1
  %t647 = extractvalue { i32, i64 } %t645, 0
  store i32 %t647, ptr %l274
  %t648 = icmp ne i32 %t647, 0
  br i1 %t648, label %bb136, label %ok.649, !prof !99
ok.649:
  store i64 %t646, ptr %l273
  br label %bb135
bb135:
  %t650 = load i64, ptr %l273, !tbaa !24
  store i64 %t650, ptr %l270, !tbaa !24
  br label %bb138
bb136:
  br label %bb137
bb137:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l270, !tbaa !24
  br label %bb138
bb138:
  %t651 = load i64, ptr %l270, !tbaa !24
  store i64 %t651, ptr %l33, !tbaa !24
  %t652 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s25, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t652, ptr %l275
  br label %bb139
bb139:
  %t653 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l275
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t653, ptr %l34
  %t654 = getelementptr %"compiler/profile:Tally", ptr %l3, i32 0, i32 5
  store ptr %t654, ptr %l35, !tbaa !29
  store i64 0, ptr %l36, !tbaa !24
  br label %bb140
bb140:
  %t656 = load i64, ptr %l36, !tbaa !24
  store i64 %t656, ptr %l277, !tbaa !24
  %t657 = load ptr, ptr %l35, !tbaa !29
  %t659 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t657)
  store i64 %t659, ptr %l279
  br label %bb141
bb141:
  %t660 = load i64, ptr %l277, !tbaa !24
  %t661 = load i64, ptr %l279, !tbaa !24
  %t662 = icmp slt i64 %t660, %t661
  %t664 = xor i1 %t662, true
  br i1 %t664, label %bb142, label %bb143
bb142:
  br label %bb152
bb143:
  br label %bb144
bb144:
  %t666 = load ptr, ptr %l35, !tbaa !29
  %t667 = load i64, ptr %l36, !tbaa !24
  %t670 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t666, i64 %t667)
  store i64 %t670, ptr %l284
  br label %bb145
bb145:
  %t671 = load i64, ptr %l284, !tbaa !24
  store i64 %t671, ptr %l37, !tbaa !24
  %t672 = getelementptr %"compiler/profile:Tally", ptr %l3, i32 0, i32 4
  %t673 = load i64, ptr %l31, !tbaa !24
  %t675 = mul i64 %t673, 16777216
  %t676 = load i64, ptr %l37, !tbaa !24
  %t679 = add i64 %t675, %t676
  %t682 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %s0, ptr %t672, i64 %t679)
  store i1 %t682, ptr %l290
  br label %bb146
bb146:
  %t683 = load i1, ptr %l290, !tbaa !21
  br i1 %t683, label %bb147, label %bb148
bb147:
  %t684 = load i64, ptr %l37, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s25, ptr %l34, i64 %t684)
  br label %bb149
bb148:
  br label %bb150
bb149:
  br label %bb150
bb150:
  br label %bb151
bb151:
  %t687 = load i64, ptr %l36, !tbaa !24
  %t689 = add i64 %t687, 1
  store i64 %t689, ptr %l36, !tbaa !24
  br label %bb140
bb152:
  %t691 = load %"compiler/profile:Tally", ptr %l3
  %t692 = load i64, ptr %l31, !tbaa !24
  %t693 = load ptr, ptr %l2, !tbaa !29
  %t694 = getelementptr { %"compiler/profile:Tally", i64, ptr, ptr, ptr }, ptr null, i32 1
  %t695 = ptrtoint ptr %t694 to i64
  %t697 = getelementptr { %"compiler/profile:Tally", i64, ptr, ptr, ptr }, ptr %t696, i32 0, i32 0
  store %"compiler/profile:Tally" %t691, ptr %t697, !tbaa !28
  %t699 = getelementptr { %"compiler/profile:Tally", i64, ptr, ptr, ptr }, ptr %t696, i32 0, i32 1
  store i64 %t692, ptr %t699, !tbaa !28
  %t701 = getelementptr { %"compiler/profile:Tally", i64, ptr, ptr, ptr }, ptr %t696, i32 0, i32 2
  store ptr %t693, ptr %t701, !tbaa !28
  call void @__olang_scope_escape(ptr %s0)
  %t703 = getelementptr { %"compiler/profile:Tally", i64, ptr, ptr, ptr }, ptr %t696, i32 0, i32 3
  store ptr %s0, ptr %t703, !tbaa !28
  call void @__olang_scope_escape(ptr %v2)
  %t704 = getelementptr { %"compiler/profile:Tally", i64, ptr, ptr, ptr }, ptr %t696, i32 0, i32 4
  store ptr %v2, ptr %t704, !tbaa !28
  %t705 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_63, 0
  %t706 = insertvalue { ptr, ptr } %t705, ptr %t696, 1
  %t709 = extractvalue { ptr, ptr } %t706, 0
  %t710 = extractvalue { ptr, ptr } %t706, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %s25, ptr %s25, ptr %l34, ptr %t709, ptr %t710)
  br label %bb153
bb153:
  %t711 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s25, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t711, ptr %l300
  br label %bb154
bb154:
  %t712 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l300
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t712, ptr %l38
  store ptr %l34, ptr %l39, !tbaa !29
  store i64 0, ptr %l40, !tbaa !24
  br label %bb155
bb155:
  store %olang.scope zeroinitializer, ptr %s33
  %t714 = load i64, ptr %l40, !tbaa !24
  store i64 %t714, ptr %l302, !tbaa !24
  %t715 = load ptr, ptr %l39, !tbaa !29
  %t717 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s25, ptr %t715)
  store i64 %t717, ptr %l304
  br label %bb156
bb156:
  %t718 = load i64, ptr %l302, !tbaa !24
  %t719 = load i64, ptr %l304, !tbaa !24
  %t720 = icmp slt i64 %t718, %t719
  %t722 = xor i1 %t720, true
  br i1 %t722, label %bb157, label %bb158
bb157:
  call void @__olang_scope_close(ptr %s33)
  br label %bb173
bb158:
  br label %bb159
bb159:
  %t724 = load ptr, ptr %l39, !tbaa !29
  %t725 = load i64, ptr %l40, !tbaa !24
  %t728 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s25, ptr %t724, i64 %t725)
  store i64 %t728, ptr %l309
  br label %bb160
bb160:
  %t729 = load i64, ptr %l309, !tbaa !24
  store i64 %t729, ptr %l41, !tbaa !24
  %t731 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s25, ptr %l38)
  store i64 %t731, ptr %l311
  br label %bb161
bb161:
  %t732 = load i64, ptr %l311, !tbaa !24
  %t733 = icmp sge i64 %t732, 4
  br i1 %t733, label %bb162, label %bb163
bb162:
  call void @__olang_scope_close(ptr %s33)
  br label %bb173
bb163:
  br label %bb164
bb164:
  store ptr %l38, ptr %l313, !tbaa !29
  %t735 = load ptr, ptr %l2, !tbaa !29
  %t737 = getelementptr %"compiler/profile:Places", ptr %t735, i32 0, i32 0
  %t738 = load i64, ptr %l41, !tbaa !24
  %t741 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %s33, ptr %t737, i64 %t738)
  store { i64, ptr } %t741, ptr %l317
  br label %bb165
bb165:
  %t742 = getelementptr %"compiler/profile:Tally", ptr %l3, i32 0, i32 4
  %t743 = load i64, ptr %l31, !tbaa !24
  %t745 = mul i64 %t743, 16777216
  %t746 = load i64, ptr %l41, !tbaa !24
  %t749 = add i64 %t745, %t746
  %t752 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %s0, ptr %t742, i64 %t749)
  %t753 = extractvalue { i32, i64 } %t752, 1
  %t754 = extractvalue { i32, i64 } %t752, 0
  store i32 %t754, ptr %l325
  %t755 = icmp ne i32 %t754, 0
  br i1 %t755, label %bb167, label %ok.756, !prof !99
ok.756:
  store i64 %t753, ptr %l324
  br label %bb166
bb166:
  %t757 = load i64, ptr %l324, !tbaa !24
  store i64 %t757, ptr %l318, !tbaa !24
  br label %bb169
bb167:
  br label %bb168
bb168:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l318, !tbaa !24
  br label %bb169
bb169:
  %t758 = load i64, ptr %l33, !tbaa !24
  %t759 = load i64, ptr %l318, !tbaa !24
  %t761 = call { i64, ptr } @compiler_2fprofile_2epct(ptr %s33, i64 %t759, i64 %t758)
  store { i64, ptr } %t761, ptr %l327
  br label %bb170
bb170:
  %t762 = load { i64, ptr }, ptr %l317, !tbaa !27
  %t763 = extractvalue { i64, ptr } %t762, 1
  %t764 = extractvalue { i64, ptr } %t762, 0
  %t765 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t766 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t767 = add i64 %t764, %t766
  %t768 = load { i64, ptr }, ptr %l327, !tbaa !27
  %t769 = extractvalue { i64, ptr } %t768, 1
  %t770 = extractvalue { i64, ptr } %t768, 0
  %t771 = add i64 %t767, %t770
  %t772 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t771)
  call void @olang_textcopy(ptr %t772, ptr %t763, i64 %t764)
  %t773 = getelementptr i8, ptr %t772, i64 %t764
  call void @olang_textcopy(ptr %t773, ptr %t765, i64 %t766)
  %t774 = getelementptr i8, ptr %t773, i64 %t766
  call void @olang_textcopy(ptr %t774, ptr %t769, i64 %t770)
  %t775 = insertvalue { i64, ptr } undef, i64 %t771, 0
  %t776 = insertvalue { i64, ptr } %t775, ptr %t772, 1
  %t778 = extractvalue { i64, ptr } %t776, 0
  %t779 = extractvalue { i64, ptr } %t776, 1
  %t780 = mul i64 %t778, 1
  %t781 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t780)
  call void @llvm.memcpy.p0.p0.i64(ptr %t781, ptr %t779, i64 %t780, i1 false)
  %t782 = insertvalue { i64, ptr } undef, i64 %t778, 0
  %t783 = insertvalue { i64, ptr } %t782, ptr %t781, 1
  %t784 = load ptr, ptr %l313, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s25, ptr %s25, ptr %t784, { i64, ptr } %t783)
  br label %bb171
bb171:
  call void @__olang_scope_close(ptr %s33)
  br label %bb172
bb172:
  %t786 = load i64, ptr %l40, !tbaa !24
  %t788 = add i64 %t786, 1
  store i64 %t788, ptr %l40, !tbaa !24
  br label %bb155
bb173:
  store ptr %l5, ptr %l332, !tbaa !29
  %t790 = load ptr, ptr %l2, !tbaa !29
  %t792 = getelementptr %"compiler/profile:Places", ptr %t790, i32 0, i32 0
  %t793 = load i64, ptr %l31, !tbaa !24
  %t796 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %s25, ptr %t792, i64 %t793)
  store { i64, ptr } %t796, ptr %l336
  br label %bb174
bb174:
  %t798 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s25, ptr %l38)
  store i64 %t798, ptr %l338
  br label %bb175
bb175:
  %t799 = load i64, ptr %l338, !tbaa !24
  %t800 = icmp eq i64 %t799, 0
  br i1 %t800, label %bb176, label %bb177
bb176:
  store { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d65, i32 0, i32 1) }, ptr %l340, !tbaa !27
  br label %bb179
bb177:
  %t803 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s25, ptr %s25, ptr %s25, ptr %l38, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d66, i32 0, i32 1) })
  store { i64, ptr } %t803, ptr %l342
  br label %bb178
bb178:
  %t804 = load { i64, ptr }, ptr %l342, !tbaa !27
  %t805 = extractvalue { i64, ptr } %t804, 0
  %t806 = extractvalue { i64, ptr } %t804, 1
  %t807 = mul i64 %t805, 1
  %t808 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t807)
  call void @llvm.memcpy.p0.p0.i64(ptr %t808, ptr %t806, i64 %t807, i1 false)
  %t809 = insertvalue { i64, ptr } undef, i64 %t805, 0
  %t810 = insertvalue { i64, ptr } %t809, ptr %t808, 1
  store { i64, ptr } %t810, ptr %l340, !tbaa !27
  br label %bb179
bb179:
  %t812 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t813 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t814 = load { i64, ptr }, ptr %l336, !tbaa !27
  %t815 = extractvalue { i64, ptr } %t814, 1
  %t816 = extractvalue { i64, ptr } %t814, 0
  %t817 = add i64 %t813, %t816
  %t818 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t819 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  %t820 = add i64 %t817, %t819
  %t821 = load { i64, ptr }, ptr %l340, !tbaa !27
  %t822 = extractvalue { i64, ptr } %t821, 1
  %t823 = extractvalue { i64, ptr } %t821, 0
  %t824 = add i64 %t820, %t823
  %t825 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d69, i32 0, i32 1) }, 1
  %t826 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d69, i32 0, i32 1) }, 0
  %t827 = add i64 %t824, %t826
  %t828 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t827)
  call void @olang_textcopy(ptr %t828, ptr %t812, i64 %t813)
  %t829 = getelementptr i8, ptr %t828, i64 %t813
  call void @olang_textcopy(ptr %t829, ptr %t815, i64 %t816)
  %t830 = getelementptr i8, ptr %t829, i64 %t816
  call void @olang_textcopy(ptr %t830, ptr %t818, i64 %t819)
  %t831 = getelementptr i8, ptr %t830, i64 %t819
  call void @olang_textcopy(ptr %t831, ptr %t822, i64 %t823)
  %t832 = getelementptr i8, ptr %t831, i64 %t823
  call void @olang_textcopy(ptr %t832, ptr %t825, i64 %t826)
  %t833 = insertvalue { i64, ptr } undef, i64 %t827, 0
  %t834 = insertvalue { i64, ptr } %t833, ptr %t828, 1
  %t836 = extractvalue { i64, ptr } %t834, 0
  %t837 = extractvalue { i64, ptr } %t834, 1
  %t838 = mul i64 %t836, 1
  %t839 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t838)
  call void @llvm.memcpy.p0.p0.i64(ptr %t839, ptr %t837, i64 %t838, i1 false)
  %t840 = insertvalue { i64, ptr } undef, i64 %t836, 0
  %t841 = insertvalue { i64, ptr } %t840, ptr %t839, 1
  %t842 = load ptr, ptr %l332, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s25, ptr %t842, { i64, ptr } %t841)
  br label %bb180
bb180:
  call void @__olang_scope_close(ptr %s25)
  br label %bb181
bb181:
  %t844 = load i64, ptr %l30, !tbaa !24
  %t846 = add i64 %t844, 1
  store i64 %t846, ptr %l30, !tbaa !24
  br label %bb119
bb182:
  %t849 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v3, ptr %l5)
  store { i64, ptr } %t849, ptr %l349
  br label %bb183
bb183:
  %t850 = load { i64, ptr }, ptr %l349, !tbaa !27
  store { i64, ptr } %t850, ptr %l350, !tbaa !27
  %t851 = load { i64, ptr }, ptr %l350, !tbaa !27
  %t852 = extractvalue { i64, ptr } %t851, 0
  store i64 %t852, ptr %l351, !tbaa !24
  %t853 = load i64, ptr %l351, !tbaa !24
  %t854 = mul i64 %t853, 1
  %t855 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t854)
  %t856 = insertvalue { i64, ptr } undef, i64 %t853, 0
  %t857 = insertvalue { i64, ptr } %t856, ptr %t855, 1
  store { i64, ptr } %t857, ptr %l352, !tbaa !27
  %t858 = getelementptr { i64, ptr }, ptr %l352, i32 0, i32 1
  %t859 = load ptr, ptr %t858, !tbaa !27
  %t860 = getelementptr { i64, ptr }, ptr %l350, i32 0, i32 1
  %t861 = load ptr, ptr %t860, !tbaa !27
  %t862 = load i64, ptr %l351, !tbaa !24
  %t863 = mul i64 %t862, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t859, ptr %t861, i64 %t863, i1 false)
  %t864 = load { i64, ptr }, ptr %l352, !tbaa !27
  store { i64, ptr } %t864, ptr %l350, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t865 = load { i64, ptr }, ptr %l350, !tbaa !27
  store { i64, ptr } %t865, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/profile:Places" @compiler_2fprofile_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %lp2 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca %"compiler/profile:Sample"
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l17 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca %"compiler/profile:mapping"
  %l26 = alloca i64
  %l27 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l35 = alloca %"std/prelude/text:StringBuilder"
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca %"std/os:Output"
  %l44 = alloca %"std/prelude/text:LineIter"
  %l46 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca { i64, ptr }
  %l57 = alloca { { i64, ptr }, i64 }
  %l58 = alloca { i64, ptr }
  %l59 = alloca i64
  %l60 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l61 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l62 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l64 = alloca %"compiler/profile:Places"
  %l67 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l68 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l69 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l72 = alloca i64
  %l74 = alloca i64
  %l79 = alloca %"compiler/profile:Sample"
  %l84 = alloca i64
  %l87 = alloca i64
  %l110 = alloca i64
  %l113 = alloca i64
  %l117 = alloca i1
  %l119 = alloca ptr
  %l120 = alloca i64
  %l122 = alloca i64
  %l129 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l130 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l132 = alloca i64
  %l134 = alloca i64
  %l139 = alloca i64
  %l140 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l142 = alloca i64
  %l143 = alloca { i64, ptr }
  %l145 = alloca i64
  %l147 = alloca i64
  %l152 = alloca %"compiler/profile:mapping"
  %l156 = alloca i1
  %l161 = alloca { i64, ptr }
  %l163 = alloca i64
  %l171 = alloca i1
  %l174 = alloca i1
  %l176 = alloca ptr
  %l179 = alloca { i64, ptr }
  %l181 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l182 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l185 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l186 = alloca i32
  %l187 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l189 = alloca i64
  %l193 = alloca i64
  %l196 = alloca i64
  %l214 = alloca i64
  %l217 = alloca i64
  %l219 = alloca i1
  %l220 = alloca i64
  %l223 = alloca i64
  %l227 = alloca i64
  %l230 = alloca i64
  %l233 = alloca i64
  %l234 = alloca i64
  %l238 = alloca i64
  %l252 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l254 = alloca i1
  %l256 = alloca %"std/prelude/text:StringBuilder"
  %l258 = alloca i64
  %l262 = alloca i64
  %l265 = alloca i64
  %l285 = alloca i64
  %l287 = alloca ptr
  %l290 = alloca { i64, ptr }
  %l293 = alloca i64
  %l294 = alloca i64
  %l295 = alloca i64
  %l296 = alloca i32
  %l297 = alloca { i64, ptr }
  %l306 = alloca %"std/os:Output"
  %l310 = alloca { i64, ptr }
  %l312 = alloca { i64, ptr }
  %l314 = alloca %"std/os:Output"
  %l315 = alloca i32
  %l317 = alloca i1
  %l318 = alloca %"std/os:Output"
  %l322 = alloca %"std/prelude/text:LineIter"
  %l323 = alloca { i64, ptr }
  %l325 = alloca { i64, ptr }
  %l326 = alloca i32
  %l328 = alloca i1
  %l333 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l335 = alloca i64
  %l339 = alloca i64
  %l342 = alloca i64
  %l360 = alloca ptr
  %l362 = alloca i64
  %l365 = alloca i64
  %l367 = alloca i1
  %l368 = alloca i64
  %l370 = alloca i64
  %l373 = alloca i64
  %l375 = alloca i64
  %l377 = alloca i1
  %l380 = alloca { i64, ptr }
  %l381 = alloca i1
  %l386 = alloca { i64, ptr }
  %l390 = alloca { i64, ptr }
  %l394 = alloca { { i64, ptr }, i64 }
  %l395 = alloca { i64, ptr }
  %l396 = alloca i64
  %l397 = alloca { i64, ptr }
  %l400 = alloca i1
  %l401 = alloca i1
  %l404 = alloca { i64, ptr }
  %l405 = alloca i1
  %l406 = alloca ptr
  %l409 = alloca { i64, ptr }
  %l410 = alloca i1
  %l412 = alloca ptr
  %l415 = alloca { i64, ptr }
  %l417 = alloca { i64, ptr }
  %l420 = alloca { i64, ptr }
  %l421 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l422 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l423 = alloca ptr
  %l426 = alloca { i64, ptr }
  %l427 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l428 = alloca i32
  %l429 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l430 = alloca ptr
  %l433 = alloca i64
  %l434 = alloca { i64, ptr }
  %l437 = alloca i1
  %l439 = alloca i1
  %l442 = alloca i64
  %l443 = alloca i64
  %l444 = alloca i64
  %l445 = alloca i32
  %l446 = alloca { i64, ptr }
  %l449 = alloca { i64, ptr }
  %l450 = alloca { i64, ptr }
  %l454 = alloca { i64, ptr }
  %l456 = alloca ptr
  %l459 = alloca i64
  %l462 = alloca i64
  %l464 = alloca %"compiler/profile:Frame"
  %l471 = alloca i1
  %l474 = alloca i64
  %l476 = alloca i1
  %l479 = alloca { i64, ptr }
  %l480 = alloca i1
  %l481 = alloca ptr
  %l484 = alloca { i64, ptr }
  %l485 = alloca i1
  %l487 = alloca ptr
  %l490 = alloca { i64, ptr }
  %l492 = alloca { i64, ptr }
  %l495 = alloca { i64, ptr }
  %l496 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l497 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l498 = alloca ptr
  %l501 = alloca { i64, ptr }
  %l502 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l503 = alloca i32
  %l504 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l505 = alloca ptr
  %l508 = alloca i64
  %l509 = alloca { i64, ptr }
  %l511 = alloca i1
  %l513 = alloca ptr
  %l514 = alloca ptr
  %l516 = alloca { i64, ptr }
  %l518 = alloca i64
  %l520 = alloca i64
  %l521 = alloca %"compiler/profile:Frame"
  %l526 = alloca { i64, ptr }
  %l527 = alloca i1
  %l529 = alloca { i64, ptr }
  %l532 = alloca { i64, ptr }
  %l533 = alloca { i64, ptr }
  %l534 = alloca ptr
  %l535 = alloca ptr
  %l538 = alloca i64
  %l539 = alloca i64
  %l540 = alloca i64
  %l541 = alloca i32
  %l542 = alloca { i64, ptr }
  %l546 = alloca i64
  %l548 = alloca i64
  %l549 = alloca %"compiler/profile:Frame"
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %s44 = alloca %olang.scope
  %s47 = alloca %olang.scope
  %s48 = alloca %olang.scope
  %s50 = alloca %olang.scope
  %s51 = alloca %olang.scope
  %rv = alloca %"compiler/profile:Places"
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/profile:Places" @compiler_2fprofile_3aPlaces_2ector(ptr %v2)
  store %"compiler/profile:Places" %t1, ptr %l64
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"compiler/profile:Places", ptr %l64
  %t4 = load ptr, ptr %lp2
  store %"compiler/profile:Places" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/profile:Profile", ptr %t5, i32 0, i32 5
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fprofile_2emappings(ptr %v0, ptr %s0, { i64, ptr } %t8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l67
  br label %bb2
bb2:
  %t11 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l67
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l3
  %t12 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_H672d76f1ccd7b9b901b64baf95956196(ptr %s0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l68
  br label %bb3
bb3:
  %t13 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l68
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l4
  %t14 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, ptr %l69
  br label %bb4
bb4:
  %t15 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l69
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %l5
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/profile:Profile", ptr %t16, i32 0, i32 3
  store ptr %t18, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb5
bb5:
  %t20 = load i64, ptr %l7, !tbaa !24
  store i64 %t20, ptr %l72, !tbaa !24
  %t21 = load ptr, ptr %l6, !tbaa !29
  %t23 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2eLen_3ccompiler_2fprofile_3aSample_3e(ptr %v0, ptr %t21)
  store i64 %t23, ptr %l74
  br label %bb6
bb6:
  %t24 = load i64, ptr %l72, !tbaa !24
  %t25 = load i64, ptr %l74, !tbaa !24
  %t26 = icmp slt i64 %t24, %t25
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb7, label %bb8
bb7:
  br label %bb35
bb8:
  br label %bb9
bb9:
  %t30 = load ptr, ptr %l6, !tbaa !29
  %t31 = load i64, ptr %l7, !tbaa !24
  %t34 = call %"compiler/profile:Sample" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2eAt_3ccompiler_2fprofile_3aSample_3e(ptr %v0, ptr %t30, i64 %t31)
  store %"compiler/profile:Sample" %t34, ptr %l79
  br label %bb10
bb10:
  %t35 = load %"compiler/profile:Sample", ptr %l79
  store %"compiler/profile:Sample" %t35, ptr %l8
  store i64 0, ptr %l9, !tbaa !24
  %t36 = getelementptr %"compiler/profile:Sample", ptr %l8, i32 0, i32 2
  %t37 = load i64, ptr %t36, !tbaa !24
  store i64 %t37, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t39 = load i64, ptr %l10, !tbaa !24
  %t40 = load i64, ptr %l9, !tbaa !24
  %t43 = icmp sgt i64 %t39, %t40
  br i1 %t43, label %bb11, label %bb12
bb11:
  %t45 = load i64, ptr %l11, !tbaa !24
  %t47 = icmp sgt i64 %t45, 0
  br i1 %t47, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l84, !tbaa !24
  br label %bb16
bb13:
  %t49 = load i64, ptr %l10, !tbaa !24
  %t50 = load i64, ptr %l9, !tbaa !24
  %t53 = sub i64 %t49, %t50
  %t54 = load i64, ptr %l11, !tbaa !24
  %t57 = add i64 %t53, %t54
  %t59 = sub i64 %t57, 1
  %t60 = load i64, ptr %l11, !tbaa !24
  %t63 = sdiv i64 %t59, %t60
  store i64 %t63, ptr %l87, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb15
bb15:
  %t65 = load i64, ptr %l87, !tbaa !24
  store i64 %t65, ptr %l84, !tbaa !24
  br label %bb16
bb16:
  %t66 = load i64, ptr %l84, !tbaa !24
  store i64 %t66, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb17
bb17:
  %t67 = load i64, ptr %l13, !tbaa !24
  %t68 = load i64, ptr %l12, !tbaa !24
  %t71 = icmp slt i64 %t67, %t68
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb18, label %bb19
bb18:
  br label %bb33
bb19:
  br label %bb20
bb20:
  %t75 = load i64, ptr %l9, !tbaa !24
  %t76 = load i64, ptr %l13, !tbaa !24
  %t77 = load i64, ptr %l11, !tbaa !24
  %t80 = mul i64 %t76, %t77
  %t83 = add i64 %t75, %t80
  store i64 %t83, ptr %l14, !tbaa !24
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/profile:Profile", ptr %t85, i32 0, i32 4
  %t88 = getelementptr %"compiler/profile:Sample", ptr %l8, i32 0, i32 1
  %t89 = load i64, ptr %t88, !tbaa !24
  %t90 = load i64, ptr %l14, !tbaa !24
  %t93 = add i64 %t89, %t90
  %t96 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t87, i64 %t93)
  store i64 %t96, ptr %l110
  br label %bb21
bb21:
  %t97 = load i64, ptr %l14, !tbaa !24
  %t99 = icmp eq i64 %t97, 0
  br i1 %t99, label %bb22, label %bb23
bb22:
  store i64 0, ptr %l113, !tbaa !24
  br label %bb24
bb23:
  store i64 1, ptr %l113, !tbaa !24
  br label %bb24
bb24:
  %t101 = load i64, ptr %l110, !tbaa !24
  %t102 = load i64, ptr %l113, !tbaa !24
  %t103 = sub i64 %t101, %t102
  store i64 %t103, ptr %l15, !tbaa !24
  %t105 = load ptr, ptr %lp2
  %t106 = getelementptr %"compiler/profile:Places", ptr %t105, i32 0, i32 5
  %t107 = load i64, ptr %l15, !tbaa !24
  %t110 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v2, ptr %t106, i64 %t107)
  store i1 %t110, ptr %l117
  br label %bb25
bb25:
  %t111 = load i1, ptr %l117, !tbaa !21
  %t112 = xor i1 %t111, true
  br i1 %t112, label %bb26, label %bb27
bb26:
  %t114 = load ptr, ptr %lp2
  %t115 = getelementptr %"compiler/profile:Places", ptr %t114, i32 0, i32 5
  store ptr %t115, ptr %l119, !tbaa !29
  %t116 = load i64, ptr %l15, !tbaa !24
  store i64 %t116, ptr %l120, !tbaa !24
  %t118 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l5)
  store i64 %t118, ptr %l122
  br label %bb28
bb27:
  br label %bb31
bb28:
  %t119 = load ptr, ptr %l119, !tbaa !29
  %t120 = load i64, ptr %l120, !tbaa !24
  %t121 = load i64, ptr %l122, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v2, ptr %t119, i64 %t120, i64 %t121)
  br label %bb29
bb29:
  %t122 = load i64, ptr %l15, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l5, i64 %t122)
  br label %bb30
bb30:
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t125 = load i64, ptr %l13, !tbaa !24
  %t127 = add i64 %t125, 1
  store i64 %t127, ptr %l13, !tbaa !24
  br label %bb17
bb33:
  br label %bb34
bb34:
  %t129 = load i64, ptr %l7, !tbaa !24
  %t131 = add i64 %t129, 1
  store i64 %t131, ptr %l7, !tbaa !24
  br label %bb5
bb35:
  %t133 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t133, ptr %l129
  br label %bb36
bb36:
  %t134 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l129
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t134, ptr %l16
  %t135 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t135, ptr %l130
  br label %bb37
bb37:
  %t136 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l130
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t136, ptr %l17
  store ptr %l5, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s9
  %t138 = load i64, ptr %l19, !tbaa !24
  store i64 %t138, ptr %l132, !tbaa !24
  %t139 = load ptr, ptr %l18, !tbaa !29
  %t141 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t139)
  store i64 %t141, ptr %l134
  br label %bb39
bb39:
  %t142 = load i64, ptr %l132, !tbaa !24
  %t143 = load i64, ptr %l134, !tbaa !24
  %t144 = icmp slt i64 %t142, %t143
  %t146 = xor i1 %t144, true
  br i1 %t146, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s9)
  br label %bb103
bb41:
  br label %bb42
bb42:
  %t148 = load ptr, ptr %l18, !tbaa !29
  %t149 = load i64, ptr %l19, !tbaa !24
  %t152 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t148, i64 %t149)
  store i64 %t152, ptr %l139
  br label %bb43
bb43:
  %t153 = load i64, ptr %l139, !tbaa !24
  store i64 %t153, ptr %l20, !tbaa !24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d70, i32 0, i32 1) }, ptr %l140, !tbaa !27
  %t154 = load { i64, ptr }, ptr %l140, !tbaa !27
  store { i64, ptr } %t154, ptr %l141, !tbaa !27
  %t155 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t155, 0
  store i64 %t156, ptr %l142, !tbaa !24
  %t157 = load i64, ptr %l142, !tbaa !24
  %t158 = mul i64 %t157, 1
  %t159 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t158)
  %t160 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t161 = insertvalue { i64, ptr } %t160, ptr %t159, 1
  store { i64, ptr } %t161, ptr %l143, !tbaa !27
  %t162 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !27
  %t164 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !27
  %t166 = load i64, ptr %l142, !tbaa !24
  %t167 = mul i64 %t166, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t163, ptr %t165, i64 %t167, i1 false)
  %t168 = load { i64, ptr }, ptr %l143, !tbaa !27
  store { i64, ptr } %t168, ptr %l21, !tbaa !27
  store i64 -1, ptr %l22, !tbaa !24
  store ptr %l3, ptr %l23, !tbaa !29
  store i64 0, ptr %l24, !tbaa !24
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s11
  %t170 = load i64, ptr %l24, !tbaa !24
  store i64 %t170, ptr %l145, !tbaa !24
  %t171 = load ptr, ptr %l23, !tbaa !29
  %t173 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3amapping_3e_2eLen__Heb6545c4cbf57678e5e8a74f397c9583(ptr %s0, ptr %t171)
  store i64 %t173, ptr %l147
  br label %bb45
bb45:
  %t174 = load i64, ptr %l145, !tbaa !24
  %t175 = load i64, ptr %l147, !tbaa !24
  %t176 = icmp slt i64 %t174, %t175
  %t178 = xor i1 %t176, true
  br i1 %t178, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s11)
  br label %bb99
bb47:
  br label %bb48
bb48:
  %t180 = load ptr, ptr %l23, !tbaa !29
  %t181 = load i64, ptr %l24, !tbaa !24
  %t184 = call %"compiler/profile:mapping" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3amapping_3e_2eAt_3ccompiler_2fprofile_3amapping_3e(ptr %s0, ptr %s0, ptr %t180, i64 %t181)
  store %"compiler/profile:mapping" %t184, ptr %l152
  br label %bb49
bb49:
  %t185 = load %"compiler/profile:mapping", ptr %l152
  store %"compiler/profile:mapping" %t185, ptr %l25
  %t186 = load i64, ptr %l20, !tbaa !24
  %t187 = getelementptr %"compiler/profile:mapping", ptr %l25, i32 0, i32 0
  %t188 = load i64, ptr %t187, !tbaa !24
  %t191 = icmp slt i64 %t186, %t188
  br i1 %t191, label %bb50, label %bb51
bb50:
  store i1 true, ptr %l156, !tbaa !21
  br label %bb52
bb51:
  %t193 = load i64, ptr %l20, !tbaa !24
  %t194 = getelementptr %"compiler/profile:mapping", ptr %l25, i32 0, i32 1
  %t195 = load i64, ptr %t194, !tbaa !24
  %t198 = icmp sge i64 %t193, %t195
  store i1 %t198, ptr %l156, !tbaa !21
  br label %bb52
bb52:
  %t200 = load i1, ptr %l156, !tbaa !21
  br i1 %t200, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s11)
  br label %bb98
bb54:
  br label %bb55
bb55:
  %t201 = getelementptr %"compiler/profile:mapping", ptr %l25, i32 0, i32 3
  %t202 = load { i64, ptr }, ptr %t201, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t202, 1
  %t205 = extractvalue { i64, ptr } %t202, 0
  %t206 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t205)
  call void @olang_textcopy(ptr %t206, ptr %t204, i64 %t205)
  %t207 = insertvalue { i64, ptr } undef, i64 %t205, 0
  %t208 = insertvalue { i64, ptr } %t207, ptr %t206, 1
  store { i64, ptr } %t208, ptr %l161, !tbaa !27
  %t209 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t210 = extractvalue { i64, ptr } %t209, 0
  %t211 = load { i64, ptr }, ptr %l161, !tbaa !27
  %t212 = extractvalue { i64, ptr } %t211, 0
  store i64 %t212, ptr %l163, !tbaa !24
  %t214 = load i64, ptr %l163, !tbaa !24
  %t215 = icmp eq i64 %t210, %t214
  br i1 %t215, label %bb56, label %bb57
bb56:
  %t217 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !27
  %t219 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t220 = load ptr, ptr %t219, !tbaa !27
  %t221 = load i64, ptr %l163, !tbaa !24
  %t222 = mul i64 %t221, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t218, ptr %t220, i64 %t222, i1 false)
  br label %bb58
bb57:
  %t223 = load { i64, ptr }, ptr %l161, !tbaa !27
  store { i64, ptr } %t223, ptr %l21, !tbaa !27
  br label %bb58
bb58:
  %t224 = load i64, ptr %l20, !tbaa !24
  %t225 = getelementptr %"compiler/profile:mapping", ptr %l25, i32 0, i32 0
  %t226 = load i64, ptr %t225, !tbaa !24
  %t229 = sub i64 %t224, %t226
  %t230 = getelementptr %"compiler/profile:mapping", ptr %l25, i32 0, i32 2
  %t231 = load i64, ptr %t230, !tbaa !24
  %t234 = add i64 %t229, %t231
  store i64 %t234, ptr %l26, !tbaa !24
  %t236 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t238 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s9, ptr %s11, { i64, ptr } %t236, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d71, i32 0, i32 1) })
  store i1 %t238, ptr %l171
  br label %bb59
bb59:
  %t239 = load i1, ptr %l171, !tbaa !21
  br i1 %t239, label %bb60, label %bb61
bb60:
  %t240 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t243 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H67bc384d82ac3ceb3fdc5d6d25b5f02a(ptr %s0, ptr %s9, ptr %l4, { i64, ptr } %t240)
  store i1 %t243, ptr %l174
  br label %bb62
bb61:
  br label %bb97
bb62:
  %t244 = load i1, ptr %l174, !tbaa !21
  %t245 = xor i1 %t244, true
  br i1 %t245, label %bb63, label %bb64
bb63:
  store ptr %l4, ptr %l176, !tbaa !29
  %t247 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t249 = extractvalue { i64, ptr } %t247, 1
  %t250 = extractvalue { i64, ptr } %t247, 0
  %t251 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t250)
  call void @olang_textcopy(ptr %t251, ptr %t249, i64 %t250)
  %t252 = insertvalue { i64, ptr } undef, i64 %t250, 0
  %t253 = insertvalue { i64, ptr } %t252, ptr %t251, 1
  %t255 = extractvalue { i64, ptr } %t253, 0
  %t256 = extractvalue { i64, ptr } %t253, 1
  %t257 = mul i64 %t255, 1
  %t258 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t257)
  call void @llvm.memcpy.p0.p0.i64(ptr %t258, ptr %t256, i64 %t257, i1 false)
  %t259 = insertvalue { i64, ptr } undef, i64 %t255, 0
  %t260 = insertvalue { i64, ptr } %t259, ptr %t258, 1
  store { i64, ptr } %t260, ptr %l179, !tbaa !27
  %t261 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t263 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fprofile_2esegments(ptr %s9, ptr %s0, { i64, ptr } %t261)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t263, ptr %l181
  br label %bb65
bb64:
  br label %bb67
bb65:
  %t264 = load ptr, ptr %l176, !tbaa !29
  %t265 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t266 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l181
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Hd2a6d6393d72da4a22d0070783b9e545(ptr %s0, ptr %s0, ptr %s0, ptr %t264, { i64, ptr } %t265, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t266)
  br label %bb66
bb66:
  br label %bb67
bb67:
  %t267 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t270 = call { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H319c0ff6422dd1c7d243d7553286ad0b(ptr %s0, ptr %s9, ptr %s0, ptr %l4, { i64, ptr } %t267)
  %t271 = extractvalue { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } %t270, 1
  %t272 = extractvalue { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } %t270, 0
  store i32 %t272, ptr %l186
  %t273 = icmp ne i32 %t272, 0
  br i1 %t273, label %bb69, label %ok.274, !prof !99
ok.274:
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t271, ptr %l185
  br label %bb68
bb68:
  %t275 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l185
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t275, ptr %l182
  br label %bb72
bb69:
  br label %bb70
bb70:
  call void @__olang_ert_req_clear()
  %t276 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t276, ptr %l187
  br label %bb71
bb71:
  %t277 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l187
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t277, ptr %l182
  br label %bb72
bb72:
  %t278 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l182
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t278, ptr %l27
  store i64 0, ptr %l28, !tbaa !24
  %t280 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l27)
  store i64 %t280, ptr %l189
  br label %bb73
bb73:
  %t281 = load i64, ptr %l189, !tbaa !24
  store i64 %t281, ptr %l29, !tbaa !24
  store i64 3, ptr %l30, !tbaa !24
  %t282 = load i64, ptr %l29, !tbaa !24
  %t283 = load i64, ptr %l28, !tbaa !24
  %t286 = icmp sgt i64 %t282, %t283
  br i1 %t286, label %bb74, label %bb75
bb74:
  %t288 = load i64, ptr %l30, !tbaa !24
  %t290 = icmp sgt i64 %t288, 0
  br i1 %t290, label %bb76, label %bb77
bb75:
  store i64 0, ptr %l193, !tbaa !24
  br label %bb79
bb76:
  %t292 = load i64, ptr %l29, !tbaa !24
  %t293 = load i64, ptr %l28, !tbaa !24
  %t296 = sub i64 %t292, %t293
  %t297 = load i64, ptr %l30, !tbaa !24
  %t300 = add i64 %t296, %t297
  %t302 = sub i64 %t300, 1
  %t303 = load i64, ptr %l30, !tbaa !24
  %t306 = sdiv i64 %t302, %t303
  store i64 %t306, ptr %l196, !tbaa !24
  br label %bb78
bb77:
  store i64 0, ptr %l196, !tbaa !24
  br label %bb78
bb78:
  %t308 = load i64, ptr %l196, !tbaa !24
  store i64 %t308, ptr %l193, !tbaa !24
  br label %bb79
bb79:
  %t309 = load i64, ptr %l193, !tbaa !24
  store i64 %t309, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  br label %bb80
bb80:
  %t310 = load i64, ptr %l32, !tbaa !24
  %t311 = load i64, ptr %l31, !tbaa !24
  %t314 = icmp slt i64 %t310, %t311
  %t316 = xor i1 %t314, true
  br i1 %t316, label %bb81, label %bb82
bb81:
  br label %bb96
bb82:
  br label %bb83
bb83:
  %t318 = load i64, ptr %l28, !tbaa !24
  %t319 = load i64, ptr %l32, !tbaa !24
  %t320 = load i64, ptr %l30, !tbaa !24
  %t323 = mul i64 %t319, %t320
  %t326 = add i64 %t318, %t323
  store i64 %t326, ptr %l33, !tbaa !24
  %t328 = load i64, ptr %l26, !tbaa !24
  store i64 %t328, ptr %l214, !tbaa !24
  %t329 = load i64, ptr %l33, !tbaa !24
  %t332 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l27, i64 %t329)
  store i64 %t332, ptr %l217
  br label %bb84
bb84:
  %t333 = load i64, ptr %l214, !tbaa !24
  %t334 = load i64, ptr %l217, !tbaa !24
  %t335 = icmp sge i64 %t333, %t334
  br i1 %t335, label %bb85, label %bb86
bb85:
  %t337 = load i64, ptr %l26, !tbaa !24
  store i64 %t337, ptr %l220, !tbaa !24
  %t338 = load i64, ptr %l33, !tbaa !24
  %t341 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l27, i64 %t338)
  store i64 %t341, ptr %l223
  br label %bb87
bb86:
  store i1 false, ptr %l219, !tbaa !21
  br label %bb89
bb87:
  %t342 = load i64, ptr %l33, !tbaa !24
  %t344 = add i64 %t342, 1
  %t347 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l27, i64 %t344)
  store i64 %t347, ptr %l227
  br label %bb88
bb88:
  %t348 = load i64, ptr %l223, !tbaa !24
  %t349 = load i64, ptr %l227, !tbaa !24
  %t350 = add i64 %t348, %t349
  %t351 = load i64, ptr %l220, !tbaa !24
  %t353 = icmp slt i64 %t351, %t350
  store i1 %t353, ptr %l219, !tbaa !21
  br label %bb89
bb89:
  %t355 = load i1, ptr %l219, !tbaa !21
  br i1 %t355, label %bb90, label %bb91
bb90:
  %t356 = load i64, ptr %l26, !tbaa !24
  store i64 %t356, ptr %l230, !tbaa !24
  %t357 = load i64, ptr %l33, !tbaa !24
  %t360 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l27, i64 %t357)
  store i64 %t360, ptr %l233
  br label %bb92
bb91:
  br label %bb94
bb92:
  %t361 = load i64, ptr %l230, !tbaa !24
  %t362 = load i64, ptr %l233, !tbaa !24
  %t363 = sub i64 %t361, %t362
  store i64 %t363, ptr %l234, !tbaa !24
  %t364 = load i64, ptr %l33, !tbaa !24
  %t366 = add i64 %t364, 2
  %t369 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l27, i64 %t366)
  store i64 %t369, ptr %l238
  br label %bb93
bb93:
  %t370 = load i64, ptr %l234, !tbaa !24
  %t371 = load i64, ptr %l238, !tbaa !24
  %t372 = add i64 %t370, %t371
  store i64 %t372, ptr %l22, !tbaa !24
  br label %bb94
bb94:
  br label %bb95
bb95:
  %t374 = load i64, ptr %l32, !tbaa !24
  %t376 = add i64 %t374, 1
  store i64 %t376, ptr %l32, !tbaa !24
  br label %bb80
bb96:
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s11)
  br label %bb99
bb98:
  %t378 = load i64, ptr %l24, !tbaa !24
  %t380 = add i64 %t378, 1
  store i64 %t380, ptr %l24, !tbaa !24
  br label %bb44
bb99:
  %t382 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t384 = extractvalue { i64, ptr } %t382, 1
  %t385 = extractvalue { i64, ptr } %t382, 0
  %t386 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t385)
  call void @olang_textcopy(ptr %t386, ptr %t384, i64 %t385)
  %t387 = insertvalue { i64, ptr } undef, i64 %t385, 0
  %t388 = insertvalue { i64, ptr } %t387, ptr %t386, 1
  %t390 = extractvalue { i64, ptr } %t388, 0
  %t391 = extractvalue { i64, ptr } %t388, 1
  %t392 = mul i64 %t390, 1
  %t393 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t392)
  call void @llvm.memcpy.p0.p0.i64(ptr %t393, ptr %t391, i64 %t392, i1 false)
  %t394 = insertvalue { i64, ptr } undef, i64 %t390, 0
  %t395 = insertvalue { i64, ptr } %t394, ptr %t393, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l16, { i64, ptr } %t395)
  br label %bb100
bb100:
  %t398 = load i64, ptr %l22, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l17, i64 %t398)
  br label %bb101
bb101:
  call void @__olang_scope_close(ptr %s9)
  br label %bb102
bb102:
  %t401 = load i64, ptr %l19, !tbaa !24
  %t403 = add i64 %t401, 1
  store i64 %t403, ptr %l19, !tbaa !24
  br label %bb38
bb103:
  %t405 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t405, ptr %l252
  br label %bb104
bb104:
  %t406 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l252
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t406, ptr %l34
  %t407 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t409 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t407, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d72, i32 0, i32 1) })
  store i1 %t409, ptr %l254
  br label %bb105
bb105:
  %t410 = load i1, ptr %l254, !tbaa !21
  %t411 = xor i1 %t410, true
  br i1 %t411, label %bb106, label %bb107
bb106:
  store %olang.scope zeroinitializer, ptr %s24
  %t413 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s24)
  store %"std/prelude/text:StringBuilder" %t413, ptr %l256
  br label %bb108
bb107:
  br label %bb153
bb108:
  %t414 = load %"std/prelude/text:StringBuilder", ptr %l256
  store %"std/prelude/text:StringBuilder" %t414, ptr %l35
  store i64 0, ptr %l36, !tbaa !24
  store i64 0, ptr %l37, !tbaa !24
  %t416 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l5)
  store i64 %t416, ptr %l258
  br label %bb109
bb109:
  %t417 = load i64, ptr %l258, !tbaa !24
  store i64 %t417, ptr %l38, !tbaa !24
  store i64 1, ptr %l39, !tbaa !24
  %t418 = load i64, ptr %l38, !tbaa !24
  %t419 = load i64, ptr %l37, !tbaa !24
  %t422 = icmp sgt i64 %t418, %t419
  br i1 %t422, label %bb110, label %bb111
bb110:
  %t424 = load i64, ptr %l39, !tbaa !24
  %t426 = icmp sgt i64 %t424, 0
  br i1 %t426, label %bb112, label %bb113
bb111:
  store i64 0, ptr %l262, !tbaa !24
  br label %bb115
bb112:
  %t428 = load i64, ptr %l38, !tbaa !24
  %t429 = load i64, ptr %l37, !tbaa !24
  %t432 = sub i64 %t428, %t429
  %t433 = load i64, ptr %l39, !tbaa !24
  %t436 = add i64 %t432, %t433
  %t438 = sub i64 %t436, 1
  %t439 = load i64, ptr %l39, !tbaa !24
  %t442 = sdiv i64 %t438, %t439
  store i64 %t442, ptr %l265, !tbaa !24
  br label %bb114
bb113:
  store i64 0, ptr %l265, !tbaa !24
  br label %bb114
bb114:
  %t444 = load i64, ptr %l265, !tbaa !24
  store i64 %t444, ptr %l262, !tbaa !24
  br label %bb115
bb115:
  %t445 = load i64, ptr %l262, !tbaa !24
  store i64 %t445, ptr %l40, !tbaa !24
  store i64 0, ptr %l41, !tbaa !24
  br label %bb116
bb116:
  store %olang.scope zeroinitializer, ptr %s26
  %t446 = load i64, ptr %l41, !tbaa !24
  %t447 = load i64, ptr %l40, !tbaa !24
  %t450 = icmp slt i64 %t446, %t447
  %t452 = xor i1 %t450, true
  br i1 %t452, label %bb117, label %bb118
bb117:
  call void @__olang_scope_close(ptr %s26)
  br label %bb131
bb118:
  br label %bb119
bb119:
  %t454 = load i64, ptr %l37, !tbaa !24
  %t455 = load i64, ptr %l41, !tbaa !24
  %t456 = load i64, ptr %l39, !tbaa !24
  %t459 = mul i64 %t455, %t456
  %t462 = add i64 %t454, %t459
  store i64 %t462, ptr %l42, !tbaa !24
  %t464 = load i64, ptr %l42, !tbaa !24
  %t467 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l17, i64 %t464)
  store i64 %t467, ptr %l285
  br label %bb120
bb120:
  %t468 = load i64, ptr %l285, !tbaa !24
  %t469 = icmp slt i64 %t468, 0
  br i1 %t469, label %bb121, label %bb122
bb121:
  call void @__olang_scope_close(ptr %s26)
  br label %bb130
bb122:
  br label %bb123
bb123:
  store ptr %l35, ptr %l287, !tbaa !29
  %t471 = load i64, ptr %l42, !tbaa !24
  %t474 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s26, ptr %l16, i64 %t471)
  store { i64, ptr } %t474, ptr %l290
  br label %bb124
bb124:
  %t475 = load i64, ptr %l42, !tbaa !24
  %t478 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l17, i64 %t475)
  store i64 %t478, ptr %l293
  br label %bb125
bb125:
  %t479 = load i64, ptr %l293, !tbaa !24
  store i64 %t479, ptr %l294, !tbaa !65
  %t480 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s26, i64 16)
  %t481 = extractvalue { i32, i64 } %t480, 1
  %t482 = extractvalue { i32, i64 } %t480, 0
  store i32 %t482, ptr %l296
  %t483 = icmp ne i32 %t482, 0
  br i1 %t483, label %bb127, label %ok.484, !prof !99
ok.484:
  store i64 %t481, ptr %l295
  br label %bb126
bb126:
  %t485 = load i64, ptr %l294, !tbaa !65
  %t486 = load i64, ptr %l295, !tbaa !24
  %t487 = call { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %s26, i64 %t485, i64 %t486)
  store { i64, ptr } %t487, ptr %l297
  br label %bb128
bb127:
  call void @__olang_check_failed(ptr @olang_loc_d50f4fab691edd32_66973f8664df657e)
  unreachable
bb128:
  %t488 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t489 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  %t490 = load { i64, ptr }, ptr %l290, !tbaa !27
  %t491 = extractvalue { i64, ptr } %t490, 1
  %t492 = extractvalue { i64, ptr } %t490, 0
  %t493 = add i64 %t489, %t492
  %t494 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t495 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t496 = add i64 %t493, %t495
  %t497 = load { i64, ptr }, ptr %l297, !tbaa !27
  %t498 = extractvalue { i64, ptr } %t497, 1
  %t499 = extractvalue { i64, ptr } %t497, 0
  %t500 = add i64 %t496, %t499
  %t501 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d75, i32 0, i32 1) }, 1
  %t502 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d75, i32 0, i32 1) }, 0
  %t503 = add i64 %t500, %t502
  %t504 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t503)
  call void @olang_textcopy(ptr %t504, ptr %t488, i64 %t489)
  %t505 = getelementptr i8, ptr %t504, i64 %t489
  call void @olang_textcopy(ptr %t505, ptr %t491, i64 %t492)
  %t506 = getelementptr i8, ptr %t505, i64 %t492
  call void @olang_textcopy(ptr %t506, ptr %t494, i64 %t495)
  %t507 = getelementptr i8, ptr %t506, i64 %t495
  call void @olang_textcopy(ptr %t507, ptr %t498, i64 %t499)
  %t508 = getelementptr i8, ptr %t507, i64 %t499
  call void @olang_textcopy(ptr %t508, ptr %t501, i64 %t502)
  %t509 = insertvalue { i64, ptr } undef, i64 %t503, 0
  %t510 = insertvalue { i64, ptr } %t509, ptr %t504, 1
  %t512 = extractvalue { i64, ptr } %t510, 0
  %t513 = extractvalue { i64, ptr } %t510, 1
  %t514 = mul i64 %t512, 1
  %t515 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t514)
  call void @llvm.memcpy.p0.p0.i64(ptr %t515, ptr %t513, i64 %t514, i1 false)
  %t516 = insertvalue { i64, ptr } undef, i64 %t512, 0
  %t517 = insertvalue { i64, ptr } %t516, ptr %t515, 1
  %t518 = load ptr, ptr %l287, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s24, ptr %s26, ptr %t518, { i64, ptr } %t517)
  br label %bb129
bb129:
  %t520 = load i64, ptr %l36, !tbaa !24
  %t522 = add i64 %t520, 1
  store i64 %t522, ptr %l36, !tbaa !24
  call void @__olang_scope_close(ptr %s26)
  br label %bb130
bb130:
  %t524 = load i64, ptr %l41, !tbaa !24
  %t526 = add i64 %t524, 1
  store i64 %t526, ptr %l41, !tbaa !24
  br label %bb116
bb131:
  %t528 = load i64, ptr %l36, !tbaa !24
  %t530 = icmp sgt i64 %t528, 0
  br i1 %t530, label %bb132, label %bb133
bb132:
  store %olang.scope zeroinitializer, ptr %s30
  %t532 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t534 = extractvalue { i64, ptr } %t532, 1
  %t535 = extractvalue { i64, ptr } %t532, 0
  %t536 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t535)
  call void @olang_textcopy(ptr %t536, ptr %t534, i64 %t535)
  %t537 = insertvalue { i64, ptr } undef, i64 %t535, 0
  %t538 = insertvalue { i64, ptr } %t537, ptr %t536, 1
  %t540 = extractvalue { i64, ptr } %t538, 0
  %t541 = extractvalue { i64, ptr } %t538, 1
  %t542 = mul i64 %t540, 1
  %t543 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t542)
  call void @llvm.memcpy.p0.p0.i64(ptr %t543, ptr %t541, i64 %t542, i1 false)
  %t544 = insertvalue { i64, ptr } undef, i64 %t540, 0
  %t545 = insertvalue { i64, ptr } %t544, ptr %t543, 1
  %t546 = mul i64 3, 16
  %t547 = call ptr @__olang_scope_alloc_zeroed(ptr %s30, i64 %t546)
  %t548 = insertvalue { i64, ptr } undef, i64 3, 0
  %t549 = insertvalue { i64, ptr } %t548, ptr %t547, 1
  store { i64, ptr } %t549, ptr %l310, !tbaa !27
  %t551 = getelementptr { i64, ptr }, ptr %l310, i32 0, i32 1
  %t552 = load ptr, ptr %t551, !tbaa !27
  %t553 = getelementptr { i64, ptr }, ptr %t552, i64 0
  store { i64, ptr } %t545, ptr %t553, !tbaa !37
  %t554 = getelementptr { i64, ptr }, ptr %l310, i32 0, i32 1
  %t555 = load ptr, ptr %t554, !tbaa !27
  %t556 = getelementptr { i64, ptr }, ptr %t555, i64 1
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d76, i32 0, i32 1) }, ptr %t556, !tbaa !37
  %t557 = getelementptr { i64, ptr }, ptr %l310, i32 0, i32 1
  %t558 = load ptr, ptr %t557, !tbaa !27
  %t559 = getelementptr { i64, ptr }, ptr %t558, i64 2
  store { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d77, i32 0, i32 1) }, ptr %t559, !tbaa !37
  %t561 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s24, ptr %s30, ptr %l35)
  store { i64, ptr } %t561, ptr %l312
  br label %bb134
bb133:
  br label %bb152
bb134:
  %t562 = load { i64, ptr }, ptr %l312, !tbaa !27
  %t563 = load { i64, ptr }, ptr %l310, !tbaa !27
  %t565 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s30, ptr %s30, ptr %s30, ptr %s30, { i64, ptr } %t563, { i64, ptr } %t562, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d78, i32 0, i32 1) })
  %t566 = extractvalue { i32, %"std/os:Output" } %t565, 1
  %t567 = extractvalue { i32, %"std/os:Output" } %t565, 0
  store i32 %t567, ptr %l315
  %t568 = icmp ne i32 %t567, 0
  br i1 %t568, label %bb136, label %ok.569, !prof !99
ok.569:
  store %"std/os:Output" %t566, ptr %l314
  br label %bb135
bb135:
  %t570 = load %"std/os:Output", ptr %l314
  store %"std/os:Output" %t570, ptr %l306
  br label %bb139
bb136:
  %t571 = load i32, ptr %l315, !tbaa !23
  %t572 = ashr i32 %t571, 16
  %t574 = icmp eq i32 %t572, 1
  store i1 %t574, ptr %l317, !tbaa !21
  br label %bb137
bb137:
  call void @__olang_ert_req_clear()
  %t575 = call %"std/os:Output" @std_2fos_3aOutput_2ector(ptr %s30, ptr %s30, ptr %s30, i32 1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d79, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d80, i32 0, i32 1) })
  store %"std/os:Output" %t575, ptr %l318
  br label %bb138
bb138:
  %t576 = load %"std/os:Output", ptr %l318
  store %"std/os:Output" %t576, ptr %l306
  br label %bb139
bb139:
  %t577 = load %"std/os:Output", ptr %l306
  store %"std/os:Output" %t577, ptr %l43
  %t578 = getelementptr %"std/os:Output", ptr %l43, i32 0, i32 0
  %t579 = load i32, ptr %t578, !tbaa !23
  %t581 = icmp eq i32 %t579, 0
  br i1 %t581, label %bb140, label %bb141
bb140:
  %t583 = getelementptr %"std/os:Output", ptr %l43, i32 0, i32 1
  %t584 = load { i64, ptr }, ptr %t583, !tbaa !27
  %t586 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %s30, ptr %s30, { i64, ptr } %t584)
  store %"std/prelude/text:LineIter" %t586, ptr %l322
  br label %bb142
bb141:
  br label %bb151
bb142:
  %t587 = load %"std/prelude/text:LineIter", ptr %l322
  store %"std/prelude/text:LineIter" %t587, ptr %l44
  br label %bb143
bb143:
  %t589 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %s30, ptr %l44)
  %t590 = extractvalue { i32, { i64, ptr } } %t589, 1
  %t591 = extractvalue { i32, { i64, ptr } } %t589, 0
  store i32 %t591, ptr %l326
  %t592 = icmp ne i32 %t591, 0
  br i1 %t592, label %bb145, label %ok.593, !prof !99
ok.593:
  store { i64, ptr } %t590, ptr %l325
  br label %bb144
bb144:
  %t594 = load { i64, ptr }, ptr %l325, !tbaa !27
  store { i64, ptr } %t594, ptr %l323, !tbaa !27
  br label %bb147
bb145:
  %t595 = load i32, ptr %l326, !tbaa !23
  %t596 = ashr i32 %t595, 16
  %t598 = icmp eq i32 %t596, 1
  store i1 %t598, ptr %l328, !tbaa !21
  br label %bb146
bb146:
  call void @__olang_ert_req_clear()
  br label %bb150
bb147:
  %t599 = load { i64, ptr }, ptr %l323, !tbaa !27
  %t602 = extractvalue { i64, ptr } %t599, 1
  %t603 = extractvalue { i64, ptr } %t599, 0
  %t604 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t603)
  call void @olang_textcopy(ptr %t604, ptr %t602, i64 %t603)
  %t605 = insertvalue { i64, ptr } undef, i64 %t603, 0
  %t606 = insertvalue { i64, ptr } %t605, ptr %t604, 1
  %t608 = extractvalue { i64, ptr } %t606, 0
  %t609 = extractvalue { i64, ptr } %t606, 1
  %t610 = mul i64 %t608, 1
  %t611 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t610)
  call void @llvm.memcpy.p0.p0.i64(ptr %t611, ptr %t609, i64 %t610, i1 false)
  %t612 = insertvalue { i64, ptr } undef, i64 %t608, 0
  %t613 = insertvalue { i64, ptr } %t612, ptr %t611, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l34, { i64, ptr } %t613)
  br label %bb148
bb148:
  br label %bb149
bb149:
  br label %bb143
bb150:
  br label %bb151
bb151:
  call void @__olang_scope_close(ptr %s30)
  br label %bb152
bb152:
  call void @__olang_scope_close(ptr %s24)
  br label %bb153
bb153:
  %t616 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_H85afd28815ee4de4ef19d4ccaecd867e(ptr %s0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t616, ptr %l333
  br label %bb154
bb154:
  %t617 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l333
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t617, ptr %l46
  store i64 0, ptr %l47, !tbaa !24
  store i64 0, ptr %l48, !tbaa !24
  %t619 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l5)
  store i64 %t619, ptr %l335
  br label %bb155
bb155:
  %t620 = load i64, ptr %l335, !tbaa !24
  store i64 %t620, ptr %l49, !tbaa !24
  store i64 1, ptr %l50, !tbaa !24
  %t621 = load i64, ptr %l49, !tbaa !24
  %t622 = load i64, ptr %l48, !tbaa !24
  %t625 = icmp sgt i64 %t621, %t622
  br i1 %t625, label %bb156, label %bb157
bb156:
  %t627 = load i64, ptr %l50, !tbaa !24
  %t629 = icmp sgt i64 %t627, 0
  br i1 %t629, label %bb158, label %bb159
bb157:
  store i64 0, ptr %l339, !tbaa !24
  br label %bb161
bb158:
  %t631 = load i64, ptr %l49, !tbaa !24
  %t632 = load i64, ptr %l48, !tbaa !24
  %t635 = sub i64 %t631, %t632
  %t636 = load i64, ptr %l50, !tbaa !24
  %t639 = add i64 %t635, %t636
  %t641 = sub i64 %t639, 1
  %t642 = load i64, ptr %l50, !tbaa !24
  %t645 = sdiv i64 %t641, %t642
  store i64 %t645, ptr %l342, !tbaa !24
  br label %bb160
bb159:
  store i64 0, ptr %l342, !tbaa !24
  br label %bb160
bb160:
  %t647 = load i64, ptr %l342, !tbaa !24
  store i64 %t647, ptr %l339, !tbaa !24
  br label %bb161
bb161:
  %t648 = load i64, ptr %l339, !tbaa !24
  store i64 %t648, ptr %l51, !tbaa !24
  store i64 0, ptr %l52, !tbaa !24
  br label %bb162
bb162:
  store %olang.scope zeroinitializer, ptr %s37
  %t649 = load i64, ptr %l52, !tbaa !24
  %t650 = load i64, ptr %l51, !tbaa !24
  %t653 = icmp slt i64 %t649, %t650
  %t655 = xor i1 %t653, true
  br i1 %t655, label %bb163, label %bb164
bb163:
  call void @__olang_scope_close(ptr %s37)
  br label %bb294
bb164:
  br label %bb165
bb165:
  %t657 = load i64, ptr %l48, !tbaa !24
  %t658 = load i64, ptr %l52, !tbaa !24
  %t659 = load i64, ptr %l50, !tbaa !24
  %t662 = mul i64 %t658, %t659
  %t665 = add i64 %t657, %t662
  store i64 %t665, ptr %l53, !tbaa !24
  %t667 = load ptr, ptr %lp2
  %t668 = getelementptr %"compiler/profile:Places", ptr %t667, i32 0, i32 3
  store ptr %t668, ptr %l360, !tbaa !29
  %t669 = load ptr, ptr %lp2
  %t670 = getelementptr %"compiler/profile:Places", ptr %t669, i32 0, i32 2
  %t672 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2eLen_3ccompiler_2fprofile_3aFrame_3e(ptr %v2, ptr %t670)
  store i64 %t672, ptr %l362
  br label %bb166
bb166:
  %t673 = load ptr, ptr %l360, !tbaa !29
  %t674 = load i64, ptr %l362, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t673, i64 %t674)
  br label %bb167
bb167:
  store i64 0, ptr %l54, !tbaa !24
  %t675 = load i64, ptr %l53, !tbaa !24
  %t678 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l17, i64 %t675)
  store i64 %t678, ptr %l365
  br label %bb168
bb168:
  %t679 = load i64, ptr %l365, !tbaa !24
  %t680 = icmp sge i64 %t679, 0
  br i1 %t680, label %bb169, label %bb170
bb169:
  %t682 = load i64, ptr %l47, !tbaa !24
  store i64 %t682, ptr %l368, !tbaa !24
  %t684 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l34)
  store i64 %t684, ptr %l370
  br label %bb171
bb170:
  store i1 false, ptr %l367, !tbaa !21
  br label %bb172
bb171:
  %t685 = load i64, ptr %l368, !tbaa !24
  %t686 = load i64, ptr %l370, !tbaa !24
  %t687 = icmp slt i64 %t685, %t686
  store i1 %t687, ptr %l367, !tbaa !21
  br label %bb172
bb172:
  %t689 = load i1, ptr %l367, !tbaa !21
  br i1 %t689, label %bb173, label %bb174
bb173:
  br label %bb175
bb174:
  br label %bb235
bb175:
  store %olang.scope zeroinitializer, ptr %s39
  %t690 = load i64, ptr %l47, !tbaa !24
  %t692 = add i64 %t690, 1
  store i64 %t692, ptr %l373, !tbaa !24
  %t694 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l34)
  store i64 %t694, ptr %l375
  br label %bb176
bb176:
  %t695 = load i64, ptr %l373, !tbaa !24
  %t696 = load i64, ptr %l375, !tbaa !24
  %t697 = icmp slt i64 %t695, %t696
  br i1 %t697, label %bb177, label %bb178
bb177:
  %t699 = load i64, ptr %l47, !tbaa !24
  %t702 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l34, i64 %t699)
  store { i64, ptr } %t702, ptr %l380
  br label %bb179
bb178:
  store i1 false, ptr %l377, !tbaa !21
  br label %bb181
bb179:
  %t703 = load { i64, ptr }, ptr %l380, !tbaa !27
  %t704 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s39, { i64, ptr } %t703, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d81, i32 0, i32 1) })
  store i1 %t704, ptr %l381
  br label %bb180
bb180:
  %t705 = load i1, ptr %l381, !tbaa !21
  %t706 = xor i1 %t705, true
  store i1 %t706, ptr %l377, !tbaa !21
  br label %bb181
bb181:
  %t708 = load i1, ptr %l377, !tbaa !21
  %t709 = xor i1 %t708, true
  br i1 %t709, label %bb182, label %bb183
bb182:
  call void @__olang_scope_close(ptr %s39)
  br label %bb234
bb183:
  br label %bb184
bb184:
  %t711 = load i64, ptr %l47, !tbaa !24
  %t714 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l34, i64 %t711)
  store { i64, ptr } %t714, ptr %l386
  br label %bb185
bb185:
  %t715 = load { i64, ptr }, ptr %l386, !tbaa !27
  store { i64, ptr } %t715, ptr %l55, !tbaa !27
  %t716 = load i64, ptr %l47, !tbaa !24
  %t718 = add i64 %t716, 1
  %t721 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l34, i64 %t718)
  store { i64, ptr } %t721, ptr %l390
  br label %bb186
bb186:
  %t722 = load { i64, ptr }, ptr %l390, !tbaa !27
  %t723 = load i64, ptr %l47, !tbaa !24
  %t725 = add i64 %t723, 2
  store i64 %t725, ptr %l47, !tbaa !24
  %t729 = call { { i64, ptr }, i64 } @compiler_2fprofile_2efileLine(ptr %s0, ptr %s39, { i64, ptr } %t722)
  store { { i64, ptr }, i64 } %t729, ptr %l394
  br label %bb187
bb187:
  %t730 = load { { i64, ptr }, i64 }, ptr %l394
  store { { i64, ptr }, i64 } %t730, ptr %l57
  %t731 = getelementptr { { i64, ptr }, i64 }, ptr %l57, i32 0, i32 0
  %t732 = load { i64, ptr }, ptr %t731, !tbaa !27
  store { i64, ptr } %t732, ptr %l395, !tbaa !27
  %t733 = load { i64, ptr }, ptr %l395, !tbaa !27
  %t734 = extractvalue { i64, ptr } %t733, 0
  store i64 %t734, ptr %l396, !tbaa !24
  %t735 = load i64, ptr %l396, !tbaa !24
  %t736 = mul i64 %t735, 1
  %t737 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t736)
  %t738 = insertvalue { i64, ptr } undef, i64 %t735, 0
  %t739 = insertvalue { i64, ptr } %t738, ptr %t737, 1
  store { i64, ptr } %t739, ptr %l397, !tbaa !27
  %t740 = getelementptr { i64, ptr }, ptr %l397, i32 0, i32 1
  %t741 = load ptr, ptr %t740, !tbaa !27
  %t742 = getelementptr { i64, ptr }, ptr %l395, i32 0, i32 1
  %t743 = load ptr, ptr %t742, !tbaa !27
  %t744 = load i64, ptr %l396, !tbaa !24
  %t745 = mul i64 %t744, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t741, ptr %t743, i64 %t745, i1 false)
  %t746 = load { i64, ptr }, ptr %l397, !tbaa !27
  store { i64, ptr } %t746, ptr %l58, !tbaa !27
  %t747 = getelementptr { { i64, ptr }, i64 }, ptr %l57, i32 0, i32 1
  %t748 = load i64, ptr %t747, !tbaa !24
  store i64 %t748, ptr %l59, !tbaa !24
  %t750 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t752 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s39, { i64, ptr } %t750, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d82, i32 0, i32 1) })
  store i1 %t752, ptr %l400
  br label %bb188
bb188:
  %t753 = load i1, ptr %l400, !tbaa !21
  br i1 %t753, label %bb189, label %bb190
bb189:
  %t754 = load i64, ptr %l53, !tbaa !24
  %t757 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l16, i64 %t754)
  store { i64, ptr } %t757, ptr %l404
  br label %bb191
bb190:
  store i1 false, ptr %l401, !tbaa !21
  br label %bb193
bb191:
  %t758 = load { i64, ptr }, ptr %l404, !tbaa !27
  %t759 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s39, { i64, ptr } %t758, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d83, i32 0, i32 1) })
  store i1 %t759, ptr %l405
  br label %bb192
bb192:
  %t760 = load i1, ptr %l405, !tbaa !21
  store i1 %t760, ptr %l401, !tbaa !21
  br label %bb193
bb193:
  %t761 = load i1, ptr %l401, !tbaa !21
  br i1 %t761, label %bb194, label %bb195
bb194:
  store %olang.scope zeroinitializer, ptr %s40
  store ptr %l46, ptr %l406, !tbaa !29
  %t762 = load i64, ptr %l53, !tbaa !24
  %t765 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l16, i64 %t762)
  store { i64, ptr } %t765, ptr %l409
  br label %bb196
bb195:
  br label %bb217
bb196:
  %t766 = load ptr, ptr %l406, !tbaa !29
  %t767 = load { i64, ptr }, ptr %l409, !tbaa !27
  %t768 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H509117e81ae737fb138b1f364b80e611(ptr %s0, ptr %s0, ptr %t766, { i64, ptr } %t767)
  store i1 %t768, ptr %l410
  br label %bb197
bb197:
  %t769 = load i1, ptr %l410, !tbaa !21
  %t770 = xor i1 %t769, true
  br i1 %t770, label %bb198, label %bb199
bb198:
  store %olang.scope zeroinitializer, ptr %s41
  store ptr %l46, ptr %l412, !tbaa !29
  %t772 = load i64, ptr %l53, !tbaa !24
  %t775 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s41, ptr %l16, i64 %t772)
  store { i64, ptr } %t775, ptr %l415
  br label %bb200
bb199:
  br label %bb204
bb200:
  %t776 = load { i64, ptr }, ptr %l415, !tbaa !27
  %t777 = extractvalue { i64, ptr } %t776, 1
  %t778 = extractvalue { i64, ptr } %t776, 0
  %t779 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t778)
  call void @olang_textcopy(ptr %t779, ptr %t777, i64 %t778)
  %t780 = insertvalue { i64, ptr } undef, i64 %t778, 0
  %t781 = insertvalue { i64, ptr } %t780, ptr %t779, 1
  %t783 = extractvalue { i64, ptr } %t781, 0
  %t784 = extractvalue { i64, ptr } %t781, 1
  %t785 = mul i64 %t783, 1
  %t786 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t785)
  call void @llvm.memcpy.p0.p0.i64(ptr %t786, ptr %t784, i64 %t785, i1 false)
  %t787 = insertvalue { i64, ptr } undef, i64 %t783, 0
  %t788 = insertvalue { i64, ptr } %t787, ptr %t786, 1
  store { i64, ptr } %t788, ptr %l417, !tbaa !27
  %t789 = load i64, ptr %l53, !tbaa !24
  %t792 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l16, i64 %t789)
  store { i64, ptr } %t792, ptr %l420
  br label %bb201
bb201:
  %t793 = load { i64, ptr }, ptr %l420, !tbaa !27
  %t794 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fprofile_2efunctionSymbols(ptr %s0, ptr %s0, { i64, ptr } %t793)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t794, ptr %l421
  br label %bb202
bb202:
  %t795 = load ptr, ptr %l412, !tbaa !29
  %t796 = load { i64, ptr }, ptr %l417, !tbaa !27
  %t797 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l421
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Hb4e1316c13adc554c531dbb9cf254a96(ptr %s0, ptr %s0, ptr %s0, ptr %t795, { i64, ptr } %t796, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t797)
  br label %bb203
bb203:
  call void @__olang_scope_close(ptr %s41)
  br label %bb204
bb204:
  store ptr %l46, ptr %l423, !tbaa !29
  %t798 = load i64, ptr %l53, !tbaa !24
  %t801 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l16, i64 %t798)
  store { i64, ptr } %t801, ptr %l426
  br label %bb205
bb205:
  %t802 = load ptr, ptr %l423, !tbaa !29
  %t803 = load { i64, ptr }, ptr %l426, !tbaa !27
  %t804 = call { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Hf7a94710bd717f9f9bfa139cb342fdae(ptr %s0, ptr %s0, ptr %s0, ptr %t802, { i64, ptr } %t803)
  %t805 = extractvalue { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } %t804, 1
  %t806 = extractvalue { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } %t804, 0
  store i32 %t806, ptr %l428
  %t807 = icmp ne i32 %t806, 0
  br i1 %t807, label %bb207, label %ok.808, !prof !99
ok.808:
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t805, ptr %l427
  br label %bb206
bb206:
  %t809 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l427
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t809, ptr %l422
  br label %bb210
bb207:
  br label %bb208
bb208:
  call void @__olang_ert_req_clear()
  %t810 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aelfFn_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t810, ptr %l429
  br label %bb209
bb209:
  %t811 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l429
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t811, ptr %l422
  br label %bb210
bb210:
  %t812 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l422
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t812, ptr %l60
  store ptr %l60, ptr %l430, !tbaa !29
  %t813 = load i64, ptr %l53, !tbaa !24
  %t816 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l17, i64 %t813)
  store i64 %t816, ptr %l433
  br label %bb211
bb211:
  %t817 = load ptr, ptr %l430, !tbaa !29
  %t818 = load i64, ptr %l433, !tbaa !24
  %t819 = call { i64, ptr } @compiler_2fprofile_2esymbolAt(ptr %s0, ptr %s0, ptr %t817, i64 %t818)
  store { i64, ptr } %t819, ptr %l434
  br label %bb212
bb212:
  %t820 = load { i64, ptr }, ptr %l434, !tbaa !27
  %t821 = extractvalue { i64, ptr } %t820, 0
  %t822 = extractvalue { i64, ptr } %t820, 1
  %t823 = mul i64 %t821, 1
  %t824 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t823)
  call void @llvm.memcpy.p0.p0.i64(ptr %t824, ptr %t822, i64 %t823, i1 false)
  %t825 = insertvalue { i64, ptr } undef, i64 %t821, 0
  %t826 = insertvalue { i64, ptr } %t825, ptr %t824, 1
  store { i64, ptr } %t826, ptr %l55, !tbaa !27
  %t828 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t830 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s40, { i64, ptr } %t828, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d84, i32 0, i32 1) })
  store i1 %t830, ptr %l437
  br label %bb213
bb213:
  %t831 = load i1, ptr %l437, !tbaa !21
  br i1 %t831, label %bb214, label %bb215
bb214:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d85, i32 0, i32 1) }, ptr %l55, !tbaa !27
  br label %bb216
bb215:
  br label %bb216
bb216:
  call void @__olang_scope_close(ptr %s40)
  br label %bb217
bb217:
  %t832 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t834 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s39, { i64, ptr } %t832, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d86, i32 0, i32 1) })
  store i1 %t834, ptr %l439
  br label %bb218
bb218:
  %t835 = load i1, ptr %l439, !tbaa !21
  br i1 %t835, label %bb219, label %bb220
bb219:
  store %olang.scope zeroinitializer, ptr %s44
  %t836 = load i64, ptr %l53, !tbaa !24
  %t839 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l5, i64 %t836)
  store i64 %t839, ptr %l442
  br label %bb221
bb220:
  %t840 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t842 = call { i64, ptr } @compiler_2fprofile_2eReadable(ptr %s0, ptr %s0, { i64, ptr } %t840)
  store { i64, ptr } %t842, ptr %l454
  br label %bb227
bb221:
  %t843 = load i64, ptr %l442, !tbaa !24
  store i64 %t843, ptr %l443, !tbaa !65
  %t844 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s44, i64 16)
  %t845 = extractvalue { i32, i64 } %t844, 1
  %t846 = extractvalue { i32, i64 } %t844, 0
  store i32 %t846, ptr %l445
  %t847 = icmp ne i32 %t846, 0
  br i1 %t847, label %bb223, label %ok.848, !prof !99
ok.848:
  store i64 %t845, ptr %l444
  br label %bb222
bb222:
  %t849 = load i64, ptr %l443, !tbaa !65
  %t850 = load i64, ptr %l444, !tbaa !24
  %t851 = call { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %s44, i64 %t849, i64 %t850)
  store { i64, ptr } %t851, ptr %l446
  br label %bb224
bb223:
  call void @__olang_check_failed(ptr @olang_loc_a4addf443e3a86b3_5ebaaf6328319b7f)
  unreachable
bb224:
  %t852 = load i64, ptr %l53, !tbaa !24
  %t855 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l16, i64 %t852)
  store { i64, ptr } %t855, ptr %l449
  br label %bb225
bb225:
  %t856 = load { i64, ptr }, ptr %l449, !tbaa !27
  %t857 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %s0, { i64, ptr } %t856)
  store { i64, ptr } %t857, ptr %l450
  br label %bb226
bb226:
  %t858 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d87, i32 0, i32 1) }, 1
  %t859 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d87, i32 0, i32 1) }, 0
  %t860 = load { i64, ptr }, ptr %l446, !tbaa !27
  %t861 = extractvalue { i64, ptr } %t860, 1
  %t862 = extractvalue { i64, ptr } %t860, 0
  %t863 = add i64 %t859, %t862
  %t864 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d88, i32 0, i32 1) }, 1
  %t865 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d88, i32 0, i32 1) }, 0
  %t866 = add i64 %t863, %t865
  %t867 = load { i64, ptr }, ptr %l450, !tbaa !27
  %t868 = extractvalue { i64, ptr } %t867, 1
  %t869 = extractvalue { i64, ptr } %t867, 0
  %t870 = add i64 %t866, %t869
  %t871 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d89, i32 0, i32 1) }, 1
  %t872 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d89, i32 0, i32 1) }, 0
  %t873 = add i64 %t870, %t872
  %t874 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t873)
  call void @olang_textcopy(ptr %t874, ptr %t858, i64 %t859)
  %t875 = getelementptr i8, ptr %t874, i64 %t859
  call void @olang_textcopy(ptr %t875, ptr %t861, i64 %t862)
  %t876 = getelementptr i8, ptr %t875, i64 %t862
  call void @olang_textcopy(ptr %t876, ptr %t864, i64 %t865)
  %t877 = getelementptr i8, ptr %t876, i64 %t865
  call void @olang_textcopy(ptr %t877, ptr %t868, i64 %t869)
  %t878 = getelementptr i8, ptr %t877, i64 %t869
  call void @olang_textcopy(ptr %t878, ptr %t871, i64 %t872)
  %t879 = insertvalue { i64, ptr } undef, i64 %t873, 0
  %t880 = insertvalue { i64, ptr } %t879, ptr %t874, 1
  %t882 = extractvalue { i64, ptr } %t880, 0
  %t883 = extractvalue { i64, ptr } %t880, 1
  %t884 = mul i64 %t882, 1
  %t885 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t884)
  call void @llvm.memcpy.p0.p0.i64(ptr %t885, ptr %t883, i64 %t884, i1 false)
  %t886 = insertvalue { i64, ptr } undef, i64 %t882, 0
  %t887 = insertvalue { i64, ptr } %t886, ptr %t885, 1
  store { i64, ptr } %t887, ptr %l55, !tbaa !27
  call void @__olang_scope_close(ptr %s44)
  br label %bb228
bb227:
  %t889 = load { i64, ptr }, ptr %l454, !tbaa !27
  %t890 = extractvalue { i64, ptr } %t889, 0
  %t891 = extractvalue { i64, ptr } %t889, 1
  %t892 = mul i64 %t890, 1
  %t893 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t892)
  call void @llvm.memcpy.p0.p0.i64(ptr %t893, ptr %t891, i64 %t892, i1 false)
  %t894 = insertvalue { i64, ptr } undef, i64 %t890, 0
  %t895 = insertvalue { i64, ptr } %t894, ptr %t893, 1
  store { i64, ptr } %t895, ptr %l55, !tbaa !27
  br label %bb228
bb228:
  %t897 = load ptr, ptr %lp2
  %t898 = getelementptr %"compiler/profile:Places", ptr %t897, i32 0, i32 2
  store ptr %t898, ptr %l456, !tbaa !29
  %t899 = load ptr, ptr %lp2
  %t900 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t903 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v2, ptr %s0, ptr %t899, { i64, ptr } %t900)
  store i64 %t903, ptr %l459
  br label %bb229
bb229:
  %t904 = load ptr, ptr %lp2
  %t905 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t908 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v2, ptr %s39, ptr %t904, { i64, ptr } %t905)
  store i64 %t908, ptr %l462
  br label %bb230
bb230:
  %t909 = load i64, ptr %l59, !tbaa !24
  %t910 = load i64, ptr %l459, !tbaa !24
  %t911 = load i64, ptr %l462, !tbaa !24
  %t913 = call %"compiler/profile:Frame" @compiler_2fprofile_3aFrame_2ector(ptr %s39, i64 %t910, i64 %t911, i64 %t909)
  store %"compiler/profile:Frame" %t913, ptr %l464
  br label %bb231
bb231:
  %t914 = load ptr, ptr %l456, !tbaa !29
  %t915 = load %"compiler/profile:Frame", ptr %l464
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2ePush_3ccompiler_2fprofile_3aFrame_3e(ptr %v2, ptr %t914, %"compiler/profile:Frame" %t915)
  br label %bb232
bb232:
  %t916 = load i64, ptr %l54, !tbaa !24
  %t918 = add i64 %t916, 1
  store i64 %t918, ptr %l54, !tbaa !24
  call void @__olang_scope_close(ptr %s39)
  br label %bb233
bb233:
  br label %bb175
bb234:
  %t920 = load i64, ptr %l47, !tbaa !24
  %t922 = add i64 %t920, 1
  store i64 %t922, ptr %l47, !tbaa !24
  br label %bb235
bb235:
  %t924 = load i64, ptr %l54, !tbaa !24
  %t926 = icmp eq i64 %t924, 0
  br i1 %t926, label %bb236, label %bb237
bb236:
  %t928 = load i64, ptr %l53, !tbaa !24
  %t931 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l17, i64 %t928)
  store i64 %t931, ptr %l474
  br label %bb238
bb237:
  store i1 false, ptr %l471, !tbaa !21
  br label %bb239
bb238:
  %t932 = load i64, ptr %l474, !tbaa !24
  %t933 = icmp sge i64 %t932, 0
  store i1 %t933, ptr %l471, !tbaa !21
  br label %bb239
bb239:
  %t935 = load i1, ptr %l471, !tbaa !21
  br i1 %t935, label %bb240, label %bb241
bb240:
  %t936 = load i64, ptr %l53, !tbaa !24
  %t939 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l16, i64 %t936)
  store { i64, ptr } %t939, ptr %l479
  br label %bb242
bb241:
  store i1 false, ptr %l476, !tbaa !21
  br label %bb244
bb242:
  %t940 = load { i64, ptr }, ptr %l479, !tbaa !27
  %t941 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s37, { i64, ptr } %t940, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d90, i32 0, i32 1) })
  store i1 %t941, ptr %l480
  br label %bb243
bb243:
  %t942 = load i1, ptr %l480, !tbaa !21
  store i1 %t942, ptr %l476, !tbaa !21
  br label %bb244
bb244:
  %t943 = load i1, ptr %l476, !tbaa !21
  br i1 %t943, label %bb245, label %bb246
bb245:
  store %olang.scope zeroinitializer, ptr %s47
  store ptr %l46, ptr %l481, !tbaa !29
  %t944 = load i64, ptr %l53, !tbaa !24
  %t947 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l16, i64 %t944)
  store { i64, ptr } %t947, ptr %l484
  br label %bb247
bb246:
  br label %bb273
bb247:
  %t948 = load ptr, ptr %l481, !tbaa !29
  %t949 = load { i64, ptr }, ptr %l484, !tbaa !27
  %t950 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H509117e81ae737fb138b1f364b80e611(ptr %s0, ptr %s0, ptr %t948, { i64, ptr } %t949)
  store i1 %t950, ptr %l485
  br label %bb248
bb248:
  %t951 = load i1, ptr %l485, !tbaa !21
  %t952 = xor i1 %t951, true
  br i1 %t952, label %bb249, label %bb250
bb249:
  store %olang.scope zeroinitializer, ptr %s48
  store ptr %l46, ptr %l487, !tbaa !29
  %t954 = load i64, ptr %l53, !tbaa !24
  %t957 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s48, ptr %l16, i64 %t954)
  store { i64, ptr } %t957, ptr %l490
  br label %bb251
bb250:
  br label %bb255
bb251:
  %t958 = load { i64, ptr }, ptr %l490, !tbaa !27
  %t959 = extractvalue { i64, ptr } %t958, 1
  %t960 = extractvalue { i64, ptr } %t958, 0
  %t961 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t960)
  call void @olang_textcopy(ptr %t961, ptr %t959, i64 %t960)
  %t962 = insertvalue { i64, ptr } undef, i64 %t960, 0
  %t963 = insertvalue { i64, ptr } %t962, ptr %t961, 1
  %t965 = extractvalue { i64, ptr } %t963, 0
  %t966 = extractvalue { i64, ptr } %t963, 1
  %t967 = mul i64 %t965, 1
  %t968 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t967)
  call void @llvm.memcpy.p0.p0.i64(ptr %t968, ptr %t966, i64 %t967, i1 false)
  %t969 = insertvalue { i64, ptr } undef, i64 %t965, 0
  %t970 = insertvalue { i64, ptr } %t969, ptr %t968, 1
  store { i64, ptr } %t970, ptr %l492, !tbaa !27
  %t971 = load i64, ptr %l53, !tbaa !24
  %t974 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l16, i64 %t971)
  store { i64, ptr } %t974, ptr %l495
  br label %bb252
bb252:
  %t975 = load { i64, ptr }, ptr %l495, !tbaa !27
  %t976 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fprofile_2efunctionSymbols(ptr %s0, ptr %s0, { i64, ptr } %t975)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t976, ptr %l496
  br label %bb253
bb253:
  %t977 = load ptr, ptr %l487, !tbaa !29
  %t978 = load { i64, ptr }, ptr %l492, !tbaa !27
  %t979 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l496
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Hb4e1316c13adc554c531dbb9cf254a96(ptr %s0, ptr %s0, ptr %s0, ptr %t977, { i64, ptr } %t978, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t979)
  br label %bb254
bb254:
  call void @__olang_scope_close(ptr %s48)
  br label %bb255
bb255:
  store ptr %l46, ptr %l498, !tbaa !29
  %t980 = load i64, ptr %l53, !tbaa !24
  %t983 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l16, i64 %t980)
  store { i64, ptr } %t983, ptr %l501
  br label %bb256
bb256:
  %t984 = load ptr, ptr %l498, !tbaa !29
  %t985 = load { i64, ptr }, ptr %l501, !tbaa !27
  %t986 = call { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Hf7a94710bd717f9f9bfa139cb342fdae(ptr %s0, ptr %s0, ptr %s0, ptr %t984, { i64, ptr } %t985)
  %t987 = extractvalue { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } %t986, 1
  %t988 = extractvalue { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } %t986, 0
  store i32 %t988, ptr %l503
  %t989 = icmp ne i32 %t988, 0
  br i1 %t989, label %bb258, label %ok.990, !prof !99
ok.990:
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t987, ptr %l502
  br label %bb257
bb257:
  %t991 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l502
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t991, ptr %l497
  br label %bb261
bb258:
  br label %bb259
bb259:
  call void @__olang_ert_req_clear()
  %t992 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aelfFn_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t992, ptr %l504
  br label %bb260
bb260:
  %t993 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l504
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t993, ptr %l497
  br label %bb261
bb261:
  %t994 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l497
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t994, ptr %l61
  store ptr %l61, ptr %l505, !tbaa !29
  %t995 = load i64, ptr %l53, !tbaa !24
  %t998 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l17, i64 %t995)
  store i64 %t998, ptr %l508
  br label %bb262
bb262:
  %t999 = load ptr, ptr %l505, !tbaa !29
  %t1000 = load i64, ptr %l508, !tbaa !24
  %t1001 = call { i64, ptr } @compiler_2fprofile_2esymbolAt(ptr %s0, ptr %s47, ptr %t999, i64 %t1000)
  store { i64, ptr } %t1001, ptr %l509
  br label %bb263
bb263:
  %t1002 = load { i64, ptr }, ptr %l509, !tbaa !27
  store { i64, ptr } %t1002, ptr %l62, !tbaa !27
  %t1003 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t1005 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s47, ptr %s47, { i64, ptr } %t1003, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d91, i32 0, i32 1) })
  store i1 %t1005, ptr %l511
  br label %bb264
bb264:
  %t1006 = load i1, ptr %l511, !tbaa !21
  %t1007 = xor i1 %t1006, true
  br i1 %t1007, label %bb265, label %bb266
bb265:
  store %olang.scope zeroinitializer, ptr %s50
  %t1009 = load ptr, ptr %lp2
  %t1010 = getelementptr %"compiler/profile:Places", ptr %t1009, i32 0, i32 2
  store ptr %t1010, ptr %l513, !tbaa !29
  %t1011 = load ptr, ptr %lp2
  store ptr %t1011, ptr %l514, !tbaa !29
  %t1012 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t1014 = call { i64, ptr } @compiler_2fprofile_2eReadable(ptr %s47, ptr %s50, { i64, ptr } %t1012)
  store { i64, ptr } %t1014, ptr %l516
  br label %bb267
bb266:
  br label %bb272
bb267:
  %t1015 = load { i64, ptr }, ptr %l516, !tbaa !27
  %t1016 = extractvalue { i64, ptr } %t1015, 0
  %t1017 = extractvalue { i64, ptr } %t1015, 1
  %t1018 = mul i64 %t1016, 1
  %t1019 = call ptr @__olang_scope_alloc(ptr %s50, i64 %t1018)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1019, ptr %t1017, i64 %t1018, i1 false)
  %t1020 = insertvalue { i64, ptr } undef, i64 %t1016, 0
  %t1021 = insertvalue { i64, ptr } %t1020, ptr %t1019, 1
  %t1022 = load ptr, ptr %l514, !tbaa !29
  %t1024 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v2, ptr %s50, ptr %t1022, { i64, ptr } %t1021)
  store i64 %t1024, ptr %l518
  br label %bb268
bb268:
  %t1025 = load ptr, ptr %lp2
  %t1027 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v2, ptr %s50, ptr %t1025, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d92, i32 0, i32 1) })
  store i64 %t1027, ptr %l520
  br label %bb269
bb269:
  %t1028 = load i64, ptr %l518, !tbaa !24
  %t1029 = load i64, ptr %l520, !tbaa !24
  %t1030 = call %"compiler/profile:Frame" @compiler_2fprofile_3aFrame_2ector(ptr %s50, i64 %t1028, i64 %t1029, i64 0)
  store %"compiler/profile:Frame" %t1030, ptr %l521
  br label %bb270
bb270:
  %t1031 = load ptr, ptr %l513, !tbaa !29
  %t1032 = load %"compiler/profile:Frame", ptr %l521
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2ePush_3ccompiler_2fprofile_3aFrame_3e(ptr %v2, ptr %t1031, %"compiler/profile:Frame" %t1032)
  br label %bb271
bb271:
  store i64 1, ptr %l54, !tbaa !24
  call void @__olang_scope_close(ptr %s50)
  br label %bb272
bb272:
  call void @__olang_scope_close(ptr %s47)
  br label %bb273
bb273:
  %t1033 = load i64, ptr %l54, !tbaa !24
  %t1035 = icmp eq i64 %t1033, 0
  br i1 %t1035, label %bb274, label %bb275
bb274:
  store %olang.scope zeroinitializer, ptr %s51
  %t1037 = load i64, ptr %l53, !tbaa !24
  %t1040 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l16, i64 %t1037)
  store { i64, ptr } %t1040, ptr %l526
  br label %bb276
bb275:
  br label %bb291
bb276:
  %t1041 = load { i64, ptr }, ptr %l526, !tbaa !27
  %t1042 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s51, { i64, ptr } %t1041, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d93, i32 0, i32 1) })
  store i1 %t1042, ptr %l527
  br label %bb277
bb277:
  %t1043 = load i1, ptr %l527, !tbaa !21
  %t1044 = xor i1 %t1043, true
  br i1 %t1044, label %bb278, label %bb279
bb278:
  %t1046 = load i64, ptr %l53, !tbaa !24
  %t1049 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l16, i64 %t1046)
  store { i64, ptr } %t1049, ptr %l532
  br label %bb280
bb279:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d94, i32 0, i32 1) }, ptr %l529, !tbaa !27
  br label %bb282
bb280:
  %t1050 = load { i64, ptr }, ptr %l532, !tbaa !27
  %t1051 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %s0, { i64, ptr } %t1050)
  store { i64, ptr } %t1051, ptr %l533
  br label %bb281
bb281:
  %t1052 = load { i64, ptr }, ptr %l533, !tbaa !27
  store { i64, ptr } %t1052, ptr %l529, !tbaa !27
  br label %bb282
bb282:
  %t1053 = load { i64, ptr }, ptr %l529, !tbaa !27
  store { i64, ptr } %t1053, ptr %l63, !tbaa !27
  %t1054 = load ptr, ptr %lp2
  %t1055 = getelementptr %"compiler/profile:Places", ptr %t1054, i32 0, i32 2
  store ptr %t1055, ptr %l534, !tbaa !29
  %t1056 = load ptr, ptr %lp2
  store ptr %t1056, ptr %l535, !tbaa !29
  %t1057 = load i64, ptr %l53, !tbaa !24
  %t1060 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l5, i64 %t1057)
  store i64 %t1060, ptr %l538
  br label %bb283
bb283:
  %t1061 = load i64, ptr %l538, !tbaa !24
  store i64 %t1061, ptr %l539, !tbaa !65
  %t1062 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s51, i64 16)
  %t1063 = extractvalue { i32, i64 } %t1062, 1
  %t1064 = extractvalue { i32, i64 } %t1062, 0
  store i32 %t1064, ptr %l541
  %t1065 = icmp ne i32 %t1064, 0
  br i1 %t1065, label %bb285, label %ok.1066, !prof !99
ok.1066:
  store i64 %t1063, ptr %l540
  br label %bb284
bb284:
  %t1067 = load i64, ptr %l539, !tbaa !65
  %t1068 = load i64, ptr %l540, !tbaa !24
  %t1069 = call { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %s51, i64 %t1067, i64 %t1068)
  store { i64, ptr } %t1069, ptr %l542
  br label %bb286
bb285:
  call void @__olang_check_failed(ptr @olang_loc_41e6651314f25f98_646ba62944647444)
  unreachable
bb286:
  %t1070 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t1071 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d95, i32 0, i32 1) }, 1
  %t1072 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  %t1073 = load { i64, ptr }, ptr %l542, !tbaa !27
  %t1074 = extractvalue { i64, ptr } %t1073, 1
  %t1075 = extractvalue { i64, ptr } %t1073, 0
  %t1076 = add i64 %t1072, %t1075
  %t1077 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d96, i32 0, i32 1) }, 1
  %t1078 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d96, i32 0, i32 1) }, 0
  %t1079 = add i64 %t1076, %t1078
  %t1081 = extractvalue { i64, ptr } %t1070, 1
  %t1082 = extractvalue { i64, ptr } %t1070, 0
  %t1083 = add i64 %t1079, %t1082
  %t1084 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d97, i32 0, i32 1) }, 1
  %t1085 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d97, i32 0, i32 1) }, 0
  %t1086 = add i64 %t1083, %t1085
  %t1087 = call ptr @__olang_scope_alloc(ptr %s51, i64 %t1086)
  call void @olang_textcopy(ptr %t1087, ptr %t1071, i64 %t1072)
  %t1088 = getelementptr i8, ptr %t1087, i64 %t1072
  call void @olang_textcopy(ptr %t1088, ptr %t1074, i64 %t1075)
  %t1089 = getelementptr i8, ptr %t1088, i64 %t1075
  call void @olang_textcopy(ptr %t1089, ptr %t1077, i64 %t1078)
  %t1090 = getelementptr i8, ptr %t1089, i64 %t1078
  call void @olang_textcopy(ptr %t1090, ptr %t1081, i64 %t1082)
  %t1091 = getelementptr i8, ptr %t1090, i64 %t1082
  call void @olang_textcopy(ptr %t1091, ptr %t1084, i64 %t1085)
  %t1092 = insertvalue { i64, ptr } undef, i64 %t1086, 0
  %t1093 = insertvalue { i64, ptr } %t1092, ptr %t1087, 1
  %t1095 = extractvalue { i64, ptr } %t1093, 0
  %t1096 = extractvalue { i64, ptr } %t1093, 1
  %t1097 = mul i64 %t1095, 1
  %t1098 = call ptr @__olang_scope_alloc(ptr %s51, i64 %t1097)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1098, ptr %t1096, i64 %t1097, i1 false)
  %t1099 = insertvalue { i64, ptr } undef, i64 %t1095, 0
  %t1100 = insertvalue { i64, ptr } %t1099, ptr %t1098, 1
  %t1101 = load ptr, ptr %l535, !tbaa !29
  %t1103 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v2, ptr %s51, ptr %t1101, { i64, ptr } %t1100)
  store i64 %t1103, ptr %l546
  br label %bb287
bb287:
  %t1104 = load ptr, ptr %lp2
  %t1106 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v2, ptr %s51, ptr %t1104, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d98, i32 0, i32 1) })
  store i64 %t1106, ptr %l548
  br label %bb288
bb288:
  %t1107 = load i64, ptr %l546, !tbaa !24
  %t1108 = load i64, ptr %l548, !tbaa !24
  %t1109 = call %"compiler/profile:Frame" @compiler_2fprofile_3aFrame_2ector(ptr %s51, i64 %t1107, i64 %t1108, i64 0)
  store %"compiler/profile:Frame" %t1109, ptr %l549
  br label %bb289
bb289:
  %t1110 = load ptr, ptr %l534, !tbaa !29
  %t1111 = load %"compiler/profile:Frame", ptr %l549
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2ePush_3ccompiler_2fprofile_3aFrame_3e(ptr %v2, ptr %t1110, %"compiler/profile:Frame" %t1111)
  br label %bb290
bb290:
  store i64 1, ptr %l54, !tbaa !24
  call void @__olang_scope_close(ptr %s51)
  br label %bb291
bb291:
  %t1112 = load ptr, ptr %lp2
  %t1113 = getelementptr %"compiler/profile:Places", ptr %t1112, i32 0, i32 4
  %t1114 = load i64, ptr %l54, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t1113, i64 %t1114)
  br label %bb292
bb292:
  call void @__olang_scope_close(ptr %s37)
  br label %bb293
bb293:
  %t1117 = load i64, ptr %l52, !tbaa !24
  %t1119 = add i64 %t1117, 1
  store i64 %t1119, ptr %l52, !tbaa !24
  br label %bb162
bb294:
  %t1121 = load ptr, ptr %lp2
  %t1122 = load %"compiler/profile:Places", ptr %t1121
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/profile:Places" %t1122, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/profile:Places", ptr %rv
  ret %"compiler/profile:Places" %rr
}

define dso_local { i64, ptr } @compiler_2fprofile_2eSymbolizer(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %lp7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l10 = alloca i1
  %l12 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i32
  %l18 = alloca { i64, ptr }
  %l22 = alloca i1
  %l25 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l30 = alloca i1
  %l45 = alloca { i64, ptr }
  %l47 = alloca i1
  %l52 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l54 = alloca i64
  %l55 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i64, ptr } @compiler_2ftarget_2eFindClang(ptr %s0)
  store { i64, ptr } %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t2, ptr %l0, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t3, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d99, i32 0, i32 1) })
  store i1 %t5, ptr %l10
  br label %bb2
bb2:
  %t6 = load i1, ptr %l10, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t11 = call { i64, ptr } @compiler_2ftarget_2eWhereIs(ptr %s0, ptr %s1, { i64, ptr } %t9)
  store { i64, ptr } %t11, ptr %l14
  br label %bb5
bb4:
  br label %bb20
bb5:
  %t12 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  %t14 = extractvalue { i64, ptr } %t12, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t20 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %s1, ptr %s1, { i64, ptr } %t18)
  %t21 = extractvalue { i32, { i64, ptr } } %t20, 1
  %t22 = extractvalue { i32, { i64, ptr } } %t20, 0
  store i32 %t22, ptr %l17
  %t23 = icmp ne i32 %t22, 0
  br i1 %t23, label %bb7, label %ok.24, !prof !99
ok.24:
  store { i64, ptr } %t21, ptr %l16
  br label %bb6
bb6:
  %t25 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t25, ptr %l12, !tbaa !27
  br label %bb9
bb7:
  br label %bb8
bb8:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d100, i32 0, i32 1) }, ptr %l18, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  %t29 = extractvalue { i64, ptr } %t26, 1
  %t30 = mul i64 %t28, 1
  %t31 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t30)
  call void @llvm.memcpy.p0.p0.i64(ptr %t31, ptr %t29, i64 %t30, i1 false)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  store { i64, ptr } %t33, ptr %l12, !tbaa !27
  br label %bb9
bb9:
  %t35 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t35, ptr %l1, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t38 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s1, { i64, ptr } %t36, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d101, i32 0, i32 1) })
  store i1 %t38, ptr %l22
  br label %bb10
bb10:
  %t39 = load i1, ptr %l22, !tbaa !21
  %t40 = xor i1 %t39, true
  br i1 %t40, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = call { i64, ptr } @std_2ffilepath_2eDir(ptr %s1, { i64, ptr } %t42)
  store { i64, ptr } %t44, ptr %l25
  br label %bb13
bb12:
  br label %bb19
bb13:
  %t45 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d102, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d102, i32 0, i32 1) }, 0
  %t50 = add i64 %t47, %t49
  %t51 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t50)
  call void @olang_textcopy(ptr %t51, ptr %t46, i64 %t47)
  %t52 = getelementptr i8, ptr %t51, i64 %t47
  call void @olang_textcopy(ptr %t52, ptr %t48, i64 %t49)
  %t53 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t51, 1
  %t55 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t55, ptr %lp2
  %t57 = load ptr, ptr %lp2
  store { i64, ptr } %t54, ptr %t57, !tbaa !27
  %t58 = load ptr, ptr %lp2
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  %t61 = call { i64, ptr } @compiler_2ftarget_2eWhereIs(ptr %v0, ptr %s2, { i64, ptr } %t59)
  store { i64, ptr } %t61, ptr %l28
  br label %bb14
bb14:
  %t62 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t62, 0
  %t64 = extractvalue { i64, ptr } %t62, 1
  %t65 = mul i64 %t63, 1
  %t66 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t65)
  call void @llvm.memcpy.p0.p0.i64(ptr %t66, ptr %t64, i64 %t65, i1 false)
  %t67 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  %t70 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t68, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d103, i32 0, i32 1) })
  store i1 %t70, ptr %l30
  br label %bb15
bb15:
  %t71 = load i1, ptr %l30, !tbaa !21
  %t72 = xor i1 %t71, true
  br i1 %t72, label %bb16, label %bb17
bb16:
  %t74 = load ptr, ptr %lp2
  %t75 = load { i64, ptr }, ptr %t74, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t75, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s1)
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s5
  %t77 = insertvalue [4 x { i64, ptr }] undef, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d104, i32 0, i32 1) }, 0
  %t78 = insertvalue [4 x { i64, ptr }] %t77, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d105, i32 0, i32 1) }, 1
  %t79 = insertvalue [4 x { i64, ptr }] %t78, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d106, i32 0, i32 1) }, 2
  %t80 = insertvalue [4 x { i64, ptr }] %t79, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d107, i32 0, i32 1) }, 3
  %t82 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 64, i64 8)
  store [4 x { i64, ptr }] %t80, ptr %t82
  store ptr %t82, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t84 = load ptr, ptr %l3
  store i64 4, ptr %l5, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s6
  %t87 = load i64, ptr %l4, !tbaa !24
  %t88 = load i64, ptr %l5, !tbaa !24
  %t91 = icmp slt i64 %t87, %t88
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s6)
  br label %bb31
bb23:
  br label %bb24
bb24:
  %t95 = load ptr, ptr %l3
  %t96 = load i64, ptr %l4, !tbaa !24
  %t99 = getelementptr [4 x { i64, ptr }], ptr %t95, i64 0, i64 %t96
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !37
  %t103 = load ptr, ptr @__olang_prog_scope
  %t105 = call { i64, ptr } @compiler_2ftarget_2eWhereIs(ptr %t103, ptr %v0, { i64, ptr } %t100)
  store { i64, ptr } %t105, ptr %l45
  br label %bb25
bb25:
  %t106 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t106, ptr %lp7
  %t107 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t108 = load ptr, ptr %lp7
  store { i64, ptr } %t107, ptr %t108, !tbaa !27
  %t109 = load ptr, ptr %lp7
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !27
  %t112 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s6, { i64, ptr } %t110, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d108, i32 0, i32 1) })
  store i1 %t112, ptr %l47
  br label %bb26
bb26:
  %t113 = load i1, ptr %l47, !tbaa !21
  %t114 = xor i1 %t113, true
  br i1 %t114, label %bb27, label %bb28
bb27:
  %t116 = load ptr, ptr %lp7
  %t117 = load { i64, ptr }, ptr %t116, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t117, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s6)
  br label %bb30
bb30:
  %t119 = load i64, ptr %l4, !tbaa !24
  %t121 = add i64 %t119, 1
  store i64 %t121, ptr %l4, !tbaa !24
  br label %bb21
bb31:
  call void @__olang_scope_close(ptr %s5)
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d109, i32 0, i32 1) }, ptr %l52, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t123, ptr %l53, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t124, 0
  store i64 %t125, ptr %l54, !tbaa !24
  %t126 = load i64, ptr %l54, !tbaa !24
  %t127 = mul i64 %t126, 1
  %t128 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t127)
  %t129 = insertvalue { i64, ptr } undef, i64 %t126, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t128, 1
  store { i64, ptr } %t130, ptr %l55, !tbaa !27
  %t131 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = load i64, ptr %l54, !tbaa !24
  %t136 = mul i64 %t135, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t132, ptr %t134, i64 %t136, i1 false)
  %t137 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t137, ptr %l53, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t138 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t138, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/profile:Tally" @compiler_2fprofile_2eTallied(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/profile:Sample"
  %l6 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca i64
  %l8 = alloca %"compiler/profile:Frame"
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca i64
  %l17 = alloca %"compiler/profile:Tally"
  %l20 = alloca i64
  %l22 = alloca i64
  %l27 = alloca %"compiler/profile:Sample"
  %l31 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l33 = alloca i64
  %l37 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca %"compiler/profile:Frame"
  %l43 = alloca i1
  %l45 = alloca i1
  %l48 = alloca i1
  %l55 = alloca ptr
  %l59 = alloca { i64, ptr }
  %l63 = alloca i64
  %l66 = alloca i1
  %l76 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l78 = alloca i64
  %l80 = alloca i64
  %l86 = alloca i64
  %l90 = alloca %"compiler/profile:Frame"
  %l95 = alloca i1
  %l100 = alloca i1
  %l102 = alloca i1
  %l105 = alloca i1
  %l113 = alloca i64
  %l115 = alloca i64
  %l117 = alloca ptr
  %l119 = alloca i64
  %l121 = alloca ptr
  %l125 = alloca i64
  %l126 = alloca %"compiler/profile:Frame"
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/profile:Tally"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"compiler/profile:Tally" @compiler_2fprofile_3aTally_2ector(ptr %v2)
  store %"compiler/profile:Tally" %t1, ptr %l17
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 56, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"compiler/profile:Tally", ptr %l17
  %t4 = load ptr, ptr %lp2
  store %"compiler/profile:Tally" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/profile:Profile", ptr %t5, i32 0, i32 3
  store ptr %t7, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load i64, ptr %l4, !tbaa !24
  store i64 %t9, ptr %l20, !tbaa !24
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2eLen_3ccompiler_2fprofile_3aSample_3e(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l22
  br label %bb3
bb3:
  %t13 = load i64, ptr %l20, !tbaa !24
  %t14 = load i64, ptr %l22, !tbaa !24
  %t15 = icmp slt i64 %t13, %t14
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb67
bb5:
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l3, !tbaa !29
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = call %"compiler/profile:Sample" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2eAt_3ccompiler_2fprofile_3aSample_3e(ptr %v0, ptr %t19, i64 %t20)
  store %"compiler/profile:Sample" %t23, ptr %l27
  br label %bb7
bb7:
  %t24 = load %"compiler/profile:Sample", ptr %l27
  store %"compiler/profile:Sample" %t24, ptr %l5
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load %"compiler/profile:Sample", ptr %l5
  %t31 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2estack(ptr %v1, ptr %v0, ptr %s2, ptr %t25, ptr %t26, %"compiler/profile:Sample" %t27)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t31, ptr %l31
  br label %bb8
bb8:
  %t32 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l31
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %l6
  %t34 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s2, ptr %l6)
  store i64 %t34, ptr %l33
  br label %bb9
bb9:
  %t35 = load i64, ptr %l33, !tbaa !24
  %t36 = icmp eq i64 %t35, 0
  br i1 %t36, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb66
bb11:
  br label %bb12
bb12:
  %t38 = getelementptr %"compiler/profile:Sample", ptr %l5, i32 0, i32 0
  %t39 = load i64, ptr %t38, !tbaa !24
  store i64 %t39, ptr %l7, !tbaa !24
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr %"compiler/profile:Places", ptr %t41, i32 0, i32 2
  store ptr %t43, ptr %l37, !tbaa !29
  %t45 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %l6, i64 0)
  store i64 %t45, ptr %l39
  br label %bb13
bb13:
  %t46 = load ptr, ptr %l37, !tbaa !29
  %t47 = load i64, ptr %l39, !tbaa !24
  %t48 = call %"compiler/profile:Frame" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2eAt_3ccompiler_2fprofile_3aFrame_3e(ptr %v1, ptr %t46, i64 %t47)
  store %"compiler/profile:Frame" %t48, ptr %l40
  br label %bb14
bb14:
  %t49 = load %"compiler/profile:Frame", ptr %l40
  store %"compiler/profile:Frame" %t49, ptr %l8
  %t50 = load ptr, ptr %lp2
  %t51 = getelementptr %"compiler/profile:Tally", ptr %t50, i32 0, i32 1
  %t52 = getelementptr %"compiler/profile:Frame", ptr %l8, i32 0, i32 0
  %t53 = load i64, ptr %t52, !tbaa !24
  %t56 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v2, ptr %t51, i64 %t53)
  store i1 %t56, ptr %l43
  br label %bb15
bb15:
  %t57 = load i1, ptr %l43, !tbaa !21
  %t58 = xor i1 %t57, true
  br i1 %t58, label %bb16, label %bb17
bb16:
  %t60 = load ptr, ptr %lp2
  %t61 = getelementptr %"compiler/profile:Tally", ptr %t60, i32 0, i32 0
  %t62 = getelementptr %"compiler/profile:Frame", ptr %l8, i32 0, i32 0
  %t63 = load i64, ptr %t62, !tbaa !24
  %t66 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v2, ptr %t61, i64 %t63)
  store i1 %t66, ptr %l48
  br label %bb18
bb17:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb19
bb18:
  %t67 = load i1, ptr %l48, !tbaa !21
  %t68 = xor i1 %t67, true
  store i1 %t68, ptr %l45, !tbaa !21
  br label %bb19
bb19:
  %t70 = load i1, ptr %l45, !tbaa !21
  br i1 %t70, label %bb20, label %bb21
bb20:
  %t71 = load ptr, ptr %lp2
  %t72 = getelementptr %"compiler/profile:Tally", ptr %t71, i32 0, i32 5
  %t73 = getelementptr %"compiler/profile:Frame", ptr %l8, i32 0, i32 0
  %t74 = load i64, ptr %t73, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t72, i64 %t74)
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb23
bb23:
  %t77 = load ptr, ptr %lp2
  %t78 = getelementptr %"compiler/profile:Tally", ptr %t77, i32 0, i32 0
  %t79 = getelementptr %"compiler/profile:Frame", ptr %l8, i32 0, i32 0
  %t80 = load i64, ptr %t79, !tbaa !24
  %t81 = load i64, ptr %l7, !tbaa !24
  call void @compiler_2fprofile_2eadd(ptr %v2, ptr %t78, i64 %t80, i64 %t81)
  br label %bb24
bb24:
  %t85 = load ptr, ptr %l1, !tbaa !29
  store ptr %t85, ptr %l55, !tbaa !29
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t88 = getelementptr %"compiler/profile:Places", ptr %t86, i32 0, i32 0
  %t89 = getelementptr %"compiler/profile:Frame", ptr %l8, i32 0, i32 1
  %t90 = load i64, ptr %t89, !tbaa !24
  %t93 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %s2, ptr %t88, i64 %t90)
  store { i64, ptr } %t93, ptr %l59
  br label %bb25
bb25:
  %t94 = getelementptr %"compiler/profile:Frame", ptr %l8, i32 0, i32 2
  %t95 = load i64, ptr %t94, !tbaa !24
  %t96 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 1
  %t98 = extractvalue { i64, ptr } %t96, 0
  %t99 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d110, i32 0, i32 1) }, 1
  %t100 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d110, i32 0, i32 1) }, 0
  %t101 = add i64 %t98, %t100
  %t103 = call i64 @__olang_fmt_i64(ptr null, i64 %t95)
  %t104 = add i64 %t101, %t103
  %t105 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t104)
  call void @olang_textcopy(ptr %t105, ptr %t97, i64 %t98)
  %t106 = getelementptr i8, ptr %t105, i64 %t98
  call void @olang_textcopy(ptr %t106, ptr %t99, i64 %t100)
  %t107 = getelementptr i8, ptr %t106, i64 %t100
  %t108 = call i64 @__olang_fmt_i64(ptr %t107, i64 %t95)
  %t109 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t105, 1
  %t112 = extractvalue { i64, ptr } %t110, 0
  %t113 = extractvalue { i64, ptr } %t110, 1
  %t114 = mul i64 %t112, 1
  %t115 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t114)
  call void @llvm.memcpy.p0.p0.i64(ptr %t115, ptr %t113, i64 %t114, i1 false)
  %t116 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t115, 1
  %t118 = load ptr, ptr %l55, !tbaa !29
  %t120 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v1, ptr %s2, ptr %t118, { i64, ptr } %t117)
  store i64 %t120, ptr %l63
  br label %bb26
bb26:
  %t121 = load i64, ptr %l63, !tbaa !24
  store i64 %t121, ptr %l9, !tbaa !24
  %t122 = load ptr, ptr %lp2
  %t123 = getelementptr %"compiler/profile:Tally", ptr %t122, i32 0, i32 2
  %t124 = load i64, ptr %l9, !tbaa !24
  %t127 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v2, ptr %t123, i64 %t124)
  store i1 %t127, ptr %l66
  br label %bb27
bb27:
  %t128 = load i1, ptr %l66, !tbaa !21
  %t129 = xor i1 %t128, true
  br i1 %t129, label %bb28, label %bb29
bb28:
  %t131 = load ptr, ptr %lp2
  %t132 = getelementptr %"compiler/profile:Tally", ptr %t131, i32 0, i32 6
  %t133 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t132, i64 %t133)
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb31
bb31:
  %t136 = load ptr, ptr %lp2
  %t137 = getelementptr %"compiler/profile:Tally", ptr %t136, i32 0, i32 2
  %t138 = load i64, ptr %l9, !tbaa !24
  %t139 = load i64, ptr %l7, !tbaa !24
  call void @compiler_2fprofile_2eadd(ptr %v2, ptr %t137, i64 %t138, i64 %t139)
  br label %bb32
bb32:
  %t143 = load ptr, ptr %lp2
  %t144 = getelementptr %"compiler/profile:Tally", ptr %t143, i32 0, i32 3
  %t145 = load i64, ptr %l9, !tbaa !24
  %t146 = getelementptr %"compiler/profile:Frame", ptr %l8, i32 0, i32 0
  %t147 = load i64, ptr %t146, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v2, ptr %t144, i64 %t145, i64 %t147)
  br label %bb33
bb33:
  %t151 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t151, ptr %l76
  br label %bb34
bb34:
  %t152 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l76
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t152, ptr %l10
  store ptr %l6, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb35
bb35:
  %t154 = load i64, ptr %l12, !tbaa !24
  store i64 %t154, ptr %l78, !tbaa !24
  %t155 = load ptr, ptr %l11, !tbaa !29
  %t157 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s2, ptr %t155)
  store i64 %t157, ptr %l80
  br label %bb36
bb36:
  %t158 = load i64, ptr %l78, !tbaa !24
  %t159 = load i64, ptr %l80, !tbaa !24
  %t160 = icmp slt i64 %t158, %t159
  %t162 = xor i1 %t160, true
  br i1 %t162, label %bb37, label %bb38
bb37:
  br label %bb65
bb38:
  br label %bb39
bb39:
  %t164 = load i64, ptr %l12, !tbaa !24
  store i64 %t164, ptr %l13, !tbaa !24
  %t166 = load ptr, ptr %l11, !tbaa !29
  %t167 = load i64, ptr %l12, !tbaa !24
  %t170 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %t166, i64 %t167)
  store i64 %t170, ptr %l86
  br label %bb40
bb40:
  %t171 = load i64, ptr %l86, !tbaa !24
  %t172 = load ptr, ptr %l1, !tbaa !29
  %t174 = getelementptr %"compiler/profile:Places", ptr %t172, i32 0, i32 2
  %t178 = call %"compiler/profile:Frame" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2eAt_3ccompiler_2fprofile_3aFrame_3e(ptr %v1, ptr %t174, i64 %t171)
  store %"compiler/profile:Frame" %t178, ptr %l90
  br label %bb41
bb41:
  %t179 = getelementptr %"compiler/profile:Frame", ptr %l90, i32 0, i32 0
  %t180 = load i64, ptr %t179, !tbaa !24
  store i64 %t180, ptr %l15, !tbaa !24
  %t182 = load i64, ptr %l15, !tbaa !24
  %t187 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %s2, ptr %l10, i64 %t182)
  store i1 %t187, ptr %l95
  br label %bb42
bb42:
  %t188 = load i1, ptr %l95, !tbaa !21
  br i1 %t188, label %bb43, label %bb44
bb43:
  br label %bb64
bb44:
  br label %bb45
bb45:
  %t189 = load i64, ptr %l15, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s2, ptr %l10, i64 %t189)
  br label %bb46
bb46:
  %t192 = load ptr, ptr %lp2
  %t193 = getelementptr %"compiler/profile:Tally", ptr %t192, i32 0, i32 1
  %t194 = load i64, ptr %l15, !tbaa !24
  %t197 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v2, ptr %t193, i64 %t194)
  store i1 %t197, ptr %l100
  br label %bb47
bb47:
  %t198 = load i1, ptr %l100, !tbaa !21
  %t199 = xor i1 %t198, true
  br i1 %t199, label %bb48, label %bb49
bb48:
  %t201 = load ptr, ptr %lp2
  %t202 = getelementptr %"compiler/profile:Tally", ptr %t201, i32 0, i32 0
  %t203 = load i64, ptr %l15, !tbaa !24
  %t206 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v2, ptr %t202, i64 %t203)
  store i1 %t206, ptr %l105
  br label %bb50
bb49:
  store i1 false, ptr %l102, !tbaa !21
  br label %bb51
bb50:
  %t207 = load i1, ptr %l105, !tbaa !21
  %t208 = xor i1 %t207, true
  store i1 %t208, ptr %l102, !tbaa !21
  br label %bb51
bb51:
  %t210 = load i1, ptr %l102, !tbaa !21
  br i1 %t210, label %bb52, label %bb53
bb52:
  %t211 = load ptr, ptr %lp2
  %t212 = getelementptr %"compiler/profile:Tally", ptr %t211, i32 0, i32 5
  %t213 = load i64, ptr %l15, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t212, i64 %t213)
  br label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb55
bb55:
  %t216 = load ptr, ptr %lp2
  %t217 = getelementptr %"compiler/profile:Tally", ptr %t216, i32 0, i32 1
  %t218 = load i64, ptr %l15, !tbaa !24
  %t219 = load i64, ptr %l7, !tbaa !24
  call void @compiler_2fprofile_2eadd(ptr %v2, ptr %t217, i64 %t218, i64 %t219)
  br label %bb56
bb56:
  %t223 = load i64, ptr %l13, !tbaa !24
  %t225 = add i64 %t223, 1
  store i64 %t225, ptr %l113, !tbaa !24
  %t227 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s2, ptr %l6)
  store i64 %t227, ptr %l115
  br label %bb57
bb57:
  %t228 = load i64, ptr %l113, !tbaa !24
  %t229 = load i64, ptr %l115, !tbaa !24
  %t230 = icmp slt i64 %t228, %t229
  br i1 %t230, label %bb58, label %bb59
bb58:
  %t232 = load ptr, ptr %lp2
  %t233 = getelementptr %"compiler/profile:Tally", ptr %t232, i32 0, i32 4
  store ptr %t233, ptr %l117, !tbaa !29
  %t234 = load i64, ptr %l15, !tbaa !24
  %t236 = mul i64 %t234, 16777216
  store i64 %t236, ptr %l119, !tbaa !24
  %t237 = load ptr, ptr %l1, !tbaa !29
  %t239 = getelementptr %"compiler/profile:Places", ptr %t237, i32 0, i32 2
  store ptr %t239, ptr %l121, !tbaa !29
  %t240 = load i64, ptr %l13, !tbaa !24
  %t242 = add i64 %t240, 1
  %t245 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %l6, i64 %t242)
  store i64 %t245, ptr %l125
  br label %bb60
bb59:
  br label %bb63
bb60:
  %t246 = load ptr, ptr %l121, !tbaa !29
  %t247 = load i64, ptr %l125, !tbaa !24
  %t248 = call %"compiler/profile:Frame" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2eAt_3ccompiler_2fprofile_3aFrame_3e(ptr %v1, ptr %t246, i64 %t247)
  store %"compiler/profile:Frame" %t248, ptr %l126
  br label %bb61
bb61:
  %t249 = getelementptr %"compiler/profile:Frame", ptr %l126, i32 0, i32 0
  %t250 = load i64, ptr %t249, !tbaa !24
  %t251 = load i64, ptr %l119, !tbaa !24
  %t253 = add i64 %t251, %t250
  %t254 = load i64, ptr %l7, !tbaa !24
  %t255 = load ptr, ptr %l117, !tbaa !29
  call void @compiler_2fprofile_2eadd(ptr %v2, ptr %t255, i64 %t253, i64 %t254)
  br label %bb62
bb62:
  br label %bb63
bb63:
  br label %bb64
bb64:
  %t258 = load i64, ptr %l12, !tbaa !24
  %t260 = add i64 %t258, 1
  store i64 %t260, ptr %l12, !tbaa !24
  br label %bb35
bb65:
  call void @__olang_scope_close(ptr %s2)
  br label %bb66
bb66:
  %t262 = load i64, ptr %l4, !tbaa !24
  %t264 = add i64 %t262, 1
  store i64 %t264, ptr %l4, !tbaa !24
  br label %bb2
bb67:
  %t266 = load ptr, ptr %lp2
  %t267 = load %"compiler/profile:Tally", ptr %t266
  store %"compiler/profile:Tally" %t267, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/profile:Tally", ptr %rv
  ret %"compiler/profile:Tally" %rr
}

define dso_local void @compiler_2fprofile_2eadd(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  store i64 %t2, ptr %l4, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l9
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l8
  br label %bb1
bb1:
  %t12 = load i64, ptr %l8, !tbaa !24
  store i64 %t12, ptr %l5, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l5, !tbaa !24
  %t16 = add i64 %t14, %a2
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t18 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t17, i64 %t18, i64 %t16)
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l18 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l24 = alloca i64
  %l28 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/profile:Places", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %t3, { i64, ptr } %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l8
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l7
  br label %bb1
bb1:
  %t12 = load i64, ptr %l7, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l3, !tbaa !24
  store i64 %t13, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp sge i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load i64, ptr %l2, !tbaa !24
  store i64 %t18, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/profile:Places", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = extractvalue { i64, ptr } %t23, 0
  %t27 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t25, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = extractvalue { i64, ptr } %t29, 1
  %t33 = mul i64 %t31, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t33)
  call void @llvm.memcpy.p0.p0.i64(ptr %t34, ptr %t32, i64 %t33, i1 false)
  %t35 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t22, { i64, ptr } %t36)
  br label %bb8
bb8:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/profile:Places", ptr %t39, i32 0, i32 1
  store ptr %t41, ptr %l18, !tbaa !29
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 1
  %t45 = extractvalue { i64, ptr } %t42, 0
  %t46 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t45)
  call void @olang_textcopy(ptr %t46, ptr %t44, i64 %t45)
  %t47 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  %t50 = extractvalue { i64, ptr } %t48, 0
  %t51 = extractvalue { i64, ptr } %t48, 1
  %t52 = mul i64 %t50, 1
  %t53 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t52)
  call void @llvm.memcpy.p0.p0.i64(ptr %t53, ptr %t51, i64 %t52, i1 false)
  %t54 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  store { i64, ptr } %t55, ptr %l21, !tbaa !27
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/profile:Places", ptr %t56, i32 0, i32 0
  %t60 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t58)
  store i64 %t60, ptr %l24
  br label %bb9
bb9:
  %t61 = load i64, ptr %l24, !tbaa !24
  %t62 = sub i64 %t61, 1
  %t63 = load ptr, ptr %l18, !tbaa !29
  %t64 = load { i64, ptr }, ptr %l21, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v0, ptr %t63, { i64, ptr } %t64, i64 %t62)
  br label %bb10
bb10:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/profile:Places", ptr %t66, i32 0, i32 0
  %t70 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t68)
  store i64 %t70, ptr %l28
  br label %bb11
bb11:
  %t71 = load i64, ptr %l28, !tbaa !24
  %t72 = sub i64 %t71, 1
  store i64 %t72, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2estack(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/profile:Sample" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/profile:Sample"
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l23 = alloca i64
  %l26 = alloca i64
  %l49 = alloca i64
  %l52 = alloca i64
  %l54 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i32
  %l65 = alloca i64
  %l69 = alloca i64
  %l72 = alloca i64
  %l90 = alloca ptr
  %l94 = alloca i64
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  store %"compiler/profile:Sample" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l18
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t2, ptr %lp3
  %t3 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l18
  %t4 = load ptr, ptr %lp3
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  store i64 0, ptr %l4, !tbaa !24
  %t5 = getelementptr %"compiler/profile:Sample", ptr %l2, i32 0, i32 2
  %t6 = load i64, ptr %t5, !tbaa !24
  store i64 %t6, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = load i64, ptr %l4, !tbaa !24
  %t12 = icmp sgt i64 %t8, %t9
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = load i64, ptr %l6, !tbaa !24
  %t16 = icmp sgt i64 %t14, 0
  br i1 %t16, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb4:
  %t18 = load i64, ptr %l5, !tbaa !24
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = sub i64 %t18, %t19
  %t23 = load i64, ptr %l6, !tbaa !24
  %t26 = add i64 %t22, %t23
  %t28 = sub i64 %t26, 1
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = sdiv i64 %t28, %t29
  store i64 %t32, ptr %l26, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb6
bb6:
  %t34 = load i64, ptr %l26, !tbaa !24
  store i64 %t34, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t35 = load i64, ptr %l23, !tbaa !24
  store i64 %t35, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  %t36 = load i64, ptr %l8, !tbaa !24
  %t37 = load i64, ptr %l7, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb9, label %bb10
bb9:
  br label %bb39
bb10:
  br label %bb11
bb11:
  %t44 = load i64, ptr %l4, !tbaa !24
  %t45 = load i64, ptr %l8, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t49 = mul i64 %t45, %t46
  %t52 = add i64 %t44, %t49
  store i64 %t52, ptr %l9, !tbaa !24
  %t56 = getelementptr %"compiler/profile:Profile", ptr %a1, i32 0, i32 4
  %t57 = getelementptr %"compiler/profile:Sample", ptr %l2, i32 0, i32 1
  %t58 = load i64, ptr %t57, !tbaa !24
  %t59 = load i64, ptr %l9, !tbaa !24
  %t62 = add i64 %t58, %t59
  %t65 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t56, i64 %t62)
  store i64 %t65, ptr %l49
  br label %bb12
bb12:
  %t66 = load i64, ptr %l9, !tbaa !24
  %t68 = icmp eq i64 %t66, 0
  br i1 %t68, label %bb13, label %bb14
bb13:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb15
bb14:
  store i64 1, ptr %l52, !tbaa !24
  br label %bb15
bb15:
  %t70 = load i64, ptr %l49, !tbaa !24
  %t71 = load i64, ptr %l52, !tbaa !24
  %t72 = sub i64 %t70, %t71
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/profile:Places", ptr %t74, i32 0, i32 5
  %t80 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t76, i64 %t72)
  %t81 = extractvalue { i32, i64 } %t80, 1
  %t82 = extractvalue { i32, i64 } %t80, 0
  store i32 %t82, ptr %l59
  %t83 = icmp ne i32 %t82, 0
  br i1 %t83, label %bb17, label %ok.84, !prof !99
ok.84:
  store i64 %t81, ptr %l58
  br label %bb16
bb16:
  %t85 = load i64, ptr %l58, !tbaa !24
  store i64 %t85, ptr %l54, !tbaa !24
  br label %bb19
bb17:
  br label %bb18
bb18:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l54, !tbaa !24
  br label %bb19
bb19:
  %t86 = load i64, ptr %l54, !tbaa !24
  store i64 %t86, ptr %l11, !tbaa !24
  %t87 = load i64, ptr %l11, !tbaa !24
  %t89 = icmp slt i64 %t87, 0
  br i1 %t89, label %bb20, label %bb21
bb20:
  br label %bb38
bb21:
  br label %bb22
bb22:
  store i64 0, ptr %l12, !tbaa !24
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/profile:Places", ptr %t91, i32 0, i32 4
  %t94 = load i64, ptr %l11, !tbaa !24
  %t97 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t93, i64 %t94)
  store i64 %t97, ptr %l65
  br label %bb23
bb23:
  %t98 = load i64, ptr %l65, !tbaa !24
  store i64 %t98, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t99 = load i64, ptr %l13, !tbaa !24
  %t100 = load i64, ptr %l12, !tbaa !24
  %t103 = icmp sgt i64 %t99, %t100
  br i1 %t103, label %bb24, label %bb25
bb24:
  %t105 = load i64, ptr %l14, !tbaa !24
  %t107 = icmp sgt i64 %t105, 0
  br i1 %t107, label %bb26, label %bb27
bb25:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb29
bb26:
  %t109 = load i64, ptr %l13, !tbaa !24
  %t110 = load i64, ptr %l12, !tbaa !24
  %t113 = sub i64 %t109, %t110
  %t114 = load i64, ptr %l14, !tbaa !24
  %t117 = add i64 %t113, %t114
  %t119 = sub i64 %t117, 1
  %t120 = load i64, ptr %l14, !tbaa !24
  %t123 = sdiv i64 %t119, %t120
  store i64 %t123, ptr %l72, !tbaa !24
  br label %bb28
bb27:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb28
bb28:
  %t125 = load i64, ptr %l72, !tbaa !24
  store i64 %t125, ptr %l69, !tbaa !24
  br label %bb29
bb29:
  %t126 = load i64, ptr %l69, !tbaa !24
  store i64 %t126, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb30
bb30:
  %t127 = load i64, ptr %l16, !tbaa !24
  %t128 = load i64, ptr %l15, !tbaa !24
  %t131 = icmp slt i64 %t127, %t128
  %t133 = xor i1 %t131, true
  br i1 %t133, label %bb31, label %bb32
bb31:
  br label %bb37
bb32:
  br label %bb33
bb33:
  %t135 = load i64, ptr %l12, !tbaa !24
  %t136 = load i64, ptr %l16, !tbaa !24
  %t137 = load i64, ptr %l14, !tbaa !24
  %t140 = mul i64 %t136, %t137
  %t143 = add i64 %t135, %t140
  store i64 %t143, ptr %l17, !tbaa !24
  %t145 = load ptr, ptr %lp3
  store ptr %t145, ptr %l90, !tbaa !29
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/profile:Places", ptr %t146, i32 0, i32 3
  %t149 = load i64, ptr %l11, !tbaa !24
  %t152 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t148, i64 %t149)
  store i64 %t152, ptr %l94
  br label %bb34
bb34:
  %t153 = load i64, ptr %l17, !tbaa !24
  %t154 = load i64, ptr %l94, !tbaa !24
  %t156 = add i64 %t154, %t153
  %t157 = load ptr, ptr %l90, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t157, i64 %t156)
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t159 = load i64, ptr %l16, !tbaa !24
  %t161 = add i64 %t159, 1
  store i64 %t161, ptr %l16, !tbaa !24
  br label %bb30
bb37:
  br label %bb38
bb38:
  %t163 = load i64, ptr %l8, !tbaa !24
  %t165 = add i64 %t163, 1
  store i64 %t165, ptr %l8, !tbaa !24
  br label %bb8
bb39:
  %t167 = load ptr, ptr %lp3
  %t168 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t167
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t168, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i64 @compiler_2fprofile_2ecompiler_2fprofile_3aProfile_2eTotal(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/profile:Sample"
  %l7 = alloca i64
  %l9 = alloca i64
  %l14 = alloca %"compiler/profile:Sample"
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t3 = getelementptr %"compiler/profile:Profile", ptr %a0, i32 0, i32 3
  store ptr %t3, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l3, !tbaa !24
  store i64 %t5, ptr %l7, !tbaa !24
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2eLen_3ccompiler_2fprofile_3aSample_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l9
  br label %bb2
bb2:
  %t9 = load i64, ptr %l7, !tbaa !24
  %t10 = load i64, ptr %l9, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = call %"compiler/profile:Sample" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2eAt_3ccompiler_2fprofile_3aSample_3e(ptr %v0, ptr %t15, i64 %t16)
  store %"compiler/profile:Sample" %t19, ptr %l14
  br label %bb6
bb6:
  %t20 = load %"compiler/profile:Sample", ptr %l14
  store %"compiler/profile:Sample" %t20, ptr %l4
  %t21 = load i64, ptr %l1, !tbaa !24
  %t22 = getelementptr %"compiler/profile:Sample", ptr %l4, i32 0, i32 0
  %t23 = load i64, ptr %t22, !tbaa !24
  %t26 = add i64 %t21, %t23
  store i64 %t26, ptr %l1, !tbaa !24
  br label %bb7
bb7:
  %t28 = load i64, ptr %l3, !tbaa !24
  %t30 = add i64 %t28, 1
  store i64 %t30, ptr %l3, !tbaa !24
  br label %bb1
bb8:
  %t32 = load i64, ptr %l1, !tbaa !24
  store i64 %t32, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fprofile_2eescapeXml(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb24
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l14, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 %t18
  %t23 = load i8, ptr %t22, !tbaa !32
  store i8 %t23, ptr %l5, !tbaa !22
  %t25 = load i8, ptr %l5, !tbaa !22
  %t27 = icmp eq i8 %t25, 60
  br i1 %t27, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d111, i32 0, i32 1) })
  br label %bb8
bb7:
  %t30 = load i8, ptr %l5, !tbaa !22
  %t32 = icmp eq i8 %t30, 62
  br i1 %t32, label %bb9, label %bb10
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb9:
  store %olang.scope zeroinitializer, ptr %s5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %l1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d112, i32 0, i32 1) })
  br label %bb11
bb10:
  %t35 = load i8, ptr %l5, !tbaa !22
  %t37 = icmp eq i8 %t35, 38
  br i1 %t37, label %bb12, label %bb13
bb11:
  call void @__olang_scope_close(ptr %s5)
  br label %bb21
bb12:
  store %olang.scope zeroinitializer, ptr %s7
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %l1, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d113, i32 0, i32 1) })
  br label %bb14
bb13:
  %t40 = load i8, ptr %l5, !tbaa !22
  %t42 = icmp eq i8 %t40, 34
  br i1 %t42, label %bb15, label %bb16
bb14:
  call void @__olang_scope_close(ptr %s7)
  br label %bb20
bb15:
  store %olang.scope zeroinitializer, ptr %s9
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s9, ptr %l1, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d114, i32 0, i32 1) })
  br label %bb17
bb16:
  %t45 = load i8, ptr %l5, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 %t45)
  br label %bb18
bb17:
  call void @__olang_scope_close(ptr %s9)
  br label %bb19
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t48 = load i64, ptr %l3, !tbaa !24
  %t50 = add i64 %t48, 1
  store i64 %t50, ptr %l3, !tbaa !24
  br label %bb2
bb24:
  %t53 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t53, ptr %l34
  br label %bb25
bb25:
  %t54 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t54, ptr %l35, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 0
  store i64 %t56, ptr %l36, !tbaa !24
  %t57 = load i64, ptr %l36, !tbaa !24
  %t58 = mul i64 %t57, 1
  %t59 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t58)
  %t60 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l37, !tbaa !27
  %t62 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = load i64, ptr %l36, !tbaa !24
  %t67 = mul i64 %t66, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t63, ptr %t65, i64 %t67, i1 false)
  %t68 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t68, ptr %l35, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t69 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t69, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { { i64, ptr }, i64 } @compiler_2fprofile_2efileLine(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l20 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i32
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l40 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca i32
  %l51 = alloca i64
  %l52 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, i64 }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d115, i32 0, i32 1) })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l7
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store i64 %t4, ptr %l6
  br label %bb1
bb1:
  %t8 = load i64, ptr %l6, !tbaa !24
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t9 = load i64, ptr %l4, !tbaa !24
  store i64 %t9, ptr %l1, !tbaa !24
  %t10 = load i64, ptr %l1, !tbaa !24
  %t12 = icmp slt i64 %t10, 0
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 1
  %t17 = extractvalue { i64, ptr } %t14, 0
  %t18 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t17)
  call void @olang_textcopy(ptr %t18, ptr %t16, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  %t22 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t20, 0
  %t23 = insertvalue { { i64, ptr }, i64 } %t22, i64 0, 1
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i64 } %t23, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t25 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t25, ptr %l13, !tbaa !27
  %t26 = load i64, ptr %l1, !tbaa !24
  store i64 %t26, ptr %l14, !tbaa !24
  %t27 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t27, 0
  store i64 %t28, ptr %l15, !tbaa !24
  %t29 = icmp sge i64 0, 0
  br i1 %t29, label %bb8, label %bb9
bb8:
  %t31 = load i64, ptr %l14, !tbaa !24
  %t32 = icmp sle i64 0, %t31
  br i1 %t32, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_7d2ae97c2364b59d_ce98559d67a1b5c9)
  unreachable
bb10:
  %t34 = load i64, ptr %l14, !tbaa !24
  %t35 = load i64, ptr %l15, !tbaa !24
  %t36 = icmp sle i64 %t34, %t35
  br i1 %t36, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_7d2ae97c2364b59d_ce98559d67a1b5c9)
  unreachable
bb12:
  %t38 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = load i64, ptr %l14, !tbaa !24
  %t41 = getelementptr i8, ptr %t39, i64 0
  %t42 = sub i64 %t40, 0
  %t43 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t41, 1
  store { i64, ptr } %t44, ptr %l2, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t48 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s0, { i64, ptr } %t46, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d116, i32 0, i32 1) })
  %t49 = extractvalue { i32, i64 } %t48, 1
  %t50 = extractvalue { i32, i64 } %t48, 0
  store i32 %t50, ptr %l23
  %t51 = icmp ne i32 %t50, 0
  br i1 %t51, label %bb15, label %ok.52, !prof !99
ok.52:
  store i64 %t49, ptr %l22
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_7d2ae97c2364b59d_ce98559d67a1b5c9)
  unreachable
bb14:
  %t53 = load i64, ptr %l22, !tbaa !24
  store i64 %t53, ptr %l20, !tbaa !24
  br label %bb17
bb15:
  br label %bb16
bb16:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l20, !tbaa !24
  br label %bb17
bb17:
  %t54 = load i64, ptr %l20, !tbaa !24
  store i64 %t54, ptr %l3, !tbaa !24
  %t55 = load i64, ptr %l3, !tbaa !24
  %t57 = icmp slt i64 %t55, 0
  br i1 %t57, label %bb18, label %bb19
bb18:
  %t59 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 1
  %t62 = extractvalue { i64, ptr } %t59, 0
  %t63 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t62)
  call void @olang_textcopy(ptr %t63, ptr %t61, i64 %t62)
  %t64 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  %t67 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t65, 0
  %t68 = insertvalue { { i64, ptr }, i64 } %t67, i64 0, 1
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i64 } %t68, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t70 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t70, ptr %l29, !tbaa !27
  %t71 = load i64, ptr %l3, !tbaa !24
  store i64 %t71, ptr %l30, !tbaa !24
  %t72 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 0
  store i64 %t73, ptr %l31, !tbaa !24
  %t74 = icmp sge i64 0, 0
  br i1 %t74, label %bb21, label %bb22
bb21:
  %t76 = load i64, ptr %l30, !tbaa !24
  %t77 = icmp sle i64 0, %t76
  br i1 %t77, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_ec3589048a52ea40_4feb0c814716a05c)
  unreachable
bb23:
  %t79 = load i64, ptr %l30, !tbaa !24
  %t80 = load i64, ptr %l31, !tbaa !24
  %t81 = icmp sle i64 %t79, %t80
  br i1 %t81, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_ec3589048a52ea40_4feb0c814716a05c)
  unreachable
bb25:
  %t83 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = load i64, ptr %l30, !tbaa !24
  %t86 = getelementptr i8, ptr %t84, i64 0
  %t87 = sub i64 %t85, 0
  %t88 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t86, 1
  %t91 = extractvalue { i64, ptr } %t89, 1
  %t92 = extractvalue { i64, ptr } %t89, 0
  %t93 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t92)
  call void @olang_textcopy(ptr %t93, ptr %t91, i64 %t92)
  %t94 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t93, 1
  store { i64, ptr } %t95, ptr %l36, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t96, ptr %l38, !tbaa !27
  %t97 = load i64, ptr %l3, !tbaa !24
  %t99 = add i64 %t97, 1
  store i64 %t99, ptr %l40, !tbaa !24
  %t100 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t100, 0
  store i64 %t103, ptr %l43, !tbaa !24
  %t104 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 0
  store i64 %t105, ptr %l44, !tbaa !24
  %t106 = load i64, ptr %l40, !tbaa !24
  %t107 = icmp sge i64 %t106, 0
  br i1 %t107, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_ec3589048a52ea40_4feb0c814716a05c)
  unreachable
bb27:
  %t109 = load i64, ptr %l40, !tbaa !24
  %t110 = load i64, ptr %l43, !tbaa !24
  %t111 = icmp sle i64 %t109, %t110
  br i1 %t111, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_ec3589048a52ea40_4feb0c814716a05c)
  unreachable
bb29:
  %t113 = load i64, ptr %l43, !tbaa !24
  %t114 = load i64, ptr %l44, !tbaa !24
  %t115 = icmp sle i64 %t113, %t114
  br i1 %t115, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_ec3589048a52ea40_4feb0c814716a05c)
  unreachable
bb31:
  %t117 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = load i64, ptr %l40, !tbaa !24
  %t120 = load i64, ptr %l43, !tbaa !24
  %t121 = getelementptr i8, ptr %t118, i64 %t119
  %t122 = sub i64 %t120, %t119
  %t123 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t121, 1
  store { i64, ptr } %t124, ptr %l48, !tbaa !27
  %t125 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 10)
  %t126 = extractvalue { i32, i64 } %t125, 1
  %t127 = extractvalue { i32, i64 } %t125, 0
  store i32 %t127, ptr %l50
  %t128 = icmp ne i32 %t127, 0
  br i1 %t128, label %bb34, label %ok.129, !prof !99
ok.129:
  store i64 %t126, ptr %l49
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_ec3589048a52ea40_4feb0c814716a05c)
  unreachable
bb33:
  %t130 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t131 = load i64, ptr %l49, !tbaa !24
  %t132 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %t130, i64 %t131)
  %t133 = extractvalue { i32, i64 } %t132, 1
  %t134 = extractvalue { i32, i64 } %t132, 0
  store i32 %t134, ptr %l52
  %t135 = icmp ne i32 %t134, 0
  br i1 %t135, label %bb37, label %ok.136, !prof !99
ok.136:
  store i64 %t133, ptr %l51
  br label %bb36
bb34:
  br label %bb35
bb35:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l37, !tbaa !24
  br label %bb38
bb36:
  %t137 = load i64, ptr %l51, !tbaa !24
  store i64 %t137, ptr %l37, !tbaa !24
  br label %bb38
bb37:
  br label %bb35
bb38:
  %t138 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t139 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t138, 0
  %t140 = load i64, ptr %l37, !tbaa !24
  %t141 = insertvalue { { i64, ptr }, i64 } %t139, i64 %t140, 1
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i64 } %t141, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, i64 }, ptr %rv
  ret { { i64, ptr }, i64 } %rr
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fprofile_2efunctionSymbols(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %lp1 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l30 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca i32
  %l35 = alloca i1
  %l40 = alloca i1
  %l41 = alloca { i64, ptr }
  %l45 = alloca i1
  %l46 = alloca { i64, ptr }
  %l51 = alloca i1
  %l52 = alloca { i64, ptr }
  %l59 = alloca i64
  %l62 = alloca i64
  %l65 = alloca i64
  %l70 = alloca i64
  %l73 = alloca i64
  %l105 = alloca i64
  %l108 = alloca i1
  %l115 = alloca i64
  %l120 = alloca i64
  %l125 = alloca i64
  %l130 = alloca i64
  %l139 = alloca i64
  %l142 = alloca i1
  %l155 = alloca i64
  %l158 = alloca i64
  %l185 = alloca i64
  %l186 = alloca { i64, ptr }
  %l193 = alloca i1
  %l196 = alloca i64
  %l200 = alloca i64
  %l207 = alloca i1
  %l208 = alloca { i64, ptr }
  %l216 = alloca ptr
  %l217 = alloca i64
  %l222 = alloca i64
  %l223 = alloca { i64, ptr }
  %l224 = alloca i64
  %l225 = alloca i64
  %l226 = alloca i64
  %l232 = alloca %"compiler/profile:elfFn"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aelfFn_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l29
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l29
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  %t7 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
  %t8 = extractvalue { i32, { i64, ptr } } %t7, 1
  %t9 = extractvalue { i32, { i64, ptr } } %t7, 0
  store i32 %t9, ptr %l33
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb3, label %ok.11, !prof !99
ok.11:
  store { i64, ptr } %t8, ptr %l32
  br label %bb2
bb2:
  %t12 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t12, ptr %l30, !tbaa !27
  br label %bb5
bb3:
  %t13 = load i32, ptr %l33, !tbaa !23
  %t14 = ashr i32 %t13, 16
  %t16 = icmp eq i32 %t14, 1
  store i1 %t16, ptr %l35, !tbaa !21
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  %t17 = load ptr, ptr %lp1
  %t18 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t17
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t18, ptr %rv
  br label %ret
bb5:
  %t20 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t20, ptr %lp2
  %t21 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t22 = load ptr, ptr %lp2
  store { i64, ptr } %t21, ptr %t22, !tbaa !27
  %t23 = load ptr, ptr %lp2
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = icmp slt i64 %t26, 64
  br i1 %t28, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb8
bb7:
  %t30 = load ptr, ptr %lp2
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  store { i64, ptr } %t31, ptr %l41, !tbaa !27
  %t32 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr i8, ptr %t33, i64 0
  %t35 = load i8, ptr %t34, !tbaa !32
  %t38 = icmp ne i8 %t35, 127
  store i1 %t38, ptr %l40, !tbaa !21
  br label %bb8
bb8:
  %t40 = load i1, ptr %l40, !tbaa !21
  br i1 %t40, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb11
bb10:
  %t41 = load ptr, ptr %lp2
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  store { i64, ptr } %t42, ptr %l46, !tbaa !27
  %t43 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr i8, ptr %t44, i64 1
  %t46 = load i8, ptr %t45, !tbaa !32
  %t50 = icmp ne i8 %t46, 69
  store i1 %t50, ptr %l45, !tbaa !21
  br label %bb11
bb11:
  %t52 = load i1, ptr %l45, !tbaa !21
  br i1 %t52, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb14
bb13:
  %t53 = load ptr, ptr %lp2
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  store { i64, ptr } %t54, ptr %l52, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr i8, ptr %t56, i64 4
  %t58 = load i8, ptr %t57, !tbaa !32
  %t61 = icmp ne i8 %t58, 2
  store i1 %t61, ptr %l51, !tbaa !21
  br label %bb14
bb14:
  %t63 = load i1, ptr %l51, !tbaa !21
  br i1 %t63, label %bb15, label %bb16
bb15:
  %t64 = load ptr, ptr %lp1
  %t65 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t64
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t65, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t67 = load ptr, ptr %lp2
  %t68 = load { i64, ptr }, ptr %t67, !tbaa !27
  %t71 = call i64 @compiler_2fprofile_2ele(ptr %v1, { i64, ptr } %t68, i64 40, i64 8)
  store i64 %t71, ptr %l59
  br label %bb18
bb18:
  %t72 = load i64, ptr %l59, !tbaa !24
  store i64 %t72, ptr %l3, !tbaa !24
  %t73 = load ptr, ptr %lp2
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !27
  %t77 = call i64 @compiler_2fprofile_2ele(ptr %v1, { i64, ptr } %t74, i64 58, i64 2)
  store i64 %t77, ptr %l62
  br label %bb19
bb19:
  %t78 = load i64, ptr %l62, !tbaa !24
  store i64 %t78, ptr %l4, !tbaa !24
  %t79 = load ptr, ptr %lp2
  %t80 = load { i64, ptr }, ptr %t79, !tbaa !27
  %t83 = call i64 @compiler_2fprofile_2ele(ptr %v1, { i64, ptr } %t80, i64 60, i64 2)
  store i64 %t83, ptr %l65
  br label %bb20
bb20:
  %t84 = load i64, ptr %l65, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  store i64 %t84, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t87 = load i64, ptr %l7, !tbaa !24
  %t88 = load i64, ptr %l6, !tbaa !24
  %t91 = icmp sgt i64 %t87, %t88
  br i1 %t91, label %bb21, label %bb22
bb21:
  %t93 = load i64, ptr %l8, !tbaa !24
  %t95 = icmp sgt i64 %t93, 0
  br i1 %t95, label %bb23, label %bb24
bb22:
  store i64 0, ptr %l70, !tbaa !24
  br label %bb26
bb23:
  %t97 = load i64, ptr %l7, !tbaa !24
  %t98 = load i64, ptr %l6, !tbaa !24
  %t101 = sub i64 %t97, %t98
  %t102 = load i64, ptr %l8, !tbaa !24
  %t105 = add i64 %t101, %t102
  %t107 = sub i64 %t105, 1
  %t108 = load i64, ptr %l8, !tbaa !24
  %t111 = sdiv i64 %t107, %t108
  store i64 %t111, ptr %l73, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l73, !tbaa !24
  br label %bb25
bb25:
  %t113 = load i64, ptr %l73, !tbaa !24
  store i64 %t113, ptr %l70, !tbaa !24
  br label %bb26
bb26:
  %t114 = load i64, ptr %l70, !tbaa !24
  store i64 %t114, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb27
bb27:
  %t115 = load i64, ptr %l10, !tbaa !24
  %t116 = load i64, ptr %l9, !tbaa !24
  %t119 = icmp slt i64 %t115, %t116
  %t121 = xor i1 %t119, true
  br i1 %t121, label %bb28, label %bb29
bb28:
  br label %bb91
bb29:
  br label %bb30
bb30:
  %t123 = load i64, ptr %l6, !tbaa !24
  %t124 = load i64, ptr %l10, !tbaa !24
  %t125 = load i64, ptr %l8, !tbaa !24
  %t128 = mul i64 %t124, %t125
  %t131 = add i64 %t123, %t128
  %t133 = load i64, ptr %l3, !tbaa !24
  %t135 = load i64, ptr %l4, !tbaa !24
  %t138 = mul i64 %t131, %t135
  %t141 = add i64 %t133, %t138
  store i64 %t141, ptr %l12, !tbaa !24
  %t143 = load i64, ptr %l12, !tbaa !24
  %t145 = add i64 %t143, 64
  %t146 = load ptr, ptr %lp2
  %t147 = load { i64, ptr }, ptr %t146, !tbaa !27
  %t149 = extractvalue { i64, ptr } %t147, 0
  %t152 = icmp sgt i64 %t145, %t149
  br i1 %t152, label %bb31, label %bb32
bb31:
  br label %bb91
bb32:
  br label %bb33
bb33:
  %t154 = load ptr, ptr %lp2
  %t155 = load { i64, ptr }, ptr %t154, !tbaa !27
  %t157 = load i64, ptr %l12, !tbaa !24
  %t159 = add i64 %t157, 4
  %t162 = call i64 @compiler_2fprofile_2ele(ptr %v1, { i64, ptr } %t155, i64 %t159, i64 4)
  store i64 %t162, ptr %l105
  br label %bb34
bb34:
  %t163 = load i64, ptr %l105, !tbaa !24
  store i64 %t163, ptr %l13, !tbaa !24
  %t164 = load i64, ptr %l13, !tbaa !24
  %t166 = icmp ne i64 %t164, 2
  br i1 %t166, label %bb35, label %bb36
bb35:
  %t168 = load i64, ptr %l13, !tbaa !24
  %t170 = icmp ne i64 %t168, 11
  store i1 %t170, ptr %l108, !tbaa !21
  br label %bb37
bb36:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb37
bb37:
  %t172 = load i1, ptr %l108, !tbaa !21
  br i1 %t172, label %bb38, label %bb39
bb38:
  br label %bb90
bb39:
  br label %bb40
bb40:
  %t173 = load ptr, ptr %lp2
  %t174 = load { i64, ptr }, ptr %t173, !tbaa !27
  %t176 = load i64, ptr %l12, !tbaa !24
  %t178 = add i64 %t176, 24
  %t181 = call i64 @compiler_2fprofile_2ele(ptr %v1, { i64, ptr } %t174, i64 %t178, i64 8)
  store i64 %t181, ptr %l115
  br label %bb41
bb41:
  %t182 = load i64, ptr %l115, !tbaa !24
  store i64 %t182, ptr %l14, !tbaa !24
  %t183 = load ptr, ptr %lp2
  %t184 = load { i64, ptr }, ptr %t183, !tbaa !27
  %t186 = load i64, ptr %l12, !tbaa !24
  %t188 = add i64 %t186, 32
  %t191 = call i64 @compiler_2fprofile_2ele(ptr %v1, { i64, ptr } %t184, i64 %t188, i64 8)
  store i64 %t191, ptr %l120
  br label %bb42
bb42:
  %t192 = load i64, ptr %l120, !tbaa !24
  store i64 %t192, ptr %l15, !tbaa !24
  %t193 = load ptr, ptr %lp2
  %t194 = load { i64, ptr }, ptr %t193, !tbaa !27
  %t196 = load i64, ptr %l12, !tbaa !24
  %t198 = add i64 %t196, 40
  %t201 = call i64 @compiler_2fprofile_2ele(ptr %v1, { i64, ptr } %t194, i64 %t198, i64 4)
  store i64 %t201, ptr %l125
  br label %bb43
bb43:
  %t202 = load i64, ptr %l125, !tbaa !24
  store i64 %t202, ptr %l16, !tbaa !24
  %t203 = load ptr, ptr %lp2
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  %t206 = load i64, ptr %l12, !tbaa !24
  %t208 = add i64 %t206, 56
  %t211 = call i64 @compiler_2fprofile_2ele(ptr %v1, { i64, ptr } %t204, i64 %t208, i64 8)
  store i64 %t211, ptr %l130
  br label %bb44
bb44:
  %t212 = load i64, ptr %l130, !tbaa !24
  store i64 %t212, ptr %l17, !tbaa !24
  %t213 = load ptr, ptr %lp2
  %t214 = load { i64, ptr }, ptr %t213, !tbaa !27
  %t216 = load i64, ptr %l3, !tbaa !24
  %t217 = load i64, ptr %l16, !tbaa !24
  %t218 = load i64, ptr %l4, !tbaa !24
  %t221 = mul i64 %t217, %t218
  %t224 = add i64 %t216, %t221
  %t226 = add i64 %t224, 24
  %t229 = call i64 @compiler_2fprofile_2ele(ptr %v1, { i64, ptr } %t214, i64 %t226, i64 8)
  store i64 %t229, ptr %l139
  br label %bb45
bb45:
  %t230 = load i64, ptr %l139, !tbaa !24
  store i64 %t230, ptr %l18, !tbaa !24
  %t231 = load i64, ptr %l17, !tbaa !24
  %t233 = icmp slt i64 %t231, 24
  br i1 %t233, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l142, !tbaa !21
  br label %bb48
bb47:
  %t235 = load i64, ptr %l14, !tbaa !24
  %t236 = load i64, ptr %l15, !tbaa !24
  %t239 = add i64 %t235, %t236
  %t240 = load ptr, ptr %lp2
  %t241 = load { i64, ptr }, ptr %t240, !tbaa !27
  %t243 = extractvalue { i64, ptr } %t241, 0
  %t246 = icmp sgt i64 %t239, %t243
  store i1 %t246, ptr %l142, !tbaa !21
  br label %bb48
bb48:
  %t248 = load i1, ptr %l142, !tbaa !21
  br i1 %t248, label %bb49, label %bb50
bb49:
  br label %bb90
bb50:
  br label %bb51
bb51:
  store i64 0, ptr %l19, !tbaa !24
  %t249 = load i64, ptr %l15, !tbaa !24
  %t250 = load i64, ptr %l17, !tbaa !24
  %t253 = sdiv i64 %t249, %t250
  store i64 %t253, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t255 = load i64, ptr %l20, !tbaa !24
  %t256 = load i64, ptr %l19, !tbaa !24
  %t259 = icmp sgt i64 %t255, %t256
  br i1 %t259, label %bb52, label %bb53
bb52:
  %t261 = load i64, ptr %l21, !tbaa !24
  %t263 = icmp sgt i64 %t261, 0
  br i1 %t263, label %bb54, label %bb55
bb53:
  store i64 0, ptr %l155, !tbaa !24
  br label %bb57
bb54:
  %t265 = load i64, ptr %l20, !tbaa !24
  %t266 = load i64, ptr %l19, !tbaa !24
  %t269 = sub i64 %t265, %t266
  %t270 = load i64, ptr %l21, !tbaa !24
  %t273 = add i64 %t269, %t270
  %t275 = sub i64 %t273, 1
  %t276 = load i64, ptr %l21, !tbaa !24
  %t279 = sdiv i64 %t275, %t276
  store i64 %t279, ptr %l158, !tbaa !24
  br label %bb56
bb55:
  store i64 0, ptr %l158, !tbaa !24
  br label %bb56
bb56:
  %t281 = load i64, ptr %l158, !tbaa !24
  store i64 %t281, ptr %l155, !tbaa !24
  br label %bb57
bb57:
  %t282 = load i64, ptr %l155, !tbaa !24
  store i64 %t282, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb58
bb58:
  %t283 = load i64, ptr %l23, !tbaa !24
  %t284 = load i64, ptr %l22, !tbaa !24
  %t287 = icmp slt i64 %t283, %t284
  %t289 = xor i1 %t287, true
  br i1 %t289, label %bb59, label %bb60
bb59:
  br label %bb89
bb60:
  br label %bb61
bb61:
  %t291 = load i64, ptr %l19, !tbaa !24
  %t292 = load i64, ptr %l23, !tbaa !24
  %t293 = load i64, ptr %l21, !tbaa !24
  %t296 = mul i64 %t292, %t293
  %t299 = add i64 %t291, %t296
  %t301 = load i64, ptr %l14, !tbaa !24
  %t303 = load i64, ptr %l17, !tbaa !24
  %t306 = mul i64 %t299, %t303
  %t309 = add i64 %t301, %t306
  store i64 %t309, ptr %l25, !tbaa !24
  %t311 = load ptr, ptr %lp2
  %t312 = load { i64, ptr }, ptr %t311, !tbaa !27
  %t314 = load i64, ptr %l25, !tbaa !24
  %t316 = add i64 %t314, 8
  %t319 = call i64 @compiler_2fprofile_2ele(ptr %v1, { i64, ptr } %t312, i64 %t316, i64 8)
  store i64 %t319, ptr %l185
  br label %bb62
bb62:
  %t320 = load i64, ptr %l185, !tbaa !24
  store i64 %t320, ptr %l26, !tbaa !24
  %t321 = load ptr, ptr %lp2
  %t322 = load { i64, ptr }, ptr %t321, !tbaa !27
  store { i64, ptr } %t322, ptr %l186, !tbaa !27
  %t323 = load i64, ptr %l25, !tbaa !24
  %t325 = add i64 %t323, 4
  %t327 = getelementptr { i64, ptr }, ptr %l186, i32 0, i32 1
  %t328 = load ptr, ptr %t327, !tbaa !27
  %t329 = getelementptr i8, ptr %t328, i64 %t325
  %t330 = load i8, ptr %t329, !tbaa !32
  %t332 = zext i8 %t330 to i64
  %t334 = and i64 %t332, 15
  %t336 = icmp ne i64 %t334, 2
  br i1 %t336, label %bb63, label %bb64
bb63:
  store i1 true, ptr %l193, !tbaa !21
  br label %bb65
bb64:
  %t338 = load i64, ptr %l26, !tbaa !24
  %t340 = icmp eq i64 %t338, 0
  store i1 %t340, ptr %l193, !tbaa !21
  br label %bb65
bb65:
  %t342 = load i1, ptr %l193, !tbaa !21
  br i1 %t342, label %bb66, label %bb67
bb66:
  br label %bb88
bb67:
  br label %bb68
bb68:
  %t343 = load i64, ptr %l18, !tbaa !24
  store i64 %t343, ptr %l196, !tbaa !24
  %t344 = load ptr, ptr %lp2
  %t345 = load { i64, ptr }, ptr %t344, !tbaa !27
  %t347 = load i64, ptr %l25, !tbaa !24
  %t350 = call i64 @compiler_2fprofile_2ele(ptr %v1, { i64, ptr } %t345, i64 %t347, i64 4)
  store i64 %t350, ptr %l200
  br label %bb69
bb69:
  %t351 = load i64, ptr %l196, !tbaa !24
  %t352 = load i64, ptr %l200, !tbaa !24
  %t353 = add i64 %t351, %t352
  store i64 %t353, ptr %l27, !tbaa !24
  %t355 = load i64, ptr %l27, !tbaa !24
  store i64 %t355, ptr %l28, !tbaa !24
  br label %bb70
bb70:
  %t357 = load i64, ptr %l28, !tbaa !24
  %t358 = load ptr, ptr %lp2
  %t359 = load { i64, ptr }, ptr %t358, !tbaa !27
  %t361 = extractvalue { i64, ptr } %t359, 0
  %t364 = icmp slt i64 %t357, %t361
  br i1 %t364, label %bb71, label %bb72
bb71:
  %t366 = load ptr, ptr %lp2
  %t367 = load { i64, ptr }, ptr %t366, !tbaa !27
  store { i64, ptr } %t367, ptr %l208, !tbaa !27
  %t368 = load i64, ptr %l28, !tbaa !24
  %t370 = getelementptr { i64, ptr }, ptr %l208, i32 0, i32 1
  %t371 = load ptr, ptr %t370, !tbaa !27
  %t372 = getelementptr i8, ptr %t371, i64 %t368
  %t373 = load i8, ptr %t372, !tbaa !32
  %t376 = icmp ne i8 %t373, 0
  store i1 %t376, ptr %l207, !tbaa !21
  br label %bb73
bb72:
  store i1 false, ptr %l207, !tbaa !21
  br label %bb73
bb73:
  %t378 = load i1, ptr %l207, !tbaa !21
  %t379 = xor i1 %t378, true
  br i1 %t379, label %bb74, label %bb75
bb74:
  br label %bb78
bb75:
  br label %bb76
bb76:
  %t381 = load i64, ptr %l28, !tbaa !24
  %t383 = add i64 %t381, 1
  store i64 %t383, ptr %l28, !tbaa !24
  br label %bb77
bb77:
  br label %bb70
bb78:
  %t385 = load ptr, ptr %lp1
  store ptr %t385, ptr %l216, !tbaa !29
  %t386 = load i64, ptr %l26, !tbaa !24
  store i64 %t386, ptr %l217, !tbaa !24
  %t387 = load ptr, ptr %lp2
  %t388 = load { i64, ptr }, ptr %t387, !tbaa !27
  %t390 = load i64, ptr %l25, !tbaa !24
  %t392 = add i64 %t390, 16
  %t395 = call i64 @compiler_2fprofile_2ele(ptr %v1, { i64, ptr } %t388, i64 %t392, i64 8)
  store i64 %t395, ptr %l222
  br label %bb79
bb79:
  %t396 = load ptr, ptr %lp2
  %t397 = load { i64, ptr }, ptr %t396, !tbaa !27
  store { i64, ptr } %t397, ptr %l223, !tbaa !27
  %t398 = load i64, ptr %l27, !tbaa !24
  store i64 %t398, ptr %l224, !tbaa !24
  %t399 = load i64, ptr %l28, !tbaa !24
  store i64 %t399, ptr %l225, !tbaa !24
  %t400 = load { i64, ptr }, ptr %l223, !tbaa !27
  %t401 = extractvalue { i64, ptr } %t400, 0
  store i64 %t401, ptr %l226, !tbaa !24
  %t402 = load i64, ptr %l224, !tbaa !24
  %t403 = icmp sge i64 %t402, 0
  br i1 %t403, label %bb80, label %bb81
bb80:
  %t405 = load i64, ptr %l224, !tbaa !24
  %t406 = load i64, ptr %l225, !tbaa !24
  %t407 = icmp sle i64 %t405, %t406
  br i1 %t407, label %bb82, label %bb83
bb81:
  call void @__olang_check_failed(ptr @olang_loc_47d41d181de998ca_407a2b261e632036)
  unreachable
bb82:
  %t409 = load i64, ptr %l225, !tbaa !24
  %t410 = load i64, ptr %l226, !tbaa !24
  %t411 = icmp sle i64 %t409, %t410
  br i1 %t411, label %bb84, label %bb85
bb83:
  call void @__olang_check_failed(ptr @olang_loc_47d41d181de998ca_407a2b261e632036)
  unreachable
bb84:
  %t413 = getelementptr { i64, ptr }, ptr %l223, i32 0, i32 1
  %t414 = load ptr, ptr %t413, !tbaa !27
  %t415 = load i64, ptr %l224, !tbaa !24
  %t416 = load i64, ptr %l225, !tbaa !24
  %t417 = getelementptr i8, ptr %t414, i64 %t415
  %t418 = sub i64 %t416, %t415
  %t419 = insertvalue { i64, ptr } undef, i64 %t418, 0
  %t420 = insertvalue { i64, ptr } %t419, ptr %t417, 1
  %t422 = load i64, ptr %l217, !tbaa !24
  %t423 = load i64, ptr %l222, !tbaa !24
  %t425 = call %"compiler/profile:elfFn" @compiler_2fprofile_3aelfFn_2ector(ptr %v1, ptr %v1, i64 %t422, i64 %t423, { i64, ptr } %t420)
  store %"compiler/profile:elfFn" %t425, ptr %l232
  br label %bb86
bb85:
  call void @__olang_check_failed(ptr @olang_loc_47d41d181de998ca_407a2b261e632036)
  unreachable
bb86:
  %t426 = load ptr, ptr %l216, !tbaa !29
  %t427 = load %"compiler/profile:elfFn", ptr %l232
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aelfFn_3e_2ePush_3ccompiler_2fprofile_3aelfFn_3e(ptr %v1, ptr %v1, ptr %t426, %"compiler/profile:elfFn" %t427)
  br label %bb87
bb87:
  br label %bb88
bb88:
  %t428 = load i64, ptr %l23, !tbaa !24
  %t430 = add i64 %t428, 1
  store i64 %t430, ptr %l23, !tbaa !24
  br label %bb58
bb89:
  br label %bb90
bb90:
  %t432 = load i64, ptr %l10, !tbaa !24
  %t434 = add i64 %t432, 1
  store i64 %t434, ptr %l10, !tbaa !24
  br label %bb27
bb91:
  %t436 = load ptr, ptr %lp1
  %t437 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_117, 0
  %t438 = insertvalue { ptr, ptr } %t437, ptr null, 1
  %t441 = extractvalue { ptr, ptr } %t438, 0
  %t442 = extractvalue { ptr, ptr } %t438, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aelfFn_3e_2eSort_3_H16cb1151e861568c30a5b57cf3c12bc1(ptr %v1, ptr %s0, ptr %t436, ptr %t441, ptr %t442)
  br label %bb92
bb92:
  %t443 = load ptr, ptr %lp1
  %t444 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t443
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t444, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i64 @compiler_2fprofile_2ehex(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  %t2 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 16)
  %t3 = extractvalue { i32, i64 } %t2, 1
  %t4 = extractvalue { i32, i64 } %t2, 0
  store i32 %t4, ptr %l4
  %t5 = icmp ne i32 %t4, 0
  br i1 %t5, label %bb2, label %ok.6, !prof !99
ok.6:
  store i64 %t3, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %t7, i64 %t8)
  %t10 = extractvalue { i32, i64 } %t9, 1
  %t11 = extractvalue { i32, i64 } %t9, 0
  store i32 %t11, ptr %l6
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb5, label %ok.13, !prof !99
ok.13:
  store i64 %t10, ptr %l5
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l1, !tbaa !24
  br label %bb6
bb4:
  %t14 = load i64, ptr %l5, !tbaa !24
  store i64 %t14, ptr %l1, !tbaa !24
  br label %bb6
bb5:
  br label %bb3
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t15 = load i64, ptr %l1, !tbaa !24
  store i64 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fprofile_2eidentityChar(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l2 = alloca i1
  %l3 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %rv = alloca i1
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l0, !tbaa !22
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t1)
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb5
bb3:
  %t5 = load i8, ptr %l0, !tbaa !22
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t5)
  store i1 %t7, ptr %l5
  br label %bb4
bb4:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb5
bb5:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb8
bb7:
  %t10 = load i8, ptr %l0, !tbaa !22
  %t12 = icmp eq i8 %t10, 95
  store i1 %t12, ptr %l6, !tbaa !21
  br label %bb8
bb8:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb11
bb10:
  %t15 = load i8, ptr %l0, !tbaa !22
  %t17 = icmp eq i8 %t15, 47
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb11
bb11:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb14
bb13:
  %t20 = load i8, ptr %l0, !tbaa !22
  %t22 = icmp eq i8 %t20, 45
  store i1 %t22, ptr %l12, !tbaa !21
  br label %bb14
bb14:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb17
bb16:
  %t25 = load i8, ptr %l0, !tbaa !22
  %t27 = icmp eq i8 %t25, 126
  store i1 %t27, ptr %l15, !tbaa !21
  br label %bb17
bb17:
  %t29 = load i1, ptr %l15, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fprofile_2ele(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l36 = alloca { i64, ptr }
  %l43 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  store i64 %a2, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t3 = load i64, ptr %l5, !tbaa !24
  %t4 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l6, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l6, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l6, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l17, !tbaa !24
  store i64 %t29, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l14, !tbaa !24
  store i64 %t30, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb7
bb7:
  %t31 = load i64, ptr %l8, !tbaa !24
  %t32 = load i64, ptr %l7, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t39 = load i64, ptr %l4, !tbaa !24
  %t40 = load i64, ptr %l8, !tbaa !24
  %t41 = load i64, ptr %l6, !tbaa !24
  %t44 = mul i64 %t40, %t41
  %t47 = add i64 %t39, %t44
  store i64 %t47, ptr %l9, !tbaa !24
  %t49 = load i64, ptr %l3, !tbaa !24
  store { i64, ptr } %a0, ptr %l36, !tbaa !27
  %t52 = load i64, ptr %l9, !tbaa !24
  %t55 = add i64 %a1, %t52
  %t57 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr i8, ptr %t58, i64 %t55
  %t60 = load i8, ptr %t59, !tbaa !32
  %t62 = zext i8 %t60 to i64
  %t63 = load i64, ptr %l9, !tbaa !24
  %t65 = mul i64 %t63, 8
  store i64 %t65, ptr %l43, !tbaa !24
  %t67 = load i64, ptr %l43, !tbaa !24
  %t68 = load i64, ptr %l43, !tbaa !24
  %t69 = shl i64 %t62, %t68
  %t72 = or i64 %t49, %t69
  store i64 %t72, ptr %l3, !tbaa !24
  br label %bb11
bb11:
  %t74 = load i64, ptr %l8, !tbaa !24
  %t76 = add i64 %t74, 1
  store i64 %t76, ptr %l8, !tbaa !24
  br label %bb7
bb12:
  %t78 = load i64, ptr %l3, !tbaa !24
  store i64 %t78, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fprofile_2emappings(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %lp1 = alloca ptr
  %l2 = alloca %"std/prelude/text:LineIter"
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/text:StringBuilder"
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca %"std/prelude/text:LineIter"
  %l20 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i32
  %l25 = alloca i1
  %l26 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l28 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l39 = alloca i1
  %l48 = alloca i64
  %l50 = alloca i64
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca i32
  %l57 = alloca %"std/prelude/text:StringBuilder"
  %l59 = alloca i64
  %l63 = alloca i64
  %l66 = alloca i64
  %l87 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l93 = alloca ptr
  %l95 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l97 = alloca i64
  %l98 = alloca i64
  %l103 = alloca i64
  %l105 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  %l108 = alloca i64
  %l110 = alloca { i64, ptr }
  %l113 = alloca i64
  %l114 = alloca i64
  %l119 = alloca i64
  %l121 = alloca { i64, ptr }
  %l122 = alloca i64
  %l124 = alloca { i64, ptr }
  %l125 = alloca %"compiler/profile:mapping"
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3amapping_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l17
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l17
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  %t7 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store %"std/prelude/text:LineIter" %t7, ptr %l19
  br label %bb2
bb2:
  %t8 = load %"std/prelude/text:LineIter", ptr %l19
  store %"std/prelude/text:LineIter" %t8, ptr %l2
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %l2)
  %t11 = extractvalue { i32, { i64, ptr } } %t10, 1
  %t12 = extractvalue { i32, { i64, ptr } } %t10, 0
  store i32 %t12, ptr %l23
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb5, label %ok.14, !prof !99
ok.14:
  store { i64, ptr } %t11, ptr %l22
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t15, ptr %l20, !tbaa !27
  br label %bb7
bb5:
  %t16 = load i32, ptr %l23, !tbaa !23
  %t17 = ashr i32 %t16, 16
  %t19 = icmp eq i32 %t17, 1
  store i1 %t19, ptr %l25, !tbaa !21
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb76
bb7:
  %t20 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  %t21 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, ptr %l26
  br label %bb8
bb8:
  %t22 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l26
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l4
  store %olang.scope zeroinitializer, ptr %s3
  %t23 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t25 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %s3, { i64, ptr } %t23, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d118, i32 0, i32 1) })
  store { i64, ptr } %t25, ptr %l28
  br label %bb9
bb9:
  %t26 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t26, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t27 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  store i64 %t29, ptr %l7, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t31 = load i64, ptr %l6, !tbaa !24
  %t32 = load i64, ptr %l7, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s4)
  br label %bb20
bb12:
  br label %bb13
bb13:
  %t39 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t39, ptr %l35, !tbaa !27
  %t40 = load i64, ptr %l6, !tbaa !24
  %t42 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %t43, i64 %t40
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !37
  store { i64, ptr } %t45, ptr %l8, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t49 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t47, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d119, i32 0, i32 1) })
  store i1 %t49, ptr %l39
  br label %bb14
bb14:
  %t50 = load i1, ptr %l39, !tbaa !21
  %t51 = xor i1 %t50, true
  br i1 %t51, label %bb15, label %bb16
bb15:
  %t53 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 1
  %t56 = extractvalue { i64, ptr } %t53, 0
  %t57 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t55, i64 %t56)
  %t58 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  %t61 = extractvalue { i64, ptr } %t59, 0
  %t62 = extractvalue { i64, ptr } %t59, 1
  %t63 = mul i64 %t61, 1
  %t64 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t63)
  call void @llvm.memcpy.p0.p0.i64(ptr %t64, ptr %t62, i64 %t63, i1 false)
  %t65 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t64, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s2, ptr %s2, ptr %l4, { i64, ptr } %t66)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb19
bb19:
  %t69 = load i64, ptr %l6, !tbaa !24
  %t71 = add i64 %t69, 1
  store i64 %t71, ptr %l6, !tbaa !24
  br label %bb10
bb20:
  call void @__olang_scope_close(ptr %s3)
  %t74 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s2, ptr %l4)
  store i64 %t74, ptr %l48
  br label %bb21
bb21:
  %t75 = load i64, ptr %l48, !tbaa !24
  %t76 = icmp slt i64 %t75, 6
  br i1 %t76, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s2)
  br label %bb75
bb23:
  br label %bb24
bb24:
  %t79 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s2, ptr %s2, ptr %l4, i64 0)
  store { i64, ptr } %t79, ptr %l52
  br label %bb25
bb25:
  %t80 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t81 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s2, ptr %s2, { i64, ptr } %t80, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d120, i32 0, i32 1) })
  %t82 = extractvalue { i32, i64 } %t81, 1
  %t83 = extractvalue { i32, i64 } %t81, 0
  store i32 %t83, ptr %l54
  %t84 = icmp ne i32 %t83, 0
  br i1 %t84, label %bb27, label %ok.85, !prof !99
ok.85:
  store i64 %t82, ptr %l53
  br label %bb26
bb26:
  %t86 = load i64, ptr %l53, !tbaa !24
  store i64 %t86, ptr %l50, !tbaa !24
  br label %bb29
bb27:
  br label %bb28
bb28:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l50, !tbaa !24
  br label %bb29
bb29:
  %t87 = load i64, ptr %l50, !tbaa !24
  store i64 %t87, ptr %l9, !tbaa !24
  %t88 = load i64, ptr %l9, !tbaa !24
  %t90 = icmp slt i64 %t88, 0
  br i1 %t90, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s2)
  br label %bb75
bb31:
  br label %bb32
bb32:
  %t92 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s2)
  store %"std/prelude/text:StringBuilder" %t92, ptr %l57
  br label %bb33
bb33:
  %t93 = load %"std/prelude/text:StringBuilder", ptr %l57
  store %"std/prelude/text:StringBuilder" %t93, ptr %l10
  store i64 5, ptr %l11, !tbaa !24
  %t95 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s2, ptr %l4)
  store i64 %t95, ptr %l59
  br label %bb34
bb34:
  %t96 = load i64, ptr %l59, !tbaa !24
  store i64 %t96, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t97 = load i64, ptr %l12, !tbaa !24
  %t98 = load i64, ptr %l11, !tbaa !24
  %t101 = icmp sgt i64 %t97, %t98
  br i1 %t101, label %bb35, label %bb36
bb35:
  %t103 = load i64, ptr %l13, !tbaa !24
  %t105 = icmp sgt i64 %t103, 0
  br i1 %t105, label %bb37, label %bb38
bb36:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb40
bb37:
  %t107 = load i64, ptr %l12, !tbaa !24
  %t108 = load i64, ptr %l11, !tbaa !24
  %t111 = sub i64 %t107, %t108
  %t112 = load i64, ptr %l13, !tbaa !24
  %t115 = add i64 %t111, %t112
  %t117 = sub i64 %t115, 1
  %t118 = load i64, ptr %l13, !tbaa !24
  %t121 = sdiv i64 %t117, %t118
  store i64 %t121, ptr %l66, !tbaa !24
  br label %bb39
bb38:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb39
bb39:
  %t123 = load i64, ptr %l66, !tbaa !24
  store i64 %t123, ptr %l63, !tbaa !24
  br label %bb40
bb40:
  %t124 = load i64, ptr %l63, !tbaa !24
  store i64 %t124, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb41
bb41:
  %t125 = load i64, ptr %l15, !tbaa !24
  %t126 = load i64, ptr %l14, !tbaa !24
  %t129 = icmp slt i64 %t125, %t126
  %t131 = xor i1 %t129, true
  br i1 %t131, label %bb42, label %bb43
bb42:
  br label %bb52
bb43:
  br label %bb44
bb44:
  %t133 = load i64, ptr %l11, !tbaa !24
  %t134 = load i64, ptr %l15, !tbaa !24
  %t135 = load i64, ptr %l13, !tbaa !24
  %t138 = mul i64 %t134, %t135
  %t141 = add i64 %t133, %t138
  store i64 %t141, ptr %l16, !tbaa !24
  %t143 = load i64, ptr %l16, !tbaa !24
  %t145 = icmp sgt i64 %t143, 5
  br i1 %t145, label %bb45, label %bb46
bb45:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s2, ptr %l10, i8 32)
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb48
bb48:
  store ptr %l10, ptr %l87, !tbaa !29
  %t148 = load i64, ptr %l16, !tbaa !24
  %t151 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s2, ptr %s2, ptr %l4, i64 %t148)
  store { i64, ptr } %t151, ptr %l90
  br label %bb49
bb49:
  %t152 = load ptr, ptr %l87, !tbaa !29
  %t153 = load { i64, ptr }, ptr %l90, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s2, ptr %s2, ptr %t152, { i64, ptr } %t153)
  br label %bb50
bb50:
  br label %bb51
bb51:
  %t154 = load i64, ptr %l15, !tbaa !24
  %t156 = add i64 %t154, 1
  store i64 %t156, ptr %l15, !tbaa !24
  br label %bb41
bb52:
  %t158 = load ptr, ptr %lp1
  store ptr %t158, ptr %l93, !tbaa !29
  %t160 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s2, ptr %s2, ptr %l4, i64 0)
  store { i64, ptr } %t160, ptr %l95
  br label %bb53
bb53:
  %t161 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t161, ptr %l96, !tbaa !27
  %t162 = load i64, ptr %l9, !tbaa !24
  store i64 %t162, ptr %l97, !tbaa !24
  %t163 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t164 = extractvalue { i64, ptr } %t163, 0
  store i64 %t164, ptr %l98, !tbaa !24
  %t165 = icmp sge i64 0, 0
  br i1 %t165, label %bb54, label %bb55
bb54:
  %t167 = load i64, ptr %l97, !tbaa !24
  %t168 = icmp sle i64 0, %t167
  br i1 %t168, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_49a351722641e944_c5b141a1c073228)
  unreachable
bb56:
  %t170 = load i64, ptr %l97, !tbaa !24
  %t171 = load i64, ptr %l98, !tbaa !24
  %t172 = icmp sle i64 %t170, %t171
  br i1 %t172, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @olang_loc_49a351722641e944_c5b141a1c073228)
  unreachable
bb58:
  %t174 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !27
  %t176 = load i64, ptr %l97, !tbaa !24
  %t177 = getelementptr i8, ptr %t175, i64 0
  %t178 = sub i64 %t176, 0
  %t179 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t180 = insertvalue { i64, ptr } %t179, ptr %t177, 1
  %t182 = call i64 @compiler_2fprofile_2ehex(ptr %s2, { i64, ptr } %t180)
  store i64 %t182, ptr %l103
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_49a351722641e944_c5b141a1c073228)
  unreachable
bb60:
  %t184 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s2, ptr %s2, ptr %l4, i64 0)
  store { i64, ptr } %t184, ptr %l105
  br label %bb61
bb61:
  %t185 = load { i64, ptr }, ptr %l105, !tbaa !27
  store { i64, ptr } %t185, ptr %l106, !tbaa !27
  %t186 = load i64, ptr %l9, !tbaa !24
  %t188 = add i64 %t186, 1
  store i64 %t188, ptr %l108, !tbaa !24
  %t190 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s2, ptr %s2, ptr %l4, i64 0)
  store { i64, ptr } %t190, ptr %l110
  br label %bb62
bb62:
  %t191 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t194 = extractvalue { i64, ptr } %t191, 0
  store i64 %t194, ptr %l113, !tbaa !24
  %t195 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t195, 0
  store i64 %t196, ptr %l114, !tbaa !24
  %t197 = load i64, ptr %l108, !tbaa !24
  %t198 = icmp sge i64 %t197, 0
  br i1 %t198, label %bb63, label %bb64
bb63:
  %t200 = load i64, ptr %l108, !tbaa !24
  %t201 = load i64, ptr %l113, !tbaa !24
  %t202 = icmp sle i64 %t200, %t201
  br i1 %t202, label %bb65, label %bb66
bb64:
  call void @__olang_check_failed(ptr @olang_loc_49a351722641e944_c5b141a1c073228)
  unreachable
bb65:
  %t204 = load i64, ptr %l113, !tbaa !24
  %t205 = load i64, ptr %l114, !tbaa !24
  %t206 = icmp sle i64 %t204, %t205
  br i1 %t206, label %bb67, label %bb68
bb66:
  call void @__olang_check_failed(ptr @olang_loc_49a351722641e944_c5b141a1c073228)
  unreachable
bb67:
  %t208 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = load i64, ptr %l108, !tbaa !24
  %t211 = load i64, ptr %l113, !tbaa !24
  %t212 = getelementptr i8, ptr %t209, i64 %t210
  %t213 = sub i64 %t211, %t210
  %t214 = insertvalue { i64, ptr } undef, i64 %t213, 0
  %t215 = insertvalue { i64, ptr } %t214, ptr %t212, 1
  %t217 = call i64 @compiler_2fprofile_2ehex(ptr %s2, { i64, ptr } %t215)
  store i64 %t217, ptr %l119
  br label %bb69
bb68:
  call void @__olang_check_failed(ptr @olang_loc_49a351722641e944_c5b141a1c073228)
  unreachable
bb69:
  %t219 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s2, ptr %s2, ptr %l4, i64 2)
  store { i64, ptr } %t219, ptr %l121
  br label %bb70
bb70:
  %t220 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t221 = call i64 @compiler_2fprofile_2ehex(ptr %s2, { i64, ptr } %t220)
  store i64 %t221, ptr %l122
  br label %bb71
bb71:
  %t223 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s2, ptr %v1, ptr %l10)
  store { i64, ptr } %t223, ptr %l124
  br label %bb72
bb72:
  %t224 = load i64, ptr %l103, !tbaa !24
  %t225 = load i64, ptr %l119, !tbaa !24
  %t226 = load i64, ptr %l122, !tbaa !24
  %t227 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t228 = call %"compiler/profile:mapping" @compiler_2fprofile_3amapping_2ector(ptr %v1, ptr %v1, i64 %t224, i64 %t225, i64 %t226, { i64, ptr } %t227)
  store %"compiler/profile:mapping" %t228, ptr %l125
  br label %bb73
bb73:
  %t229 = load ptr, ptr %l93, !tbaa !29
  %t230 = load %"compiler/profile:mapping", ptr %l125
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3amapping_3e_2ePush_Hc0dd0b8028ee4ec7edce99e352ae7bbd(ptr %v1, ptr %v1, ptr %t229, %"compiler/profile:mapping" %t230)
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s2)
  br label %bb75
bb75:
  br label %bb3
bb76:
  %t231 = load ptr, ptr %lp1
  %t232 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t231
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t232, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local { i64, ptr } @compiler_2fprofile_2emillis(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %l8 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = sitofp i64 %a0 to double
  %t6 = sitofp i64 %a1 to double
  %t9 = fmul double %t3, %t6
  %t11 = fdiv double %t9, 0x412e848000000000
  %t13 = call { i64, ptr } @std_2fprelude_2ffloat_2eF64_2eFixed(ptr %v0, double %t11, i64 1)
  store { i64, ptr } %t13, ptr %l8
  br label %bb1
bb1:
  %t14 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t14, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fprofile_2epct(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l4 = alloca double
  %l7 = alloca i64
  %l11 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = sitofp i64 %a0 to double
  %t5 = fmul double %t3, 0x4059000000000000
  store double %t5, ptr %l4, !tbaa !26
  %t6 = load i64, ptr %l1, !tbaa !24
  %t8 = icmp sgt i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i64, ptr %l1, !tbaa !24
  store i64 %t10, ptr %l7, !tbaa !24
  br label %bb3
bb2:
  store i64 1, ptr %l7, !tbaa !24
  br label %bb3
bb3:
  %t12 = load i64, ptr %l7, !tbaa !24
  %t13 = sitofp i64 %t12 to double
  %t14 = load double, ptr %l4, !tbaa !26
  %t16 = fdiv double %t14, %t13
  %t18 = call { i64, ptr } @std_2fprelude_2ffloat_2eF64_2eFixed(ptr %s0, double %t16, i64 1)
  store { i64, ptr } %t18, ptr %l11
  br label %bb4
bb4:
  %t19 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 1
  %t21 = extractvalue { i64, ptr } %t19, 0
  %t22 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d121, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d121, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t25 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t24)
  call void @olang_textcopy(ptr %t25, ptr %t20, i64 %t21)
  %t26 = getelementptr i8, ptr %t25, i64 %t21
  call void @olang_textcopy(ptr %t26, ptr %t22, i64 %t23)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t25, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t28, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fprofile_2equalifier(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l3 = alloca i1
  %l4 = alloca i1
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca { i64, ptr }
  %l17 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d122, i32 0, i32 1) })
  store i1 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb5
bb3:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d123, i32 0, i32 1) })
  store i1 %t7, ptr %l6
  br label %bb4
bb4:
  %t8 = load i1, ptr %l6, !tbaa !21
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb5
bb5:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d124, i32 0, i32 1) }, ptr %l7, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t10, ptr %l8, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  store i64 %t12, ptr %l9, !tbaa !24
  %t13 = load i64, ptr %l9, !tbaa !24
  %t14 = mul i64 %t13, 1
  %t15 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l10, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = load i64, ptr %l9, !tbaa !24
  %t23 = mul i64 %t22, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t19, ptr %t21, i64 %t23, i1 false)
  %t24 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t24, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t25 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t25, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t26 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t28 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s0, { i64, ptr } %t26, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d125, i32 0, i32 1) })
  %t29 = extractvalue { i32, i64 } %t28, 1
  %t30 = extractvalue { i32, i64 } %t28, 0
  store i32 %t30, ptr %l14
  %t31 = icmp ne i32 %t30, 0
  br i1 %t31, label %bb10, label %ok.32, !prof !99
ok.32:
  store i64 %t29, ptr %l13
  br label %bb9
bb9:
  %t33 = load i64, ptr %l13, !tbaa !24
  store i64 %t33, ptr %l11, !tbaa !24
  br label %bb12
bb10:
  br label %bb11
bb11:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l11, !tbaa !24
  br label %bb12
bb12:
  %t34 = load i64, ptr %l11, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t35, ptr %l15, !tbaa !27
  %t38 = add i64 %t34, 1
  store i64 %t38, ptr %l17, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t39, 0
  store i64 %t42, ptr %l20, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t43, 0
  store i64 %t44, ptr %l21, !tbaa !24
  %t45 = load i64, ptr %l17, !tbaa !24
  %t46 = icmp sge i64 %t45, 0
  br i1 %t46, label %bb13, label %bb14
bb13:
  %t48 = load i64, ptr %l17, !tbaa !24
  %t49 = load i64, ptr %l20, !tbaa !24
  %t50 = icmp sle i64 %t48, %t49
  br i1 %t50, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_8377dd777846f8d9_8488686b399fded)
  unreachable
bb15:
  %t52 = load i64, ptr %l20, !tbaa !24
  %t53 = load i64, ptr %l21, !tbaa !24
  %t54 = icmp sle i64 %t52, %t53
  br i1 %t54, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_8377dd777846f8d9_8488686b399fded)
  unreachable
bb17:
  %t56 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = load i64, ptr %l17, !tbaa !24
  %t59 = load i64, ptr %l20, !tbaa !24
  %t60 = getelementptr i8, ptr %t57, i64 %t58
  %t61 = sub i64 %t59, %t58
  %t62 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t60, 1
  %t65 = extractvalue { i64, ptr } %t63, 1
  %t66 = extractvalue { i64, ptr } %t63, 0
  %t67 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d126, i32 0, i32 1) }, 1
  %t68 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d126, i32 0, i32 1) }, 0
  %t69 = add i64 %t66, %t68
  %t70 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t69)
  call void @olang_textcopy(ptr %t70, ptr %t65, i64 %t66)
  %t71 = getelementptr i8, ptr %t70, i64 %t66
  call void @olang_textcopy(ptr %t71, ptr %t67, i64 %t68)
  %t72 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t70, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t73, ptr %rv
  br label %ret
bb18:
  call void @__olang_check_failed(ptr @olang_loc_8377dd777846f8d9_8488686b399fded)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fprofile_2erunProfiled(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l4 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca [1 x i32]
  %l13 = alloca i32
  %l14 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l26 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l39 = alloca i32
  %l40 = alloca i32
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca i32
  %l50 = alloca i1
  %l51 = alloca { i64, ptr }
  %l52 = alloca i32
  %l56 = alloca i64
  %l57 = alloca i64
  %l62 = alloca i32
  %l68 = alloca i1
  %l71 = alloca i64
  %l73 = alloca i64
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l14
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l14
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l4
  %t5 = extractvalue { i64, ptr } %a1, 1
  %t6 = extractvalue { i64, ptr } %a1, 0
  %t7 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t6)
  call void @olang_textcopy(ptr %t7, ptr %t5, i64 %t6)
  %t8 = insertvalue { i64, ptr } undef, i64 %t6, 0
  %t9 = insertvalue { i64, ptr } %t8, ptr %t7, 1
  %t11 = extractvalue { i64, ptr } %t9, 0
  %t12 = extractvalue { i64, ptr } %t9, 1
  %t13 = mul i64 %t11, 1
  %t14 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t13)
  call void @llvm.memcpy.p0.p0.i64(ptr %t14, ptr %t12, i64 %t13, i1 false)
  %t15 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } %t16)
  br label %bb2
bb2:
  store { i64, ptr } %a2, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l7, !tbaa !24
  br label %bb3
bb3:
  %t25 = load i64, ptr %l6, !tbaa !24
  %t26 = load i64, ptr %l7, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb4, label %bb5
bb4:
  br label %bb9
bb5:
  br label %bb6
bb6:
  %t33 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t33, ptr %l26, !tbaa !27
  %t34 = load i64, ptr %l6, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %t37, i64 %t34
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !37
  %t43 = extractvalue { i64, ptr } %t39, 1
  %t44 = extractvalue { i64, ptr } %t39, 0
  %t45 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t44)
  call void @olang_textcopy(ptr %t45, ptr %t43, i64 %t44)
  %t46 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  %t49 = extractvalue { i64, ptr } %t47, 0
  %t50 = extractvalue { i64, ptr } %t47, 1
  %t51 = mul i64 %t49, 1
  %t52 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t51)
  call void @llvm.memcpy.p0.p0.i64(ptr %t52, ptr %t50, i64 %t51, i1 false)
  %t53 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } %t54)
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t57 = load i64, ptr %l6, !tbaa !24
  %t59 = add i64 %t57, 1
  store i64 %t59, ptr %l6, !tbaa !24
  br label %bb3
bb9:
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d127, i32 0, i32 1) }, ptr %l35, !tbaa !27
  %t63 = extractvalue { i64, ptr } %a3, 1
  %t64 = extractvalue { i64, ptr } %a3, 0
  %t65 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 1
  %t66 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d128, i32 0, i32 1) }, 0
  %t67 = add i64 %t64, %t66
  %t68 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t67)
  call void @olang_textcopy(ptr %t68, ptr %t63, i64 %t64)
  %t69 = getelementptr i8, ptr %t68, i64 %t64
  call void @olang_textcopy(ptr %t69, ptr %t65, i64 %t66)
  %t70 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t68, 1
  %t73 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 1
  %t75 = extractvalue { i64, ptr } %t73, 0
  %t77 = extractvalue { i64, ptr } %t71, 1
  %t78 = extractvalue { i64, ptr } %t71, 0
  %t79 = call i32 @setenv(ptr %t74, ptr %t77, i32 1)
  store i32 %t79, ptr %l39
  br label %bb10
bb10:
  %t80 = call i32 @fork()
  store i32 %t80, ptr %l40
  br label %bb11
bb11:
  %t81 = load i32, ptr %l40, !tbaa !23
  store i32 %t81, ptr %l9, !tbaa !23
  %t82 = load i32, ptr %l9, !tbaa !23
  %t84 = icmp eq i32 %t82, 0
  br i1 %t84, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s7
  %t88 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %v0, ptr %s7, { i64, ptr } %a0)
  store { i64, ptr } %t88, ptr %l44
  br label %bb14
bb13:
  br label %bb21
bb14:
  %t89 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t89, 0
  %t91 = extractvalue { i64, ptr } %t89, 1
  %t92 = mul i64 %t90, 1
  %t93 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t92)
  call void @llvm.memcpy.p0.p0.i64(ptr %t93, ptr %t91, i64 %t92, i1 false)
  %t94 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t93, 1
  store { i64, ptr } %t95, ptr %l45, !tbaa !27
  %t97 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s0, ptr %s0, ptr %l4)
  store { i64, ptr } %t97, ptr %l47
  br label %bb15
bb15:
  %t98 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t99 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t100 = call i32 @std_2fos_2eExecInPlace(ptr %s7, ptr %s0, { i64, ptr } %t98, { i64, ptr } %t99)
  store i32 %t100, ptr %l48
  %t101 = icmp ne i32 %t100, 0
  br i1 %t101, label %bb17, label %ok.102, !prof !99
ok.102:
  br label %bb16
bb16:
  br label %bb19
bb17:
  %t103 = load i32, ptr %l48, !tbaa !23
  %t104 = ashr i32 %t103, 16
  %t106 = icmp eq i32 %t104, 1
  store i1 %t106, ptr %l50, !tbaa !21
  br label %bb18
bb18:
  call void @__olang_ert_req_clear()
  br label %bb19
bb19:
  call void @_exit(i32 127)
  unreachable
bb20:
  call void @__olang_check_failed(ptr @olang_loc_ec22c3592c386ac4_6a748f217c4c44c0)
  unreachable
bb21:
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d129, i32 0, i32 1) }, ptr %l51, !tbaa !27
  %t107 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t107, 1
  %t109 = extractvalue { i64, ptr } %t107, 0
  %t110 = call i32 @unsetenv(ptr %t108)
  store i32 %t110, ptr %l52
  br label %bb22
bb22:
  %t111 = load i32, ptr %l9, !tbaa !23
  %t113 = icmp slt i32 %t111, 0
  br i1 %t113, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s0)
  store i32 -1, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t116 = call i64 @signal(i32 2, i64 1)
  store i64 %t116, ptr %l56
  br label %bb26
bb26:
  %t117 = load i64, ptr %l56, !tbaa !24
  store i64 %t117, ptr %l10, !tbaa !24
  %t118 = call i64 @signal(i32 3, i64 1)
  store i64 %t118, ptr %l57
  br label %bb27
bb27:
  %t119 = load i64, ptr %l57, !tbaa !24
  store i64 %t119, ptr %l11, !tbaa !24
  %t120 = insertvalue [1 x i32] undef, i32 0, 0
  store [1 x i32] %t120, ptr %l12
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s10
  %t122 = load i32, ptr %l9, !tbaa !23
  %t124 = insertvalue { i64, ptr } undef, i64 1, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %l12, 1
  %t128 = extractvalue { i64, ptr } %t125, 1
  %t129 = extractvalue { i64, ptr } %t125, 0
  %t130 = call i32 @waitpid(i32 %t122, ptr %t128, i32 0)
  store i32 %t130, ptr %l62
  br label %bb29
bb29:
  %t131 = load i32, ptr %l62, !tbaa !23
  %t132 = icmp slt i32 %t131, 0
  %t134 = xor i1 %t132, true
  br i1 %t134, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s10)
  br label %bb38
bb31:
  br label %bb32
bb32:
  %t136 = load i32, ptr %l9, !tbaa !23
  %t137 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d130, i32 0, i32 1) }, 1
  %t138 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d130, i32 0, i32 1) }, 0
  %t140 = sext i32 %t136 to i64
  %t141 = call i64 @__olang_fmt_i64(ptr null, i64 %t140)
  %t142 = add i64 %t138, %t141
  %t143 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t142)
  call void @olang_textcopy(ptr %t143, ptr %t137, i64 %t138)
  %t144 = getelementptr i8, ptr %t143, i64 %t138
  %t145 = call i64 @__olang_fmt_i64(ptr %t144, i64 %t140)
  %t146 = insertvalue { i64, ptr } undef, i64 %t142, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t143, 1
  %t149 = extractvalue { i64, ptr } %t147, 0
  %t150 = extractvalue { i64, ptr } %t147, 1
  %t151 = mul i64 %t149, 1
  %t152 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t151)
  call void @llvm.memcpy.p0.p0.i64(ptr %t152, ptr %t150, i64 %t151, i1 false)
  %t153 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t152, 1
  %t156 = call i1 @std_2fos_2eExists(ptr %s10, { i64, ptr } %t154)
  store i1 %t156, ptr %l68
  br label %bb33
bb33:
  %t157 = load i1, ptr %l68, !tbaa !21
  %t158 = xor i1 %t157, true
  br i1 %t158, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s10)
  br label %bb38
bb35:
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s10)
  br label %bb37
bb37:
  br label %bb28
bb38:
  %t160 = load i64, ptr %l10, !tbaa !24
  %t162 = call i64 @signal(i32 2, i64 %t160)
  store i64 %t162, ptr %l71
  br label %bb39
bb39:
  %t163 = load i64, ptr %l11, !tbaa !24
  %t165 = call i64 @signal(i32 3, i64 %t163)
  store i64 %t165, ptr %l73
  br label %bb40
bb40:
  %t166 = getelementptr [1 x i32], ptr %l12, i64 0, i64 0
  %t167 = load i32, ptr %t166, !tbaa !33
  store i32 %t167, ptr %l13, !tbaa !23
  %t169 = load i32, ptr %l13, !tbaa !23
  %t171 = and i32 %t169, 127
  %t173 = icmp ne i32 %t171, 0
  br i1 %t173, label %bb41, label %bb42
bb41:
  %t175 = load i32, ptr %l13, !tbaa !23
  %t177 = and i32 %t175, 127
  %t179 = add i32 128, %t177
  call void @__olang_scope_close(ptr %s0)
  store i32 %t179, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  %t181 = load i32, ptr %l13, !tbaa !23
  %t183 = ashr i32 %t181, 8
  %t185 = and i32 %t183, 255
  call void @__olang_scope_close(ptr %s0)
  store i32 %t185, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fprofile_2esampleFile(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l31 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l38 = alloca { i64, ptr }
  %l62 = alloca i64
  %l65 = alloca i64
  %l86 = alloca i64
  %l101 = alloca { i64, ptr }
  %l107 = alloca i64
  %l110 = alloca i64
  %l131 = alloca i64
  %l146 = alloca { i64, ptr }
  %l155 = alloca { i64, ptr }
  %l156 = alloca { i64, ptr }
  %l157 = alloca i64
  %l158 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cU8_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l31
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l31
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l2
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d131, i32 0, i32 1) }, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l38, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i8, ptr %t19, i64 %t16
  %t21 = load i8, ptr %t20, !tbaa !32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %s0, ptr %l2, i8 %t21)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t27 = load i64, ptr %l4, !tbaa !24
  %t29 = add i64 %t27, 1
  store i64 %t29, ptr %l4, !tbaa !24
  br label %bb2
bb8:
  store %olang.scope zeroinitializer, ptr %s4
  %t31 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = insertvalue [4 x i64] undef, i64 1000000, 0
  %t36 = insertvalue [4 x i64] %t34, i64 %t33, 1
  %t37 = insertvalue [4 x i64] %t36, i64 2, 2
  %t38 = insertvalue [4 x i64] %t37, i64 1, 3
  %t40 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 32, i64 8)
  store [4 x i64] %t38, ptr %t40
  store ptr %t40, ptr %l7
  store i64 0, ptr %l8, !tbaa !24
  %t42 = load ptr, ptr %l7
  store i64 4, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  %t45 = load i64, ptr %l8, !tbaa !24
  %t46 = load i64, ptr %l9, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb10, label %bb11
bb10:
  br label %bb27
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l7
  %t54 = load i64, ptr %l8, !tbaa !24
  %t57 = getelementptr [4 x i64], ptr %t53, i64 0, i64 %t54
  %t58 = load i64, ptr %t57, !tbaa !34
  store i64 %t58, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  store i64 8, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t60 = load i64, ptr %l12, !tbaa !24
  %t61 = load i64, ptr %l11, !tbaa !24
  %t64 = icmp sgt i64 %t60, %t61
  br i1 %t64, label %bb13, label %bb14
bb13:
  %t66 = load i64, ptr %l13, !tbaa !24
  %t68 = icmp sgt i64 %t66, 0
  br i1 %t68, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb18
bb15:
  %t70 = load i64, ptr %l12, !tbaa !24
  %t71 = load i64, ptr %l11, !tbaa !24
  %t74 = sub i64 %t70, %t71
  %t75 = load i64, ptr %l13, !tbaa !24
  %t78 = add i64 %t74, %t75
  %t80 = sub i64 %t78, 1
  %t81 = load i64, ptr %l13, !tbaa !24
  %t84 = sdiv i64 %t80, %t81
  store i64 %t84, ptr %l65, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l65, !tbaa !24
  br label %bb17
bb17:
  %t86 = load i64, ptr %l65, !tbaa !24
  store i64 %t86, ptr %l62, !tbaa !24
  br label %bb18
bb18:
  %t87 = load i64, ptr %l62, !tbaa !24
  store i64 %t87, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb19
bb19:
  %t88 = load i64, ptr %l15, !tbaa !24
  %t89 = load i64, ptr %l14, !tbaa !24
  %t92 = icmp slt i64 %t88, %t89
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb20, label %bb21
bb20:
  br label %bb25
bb21:
  br label %bb22
bb22:
  %t96 = load i64, ptr %l11, !tbaa !24
  %t97 = load i64, ptr %l15, !tbaa !24
  %t98 = load i64, ptr %l13, !tbaa !24
  %t101 = mul i64 %t97, %t98
  %t104 = add i64 %t96, %t101
  %t106 = load i64, ptr %l10, !tbaa !24
  %t109 = mul i64 %t104, 8
  store i64 %t109, ptr %l86, !tbaa !24
  %t111 = load i64, ptr %l86, !tbaa !24
  %t112 = load i64, ptr %l86, !tbaa !24
  %t113 = ashr i64 %t106, %t112
  %t115 = and i64 %t113, 255
  %t117 = trunc i64 %t115 to i8
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %s0, ptr %l2, i8 %t117)
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t120 = load i64, ptr %l15, !tbaa !24
  %t122 = add i64 %t120, 1
  store i64 %t122, ptr %l15, !tbaa !24
  br label %bb19
bb25:
  br label %bb26
bb26:
  %t124 = load i64, ptr %l8, !tbaa !24
  %t126 = add i64 %t124, 1
  store i64 %t126, ptr %l8, !tbaa !24
  br label %bb9
bb27:
  call void @__olang_scope_close(ptr %s4)
  %t128 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t128, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t130 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t130, 0
  store i64 %t132, ptr %l19, !tbaa !24
  br label %bb28
bb28:
  %t134 = load i64, ptr %l18, !tbaa !24
  %t135 = load i64, ptr %l19, !tbaa !24
  %t138 = icmp slt i64 %t134, %t135
  %t140 = xor i1 %t138, true
  br i1 %t140, label %bb29, label %bb30
bb29:
  br label %bb46
bb30:
  br label %bb31
bb31:
  %t142 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t142, ptr %l101, !tbaa !27
  %t143 = load i64, ptr %l18, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr i64, ptr %t146, i64 %t143
  %t148 = load i64, ptr %t147, !tbaa !34
  store i64 %t148, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  store i64 8, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t150 = load i64, ptr %l22, !tbaa !24
  %t151 = load i64, ptr %l21, !tbaa !24
  %t154 = icmp sgt i64 %t150, %t151
  br i1 %t154, label %bb32, label %bb33
bb32:
  %t156 = load i64, ptr %l23, !tbaa !24
  %t158 = icmp sgt i64 %t156, 0
  br i1 %t158, label %bb34, label %bb35
bb33:
  store i64 0, ptr %l107, !tbaa !24
  br label %bb37
bb34:
  %t160 = load i64, ptr %l22, !tbaa !24
  %t161 = load i64, ptr %l21, !tbaa !24
  %t164 = sub i64 %t160, %t161
  %t165 = load i64, ptr %l23, !tbaa !24
  %t168 = add i64 %t164, %t165
  %t170 = sub i64 %t168, 1
  %t171 = load i64, ptr %l23, !tbaa !24
  %t174 = sdiv i64 %t170, %t171
  store i64 %t174, ptr %l110, !tbaa !24
  br label %bb36
bb35:
  store i64 0, ptr %l110, !tbaa !24
  br label %bb36
bb36:
  %t176 = load i64, ptr %l110, !tbaa !24
  store i64 %t176, ptr %l107, !tbaa !24
  br label %bb37
bb37:
  %t177 = load i64, ptr %l107, !tbaa !24
  store i64 %t177, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb38
bb38:
  %t178 = load i64, ptr %l25, !tbaa !24
  %t179 = load i64, ptr %l24, !tbaa !24
  %t182 = icmp slt i64 %t178, %t179
  %t184 = xor i1 %t182, true
  br i1 %t184, label %bb39, label %bb40
bb39:
  br label %bb44
bb40:
  br label %bb41
bb41:
  %t186 = load i64, ptr %l21, !tbaa !24
  %t187 = load i64, ptr %l25, !tbaa !24
  %t188 = load i64, ptr %l23, !tbaa !24
  %t191 = mul i64 %t187, %t188
  %t194 = add i64 %t186, %t191
  %t196 = load i64, ptr %l20, !tbaa !24
  %t199 = mul i64 %t194, 8
  store i64 %t199, ptr %l131, !tbaa !24
  %t201 = load i64, ptr %l131, !tbaa !24
  %t202 = load i64, ptr %l131, !tbaa !24
  %t203 = ashr i64 %t196, %t202
  %t205 = and i64 %t203, 255
  %t207 = trunc i64 %t205 to i8
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %s0, ptr %l2, i8 %t207)
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t210 = load i64, ptr %l25, !tbaa !24
  %t212 = add i64 %t210, 1
  store i64 %t212, ptr %l25, !tbaa !24
  br label %bb38
bb44:
  br label %bb45
bb45:
  %t214 = load i64, ptr %l18, !tbaa !24
  %t216 = add i64 %t214, 1
  store i64 %t216, ptr %l18, !tbaa !24
  br label %bb28
bb46:
  store { i64, ptr } %a1, ptr %l27, !tbaa !27
  store i64 0, ptr %l28, !tbaa !24
  %t220 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t222 = extractvalue { i64, ptr } %t220, 0
  store i64 %t222, ptr %l29, !tbaa !24
  br label %bb47
bb47:
  %t224 = load i64, ptr %l28, !tbaa !24
  %t225 = load i64, ptr %l29, !tbaa !24
  %t228 = icmp slt i64 %t224, %t225
  %t230 = xor i1 %t228, true
  br i1 %t230, label %bb48, label %bb49
bb48:
  br label %bb53
bb49:
  br label %bb50
bb50:
  %t232 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t232, ptr %l146, !tbaa !27
  %t233 = load i64, ptr %l28, !tbaa !24
  %t235 = getelementptr { i64, ptr }, ptr %l146, i32 0, i32 1
  %t236 = load ptr, ptr %t235, !tbaa !27
  %t237 = getelementptr i8, ptr %t236, i64 %t233
  %t238 = load i8, ptr %t237, !tbaa !32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %s0, ptr %l2, i8 %t238)
  br label %bb51
bb51:
  br label %bb52
bb52:
  %t244 = load i64, ptr %l28, !tbaa !24
  %t246 = add i64 %t244, 1
  store i64 %t246, ptr %l28, !tbaa !24
  br label %bb47
bb53:
  %t249 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eToArray_3cU8_3e(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t249, ptr %l155
  br label %bb54
bb54:
  %t250 = load { i64, ptr }, ptr %l155, !tbaa !27
  store { i64, ptr } %t250, ptr %l156, !tbaa !27
  %t251 = load { i64, ptr }, ptr %l156, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t251, 0
  store i64 %t252, ptr %l157, !tbaa !24
  %t253 = load i64, ptr %l157, !tbaa !24
  %t254 = mul i64 %t253, 1
  %t255 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t254)
  %t256 = insertvalue { i64, ptr } undef, i64 %t253, 0
  %t257 = insertvalue { i64, ptr } %t256, ptr %t255, 1
  store { i64, ptr } %t257, ptr %l158, !tbaa !27
  %t258 = getelementptr { i64, ptr }, ptr %l158, i32 0, i32 1
  %t259 = load ptr, ptr %t258, !tbaa !27
  %t260 = getelementptr { i64, ptr }, ptr %l156, i32 0, i32 1
  %t261 = load ptr, ptr %t260, !tbaa !27
  %t262 = load i64, ptr %l157, !tbaa !24
  %t263 = mul i64 %t262, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t259, ptr %t261, i64 %t263, i1 false)
  %t264 = load { i64, ptr }, ptr %l158, !tbaa !27
  store { i64, ptr } %t264, ptr %l156, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t265 = load { i64, ptr }, ptr %l156, !tbaa !27
  store { i64, ptr } %t265, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fprofile_2esay(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca i32
  %l4 = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %a0)
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  br label %bb1
bb1:
  br label %bb4
bb2:
  %t6 = load i32, ptr %l2, !tbaa !23
  %t7 = ashr i32 %t6, 16
  %t9 = icmp eq i32 %t7, 1
  store i1 %t9, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  br label %bb4
bb4:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fprofile_2esegments(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %lp1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l20 = alloca i1
  %l25 = alloca i1
  %l26 = alloca { i64, ptr }
  %l30 = alloca i1
  %l31 = alloca { i64, ptr }
  %l36 = alloca i1
  %l37 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l65 = alloca i64
  %l68 = alloca i64
  %l96 = alloca i1
  %l105 = alloca i64
  %l108 = alloca ptr
  %l113 = alloca i64
  %l114 = alloca ptr
  %l119 = alloca i64
  %l120 = alloca ptr
  %l125 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l14
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l14
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  %t7 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %s0, { i64, ptr } %a0)
  %t8 = extractvalue { i32, { i64, ptr } } %t7, 1
  %t9 = extractvalue { i32, { i64, ptr } } %t7, 0
  store i32 %t9, ptr %l18
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb3, label %ok.11, !prof !99
ok.11:
  store { i64, ptr } %t8, ptr %l17
  br label %bb2
bb2:
  %t12 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t12, ptr %l15, !tbaa !27
  br label %bb5
bb3:
  %t13 = load i32, ptr %l18, !tbaa !23
  %t14 = ashr i32 %t13, 16
  %t16 = icmp eq i32 %t14, 1
  store i1 %t16, ptr %l20, !tbaa !21
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  %t17 = load ptr, ptr %lp1
  %t18 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t17
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t18, ptr %rv
  br label %ret
bb5:
  %t20 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t20, ptr %l2, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t25 = icmp slt i64 %t23, 64
  br i1 %t25, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb8
bb7:
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t27, ptr %l26, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr i8, ptr %t29, i64 0
  %t31 = load i8, ptr %t30, !tbaa !32
  %t34 = icmp ne i8 %t31, 127
  store i1 %t34, ptr %l25, !tbaa !21
  br label %bb8
bb8:
  %t36 = load i1, ptr %l25, !tbaa !21
  br i1 %t36, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb11
bb10:
  %t37 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t37, ptr %l31, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr i8, ptr %t39, i64 1
  %t41 = load i8, ptr %t40, !tbaa !32
  %t45 = icmp ne i8 %t41, 69
  store i1 %t45, ptr %l30, !tbaa !21
  br label %bb11
bb11:
  %t47 = load i1, ptr %l30, !tbaa !21
  br i1 %t47, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb14
bb13:
  %t48 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t48, ptr %l37, !tbaa !27
  %t49 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr i8, ptr %t50, i64 4
  %t52 = load i8, ptr %t51, !tbaa !32
  %t55 = icmp ne i8 %t52, 2
  store i1 %t55, ptr %l36, !tbaa !21
  br label %bb14
bb14:
  %t57 = load i1, ptr %l36, !tbaa !21
  br i1 %t57, label %bb15, label %bb16
bb15:
  %t58 = load ptr, ptr %lp1
  %t59 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t58
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t59, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t61 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t64 = call i64 @compiler_2fprofile_2eword(ptr %s0, { i64, ptr } %t61, i64 4)
  store i64 %t64, ptr %l44
  br label %bb18
bb18:
  %t65 = load i64, ptr %l44, !tbaa !24
  store i64 %t65, ptr %l3, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t66, ptr %l45, !tbaa !27
  %t67 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr i8, ptr %t68, i64 54
  %t70 = load i8, ptr %t69, !tbaa !32
  %t72 = zext i8 %t70 to i64
  %t73 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t73, ptr %l48, !tbaa !27
  %t74 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr i8, ptr %t75, i64 55
  %t77 = load i8, ptr %t76, !tbaa !32
  %t79 = zext i8 %t77 to i64
  %t81 = shl i64 %t79, 8
  %t84 = or i64 %t72, %t81
  store i64 %t84, ptr %l4, !tbaa !24
  %t86 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t86, ptr %l53, !tbaa !27
  %t87 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr i8, ptr %t88, i64 56
  %t90 = load i8, ptr %t89, !tbaa !32
  %t92 = zext i8 %t90 to i64
  %t93 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t93, ptr %l56, !tbaa !27
  %t94 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr i8, ptr %t95, i64 57
  %t97 = load i8, ptr %t96, !tbaa !32
  %t99 = zext i8 %t97 to i64
  %t101 = shl i64 %t99, 8
  %t104 = or i64 %t92, %t101
  store i64 0, ptr %l6, !tbaa !24
  store i64 %t104, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t108 = load i64, ptr %l7, !tbaa !24
  %t109 = load i64, ptr %l6, !tbaa !24
  %t112 = icmp sgt i64 %t108, %t109
  br i1 %t112, label %bb19, label %bb20
bb19:
  %t114 = load i64, ptr %l8, !tbaa !24
  %t116 = icmp sgt i64 %t114, 0
  br i1 %t116, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l65, !tbaa !24
  br label %bb24
bb21:
  %t118 = load i64, ptr %l7, !tbaa !24
  %t119 = load i64, ptr %l6, !tbaa !24
  %t122 = sub i64 %t118, %t119
  %t123 = load i64, ptr %l8, !tbaa !24
  %t126 = add i64 %t122, %t123
  %t128 = sub i64 %t126, 1
  %t129 = load i64, ptr %l8, !tbaa !24
  %t132 = sdiv i64 %t128, %t129
  store i64 %t132, ptr %l68, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l68, !tbaa !24
  br label %bb23
bb23:
  %t134 = load i64, ptr %l68, !tbaa !24
  store i64 %t134, ptr %l65, !tbaa !24
  br label %bb24
bb24:
  %t135 = load i64, ptr %l65, !tbaa !24
  store i64 %t135, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb25
bb25:
  %t136 = load i64, ptr %l10, !tbaa !24
  %t137 = load i64, ptr %l9, !tbaa !24
  %t140 = icmp slt i64 %t136, %t137
  %t142 = xor i1 %t140, true
  br i1 %t142, label %bb26, label %bb27
bb26:
  br label %bb46
bb27:
  br label %bb28
bb28:
  %t144 = load i64, ptr %l6, !tbaa !24
  %t145 = load i64, ptr %l10, !tbaa !24
  %t146 = load i64, ptr %l8, !tbaa !24
  %t149 = mul i64 %t145, %t146
  %t152 = add i64 %t144, %t149
  %t154 = load i64, ptr %l3, !tbaa !24
  %t156 = load i64, ptr %l4, !tbaa !24
  %t159 = mul i64 %t152, %t156
  %t162 = add i64 %t154, %t159
  store i64 %t162, ptr %l12, !tbaa !24
  %t164 = load i64, ptr %l12, !tbaa !24
  %t166 = add i64 %t164, 56
  %t167 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t167, 0
  %t172 = icmp sgt i64 %t166, %t169
  br i1 %t172, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l96, !tbaa !21
  br label %bb31
bb30:
  %t174 = load i64, ptr %l12, !tbaa !24
  %t176 = srem i64 %t174, 8
  %t178 = icmp ne i64 %t176, 0
  store i1 %t178, ptr %l96, !tbaa !21
  br label %bb31
bb31:
  %t180 = load i1, ptr %l96, !tbaa !21
  br i1 %t180, label %bb32, label %bb33
bb32:
  br label %bb46
bb33:
  br label %bb34
bb34:
  %t181 = load i64, ptr %l12, !tbaa !24
  %t183 = sdiv i64 %t181, 8
  store i64 %t183, ptr %l13, !tbaa !24
  %t185 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t187 = load i64, ptr %l13, !tbaa !24
  %t190 = call i64 @compiler_2fprofile_2eword(ptr %s0, { i64, ptr } %t185, i64 %t187)
  store i64 %t190, ptr %l105
  br label %bb35
bb35:
  %t191 = load i64, ptr %l105, !tbaa !24
  %t192 = and i64 %t191, 4294967295
  %t194 = icmp ne i64 %t192, 1
  br i1 %t194, label %bb36, label %bb37
bb36:
  br label %bb45
bb37:
  br label %bb38
bb38:
  %t196 = load ptr, ptr %lp1
  store ptr %t196, ptr %l108, !tbaa !29
  %t197 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t199 = load i64, ptr %l13, !tbaa !24
  %t201 = add i64 %t199, 1
  %t204 = call i64 @compiler_2fprofile_2eword(ptr %s0, { i64, ptr } %t197, i64 %t201)
  store i64 %t204, ptr %l113
  br label %bb39
bb39:
  %t205 = load ptr, ptr %l108, !tbaa !29
  %t206 = load i64, ptr %l113, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t205, i64 %t206)
  br label %bb40
bb40:
  %t207 = load ptr, ptr %lp1
  store ptr %t207, ptr %l114, !tbaa !29
  %t208 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t210 = load i64, ptr %l13, !tbaa !24
  %t212 = add i64 %t210, 4
  %t215 = call i64 @compiler_2fprofile_2eword(ptr %s0, { i64, ptr } %t208, i64 %t212)
  store i64 %t215, ptr %l119
  br label %bb41
bb41:
  %t216 = load ptr, ptr %l114, !tbaa !29
  %t217 = load i64, ptr %l119, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t216, i64 %t217)
  br label %bb42
bb42:
  %t218 = load ptr, ptr %lp1
  store ptr %t218, ptr %l120, !tbaa !29
  %t219 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t221 = load i64, ptr %l13, !tbaa !24
  %t223 = add i64 %t221, 2
  %t226 = call i64 @compiler_2fprofile_2eword(ptr %s0, { i64, ptr } %t219, i64 %t223)
  store i64 %t226, ptr %l125
  br label %bb43
bb43:
  %t227 = load ptr, ptr %l120, !tbaa !29
  %t228 = load i64, ptr %l125, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t227, i64 %t228)
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t229 = load i64, ptr %l10, !tbaa !24
  %t231 = add i64 %t229, 1
  store i64 %t231, ptr %l10, !tbaa !24
  br label %bb25
bb46:
  %t233 = load ptr, ptr %lp1
  %t234 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t233
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t234, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local { i64, ptr } @compiler_2fprofile_2eshortPath(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l9 = alloca i1
  %l11 = alloca i1
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l20 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %s0)
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l4
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  store { i64, ptr } %t2, ptr %l3
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d132, i32 0, i32 1) }, ptr %l5, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t10 = extractvalue { i64, ptr } %t7, 1
  %t11 = mul i64 %t9, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t10, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  br label %bb4
bb4:
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t16, ptr %l1, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t17, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d133, i32 0, i32 1) })
  store i1 %t19, ptr %l9
  br label %bb5
bb5:
  %t20 = load i1, ptr %l9, !tbaa !21
  %t21 = xor i1 %t20, true
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 1
  %t27 = extractvalue { i64, ptr } %t24, 0
  %t28 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d134, i32 0, i32 1) }, 1
  %t29 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d134, i32 0, i32 1) }, 0
  %t30 = add i64 %t27, %t29
  %t31 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t30)
  call void @olang_textcopy(ptr %t31, ptr %t26, i64 %t27)
  %t32 = getelementptr i8, ptr %t31, i64 %t27
  call void @olang_textcopy(ptr %t32, ptr %t28, i64 %t29)
  %t33 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t31, 1
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t37 = extractvalue { i64, ptr } %t34, 1
  %t38 = mul i64 %t36, 1
  %t39 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t38)
  call void @llvm.memcpy.p0.p0.i64(ptr %t39, ptr %t37, i64 %t38, i1 false)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  %t44 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t23, { i64, ptr } %t41)
  store i1 %t44, ptr %l16
  br label %bb8
bb7:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb9
bb8:
  %t45 = load i1, ptr %l16, !tbaa !21
  store i1 %t45, ptr %l11, !tbaa !21
  br label %bb9
bb9:
  %t46 = load i1, ptr %l11, !tbaa !21
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t47 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t47, ptr %l17, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t48, 0
  %t52 = add i64 %t50, 1
  store i64 %t52, ptr %l20, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t53, 0
  store i64 %t56, ptr %l23, !tbaa !24
  %t57 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t57, 0
  store i64 %t58, ptr %l24, !tbaa !24
  %t59 = load i64, ptr %l20, !tbaa !24
  %t60 = icmp sge i64 %t59, 0
  br i1 %t60, label %bb12, label %bb13
bb11:
  br label %bb18
bb12:
  %t62 = load i64, ptr %l20, !tbaa !24
  %t63 = load i64, ptr %l23, !tbaa !24
  %t64 = icmp sle i64 %t62, %t63
  br i1 %t64, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_9b07e838cb7ed4ee_978ead1b2c1f88ba)
  unreachable
bb14:
  %t66 = load i64, ptr %l23, !tbaa !24
  %t67 = load i64, ptr %l24, !tbaa !24
  %t68 = icmp sle i64 %t66, %t67
  br i1 %t68, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_9b07e838cb7ed4ee_978ead1b2c1f88ba)
  unreachable
bb16:
  %t70 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = load i64, ptr %l20, !tbaa !24
  %t73 = load i64, ptr %l23, !tbaa !24
  %t74 = getelementptr i8, ptr %t71, i64 %t72
  %t75 = sub i64 %t73, %t72
  %t76 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t74, 1
  %t79 = extractvalue { i64, ptr } %t77, 1
  %t80 = extractvalue { i64, ptr } %t77, 0
  %t81 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t80)
  call void @olang_textcopy(ptr %t81, ptr %t79, i64 %t80)
  %t82 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t81, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t83, ptr %rv
  br label %ret
bb17:
  call void @__olang_check_failed(ptr @olang_loc_9b07e838cb7ed4ee_978ead1b2c1f88ba)
  unreachable
bb18:
  %t85 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t85, 1
  %t88 = extractvalue { i64, ptr } %t85, 0
  %t89 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t88)
  call void @olang_textcopy(ptr %t89, ptr %t87, i64 %t88)
  %t90 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t91, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fprofile_2esymbolAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca i64
  %l19 = alloca %"compiler/profile:elfFn"
  %l30 = alloca i1
  %l36 = alloca i64
  %l40 = alloca %"compiler/profile:elfFn"
  %l41 = alloca i64
  %l45 = alloca %"compiler/profile:elfFn"
  %l48 = alloca i64
  %l52 = alloca %"compiler/profile:elfFn"
  %l59 = alloca %"compiler/profile:elfFn"
  %l64 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aelfFn_3e_2eLen_3ccompiler_2fprofile_3aelfFn_3e(ptr %v0, ptr %t1)
  store i64 %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load i64, ptr %l7, !tbaa !24
  store i64 %t4, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp slt i64 %t5, %t6
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t13 = load i64, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = add i64 %t13, %t14
  %t19 = sdiv i64 %t17, 2
  store i64 %t19, ptr %l4, !tbaa !24
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i64, ptr %l4, !tbaa !24
  %t26 = call %"compiler/profile:elfFn" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aelfFn_3e_2eAt_3ccompiler_2fprofile_3aelfFn_3e(ptr %v0, ptr %s1, ptr %t21, i64 %t23)
  store %"compiler/profile:elfFn" %t26, ptr %l19
  br label %bb6
bb6:
  %t27 = getelementptr %"compiler/profile:elfFn", ptr %l19, i32 0, i32 0
  %t28 = load i64, ptr %t27, !tbaa !24
  %t29 = load i64, ptr %l1, !tbaa !24
  %t32 = icmp sle i64 %t28, %t29
  br i1 %t32, label %bb7, label %bb8
bb7:
  %t34 = load i64, ptr %l4, !tbaa !24
  %t36 = add i64 %t34, 1
  store i64 %t36, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  %t38 = load i64, ptr %l4, !tbaa !24
  store i64 %t38, ptr %l3, !tbaa !24
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb10:
  br label %bb2
bb11:
  %t40 = load i64, ptr %l2, !tbaa !24
  %t42 = sub i64 %t40, 1
  store i64 %t42, ptr %l5, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s5
  %t44 = load i64, ptr %l5, !tbaa !24
  %t46 = icmp sge i64 %t44, 0
  br i1 %t46, label %bb13, label %bb14
bb13:
  %t48 = load i64, ptr %l5, !tbaa !24
  %t49 = load i64, ptr %l2, !tbaa !24
  %t51 = sub i64 %t49, 4
  %t54 = icmp sge i64 %t48, %t51
  store i1 %t54, ptr %l30, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb15
bb15:
  %t56 = load i1, ptr %l30, !tbaa !21
  %t57 = xor i1 %t56, true
  br i1 %t57, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s5)
  br label %bb30
bb17:
  br label %bb18
bb18:
  %t59 = load i64, ptr %l1, !tbaa !24
  store i64 %t59, ptr %l36, !tbaa !24
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i64, ptr %l5, !tbaa !24
  %t65 = call %"compiler/profile:elfFn" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aelfFn_3e_2eAt_3ccompiler_2fprofile_3aelfFn_3e(ptr %v0, ptr %s5, ptr %t60, i64 %t62)
  store %"compiler/profile:elfFn" %t65, ptr %l40
  br label %bb19
bb19:
  %t66 = getelementptr %"compiler/profile:elfFn", ptr %l40, i32 0, i32 0
  %t67 = load i64, ptr %t66, !tbaa !24
  store i64 %t67, ptr %l41, !tbaa !24
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i64, ptr %l5, !tbaa !24
  %t73 = call %"compiler/profile:elfFn" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aelfFn_3e_2eAt_3ccompiler_2fprofile_3aelfFn_3e(ptr %v0, ptr %s5, ptr %t68, i64 %t70)
  store %"compiler/profile:elfFn" %t73, ptr %l45
  br label %bb20
bb20:
  %t74 = getelementptr %"compiler/profile:elfFn", ptr %l45, i32 0, i32 1
  %t75 = load i64, ptr %t74, !tbaa !24
  %t77 = icmp sgt i64 %t75, 0
  br i1 %t77, label %bb21, label %bb22
bb21:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i64, ptr %l5, !tbaa !24
  %t84 = call %"compiler/profile:elfFn" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aelfFn_3e_2eAt_3ccompiler_2fprofile_3aelfFn_3e(ptr %v0, ptr %s5, ptr %t79, i64 %t81)
  store %"compiler/profile:elfFn" %t84, ptr %l52
  br label %bb23
bb22:
  store i64 1, ptr %l48, !tbaa !24
  br label %bb24
bb23:
  %t85 = getelementptr %"compiler/profile:elfFn", ptr %l52, i32 0, i32 1
  %t86 = load i64, ptr %t85, !tbaa !24
  store i64 %t86, ptr %l48, !tbaa !24
  br label %bb24
bb24:
  %t88 = load i64, ptr %l41, !tbaa !24
  %t89 = load i64, ptr %l48, !tbaa !24
  %t90 = add i64 %t88, %t89
  %t91 = load i64, ptr %l36, !tbaa !24
  %t93 = icmp slt i64 %t91, %t90
  br i1 %t93, label %bb25, label %bb26
bb25:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = load i64, ptr %l5, !tbaa !24
  %t100 = call %"compiler/profile:elfFn" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aelfFn_3e_2eAt_3ccompiler_2fprofile_3aelfFn_3e(ptr %v0, ptr %v0, ptr %t95, i64 %t97)
  store %"compiler/profile:elfFn" %t100, ptr %l59
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t101 = getelementptr %"compiler/profile:elfFn", ptr %l59, i32 0, i32 2
  %t102 = load { i64, ptr }, ptr %t101, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t102, 1
  %t105 = extractvalue { i64, ptr } %t102, 0
  %t106 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t105)
  call void @olang_textcopy(ptr %t106, ptr %t104, i64 %t105)
  %t107 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  call void @__olang_scope_close(ptr %s5)
  store { i64, ptr } %t108, ptr %rv
  br label %ret
bb28:
  call void @__olang_scope_close(ptr %s5)
  br label %bb29
bb29:
  %t110 = load i64, ptr %l5, !tbaa !24
  %t112 = sub i64 %t110, 1
  store i64 %t112, ptr %l5, !tbaa !24
  br label %bb12
bb30:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d135, i32 0, i32 1) }, ptr %l64, !tbaa !27
  %t114 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t114, ptr %l65, !tbaa !27
  %t115 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t115, 0
  store i64 %t116, ptr %l66, !tbaa !24
  %t117 = load i64, ptr %l66, !tbaa !24
  %t118 = mul i64 %t117, 1
  %t119 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t118)
  %t120 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t121 = insertvalue { i64, ptr } %t120, ptr %t119, 1
  store { i64, ptr } %t121, ptr %l67, !tbaa !27
  %t122 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = load i64, ptr %l66, !tbaa !24
  %t127 = mul i64 %t126, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t123, ptr %t125, i64 %t127, i1 false)
  %t128 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t128, ptr %l65, !tbaa !27
  %t129 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t129, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { %"compiler/profile:Profile", %"compiler/profile:Places" } @compiler_2fprofile_2etwoStacks(ptr %v0) #0 {
entry:
  %lp0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %lp5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca %"compiler/profile:Profile"
  %l12 = alloca ptr
  %l13 = alloca %"compiler/profile:Sample"
  %l14 = alloca ptr
  %l15 = alloca %"compiler/profile:Sample"
  %l31 = alloca %"compiler/profile:Places"
  %l52 = alloca ptr
  %l54 = alloca i64
  %l56 = alloca i64
  %l57 = alloca %"compiler/profile:Frame"
  %l58 = alloca ptr
  %l60 = alloca i64
  %l62 = alloca i64
  %l63 = alloca %"compiler/profile:Frame"
  %l64 = alloca ptr
  %l66 = alloca i64
  %l68 = alloca i64
  %l69 = alloca %"compiler/profile:Frame"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { %"compiler/profile:Profile", %"compiler/profile:Places" }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/profile:Profile" @compiler_2fprofile_3aProfile_2ector(ptr %v0)
  store %"compiler/profile:Profile" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store ptr %t2, ptr %lp0
  %t3 = load %"compiler/profile:Profile", ptr %l11
  %t4 = load ptr, ptr %lp0
  store %"compiler/profile:Profile" %t3, ptr %t4
  %t5 = load ptr, ptr %lp0
  %t6 = getelementptr %"compiler/profile:Profile", ptr %t5, i32 0, i32 2
  store i64 1, ptr %t6, !tbaa !24
  %t7 = load ptr, ptr %lp0
  %t8 = getelementptr %"compiler/profile:Profile", ptr %t7, i32 0, i32 3
  store ptr %t8, ptr %l12, !tbaa !29
  %t9 = call %"compiler/profile:Sample" @compiler_2fprofile_3aSample_2ector(ptr %s0, i64 3, i64 0, i64 2)
  store %"compiler/profile:Sample" %t9, ptr %l13
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l12, !tbaa !29
  %t11 = load %"compiler/profile:Sample", ptr %l13
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2ePush_3ccompiler_2fprofile_3aSample_3e(ptr %v0, ptr %t10, %"compiler/profile:Sample" %t11)
  br label %bb3
bb3:
  %t12 = load ptr, ptr %lp0
  %t13 = getelementptr %"compiler/profile:Profile", ptr %t12, i32 0, i32 3
  store ptr %t13, ptr %l14, !tbaa !29
  %t14 = call %"compiler/profile:Sample" @compiler_2fprofile_3aSample_2ector(ptr %s0, i64 1, i64 2, i64 2)
  store %"compiler/profile:Sample" %t14, ptr %l15
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l14, !tbaa !29
  %t16 = load %"compiler/profile:Sample", ptr %l15
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2ePush_3ccompiler_2fprofile_3aSample_3e(ptr %v0, ptr %t15, %"compiler/profile:Sample" %t16)
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = insertvalue [4 x i64] undef, i64 100, 0
  %t18 = insertvalue [4 x i64] %t17, i64 201, 1
  %t19 = insertvalue [4 x i64] %t18, i64 300, 2
  %t20 = insertvalue [4 x i64] %t19, i64 201, 3
  %t22 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store [4 x i64] %t20, ptr %t22
  store ptr %t22, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t24 = load ptr, ptr %l1
  store i64 4, ptr %l3, !tbaa !24
  br label %bb6
bb6:
  %t27 = load i64, ptr %l2, !tbaa !24
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = icmp slt i64 %t27, %t28
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb7, label %bb8
bb7:
  br label %bb12
bb8:
  br label %bb9
bb9:
  %t35 = load ptr, ptr %l1
  %t36 = load i64, ptr %l2, !tbaa !24
  %t39 = getelementptr [4 x i64], ptr %t35, i64 0, i64 %t36
  %t40 = load i64, ptr %t39, !tbaa !34
  %t42 = load ptr, ptr %lp0
  %t43 = getelementptr %"compiler/profile:Profile", ptr %t42, i32 0, i32 4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t43, i64 %t40)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t47 = load i64, ptr %l2, !tbaa !24
  %t49 = add i64 %t47, 1
  store i64 %t49, ptr %l2, !tbaa !24
  br label %bb6
bb12:
  call void @__olang_scope_close(ptr %s1)
  %t51 = call %"compiler/profile:Places" @compiler_2fprofile_3aPlaces_2ector(ptr %v0)
  store %"compiler/profile:Places" %t51, ptr %l31
  br label %bb13
bb13:
  %t52 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store ptr %t52, ptr %lp5
  %t53 = load %"compiler/profile:Places", ptr %l31
  %t54 = load ptr, ptr %lp5
  store %"compiler/profile:Places" %t53, ptr %t54
  store %olang.scope zeroinitializer, ptr %s4
  %t55 = insertvalue [3 x i64] undef, i64 100, 0
  %t56 = insertvalue [3 x i64] %t55, i64 200, 1
  %t57 = insertvalue [3 x i64] %t56, i64 300, 2
  %t59 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 24, i64 8)
  store [3 x i64] %t57, ptr %t59
  store ptr %t59, ptr %l6
  store i64 0, ptr %l7, !tbaa !24
  %t61 = load ptr, ptr %l6
  store i64 3, ptr %l8, !tbaa !24
  br label %bb14
bb14:
  %t64 = load i64, ptr %l7, !tbaa !24
  %t65 = load i64, ptr %l8, !tbaa !24
  %t68 = icmp slt i64 %t64, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb15, label %bb16
bb15:
  br label %bb22
bb16:
  br label %bb17
bb17:
  %t72 = load i64, ptr %l7, !tbaa !24
  store i64 %t72, ptr %l9, !tbaa !24
  %t74 = load ptr, ptr %l6
  %t75 = load i64, ptr %l7, !tbaa !24
  %t78 = getelementptr [3 x i64], ptr %t74, i64 0, i64 %t75
  %t79 = load i64, ptr %t78, !tbaa !34
  %t81 = load ptr, ptr %lp5
  %t82 = getelementptr %"compiler/profile:Places", ptr %t81, i32 0, i32 5
  %t84 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t82, i64 %t79, i64 %t84)
  br label %bb18
bb18:
  %t88 = load ptr, ptr %lp5
  %t89 = getelementptr %"compiler/profile:Places", ptr %t88, i32 0, i32 3
  %t90 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t89, i64 %t90)
  br label %bb19
bb19:
  %t93 = load ptr, ptr %lp5
  %t94 = getelementptr %"compiler/profile:Places", ptr %t93, i32 0, i32 4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t94, i64 1)
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t96 = load i64, ptr %l7, !tbaa !24
  %t98 = add i64 %t96, 1
  store i64 %t98, ptr %l7, !tbaa !24
  br label %bb14
bb22:
  call void @__olang_scope_close(ptr %s4)
  %t100 = load ptr, ptr %lp5
  %t101 = getelementptr %"compiler/profile:Places", ptr %t100, i32 0, i32 2
  store ptr %t101, ptr %l52, !tbaa !29
  %t102 = load ptr, ptr %lp5
  %t104 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v0, ptr %s0, ptr %t102, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d136, i32 0, i32 1) })
  store i64 %t104, ptr %l54
  br label %bb23
bb23:
  %t105 = load ptr, ptr %lp5
  %t107 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v0, ptr %s0, ptr %t105, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d137, i32 0, i32 1) })
  store i64 %t107, ptr %l56
  br label %bb24
bb24:
  %t108 = load i64, ptr %l54, !tbaa !24
  %t109 = load i64, ptr %l56, !tbaa !24
  %t110 = call %"compiler/profile:Frame" @compiler_2fprofile_3aFrame_2ector(ptr %s0, i64 %t108, i64 %t109, i64 6)
  store %"compiler/profile:Frame" %t110, ptr %l57
  br label %bb25
bb25:
  %t111 = load ptr, ptr %l52, !tbaa !29
  %t112 = load %"compiler/profile:Frame", ptr %l57
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2ePush_3ccompiler_2fprofile_3aFrame_3e(ptr %v0, ptr %t111, %"compiler/profile:Frame" %t112)
  br label %bb26
bb26:
  %t113 = load ptr, ptr %lp5
  %t114 = getelementptr %"compiler/profile:Places", ptr %t113, i32 0, i32 2
  store ptr %t114, ptr %l58, !tbaa !29
  %t115 = load ptr, ptr %lp5
  %t117 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v0, ptr %s0, ptr %t115, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d138, i32 0, i32 1) })
  store i64 %t117, ptr %l60
  br label %bb27
bb27:
  %t118 = load ptr, ptr %lp5
  %t120 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v0, ptr %s0, ptr %t118, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d139, i32 0, i32 1) })
  store i64 %t120, ptr %l62
  br label %bb28
bb28:
  %t121 = load i64, ptr %l60, !tbaa !24
  %t122 = load i64, ptr %l62, !tbaa !24
  %t123 = call %"compiler/profile:Frame" @compiler_2fprofile_3aFrame_2ector(ptr %s0, i64 %t121, i64 %t122, i64 20)
  store %"compiler/profile:Frame" %t123, ptr %l63
  br label %bb29
bb29:
  %t124 = load ptr, ptr %l58, !tbaa !29
  %t125 = load %"compiler/profile:Frame", ptr %l63
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2ePush_3ccompiler_2fprofile_3aFrame_3e(ptr %v0, ptr %t124, %"compiler/profile:Frame" %t125)
  br label %bb30
bb30:
  %t126 = load ptr, ptr %lp5
  %t127 = getelementptr %"compiler/profile:Places", ptr %t126, i32 0, i32 2
  store ptr %t127, ptr %l64, !tbaa !29
  %t128 = load ptr, ptr %lp5
  %t130 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v0, ptr %s0, ptr %t128, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d140, i32 0, i32 1) })
  store i64 %t130, ptr %l66
  br label %bb31
bb31:
  %t131 = load ptr, ptr %lp5
  %t133 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v0, ptr %s0, ptr %t131, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d141, i32 0, i32 1) })
  store i64 %t133, ptr %l68
  br label %bb32
bb32:
  %t134 = load i64, ptr %l66, !tbaa !24
  %t135 = load i64, ptr %l68, !tbaa !24
  %t136 = call %"compiler/profile:Frame" @compiler_2fprofile_3aFrame_2ector(ptr %s0, i64 %t134, i64 %t135, i64 14)
  store %"compiler/profile:Frame" %t136, ptr %l69
  br label %bb33
bb33:
  %t137 = load ptr, ptr %l64, !tbaa !29
  %t138 = load %"compiler/profile:Frame", ptr %l69
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2ePush_3ccompiler_2fprofile_3aFrame_3e(ptr %v0, ptr %t137, %"compiler/profile:Frame" %t138)
  br label %bb34
bb34:
  %t139 = load ptr, ptr %lp0
  %t140 = load %"compiler/profile:Profile", ptr %t139
  %t141 = load ptr, ptr %lp5
  %t142 = load %"compiler/profile:Places", ptr %t141
  %t144 = insertvalue { %"compiler/profile:Profile", %"compiler/profile:Places" } undef, %"compiler/profile:Profile" %t140, 0
  %t146 = insertvalue { %"compiler/profile:Profile", %"compiler/profile:Places" } %t144, %"compiler/profile:Places" %t142, 1
  call void @__olang_scope_close(ptr %s0)
  store { %"compiler/profile:Profile", %"compiler/profile:Places" } %t146, ptr %rv
  br label %ret
ret:
  %rr = load { %"compiler/profile:Profile", %"compiler/profile:Places" }, ptr %rv
  ret { %"compiler/profile:Profile", %"compiler/profile:Places" } %rr
}

define dso_local { i64, ptr } @compiler_2fprofile_2etypesRead(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l18 = alloca { i64, ptr }
  %l27 = alloca i1
  %l28 = alloca { i64, ptr }
  %l32 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l54 = alloca { i64, ptr }
  %l60 = alloca ptr
  %l61 = alloca { i64, ptr }
  %l62 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l72 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l74 = alloca i64
  %l75 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t3, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load i64, ptr %l4, !tbaa !24
  %t10 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb35
bb4:
  br label %bb5
bb5:
  %t17 = load i64, ptr %l4, !tbaa !24
  store i64 %t17, ptr %l6, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t19, ptr %l18, !tbaa !27
  %t20 = load i64, ptr %l4, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i8, ptr %t23, i64 %t20
  %t25 = load i8, ptr %t24, !tbaa !32
  %t29 = icmp ne i8 %t25, 58
  br i1 %t29, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb7:
  br label %bb8
bb8:
  %t31 = load i64, ptr %l6, !tbaa !24
  store i64 %t31, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  %t33 = load i64, ptr %l8, !tbaa !24
  %t34 = load i64, ptr %l2, !tbaa !24
  %t37 = icmp sgt i64 %t33, %t34
  br i1 %t37, label %bb10, label %bb11
bb10:
  %t39 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t39, ptr %l28, !tbaa !27
  %t40 = load i64, ptr %l8, !tbaa !24
  %t42 = sub i64 %t40, 1
  %t44 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr i8, ptr %t45, i64 %t42
  %t47 = load i8, ptr %t46, !tbaa !32
  %t49 = call i1 @compiler_2fprofile_2eidentityChar(i8 %t47)
  store i1 %t49, ptr %l32
  br label %bb12
bb11:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb13
bb12:
  %t50 = load i1, ptr %l32, !tbaa !21
  store i1 %t50, ptr %l27, !tbaa !21
  br label %bb13
bb13:
  %t51 = load i1, ptr %l27, !tbaa !21
  %t52 = xor i1 %t51, true
  br i1 %t52, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t54 = load i64, ptr %l8, !tbaa !24
  %t56 = sub i64 %t54, 1
  store i64 %t56, ptr %l8, !tbaa !24
  br label %bb17
bb17:
  br label %bb9
bb18:
  store ptr %l1, ptr %l36, !tbaa !29
  %t58 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t58, ptr %l37, !tbaa !27
  %t59 = load i64, ptr %l2, !tbaa !24
  store i64 %t59, ptr %l38, !tbaa !24
  %t60 = load i64, ptr %l8, !tbaa !24
  store i64 %t60, ptr %l39, !tbaa !24
  %t61 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t61, 0
  store i64 %t62, ptr %l40, !tbaa !24
  %t63 = load i64, ptr %l38, !tbaa !24
  %t64 = icmp sge i64 %t63, 0
  br i1 %t64, label %bb19, label %bb20
bb19:
  %t66 = load i64, ptr %l38, !tbaa !24
  %t67 = load i64, ptr %l39, !tbaa !24
  %t68 = icmp sle i64 %t66, %t67
  br i1 %t68, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_cc2e380c5cd0dda_c071bfd9a740ca6e)
  unreachable
bb21:
  %t70 = load i64, ptr %l39, !tbaa !24
  %t71 = load i64, ptr %l40, !tbaa !24
  %t72 = icmp sle i64 %t70, %t71
  br i1 %t72, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_cc2e380c5cd0dda_c071bfd9a740ca6e)
  unreachable
bb23:
  %t74 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = load i64, ptr %l38, !tbaa !24
  %t77 = load i64, ptr %l39, !tbaa !24
  %t78 = getelementptr i8, ptr %t75, i64 %t76
  %t79 = sub i64 %t77, %t76
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  %t82 = load ptr, ptr %l36, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t82, { i64, ptr } %t81)
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_cc2e380c5cd0dda_c071bfd9a740ca6e)
  unreachable
bb25:
  store ptr %l1, ptr %l45, !tbaa !29
  %t84 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t84, ptr %l46, !tbaa !27
  %t85 = load i64, ptr %l8, !tbaa !24
  store i64 %t85, ptr %l47, !tbaa !24
  %t86 = load i64, ptr %l6, !tbaa !24
  store i64 %t86, ptr %l48, !tbaa !24
  %t87 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  store i64 %t88, ptr %l49, !tbaa !24
  %t89 = load i64, ptr %l47, !tbaa !24
  %t90 = icmp sge i64 %t89, 0
  br i1 %t90, label %bb26, label %bb27
bb26:
  %t92 = load i64, ptr %l47, !tbaa !24
  %t93 = load i64, ptr %l48, !tbaa !24
  %t94 = icmp sle i64 %t92, %t93
  br i1 %t94, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_4bebebd3fadd2f37_94a97b9fa165786b)
  unreachable
bb28:
  %t96 = load i64, ptr %l48, !tbaa !24
  %t97 = load i64, ptr %l49, !tbaa !24
  %t98 = icmp sle i64 %t96, %t97
  br i1 %t98, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_4bebebd3fadd2f37_94a97b9fa165786b)
  unreachable
bb30:
  %t100 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = load i64, ptr %l47, !tbaa !24
  %t103 = load i64, ptr %l48, !tbaa !24
  %t104 = getelementptr i8, ptr %t101, i64 %t102
  %t105 = sub i64 %t103, %t102
  %t106 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t104, 1
  %t109 = call { i64, ptr } @compiler_2fprofile_2equalifier(ptr %v0, ptr %s2, { i64, ptr } %t107)
  store { i64, ptr } %t109, ptr %l54
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_4bebebd3fadd2f37_94a97b9fa165786b)
  unreachable
bb32:
  %t110 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t110, 0
  %t112 = extractvalue { i64, ptr } %t110, 1
  %t113 = mul i64 %t111, 1
  %t114 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t113)
  call void @llvm.memcpy.p0.p0.i64(ptr %t114, ptr %t112, i64 %t113, i1 false)
  %t115 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t114, 1
  %t117 = load ptr, ptr %l45, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t117, { i64, ptr } %t116)
  br label %bb33
bb33:
  %t119 = load i64, ptr %l6, !tbaa !24
  %t121 = add i64 %t119, 1
  store i64 %t121, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb34:
  %t123 = load i64, ptr %l4, !tbaa !24
  %t125 = add i64 %t123, 1
  store i64 %t125, ptr %l4, !tbaa !24
  br label %bb2
bb35:
  store ptr %l1, ptr %l60, !tbaa !29
  %t127 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t127, ptr %l61, !tbaa !27
  %t128 = load i64, ptr %l2, !tbaa !24
  store i64 %t128, ptr %l62, !tbaa !24
  %t129 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t129, 0
  store i64 %t132, ptr %l65, !tbaa !24
  %t133 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 0
  store i64 %t134, ptr %l66, !tbaa !24
  %t135 = load i64, ptr %l62, !tbaa !24
  %t136 = icmp sge i64 %t135, 0
  br i1 %t136, label %bb36, label %bb37
bb36:
  %t138 = load i64, ptr %l62, !tbaa !24
  %t139 = load i64, ptr %l65, !tbaa !24
  %t140 = icmp sle i64 %t138, %t139
  br i1 %t140, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_ea1fc1fa824e624c_c3d948fe5a073af0)
  unreachable
bb38:
  %t142 = load i64, ptr %l65, !tbaa !24
  %t143 = load i64, ptr %l66, !tbaa !24
  %t144 = icmp sle i64 %t142, %t143
  br i1 %t144, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_ea1fc1fa824e624c_c3d948fe5a073af0)
  unreachable
bb40:
  %t146 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = load i64, ptr %l62, !tbaa !24
  %t149 = load i64, ptr %l65, !tbaa !24
  %t150 = getelementptr i8, ptr %t147, i64 %t148
  %t151 = sub i64 %t149, %t148
  %t152 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t150, 1
  %t154 = load ptr, ptr %l60, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t154, { i64, ptr } %t153)
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_ea1fc1fa824e624c_c3d948fe5a073af0)
  unreachable
bb42:
  %t157 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t157, ptr %l72
  br label %bb43
bb43:
  %t158 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t158, ptr %l73, !tbaa !27
  %t159 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t159, 0
  store i64 %t160, ptr %l74, !tbaa !24
  %t161 = load i64, ptr %l74, !tbaa !24
  %t162 = mul i64 %t161, 1
  %t163 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t162)
  %t164 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t165 = insertvalue { i64, ptr } %t164, ptr %t163, 1
  store { i64, ptr } %t165, ptr %l75, !tbaa !27
  %t166 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = load i64, ptr %l74, !tbaa !24
  %t171 = mul i64 %t170, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t167, ptr %t169, i64 %t171, i1 false)
  %t172 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t172, ptr %l73, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t173 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t173, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fprofile_2eword(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i64
  %l34 = alloca { i64, ptr }
  %l42 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  store i64 8, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t1 = load i64, ptr %l4, !tbaa !24
  %t2 = load i64, ptr %l3, !tbaa !24
  %t5 = icmp sgt i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l5, !tbaa !24
  %t9 = icmp sgt i64 %t7, 0
  br i1 %t9, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l12, !tbaa !24
  br label %bb6
bb3:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t15 = sub i64 %t11, %t12
  %t16 = load i64, ptr %l5, !tbaa !24
  %t19 = add i64 %t15, %t16
  %t21 = sub i64 %t19, 1
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = sdiv i64 %t21, %t22
  store i64 %t25, ptr %l15, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb5
bb5:
  %t27 = load i64, ptr %l15, !tbaa !24
  store i64 %t27, ptr %l12, !tbaa !24
  br label %bb6
bb6:
  %t28 = load i64, ptr %l12, !tbaa !24
  store i64 %t28, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t29 = load i64, ptr %l7, !tbaa !24
  %t30 = load i64, ptr %l6, !tbaa !24
  %t33 = icmp slt i64 %t29, %t30
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb8, label %bb9
bb8:
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t37 = load i64, ptr %l3, !tbaa !24
  %t38 = load i64, ptr %l7, !tbaa !24
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = mul i64 %t38, %t39
  %t45 = add i64 %t37, %t42
  store i64 %t45, ptr %l8, !tbaa !24
  %t47 = load i64, ptr %l2, !tbaa !24
  store { i64, ptr } %a0, ptr %l34, !tbaa !27
  %t51 = mul i64 %a1, 8
  %t52 = load i64, ptr %l8, !tbaa !24
  %t55 = add i64 %t51, %t52
  %t57 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr i8, ptr %t58, i64 %t55
  %t60 = load i8, ptr %t59, !tbaa !32
  %t62 = zext i8 %t60 to i64
  %t63 = load i64, ptr %l8, !tbaa !24
  %t65 = mul i64 %t63, 8
  store i64 %t65, ptr %l42, !tbaa !24
  %t67 = load i64, ptr %l42, !tbaa !24
  %t68 = load i64, ptr %l42, !tbaa !24
  %t69 = shl i64 %t62, %t68
  %t72 = or i64 %t47, %t69
  store i64 %t72, ptr %l2, !tbaa !24
  br label %bb11
bb11:
  %t74 = load i64, ptr %l7, !tbaa !24
  %t76 = add i64 %t74, 1
  store i64 %t76, ptr %l7, !tbaa !24
  br label %bb7
bb12:
  %t78 = load i64, ptr %l2, !tbaa !24
  store i64 %t78, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/profile:Frame" @compiler_2fprofile_3aFrame_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2) #0 {
entry:
  %rv = alloca %"compiler/profile:Frame"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/profile:Frame" undef, i64 %a0, 0
  %t10 = insertvalue %"compiler/profile:Frame" %t8, i64 %a1, 1
  %t12 = insertvalue %"compiler/profile:Frame" %t10, i64 %a2, 2
  store %"compiler/profile:Frame" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/profile:Frame", ptr %rv
  ret %"compiler/profile:Frame" %rr
}

define dso_local %"compiler/profile:Places" @compiler_2fprofile_3aPlaces_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l1 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l2 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/profile:Places"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l6
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  %t3 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l7
  br label %bb2
bb2:
  %t4 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l7
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l1
  %t5 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l8
  br label %bb3
bb3:
  %t6 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l2
  %t7 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l9
  br label %bb4
bb4:
  %t8 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l3
  %t9 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l10
  br label %bb5
bb5:
  %t10 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l4
  %t11 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l11
  br label %bb6
bb6:
  %t12 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  %t13 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  %t14 = insertvalue %"compiler/profile:Places" undef, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, 0
  %t15 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l1
  %t16 = insertvalue %"compiler/profile:Places" %t14, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, 1
  %t17 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l2
  %t18 = insertvalue %"compiler/profile:Places" %t16, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, 2
  %t19 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  %t20 = insertvalue %"compiler/profile:Places" %t18, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, 3
  %t21 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l4
  %t22 = insertvalue %"compiler/profile:Places" %t20, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, 4
  %t24 = insertvalue %"compiler/profile:Places" %t22, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, 5
  store %"compiler/profile:Places" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/profile:Places", ptr %rv
  ret %"compiler/profile:Places" %rr
}

define dso_local %"compiler/profile:Profile" @compiler_2fprofile_3aProfile_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/profile:Profile"
  br label %start
start:
  br label %bb0
bb0:
  store i64 1000000, ptr %l0, !tbaa !24
  store i64 0, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l6
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l3
  %t3 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l7
  br label %bb2
bb2:
  %t4 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l7
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d142, i32 0, i32 1) }, ptr %l5, !tbaa !27
  %t5 = load i64, ptr %l0, !tbaa !24
  %t6 = insertvalue %"compiler/profile:Profile" undef, i64 %t5, 0
  %t7 = load i64, ptr %l1, !tbaa !24
  %t8 = insertvalue %"compiler/profile:Profile" %t6, i64 %t7, 1
  %t9 = load i64, ptr %l2, !tbaa !24
  %t10 = insertvalue %"compiler/profile:Profile" %t8, i64 %t9, 2
  %t11 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  %t12 = insertvalue %"compiler/profile:Profile" %t10, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, 3
  %t14 = insertvalue %"compiler/profile:Profile" %t12, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, 4
  %t15 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t16 = insertvalue %"compiler/profile:Profile" %t14, { i64, ptr } %t15, 5
  store %"compiler/profile:Profile" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/profile:Profile", ptr %rv
  ret %"compiler/profile:Profile" %rr
}

define dso_local %"compiler/profile:Sample" @compiler_2fprofile_3aSample_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2) #0 {
entry:
  %rv = alloca %"compiler/profile:Sample"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/profile:Sample" undef, i64 %a0, 0
  %t10 = insertvalue %"compiler/profile:Sample" %t8, i64 %a1, 1
  %t12 = insertvalue %"compiler/profile:Sample" %t10, i64 %a2, 2
  store %"compiler/profile:Sample" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/profile:Sample", ptr %rv
  ret %"compiler/profile:Sample" %rr
}

define dso_local %"compiler/profile:Tally" @compiler_2fprofile_3aTally_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l1 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l2 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/profile:Tally"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l7
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  %t3 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l8
  br label %bb2
bb2:
  %t4 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l1
  %t5 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l9
  br label %bb3
bb3:
  %t6 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l2
  %t7 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l10
  br label %bb4
bb4:
  %t8 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l3
  %t9 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l11
  br label %bb5
bb5:
  %t10 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l4
  %t11 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l12
  br label %bb6
bb6:
  %t12 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l5
  %t13 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l13
  br label %bb7
bb7:
  %t14 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  %t15 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  %t16 = insertvalue %"compiler/profile:Tally" undef, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, 0
  %t17 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l1
  %t18 = insertvalue %"compiler/profile:Tally" %t16, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, 1
  %t19 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l2
  %t20 = insertvalue %"compiler/profile:Tally" %t18, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, 2
  %t21 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  %t22 = insertvalue %"compiler/profile:Tally" %t20, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, 3
  %t23 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l4
  %t24 = insertvalue %"compiler/profile:Tally" %t22, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, 4
  %t25 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  %t26 = insertvalue %"compiler/profile:Tally" %t24, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, 5
  %t28 = insertvalue %"compiler/profile:Tally" %t26, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, 6
  store %"compiler/profile:Tally" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/profile:Tally", ptr %rv
  ret %"compiler/profile:Tally" %rr
}

define dso_local %"compiler/profile:elfFn" @compiler_2fprofile_3aelfFn_2ector(ptr %v0, ptr %v1, i64 %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %rv = alloca %"compiler/profile:elfFn"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/profile:elfFn" undef, i64 %a0, 0
  %t10 = insertvalue %"compiler/profile:elfFn" %t8, i64 %a1, 1
  %t12 = insertvalue %"compiler/profile:elfFn" %t10, { i64, ptr } %a2, 2
  store %"compiler/profile:elfFn" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/profile:elfFn", ptr %rv
  ret %"compiler/profile:elfFn" %rr
}

define dso_local %"compiler/profile:mapping" @compiler_2fprofile_3amapping_2ector(ptr %v0, ptr %v1, i64 %a0, i64 %a1, i64 %a2, { i64, ptr } %a3) #0 {
entry:
  %rv = alloca %"compiler/profile:mapping"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/profile:mapping" undef, i64 %a0, 0
  %t12 = insertvalue %"compiler/profile:mapping" %t10, i64 %a1, 1
  %t14 = insertvalue %"compiler/profile:mapping" %t12, i64 %a2, 2
  %t16 = insertvalue %"compiler/profile:mapping" %t14, { i64, ptr } %a3, 3
  store %"compiler/profile:mapping" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/profile:mapping", ptr %rv
  ret %"compiler/profile:mapping" %rr
}

define dso_local %"compiler/profile:node" @compiler_2fprofile_3anode_2ector(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l8 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/profile:node"
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a0, ptr %l2, !tbaa !24
  store i64 %a1, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t5 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = insertvalue %"compiler/profile:node" undef, i64 %t7, 0
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = insertvalue %"compiler/profile:node" %t8, i64 %t9, 1
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = insertvalue %"compiler/profile:node" %t10, i64 %t11, 2
  %t14 = insertvalue %"compiler/profile:node" %t12, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, 3
  store %"compiler/profile:node" %t14, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/profile:node", ptr %rv
  ret %"compiler/profile:node" %rr
}

define dso_local void @olang_2einit_2ecompiler_2fprofile() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fprofile_2eFlameWidth_2einit()
  br label %bb1
bb1:
  call void @compiler_2fprofile_2eFrameHeight_2einit()
  br label %bb2
bb2:
  call void @compiler_2fprofile_2eFlameScript_2einit()
  br label %bb3
bb3:
  br label %ret
ret:
  ret void
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal i1 @olang_lambda_0(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca ptr
  %l8 = alloca %"compiler/profile:node"
  %l10 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l15 = alloca %"compiler/profile:node"
  %l17 = alloca { i64, ptr }
  %l18 = alloca i1
  %rv = alloca i1
  %cp0 = getelementptr { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  store ptr %cv0, ptr %l2
  %cp1 = getelementptr { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr }, ptr %env, i32 0, i32 1
  %cv1 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %cp1, !tbaa !28
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %cv1, ptr %l3
  %vq0 = getelementptr { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr }, ptr %env, i32 0, i32 2
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  %vq1 = getelementptr { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr }, ptr %env, i32 0, i32 3
  %vr1 = load ptr, ptr %vq1, !tbaa !28
  %vc1 = call ptr @__olang_capture_scope(ptr %vr1)
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/profile:Places", ptr %t1, i32 0, i32 0
  store ptr %t3, ptr %l5, !tbaa !29
  %t7 = call %"compiler/profile:node" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eAt_3ccompiler_2fprofile_3anode_3e(ptr %vc1, ptr %vc1, ptr %l3, i64 %a0)
  store %"compiler/profile:node" %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = getelementptr %"compiler/profile:node", ptr %l8, i32 0, i32 0
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l5, !tbaa !29
  %t12 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %vc0, ptr %vc0, ptr %t10, i64 %t9)
  store { i64, ptr } %t12, ptr %l10
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t15 = getelementptr %"compiler/profile:Places", ptr %t13, i32 0, i32 0
  store ptr %t15, ptr %l12, !tbaa !29
  %t19 = call %"compiler/profile:node" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eAt_3ccompiler_2fprofile_3anode_3e(ptr %vc1, ptr %vc1, ptr %l3, i64 %a1)
  store %"compiler/profile:node" %t19, ptr %l15
  br label %bb3
bb3:
  %t20 = getelementptr %"compiler/profile:node", ptr %l15, i32 0, i32 0
  %t21 = load i64, ptr %t20, !tbaa !24
  %t22 = load ptr, ptr %l12, !tbaa !29
  %t24 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %vc0, ptr %vc0, ptr %t22, i64 %t21)
  store { i64, ptr } %t24, ptr %l17
  br label %bb4
bb4:
  %t25 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %vc0, ptr %vc0, { i64, ptr } %t25, { i64, ptr } %t26)
  store i1 %t27, ptr %l18
  br label %bb5
bb5:
  %t28 = load i1, ptr %l18, !tbaa !21
  store i1 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d1 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"all" }>, align 8
@.d2 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" - " }>, align 8
@.d3 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" ms, " }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare i64 @__olang_fmt_i64(ptr, i64)
@.d4 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"<g class=\22f\22 data-x=\22" }>, align 8
@.d5 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"\22 data-w=\22" }>, align 8
@.d6 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"\22 data-d=\22" }>, align 8
@.d7 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"\22><title>" }>, align 8
@.d8 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"</title><rect y=\22" }>, align 8
@.d9 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"\22 height=\22" }>, align 8
@.d10 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"\22 rx=\222\22 fill=\22rgb(" }>, align 8
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d12 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c")\22/><text y=\22" }>, align 8
@.d13 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\22>" }>, align 8
@.d14 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"</text></g>\0A" }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d15 = private constant <{ i64, [57 x i8] }> <{ i64 0, [57 x i8] c"<!doctype html>\0A<html><head><meta charset=\22utf-8\22><title>" }>, align 8
@.d16 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c" - olang profile</title>\0A" }>, align 8
@.d17 = private constant <{ i64, [213 x i8] }> <{ i64 0, [213 x i8] c"<style>body{margin:0;padding:10px;font:12px monospace;background:#fff}svg text{font:11px monospace;fill:#000;pointer-events:none}g.f{cursor:pointer}g.f:hover rect{stroke:#000;stroke-width:.5}</style></head><body>\0A" }>, align 8
@.d18 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"<div>" }>, align 8
@.d19 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d20 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" samples, " }>, align 8
@.d21 = private constant <{ i64, [78 x i8] }> <{ i64 0, [78 x i8] c" s of CPU time - a click on a frame zooms to it, on the bottom bar back</div>\0A" }>, align 8
@.d22 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"<svg id=\22fg\22 width=\22" }>, align 8
@.d23 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"\22 height=\22" }>, align 8
@.d24 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"\22 data-total=\22" }>, align 8
@.d25 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"\22>\0A" }>, align 8
@.d26 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"</svg>\0A" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d27 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"</body></html>\0A" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d28 = private constant <{ i64, [1031 x i8] }> <{ i64 0, [1031 x i8] c"<script>\0A(function(){\0A  var svg=document.getElementById(\22fg\22),W=svg.getAttribute(\22width\22)*1,gs=svg.querySelectorAll(\22g.f\22);\0A  function show(x0,w0,d0){\0A    for(var i=0;i<gs.length;i++){\0A      var g=gs[i],x=g.dataset.x*1,w=g.dataset.w*1,d=g.dataset.d*1,r=g.querySelector(\22rect\22),t=g.querySelector(\22text\22);\0A      var inside=x>=x0&&x+w<=x0+w0,under=d<d0&&x<=x0&&x+w>=x0+w0;\0A      if(!(inside&&d>=d0)&&!under){g.style.display=\22none\22;continue}\0A      g.style.display=\22\22;\0A      var px=under?0:(x-x0)/w0*W,pw=under?W:w/w0*W;\0A      r.setAttribute(\22x\22,px);r.setAttribute(\22width\22,Math.max(pw-1,0.5));t.setAttribute(\22x\22,px+3);\0A      var full=g.querySelector(\22title\22).textContent.replace(/ - [0-9.]+ ms, .*$/,\22\22),n=Math.floor((pw-6)/7);\0A      t.textContent=n<3?\22\22:(full.length<=n?full:full.slice(0,n-2)+\22..\22);\0A    }\0A  }\0A  for(var i=0;i<gs.length;i++){gs[i].addEventListener(\22click\22,function(){\0A    var d=this.dataset.d*1;show(this.dataset.x*1,Math.max(this.dataset.w*1,1),d==0?0:d)})}\0A  show(0,Math.max(svg.dataset.total*1,1),0);\0A})();\0A</script>" }>, align 8
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare void @__olang_check_failed(ptr) cold noreturn
@.d29 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"OLPROF01" }>, align 8
@.d30 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"_2e" }>, align 8
@.d31 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"./" }>, align 8
@.d32 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"../" }>, align 8
@.d33 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"./" }>, align 8
@.d34 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
declare void @__olang_ert_req_clear()
@.d35 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d36 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d37 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d38 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" thread" }>, align 8
@.d39 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" threads" }>, align 8
@.d40 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"\0Aolang profile: " }>, align 8
@.d41 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" - " }>, align 8
@.d42 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" samples, " }>, align 8
@.d43 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c" s of CPU time on " }>, align 8
@.d44 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d45 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"  (" }>, align 8
@.d46 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c" samples dropped: the buffer was full)\0A" }>, align 8
@.d47 = private constant <{ i64, [61 x i8] }> <{ i64 0, [61 x i8] c"  no samples: the program used less CPU time than one period\0A" }>, align 8
define internal i1 @olang_lambda_48(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca %"compiler/profile:Tally"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l24 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i32
  %l29 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i32
  %l43 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca i1
  %rv = alloca i1
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  %cp0 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load %"compiler/profile:Tally", ptr %cp0, !tbaa !28
  store %"compiler/profile:Tally" %cv0, ptr %l2
  %cp1 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %env, i32 0, i32 1
  %cv1 = load ptr, ptr %cp1, !tbaa !28
  store ptr %cv1, ptr %l7
  %vq0 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %env, i32 0, i32 2
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  %vq1 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %env, i32 0, i32 3
  %vr1 = load ptr, ptr %vq1, !tbaa !28
  %vc1 = call ptr @__olang_capture_scope(ptr %vr1)
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/profile:Tally", ptr %l2, i32 0, i32 0
  %t2 = load i64, ptr %l0, !tbaa !24
  %t5 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %vc0, ptr %t1, i64 %t2)
  %t6 = extractvalue { i32, i64 } %t5, 1
  %t7 = extractvalue { i32, i64 } %t5, 0
  store i32 %t7, ptr %l12
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store i64 %t6, ptr %l11
  br label %bb1
bb1:
  %t10 = load i64, ptr %l11, !tbaa !24
  store i64 %t10, ptr %l8, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l8, !tbaa !24
  br label %bb4
bb4:
  %t11 = load i64, ptr %l8, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  %t12 = getelementptr %"compiler/profile:Tally", ptr %l2, i32 0, i32 0
  %t13 = load i64, ptr %l1, !tbaa !24
  %t16 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %vc0, ptr %t12, i64 %t13)
  %t17 = extractvalue { i32, i64 } %t16, 1
  %t18 = extractvalue { i32, i64 } %t16, 0
  store i32 %t18, ptr %l17
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb6, label %ok.20, !prof !99
ok.20:
  store i64 %t17, ptr %l16
  br label %bb5
bb5:
  %t21 = load i64, ptr %l16, !tbaa !24
  store i64 %t21, ptr %l13, !tbaa !24
  br label %bb8
bb6:
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l13, !tbaa !24
  br label %bb8
bb8:
  %t22 = load i64, ptr %l13, !tbaa !24
  store i64 %t22, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l3, !tbaa !24
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = icmp ne i64 %t23, %t24
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t29 = load i64, ptr %l3, !tbaa !24
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = icmp sgt i64 %t29, %t30
  store i1 %t33, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t35 = getelementptr %"compiler/profile:Tally", ptr %l2, i32 0, i32 1
  %t36 = load i64, ptr %l0, !tbaa !24
  %t39 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %vc0, ptr %t35, i64 %t36)
  %t40 = extractvalue { i32, i64 } %t39, 1
  %t41 = extractvalue { i32, i64 } %t39, 0
  store i32 %t41, ptr %l28
  %t42 = icmp ne i32 %t41, 0
  br i1 %t42, label %bb13, label %ok.43, !prof !99
ok.43:
  store i64 %t40, ptr %l27
  br label %bb12
bb12:
  %t44 = load i64, ptr %l27, !tbaa !24
  store i64 %t44, ptr %l24, !tbaa !24
  br label %bb15
bb13:
  br label %bb14
bb14:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l24, !tbaa !24
  br label %bb15
bb15:
  %t45 = load i64, ptr %l24, !tbaa !24
  store i64 %t45, ptr %l5, !tbaa !24
  %t46 = getelementptr %"compiler/profile:Tally", ptr %l2, i32 0, i32 1
  %t47 = load i64, ptr %l1, !tbaa !24
  %t50 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %vc0, ptr %t46, i64 %t47)
  %t51 = extractvalue { i32, i64 } %t50, 1
  %t52 = extractvalue { i32, i64 } %t50, 0
  store i32 %t52, ptr %l33
  %t53 = icmp ne i32 %t52, 0
  br i1 %t53, label %bb17, label %ok.54, !prof !99
ok.54:
  store i64 %t51, ptr %l32
  br label %bb16
bb16:
  %t55 = load i64, ptr %l32, !tbaa !24
  store i64 %t55, ptr %l29, !tbaa !24
  br label %bb19
bb17:
  br label %bb18
bb18:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l29, !tbaa !24
  br label %bb19
bb19:
  %t56 = load i64, ptr %l29, !tbaa !24
  store i64 %t56, ptr %l6, !tbaa !24
  %t57 = load i64, ptr %l5, !tbaa !24
  %t58 = load i64, ptr %l6, !tbaa !24
  %t61 = icmp ne i64 %t57, %t58
  br i1 %t61, label %bb20, label %bb21
bb20:
  %t63 = load i64, ptr %l5, !tbaa !24
  %t64 = load i64, ptr %l6, !tbaa !24
  %t67 = icmp sgt i64 %t63, %t64
  store i1 %t67, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t69 = load ptr, ptr %l7, !tbaa !29
  %t71 = getelementptr %"compiler/profile:Places", ptr %t69, i32 0, i32 0
  %t72 = load i64, ptr %l0, !tbaa !24
  %t75 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %vc1, ptr %vc1, ptr %t71, i64 %t72)
  store { i64, ptr } %t75, ptr %l43
  br label %bb23
bb23:
  %t76 = load ptr, ptr %l7, !tbaa !29
  %t78 = getelementptr %"compiler/profile:Places", ptr %t76, i32 0, i32 0
  %t79 = load i64, ptr %l1, !tbaa !24
  %t82 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %vc1, ptr %vc1, ptr %t78, i64 %t79)
  store { i64, ptr } %t82, ptr %l47
  br label %bb24
bb24:
  %t83 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t84 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t85 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %vc1, ptr %vc1, { i64, ptr } %t83, { i64, ptr } %t84)
  store i1 %t85, ptr %l48
  br label %bb25
bb25:
  %t86 = load i1, ptr %l48, !tbaa !21
  store i1 %t86, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d49 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"\0A   self   total  function\0A" }>, align 8
@.d50 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d51 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d52 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d53 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
define internal i1 @olang_lambda_54(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca %"compiler/profile:Tally"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l25 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i1
  %rv = alloca i1
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  %cp0 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load %"compiler/profile:Tally", ptr %cp0, !tbaa !28
  store %"compiler/profile:Tally" %cv0, ptr %l2
  %cp1 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %env, i32 0, i32 1
  %cv1 = load ptr, ptr %cp1, !tbaa !28
  store ptr %cv1, ptr %l5
  %vq0 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %env, i32 0, i32 2
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  %vq1 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %env, i32 0, i32 3
  %vr1 = load ptr, ptr %vq1, !tbaa !28
  %vc1 = call ptr @__olang_capture_scope(ptr %vr1)
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/profile:Tally", ptr %l2, i32 0, i32 2
  %t2 = load i64, ptr %l0, !tbaa !24
  %t5 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %vc0, ptr %t1, i64 %t2)
  %t6 = extractvalue { i32, i64 } %t5, 1
  %t7 = extractvalue { i32, i64 } %t5, 0
  store i32 %t7, ptr %l10
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store i64 %t6, ptr %l9
  br label %bb1
bb1:
  %t10 = load i64, ptr %l9, !tbaa !24
  store i64 %t10, ptr %l6, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l6, !tbaa !24
  br label %bb4
bb4:
  %t11 = load i64, ptr %l6, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  %t12 = getelementptr %"compiler/profile:Tally", ptr %l2, i32 0, i32 2
  %t13 = load i64, ptr %l1, !tbaa !24
  %t16 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %vc0, ptr %t12, i64 %t13)
  %t17 = extractvalue { i32, i64 } %t16, 1
  %t18 = extractvalue { i32, i64 } %t16, 0
  store i32 %t18, ptr %l15
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb6, label %ok.20, !prof !99
ok.20:
  store i64 %t17, ptr %l14
  br label %bb5
bb5:
  %t21 = load i64, ptr %l14, !tbaa !24
  store i64 %t21, ptr %l11, !tbaa !24
  br label %bb8
bb6:
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l11, !tbaa !24
  br label %bb8
bb8:
  %t22 = load i64, ptr %l11, !tbaa !24
  store i64 %t22, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l3, !tbaa !24
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = icmp ne i64 %t23, %t24
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t29 = load i64, ptr %l3, !tbaa !24
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = icmp sgt i64 %t29, %t30
  store i1 %t33, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t35 = load ptr, ptr %l5, !tbaa !29
  %t37 = getelementptr %"compiler/profile:Places", ptr %t35, i32 0, i32 0
  %t38 = load i64, ptr %l0, !tbaa !24
  %t41 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %vc1, ptr %vc1, ptr %t37, i64 %t38)
  store { i64, ptr } %t41, ptr %l25
  br label %bb12
bb12:
  %t42 = load ptr, ptr %l5, !tbaa !29
  %t44 = getelementptr %"compiler/profile:Places", ptr %t42, i32 0, i32 0
  %t45 = load i64, ptr %l1, !tbaa !24
  %t48 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %vc1, ptr %vc1, ptr %t44, i64 %t45)
  store { i64, ptr } %t48, ptr %l29
  br label %bb13
bb13:
  %t49 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t51 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %vc1, ptr %vc1, { i64, ptr } %t49, { i64, ptr } %t50)
  store i1 %t51, ptr %l30
  br label %bb14
bb14:
  %t52 = load i1, ptr %l30, !tbaa !21
  store i1 %t52, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d55 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c":0" }>, align 8
@.d56 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"line" }>, align 8
@.d57 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"\0A   self  " }>, align 8
@.d58 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"  function\0A" }>, align 8
@.d59 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d60 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d61 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d62 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c"\0A  called from (the five hottest functions)\0A" }>, align 8
define internal i1 @olang_lambda_63(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca %"compiler/profile:Tally"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i32
  %l32 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca i1
  %rv = alloca i1
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  %cp0 = getelementptr { %"compiler/profile:Tally", i64, ptr, ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load %"compiler/profile:Tally", ptr %cp0, !tbaa !28
  store %"compiler/profile:Tally" %cv0, ptr %l2
  %cp1 = getelementptr { %"compiler/profile:Tally", i64, ptr, ptr, ptr }, ptr %env, i32 0, i32 1
  %cv1 = load i64, ptr %cp1, !tbaa !28
  store i64 %cv1, ptr %l3
  %cp2 = getelementptr { %"compiler/profile:Tally", i64, ptr, ptr, ptr }, ptr %env, i32 0, i32 2
  %cv2 = load ptr, ptr %cp2, !tbaa !28
  store ptr %cv2, ptr %l6
  %vq0 = getelementptr { %"compiler/profile:Tally", i64, ptr, ptr, ptr }, ptr %env, i32 0, i32 3
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  %vq1 = getelementptr { %"compiler/profile:Tally", i64, ptr, ptr, ptr }, ptr %env, i32 0, i32 4
  %vr1 = load ptr, ptr %vq1, !tbaa !28
  %vc1 = call ptr @__olang_capture_scope(ptr %vr1)
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/profile:Tally", ptr %l2, i32 0, i32 4
  %t2 = load i64, ptr %l3, !tbaa !24
  %t4 = mul i64 %t2, 16777216
  %t5 = load i64, ptr %l0, !tbaa !24
  %t8 = add i64 %t4, %t5
  %t11 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %vc0, ptr %t1, i64 %t8)
  %t12 = extractvalue { i32, i64 } %t11, 1
  %t13 = extractvalue { i32, i64 } %t11, 0
  store i32 %t13, ptr %l14
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb2, label %ok.15, !prof !99
ok.15:
  store i64 %t12, ptr %l13
  br label %bb1
bb1:
  %t16 = load i64, ptr %l13, !tbaa !24
  store i64 %t16, ptr %l7, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  %t17 = load i64, ptr %l7, !tbaa !24
  store i64 %t17, ptr %l4, !tbaa !24
  %t18 = getelementptr %"compiler/profile:Tally", ptr %l2, i32 0, i32 4
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = mul i64 %t19, 16777216
  %t22 = load i64, ptr %l1, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t28 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %vc0, ptr %t18, i64 %t25)
  %t29 = extractvalue { i32, i64 } %t28, 1
  %t30 = extractvalue { i32, i64 } %t28, 0
  store i32 %t30, ptr %l22
  %t31 = icmp ne i32 %t30, 0
  br i1 %t31, label %bb6, label %ok.32, !prof !99
ok.32:
  store i64 %t29, ptr %l21
  br label %bb5
bb5:
  %t33 = load i64, ptr %l21, !tbaa !24
  store i64 %t33, ptr %l15, !tbaa !24
  br label %bb8
bb6:
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l15, !tbaa !24
  br label %bb8
bb8:
  %t34 = load i64, ptr %l15, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  %t35 = load i64, ptr %l4, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp ne i64 %t35, %t36
  br i1 %t39, label %bb9, label %bb10
bb9:
  %t41 = load i64, ptr %l4, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = icmp sgt i64 %t41, %t42
  store i1 %t45, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t47 = load ptr, ptr %l6, !tbaa !29
  %t49 = getelementptr %"compiler/profile:Places", ptr %t47, i32 0, i32 0
  %t50 = load i64, ptr %l0, !tbaa !24
  %t53 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %vc1, ptr %vc1, ptr %t49, i64 %t50)
  store { i64, ptr } %t53, ptr %l32
  br label %bb12
bb12:
  %t54 = load ptr, ptr %l6, !tbaa !29
  %t56 = getelementptr %"compiler/profile:Places", ptr %t54, i32 0, i32 0
  %t57 = load i64, ptr %l1, !tbaa !24
  %t60 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %vc1, ptr %vc1, ptr %t56, i64 %t57)
  store { i64, ptr } %t60, ptr %l36
  br label %bb13
bb13:
  %t61 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t63 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %vc1, ptr %vc1, { i64, ptr } %t61, { i64, ptr } %t62)
  store i1 %t63, ptr %l37
  br label %bb14
bb14:
  %t64 = load i1, ptr %l37, !tbaa !21
  store i1 %t64, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d64 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d65 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"(the thread's first frame)" }>, align 8
@.d66 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d67 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d68 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"  <-  " }>, align 8
@.d69 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_H672d76f1ccd7b9b901b64baf95956196(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d70 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d71 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d72 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d73 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\22" }>, align 8
@.d74 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"\22 0x" }>, align 8
@.d75 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d76 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"--inlining" }>, align 8
@.d77 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"--functions=short" }>, align 8
@.d78 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d79 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d80 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_H85afd28815ee4de4ef19d4ccaecd867e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2fvec_3a_Hdb387e679134e71bf5648ac6d1ce10ff(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d81 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d82 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"??" }>, align 8
@.d83 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d84 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d85 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"??" }>, align 8
@.d86 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"??" }>, align 8
@.d87 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"0x" }>, align 8
@.d88 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" (" }>, align 8
@.d89 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d90 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d91 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d92 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"??" }>, align 8
@.d93 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d94 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"no file" }>, align 8
@.d95 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"0x" }>, align 8
@.d96 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" (" }>, align 8
@.d97 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d98 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"??" }>, align 8
@.d99 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d100 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d101 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d102 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"/llvm-symbolizer" }>, align 8
@.d103 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d104 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"llvm-symbolizer-20" }>, align 8
@.d105 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"llvm-symbolizer-19" }>, align 8
@.d106 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"llvm-symbolizer-18" }>, align 8
@.d107 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"llvm-symbolizer" }>, align 8
@.d108 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d109 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d110 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d111 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"&lt;" }>, align 8
@.d112 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"&gt;" }>, align 8
@.d113 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"&amp;" }>, align 8
@.d114 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"&quot;" }>, align 8
@.d115 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d116 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
define internal i1 @olang_lambda_117(ptr %env, ptr %v0, ptr %v1, %"compiler/profile:elfFn" %a0, %"compiler/profile:elfFn" %a1) #0 {
entry:
  %l0 = alloca %"compiler/profile:elfFn"
  %l1 = alloca %"compiler/profile:elfFn"
  %rv = alloca i1
  store %"compiler/profile:elfFn" %a0, ptr %l0
  store %"compiler/profile:elfFn" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/profile:elfFn", ptr %l0, i32 0, i32 0
  %t2 = load i64, ptr %t1, !tbaa !24
  %t3 = getelementptr %"compiler/profile:elfFn", ptr %l1, i32 0, i32 0
  %t4 = load i64, ptr %t3, !tbaa !24
  %t7 = icmp slt i64 %t2, %t4
  store i1 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d118 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d119 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d120 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
@.d121 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"%" }>, align 8
@.d122 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"std/prelude" }>, align 8
@.d123 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d124 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d125 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d126 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d127 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"OLANG_PROFILE\00" }>, align 8
@.d128 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
declare i32 @setenv(ptr, ptr, i32)
declare i32 @fork()
declare void @_exit(i32)
@.d129 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"OLANG_PROFILE\00" }>, align 8
declare i32 @unsetenv(ptr)
declare i64 @signal(i32, i64)
declare i32 @waitpid(i32, ptr, i32)
@.d130 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"/proc/" }>, align 8
@.d131 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"OLPROF01" }>, align 8
@.d132 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d133 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d134 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d135 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d136 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"hot" }>, align 8
@.d137 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"hot.olang" }>, align 8
@.d138 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"main" }>, align 8
@.d139 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"hot.olang" }>, align 8
@.d140 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"Vec<I64>.Push" }>, align 8
@.d141 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"hot.olang" }>, align 8
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d142 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2ePush_3ccompiler_2fprofile_3anode_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/profile:node" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2eLen_3ccompiler_2fprofile_3aSample_3e(ptr %v0, ptr %a0)
declare %"compiler/profile:Sample" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2eAt_3ccompiler_2fprofile_3aSample_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/profile:node" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eAt_3ccompiler_2fprofile_3anode_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eSetAt_3ccompiler_2fprofile_3anode_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/profile:node" %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/profile:Frame" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2eAt_3ccompiler_2fprofile_3aFrame_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eLen_3ccompiler_2fprofile_3anode_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClone_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1c, ptr %a1e)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eHash(ptr %v0, { i64, ptr } %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ffloat_2eF64_2eFixed(ptr %v0, double %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_c23c40ac9fceed99_19c8ab4fbd7fcba5 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2ePush_3ccompiler_2fprofile_3aSample_3e(ptr %v0, ptr %a0, %"compiler/profile:Sample" %a1)
@olang_loc_ebd4d37101874eec_6116e20ed9489b48 = external constant [0 x i8]
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2ftypes_2eDemangle(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_3603727fe313055_49dd245dfeecf61 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_e16765c4a8f41078_55e216e6a7163174 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_a05021294fe2b6d3_c60223eeaa2ef05f = external constant [0 x i8]
@olang_loc_efed15e4a0150676_49528d4cd386b8e2 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadEnd(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3amapping_3e_2eLen__Heb6545c4cbf57678e5e8a74f397c9583(ptr %v0, ptr %a0)
declare %"compiler/profile:mapping" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3amapping_3e_2eAt_3ccompiler_2fprofile_3amapping_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H67bc384d82ac3ceb3fdc5d6d25b5f02a(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Hd2a6d6393d72da4a22d0070783b9e545(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a2)
declare { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H319c0ff6422dd1c7d243d7553286ad0b(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %v0, i64 %a0, i64 %a1)
@olang_loc_d50f4fab691edd32_66973f8664df657e = external constant [0 x i8]
declare { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
declare %"std/os:Output" @std_2fos_3aOutput_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2eLen_3ccompiler_2fprofile_3aFrame_3e(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H509117e81ae737fb138b1f364b80e611(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Hb4e1316c13adc554c531dbb9cf254a96(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a2)
declare { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Hf7a94710bd717f9f9bfa139cb342fdae(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aelfFn_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_a4addf443e3a86b3_5ebaaf6328319b7f = external constant [0 x i8]
declare { i64, ptr } @std_2ffilepath_2eBase(ptr %v0, { i64, ptr } %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2ePush_3ccompiler_2fprofile_3aFrame_3e(ptr %v0, ptr %a0, %"compiler/profile:Frame" %a1)
@olang_loc_41e6651314f25f98_646ba62944647444 = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftarget_2eFindClang(ptr %v0)
declare { i64, ptr } @compiler_2ftarget_2eWhereIs(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2ffilepath_2eDir(ptr %v0, { i64, ptr } %a0)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9162e3b7f03fcbf954b681204d5f6cca(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha091d021a90ce6aa48813730c00df6d2(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_7d2ae97c2364b59d_ce98559d67a1b5c9 = external constant [0 x i8]
@olang_loc_ec3589048a52ea40_4feb0c814716a05c = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_47d41d181de998ca_407a2b261e632036 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aelfFn_3e_2ePush_3ccompiler_2fprofile_3aelfFn_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/profile:elfFn" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aelfFn_3e_2eSort_3_H16cb1151e861568c30a5b57cf3c12bc1(ptr %v0, ptr %v1, ptr %a0, ptr %a1c, ptr %a1e)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3amapping_3e_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_49a351722641e944_c5b141a1c073228 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3amapping_3e_2ePush_Hc0dd0b8028ee4ec7edce99e352ae7bbd(ptr %v0, ptr %v1, ptr %a0, %"compiler/profile:mapping" %a1)
@olang_loc_8377dd777846f8d9_8488686b399fded = external constant [0 x i8]
declare { i64, ptr } @compiler_2fbuild_2eShown(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v1, ptr %a0)
declare i32 @std_2fos_2eExecInPlace(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_ec22c3592c386ac4_6a748f217c4c44c0 = external constant [0 x i8]
declare i1 @std_2fos_2eExists(ptr %v0, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cU8_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eToArray_3cU8_3e(ptr %v0, ptr %v1, ptr %a0)
declare i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %v0)
@olang_loc_9b07e838cb7ed4ee_978ead1b2c1f88ba = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aelfFn_3e_2eLen_3ccompiler_2fprofile_3aelfFn_3e(ptr %v0, ptr %a0)
declare %"compiler/profile:elfFn" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aelfFn_3e_2eAt_3ccompiler_2fprofile_3aelfFn_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_cc2e380c5cd0dda_c071bfd9a740ca6e = external constant [0 x i8]
@olang_loc_4bebebd3fadd2f37_94a97b9fa165786b = external constant [0 x i8]
@olang_loc_ea1fc1fa824e624c_c3d948fe5a073af0 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2ector(ptr %v0, i64 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2fvec_3a_Hdb387e679134e71bf5648ac6d1ce10ff(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
