; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_1c32c25abf9ef178_42417acd44bf71fc = weak_odr constant [46 x i8] c"std/prelude/input.olang:185: unhandled error\0A\00"
@olang_loc_3985a8c7e5af0b6c_4b8b5d3a34f4de30 = weak_odr constant [56 x i8] c"std/prelude/input.olang:113: array length out of range\0A\00"
@olang_loc_75bb22291815a95c_1b64f601cbc646a8 = weak_odr constant [50 x i8] c"std/prelude/input.olang:186: unreachable reached\0A\00"
@olang_loc_762cd1d3020b924b_608d4506c1a78147 = weak_odr constant [55 x i8] c"std/prelude/input.olang:24: array length out of range\0A\00"
@olang_loc_78089c6e05f54348_c44345d44a04efa4 = weak_odr constant [30 x i8] c"std/prelude/input.olang:185: \00"
@olang_loc_92977f40bcde603b_fc91076acd0d7977 = weak_odr constant [55 x i8] c"std/prelude/input.olang:50: slice bounds out of range\0A\00"
@olang_loc_9ba75df5616cc8b4_d0585f7fc85a1438 = weak_odr constant [56 x i8] c"std/prelude/input.olang:168: array length out of range\0A\00"
@olang_loc_9ebb7b2d76e16f9e_f5b8f0b55eb9c682 = weak_odr constant [55 x i8] c"std/prelude/input.olang:47: array length out of range\0A\00"
@olang_loc_c67b2ccd325ea30_72929b4d00680694 = weak_odr constant [55 x i8] c"std/prelude/input.olang:56: array length out of range\0A\00"
