; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/os:File" = type { i32 }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"std/os:Process" = type { i32, i32, i32, i1, i1, i64 }
%"std/os:FileInfo" = type { i32, i64, i64 }
%"<fcntl.h>:timespec" = type { i64, i64 }
%"<poll.h>:pollfd" = type { i32, i16, i16 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
define dso_local { i64, ptr } @std_2fos_2eArgs(ptr %v0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %lp8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l39 = alloca i64
  %l42 = alloca i64
  %l49 = alloca i64
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t13 = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call i64 @__olang_arg_count()
  store i64 %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load i64, ptr %l9, !tbaa !24
  store i64 %t2, ptr %l0, !tbaa !24
  %t3 = load i64, ptr %l0, !tbaa !24
  store i64 %t3, ptr %l10, !tbaa !24
  %t4 = load i64, ptr %l10, !tbaa !24
  %t5 = icmp sge i64 %t4, 0
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t7 = load i64, ptr %l10, !tbaa !24
  %t8 = icmp sle i64 %t7, 576460752303423487
  br i1 %t8, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_2e089b9dcc6d7cfd_6f26744b60ea9b91)
  unreachable
bb4:
  %t10 = load i64, ptr %l10, !tbaa !24
  %t11 = mul i64 %t10, 16
  %t12 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t11)
  store i64 0, ptr %t13
  br label %fill.14
fill.14:
  %t17 = load i64, ptr %t13
  %t18 = icmp slt i64 %t17, %t10
  br i1 %t18, label %fillb.15, label %filld.16
fillb.15:
  %t19 = getelementptr { i64, ptr }, ptr %t12, i64 %t17
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %t19
  %t20 = add i64 %t17, 1
  store i64 %t20, ptr %t13
  br label %fill.14
filld.16:
  %t21 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t12, 1
  store { i64, ptr } %t22, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t24 = load i64, ptr %l0, !tbaa !24
  store i64 %t24, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t26 = load i64, ptr %l3, !tbaa !24
  %t27 = load i64, ptr %l2, !tbaa !24
  %t30 = icmp sgt i64 %t26, %t27
  br i1 %t30, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_2e089b9dcc6d7cfd_6f26744b60ea9b91)
  unreachable
bb6:
  %t32 = load i64, ptr %l4, !tbaa !24
  %t34 = icmp sgt i64 %t32, 0
  br i1 %t34, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb11
bb8:
  %t36 = load i64, ptr %l3, !tbaa !24
  %t37 = load i64, ptr %l2, !tbaa !24
  %t40 = sub i64 %t36, %t37
  %t41 = load i64, ptr %l4, !tbaa !24
  %t44 = add i64 %t40, %t41
  %t46 = sub i64 %t44, 1
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = sdiv i64 %t46, %t47
  store i64 %t50, ptr %l21, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb10
bb10:
  %t52 = load i64, ptr %l21, !tbaa !24
  store i64 %t52, ptr %l18, !tbaa !24
  br label %bb11
bb11:
  %t53 = load i64, ptr %l18, !tbaa !24
  store i64 %t53, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t54 = load i64, ptr %l6, !tbaa !24
  %t55 = load i64, ptr %l5, !tbaa !24
  %t58 = icmp slt i64 %t54, %t55
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb14:
  br label %bb15
bb15:
  %t62 = load i64, ptr %l2, !tbaa !24
  %t63 = load i64, ptr %l6, !tbaa !24
  %t64 = load i64, ptr %l4, !tbaa !24
  %t67 = mul i64 %t63, %t64
  %t70 = add i64 %t62, %t67
  store i64 %t70, ptr %l7, !tbaa !24
  %t72 = load i64, ptr %l7, !tbaa !24
  store i64 %t72, ptr %l39, !tbaa !24
  %t73 = icmp sge i64 0, 0
  br i1 %t73, label %bb16, label %bb17
bb16:
  %t75 = mul i64 0, 1
  %t76 = insertvalue { i64, ptr } undef, i64 0, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t78 = load i64, ptr %l39, !tbaa !24
  %t80 = extractvalue { i64, ptr } %t77, 1
  %t81 = extractvalue { i64, ptr } %t77, 0
  %t82 = call i64 @__olang_arg(i64 %t78, ptr %t80, i64 0)
  store i64 %t82, ptr %l42
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_722c60a9fee6cfd0_5c8c3a8aa9ab1a84)
  unreachable
bb18:
  %t83 = load i64, ptr %l42, !tbaa !24
  %t84 = icmp sge i64 %t83, 0
  br i1 %t84, label %bb19, label %bb20
bb19:
  %t86 = load i64, ptr %l42, !tbaa !24
  %t87 = mul i64 %t86, 1
  %t88 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t87)
  %t89 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  %t91 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t91, ptr %lp8
  %t93 = load ptr, ptr %lp8
  store { i64, ptr } %t90, ptr %t93, !tbaa !27
  %t94 = load i64, ptr %l7, !tbaa !24
  %t95 = load ptr, ptr %lp8
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !27
  %t97 = load ptr, ptr %lp8
  %t98 = load { i64, ptr }, ptr %t97, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t98, 0
  %t103 = extractvalue { i64, ptr } %t96, 1
  %t104 = extractvalue { i64, ptr } %t96, 0
  %t106 = call i64 @__olang_arg(i64 %t94, ptr %t103, i64 %t100)
  store i64 %t106, ptr %l49
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_722c60a9fee6cfd0_5c8c3a8aa9ab1a84)
  unreachable
bb21:
  %t107 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t107, ptr %l50, !tbaa !27
  %t108 = load i64, ptr %l7, !tbaa !24
  store i64 %t108, ptr %l51, !tbaa !24
  %t109 = call ptr @__olang_scope_hold(ptr %v0)
  %t110 = ptrtoint ptr %t109 to i64
  store i64 %t110, ptr %l52, !tbaa !24
  %t111 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t111, label %bb22, label %bb23
bb22:
  %t113 = call ptr @__olang_region_make(ptr %v0)
  %t114 = ptrtoint ptr %t113 to i64
  store i64 %t114, ptr %l52, !tbaa !24
  br label %bb23
bb23:
  %t115 = load ptr, ptr %lp8
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  %t119 = load i64, ptr %l52
  %t120 = inttoptr i64 %t119 to ptr
  %t121 = extractvalue { i64, ptr } %t116, 0
  %t122 = extractvalue { i64, ptr } %t116, 1
  %t123 = mul i64 %t121, 1
  %t124 = call ptr @__olang_held_alloc(ptr %t120, i64 %t123)
  call void @llvm.memcpy.p0.p0.i64(ptr %t124, ptr %t122, i64 %t123, i1 false)
  %t125 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t124, 1
  %t128 = load i64, ptr %l51, !tbaa !24
  %t129 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr { i64, ptr }, ptr %t130, i64 %t128
  store { i64, ptr } %t126, ptr %t131, !tbaa !37
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb24:
  %t132 = load i64, ptr %l6, !tbaa !24
  %t135 = add i64 %t132, 1
  store i64 %t135, ptr %l6, !tbaa !24
  br label %bb12
bb25:
  %t137 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t137, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l10 = alloca i1
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, [2 x i64] }
  %l18 = alloca i64
  %l20 = alloca { i64, [2 x i64] }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t16 = alloca { { i64, ptr }, ptr }, align 8
  %t56 = alloca { i64, [2 x i64] }, align 8
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 1
  %t4 = extractvalue { i64, ptr } %t1, 0
  %t5 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t14 = getelementptr { { i64, ptr }, ptr }, ptr null, i32 1
  %t15 = ptrtoint ptr %t14 to i64
  %t17 = getelementptr { { i64, ptr }, ptr }, ptr %t16, i32 0, i32 0
  store { i64, ptr } %t11, ptr %t17, !tbaa !28
  call void @__olang_scope_escape(ptr %s0)
  %t19 = call ptr @__olang_scope_hold(ptr %s0)
  %t20 = getelementptr { { i64, ptr }, ptr }, ptr %t16, i32 0, i32 1
  store ptr %t19, ptr %t20, !tbaa !28
  %t21 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_2, 0
  %t22 = insertvalue { ptr, ptr } %t21, ptr %t16, 1
  %t24 = extractvalue { ptr, ptr } %t22, 0
  %t25 = extractvalue { ptr, ptr } %t22, 1
  %t26 = call { i32, { i64, ptr } } @std_2fos_2ecopyOut(ptr %s0, ptr %s0, ptr %v1, ptr %t24, ptr %t25, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d3, i32 0, i32 1) })
  %t27 = extractvalue { i32, { i64, ptr } } %t26, 1
  %t28 = extractvalue { i32, { i64, ptr } } %t26, 0
  store i32 %t28, ptr %l8
  %t29 = icmp ne i32 %t28, 0
  br i1 %t29, label %bb2, label %ok.30, !prof !99
ok.30:
  store { i64, ptr } %t27, ptr %l7
  br label %bb1
bb1:
  %t31 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t31, ptr %l4, !tbaa !27
  br label %bb7
bb2:
  %t32 = load i32, ptr %l8, !tbaa !23
  %t33 = ashr i32 %t32, 16
  %t35 = icmp eq i32 %t33, 1
  store i1 %t35, ptr %l10, !tbaa !21
  %t36 = load i32, ptr %l8, !tbaa !23
  %t37 = ashr i32 %t36, 16
  %t39 = icmp eq i32 %t37, 1
  br i1 %t39, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t41, ptr %l14, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t43, 0
  store i64 %t44, ptr %l15, !tbaa !24
  %t45 = load i64, ptr %l15, !tbaa !24
  %t46 = mul i64 %t45, 1
  %t47 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t46)
  %t48 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  store { i64, ptr } %t49, ptr %l16, !tbaa !27
  %t50 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = load i64, ptr %l15, !tbaa !24
  %t55 = mul i64 %t54, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t51, ptr %t53, i64 %t55, i1 false)
  store { i64, [2 x i64] } zeroinitializer, ptr %t56
  %t57 = getelementptr { i64, [2 x i64] }, ptr %t56, i32 0, i32 0
  store i64 0, ptr %t57
  %t58 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t59 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t58, 0
  %t60 = getelementptr { i64, [2 x i64] }, ptr %t56, i32 0, i32 1
  store { { i64, ptr } } %t59, ptr %t60
  %t61 = load { i64, [2 x i64] }, ptr %t56
  store { i64, [2 x i64] } %t61, ptr %l17
  %t62 = call ptr @__olang_errpay_push()
  %t63 = ptrtoint ptr %t62 to i64
  store i64 %t63, ptr %l18, !tbaa !24
  %t64 = load i64, ptr %l18
  %t65 = inttoptr i64 %t64 to ptr
  %t67 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fos_3aError_24payload(ptr %t65, ptr %l17)
  store { i64, [2 x i64] } %t67, ptr %l20
  br label %bb6
bb6:
  %t68 = load { i64, [2 x i64] }, ptr %l20
  %t69 = load i64, ptr %l18
  %t70 = inttoptr i64 %t69 to ptr
  %t71 = call ptr @__olang_scope_alloc_a(ptr %t70, i64 24, i64 8)
  store { i64, [2 x i64] } %t68, ptr %t71
  call void @__olang_errpay_set(ptr %t71)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t74 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t74, ptr %rv
  br label %ret
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t75 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t76 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t75, 1
  store { i32, { i64, ptr } } %t76, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i32 @std_2fos_2eExecInPlace(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, [2 x i64] }
  %l27 = alloca i64
  %l29 = alloca { i64, [2 x i64] }
  %l39 = alloca { i64, ptr }
  %l42 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i32
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca { i64, ptr }
  %l51 = alloca { i64, [2 x i64] }
  %l52 = alloca i64
  %l54 = alloca { i64, [2 x i64] }
  %l65 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i32
  %l71 = alloca { i64, ptr }
  %l72 = alloca i64
  %l73 = alloca { i64, ptr }
  %l74 = alloca { i64, [2 x i64] }
  %l75 = alloca i64
  %l77 = alloca { i64, [2 x i64] }
  %l80 = alloca i64
  %l86 = alloca i64
  %l89 = alloca i1
  %l94 = alloca { i64, ptr }
  %l100 = alloca i64
  %l103 = alloca i1
  %l108 = alloca { i64, ptr }
  %l132 = alloca i32
  %l133 = alloca i32
  %l135 = alloca i32
  %l138 = alloca { i64, ptr }
  %l139 = alloca i64
  %l140 = alloca { i64, ptr }
  %l141 = alloca { i64, [2 x i64] }
  %l142 = alloca i64
  %l144 = alloca { i64, [2 x i64] }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca i32
  %t22 = alloca { i64, [2 x i64] }, align 8
  %t87 = alloca { i64, [2 x i64] }, align 8
  %t145 = alloca { i64, [2 x i64] }, align 8
  %t319 = alloca { i64, [2 x i64] }, align 8
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t7, ptr %l23, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l24, !tbaa !24
  %t11 = load i64, ptr %l24, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l25, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = load i64, ptr %l24, !tbaa !24
  %t21 = mul i64 %t20, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %t19, i64 %t21, i1 false)
  store { i64, [2 x i64] } zeroinitializer, ptr %t22
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t22, i32 0, i32 0
  store i64 6, ptr %t23
  %t24 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t25 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t24, 0
  %t26 = getelementptr { i64, [2 x i64] }, ptr %t22, i32 0, i32 1
  store { { i64, ptr } } %t25, ptr %t26
  %t27 = load { i64, [2 x i64] }, ptr %t22
  store { i64, [2 x i64] } %t27, ptr %l26
  %t28 = call ptr @__olang_errpay_push()
  %t29 = ptrtoint ptr %t28 to i64
  store i64 %t29, ptr %l27, !tbaa !24
  %t30 = load i64, ptr %l27
  %t31 = inttoptr i64 %t30 to ptr
  %t33 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fos_3aError_24payload(ptr %t31, ptr %l26)
  store { i64, [2 x i64] } %t33, ptr %l29
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t34 = load { i64, [2 x i64] }, ptr %l29
  %t35 = load i64, ptr %l27
  %t36 = inttoptr i64 %t35 to ptr
  %t37 = call ptr @__olang_scope_alloc_a(ptr %t36, i64 24, i64 8)
  store { i64, [2 x i64] } %t34, ptr %t37
  call void @__olang_errpay_set(ptr %t37)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i32 65542, ptr %rv
  br label %ret
bb4:
  store i64 0, ptr %l2, !tbaa !24
  %t40 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t40, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  store i64 %t44, ptr %l5, !tbaa !24
  br label %bb5
bb5:
  %t46 = load i64, ptr %l4, !tbaa !24
  %t47 = load i64, ptr %l5, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb6, label %bb7
bb6:
  br label %bb18
bb7:
  br label %bb8
bb8:
  %t54 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t54, ptr %l39, !tbaa !27
  %t55 = load i64, ptr %l4, !tbaa !24
  %t57 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr { i64, ptr }, ptr %t58, i64 %t55
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !37
  store { i64, ptr } %t60, ptr %l6, !tbaa !27
  store i1 true, ptr %l7, !tbaa !21
  %t62 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t64 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v1, { i64, ptr } %t62, i8 0)
  %t65 = extractvalue { i32, i64 } %t64, 1
  %t66 = extractvalue { i32, i64 } %t64, 0
  store i32 %t66, ptr %l45
  %t67 = icmp ne i32 %t66, 0
  br i1 %t67, label %bb10, label %ok.68, !prof !99
ok.68:
  store i64 %t65, ptr %l44
  br label %bb9
bb9:
  %t69 = load i64, ptr %l44, !tbaa !24
  store i64 %t69, ptr %l42, !tbaa !24
  br label %bb12
bb10:
  br label %bb11
bb11:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb12
bb12:
  %t70 = load i1, ptr %l7, !tbaa !21
  br i1 %t70, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s5
  %t72 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t72, ptr %l48, !tbaa !27
  %t74 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t74, 0
  store i64 %t75, ptr %l49, !tbaa !24
  %t76 = load i64, ptr %l49, !tbaa !24
  %t77 = mul i64 %t76, 1
  %t78 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t77)
  %t79 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t78, 1
  store { i64, ptr } %t80, ptr %l50, !tbaa !27
  %t81 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = load i64, ptr %l49, !tbaa !24
  %t86 = mul i64 %t85, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t82, ptr %t84, i64 %t86, i1 false)
  store { i64, [2 x i64] } zeroinitializer, ptr %t87
  %t88 = getelementptr { i64, [2 x i64] }, ptr %t87, i32 0, i32 0
  store i64 6, ptr %t88
  %t89 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t90 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t89, 0
  %t91 = getelementptr { i64, [2 x i64] }, ptr %t87, i32 0, i32 1
  store { { i64, ptr } } %t90, ptr %t91
  %t92 = load { i64, [2 x i64] }, ptr %t87
  store { i64, [2 x i64] } %t92, ptr %l51
  %t93 = call ptr @__olang_errpay_push()
  %t94 = ptrtoint ptr %t93 to i64
  store i64 %t94, ptr %l52, !tbaa !24
  %t95 = load i64, ptr %l52
  %t96 = inttoptr i64 %t95 to ptr
  %t98 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fos_3aError_24payload(ptr %t96, ptr %l51)
  store { i64, [2 x i64] } %t98, ptr %l54
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t99 = load { i64, [2 x i64] }, ptr %l54
  %t100 = load i64, ptr %l52
  %t101 = inttoptr i64 %t100 to ptr
  %t102 = call ptr @__olang_scope_alloc_a(ptr %t101, i64 24, i64 8)
  store { i64, [2 x i64] } %t99, ptr %t102
  call void @__olang_errpay_set(ptr %t102)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store i32 65542, ptr %rv
  br label %ret
bb16:
  %t105 = load i64, ptr %l2, !tbaa !24
  %t106 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t106, 0
  %t110 = add i64 %t108, 1
  %t113 = add i64 %t105, %t110
  store i64 %t113, ptr %l2, !tbaa !24
  br label %bb17
bb17:
  %t115 = load i64, ptr %l4, !tbaa !24
  %t118 = add i64 %t115, 1
  store i64 %t118, ptr %l4, !tbaa !24
  br label %bb5
bb18:
  store i1 true, ptr %l8, !tbaa !21
  %t120 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t122 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %t120, i8 0)
  %t123 = extractvalue { i32, i64 } %t122, 1
  %t124 = extractvalue { i32, i64 } %t122, 0
  store i32 %t124, ptr %l68
  %t125 = icmp ne i32 %t124, 0
  br i1 %t125, label %bb20, label %ok.126, !prof !99
ok.126:
  store i64 %t123, ptr %l67
  br label %bb19
bb19:
  %t127 = load i64, ptr %l67, !tbaa !24
  store i64 %t127, ptr %l65, !tbaa !24
  br label %bb22
bb20:
  br label %bb21
bb21:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb22
bb22:
  %t128 = load i1, ptr %l8, !tbaa !21
  br i1 %t128, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s8
  %t130 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t130, ptr %l71, !tbaa !27
  %t132 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t132, 0
  store i64 %t133, ptr %l72, !tbaa !24
  %t134 = load i64, ptr %l72, !tbaa !24
  %t135 = mul i64 %t134, 1
  %t136 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t135)
  %t137 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t136, 1
  store { i64, ptr } %t138, ptr %l73, !tbaa !27
  %t139 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !27
  %t141 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = load i64, ptr %l72, !tbaa !24
  %t144 = mul i64 %t143, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t140, ptr %t142, i64 %t144, i1 false)
  store { i64, [2 x i64] } zeroinitializer, ptr %t145
  %t146 = getelementptr { i64, [2 x i64] }, ptr %t145, i32 0, i32 0
  store i64 6, ptr %t146
  %t147 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t148 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t147, 0
  %t149 = getelementptr { i64, [2 x i64] }, ptr %t145, i32 0, i32 1
  store { { i64, ptr } } %t148, ptr %t149
  %t150 = load { i64, [2 x i64] }, ptr %t145
  store { i64, [2 x i64] } %t150, ptr %l74
  %t151 = call ptr @__olang_errpay_push()
  %t152 = ptrtoint ptr %t151 to i64
  store i64 %t152, ptr %l75, !tbaa !24
  %t153 = load i64, ptr %l75
  %t154 = inttoptr i64 %t153 to ptr
  %t156 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fos_3aError_24payload(ptr %t154, ptr %l74)
  store { i64, [2 x i64] } %t156, ptr %l77
  br label %bb25
bb24:
  br label %bb26
bb25:
  %t157 = load { i64, [2 x i64] }, ptr %l77
  %t158 = load i64, ptr %l75
  %t159 = inttoptr i64 %t158 to ptr
  %t160 = call ptr @__olang_scope_alloc_a(ptr %t159, i64 24, i64 8)
  store { i64, [2 x i64] } %t157, ptr %t160
  call void @__olang_errpay_set(ptr %t160)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  store i32 65542, ptr %rv
  br label %ret
bb26:
  %t163 = load i64, ptr %l2, !tbaa !24
  store i64 %t163, ptr %l80, !tbaa !24
  %t164 = load i64, ptr %l80, !tbaa !24
  %t165 = icmp sge i64 %t164, 0
  br i1 %t165, label %bb27, label %bb28
bb27:
  %t167 = load i64, ptr %l80, !tbaa !24
  %t168 = mul i64 %t167, 1
  %t169 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t168)
  %t170 = insertvalue { i64, ptr } undef, i64 %t167, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t169, 1
  store { i64, ptr } %t171, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t173 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t173, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t175 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t175, 0
  store i64 %t177, ptr %l13, !tbaa !24
  %t179 = load i64, ptr %l13, !tbaa !24
  %t180 = sub i64 %t179, 1
  store i64 %t180, ptr %l86, !tbaa !24
  %t181 = load i64, ptr %l13, !tbaa !24
  %t182 = icmp slt i64 %t181, 2147483648
  %t183 = load i64, ptr %l12, !tbaa !24
  %t184 = icmp sge i64 %t183, 0
  %t187 = and i1 %t182, %t184
  store i1 %t187, ptr %l89, !tbaa !21
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_c6732c6b36ef1233_192580cd7896553f)
  unreachable
bb29:
  %t188 = load i64, ptr %l12, !tbaa !24
  %t189 = load i64, ptr %l13, !tbaa !24
  %t192 = icmp slt i64 %t188, %t189
  %t194 = xor i1 %t192, true
  br i1 %t194, label %bb30, label %bb31
bb30:
  br label %bb40
bb31:
  br label %bb32
bb32:
  %t196 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t196, ptr %l94, !tbaa !27
  %t197 = load i64, ptr %l12, !tbaa !24
  %t199 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !27
  %t201 = getelementptr { i64, ptr }, ptr %t200, i64 %t197
  %t202 = load { i64, ptr }, ptr %t201, !tbaa !37
  store { i64, ptr } %t202, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t206 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t206, 0
  store i64 %t208, ptr %l17, !tbaa !24
  %t210 = load i64, ptr %l17, !tbaa !24
  %t211 = sub i64 %t210, 1
  store i64 %t211, ptr %l100, !tbaa !24
  %t212 = load i64, ptr %l17, !tbaa !24
  %t213 = icmp slt i64 %t212, 2147483648
  %t214 = load i64, ptr %l16, !tbaa !24
  %t215 = icmp sge i64 %t214, 0
  %t218 = and i1 %t213, %t215
  store i1 %t218, ptr %l103, !tbaa !21
  br label %bb33
bb33:
  %t219 = load i64, ptr %l16, !tbaa !24
  %t220 = load i64, ptr %l17, !tbaa !24
  %t223 = icmp slt i64 %t219, %t220
  %t225 = xor i1 %t223, true
  br i1 %t225, label %bb34, label %bb35
bb34:
  br label %bb38
bb35:
  br label %bb36
bb36:
  %t227 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t227, ptr %l108, !tbaa !27
  %t228 = load i64, ptr %l16, !tbaa !24
  %t230 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !27
  %t232 = getelementptr i8, ptr %t231, i64 %t228
  %t233 = load i8, ptr %t232, !tbaa !32
  %t235 = load i64, ptr %l10, !tbaa !24
  %t240 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !27
  %t242 = getelementptr i8, ptr %t241, i64 %t235
  store i8 %t233, ptr %t242, !tbaa !32
  %t243 = load i64, ptr %l10, !tbaa !24
  %t246 = add i64 %t243, 1
  store i64 %t246, ptr %l10, !tbaa !24
  br label %bb37
bb37:
  %t248 = load i64, ptr %l16, !tbaa !24
  %t251 = add i64 %t248, 1
  store i64 %t251, ptr %l16, !tbaa !24
  br label %bb33
bb38:
  %t253 = load i64, ptr %l10, !tbaa !24
  %t256 = add i64 %t253, 1
  store i64 %t256, ptr %l10, !tbaa !24
  br label %bb39
bb39:
  %t258 = load i64, ptr %l12, !tbaa !24
  %t261 = add i64 %t258, 1
  store i64 %t261, ptr %l12, !tbaa !24
  br label %bb29
bb40:
  store %olang.scope zeroinitializer, ptr %s15
  %t263 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t265 = extractvalue { i64, ptr } %t263, 1
  %t266 = extractvalue { i64, ptr } %t263, 0
  %t267 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t268 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t269 = add i64 %t266, %t268
  %t270 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t269)
  call void @olang_textcopy(ptr %t270, ptr %t265, i64 %t266)
  %t271 = getelementptr i8, ptr %t270, i64 %t266
  call void @olang_textcopy(ptr %t271, ptr %t267, i64 %t268)
  %t272 = insertvalue { i64, ptr } undef, i64 %t269, 0
  %t273 = insertvalue { i64, ptr } %t272, ptr %t270, 1
  %t275 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t276 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t278 = extractvalue { i64, ptr } %t276, 0
  %t280 = extractvalue { i64, ptr } %t273, 1
  %t281 = extractvalue { i64, ptr } %t273, 0
  %t283 = extractvalue { i64, ptr } %t275, 1
  %t284 = extractvalue { i64, ptr } %t275, 0
  %t286 = call i32 @__olang_exec(ptr %t280, ptr %t283, i64 %t278)
  store i32 %t286, ptr %l132
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s15)
  %t287 = call i32 @__olang_err()
  store i32 %t287, ptr %l133
  br label %bb42
bb42:
  %t288 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t289 = load i32, ptr %l133, !tbaa !23
  %t291 = call i32 @std_2fos_2eraise(ptr %v0, i32 %t289, { i64, ptr } %t288)
  store i32 %t291, ptr %l135
  %t292 = icmp ne i32 %t291, 0
  br i1 %t292, label %bb44, label %ok.293, !prof !99
ok.293:
  br label %bb43
bb43:
  br label %bb45
bb44:
  %t294 = load i32, ptr %l135, !tbaa !23
  %t295 = lshr i32 %t294, 16
  %t296 = and i32 %t294, 65535
  %t297 = icmp eq i32 %t295, 1
  %t298 = select i1 %t297, i32 1, i32 0
  %t299 = icmp eq i32 %t294, 0
  %t300 = shl i32 %t298, 16
  %t301 = or i32 %t300, %t296
  %t302 = select i1 %t299, i32 0, i32 %t301
  call void @__olang_scope_close(ptr %s0)
  store i32 %t302, ptr %rv
  br label %ret
bb45:
  %t304 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t304, ptr %l138, !tbaa !27
  %t306 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t307 = extractvalue { i64, ptr } %t306, 0
  store i64 %t307, ptr %l139, !tbaa !24
  %t308 = load i64, ptr %l139, !tbaa !24
  %t309 = mul i64 %t308, 1
  %t310 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t309)
  %t311 = insertvalue { i64, ptr } undef, i64 %t308, 0
  %t312 = insertvalue { i64, ptr } %t311, ptr %t310, 1
  store { i64, ptr } %t312, ptr %l140, !tbaa !27
  %t313 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t314 = load ptr, ptr %t313, !tbaa !27
  %t315 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t316 = load ptr, ptr %t315, !tbaa !27
  %t317 = load i64, ptr %l139, !tbaa !24
  %t318 = mul i64 %t317, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t314, ptr %t316, i64 %t318, i1 false)
  store { i64, [2 x i64] } zeroinitializer, ptr %t319
  %t320 = getelementptr { i64, [2 x i64] }, ptr %t319, i32 0, i32 0
  store i64 6, ptr %t320
  %t321 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t322 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t321, 0
  %t323 = getelementptr { i64, [2 x i64] }, ptr %t319, i32 0, i32 1
  store { { i64, ptr } } %t322, ptr %t323
  %t324 = load { i64, [2 x i64] }, ptr %t319
  store { i64, [2 x i64] } %t324, ptr %l141
  %t325 = call ptr @__olang_errpay_push()
  %t326 = ptrtoint ptr %t325 to i64
  store i64 %t326, ptr %l142, !tbaa !24
  %t327 = load i64, ptr %l142
  %t328 = inttoptr i64 %t327 to ptr
  %t330 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fos_3aError_24payload(ptr %t328, ptr %l141)
  store { i64, [2 x i64] } %t330, ptr %l144
  br label %bb46
bb46:
  %t331 = load { i64, [2 x i64] }, ptr %l144
  %t332 = load i64, ptr %l142
  %t333 = inttoptr i64 %t332 to ptr
  %t334 = call ptr @__olang_scope_alloc_a(ptr %t333, i64 24, i64 8)
  store { i64, [2 x i64] } %t331, ptr %t334
  call void @__olang_errpay_set(ptr %t334)
  call void @__olang_scope_close(ptr %s0)
  store i32 65542, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, %"std/os:File" } @std_2fos_2eFile_2eAppend(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca i1
  %l4 = alloca i32
  %l8 = alloca i32
  %l12 = alloca i32
  %l16 = alloca i32
  %l19 = alloca %"std/os:File"
  %s0 = alloca %olang.scope
  %rv = alloca { i32, %"std/os:File" }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d5, i32 0, i32 1) }, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store i1 %t1, ptr %l2
  br label %bb1
bb1:
  %t2 = load i1, ptr %l2, !tbaa !21
  %t3 = xor i1 %t2, true
  br i1 %t3, label %bb2, label %bb3
bb2:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 1
  %t8 = extractvalue { i64, ptr } %t5, 0
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @olang_textcopy(ptr %t12, ptr %t7, i64 %t8)
  %t13 = getelementptr i8, ptr %t12, i64 %t8
  call void @olang_textcopy(ptr %t13, ptr %t9, i64 %t10)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t12, 1
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = extractvalue { i64, ptr } %t15, 0
  %t20 = call i32 (ptr, i32, ...) @open(ptr %t18, i32 1089, i32 438)
  store i32 %t20, ptr %l8
  br label %bb4
bb3:
  %t21 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = extractvalue { i64, ptr } %t21, 0
  %t25 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t27 = add i64 %t24, %t26
  %t28 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t27)
  call void @olang_textcopy(ptr %t28, ptr %t23, i64 %t24)
  %t29 = getelementptr i8, ptr %t28, i64 %t24
  call void @olang_textcopy(ptr %t29, ptr %t25, i64 %t26)
  %t30 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t28, 1
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = extractvalue { i64, ptr } %t31, 0
  %t36 = call i32 (ptr, i32, ...) @open(ptr %t34, i32 33033, i32 384)
  store i32 %t36, ptr %l12
  br label %bb5
bb4:
  %t37 = load i32, ptr %l8, !tbaa !23
  store i32 %t37, ptr %l4, !tbaa !23
  br label %bb6
bb5:
  %t38 = load i32, ptr %l12, !tbaa !23
  store i32 %t38, ptr %l4, !tbaa !23
  br label %bb6
bb6:
  %t39 = load i32, ptr %l4, !tbaa !23
  store i32 %t39, ptr %l1, !tbaa !23
  %t40 = load i32, ptr %l1, !tbaa !23
  %t42 = sext i32 %t40 to i64
  %t43 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t46 = call i32 @std_2fos_2echeck(ptr %v0, i64 %t42, { i64, ptr } %t43)
  store i32 %t46, ptr %l16
  %t47 = icmp ne i32 %t46, 0
  br i1 %t47, label %bb8, label %ok.48, !prof !99
ok.48:
  br label %bb7
bb7:
  br label %bb9
bb8:
  %t49 = load i32, ptr %l16, !tbaa !23
  %t50 = lshr i32 %t49, 16
  %t51 = and i32 %t49, 65535
  %t52 = icmp eq i32 %t50, 1
  %t53 = select i1 %t52, i32 1, i32 0
  %t54 = icmp eq i32 %t49, 0
  %t55 = shl i32 %t53, 16
  %t56 = or i32 %t55, %t51
  %t57 = select i1 %t54, i32 0, i32 %t56
  call void @__olang_scope_close(ptr %s0)
  %t59 = insertvalue { i32, %"std/os:File" } zeroinitializer, i32 %t57, 0
  store { i32, %"std/os:File" } %t59, ptr %rv
  br label %ret
bb9:
  %t60 = load i32, ptr %l1, !tbaa !23
  %t62 = call %"std/os:File" @std_2fos_3aFile_2ector(ptr %s0, i32 %t60)
  store %"std/os:File" %t62, ptr %l19
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t63 = load %"std/os:File", ptr %l19
  %t64 = insertvalue { i32, %"std/os:File" } zeroinitializer, %"std/os:File" %t63, 1
  store { i32, %"std/os:File" } %t64, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/os:File" }, ptr %rv
  ret { i32, %"std/os:File" } %rr
}

define dso_local { i32, %"std/os:File" } @std_2fos_2eFile_2eCreate(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca i1
  %l4 = alloca i32
  %l8 = alloca i32
  %l12 = alloca i32
  %l16 = alloca i32
  %l19 = alloca %"std/os:File"
  %s0 = alloca %olang.scope
  %rv = alloca { i32, %"std/os:File" }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d9, i32 0, i32 1) }, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i1 %t1, ptr %l2
  br label %bb1
bb1:
  %t2 = load i1, ptr %l2, !tbaa !21
  %t3 = xor i1 %t2, true
  br i1 %t3, label %bb2, label %bb3
bb2:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 1
  %t8 = extractvalue { i64, ptr } %t5, 0
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @olang_textcopy(ptr %t12, ptr %t7, i64 %t8)
  %t13 = getelementptr i8, ptr %t12, i64 %t8
  call void @olang_textcopy(ptr %t13, ptr %t9, i64 %t10)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t12, 1
  %t18 = extractvalue { i64, ptr } %t15, 1
  %t19 = extractvalue { i64, ptr } %t15, 0
  %t20 = call i32 @creat(ptr %t18, i32 438)
  store i32 %t20, ptr %l8
  br label %bb4
bb3:
  %t21 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = extractvalue { i64, ptr } %t21, 0
  %t25 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t27 = add i64 %t24, %t26
  %t28 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t27)
  call void @olang_textcopy(ptr %t28, ptr %t23, i64 %t24)
  %t29 = getelementptr i8, ptr %t28, i64 %t24
  call void @olang_textcopy(ptr %t29, ptr %t25, i64 %t26)
  %t30 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t28, 1
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = extractvalue { i64, ptr } %t31, 0
  %t36 = call i32 (ptr, i32, ...) @open(ptr %t34, i32 33537, i32 384)
  store i32 %t36, ptr %l12
  br label %bb5
bb4:
  %t37 = load i32, ptr %l8, !tbaa !23
  store i32 %t37, ptr %l4, !tbaa !23
  br label %bb6
bb5:
  %t38 = load i32, ptr %l12, !tbaa !23
  store i32 %t38, ptr %l4, !tbaa !23
  br label %bb6
bb6:
  %t39 = load i32, ptr %l4, !tbaa !23
  store i32 %t39, ptr %l1, !tbaa !23
  %t40 = load i32, ptr %l1, !tbaa !23
  %t42 = sext i32 %t40 to i64
  %t43 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t46 = call i32 @std_2fos_2echeck(ptr %v0, i64 %t42, { i64, ptr } %t43)
  store i32 %t46, ptr %l16
  %t47 = icmp ne i32 %t46, 0
  br i1 %t47, label %bb8, label %ok.48, !prof !99
ok.48:
  br label %bb7
bb7:
  br label %bb9
bb8:
  %t49 = load i32, ptr %l16, !tbaa !23
  %t50 = lshr i32 %t49, 16
  %t51 = and i32 %t49, 65535
  %t52 = icmp eq i32 %t50, 1
  %t53 = select i1 %t52, i32 1, i32 0
  %t54 = icmp eq i32 %t49, 0
  %t55 = shl i32 %t53, 16
  %t56 = or i32 %t55, %t51
  %t57 = select i1 %t54, i32 0, i32 %t56
  call void @__olang_scope_close(ptr %s0)
  %t59 = insertvalue { i32, %"std/os:File" } zeroinitializer, i32 %t57, 0
  store { i32, %"std/os:File" } %t59, ptr %rv
  br label %ret
bb9:
  %t60 = load i32, ptr %l1, !tbaa !23
  %t62 = call %"std/os:File" @std_2fos_3aFile_2ector(ptr %s0, i32 %t60)
  store %"std/os:File" %t62, ptr %l19
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t63 = load %"std/os:File", ptr %l19
  %t64 = insertvalue { i32, %"std/os:File" } zeroinitializer, %"std/os:File" %t63, 1
  store { i32, %"std/os:File" } %t64, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/os:File" }, ptr %rv
  ret { i32, %"std/os:File" } %rr
}

define dso_local i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l10 = alloca i1
  %l17 = alloca i64
  %l20 = alloca i64
  %l42 = alloca i1
  %l43 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca i64
  %l57 = alloca i32
  %l59 = alloca i32
  %l64 = alloca i32
  %l67 = alloca i1
  %l70 = alloca { i64, ptr }
  %l71 = alloca i64
  %l72 = alloca { i64, ptr }
  %l73 = alloca { i64, [2 x i64] }
  %l74 = alloca i64
  %l76 = alloca { i64, [2 x i64] }
  %s3 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca i32
  %t158 = alloca { i64, [2 x i64] }, align 8
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %t1)
  store i1 %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load i1, ptr %l10, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i32 0, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store i64 1, ptr %l1, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t9 = add i64 %t7, 1
  store i64 %t9, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l2, !tbaa !24
  %t12 = load i64, ptr %l1, !tbaa !24
  %t15 = icmp sgt i64 %t11, %t12
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t17 = load i64, ptr %l3, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb10
bb7:
  %t21 = load i64, ptr %l2, !tbaa !24
  %t22 = load i64, ptr %l1, !tbaa !24
  %t25 = sub i64 %t21, %t22
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = add i64 %t25, %t26
  %t31 = sub i64 %t29, 1
  %t32 = load i64, ptr %l3, !tbaa !24
  %t35 = sdiv i64 %t31, %t32
  store i64 %t35, ptr %l20, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb9
bb9:
  %t37 = load i64, ptr %l20, !tbaa !24
  store i64 %t37, ptr %l17, !tbaa !24
  br label %bb10
bb10:
  %t38 = load i64, ptr %l17, !tbaa !24
  store i64 %t38, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t39 = load i64, ptr %l5, !tbaa !24
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb44
bb13:
  br label %bb14
bb14:
  %t47 = load i64, ptr %l1, !tbaa !24
  %t48 = load i64, ptr %l5, !tbaa !24
  %t49 = load i64, ptr %l3, !tbaa !24
  %t52 = mul i64 %t48, %t49
  %t55 = add i64 %t47, %t52
  store i64 %t55, ptr %l6, !tbaa !24
  %t57 = load i64, ptr %l6, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t63 = icmp slt i64 %t57, %t60
  br i1 %t63, label %bb15, label %bb16
bb15:
  %t65 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t65, ptr %l43, !tbaa !27
  %t66 = load i64, ptr %l6, !tbaa !24
  %t68 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr i8, ptr %t69, i64 %t66
  %t71 = load i8, ptr %t70, !tbaa !32
  %t73 = icmp ne i8 %t71, 47
  store i1 %t73, ptr %l42, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb17
bb17:
  %t75 = load i1, ptr %l42, !tbaa !21
  br i1 %t75, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb43
bb19:
  br label %bb20
bb20:
  %t76 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t76, ptr %l47, !tbaa !27
  %t77 = load i64, ptr %l6, !tbaa !24
  store i64 %t77, ptr %l48, !tbaa !24
  %t78 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 0
  store i64 %t79, ptr %l49, !tbaa !24
  %t80 = icmp sge i64 0, 0
  br i1 %t80, label %bb21, label %bb22
bb21:
  %t82 = load i64, ptr %l48, !tbaa !24
  %t83 = icmp sle i64 0, %t82
  br i1 %t83, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_1b39f3aec8a2d100_9d79a3da2d056474)
  unreachable
bb23:
  %t85 = load i64, ptr %l48, !tbaa !24
  %t86 = load i64, ptr %l49, !tbaa !24
  %t87 = icmp sle i64 %t85, %t86
  br i1 %t87, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_1b39f3aec8a2d100_9d79a3da2d056474)
  unreachable
bb25:
  %t89 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = load i64, ptr %l48, !tbaa !24
  %t92 = getelementptr i8, ptr %t90, i64 0
  %t93 = sub i64 %t91, 0
  %t94 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t92, 1
  store { i64, ptr } %t95, ptr %l7, !tbaa !27
  %t97 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 1
  %t100 = extractvalue { i64, ptr } %t97, 0
  %t101 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t102 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t103 = add i64 %t100, %t102
  %t104 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t103)
  call void @olang_textcopy(ptr %t104, ptr %t99, i64 %t100)
  %t105 = getelementptr i8, ptr %t104, i64 %t100
  call void @olang_textcopy(ptr %t105, ptr %t101, i64 %t102)
  %t106 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t104, 1
  %t110 = call i32 @std_2fos_2emkdir(ptr %s3, { i64, ptr } %t107)
  store i32 %t110, ptr %l57
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_1b39f3aec8a2d100_9d79a3da2d056474)
  unreachable
bb27:
  %t111 = load i32, ptr %l57, !tbaa !23
  %t112 = icmp ne i32 %t111, 0
  br i1 %t112, label %bb28, label %bb29
bb28:
  %t114 = call i32 @__olang_err()
  store i32 %t114, ptr %l59
  br label %bb30
bb29:
  br label %bb42
bb30:
  %t115 = load i32, ptr %l59, !tbaa !23
  store i32 %t115, ptr %l8, !tbaa !23
  %t116 = load i32, ptr %l8, !tbaa !23
  %t118 = icmp ne i32 %t116, 2
  br i1 %t118, label %bb31, label %bb32
bb31:
  %t120 = load i32, ptr %l8, !tbaa !23
  %t121 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t124 = call i32 @std_2fos_2eraise(ptr %v0, i32 %t120, { i64, ptr } %t121)
  store i32 %t124, ptr %l64
  %t125 = icmp ne i32 %t124, 0
  br i1 %t125, label %bb34, label %ok.126, !prof !99
ok.126:
  br label %bb33
bb32:
  br label %bb36
bb33:
  br label %bb35
bb34:
  %t127 = load i32, ptr %l64, !tbaa !23
  %t128 = lshr i32 %t127, 16
  %t129 = and i32 %t127, 65535
  %t130 = icmp eq i32 %t128, 1
  %t131 = select i1 %t130, i32 1, i32 0
  %t132 = icmp eq i32 %t127, 0
  %t133 = shl i32 %t131, 16
  %t134 = or i32 %t133, %t129
  %t135 = select i1 %t132, i32 0, i32 %t134
  call void @__olang_scope_close(ptr %s3)
  store i32 %t135, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t137 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t139 = call i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %t137)
  store i1 %t139, ptr %l67
  br label %bb37
bb37:
  %t140 = load i1, ptr %l67, !tbaa !21
  %t141 = xor i1 %t140, true
  br i1 %t141, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s8
  %t143 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t143, ptr %l70, !tbaa !27
  %t145 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t145, 0
  store i64 %t146, ptr %l71, !tbaa !24
  %t147 = load i64, ptr %l71, !tbaa !24
  %t148 = mul i64 %t147, 1
  %t149 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t148)
  %t150 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  store { i64, ptr } %t151, ptr %l72, !tbaa !27
  %t152 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = load i64, ptr %l71, !tbaa !24
  %t157 = mul i64 %t156, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t153, ptr %t155, i64 %t157, i1 false)
  store { i64, [2 x i64] } zeroinitializer, ptr %t158
  %t159 = getelementptr { i64, [2 x i64] }, ptr %t158, i32 0, i32 0
  store i64 3, ptr %t159
  %t160 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t161 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t160, 0
  %t162 = getelementptr { i64, [2 x i64] }, ptr %t158, i32 0, i32 1
  store { { i64, ptr } } %t161, ptr %t162
  %t163 = load { i64, [2 x i64] }, ptr %t158
  store { i64, [2 x i64] } %t163, ptr %l73
  %t164 = call ptr @__olang_errpay_push()
  %t165 = ptrtoint ptr %t164 to i64
  store i64 %t165, ptr %l74, !tbaa !24
  %t166 = load i64, ptr %l74
  %t167 = inttoptr i64 %t166 to ptr
  %t169 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fos_3aError_24payload(ptr %t167, ptr %l73)
  store { i64, [2 x i64] } %t169, ptr %l76
  br label %bb40
bb39:
  br label %bb41
bb40:
  %t170 = load { i64, [2 x i64] }, ptr %l76
  %t171 = load i64, ptr %l74
  %t172 = inttoptr i64 %t171 to ptr
  %t173 = call ptr @__olang_scope_alloc_a(ptr %t172, i64 24, i64 8)
  store { i64, [2 x i64] } %t170, ptr %t173
  call void @__olang_errpay_set(ptr %t173)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s3)
  store i32 65539, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s3)
  br label %bb43
bb43:
  %t176 = load i64, ptr %l5, !tbaa !24
  %t179 = add i64 %t176, 1
  store i64 %t179, ptr %l5, !tbaa !24
  br label %bb11
bb44:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i1
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, [2 x i64] }
  %l14 = alloca i64
  %l16 = alloca { i64, [2 x i64] }
  %l20 = alloca { i64, ptr }
  %l22 = alloca i1
  %l23 = alloca { i64, ptr }
  %l31 = alloca i32
  %l33 = alloca i32
  %l35 = alloca i32
  %l39 = alloca i64
  %l40 = alloca i64
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t22 = alloca { i64, [2 x i64] }, align 8
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, ptr %l7, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t5 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t1, { i64, ptr } %t4)
  store i1 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i1, ptr %l8, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %l10, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l11, !tbaa !24
  %t11 = load i64, ptr %l11, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l12, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = load i64, ptr %l11, !tbaa !24
  %t21 = mul i64 %t20, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %t19, i64 %t21, i1 false)
  store { i64, [2 x i64] } zeroinitializer, ptr %t22
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t22, i32 0, i32 0
  store i64 6, ptr %t23
  %t24 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t25 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t24, 0
  %t26 = getelementptr { i64, [2 x i64] }, ptr %t22, i32 0, i32 1
  store { { i64, ptr } } %t25, ptr %t26
  %t27 = load { i64, [2 x i64] }, ptr %t22
  store { i64, [2 x i64] } %t27, ptr %l13
  %t28 = call ptr @__olang_errpay_push()
  %t29 = ptrtoint ptr %t28 to i64
  store i64 %t29, ptr %l14, !tbaa !24
  %t30 = load i64, ptr %l14
  %t31 = inttoptr i64 %t30 to ptr
  %t33 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fos_3aError_24payload(ptr %t31, ptr %l13)
  store { i64, [2 x i64] } %t33, ptr %l16
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t34 = load { i64, [2 x i64] }, ptr %l16
  %t35 = load i64, ptr %l14
  %t36 = inttoptr i64 %t35 to ptr
  %t37 = call ptr @__olang_scope_alloc_a(ptr %t36, i64 24, i64 8)
  store { i64, [2 x i64] } %t34, ptr %t37
  call void @__olang_errpay_set(ptr %t37)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t40 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65542, 0
  store { i32, { i64, ptr } } %t40, ptr %rv
  br label %ret
bb5:
  %t43 = call { i64, ptr } @std_2fos_2etempDir(ptr %v0, ptr %s0, { i64, ptr } %a0)
  store { i64, ptr } %t43, ptr %l20
  br label %bb6
bb6:
  %t44 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t44, ptr %l2, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t47 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s0, { i64, ptr } %t45, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t47, ptr %l22
  br label %bb7
bb7:
  %t48 = load i1, ptr %l22, !tbaa !21
  br i1 %t48, label %bb8, label %bb9
bb8:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l23, !tbaa !27
  br label %bb10
bb9:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, ptr %l23, !tbaa !27
  br label %bb10
bb10:
  %t49 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t50, 1
  %t55 = extractvalue { i64, ptr } %t50, 0
  %t57 = extractvalue { i64, ptr } %t49, 1
  %t58 = extractvalue { i64, ptr } %t49, 0
  %t59 = add i64 %t55, %t58
  %t61 = extractvalue { i64, ptr } %t52, 1
  %t62 = extractvalue { i64, ptr } %t52, 0
  %t63 = add i64 %t59, %t62
  %t64 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t65 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t66 = add i64 %t63, %t65
  %t67 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t66)
  call void @olang_textcopy(ptr %t67, ptr %t54, i64 %t55)
  %t68 = getelementptr i8, ptr %t67, i64 %t55
  call void @olang_textcopy(ptr %t68, ptr %t57, i64 %t58)
  %t69 = getelementptr i8, ptr %t68, i64 %t58
  call void @olang_textcopy(ptr %t69, ptr %t61, i64 %t62)
  %t70 = getelementptr i8, ptr %t69, i64 %t62
  call void @olang_textcopy(ptr %t70, ptr %t64, i64 %t65)
  %t71 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t67, 1
  store { i64, ptr } %t72, ptr %l4, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t75, 1
  %t79 = extractvalue { i64, ptr } %t75, 0
  %t80 = call i32 @__olang_mkdtemp(ptr %t78)
  store i32 %t80, ptr %l31
  br label %bb11
bb11:
  %t81 = load i32, ptr %l31, !tbaa !23
  %t82 = icmp ne i32 %t81, 0
  br i1 %t82, label %bb12, label %bb13
bb12:
  %t84 = call i32 @__olang_err()
  store i32 %t84, ptr %l33
  br label %bb14
bb13:
  br label %bb18
bb14:
  %t85 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t86 = load i32, ptr %l33, !tbaa !23
  %t88 = call i32 @std_2fos_2eraise(ptr %s0, i32 %t86, { i64, ptr } %t85)
  store i32 %t88, ptr %l35
  %t89 = icmp ne i32 %t88, 0
  br i1 %t89, label %bb16, label %ok.90, !prof !99
ok.90:
  br label %bb15
bb15:
  br label %bb17
bb16:
  %t91 = load i32, ptr %l35, !tbaa !23
  %t92 = lshr i32 %t91, 16
  %t93 = and i32 %t91, 65535
  %t94 = icmp eq i32 %t92, 1
  %t95 = select i1 %t94, i32 1, i32 0
  %t96 = icmp eq i32 %t91, 0
  %t97 = shl i32 %t95, 16
  %t98 = or i32 %t97, %t93
  %t99 = select i1 %t96, i32 0, i32 %t98
  call void @__olang_scope_close(ptr %s0)
  %t101 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t99, 0
  store { i32, { i64, ptr } } %t101, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t102 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t102, 0
  %t106 = sub i64 %t104, 1
  store i64 %t106, ptr %l39, !tbaa !24
  %t107 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t107, 0
  store i64 %t108, ptr %l40, !tbaa !24
  %t109 = icmp sge i64 0, 0
  br i1 %t109, label %bb19, label %bb20
bb19:
  %t111 = load i64, ptr %l39, !tbaa !24
  %t112 = icmp sle i64 0, %t111
  br i1 %t112, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_93142f54c4ba4464_592b0bc010c9eac8)
  unreachable
bb21:
  %t114 = load i64, ptr %l39, !tbaa !24
  %t115 = load i64, ptr %l40, !tbaa !24
  %t116 = icmp sle i64 %t114, %t115
  br i1 %t116, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_93142f54c4ba4464_592b0bc010c9eac8)
  unreachable
bb23:
  %t118 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = load i64, ptr %l39, !tbaa !24
  %t121 = getelementptr i8, ptr %t119, i64 0
  %t122 = sub i64 %t120, 0
  %t123 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t121, 1
  store { i64, ptr } %t124, ptr %l45, !tbaa !27
  %t126 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t126, 0
  store i64 %t127, ptr %l46, !tbaa !24
  %t128 = load i64, ptr %l46, !tbaa !24
  %t129 = mul i64 %t128, 1
  %t130 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t129)
  %t131 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  store { i64, ptr } %t132, ptr %l47, !tbaa !27
  %t133 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !27
  %t137 = load i64, ptr %l46, !tbaa !24
  %t138 = mul i64 %t137, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t134, ptr %t136, i64 %t138, i1 false)
  %t139 = load { i64, ptr }, ptr %l47, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t142 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t139, 1
  store { i32, { i64, ptr } } %t142, ptr %rv
  br label %ret
bb24:
  call void @__olang_check_failed(ptr @olang_loc_93142f54c4ba4464_592b0bc010c9eac8)
  unreachable
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local %"std/os:Output" @std_2fos_2eOutput_2eechoed(ptr %v0, i64 %a0) #0 {
entry:
  %l1 = alloca [2 x { i64, ptr }]
  %l2 = alloca %"std/os:Output"
  %l3 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca %"std/os:Output"
  %l13 = alloca i32
  %l17 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %s3 = alloca %olang.builder
  %s3room = alloca [64 x i8], align 8
  %s4 = alloca %olang.builder
  %s4room = alloca [64 x i8], align 8
  %s5 = alloca %olang.builder
  %s5room = alloca [64 x i8], align 8
  %s6 = alloca %olang.builder
  %s6room = alloca [64 x i8], align 8
  %s7 = alloca %olang.builder
  %s7room = alloca [64 x i8], align 8
  %s8 = alloca %olang.builder
  %s8room = alloca [64 x i8], align 8
  %rv = alloca %"std/os:Output"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call ptr @__olang_scope_hold(ptr %s0)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_202_3e_2e_2d1
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %s0)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t8 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t11 = call i64 @__olang_fmt_i64(ptr null, i64 %a0)
  %t12 = add i64 %t9, %t11
  %t13 = load i64, ptr %l3
  %t14 = inttoptr i64 %t13 to ptr
  %t15 = call ptr @__olang_held_alloc(ptr %t14, i64 %t12)
  call void @olang_textcopy(ptr %t15, ptr %t8, i64 %t9)
  %t16 = getelementptr i8, ptr %t15, i64 %t9
  %t17 = call i64 @__olang_fmt_i64(ptr %t16, i64 %a0)
  %t18 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t15, 1
  %t21 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t23 = insertvalue [2 x { i64, ptr }] %t21, { i64, ptr } %t19, 1
  store [2 x { i64, ptr }] %t23, ptr %l1
  %t26 = insertvalue { i64, ptr } undef, i64 2, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %l1, 1
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %l11, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t30 = call { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %s0, ptr %s0, ptr %s0, ptr %v0, { i64, ptr } %t27, { i64, ptr } %t29, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d22, i32 0, i32 1) })
  %t31 = extractvalue { i32, %"std/os:Output" } %t30, 1
  %t32 = extractvalue { i32, %"std/os:Output" } %t30, 0
  store i32 %t32, ptr %l13
  %t33 = icmp ne i32 %t32, 0
  br i1 %t33, label %bb4, label %ok.34, !prof !99
ok.34:
  store %"std/os:Output" %t31, ptr %l12
  br label %bb3
bb3:
  %t35 = load %"std/os:Output", ptr %l12
  store %"std/os:Output" %t35, ptr %l2
  br label %bb19
bb4:
  %t36 = load i32, ptr %l13, !tbaa !23
  %t37 = icmp eq i32 %t36, 65536
  br i1 %t37, label %bb5, label %bb6
bb5:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t39 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t39, i64 %t40)
  %t41 = call ptr @__olang_errpay_top_get()
  %t42 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t43 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t42, i64 %t43)
  %t45 = getelementptr { i64, [2 x i64] }, ptr %t41, i32 0, i32 1
  %t46 = getelementptr { { i64, ptr } }, ptr %t45, i32 0, i32 0
  %t47 = load { i64, ptr }, ptr %t46
  %t49 = extractvalue { i64, ptr } %t47, 1
  %t50 = extractvalue { i64, ptr } %t47, 0
  %t51 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t49, i64 %t50, i8 34)
  %t52 = call ptr @__olang_sb_room(ptr %s2, i64 %t51)
  %t53 = call i64 @__olang_rd_quote(ptr %t52, i64 0, ptr %t49, i64 %t50, i8 34)
  call void @__olang_sb_add(ptr %s2, i64 %t51)
  %t54 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t55 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t54, i64 %t55)
  %t56 = load ptr, ptr %s2
  %t57 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t58 = load i64, ptr %t57
  %t59 = load ptr, ptr @__olang_prog_scope
  %t60 = call ptr @__olang_scope_alloc(ptr %t59, i64 %t58)
  call void @olang_textcopy(ptr %t60, ptr %t56, i64 %t58)
  %t61 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  store { i64, ptr } %t62, ptr %l17, !tbaa !27
  %t63 = getelementptr %olang.builder, ptr %s2, i32 0, i32 3
  %t64 = load ptr, ptr %t63
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %sbgrew.66, label %sbdone.67
sbgrew.66:
  call void @__olang_sb_done(ptr %s2)
  br label %sbdone.67
sbdone.67:
  %t68 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t69 = load ptr, ptr @__olang_prog_scope
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t71 = extractvalue { i64, ptr } %t68, 1
  %t72 = mul i64 %t70, 1
  %t73 = call ptr @__olang_scope_alloc(ptr %t69, i64 %t72)
  call void @llvm.memcpy.p0.p0.i64(ptr %t73, ptr %t71, i64 %t72, i1 false)
  %t74 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  %t77 = extractvalue { i64, ptr } %t75, 1
  %t78 = extractvalue { i64, ptr } %t75, 0
  %t79 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t77, 1
  call void @__olang_bang_failed_text(ptr @olang_loc_f119a7c9f27c98b4_8ee77fd34027ef68, { i64, ptr } %t80, i1 false)
  unreachable
bb6:
  %t81 = load i32, ptr %l13, !tbaa !23
  %t82 = icmp eq i32 %t81, 65537
  br i1 %t82, label %bb7, label %bb8
bb7:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s3
  store ptr %s3room, ptr %s3
  %t84 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t85 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t84, i64 %t85)
  %t86 = call ptr @__olang_errpay_top_get()
  %t87 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t88 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t87, i64 %t88)
  %t90 = getelementptr { i64, [2 x i64] }, ptr %t86, i32 0, i32 1
  %t91 = getelementptr { { i64, ptr } }, ptr %t90, i32 0, i32 0
  %t92 = load { i64, ptr }, ptr %t91
  %t94 = extractvalue { i64, ptr } %t92, 1
  %t95 = extractvalue { i64, ptr } %t92, 0
  %t96 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t94, i64 %t95, i8 34)
  %t97 = call ptr @__olang_sb_room(ptr %s3, i64 %t96)
  %t98 = call i64 @__olang_rd_quote(ptr %t97, i64 0, ptr %t94, i64 %t95, i8 34)
  call void @__olang_sb_add(ptr %s3, i64 %t96)
  %t99 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t100 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t99, i64 %t100)
  %t101 = load ptr, ptr %s3
  %t102 = getelementptr %olang.builder, ptr %s3, i32 0, i32 1
  %t103 = load i64, ptr %t102
  %t104 = load ptr, ptr @__olang_prog_scope
  %t105 = call ptr @__olang_scope_alloc(ptr %t104, i64 %t103)
  call void @olang_textcopy(ptr %t105, ptr %t101, i64 %t103)
  %t106 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  store { i64, ptr } %t107, ptr %l22, !tbaa !27
  %t108 = getelementptr %olang.builder, ptr %s3, i32 0, i32 3
  %t109 = load ptr, ptr %t108
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %sbgrew.111, label %sbdone.112
sbgrew.111:
  call void @__olang_sb_done(ptr %s3)
  br label %sbdone.112
sbdone.112:
  %t113 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t114 = load ptr, ptr @__olang_prog_scope
  %t115 = extractvalue { i64, ptr } %t113, 0
  %t116 = extractvalue { i64, ptr } %t113, 1
  %t117 = mul i64 %t115, 1
  %t118 = call ptr @__olang_scope_alloc(ptr %t114, i64 %t117)
  call void @llvm.memcpy.p0.p0.i64(ptr %t118, ptr %t116, i64 %t117, i1 false)
  %t119 = insertvalue { i64, ptr } undef, i64 %t115, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t118, 1
  %t122 = extractvalue { i64, ptr } %t120, 1
  %t123 = extractvalue { i64, ptr } %t120, 0
  %t124 = insertvalue { i64, ptr } undef, i64 %t123, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t122, 1
  call void @__olang_bang_failed_text(ptr @olang_loc_f119a7c9f27c98b4_8ee77fd34027ef68, { i64, ptr } %t125, i1 false)
  unreachable
bb8:
  %t126 = load i32, ptr %l13, !tbaa !23
  %t127 = icmp eq i32 %t126, 65538
  br i1 %t127, label %bb9, label %bb10
bb9:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s4
  store ptr %s4room, ptr %s4
  %t129 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t130 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t129, i64 %t130)
  %t131 = call ptr @__olang_errpay_top_get()
  %t132 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t133 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t132, i64 %t133)
  %t135 = getelementptr { i64, [2 x i64] }, ptr %t131, i32 0, i32 1
  %t136 = getelementptr { { i64, ptr } }, ptr %t135, i32 0, i32 0
  %t137 = load { i64, ptr }, ptr %t136
  %t139 = extractvalue { i64, ptr } %t137, 1
  %t140 = extractvalue { i64, ptr } %t137, 0
  %t141 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t139, i64 %t140, i8 34)
  %t142 = call ptr @__olang_sb_room(ptr %s4, i64 %t141)
  %t143 = call i64 @__olang_rd_quote(ptr %t142, i64 0, ptr %t139, i64 %t140, i8 34)
  call void @__olang_sb_add(ptr %s4, i64 %t141)
  %t144 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t145 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t144, i64 %t145)
  %t146 = load ptr, ptr %s4
  %t147 = getelementptr %olang.builder, ptr %s4, i32 0, i32 1
  %t148 = load i64, ptr %t147
  %t149 = load ptr, ptr @__olang_prog_scope
  %t150 = call ptr @__olang_scope_alloc(ptr %t149, i64 %t148)
  call void @olang_textcopy(ptr %t150, ptr %t146, i64 %t148)
  %t151 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t150, 1
  store { i64, ptr } %t152, ptr %l27, !tbaa !27
  %t153 = getelementptr %olang.builder, ptr %s4, i32 0, i32 3
  %t154 = load ptr, ptr %t153
  %t155 = icmp ne ptr %t154, null
  br i1 %t155, label %sbgrew.156, label %sbdone.157
sbgrew.156:
  call void @__olang_sb_done(ptr %s4)
  br label %sbdone.157
sbdone.157:
  %t158 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t159 = load ptr, ptr @__olang_prog_scope
  %t160 = extractvalue { i64, ptr } %t158, 0
  %t161 = extractvalue { i64, ptr } %t158, 1
  %t162 = mul i64 %t160, 1
  %t163 = call ptr @__olang_scope_alloc(ptr %t159, i64 %t162)
  call void @llvm.memcpy.p0.p0.i64(ptr %t163, ptr %t161, i64 %t162, i1 false)
  %t164 = insertvalue { i64, ptr } undef, i64 %t160, 0
  %t165 = insertvalue { i64, ptr } %t164, ptr %t163, 1
  %t167 = extractvalue { i64, ptr } %t165, 1
  %t168 = extractvalue { i64, ptr } %t165, 0
  %t169 = insertvalue { i64, ptr } undef, i64 %t168, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t167, 1
  call void @__olang_bang_failed_text(ptr @olang_loc_f119a7c9f27c98b4_8ee77fd34027ef68, { i64, ptr } %t170, i1 false)
  unreachable
bb10:
  %t171 = load i32, ptr %l13, !tbaa !23
  %t172 = icmp eq i32 %t171, 65539
  br i1 %t172, label %bb11, label %bb12
bb11:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s5
  store ptr %s5room, ptr %s5
  %t174 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t175 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t174, i64 %t175)
  %t176 = call ptr @__olang_errpay_top_get()
  %t177 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t178 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t177, i64 %t178)
  %t180 = getelementptr { i64, [2 x i64] }, ptr %t176, i32 0, i32 1
  %t181 = getelementptr { { i64, ptr } }, ptr %t180, i32 0, i32 0
  %t182 = load { i64, ptr }, ptr %t181
  %t184 = extractvalue { i64, ptr } %t182, 1
  %t185 = extractvalue { i64, ptr } %t182, 0
  %t186 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t184, i64 %t185, i8 34)
  %t187 = call ptr @__olang_sb_room(ptr %s5, i64 %t186)
  %t188 = call i64 @__olang_rd_quote(ptr %t187, i64 0, ptr %t184, i64 %t185, i8 34)
  call void @__olang_sb_add(ptr %s5, i64 %t186)
  %t189 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t190 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t189, i64 %t190)
  %t191 = load ptr, ptr %s5
  %t192 = getelementptr %olang.builder, ptr %s5, i32 0, i32 1
  %t193 = load i64, ptr %t192
  %t194 = load ptr, ptr @__olang_prog_scope
  %t195 = call ptr @__olang_scope_alloc(ptr %t194, i64 %t193)
  call void @olang_textcopy(ptr %t195, ptr %t191, i64 %t193)
  %t196 = insertvalue { i64, ptr } undef, i64 %t193, 0
  %t197 = insertvalue { i64, ptr } %t196, ptr %t195, 1
  store { i64, ptr } %t197, ptr %l32, !tbaa !27
  %t198 = getelementptr %olang.builder, ptr %s5, i32 0, i32 3
  %t199 = load ptr, ptr %t198
  %t200 = icmp ne ptr %t199, null
  br i1 %t200, label %sbgrew.201, label %sbdone.202
sbgrew.201:
  call void @__olang_sb_done(ptr %s5)
  br label %sbdone.202
sbdone.202:
  %t203 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t204 = load ptr, ptr @__olang_prog_scope
  %t205 = extractvalue { i64, ptr } %t203, 0
  %t206 = extractvalue { i64, ptr } %t203, 1
  %t207 = mul i64 %t205, 1
  %t208 = call ptr @__olang_scope_alloc(ptr %t204, i64 %t207)
  call void @llvm.memcpy.p0.p0.i64(ptr %t208, ptr %t206, i64 %t207, i1 false)
  %t209 = insertvalue { i64, ptr } undef, i64 %t205, 0
  %t210 = insertvalue { i64, ptr } %t209, ptr %t208, 1
  %t212 = extractvalue { i64, ptr } %t210, 1
  %t213 = extractvalue { i64, ptr } %t210, 0
  %t214 = insertvalue { i64, ptr } undef, i64 %t213, 0
  %t215 = insertvalue { i64, ptr } %t214, ptr %t212, 1
  call void @__olang_bang_failed_text(ptr @olang_loc_f119a7c9f27c98b4_8ee77fd34027ef68, { i64, ptr } %t215, i1 false)
  unreachable
bb12:
  %t216 = load i32, ptr %l13, !tbaa !23
  %t217 = icmp eq i32 %t216, 65540
  br i1 %t217, label %bb13, label %bb14
bb13:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s6
  store ptr %s6room, ptr %s6
  %t219 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t220 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s6, ptr %t219, i64 %t220)
  %t221 = call ptr @__olang_errpay_top_get()
  %t222 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t223 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s6, ptr %t222, i64 %t223)
  %t225 = getelementptr { i64, [2 x i64] }, ptr %t221, i32 0, i32 1
  %t226 = getelementptr { { i64, ptr } }, ptr %t225, i32 0, i32 0
  %t227 = load { i64, ptr }, ptr %t226
  %t229 = extractvalue { i64, ptr } %t227, 1
  %t230 = extractvalue { i64, ptr } %t227, 0
  %t231 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t229, i64 %t230, i8 34)
  %t232 = call ptr @__olang_sb_room(ptr %s6, i64 %t231)
  %t233 = call i64 @__olang_rd_quote(ptr %t232, i64 0, ptr %t229, i64 %t230, i8 34)
  call void @__olang_sb_add(ptr %s6, i64 %t231)
  %t234 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t235 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s6, ptr %t234, i64 %t235)
  %t236 = load ptr, ptr %s6
  %t237 = getelementptr %olang.builder, ptr %s6, i32 0, i32 1
  %t238 = load i64, ptr %t237
  %t239 = load ptr, ptr @__olang_prog_scope
  %t240 = call ptr @__olang_scope_alloc(ptr %t239, i64 %t238)
  call void @olang_textcopy(ptr %t240, ptr %t236, i64 %t238)
  %t241 = insertvalue { i64, ptr } undef, i64 %t238, 0
  %t242 = insertvalue { i64, ptr } %t241, ptr %t240, 1
  store { i64, ptr } %t242, ptr %l37, !tbaa !27
  %t243 = getelementptr %olang.builder, ptr %s6, i32 0, i32 3
  %t244 = load ptr, ptr %t243
  %t245 = icmp ne ptr %t244, null
  br i1 %t245, label %sbgrew.246, label %sbdone.247
sbgrew.246:
  call void @__olang_sb_done(ptr %s6)
  br label %sbdone.247
sbdone.247:
  %t248 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t249 = load ptr, ptr @__olang_prog_scope
  %t250 = extractvalue { i64, ptr } %t248, 0
  %t251 = extractvalue { i64, ptr } %t248, 1
  %t252 = mul i64 %t250, 1
  %t253 = call ptr @__olang_scope_alloc(ptr %t249, i64 %t252)
  call void @llvm.memcpy.p0.p0.i64(ptr %t253, ptr %t251, i64 %t252, i1 false)
  %t254 = insertvalue { i64, ptr } undef, i64 %t250, 0
  %t255 = insertvalue { i64, ptr } %t254, ptr %t253, 1
  %t257 = extractvalue { i64, ptr } %t255, 1
  %t258 = extractvalue { i64, ptr } %t255, 0
  %t259 = insertvalue { i64, ptr } undef, i64 %t258, 0
  %t260 = insertvalue { i64, ptr } %t259, ptr %t257, 1
  call void @__olang_bang_failed_text(ptr @olang_loc_f119a7c9f27c98b4_8ee77fd34027ef68, { i64, ptr } %t260, i1 false)
  unreachable
bb14:
  %t261 = load i32, ptr %l13, !tbaa !23
  %t262 = icmp eq i32 %t261, 65541
  br i1 %t262, label %bb15, label %bb16
bb15:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s7
  store ptr %s7room, ptr %s7
  %t264 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t265 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t264, i64 %t265)
  %t266 = call ptr @__olang_errpay_top_get()
  %t267 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t268 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t267, i64 %t268)
  %t270 = getelementptr { i64, [2 x i64] }, ptr %t266, i32 0, i32 1
  %t271 = getelementptr { { i64, ptr } }, ptr %t270, i32 0, i32 0
  %t272 = load { i64, ptr }, ptr %t271
  %t274 = extractvalue { i64, ptr } %t272, 1
  %t275 = extractvalue { i64, ptr } %t272, 0
  %t276 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t274, i64 %t275, i8 34)
  %t277 = call ptr @__olang_sb_room(ptr %s7, i64 %t276)
  %t278 = call i64 @__olang_rd_quote(ptr %t277, i64 0, ptr %t274, i64 %t275, i8 34)
  call void @__olang_sb_add(ptr %s7, i64 %t276)
  %t279 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t280 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t279, i64 %t280)
  %t281 = load ptr, ptr %s7
  %t282 = getelementptr %olang.builder, ptr %s7, i32 0, i32 1
  %t283 = load i64, ptr %t282
  %t284 = load ptr, ptr @__olang_prog_scope
  %t285 = call ptr @__olang_scope_alloc(ptr %t284, i64 %t283)
  call void @olang_textcopy(ptr %t285, ptr %t281, i64 %t283)
  %t286 = insertvalue { i64, ptr } undef, i64 %t283, 0
  %t287 = insertvalue { i64, ptr } %t286, ptr %t285, 1
  store { i64, ptr } %t287, ptr %l42, !tbaa !27
  %t288 = getelementptr %olang.builder, ptr %s7, i32 0, i32 3
  %t289 = load ptr, ptr %t288
  %t290 = icmp ne ptr %t289, null
  br i1 %t290, label %sbgrew.291, label %sbdone.292
sbgrew.291:
  call void @__olang_sb_done(ptr %s7)
  br label %sbdone.292
sbdone.292:
  %t293 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t294 = load ptr, ptr @__olang_prog_scope
  %t295 = extractvalue { i64, ptr } %t293, 0
  %t296 = extractvalue { i64, ptr } %t293, 1
  %t297 = mul i64 %t295, 1
  %t298 = call ptr @__olang_scope_alloc(ptr %t294, i64 %t297)
  call void @llvm.memcpy.p0.p0.i64(ptr %t298, ptr %t296, i64 %t297, i1 false)
  %t299 = insertvalue { i64, ptr } undef, i64 %t295, 0
  %t300 = insertvalue { i64, ptr } %t299, ptr %t298, 1
  %t302 = extractvalue { i64, ptr } %t300, 1
  %t303 = extractvalue { i64, ptr } %t300, 0
  %t304 = insertvalue { i64, ptr } undef, i64 %t303, 0
  %t305 = insertvalue { i64, ptr } %t304, ptr %t302, 1
  call void @__olang_bang_failed_text(ptr @olang_loc_f119a7c9f27c98b4_8ee77fd34027ef68, { i64, ptr } %t305, i1 false)
  unreachable
bb16:
  %t306 = load i32, ptr %l13, !tbaa !23
  %t307 = icmp eq i32 %t306, 65542
  br i1 %t307, label %bb17, label %bb18
bb17:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s8
  store ptr %s8room, ptr %s8
  %t309 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t310 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s8, ptr %t309, i64 %t310)
  %t311 = call ptr @__olang_errpay_top_get()
  %t312 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t313 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s8, ptr %t312, i64 %t313)
  %t315 = getelementptr { i64, [2 x i64] }, ptr %t311, i32 0, i32 1
  %t316 = getelementptr { { i64, ptr } }, ptr %t315, i32 0, i32 0
  %t317 = load { i64, ptr }, ptr %t316
  %t319 = extractvalue { i64, ptr } %t317, 1
  %t320 = extractvalue { i64, ptr } %t317, 0
  %t321 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t319, i64 %t320, i8 34)
  %t322 = call ptr @__olang_sb_room(ptr %s8, i64 %t321)
  %t323 = call i64 @__olang_rd_quote(ptr %t322, i64 0, ptr %t319, i64 %t320, i8 34)
  call void @__olang_sb_add(ptr %s8, i64 %t321)
  %t324 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t325 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s8, ptr %t324, i64 %t325)
  %t326 = load ptr, ptr %s8
  %t327 = getelementptr %olang.builder, ptr %s8, i32 0, i32 1
  %t328 = load i64, ptr %t327
  %t329 = load ptr, ptr @__olang_prog_scope
  %t330 = call ptr @__olang_scope_alloc(ptr %t329, i64 %t328)
  call void @olang_textcopy(ptr %t330, ptr %t326, i64 %t328)
  %t331 = insertvalue { i64, ptr } undef, i64 %t328, 0
  %t332 = insertvalue { i64, ptr } %t331, ptr %t330, 1
  store { i64, ptr } %t332, ptr %l47, !tbaa !27
  %t333 = getelementptr %olang.builder, ptr %s8, i32 0, i32 3
  %t334 = load ptr, ptr %t333
  %t335 = icmp ne ptr %t334, null
  br i1 %t335, label %sbgrew.336, label %sbdone.337
sbgrew.336:
  call void @__olang_sb_done(ptr %s8)
  br label %sbdone.337
sbdone.337:
  %t338 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t339 = load ptr, ptr @__olang_prog_scope
  %t340 = extractvalue { i64, ptr } %t338, 0
  %t341 = extractvalue { i64, ptr } %t338, 1
  %t342 = mul i64 %t340, 1
  %t343 = call ptr @__olang_scope_alloc(ptr %t339, i64 %t342)
  call void @llvm.memcpy.p0.p0.i64(ptr %t343, ptr %t341, i64 %t342, i1 false)
  %t344 = insertvalue { i64, ptr } undef, i64 %t340, 0
  %t345 = insertvalue { i64, ptr } %t344, ptr %t343, 1
  %t347 = extractvalue { i64, ptr } %t345, 1
  %t348 = extractvalue { i64, ptr } %t345, 0
  %t349 = insertvalue { i64, ptr } undef, i64 %t348, 0
  %t350 = insertvalue { i64, ptr } %t349, ptr %t347, 1
  call void @__olang_bang_failed_text(ptr @olang_loc_f119a7c9f27c98b4_8ee77fd34027ef68, { i64, ptr } %t350, i1 false)
  unreachable
bb18:
  call void @__olang_bang_failed_plain(ptr @olang_loc_1a596f16b0c0d4cc_1848fbd7ff01a1d8)
  unreachable
bb19:
  call void @__olang_scope_close(ptr %s0)
  %t351 = load %"std/os:Output", ptr %l2
  store %"std/os:Output" %t351, ptr %rv
  br label %ret
ret:
  %rr = load %"std/os:Output", ptr %rv
  ret %"std/os:Output" %rr
}

define dso_local { i32, %"std/os:Process" } @std_2fos_2eProcess_2eStart(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca %"std/os:FileInfo"
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i32
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, [2 x i64] }
  %l36 = alloca i64
  %l38 = alloca { i64, [2 x i64] }
  %l48 = alloca { i64, ptr }
  %l51 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i32
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca { i64, ptr }
  %l60 = alloca { i64, [2 x i64] }
  %l61 = alloca i64
  %l63 = alloca { i64, [2 x i64] }
  %l74 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i32
  %l80 = alloca { i64, ptr }
  %l81 = alloca i64
  %l82 = alloca { i64, ptr }
  %l83 = alloca { i64, [2 x i64] }
  %l84 = alloca i64
  %l86 = alloca { i64, [2 x i64] }
  %l92 = alloca %"std/os:FileInfo"
  %l94 = alloca %"std/os:FileInfo"
  %l95 = alloca i32
  %l101 = alloca { i64, ptr }
  %l102 = alloca i64
  %l103 = alloca { i64, ptr }
  %l104 = alloca { i64, [2 x i64] }
  %l105 = alloca i64
  %l107 = alloca { i64, [2 x i64] }
  %l110 = alloca i64
  %l116 = alloca i64
  %l119 = alloca i1
  %l124 = alloca { i64, ptr }
  %l130 = alloca i64
  %l133 = alloca i1
  %l138 = alloca { i64, ptr }
  %l156 = alloca i32
  %l157 = alloca i32
  %l158 = alloca i32
  %l162 = alloca i32
  %l164 = alloca i1
  %l167 = alloca { i64, ptr }
  %l169 = alloca { i64, ptr }
  %l170 = alloca i64
  %l171 = alloca { i64, ptr }
  %l172 = alloca { i64, [2 x i64] }
  %l173 = alloca i64
  %l175 = alloca { i64, [2 x i64] }
  %l177 = alloca i32
  %l179 = alloca i32
  %l181 = alloca i64
  %l183 = alloca i32
  %l184 = alloca i32
  %l185 = alloca i32
  %l186 = alloca i32
  %l188 = alloca i32
  %l189 = alloca i32
  %l192 = alloca i32
  %l193 = alloca i32
  %l194 = alloca i32
  %l195 = alloca i32
  %l197 = alloca i32
  %l207 = alloca i32
  %l210 = alloca i32
  %l213 = alloca i32
  %l215 = alloca i32
  %l217 = alloca { i64, ptr }
  %l219 = alloca i32
  %l220 = alloca i32
  %l222 = alloca i32
  %l227 = alloca %"std/os:Process"
  %l229 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %rv = alloca { i32, %"std/os:Process" }
  %t21 = alloca { i64, [2 x i64] }, align 8
  %t87 = alloca { i64, [2 x i64] }, align 8
  %t146 = alloca { i64, [2 x i64] }, align 8
  %t214 = alloca { i64, [2 x i64] }, align 8
  %t386 = alloca { i64, [2 x i64] }, align 8
  store { i64, ptr } %a0, ptr %l0
  store i1 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d32, i32 0, i32 1) }, ptr %l31, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t7, ptr %l32, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l33, !tbaa !24
  %t10 = load i64, ptr %l33, !tbaa !24
  %t11 = mul i64 %t10, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l34, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l33, !tbaa !24
  %t20 = mul i64 %t19, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %t18, i64 %t20, i1 false)
  store { i64, [2 x i64] } zeroinitializer, ptr %t21
  %t22 = getelementptr { i64, [2 x i64] }, ptr %t21, i32 0, i32 0
  store i64 6, ptr %t22
  %t23 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t24 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t23, 0
  %t25 = getelementptr { i64, [2 x i64] }, ptr %t21, i32 0, i32 1
  store { { i64, ptr } } %t24, ptr %t25
  %t26 = load { i64, [2 x i64] }, ptr %t21
  store { i64, [2 x i64] } %t26, ptr %l35
  %t27 = call ptr @__olang_errpay_push()
  %t28 = ptrtoint ptr %t27 to i64
  store i64 %t28, ptr %l36, !tbaa !24
  %t29 = load i64, ptr %l36
  %t30 = inttoptr i64 %t29 to ptr
  %t32 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fos_3aError_24payload(ptr %t30, ptr %l35)
  store { i64, [2 x i64] } %t32, ptr %l38
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t33 = load { i64, [2 x i64] }, ptr %l38
  %t34 = load i64, ptr %l36
  %t35 = inttoptr i64 %t34 to ptr
  %t36 = call ptr @__olang_scope_alloc_a(ptr %t35, i64 24, i64 8)
  store { i64, [2 x i64] } %t33, ptr %t36
  call void @__olang_errpay_set(ptr %t36)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t39 = insertvalue { i32, %"std/os:Process" } zeroinitializer, i32 65542, 0
  store { i32, %"std/os:Process" } %t39, ptr %rv
  br label %ret
bb4:
  store i64 0, ptr %l4, !tbaa !24
  %t40 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t40, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  store i64 %t44, ptr %l7, !tbaa !24
  br label %bb5
bb5:
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l7, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb6, label %bb7
bb6:
  br label %bb18
bb7:
  br label %bb8
bb8:
  %t54 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t54, ptr %l48, !tbaa !27
  %t55 = load i64, ptr %l6, !tbaa !24
  %t57 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr { i64, ptr }, ptr %t58, i64 %t55
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !37
  store { i64, ptr } %t60, ptr %l8, !tbaa !27
  store i1 true, ptr %l9, !tbaa !21
  %t62 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t64 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %t62, i8 0)
  %t65 = extractvalue { i32, i64 } %t64, 1
  %t66 = extractvalue { i32, i64 } %t64, 0
  store i32 %t66, ptr %l54
  %t67 = icmp ne i32 %t66, 0
  br i1 %t67, label %bb10, label %ok.68, !prof !99
ok.68:
  store i64 %t65, ptr %l53
  br label %bb9
bb9:
  %t69 = load i64, ptr %l53, !tbaa !24
  store i64 %t69, ptr %l51, !tbaa !24
  br label %bb12
bb10:
  br label %bb11
bb11:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb12
bb12:
  %t70 = load i1, ptr %l9, !tbaa !21
  br i1 %t70, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s5
  %t72 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t72, ptr %l57, !tbaa !27
  %t74 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t74, 0
  store i64 %t75, ptr %l58, !tbaa !24
  %t76 = load i64, ptr %l58, !tbaa !24
  %t77 = mul i64 %t76, 1
  %t78 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t77)
  %t79 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t78, 1
  store { i64, ptr } %t80, ptr %l59, !tbaa !27
  %t81 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = load i64, ptr %l58, !tbaa !24
  %t86 = mul i64 %t85, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t82, ptr %t84, i64 %t86, i1 false)
  store { i64, [2 x i64] } zeroinitializer, ptr %t87
  %t88 = getelementptr { i64, [2 x i64] }, ptr %t87, i32 0, i32 0
  store i64 6, ptr %t88
  %t89 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t90 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t89, 0
  %t91 = getelementptr { i64, [2 x i64] }, ptr %t87, i32 0, i32 1
  store { { i64, ptr } } %t90, ptr %t91
  %t92 = load { i64, [2 x i64] }, ptr %t87
  store { i64, [2 x i64] } %t92, ptr %l60
  %t93 = call ptr @__olang_errpay_push()
  %t94 = ptrtoint ptr %t93 to i64
  store i64 %t94, ptr %l61, !tbaa !24
  %t95 = load i64, ptr %l61
  %t96 = inttoptr i64 %t95 to ptr
  %t98 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fos_3aError_24payload(ptr %t96, ptr %l60)
  store { i64, [2 x i64] } %t98, ptr %l63
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t99 = load { i64, [2 x i64] }, ptr %l63
  %t100 = load i64, ptr %l61
  %t101 = inttoptr i64 %t100 to ptr
  %t102 = call ptr @__olang_scope_alloc_a(ptr %t101, i64 24, i64 8)
  store { i64, [2 x i64] } %t99, ptr %t102
  call void @__olang_errpay_set(ptr %t102)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t105 = insertvalue { i32, %"std/os:Process" } zeroinitializer, i32 65542, 0
  store { i32, %"std/os:Process" } %t105, ptr %rv
  br label %ret
bb16:
  %t106 = load i64, ptr %l4, !tbaa !24
  %t107 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t107, 0
  %t111 = add i64 %t109, 1
  %t114 = add i64 %t106, %t111
  store i64 %t114, ptr %l4, !tbaa !24
  br label %bb17
bb17:
  %t116 = load i64, ptr %l6, !tbaa !24
  %t119 = add i64 %t116, 1
  store i64 %t119, ptr %l6, !tbaa !24
  br label %bb5
bb18:
  store i1 true, ptr %l10, !tbaa !21
  %t121 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t123 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v2, { i64, ptr } %t121, i8 0)
  %t124 = extractvalue { i32, i64 } %t123, 1
  %t125 = extractvalue { i32, i64 } %t123, 0
  store i32 %t125, ptr %l77
  %t126 = icmp ne i32 %t125, 0
  br i1 %t126, label %bb20, label %ok.127, !prof !99
ok.127:
  store i64 %t124, ptr %l76
  br label %bb19
bb19:
  %t128 = load i64, ptr %l76, !tbaa !24
  store i64 %t128, ptr %l74, !tbaa !24
  br label %bb22
bb20:
  br label %bb21
bb21:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb22
bb22:
  %t129 = load i1, ptr %l10, !tbaa !21
  br i1 %t129, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s8
  %t131 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t131, ptr %l80, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 0
  store i64 %t134, ptr %l81, !tbaa !24
  %t135 = load i64, ptr %l81, !tbaa !24
  %t136 = mul i64 %t135, 1
  %t137 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t136)
  %t138 = insertvalue { i64, ptr } undef, i64 %t135, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t137, 1
  store { i64, ptr } %t139, ptr %l82, !tbaa !27
  %t140 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = load i64, ptr %l81, !tbaa !24
  %t145 = mul i64 %t144, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t141, ptr %t143, i64 %t145, i1 false)
  store { i64, [2 x i64] } zeroinitializer, ptr %t146
  %t147 = getelementptr { i64, [2 x i64] }, ptr %t146, i32 0, i32 0
  store i64 6, ptr %t147
  %t148 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t149 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t148, 0
  %t150 = getelementptr { i64, [2 x i64] }, ptr %t146, i32 0, i32 1
  store { { i64, ptr } } %t149, ptr %t150
  %t151 = load { i64, [2 x i64] }, ptr %t146
  store { i64, [2 x i64] } %t151, ptr %l83
  %t152 = call ptr @__olang_errpay_push()
  %t153 = ptrtoint ptr %t152 to i64
  store i64 %t153, ptr %l84, !tbaa !24
  %t154 = load i64, ptr %l84
  %t155 = inttoptr i64 %t154 to ptr
  %t157 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fos_3aError_24payload(ptr %t155, ptr %l83)
  store { i64, [2 x i64] } %t157, ptr %l86
  br label %bb25
bb24:
  br label %bb26
bb25:
  %t158 = load { i64, [2 x i64] }, ptr %l86
  %t159 = load i64, ptr %l84
  %t160 = inttoptr i64 %t159 to ptr
  %t161 = call ptr @__olang_scope_alloc_a(ptr %t160, i64 24, i64 8)
  store { i64, [2 x i64] } %t158, ptr %t161
  call void @__olang_errpay_set(ptr %t161)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t164 = insertvalue { i32, %"std/os:Process" } zeroinitializer, i32 65542, 0
  store { i32, %"std/os:Process" } %t164, ptr %rv
  br label %ret
bb26:
  %t165 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t167 = extractvalue { i64, ptr } %t165, 0
  %t169 = icmp sgt i64 %t167, 0
  br i1 %t169, label %bb27, label %bb28
bb27:
  %t171 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t173 = call { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %v2, { i64, ptr } %t171)
  %t174 = extractvalue { i32, %"std/os:FileInfo" } %t173, 1
  %t175 = extractvalue { i32, %"std/os:FileInfo" } %t173, 0
  store i32 %t175, ptr %l95
  %t176 = icmp ne i32 %t175, 0
  br i1 %t176, label %bb30, label %ok.177, !prof !99
ok.177:
  store %"std/os:FileInfo" %t174, ptr %l94
  br label %bb29
bb28:
  br label %bb36
bb29:
  %t178 = load %"std/os:FileInfo", ptr %l94
  store %"std/os:FileInfo" %t178, ptr %l92
  br label %bb31
bb30:
  %t179 = load i32, ptr %l95, !tbaa !23
  %t180 = lshr i32 %t179, 16
  %t181 = and i32 %t179, 65535
  %t182 = icmp eq i32 %t180, 1
  %t183 = select i1 %t182, i32 1, i32 0
  %t184 = icmp eq i32 %t179, 0
  %t185 = shl i32 %t183, 16
  %t186 = or i32 %t185, %t181
  %t187 = select i1 %t184, i32 0, i32 %t186
  call void @__olang_scope_close(ptr %s0)
  %t189 = insertvalue { i32, %"std/os:Process" } zeroinitializer, i32 %t187, 0
  store { i32, %"std/os:Process" } %t189, ptr %rv
  br label %ret
bb31:
  %t190 = load %"std/os:FileInfo", ptr %l92
  store %"std/os:FileInfo" %t190, ptr %l11
  %t191 = getelementptr %"std/os:FileInfo", ptr %l11, i32 0, i32 0
  %t192 = load i32, ptr %t191, !range !{i32 0, i32 3}
  %t194 = trunc i64 1 to i32
  %t195 = icmp eq i32 %t192, %t194
  %t197 = xor i1 %t195, true
  br i1 %t197, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s10
  %t199 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t199, ptr %l101, !tbaa !27
  %t201 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t202 = extractvalue { i64, ptr } %t201, 0
  store i64 %t202, ptr %l102, !tbaa !24
  %t203 = load i64, ptr %l102, !tbaa !24
  %t204 = mul i64 %t203, 1
  %t205 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t204)
  %t206 = insertvalue { i64, ptr } undef, i64 %t203, 0
  %t207 = insertvalue { i64, ptr } %t206, ptr %t205, 1
  store { i64, ptr } %t207, ptr %l103, !tbaa !27
  %t208 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t211 = load ptr, ptr %t210, !tbaa !27
  %t212 = load i64, ptr %l102, !tbaa !24
  %t213 = mul i64 %t212, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t209, ptr %t211, i64 %t213, i1 false)
  store { i64, [2 x i64] } zeroinitializer, ptr %t214
  %t215 = getelementptr { i64, [2 x i64] }, ptr %t214, i32 0, i32 0
  store i64 3, ptr %t215
  %t216 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t217 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t216, 0
  %t218 = getelementptr { i64, [2 x i64] }, ptr %t214, i32 0, i32 1
  store { { i64, ptr } } %t217, ptr %t218
  %t219 = load { i64, [2 x i64] }, ptr %t214
  store { i64, [2 x i64] } %t219, ptr %l104
  %t220 = call ptr @__olang_errpay_push()
  %t221 = ptrtoint ptr %t220 to i64
  store i64 %t221, ptr %l105, !tbaa !24
  %t222 = load i64, ptr %l105
  %t223 = inttoptr i64 %t222 to ptr
  %t225 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fos_3aError_24payload(ptr %t223, ptr %l104)
  store { i64, [2 x i64] } %t225, ptr %l107
  br label %bb34
bb33:
  br label %bb35
bb34:
  %t226 = load { i64, [2 x i64] }, ptr %l107
  %t227 = load i64, ptr %l105
  %t228 = inttoptr i64 %t227 to ptr
  %t229 = call ptr @__olang_scope_alloc_a(ptr %t228, i64 24, i64 8)
  store { i64, [2 x i64] } %t226, ptr %t229
  call void @__olang_errpay_set(ptr %t229)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t232 = insertvalue { i32, %"std/os:Process" } zeroinitializer, i32 65539, 0
  store { i32, %"std/os:Process" } %t232, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t233 = load i64, ptr %l4, !tbaa !24
  store i64 %t233, ptr %l110, !tbaa !24
  %t234 = load i64, ptr %l110, !tbaa !24
  %t235 = icmp sge i64 %t234, 0
  br i1 %t235, label %bb37, label %bb38
bb37:
  %t237 = load i64, ptr %l110, !tbaa !24
  %t238 = mul i64 %t237, 1
  %t239 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t238)
  %t240 = insertvalue { i64, ptr } undef, i64 %t237, 0
  %t241 = insertvalue { i64, ptr } %t240, ptr %t239, 1
  store { i64, ptr } %t241, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t243 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t243, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t245 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t247 = extractvalue { i64, ptr } %t245, 0
  store i64 %t247, ptr %l16, !tbaa !24
  %t249 = load i64, ptr %l16, !tbaa !24
  %t250 = sub i64 %t249, 1
  store i64 %t250, ptr %l116, !tbaa !24
  %t251 = load i64, ptr %l16, !tbaa !24
  %t252 = icmp slt i64 %t251, 2147483648
  %t253 = load i64, ptr %l15, !tbaa !24
  %t254 = icmp sge i64 %t253, 0
  %t257 = and i1 %t252, %t254
  store i1 %t257, ptr %l119, !tbaa !21
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_ae615ff442418127_414de4f669869a8b)
  unreachable
bb39:
  %t258 = load i64, ptr %l15, !tbaa !24
  %t259 = load i64, ptr %l16, !tbaa !24
  %t262 = icmp slt i64 %t258, %t259
  %t264 = xor i1 %t262, true
  br i1 %t264, label %bb40, label %bb41
bb40:
  br label %bb50
bb41:
  br label %bb42
bb42:
  %t266 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t266, ptr %l124, !tbaa !27
  %t267 = load i64, ptr %l15, !tbaa !24
  %t269 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !27
  %t271 = getelementptr { i64, ptr }, ptr %t270, i64 %t267
  %t272 = load { i64, ptr }, ptr %t271, !tbaa !37
  store { i64, ptr } %t272, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t276 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t278 = extractvalue { i64, ptr } %t276, 0
  store i64 %t278, ptr %l20, !tbaa !24
  %t280 = load i64, ptr %l20, !tbaa !24
  %t281 = sub i64 %t280, 1
  store i64 %t281, ptr %l130, !tbaa !24
  %t282 = load i64, ptr %l20, !tbaa !24
  %t283 = icmp slt i64 %t282, 2147483648
  %t284 = load i64, ptr %l19, !tbaa !24
  %t285 = icmp sge i64 %t284, 0
  %t288 = and i1 %t283, %t285
  store i1 %t288, ptr %l133, !tbaa !21
  br label %bb43
bb43:
  %t289 = load i64, ptr %l19, !tbaa !24
  %t290 = load i64, ptr %l20, !tbaa !24
  %t293 = icmp slt i64 %t289, %t290
  %t295 = xor i1 %t293, true
  br i1 %t295, label %bb44, label %bb45
bb44:
  br label %bb48
bb45:
  br label %bb46
bb46:
  %t297 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t297, ptr %l138, !tbaa !27
  %t298 = load i64, ptr %l19, !tbaa !24
  %t300 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t301 = load ptr, ptr %t300, !tbaa !27
  %t302 = getelementptr i8, ptr %t301, i64 %t298
  %t303 = load i8, ptr %t302, !tbaa !32
  %t305 = load i64, ptr %l13, !tbaa !24
  %t310 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t311 = load ptr, ptr %t310, !tbaa !27
  %t312 = getelementptr i8, ptr %t311, i64 %t305
  store i8 %t303, ptr %t312, !tbaa !32
  %t313 = load i64, ptr %l13, !tbaa !24
  %t316 = add i64 %t313, 1
  store i64 %t316, ptr %l13, !tbaa !24
  br label %bb47
bb47:
  %t318 = load i64, ptr %l19, !tbaa !24
  %t321 = add i64 %t318, 1
  store i64 %t321, ptr %l19, !tbaa !24
  br label %bb43
bb48:
  %t323 = load i64, ptr %l13, !tbaa !24
  %t326 = add i64 %t323, 1
  store i64 %t326, ptr %l13, !tbaa !24
  br label %bb49
bb49:
  %t328 = load i64, ptr %l15, !tbaa !24
  %t331 = add i64 %t328, 1
  store i64 %t331, ptr %l15, !tbaa !24
  br label %bb39
bb50:
  %t333 = call { i32, i32 } @std_2fos_2ememFile()
  %t334 = extractvalue { i32, i32 } %t333, 1
  %t335 = extractvalue { i32, i32 } %t333, 0
  store i32 %t335, ptr %l158
  %t336 = icmp ne i32 %t335, 0
  br i1 %t336, label %bb52, label %ok.337, !prof !99
ok.337:
  store i32 %t334, ptr %l157
  br label %bb51
bb51:
  %t338 = load i32, ptr %l157, !tbaa !23
  store i32 %t338, ptr %l156, !tbaa !23
  br label %bb53
bb52:
  %t339 = load i32, ptr %l158, !tbaa !23
  %t340 = lshr i32 %t339, 16
  %t341 = and i32 %t339, 65535
  %t342 = icmp eq i32 %t340, 1
  %t343 = select i1 %t342, i32 1, i32 0
  %t344 = icmp eq i32 %t339, 0
  %t345 = shl i32 %t343, 16
  %t346 = or i32 %t345, %t341
  %t347 = select i1 %t344, i32 0, i32 %t346
  call void @__olang_scope_close(ptr %s0)
  %t349 = insertvalue { i32, %"std/os:Process" } zeroinitializer, i32 %t347, 0
  store { i32, %"std/os:Process" } %t349, ptr %rv
  br label %ret
bb53:
  %t350 = load i32, ptr %l156, !tbaa !23
  store i32 %t350, ptr %l22, !tbaa !23
  %t351 = load i32, ptr %l22, !tbaa !23
  %t355 = call i32 @std_2fio_2eWrite(ptr %v1, i32 %t351, { i64, ptr } %a1)
  store i32 %t355, ptr %l162
  %t356 = icmp ne i32 %t355, 0
  br i1 %t356, label %bb55, label %ok.357, !prof !99
ok.357:
  br label %bb54
bb54:
  br label %bb61
bb55:
  %t358 = load i32, ptr %l162, !tbaa !23
  %t359 = ashr i32 %t358, 16
  %t361 = icmp eq i32 %t359, 1
  store i1 %t361, ptr %l164, !tbaa !21
  %t362 = load i32, ptr %l162, !tbaa !23
  %t363 = ashr i32 %t362, 16
  %t365 = icmp eq i32 %t363, 1
  br i1 %t365, label %bb56, label %bb57
bb56:
  call void @__olang_errpay_pop()
  br label %bb57
bb57:
  br label %bb58
bb58:
  store %olang.scope zeroinitializer, ptr %s17
  %t367 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t367, ptr %l167, !tbaa !27
  %t368 = getelementptr { i64, ptr }, ptr %l167, i32 0, i32 1
  %t369 = load ptr, ptr %t368, !tbaa !27
  %t370 = getelementptr { i64, ptr }, ptr %t369, i64 0
  %t371 = load { i64, ptr }, ptr %t370, !tbaa !37
  store { i64, ptr } %t371, ptr %l169, !tbaa !27
  %t373 = load { i64, ptr }, ptr %l169, !tbaa !27
  %t374 = extractvalue { i64, ptr } %t373, 0
  store i64 %t374, ptr %l170, !tbaa !24
  %t375 = load i64, ptr %l170, !tbaa !24
  %t376 = mul i64 %t375, 1
  %t377 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t376)
  %t378 = insertvalue { i64, ptr } undef, i64 %t375, 0
  %t379 = insertvalue { i64, ptr } %t378, ptr %t377, 1
  store { i64, ptr } %t379, ptr %l171, !tbaa !27
  %t380 = getelementptr { i64, ptr }, ptr %l171, i32 0, i32 1
  %t381 = load ptr, ptr %t380, !tbaa !27
  %t382 = getelementptr { i64, ptr }, ptr %l169, i32 0, i32 1
  %t383 = load ptr, ptr %t382, !tbaa !27
  %t384 = load i64, ptr %l170, !tbaa !24
  %t385 = mul i64 %t384, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t381, ptr %t383, i64 %t385, i1 false)
  store { i64, [2 x i64] } zeroinitializer, ptr %t386
  %t387 = getelementptr { i64, [2 x i64] }, ptr %t386, i32 0, i32 0
  store i64 6, ptr %t387
  %t388 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t389 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t388, 0
  %t390 = getelementptr { i64, [2 x i64] }, ptr %t386, i32 0, i32 1
  store { { i64, ptr } } %t389, ptr %t390
  %t391 = load { i64, [2 x i64] }, ptr %t386
  store { i64, [2 x i64] } %t391, ptr %l172
  %t392 = call ptr @__olang_errpay_push()
  %t393 = ptrtoint ptr %t392 to i64
  store i64 %t393, ptr %l173, !tbaa !24
  %t394 = load i64, ptr %l173
  %t395 = inttoptr i64 %t394 to ptr
  %t397 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fos_3aError_24payload(ptr %t395, ptr %l172)
  store { i64, [2 x i64] } %t397, ptr %l175
  br label %bb59
bb59:
  %t398 = load { i64, [2 x i64] }, ptr %l175
  %t399 = load i64, ptr %l173
  %t400 = inttoptr i64 %t399 to ptr
  %t401 = call ptr @__olang_scope_alloc_a(ptr %t400, i64 24, i64 8)
  store { i64, [2 x i64] } %t398, ptr %t401
  call void @__olang_errpay_set(ptr %t401)
  store i32 65542, ptr %l177, !tbaa !23
  call void @__olang_scope_close(ptr %s17)
  %t403 = load i32, ptr %l22, !tbaa !23
  %t405 = call i32 @close(i32 %t403)
  store i32 %t405, ptr %l179
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s0)
  %t406 = load i32, ptr %l177, !tbaa !23
  %t407 = insertvalue { i32, %"std/os:Process" } zeroinitializer, i32 %t406, 0
  store { i32, %"std/os:Process" } %t407, ptr %rv
  br label %ret
bb61:
  %t408 = load i32, ptr %l22, !tbaa !23
  %t410 = call i64 @lseek(i32 %t408, i64 0, i32 0)
  store i64 %t410, ptr %l181
  br label %bb62
bb62:
  store i32 -1, ptr %l23, !tbaa !23
  store i32 -1, ptr %l24, !tbaa !23
  %t411 = load i1, ptr %l2, !tbaa !21
  br i1 %t411, label %bb63, label %bb64
bb63:
  %t413 = call { i32, i32 } @std_2fos_2ememFile()
  %t414 = extractvalue { i32, i32 } %t413, 1
  %t415 = extractvalue { i32, i32 } %t413, 0
  store i32 %t415, ptr %l185
  %t416 = icmp ne i32 %t415, 0
  br i1 %t416, label %bb66, label %ok.417, !prof !99
ok.417:
  store i32 %t414, ptr %l184
  br label %bb65
bb64:
  br label %bb78
bb65:
  %t418 = load i32, ptr %l184, !tbaa !23
  store i32 %t418, ptr %l183, !tbaa !23
  br label %bb68
bb66:
  %t419 = load i32, ptr %l185, !tbaa !23
  %t420 = lshr i32 %t419, 16
  %t421 = and i32 %t419, 65535
  %t422 = icmp eq i32 %t420, 1
  %t423 = select i1 %t422, i32 1, i32 0
  %t424 = icmp eq i32 %t419, 0
  %t425 = shl i32 %t423, 16
  %t426 = or i32 %t425, %t421
  %t427 = select i1 %t424, i32 0, i32 %t426
  store i32 %t427, ptr %l186, !tbaa !23
  %t428 = load i32, ptr %l22, !tbaa !23
  %t430 = call i32 @close(i32 %t428)
  store i32 %t430, ptr %l188
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s0)
  %t431 = load i32, ptr %l186, !tbaa !23
  %t432 = insertvalue { i32, %"std/os:Process" } zeroinitializer, i32 %t431, 0
  store { i32, %"std/os:Process" } %t432, ptr %rv
  br label %ret
bb68:
  %t433 = load i32, ptr %l183, !tbaa !23
  store i32 %t433, ptr %l23, !tbaa !23
  %t434 = call i32 @std_2fos_2ememfd()
  store i32 %t434, ptr %l189
  br label %bb69
bb69:
  %t435 = load i32, ptr %l189, !tbaa !23
  store i32 %t435, ptr %l25, !tbaa !23
  %t436 = load i32, ptr %l25, !tbaa !23
  %t438 = icmp slt i32 %t436, 0
  br i1 %t438, label %bb70, label %bb71
bb70:
  store %olang.scope zeroinitializer, ptr %s21
  %t440 = load i32, ptr %l23, !tbaa !23
  store i32 %t440, ptr %l192, !tbaa !23
  %t441 = call i32 @__olang_err()
  store i32 %t441, ptr %l193
  br label %bb72
bb71:
  br label %bb77
bb72:
  %t442 = load i32, ptr %l192, !tbaa !23
  %t443 = load i32, ptr %l193, !tbaa !23
  %t444 = call i32 @std_2fos_2ecloseAndRaise(ptr %s21, i32 %t442, i32 %t443, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i32 %t444, ptr %l194
  %t445 = icmp ne i32 %t444, 0
  br i1 %t445, label %bb74, label %ok.446, !prof !99
ok.446:
  br label %bb73
bb73:
  br label %bb76
bb74:
  %t447 = load i32, ptr %l194, !tbaa !23
  %t448 = lshr i32 %t447, 16
  %t449 = and i32 %t447, 65535
  %t450 = icmp eq i32 %t448, 1
  %t451 = select i1 %t450, i32 1, i32 0
  %t452 = icmp eq i32 %t447, 0
  %t453 = shl i32 %t451, 16
  %t454 = or i32 %t453, %t449
  %t455 = select i1 %t452, i32 0, i32 %t454
  store i32 %t455, ptr %l195, !tbaa !23
  call void @__olang_scope_close(ptr %s21)
  %t456 = load i32, ptr %l22, !tbaa !23
  %t458 = call i32 @close(i32 %t456)
  store i32 %t458, ptr %l197
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s0)
  %t459 = load i32, ptr %l195, !tbaa !23
  %t460 = insertvalue { i32, %"std/os:Process" } zeroinitializer, i32 %t459, 0
  store { i32, %"std/os:Process" } %t460, ptr %rv
  br label %ret
bb76:
  call void @__olang_scope_close(ptr %s21)
  br label %bb77
bb77:
  %t461 = load i32, ptr %l25, !tbaa !23
  store i32 %t461, ptr %l24, !tbaa !23
  br label %bb78
bb78:
  %t463 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t464 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t465 = load i32, ptr %l22, !tbaa !23
  %t466 = load i32, ptr %l23, !tbaa !23
  %t467 = load i32, ptr %l24, !tbaa !23
  %t468 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t470 = extractvalue { i64, ptr } %t468, 1
  %t471 = extractvalue { i64, ptr } %t468, 0
  %t472 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t473 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t474 = add i64 %t471, %t473
  %t475 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t474)
  call void @olang_textcopy(ptr %t475, ptr %t470, i64 %t471)
  %t476 = getelementptr i8, ptr %t475, i64 %t471
  call void @olang_textcopy(ptr %t476, ptr %t472, i64 %t473)
  %t477 = insertvalue { i64, ptr } undef, i64 %t474, 0
  %t478 = insertvalue { i64, ptr } %t477, ptr %t475, 1
  %t486 = call i32 @std_2fos_2estartProgram(ptr %v0, ptr %s0, ptr %s0, { i64, ptr } %t463, { i64, ptr } %t464, i32 %t465, i32 %t466, i32 %t467, { i64, ptr } %t478)
  store i32 %t486, ptr %l207
  br label %bb79
bb79:
  %t487 = load i32, ptr %l207, !tbaa !23
  store i32 %t487, ptr %l26, !tbaa !23
  %t488 = load i32, ptr %l26, !tbaa !23
  %t490 = icmp slt i32 %t488, 0
  br i1 %t490, label %bb80, label %bb81
bb80:
  %t492 = call i32 @__olang_err()
  store i32 %t492, ptr %l210
  br label %bb82
bb81:
  br label %bb92
bb82:
  %t493 = load i32, ptr %l210, !tbaa !23
  store i32 %t493, ptr %l27, !tbaa !23
  %t494 = load i1, ptr %l2, !tbaa !21
  br i1 %t494, label %bb83, label %bb84
bb83:
  %t496 = load i32, ptr %l23, !tbaa !23
  %t498 = call i32 @close(i32 %t496)
  store i32 %t498, ptr %l213
  br label %bb85
bb84:
  br label %bb87
bb85:
  %t499 = load i32, ptr %l24, !tbaa !23
  %t501 = call i32 @close(i32 %t499)
  store i32 %t501, ptr %l215
  br label %bb86
bb86:
  br label %bb87
bb87:
  %t502 = load i32, ptr %l27, !tbaa !23
  %t503 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t503, ptr %l217, !tbaa !27
  %t504 = getelementptr { i64, ptr }, ptr %l217, i32 0, i32 1
  %t505 = load ptr, ptr %t504, !tbaa !27
  %t506 = getelementptr { i64, ptr }, ptr %t505, i64 0
  %t507 = load { i64, ptr }, ptr %t506, !tbaa !37
  %t510 = call i32 @std_2fos_2eraise(ptr %v0, i32 %t502, { i64, ptr } %t507)
  store i32 %t510, ptr %l219
  %t511 = icmp ne i32 %t510, 0
  br i1 %t511, label %bb89, label %ok.512, !prof !99
ok.512:
  br label %bb88
bb88:
  br label %bb91
bb89:
  %t513 = load i32, ptr %l219, !tbaa !23
  %t514 = lshr i32 %t513, 16
  %t515 = and i32 %t513, 65535
  %t516 = icmp eq i32 %t514, 1
  %t517 = select i1 %t516, i32 1, i32 0
  %t518 = icmp eq i32 %t513, 0
  %t519 = shl i32 %t517, 16
  %t520 = or i32 %t519, %t515
  %t521 = select i1 %t518, i32 0, i32 %t520
  store i32 %t521, ptr %l220, !tbaa !23
  %t522 = load i32, ptr %l22, !tbaa !23
  %t524 = call i32 @close(i32 %t522)
  store i32 %t524, ptr %l222
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s0)
  %t525 = load i32, ptr %l220, !tbaa !23
  %t526 = insertvalue { i32, %"std/os:Process" } zeroinitializer, i32 %t525, 0
  store { i32, %"std/os:Process" } %t526, ptr %rv
  br label %ret
bb91:
  br label %bb92
bb92:
  %t527 = load i32, ptr %l26, !tbaa !23
  %t528 = load i32, ptr %l23, !tbaa !23
  %t529 = load i32, ptr %l24, !tbaa !23
  %t530 = load i1, ptr %l2, !tbaa !21
  %t535 = call %"std/os:Process" @std_2fos_3aProcess_2ector(ptr %s0, i32 %t527, i32 %t528, i32 %t529, i1 %t530)
  store %"std/os:Process" %t535, ptr %l227
  br label %bb93
bb93:
  %t536 = load i32, ptr %l22, !tbaa !23
  %t538 = call i32 @close(i32 %t536)
  store i32 %t538, ptr %l229
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s0)
  %t539 = load %"std/os:Process", ptr %l227
  %t540 = insertvalue { i32, %"std/os:Process" } zeroinitializer, %"std/os:Process" %t539, 1
  store { i32, %"std/os:Process" } %t540, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/os:Process" }, ptr %rv
  ret { i32, %"std/os:Process" } %rr
}

define dso_local { i64, ptr } @std_2fos_2eQuote(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l35 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l55 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) }, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t5 = load i64, ptr %l4, !tbaa !24
  %t6 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l5, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l17, !tbaa !24
  store i64 %t31, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l14, !tbaa !24
  store i64 %t32, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t33 = load i64, ptr %l7, !tbaa !24
  %t34 = load i64, ptr %l6, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  br label %bb21
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l3, !tbaa !24
  %t42 = load i64, ptr %l7, !tbaa !24
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l8, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t51, ptr %l35, !tbaa !27
  %t52 = load i64, ptr %l8, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i8, ptr %t55, i64 %t52
  %t57 = load i8, ptr %t56, !tbaa !32
  %t59 = icmp eq i8 %t57, 39
  br i1 %t59, label %bb11, label %bb12
bb11:
  %t61 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t61, ptr %l39, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t62, ptr %l40, !tbaa !27
  %t63 = load i64, ptr %l2, !tbaa !24
  store i64 %t63, ptr %l41, !tbaa !24
  %t64 = load i64, ptr %l8, !tbaa !24
  store i64 %t64, ptr %l42, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  store i64 %t66, ptr %l43, !tbaa !24
  %t67 = load i64, ptr %l41, !tbaa !24
  %t68 = icmp sge i64 %t67, 0
  br i1 %t68, label %bb13, label %bb14
bb12:
  br label %bb19
bb13:
  %t70 = load i64, ptr %l41, !tbaa !24
  %t71 = load i64, ptr %l42, !tbaa !24
  %t72 = icmp sle i64 %t70, %t71
  br i1 %t72, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_3ae06a7cd351f714_4bcb8792cbdf34a0)
  unreachable
bb15:
  %t74 = load i64, ptr %l42, !tbaa !24
  %t75 = load i64, ptr %l43, !tbaa !24
  %t76 = icmp sle i64 %t74, %t75
  br i1 %t76, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_3ae06a7cd351f714_4bcb8792cbdf34a0)
  unreachable
bb17:
  %t78 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = load i64, ptr %l41, !tbaa !24
  %t81 = load i64, ptr %l42, !tbaa !24
  %t82 = getelementptr i8, ptr %t79, i64 %t80
  %t83 = sub i64 %t81, %t80
  %t84 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t82, 1
  %t86 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t90 = extractvalue { i64, ptr } %t85, 1
  %t91 = extractvalue { i64, ptr } %t85, 0
  %t92 = add i64 %t88, %t91
  %t93 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t94 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t95 = add i64 %t92, %t94
  %t96 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t95)
  call void @olang_textcopy(ptr %t96, ptr %t87, i64 %t88)
  %t97 = getelementptr i8, ptr %t96, i64 %t88
  call void @olang_textcopy(ptr %t97, ptr %t90, i64 %t91)
  %t98 = getelementptr i8, ptr %t97, i64 %t91
  call void @olang_textcopy(ptr %t98, ptr %t93, i64 %t94)
  %t99 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t96, 1
  store { i64, ptr } %t100, ptr %l1, !tbaa !27
  %t103 = load i64, ptr %l8, !tbaa !24
  %t105 = add i64 %t103, 1
  store i64 %t105, ptr %l2, !tbaa !24
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_3ae06a7cd351f714_4bcb8792cbdf34a0)
  unreachable
bb19:
  br label %bb20
bb20:
  %t107 = load i64, ptr %l7, !tbaa !24
  %t110 = add i64 %t107, 1
  store i64 %t110, ptr %l7, !tbaa !24
  br label %bb7
bb21:
  %t112 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t112, ptr %l55, !tbaa !27
  %t113 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t113, ptr %l56, !tbaa !27
  %t114 = load i64, ptr %l2, !tbaa !24
  store i64 %t114, ptr %l57, !tbaa !24
  %t115 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t115, 0
  store i64 %t118, ptr %l60, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t119, 0
  store i64 %t120, ptr %l61, !tbaa !24
  %t121 = load i64, ptr %l57, !tbaa !24
  %t122 = icmp sge i64 %t121, 0
  br i1 %t122, label %bb22, label %bb23
bb22:
  %t124 = load i64, ptr %l57, !tbaa !24
  %t125 = load i64, ptr %l60, !tbaa !24
  %t126 = icmp sle i64 %t124, %t125
  br i1 %t126, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_63ca89910fe1f481_50e57e01f8d90efd)
  unreachable
bb24:
  %t128 = load i64, ptr %l60, !tbaa !24
  %t129 = load i64, ptr %l61, !tbaa !24
  %t130 = icmp sle i64 %t128, %t129
  br i1 %t130, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_63ca89910fe1f481_50e57e01f8d90efd)
  unreachable
bb26:
  %t132 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = load i64, ptr %l57, !tbaa !24
  %t135 = load i64, ptr %l60, !tbaa !24
  %t136 = getelementptr i8, ptr %t133, i64 %t134
  %t137 = sub i64 %t135, %t134
  %t138 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t136, 1
  %t140 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t140, 1
  %t142 = extractvalue { i64, ptr } %t140, 0
  %t144 = extractvalue { i64, ptr } %t139, 1
  %t145 = extractvalue { i64, ptr } %t139, 0
  %t146 = add i64 %t142, %t145
  %t147 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t148 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t149 = add i64 %t146, %t148
  %t150 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t149)
  call void @olang_textcopy(ptr %t150, ptr %t141, i64 %t142)
  %t151 = getelementptr i8, ptr %t150, i64 %t142
  call void @olang_textcopy(ptr %t151, ptr %t144, i64 %t145)
  %t152 = getelementptr i8, ptr %t151, i64 %t145
  call void @olang_textcopy(ptr %t152, ptr %t147, i64 %t148)
  %t153 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t150, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t154, ptr %rv
  br label %ret
bb27:
  call void @__olang_check_failed(ptr @olang_loc_63ca89910fe1f481_50e57e01f8d90efd)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i32
  %l19 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l28 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t16 = alloca { { i64, ptr }, ptr }, align 8
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 1
  %t4 = extractvalue { i64, ptr } %t1, 0
  %t5 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t14 = getelementptr { { i64, ptr }, ptr }, ptr null, i32 1
  %t15 = ptrtoint ptr %t14 to i64
  %t17 = getelementptr { { i64, ptr }, ptr }, ptr %t16, i32 0, i32 0
  store { i64, ptr } %t11, ptr %t17, !tbaa !28
  call void @__olang_scope_escape(ptr %s0)
  %t19 = call ptr @__olang_scope_hold(ptr %s0)
  %t20 = getelementptr { { i64, ptr }, ptr }, ptr %t16, i32 0, i32 1
  store ptr %t19, ptr %t20, !tbaa !28
  %t21 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_39, 0
  %t22 = insertvalue { ptr, ptr } %t21, ptr %t16, 1
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t25 = extractvalue { ptr, ptr } %t22, 0
  %t26 = extractvalue { ptr, ptr } %t22, 1
  %t28 = call { i32, { i64, ptr } } @std_2fos_2ecopyOut(ptr %s0, ptr %v0, ptr %v1, ptr %t25, ptr %t26, { i64, ptr } %t23)
  %t29 = extractvalue { i32, { i64, ptr } } %t28, 1
  %t30 = extractvalue { i32, { i64, ptr } } %t28, 0
  store i32 %t30, ptr %l11
  %t31 = icmp ne i32 %t30, 0
  br i1 %t31, label %bb2, label %ok.32, !prof !99
ok.32:
  store { i64, ptr } %t29, ptr %l10
  br label %bb1
bb1:
  %t33 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t33, ptr %l6, !tbaa !27
  br label %bb3
bb2:
  %t34 = load i32, ptr %l11, !tbaa !23
  %t35 = lshr i32 %t34, 16
  %t36 = and i32 %t34, 65535
  %t37 = icmp eq i32 %t35, 1
  %t38 = select i1 %t37, i32 1, i32 0
  %t39 = icmp eq i32 %t34, 0
  %t40 = shl i32 %t38, 16
  %t41 = or i32 %t40, %t36
  %t42 = select i1 %t39, i32 0, i32 %t41
  call void @__olang_scope_close(ptr %s0)
  %t44 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t42, 0
  store { i32, { i64, ptr } } %t44, ptr %rv
  br label %ret
bb3:
  %t45 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t45, ptr %l2, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t46, 0
  %t50 = icmp eq i64 %t48, 0
  br i1 %t50, label %bb4, label %bb5
bb4:
  %t52 = icmp sge i64 0, 0
  br i1 %t52, label %bb6, label %bb7
bb5:
  br label %bb10
bb6:
  %t54 = icmp sle i64 0, 576460752303423487
  br i1 %t54, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_879ad2febb339b7d_10a4c06fe5c76379)
  unreachable
bb8:
  %t56 = mul i64 0, 16
  %t57 = insertvalue { i64, ptr } undef, i64 0, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  call void @__olang_scope_close(ptr %s0)
  %t60 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t58, 1
  store { i32, { i64, ptr } } %t60, ptr %rv
  br label %ret
bb9:
  call void @__olang_check_failed(ptr @olang_loc_879ad2febb339b7d_10a4c06fe5c76379)
  unreachable
bb10:
  %t61 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t61, ptr %l19, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t62, 0
  %t66 = sub i64 %t64, 1
  store i64 %t66, ptr %l22, !tbaa !24
  %t67 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 0
  store i64 %t68, ptr %l23, !tbaa !24
  %t69 = icmp sge i64 0, 0
  br i1 %t69, label %bb11, label %bb12
bb11:
  %t71 = load i64, ptr %l22, !tbaa !24
  %t72 = icmp sle i64 0, %t71
  br i1 %t72, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_2b89142fbf8fc460_df42bdef933d62c4)
  unreachable
bb13:
  %t74 = load i64, ptr %l22, !tbaa !24
  %t75 = load i64, ptr %l23, !tbaa !24
  %t76 = icmp sle i64 %t74, %t75
  br i1 %t76, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_2b89142fbf8fc460_df42bdef933d62c4)
  unreachable
bb15:
  %t78 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = load i64, ptr %l22, !tbaa !24
  %t81 = getelementptr i8, ptr %t79, i64 0
  %t82 = sub i64 %t80, 0
  %t83 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t81, 1
  %t86 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v1, ptr %s0, ptr %v1, { i64, ptr } %t84, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d40, i32 0, i32 1) })
  store { i64, ptr } %t86, ptr %l28
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_2b89142fbf8fc460_df42bdef933d62c4)
  unreachable
bb17:
  %t87 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t87, ptr %l3, !tbaa !27
  %t88 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t89 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_41, 0
  %t90 = insertvalue { ptr, ptr } %t89, ptr null, 1
  %t93 = extractvalue { ptr, ptr } %t90, 0
  %t94 = extractvalue { ptr, ptr } %t90, 1
  call void @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eSort_3cstd_2fprelu_H425a408f665c1f34766f6a10dd38435a(ptr %v1, ptr %s0, { i64, ptr } %t88, ptr %t93, ptr %t94)
  br label %bb18
bb18:
  %t95 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t97 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t95, 1
  store { i32, { i64, ptr } } %t97, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/os:File"
  %l2 = alloca i1
  %l3 = alloca i64
  %lp4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca [1 x i8]
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l23 = alloca i1
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, [2 x i64] }
  %l29 = alloca i64
  %l31 = alloca { i64, [2 x i64] }
  %l34 = alloca %"std/os:File"
  %l36 = alloca %"std/os:File"
  %l37 = alloca i32
  %l40 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l48 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i32
  %l54 = alloca i32
  %l60 = alloca i64
  %l61 = alloca i64
  %l66 = alloca { i64, ptr }
  %l67 = alloca i64
  %l68 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l77 = alloca i64
  %l80 = alloca i32
  %l82 = alloca i32
  %l83 = alloca i32
  %l88 = alloca i64
  %l92 = alloca i64
  %l94 = alloca { i64, ptr }
  %l102 = alloca i64
  %l105 = alloca i64
  %l114 = alloca i64
  %l117 = alloca i1
  %l137 = alloca i64
  %l142 = alloca i64
  %l143 = alloca i32
  %l144 = alloca i32
  %l151 = alloca i64
  %l152 = alloca i64
  %l157 = alloca { i64, ptr }
  %l158 = alloca i64
  %l159 = alloca { i64, ptr }
  %l161 = alloca { i64, ptr }
  %l166 = alloca i64
  %l173 = alloca i64
  %l176 = alloca i64
  %l185 = alloca i64
  %l188 = alloca i1
  %l204 = alloca { i64, ptr }
  %l206 = alloca { i64, ptr }
  %l207 = alloca i64
  %l208 = alloca { i64, ptr }
  %l210 = alloca i64
  %l212 = alloca i64
  %l213 = alloca { i64, ptr }
  %l216 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t20 = alloca { i64, [2 x i64] }, align 8
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %t1)
  store i1 %t3, ptr %l23
  br label %bb1
bb1:
  %t4 = load i1, ptr %l23, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t5, ptr %l25, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l26, !tbaa !24
  %t9 = load i64, ptr %l26, !tbaa !24
  %t10 = mul i64 %t9, 1
  %t11 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l27, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = load i64, ptr %l26, !tbaa !24
  %t19 = mul i64 %t18, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t15, ptr %t17, i64 %t19, i1 false)
  store { i64, [2 x i64] } zeroinitializer, ptr %t20
  %t21 = getelementptr { i64, [2 x i64] }, ptr %t20, i32 0, i32 0
  store i64 4, ptr %t21
  %t22 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t23 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t22, 0
  %t24 = getelementptr { i64, [2 x i64] }, ptr %t20, i32 0, i32 1
  store { { i64, ptr } } %t23, ptr %t24
  %t25 = load { i64, [2 x i64] }, ptr %t20
  store { i64, [2 x i64] } %t25, ptr %l28
  %t26 = call ptr @__olang_errpay_push()
  %t27 = ptrtoint ptr %t26 to i64
  store i64 %t27, ptr %l29, !tbaa !24
  %t28 = load i64, ptr %l29
  %t29 = inttoptr i64 %t28 to ptr
  %t31 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fos_3aError_24payload(ptr %t29, ptr %l28)
  store { i64, [2 x i64] } %t31, ptr %l31
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t32 = load { i64, [2 x i64] }, ptr %l31
  %t33 = load i64, ptr %l29
  %t34 = inttoptr i64 %t33 to ptr
  %t35 = call ptr @__olang_scope_alloc_a(ptr %t34, i64 24, i64 8)
  store { i64, [2 x i64] } %t32, ptr %t35
  call void @__olang_errpay_set(ptr %t35)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t38 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65540, 0
  store { i32, { i64, ptr } } %t38, ptr %rv
  br label %ret
bb5:
  %t39 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t41 = call { i32, %"std/os:File" } @std_2fos_2eFile_2eOpen(ptr %v0, { i64, ptr } %t39)
  %t42 = extractvalue { i32, %"std/os:File" } %t41, 1
  %t43 = extractvalue { i32, %"std/os:File" } %t41, 0
  store i32 %t43, ptr %l37
  %t44 = icmp ne i32 %t43, 0
  br i1 %t44, label %bb7, label %ok.45, !prof !99
ok.45:
  store %"std/os:File" %t42, ptr %l36
  br label %bb6
bb6:
  %t46 = load %"std/os:File", ptr %l36
  store %"std/os:File" %t46, ptr %l34
  br label %bb8
bb7:
  %t47 = load i32, ptr %l37, !tbaa !23
  %t48 = lshr i32 %t47, 16
  %t49 = and i32 %t47, 65535
  %t50 = icmp eq i32 %t48, 1
  %t51 = select i1 %t50, i32 1, i32 0
  %t52 = icmp eq i32 %t47, 0
  %t53 = shl i32 %t51, 16
  %t54 = or i32 %t53, %t49
  %t55 = select i1 %t52, i32 0, i32 %t54
  call void @__olang_scope_close(ptr %s0)
  %t57 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t55, 0
  store { i32, { i64, ptr } } %t57, ptr %rv
  br label %ret
bb8:
  %t58 = load %"std/os:File", ptr %l34
  store %"std/os:File" %t58, ptr %l1
  store i1 true, ptr %l2, !tbaa !21
  %t59 = getelementptr %"std/os:File", ptr %l1, i32 0, i32 0
  %t60 = load i32, ptr %t59, !tbaa !23
  %t62 = call i64 @std_2fos_2eseek(i32 %t60, i32 2)
  store i64 %t62, ptr %l40
  br label %bb9
bb9:
  %t63 = load i64, ptr %l40, !tbaa !24
  store i64 %t63, ptr %l3, !tbaa !24
  %t64 = load i64, ptr %l3, !tbaa !24
  %t66 = icmp slt i64 %t64, 0
  br i1 %t66, label %bb10, label %bb11
bb10:
  store i64 0, ptr %l3, !tbaa !24
  br label %bb13
bb11:
  %t68 = getelementptr %"std/os:File", ptr %l1, i32 0, i32 0
  %t69 = load i32, ptr %t68, !tbaa !23
  %t71 = call i64 @std_2fos_2eseek(i32 %t69, i32 0)
  store i64 %t71, ptr %l44
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t72 = load i64, ptr %l3, !tbaa !24
  store i64 %t72, ptr %l45, !tbaa !24
  %t73 = load i64, ptr %l45, !tbaa !24
  %t74 = icmp sge i64 %t73, 0
  br i1 %t74, label %bb14, label %bb15
bb14:
  %t76 = load i64, ptr %l45, !tbaa !24
  %t77 = mul i64 %t76, 1
  %t78 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t77)
  %t79 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t78, 1
  %t81 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t81, ptr %lp4
  %t83 = load ptr, ptr %lp4
  store { i64, ptr } %t80, ptr %t83, !tbaa !27
  %t84 = getelementptr %"std/os:File", ptr %l1, i32 0, i32 0
  %t85 = load i32, ptr %t84, !tbaa !23
  %t86 = load ptr, ptr %lp4
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  %t88 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t92 = call { i32, i64 } @std_2fos_2ereadInto(ptr %v1, ptr %v0, i32 %t85, { i64, ptr } %t87, i64 0, { i64, ptr } %t88)
  %t93 = extractvalue { i32, i64 } %t92, 1
  %t94 = extractvalue { i32, i64 } %t92, 0
  store i32 %t94, ptr %l53
  %t95 = icmp ne i32 %t94, 0
  br i1 %t95, label %bb17, label %ok.96, !prof !99
ok.96:
  store i64 %t93, ptr %l52
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_587e358192386240_8b720e6e0da4b04)
  unreachable
bb16:
  %t97 = load i64, ptr %l52, !tbaa !24
  store i64 %t97, ptr %l48, !tbaa !24
  br label %bb22
bb17:
  %t98 = load i32, ptr %l53, !tbaa !23
  %t99 = lshr i32 %t98, 16
  %t100 = and i32 %t98, 65535
  %t101 = icmp eq i32 %t99, 1
  %t102 = select i1 %t101, i32 1, i32 0
  %t103 = icmp eq i32 %t98, 0
  %t104 = shl i32 %t102, 16
  %t105 = or i32 %t104, %t100
  %t106 = select i1 %t103, i32 0, i32 %t105
  store i32 %t106, ptr %l54, !tbaa !23
  %t107 = load i1, ptr %l2, !tbaa !21
  br i1 %t107, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s5
  call void @olang_2emir_2eHelperKind_2eDrop_2estd_2fos_3aFile(ptr %s5, ptr %l1)
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i1 false, ptr %l2, !tbaa !21
  call void @__olang_scope_close(ptr %s5)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s0)
  %t110 = load i32, ptr %l54, !tbaa !23
  %t111 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t110, 0
  store { i32, { i64, ptr } } %t111, ptr %rv
  br label %ret
bb22:
  %t112 = load i64, ptr %l48, !tbaa !24
  store i64 %t112, ptr %l5, !tbaa !24
  %t113 = load i64, ptr %l5, !tbaa !24
  %t114 = load i64, ptr %l3, !tbaa !24
  %t117 = icmp slt i64 %t113, %t114
  br i1 %t117, label %bb23, label %bb24
bb23:
  %t119 = load i64, ptr %l5, !tbaa !24
  store i64 %t119, ptr %l60, !tbaa !24
  %t120 = load ptr, ptr %lp4
  %t121 = load { i64, ptr }, ptr %t120, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t121, 0
  store i64 %t122, ptr %l61, !tbaa !24
  %t123 = icmp sge i64 0, 0
  br i1 %t123, label %bb25, label %bb26
bb24:
  br label %bb35
bb25:
  %t125 = load i64, ptr %l60, !tbaa !24
  %t126 = icmp sle i64 0, %t125
  br i1 %t126, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_cd46a02c4675cb4d_fa072eb3f90c0109)
  unreachable
bb27:
  %t128 = load i64, ptr %l60, !tbaa !24
  %t129 = load i64, ptr %l61, !tbaa !24
  %t130 = icmp sle i64 %t128, %t129
  br i1 %t130, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_cd46a02c4675cb4d_fa072eb3f90c0109)
  unreachable
bb29:
  %t132 = load ptr, ptr %lp4
  %t133 = getelementptr { i64, ptr }, ptr %t132, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = load i64, ptr %l60, !tbaa !24
  %t136 = getelementptr i8, ptr %t134, i64 0
  %t137 = sub i64 %t135, 0
  %t138 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t136, 1
  store { i64, ptr } %t139, ptr %l66, !tbaa !27
  %t141 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 0
  store i64 %t142, ptr %l67, !tbaa !24
  %t143 = load i64, ptr %l67, !tbaa !24
  %t144 = mul i64 %t143, 1
  %t145 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t144)
  %t146 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t145, 1
  store { i64, ptr } %t147, ptr %l68, !tbaa !27
  %t148 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !27
  %t150 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = load i64, ptr %l67, !tbaa !24
  %t153 = mul i64 %t152, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t149, ptr %t151, i64 %t153, i1 false)
  %t154 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t154, ptr %l70, !tbaa !27
  %t156 = load i1, ptr %l2, !tbaa !21
  br i1 %t156, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_cd46a02c4675cb4d_fa072eb3f90c0109)
  unreachable
bb31:
  store %olang.scope zeroinitializer, ptr %s8
  call void @olang_2emir_2eHelperKind_2eDrop_2estd_2fos_3aFile(ptr %s8, ptr %l1)
  br label %bb33
bb32:
  br label %bb34
bb33:
  store i1 false, ptr %l2, !tbaa !21
  call void @__olang_scope_close(ptr %s8)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s0)
  %t159 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t160 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t159, 1
  store { i32, { i64, ptr } } %t160, ptr %rv
  br label %ret
bb35:
  %t161 = insertvalue [1 x i8] undef, i8 0, 0
  store [1 x i8] %t161, ptr %l6
  %t163 = getelementptr %"std/os:File", ptr %l1, i32 0, i32 0
  %t164 = load i32, ptr %t163, !tbaa !23
  %t166 = insertvalue { i64, ptr } undef, i64 1, 0
  %t167 = insertvalue { i64, ptr } %t166, ptr %l6, 1
  %t170 = call i64 @std_2fos_2erawRead(ptr %s0, i32 %t164, { i64, ptr } %t167)
  store i64 %t170, ptr %l77
  br label %bb36
bb36:
  %t171 = load i64, ptr %l77, !tbaa !24
  store i64 %t171, ptr %l7, !tbaa !24
  %t172 = load i64, ptr %l7, !tbaa !24
  %t174 = icmp slt i64 %t172, 0
  br i1 %t174, label %bb37, label %bb38
bb37:
  %t176 = call i32 @__olang_err()
  store i32 %t176, ptr %l80
  br label %bb39
bb38:
  br label %bb47
bb39:
  %t177 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t178 = load i32, ptr %l80, !tbaa !23
  %t180 = call i32 @std_2fos_2eraise(ptr %v0, i32 %t178, { i64, ptr } %t177)
  store i32 %t180, ptr %l82
  %t181 = icmp ne i32 %t180, 0
  br i1 %t181, label %bb41, label %ok.182, !prof !99
ok.182:
  br label %bb40
bb40:
  br label %bb46
bb41:
  %t183 = load i32, ptr %l82, !tbaa !23
  %t184 = lshr i32 %t183, 16
  %t185 = and i32 %t183, 65535
  %t186 = icmp eq i32 %t184, 1
  %t187 = select i1 %t186, i32 1, i32 0
  %t188 = icmp eq i32 %t183, 0
  %t189 = shl i32 %t187, 16
  %t190 = or i32 %t189, %t185
  %t191 = select i1 %t188, i32 0, i32 %t190
  store i32 %t191, ptr %l83, !tbaa !23
  %t192 = load i1, ptr %l2, !tbaa !21
  br i1 %t192, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s11
  call void @olang_2emir_2eHelperKind_2eDrop_2estd_2fos_3aFile(ptr %s11, ptr %l1)
  br label %bb44
bb43:
  br label %bb45
bb44:
  store i1 false, ptr %l2, !tbaa !21
  call void @__olang_scope_close(ptr %s11)
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s0)
  %t195 = load i32, ptr %l83, !tbaa !23
  %t196 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t195, 0
  store { i32, { i64, ptr } } %t196, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t197 = load i64, ptr %l7, !tbaa !24
  %t199 = icmp sgt i64 %t197, 0
  br i1 %t199, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s12
  %t201 = call ptr @__olang_scope_hold(ptr %s12)
  %t202 = ptrtoint ptr %t201 to i64
  store i64 %t202, ptr %l88, !tbaa !24
  %t203 = load i1, ptr @olang_2esole_2estd__2fos__2eReadFile_2elocal_2e8
  br i1 %t203, label %bb50, label %bb51
bb49:
  br label %bb113
bb50:
  %t205 = call ptr @__olang_region_make(ptr %s12)
  %t206 = ptrtoint ptr %t205 to i64
  store i64 %t206, ptr %l88, !tbaa !24
  br label %bb51
bb51:
  %t207 = load i64, ptr %l3, !tbaa !24
  %t209 = mul i64 %t207, 2
  %t211 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t209, i64 4096)
  store i64 %t211, ptr %l92
  br label %bb52
bb52:
  %t212 = load i64, ptr %l92, !tbaa !24
  %t213 = icmp sge i64 %t212, 0
  br i1 %t213, label %bb53, label %bb54
bb53:
  %t215 = load i64, ptr %l92, !tbaa !24
  %t216 = mul i64 %t215, 1
  %t217 = load i64, ptr %l88
  %t218 = inttoptr i64 %t217 to ptr
  %t219 = call ptr @__olang_scope_alloc_zeroed(ptr %t218, i64 %t216)
  %t220 = insertvalue { i64, ptr } undef, i64 %t215, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr %t219, 1
  store { i64, ptr } %t221, ptr %l94, !tbaa !27
  %t222 = load i1, ptr @olang_2esole_2estd__2fos__2eReadFile_2elocal_2e8
  br i1 %t222, label %bb55, label %bb56
bb54:
  call void @__olang_check_failed(ptr @olang_loc_177c37a6b0701e6e_ab9bf986b91be9f2)
  unreachable
bb55:
  %t224 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t225 = extractvalue { i64, ptr } %t224, 0
  %t227 = icmp eq i64 %t225, 0
  br i1 %t227, label %bb57, label %bb58
bb56:
  %t229 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t229, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t230 = load i64, ptr %l3, !tbaa !24
  store i64 %t230, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t232 = load i64, ptr %l10, !tbaa !24
  %t233 = load i64, ptr %l9, !tbaa !24
  %t236 = icmp sgt i64 %t232, %t233
  br i1 %t236, label %bb59, label %bb60
bb57:
  store { i64, ptr } zeroinitializer, ptr %l94, !tbaa !27
  br label %bb58
bb58:
  %t238 = load i64, ptr %l88
  %t239 = inttoptr i64 %t238 to ptr
  %t240 = load { i64, ptr }, ptr %l94
  %t241 = extractvalue { i64, ptr } %t240, 1
  %t242 = call ptr @__olang_region_or(ptr %t241, ptr null)
  %t243 = icmp ne ptr %t242, null
  %t244 = select i1 %t243, ptr %t242, ptr null
  call void @__olang_region_settle_in(ptr %t239, ptr %t244)
  br label %bb56
bb59:
  %t245 = load i64, ptr %l11, !tbaa !24
  %t247 = icmp sgt i64 %t245, 0
  br i1 %t247, label %bb61, label %bb62
bb60:
  store i64 0, ptr %l102, !tbaa !24
  br label %bb64
bb61:
  %t249 = load i64, ptr %l10, !tbaa !24
  %t250 = load i64, ptr %l9, !tbaa !24
  %t253 = sub i64 %t249, %t250
  %t254 = load i64, ptr %l11, !tbaa !24
  %t257 = add i64 %t253, %t254
  %t259 = sub i64 %t257, 1
  %t260 = load i64, ptr %l11, !tbaa !24
  %t263 = sdiv i64 %t259, %t260
  store i64 %t263, ptr %l105, !tbaa !24
  br label %bb63
bb62:
  store i64 0, ptr %l105, !tbaa !24
  br label %bb63
bb63:
  %t265 = load i64, ptr %l105, !tbaa !24
  store i64 %t265, ptr %l102, !tbaa !24
  br label %bb64
bb64:
  %t266 = load i64, ptr %l102, !tbaa !24
  store i64 %t266, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  %t267 = load i64, ptr %l12, !tbaa !24
  %t268 = sub i64 %t267, 1
  store i64 %t268, ptr %l114, !tbaa !24
  %t269 = load i64, ptr %l12, !tbaa !24
  %t270 = icmp slt i64 %t269, 2147483648
  %t271 = load i64, ptr %l13, !tbaa !24
  %t272 = icmp sge i64 %t271, 0
  %t275 = and i1 %t270, %t272
  store i1 %t275, ptr %l117, !tbaa !21
  br label %bb65
bb65:
  %t276 = load i64, ptr %l13, !tbaa !24
  %t277 = load i64, ptr %l12, !tbaa !24
  %t280 = icmp slt i64 %t276, %t277
  %t282 = xor i1 %t280, true
  br i1 %t282, label %bb66, label %bb67
bb66:
  br label %bb70
bb67:
  br label %bb68
bb68:
  %t284 = load i64, ptr %l9, !tbaa !24
  %t285 = load i64, ptr %l13, !tbaa !24
  %t286 = load i64, ptr %l11, !tbaa !24
  %t289 = mul i64 %t285, %t286
  %t292 = add i64 %t284, %t289
  store i64 %t292, ptr %l14, !tbaa !24
  %t294 = load i64, ptr %l14, !tbaa !24
  %t295 = load i64, ptr %l14, !tbaa !24
  %t296 = load ptr, ptr %lp4
  %t298 = getelementptr { i64, ptr }, ptr %t296, i32 0, i32 1
  %t299 = load ptr, ptr %t298, !tbaa !27
  %t300 = getelementptr i8, ptr %t299, i64 %t295
  %t301 = load i8, ptr %t300, !tbaa !32
  %t304 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t305 = load ptr, ptr %t304, !tbaa !27
  %t306 = getelementptr i8, ptr %t305, i64 %t294
  store i8 %t301, ptr %t306, !tbaa !32
  br label %bb69
bb69:
  %t307 = load i64, ptr %l13, !tbaa !24
  %t310 = add i64 %t307, 1
  store i64 %t310, ptr %l13, !tbaa !24
  br label %bb65
bb70:
  %t312 = load i64, ptr %l3, !tbaa !24
  %t313 = getelementptr [1 x i8], ptr %l6, i64 0, i64 0
  %t314 = load i8, ptr %t313, !tbaa !32
  %t317 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t318 = load ptr, ptr %t317, !tbaa !27
  %t319 = getelementptr i8, ptr %t318, i64 %t312
  store i8 %t314, ptr %t319, !tbaa !32
  %t320 = load i64, ptr %l3, !tbaa !24
  %t322 = add i64 %t320, 1
  store i64 %t322, ptr %l5, !tbaa !24
  br label %bb71
bb71:
  store %olang.scope zeroinitializer, ptr %s16
  %t324 = getelementptr %"std/os:File", ptr %l1, i32 0, i32 0
  %t325 = load i32, ptr %t324, !tbaa !23
  %t326 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t327 = load i64, ptr %l5, !tbaa !24
  %t328 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t333 = call { i32, i64 } @std_2fos_2ereadInto(ptr %s12, ptr %v0, i32 %t325, { i64, ptr } %t326, i64 %t327, { i64, ptr } %t328)
  %t334 = extractvalue { i32, i64 } %t333, 1
  %t335 = extractvalue { i32, i64 } %t333, 0
  store i32 %t335, ptr %l143
  %t336 = icmp ne i32 %t335, 0
  br i1 %t336, label %bb73, label %ok.337, !prof !99
ok.337:
  store i64 %t334, ptr %l142
  br label %bb72
bb72:
  %t338 = load i64, ptr %l142, !tbaa !24
  store i64 %t338, ptr %l137, !tbaa !24
  br label %bb78
bb73:
  %t339 = load i32, ptr %l143, !tbaa !23
  %t340 = lshr i32 %t339, 16
  %t341 = and i32 %t339, 65535
  %t342 = icmp eq i32 %t340, 1
  %t343 = select i1 %t342, i32 1, i32 0
  %t344 = icmp eq i32 %t339, 0
  %t345 = shl i32 %t343, 16
  %t346 = or i32 %t345, %t341
  %t347 = select i1 %t344, i32 0, i32 %t346
  store i32 %t347, ptr %l144, !tbaa !23
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s12)
  %t348 = load i1, ptr %l2, !tbaa !21
  br i1 %t348, label %bb74, label %bb75
bb74:
  store %olang.scope zeroinitializer, ptr %s18
  call void @olang_2emir_2eHelperKind_2eDrop_2estd_2fos_3aFile(ptr %s18, ptr %l1)
  br label %bb76
bb75:
  br label %bb77
bb76:
  store i1 false, ptr %l2, !tbaa !21
  call void @__olang_scope_close(ptr %s18)
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s0)
  %t351 = load i32, ptr %l144, !tbaa !23
  %t352 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t351, 0
  store { i32, { i64, ptr } } %t352, ptr %rv
  br label %ret
bb78:
  %t353 = load i64, ptr %l137, !tbaa !24
  store i64 %t353, ptr %l5, !tbaa !24
  %t354 = load i64, ptr %l5, !tbaa !24
  %t355 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t357 = extractvalue { i64, ptr } %t355, 0
  %t360 = icmp slt i64 %t354, %t357
  br i1 %t360, label %bb79, label %bb80
bb79:
  %t362 = load i64, ptr %l5, !tbaa !24
  store i64 %t362, ptr %l151, !tbaa !24
  %t363 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t364 = extractvalue { i64, ptr } %t363, 0
  store i64 %t364, ptr %l152, !tbaa !24
  %t365 = icmp sge i64 0, 0
  br i1 %t365, label %bb81, label %bb82
bb80:
  br label %bb91
bb81:
  %t367 = load i64, ptr %l151, !tbaa !24
  %t368 = icmp sle i64 0, %t367
  br i1 %t368, label %bb83, label %bb84
bb82:
  call void @__olang_check_failed(ptr @olang_loc_870dc790e95aa6eb_a67bfaf9489a2847)
  unreachable
bb83:
  %t370 = load i64, ptr %l151, !tbaa !24
  %t371 = load i64, ptr %l152, !tbaa !24
  %t372 = icmp sle i64 %t370, %t371
  br i1 %t372, label %bb85, label %bb86
bb84:
  call void @__olang_check_failed(ptr @olang_loc_870dc790e95aa6eb_a67bfaf9489a2847)
  unreachable
bb85:
  %t374 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t375 = load ptr, ptr %t374, !tbaa !27
  %t376 = load i64, ptr %l151, !tbaa !24
  %t377 = getelementptr i8, ptr %t375, i64 0
  %t378 = sub i64 %t376, 0
  %t379 = insertvalue { i64, ptr } undef, i64 %t378, 0
  %t380 = insertvalue { i64, ptr } %t379, ptr %t377, 1
  store { i64, ptr } %t380, ptr %l157, !tbaa !27
  %t382 = load { i64, ptr }, ptr %l157, !tbaa !27
  %t383 = extractvalue { i64, ptr } %t382, 0
  store i64 %t383, ptr %l158, !tbaa !24
  %t384 = load i64, ptr %l158, !tbaa !24
  %t385 = mul i64 %t384, 1
  %t386 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t385)
  %t387 = insertvalue { i64, ptr } undef, i64 %t384, 0
  %t388 = insertvalue { i64, ptr } %t387, ptr %t386, 1
  store { i64, ptr } %t388, ptr %l159, !tbaa !27
  %t389 = getelementptr { i64, ptr }, ptr %l159, i32 0, i32 1
  %t390 = load ptr, ptr %t389, !tbaa !27
  %t391 = getelementptr { i64, ptr }, ptr %l157, i32 0, i32 1
  %t392 = load ptr, ptr %t391, !tbaa !27
  %t393 = load i64, ptr %l158, !tbaa !24
  %t394 = mul i64 %t393, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t390, ptr %t392, i64 %t394, i1 false)
  %t395 = load { i64, ptr }, ptr %l159, !tbaa !27
  store { i64, ptr } %t395, ptr %l161, !tbaa !27
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s12)
  %t397 = load i1, ptr %l2, !tbaa !21
  br i1 %t397, label %bb87, label %bb88
bb86:
  call void @__olang_check_failed(ptr @olang_loc_870dc790e95aa6eb_a67bfaf9489a2847)
  unreachable
bb87:
  store %olang.scope zeroinitializer, ptr %s21
  call void @olang_2emir_2eHelperKind_2eDrop_2estd_2fos_3aFile(ptr %s21, ptr %l1)
  br label %bb89
bb88:
  br label %bb90
bb89:
  store i1 false, ptr %l2, !tbaa !21
  call void @__olang_scope_close(ptr %s21)
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s0)
  %t400 = load { i64, ptr }, ptr %l161, !tbaa !27
  %t401 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t400, 1
  store { i32, { i64, ptr } } %t401, ptr %rv
  br label %ret
bb91:
  %t402 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t404 = extractvalue { i64, ptr } %t402, 0
  %t406 = mul i64 %t404, 2
  store i64 %t406, ptr %l166, !tbaa !24
  %t407 = load i64, ptr %l166, !tbaa !24
  %t408 = icmp sge i64 %t407, 0
  br i1 %t408, label %bb92, label %bb93
bb92:
  %t410 = load i64, ptr %l166, !tbaa !24
  %t411 = mul i64 %t410, 1
  %t412 = call ptr @__olang_scope_alloc_zeroed(ptr %s16, i64 %t411)
  %t413 = insertvalue { i64, ptr } undef, i64 %t410, 0
  %t414 = insertvalue { i64, ptr } %t413, ptr %t412, 1
  store { i64, ptr } %t414, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t416 = load i64, ptr %l5, !tbaa !24
  store i64 %t416, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t418 = load i64, ptr %l17, !tbaa !24
  %t419 = load i64, ptr %l16, !tbaa !24
  %t422 = icmp sgt i64 %t418, %t419
  br i1 %t422, label %bb94, label %bb95
bb93:
  call void @__olang_check_failed(ptr @olang_loc_8e0d503f3b50c80c_2eb254ad451fbc78)
  unreachable
bb94:
  %t424 = load i64, ptr %l18, !tbaa !24
  %t426 = icmp sgt i64 %t424, 0
  br i1 %t426, label %bb96, label %bb97
bb95:
  store i64 0, ptr %l173, !tbaa !24
  br label %bb99
bb96:
  %t428 = load i64, ptr %l17, !tbaa !24
  %t429 = load i64, ptr %l16, !tbaa !24
  %t432 = sub i64 %t428, %t429
  %t433 = load i64, ptr %l18, !tbaa !24
  %t436 = add i64 %t432, %t433
  %t438 = sub i64 %t436, 1
  %t439 = load i64, ptr %l18, !tbaa !24
  %t442 = sdiv i64 %t438, %t439
  store i64 %t442, ptr %l176, !tbaa !24
  br label %bb98
bb97:
  store i64 0, ptr %l176, !tbaa !24
  br label %bb98
bb98:
  %t444 = load i64, ptr %l176, !tbaa !24
  store i64 %t444, ptr %l173, !tbaa !24
  br label %bb99
bb99:
  %t445 = load i64, ptr %l173, !tbaa !24
  store i64 %t445, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  %t446 = load i64, ptr %l19, !tbaa !24
  %t447 = sub i64 %t446, 1
  store i64 %t447, ptr %l185, !tbaa !24
  %t448 = load i64, ptr %l19, !tbaa !24
  %t449 = icmp slt i64 %t448, 2147483648
  %t450 = load i64, ptr %l20, !tbaa !24
  %t451 = icmp sge i64 %t450, 0
  %t454 = and i1 %t449, %t451
  store i1 %t454, ptr %l188, !tbaa !21
  br label %bb100
bb100:
  %t455 = load i64, ptr %l20, !tbaa !24
  %t456 = load i64, ptr %l19, !tbaa !24
  %t459 = icmp slt i64 %t455, %t456
  %t461 = xor i1 %t459, true
  br i1 %t461, label %bb101, label %bb102
bb101:
  br label %bb105
bb102:
  br label %bb103
bb103:
  %t463 = load i64, ptr %l16, !tbaa !24
  %t464 = load i64, ptr %l20, !tbaa !24
  %t465 = load i64, ptr %l18, !tbaa !24
  %t468 = mul i64 %t464, %t465
  %t471 = add i64 %t463, %t468
  store i64 %t471, ptr %l21, !tbaa !24
  %t473 = load i64, ptr %l21, !tbaa !24
  %t474 = load i64, ptr %l21, !tbaa !24
  %t476 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t477 = load ptr, ptr %t476, !tbaa !27
  %t478 = getelementptr i8, ptr %t477, i64 %t474
  %t479 = load i8, ptr %t478, !tbaa !32
  %t482 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t483 = load ptr, ptr %t482, !tbaa !27
  %t484 = getelementptr i8, ptr %t483, i64 %t473
  store i8 %t479, ptr %t484, !tbaa !32
  br label %bb104
bb104:
  %t485 = load i64, ptr %l20, !tbaa !24
  %t488 = add i64 %t485, 1
  store i64 %t488, ptr %l20, !tbaa !24
  br label %bb100
bb105:
  %t490 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t490, ptr %l204, !tbaa !27
  %t491 = load i1, ptr @olang_2esole_2estd__2fos__2eReadFile_2elocal_2e8
  br i1 %t491, label %bb106, label %bb107
bb106:
  %t493 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t493, ptr %l206, !tbaa !27
  %t494 = load { i64, ptr }, ptr %l204, !tbaa !27
  %t495 = extractvalue { i64, ptr } %t494, 0
  store i64 %t495, ptr %l207, !tbaa !24
  %t496 = load i64, ptr %l207, !tbaa !24
  %t497 = mul i64 %t496, 1
  %t498 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t497)
  %t499 = insertvalue { i64, ptr } undef, i64 %t496, 0
  %t500 = insertvalue { i64, ptr } %t499, ptr %t498, 1
  store { i64, ptr } %t500, ptr %l208, !tbaa !27
  %t501 = getelementptr { i64, ptr }, ptr %l208, i32 0, i32 1
  %t502 = load ptr, ptr %t501, !tbaa !27
  %t503 = getelementptr { i64, ptr }, ptr %l204, i32 0, i32 1
  %t504 = load ptr, ptr %t503, !tbaa !27
  %t505 = load i64, ptr %l207, !tbaa !24
  %t506 = mul i64 %t505, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t502, ptr %t504, i64 %t506, i1 false)
  %t507 = load { i64, ptr }, ptr %l208, !tbaa !27
  store { i64, ptr } %t507, ptr %l8, !tbaa !27
  %t508 = load { i64, ptr }, ptr %l206
  %t509 = extractvalue { i64, ptr } %t508, 1
  call void @__olang_region_release(ptr %t509)
  store { i64, ptr } zeroinitializer, ptr %l206
  br label %bb108
bb107:
  %t510 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t511 = extractvalue { i64, ptr } %t510, 0
  %t512 = load { i64, ptr }, ptr %l204, !tbaa !27
  %t513 = extractvalue { i64, ptr } %t512, 0
  store i64 %t513, ptr %l210, !tbaa !24
  %t515 = load i64, ptr %l210, !tbaa !24
  %t516 = icmp eq i64 %t511, %t515
  br i1 %t516, label %bb109, label %bb110
bb108:
  call void @__olang_scope_close(ptr %s16)
  br label %bb112
bb109:
  %t518 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t519 = load ptr, ptr %t518, !tbaa !27
  %t520 = getelementptr { i64, ptr }, ptr %l204, i32 0, i32 1
  %t521 = load ptr, ptr %t520, !tbaa !27
  %t522 = load i64, ptr %l210, !tbaa !24
  %t523 = mul i64 %t522, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t519, ptr %t521, i64 %t523, i1 false)
  br label %bb111
bb110:
  %t524 = load { i64, ptr }, ptr %l204, !tbaa !27
  %t525 = extractvalue { i64, ptr } %t524, 0
  store i64 %t525, ptr %l212, !tbaa !24
  %t526 = load i64, ptr %l212, !tbaa !24
  %t527 = mul i64 %t526, 1
  %t528 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t527)
  %t529 = insertvalue { i64, ptr } undef, i64 %t526, 0
  %t530 = insertvalue { i64, ptr } %t529, ptr %t528, 1
  store { i64, ptr } %t530, ptr %l213, !tbaa !27
  %t531 = getelementptr { i64, ptr }, ptr %l213, i32 0, i32 1
  %t532 = load ptr, ptr %t531, !tbaa !27
  %t533 = getelementptr { i64, ptr }, ptr %l204, i32 0, i32 1
  %t534 = load ptr, ptr %t533, !tbaa !27
  %t535 = load i64, ptr %l212, !tbaa !24
  %t536 = mul i64 %t535, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t532, ptr %t534, i64 %t536, i1 false)
  %t537 = load { i64, ptr }, ptr %l213, !tbaa !27
  store { i64, ptr } %t537, ptr %l8, !tbaa !27
  br label %bb111
bb111:
  br label %bb108
bb112:
  br label %bb71
bb113:
  %t538 = load ptr, ptr %lp4
  %t539 = load { i64, ptr }, ptr %t538, !tbaa !27
  store { i64, ptr } %t539, ptr %l216, !tbaa !27
  %t542 = load i1, ptr %l2, !tbaa !21
  br i1 %t542, label %bb114, label %bb115
bb114:
  store %olang.scope zeroinitializer, ptr %s26
  call void @olang_2emir_2eHelperKind_2eDrop_2estd_2fos_3aFile(ptr %s26, ptr %l1)
  br label %bb116
bb115:
  br label %bb117
bb116:
  store i1 false, ptr %l2, !tbaa !21
  call void @__olang_scope_close(ptr %s26)
  br label %bb117
bb117:
  call void @__olang_scope_close(ptr %s0)
  %t545 = load { i64, ptr }, ptr %l216, !tbaa !27
  %t546 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t545, 1
  store { i32, { i64, ptr } } %t546, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l7 = alloca i64
  %l15 = alloca i64
  %l23 = alloca i64
  %l31 = alloca i64
  %l34 = alloca i32
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 1
  %t4 = extractvalue { i64, ptr } %t1, 0
  %t5 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  store { i64, ptr } %t11, ptr %l1, !tbaa !27
  store i64 256, ptr %l2, !tbaa !24
  %t13 = load i64, ptr %l2, !tbaa !24
  store i64 %t13, ptr %l7, !tbaa !24
  %t14 = load i64, ptr %l7, !tbaa !24
  %t15 = icmp sge i64 %t14, 0
  br i1 %t15, label %bb1, label %bb2
bb1:
  %t17 = load i64, ptr %l7, !tbaa !24
  %t18 = mul i64 %t17, 1
  %t19 = call ptr @__olang_scope_alloc_zeroed(ptr %s1, i64 %t18)
  %t20 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l3, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t26 = load i64, ptr %l2, !tbaa !24
  %t29 = extractvalue { i64, ptr } %t23, 1
  %t30 = extractvalue { i64, ptr } %t23, 0
  %t32 = extractvalue { i64, ptr } %t25, 1
  %t33 = extractvalue { i64, ptr } %t25, 0
  %t35 = call i64 @readlink(ptr %t29, ptr %t32, i64 %t26)
  store i64 %t35, ptr %l15
  br label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_3bbcea0c000efd36_21b55d08ecf81e22)
  unreachable
bb3:
  %t36 = load i64, ptr %l15, !tbaa !24
  store i64 %t36, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t37 = load i64, ptr %l4, !tbaa !24
  %t38 = load i64, ptr %l2, !tbaa !24
  %t41 = icmp eq i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb5, label %bb6
bb5:
  br label %bb12
bb6:
  br label %bb7
bb7:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t48 = mul i64 %t45, 2
  store i64 %t48, ptr %l2, !tbaa !24
  %t50 = load i64, ptr %l2, !tbaa !24
  store i64 %t50, ptr %l23, !tbaa !24
  %t51 = load i64, ptr %l23, !tbaa !24
  %t52 = icmp sge i64 %t51, 0
  br i1 %t52, label %bb8, label %bb9
bb8:
  %t54 = load i64, ptr %l23, !tbaa !24
  %t55 = mul i64 %t54, 1
  %t56 = call ptr @__olang_scope_alloc_zeroed(ptr %s1, i64 %t55)
  %t57 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  store { i64, ptr } %t58, ptr %l3, !tbaa !27
  %t60 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t63 = load i64, ptr %l2, !tbaa !24
  %t66 = extractvalue { i64, ptr } %t60, 1
  %t67 = extractvalue { i64, ptr } %t60, 0
  %t69 = extractvalue { i64, ptr } %t62, 1
  %t70 = extractvalue { i64, ptr } %t62, 0
  %t72 = call i64 @readlink(ptr %t66, ptr %t69, i64 %t63)
  store i64 %t72, ptr %l31
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_ff17d2e56a811dcb_410ea2db80d8aad7)
  unreachable
bb10:
  %t73 = load i64, ptr %l31, !tbaa !24
  store i64 %t73, ptr %l4, !tbaa !24
  br label %bb11
bb11:
  br label %bb4
bb12:
  %t74 = load i64, ptr %l4, !tbaa !24
  %t75 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t78 = call i32 @std_2fos_2echeck(ptr %v0, i64 %t74, { i64, ptr } %t75)
  store i32 %t78, ptr %l34
  %t79 = icmp ne i32 %t78, 0
  br i1 %t79, label %bb14, label %ok.80, !prof !99
ok.80:
  br label %bb13
bb13:
  br label %bb15
bb14:
  %t81 = load i32, ptr %l34, !tbaa !23
  %t82 = lshr i32 %t81, 16
  %t83 = and i32 %t81, 65535
  %t84 = icmp eq i32 %t82, 1
  %t85 = select i1 %t84, i32 1, i32 0
  %t86 = icmp eq i32 %t81, 0
  %t87 = shl i32 %t85, 16
  %t88 = or i32 %t87, %t83
  %t89 = select i1 %t86, i32 0, i32 %t88
  call void @__olang_scope_close(ptr %s1)
  %t91 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t89, 0
  store { i32, { i64, ptr } } %t91, ptr %rv
  br label %ret
bb15:
  %t92 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t92, ptr %l36, !tbaa !27
  %t93 = load i64, ptr %l4, !tbaa !24
  store i64 %t93, ptr %l37, !tbaa !24
  %t94 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 0
  store i64 %t95, ptr %l38, !tbaa !24
  %t96 = icmp sge i64 0, 0
  br i1 %t96, label %bb16, label %bb17
bb16:
  %t98 = load i64, ptr %l37, !tbaa !24
  %t99 = icmp sle i64 0, %t98
  br i1 %t99, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_d7f228265709f418_7e9f802c53b666ac)
  unreachable
bb18:
  %t101 = load i64, ptr %l37, !tbaa !24
  %t102 = load i64, ptr %l38, !tbaa !24
  %t103 = icmp sle i64 %t101, %t102
  br i1 %t103, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_d7f228265709f418_7e9f802c53b666ac)
  unreachable
bb20:
  %t105 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = load i64, ptr %l37, !tbaa !24
  %t108 = getelementptr i8, ptr %t106, i64 0
  %t109 = sub i64 %t107, 0
  %t110 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t108, 1
  store { i64, ptr } %t111, ptr %l43, !tbaa !27
  %t113 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  store i64 %t114, ptr %l44, !tbaa !24
  %t115 = load i64, ptr %l44, !tbaa !24
  %t116 = mul i64 %t115, 1
  %t117 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t116)
  %t118 = insertvalue { i64, ptr } undef, i64 %t115, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t117, 1
  store { i64, ptr } %t119, ptr %l45, !tbaa !27
  %t120 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = load i64, ptr %l44, !tbaa !24
  %t125 = mul i64 %t124, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t121, ptr %t123, i64 %t125, i1 false)
  %t126 = load { i64, ptr }, ptr %l45, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  %t129 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t126, 1
  store { i32, { i64, ptr } } %t129, ptr %rv
  br label %ret
bb21:
  call void @__olang_check_failed(ptr @olang_loc_d7f228265709f418_7e9f802c53b666ac)
  unreachable
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i32 @std_2fos_2eRemoveAll(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l21 = alloca i1
  %l22 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l40 = alloca i1
  %l41 = alloca i1
  %l43 = alloca i1
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, [2 x i64] }
  %l49 = alloca i64
  %l51 = alloca { i64, [2 x i64] }
  %l55 = alloca i32
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i32
  %t104 = alloca { i64, [2 x i64] }, align 8
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l1, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = icmp sgt i64 %t5, 1
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l9, !tbaa !27
  %t10 = load i64, ptr %l1, !tbaa !24
  %t12 = sub i64 %t10, 1
  %t14 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i8, ptr %t15, i64 %t12
  %t17 = load i8, ptr %t16, !tbaa !32
  %t19 = icmp eq i8 %t17, 47
  store i1 %t19, ptr %l8, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t21 = load i1, ptr %l8, !tbaa !21
  %t22 = xor i1 %t21, true
  br i1 %t22, label %bb5, label %bb6
bb5:
  br label %bb9
bb6:
  br label %bb7
bb7:
  %t24 = load i64, ptr %l1, !tbaa !24
  %t27 = sub i64 %t24, 1
  store i64 %t27, ptr %l1, !tbaa !24
  br label %bb8
bb8:
  br label %bb1
bb9:
  %t29 = load i64, ptr %l1, !tbaa !24
  store i64 %t29, ptr %l2, !tbaa !24
  br label %bb10
bb10:
  %t31 = load i64, ptr %l2, !tbaa !24
  %t33 = icmp sgt i64 %t31, 0
  br i1 %t33, label %bb11, label %bb12
bb11:
  %t35 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t35, ptr %l22, !tbaa !27
  %t36 = load i64, ptr %l2, !tbaa !24
  %t38 = sub i64 %t36, 1
  %t40 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr i8, ptr %t41, i64 %t38
  %t43 = load i8, ptr %t42, !tbaa !32
  %t45 = icmp ne i8 %t43, 47
  store i1 %t45, ptr %l21, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb13
bb13:
  %t47 = load i1, ptr %l21, !tbaa !21
  %t48 = xor i1 %t47, true
  br i1 %t48, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t50 = load i64, ptr %l2, !tbaa !24
  %t53 = sub i64 %t50, 1
  store i64 %t53, ptr %l2, !tbaa !24
  br label %bb17
bb17:
  br label %bb10
bb18:
  %t55 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t55, ptr %l31, !tbaa !27
  %t56 = load i64, ptr %l2, !tbaa !24
  store i64 %t56, ptr %l32, !tbaa !24
  %t57 = load i64, ptr %l1, !tbaa !24
  store i64 %t57, ptr %l33, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t58, 0
  store i64 %t59, ptr %l34, !tbaa !24
  %t60 = load i64, ptr %l32, !tbaa !24
  %t61 = icmp sge i64 %t60, 0
  br i1 %t61, label %bb19, label %bb20
bb19:
  %t63 = load i64, ptr %l32, !tbaa !24
  %t64 = load i64, ptr %l33, !tbaa !24
  %t65 = icmp sle i64 %t63, %t64
  br i1 %t65, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_9d6ebd177b1045e9_d85719897e835afd)
  unreachable
bb21:
  %t67 = load i64, ptr %l33, !tbaa !24
  %t68 = load i64, ptr %l34, !tbaa !24
  %t69 = icmp sle i64 %t67, %t68
  br i1 %t69, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_9d6ebd177b1045e9_d85719897e835afd)
  unreachable
bb23:
  %t71 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = load i64, ptr %l32, !tbaa !24
  %t74 = load i64, ptr %l33, !tbaa !24
  %t75 = getelementptr i8, ptr %t72, i64 %t73
  %t76 = sub i64 %t74, %t73
  %t77 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t75, 1
  store { i64, ptr } %t78, ptr %l3, !tbaa !27
  %t80 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t82 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t80, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) })
  store i1 %t82, ptr %l40
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_9d6ebd177b1045e9_d85719897e835afd)
  unreachable
bb25:
  %t83 = load i1, ptr %l40, !tbaa !21
  br i1 %t83, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb29
bb27:
  %t84 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t86 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t84, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d44, i32 0, i32 1) })
  store i1 %t86, ptr %l43
  br label %bb28
bb28:
  %t87 = load i1, ptr %l43, !tbaa !21
  store i1 %t87, ptr %l41, !tbaa !21
  br label %bb29
bb29:
  %t88 = load i1, ptr %l41, !tbaa !21
  br i1 %t88, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s3
  %t89 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t89, ptr %l45, !tbaa !27
  %t91 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t91, 0
  store i64 %t92, ptr %l46, !tbaa !24
  %t93 = load i64, ptr %l46, !tbaa !24
  %t94 = mul i64 %t93, 1
  %t95 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t94)
  %t96 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t95, 1
  store { i64, ptr } %t97, ptr %l47, !tbaa !27
  %t98 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = load i64, ptr %l46, !tbaa !24
  %t103 = mul i64 %t102, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t99, ptr %t101, i64 %t103, i1 false)
  store { i64, [2 x i64] } zeroinitializer, ptr %t104
  %t105 = getelementptr { i64, [2 x i64] }, ptr %t104, i32 0, i32 0
  store i64 6, ptr %t105
  %t106 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t107 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t106, 0
  %t108 = getelementptr { i64, [2 x i64] }, ptr %t104, i32 0, i32 1
  store { { i64, ptr } } %t107, ptr %t108
  %t109 = load { i64, [2 x i64] }, ptr %t104
  store { i64, [2 x i64] } %t109, ptr %l48
  %t110 = call ptr @__olang_errpay_push()
  %t111 = ptrtoint ptr %t110 to i64
  store i64 %t111, ptr %l49, !tbaa !24
  %t112 = load i64, ptr %l49
  %t113 = inttoptr i64 %t112 to ptr
  %t115 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fos_3aError_24payload(ptr %t113, ptr %l48)
  store { i64, [2 x i64] } %t115, ptr %l51
  br label %bb32
bb31:
  br label %bb33
bb32:
  %t116 = load { i64, [2 x i64] }, ptr %l51
  %t117 = load i64, ptr %l49
  %t118 = inttoptr i64 %t117 to ptr
  %t119 = call ptr @__olang_scope_alloc_a(ptr %t118, i64 24, i64 8)
  store { i64, [2 x i64] } %t116, ptr %t119
  call void @__olang_errpay_set(ptr %t119)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i32 65542, ptr %rv
  br label %ret
bb33:
  %t122 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t124 = call i32 @std_2fos_2eremoveTree(ptr %v0, { i64, ptr } %t122)
  store i32 %t124, ptr %l55
  %t125 = icmp ne i32 %t124, 0
  br i1 %t125, label %bb35, label %ok.126, !prof !99
ok.126:
  br label %bb34
bb34:
  br label %bb36
bb35:
  %t127 = load i32, ptr %l55, !tbaa !23
  %t128 = lshr i32 %t127, 16
  %t129 = and i32 %t127, 65535
  %t130 = icmp eq i32 %t128, 1
  %t131 = select i1 %t130, i32 1, i32 0
  %t132 = icmp eq i32 %t127, 0
  %t133 = shl i32 %t131, 16
  %t134 = or i32 %t133, %t129
  %t135 = select i1 %t132, i32 0, i32 %t134
  call void @__olang_scope_close(ptr %s0)
  store i32 %t135, ptr %rv
  br label %ret
bb36:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fos_2ecloseAndRaise(ptr %v0, i32 %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %l4 = alloca i32
  %l7 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @close(i32 %a0)
  store i32 %t3, ptr %l4
  br label %bb1
bb1:
  %t8 = call i32 @std_2fos_2eraise(ptr %v0, i32 %a1, { i64, ptr } %a2)
  store i32 %t8, ptr %l7
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb3, label %ok.10, !prof !99
ok.10:
  br label %bb2
bb2:
  br label %bb4
bb3:
  %t11 = load i32, ptr %l7, !tbaa !23
  %t12 = lshr i32 %t11, 16
  %t13 = and i32 %t11, 65535
  %t14 = icmp eq i32 %t12, 1
  %t15 = select i1 %t14, i32 1, i32 0
  %t16 = icmp eq i32 %t11, 0
  %t17 = shl i32 %t15, 16
  %t18 = or i32 %t17, %t13
  %t19 = select i1 %t16, i32 0, i32 %t18
  store i32 %t19, ptr %rv
  br label %ret
bb4:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @std_2fos_2ecopyOut(ptr %v0, ptr %v1, ptr %v2, ptr %a0c, ptr %a0e, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { ptr, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { ptr, ptr }
  %l8 = alloca i64
  %l11 = alloca i32
  %l13 = alloca i64
  %l18 = alloca i64
  %l24 = alloca i32
  %l26 = alloca i64
  %l27 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %pf0 = insertvalue { ptr, ptr } undef, ptr %a0c, 0
  %pg0 = insertvalue { ptr, ptr } %pf0, ptr %a0e, 1
  store { ptr, ptr } %pg0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { ptr, ptr }, ptr %l0
  store { ptr, ptr } %t1, ptr %l5
  %t2 = icmp sge i64 0, 0
  br i1 %t2, label %bb1, label %bb2
bb1:
  %t4 = mul i64 0, 1
  %t5 = insertvalue { i64, ptr } undef, i64 0, 0
  %t6 = insertvalue { i64, ptr } %t5, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t7 = load { ptr, ptr }, ptr %l5
  %t8 = extractvalue { ptr, ptr } %t7, 0
  %t9 = extractvalue { ptr, ptr } %t7, 1
  %t11 = call i64 %t8(ptr %t9, ptr %s0, { i64, ptr } %t6)
  store i64 %t11, ptr %l8
  br label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_7455114053b9a685_f9a96b9bd4adb589)
  unreachable
bb3:
  %t12 = load i64, ptr %l8, !tbaa !24
  store i64 %t12, ptr %l2, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t13 = load i64, ptr %l2, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t17 = call i32 @std_2fos_2echeck(ptr %v1, i64 %t13, { i64, ptr } %t14)
  store i32 %t17, ptr %l11
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb6, label %ok.19, !prof !99
ok.19:
  br label %bb5
bb5:
  br label %bb7
bb6:
  %t20 = load i32, ptr %l11, !tbaa !23
  %t21 = lshr i32 %t20, 16
  %t22 = and i32 %t20, 65535
  %t23 = icmp eq i32 %t21, 1
  %t24 = select i1 %t23, i32 1, i32 0
  %t25 = icmp eq i32 %t20, 0
  %t26 = shl i32 %t24, 16
  %t27 = or i32 %t26, %t22
  %t28 = select i1 %t25, i32 0, i32 %t27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t30 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t28, 0
  store { i32, { i64, ptr } } %t30, ptr %rv
  br label %ret
bb7:
  %t31 = load i64, ptr %l2, !tbaa !24
  store i64 %t31, ptr %l13, !tbaa !24
  %t32 = load i64, ptr %l13, !tbaa !24
  %t33 = icmp sge i64 %t32, 0
  br i1 %t33, label %bb8, label %bb9
bb8:
  %t35 = load i64, ptr %l13, !tbaa !24
  %t36 = mul i64 %t35, 1
  %t37 = call ptr @__olang_scope_alloc_zeroed(ptr %s1, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l3, !tbaa !27
  %t41 = load { ptr, ptr }, ptr %l0
  %t42 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t44 = extractvalue { ptr, ptr } %t41, 0
  %t45 = extractvalue { ptr, ptr } %t41, 1
  %t47 = call i64 %t44(ptr %t45, ptr %s1, { i64, ptr } %t42)
  store i64 %t47, ptr %l18
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_d680568c47c09218_ee59193b16d39a3c)
  unreachable
bb10:
  %t48 = load i64, ptr %l18, !tbaa !24
  store i64 %t48, ptr %l4, !tbaa !24
  %t49 = load i64, ptr %l4, !tbaa !24
  %t50 = load i64, ptr %l2, !tbaa !24
  %t53 = icmp sle i64 %t49, %t50
  br i1 %t53, label %bb11, label %bb12
bb11:
  %t55 = load i64, ptr %l4, !tbaa !24
  %t56 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t59 = call i32 @std_2fos_2echeck(ptr %v1, i64 %t55, { i64, ptr } %t56)
  store i32 %t59, ptr %l24
  %t60 = icmp ne i32 %t59, 0
  br i1 %t60, label %bb14, label %ok.61, !prof !99
ok.61:
  br label %bb13
bb12:
  br label %bb22
bb13:
  br label %bb15
bb14:
  %t62 = load i32, ptr %l24, !tbaa !23
  %t63 = lshr i32 %t62, 16
  %t64 = and i32 %t62, 65535
  %t65 = icmp eq i32 %t63, 1
  %t66 = select i1 %t65, i32 1, i32 0
  %t67 = icmp eq i32 %t62, 0
  %t68 = shl i32 %t66, 16
  %t69 = or i32 %t68, %t64
  %t70 = select i1 %t67, i32 0, i32 %t69
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t72 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t70, 0
  store { i32, { i64, ptr } } %t72, ptr %rv
  br label %ret
bb15:
  %t73 = load i64, ptr %l4, !tbaa !24
  store i64 %t73, ptr %l26, !tbaa !24
  %t74 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t74, 0
  store i64 %t75, ptr %l27, !tbaa !24
  %t76 = icmp sge i64 0, 0
  br i1 %t76, label %bb16, label %bb17
bb16:
  %t78 = load i64, ptr %l26, !tbaa !24
  %t79 = icmp sle i64 0, %t78
  br i1 %t79, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_a97aa98585cf6243_3a57acf5b7e1165f)
  unreachable
bb18:
  %t81 = load i64, ptr %l26, !tbaa !24
  %t82 = load i64, ptr %l27, !tbaa !24
  %t83 = icmp sle i64 %t81, %t82
  br i1 %t83, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_a97aa98585cf6243_3a57acf5b7e1165f)
  unreachable
bb20:
  %t85 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = load i64, ptr %l26, !tbaa !24
  %t88 = getelementptr i8, ptr %t86, i64 0
  %t89 = sub i64 %t87, 0
  %t90 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t88, 1
  store { i64, ptr } %t91, ptr %l32, !tbaa !27
  %t93 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 0
  store i64 %t94, ptr %l33, !tbaa !24
  %t95 = load i64, ptr %l33, !tbaa !24
  %t96 = mul i64 %t95, 1
  %t97 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t96)
  %t98 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t97, 1
  store { i64, ptr } %t99, ptr %l34, !tbaa !27
  %t100 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = load i64, ptr %l33, !tbaa !24
  %t105 = mul i64 %t104, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t101, ptr %t103, i64 %t105, i1 false)
  %t106 = load { i64, ptr }, ptr %l34, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t109 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t106, 1
  store { i32, { i64, ptr } } %t109, ptr %rv
  br label %ret
bb21:
  call void @__olang_check_failed(ptr @olang_loc_a97aa98585cf6243_3a57acf5b7e1165f)
  unreachable
bb22:
  %t110 = load i64, ptr %l4, !tbaa !24
  store i64 %t110, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb23
bb23:
  br label %bb4
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, i32 } @std_2fos_2ememFile() #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i32
  %l4 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, i32 }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call i32 @std_2fos_2ememfd()
  store i32 %t1, ptr %l1
  br label %bb1
bb1:
  %t2 = load i32, ptr %l1, !tbaa !23
  store i32 %t2, ptr %l0, !tbaa !23
  %t3 = load i32, ptr %l0, !tbaa !23
  %t5 = sext i32 %t3 to i64
  %t7 = call i32 @std_2fos_2echeck(ptr %s0, i64 %t5, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d45, i32 0, i32 1) })
  store i32 %t7, ptr %l4
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb3, label %ok.9, !prof !99
ok.9:
  br label %bb2
bb2:
  br label %bb4
bb3:
  %t10 = load i32, ptr %l4, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  call void @__olang_scope_close(ptr %s0)
  %t20 = insertvalue { i32, i32 } zeroinitializer, i32 %t18, 0
  store { i32, i32 } %t20, ptr %rv
  br label %ret
bb4:
  %t21 = load i32, ptr %l0, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t23 = insertvalue { i32, i32 } zeroinitializer, i32 %t21, 1
  store { i32, i32 } %t23, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local i32 @std_2fos_2eraise(ptr %v0, i32 %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca i64
  %l11 = alloca { i64, [2 x i64] }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, [2 x i64] }
  %l21 = alloca i64
  %l23 = alloca { i64, [2 x i64] }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, [2 x i64] }
  %l33 = alloca i64
  %l35 = alloca { i64, [2 x i64] }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %l44 = alloca { i64, [2 x i64] }
  %l45 = alloca i64
  %l47 = alloca { i64, [2 x i64] }
  %l53 = alloca { i64, ptr }
  %l54 = alloca i64
  %l55 = alloca { i64, ptr }
  %l56 = alloca { i64, [2 x i64] }
  %l57 = alloca i64
  %l59 = alloca { i64, [2 x i64] }
  %l65 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %l68 = alloca { i64, [2 x i64] }
  %l69 = alloca i64
  %l71 = alloca { i64, [2 x i64] }
  %l75 = alloca { i64, ptr }
  %l76 = alloca i64
  %l77 = alloca { i64, ptr }
  %l78 = alloca { i64, [2 x i64] }
  %l79 = alloca i64
  %l81 = alloca { i64, [2 x i64] }
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca i32
  %t20 = alloca { i64, [2 x i64] }, align 8
  %t57 = alloca { i64, [2 x i64] }, align 8
  %t94 = alloca { i64, [2 x i64] }, align 8
  %t131 = alloca { i64, [2 x i64] }, align 8
  %t168 = alloca { i64, [2 x i64] }, align 8
  %t205 = alloca { i64, [2 x i64] }, align 8
  %t238 = alloca { i64, [2 x i64] }, align 8
  store i32 %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !tbaa !23
  %t3 = icmp eq i32 %t1, 1
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb5
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t5, ptr %l5, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l6, !tbaa !24
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = mul i64 %t9, 1
  %t11 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l7, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = load i64, ptr %l6, !tbaa !24
  %t19 = mul i64 %t18, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t15, ptr %t17, i64 %t19, i1 false)
  store { i64, [2 x i64] } zeroinitializer, ptr %t20
  %t21 = getelementptr { i64, [2 x i64] }, ptr %t20, i32 0, i32 0
  store i64 0, ptr %t21
  %t22 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t23 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t22, 0
  %t24 = getelementptr { i64, [2 x i64] }, ptr %t20, i32 0, i32 1
  store { { i64, ptr } } %t23, ptr %t24
  %t25 = load { i64, [2 x i64] }, ptr %t20
  store { i64, [2 x i64] } %t25, ptr %l8
  %t26 = call ptr @__olang_errpay_push()
  %t27 = ptrtoint ptr %t26 to i64
  store i64 %t27, ptr %l9, !tbaa !24
  %t28 = load i64, ptr %l9
  %t29 = inttoptr i64 %t28 to ptr
  %t31 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fos_3aError_24payload(ptr %t29, ptr %l8)
  store { i64, [2 x i64] } %t31, ptr %l11
  br label %bb4
bb4:
  %t32 = load { i64, [2 x i64] }, ptr %l11
  %t33 = load i64, ptr %l9
  %t34 = inttoptr i64 %t33 to ptr
  %t35 = call ptr @__olang_scope_alloc_a(ptr %t34, i64 24, i64 8)
  store { i64, [2 x i64] } %t32, ptr %t35
  call void @__olang_errpay_set(ptr %t35)
  call void @__olang_scope_close(ptr %s1)
  store i32 65536, ptr %rv
  br label %ret
bb5:
  %t38 = load i32, ptr %l0, !tbaa !23
  %t40 = icmp eq i32 %t38, 2
  br i1 %t40, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb10
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t42, ptr %l17, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t44, 0
  store i64 %t45, ptr %l18, !tbaa !24
  %t46 = load i64, ptr %l18, !tbaa !24
  %t47 = mul i64 %t46, 1
  %t48 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  store { i64, ptr } %t50, ptr %l19, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = load i64, ptr %l18, !tbaa !24
  %t56 = mul i64 %t55, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t52, ptr %t54, i64 %t56, i1 false)
  store { i64, [2 x i64] } zeroinitializer, ptr %t57
  %t58 = getelementptr { i64, [2 x i64] }, ptr %t57, i32 0, i32 0
  store i64 1, ptr %t58
  %t59 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t60 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t59, 0
  %t61 = getelementptr { i64, [2 x i64] }, ptr %t57, i32 0, i32 1
  store { { i64, ptr } } %t60, ptr %t61
  %t62 = load { i64, [2 x i64] }, ptr %t57
  store { i64, [2 x i64] } %t62, ptr %l20
  %t63 = call ptr @__olang_errpay_push()
  %t64 = ptrtoint ptr %t63 to i64
  store i64 %t64, ptr %l21, !tbaa !24
  %t65 = load i64, ptr %l21
  %t66 = inttoptr i64 %t65 to ptr
  %t68 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fos_3aError_24payload(ptr %t66, ptr %l20)
  store { i64, [2 x i64] } %t68, ptr %l23
  br label %bb9
bb9:
  %t69 = load { i64, [2 x i64] }, ptr %l23
  %t70 = load i64, ptr %l21
  %t71 = inttoptr i64 %t70 to ptr
  %t72 = call ptr @__olang_scope_alloc_a(ptr %t71, i64 24, i64 8)
  store { i64, [2 x i64] } %t69, ptr %t72
  call void @__olang_errpay_set(ptr %t72)
  call void @__olang_scope_close(ptr %s2)
  store i32 65537, ptr %rv
  br label %ret
bb10:
  %t75 = load i32, ptr %l0, !tbaa !23
  %t77 = icmp eq i32 %t75, 3
  br i1 %t77, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb15
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t79 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t79, ptr %l29, !tbaa !27
  %t81 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t81, 0
  store i64 %t82, ptr %l30, !tbaa !24
  %t83 = load i64, ptr %l30, !tbaa !24
  %t84 = mul i64 %t83, 1
  %t85 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t84)
  %t86 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t85, 1
  store { i64, ptr } %t87, ptr %l31, !tbaa !27
  %t88 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = load i64, ptr %l30, !tbaa !24
  %t93 = mul i64 %t92, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t89, ptr %t91, i64 %t93, i1 false)
  store { i64, [2 x i64] } zeroinitializer, ptr %t94
  %t95 = getelementptr { i64, [2 x i64] }, ptr %t94, i32 0, i32 0
  store i64 2, ptr %t95
  %t96 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t97 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t96, 0
  %t98 = getelementptr { i64, [2 x i64] }, ptr %t94, i32 0, i32 1
  store { { i64, ptr } } %t97, ptr %t98
  %t99 = load { i64, [2 x i64] }, ptr %t94
  store { i64, [2 x i64] } %t99, ptr %l32
  %t100 = call ptr @__olang_errpay_push()
  %t101 = ptrtoint ptr %t100 to i64
  store i64 %t101, ptr %l33, !tbaa !24
  %t102 = load i64, ptr %l33
  %t103 = inttoptr i64 %t102 to ptr
  %t105 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fos_3aError_24payload(ptr %t103, ptr %l32)
  store { i64, [2 x i64] } %t105, ptr %l35
  br label %bb14
bb14:
  %t106 = load { i64, [2 x i64] }, ptr %l35
  %t107 = load i64, ptr %l33
  %t108 = inttoptr i64 %t107 to ptr
  %t109 = call ptr @__olang_scope_alloc_a(ptr %t108, i64 24, i64 8)
  store { i64, [2 x i64] } %t106, ptr %t109
  call void @__olang_errpay_set(ptr %t109)
  call void @__olang_scope_close(ptr %s3)
  store i32 65538, ptr %rv
  br label %ret
bb15:
  %t112 = load i32, ptr %l0, !tbaa !23
  %t114 = icmp eq i32 %t112, 4
  br i1 %t114, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb20
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  %t116 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t116, ptr %l41, !tbaa !27
  %t118 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t118, 0
  store i64 %t119, ptr %l42, !tbaa !24
  %t120 = load i64, ptr %l42, !tbaa !24
  %t121 = mul i64 %t120, 1
  %t122 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t121)
  %t123 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  store { i64, ptr } %t124, ptr %l43, !tbaa !27
  %t125 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = load i64, ptr %l42, !tbaa !24
  %t130 = mul i64 %t129, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t126, ptr %t128, i64 %t130, i1 false)
  store { i64, [2 x i64] } zeroinitializer, ptr %t131
  %t132 = getelementptr { i64, [2 x i64] }, ptr %t131, i32 0, i32 0
  store i64 3, ptr %t132
  %t133 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t134 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t133, 0
  %t135 = getelementptr { i64, [2 x i64] }, ptr %t131, i32 0, i32 1
  store { { i64, ptr } } %t134, ptr %t135
  %t136 = load { i64, [2 x i64] }, ptr %t131
  store { i64, [2 x i64] } %t136, ptr %l44
  %t137 = call ptr @__olang_errpay_push()
  %t138 = ptrtoint ptr %t137 to i64
  store i64 %t138, ptr %l45, !tbaa !24
  %t139 = load i64, ptr %l45
  %t140 = inttoptr i64 %t139 to ptr
  %t142 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fos_3aError_24payload(ptr %t140, ptr %l44)
  store { i64, [2 x i64] } %t142, ptr %l47
  br label %bb19
bb19:
  %t143 = load { i64, [2 x i64] }, ptr %l47
  %t144 = load i64, ptr %l45
  %t145 = inttoptr i64 %t144 to ptr
  %t146 = call ptr @__olang_scope_alloc_a(ptr %t145, i64 24, i64 8)
  store { i64, [2 x i64] } %t143, ptr %t146
  call void @__olang_errpay_set(ptr %t146)
  call void @__olang_scope_close(ptr %s4)
  store i32 65539, ptr %rv
  br label %ret
bb20:
  %t149 = load i32, ptr %l0, !tbaa !23
  %t151 = icmp eq i32 %t149, 5
  br i1 %t151, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb25
bb23:
  store %olang.scope zeroinitializer, ptr %s5
  %t153 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t153, ptr %l53, !tbaa !27
  %t155 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t155, 0
  store i64 %t156, ptr %l54, !tbaa !24
  %t157 = load i64, ptr %l54, !tbaa !24
  %t158 = mul i64 %t157, 1
  %t159 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t158)
  %t160 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t161 = insertvalue { i64, ptr } %t160, ptr %t159, 1
  store { i64, ptr } %t161, ptr %l55, !tbaa !27
  %t162 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !27
  %t164 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !27
  %t166 = load i64, ptr %l54, !tbaa !24
  %t167 = mul i64 %t166, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t163, ptr %t165, i64 %t167, i1 false)
  store { i64, [2 x i64] } zeroinitializer, ptr %t168
  %t169 = getelementptr { i64, [2 x i64] }, ptr %t168, i32 0, i32 0
  store i64 4, ptr %t169
  %t170 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t171 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t170, 0
  %t172 = getelementptr { i64, [2 x i64] }, ptr %t168, i32 0, i32 1
  store { { i64, ptr } } %t171, ptr %t172
  %t173 = load { i64, [2 x i64] }, ptr %t168
  store { i64, [2 x i64] } %t173, ptr %l56
  %t174 = call ptr @__olang_errpay_push()
  %t175 = ptrtoint ptr %t174 to i64
  store i64 %t175, ptr %l57, !tbaa !24
  %t176 = load i64, ptr %l57
  %t177 = inttoptr i64 %t176 to ptr
  %t179 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fos_3aError_24payload(ptr %t177, ptr %l56)
  store { i64, [2 x i64] } %t179, ptr %l59
  br label %bb24
bb24:
  %t180 = load { i64, [2 x i64] }, ptr %l59
  %t181 = load i64, ptr %l57
  %t182 = inttoptr i64 %t181 to ptr
  %t183 = call ptr @__olang_scope_alloc_a(ptr %t182, i64 24, i64 8)
  store { i64, [2 x i64] } %t180, ptr %t183
  call void @__olang_errpay_set(ptr %t183)
  call void @__olang_scope_close(ptr %s5)
  store i32 65540, ptr %rv
  br label %ret
bb25:
  %t186 = load i32, ptr %l0, !tbaa !23
  %t188 = icmp eq i32 %t186, 6
  br i1 %t188, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb30
bb28:
  store %olang.scope zeroinitializer, ptr %s6
  %t190 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t190, ptr %l65, !tbaa !27
  %t192 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t192, 0
  store i64 %t193, ptr %l66, !tbaa !24
  %t194 = load i64, ptr %l66, !tbaa !24
  %t195 = mul i64 %t194, 1
  %t196 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t195)
  %t197 = insertvalue { i64, ptr } undef, i64 %t194, 0
  %t198 = insertvalue { i64, ptr } %t197, ptr %t196, 1
  store { i64, ptr } %t198, ptr %l67, !tbaa !27
  %t199 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !27
  %t201 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !27
  %t203 = load i64, ptr %l66, !tbaa !24
  %t204 = mul i64 %t203, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t200, ptr %t202, i64 %t204, i1 false)
  store { i64, [2 x i64] } zeroinitializer, ptr %t205
  %t206 = getelementptr { i64, [2 x i64] }, ptr %t205, i32 0, i32 0
  store i64 5, ptr %t206
  %t207 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t208 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t207, 0
  %t209 = getelementptr { i64, [2 x i64] }, ptr %t205, i32 0, i32 1
  store { { i64, ptr } } %t208, ptr %t209
  %t210 = load { i64, [2 x i64] }, ptr %t205
  store { i64, [2 x i64] } %t210, ptr %l68
  %t211 = call ptr @__olang_errpay_push()
  %t212 = ptrtoint ptr %t211 to i64
  store i64 %t212, ptr %l69, !tbaa !24
  %t213 = load i64, ptr %l69
  %t214 = inttoptr i64 %t213 to ptr
  %t216 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fos_3aError_24payload(ptr %t214, ptr %l68)
  store { i64, [2 x i64] } %t216, ptr %l71
  br label %bb29
bb29:
  %t217 = load { i64, [2 x i64] }, ptr %l71
  %t218 = load i64, ptr %l69
  %t219 = inttoptr i64 %t218 to ptr
  %t220 = call ptr @__olang_scope_alloc_a(ptr %t219, i64 24, i64 8)
  store { i64, [2 x i64] } %t217, ptr %t220
  call void @__olang_errpay_set(ptr %t220)
  call void @__olang_scope_close(ptr %s6)
  store i32 65541, ptr %rv
  br label %ret
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb35
bb33:
  store %olang.scope zeroinitializer, ptr %s7
  %t223 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t223, ptr %l75, !tbaa !27
  %t225 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t226 = extractvalue { i64, ptr } %t225, 0
  store i64 %t226, ptr %l76, !tbaa !24
  %t227 = load i64, ptr %l76, !tbaa !24
  %t228 = mul i64 %t227, 1
  %t229 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t228)
  %t230 = insertvalue { i64, ptr } undef, i64 %t227, 0
  %t231 = insertvalue { i64, ptr } %t230, ptr %t229, 1
  store { i64, ptr } %t231, ptr %l77, !tbaa !27
  %t232 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !27
  %t234 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = load i64, ptr %l76, !tbaa !24
  %t237 = mul i64 %t236, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t233, ptr %t235, i64 %t237, i1 false)
  store { i64, [2 x i64] } zeroinitializer, ptr %t238
  %t239 = getelementptr { i64, [2 x i64] }, ptr %t238, i32 0, i32 0
  store i64 6, ptr %t239
  %t240 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t241 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t240, 0
  %t242 = getelementptr { i64, [2 x i64] }, ptr %t238, i32 0, i32 1
  store { { i64, ptr } } %t241, ptr %t242
  %t243 = load { i64, [2 x i64] }, ptr %t238
  store { i64, [2 x i64] } %t243, ptr %l78
  %t244 = call ptr @__olang_errpay_push()
  %t245 = ptrtoint ptr %t244 to i64
  store i64 %t245, ptr %l79, !tbaa !24
  %t246 = load i64, ptr %l79
  %t247 = inttoptr i64 %t246 to ptr
  %t249 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fos_3aError_24payload(ptr %t247, ptr %l78)
  store { i64, [2 x i64] } %t249, ptr %l81
  br label %bb34
bb34:
  %t250 = load { i64, [2 x i64] }, ptr %l81
  %t251 = load i64, ptr %l79
  %t252 = inttoptr i64 %t251 to ptr
  %t253 = call ptr @__olang_scope_alloc_a(ptr %t252, i64 24, i64 8)
  store { i64, [2 x i64] } %t250, ptr %t253
  call void @__olang_errpay_set(ptr %t253)
  call void @__olang_scope_close(ptr %s7)
  store i32 65542, ptr %rv
  br label %ret
bb35:
  call void @__olang_check_failed(ptr @olang_loc_6e884a0c8190443b_54808bbd727a9dff)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @std_2fos_2ereadBack(ptr %v0, i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i32
  %l13 = alloca i64
  %l14 = alloca i64
  %l21 = alloca i32
  %l22 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l30 = alloca i64
  %l33 = alloca i32
  %l34 = alloca i32
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l42 = alloca { i64, [2 x i64] }
  %l43 = alloca i64
  %l45 = alloca { i64, [2 x i64] }
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t114 = alloca { i64, [2 x i64] }, align 8
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0, !tbaa !23
  %t3 = call i64 @std_2fos_2eseek(i32 %t1, i32 2)
  store i64 %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load i64, ptr %l6, !tbaa !24
  store i64 %t4, ptr %l1, !tbaa !24
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = icmp slt i64 %t5, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = call i32 @__olang_err()
  store i32 %t9, ptr %l9
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t10 = load i32, ptr %l9, !tbaa !23
  %t11 = call i32 @std_2fos_2eraise(ptr %s1, i32 %t10, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d46, i32 0, i32 1) })
  store i32 %t11, ptr %l10
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb6, label %ok.13, !prof !99
ok.13:
  br label %bb5
bb5:
  br label %bb7
bb6:
  %t14 = load i32, ptr %l10, !tbaa !23
  %t15 = lshr i32 %t14, 16
  %t16 = and i32 %t14, 65535
  %t17 = icmp eq i32 %t15, 1
  %t18 = select i1 %t17, i32 1, i32 0
  %t19 = icmp eq i32 %t14, 0
  %t20 = shl i32 %t18, 16
  %t21 = or i32 %t20, %t16
  %t22 = select i1 %t19, i32 0, i32 %t21
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t24 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t22, 0
  store { i32, { i64, ptr } } %t24, ptr %rv
  br label %ret
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb8:
  %t25 = load i32, ptr %l0, !tbaa !23
  %t27 = call i64 @std_2fos_2eseek(i32 %t25, i32 0)
  store i64 %t27, ptr %l13
  br label %bb9
bb9:
  %t28 = load i64, ptr %l1, !tbaa !24
  store i64 %t28, ptr %l14, !tbaa !24
  %t29 = load i64, ptr %l14, !tbaa !24
  %t30 = icmp sge i64 %t29, 0
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t32 = load i64, ptr %l14, !tbaa !24
  %t33 = mul i64 %t32, 1
  %t34 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t33)
  %t35 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  store { i64, ptr } %t36, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_63206310f1419a1b_2cb9bc5fa11cb777)
  unreachable
bb12:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t39 = load i64, ptr %l1, !tbaa !24
  %t42 = icmp slt i64 %t38, %t39
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb13, label %bb14
bb13:
  br label %bb35
bb14:
  br label %bb15
bb15:
  %t46 = load i32, ptr %l0, !tbaa !23
  store i32 %t46, ptr %l21, !tbaa !23
  %t47 = load i64, ptr %l3, !tbaa !24
  store i64 %t47, ptr %l22, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t48, 0
  store i64 %t50, ptr %l24, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t51, 0
  store i64 %t52, ptr %l25, !tbaa !24
  %t53 = load i64, ptr %l22, !tbaa !24
  %t54 = icmp sge i64 %t53, 0
  br i1 %t54, label %bb16, label %bb17
bb16:
  %t56 = load i64, ptr %l22, !tbaa !24
  %t57 = load i64, ptr %l24, !tbaa !24
  %t58 = icmp sle i64 %t56, %t57
  br i1 %t58, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_57657329f9419e06_2a1a8642ca70aa5a)
  unreachable
bb18:
  %t60 = load i64, ptr %l24, !tbaa !24
  %t61 = load i64, ptr %l25, !tbaa !24
  %t62 = icmp sle i64 %t60, %t61
  br i1 %t62, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_57657329f9419e06_2a1a8642ca70aa5a)
  unreachable
bb20:
  %t64 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = load i64, ptr %l22, !tbaa !24
  %t67 = load i64, ptr %l24, !tbaa !24
  %t68 = getelementptr i8, ptr %t65, i64 %t66
  %t69 = sub i64 %t67, %t66
  %t70 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t68, 1
  %t72 = load i32, ptr %l21, !tbaa !23
  %t74 = call i64 @std_2fos_2erawRead(ptr %s0, i32 %t72, { i64, ptr } %t71)
  store i64 %t74, ptr %l30
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_57657329f9419e06_2a1a8642ca70aa5a)
  unreachable
bb22:
  %t75 = load i64, ptr %l30, !tbaa !24
  store i64 %t75, ptr %l4, !tbaa !24
  %t76 = load i64, ptr %l4, !tbaa !24
  %t78 = icmp slt i64 %t76, 0
  br i1 %t78, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s3
  %t80 = call i32 @__olang_err()
  store i32 %t80, ptr %l33
  br label %bb25
bb24:
  br label %bb29
bb25:
  %t81 = load i32, ptr %l33, !tbaa !23
  %t82 = call i32 @std_2fos_2eraise(ptr %s3, i32 %t81, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d47, i32 0, i32 1) })
  store i32 %t82, ptr %l34
  %t83 = icmp ne i32 %t82, 0
  br i1 %t83, label %bb27, label %ok.84, !prof !99
ok.84:
  br label %bb26
bb26:
  br label %bb28
bb27:
  %t85 = load i32, ptr %l34, !tbaa !23
  %t86 = lshr i32 %t85, 16
  %t87 = and i32 %t85, 65535
  %t88 = icmp eq i32 %t86, 1
  %t89 = select i1 %t88, i32 1, i32 0
  %t90 = icmp eq i32 %t85, 0
  %t91 = shl i32 %t89, 16
  %t92 = or i32 %t91, %t87
  %t93 = select i1 %t90, i32 0, i32 %t92
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t95 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t93, 0
  store { i32, { i64, ptr } } %t95, ptr %rv
  br label %ret
bb28:
  call void @__olang_scope_close(ptr %s3)
  br label %bb29
bb29:
  %t96 = load i64, ptr %l4, !tbaa !24
  %t98 = icmp eq i64 %t96, 0
  br i1 %t98, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s4
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %l38, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t100, ptr %l39, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 0
  store i64 %t102, ptr %l40, !tbaa !24
  %t103 = load i64, ptr %l40, !tbaa !24
  %t104 = mul i64 %t103, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t104)
  %t106 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  store { i64, ptr } %t107, ptr %l41, !tbaa !27
  %t108 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = load i64, ptr %l40, !tbaa !24
  %t113 = mul i64 %t112, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t109, ptr %t111, i64 %t113, i1 false)
  store { i64, [2 x i64] } zeroinitializer, ptr %t114
  %t115 = getelementptr { i64, [2 x i64] }, ptr %t114, i32 0, i32 0
  store i64 6, ptr %t115
  %t116 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t117 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t116, 0
  %t118 = getelementptr { i64, [2 x i64] }, ptr %t114, i32 0, i32 1
  store { { i64, ptr } } %t117, ptr %t118
  %t119 = load { i64, [2 x i64] }, ptr %t114
  store { i64, [2 x i64] } %t119, ptr %l42
  %t120 = call ptr @__olang_errpay_push()
  %t121 = ptrtoint ptr %t120 to i64
  store i64 %t121, ptr %l43, !tbaa !24
  %t122 = load i64, ptr %l43
  %t123 = inttoptr i64 %t122 to ptr
  %t125 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fos_3aError_24payload(ptr %t123, ptr %l42)
  store { i64, [2 x i64] } %t125, ptr %l45
  br label %bb32
bb31:
  br label %bb33
bb32:
  %t126 = load { i64, [2 x i64] }, ptr %l45
  %t127 = load i64, ptr %l43
  %t128 = inttoptr i64 %t127 to ptr
  %t129 = call ptr @__olang_scope_alloc_a(ptr %t128, i64 24, i64 8)
  store { i64, [2 x i64] } %t126, ptr %t129
  call void @__olang_errpay_set(ptr %t129)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t132 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65542, 0
  store { i32, { i64, ptr } } %t132, ptr %rv
  br label %ret
bb33:
  %t133 = load i64, ptr %l3, !tbaa !24
  %t135 = load i64, ptr %l4, !tbaa !24
  %t138 = add i64 %t133, %t135
  store i64 %t138, ptr %l3, !tbaa !24
  br label %bb34
bb34:
  br label %bb12
bb35:
  %t140 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t140, ptr %l52, !tbaa !27
  %t141 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 0
  store i64 %t142, ptr %l53, !tbaa !24
  %t143 = load i64, ptr %l53, !tbaa !24
  %t144 = mul i64 %t143, 1
  %t145 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t144)
  %t146 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t145, 1
  store { i64, ptr } %t147, ptr %l54, !tbaa !27
  %t148 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !27
  %t150 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = load i64, ptr %l53, !tbaa !24
  %t153 = mul i64 %t152, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t149, ptr %t151, i64 %t153, i1 false)
  %t154 = load { i64, ptr }, ptr %l54, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t157 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t154, 1
  store { i32, { i64, ptr } } %t157, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, i64 } @std_2fos_2ereadInto(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1, i64 %a2, { i64, ptr } %a3) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l12 = alloca i32
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i32
  %l28 = alloca i32
  %rv = alloca { i32, i64 }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a2, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l4, !tbaa !24
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t9 = icmp slt i64 %t3, %t6
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  br label %bb23
bb3:
  br label %bb4
bb4:
  store i32 %a0, ptr %l12, !tbaa !23
  %t14 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t14, ptr %l13, !tbaa !27
  %t15 = load i64, ptr %l4, !tbaa !24
  store i64 %t15, ptr %l14, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t16, 0
  store i64 %t19, ptr %l17, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  store i64 %t21, ptr %l18, !tbaa !24
  %t22 = load i64, ptr %l14, !tbaa !24
  %t23 = icmp sge i64 %t22, 0
  br i1 %t23, label %bb5, label %bb6
bb5:
  %t25 = load i64, ptr %l14, !tbaa !24
  %t26 = load i64, ptr %l17, !tbaa !24
  %t27 = icmp sle i64 %t25, %t26
  br i1 %t27, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_118c1c5257346374_e7678ca1d651d180)
  unreachable
bb7:
  %t29 = load i64, ptr %l17, !tbaa !24
  %t30 = load i64, ptr %l18, !tbaa !24
  %t31 = icmp sle i64 %t29, %t30
  br i1 %t31, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_118c1c5257346374_e7678ca1d651d180)
  unreachable
bb9:
  %t33 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = load i64, ptr %l14, !tbaa !24
  %t36 = load i64, ptr %l17, !tbaa !24
  %t37 = getelementptr i8, ptr %t34, i64 %t35
  %t38 = sub i64 %t36, %t35
  %t39 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t37, 1
  %t41 = load i32, ptr %l12, !tbaa !23
  %t43 = call i64 @std_2fos_2erawRead(ptr %v0, i32 %t41, { i64, ptr } %t40)
  store i64 %t43, ptr %l23
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_118c1c5257346374_e7678ca1d651d180)
  unreachable
bb11:
  %t44 = load i64, ptr %l23, !tbaa !24
  store i64 %t44, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t47 = icmp slt i64 %t45, 0
  br i1 %t47, label %bb12, label %bb13
bb12:
  %t49 = call i32 @__olang_err()
  store i32 %t49, ptr %l26
  br label %bb14
bb13:
  br label %bb18
bb14:
  %t51 = load i32, ptr %l26, !tbaa !23
  %t53 = call i32 @std_2fos_2eraise(ptr %v1, i32 %t51, { i64, ptr } %a3)
  store i32 %t53, ptr %l28
  %t54 = icmp ne i32 %t53, 0
  br i1 %t54, label %bb16, label %ok.55, !prof !99
ok.55:
  br label %bb15
bb15:
  br label %bb17
bb16:
  %t56 = load i32, ptr %l28, !tbaa !23
  %t57 = lshr i32 %t56, 16
  %t58 = and i32 %t56, 65535
  %t59 = icmp eq i32 %t57, 1
  %t60 = select i1 %t59, i32 1, i32 0
  %t61 = icmp eq i32 %t56, 0
  %t62 = shl i32 %t60, 16
  %t63 = or i32 %t62, %t58
  %t64 = select i1 %t61, i32 0, i32 %t63
  %t66 = insertvalue { i32, i64 } zeroinitializer, i32 %t64, 0
  store { i32, i64 } %t66, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t67 = load i64, ptr %l5, !tbaa !24
  %t69 = icmp eq i64 %t67, 0
  br i1 %t69, label %bb19, label %bb20
bb19:
  br label %bb23
bb20:
  br label %bb21
bb21:
  %t71 = load i64, ptr %l4, !tbaa !24
  %t73 = load i64, ptr %l5, !tbaa !24
  %t76 = add i64 %t71, %t73
  store i64 %t76, ptr %l4, !tbaa !24
  br label %bb22
bb22:
  br label %bb1
bb23:
  %t78 = load i64, ptr %l4, !tbaa !24
  %t80 = insertvalue { i32, i64 } zeroinitializer, i64 %t78, 1
  store { i32, i64 } %t80, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local i32 @std_2fos_2eremoveTree(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l13 = alloca i32
  %l15 = alloca i32
  %l20 = alloca i1
  %l25 = alloca i32
  %l28 = alloca { i64, ptr }
  %l29 = alloca i32
  %l37 = alloca { i64, ptr }
  %l44 = alloca i32
  %l50 = alloca i32
  %l53 = alloca i32
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 1
  %t10 = extractvalue { i64, ptr } %t7, 0
  %t11 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t14 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t13)
  call void @olang_textcopy(ptr %t14, ptr %t9, i64 %t10)
  %t15 = getelementptr i8, ptr %t14, i64 %t10
  call void @olang_textcopy(ptr %t15, ptr %t11, i64 %t12)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t14, 1
  store { i64, ptr } %t17, ptr %l1, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t21 = call i32 @std_2fos_2eremove(ptr %s0, { i64, ptr } %t19)
  store i32 %t21, ptr %l13
  br label %bb4
bb4:
  %t22 = load i32, ptr %l13, !tbaa !23
  %t23 = icmp eq i32 %t22, 0
  br i1 %t23, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t25 = call i32 @__olang_err()
  store i32 %t25, ptr %l15
  br label %bb8
bb8:
  %t26 = load i32, ptr %l15, !tbaa !23
  store i32 %t26, ptr %l2, !tbaa !23
  %t27 = load i32, ptr %l2, !tbaa !23
  %t29 = icmp eq i32 %t27, 1
  br i1 %t29, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t31 = load i32, ptr %l2, !tbaa !23
  %t33 = icmp ne i32 %t31, 6
  br i1 %t33, label %bb12, label %bb13
bb12:
  %t35 = load i32, ptr %l2, !tbaa !23
  %t37 = icmp ne i32 %t35, 2
  store i1 %t37, ptr %l20, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb14
bb14:
  %t39 = load i1, ptr %l20, !tbaa !21
  br i1 %t39, label %bb15, label %bb16
bb15:
  %t40 = load i32, ptr %l2, !tbaa !23
  %t41 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t44 = call i32 @std_2fos_2eraise(ptr %v0, i32 %t40, { i64, ptr } %t41)
  store i32 %t44, ptr %l25
  %t45 = icmp ne i32 %t44, 0
  br i1 %t45, label %bb18, label %ok.46, !prof !99
ok.46:
  br label %bb17
bb16:
  br label %bb20
bb17:
  br label %bb19
bb18:
  %t47 = load i32, ptr %l25, !tbaa !23
  %t48 = lshr i32 %t47, 16
  %t49 = and i32 %t47, 65535
  %t50 = icmp eq i32 %t48, 1
  %t51 = select i1 %t50, i32 1, i32 0
  %t52 = icmp eq i32 %t47, 0
  %t53 = shl i32 %t51, 16
  %t54 = or i32 %t53, %t49
  %t55 = select i1 %t52, i32 0, i32 %t54
  call void @__olang_scope_close(ptr %s0)
  store i32 %t55, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s6
  %t57 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t59 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %s6, { i64, ptr } %t57)
  %t60 = extractvalue { i32, { i64, ptr } } %t59, 1
  %t61 = extractvalue { i32, { i64, ptr } } %t59, 0
  store i32 %t61, ptr %l29
  %t62 = icmp ne i32 %t61, 0
  br i1 %t62, label %bb22, label %ok.63, !prof !99
ok.63:
  store { i64, ptr } %t60, ptr %l28
  br label %bb21
bb21:
  %t64 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t64, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t65, 0
  store i64 %t67, ptr %l5, !tbaa !24
  br label %bb23
bb22:
  %t69 = load i32, ptr %l29, !tbaa !23
  %t70 = lshr i32 %t69, 16
  %t71 = and i32 %t69, 65535
  %t72 = icmp eq i32 %t70, 1
  %t73 = select i1 %t72, i32 1, i32 0
  %t74 = icmp eq i32 %t69, 0
  %t75 = shl i32 %t73, 16
  %t76 = or i32 %t75, %t71
  %t77 = select i1 %t74, i32 0, i32 %t76
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t77, ptr %rv
  br label %ret
bb23:
  store %olang.scope zeroinitializer, ptr %s7
  %t79 = load i64, ptr %l4, !tbaa !24
  %t80 = load i64, ptr %l5, !tbaa !24
  %t83 = icmp slt i64 %t79, %t80
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s7)
  br label %bb31
bb25:
  br label %bb26
bb26:
  %t87 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t87, ptr %l37, !tbaa !27
  %t88 = load i64, ptr %l4, !tbaa !24
  %t90 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %t91, i64 %t88
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !37
  %t95 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t95, 1
  %t99 = extractvalue { i64, ptr } %t95, 0
  %t100 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t101 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t102 = add i64 %t99, %t101
  %t104 = extractvalue { i64, ptr } %t93, 1
  %t105 = extractvalue { i64, ptr } %t93, 0
  %t106 = add i64 %t102, %t105
  %t107 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t106)
  call void @olang_textcopy(ptr %t107, ptr %t98, i64 %t99)
  %t108 = getelementptr i8, ptr %t107, i64 %t99
  call void @olang_textcopy(ptr %t108, ptr %t100, i64 %t101)
  %t109 = getelementptr i8, ptr %t108, i64 %t101
  call void @olang_textcopy(ptr %t109, ptr %t104, i64 %t105)
  %t110 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t107, 1
  %t114 = call i32 @std_2fos_2eremoveTree(ptr %s7, { i64, ptr } %t111)
  store i32 %t114, ptr %l44
  %t115 = icmp ne i32 %t114, 0
  br i1 %t115, label %bb28, label %ok.116, !prof !99
ok.116:
  br label %bb27
bb27:
  br label %bb29
bb28:
  %t117 = load i32, ptr %l44, !tbaa !23
  %t118 = lshr i32 %t117, 16
  %t119 = and i32 %t117, 65535
  %t120 = icmp eq i32 %t118, 1
  %t121 = select i1 %t120, i32 1, i32 0
  %t122 = icmp eq i32 %t117, 0
  %t123 = shl i32 %t121, 16
  %t124 = or i32 %t123, %t119
  %t125 = select i1 %t122, i32 0, i32 %t124
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t125, ptr %rv
  br label %ret
bb29:
  call void @__olang_scope_close(ptr %s7)
  br label %bb30
bb30:
  %t127 = load i64, ptr %l4, !tbaa !24
  %t130 = add i64 %t127, 1
  store i64 %t130, ptr %l4, !tbaa !24
  br label %bb23
bb31:
  call void @__olang_scope_close(ptr %s6)
  br label %bb32
bb32:
  %t132 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t134 = call i32 @std_2fos_2eremove(ptr %s0, { i64, ptr } %t132)
  store i32 %t134, ptr %l50
  br label %bb33
bb33:
  %t135 = load i32, ptr %l50, !tbaa !23
  %t136 = sext i32 %t135 to i64
  %t137 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t140 = call i32 @std_2fos_2echeck(ptr %v0, i64 %t136, { i64, ptr } %t137)
  store i32 %t140, ptr %l53
  %t141 = icmp ne i32 %t140, 0
  br i1 %t141, label %bb35, label %ok.142, !prof !99
ok.142:
  br label %bb34
bb34:
  br label %bb36
bb35:
  %t143 = load i32, ptr %l53, !tbaa !23
  %t144 = lshr i32 %t143, 16
  %t145 = and i32 %t143, 65535
  %t146 = icmp eq i32 %t144, 1
  %t147 = select i1 %t146, i32 1, i32 0
  %t148 = icmp eq i32 %t143, 0
  %t149 = shl i32 %t147, 16
  %t150 = or i32 %t149, %t145
  %t151 = select i1 %t148, i32 0, i32 %t150
  call void @__olang_scope_close(ptr %s0)
  store i32 %t151, ptr %rv
  br label %ret
bb36:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fos_2estartProgram(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i32 %a2, i32 %a3, i32 %a4, { i64, ptr } %a5) #0 {
entry:
  %l16 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t20 = extractvalue { i64, ptr } %a5, 1
  %t21 = extractvalue { i64, ptr } %a5, 0
  %t22 = call i32 @__olang_spawn(ptr %t13, i64 %t5, i32 %a2, i32 %a3, i32 %a4, ptr %t20)
  store i32 %t22, ptr %l16
  br label %bb1
bb1:
  %t23 = load i32, ptr %l16, !tbaa !23
  store i32 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, %"std/os:Output" } @std_2fos_2estd_2fos_3aProcess_2eWait(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca [1 x i32]
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca i64
  %l11 = alloca { i64, [2 x i64] }
  %l19 = alloca i32
  %l21 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca i32
  %l25 = alloca %"std/os:Output"
  %l28 = alloca %"std/os:Output"
  %l29 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i32, %"std/os:Output" }
  %t20 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/os:Process", ptr %t1, i32 0, i32 4
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d51, i32 0, i32 1) }, ptr %l4, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %l5, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l6, !tbaa !24
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = mul i64 %t9, 1
  %t11 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l7, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = load i64, ptr %l6, !tbaa !24
  %t19 = mul i64 %t18, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t15, ptr %t17, i64 %t19, i1 false)
  store { i64, [2 x i64] } zeroinitializer, ptr %t20
  %t21 = getelementptr { i64, [2 x i64] }, ptr %t20, i32 0, i32 0
  store i64 6, ptr %t21
  %t22 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t23 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t22, 0
  %t24 = getelementptr { i64, [2 x i64] }, ptr %t20, i32 0, i32 1
  store { { i64, ptr } } %t23, ptr %t24
  %t25 = load { i64, [2 x i64] }, ptr %t20
  store { i64, [2 x i64] } %t25, ptr %l8
  %t26 = call ptr @__olang_errpay_push()
  %t27 = ptrtoint ptr %t26 to i64
  store i64 %t27, ptr %l9, !tbaa !24
  %t28 = load i64, ptr %l9
  %t29 = inttoptr i64 %t28 to ptr
  %t31 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fos_3aError_24payload(ptr %t29, ptr %l8)
  store { i64, [2 x i64] } %t31, ptr %l11
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t32 = load { i64, [2 x i64] }, ptr %l11
  %t33 = load i64, ptr %l9
  %t34 = inttoptr i64 %t33 to ptr
  %t35 = call ptr @__olang_scope_alloc_a(ptr %t34, i64 24, i64 8)
  store { i64, [2 x i64] } %t32, ptr %t35
  call void @__olang_errpay_set(ptr %t35)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t38 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 65542, 0
  store { i32, %"std/os:Output" } %t38, ptr %rv
  br label %ret
bb4:
  %t39 = insertvalue [1 x i32] undef, i32 0, 0
  store [1 x i32] %t39, ptr %l1
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"std/os:Process", ptr %t41, i32 0, i32 0
  %t44 = load i32, ptr %t43, !tbaa !23
  %t46 = insertvalue { i64, ptr } undef, i64 1, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %l1, 1
  %t50 = call i32 @std_2fos_2ewaitFor(ptr %s0, i32 %t44, { i64, ptr } %t47, i1 false)
  store i32 %t50, ptr %l19
  br label %bb5
bb5:
  %t51 = load i32, ptr %l19, !tbaa !23
  %t52 = icmp slt i32 %t51, 0
  br i1 %t52, label %bb6, label %bb7
bb6:
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l21, !tbaa !29
  %t55 = call i32 @__olang_err()
  store i32 %t55, ptr %l22
  br label %bb8
bb7:
  br label %bb12
bb8:
  %t56 = load ptr, ptr %l21, !tbaa !29
  %t57 = load i32, ptr %l22, !tbaa !23
  %t58 = call i32 @std_2fos_2estd_2fos_3aProcess_2elost(ptr %v0, ptr %t56, i32 %t57)
  store i32 %t58, ptr %l23
  %t59 = icmp ne i32 %t58, 0
  br i1 %t59, label %bb10, label %ok.60, !prof !99
ok.60:
  br label %bb9
bb9:
  br label %bb11
bb10:
  %t61 = load i32, ptr %l23, !tbaa !23
  %t62 = lshr i32 %t61, 16
  %t63 = and i32 %t61, 65535
  %t64 = icmp eq i32 %t62, 1
  %t65 = select i1 %t64, i32 1, i32 0
  %t66 = icmp eq i32 %t61, 0
  %t67 = shl i32 %t65, 16
  %t68 = or i32 %t67, %t63
  %t69 = select i1 %t66, i32 0, i32 %t68
  call void @__olang_scope_close(ptr %s0)
  %t71 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t69, 0
  store { i32, %"std/os:Output" } %t71, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr [1 x i32], ptr %l1, i64 0, i64 0
  %t74 = load i32, ptr %t73, !tbaa !33
  %t77 = call { i32, %"std/os:Output" } @std_2fos_2estd_2fos_3aProcess_2eended(ptr %v0, ptr %v1, ptr %t72, i32 %t74)
  %t78 = extractvalue { i32, %"std/os:Output" } %t77, 1
  %t79 = extractvalue { i32, %"std/os:Output" } %t77, 0
  store i32 %t79, ptr %l29
  %t80 = icmp ne i32 %t79, 0
  br i1 %t80, label %bb14, label %ok.81, !prof !99
ok.81:
  store %"std/os:Output" %t78, ptr %l28
  br label %bb13
bb13:
  %t82 = load %"std/os:Output", ptr %l28
  store %"std/os:Output" %t82, ptr %l25
  br label %bb15
bb14:
  %t83 = load i32, ptr %l29, !tbaa !23
  %t84 = lshr i32 %t83, 16
  %t85 = and i32 %t83, 65535
  %t86 = icmp eq i32 %t84, 1
  %t87 = select i1 %t86, i32 1, i32 0
  %t88 = icmp eq i32 %t83, 0
  %t89 = shl i32 %t87, 16
  %t90 = or i32 %t89, %t85
  %t91 = select i1 %t88, i32 0, i32 %t90
  call void @__olang_scope_close(ptr %s0)
  %t93 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t91, 0
  store { i32, %"std/os:Output" } %t93, ptr %rv
  br label %ret
bb15:
  call void @__olang_scope_close(ptr %s0)
  %t94 = load %"std/os:Output", ptr %l25
  %t95 = insertvalue { i32, %"std/os:Output" } zeroinitializer, %"std/os:Output" %t94, 1
  store { i32, %"std/os:Output" } %t95, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/os:Output" }, ptr %rv
  ret { i32, %"std/os:Output" } %rr
}

define dso_local { i32, %"std/os:Output" } @std_2fos_2estd_2fos_3aProcess_2eended(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l17 = alloca %"std/os:Output"
  %l18 = alloca i32
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca i32
  %l26 = alloca i32
  %l29 = alloca i32
  %l32 = alloca i32
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca i32
  %l40 = alloca i32
  %l43 = alloca i32
  %l46 = alloca i32
  %l47 = alloca %"std/os:Output"
  %l50 = alloca i32
  %l53 = alloca i32
  %rv = alloca { i32, %"std/os:Output" }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/os:Process", ptr %t1, i32 0, i32 4
  store i1 true, ptr %t3, !tbaa !21
  %t4 = load i32, ptr %l1, !tbaa !23
  %t6 = ashr i32 %t4, 8
  %t8 = and i32 %t6, 255
  store i32 %t8, ptr %l2, !tbaa !23
  %t10 = load i32, ptr %l1, !tbaa !23
  %t12 = and i32 %t10, 127
  %t14 = icmp ne i32 %t12, 0
  br i1 %t14, label %bb1, label %bb2
bb1:
  %t16 = load i32, ptr %l1, !tbaa !23
  %t18 = and i32 %t16, 127
  %t20 = add i32 128, %t18
  store i32 %t20, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"std/os:Process", ptr %t22, i32 0, i32 3
  %t25 = load i1, ptr %t24, !tbaa !21
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb4, label %bb5
bb4:
  %t29 = load i32, ptr %l2, !tbaa !23
  %t31 = call %"std/os:Output" @std_2fos_3aOutput_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t29, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d52, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d53, i32 0, i32 1) })
  store %"std/os:Output" %t31, ptr %l17
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t32 = load %"std/os:Output", ptr %l17
  %t33 = insertvalue { i32, %"std/os:Output" } zeroinitializer, %"std/os:Output" %t32, 1
  store { i32, %"std/os:Output" } %t33, ptr %rv
  br label %ret
bb7:
  %t34 = load i32, ptr %l2, !tbaa !23
  store i32 %t34, ptr %l18, !tbaa !23
  %t35 = call ptr @__olang_scope_hold(ptr %v1)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l20, !tbaa !24
  %t37 = load i1, ptr @olang_2esole_2estd_2fos_3aOutput_2e1
  br i1 %t37, label %bb8, label %bb9
bb8:
  %t39 = call ptr @__olang_region_make(ptr %v1)
  %t40 = ptrtoint ptr %t39 to i64
  store i64 %t40, ptr %l20, !tbaa !24
  br label %bb9
bb9:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"std/os:Process", ptr %t41, i32 0, i32 1
  %t44 = load i32, ptr %t43, !tbaa !23
  %t45 = load i64, ptr %l20
  %t46 = inttoptr i64 %t45 to ptr
  %t48 = call { i32, { i64, ptr } } @std_2fos_2ereadBack(ptr %t46, i32 %t44)
  %t49 = extractvalue { i32, { i64, ptr } } %t48, 1
  %t50 = extractvalue { i32, { i64, ptr } } %t48, 0
  store i32 %t50, ptr %l25
  %t51 = icmp ne i32 %t50, 0
  br i1 %t51, label %bb11, label %ok.52, !prof !99
ok.52:
  store { i64, ptr } %t49, ptr %l24
  br label %bb10
bb10:
  %t53 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t53, ptr %l19, !tbaa !27
  br label %bb14
bb11:
  %t54 = load i32, ptr %l25, !tbaa !23
  %t55 = lshr i32 %t54, 16
  %t56 = and i32 %t54, 65535
  %t57 = icmp eq i32 %t55, 1
  %t58 = select i1 %t57, i32 1, i32 0
  %t59 = icmp eq i32 %t54, 0
  %t60 = shl i32 %t58, 16
  %t61 = or i32 %t60, %t56
  %t62 = select i1 %t59, i32 0, i32 %t61
  store i32 %t62, ptr %l26, !tbaa !23
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"std/os:Process", ptr %t63, i32 0, i32 1
  %t66 = load i32, ptr %t65, !tbaa !23
  %t68 = call i32 @close(i32 %t66)
  store i32 %t68, ptr %l29
  br label %bb12
bb12:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"std/os:Process", ptr %t69, i32 0, i32 2
  %t72 = load i32, ptr %t71, !tbaa !23
  %t74 = call i32 @close(i32 %t72)
  store i32 %t74, ptr %l32
  br label %bb13
bb13:
  %t75 = load i32, ptr %l26, !tbaa !23
  %t76 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t75, 0
  store { i32, %"std/os:Output" } %t76, ptr %rv
  br label %ret
bb14:
  %t77 = call ptr @__olang_scope_hold(ptr %v1)
  %t78 = ptrtoint ptr %t77 to i64
  store i64 %t78, ptr %l34, !tbaa !24
  %t79 = load i1, ptr @olang_2esole_2estd_2fos_3aOutput_2e2
  br i1 %t79, label %bb15, label %bb16
bb15:
  %t81 = call ptr @__olang_region_make(ptr %v1)
  %t82 = ptrtoint ptr %t81 to i64
  store i64 %t82, ptr %l34, !tbaa !24
  br label %bb16
bb16:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"std/os:Process", ptr %t83, i32 0, i32 2
  %t86 = load i32, ptr %t85, !tbaa !23
  %t87 = load i64, ptr %l34
  %t88 = inttoptr i64 %t87 to ptr
  %t90 = call { i32, { i64, ptr } } @std_2fos_2ereadBack(ptr %t88, i32 %t86)
  %t91 = extractvalue { i32, { i64, ptr } } %t90, 1
  %t92 = extractvalue { i32, { i64, ptr } } %t90, 0
  store i32 %t92, ptr %l39
  %t93 = icmp ne i32 %t92, 0
  br i1 %t93, label %bb18, label %ok.94, !prof !99
ok.94:
  store { i64, ptr } %t91, ptr %l38
  br label %bb17
bb17:
  %t95 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t95, ptr %l33, !tbaa !27
  br label %bb21
bb18:
  %t96 = load i32, ptr %l39, !tbaa !23
  %t97 = lshr i32 %t96, 16
  %t98 = and i32 %t96, 65535
  %t99 = icmp eq i32 %t97, 1
  %t100 = select i1 %t99, i32 1, i32 0
  %t101 = icmp eq i32 %t96, 0
  %t102 = shl i32 %t100, 16
  %t103 = or i32 %t102, %t98
  %t104 = select i1 %t101, i32 0, i32 %t103
  store i32 %t104, ptr %l40, !tbaa !23
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"std/os:Process", ptr %t105, i32 0, i32 1
  %t108 = load i32, ptr %t107, !tbaa !23
  %t110 = call i32 @close(i32 %t108)
  store i32 %t110, ptr %l43
  br label %bb19
bb19:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"std/os:Process", ptr %t111, i32 0, i32 2
  %t114 = load i32, ptr %t113, !tbaa !23
  %t116 = call i32 @close(i32 %t114)
  store i32 %t116, ptr %l46
  br label %bb20
bb20:
  %t117 = load i32, ptr %l40, !tbaa !23
  %t118 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t117, 0
  store { i32, %"std/os:Output" } %t118, ptr %rv
  br label %ret
bb21:
  %t119 = load i32, ptr %l18, !tbaa !23
  %t120 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t121 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t122 = call %"std/os:Output" @std_2fos_3aOutput_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t119, { i64, ptr } %t120, { i64, ptr } %t121)
  store %"std/os:Output" %t122, ptr %l47
  br label %bb22
bb22:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"std/os:Process", ptr %t123, i32 0, i32 1
  %t126 = load i32, ptr %t125, !tbaa !23
  %t128 = call i32 @close(i32 %t126)
  store i32 %t128, ptr %l50
  br label %bb23
bb23:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"std/os:Process", ptr %t129, i32 0, i32 2
  %t132 = load i32, ptr %t131, !tbaa !23
  %t134 = call i32 @close(i32 %t132)
  store i32 %t134, ptr %l53
  br label %bb24
bb24:
  %t135 = load %"std/os:Output", ptr %l47
  %t136 = insertvalue { i32, %"std/os:Output" } zeroinitializer, %"std/os:Output" %t135, 1
  store { i32, %"std/os:Output" } %t136, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/os:Output" }, ptr %rv
  ret { i32, %"std/os:Output" } %rr
}

define dso_local { i32, %"std/os:Output" } @std_2fos_2estd_2fos_3aProcess_2ewaitNapping(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca [1 x i32]
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca %"<fcntl.h>:timespec"
  %l12 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i32
  %l23 = alloca %"std/os:Output"
  %l26 = alloca %"std/os:Output"
  %l27 = alloca i32
  %l30 = alloca i1
  %l36 = alloca i32
  %l38 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca i32
  %l42 = alloca %"std/os:Output"
  %l45 = alloca %"std/os:Output"
  %l46 = alloca i32
  %l48 = alloca i1
  %l52 = alloca i32
  %l55 = alloca i64
  %l58 = alloca i1
  %l68 = alloca %"<fcntl.h>:timespec"
  %l77 = alloca i32
  %l78 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i32, %"std/os:Output" }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = insertvalue [1 x i32] undef, i32 0, 0
  store [1 x i32] %t1, ptr %l2
  store i64 50000, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"std/os:Process", ptr %t3, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  %t8 = insertvalue { i64, ptr } undef, i64 1, 0
  %t9 = insertvalue { i64, ptr } %t8, ptr %l2, 1
  %t12 = call i32 @std_2fos_2ewaitFor(ptr %s0, i32 %t6, { i64, ptr } %t9, i1 true)
  store i32 %t12, ptr %l12
  br label %bb2
bb2:
  %t13 = load i32, ptr %l12, !tbaa !23
  store i32 %t13, ptr %l4, !tbaa !23
  %t14 = load i32, ptr %l4, !tbaa !23
  %t16 = icmp slt i32 %t14, 0
  br i1 %t16, label %bb3, label %bb4
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l15, !tbaa !29
  %t19 = call i32 @__olang_err()
  store i32 %t19, ptr %l16
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t20 = load ptr, ptr %l15, !tbaa !29
  %t21 = load i32, ptr %l16, !tbaa !23
  %t22 = call i32 @std_2fos_2estd_2fos_3aProcess_2elost(ptr %v0, ptr %t20, i32 %t21)
  store i32 %t22, ptr %l17
  %t23 = icmp ne i32 %t22, 0
  br i1 %t23, label %bb7, label %ok.24, !prof !99
ok.24:
  br label %bb6
bb6:
  br label %bb8
bb7:
  %t25 = load i32, ptr %l17, !tbaa !23
  %t26 = lshr i32 %t25, 16
  %t27 = and i32 %t25, 65535
  %t28 = icmp eq i32 %t26, 1
  %t29 = select i1 %t28, i32 1, i32 0
  %t30 = icmp eq i32 %t25, 0
  %t31 = shl i32 %t29, 16
  %t32 = or i32 %t31, %t27
  %t33 = select i1 %t30, i32 0, i32 %t32
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t35 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t33, 0
  store { i32, %"std/os:Output" } %t35, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t36 = load i32, ptr %l4, !tbaa !23
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"std/os:Process", ptr %t37, i32 0, i32 0
  %t40 = load i32, ptr %t39, !tbaa !23
  %t43 = icmp eq i32 %t36, %t40
  br i1 %t43, label %bb10, label %bb11
bb10:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr [1 x i32], ptr %l2, i64 0, i64 0
  %t47 = load i32, ptr %t46, !tbaa !33
  %t50 = call { i32, %"std/os:Output" } @std_2fos_2estd_2fos_3aProcess_2eended(ptr %v0, ptr %v2, ptr %t45, i32 %t47)
  %t51 = extractvalue { i32, %"std/os:Output" } %t50, 1
  %t52 = extractvalue { i32, %"std/os:Output" } %t50, 0
  store i32 %t52, ptr %l27
  %t53 = icmp ne i32 %t52, 0
  br i1 %t53, label %bb13, label %ok.54, !prof !99
ok.54:
  store %"std/os:Output" %t51, ptr %l26
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t55 = load %"std/os:Output", ptr %l26
  store %"std/os:Output" %t55, ptr %l23
  br label %bb14
bb13:
  %t56 = load i32, ptr %l27, !tbaa !23
  %t57 = lshr i32 %t56, 16
  %t58 = and i32 %t56, 65535
  %t59 = icmp eq i32 %t57, 1
  %t60 = select i1 %t59, i32 1, i32 0
  %t61 = icmp eq i32 %t56, 0
  %t62 = shl i32 %t60, 16
  %t63 = or i32 %t62, %t58
  %t64 = select i1 %t61, i32 0, i32 %t63
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t66 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t64, 0
  store { i32, %"std/os:Output" } %t66, ptr %rv
  br label %ret
bb14:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t67 = load %"std/os:Output", ptr %l23
  %t68 = insertvalue { i32, %"std/os:Output" } zeroinitializer, %"std/os:Output" %t67, 1
  store { i32, %"std/os:Output" } %t68, ptr %rv
  br label %ret
bb15:
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t71 = call i1 @std_2fcancel_2estd_2fcancel_3aToken_2eCancelled(ptr %v1, ptr %t69)
  store i1 %t71, ptr %l30
  br label %bb16
bb16:
  %t72 = load i1, ptr %l30, !tbaa !21
  br i1 %t72, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t73 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fos_2estd_2fos_3aProcess_2eKill(ptr %v0, ptr %t73)
  br label %bb19
bb18:
  br label %bb37
bb19:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"std/os:Process", ptr %t75, i32 0, i32 0
  %t78 = load i32, ptr %t77, !tbaa !23
  %t80 = insertvalue { i64, ptr } undef, i64 1, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %l2, 1
  %t84 = call i32 @std_2fos_2ewaitFor(ptr %s0, i32 %t78, { i64, ptr } %t81, i1 false)
  store i32 %t84, ptr %l36
  br label %bb20
bb20:
  %t85 = load i32, ptr %l36, !tbaa !23
  %t86 = icmp slt i32 %t85, 0
  br i1 %t86, label %bb21, label %bb22
bb21:
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l38, !tbaa !29
  %t89 = call i32 @__olang_err()
  store i32 %t89, ptr %l39
  br label %bb23
bb22:
  br label %bb27
bb23:
  %t90 = load ptr, ptr %l38, !tbaa !29
  %t91 = load i32, ptr %l39, !tbaa !23
  %t92 = call i32 @std_2fos_2estd_2fos_3aProcess_2elost(ptr %v0, ptr %t90, i32 %t91)
  store i32 %t92, ptr %l40
  %t93 = icmp ne i32 %t92, 0
  br i1 %t93, label %bb25, label %ok.94, !prof !99
ok.94:
  br label %bb24
bb24:
  br label %bb26
bb25:
  %t95 = load i32, ptr %l40, !tbaa !23
  %t96 = lshr i32 %t95, 16
  %t97 = and i32 %t95, 65535
  %t98 = icmp eq i32 %t96, 1
  %t99 = select i1 %t98, i32 1, i32 0
  %t100 = icmp eq i32 %t95, 0
  %t101 = shl i32 %t99, 16
  %t102 = or i32 %t101, %t97
  %t103 = select i1 %t100, i32 0, i32 %t102
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t105 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t103, 0
  store { i32, %"std/os:Output" } %t105, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr [1 x i32], ptr %l2, i64 0, i64 0
  %t108 = load i32, ptr %t107, !tbaa !33
  %t111 = call { i32, %"std/os:Output" } @std_2fos_2estd_2fos_3aProcess_2eended(ptr %v0, ptr %s4, ptr %t106, i32 %t108)
  %t112 = extractvalue { i32, %"std/os:Output" } %t111, 1
  %t113 = extractvalue { i32, %"std/os:Output" } %t111, 0
  store i32 %t113, ptr %l46
  %t114 = icmp ne i32 %t113, 0
  br i1 %t114, label %bb29, label %ok.115, !prof !99
ok.115:
  store %"std/os:Output" %t112, ptr %l45
  br label %bb28
bb28:
  %t116 = load %"std/os:Output", ptr %l45
  store %"std/os:Output" %t116, ptr %l42
  br label %bb33
bb29:
  %t117 = load i32, ptr %l46, !tbaa !23
  %t118 = ashr i32 %t117, 16
  %t120 = icmp eq i32 %t118, 1
  store i1 %t120, ptr %l48, !tbaa !21
  %t121 = load i32, ptr %l46, !tbaa !23
  %t122 = ashr i32 %t121, 16
  %t124 = icmp eq i32 %t122, 1
  br i1 %t124, label %bb30, label %bb31
bb30:
  call void @__olang_errpay_pop()
  br label %bb31
bb31:
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t128 = call i32 @std_2fcancel_2estd_2fcancel_3aToken_2eReason(ptr %v1, ptr %t126)
  store i32 %t128, ptr %l52
  %t129 = icmp ne i32 %t128, 0
  br i1 %t129, label %bb35, label %ok.130, !prof !99
ok.130:
  br label %bb34
bb34:
  br label %bb36
bb35:
  %t131 = load i32, ptr %l52, !tbaa !23
  %t132 = lshr i32 %t131, 16
  %t133 = and i32 %t131, 65535
  %t134 = icmp eq i32 %t132, 1
  %t135 = select i1 %t134, i32 2, i32 0
  %t136 = icmp eq i32 %t131, 0
  %t137 = shl i32 %t135, 16
  %t138 = or i32 %t137, %t133
  %t139 = select i1 %t136, i32 0, i32 %t138
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t141 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t139, 0
  store { i32, %"std/os:Output" } %t141, ptr %rv
  br label %ret
bb36:
  call void @__olang_scope_close(ptr %s4)
  br label %bb37
bb37:
  %t142 = load ptr, ptr %l1, !tbaa !29
  %t144 = call i64 @std_2fcancel_2estd_2fcancel_3aToken_2eLeftNs(ptr %v1, ptr %t142)
  store i64 %t144, ptr %l55
  br label %bb38
bb38:
  %t145 = load i64, ptr %l55, !tbaa !24
  store i64 %t145, ptr %l5, !tbaa !24
  %t146 = load i64, ptr %l5, !tbaa !24
  %t148 = icmp slt i64 %t146, 0
  br i1 %t148, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l58, !tbaa !21
  br label %bb41
bb40:
  %t150 = load i64, ptr %l5, !tbaa !24
  %t151 = load i64, ptr %l3, !tbaa !24
  %t154 = icmp sgt i64 %t150, %t151
  store i1 %t154, ptr %l58, !tbaa !21
  br label %bb41
bb41:
  %t156 = load i1, ptr %l58, !tbaa !21
  br i1 %t156, label %bb42, label %bb43
bb42:
  %t157 = load i64, ptr %l3, !tbaa !24
  store i64 %t157, ptr %l5, !tbaa !24
  br label %bb44
bb43:
  br label %bb44
bb44:
  %t159 = load i64, ptr %l3, !tbaa !24
  %t161 = icmp slt i64 %t159, 10000000
  br i1 %t161, label %bb45, label %bb46
bb45:
  %t163 = load i64, ptr %l3, !tbaa !24
  %t166 = mul i64 %t163, 2
  store i64 %t166, ptr %l3, !tbaa !24
  br label %bb47
bb46:
  br label %bb47
bb47:
  %t168 = call %"<fcntl.h>:timespec" @_3cfcntl_2eh_3e_3atimespec_2ector(ptr %s1)
  store %"<fcntl.h>:timespec" %t168, ptr %l68
  br label %bb48
bb48:
  %t169 = load %"<fcntl.h>:timespec", ptr %l68
  store %"<fcntl.h>:timespec" %t169, ptr %l6
  %t170 = load i64, ptr %l5, !tbaa !24
  %t172 = sdiv i64 %t170, 1000000000
  %t174 = getelementptr %"<fcntl.h>:timespec", ptr %l6, i32 0, i32 0
  store i64 %t172, ptr %t174, !tbaa !24
  %t175 = load i64, ptr %l5, !tbaa !24
  %t177 = srem i64 %t175, 1000000000
  %t179 = trunc i64 %t177 to i32
  %t181 = sext i32 %t179 to i64
  %t183 = getelementptr %"<fcntl.h>:timespec", ptr %l6, i32 0, i32 1
  store i64 %t181, ptr %t183, !tbaa !24
  %t186 = call i32 @nanosleep(ptr %l6, ptr %l6)
  store i32 %t186, ptr %l77
  br label %bb49
bb49:
  %t187 = load ptr, ptr %l0, !tbaa !29
  store ptr %t187, ptr %l78, !tbaa !29
  %t188 = load ptr, ptr %l78, !tbaa !29
  %t189 = getelementptr %"std/os:Process", ptr %t188, i32 0, i32 5
  %t190 = load i64, ptr %t189, !tbaa !24
  %t193 = add i64 %t190, 1
  %t195 = load ptr, ptr %l78, !tbaa !29
  %t196 = getelementptr %"std/os:Process", ptr %t195, i32 0, i32 5
  store i64 %t193, ptr %t196, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb50
bb50:
  br label %bb1
ret:
  %rr = load { i32, %"std/os:Output" }, ptr %rv
  ret { i32, %"std/os:Output" } %rr
}

define dso_local { i32, %"std/os:Output" } @std_2fos_2estd_2fos_3aProcess_2ewaitPolling(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca [1 x i32]
  %l3 = alloca [2 x %"<poll.h>:pollfd"]
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"<poll.h>:pollfd"
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i64
  %l13 = alloca %"<poll.h>:pollfd"
  %l15 = alloca %"<poll.h>:pollfd"
  %l19 = alloca i64
  %l22 = alloca i32
  %l28 = alloca i64
  %l33 = alloca i32
  %l36 = alloca ptr
  %l37 = alloca i32
  %l38 = alloca i32
  %l39 = alloca i32
  %l54 = alloca i32
  %l62 = alloca %"std/os:Output"
  %l65 = alloca %"std/os:Output"
  %l66 = alloca i32
  %l67 = alloca i32
  %l82 = alloca i32
  %l100 = alloca i32
  %l105 = alloca i1
  %l111 = alloca i32
  %l113 = alloca ptr
  %l114 = alloca i32
  %l115 = alloca i32
  %l116 = alloca i32
  %l131 = alloca i32
  %l135 = alloca %"std/os:Output"
  %l138 = alloca %"std/os:Output"
  %l139 = alloca i32
  %l141 = alloca i1
  %l145 = alloca i32
  %l146 = alloca i32
  %l161 = alloca i32
  %l166 = alloca i64
  %l171 = alloca i1
  %l181 = alloca ptr
  %l184 = alloca i64
  %l189 = alloca i32
  %l190 = alloca ptr
  %s22 = alloca %olang.scope
  %rv = alloca { i32, %"std/os:Output" }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [1 x i32] undef, i32 0, 0
  store [1 x i32] %t1, ptr %l2
  store %"<poll.h>:pollfd" zeroinitializer, ptr %l13
  %t3 = icmp sgt i64 2, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call %"<poll.h>:pollfd" @olang_2emir_2eHelperKind_2eZero_2e_3cpoll_2eh_3e_3apollfd()
  store %"<poll.h>:pollfd" %t5, ptr %l15
  br label %bb3
bb2:
  %t6 = load %"<poll.h>:pollfd", ptr %l13
  %t7 = insertvalue [2 x %"<poll.h>:pollfd"] undef, %"<poll.h>:pollfd" %t6, 0
  %t8 = load %"<poll.h>:pollfd", ptr %l13
  %t9 = insertvalue [2 x %"<poll.h>:pollfd"] %t7, %"<poll.h>:pollfd" %t8, 1
  store [2 x %"<poll.h>:pollfd"] %t9, ptr %l3
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"std/os:Process", ptr %t11, i32 0, i32 0
  %t14 = load i32, ptr %t13, !tbaa !23
  %t16 = call i64 (i64, ...) @syscall(i64 434, i32 %t14, i32 0)
  store i64 %t16, ptr %l19
  br label %bb4
bb3:
  %t17 = load %"<poll.h>:pollfd", ptr %l15
  store %"<poll.h>:pollfd" %t17, ptr %l13
  br label %bb2
bb4:
  %t18 = load i64, ptr %l19, !tbaa !24
  %t19 = trunc i64 %t18 to i32
  %t21 = getelementptr [2 x %"<poll.h>:pollfd"], ptr %l3, i64 0, i64 0
  %t22 = getelementptr %"<poll.h>:pollfd", ptr %t21, i32 0, i32 0
  store i32 %t19, ptr %t22, !tbaa !23
  %t23 = load i32, ptr @G_2e_3csys_2feventfd_2eh_3e_2eEFD__CLOEXEC, !tbaa !23
  %t25 = call i32 @eventfd(i32 0, i32 %t23)
  store i32 %t25, ptr %l22
  br label %bb5
bb5:
  %t26 = load i32, ptr %l22, !tbaa !23
  %t27 = getelementptr [2 x %"<poll.h>:pollfd"], ptr %l3, i64 0, i64 1
  %t28 = getelementptr %"<poll.h>:pollfd", ptr %t27, i32 0, i32 0
  store i32 %t26, ptr %t28, !tbaa !23
  %t29 = load i32, ptr @G_2e_3cpoll_2eh_3e_2ePOLLIN, !tbaa !23
  %t31 = trunc i32 %t29 to i16
  %t33 = getelementptr [2 x %"<poll.h>:pollfd"], ptr %l3, i64 0, i64 0
  %t34 = getelementptr %"<poll.h>:pollfd", ptr %t33, i32 0, i32 1
  store i16 %t31, ptr %t34, !tbaa !62
  %t35 = load i32, ptr @G_2e_3cpoll_2eh_3e_2ePOLLIN, !tbaa !23
  %t37 = trunc i32 %t35 to i16
  %t39 = getelementptr [2 x %"<poll.h>:pollfd"], ptr %l3, i64 0, i64 1
  %t40 = getelementptr %"<poll.h>:pollfd", ptr %t39, i32 0, i32 1
  store i16 %t37, ptr %t40, !tbaa !62
  %t41 = getelementptr [2 x %"<poll.h>:pollfd"], ptr %l3, i64 0, i64 1
  %t42 = getelementptr %"<poll.h>:pollfd", ptr %t41, i32 0, i32 0
  %t43 = load i32, ptr %t42, !tbaa !23
  %t45 = call i64 @std_2fcancel_2ePark(i32 %t43)
  store i64 %t45, ptr %l28
  br label %bb6
bb6:
  %t46 = load i64, ptr %l28, !tbaa !24
  store i64 %t46, ptr %l4, !tbaa !24
  store i64 50000, ptr %l9, !tbaa !24
  br label %bb7
bb7:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"std/os:Process", ptr %t47, i32 0, i32 0
  %t50 = load i32, ptr %t49, !tbaa !23
  %t52 = insertvalue { i64, ptr } undef, i64 1, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %l2, 1
  %t56 = extractvalue { i64, ptr } %t53, 1
  %t57 = extractvalue { i64, ptr } %t53, 0
  %t58 = call i32 @waitpid(i32 %t50, ptr %t56, i32 1)
  store i32 %t58, ptr %l33
  br label %bb8
bb8:
  %t59 = load i32, ptr %l33, !tbaa !23
  store i32 %t59, ptr %l10, !tbaa !23
  %t60 = load i32, ptr %l10, !tbaa !23
  %t62 = icmp slt i32 %t60, 0
  br i1 %t62, label %bb9, label %bb10
bb9:
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l36, !tbaa !29
  %t65 = call i32 @__olang_err()
  store i32 %t65, ptr %l37
  br label %bb11
bb10:
  br label %bb26
bb11:
  %t66 = load ptr, ptr %l36, !tbaa !29
  %t67 = load i32, ptr %l37, !tbaa !23
  %t68 = call i32 @std_2fos_2estd_2fos_3aProcess_2elost(ptr %v0, ptr %t66, i32 %t67)
  store i32 %t68, ptr %l38
  %t69 = icmp ne i32 %t68, 0
  br i1 %t69, label %bb13, label %ok.70, !prof !99
ok.70:
  br label %bb12
bb12:
  br label %bb25
bb13:
  %t71 = load i32, ptr %l38, !tbaa !23
  %t72 = lshr i32 %t71, 16
  %t73 = and i32 %t71, 65535
  %t74 = icmp eq i32 %t72, 1
  %t75 = select i1 %t74, i32 1, i32 0
  %t76 = icmp eq i32 %t71, 0
  %t77 = shl i32 %t75, 16
  %t78 = or i32 %t77, %t73
  %t79 = select i1 %t76, i32 0, i32 %t78
  store i32 %t79, ptr %l39, !tbaa !23
  %t80 = load i64, ptr %l4, !tbaa !24
  call void @std_2fcancel_2eDone(i64 %t80)
  br label %bb14
bb14:
  store ptr %l3, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  %t83 = load ptr, ptr %l5
  store i64 2, ptr %l7, !tbaa !24
  br label %bb15
bb15:
  %t86 = load i64, ptr %l6, !tbaa !24
  %t87 = load i64, ptr %l7, !tbaa !24
  %t90 = icmp slt i64 %t86, %t87
  %t92 = xor i1 %t90, true
  br i1 %t92, label %bb16, label %bb17
bb16:
  br label %bb24
bb17:
  br label %bb18
bb18:
  %t94 = load ptr, ptr %l5
  %t95 = load i64, ptr %l6, !tbaa !24
  %t98 = getelementptr [2 x %"<poll.h>:pollfd"], ptr %t94, i64 0, i64 %t95
  %t99 = load %"<poll.h>:pollfd", ptr %t98
  store %"<poll.h>:pollfd" %t99, ptr %l8
  %t101 = getelementptr %"<poll.h>:pollfd", ptr %l8, i32 0, i32 0
  %t102 = load i32, ptr %t101, !tbaa !23
  %t104 = icmp sge i32 %t102, 0
  br i1 %t104, label %bb19, label %bb20
bb19:
  %t106 = getelementptr %"<poll.h>:pollfd", ptr %l8, i32 0, i32 0
  %t107 = load i32, ptr %t106, !tbaa !23
  %t109 = call i32 @close(i32 %t107)
  store i32 %t109, ptr %l54
  br label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t110 = load i64, ptr %l6, !tbaa !24
  %t113 = add i64 %t110, 1
  store i64 %t113, ptr %l6, !tbaa !24
  br label %bb15
bb24:
  %t115 = load i32, ptr %l39, !tbaa !23
  %t116 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t115, 0
  store { i32, %"std/os:Output" } %t116, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t117 = load i32, ptr %l10, !tbaa !23
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"std/os:Process", ptr %t118, i32 0, i32 0
  %t121 = load i32, ptr %t120, !tbaa !23
  %t124 = icmp eq i32 %t117, %t121
  br i1 %t124, label %bb27, label %bb28
bb27:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr [1 x i32], ptr %l2, i64 0, i64 0
  %t128 = load i32, ptr %t127, !tbaa !33
  %t131 = call { i32, %"std/os:Output" } @std_2fos_2estd_2fos_3aProcess_2eended(ptr %v0, ptr %v2, ptr %t126, i32 %t128)
  %t132 = extractvalue { i32, %"std/os:Output" } %t131, 1
  %t133 = extractvalue { i32, %"std/os:Output" } %t131, 0
  store i32 %t133, ptr %l66
  %t134 = icmp ne i32 %t133, 0
  br i1 %t134, label %bb30, label %ok.135, !prof !99
ok.135:
  store %"std/os:Output" %t132, ptr %l65
  br label %bb29
bb28:
  br label %bb54
bb29:
  %t136 = load %"std/os:Output", ptr %l65
  store %"std/os:Output" %t136, ptr %l62
  br label %bb42
bb30:
  %t137 = load i32, ptr %l66, !tbaa !23
  %t138 = lshr i32 %t137, 16
  %t139 = and i32 %t137, 65535
  %t140 = icmp eq i32 %t138, 1
  %t141 = select i1 %t140, i32 1, i32 0
  %t142 = icmp eq i32 %t137, 0
  %t143 = shl i32 %t141, 16
  %t144 = or i32 %t143, %t139
  %t145 = select i1 %t142, i32 0, i32 %t144
  store i32 %t145, ptr %l67, !tbaa !23
  %t146 = load i64, ptr %l4, !tbaa !24
  call void @std_2fcancel_2eDone(i64 %t146)
  br label %bb31
bb31:
  store ptr %l3, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  %t149 = load ptr, ptr %l5
  store i64 2, ptr %l7, !tbaa !24
  br label %bb32
bb32:
  %t152 = load i64, ptr %l6, !tbaa !24
  %t153 = load i64, ptr %l7, !tbaa !24
  %t156 = icmp slt i64 %t152, %t153
  %t158 = xor i1 %t156, true
  br i1 %t158, label %bb33, label %bb34
bb33:
  br label %bb41
bb34:
  br label %bb35
bb35:
  %t160 = load ptr, ptr %l5
  %t161 = load i64, ptr %l6, !tbaa !24
  %t164 = getelementptr [2 x %"<poll.h>:pollfd"], ptr %t160, i64 0, i64 %t161
  %t165 = load %"<poll.h>:pollfd", ptr %t164
  store %"<poll.h>:pollfd" %t165, ptr %l8
  %t167 = getelementptr %"<poll.h>:pollfd", ptr %l8, i32 0, i32 0
  %t168 = load i32, ptr %t167, !tbaa !23
  %t170 = icmp sge i32 %t168, 0
  br i1 %t170, label %bb36, label %bb37
bb36:
  %t172 = getelementptr %"<poll.h>:pollfd", ptr %l8, i32 0, i32 0
  %t173 = load i32, ptr %t172, !tbaa !23
  %t175 = call i32 @close(i32 %t173)
  store i32 %t175, ptr %l82
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t176 = load i64, ptr %l6, !tbaa !24
  %t179 = add i64 %t176, 1
  store i64 %t179, ptr %l6, !tbaa !24
  br label %bb32
bb41:
  %t181 = load i32, ptr %l67, !tbaa !23
  %t182 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t181, 0
  store { i32, %"std/os:Output" } %t182, ptr %rv
  br label %ret
bb42:
  %t183 = load i64, ptr %l4, !tbaa !24
  call void @std_2fcancel_2eDone(i64 %t183)
  br label %bb43
bb43:
  store ptr %l3, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  %t186 = load ptr, ptr %l5
  store i64 2, ptr %l7, !tbaa !24
  br label %bb44
bb44:
  %t189 = load i64, ptr %l6, !tbaa !24
  %t190 = load i64, ptr %l7, !tbaa !24
  %t193 = icmp slt i64 %t189, %t190
  %t195 = xor i1 %t193, true
  br i1 %t195, label %bb45, label %bb46
bb45:
  br label %bb53
bb46:
  br label %bb47
bb47:
  %t197 = load ptr, ptr %l5
  %t198 = load i64, ptr %l6, !tbaa !24
  %t201 = getelementptr [2 x %"<poll.h>:pollfd"], ptr %t197, i64 0, i64 %t198
  %t202 = load %"<poll.h>:pollfd", ptr %t201
  store %"<poll.h>:pollfd" %t202, ptr %l8
  %t204 = getelementptr %"<poll.h>:pollfd", ptr %l8, i32 0, i32 0
  %t205 = load i32, ptr %t204, !tbaa !23
  %t207 = icmp sge i32 %t205, 0
  br i1 %t207, label %bb48, label %bb49
bb48:
  %t209 = getelementptr %"<poll.h>:pollfd", ptr %l8, i32 0, i32 0
  %t210 = load i32, ptr %t209, !tbaa !23
  %t212 = call i32 @close(i32 %t210)
  store i32 %t212, ptr %l100
  br label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb51
bb51:
  br label %bb52
bb52:
  %t213 = load i64, ptr %l6, !tbaa !24
  %t216 = add i64 %t213, 1
  store i64 %t216, ptr %l6, !tbaa !24
  br label %bb44
bb53:
  %t218 = load %"std/os:Output", ptr %l62
  %t219 = insertvalue { i32, %"std/os:Output" } zeroinitializer, %"std/os:Output" %t218, 1
  store { i32, %"std/os:Output" } %t219, ptr %rv
  br label %ret
bb54:
  %t220 = load ptr, ptr %l1, !tbaa !29
  %t222 = call i1 @std_2fcancel_2estd_2fcancel_3aToken_2eCancelled(ptr %v1, ptr %t220)
  store i1 %t222, ptr %l105
  br label %bb55
bb55:
  %t223 = load i1, ptr %l105, !tbaa !21
  br i1 %t223, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s22
  %t224 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fos_2estd_2fos_3aProcess_2eKill(ptr %v0, ptr %t224)
  br label %bb58
bb57:
  br label %bb98
bb58:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"std/os:Process", ptr %t226, i32 0, i32 0
  %t229 = load i32, ptr %t228, !tbaa !23
  %t231 = insertvalue { i64, ptr } undef, i64 1, 0
  %t232 = insertvalue { i64, ptr } %t231, ptr %l2, 1
  %t235 = extractvalue { i64, ptr } %t232, 1
  %t236 = extractvalue { i64, ptr } %t232, 0
  %t237 = call i32 @waitpid(i32 %t229, ptr %t235, i32 0)
  store i32 %t237, ptr %l111
  br label %bb59
bb59:
  %t238 = load i32, ptr %l111, !tbaa !23
  %t239 = icmp slt i32 %t238, 0
  br i1 %t239, label %bb60, label %bb61
bb60:
  %t241 = load ptr, ptr %l0, !tbaa !29
  store ptr %t241, ptr %l113, !tbaa !29
  %t242 = call i32 @__olang_err()
  store i32 %t242, ptr %l114
  br label %bb62
bb61:
  br label %bb77
bb62:
  %t243 = load ptr, ptr %l113, !tbaa !29
  %t244 = load i32, ptr %l114, !tbaa !23
  %t245 = call i32 @std_2fos_2estd_2fos_3aProcess_2elost(ptr %v0, ptr %t243, i32 %t244)
  store i32 %t245, ptr %l115
  %t246 = icmp ne i32 %t245, 0
  br i1 %t246, label %bb64, label %ok.247, !prof !99
ok.247:
  br label %bb63
bb63:
  br label %bb76
bb64:
  %t248 = load i32, ptr %l115, !tbaa !23
  %t249 = lshr i32 %t248, 16
  %t250 = and i32 %t248, 65535
  %t251 = icmp eq i32 %t249, 1
  %t252 = select i1 %t251, i32 1, i32 0
  %t253 = icmp eq i32 %t248, 0
  %t254 = shl i32 %t252, 16
  %t255 = or i32 %t254, %t250
  %t256 = select i1 %t253, i32 0, i32 %t255
  store i32 %t256, ptr %l116, !tbaa !23
  call void @__olang_scope_close(ptr %s22)
  %t257 = load i64, ptr %l4, !tbaa !24
  call void @std_2fcancel_2eDone(i64 %t257)
  br label %bb65
bb65:
  store ptr %l3, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  %t260 = load ptr, ptr %l5
  store i64 2, ptr %l7, !tbaa !24
  br label %bb66
bb66:
  %t263 = load i64, ptr %l6, !tbaa !24
  %t264 = load i64, ptr %l7, !tbaa !24
  %t267 = icmp slt i64 %t263, %t264
  %t269 = xor i1 %t267, true
  br i1 %t269, label %bb67, label %bb68
bb67:
  br label %bb75
bb68:
  br label %bb69
bb69:
  %t271 = load ptr, ptr %l5
  %t272 = load i64, ptr %l6, !tbaa !24
  %t275 = getelementptr [2 x %"<poll.h>:pollfd"], ptr %t271, i64 0, i64 %t272
  %t276 = load %"<poll.h>:pollfd", ptr %t275
  store %"<poll.h>:pollfd" %t276, ptr %l8
  %t278 = getelementptr %"<poll.h>:pollfd", ptr %l8, i32 0, i32 0
  %t279 = load i32, ptr %t278, !tbaa !23
  %t281 = icmp sge i32 %t279, 0
  br i1 %t281, label %bb70, label %bb71
bb70:
  %t283 = getelementptr %"<poll.h>:pollfd", ptr %l8, i32 0, i32 0
  %t284 = load i32, ptr %t283, !tbaa !23
  %t286 = call i32 @close(i32 %t284)
  store i32 %t286, ptr %l131
  br label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb73
bb73:
  br label %bb74
bb74:
  %t287 = load i64, ptr %l6, !tbaa !24
  %t290 = add i64 %t287, 1
  store i64 %t290, ptr %l6, !tbaa !24
  br label %bb66
bb75:
  %t292 = load i32, ptr %l116, !tbaa !23
  %t293 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t292, 0
  store { i32, %"std/os:Output" } %t293, ptr %rv
  br label %ret
bb76:
  br label %bb77
bb77:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = getelementptr [1 x i32], ptr %l2, i64 0, i64 0
  %t296 = load i32, ptr %t295, !tbaa !33
  %t299 = call { i32, %"std/os:Output" } @std_2fos_2estd_2fos_3aProcess_2eended(ptr %v0, ptr %s22, ptr %t294, i32 %t296)
  %t300 = extractvalue { i32, %"std/os:Output" } %t299, 1
  %t301 = extractvalue { i32, %"std/os:Output" } %t299, 0
  store i32 %t301, ptr %l139
  %t302 = icmp ne i32 %t301, 0
  br i1 %t302, label %bb79, label %ok.303, !prof !99
ok.303:
  store %"std/os:Output" %t300, ptr %l138
  br label %bb78
bb78:
  %t304 = load %"std/os:Output", ptr %l138
  store %"std/os:Output" %t304, ptr %l135
  br label %bb83
bb79:
  %t305 = load i32, ptr %l139, !tbaa !23
  %t306 = ashr i32 %t305, 16
  %t308 = icmp eq i32 %t306, 1
  store i1 %t308, ptr %l141, !tbaa !21
  %t309 = load i32, ptr %l139, !tbaa !23
  %t310 = ashr i32 %t309, 16
  %t312 = icmp eq i32 %t310, 1
  br i1 %t312, label %bb80, label %bb81
bb80:
  call void @__olang_errpay_pop()
  br label %bb81
bb81:
  br label %bb82
bb82:
  br label %bb83
bb83:
  %t314 = load ptr, ptr %l1, !tbaa !29
  %t316 = call i32 @std_2fcancel_2estd_2fcancel_3aToken_2eReason(ptr %v1, ptr %t314)
  store i32 %t316, ptr %l145
  %t317 = icmp ne i32 %t316, 0
  br i1 %t317, label %bb85, label %ok.318, !prof !99
ok.318:
  br label %bb84
bb84:
  br label %bb97
bb85:
  %t319 = load i32, ptr %l145, !tbaa !23
  %t320 = lshr i32 %t319, 16
  %t321 = and i32 %t319, 65535
  %t322 = icmp eq i32 %t320, 1
  %t323 = select i1 %t322, i32 2, i32 0
  %t324 = icmp eq i32 %t319, 0
  %t325 = shl i32 %t323, 16
  %t326 = or i32 %t325, %t321
  %t327 = select i1 %t324, i32 0, i32 %t326
  store i32 %t327, ptr %l146, !tbaa !23
  call void @__olang_scope_close(ptr %s22)
  %t328 = load i64, ptr %l4, !tbaa !24
  call void @std_2fcancel_2eDone(i64 %t328)
  br label %bb86
bb86:
  store ptr %l3, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  %t331 = load ptr, ptr %l5
  store i64 2, ptr %l7, !tbaa !24
  br label %bb87
bb87:
  %t334 = load i64, ptr %l6, !tbaa !24
  %t335 = load i64, ptr %l7, !tbaa !24
  %t338 = icmp slt i64 %t334, %t335
  %t340 = xor i1 %t338, true
  br i1 %t340, label %bb88, label %bb89
bb88:
  br label %bb96
bb89:
  br label %bb90
bb90:
  %t342 = load ptr, ptr %l5
  %t343 = load i64, ptr %l6, !tbaa !24
  %t346 = getelementptr [2 x %"<poll.h>:pollfd"], ptr %t342, i64 0, i64 %t343
  %t347 = load %"<poll.h>:pollfd", ptr %t346
  store %"<poll.h>:pollfd" %t347, ptr %l8
  %t349 = getelementptr %"<poll.h>:pollfd", ptr %l8, i32 0, i32 0
  %t350 = load i32, ptr %t349, !tbaa !23
  %t352 = icmp sge i32 %t350, 0
  br i1 %t352, label %bb91, label %bb92
bb91:
  %t354 = getelementptr %"<poll.h>:pollfd", ptr %l8, i32 0, i32 0
  %t355 = load i32, ptr %t354, !tbaa !23
  %t357 = call i32 @close(i32 %t355)
  store i32 %t357, ptr %l161
  br label %bb93
bb92:
  br label %bb94
bb93:
  br label %bb94
bb94:
  br label %bb95
bb95:
  %t358 = load i64, ptr %l6, !tbaa !24
  %t361 = add i64 %t358, 1
  store i64 %t361, ptr %l6, !tbaa !24
  br label %bb87
bb96:
  %t363 = load i32, ptr %l146, !tbaa !23
  %t364 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t363, 0
  store { i32, %"std/os:Output" } %t364, ptr %rv
  br label %ret
bb97:
  call void @__olang_scope_close(ptr %s22)
  br label %bb98
bb98:
  %t365 = load ptr, ptr %l1, !tbaa !29
  %t367 = call i64 @std_2fcancel_2estd_2fcancel_3aToken_2eLeftNs(ptr %v1, ptr %t365)
  store i64 %t367, ptr %l166
  br label %bb99
bb99:
  %t368 = load i64, ptr %l166, !tbaa !24
  store i64 %t368, ptr %l11, !tbaa !24
  %t369 = getelementptr [2 x %"<poll.h>:pollfd"], ptr %l3, i64 0, i64 0
  %t370 = getelementptr %"<poll.h>:pollfd", ptr %t369, i32 0, i32 0
  %t371 = load i32, ptr %t370, !tbaa !23
  %t373 = icmp slt i32 %t371, 0
  br i1 %t373, label %bb100, label %bb101
bb100:
  %t375 = load i64, ptr %l11, !tbaa !24
  %t377 = icmp slt i64 %t375, 0
  br i1 %t377, label %bb102, label %bb103
bb101:
  br label %bb111
bb102:
  store i1 true, ptr %l171, !tbaa !21
  br label %bb104
bb103:
  %t379 = load i64, ptr %l11, !tbaa !24
  %t380 = load i64, ptr %l9, !tbaa !24
  %t383 = icmp sgt i64 %t379, %t380
  store i1 %t383, ptr %l171, !tbaa !21
  br label %bb104
bb104:
  %t385 = load i1, ptr %l171, !tbaa !21
  br i1 %t385, label %bb105, label %bb106
bb105:
  %t386 = load i64, ptr %l9, !tbaa !24
  store i64 %t386, ptr %l11, !tbaa !24
  br label %bb107
bb106:
  br label %bb107
bb107:
  %t388 = load i64, ptr %l9, !tbaa !24
  %t390 = icmp slt i64 %t388, 10000000
  br i1 %t390, label %bb108, label %bb109
bb108:
  %t392 = load i64, ptr %l9, !tbaa !24
  %t395 = mul i64 %t392, 2
  store i64 %t395, ptr %l9, !tbaa !24
  br label %bb110
bb109:
  br label %bb110
bb110:
  br label %bb111
bb111:
  store ptr %l3, ptr %l181
  %t397 = load i64, ptr %l11, !tbaa !24
  %t399 = icmp slt i64 %t397, 0
  br i1 %t399, label %bb112, label %bb113
bb112:
  store i64 -1, ptr %l184, !tbaa !24
  br label %bb114
bb113:
  %t401 = load i64, ptr %l11, !tbaa !24
  %t403 = add i64 %t401, 999999
  %t405 = sdiv i64 %t403, 1000000
  store i64 %t405, ptr %l184, !tbaa !24
  br label %bb114
bb114:
  %t407 = load i64, ptr %l184, !tbaa !24
  %t408 = trunc i64 %t407 to i32
  %t409 = load ptr, ptr %l181
  %t411 = call i32 @poll(ptr %t409, i64 2, i32 %t408)
  store i32 %t411, ptr %l189
  br label %bb115
bb115:
  %t412 = load ptr, ptr %l0, !tbaa !29
  store ptr %t412, ptr %l190, !tbaa !29
  %t413 = load ptr, ptr %l190, !tbaa !29
  %t414 = getelementptr %"std/os:Process", ptr %t413, i32 0, i32 5
  %t415 = load i64, ptr %t414, !tbaa !24
  %t418 = add i64 %t415, 1
  %t420 = load ptr, ptr %l190, !tbaa !29
  %t421 = getelementptr %"std/os:Process", ptr %t420, i32 0, i32 5
  store i64 %t418, ptr %t421, !tbaa !24
  br label %bb116
bb116:
  br label %bb7
ret:
  %rr = load { i32, %"std/os:Output" }, ptr %rv
  ret { i32, %"std/os:Output" } %rr
}

define dso_local { i64, ptr } @std_2fos_2etempDir(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp sgt i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 1
  %t10 = extractvalue { i64, ptr } %t7, 0
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t9, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t13, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t15 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d54, i32 0, i32 1) })
  %t16 = extractvalue { i32, { i64, ptr } } %t15, 1
  %t17 = extractvalue { i32, { i64, ptr } } %t15, 0
  store i32 %t17, ptr %l9
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb5, label %ok.19, !prof !99
ok.19:
  store { i64, ptr } %t16, ptr %l8
  br label %bb4
bb4:
  %t20 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t20, ptr %l7, !tbaa !27
  br label %bb9
bb5:
  %t21 = load i32, ptr %l9, !tbaa !23
  %t22 = ashr i32 %t21, 16
  %t24 = icmp eq i32 %t22, 1
  br i1 %t24, label %bb6, label %bb7
bb6:
  call void @__olang_errpay_pop()
  br label %bb7
bb7:
  br label %bb8
bb8:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d55, i32 0, i32 1) }, ptr %l7, !tbaa !27
  br label %bb9
bb9:
  %t26 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t26, ptr %l1, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t31 = icmp sgt i64 %t29, 0
  br i1 %t31, label %bb10, label %bb11
bb10:
  %t33 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 1
  %t36 = extractvalue { i64, ptr } %t33, 0
  %t37 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t36)
  call void @olang_textcopy(ptr %t37, ptr %t35, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t39, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d56, i32 0, i32 1) }, ptr %l17, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t41, ptr %l18, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  store i64 %t43, ptr %l19, !tbaa !24
  %t44 = load i64, ptr %l19, !tbaa !24
  %t45 = mul i64 %t44, 1
  %t46 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t45)
  %t47 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  store { i64, ptr } %t48, ptr %l20, !tbaa !27
  %t49 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = load i64, ptr %l19, !tbaa !24
  %t54 = mul i64 %t53, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t50, ptr %t52, i64 %t54, i1 false)
  %t55 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t55, ptr %l18, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t56 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t56, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @std_2fos_2ewinCommandLine(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i8
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca %"std/prelude/text:StringBuilder"
  %l34 = alloca { i64, ptr }
  %l43 = alloca i1
  %l46 = alloca { i64, ptr }
  %l47 = alloca i1
  %l49 = alloca i1
  %l52 = alloca { i64, ptr }
  %l53 = alloca i1
  %l55 = alloca i1
  %l58 = alloca { i64, ptr }
  %l59 = alloca i1
  %l71 = alloca { i64, ptr }
  %l81 = alloca i64
  %l90 = alloca i64
  %l93 = alloca i64
  %l125 = alloca i64
  %l128 = alloca i64
  %l156 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l25
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l25
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb68
bb4:
  br label %bb5
bb5:
  %t17 = load i64, ptr %l3, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t19, ptr %l34, !tbaa !27
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %t23, i64 %t20
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !37
  store { i64, ptr } %t25, ptr %l6, !tbaa !27
  %t29 = icmp sgt i64 %t17, 0
  br i1 %t29, label %bb6, label %bb7
bb6:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 32)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t32 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t36 = icmp sgt i64 %t34, 0
  br i1 %t36, label %bb10, label %bb11
bb10:
  %t38 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d57, i32 0, i32 1) }, ptr %l46, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t42 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s2, { i64, ptr } %t38, { i64, ptr } %t41)
  store i1 %t42, ptr %l47
  br label %bb12
bb11:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb13
bb12:
  %t43 = load i1, ptr %l47, !tbaa !21
  %t44 = xor i1 %t43, true
  store i1 %t44, ptr %l43, !tbaa !21
  br label %bb13
bb13:
  %t46 = load i1, ptr %l43, !tbaa !21
  br i1 %t46, label %bb14, label %bb15
bb14:
  %t47 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, ptr %l52, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t51 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s2, { i64, ptr } %t47, { i64, ptr } %t50)
  store i1 %t51, ptr %l53
  br label %bb16
bb15:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb17
bb16:
  %t52 = load i1, ptr %l53, !tbaa !21
  %t53 = xor i1 %t52, true
  store i1 %t53, ptr %l49, !tbaa !21
  br label %bb17
bb17:
  %t55 = load i1, ptr %l49, !tbaa !21
  br i1 %t55, label %bb18, label %bb19
bb18:
  %t56 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, ptr %l58, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t60 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s2, { i64, ptr } %t56, { i64, ptr } %t59)
  store i1 %t60, ptr %l59
  br label %bb20
bb19:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb21
bb20:
  %t61 = load i1, ptr %l59, !tbaa !21
  %t62 = xor i1 %t61, true
  store i1 %t62, ptr %l55, !tbaa !21
  br label %bb21
bb21:
  %t64 = load i1, ptr %l55, !tbaa !21
  br i1 %t64, label %bb22, label %bb23
bb22:
  %t65 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %l1, { i64, ptr } %t65)
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_scope_close(ptr %s2)
  br label %bb67
bb25:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 34)
  br label %bb26
bb26:
  store i64 0, ptr %l7, !tbaa !24
  %t69 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t69, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t71 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t71, 0
  store i64 %t73, ptr %l10, !tbaa !24
  br label %bb27
bb27:
  %t75 = load i64, ptr %l9, !tbaa !24
  %t76 = load i64, ptr %l10, !tbaa !24
  %t79 = icmp slt i64 %t75, %t76
  %t81 = xor i1 %t79, true
  br i1 %t81, label %bb28, label %bb29
bb28:
  br label %bb52
bb29:
  br label %bb30
bb30:
  %t83 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t83, ptr %l71, !tbaa !27
  %t84 = load i64, ptr %l9, !tbaa !24
  %t86 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr i8, ptr %t87, i64 %t84
  %t89 = load i8, ptr %t88, !tbaa !32
  store i8 %t89, ptr %l11, !tbaa !22
  %t91 = load i8, ptr %l11, !tbaa !22
  %t93 = icmp eq i8 %t91, 92
  br i1 %t93, label %bb31, label %bb32
bb31:
  %t95 = load i64, ptr %l7, !tbaa !24
  %t98 = add i64 %t95, 1
  store i64 %t98, ptr %l7, !tbaa !24
  br label %bb51
bb32:
  br label %bb33
bb33:
  %t100 = load i8, ptr %l11, !tbaa !22
  %t102 = icmp eq i8 %t100, 34
  br i1 %t102, label %bb34, label %bb35
bb34:
  %t104 = load i64, ptr %l7, !tbaa !24
  %t106 = mul i64 %t104, 2
  %t108 = add i64 %t106, 1
  store i64 %t108, ptr %l81, !tbaa !24
  br label %bb36
bb35:
  %t110 = load i64, ptr %l7, !tbaa !24
  store i64 %t110, ptr %l81, !tbaa !24
  br label %bb36
bb36:
  %t112 = load i64, ptr %l81, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  store i64 %t112, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t115 = load i64, ptr %l14, !tbaa !24
  %t116 = load i64, ptr %l13, !tbaa !24
  %t119 = icmp sgt i64 %t115, %t116
  br i1 %t119, label %bb37, label %bb38
bb37:
  %t121 = load i64, ptr %l15, !tbaa !24
  %t123 = icmp sgt i64 %t121, 0
  br i1 %t123, label %bb39, label %bb40
bb38:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb42
bb39:
  %t125 = load i64, ptr %l14, !tbaa !24
  %t126 = load i64, ptr %l13, !tbaa !24
  %t129 = sub i64 %t125, %t126
  %t130 = load i64, ptr %l15, !tbaa !24
  %t133 = add i64 %t129, %t130
  %t135 = sub i64 %t133, 1
  %t136 = load i64, ptr %l15, !tbaa !24
  %t139 = sdiv i64 %t135, %t136
  store i64 %t139, ptr %l93, !tbaa !24
  br label %bb41
bb40:
  store i64 0, ptr %l93, !tbaa !24
  br label %bb41
bb41:
  %t141 = load i64, ptr %l93, !tbaa !24
  store i64 %t141, ptr %l90, !tbaa !24
  br label %bb42
bb42:
  %t142 = load i64, ptr %l90, !tbaa !24
  store i64 %t142, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb43
bb43:
  %t143 = load i64, ptr %l17, !tbaa !24
  %t144 = load i64, ptr %l16, !tbaa !24
  %t147 = icmp slt i64 %t143, %t144
  %t149 = xor i1 %t147, true
  br i1 %t149, label %bb44, label %bb45
bb44:
  br label %bb49
bb45:
  br label %bb46
bb46:
  %t151 = load i64, ptr %l13, !tbaa !24
  %t152 = load i64, ptr %l17, !tbaa !24
  %t153 = load i64, ptr %l15, !tbaa !24
  %t156 = mul i64 %t152, %t153
  %t159 = add i64 %t151, %t156
  store i64 %t159, ptr %l18, !tbaa !24
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 92)
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t162 = load i64, ptr %l17, !tbaa !24
  %t165 = add i64 %t162, 1
  store i64 %t165, ptr %l17, !tbaa !24
  br label %bb43
bb49:
  %t167 = load i8, ptr %l11, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 %t167)
  br label %bb50
bb50:
  store i64 0, ptr %l7, !tbaa !24
  br label %bb51
bb51:
  %t170 = load i64, ptr %l9, !tbaa !24
  %t173 = add i64 %t170, 1
  store i64 %t173, ptr %l9, !tbaa !24
  br label %bb27
bb52:
  store i64 0, ptr %l19, !tbaa !24
  %t175 = load i64, ptr %l7, !tbaa !24
  %t177 = mul i64 %t175, 2
  store i64 %t177, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t179 = load i64, ptr %l20, !tbaa !24
  %t180 = load i64, ptr %l19, !tbaa !24
  %t183 = icmp sgt i64 %t179, %t180
  br i1 %t183, label %bb53, label %bb54
bb53:
  %t185 = load i64, ptr %l21, !tbaa !24
  %t187 = icmp sgt i64 %t185, 0
  br i1 %t187, label %bb55, label %bb56
bb54:
  store i64 0, ptr %l125, !tbaa !24
  br label %bb58
bb55:
  %t189 = load i64, ptr %l20, !tbaa !24
  %t190 = load i64, ptr %l19, !tbaa !24
  %t193 = sub i64 %t189, %t190
  %t194 = load i64, ptr %l21, !tbaa !24
  %t197 = add i64 %t193, %t194
  %t199 = sub i64 %t197, 1
  %t200 = load i64, ptr %l21, !tbaa !24
  %t203 = sdiv i64 %t199, %t200
  store i64 %t203, ptr %l128, !tbaa !24
  br label %bb57
bb56:
  store i64 0, ptr %l128, !tbaa !24
  br label %bb57
bb57:
  %t205 = load i64, ptr %l128, !tbaa !24
  store i64 %t205, ptr %l125, !tbaa !24
  br label %bb58
bb58:
  %t206 = load i64, ptr %l125, !tbaa !24
  store i64 %t206, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb59
bb59:
  %t207 = load i64, ptr %l23, !tbaa !24
  %t208 = load i64, ptr %l22, !tbaa !24
  %t211 = icmp slt i64 %t207, %t208
  %t213 = xor i1 %t211, true
  br i1 %t213, label %bb60, label %bb61
bb60:
  br label %bb65
bb61:
  br label %bb62
bb62:
  %t215 = load i64, ptr %l19, !tbaa !24
  %t216 = load i64, ptr %l23, !tbaa !24
  %t217 = load i64, ptr %l21, !tbaa !24
  %t220 = mul i64 %t216, %t217
  %t223 = add i64 %t215, %t220
  store i64 %t223, ptr %l24, !tbaa !24
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 92)
  br label %bb63
bb63:
  br label %bb64
bb64:
  %t226 = load i64, ptr %l23, !tbaa !24
  %t229 = add i64 %t226, 1
  store i64 %t229, ptr %l23, !tbaa !24
  br label %bb59
bb65:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 34)
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s2)
  br label %bb67
bb67:
  %t232 = load i64, ptr %l3, !tbaa !24
  %t235 = add i64 %t232, 1
  store i64 %t235, ptr %l3, !tbaa !24
  br label %bb2
bb68:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 0)
  br label %bb69
bb69:
  %t239 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t239, ptr %l156
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s0)
  %t240 = load { i64, ptr }, ptr %l156, !tbaa !27
  store { i64, ptr } %t240, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/os:Process" @std_2fos_3aProcess_2ector(ptr %v0, i32 %a0, i32 %a1, i32 %a2, i1 %a3) #0 {
entry:
  %rv = alloca %"std/os:Process"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"std/os:Process" undef, i32 %a0, 0
  %t12 = insertvalue %"std/os:Process" %t10, i32 %a1, 1
  %t14 = insertvalue %"std/os:Process" %t12, i32 %a2, 2
  %t16 = insertvalue %"std/os:Process" %t14, i1 %a3, 3
  %t18 = insertvalue %"std/os:Process" %t16, i1 false, 4
  %t20 = insertvalue %"std/os:Process" %t18, i64 0, 5
  store %"std/os:Process" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/os:Process", ptr %rv
  ret %"std/os:Process" %rr
}

declare i64 @__olang_arg_count()
declare void @__olang_check_failed(ptr) cold noreturn
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@.d0 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@__olang_empty_array = external constant [16 x i64]
declare i64 @__olang_arg(i64, ptr, i64)
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d1 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal i64 @olang_lambda_2(ptr %env, ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l9 = alloca i64
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  %cp0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load { i64, ptr }, ptr %cp0, !tbaa !28
  %vq0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  %t10 = extractvalue { i64, ptr } %cv0, 1
  %t11 = extractvalue { i64, ptr } %cv0, 0
  %t13 = extractvalue { i64, ptr } %t4, 1
  %t14 = extractvalue { i64, ptr } %t4, 0
  %t16 = call i64 @__olang_env(ptr %t10, ptr %t13, i64 %t8)
  store i64 %t16, ptr %l9
  br label %bb1
bb1:
  %t17 = load i64, ptr %l9, !tbaa !24
  store i64 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

@.d3 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @__olang_errpay_pop()
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @__olang_errpay_push() cold
define linkonce_odr { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fos_3aError_24payload(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %rv = alloca { i64, [2 x i64] }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, [2 x i64] }, ptr %a0
  store { i64, [2 x i64] } %t2, ptr %l1
  %t3 = load i64, ptr %l1, !range !{i64 0, i64 7}
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 ]
bb1:
  %t5 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t5, ptr %rv
  br label %ret
bb2:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, ptr } }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l5, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = mul i64 %t20, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %t19, i64 %t21, i1 false)
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t24 = getelementptr { { i64, ptr } }, ptr %t23, i32 0, i32 0
  store { i64, ptr } %t22, ptr %t24
  br label %bb1
bb3:
  %t25 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t26 = getelementptr { { i64, ptr } }, ptr %t25, i32 0, i32 0
  %t27 = load { i64, ptr }, ptr %t26
  store { i64, ptr } %t27, ptr %l6, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l7, !tbaa !24
  %t30 = load i64, ptr %l7, !tbaa !24
  %t31 = mul i64 %t30, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t31)
  %t33 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l8, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = load i64, ptr %l7, !tbaa !24
  %t40 = mul i64 %t39, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t36, ptr %t38, i64 %t40, i1 false)
  %t41 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t42 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t43 = getelementptr { { i64, ptr } }, ptr %t42, i32 0, i32 0
  store { i64, ptr } %t41, ptr %t43
  br label %bb1
bb4:
  %t44 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t45 = getelementptr { { i64, ptr } }, ptr %t44, i32 0, i32 0
  %t46 = load { i64, ptr }, ptr %t45
  store { i64, ptr } %t46, ptr %l9, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t47, 0
  store i64 %t48, ptr %l10, !tbaa !24
  %t49 = load i64, ptr %l10, !tbaa !24
  %t50 = mul i64 %t49, 1
  %t51 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t50)
  %t52 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t51, 1
  store { i64, ptr } %t53, ptr %l11, !tbaa !27
  %t54 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = load i64, ptr %l10, !tbaa !24
  %t59 = mul i64 %t58, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t55, ptr %t57, i64 %t59, i1 false)
  %t60 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t61 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t62 = getelementptr { { i64, ptr } }, ptr %t61, i32 0, i32 0
  store { i64, ptr } %t60, ptr %t62
  br label %bb1
bb5:
  %t63 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t64 = getelementptr { { i64, ptr } }, ptr %t63, i32 0, i32 0
  %t65 = load { i64, ptr }, ptr %t64
  store { i64, ptr } %t65, ptr %l12, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  store i64 %t67, ptr %l13, !tbaa !24
  %t68 = load i64, ptr %l13, !tbaa !24
  %t69 = mul i64 %t68, 1
  %t70 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t69)
  %t71 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  store { i64, ptr } %t72, ptr %l14, !tbaa !27
  %t73 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l13, !tbaa !24
  %t78 = mul i64 %t77, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t74, ptr %t76, i64 %t78, i1 false)
  %t79 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t80 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t81 = getelementptr { { i64, ptr } }, ptr %t80, i32 0, i32 0
  store { i64, ptr } %t79, ptr %t81
  br label %bb1
bb6:
  %t82 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t83 = getelementptr { { i64, ptr } }, ptr %t82, i32 0, i32 0
  %t84 = load { i64, ptr }, ptr %t83
  store { i64, ptr } %t84, ptr %l15, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 0
  store i64 %t86, ptr %l16, !tbaa !24
  %t87 = load i64, ptr %l16, !tbaa !24
  %t88 = mul i64 %t87, 1
  %t89 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t88)
  %t90 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  store { i64, ptr } %t91, ptr %l17, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = load i64, ptr %l16, !tbaa !24
  %t97 = mul i64 %t96, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t93, ptr %t95, i64 %t97, i1 false)
  %t98 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t99 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t100 = getelementptr { { i64, ptr } }, ptr %t99, i32 0, i32 0
  store { i64, ptr } %t98, ptr %t100
  br label %bb1
bb7:
  %t101 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t102 = getelementptr { { i64, ptr } }, ptr %t101, i32 0, i32 0
  %t103 = load { i64, ptr }, ptr %t102
  store { i64, ptr } %t103, ptr %l18, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 0
  store i64 %t105, ptr %l19, !tbaa !24
  %t106 = load i64, ptr %l19, !tbaa !24
  %t107 = mul i64 %t106, 1
  %t108 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t107)
  %t109 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  store { i64, ptr } %t110, ptr %l20, !tbaa !27
  %t111 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = load i64, ptr %l19, !tbaa !24
  %t116 = mul i64 %t115, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t112, ptr %t114, i64 %t116, i1 false)
  %t117 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t118 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t119 = getelementptr { { i64, ptr } }, ptr %t118, i32 0, i32 0
  store { i64, ptr } %t117, ptr %t119
  br label %bb1
bb8:
  %t120 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t121 = getelementptr { { i64, ptr } }, ptr %t120, i32 0, i32 0
  %t122 = load { i64, ptr }, ptr %t121
  store { i64, ptr } %t122, ptr %l21, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  store i64 %t124, ptr %l22, !tbaa !24
  %t125 = load i64, ptr %l22, !tbaa !24
  %t126 = mul i64 %t125, 1
  %t127 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t126)
  %t128 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  store { i64, ptr } %t129, ptr %l23, !tbaa !27
  %t130 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = load i64, ptr %l22, !tbaa !24
  %t135 = mul i64 %t134, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t131, ptr %t133, i64 %t135, i1 false)
  %t136 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t137 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t138 = getelementptr { { i64, ptr } }, ptr %t137, i32 0, i32 0
  store { i64, ptr } %t136, ptr %t138
  br label %bb1
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

declare void @__olang_errpay_set(ptr) cold
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
declare i32 @__olang_exec(ptr, ptr, i64)
declare i32 @__olang_err()
@.d5 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"linux" }>, align 8
@.d6 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"windows" }>, align 8
@.d7 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
declare i32 @open(ptr, i32, ...)
@.d8 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
@.d9 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"linux" }>, align 8
@.d10 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"windows" }>, align 8
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
declare i32 @creat(ptr, i32)
@.d12 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
@.d13 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d16 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d17 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d18 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"XXXXXX\00" }>, align 8
declare i32 @__olang_mkdtemp(ptr)
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_202_3e_2e_2d1 = weak hidden constant i1 false
@.d19 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"run " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d20 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"echo" }>, align 8
@.d21 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d22 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d23 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"os.Error.NotFound" }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
declare ptr @__olang_errpay_top_get()
@.d24 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
declare i64 @__olang_rd_quote(ptr, i64, ptr, i64, i8)
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare void @__olang_sb_add(ptr, i64)
@.d25 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
declare void @__olang_sb_done(ptr)
declare void @__olang_bang_failed_text(ptr, { i64, ptr }, i1) cold noreturn
@.d26 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Exists" }>, align 8
@.d27 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Denied" }>, align 8
@.d28 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.NotDir" }>, align 8
@.d29 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"os.Error.IsDir" }>, align 8
@.d30 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"os.Error.NotEmpty" }>, align 8
@.d31 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Failed" }>, align 8
declare void @__olang_bang_failed_plain(ptr) cold noreturn
@.d32 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare i32 @close(i32)
declare i64 @lseek(i32, i64, i32)
@.d33 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d34 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
@.d35 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d36 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"'\5C''" }>, align 8
@.d37 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d38 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
define internal i64 @olang_lambda_39(ptr %env, ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l9 = alloca i64
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  %cp0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load { i64, ptr }, ptr %cp0, !tbaa !28
  %vq0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  %t10 = extractvalue { i64, ptr } %cv0, 1
  %t11 = extractvalue { i64, ptr } %cv0, 0
  %t13 = extractvalue { i64, ptr } %t4, 1
  %t14 = extractvalue { i64, ptr } %t4, 0
  %t16 = call i64 @__olang_dir(ptr %t10, ptr %t13, i64 %t8)
  store i64 %t16, ptr %l9
  br label %bb1
bb1:
  %t17 = load i64, ptr %l9, !tbaa !24
  store i64 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

@.d40 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
define internal i1 @olang_lambda_41(ptr %env, ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l4 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i32 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eCompare(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4, !tbaa !23
  %t7 = icmp slt i32 %t6, 0
  store i1 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr void @olang_2emir_2eHelperKind_2eDrop_2estd_2fos_3aFile(ptr %v0, ptr %a0) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @std_2fos_3aFile_2edtor(ptr %v0, ptr %a0)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

@olang_2esole_2estd__2fos__2eReadFile_2elocal_2e8 = weak hidden constant i1 false
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle_in(ptr, ptr)
declare void @__olang_region_release(ptr) noinline
@.d42 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
declare i64 @readlink(ptr, ptr, i64)
@.d43 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d44 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".." }>, align 8
@.d45 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d46 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d47 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d48 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d49 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
@.d50 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
declare i32 @__olang_spawn(ptr, i64, i32, i32, i32, ptr)
@.d51 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d52 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d53 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2estd_2fos_3aOutput_2e1 = weak hidden constant i1 false
@olang_2esole_2estd_2fos_3aOutput_2e2 = weak hidden constant i1 false
declare i32 @nanosleep(ptr, ptr)
define linkonce_odr %"<poll.h>:pollfd" @olang_2emir_2eHelperKind_2eZero_2e_3cpoll_2eh_3e_3apollfd() #0 {
entry:
  %l0 = alloca %"<poll.h>:pollfd"
  %rv = alloca %"<poll.h>:pollfd"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"<poll.h>:pollfd" @_3cpoll_2eh_3e_3apollfd_2ector(ptr %t1)
  store %"<poll.h>:pollfd" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"<poll.h>:pollfd", ptr %l0
  store %"<poll.h>:pollfd" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"<poll.h>:pollfd", ptr %rv
  ret %"<poll.h>:pollfd" %rr
}

declare i64 @syscall(i64, ...)
declare i32 @eventfd(i32, i32)
declare i32 @waitpid(i32, ptr, i32)
declare i32 @poll(ptr, i64, i32)
@.d54 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"TMPDIR" }>, align 8
@.d55 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d56 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"/tmp" }>, align 8
@.d57 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d58 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\09" }>, align 8
@.d59 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\22" }>, align 8
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
declare i64 @__olang_env(ptr, ptr, i64)
declare ptr @__olang_sb_grow(ptr, i64) noinline
declare i64 @__olang_dir(ptr, ptr, i64)
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
@olang_loc_2e089b9dcc6d7cfd_6f26744b60ea9b91 = external constant [0 x i8]
@olang_loc_722c60a9fee6cfd0_5c8c3a8aa9ab1a84 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %a0, i8 %a1)
@olang_loc_c6732c6b36ef1233_192580cd7896553f = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2echeck(ptr %v0, i64 %a0, { i64, ptr } %a1)
declare %"std/os:File" @std_2fos_3aFile_2ector(ptr %v0, i32 %a0)
declare i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %a0)
@olang_loc_1b39f3aec8a2d100_9d79a3da2d056474 = external constant [0 x i8]
declare i32 @std_2fos_2emkdir(ptr %v0, { i64, ptr } %a0)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_93142f54c4ba4464_592b0bc010c9eac8 = external constant [0 x i8]
declare { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
@olang_loc_f119a7c9f27c98b4_8ee77fd34027ef68 = external constant [0 x i8]
@olang_loc_1a596f16b0c0d4cc_1848fbd7ff01a1d8 = external constant [0 x i8]
declare { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %v0, { i64, ptr } %a0)
@olang_loc_ae615ff442418127_414de4f669869a8b = external constant [0 x i8]
declare i32 @std_2fio_2eWrite(ptr %v0, i32 %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2ememfd()
@olang_loc_3ae06a7cd351f714_4bcb8792cbdf34a0 = external constant [0 x i8]
@olang_loc_63ca89910fe1f481_50e57e01f8d90efd = external constant [0 x i8]
@olang_loc_879ad2febb339b7d_10a4c06fe5c76379 = external constant [0 x i8]
@olang_loc_2b89142fbf8fc460_df42bdef933d62c4 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eSort_3cstd_2fprelu_H425a408f665c1f34766f6a10dd38435a(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
declare { i32, %"std/os:File" } @std_2fos_2eFile_2eOpen(ptr %v0, { i64, ptr } %a0)
declare i64 @std_2fos_2eseek(i32 %a0, i32 %a1)
@olang_loc_587e358192386240_8b720e6e0da4b04 = external constant [0 x i8]
@olang_loc_cd46a02c4675cb4d_fa072eb3f90c0109 = external constant [0 x i8]
declare i64 @std_2fos_2erawRead(ptr %v0, i32 %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %a0, i64 %a1)
@olang_loc_177c37a6b0701e6e_ab9bf986b91be9f2 = external constant [0 x i8]
@olang_loc_870dc790e95aa6eb_a67bfaf9489a2847 = external constant [0 x i8]
@olang_loc_8e0d503f3b50c80c_2eb254ad451fbc78 = external constant [0 x i8]
@olang_loc_3bbcea0c000efd36_21b55d08ecf81e22 = external constant [0 x i8]
@olang_loc_ff17d2e56a811dcb_410ea2db80d8aad7 = external constant [0 x i8]
@olang_loc_d7f228265709f418_7e9f802c53b666ac = external constant [0 x i8]
@olang_loc_9d6ebd177b1045e9_d85719897e835afd = external constant [0 x i8]
@olang_loc_7455114053b9a685_f9a96b9bd4adb589 = external constant [0 x i8]
@olang_loc_d680568c47c09218_ee59193b16d39a3c = external constant [0 x i8]
@olang_loc_a97aa98585cf6243_3a57acf5b7e1165f = external constant [0 x i8]
@olang_loc_6e884a0c8190443b_54808bbd727a9dff = external constant [0 x i8]
@olang_loc_63206310f1419a1b_2cb9bc5fa11cb777 = external constant [0 x i8]
@olang_loc_57657329f9419e06_2a1a8642ca70aa5a = external constant [0 x i8]
@olang_loc_118c1c5257346374_e7678ca1d651d180 = external constant [0 x i8]
declare i32 @std_2fos_2eremove(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fos_2ewaitFor(ptr %v0, i32 %a0, { i64, ptr } %a1, i1 %a2)
declare i32 @std_2fos_2estd_2fos_3aProcess_2elost(ptr %v0, ptr %a0, i32 %a1)
declare %"std/os:Output" @std_2fos_3aOutput_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i1 @std_2fcancel_2estd_2fcancel_3aToken_2eCancelled(ptr %v0, ptr %a0)
declare void @std_2fos_2estd_2fos_3aProcess_2eKill(ptr %v0, ptr %a0)
declare i32 @std_2fcancel_2estd_2fcancel_3aToken_2eReason(ptr %v0, ptr %a0)
declare i64 @std_2fcancel_2estd_2fcancel_3aToken_2eLeftNs(ptr %v0, ptr %a0)
declare %"<fcntl.h>:timespec" @_3cfcntl_2eh_3e_3atimespec_2ector(ptr %v0)
@G_2e_3csys_2feventfd_2eh_3e_2eEFD__CLOEXEC = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\08\00" }>, align 8
@G_2e_3cpoll_2eh_3e_2ePOLLIN = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare i64 @std_2fcancel_2ePark(i32 %a0)
declare void @std_2fcancel_2eDone(i64 %a0)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i32 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eCompare(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fos_3aFile_2edtor(ptr %v0, ptr %a0)
declare %"<poll.h>:pollfd" @_3cpoll_2eh_3e_3apollfd_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
