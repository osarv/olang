; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
define dso_local { i64, ptr } @compiler_2fruntime_2eBionic(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %l4, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l5, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t6 = call { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %a0, { i64, ptr } %t4, { i64, ptr } %t5)
  store { i64, ptr } %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t7, ptr %l1, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %l9, !tbaa !27
  store { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr %l10, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t13 = call { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t9, { i64, ptr } %t11, { i64, ptr } %t12)
  store { i64, ptr } %t13, ptr %l11
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  store { i64, ptr } %t14, ptr %l1, !tbaa !27
  %t17 = load i1, ptr @olang_2esole_2ecompiler__2fruntime__2eBionic_2elocal_2e1
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load { i64, ptr }, ptr %l13
  %t20 = extractvalue { i64, ptr } %t19, 1
  call void @__olang_region_release(ptr %t20)
  store { i64, ptr } zeroinitializer, ptr %l13
  br label %bb4
bb4:
  %t21 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %l16, !tbaa !27
  store { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %l17, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t25 = call { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t21, { i64, ptr } %t23, { i64, ptr } %t24)
  store { i64, ptr } %t25, ptr %l18
  br label %bb5
bb5:
  %t26 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t27, ptr %l20, !tbaa !27
  store { i64, ptr } %t26, ptr %l1, !tbaa !27
  %t29 = load i1, ptr @olang_2esole_2ecompiler__2fruntime__2eBionic_2elocal_2e1
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t31 = load { i64, ptr }, ptr %l20
  %t32 = extractvalue { i64, ptr } %t31, 1
  call void @__olang_region_release(ptr %t32)
  store { i64, ptr } zeroinitializer, ptr %l20
  br label %bb7
bb7:
  %t33 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t34 = load { i64, ptr }, ptr @G_2ecompiler_2fruntime_2eBionicShims, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t33, 1
  %t37 = extractvalue { i64, ptr } %t33, 0
  %t39 = extractvalue { i64, ptr } %t34, 1
  %t40 = extractvalue { i64, ptr } %t34, 0
  %t41 = add i64 %t37, %t40
  %t42 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t41)
  call void @olang_textcopy(ptr %t42, ptr %t36, i64 %t37)
  %t43 = getelementptr i8, ptr %t42, i64 %t37
  call void @olang_textcopy(ptr %t43, ptr %t39, i64 %t40)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t42, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t45, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fruntime_2eDecls(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca i1
  %l3 = alloca %"std/prelude/text:LineIter"
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca %"std/prelude/text:LineIter"
  %l8 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i32
  %l13 = alloca i1
  %l19 = alloca i1
  %l21 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l38 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l5
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store i1 false, ptr %l2, !tbaa !21
  %t5 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store %"std/prelude/text:LineIter" %t5, ptr %l7
  br label %bb2
bb2:
  %t6 = load %"std/prelude/text:LineIter", ptr %l7
  store %"std/prelude/text:LineIter" %t6, ptr %l3
  br label %bb3
bb3:
  %t8 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v0, ptr %l3)
  %t9 = extractvalue { i32, { i64, ptr } } %t8, 1
  %t10 = extractvalue { i32, { i64, ptr } } %t8, 0
  store i32 %t10, ptr %l11
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb5, label %ok.12, !prof !99
ok.12:
  store { i64, ptr } %t9, ptr %l10
  br label %bb4
bb4:
  %t13 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t13, ptr %l8, !tbaa !27
  br label %bb7
bb5:
  %t14 = load i32, ptr %l11, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  store i1 %t17, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  br label %bb30
bb7:
  %t18 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t18, ptr %l4, !tbaa !27
  %t19 = load i1, ptr %l2, !tbaa !21
  br i1 %t19, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t21 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %l1, { i64, ptr } %t21)
  br label %bb10
bb9:
  %t24 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t26 = call i1 @compiler_2fruntime_2emodulesInline(ptr %v0, { i64, ptr } %t24)
  store i1 %t26, ptr %l21
  br label %bb16
bb10:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 10)
  br label %bb11
bb11:
  %t28 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t30 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t28, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store i1 %t30, ptr %l19
  br label %bb12
bb12:
  %t31 = load i1, ptr %l19, !tbaa !21
  br i1 %t31, label %bb13, label %bb14
bb13:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb15
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb28
bb16:
  %t32 = load i1, ptr %l21, !tbaa !21
  br i1 %t32, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  store ptr %l1, ptr %l22, !tbaa !29
  %t33 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t33, ptr %l23, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t34, 0
  store i64 %t37, ptr %l26, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  store i64 %t39, ptr %l27, !tbaa !24
  %t40 = icmp sge i64 7, 0
  br i1 %t40, label %bb19, label %bb20
bb18:
  %t42 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fruntime_2edeclare(ptr %s0, ptr %v0, ptr %l1, { i64, ptr } %t42)
  br label %bb26
bb19:
  %t45 = load i64, ptr %l26, !tbaa !24
  %t46 = icmp sle i64 7, %t45
  br i1 %t46, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_4678f23b07212b71_6204d41da44925a5)
  unreachable
bb21:
  %t48 = load i64, ptr %l26, !tbaa !24
  %t49 = load i64, ptr %l27, !tbaa !24
  %t50 = icmp sle i64 %t48, %t49
  br i1 %t50, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_4678f23b07212b71_6204d41da44925a5)
  unreachable
bb23:
  %t52 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = load i64, ptr %l26, !tbaa !24
  %t55 = getelementptr i8, ptr %t53, i64 7
  %t56 = sub i64 %t54, 7
  %t57 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t55, 1
  %t59 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t62 = extractvalue { i64, ptr } %t58, 1
  %t63 = extractvalue { i64, ptr } %t58, 0
  %t64 = add i64 %t60, %t63
  %t65 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t66 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t67 = add i64 %t64, %t66
  %t68 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t67)
  call void @olang_textcopy(ptr %t68, ptr %t59, i64 %t60)
  %t69 = getelementptr i8, ptr %t68, i64 %t60
  call void @olang_textcopy(ptr %t69, ptr %t62, i64 %t63)
  %t70 = getelementptr i8, ptr %t69, i64 %t63
  call void @olang_textcopy(ptr %t70, ptr %t65, i64 %t66)
  %t71 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t68, 1
  %t74 = load ptr, ptr %l22, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %t74, { i64, ptr } %t72)
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_4678f23b07212b71_6204d41da44925a5)
  unreachable
bb25:
  store i1 true, ptr %l2, !tbaa !21
  call void @__olang_scope_close(ptr %s6)
  br label %bb27
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  br label %bb3
bb30:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 10)
  br label %bb31
bb31:
  %t78 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t78, ptr %l38
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s0)
  %t79 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t79, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fruntime_2eDyncallIr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, i1 %a4, i1 %a5, i1 %a6) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l3 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i32
  %l18 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i32
  %l26 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store { i64, ptr } %a1, ptr %l1
  store i1 %a3, ptr %l3
  store i1 %a5, ptr %l5
  store i1 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t2 = load i1, ptr %l3, !tbaa !21
  %t3 = load i1, ptr %l5, !tbaa !21
  %t4 = load i1, ptr %l6, !tbaa !21
  %t9 = call { i32, { i64, ptr } } @compiler_2fruntime_2eText(ptr %v1, ptr %s0, ptr %s0, { i64, ptr } %t1, i1 %t2, i1 false, i1 %t3, i1 %t4, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d9, i32 0, i32 1) })
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l16
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb2, label %ok.13, !prof !99
ok.13:
  store { i64, ptr } %t10, ptr %l15
  br label %bb1
bb1:
  %t14 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t14, ptr %l10, !tbaa !27
  br label %bb3
bb2:
  %t15 = load i32, ptr %l16, !tbaa !23
  %t16 = lshr i32 %t15, 16
  %t17 = and i32 %t15, 65535
  %t18 = icmp eq i32 %t16, 1
  %t19 = select i1 %t18, i32 1, i32 0
  %t20 = icmp eq i32 %t15, 0
  %t21 = shl i32 %t19, 16
  %t22 = or i32 %t21, %t17
  %t23 = select i1 %t20, i32 0, i32 %t22
  call void @__olang_scope_close(ptr %s0)
  %t25 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t23, 0
  store { i32, { i64, ptr } } %t25, ptr %rv
  br label %ret
bb3:
  %t26 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t26, ptr %l7, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t28 = load i1, ptr %l3, !tbaa !21
  %t29 = load i1, ptr %l5, !tbaa !21
  %t30 = load i1, ptr %l6, !tbaa !21
  %t35 = call { i32, { i64, ptr } } @compiler_2fruntime_2eText(ptr %v1, ptr %s0, ptr %s0, { i64, ptr } %t27, i1 %t28, i1 true, i1 %t29, i1 %t30, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d9, i32 0, i32 1) })
  %t36 = extractvalue { i32, { i64, ptr } } %t35, 1
  %t37 = extractvalue { i32, { i64, ptr } } %t35, 0
  store i32 %t37, ptr %l24
  %t38 = icmp ne i32 %t37, 0
  br i1 %t38, label %bb5, label %ok.39, !prof !99
ok.39:
  store { i64, ptr } %t36, ptr %l23
  br label %bb4
bb4:
  %t40 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t40, ptr %l18, !tbaa !27
  br label %bb6
bb5:
  %t41 = load i32, ptr %l24, !tbaa !23
  %t42 = lshr i32 %t41, 16
  %t43 = and i32 %t41, 65535
  %t44 = icmp eq i32 %t42, 1
  %t45 = select i1 %t44, i32 1, i32 0
  %t46 = icmp eq i32 %t41, 0
  %t47 = shl i32 %t45, 16
  %t48 = or i32 %t47, %t43
  %t49 = select i1 %t46, i32 0, i32 %t48
  call void @__olang_scope_close(ptr %s0)
  %t51 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t49, 0
  store { i32, { i64, ptr } } %t51, ptr %rv
  br label %ret
bb6:
  %t52 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t52, ptr %l8, !tbaa !27
  store { i64, ptr } %a0, ptr %l26, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t56 = call { i64, ptr } @compiler_2fruntime_2eDecls(ptr %s0, ptr %s0, { i64, ptr } %t54)
  store { i64, ptr } %t56, ptr %l28
  br label %bb7
bb7:
  %t57 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t58 = load { i64, ptr }, ptr @G_2ecompiler_2fruntime_2eHeaderTbaa, !tbaa !27
  %t59 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t61 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t61, 1
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t64 = add i64 %t60, %t63
  %t65 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t66 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t67 = add i64 %t64, %t66
  %t68 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 1
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t71 = add i64 %t67, %t70
  %t73 = extractvalue { i64, ptr } %t57, 1
  %t74 = extractvalue { i64, ptr } %t57, 0
  %t75 = add i64 %t71, %t74
  %t76 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t77 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t78 = add i64 %t75, %t77
  %t80 = extractvalue { i64, ptr } %t58, 1
  %t81 = extractvalue { i64, ptr } %t58, 0
  %t82 = add i64 %t78, %t81
  %t83 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t82)
  call void @olang_textcopy(ptr %t83, ptr %t59, i64 %t60)
  %t84 = getelementptr i8, ptr %t83, i64 %t60
  call void @olang_textcopy(ptr %t84, ptr %t62, i64 %t63)
  %t85 = getelementptr i8, ptr %t84, i64 %t63
  call void @olang_textcopy(ptr %t85, ptr %t65, i64 %t66)
  %t86 = getelementptr i8, ptr %t85, i64 %t66
  call void @olang_textcopy(ptr %t86, ptr %t69, i64 %t70)
  %t87 = getelementptr i8, ptr %t86, i64 %t70
  call void @olang_textcopy(ptr %t87, ptr %t73, i64 %t74)
  %t88 = getelementptr i8, ptr %t87, i64 %t74
  call void @olang_textcopy(ptr %t88, ptr %t76, i64 %t77)
  %t89 = getelementptr i8, ptr %t88, i64 %t77
  call void @olang_textcopy(ptr %t89, ptr %t80, i64 %t81)
  %t90 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t83, 1
  %t99 = call { i64, ptr } @compiler_2fruntime_2eWithAttributes(ptr %s0, ptr %v2, ptr %v3, { i64, ptr } %t91, { i64, ptr } %a2, i1 %a4)
  store { i64, ptr } %t99, ptr %l35
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t100 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t101 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t100, 1
  store { i32, { i64, ptr } } %t101, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fruntime_2eFill(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, i1 %a3, i1 %a4, { i64, ptr } %a5) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/text:StringBuilder"
  %l11 = alloca i64
  %l12 = alloca i1
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i64
  %l16 = alloca %"std/prelude/text:LineIter"
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i1
  %l22 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l30 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i32
  %l38 = alloca i1
  %l43 = alloca i32
  %l45 = alloca i1
  %l52 = alloca i1
  %l53 = alloca i64
  %l55 = alloca i64
  %l56 = alloca %"std/prelude/text:StringBuilder"
  %l58 = alloca %"std/prelude/text:LineIter"
  %l59 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca i32
  %l64 = alloca i1
  %l70 = alloca i1
  %l72 = alloca i1
  %l73 = alloca { i64, ptr }
  %l76 = alloca i64
  %l77 = alloca i64
  %l83 = alloca i1
  %l85 = alloca i1
  %l86 = alloca { i64, ptr }
  %l89 = alloca i64
  %l90 = alloca i64
  %l96 = alloca i64
  %l102 = alloca i32
  %l104 = alloca { i64, ptr }
  %l107 = alloca i64
  %l108 = alloca i64
  %l113 = alloca { i64, ptr }
  %l115 = alloca i1
  %l117 = alloca { i64, ptr }
  %l120 = alloca i64
  %l121 = alloca i64
  %l126 = alloca i64
  %l128 = alloca i64
  %l129 = alloca i32
  %l132 = alloca { i64, ptr }
  %l133 = alloca i64
  %l134 = alloca i64
  %l140 = alloca i1
  %l142 = alloca i1
  %l147 = alloca i1
  %l151 = alloca i32
  %l154 = alloca i1
  %l155 = alloca i1
  %l159 = alloca i1
  %l168 = alloca i1
  %l172 = alloca i32
  %l183 = alloca i32
  %l188 = alloca { i64, ptr }
  %l189 = alloca i1
  %l194 = alloca i64
  %l196 = alloca i64
  %l197 = alloca i32
  %l202 = alloca ptr
  %l203 = alloca { i64, ptr }
  %l204 = alloca i64
  %l205 = alloca i64
  %l210 = alloca { i64, ptr }
  %l212 = alloca i64
  %l215 = alloca i64
  %l216 = alloca i64
  %l221 = alloca i64
  %l223 = alloca i64
  %l224 = alloca i32
  %l229 = alloca i32
  %l231 = alloca i64
  %l232 = alloca { i64, ptr }
  %l233 = alloca i64
  %l234 = alloca i64
  %l240 = alloca i64
  %l241 = alloca i32
  %l243 = alloca i1
  %l246 = alloca i32
  %l252 = alloca { i64, ptr }
  %l254 = alloca i64
  %l257 = alloca i64
  %l258 = alloca i64
  %l267 = alloca i32
  %l270 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %s0)
  store { i64, ptr } %t1, ptr %l30
  br label %bb1
bb1:
  %t3 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t3, 1
  %t5 = extractvalue { i64, ptr } %t3, 0
  %t6 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a0, 1
  %t11 = extractvalue { i64, ptr } %a0, 0
  %t12 = add i64 %t8, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t6, i64 %t7)
  %t15 = getelementptr i8, ptr %t14, i64 %t7
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  store { i64, ptr } %t17, ptr %l6, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t21 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } %t19)
  %t22 = extractvalue { i32, { i64, ptr } } %t21, 1
  %t23 = extractvalue { i32, { i64, ptr } } %t21, 0
  store i32 %t23, ptr %l36
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb3, label %ok.25, !prof !99
ok.25:
  store { i64, ptr } %t22, ptr %l35
  br label %bb2
bb2:
  %t26 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t26, ptr %l33, !tbaa !27
  br label %bb13
bb3:
  %t27 = load i32, ptr %l36, !tbaa !23
  %t28 = ashr i32 %t27, 16
  %t30 = icmp eq i32 %t28, 1
  store i1 %t30, ptr %l38, !tbaa !21
  %t31 = load i32, ptr %l36, !tbaa !23
  %t32 = ashr i32 %t31, 16
  %t34 = icmp eq i32 %t32, 1
  br i1 %t34, label %bb4, label %bb5
bb4:
  call void @__olang_errpay_pop()
  br label %bb5
bb5:
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t37 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t40 = extractvalue { i64, ptr } %t36, 1
  %t41 = extractvalue { i64, ptr } %t36, 0
  %t42 = add i64 %t38, %t41
  %t43 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t45 = add i64 %t42, %t44
  %t46 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t45)
  call void @olang_textcopy(ptr %t46, ptr %t37, i64 %t38)
  %t47 = getelementptr i8, ptr %t46, i64 %t38
  call void @olang_textcopy(ptr %t47, ptr %t40, i64 %t41)
  %t48 = getelementptr i8, ptr %t47, i64 %t41
  call void @olang_textcopy(ptr %t48, ptr %t43, i64 %t44)
  %t49 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t46, 1
  %t52 = call i32 @std_2fio_2ePutErrLn_3cstd_2fprelude_2ftext_3aString_3e({ i64, ptr } %t50)
  store i32 %t52, ptr %l43
  %t53 = icmp ne i32 %t52, 0
  br i1 %t53, label %bb8, label %ok.54, !prof !99
ok.54:
  br label %bb7
bb7:
  br label %bb12
bb8:
  %t55 = load i32, ptr %l43, !tbaa !23
  %t56 = ashr i32 %t55, 16
  %t58 = icmp eq i32 %t56, 1
  store i1 %t58, ptr %l45, !tbaa !21
  %t59 = load i32, ptr %l43, !tbaa !23
  %t60 = ashr i32 %t59, 16
  %t62 = icmp eq i32 %t60, 1
  br i1 %t62, label %bb9, label %bb10
bb9:
  call void @__olang_errpay_pop()
  br label %bb10
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t65 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t65, ptr %rv
  br label %ret
bb13:
  %t66 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t66, ptr %l8, !tbaa !27
  %t72 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %a5, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d16, i32 0, i32 1) })
  store i1 %t72, ptr %l52
  br label %bb14
bb14:
  %t73 = load i1, ptr %l52, !tbaa !21
  br i1 %t73, label %bb15, label %bb16
bb15:
  store i64 2, ptr %l53, !tbaa !24
  br label %bb18
bb16:
  %t74 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t76 = call i64 @compiler_2fruntime_2earchRow(ptr %v1, { i64, ptr } %t74)
  store i64 %t76, ptr %l55
  br label %bb17
bb17:
  %t77 = load i64, ptr %l55, !tbaa !24
  store i64 %t77, ptr %l53, !tbaa !24
  br label %bb18
bb18:
  %t78 = load i64, ptr %l53, !tbaa !24
  store i64 %t78, ptr %l9, !tbaa !24
  %t79 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t79, ptr %l56
  br label %bb19
bb19:
  %t80 = load %"std/prelude/text:StringBuilder", ptr %l56
  store %"std/prelude/text:StringBuilder" %t80, ptr %l10
  store i64 0, ptr %l11, !tbaa !24
  store i1 false, ptr %l12, !tbaa !21
  store i1 false, ptr %l13, !tbaa !21
  store i1 true, ptr %l14, !tbaa !21
  store i64 0, ptr %l15, !tbaa !24
  %t81 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t83 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %s0, ptr %s0, { i64, ptr } %t81)
  store %"std/prelude/text:LineIter" %t83, ptr %l58
  br label %bb20
bb20:
  %t84 = load %"std/prelude/text:LineIter", ptr %l58
  store %"std/prelude/text:LineIter" %t84, ptr %l16
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s6
  %t86 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %s0, ptr %s0, ptr %l16)
  %t87 = extractvalue { i32, { i64, ptr } } %t86, 1
  %t88 = extractvalue { i32, { i64, ptr } } %t86, 0
  store i32 %t88, ptr %l62
  %t89 = icmp ne i32 %t88, 0
  br i1 %t89, label %bb23, label %ok.90, !prof !99
ok.90:
  store { i64, ptr } %t87, ptr %l61
  br label %bb22
bb22:
  %t91 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t91, ptr %l59, !tbaa !27
  br label %bb25
bb23:
  %t92 = load i32, ptr %l62, !tbaa !23
  %t93 = ashr i32 %t92, 16
  %t95 = icmp eq i32 %t93, 1
  store i1 %t95, ptr %l64, !tbaa !21
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s6)
  br label %bb195
bb25:
  %t96 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t96, ptr %l17, !tbaa !27
  %t97 = load i64, ptr %l11, !tbaa !24
  %t100 = add i64 %t97, 1
  store i64 %t100, ptr %l11, !tbaa !24
  %t102 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t102, ptr %l18, !tbaa !27
  br i1 %a3, label %bb26, label %bb27
bb26:
  %t106 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t108 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s6, { i64, ptr } %t106, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store i1 %t108, ptr %l72
  br label %bb28
bb27:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb29
bb28:
  %t109 = load i1, ptr %l72, !tbaa !21
  store i1 %t109, ptr %l70, !tbaa !21
  br label %bb29
bb29:
  %t110 = load i1, ptr %l70, !tbaa !21
  br i1 %t110, label %bb30, label %bb31
bb30:
  %t111 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t111, ptr %l73, !tbaa !27
  %t112 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t112, 0
  store i64 %t115, ptr %l76, !tbaa !24
  %t116 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t116, 0
  store i64 %t117, ptr %l77, !tbaa !24
  %t118 = icmp sge i64 8, 0
  br i1 %t118, label %bb32, label %bb33
bb31:
  br label %bb38
bb32:
  %t120 = load i64, ptr %l76, !tbaa !24
  %t121 = icmp sle i64 8, %t120
  br i1 %t121, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_6e9edb7ac3cc3a13_be559f1d61e4dd6f)
  unreachable
bb34:
  %t123 = load i64, ptr %l76, !tbaa !24
  %t124 = load i64, ptr %l77, !tbaa !24
  %t125 = icmp sle i64 %t123, %t124
  br i1 %t125, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_6e9edb7ac3cc3a13_be559f1d61e4dd6f)
  unreachable
bb36:
  %t127 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = load i64, ptr %l76, !tbaa !24
  %t130 = getelementptr i8, ptr %t128, i64 8
  %t131 = sub i64 %t129, 8
  %t132 = insertvalue { i64, ptr } undef, i64 %t131, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr %t130, 1
  store { i64, ptr } %t133, ptr %l18, !tbaa !27
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_6e9edb7ac3cc3a13_be559f1d61e4dd6f)
  unreachable
bb38:
  br i1 %a4, label %bb39, label %bb40
bb39:
  %t137 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t139 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s6, { i64, ptr } %t137, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d18, i32 0, i32 1) })
  store i1 %t139, ptr %l85
  br label %bb41
bb40:
  store i1 false, ptr %l83, !tbaa !21
  br label %bb42
bb41:
  %t140 = load i1, ptr %l85, !tbaa !21
  store i1 %t140, ptr %l83, !tbaa !21
  br label %bb42
bb42:
  %t141 = load i1, ptr %l83, !tbaa !21
  br i1 %t141, label %bb43, label %bb44
bb43:
  %t142 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t142, ptr %l86, !tbaa !27
  %t143 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t143, 0
  store i64 %t146, ptr %l89, !tbaa !24
  %t147 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t147, 0
  store i64 %t148, ptr %l90, !tbaa !24
  %t149 = icmp sge i64 9, 0
  br i1 %t149, label %bb45, label %bb46
bb44:
  br label %bb51
bb45:
  %t151 = load i64, ptr %l89, !tbaa !24
  %t152 = icmp sle i64 9, %t151
  br i1 %t152, label %bb47, label %bb48
bb46:
  call void @__olang_check_failed(ptr @olang_loc_6e8de55f6b48d5b6_301f420811d0f7f2)
  unreachable
bb47:
  %t154 = load i64, ptr %l89, !tbaa !24
  %t155 = load i64, ptr %l90, !tbaa !24
  %t156 = icmp sle i64 %t154, %t155
  br i1 %t156, label %bb49, label %bb50
bb48:
  call void @__olang_check_failed(ptr @olang_loc_6e8de55f6b48d5b6_301f420811d0f7f2)
  unreachable
bb49:
  %t158 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !27
  %t160 = load i64, ptr %l89, !tbaa !24
  %t161 = getelementptr i8, ptr %t159, i64 9
  %t162 = sub i64 %t160, 9
  %t163 = insertvalue { i64, ptr } undef, i64 %t162, 0
  %t164 = insertvalue { i64, ptr } %t163, ptr %t161, 1
  store { i64, ptr } %t164, ptr %l18, !tbaa !27
  br label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_6e8de55f6b48d5b6_301f420811d0f7f2)
  unreachable
bb51:
  %t166 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t168 = call i64 @compiler_2fruntime_2edirective(ptr %s0, { i64, ptr } %t166)
  store i64 %t168, ptr %l96
  br label %bb52
bb52:
  %t169 = load i64, ptr %l96, !tbaa !24
  store i64 %t169, ptr %l19, !tbaa !24
  %t170 = load i64, ptr %l19, !tbaa !24
  %t172 = icmp eq i64 %t170, 0
  br i1 %t172, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s9
  %t174 = load i1, ptr %l12, !tbaa !21
  br i1 %t174, label %bb55, label %bb56
bb54:
  br label %bb107
bb55:
  store %olang.scope zeroinitializer, ptr %s10
  %t176 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t177 = load i64, ptr %l11, !tbaa !24
  %t180 = call i32 @compiler_2fruntime_2emalformed(ptr %s0, ptr %s10, { i64, ptr } %t176, i64 %t177, { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d19, i32 0, i32 1) })
  store i32 %t180, ptr %l102
  %t181 = icmp ne i32 %t180, 0
  br i1 %t181, label %bb58, label %ok.182, !prof !99
ok.182:
  br label %bb57
bb56:
  br label %bb60
bb57:
  br label %bb59
bb58:
  %t183 = load i32, ptr %l102, !tbaa !23
  %t184 = lshr i32 %t183, 16
  %t185 = and i32 %t183, 65535
  %t186 = icmp eq i32 %t184, 1
  %t187 = select i1 %t186, i32 1, i32 0
  %t188 = icmp eq i32 %t183, 0
  %t189 = shl i32 %t187, 16
  %t190 = or i32 %t189, %t185
  %t191 = select i1 %t188, i32 0, i32 %t190
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t193 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t191, 0
  store { i32, { i64, ptr } } %t193, ptr %rv
  br label %ret
bb59:
  call void @__olang_scope_close(ptr %s10)
  br label %bb60
bb60:
  %t194 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t194, ptr %l104, !tbaa !27
  %t195 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t195, 0
  store i64 %t198, ptr %l107, !tbaa !24
  %t199 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t200 = extractvalue { i64, ptr } %t199, 0
  store i64 %t200, ptr %l108, !tbaa !24
  %t201 = icmp sge i64 6, 0
  br i1 %t201, label %bb61, label %bb62
bb61:
  %t203 = load i64, ptr %l107, !tbaa !24
  %t204 = icmp sle i64 6, %t203
  br i1 %t204, label %bb63, label %bb64
bb62:
  call void @__olang_check_failed(ptr @olang_loc_37c6cc80b337eb95_eeee9a64b49e7a71)
  unreachable
bb63:
  %t206 = load i64, ptr %l107, !tbaa !24
  %t207 = load i64, ptr %l108, !tbaa !24
  %t208 = icmp sle i64 %t206, %t207
  br i1 %t208, label %bb65, label %bb66
bb64:
  call void @__olang_check_failed(ptr @olang_loc_37c6cc80b337eb95_eeee9a64b49e7a71)
  unreachable
bb65:
  %t210 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t211 = load ptr, ptr %t210, !tbaa !27
  %t212 = load i64, ptr %l107, !tbaa !24
  %t213 = getelementptr i8, ptr %t211, i64 6
  %t214 = sub i64 %t212, 6
  %t215 = insertvalue { i64, ptr } undef, i64 %t214, 0
  %t216 = insertvalue { i64, ptr } %t215, ptr %t213, 1
  %t218 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %s0, ptr %s0, { i64, ptr } %t216)
  store { i64, ptr } %t218, ptr %l113
  br label %bb67
bb66:
  call void @__olang_check_failed(ptr @olang_loc_37c6cc80b337eb95_eeee9a64b49e7a71)
  unreachable
bb67:
  %t219 = load { i64, ptr }, ptr %l113, !tbaa !27
  store { i64, ptr } %t219, ptr %l20, !tbaa !27
  %t220 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t222 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s9, { i64, ptr } %t220, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) })
  store i1 %t222, ptr %l115
  br label %bb68
bb68:
  %t223 = load i1, ptr %l115, !tbaa !21
  store i1 %t223, ptr %l21, !tbaa !21
  %t224 = load i1, ptr %l21, !tbaa !21
  br i1 %t224, label %bb69, label %bb70
bb69:
  %t226 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t226, ptr %l117, !tbaa !27
  %t227 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t230 = extractvalue { i64, ptr } %t227, 0
  store i64 %t230, ptr %l120, !tbaa !24
  %t231 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t231, 0
  store i64 %t232, ptr %l121, !tbaa !24
  %t233 = icmp sge i64 1, 0
  br i1 %t233, label %bb71, label %bb72
bb70:
  br label %bb77
bb71:
  %t235 = load i64, ptr %l120, !tbaa !24
  %t236 = icmp sle i64 1, %t235
  br i1 %t236, label %bb73, label %bb74
bb72:
  call void @__olang_check_failed(ptr @olang_loc_5fea096add1795b8_392858cd9c11d804)
  unreachable
bb73:
  %t238 = load i64, ptr %l120, !tbaa !24
  %t239 = load i64, ptr %l121, !tbaa !24
  %t240 = icmp sle i64 %t238, %t239
  br i1 %t240, label %bb75, label %bb76
bb74:
  call void @__olang_check_failed(ptr @olang_loc_5fea096add1795b8_392858cd9c11d804)
  unreachable
bb75:
  %t242 = getelementptr { i64, ptr }, ptr %l117, i32 0, i32 1
  %t243 = load ptr, ptr %t242, !tbaa !27
  %t244 = load i64, ptr %l120, !tbaa !24
  %t245 = getelementptr i8, ptr %t243, i64 1
  %t246 = sub i64 %t244, 1
  %t247 = insertvalue { i64, ptr } undef, i64 %t246, 0
  %t248 = insertvalue { i64, ptr } %t247, ptr %t245, 1
  store { i64, ptr } %t248, ptr %l20, !tbaa !27
  br label %bb77
bb76:
  call void @__olang_check_failed(ptr @olang_loc_5fea096add1795b8_392858cd9c11d804)
  unreachable
bb77:
  %t250 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t252 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s0, ptr %s9, { i64, ptr } %t250, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d21, i32 0, i32 1) })
  %t253 = extractvalue { i32, i64 } %t252, 1
  %t254 = extractvalue { i32, i64 } %t252, 0
  store i32 %t254, ptr %l129
  %t255 = icmp ne i32 %t254, 0
  br i1 %t255, label %bb79, label %ok.256, !prof !99
ok.256:
  store i64 %t253, ptr %l128
  br label %bb78
bb78:
  %t257 = load i64, ptr %l128, !tbaa !24
  store i64 %t257, ptr %l126, !tbaa !24
  br label %bb81
bb79:
  br label %bb80
bb80:
  store i64 -1, ptr %l126, !tbaa !24
  br label %bb81
bb81:
  %t258 = load i64, ptr %l126, !tbaa !24
  store i64 %t258, ptr %l22, !tbaa !24
  %t259 = load i64, ptr %l22, !tbaa !24
  %t261 = icmp sge i64 %t259, 0
  br i1 %t261, label %bb82, label %bb83
bb82:
  %t263 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t263, ptr %l132, !tbaa !27
  %t264 = load i64, ptr %l22, !tbaa !24
  store i64 %t264, ptr %l133, !tbaa !24
  %t265 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t266 = extractvalue { i64, ptr } %t265, 0
  store i64 %t266, ptr %l134, !tbaa !24
  %t267 = icmp sge i64 0, 0
  br i1 %t267, label %bb84, label %bb85
bb83:
  br label %bb90
bb84:
  %t269 = load i64, ptr %l133, !tbaa !24
  %t270 = icmp sle i64 0, %t269
  br i1 %t270, label %bb86, label %bb87
bb85:
  call void @__olang_check_failed(ptr @olang_loc_b0282b0bffd0a537_97cbf26a9ab19d0b)
  unreachable
bb86:
  %t272 = load i64, ptr %l133, !tbaa !24
  %t273 = load i64, ptr %l134, !tbaa !24
  %t274 = icmp sle i64 %t272, %t273
  br i1 %t274, label %bb88, label %bb89
bb87:
  call void @__olang_check_failed(ptr @olang_loc_b0282b0bffd0a537_97cbf26a9ab19d0b)
  unreachable
bb88:
  %t276 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !27
  %t278 = load i64, ptr %l133, !tbaa !24
  %t279 = getelementptr i8, ptr %t277, i64 0
  %t280 = sub i64 %t278, 0
  %t281 = insertvalue { i64, ptr } undef, i64 %t280, 0
  %t282 = insertvalue { i64, ptr } %t281, ptr %t279, 1
  store { i64, ptr } %t282, ptr %l20, !tbaa !27
  br label %bb90
bb89:
  call void @__olang_check_failed(ptr @olang_loc_b0282b0bffd0a537_97cbf26a9ab19d0b)
  unreachable
bb90:
  %t284 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t286 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s9, { i64, ptr } %t284, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store i1 %t286, ptr %l140
  br label %bb91
bb91:
  %t287 = load i1, ptr %l140, !tbaa !21
  %t288 = xor i1 %t287, true
  br i1 %t288, label %bb92, label %bb93
bb92:
  %t290 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t293 = insertvalue { i64, ptr } undef, i64 2, 0
  %t294 = insertvalue { i64, ptr } %t293, ptr @G_2ecompiler_2fruntime_2eArchs, 1
  %t296 = load ptr, ptr @__olang_prog_scope
  %t299 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t296, ptr %s0, { i64, ptr } %t294, { i64, ptr } %t290)
  store i1 %t299, ptr %l147
  br label %bb94
bb93:
  store i1 false, ptr %l142, !tbaa !21
  br label %bb95
bb94:
  %t300 = load i1, ptr %l147, !tbaa !21
  %t301 = xor i1 %t300, true
  store i1 %t301, ptr %l142, !tbaa !21
  br label %bb95
bb95:
  %t303 = load i1, ptr %l142, !tbaa !21
  br i1 %t303, label %bb96, label %bb97
bb96:
  store %olang.scope zeroinitializer, ptr %s13
  %t304 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t305 = load i64, ptr %l11, !tbaa !24
  %t308 = call i32 @compiler_2fruntime_2emalformed(ptr %s0, ptr %s13, { i64, ptr } %t304, i64 %t305, { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d23, i32 0, i32 1) })
  store i32 %t308, ptr %l151
  %t309 = icmp ne i32 %t308, 0
  br i1 %t309, label %bb99, label %ok.310, !prof !99
ok.310:
  br label %bb98
bb97:
  br label %bb101
bb98:
  br label %bb100
bb99:
  %t311 = load i32, ptr %l151, !tbaa !23
  %t312 = lshr i32 %t311, 16
  %t313 = and i32 %t311, 65535
  %t314 = icmp eq i32 %t312, 1
  %t315 = select i1 %t314, i32 1, i32 0
  %t316 = icmp eq i32 %t311, 0
  %t317 = shl i32 %t315, 16
  %t318 = or i32 %t317, %t313
  %t319 = select i1 %t316, i32 0, i32 %t318
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t321 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t319, 0
  store { i32, { i64, ptr } } %t321, ptr %rv
  br label %ret
bb100:
  call void @__olang_scope_close(ptr %s13)
  br label %bb101
bb101:
  %t322 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t324 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s9, { i64, ptr } %t322, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d24, i32 0, i32 1) })
  store i1 %t324, ptr %l154
  br label %bb102
bb102:
  %t325 = load i1, ptr %l154, !tbaa !21
  br i1 %t325, label %bb103, label %bb104
bb103:
  store i1 %a2, ptr %l155, !tbaa !21
  br label %bb106
bb104:
  %t328 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t329 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t332 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %v1, { i64, ptr } %t328, { i64, ptr } %t329)
  store i1 %t332, ptr %l159
  br label %bb105
bb105:
  %t333 = load i1, ptr %l159, !tbaa !21
  store i1 %t333, ptr %l155, !tbaa !21
  br label %bb106
bb106:
  %t334 = load i1, ptr %l155, !tbaa !21
  %t336 = load i1, ptr %l21, !tbaa !21
  %t339 = icmp ne i1 %t334, %t336
  store i1 %t339, ptr %l14, !tbaa !21
  store i1 true, ptr %l12, !tbaa !21
  store i1 false, ptr %l13, !tbaa !21
  %t341 = load i64, ptr %l11, !tbaa !24
  store i64 %t341, ptr %l15, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s6)
  br label %bb194
bb107:
  %t343 = load i64, ptr %l19, !tbaa !24
  %t345 = icmp eq i64 %t343, 1
  br i1 %t345, label %bb108, label %bb109
bb108:
  %t347 = load i1, ptr %l12, !tbaa !21
  %t349 = xor i1 %t347, true
  br i1 %t349, label %bb110, label %bb111
bb109:
  br label %bb119
bb110:
  store i1 true, ptr %l168, !tbaa !21
  br label %bb112
bb111:
  %t351 = load i1, ptr %l13, !tbaa !21
  store i1 %t351, ptr %l168, !tbaa !21
  br label %bb112
bb112:
  %t353 = load i1, ptr %l168, !tbaa !21
  br i1 %t353, label %bb113, label %bb114
bb113:
  store %olang.scope zeroinitializer, ptr %s15
  %t354 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t355 = load i64, ptr %l11, !tbaa !24
  %t358 = call i32 @compiler_2fruntime_2emalformed(ptr %s0, ptr %s15, { i64, ptr } %t354, i64 %t355, { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d25, i32 0, i32 1) })
  store i32 %t358, ptr %l172
  %t359 = icmp ne i32 %t358, 0
  br i1 %t359, label %bb116, label %ok.360, !prof !99
ok.360:
  br label %bb115
bb114:
  br label %bb118
bb115:
  br label %bb117
bb116:
  %t361 = load i32, ptr %l172, !tbaa !23
  %t362 = lshr i32 %t361, 16
  %t363 = and i32 %t361, 65535
  %t364 = icmp eq i32 %t362, 1
  %t365 = select i1 %t364, i32 1, i32 0
  %t366 = icmp eq i32 %t361, 0
  %t367 = shl i32 %t365, 16
  %t368 = or i32 %t367, %t363
  %t369 = select i1 %t366, i32 0, i32 %t368
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t371 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t369, 0
  store { i32, { i64, ptr } } %t371, ptr %rv
  br label %ret
bb117:
  call void @__olang_scope_close(ptr %s15)
  br label %bb118
bb118:
  %t372 = load i1, ptr %l14, !tbaa !21
  %t375 = xor i1 %t372, true
  store i1 %t375, ptr %l14, !tbaa !21
  store i1 true, ptr %l13, !tbaa !21
  call void @__olang_scope_close(ptr %s6)
  br label %bb194
bb119:
  %t377 = load i64, ptr %l19, !tbaa !24
  %t379 = icmp eq i64 %t377, 2
  br i1 %t379, label %bb120, label %bb121
bb120:
  %t381 = load i1, ptr %l12, !tbaa !21
  %t383 = xor i1 %t381, true
  br i1 %t383, label %bb122, label %bb123
bb121:
  br label %bb128
bb122:
  store %olang.scope zeroinitializer, ptr %s17
  %t385 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t386 = load i64, ptr %l11, !tbaa !24
  %t389 = call i32 @compiler_2fruntime_2emalformed(ptr %s0, ptr %s17, { i64, ptr } %t385, i64 %t386, { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d26, i32 0, i32 1) })
  store i32 %t389, ptr %l183
  %t390 = icmp ne i32 %t389, 0
  br i1 %t390, label %bb125, label %ok.391, !prof !99
ok.391:
  br label %bb124
bb123:
  br label %bb127
bb124:
  br label %bb126
bb125:
  %t392 = load i32, ptr %l183, !tbaa !23
  %t393 = lshr i32 %t392, 16
  %t394 = and i32 %t392, 65535
  %t395 = icmp eq i32 %t393, 1
  %t396 = select i1 %t395, i32 1, i32 0
  %t397 = icmp eq i32 %t392, 0
  %t398 = shl i32 %t396, 16
  %t399 = or i32 %t398, %t394
  %t400 = select i1 %t397, i32 0, i32 %t399
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t402 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t400, 0
  store { i32, { i64, ptr } } %t402, ptr %rv
  br label %ret
bb126:
  call void @__olang_scope_close(ptr %s17)
  br label %bb127
bb127:
  store i1 false, ptr %l12, !tbaa !21
  store i1 true, ptr %l14, !tbaa !21
  call void @__olang_scope_close(ptr %s6)
  br label %bb194
bb128:
  %t403 = load i1, ptr %l14, !tbaa !21
  %t405 = xor i1 %t403, true
  br i1 %t405, label %bb129, label %bb130
bb129:
  call void @__olang_scope_close(ptr %s6)
  br label %bb194
bb130:
  br label %bb131
bb131:
  %t407 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t409 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %s0, ptr %s0, { i64, ptr } %t407)
  store { i64, ptr } %t409, ptr %l188
  br label %bb132
bb132:
  %t410 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t411 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s6, { i64, ptr } %t410, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) })
  store i1 %t411, ptr %l189
  br label %bb133
bb133:
  %t412 = load i1, ptr %l189, !tbaa !21
  br i1 %t412, label %bb134, label %bb135
bb134:
  %t413 = load { i64, ptr }, ptr %l18, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l10, { i64, ptr } %t413)
  br label %bb136
bb135:
  br label %bb138
bb136:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l10, i8 10)
  br label %bb137
bb137:
  call void @__olang_scope_close(ptr %s6)
  br label %bb194
bb138:
  %t417 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t417, ptr %l25, !tbaa !27
  br label %bb139
bb139:
  store %olang.scope zeroinitializer, ptr %s20
  %t419 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t421 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s0, ptr %s20, { i64, ptr } %t419, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d28, i32 0, i32 1) })
  %t422 = extractvalue { i32, i64 } %t421, 1
  %t423 = extractvalue { i32, i64 } %t421, 0
  store i32 %t423, ptr %l197
  %t424 = icmp ne i32 %t423, 0
  br i1 %t424, label %bb141, label %ok.425, !prof !99
ok.425:
  store i64 %t422, ptr %l196
  br label %bb140
bb140:
  %t426 = load i64, ptr %l196, !tbaa !24
  store i64 %t426, ptr %l194, !tbaa !24
  br label %bb143
bb141:
  br label %bb142
bb142:
  store i64 -1, ptr %l194, !tbaa !24
  br label %bb143
bb143:
  %t427 = load i64, ptr %l194, !tbaa !24
  store i64 %t427, ptr %l26, !tbaa !24
  %t428 = load i64, ptr %l26, !tbaa !24
  %t430 = icmp slt i64 %t428, 0
  br i1 %t430, label %bb144, label %bb145
bb144:
  %t432 = load { i64, ptr }, ptr %l25, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l10, { i64, ptr } %t432)
  br label %bb146
bb145:
  br label %bb147
bb146:
  call void @__olang_scope_close(ptr %s20)
  br label %bb192
bb147:
  store ptr %l10, ptr %l202, !tbaa !29
  %t435 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t435, ptr %l203, !tbaa !27
  %t436 = load i64, ptr %l26, !tbaa !24
  store i64 %t436, ptr %l204, !tbaa !24
  %t437 = load { i64, ptr }, ptr %l203, !tbaa !27
  %t438 = extractvalue { i64, ptr } %t437, 0
  store i64 %t438, ptr %l205, !tbaa !24
  %t439 = icmp sge i64 0, 0
  br i1 %t439, label %bb148, label %bb149
bb148:
  %t441 = load i64, ptr %l204, !tbaa !24
  %t442 = icmp sle i64 0, %t441
  br i1 %t442, label %bb150, label %bb151
bb149:
  call void @__olang_check_failed(ptr @olang_loc_70ff22b8cac083da_c5bb23930b7510e)
  unreachable
bb150:
  %t444 = load i64, ptr %l204, !tbaa !24
  %t445 = load i64, ptr %l205, !tbaa !24
  %t446 = icmp sle i64 %t444, %t445
  br i1 %t446, label %bb152, label %bb153
bb151:
  call void @__olang_check_failed(ptr @olang_loc_70ff22b8cac083da_c5bb23930b7510e)
  unreachable
bb152:
  %t448 = getelementptr { i64, ptr }, ptr %l203, i32 0, i32 1
  %t449 = load ptr, ptr %t448, !tbaa !27
  %t450 = load i64, ptr %l204, !tbaa !24
  %t451 = getelementptr i8, ptr %t449, i64 0
  %t452 = sub i64 %t450, 0
  %t453 = insertvalue { i64, ptr } undef, i64 %t452, 0
  %t454 = insertvalue { i64, ptr } %t453, ptr %t451, 1
  %t455 = load ptr, ptr %l202, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t455, { i64, ptr } %t454)
  br label %bb154
bb153:
  call void @__olang_check_failed(ptr @olang_loc_70ff22b8cac083da_c5bb23930b7510e)
  unreachable
bb154:
  %t457 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t457, ptr %l210, !tbaa !27
  %t458 = load i64, ptr %l26, !tbaa !24
  %t460 = add i64 %t458, 2
  store i64 %t460, ptr %l212, !tbaa !24
  %t461 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t464 = extractvalue { i64, ptr } %t461, 0
  store i64 %t464, ptr %l215, !tbaa !24
  %t465 = load { i64, ptr }, ptr %l210, !tbaa !27
  %t466 = extractvalue { i64, ptr } %t465, 0
  store i64 %t466, ptr %l216, !tbaa !24
  %t467 = load i64, ptr %l212, !tbaa !24
  %t468 = icmp sge i64 %t467, 0
  br i1 %t468, label %bb155, label %bb156
bb155:
  %t470 = load i64, ptr %l212, !tbaa !24
  %t471 = load i64, ptr %l215, !tbaa !24
  %t472 = icmp sle i64 %t470, %t471
  br i1 %t472, label %bb157, label %bb158
bb156:
  call void @__olang_check_failed(ptr @olang_loc_fb2acf0450ba6c79_597b56b8350f036d)
  unreachable
bb157:
  %t474 = load i64, ptr %l215, !tbaa !24
  %t475 = load i64, ptr %l216, !tbaa !24
  %t476 = icmp sle i64 %t474, %t475
  br i1 %t476, label %bb159, label %bb160
bb158:
  call void @__olang_check_failed(ptr @olang_loc_fb2acf0450ba6c79_597b56b8350f036d)
  unreachable
bb159:
  %t478 = getelementptr { i64, ptr }, ptr %l210, i32 0, i32 1
  %t479 = load ptr, ptr %t478, !tbaa !27
  %t480 = load i64, ptr %l212, !tbaa !24
  %t481 = load i64, ptr %l215, !tbaa !24
  %t482 = getelementptr i8, ptr %t479, i64 %t480
  %t483 = sub i64 %t481, %t480
  %t484 = insertvalue { i64, ptr } undef, i64 %t483, 0
  %t485 = insertvalue { i64, ptr } %t484, ptr %t482, 1
  store { i64, ptr } %t485, ptr %l27, !tbaa !27
  %t487 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t489 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s0, ptr %s20, { i64, ptr } %t487, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d29, i32 0, i32 1) })
  %t490 = extractvalue { i32, i64 } %t489, 1
  %t491 = extractvalue { i32, i64 } %t489, 0
  store i32 %t491, ptr %l224
  %t492 = icmp ne i32 %t491, 0
  br i1 %t492, label %bb162, label %ok.493, !prof !99
ok.493:
  store i64 %t490, ptr %l223
  br label %bb161
bb160:
  call void @__olang_check_failed(ptr @olang_loc_fb2acf0450ba6c79_597b56b8350f036d)
  unreachable
bb161:
  %t494 = load i64, ptr %l223, !tbaa !24
  store i64 %t494, ptr %l221, !tbaa !24
  br label %bb164
bb162:
  br label %bb163
bb163:
  store i64 -1, ptr %l221, !tbaa !24
  br label %bb164
bb164:
  %t495 = load i64, ptr %l221, !tbaa !24
  store i64 %t495, ptr %l28, !tbaa !24
  %t496 = load i64, ptr %l28, !tbaa !24
  %t498 = icmp slt i64 %t496, 0
  br i1 %t498, label %bb165, label %bb166
bb165:
  store %olang.scope zeroinitializer, ptr %s22
  %t500 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t501 = load i64, ptr %l11, !tbaa !24
  %t504 = call i32 @compiler_2fruntime_2emalformed(ptr %s0, ptr %s22, { i64, ptr } %t500, i64 %t501, { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store i32 %t504, ptr %l229
  %t505 = icmp ne i32 %t504, 0
  br i1 %t505, label %bb168, label %ok.506, !prof !99
ok.506:
  br label %bb167
bb166:
  br label %bb170
bb167:
  br label %bb169
bb168:
  %t507 = load i32, ptr %l229, !tbaa !23
  %t508 = lshr i32 %t507, 16
  %t509 = and i32 %t507, 65535
  %t510 = icmp eq i32 %t508, 1
  %t511 = select i1 %t510, i32 1, i32 0
  %t512 = icmp eq i32 %t507, 0
  %t513 = shl i32 %t511, 16
  %t514 = or i32 %t513, %t509
  %t515 = select i1 %t512, i32 0, i32 %t514
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t517 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t515, 0
  store { i32, { i64, ptr } } %t517, ptr %rv
  br label %ret
bb169:
  call void @__olang_scope_close(ptr %s22)
  br label %bb170
bb170:
  %t518 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t518, ptr %l232, !tbaa !27
  %t519 = load i64, ptr %l28, !tbaa !24
  store i64 %t519, ptr %l233, !tbaa !24
  %t520 = load { i64, ptr }, ptr %l232, !tbaa !27
  %t521 = extractvalue { i64, ptr } %t520, 0
  store i64 %t521, ptr %l234, !tbaa !24
  %t522 = icmp sge i64 0, 0
  br i1 %t522, label %bb171, label %bb172
bb171:
  %t524 = load i64, ptr %l233, !tbaa !24
  %t525 = icmp sle i64 0, %t524
  br i1 %t525, label %bb173, label %bb174
bb172:
  call void @__olang_check_failed(ptr @olang_loc_4e5c01328741d84c_96bd53a062766590)
  unreachable
bb173:
  %t527 = load i64, ptr %l233, !tbaa !24
  %t528 = load i64, ptr %l234, !tbaa !24
  %t529 = icmp sle i64 %t527, %t528
  br i1 %t529, label %bb175, label %bb176
bb174:
  call void @__olang_check_failed(ptr @olang_loc_4e5c01328741d84c_96bd53a062766590)
  unreachable
bb175:
  %t531 = getelementptr { i64, ptr }, ptr %l232, i32 0, i32 1
  %t532 = load ptr, ptr %t531, !tbaa !27
  %t533 = load i64, ptr %l233, !tbaa !24
  %t534 = getelementptr i8, ptr %t532, i64 0
  %t535 = sub i64 %t533, 0
  %t536 = insertvalue { i64, ptr } undef, i64 %t535, 0
  %t537 = insertvalue { i64, ptr } %t536, ptr %t534, 1
  %t538 = load i64, ptr %l9, !tbaa !24
  %t541 = call { i32, i64 } @compiler_2fruntime_2efact(ptr %s0, { i64, ptr } %t537, i64 %t538)
  %t542 = extractvalue { i32, i64 } %t541, 1
  %t543 = extractvalue { i32, i64 } %t541, 0
  store i32 %t543, ptr %l241
  %t544 = icmp ne i32 %t543, 0
  br i1 %t544, label %bb178, label %ok.545, !prof !99
ok.545:
  store i64 %t542, ptr %l240
  br label %bb177
bb176:
  call void @__olang_check_failed(ptr @olang_loc_4e5c01328741d84c_96bd53a062766590)
  unreachable
bb177:
  %t546 = load i64, ptr %l240, !tbaa !24
  store i64 %t546, ptr %l231, !tbaa !24
  br label %bb183
bb178:
  %t547 = load i32, ptr %l241, !tbaa !23
  %t548 = ashr i32 %t547, 16
  %t550 = icmp eq i32 %t548, 1
  store i1 %t550, ptr %l243, !tbaa !21
  br label %bb179
bb179:
  store %olang.scope zeroinitializer, ptr %s23
  %t551 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t552 = load i64, ptr %l11, !tbaa !24
  %t555 = call i32 @compiler_2fruntime_2emalformed(ptr %s0, ptr %s23, { i64, ptr } %t551, i64 %t552, { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store i32 %t555, ptr %l246
  %t556 = icmp ne i32 %t555, 0
  br i1 %t556, label %bb181, label %ok.557, !prof !99
ok.557:
  br label %bb180
bb180:
  br label %bb182
bb181:
  %t558 = load i32, ptr %l246, !tbaa !23
  %t559 = lshr i32 %t558, 16
  %t560 = and i32 %t558, 65535
  %t561 = icmp eq i32 %t559, 1
  %t562 = select i1 %t561, i32 1, i32 0
  %t563 = icmp eq i32 %t558, 0
  %t564 = shl i32 %t562, 16
  %t565 = or i32 %t564, %t560
  %t566 = select i1 %t563, i32 0, i32 %t565
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t568 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t566, 0
  store { i32, { i64, ptr } } %t568, ptr %rv
  br label %ret
bb182:
  call void @__olang_check_failed(ptr @olang_loc_c5a935a141e6de44_d4317e5b19ef6ea0)
  unreachable
bb183:
  %t569 = load i64, ptr %l231, !tbaa !24
  %t572 = call i64 @__olang_fmt_i64(ptr null, i64 %t569)
  %t573 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t572)
  %t574 = call i64 @__olang_fmt_i64(ptr %t573, i64 %t569)
  %t575 = insertvalue { i64, ptr } undef, i64 %t572, 0
  %t576 = insertvalue { i64, ptr } %t575, ptr %t573, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s20, ptr %l10, { i64, ptr } %t576)
  br label %bb184
bb184:
  %t580 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t580, ptr %l252, !tbaa !27
  %t581 = load i64, ptr %l28, !tbaa !24
  %t583 = add i64 %t581, 2
  store i64 %t583, ptr %l254, !tbaa !24
  %t584 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t587 = extractvalue { i64, ptr } %t584, 0
  store i64 %t587, ptr %l257, !tbaa !24
  %t588 = load { i64, ptr }, ptr %l252, !tbaa !27
  %t589 = extractvalue { i64, ptr } %t588, 0
  store i64 %t589, ptr %l258, !tbaa !24
  %t590 = load i64, ptr %l254, !tbaa !24
  %t591 = icmp sge i64 %t590, 0
  br i1 %t591, label %bb185, label %bb186
bb185:
  %t593 = load i64, ptr %l254, !tbaa !24
  %t594 = load i64, ptr %l257, !tbaa !24
  %t595 = icmp sle i64 %t593, %t594
  br i1 %t595, label %bb187, label %bb188
bb186:
  call void @__olang_check_failed(ptr @olang_loc_6b7f8dd3ec23cfae_1ccbdaa919c4683a)
  unreachable
bb187:
  %t597 = load i64, ptr %l257, !tbaa !24
  %t598 = load i64, ptr %l258, !tbaa !24
  %t599 = icmp sle i64 %t597, %t598
  br i1 %t599, label %bb189, label %bb190
bb188:
  call void @__olang_check_failed(ptr @olang_loc_6b7f8dd3ec23cfae_1ccbdaa919c4683a)
  unreachable
bb189:
  %t601 = getelementptr { i64, ptr }, ptr %l252, i32 0, i32 1
  %t602 = load ptr, ptr %t601, !tbaa !27
  %t603 = load i64, ptr %l254, !tbaa !24
  %t604 = load i64, ptr %l257, !tbaa !24
  %t605 = getelementptr i8, ptr %t602, i64 %t603
  %t606 = sub i64 %t604, %t603
  %t607 = insertvalue { i64, ptr } undef, i64 %t606, 0
  %t608 = insertvalue { i64, ptr } %t607, ptr %t605, 1
  store { i64, ptr } %t608, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s20)
  br label %bb191
bb190:
  call void @__olang_check_failed(ptr @olang_loc_6b7f8dd3ec23cfae_1ccbdaa919c4683a)
  unreachable
bb191:
  br label %bb139
bb192:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l10, i8 10)
  br label %bb193
bb193:
  call void @__olang_scope_close(ptr %s6)
  br label %bb194
bb194:
  br label %bb21
bb195:
  %t611 = load i1, ptr %l12, !tbaa !21
  br i1 %t611, label %bb196, label %bb197
bb196:
  store %olang.scope zeroinitializer, ptr %s25
  %t613 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t614 = load i64, ptr %l15, !tbaa !24
  %t617 = call i32 @compiler_2fruntime_2emalformed(ptr %s0, ptr %s25, { i64, ptr } %t613, i64 %t614, { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d32, i32 0, i32 1) })
  store i32 %t617, ptr %l267
  %t618 = icmp ne i32 %t617, 0
  br i1 %t618, label %bb199, label %ok.619, !prof !99
ok.619:
  br label %bb198
bb197:
  br label %bb201
bb198:
  br label %bb200
bb199:
  %t620 = load i32, ptr %l267, !tbaa !23
  %t621 = lshr i32 %t620, 16
  %t622 = and i32 %t620, 65535
  %t623 = icmp eq i32 %t621, 1
  %t624 = select i1 %t623, i32 1, i32 0
  %t625 = icmp eq i32 %t620, 0
  %t626 = shl i32 %t624, 16
  %t627 = or i32 %t626, %t622
  %t628 = select i1 %t625, i32 0, i32 %t627
  call void @__olang_scope_close(ptr %s25)
  call void @__olang_scope_close(ptr %s0)
  %t630 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t628, 0
  store { i32, { i64, ptr } } %t630, ptr %rv
  br label %ret
bb200:
  call void @__olang_scope_close(ptr %s25)
  br label %bb201
bb201:
  %t632 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v3, ptr %l10)
  store { i64, ptr } %t632, ptr %l270
  br label %bb202
bb202:
  call void @__olang_scope_close(ptr %s0)
  %t633 = load { i64, ptr }, ptr %l270, !tbaa !27
  %t634 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t633, 1
  store { i32, { i64, ptr } } %t634, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fruntime_2eIr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, i1 %a4, i1 %a5, i1 %a6, i1 %a7, { i64, ptr } %a8) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i32
  %l25 = alloca i1
  %l26 = alloca i64
  %l29 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l36 = alloca i1
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l42 = alloca { i64, ptr }
  %l43 = alloca i32
  %l48 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l58 = alloca i64
  %l66 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a8, ptr %l8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call ptr @__olang_scope_hold(ptr %s0)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l11, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler__2fruntime__2eIr_2elocal_2e9
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %s0)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l11, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t12 = load i64, ptr %l11
  %t13 = inttoptr i64 %t12 to ptr
  %t19 = call { i32, { i64, ptr } } @compiler_2fruntime_2eText(ptr %v1, ptr %v3, ptr %t13, { i64, ptr } %t7, i1 %a3, i1 false, i1 %a5, i1 %a6, { i64, ptr } %t11)
  %t20 = extractvalue { i32, { i64, ptr } } %t19, 1
  %t21 = extractvalue { i32, { i64, ptr } } %t19, 0
  store i32 %t21, ptr %l19
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb4, label %ok.23, !prof !99
ok.23:
  store { i64, ptr } %t20, ptr %l18
  br label %bb3
bb3:
  %t24 = load i1, ptr @olang_2esole_2ecompiler__2fruntime__2eIr_2elocal_2e9
  br i1 %t24, label %bb5, label %bb6
bb4:
  %t26 = load i32, ptr %l19, !tbaa !23
  %t27 = lshr i32 %t26, 16
  %t28 = and i32 %t26, 65535
  %t29 = icmp eq i32 %t27, 1
  %t30 = select i1 %t29, i32 1, i32 0
  %t31 = icmp eq i32 %t26, 0
  %t32 = shl i32 %t30, 16
  %t33 = or i32 %t32, %t28
  %t34 = select i1 %t31, i32 0, i32 %t33
  call void @__olang_scope_close(ptr %s0)
  %t36 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t34, 0
  store { i32, { i64, ptr } } %t36, ptr %rv
  br label %ret
bb5:
  %t37 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  %t40 = icmp eq i64 %t38, 0
  br i1 %t40, label %bb7, label %bb8
bb6:
  %t42 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t42, ptr %l10, !tbaa !27
  br label %bb9
bb7:
  store { i64, ptr } zeroinitializer, ptr %l18, !tbaa !27
  br label %bb8
bb8:
  %t43 = load i64, ptr %l11
  %t44 = inttoptr i64 %t43 to ptr
  %t45 = load { i64, ptr }, ptr %l18
  %t46 = extractvalue { i64, ptr } %t45, 1
  %t47 = call ptr @__olang_region_or(ptr %t46, ptr null)
  %t48 = icmp ne ptr %t47, null
  %t49 = select i1 %t48, ptr %t47, ptr null
  call void @__olang_region_settle_in(ptr %t44, ptr %t49)
  br label %bb6
bb9:
  %t50 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t50, ptr %l9, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t53 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t51, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i1 %t53, ptr %l25
  br label %bb10
bb10:
  %t54 = load i1, ptr %l25, !tbaa !21
  br i1 %t54, label %bb11, label %bb12
bb11:
  %t55 = call ptr @__olang_scope_hold(ptr %s0)
  %t56 = ptrtoint ptr %t55 to i64
  store i64 %t56, ptr %l26, !tbaa !24
  %t57 = load i1, ptr @olang_2esole_2ecompiler__2fruntime__2eIr_2elocal_2e9
  br i1 %t57, label %bb13, label %bb14
bb12:
  br label %bb22
bb13:
  %t59 = call ptr @__olang_region_make(ptr %s0)
  %t60 = ptrtoint ptr %t59 to i64
  store i64 %t60, ptr %l26, !tbaa !24
  br label %bb14
bb14:
  %t61 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t62 = load i64, ptr %l26
  %t63 = inttoptr i64 %t62 to ptr
  %t65 = call { i64, ptr } @compiler_2fruntime_2eBionic(ptr %s0, ptr %t63, { i64, ptr } %t61)
  store { i64, ptr } %t65, ptr %l29
  br label %bb15
bb15:
  %t66 = load i1, ptr @olang_2esole_2ecompiler__2fruntime__2eIr_2elocal_2e9
  br i1 %t66, label %bb16, label %bb17
bb16:
  %t68 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  %t71 = icmp eq i64 %t69, 0
  br i1 %t71, label %bb18, label %bb19
bb17:
  %t73 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t73, ptr %l33, !tbaa !27
  %t74 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t74, ptr %l9, !tbaa !27
  %t75 = load i1, ptr @olang_2esole_2ecompiler__2fruntime__2eIr_2elocal_2e9
  br i1 %t75, label %bb20, label %bb21
bb18:
  store { i64, ptr } zeroinitializer, ptr %l29, !tbaa !27
  br label %bb19
bb19:
  %t77 = load i64, ptr %l26
  %t78 = inttoptr i64 %t77 to ptr
  %t79 = load { i64, ptr }, ptr %l29
  %t80 = extractvalue { i64, ptr } %t79, 1
  %t81 = call ptr @__olang_region_or(ptr %t80, ptr null)
  %t82 = icmp ne ptr %t81, null
  %t83 = select i1 %t82, ptr %t81, ptr null
  call void @__olang_region_settle_in(ptr %t78, ptr %t83)
  br label %bb17
bb20:
  %t84 = load { i64, ptr }, ptr %l33
  %t85 = extractvalue { i64, ptr } %t84, 1
  call void @__olang_region_release(ptr %t85)
  store { i64, ptr } zeroinitializer, ptr %l33
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t86 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t88 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t86, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d34, i32 0, i32 1) })
  store i1 %t88, ptr %l36
  br label %bb23
bb23:
  %t89 = load i1, ptr %l36, !tbaa !21
  br i1 %t89, label %bb24, label %bb25
bb24:
  %t90 = call ptr @__olang_scope_hold(ptr %s0)
  %t91 = ptrtoint ptr %t90 to i64
  store i64 %t91, ptr %l38, !tbaa !24
  %t92 = load i1, ptr @olang_2esole_2ecompiler__2fruntime__2eIr_2elocal_2e9
  br i1 %t92, label %bb26, label %bb27
bb25:
  br label %bb37
bb26:
  %t94 = call ptr @__olang_region_make(ptr %s0)
  %t95 = ptrtoint ptr %t94 to i64
  store i64 %t95, ptr %l38, !tbaa !24
  br label %bb27
bb27:
  %t96 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t97 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t98 = load i64, ptr %l38
  %t99 = inttoptr i64 %t98 to ptr
  %t102 = call { i32, { i64, ptr } } @compiler_2fruntime_2eWindows(ptr %s0, ptr %v1, ptr %t99, { i64, ptr } %t96, { i64, ptr } %t97)
  %t103 = extractvalue { i32, { i64, ptr } } %t102, 1
  %t104 = extractvalue { i32, { i64, ptr } } %t102, 0
  store i32 %t104, ptr %l43
  %t105 = icmp ne i32 %t104, 0
  br i1 %t105, label %bb29, label %ok.106, !prof !99
ok.106:
  store { i64, ptr } %t103, ptr %l42
  br label %bb28
bb28:
  %t107 = load i1, ptr @olang_2esole_2ecompiler__2fruntime__2eIr_2elocal_2e9
  br i1 %t107, label %bb30, label %bb31
bb29:
  %t109 = load i32, ptr %l43, !tbaa !23
  %t110 = lshr i32 %t109, 16
  %t111 = and i32 %t109, 65535
  %t112 = icmp eq i32 %t110, 1
  %t113 = select i1 %t112, i32 1, i32 0
  %t114 = icmp eq i32 %t109, 0
  %t115 = shl i32 %t113, 16
  %t116 = or i32 %t115, %t111
  %t117 = select i1 %t114, i32 0, i32 %t116
  call void @__olang_scope_close(ptr %s0)
  %t119 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t117, 0
  store { i32, { i64, ptr } } %t119, ptr %rv
  br label %ret
bb30:
  %t120 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t120, 0
  %t123 = icmp eq i64 %t121, 0
  br i1 %t123, label %bb32, label %bb33
bb31:
  %t125 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t125, ptr %l37, !tbaa !27
  br label %bb34
bb32:
  store { i64, ptr } zeroinitializer, ptr %l42, !tbaa !27
  br label %bb33
bb33:
  %t126 = load i64, ptr %l38
  %t127 = inttoptr i64 %t126 to ptr
  %t128 = load { i64, ptr }, ptr %l42
  %t129 = extractvalue { i64, ptr } %t128, 1
  %t130 = call ptr @__olang_region_or(ptr %t129, ptr null)
  %t131 = icmp ne ptr %t130, null
  %t132 = select i1 %t131, ptr %t130, ptr null
  call void @__olang_region_settle_in(ptr %t127, ptr %t132)
  br label %bb31
bb34:
  %t133 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t133, ptr %l48, !tbaa !27
  %t134 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t134, ptr %l9, !tbaa !27
  %t135 = load i1, ptr @olang_2esole_2ecompiler__2fruntime__2eIr_2elocal_2e9
  br i1 %t135, label %bb35, label %bb36
bb35:
  %t137 = load { i64, ptr }, ptr %l48
  %t138 = extractvalue { i64, ptr } %t137, 1
  call void @__olang_region_release(ptr %t138)
  store { i64, ptr } zeroinitializer, ptr %l48
  br label %bb36
bb36:
  br label %bb37
bb37:
  br i1 %a7, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s3
  %t141 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d35, i32 0, i32 1) }, ptr %l52, !tbaa !27
  store { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d36, i32 0, i32 1) }, ptr %l53, !tbaa !27
  %t143 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t144 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t145 = call { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %s3, ptr %s3, ptr %s0, { i64, ptr } %t141, { i64, ptr } %t143, { i64, ptr } %t144)
  store { i64, ptr } %t145, ptr %l54
  br label %bb40
bb39:
  br label %bb43
bb40:
  %t146 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t147 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t147, ptr %l56, !tbaa !27
  store { i64, ptr } %t146, ptr %l9, !tbaa !27
  %t149 = load i1, ptr @olang_2esole_2ecompiler__2fruntime__2eIr_2elocal_2e9
  br i1 %t149, label %bb41, label %bb42
bb41:
  %t151 = load { i64, ptr }, ptr %l56
  %t152 = extractvalue { i64, ptr } %t151, 1
  call void @__olang_region_release(ptr %t152)
  store { i64, ptr } zeroinitializer, ptr %l56
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s3)
  br label %bb43
bb43:
  %t153 = call ptr @__olang_scope_hold(ptr %s0)
  %t154 = ptrtoint ptr %t153 to i64
  store i64 %t154, ptr %l58, !tbaa !24
  %t155 = load i1, ptr @olang_2esole_2estd_2fprelude_2ftext_3aLineIter_2e0
  br i1 %t155, label %bb44, label %bb45
bb44:
  %t157 = call ptr @__olang_region_make(ptr %s0)
  %t158 = ptrtoint ptr %t157 to i64
  store i64 %t158, ptr %l58, !tbaa !24
  br label %bb45
bb45:
  %t160 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t161 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t162 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t164 = extractvalue { i64, ptr } %a0, 1
  %t165 = extractvalue { i64, ptr } %a0, 0
  %t166 = add i64 %t162, %t165
  %t167 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t168 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t169 = add i64 %t166, %t168
  %t171 = extractvalue { i64, ptr } %t160, 1
  %t172 = extractvalue { i64, ptr } %t160, 0
  %t173 = add i64 %t169, %t172
  %t174 = load i64, ptr %l58
  %t175 = inttoptr i64 %t174 to ptr
  %t176 = call ptr @__olang_held_alloc(ptr %t175, i64 %t173)
  call void @olang_textcopy(ptr %t176, ptr %t161, i64 %t162)
  %t177 = getelementptr i8, ptr %t176, i64 %t162
  call void @olang_textcopy(ptr %t177, ptr %t164, i64 %t165)
  %t178 = getelementptr i8, ptr %t177, i64 %t165
  call void @olang_textcopy(ptr %t178, ptr %t167, i64 %t168)
  %t179 = getelementptr i8, ptr %t178, i64 %t168
  call void @olang_textcopy(ptr %t179, ptr %t171, i64 %t172)
  %t180 = insertvalue { i64, ptr } undef, i64 %t173, 0
  %t181 = insertvalue { i64, ptr } %t180, ptr %t176, 1
  %t188 = call { i64, ptr } @compiler_2fruntime_2eWithAttributes(ptr %s0, ptr %v2, ptr %v4, { i64, ptr } %t181, { i64, ptr } %a2, i1 %a4)
  store { i64, ptr } %t188, ptr %l66
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s0)
  %t189 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t190 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t189, 1
  store { i32, { i64, ptr } } %t190, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fruntime_2eText(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i1 %a1, i1 %a2, i1 %a3, i1 %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i1
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca i32
  %l32 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i32
  %l44 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l51 = alloca i64
  %l53 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l61 = alloca i32
  %l63 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store { i64, ptr } %a0, ptr %l0
  store i1 %a1, ptr %l1
  store i1 %a3, ptr %l3
  store i1 %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  br i1 %a2, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = load i1, ptr %l1, !tbaa !21
  %t5 = load i1, ptr %l3, !tbaa !21
  %t6 = load i1, ptr %l4, !tbaa !21
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t13 = call { i32, { i64, ptr } } @compiler_2fruntime_2eFill(ptr %s1, ptr %v0, ptr %v1, ptr %v2, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d39, i32 0, i32 1) }, { i64, ptr } %t3, i1 %t4, i1 %t5, i1 %t6, { i64, ptr } %t7)
  %t14 = extractvalue { i32, { i64, ptr } } %t13, 1
  %t15 = extractvalue { i32, { i64, ptr } } %t13, 0
  store i32 %t15, ptr %l15
  %t16 = icmp ne i32 %t15, 0
  br i1 %t16, label %bb4, label %ok.17, !prof !99
ok.17:
  store { i64, ptr } %t14, ptr %l14
  br label %bb3
bb2:
  br label %bb6
bb3:
  %t18 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t18, ptr %l8, !tbaa !27
  br label %bb5
bb4:
  %t19 = load i32, ptr %l15, !tbaa !23
  %t20 = lshr i32 %t19, 16
  %t21 = and i32 %t19, 65535
  %t22 = icmp eq i32 %t20, 1
  %t23 = select i1 %t22, i32 1, i32 0
  %t24 = icmp eq i32 %t19, 0
  %t25 = shl i32 %t23, 16
  %t26 = or i32 %t25, %t21
  %t27 = select i1 %t24, i32 0, i32 %t26
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t29 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t27, 0
  store { i32, { i64, ptr } } %t29, ptr %rv
  br label %ret
bb5:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t30 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t31 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t30, 1
  store { i32, { i64, ptr } } %t31, ptr %rv
  br label %ret
bb6:
  %t32 = call ptr @__olang_scope_hold(ptr %v2)
  %t33 = ptrtoint ptr %t32 to i64
  store i64 %t33, ptr %l18, !tbaa !24
  %t34 = load i1, ptr @olang_2esole_2ecompiler__2fruntime__2eText_2elocal_2e6
  br i1 %t34, label %bb7, label %bb8
bb7:
  %t36 = call ptr @__olang_region_make(ptr %v2)
  %t37 = ptrtoint ptr %t36 to i64
  store i64 %t37, ptr %l18, !tbaa !24
  br label %bb8
bb8:
  %t38 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t39 = load i1, ptr %l1, !tbaa !21
  %t40 = load i1, ptr %l3, !tbaa !21
  %t41 = load i1, ptr %l4, !tbaa !21
  %t42 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t43 = load i64, ptr %l18
  %t44 = inttoptr i64 %t43 to ptr
  %t50 = call { i32, { i64, ptr } } @compiler_2fruntime_2eFill(ptr %s0, ptr %v0, ptr %v1, ptr %t44, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d40, i32 0, i32 1) }, { i64, ptr } %t38, i1 %t39, i1 %t40, i1 %t41, { i64, ptr } %t42)
  %t51 = extractvalue { i32, { i64, ptr } } %t50, 1
  %t52 = extractvalue { i32, { i64, ptr } } %t50, 0
  store i32 %t52, ptr %l26
  %t53 = icmp ne i32 %t52, 0
  br i1 %t53, label %bb10, label %ok.54, !prof !99
ok.54:
  store { i64, ptr } %t51, ptr %l25
  br label %bb9
bb9:
  %t55 = load i1, ptr @olang_2esole_2ecompiler__2fruntime__2eText_2elocal_2e6
  br i1 %t55, label %bb11, label %bb12
bb10:
  %t57 = load i32, ptr %l26, !tbaa !23
  %t58 = lshr i32 %t57, 16
  %t59 = and i32 %t57, 65535
  %t60 = icmp eq i32 %t58, 1
  %t61 = select i1 %t60, i32 1, i32 0
  %t62 = icmp eq i32 %t57, 0
  %t63 = shl i32 %t61, 16
  %t64 = or i32 %t63, %t59
  %t65 = select i1 %t62, i32 0, i32 %t64
  call void @__olang_scope_close(ptr %s0)
  %t67 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t65, 0
  store { i32, { i64, ptr } } %t67, ptr %rv
  br label %ret
bb11:
  %t68 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  %t71 = icmp eq i64 %t69, 0
  br i1 %t71, label %bb13, label %bb14
bb12:
  %t73 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t73, ptr %l17, !tbaa !27
  br label %bb15
bb13:
  store { i64, ptr } zeroinitializer, ptr %l25, !tbaa !27
  br label %bb14
bb14:
  %t74 = load i64, ptr %l18
  %t75 = inttoptr i64 %t74 to ptr
  %t76 = load { i64, ptr }, ptr %l25
  %t77 = extractvalue { i64, ptr } %t76, 1
  %t78 = call ptr @__olang_region_or(ptr %t77, ptr null)
  %t79 = icmp ne ptr %t78, null
  %t80 = select i1 %t79, ptr %t78, ptr null
  call void @__olang_region_settle_in(ptr %t75, ptr %t80)
  br label %bb12
bb15:
  %t81 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t81, ptr %l6, !tbaa !27
  %t82 = load i1, ptr %l1, !tbaa !21
  br i1 %t82, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s2
  %t84 = call ptr @__olang_scope_hold(ptr %v2)
  %t85 = ptrtoint ptr %t84 to i64
  store i64 %t85, ptr %l32, !tbaa !24
  %t86 = load i1, ptr @olang_2esole_2ecompiler__2fruntime__2eText_2elocal_2e6
  br i1 %t86, label %bb18, label %bb19
bb17:
  br label %bb29
bb18:
  %t88 = call ptr @__olang_region_make(ptr %v2)
  %t89 = ptrtoint ptr %t88 to i64
  store i64 %t89, ptr %l32, !tbaa !24
  br label %bb19
bb19:
  %t90 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t90, ptr %l34, !tbaa !27
  %t91 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t92 = load i1, ptr %l1, !tbaa !21
  %t93 = load i1, ptr %l3, !tbaa !21
  %t94 = load i1, ptr %l4, !tbaa !21
  %t95 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t101 = call { i32, { i64, ptr } } @compiler_2fruntime_2eFill(ptr %s2, ptr %v0, ptr %v1, ptr %s2, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d41, i32 0, i32 1) }, { i64, ptr } %t91, i1 %t92, i1 %t93, i1 %t94, { i64, ptr } %t95)
  %t102 = extractvalue { i32, { i64, ptr } } %t101, 1
  %t103 = extractvalue { i32, { i64, ptr } } %t101, 0
  store i32 %t103, ptr %l42
  %t104 = icmp ne i32 %t103, 0
  br i1 %t104, label %bb21, label %ok.105, !prof !99
ok.105:
  store { i64, ptr } %t102, ptr %l41
  br label %bb20
bb20:
  %t106 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t106, ptr %l35, !tbaa !27
  br label %bb22
bb21:
  %t107 = load i32, ptr %l42, !tbaa !23
  %t108 = lshr i32 %t107, 16
  %t109 = and i32 %t107, 65535
  %t110 = icmp eq i32 %t108, 1
  %t111 = select i1 %t110, i32 1, i32 0
  %t112 = icmp eq i32 %t107, 0
  %t113 = shl i32 %t111, 16
  %t114 = or i32 %t113, %t109
  %t115 = select i1 %t112, i32 0, i32 %t114
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t117 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t115, 0
  store { i32, { i64, ptr } } %t117, ptr %rv
  br label %ret
bb22:
  %t118 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t118, 1
  %t120 = extractvalue { i64, ptr } %t118, 0
  %t121 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t122 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t123 = add i64 %t120, %t122
  %t124 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t124, 1
  %t126 = extractvalue { i64, ptr } %t124, 0
  %t127 = add i64 %t123, %t126
  %t128 = load i64, ptr %l32
  %t129 = inttoptr i64 %t128 to ptr
  %t130 = call ptr @__olang_held_alloc(ptr %t129, i64 %t127)
  call void @olang_textcopy(ptr %t130, ptr %t119, i64 %t120)
  %t131 = getelementptr i8, ptr %t130, i64 %t120
  call void @olang_textcopy(ptr %t131, ptr %t121, i64 %t122)
  %t132 = getelementptr i8, ptr %t131, i64 %t122
  call void @olang_textcopy(ptr %t132, ptr %t125, i64 %t126)
  %t133 = insertvalue { i64, ptr } undef, i64 %t127, 0
  %t134 = insertvalue { i64, ptr } %t133, ptr %t130, 1
  store { i64, ptr } %t134, ptr %l44, !tbaa !27
  %t135 = load i1, ptr @olang_2esole_2ecompiler__2fruntime__2eText_2elocal_2e6
  br i1 %t135, label %bb23, label %bb24
bb23:
  %t137 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 0
  %t140 = icmp eq i64 %t138, 0
  br i1 %t140, label %bb25, label %bb26
bb24:
  %t142 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t142, ptr %l48, !tbaa !27
  %t143 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t143, ptr %l6, !tbaa !27
  %t144 = load i1, ptr @olang_2esole_2ecompiler__2fruntime__2eText_2elocal_2e6
  br i1 %t144, label %bb27, label %bb28
bb25:
  store { i64, ptr } zeroinitializer, ptr %l44, !tbaa !27
  br label %bb26
bb26:
  %t146 = load i64, ptr %l32
  %t147 = inttoptr i64 %t146 to ptr
  %t148 = load { i64, ptr }, ptr %l44
  %t149 = extractvalue { i64, ptr } %t148, 1
  %t150 = call ptr @__olang_region_or(ptr %t149, ptr null)
  %t151 = icmp ne ptr %t150, null
  %t152 = select i1 %t151, ptr %t150, ptr null
  call void @__olang_region_settle_in(ptr %t147, ptr %t152)
  br label %bb24
bb27:
  %t153 = load { i64, ptr }, ptr %l48
  %t154 = extractvalue { i64, ptr } %t153, 1
  call void @__olang_region_release(ptr %t154)
  store { i64, ptr } zeroinitializer, ptr %l48
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb29:
  %t155 = load i1, ptr %l3, !tbaa !21
  br i1 %t155, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s4
  %t157 = call ptr @__olang_scope_hold(ptr %v2)
  %t158 = ptrtoint ptr %t157 to i64
  store i64 %t158, ptr %l51, !tbaa !24
  %t159 = load i1, ptr @olang_2esole_2ecompiler__2fruntime__2eText_2elocal_2e6
  br i1 %t159, label %bb32, label %bb33
bb31:
  br label %bb43
bb32:
  %t161 = call ptr @__olang_region_make(ptr %v2)
  %t162 = ptrtoint ptr %t161 to i64
  store i64 %t162, ptr %l51, !tbaa !24
  br label %bb33
bb33:
  %t163 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t163, ptr %l53, !tbaa !27
  %t164 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t165 = load i1, ptr %l1, !tbaa !21
  %t166 = load i1, ptr %l3, !tbaa !21
  %t167 = load i1, ptr %l4, !tbaa !21
  %t168 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t174 = call { i32, { i64, ptr } } @compiler_2fruntime_2eFill(ptr %s4, ptr %v0, ptr %v1, ptr %s4, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d43, i32 0, i32 1) }, { i64, ptr } %t164, i1 %t165, i1 %t166, i1 %t167, { i64, ptr } %t168)
  %t175 = extractvalue { i32, { i64, ptr } } %t174, 1
  %t176 = extractvalue { i32, { i64, ptr } } %t174, 0
  store i32 %t176, ptr %l61
  %t177 = icmp ne i32 %t176, 0
  br i1 %t177, label %bb35, label %ok.178, !prof !99
ok.178:
  store { i64, ptr } %t175, ptr %l60
  br label %bb34
bb34:
  %t179 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t179, ptr %l54, !tbaa !27
  br label %bb36
bb35:
  %t180 = load i32, ptr %l61, !tbaa !23
  %t181 = lshr i32 %t180, 16
  %t182 = and i32 %t180, 65535
  %t183 = icmp eq i32 %t181, 1
  %t184 = select i1 %t183, i32 1, i32 0
  %t185 = icmp eq i32 %t180, 0
  %t186 = shl i32 %t184, 16
  %t187 = or i32 %t186, %t182
  %t188 = select i1 %t185, i32 0, i32 %t187
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t190 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t188, 0
  store { i32, { i64, ptr } } %t190, ptr %rv
  br label %ret
bb36:
  %t191 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t191, 1
  %t193 = extractvalue { i64, ptr } %t191, 0
  %t194 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t195 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t196 = add i64 %t193, %t195
  %t197 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t197, 1
  %t199 = extractvalue { i64, ptr } %t197, 0
  %t200 = add i64 %t196, %t199
  %t201 = load i64, ptr %l51
  %t202 = inttoptr i64 %t201 to ptr
  %t203 = call ptr @__olang_held_alloc(ptr %t202, i64 %t200)
  call void @olang_textcopy(ptr %t203, ptr %t192, i64 %t193)
  %t204 = getelementptr i8, ptr %t203, i64 %t193
  call void @olang_textcopy(ptr %t204, ptr %t194, i64 %t195)
  %t205 = getelementptr i8, ptr %t204, i64 %t195
  call void @olang_textcopy(ptr %t205, ptr %t198, i64 %t199)
  %t206 = insertvalue { i64, ptr } undef, i64 %t200, 0
  %t207 = insertvalue { i64, ptr } %t206, ptr %t203, 1
  store { i64, ptr } %t207, ptr %l63, !tbaa !27
  %t208 = load i1, ptr @olang_2esole_2ecompiler__2fruntime__2eText_2elocal_2e6
  br i1 %t208, label %bb37, label %bb38
bb37:
  %t210 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t210, 0
  %t213 = icmp eq i64 %t211, 0
  br i1 %t213, label %bb39, label %bb40
bb38:
  %t215 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t215, ptr %l67, !tbaa !27
  %t216 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t216, ptr %l6, !tbaa !27
  %t217 = load i1, ptr @olang_2esole_2ecompiler__2fruntime__2eText_2elocal_2e6
  br i1 %t217, label %bb41, label %bb42
bb39:
  store { i64, ptr } zeroinitializer, ptr %l63, !tbaa !27
  br label %bb40
bb40:
  %t219 = load i64, ptr %l51
  %t220 = inttoptr i64 %t219 to ptr
  %t221 = load { i64, ptr }, ptr %l63
  %t222 = extractvalue { i64, ptr } %t221, 1
  %t223 = call ptr @__olang_region_or(ptr %t222, ptr null)
  %t224 = icmp ne ptr %t223, null
  %t225 = select i1 %t224, ptr %t223, ptr null
  call void @__olang_region_settle_in(ptr %t220, ptr %t225)
  br label %bb38
bb41:
  %t226 = load { i64, ptr }, ptr %l67
  %t227 = extractvalue { i64, ptr } %t226, 1
  call void @__olang_region_release(ptr %t227)
  store { i64, ptr } zeroinitializer, ptr %l67
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s4)
  br label %bb43
bb43:
  %t228 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t230 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t228, 1
  store { i32, { i64, ptr } } %t230, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fruntime_2eWindows(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l4 = alloca %"std/prelude/text:LineIter"
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca i1
  %l8 = alloca %"std/prelude/text:LineIter"
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i32
  %l22 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l24 = alloca %"std/prelude/text:LineIter"
  %l25 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i32
  %l30 = alloca i1
  %l32 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i64
  %l37 = alloca { i64, ptr }
  %l40 = alloca %"std/prelude/text:StringBuilder"
  %l42 = alloca %"std/prelude/text:LineIter"
  %l43 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i32
  %l48 = alloca i1
  %l51 = alloca i1
  %l53 = alloca i1
  %l54 = alloca i1
  %l55 = alloca ptr
  %l57 = alloca { i64, ptr }
  %l59 = alloca i1
  %l61 = alloca i1
  %l62 = alloca i1
  %l63 = alloca ptr
  %l65 = alloca { i64, ptr }
  %l67 = alloca i1
  %l71 = alloca i64
  %l74 = alloca { i64, ptr }
  %l78 = alloca [14 x { i64, ptr }]
  %l83 = alloca i64
  %l86 = alloca i64
  %l111 = alloca { i64, ptr }
  %l113 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i32, { i64, ptr } } @compiler_2fruntime_2eFill(ptr %s0, ptr %v1, ptr %s0, ptr %s0, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d45, i32 0, i32 1) }, { i64, ptr } %a1, i1 false, i1 false, i1 false, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d46, i32 0, i32 1) })
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l20
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l19
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t8, ptr %l17, !tbaa !27
  br label %bb3
bb2:
  %t9 = load i32, ptr %l20, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  call void @__olang_scope_close(ptr %s0)
  %t19 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t17, 0
  store { i32, { i64, ptr } } %t19, ptr %rv
  br label %ret
bb3:
  %t20 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t20, ptr %l2, !tbaa !27
  %t21 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t21, ptr %l22
  br label %bb4
bb4:
  %t22 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l22
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t22, ptr %l3
  %t23 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t25 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %s0, ptr %s0, { i64, ptr } %t23)
  store %"std/prelude/text:LineIter" %t25, ptr %l24
  br label %bb5
bb5:
  %t26 = load %"std/prelude/text:LineIter", ptr %l24
  store %"std/prelude/text:LineIter" %t26, ptr %l4
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t28 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %s0, ptr %s0, ptr %l4)
  %t29 = extractvalue { i32, { i64, ptr } } %t28, 1
  %t30 = extractvalue { i32, { i64, ptr } } %t28, 0
  store i32 %t30, ptr %l28
  %t31 = icmp ne i32 %t30, 0
  br i1 %t31, label %bb8, label %ok.32, !prof !99
ok.32:
  store { i64, ptr } %t29, ptr %l27
  br label %bb7
bb7:
  %t33 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t33, ptr %l25, !tbaa !27
  br label %bb10
bb8:
  %t34 = load i32, ptr %l28, !tbaa !23
  %t35 = ashr i32 %t34, 16
  %t37 = icmp eq i32 %t35, 1
  store i1 %t37, ptr %l30, !tbaa !21
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb10:
  %t38 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t38, ptr %l5, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t41 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s2, { i64, ptr } %t39, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d47, i32 0, i32 1) })
  store i1 %t41, ptr %l32
  br label %bb11
bb11:
  %t42 = load i1, ptr %l32, !tbaa !21
  br i1 %t42, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  store ptr %l3, ptr %l33, !tbaa !29
  %t43 = call ptr @__olang_scope_hold(ptr %s0)
  %t44 = ptrtoint ptr %t43 to i64
  store i64 %t44, ptr %l34, !tbaa !24
  %t45 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2e0
  br i1 %t45, label %bb14, label %bb15
bb13:
  br label %bb18
bb14:
  %t47 = call ptr @__olang_region_make(ptr %s0)
  %t48 = ptrtoint ptr %t47 to i64
  store i64 %t48, ptr %l34, !tbaa !24
  br label %bb15
bb15:
  %t49 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t51 = call { i64, ptr } @compiler_2fruntime_2esymbolOf(ptr %s0, ptr %s3, { i64, ptr } %t49)
  store { i64, ptr } %t51, ptr %l37
  br label %bb16
bb16:
  %t52 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 1
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t55 = load i64, ptr %l34
  %t56 = inttoptr i64 %t55 to ptr
  %t57 = call ptr @__olang_held_alloc(ptr %t56, i64 %t54)
  call void @olang_textcopy(ptr %t57, ptr %t53, i64 %t54)
  %t58 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  %t61 = load ptr, ptr %l33, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %s0, ptr %s0, ptr %t61, { i64, ptr } %t59, i1 true)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  br label %bb6
bb20:
  %t63 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t63, ptr %l40
  br label %bb21
bb21:
  %t64 = load %"std/prelude/text:StringBuilder", ptr %l40
  store %"std/prelude/text:StringBuilder" %t64, ptr %l6
  store i1 false, ptr %l7, !tbaa !21
  %t67 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store %"std/prelude/text:LineIter" %t67, ptr %l42
  br label %bb22
bb22:
  %t68 = load %"std/prelude/text:LineIter", ptr %l42
  store %"std/prelude/text:LineIter" %t68, ptr %l8
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  %t70 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v0, ptr %l8)
  %t71 = extractvalue { i32, { i64, ptr } } %t70, 1
  %t72 = extractvalue { i32, { i64, ptr } } %t70, 0
  store i32 %t72, ptr %l46
  %t73 = icmp ne i32 %t72, 0
  br i1 %t73, label %bb25, label %ok.74, !prof !99
ok.74:
  store { i64, ptr } %t71, ptr %l45
  br label %bb24
bb24:
  %t75 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t75, ptr %l43, !tbaa !27
  br label %bb27
bb25:
  %t76 = load i32, ptr %l46, !tbaa !23
  %t77 = ashr i32 %t76, 16
  %t79 = icmp eq i32 %t77, 1
  store i1 %t79, ptr %l48, !tbaa !21
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s6)
  br label %bb56
bb27:
  %t80 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t80, ptr %l9, !tbaa !27
  %t81 = load i1, ptr %l7, !tbaa !21
  br i1 %t81, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s7
  %t83 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t85 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s7, { i64, ptr } %t83, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d48, i32 0, i32 1) })
  store i1 %t85, ptr %l51
  br label %bb30
bb29:
  br label %bb34
bb30:
  %t86 = load i1, ptr %l51, !tbaa !21
  br i1 %t86, label %bb31, label %bb32
bb31:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb33
bb32:
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  br label %bb55
bb34:
  %t87 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t89 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s6, { i64, ptr } %t87, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d49, i32 0, i32 1) })
  store i1 %t89, ptr %l53
  br label %bb35
bb35:
  %t90 = load i1, ptr %l53, !tbaa !21
  br i1 %t90, label %bb36, label %bb37
bb36:
  store ptr %l3, ptr %l55, !tbaa !29
  %t91 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t93 = call { i64, ptr } @compiler_2fruntime_2esymbolOf(ptr %v0, ptr %s6, { i64, ptr } %t91)
  store { i64, ptr } %t93, ptr %l57
  br label %bb38
bb37:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb40
bb38:
  %t94 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t95 = load ptr, ptr %l55, !tbaa !29
  %t97 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %s0, ptr %s6, ptr %t95, { i64, ptr } %t94)
  store i1 %t97, ptr %l59
  br label %bb39
bb39:
  %t98 = load i1, ptr %l59, !tbaa !21
  store i1 %t98, ptr %l54, !tbaa !21
  br label %bb40
bb40:
  %t99 = load i1, ptr %l54, !tbaa !21
  br i1 %t99, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l7, !tbaa !21
  call void @__olang_scope_close(ptr %s6)
  br label %bb55
bb42:
  br label %bb43
bb43:
  %t100 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t102 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s6, { i64, ptr } %t100, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d50, i32 0, i32 1) })
  store i1 %t102, ptr %l61
  br label %bb44
bb44:
  %t103 = load i1, ptr %l61, !tbaa !21
  br i1 %t103, label %bb45, label %bb46
bb45:
  store ptr %l3, ptr %l63, !tbaa !29
  %t104 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t106 = call { i64, ptr } @compiler_2fruntime_2esymbolOf(ptr %v0, ptr %s6, { i64, ptr } %t104)
  store { i64, ptr } %t106, ptr %l65
  br label %bb47
bb46:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb49
bb47:
  %t107 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t108 = load ptr, ptr %l63, !tbaa !29
  %t110 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %s0, ptr %s6, ptr %t108, { i64, ptr } %t107)
  store i1 %t110, ptr %l67
  br label %bb48
bb48:
  %t111 = load i1, ptr %l67, !tbaa !21
  store i1 %t111, ptr %l62, !tbaa !21
  br label %bb49
bb49:
  %t112 = load i1, ptr %l62, !tbaa !21
  br i1 %t112, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s6)
  br label %bb55
bb51:
  br label %bb52
bb52:
  %t113 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %l6, { i64, ptr } %t113)
  br label %bb53
bb53:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l6, i8 10)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s6)
  br label %bb55
bb55:
  br label %bb23
bb56:
  %t117 = call ptr @__olang_scope_hold(ptr %s0)
  %t118 = ptrtoint ptr %t117 to i64
  store i64 %t118, ptr %l71, !tbaa !24
  %t119 = load i1, ptr @olang_2esole_2ecompiler__2fruntime__2eWindows_2elocal_2e10
  br i1 %t119, label %bb57, label %bb58
bb57:
  %t121 = call ptr @__olang_region_make(ptr %s0)
  %t122 = ptrtoint ptr %t121 to i64
  store i64 %t122, ptr %l71, !tbaa !24
  br label %bb58
bb58:
  %t123 = load i64, ptr %l71
  %t124 = inttoptr i64 %t123 to ptr
  %t126 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %t124, ptr %l6)
  store { i64, ptr } %t126, ptr %l74
  br label %bb59
bb59:
  %t127 = load i1, ptr @olang_2esole_2ecompiler__2fruntime__2eWindows_2elocal_2e10
  br i1 %t127, label %bb60, label %bb61
bb60:
  %t129 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t129, 0
  %t132 = icmp eq i64 %t130, 0
  br i1 %t132, label %bb62, label %bb63
bb61:
  %t134 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t134, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l78, ptr @G_2ecompiler_2fruntime_2eWinFrom, i64 224, i1 false)
  %t135 = load [14 x { i64, ptr }], ptr %l78
  store i64 14, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t137 = load i64, ptr %l12, !tbaa !24
  %t138 = load i64, ptr %l11, !tbaa !24
  %t141 = icmp sgt i64 %t137, %t138
  br i1 %t141, label %bb64, label %bb65
bb62:
  store { i64, ptr } zeroinitializer, ptr %l74, !tbaa !27
  br label %bb63
bb63:
  %t143 = load i64, ptr %l71
  %t144 = inttoptr i64 %t143 to ptr
  %t145 = load { i64, ptr }, ptr %l74
  %t146 = extractvalue { i64, ptr } %t145, 1
  %t147 = call ptr @__olang_region_or(ptr %t146, ptr null)
  %t148 = icmp ne ptr %t147, null
  %t149 = select i1 %t148, ptr %t147, ptr null
  call void @__olang_region_settle_in(ptr %t144, ptr %t149)
  br label %bb61
bb64:
  %t150 = load i64, ptr %l13, !tbaa !24
  %t152 = icmp sgt i64 %t150, 0
  br i1 %t152, label %bb66, label %bb67
bb65:
  store i64 0, ptr %l83, !tbaa !24
  br label %bb69
bb66:
  %t154 = load i64, ptr %l12, !tbaa !24
  %t155 = load i64, ptr %l11, !tbaa !24
  %t158 = sub i64 %t154, %t155
  %t159 = load i64, ptr %l13, !tbaa !24
  %t162 = add i64 %t158, %t159
  %t164 = sub i64 %t162, 1
  %t165 = load i64, ptr %l13, !tbaa !24
  %t168 = sdiv i64 %t164, %t165
  store i64 %t168, ptr %l86, !tbaa !24
  br label %bb68
bb67:
  store i64 0, ptr %l86, !tbaa !24
  br label %bb68
bb68:
  %t170 = load i64, ptr %l86, !tbaa !24
  store i64 %t170, ptr %l83, !tbaa !24
  br label %bb69
bb69:
  %t171 = load i64, ptr %l83, !tbaa !24
  store i64 %t171, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb70
bb70:
  %t172 = load i64, ptr %l15, !tbaa !24
  %t173 = load i64, ptr %l14, !tbaa !24
  %t176 = icmp slt i64 %t172, %t173
  %t178 = xor i1 %t176, true
  br i1 %t178, label %bb71, label %bb72
bb71:
  br label %bb78
bb72:
  br label %bb73
bb73:
  %t180 = load i64, ptr %l11, !tbaa !24
  %t181 = load i64, ptr %l15, !tbaa !24
  %t182 = load i64, ptr %l13, !tbaa !24
  %t185 = mul i64 %t181, %t182
  %t188 = add i64 %t180, %t185
  store i64 %t188, ptr %l16, !tbaa !24
  %t190 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t191 = load i64, ptr %l16, !tbaa !24
  %t193 = getelementptr [14 x { i64, ptr }], ptr @G_2ecompiler_2fruntime_2eWinFrom, i64 0, i64 %t191
  %t194 = load { i64, ptr }, ptr %t193, !tbaa !37
  %t196 = load i64, ptr %l16, !tbaa !24
  %t198 = getelementptr [14 x { i64, ptr }], ptr @G_2ecompiler_2fruntime_2eWinTo, i64 0, i64 %t196
  %t199 = load { i64, ptr }, ptr %t198, !tbaa !37
  %t201 = load ptr, ptr @__olang_prog_scope
  %t202 = load ptr, ptr @__olang_prog_scope
  %t206 = call { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %t201, ptr %t202, ptr %s0, { i64, ptr } %t190, { i64, ptr } %t194, { i64, ptr } %t199)
  store { i64, ptr } %t206, ptr %l111
  br label %bb74
bb74:
  %t207 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t208 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t208, ptr %l113, !tbaa !27
  store { i64, ptr } %t207, ptr %l10, !tbaa !27
  %t210 = load i1, ptr @olang_2esole_2ecompiler__2fruntime__2eWindows_2elocal_2e10
  br i1 %t210, label %bb75, label %bb76
bb75:
  %t212 = load { i64, ptr }, ptr %l113
  %t213 = extractvalue { i64, ptr } %t212, 1
  call void @__olang_region_release(ptr %t213)
  store { i64, ptr } zeroinitializer, ptr %l113
  br label %bb76
bb76:
  br label %bb77
bb77:
  %t214 = load i64, ptr %l15, !tbaa !24
  %t217 = add i64 %t214, 1
  store i64 %t217, ptr %l15, !tbaa !24
  br label %bb70
bb78:
  %t219 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t220 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t222 = extractvalue { i64, ptr } %t219, 1
  %t223 = extractvalue { i64, ptr } %t219, 0
  %t224 = extractvalue { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t225 = extractvalue { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  %t226 = add i64 %t223, %t225
  %t228 = extractvalue { i64, ptr } %t220, 1
  %t229 = extractvalue { i64, ptr } %t220, 0
  %t230 = add i64 %t226, %t229
  %t231 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t230)
  call void @olang_textcopy(ptr %t231, ptr %t222, i64 %t223)
  %t232 = getelementptr i8, ptr %t231, i64 %t223
  call void @olang_textcopy(ptr %t232, ptr %t224, i64 %t225)
  %t233 = getelementptr i8, ptr %t232, i64 %t225
  call void @olang_textcopy(ptr %t233, ptr %t228, i64 %t229)
  %t234 = insertvalue { i64, ptr } undef, i64 %t230, 0
  %t235 = insertvalue { i64, ptr } %t234, ptr %t231, 1
  call void @__olang_scope_close(ptr %s0)
  %t237 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t235, 1
  store { i32, { i64, ptr } } %t237, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i64, ptr } @compiler_2fruntime_2eWithAttributes(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca %"std/prelude/text:LineIter"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i1
  %l11 = alloca %"std/prelude/text:StringBuilder"
  %l13 = alloca %"std/prelude/text:LineIter"
  %l14 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i32
  %l19 = alloca i1
  %l21 = alloca i1
  %l22 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l28 = alloca i1
  %l29 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i32
  %l35 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l49 = alloca i1
  %l50 = alloca i1
  %l52 = alloca i1
  %l53 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i32
  %l59 = alloca i64
  %l64 = alloca { i64, ptr }
  %l65 = alloca i64
  %l66 = alloca i64
  %l73 = alloca { i64, ptr }
  %l74 = alloca i1
  %l75 = alloca i1
  %l78 = alloca { i64, ptr }
  %l79 = alloca i1
  %l80 = alloca i1
  %l83 = alloca { i64, ptr }
  %l84 = alloca i1
  %l89 = alloca ptr
  %l91 = alloca { i64, ptr }
  %l92 = alloca ptr
  %l93 = alloca { i64, ptr }
  %l94 = alloca i64
  %l97 = alloca i64
  %l98 = alloca i64
  %l103 = alloca ptr
  %l105 = alloca { i64, ptr }
  %l110 = alloca ptr
  %l112 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l11
  store %"std/prelude/text:StringBuilder" %t2, ptr %l3
  %t5 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store %"std/prelude/text:LineIter" %t5, ptr %l13
  br label %bb2
bb2:
  %t6 = load %"std/prelude/text:LineIter", ptr %l13
  store %"std/prelude/text:LineIter" %t6, ptr %l4
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v0, ptr %l4)
  %t9 = extractvalue { i32, { i64, ptr } } %t8, 1
  %t10 = extractvalue { i32, { i64, ptr } } %t8, 0
  store i32 %t10, ptr %l17
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb5, label %ok.12, !prof !99
ok.12:
  store { i64, ptr } %t9, ptr %l16
  br label %bb4
bb4:
  %t13 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t13, ptr %l14, !tbaa !27
  br label %bb7
bb5:
  %t14 = load i32, ptr %l17, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  store i1 %t17, ptr %l19, !tbaa !21
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb88
bb7:
  %t18 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t18, ptr %l5, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t21 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t19, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) })
  store i1 %t21, ptr %l21
  br label %bb8
bb8:
  %t22 = load i1, ptr %l21, !tbaa !21
  br i1 %t22, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t23 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t25 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s3, { i64, ptr } %t23, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d53, i32 0, i32 1) })
  %t26 = extractvalue { i32, i64 } %t25, 1
  %t27 = extractvalue { i32, i64 } %t25, 0
  store i32 %t27, ptr %l25
  %t28 = icmp ne i32 %t27, 0
  br i1 %t28, label %bb12, label %ok.29, !prof !99
ok.29:
  store i64 %t26, ptr %l24
  br label %bb11
bb10:
  br label %bb34
bb11:
  %t30 = load i64, ptr %l24, !tbaa !24
  store i64 %t30, ptr %l22, !tbaa !24
  br label %bb14
bb12:
  br label %bb13
bb13:
  store i64 -1, ptr %l22, !tbaa !24
  br label %bb14
bb14:
  %t31 = load i64, ptr %l22, !tbaa !24
  store i64 %t31, ptr %l6, !tbaa !24
  %t32 = load i64, ptr %l6, !tbaa !24
  %t34 = icmp sgt i64 %t32, 0
  br i1 %t34, label %bb15, label %bb16
bb15:
  %t36 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t38 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s3, { i64, ptr } %t36, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d54, i32 0, i32 1) })
  %t39 = extractvalue { i32, i64 } %t38, 1
  %t40 = extractvalue { i32, i64 } %t38, 0
  store i32 %t40, ptr %l32
  %t41 = icmp ne i32 %t40, 0
  br i1 %t41, label %bb18, label %ok.42, !prof !99
ok.42:
  store i64 %t39, ptr %l31
  br label %bb17
bb16:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb21
bb17:
  %t43 = load i64, ptr %l31, !tbaa !24
  store i64 %t43, ptr %l29, !tbaa !24
  br label %bb20
bb18:
  br label %bb19
bb19:
  store i64 -1, ptr %l29, !tbaa !24
  br label %bb20
bb20:
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l29, !tbaa !24
  %t47 = icmp eq i64 %t45, %t44
  store i1 %t47, ptr %l28, !tbaa !21
  br label %bb21
bb21:
  %t49 = load i1, ptr %l28, !tbaa !21
  br i1 %t49, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %l3, ptr %l35, !tbaa !29
  %t50 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t50, ptr %l36, !tbaa !27
  %t51 = load i64, ptr %l6, !tbaa !24
  store i64 %t51, ptr %l37, !tbaa !24
  %t52 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 0
  store i64 %t53, ptr %l38, !tbaa !24
  %t54 = icmp sge i64 1, 0
  br i1 %t54, label %bb24, label %bb25
bb23:
  br label %bb33
bb24:
  %t56 = load i64, ptr %l37, !tbaa !24
  %t57 = icmp sle i64 1, %t56
  br i1 %t57, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_48912347760bc49b_7f197caf3eb31ff7)
  unreachable
bb26:
  %t59 = load i64, ptr %l37, !tbaa !24
  %t60 = load i64, ptr %l38, !tbaa !24
  %t61 = icmp sle i64 %t59, %t60
  br i1 %t61, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_48912347760bc49b_7f197caf3eb31ff7)
  unreachable
bb28:
  %t63 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = load i64, ptr %l37, !tbaa !24
  %t66 = getelementptr i8, ptr %t64, i64 1
  %t67 = sub i64 %t65, 1
  %t68 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t66, 1
  %t70 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t71 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  %t73 = extractvalue { i64, ptr } %t69, 1
  %t74 = extractvalue { i64, ptr } %t69, 0
  %t75 = add i64 %t71, %t74
  %t76 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t77 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t78 = add i64 %t75, %t77
  %t79 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t78)
  call void @olang_textcopy(ptr %t79, ptr %t70, i64 %t71)
  %t80 = getelementptr i8, ptr %t79, i64 %t71
  call void @olang_textcopy(ptr %t80, ptr %t73, i64 %t74)
  %t81 = getelementptr i8, ptr %t80, i64 %t74
  call void @olang_textcopy(ptr %t81, ptr %t76, i64 %t77)
  %t82 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t79, 1
  %t85 = load ptr, ptr %l35, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t85, { i64, ptr } %t83)
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_48912347760bc49b_7f197caf3eb31ff7)
  unreachable
bb30:
  %t87 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %l3, { i64, ptr } %t87)
  br label %bb31
bb31:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l3, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d57, i32 0, i32 1) })
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %bb87
bb33:
  call void @__olang_scope_close(ptr %s3)
  br label %bb34
bb34:
  %t91 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t93 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t91, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d58, i32 0, i32 1) })
  store i1 %t93, ptr %l49
  br label %bb35
bb35:
  %t94 = load i1, ptr %l49, !tbaa !21
  br i1 %t94, label %bb36, label %bb37
bb36:
  %t95 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t97 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s2, { i64, ptr } %t95, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) })
  store i1 %t97, ptr %l52
  br label %bb38
bb37:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb39
bb38:
  %t98 = load i1, ptr %l52, !tbaa !21
  store i1 %t98, ptr %l50, !tbaa !21
  br label %bb39
bb39:
  %t99 = load i1, ptr %l50, !tbaa !21
  br i1 %t99, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s6
  %t100 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t102 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s6, { i64, ptr } %t100, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d60, i32 0, i32 1) })
  %t103 = extractvalue { i32, i64 } %t102, 1
  %t104 = extractvalue { i32, i64 } %t102, 0
  store i32 %t104, ptr %l56
  %t105 = icmp ne i32 %t104, 0
  br i1 %t105, label %bb43, label %ok.106, !prof !99
ok.106:
  store i64 %t103, ptr %l55
  br label %bb42
bb41:
  br label %bb84
bb42:
  %t107 = load i64, ptr %l55, !tbaa !24
  store i64 %t107, ptr %l53, !tbaa !24
  br label %bb45
bb43:
  br label %bb44
bb44:
  store i64 -1, ptr %l53, !tbaa !24
  br label %bb45
bb45:
  %t108 = load i64, ptr %l53, !tbaa !24
  store i64 %t108, ptr %l7, !tbaa !24
  %t109 = load i64, ptr %l7, !tbaa !24
  %t111 = icmp sge i64 %t109, 0
  br i1 %t111, label %bb46, label %bb47
bb46:
  %t113 = load i64, ptr %l7, !tbaa !24
  store i64 %t113, ptr %l59, !tbaa !24
  br label %bb48
bb47:
  %t115 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t115, 0
  %t119 = sub i64 %t117, 1
  store i64 %t119, ptr %l59, !tbaa !24
  br label %bb48
bb48:
  %t121 = load i64, ptr %l59, !tbaa !24
  %t122 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t122, ptr %l64, !tbaa !27
  store i64 %t121, ptr %l65, !tbaa !24
  %t124 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t124, 0
  store i64 %t125, ptr %l66, !tbaa !24
  %t126 = icmp sge i64 0, 0
  br i1 %t126, label %bb49, label %bb50
bb49:
  %t128 = load i64, ptr %l65, !tbaa !24
  %t129 = icmp sle i64 0, %t128
  br i1 %t129, label %bb51, label %bb52
bb50:
  call void @__olang_check_failed(ptr @olang_loc_606763d33345b49e_888ff486d8884e9a)
  unreachable
bb51:
  %t131 = load i64, ptr %l65, !tbaa !24
  %t132 = load i64, ptr %l66, !tbaa !24
  %t133 = icmp sle i64 %t131, %t132
  br i1 %t133, label %bb53, label %bb54
bb52:
  call void @__olang_check_failed(ptr @olang_loc_606763d33345b49e_888ff486d8884e9a)
  unreachable
bb53:
  %t135 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !27
  %t137 = load i64, ptr %l65, !tbaa !24
  %t138 = getelementptr i8, ptr %t136, i64 0
  %t139 = sub i64 %t137, 0
  %t140 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t138, 1
  store { i64, ptr } %t141, ptr %l9, !tbaa !27
  %t143 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d61, i32 0, i32 1) }, ptr %l73, !tbaa !27
  %t146 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t147 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s6, { i64, ptr } %t143, { i64, ptr } %t146)
  store i1 %t147, ptr %l74
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_606763d33345b49e_888ff486d8884e9a)
  unreachable
bb55:
  %t148 = load i1, ptr %l74, !tbaa !21
  br i1 %t148, label %bb56, label %bb57
bb56:
  store i1 true, ptr %l75, !tbaa !21
  br label %bb59
bb57:
  %t149 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d62, i32 0, i32 1) }, ptr %l78, !tbaa !27
  %t152 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t153 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s6, { i64, ptr } %t149, { i64, ptr } %t152)
  store i1 %t153, ptr %l79
  br label %bb58
bb58:
  %t154 = load i1, ptr %l79, !tbaa !21
  store i1 %t154, ptr %l75, !tbaa !21
  br label %bb59
bb59:
  %t155 = load i1, ptr %l75, !tbaa !21
  br i1 %t155, label %bb60, label %bb61
bb60:
  store i1 true, ptr %l80, !tbaa !21
  br label %bb63
bb61:
  %t156 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d63, i32 0, i32 1) }, ptr %l83, !tbaa !27
  %t159 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t160 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s6, { i64, ptr } %t156, { i64, ptr } %t159)
  store i1 %t160, ptr %l84
  br label %bb62
bb62:
  %t161 = load i1, ptr %l84, !tbaa !21
  store i1 %t161, ptr %l80, !tbaa !21
  br label %bb63
bb63:
  %t162 = load i1, ptr %l80, !tbaa !21
  store i1 %t162, ptr %l10, !tbaa !21
  %t163 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %l3, { i64, ptr } %t163)
  br label %bb64
bb64:
  %t166 = load i64, ptr %l7, !tbaa !24
  %t168 = icmp sge i64 %t166, 0
  br i1 %t168, label %bb65, label %bb66
bb65:
  store %olang.scope zeroinitializer, ptr %s7
  store ptr %l3, ptr %l89, !tbaa !29
  %t170 = load i1, ptr %l10, !tbaa !21
  br i1 %t170, label %bb67, label %bb68
bb66:
  store %olang.scope zeroinitializer, ptr %s8
  store ptr %l3, ptr %l103, !tbaa !29
  %t172 = load i1, ptr %l10, !tbaa !21
  br i1 %t172, label %bb78, label %bb79
bb67:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d64, i32 0, i32 1) }, ptr %l91, !tbaa !27
  br label %bb69
bb68:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d65, i32 0, i32 1) }, ptr %l91, !tbaa !27
  br label %bb69
bb69:
  %t174 = load ptr, ptr %l89, !tbaa !29
  %t175 = load { i64, ptr }, ptr %l91, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %t174, { i64, ptr } %t175)
  br label %bb70
bb70:
  store ptr %l3, ptr %l92, !tbaa !29
  %t176 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t176, ptr %l93, !tbaa !27
  %t177 = load i64, ptr %l7, !tbaa !24
  store i64 %t177, ptr %l94, !tbaa !24
  %t178 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t178, 0
  store i64 %t181, ptr %l97, !tbaa !24
  %t182 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t182, 0
  store i64 %t183, ptr %l98, !tbaa !24
  %t184 = load i64, ptr %l94, !tbaa !24
  %t185 = icmp sge i64 %t184, 0
  br i1 %t185, label %bb71, label %bb72
bb71:
  %t187 = load i64, ptr %l94, !tbaa !24
  %t188 = load i64, ptr %l97, !tbaa !24
  %t189 = icmp sle i64 %t187, %t188
  br i1 %t189, label %bb73, label %bb74
bb72:
  call void @__olang_check_failed(ptr @olang_loc_dc19f5cc01bc83fd_c395ac342fa7af39)
  unreachable
bb73:
  %t191 = load i64, ptr %l97, !tbaa !24
  %t192 = load i64, ptr %l98, !tbaa !24
  %t193 = icmp sle i64 %t191, %t192
  br i1 %t193, label %bb75, label %bb76
bb74:
  call void @__olang_check_failed(ptr @olang_loc_dc19f5cc01bc83fd_c395ac342fa7af39)
  unreachable
bb75:
  %t195 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = load i64, ptr %l94, !tbaa !24
  %t198 = load i64, ptr %l97, !tbaa !24
  %t199 = getelementptr i8, ptr %t196, i64 %t197
  %t200 = sub i64 %t198, %t197
  %t201 = insertvalue { i64, ptr } undef, i64 %t200, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t199, 1
  %t203 = load ptr, ptr %l92, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t203, { i64, ptr } %t202)
  br label %bb77
bb76:
  call void @__olang_check_failed(ptr @olang_loc_dc19f5cc01bc83fd_c395ac342fa7af39)
  unreachable
bb77:
  call void @__olang_scope_close(ptr %s7)
  br label %bb82
bb78:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d66, i32 0, i32 1) }, ptr %l105, !tbaa !27
  br label %bb80
bb79:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d67, i32 0, i32 1) }, ptr %l105, !tbaa !27
  br label %bb80
bb80:
  %t205 = load ptr, ptr %l103, !tbaa !29
  %t206 = load { i64, ptr }, ptr %l105, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s8, ptr %t205, { i64, ptr } %t206)
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s8)
  br label %bb82
bb82:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l3, i8 10)
  br label %bb83
bb83:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s2)
  br label %bb87
bb84:
  %t208 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %l3, { i64, ptr } %t208)
  br label %bb85
bb85:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l3, i8 10)
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s2)
  br label %bb87
bb87:
  br label %bb3
bb88:
  store ptr %l3, ptr %l110, !tbaa !29
  br i1 %a2, label %bb89, label %bb90
bb89:
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d68, i32 0, i32 1) }, ptr %l112, !tbaa !27
  br label %bb91
bb90:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d69, i32 0, i32 1) }, ptr %l112, !tbaa !27
  br label %bb91
bb91:
  %t214 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t215 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t216 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t217 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t218 = extractvalue { i64, ptr } %t217, 1
  %t219 = extractvalue { i64, ptr } %t217, 0
  %t220 = add i64 %t216, %t219
  %t222 = extractvalue { i64, ptr } %t214, 1
  %t223 = extractvalue { i64, ptr } %t214, 0
  %t224 = add i64 %t220, %t223
  %t225 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d71, i32 0, i32 1) }, 1
  %t226 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d71, i32 0, i32 1) }, 0
  %t227 = add i64 %t224, %t226
  %t228 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t227)
  call void @olang_textcopy(ptr %t228, ptr %t215, i64 %t216)
  %t229 = getelementptr i8, ptr %t228, i64 %t216
  call void @olang_textcopy(ptr %t229, ptr %t218, i64 %t219)
  %t230 = getelementptr i8, ptr %t229, i64 %t219
  call void @olang_textcopy(ptr %t230, ptr %t222, i64 %t223)
  %t231 = getelementptr i8, ptr %t230, i64 %t223
  call void @olang_textcopy(ptr %t231, ptr %t225, i64 %t226)
  %t232 = insertvalue { i64, ptr } undef, i64 %t227, 0
  %t233 = insertvalue { i64, ptr } %t232, ptr %t228, 1
  %t235 = load ptr, ptr %l110, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t235, { i64, ptr } %t233)
  br label %bb92
bb92:
  %t237 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t238 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t239 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  %t241 = extractvalue { i64, ptr } %t237, 1
  %t242 = extractvalue { i64, ptr } %t237, 0
  %t243 = add i64 %t239, %t242
  %t244 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t245 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  %t246 = add i64 %t243, %t245
  %t247 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t246)
  call void @olang_textcopy(ptr %t247, ptr %t238, i64 %t239)
  %t248 = getelementptr i8, ptr %t247, i64 %t239
  call void @olang_textcopy(ptr %t248, ptr %t241, i64 %t242)
  %t249 = getelementptr i8, ptr %t248, i64 %t242
  call void @olang_textcopy(ptr %t249, ptr %t244, i64 %t245)
  %t250 = insertvalue { i64, ptr } undef, i64 %t246, 0
  %t251 = insertvalue { i64, ptr } %t250, ptr %t247, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } %t251)
  br label %bb93
bb93:
  %t256 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l3)
  store { i64, ptr } %t256, ptr %l121
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s0)
  %t257 = load { i64, ptr }, ptr %l121, !tbaa !27
  store { i64, ptr } %t257, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fruntime_2earchRow(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i64
  %l36 = alloca i1
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load [2 x { i64, ptr }], ptr @G_2ecompiler_2fruntime_2eArchs
  store i64 2, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t4 = load i64, ptr %l2, !tbaa !24
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = icmp sgt i64 %t4, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t12 = icmp sgt i64 %t10, 0
  br i1 %t12, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l12, !tbaa !24
  br label %bb6
bb3:
  %t14 = load i64, ptr %l2, !tbaa !24
  %t15 = load i64, ptr %l1, !tbaa !24
  %t18 = sub i64 %t14, %t15
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = add i64 %t18, %t19
  %t24 = sub i64 %t22, 1
  %t25 = load i64, ptr %l3, !tbaa !24
  %t28 = sdiv i64 %t24, %t25
  store i64 %t28, ptr %l15, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb5
bb5:
  %t30 = load i64, ptr %l15, !tbaa !24
  store i64 %t30, ptr %l12, !tbaa !24
  br label %bb6
bb6:
  %t31 = load i64, ptr %l12, !tbaa !24
  store i64 %t31, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb7
bb7:
  %t32 = load i64, ptr %l5, !tbaa !24
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = icmp slt i64 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb8, label %bb9
bb8:
  br label %bb16
bb9:
  br label %bb10
bb10:
  %t40 = load i64, ptr %l1, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t42 = load i64, ptr %l3, !tbaa !24
  %t45 = mul i64 %t41, %t42
  %t48 = add i64 %t40, %t45
  store i64 %t48, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l6, !tbaa !24
  %t52 = getelementptr [2 x { i64, ptr }], ptr @G_2ecompiler_2fruntime_2eArchs, i64 0, i64 %t50
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !37
  %t55 = load ptr, ptr @__olang_prog_scope
  %t58 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t55, ptr %v0, { i64, ptr } %t53, { i64, ptr } %a0)
  store i1 %t58, ptr %l36
  br label %bb11
bb11:
  %t59 = load i1, ptr %l36, !tbaa !21
  br i1 %t59, label %bb12, label %bb13
bb12:
  %t60 = load i64, ptr %l6, !tbaa !24
  store i64 %t60, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t62 = load i64, ptr %l5, !tbaa !24
  %t65 = add i64 %t62, 1
  store i64 %t65, ptr %l5, !tbaa !24
  br label %bb7
bb16:
  store i64 0, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fruntime_2edeclare(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca i64
  %l7 = alloca i8
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca i1
  %l19 = alloca i1
  %l21 = alloca i1
  %l22 = alloca i1
  %l25 = alloca { i64, ptr }
  %l26 = alloca i1
  %l27 = alloca i1
  %l29 = alloca i1
  %l30 = alloca i1
  %l33 = alloca { i64, ptr }
  %l34 = alloca i1
  %l39 = alloca i1
  %l40 = alloca i1
  %l42 = alloca i1
  %l43 = alloca i1
  %l46 = alloca { i64, ptr }
  %l47 = alloca i1
  %l48 = alloca i1
  %l51 = alloca { i64, ptr }
  %l52 = alloca i1
  %l54 = alloca i1
  %l55 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i32
  %l59 = alloca ptr
  %l60 = alloca { i64, ptr }
  %l61 = alloca i64
  %l62 = alloca i64
  %l78 = alloca { i64, ptr }
  %l83 = alloca i1
  %l86 = alloca i1
  %l89 = alloca i1
  %l97 = alloca i1
  %l100 = alloca i1
  %l108 = alloca i1
  %l116 = alloca i1
  %l119 = alloca i1
  %l122 = alloca { i64, ptr }
  %l123 = alloca i64
  %l124 = alloca i64
  %l125 = alloca i64
  %l130 = alloca { i64, ptr }
  %l131 = alloca i64
  %l133 = alloca i64
  %l134 = alloca i32
  %l137 = alloca i1
  %l138 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %l144 = alloca i64
  %l145 = alloca i64
  %l150 = alloca { i64, ptr }
  %l158 = alloca { i64, ptr }
  %l167 = alloca { i64, ptr }
  %l169 = alloca i64
  %l172 = alloca i64
  %l173 = alloca i64
  %l178 = alloca i64
  %l180 = alloca i64
  %l181 = alloca i32
  %l184 = alloca ptr
  %l185 = alloca { i64, ptr }
  %l186 = alloca i64
  %l187 = alloca i64
  %l192 = alloca { i64, ptr }
  %l196 = alloca i1
  %l197 = alloca i64
  %l199 = alloca i64
  %l200 = alloca i32
  %l201 = alloca ptr
  %l202 = alloca { i64, ptr }
  %l203 = alloca i64
  %l204 = alloca i64
  %l211 = alloca { i64, ptr }
  %l213 = alloca i64
  %l216 = alloca i64
  %l217 = alloca i64
  %l223 = alloca i1
  %l224 = alloca i64
  %l226 = alloca i64
  %l227 = alloca i32
  %l228 = alloca ptr
  %l229 = alloca { i64, ptr }
  %l231 = alloca i64
  %l232 = alloca i64
  %l239 = alloca { i64, ptr }
  %l241 = alloca i64
  %l244 = alloca i64
  %l245 = alloca i64
  %l251 = alloca i1
  %l252 = alloca { i64, ptr }
  %l255 = alloca i64
  %l256 = alloca i64
  %l261 = alloca i64
  %l263 = alloca i64
  %l264 = alloca i32
  %l272 = alloca i64
  %l276 = alloca i64
  %l279 = alloca ptr
  %l280 = alloca { i64, ptr }
  %l282 = alloca i64
  %l283 = alloca i64
  %l287 = alloca { i64, ptr }
  %l288 = alloca { i64, ptr }
  %l290 = alloca i64
  %l291 = alloca i64
  %l292 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s22 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d74, i32 0, i32 1) })
  store i1 %t3, ptr %l18
  br label %bb1
bb1:
  %t4 = load i1, ptr %l18, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb9
bb3:
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d75, i32 0, i32 1) })
  store i1 %t7, ptr %l21
  br label %bb4
bb4:
  %t8 = load i1, ptr %l21, !tbaa !21
  br i1 %t8, label %bb5, label %bb6
bb5:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d76, i32 0, i32 1) }, ptr %l25, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t13 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t9, { i64, ptr } %t12)
  store i1 %t13, ptr %l26
  br label %bb7
bb6:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb8
bb7:
  %t14 = load i1, ptr %l26, !tbaa !21
  store i1 %t14, ptr %l22, !tbaa !21
  br label %bb8
bb8:
  %t15 = load i1, ptr %l22, !tbaa !21
  store i1 %t15, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t16 = load i1, ptr %l19, !tbaa !21
  br i1 %t16, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb17
bb11:
  %t17 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t17, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d77, i32 0, i32 1) })
  store i1 %t19, ptr %l29
  br label %bb12
bb12:
  %t20 = load i1, ptr %l29, !tbaa !21
  br i1 %t20, label %bb13, label %bb14
bb13:
  %t21 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d78, i32 0, i32 1) }, ptr %l33, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t25 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t21, { i64, ptr } %t24)
  store i1 %t25, ptr %l34
  br label %bb15
bb14:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb16
bb15:
  %t26 = load i1, ptr %l34, !tbaa !21
  store i1 %t26, ptr %l30, !tbaa !21
  br label %bb16
bb16:
  %t27 = load i1, ptr %l30, !tbaa !21
  store i1 %t27, ptr %l27, !tbaa !21
  br label %bb17
bb17:
  %t28 = load i1, ptr %l27, !tbaa !21
  br i1 %t28, label %bb18, label %bb19
bb18:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %t29, { i64, ptr } %t30)
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t33 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t33, i8 10)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb22:
  %t35 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t37 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t35, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d79, i32 0, i32 1) })
  store i1 %t37, ptr %l39
  br label %bb23
bb23:
  %t38 = load i1, ptr %l39, !tbaa !21
  br i1 %t38, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb27
bb25:
  %t39 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t41 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t39, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d80, i32 0, i32 1) })
  store i1 %t41, ptr %l42
  br label %bb26
bb26:
  %t42 = load i1, ptr %l42, !tbaa !21
  store i1 %t42, ptr %l40, !tbaa !21
  br label %bb27
bb27:
  %t43 = load i1, ptr %l40, !tbaa !21
  br i1 %t43, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb31
bb29:
  %t44 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d81, i32 0, i32 1) }, ptr %l46, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t48 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t44, { i64, ptr } %t47)
  store i1 %t48, ptr %l47
  br label %bb30
bb30:
  %t49 = load i1, ptr %l47, !tbaa !21
  store i1 %t49, ptr %l43, !tbaa !21
  br label %bb31
bb31:
  %t50 = load i1, ptr %l43, !tbaa !21
  br i1 %t50, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb35
bb33:
  %t51 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d82, i32 0, i32 1) }, ptr %l51, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t55 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t51, { i64, ptr } %t54)
  store i1 %t55, ptr %l52
  br label %bb34
bb34:
  %t56 = load i1, ptr %l52, !tbaa !21
  store i1 %t56, ptr %l48, !tbaa !21
  br label %bb35
bb35:
  %t57 = load i1, ptr %l48, !tbaa !21
  br i1 %t57, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb37:
  br label %bb38
bb38:
  %t58 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t60 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t58, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d83, i32 0, i32 1) })
  store i1 %t60, ptr %l54
  br label %bb39
bb39:
  %t61 = load i1, ptr %l54, !tbaa !21
  br i1 %t61, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s3
  %t62 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t64 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s3, { i64, ptr } %t62, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d84, i32 0, i32 1) })
  %t65 = extractvalue { i32, i64 } %t64, 1
  %t66 = extractvalue { i32, i64 } %t64, 0
  store i32 %t66, ptr %l58
  %t67 = icmp ne i32 %t66, 0
  br i1 %t67, label %bb43, label %ok.68, !prof !99
ok.68:
  store i64 %t65, ptr %l57
  br label %bb42
bb41:
  br label %bb148
bb42:
  %t69 = load i64, ptr %l57, !tbaa !24
  store i64 %t69, ptr %l55, !tbaa !24
  br label %bb45
bb43:
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb45:
  %t70 = load i64, ptr %l55, !tbaa !24
  store i64 %t70, ptr %l2, !tbaa !24
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l59, !tbaa !29
  %t72 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t72, ptr %l60, !tbaa !27
  %t73 = load i64, ptr %l2, !tbaa !24
  store i64 %t73, ptr %l61, !tbaa !24
  %t74 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t74, 0
  store i64 %t75, ptr %l62, !tbaa !24
  %t76 = icmp sge i64 7, 0
  br i1 %t76, label %bb46, label %bb47
bb46:
  %t78 = load i64, ptr %l61, !tbaa !24
  %t79 = icmp sle i64 7, %t78
  br i1 %t79, label %bb48, label %bb49
bb47:
  call void @__olang_check_failed(ptr @olang_loc_ea39e132cd3efa0c_1aef6a820179ae38)
  unreachable
bb48:
  %t81 = load i64, ptr %l61, !tbaa !24
  %t82 = load i64, ptr %l62, !tbaa !24
  %t83 = icmp sle i64 %t81, %t82
  br i1 %t83, label %bb50, label %bb51
bb49:
  call void @__olang_check_failed(ptr @olang_loc_ea39e132cd3efa0c_1aef6a820179ae38)
  unreachable
bb50:
  %t85 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = load i64, ptr %l61, !tbaa !24
  %t88 = getelementptr i8, ptr %t86, i64 7
  %t89 = sub i64 %t87, 7
  %t90 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t88, 1
  %t92 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d85, i32 0, i32 1) }, 1
  %t93 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d85, i32 0, i32 1) }, 0
  %t95 = extractvalue { i64, ptr } %t91, 1
  %t96 = extractvalue { i64, ptr } %t91, 0
  %t97 = add i64 %t93, %t96
  %t98 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d86, i32 0, i32 1) }, 1
  %t99 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d86, i32 0, i32 1) }, 0
  %t100 = add i64 %t97, %t99
  %t101 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t100)
  call void @olang_textcopy(ptr %t101, ptr %t92, i64 %t93)
  %t102 = getelementptr i8, ptr %t101, i64 %t93
  call void @olang_textcopy(ptr %t102, ptr %t95, i64 %t96)
  %t103 = getelementptr i8, ptr %t102, i64 %t96
  call void @olang_textcopy(ptr %t103, ptr %t98, i64 %t99)
  %t104 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t101, 1
  %t107 = load ptr, ptr %l59, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s3, ptr %t107, { i64, ptr } %t105)
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_ea39e132cd3efa0c_1aef6a820179ae38)
  unreachable
bb52:
  store i64 0, ptr %l3, !tbaa !24
  %t109 = load i64, ptr %l2, !tbaa !24
  %t111 = add i64 %t109, 1
  store i64 %t111, ptr %l4, !tbaa !24
  store i1 true, ptr %l5, !tbaa !21
  %t113 = load i64, ptr %l2, !tbaa !24
  %t115 = add i64 %t113, 1
  store i64 %t115, ptr %l6, !tbaa !24
  br label %bb53
bb53:
  %t117 = load i64, ptr %l6, !tbaa !24
  %t118 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t118, 0
  %t123 = icmp slt i64 %t117, %t120
  %t125 = xor i1 %t123, true
  br i1 %t125, label %bb54, label %bb55
bb54:
  br label %bb129
bb55:
  br label %bb56
bb56:
  %t127 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t127, ptr %l78, !tbaa !27
  %t128 = load i64, ptr %l6, !tbaa !24
  %t130 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr i8, ptr %t131, i64 %t128
  %t133 = load i8, ptr %t132, !tbaa !32
  store i8 %t133, ptr %l7, !tbaa !22
  %t135 = load i8, ptr %l7, !tbaa !22
  %t137 = icmp eq i8 %t135, 40
  br i1 %t137, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l83, !tbaa !21
  br label %bb59
bb58:
  %t139 = load i8, ptr %l7, !tbaa !22
  %t141 = icmp eq i8 %t139, 91
  store i1 %t141, ptr %l83, !tbaa !21
  br label %bb59
bb59:
  %t143 = load i1, ptr %l83, !tbaa !21
  br i1 %t143, label %bb60, label %bb61
bb60:
  store i1 true, ptr %l86, !tbaa !21
  br label %bb62
bb61:
  %t144 = load i8, ptr %l7, !tbaa !22
  %t146 = icmp eq i8 %t144, 123
  store i1 %t146, ptr %l86, !tbaa !21
  br label %bb62
bb62:
  %t148 = load i1, ptr %l86, !tbaa !21
  br i1 %t148, label %bb63, label %bb64
bb63:
  store i1 true, ptr %l89, !tbaa !21
  br label %bb65
bb64:
  %t149 = load i8, ptr %l7, !tbaa !22
  %t151 = icmp eq i8 %t149, 60
  store i1 %t151, ptr %l89, !tbaa !21
  br label %bb65
bb65:
  %t153 = load i1, ptr %l89, !tbaa !21
  br i1 %t153, label %bb66, label %bb67
bb66:
  %t154 = load i64, ptr %l3, !tbaa !24
  %t157 = add i64 %t154, 1
  store i64 %t157, ptr %l3, !tbaa !24
  br label %bb127
bb67:
  %t159 = load i8, ptr %l7, !tbaa !22
  %t161 = icmp eq i8 %t159, 93
  br i1 %t161, label %bb68, label %bb69
bb68:
  store i1 true, ptr %l97, !tbaa !21
  br label %bb70
bb69:
  %t163 = load i8, ptr %l7, !tbaa !22
  %t165 = icmp eq i8 %t163, 125
  store i1 %t165, ptr %l97, !tbaa !21
  br label %bb70
bb70:
  %t167 = load i1, ptr %l97, !tbaa !21
  br i1 %t167, label %bb71, label %bb72
bb71:
  store i1 true, ptr %l100, !tbaa !21
  br label %bb73
bb72:
  %t168 = load i8, ptr %l7, !tbaa !22
  %t170 = icmp eq i8 %t168, 62
  store i1 %t170, ptr %l100, !tbaa !21
  br label %bb73
bb73:
  %t172 = load i1, ptr %l100, !tbaa !21
  br i1 %t172, label %bb74, label %bb75
bb74:
  %t173 = load i64, ptr %l3, !tbaa !24
  %t176 = sub i64 %t173, 1
  store i64 %t176, ptr %l3, !tbaa !24
  br label %bb126
bb75:
  %t178 = load i8, ptr %l7, !tbaa !22
  %t180 = icmp eq i8 %t178, 41
  br i1 %t180, label %bb76, label %bb77
bb76:
  %t182 = load i64, ptr %l3, !tbaa !24
  %t184 = icmp sgt i64 %t182, 0
  store i1 %t184, ptr %l108, !tbaa !21
  br label %bb78
bb77:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb78
bb78:
  %t186 = load i1, ptr %l108, !tbaa !21
  br i1 %t186, label %bb79, label %bb80
bb79:
  %t187 = load i64, ptr %l3, !tbaa !24
  %t190 = sub i64 %t187, 1
  store i64 %t190, ptr %l3, !tbaa !24
  br label %bb125
bb80:
  %t192 = load i8, ptr %l7, !tbaa !22
  %t194 = icmp eq i8 %t192, 44
  br i1 %t194, label %bb81, label %bb82
bb81:
  store i1 true, ptr %l116, !tbaa !21
  br label %bb83
bb82:
  %t196 = load i8, ptr %l7, !tbaa !22
  %t198 = icmp eq i8 %t196, 41
  store i1 %t198, ptr %l116, !tbaa !21
  br label %bb83
bb83:
  %t200 = load i1, ptr %l116, !tbaa !21
  br i1 %t200, label %bb84, label %bb85
bb84:
  %t201 = load i64, ptr %l3, !tbaa !24
  %t203 = icmp eq i64 %t201, 0
  store i1 %t203, ptr %l119, !tbaa !21
  br label %bb86
bb85:
  store i1 false, ptr %l119, !tbaa !21
  br label %bb86
bb86:
  %t205 = load i1, ptr %l119, !tbaa !21
  br i1 %t205, label %bb87, label %bb88
bb87:
  store %olang.scope zeroinitializer, ptr %s13
  %t206 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t206, ptr %l122, !tbaa !27
  %t207 = load i64, ptr %l4, !tbaa !24
  store i64 %t207, ptr %l123, !tbaa !24
  %t208 = load i64, ptr %l6, !tbaa !24
  store i64 %t208, ptr %l124, !tbaa !24
  %t209 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t210 = extractvalue { i64, ptr } %t209, 0
  store i64 %t210, ptr %l125, !tbaa !24
  %t211 = load i64, ptr %l123, !tbaa !24
  %t212 = icmp sge i64 %t211, 0
  br i1 %t212, label %bb89, label %bb90
bb88:
  br label %bb124
bb89:
  %t214 = load i64, ptr %l123, !tbaa !24
  %t215 = load i64, ptr %l124, !tbaa !24
  %t216 = icmp sle i64 %t214, %t215
  br i1 %t216, label %bb91, label %bb92
bb90:
  call void @__olang_check_failed(ptr @olang_loc_d8a12b6fe56d9e39_f2cc2d97d79a0415)
  unreachable
bb91:
  %t218 = load i64, ptr %l124, !tbaa !24
  %t219 = load i64, ptr %l125, !tbaa !24
  %t220 = icmp sle i64 %t218, %t219
  br i1 %t220, label %bb93, label %bb94
bb92:
  call void @__olang_check_failed(ptr @olang_loc_d8a12b6fe56d9e39_f2cc2d97d79a0415)
  unreachable
bb93:
  %t222 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t223 = load ptr, ptr %t222, !tbaa !27
  %t224 = load i64, ptr %l123, !tbaa !24
  %t225 = load i64, ptr %l124, !tbaa !24
  %t226 = getelementptr i8, ptr %t223, i64 %t224
  %t227 = sub i64 %t225, %t224
  %t228 = insertvalue { i64, ptr } undef, i64 %t227, 0
  %t229 = insertvalue { i64, ptr } %t228, ptr %t226, 1
  %t231 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v1, ptr %v1, { i64, ptr } %t229)
  store { i64, ptr } %t231, ptr %l130
  br label %bb95
bb94:
  call void @__olang_check_failed(ptr @olang_loc_d8a12b6fe56d9e39_f2cc2d97d79a0415)
  unreachable
bb95:
  %t232 = load { i64, ptr }, ptr %l130, !tbaa !27
  store { i64, ptr } %t232, ptr %l8, !tbaa !27
  %t233 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t235 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v1, ptr %s13, { i64, ptr } %t233, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d87, i32 0, i32 1) })
  %t236 = extractvalue { i32, i64 } %t235, 1
  %t237 = extractvalue { i32, i64 } %t235, 0
  store i32 %t237, ptr %l134
  %t238 = icmp ne i32 %t237, 0
  br i1 %t238, label %bb97, label %ok.239, !prof !99
ok.239:
  store i64 %t236, ptr %l133
  br label %bb96
bb96:
  %t240 = load i64, ptr %l133, !tbaa !24
  store i64 %t240, ptr %l131, !tbaa !24
  br label %bb99
bb97:
  br label %bb98
bb98:
  store i64 -1, ptr %l131, !tbaa !24
  br label %bb99
bb99:
  %t241 = load i64, ptr %l131, !tbaa !24
  store i64 %t241, ptr %l9, !tbaa !24
  %t242 = load i64, ptr %l9, !tbaa !24
  %t244 = icmp sge i64 %t242, 0
  br i1 %t244, label %bb100, label %bb101
bb100:
  %t246 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t246, ptr %l138, !tbaa !27
  %t247 = load i64, ptr %l9, !tbaa !24
  %t249 = add i64 %t247, 1
  %t251 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t252 = load ptr, ptr %t251, !tbaa !27
  %t253 = getelementptr i8, ptr %t252, i64 %t249
  %t254 = load i8, ptr %t253, !tbaa !32
  %t256 = icmp eq i8 %t254, 37
  store i1 %t256, ptr %l137, !tbaa !21
  br label %bb102
bb101:
  store i1 false, ptr %l137, !tbaa !21
  br label %bb102
bb102:
  %t258 = load i1, ptr %l137, !tbaa !21
  br i1 %t258, label %bb103, label %bb104
bb103:
  %t259 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t259, ptr %l143, !tbaa !27
  %t260 = load i64, ptr %l9, !tbaa !24
  store i64 %t260, ptr %l144, !tbaa !24
  %t261 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t262 = extractvalue { i64, ptr } %t261, 0
  store i64 %t262, ptr %l145, !tbaa !24
  %t263 = icmp sge i64 0, 0
  br i1 %t263, label %bb105, label %bb106
bb104:
  br label %bb112
bb105:
  %t265 = load i64, ptr %l144, !tbaa !24
  %t266 = icmp sle i64 0, %t265
  br i1 %t266, label %bb107, label %bb108
bb106:
  call void @__olang_check_failed(ptr @olang_loc_9d9b73c28e4e3d9a_299346768faaee36)
  unreachable
bb107:
  %t268 = load i64, ptr %l144, !tbaa !24
  %t269 = load i64, ptr %l145, !tbaa !24
  %t270 = icmp sle i64 %t268, %t269
  br i1 %t270, label %bb109, label %bb110
bb108:
  call void @__olang_check_failed(ptr @olang_loc_9d9b73c28e4e3d9a_299346768faaee36)
  unreachable
bb109:
  %t272 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !27
  %t274 = load i64, ptr %l144, !tbaa !24
  %t275 = getelementptr i8, ptr %t273, i64 0
  %t276 = sub i64 %t274, 0
  %t277 = insertvalue { i64, ptr } undef, i64 %t276, 0
  %t278 = insertvalue { i64, ptr } %t277, ptr %t275, 1
  %t280 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %v1, ptr %s13, { i64, ptr } %t278)
  store { i64, ptr } %t280, ptr %l150
  br label %bb111
bb110:
  call void @__olang_check_failed(ptr @olang_loc_9d9b73c28e4e3d9a_299346768faaee36)
  unreachable
bb111:
  %t281 = load { i64, ptr }, ptr %l150, !tbaa !27
  store { i64, ptr } %t281, ptr %l8, !tbaa !27
  br label %bb112
bb112:
  %t282 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t284 = extractvalue { i64, ptr } %t282, 0
  %t286 = icmp sgt i64 %t284, 0
  br i1 %t286, label %bb113, label %bb114
bb113:
  %t288 = load i1, ptr %l5, !tbaa !21
  %t290 = xor i1 %t288, true
  br i1 %t290, label %bb115, label %bb116
bb114:
  br label %bb120
bb115:
  store %olang.scope zeroinitializer, ptr %s16
  %t292 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s16, ptr %t292, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d88, i32 0, i32 1) })
  br label %bb117
bb116:
  br label %bb118
bb117:
  call void @__olang_scope_close(ptr %s16)
  br label %bb118
bb118:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t295, ptr %l158, !tbaa !27
  %t296 = load { i64, ptr }, ptr %l158, !tbaa !27
  %t297 = extractvalue { i64, ptr } %t296, 1
  %t298 = call ptr @__olang_scope_of(ptr %t297, ptr null)
  %t299 = call ptr @__olang_scope_hold(ptr %t298)
  %t300 = ptrtoint ptr %t299 to i64
  %t302 = inttoptr i64 %t300 to ptr
  %t304 = load { i64, ptr }, ptr %l158, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %t302, ptr %t294, { i64, ptr } %t304)
  br label %bb119
bb119:
  br label %bb120
bb120:
  store i1 false, ptr %l5, !tbaa !21
  %t305 = load i64, ptr %l6, !tbaa !24
  %t307 = add i64 %t305, 1
  store i64 %t307, ptr %l4, !tbaa !24
  %t309 = load i8, ptr %l7, !tbaa !22
  %t311 = icmp eq i8 %t309, 41
  br i1 %t311, label %bb121, label %bb122
bb121:
  call void @__olang_scope_close(ptr %s13)
  br label %bb129
bb122:
  br label %bb123
bb123:
  call void @__olang_scope_close(ptr %s13)
  br label %bb124
bb124:
  br label %bb125
bb125:
  br label %bb126
bb126:
  br label %bb127
bb127:
  %t313 = load i64, ptr %l6, !tbaa !24
  %t316 = add i64 %t313, 1
  store i64 %t316, ptr %l6, !tbaa !24
  br label %bb128
bb128:
  br label %bb53
bb129:
  %t318 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t318, ptr %l167, !tbaa !27
  %t319 = load i64, ptr %l6, !tbaa !24
  %t321 = add i64 %t319, 1
  store i64 %t321, ptr %l169, !tbaa !24
  %t322 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t325 = extractvalue { i64, ptr } %t322, 0
  store i64 %t325, ptr %l172, !tbaa !24
  %t326 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t327 = extractvalue { i64, ptr } %t326, 0
  store i64 %t327, ptr %l173, !tbaa !24
  %t328 = load i64, ptr %l169, !tbaa !24
  %t329 = icmp sge i64 %t328, 0
  br i1 %t329, label %bb130, label %bb131
bb130:
  %t331 = load i64, ptr %l169, !tbaa !24
  %t332 = load i64, ptr %l172, !tbaa !24
  %t333 = icmp sle i64 %t331, %t332
  br i1 %t333, label %bb132, label %bb133
bb131:
  call void @__olang_check_failed(ptr @olang_loc_9424fbeaf4790ef7_29a43c91e82e5293)
  unreachable
bb132:
  %t335 = load i64, ptr %l172, !tbaa !24
  %t336 = load i64, ptr %l173, !tbaa !24
  %t337 = icmp sle i64 %t335, %t336
  br i1 %t337, label %bb134, label %bb135
bb133:
  call void @__olang_check_failed(ptr @olang_loc_9424fbeaf4790ef7_29a43c91e82e5293)
  unreachable
bb134:
  %t339 = getelementptr { i64, ptr }, ptr %l167, i32 0, i32 1
  %t340 = load ptr, ptr %t339, !tbaa !27
  %t341 = load i64, ptr %l169, !tbaa !24
  %t342 = load i64, ptr %l172, !tbaa !24
  %t343 = getelementptr i8, ptr %t340, i64 %t341
  %t344 = sub i64 %t342, %t341
  %t345 = insertvalue { i64, ptr } undef, i64 %t344, 0
  %t346 = insertvalue { i64, ptr } %t345, ptr %t343, 1
  store { i64, ptr } %t346, ptr %l10, !tbaa !27
  %t348 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t350 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v1, ptr %s3, { i64, ptr } %t348, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d89, i32 0, i32 1) })
  %t351 = extractvalue { i32, i64 } %t350, 1
  %t352 = extractvalue { i32, i64 } %t350, 0
  store i32 %t352, ptr %l181
  %t353 = icmp ne i32 %t352, 0
  br i1 %t353, label %bb137, label %ok.354, !prof !99
ok.354:
  store i64 %t351, ptr %l180
  br label %bb136
bb135:
  call void @__olang_check_failed(ptr @olang_loc_9424fbeaf4790ef7_29a43c91e82e5293)
  unreachable
bb136:
  %t355 = load i64, ptr %l180, !tbaa !24
  store i64 %t355, ptr %l178, !tbaa !24
  br label %bb139
bb137:
  br label %bb138
bb138:
  %t356 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t358 = extractvalue { i64, ptr } %t356, 0
  store i64 %t358, ptr %l178, !tbaa !24
  br label %bb139
bb139:
  %t360 = load i64, ptr %l178, !tbaa !24
  %t361 = load ptr, ptr %l0, !tbaa !29
  store ptr %t361, ptr %l184, !tbaa !29
  %t362 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t362, ptr %l185, !tbaa !27
  store i64 %t360, ptr %l186, !tbaa !24
  %t364 = load { i64, ptr }, ptr %l185, !tbaa !27
  %t365 = extractvalue { i64, ptr } %t364, 0
  store i64 %t365, ptr %l187, !tbaa !24
  %t366 = icmp sge i64 0, 0
  br i1 %t366, label %bb140, label %bb141
bb140:
  %t368 = load i64, ptr %l186, !tbaa !24
  %t369 = icmp sle i64 0, %t368
  br i1 %t369, label %bb142, label %bb143
bb141:
  call void @__olang_check_failed(ptr @olang_loc_15c1087a8dcee578_9616249aba3f0cc)
  unreachable
bb142:
  %t371 = load i64, ptr %l186, !tbaa !24
  %t372 = load i64, ptr %l187, !tbaa !24
  %t373 = icmp sle i64 %t371, %t372
  br i1 %t373, label %bb144, label %bb145
bb143:
  call void @__olang_check_failed(ptr @olang_loc_15c1087a8dcee578_9616249aba3f0cc)
  unreachable
bb144:
  %t375 = getelementptr { i64, ptr }, ptr %l185, i32 0, i32 1
  %t376 = load ptr, ptr %t375, !tbaa !27
  %t377 = load i64, ptr %l186, !tbaa !24
  %t378 = getelementptr i8, ptr %t376, i64 0
  %t379 = sub i64 %t377, 0
  %t380 = insertvalue { i64, ptr } undef, i64 %t379, 0
  %t381 = insertvalue { i64, ptr } %t380, ptr %t378, 1
  %t383 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %v1, ptr %s3, { i64, ptr } %t381)
  store { i64, ptr } %t383, ptr %l192
  br label %bb146
bb145:
  call void @__olang_check_failed(ptr @olang_loc_15c1087a8dcee578_9616249aba3f0cc)
  unreachable
bb146:
  %t384 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d90, i32 0, i32 1) }, 1
  %t385 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d90, i32 0, i32 1) }, 0
  %t386 = load { i64, ptr }, ptr %l192, !tbaa !27
  %t387 = extractvalue { i64, ptr } %t386, 1
  %t388 = extractvalue { i64, ptr } %t386, 0
  %t389 = add i64 %t385, %t388
  %t390 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d91, i32 0, i32 1) }, 1
  %t391 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d91, i32 0, i32 1) }, 0
  %t392 = add i64 %t389, %t391
  %t393 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t392)
  call void @olang_textcopy(ptr %t393, ptr %t384, i64 %t385)
  %t394 = getelementptr i8, ptr %t393, i64 %t385
  call void @olang_textcopy(ptr %t394, ptr %t387, i64 %t388)
  %t395 = getelementptr i8, ptr %t394, i64 %t388
  call void @olang_textcopy(ptr %t395, ptr %t390, i64 %t391)
  %t396 = insertvalue { i64, ptr } undef, i64 %t392, 0
  %t397 = insertvalue { i64, ptr } %t396, ptr %t393, 1
  %t399 = load ptr, ptr %l184, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s3, ptr %t399, { i64, ptr } %t397)
  br label %bb147
bb147:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb148:
  %t401 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t403 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t401, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d92, i32 0, i32 1) })
  store i1 %t403, ptr %l196
  br label %bb149
bb149:
  %t404 = load i1, ptr %l196, !tbaa !21
  br i1 %t404, label %bb150, label %bb151
bb150:
  store %olang.scope zeroinitializer, ptr %s19
  %t405 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t407 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s19, { i64, ptr } %t405, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d93, i32 0, i32 1) })
  %t408 = extractvalue { i32, i64 } %t407, 1
  %t409 = extractvalue { i32, i64 } %t407, 0
  store i32 %t409, ptr %l200
  %t410 = icmp ne i32 %t409, 0
  br i1 %t410, label %bb153, label %ok.411, !prof !99
ok.411:
  store i64 %t408, ptr %l199
  br label %bb152
bb151:
  br label %bb221
bb152:
  %t412 = load i64, ptr %l199, !tbaa !24
  store i64 %t412, ptr %l197, !tbaa !24
  br label %bb155
bb153:
  br label %bb154
bb154:
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb155:
  %t413 = load i64, ptr %l197, !tbaa !24
  store i64 %t413, ptr %l12, !tbaa !24
  %t414 = load ptr, ptr %l0, !tbaa !29
  store ptr %t414, ptr %l201, !tbaa !29
  %t415 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t415, ptr %l202, !tbaa !27
  %t416 = load i64, ptr %l12, !tbaa !24
  store i64 %t416, ptr %l203, !tbaa !24
  %t417 = load { i64, ptr }, ptr %l202, !tbaa !27
  %t418 = extractvalue { i64, ptr } %t417, 0
  store i64 %t418, ptr %l204, !tbaa !24
  %t419 = icmp sge i64 0, 0
  br i1 %t419, label %bb156, label %bb157
bb156:
  %t421 = load i64, ptr %l203, !tbaa !24
  %t422 = icmp sle i64 0, %t421
  br i1 %t422, label %bb158, label %bb159
bb157:
  call void @__olang_check_failed(ptr @olang_loc_37b9d9dde30c0555_b630301b751c84f9)
  unreachable
bb158:
  %t424 = load i64, ptr %l203, !tbaa !24
  %t425 = load i64, ptr %l204, !tbaa !24
  %t426 = icmp sle i64 %t424, %t425
  br i1 %t426, label %bb160, label %bb161
bb159:
  call void @__olang_check_failed(ptr @olang_loc_37b9d9dde30c0555_b630301b751c84f9)
  unreachable
bb160:
  %t428 = getelementptr { i64, ptr }, ptr %l202, i32 0, i32 1
  %t429 = load ptr, ptr %t428, !tbaa !27
  %t430 = load i64, ptr %l203, !tbaa !24
  %t431 = getelementptr i8, ptr %t429, i64 0
  %t432 = sub i64 %t430, 0
  %t433 = insertvalue { i64, ptr } undef, i64 %t432, 0
  %t434 = insertvalue { i64, ptr } %t433, ptr %t431, 1
  %t436 = extractvalue { i64, ptr } %t434, 1
  %t437 = extractvalue { i64, ptr } %t434, 0
  %t438 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t439 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  %t440 = add i64 %t437, %t439
  %t441 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t440)
  call void @olang_textcopy(ptr %t441, ptr %t436, i64 %t437)
  %t442 = getelementptr i8, ptr %t441, i64 %t437
  call void @olang_textcopy(ptr %t442, ptr %t438, i64 %t439)
  %t443 = insertvalue { i64, ptr } undef, i64 %t440, 0
  %t444 = insertvalue { i64, ptr } %t443, ptr %t441, 1
  %t446 = load ptr, ptr %l201, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s19, ptr %t446, { i64, ptr } %t444)
  br label %bb162
bb161:
  call void @__olang_check_failed(ptr @olang_loc_37b9d9dde30c0555_b630301b751c84f9)
  unreachable
bb162:
  %t448 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t448, ptr %l211, !tbaa !27
  %t449 = load i64, ptr %l12, !tbaa !24
  %t451 = add i64 %t449, 3
  store i64 %t451, ptr %l213, !tbaa !24
  %t452 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t455 = extractvalue { i64, ptr } %t452, 0
  store i64 %t455, ptr %l216, !tbaa !24
  %t456 = load { i64, ptr }, ptr %l211, !tbaa !27
  %t457 = extractvalue { i64, ptr } %t456, 0
  store i64 %t457, ptr %l217, !tbaa !24
  %t458 = load i64, ptr %l213, !tbaa !24
  %t459 = icmp sge i64 %t458, 0
  br i1 %t459, label %bb163, label %bb164
bb163:
  %t461 = load i64, ptr %l213, !tbaa !24
  %t462 = load i64, ptr %l216, !tbaa !24
  %t463 = icmp sle i64 %t461, %t462
  br i1 %t463, label %bb165, label %bb166
bb164:
  call void @__olang_check_failed(ptr @olang_loc_2446b89a84efdb76_2c0483cfef229c5a)
  unreachable
bb165:
  %t465 = load i64, ptr %l216, !tbaa !24
  %t466 = load i64, ptr %l217, !tbaa !24
  %t467 = icmp sle i64 %t465, %t466
  br i1 %t467, label %bb167, label %bb168
bb166:
  call void @__olang_check_failed(ptr @olang_loc_2446b89a84efdb76_2c0483cfef229c5a)
  unreachable
bb167:
  %t469 = getelementptr { i64, ptr }, ptr %l211, i32 0, i32 1
  %t470 = load ptr, ptr %t469, !tbaa !27
  %t471 = load i64, ptr %l213, !tbaa !24
  %t472 = load i64, ptr %l216, !tbaa !24
  %t473 = getelementptr i8, ptr %t470, i64 %t471
  %t474 = sub i64 %t472, %t471
  %t475 = insertvalue { i64, ptr } undef, i64 %t474, 0
  %t476 = insertvalue { i64, ptr } %t475, ptr %t473, 1
  store { i64, ptr } %t476, ptr %l13, !tbaa !27
  %t478 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t480 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s19, { i64, ptr } %t478, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d95, i32 0, i32 1) })
  store i1 %t480, ptr %l223
  br label %bb169
bb168:
  call void @__olang_check_failed(ptr @olang_loc_2446b89a84efdb76_2c0483cfef229c5a)
  unreachable
bb169:
  %t481 = load i1, ptr %l223, !tbaa !21
  br i1 %t481, label %bb170, label %bb171
bb170:
  store %olang.scope zeroinitializer, ptr %s22
  %t482 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t484 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s22, { i64, ptr } %t482, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d96, i32 0, i32 1) })
  %t485 = extractvalue { i32, i64 } %t484, 1
  %t486 = extractvalue { i32, i64 } %t484, 0
  store i32 %t486, ptr %l227
  %t487 = icmp ne i32 %t486, 0
  br i1 %t487, label %bb173, label %ok.488, !prof !99
ok.488:
  store i64 %t485, ptr %l226
  br label %bb172
bb171:
  br label %bb189
bb172:
  %t489 = load i64, ptr %l226, !tbaa !24
  store i64 %t489, ptr %l224, !tbaa !24
  br label %bb175
bb173:
  br label %bb174
bb174:
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb175:
  %t490 = load i64, ptr %l224, !tbaa !24
  store i64 %t490, ptr %l14, !tbaa !24
  %t491 = load ptr, ptr %l0, !tbaa !29
  store ptr %t491, ptr %l228, !tbaa !29
  %t492 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t492, ptr %l229, !tbaa !27
  %t493 = load i64, ptr %l14, !tbaa !24
  %t495 = add i64 %t493, 1
  store i64 %t495, ptr %l231, !tbaa !24
  %t496 = load { i64, ptr }, ptr %l229, !tbaa !27
  %t497 = extractvalue { i64, ptr } %t496, 0
  store i64 %t497, ptr %l232, !tbaa !24
  %t498 = icmp sge i64 0, 0
  br i1 %t498, label %bb176, label %bb177
bb176:
  %t500 = load i64, ptr %l231, !tbaa !24
  %t501 = icmp sle i64 0, %t500
  br i1 %t501, label %bb178, label %bb179
bb177:
  call void @__olang_check_failed(ptr @olang_loc_d4a9c3df34bd8bd3_6b2d8c232432bdb7)
  unreachable
bb178:
  %t503 = load i64, ptr %l231, !tbaa !24
  %t504 = load i64, ptr %l232, !tbaa !24
  %t505 = icmp sle i64 %t503, %t504
  br i1 %t505, label %bb180, label %bb181
bb179:
  call void @__olang_check_failed(ptr @olang_loc_d4a9c3df34bd8bd3_6b2d8c232432bdb7)
  unreachable
bb180:
  %t507 = getelementptr { i64, ptr }, ptr %l229, i32 0, i32 1
  %t508 = load ptr, ptr %t507, !tbaa !27
  %t509 = load i64, ptr %l231, !tbaa !24
  %t510 = getelementptr i8, ptr %t508, i64 0
  %t511 = sub i64 %t509, 0
  %t512 = insertvalue { i64, ptr } undef, i64 %t511, 0
  %t513 = insertvalue { i64, ptr } %t512, ptr %t510, 1
  %t515 = extractvalue { i64, ptr } %t513, 1
  %t516 = extractvalue { i64, ptr } %t513, 0
  %t517 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d97, i32 0, i32 1) }, 1
  %t518 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d97, i32 0, i32 1) }, 0
  %t519 = add i64 %t516, %t518
  %t520 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t519)
  call void @olang_textcopy(ptr %t520, ptr %t515, i64 %t516)
  %t521 = getelementptr i8, ptr %t520, i64 %t516
  call void @olang_textcopy(ptr %t521, ptr %t517, i64 %t518)
  %t522 = insertvalue { i64, ptr } undef, i64 %t519, 0
  %t523 = insertvalue { i64, ptr } %t522, ptr %t520, 1
  %t525 = load ptr, ptr %l228, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s22, ptr %t525, { i64, ptr } %t523)
  br label %bb182
bb181:
  call void @__olang_check_failed(ptr @olang_loc_d4a9c3df34bd8bd3_6b2d8c232432bdb7)
  unreachable
bb182:
  %t527 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t527, ptr %l239, !tbaa !27
  %t528 = load i64, ptr %l14, !tbaa !24
  %t530 = add i64 %t528, 2
  store i64 %t530, ptr %l241, !tbaa !24
  %t531 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t534 = extractvalue { i64, ptr } %t531, 0
  store i64 %t534, ptr %l244, !tbaa !24
  %t535 = load { i64, ptr }, ptr %l239, !tbaa !27
  %t536 = extractvalue { i64, ptr } %t535, 0
  store i64 %t536, ptr %l245, !tbaa !24
  %t537 = load i64, ptr %l241, !tbaa !24
  %t538 = icmp sge i64 %t537, 0
  br i1 %t538, label %bb183, label %bb184
bb183:
  %t540 = load i64, ptr %l241, !tbaa !24
  %t541 = load i64, ptr %l244, !tbaa !24
  %t542 = icmp sle i64 %t540, %t541
  br i1 %t542, label %bb185, label %bb186
bb184:
  call void @__olang_check_failed(ptr @olang_loc_885af16d4a3d8d64_d0eb96c61f9dafb0)
  unreachable
bb185:
  %t544 = load i64, ptr %l244, !tbaa !24
  %t545 = load i64, ptr %l245, !tbaa !24
  %t546 = icmp sle i64 %t544, %t545
  br i1 %t546, label %bb187, label %bb188
bb186:
  call void @__olang_check_failed(ptr @olang_loc_885af16d4a3d8d64_d0eb96c61f9dafb0)
  unreachable
bb187:
  %t548 = getelementptr { i64, ptr }, ptr %l239, i32 0, i32 1
  %t549 = load ptr, ptr %t548, !tbaa !27
  %t550 = load i64, ptr %l241, !tbaa !24
  %t551 = load i64, ptr %l244, !tbaa !24
  %t552 = getelementptr i8, ptr %t549, i64 %t550
  %t553 = sub i64 %t551, %t550
  %t554 = insertvalue { i64, ptr } undef, i64 %t553, 0
  %t555 = insertvalue { i64, ptr } %t554, ptr %t552, 1
  store { i64, ptr } %t555, ptr %l13, !tbaa !27
  call void @__olang_scope_close(ptr %s22)
  br label %bb189
bb188:
  call void @__olang_check_failed(ptr @olang_loc_885af16d4a3d8d64_d0eb96c61f9dafb0)
  unreachable
bb189:
  %t557 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t559 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s19, { i64, ptr } %t557, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d98, i32 0, i32 1) })
  store i1 %t559, ptr %l251
  br label %bb190
bb190:
  %t560 = load i1, ptr %l251, !tbaa !21
  br i1 %t560, label %bb191, label %bb192
bb191:
  %t561 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t561, ptr %l252, !tbaa !27
  %t562 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t565 = extractvalue { i64, ptr } %t562, 0
  store i64 %t565, ptr %l255, !tbaa !24
  %t566 = load { i64, ptr }, ptr %l252, !tbaa !27
  %t567 = extractvalue { i64, ptr } %t566, 0
  store i64 %t567, ptr %l256, !tbaa !24
  %t568 = icmp sge i64 13, 0
  br i1 %t568, label %bb193, label %bb194
bb192:
  br label %bb199
bb193:
  %t570 = load i64, ptr %l255, !tbaa !24
  %t571 = icmp sle i64 13, %t570
  br i1 %t571, label %bb195, label %bb196
bb194:
  call void @__olang_check_failed(ptr @olang_loc_383c318151cd7051_6709cfbf24f79c8d)
  unreachable
bb195:
  %t573 = load i64, ptr %l255, !tbaa !24
  %t574 = load i64, ptr %l256, !tbaa !24
  %t575 = icmp sle i64 %t573, %t574
  br i1 %t575, label %bb197, label %bb198
bb196:
  call void @__olang_check_failed(ptr @olang_loc_383c318151cd7051_6709cfbf24f79c8d)
  unreachable
bb197:
  %t577 = getelementptr { i64, ptr }, ptr %l252, i32 0, i32 1
  %t578 = load ptr, ptr %t577, !tbaa !27
  %t579 = load i64, ptr %l255, !tbaa !24
  %t580 = getelementptr i8, ptr %t578, i64 13
  %t581 = sub i64 %t579, 13
  %t582 = insertvalue { i64, ptr } undef, i64 %t581, 0
  %t583 = insertvalue { i64, ptr } %t582, ptr %t580, 1
  store { i64, ptr } %t583, ptr %l13, !tbaa !27
  br label %bb199
bb198:
  call void @__olang_check_failed(ptr @olang_loc_383c318151cd7051_6709cfbf24f79c8d)
  unreachable
bb199:
  %t585 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t587 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s19, { i64, ptr } %t585, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d99, i32 0, i32 1) })
  %t588 = extractvalue { i32, i64 } %t587, 1
  %t589 = extractvalue { i32, i64 } %t587, 0
  store i32 %t589, ptr %l264
  %t590 = icmp ne i32 %t589, 0
  br i1 %t590, label %bb201, label %ok.591, !prof !99
ok.591:
  store i64 %t588, ptr %l263
  br label %bb200
bb200:
  %t592 = load i64, ptr %l263, !tbaa !24
  store i64 %t592, ptr %l261, !tbaa !24
  br label %bb203
bb201:
  br label %bb202
bb202:
  %t593 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t595 = extractvalue { i64, ptr } %t593, 0
  store i64 %t595, ptr %l261, !tbaa !24
  br label %bb203
bb203:
  %t597 = load i64, ptr %l261, !tbaa !24
  store i64 %t597, ptr %l15, !tbaa !24
  %t598 = load i64, ptr %l15, !tbaa !24
  %t600 = add i64 %t598, 1
  %t601 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t603 = extractvalue { i64, ptr } %t601, 0
  %t606 = icmp slt i64 %t600, %t603
  br i1 %t606, label %bb204, label %bb205
bb204:
  %t608 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t609 = load i64, ptr %l15, !tbaa !24
  %t611 = add i64 %t609, 1
  %t614 = call i64 @compiler_2fruntime_2etypeEnd(ptr %v1, { i64, ptr } %t608, i64 %t611)
  store i64 %t614, ptr %l276
  br label %bb206
bb205:
  %t615 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t617 = extractvalue { i64, ptr } %t615, 0
  store i64 %t617, ptr %l272, !tbaa !24
  br label %bb207
bb206:
  %t619 = load i64, ptr %l276, !tbaa !24
  store i64 %t619, ptr %l272, !tbaa !24
  br label %bb207
bb207:
  %t620 = load i64, ptr %l272, !tbaa !24
  store i64 %t620, ptr %l16, !tbaa !24
  %t621 = load ptr, ptr %l0, !tbaa !29
  store ptr %t621, ptr %l279, !tbaa !29
  %t622 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t622, ptr %l280, !tbaa !27
  %t623 = load i64, ptr %l15, !tbaa !24
  %t625 = add i64 %t623, 1
  store i64 %t625, ptr %l282, !tbaa !24
  %t626 = load { i64, ptr }, ptr %l280, !tbaa !27
  %t627 = extractvalue { i64, ptr } %t626, 0
  store i64 %t627, ptr %l283, !tbaa !24
  %t628 = icmp sge i64 0, 0
  br i1 %t628, label %bb208, label %bb209
bb208:
  %t630 = load i64, ptr %l282, !tbaa !24
  %t631 = icmp sle i64 0, %t630
  br i1 %t631, label %bb210, label %bb211
bb209:
  call void @__olang_check_failed(ptr @olang_loc_b26c87ed9711b455_3749eb6f37e52fe9)
  unreachable
bb210:
  %t633 = load i64, ptr %l282, !tbaa !24
  %t634 = load i64, ptr %l283, !tbaa !24
  %t635 = icmp sle i64 %t633, %t634
  br i1 %t635, label %bb212, label %bb213
bb211:
  call void @__olang_check_failed(ptr @olang_loc_b26c87ed9711b455_3749eb6f37e52fe9)
  unreachable
bb212:
  %t637 = getelementptr { i64, ptr }, ptr %l280, i32 0, i32 1
  %t638 = load ptr, ptr %t637, !tbaa !27
  %t639 = load i64, ptr %l282, !tbaa !24
  %t640 = getelementptr i8, ptr %t638, i64 0
  %t641 = sub i64 %t639, 0
  %t642 = insertvalue { i64, ptr } undef, i64 %t641, 0
  %t643 = insertvalue { i64, ptr } %t642, ptr %t640, 1
  store { i64, ptr } %t643, ptr %l287, !tbaa !27
  %t644 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t644, ptr %l288, !tbaa !27
  %t645 = load i64, ptr %l15, !tbaa !24
  %t647 = add i64 %t645, 1
  store i64 %t647, ptr %l290, !tbaa !24
  %t648 = load i64, ptr %l16, !tbaa !24
  store i64 %t648, ptr %l291, !tbaa !24
  %t649 = load { i64, ptr }, ptr %l288, !tbaa !27
  %t650 = extractvalue { i64, ptr } %t649, 0
  store i64 %t650, ptr %l292, !tbaa !24
  %t651 = load i64, ptr %l290, !tbaa !24
  %t652 = icmp sge i64 %t651, 0
  br i1 %t652, label %bb214, label %bb215
bb213:
  call void @__olang_check_failed(ptr @olang_loc_b26c87ed9711b455_3749eb6f37e52fe9)
  unreachable
bb214:
  %t654 = load i64, ptr %l290, !tbaa !24
  %t655 = load i64, ptr %l291, !tbaa !24
  %t656 = icmp sle i64 %t654, %t655
  br i1 %t656, label %bb216, label %bb217
bb215:
  call void @__olang_check_failed(ptr @olang_loc_b26c87ed9711b455_3749eb6f37e52fe9)
  unreachable
bb216:
  %t658 = load i64, ptr %l291, !tbaa !24
  %t659 = load i64, ptr %l292, !tbaa !24
  %t660 = icmp sle i64 %t658, %t659
  br i1 %t660, label %bb218, label %bb219
bb217:
  call void @__olang_check_failed(ptr @olang_loc_b26c87ed9711b455_3749eb6f37e52fe9)
  unreachable
bb218:
  %t662 = getelementptr { i64, ptr }, ptr %l288, i32 0, i32 1
  %t663 = load ptr, ptr %t662, !tbaa !27
  %t664 = load i64, ptr %l290, !tbaa !24
  %t665 = load i64, ptr %l291, !tbaa !24
  %t666 = getelementptr i8, ptr %t663, i64 %t664
  %t667 = sub i64 %t665, %t664
  %t668 = insertvalue { i64, ptr } undef, i64 %t667, 0
  %t669 = insertvalue { i64, ptr } %t668, ptr %t666, 1
  %t670 = load { i64, ptr }, ptr %l287, !tbaa !27
  %t671 = extractvalue { i64, ptr } %t670, 1
  %t672 = extractvalue { i64, ptr } %t670, 0
  %t674 = extractvalue { i64, ptr } %t669, 1
  %t675 = extractvalue { i64, ptr } %t669, 0
  %t676 = add i64 %t672, %t675
  %t677 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d100, i32 0, i32 1) }, 1
  %t678 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d100, i32 0, i32 1) }, 0
  %t679 = add i64 %t676, %t678
  %t680 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t679)
  call void @olang_textcopy(ptr %t680, ptr %t671, i64 %t672)
  %t681 = getelementptr i8, ptr %t680, i64 %t672
  call void @olang_textcopy(ptr %t681, ptr %t674, i64 %t675)
  %t682 = getelementptr i8, ptr %t681, i64 %t675
  call void @olang_textcopy(ptr %t682, ptr %t677, i64 %t678)
  %t683 = insertvalue { i64, ptr } undef, i64 %t679, 0
  %t684 = insertvalue { i64, ptr } %t683, ptr %t680, 1
  %t686 = load ptr, ptr %l279, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s19, ptr %t686, { i64, ptr } %t684)
  br label %bb220
bb219:
  call void @__olang_check_failed(ptr @olang_loc_b26c87ed9711b455_3749eb6f37e52fe9)
  unreachable
bb220:
  call void @__olang_scope_close(ptr %s19)
  br label %bb221
bb221:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fruntime_2edirective(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l5 = alloca i1
  %l8 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l18 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i32
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l32 = alloca i1
  %l35 = alloca i1
  %l38 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d101, i32 0, i32 1) })
  store i1 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i1, ptr %l5, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l8, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t9, 0
  store i64 %t12, ptr %l11, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t13, 0
  store i64 %t14, ptr %l12, !tbaa !24
  %t15 = icmp sge i64 3, 0
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t17 = load i64, ptr %l11, !tbaa !24
  %t18 = icmp sle i64 3, %t17
  br i1 %t18, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_6a493f8daef1bb51_6724bcad8f2aca45)
  unreachable
bb7:
  %t20 = load i64, ptr %l11, !tbaa !24
  %t21 = load i64, ptr %l12, !tbaa !24
  %t22 = icmp sle i64 %t20, %t21
  br i1 %t22, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_6a493f8daef1bb51_6724bcad8f2aca45)
  unreachable
bb9:
  %t24 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = load i64, ptr %l11, !tbaa !24
  %t27 = getelementptr i8, ptr %t25, i64 3
  %t28 = sub i64 %t26, 3
  %t29 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t27, 1
  store { i64, ptr } %t30, ptr %l1, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t32, ptr %l2, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t36 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s0, { i64, ptr } %t34, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d102, i32 0, i32 1) })
  %t37 = extractvalue { i32, i64 } %t36, 1
  %t38 = extractvalue { i32, i64 } %t36, 0
  store i32 %t38, ptr %l21
  %t39 = icmp ne i32 %t38, 0
  br i1 %t39, label %bb12, label %ok.40, !prof !99
ok.40:
  store i64 %t37, ptr %l20
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_6a493f8daef1bb51_6724bcad8f2aca45)
  unreachable
bb11:
  %t41 = load i64, ptr %l20, !tbaa !24
  store i64 %t41, ptr %l18, !tbaa !24
  br label %bb14
bb12:
  br label %bb13
bb13:
  store i64 -1, ptr %l18, !tbaa !24
  br label %bb14
bb14:
  %t42 = load i64, ptr %l18, !tbaa !24
  store i64 %t42, ptr %l3, !tbaa !24
  %t43 = load i64, ptr %l3, !tbaa !24
  %t45 = icmp sge i64 %t43, 0
  br i1 %t45, label %bb15, label %bb16
bb15:
  %t47 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t47, ptr %l24, !tbaa !27
  %t48 = load i64, ptr %l3, !tbaa !24
  store i64 %t48, ptr %l25, !tbaa !24
  %t49 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  store i64 %t50, ptr %l26, !tbaa !24
  %t51 = icmp sge i64 0, 0
  br i1 %t51, label %bb17, label %bb18
bb16:
  br label %bb23
bb17:
  %t53 = load i64, ptr %l25, !tbaa !24
  %t54 = icmp sle i64 0, %t53
  br i1 %t54, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_ba67ff79a761d864_bc768279035b5e68)
  unreachable
bb19:
  %t56 = load i64, ptr %l25, !tbaa !24
  %t57 = load i64, ptr %l26, !tbaa !24
  %t58 = icmp sle i64 %t56, %t57
  br i1 %t58, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_ba67ff79a761d864_bc768279035b5e68)
  unreachable
bb21:
  %t60 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = load i64, ptr %l25, !tbaa !24
  %t63 = getelementptr i8, ptr %t61, i64 0
  %t64 = sub i64 %t62, 0
  %t65 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t63, 1
  store { i64, ptr } %t66, ptr %l2, !tbaa !27
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_ba67ff79a761d864_bc768279035b5e68)
  unreachable
bb23:
  %t68 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t70 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t68, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d103, i32 0, i32 1) })
  store i1 %t70, ptr %l32
  br label %bb24
bb24:
  %t71 = load i1, ptr %l32, !tbaa !21
  br i1 %t71, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s0)
  store i64 0, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t73 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t75 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t73, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d104, i32 0, i32 1) })
  store i1 %t75, ptr %l35
  br label %bb28
bb28:
  %t76 = load i1, ptr %l35, !tbaa !21
  br i1 %t76, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s0)
  store i64 1, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  %t78 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t80 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t78, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d105, i32 0, i32 1) })
  store i1 %t80, ptr %l38
  br label %bb32
bb32:
  %t81 = load i1, ptr %l38, !tbaa !21
  br i1 %t81, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s0)
  store i64 2, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i32, i64 } @compiler_2fruntime_2efact(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca [15 x { i64, ptr }]
  %l13 = alloca i64
  %l16 = alloca i64
  %l37 = alloca i1
  %l45 = alloca i64
  %rv = alloca { i32, i64 }
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr @G_2ecompiler_2fruntime_2eFactNames, i64 240, i1 false)
  %t1 = load [15 x { i64, ptr }], ptr %l8
  store i64 15, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t3 = load i64, ptr %l3, !tbaa !24
  %t4 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l16, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l16, !tbaa !24
  store i64 %t29, ptr %l13, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l13, !tbaa !24
  store i64 %t30, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  %t31 = load i64, ptr %l6, !tbaa !24
  %t32 = load i64, ptr %l5, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  br label %bb22
bb9:
  br label %bb10
bb10:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t44 = mul i64 %t40, %t41
  %t47 = add i64 %t39, %t44
  store i64 %t47, ptr %l7, !tbaa !24
  %t49 = load i64, ptr %l7, !tbaa !24
  %t51 = getelementptr [15 x { i64, ptr }], ptr @G_2ecompiler_2fruntime_2eFactNames, i64 0, i64 %t49
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !37
  %t54 = load ptr, ptr @__olang_prog_scope
  %t57 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t54, ptr %v0, { i64, ptr } %t52, { i64, ptr } %a0)
  store i1 %t57, ptr %l37
  br label %bb11
bb11:
  %t58 = load i1, ptr %l37, !tbaa !21
  %t59 = xor i1 %t58, true
  br i1 %t59, label %bb12, label %bb13
bb12:
  br label %bb21
bb13:
  br label %bb14
bb14:
  %t61 = load i64, ptr %l1, !tbaa !24
  %t63 = icmp eq i64 %t61, 2
  br i1 %t63, label %bb15, label %bb16
bb15:
  %t65 = load i64, ptr %l7, !tbaa !24
  %t67 = getelementptr [15 x i64], ptr @G_2ecompiler_2fruntime_2eFactWin, i64 0, i64 %t65
  %t68 = load i64, ptr %t67, !tbaa !34
  %t70 = insertvalue { i32, i64 } zeroinitializer, i64 %t68, 1
  store { i32, i64 } %t70, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t71 = load i64, ptr %l1, !tbaa !24
  %t73 = icmp eq i64 %t71, 0
  br i1 %t73, label %bb18, label %bb19
bb18:
  %t75 = load i64, ptr %l7, !tbaa !24
  %t77 = getelementptr [15 x i64], ptr @G_2ecompiler_2fruntime_2eFactX86, i64 0, i64 %t75
  %t78 = load i64, ptr %t77, !tbaa !34
  store i64 %t78, ptr %l45, !tbaa !24
  br label %bb20
bb19:
  %t80 = load i64, ptr %l7, !tbaa !24
  %t82 = getelementptr [15 x i64], ptr @G_2ecompiler_2fruntime_2eFactArm, i64 0, i64 %t80
  %t83 = load i64, ptr %t82, !tbaa !34
  store i64 %t83, ptr %l45, !tbaa !24
  br label %bb20
bb20:
  %t85 = load i64, ptr %l45, !tbaa !24
  %t86 = insertvalue { i32, i64 } zeroinitializer, i64 %t85, 1
  store { i32, i64 } %t86, ptr %rv
  br label %ret
bb21:
  %t87 = load i64, ptr %l6, !tbaa !24
  %t90 = add i64 %t87, 1
  store i64 %t90, ptr %l6, !tbaa !24
  br label %bb7
bb22:
  %t93 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t93, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local i32 @compiler_2fruntime_2emalformed(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l7 = alloca i32
  %l9 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t4 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d106, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d106, i32 0, i32 1) }, 0
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d107, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d107, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t14 = call i64 @__olang_fmt_i64(ptr null, i64 %a1)
  %t15 = add i64 %t12, %t14
  %t16 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d108, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d108, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t20 = extractvalue { i64, ptr } %a2, 1
  %t21 = extractvalue { i64, ptr } %a2, 0
  %t22 = add i64 %t18, %t21
  %t23 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t4, i64 %t5)
  %t24 = getelementptr i8, ptr %t23, i64 %t5
  call void @olang_textcopy(ptr %t24, ptr %t7, i64 %t8)
  %t25 = getelementptr i8, ptr %t24, i64 %t8
  call void @olang_textcopy(ptr %t25, ptr %t10, i64 %t11)
  %t26 = getelementptr i8, ptr %t25, i64 %t11
  %t27 = call i64 @__olang_fmt_i64(ptr %t26, i64 %a1)
  %t28 = getelementptr i8, ptr %t26, i64 %t14
  call void @olang_textcopy(ptr %t28, ptr %t16, i64 %t17)
  %t29 = getelementptr i8, ptr %t28, i64 %t17
  call void @olang_textcopy(ptr %t29, ptr %t20, i64 %t21)
  %t30 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t23, 1
  %t33 = call i32 @std_2fio_2ePutErrLn_3cstd_2fprelude_2ftext_3aString_3e({ i64, ptr } %t31)
  store i32 %t33, ptr %l7
  %t34 = icmp ne i32 %t33, 0
  br i1 %t34, label %bb2, label %ok.35, !prof !99
ok.35:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t36 = load i32, ptr %l7, !tbaa !23
  %t37 = ashr i32 %t36, 16
  %t39 = icmp eq i32 %t37, 1
  store i1 %t39, ptr %l9, !tbaa !21
  %t40 = load i32, ptr %l7, !tbaa !23
  %t41 = ashr i32 %t40, 16
  %t43 = icmp eq i32 %t41, 1
  br i1 %t43, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fruntime_2emodulesInline(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i1
  %l4 = alloca i1
  %l6 = alloca i1
  %l7 = alloca i1
  %l9 = alloca i1
  %l13 = alloca { i64, ptr }
  %l14 = alloca i1
  %l15 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d109, i32 0, i32 1) })
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb5
bb3:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t7, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d110, i32 0, i32 1) })
  store i1 %t9, ptr %l6
  br label %bb4
bb4:
  %t10 = load i1, ptr %l6, !tbaa !21
  store i1 %t10, ptr %l4, !tbaa !21
  br label %bb5
bb5:
  %t11 = load i1, ptr %l4, !tbaa !21
  br i1 %t11, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb9
bb7:
  %t12 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t14 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t12, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d111, i32 0, i32 1) })
  store i1 %t14, ptr %l9
  br label %bb8
bb8:
  %t15 = load i1, ptr %l9, !tbaa !21
  store i1 %t15, ptr %l7, !tbaa !21
  br label %bb9
bb9:
  %t16 = load i1, ptr %l7, !tbaa !21
  br i1 %t16, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t18 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d112, i32 0, i32 1) }, ptr %l13, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t22 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s0, { i64, ptr } %t18, { i64, ptr } %t21)
  store i1 %t22, ptr %l14
  br label %bb13
bb13:
  %t23 = load i1, ptr %l14, !tbaa !21
  br i1 %t23, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb17
bb15:
  %t24 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d113, i32 0, i32 1) }, ptr %l18, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t28 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s0, { i64, ptr } %t24, { i64, ptr } %t27)
  store i1 %t28, ptr %l19
  br label %bb16
bb16:
  %t29 = load i1, ptr %l19, !tbaa !21
  store i1 %t29, ptr %l15, !tbaa !21
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t30 = load i1, ptr %l15, !tbaa !21
  store i1 %t30, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fruntime_2esymbolOf(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l4 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l17 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i32
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i64
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %t1, i8 64)
  %t5 = extractvalue { i32, i64 } %t4, 1
  %t6 = extractvalue { i32, i64 } %t4, 0
  store i32 %t6, ptr %l8
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8, !prof !99
ok.8:
  store i64 %t5, ptr %l7
  br label %bb1
bb1:
  %t9 = load i64, ptr %l7, !tbaa !24
  store i64 %t9, ptr %l4, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t10 = load i64, ptr %l4, !tbaa !24
  store i64 %t10, ptr %l1, !tbaa !24
  %t11 = load i64, ptr %l1, !tbaa !24
  %t13 = icmp slt i64 %t11, 0
  br i1 %t13, label %bb5, label %bb6
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d114, i32 0, i32 1) }, ptr %l11, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t15, ptr %l12, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l13, !tbaa !24
  %t18 = load i64, ptr %l13, !tbaa !24
  %t19 = mul i64 %t18, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l14, !tbaa !27
  %t23 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = load i64, ptr %l13, !tbaa !24
  %t28 = mul i64 %t27, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t24, ptr %t26, i64 %t28, i1 false)
  %t29 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t29, ptr %l12, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t30, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t31 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t31, ptr %l15, !tbaa !27
  %t32 = load i64, ptr %l1, !tbaa !24
  %t34 = add i64 %t32, 1
  store i64 %t34, ptr %l17, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t35, 0
  store i64 %t38, ptr %l20, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l21, !tbaa !24
  %t41 = load i64, ptr %l17, !tbaa !24
  %t42 = icmp sge i64 %t41, 0
  br i1 %t42, label %bb8, label %bb9
bb8:
  %t44 = load i64, ptr %l17, !tbaa !24
  %t45 = load i64, ptr %l20, !tbaa !24
  %t46 = icmp sle i64 %t44, %t45
  br i1 %t46, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_b70188616b037137_b122dd4ae5a41093)
  unreachable
bb10:
  %t48 = load i64, ptr %l20, !tbaa !24
  %t49 = load i64, ptr %l21, !tbaa !24
  %t50 = icmp sle i64 %t48, %t49
  br i1 %t50, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_b70188616b037137_b122dd4ae5a41093)
  unreachable
bb12:
  %t52 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = load i64, ptr %l17, !tbaa !24
  %t55 = load i64, ptr %l20, !tbaa !24
  %t56 = getelementptr i8, ptr %t53, i64 %t54
  %t57 = sub i64 %t55, %t54
  %t58 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t56, 1
  store { i64, ptr } %t59, ptr %l2, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t64 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %t61, i8 40)
  %t65 = extractvalue { i32, i64 } %t64, 1
  %t66 = extractvalue { i32, i64 } %t64, 0
  store i32 %t66, ptr %l30
  %t67 = icmp ne i32 %t66, 0
  br i1 %t67, label %bb15, label %ok.68, !prof !99
ok.68:
  store i64 %t65, ptr %l29
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_b70188616b037137_b122dd4ae5a41093)
  unreachable
bb14:
  %t69 = load i64, ptr %l29, !tbaa !24
  store i64 %t69, ptr %l26, !tbaa !24
  br label %bb17
bb15:
  br label %bb16
bb16:
  %t70 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t70, 0
  store i64 %t72, ptr %l26, !tbaa !24
  br label %bb17
bb17:
  %t74 = load i64, ptr %l26, !tbaa !24
  %t75 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t75, ptr %l33, !tbaa !27
  store i64 %t74, ptr %l34, !tbaa !24
  %t77 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t77, 0
  store i64 %t78, ptr %l35, !tbaa !24
  %t79 = icmp sge i64 0, 0
  br i1 %t79, label %bb18, label %bb19
bb18:
  %t81 = load i64, ptr %l34, !tbaa !24
  %t82 = icmp sle i64 0, %t81
  br i1 %t82, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_77d8800e35f34fda_b111e72f8d20ac36)
  unreachable
bb20:
  %t84 = load i64, ptr %l34, !tbaa !24
  %t85 = load i64, ptr %l35, !tbaa !24
  %t86 = icmp sle i64 %t84, %t85
  br i1 %t86, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_77d8800e35f34fda_b111e72f8d20ac36)
  unreachable
bb22:
  %t88 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = load i64, ptr %l34, !tbaa !24
  %t91 = getelementptr i8, ptr %t89, i64 0
  %t92 = sub i64 %t90, 0
  %t93 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t91, 1
  %t96 = extractvalue { i64, ptr } %t94, 1
  %t97 = extractvalue { i64, ptr } %t94, 0
  %t98 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t97)
  call void @olang_textcopy(ptr %t98, ptr %t96, i64 %t97)
  %t99 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  store { i64, ptr } %t100, ptr %rv
  br label %ret
bb23:
  call void @__olang_check_failed(ptr @olang_loc_77d8800e35f34fda_b111e72f8d20ac36)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fruntime_2etypeEnd(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i8
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i8
  %l17 = alloca { i64, ptr }
  %l22 = alloca i1
  %l25 = alloca i1
  %l34 = alloca i64
  %l37 = alloca i64
  %l46 = alloca i64
  %l49 = alloca i1
  %l59 = alloca { i64, ptr }
  %l63 = alloca i1
  %l64 = alloca { i64, ptr }
  %l80 = alloca i64
  %l83 = alloca i64
  %l92 = alloca i64
  %l95 = alloca i1
  %l105 = alloca { i64, ptr }
  %l110 = alloca i1
  %l113 = alloca i1
  %l121 = alloca i1
  %l124 = alloca i1
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l17, !tbaa !27
  %t2 = load i64, ptr %l1, !tbaa !24
  %t4 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !27
  %t6 = getelementptr i8, ptr %t5, i64 %t2
  %t7 = load i8, ptr %t6, !tbaa !32
  store i8 %t7, ptr %l2, !tbaa !22
  %t9 = load i8, ptr %l2, !tbaa !22
  %t11 = icmp ne i8 %t9, 91
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load i8, ptr %l2, !tbaa !22
  %t15 = icmp ne i8 %t13, 123
  store i1 %t15, ptr %l22, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb3
bb3:
  %t17 = load i1, ptr %l22, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t18 = load i8, ptr %l2, !tbaa !22
  %t20 = icmp ne i8 %t18, 60
  store i1 %t20, ptr %l25, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb6
bb6:
  %t22 = load i1, ptr %l25, !tbaa !21
  br i1 %t22, label %bb7, label %bb8
bb7:
  %t23 = load i64, ptr %l1, !tbaa !24
  store i64 %t23, ptr %l3, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  store i64 %t27, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t29 = load i64, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l3, !tbaa !24
  %t33 = icmp sgt i64 %t29, %t30
  br i1 %t33, label %bb9, label %bb10
bb8:
  br label %bb27
bb9:
  %t35 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp sgt i64 %t35, 0
  br i1 %t37, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb14
bb11:
  %t39 = load i64, ptr %l4, !tbaa !24
  %t40 = load i64, ptr %l3, !tbaa !24
  %t43 = sub i64 %t39, %t40
  %t44 = load i64, ptr %l5, !tbaa !24
  %t47 = add i64 %t43, %t44
  %t49 = sub i64 %t47, 1
  %t50 = load i64, ptr %l5, !tbaa !24
  %t53 = sdiv i64 %t49, %t50
  store i64 %t53, ptr %l37, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb13
bb13:
  %t55 = load i64, ptr %l37, !tbaa !24
  store i64 %t55, ptr %l34, !tbaa !24
  br label %bb14
bb14:
  %t56 = load i64, ptr %l34, !tbaa !24
  store i64 %t56, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  %t57 = load i64, ptr %l6, !tbaa !24
  %t58 = sub i64 %t57, 1
  store i64 %t58, ptr %l46, !tbaa !24
  %t59 = load i64, ptr %l6, !tbaa !24
  %t60 = icmp slt i64 %t59, 2147483648
  %t61 = load i64, ptr %l7, !tbaa !24
  %t62 = icmp sge i64 %t61, 0
  %t65 = and i1 %t60, %t62
  store i1 %t65, ptr %l49, !tbaa !21
  br label %bb15
bb15:
  %t66 = load i64, ptr %l7, !tbaa !24
  %t67 = load i64, ptr %l6, !tbaa !24
  %t70 = icmp slt i64 %t66, %t67
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb16, label %bb17
bb16:
  br label %bb26
bb17:
  br label %bb18
bb18:
  %t74 = load i64, ptr %l3, !tbaa !24
  %t75 = load i64, ptr %l7, !tbaa !24
  %t76 = load i64, ptr %l5, !tbaa !24
  %t79 = mul i64 %t75, %t76
  %t82 = add i64 %t74, %t79
  store i64 %t82, ptr %l8, !tbaa !24
  %t84 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t84, ptr %l59, !tbaa !27
  %t85 = load i64, ptr %l8, !tbaa !24
  %t87 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr i8, ptr %t88, i64 %t85
  %t90 = load i8, ptr %t89, !tbaa !32
  %t92 = icmp eq i8 %t90, 32
  br i1 %t92, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l63, !tbaa !21
  br label %bb21
bb20:
  %t94 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t94, ptr %l64, !tbaa !27
  %t95 = load i64, ptr %l8, !tbaa !24
  %t97 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr i8, ptr %t98, i64 %t95
  %t100 = load i8, ptr %t99, !tbaa !32
  %t102 = icmp eq i8 %t100, 44
  store i1 %t102, ptr %l63, !tbaa !21
  br label %bb21
bb21:
  %t104 = load i1, ptr %l63, !tbaa !21
  br i1 %t104, label %bb22, label %bb23
bb22:
  %t105 = load i64, ptr %l8, !tbaa !24
  store i64 %t105, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t107 = load i64, ptr %l7, !tbaa !24
  %t110 = add i64 %t107, 1
  store i64 %t110, ptr %l7, !tbaa !24
  br label %bb15
bb26:
  %t112 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t112, 0
  store i64 %t114, ptr %rv
  br label %ret
bb27:
  store i64 0, ptr %l9, !tbaa !24
  %t116 = load i64, ptr %l1, !tbaa !24
  store i64 %t116, ptr %l10, !tbaa !24
  %t118 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t118, 0
  store i64 %t120, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t122 = load i64, ptr %l11, !tbaa !24
  %t123 = load i64, ptr %l10, !tbaa !24
  %t126 = icmp sgt i64 %t122, %t123
  br i1 %t126, label %bb28, label %bb29
bb28:
  %t128 = load i64, ptr %l12, !tbaa !24
  %t130 = icmp sgt i64 %t128, 0
  br i1 %t130, label %bb30, label %bb31
bb29:
  store i64 0, ptr %l80, !tbaa !24
  br label %bb33
bb30:
  %t132 = load i64, ptr %l11, !tbaa !24
  %t133 = load i64, ptr %l10, !tbaa !24
  %t136 = sub i64 %t132, %t133
  %t137 = load i64, ptr %l12, !tbaa !24
  %t140 = add i64 %t136, %t137
  %t142 = sub i64 %t140, 1
  %t143 = load i64, ptr %l12, !tbaa !24
  %t146 = sdiv i64 %t142, %t143
  store i64 %t146, ptr %l83, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l83, !tbaa !24
  br label %bb32
bb32:
  %t148 = load i64, ptr %l83, !tbaa !24
  store i64 %t148, ptr %l80, !tbaa !24
  br label %bb33
bb33:
  %t149 = load i64, ptr %l80, !tbaa !24
  store i64 %t149, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  %t150 = load i64, ptr %l13, !tbaa !24
  %t151 = sub i64 %t150, 1
  store i64 %t151, ptr %l92, !tbaa !24
  %t152 = load i64, ptr %l13, !tbaa !24
  %t153 = icmp slt i64 %t152, 2147483648
  %t154 = load i64, ptr %l14, !tbaa !24
  %t155 = icmp sge i64 %t154, 0
  %t158 = and i1 %t153, %t155
  store i1 %t158, ptr %l95, !tbaa !21
  br label %bb34
bb34:
  %t159 = load i64, ptr %l14, !tbaa !24
  %t160 = load i64, ptr %l13, !tbaa !24
  %t163 = icmp slt i64 %t159, %t160
  %t165 = xor i1 %t163, true
  br i1 %t165, label %bb35, label %bb36
bb35:
  br label %bb60
bb36:
  br label %bb37
bb37:
  %t167 = load i64, ptr %l10, !tbaa !24
  %t168 = load i64, ptr %l14, !tbaa !24
  %t169 = load i64, ptr %l12, !tbaa !24
  %t172 = mul i64 %t168, %t169
  %t175 = add i64 %t167, %t172
  store i64 %t175, ptr %l15, !tbaa !24
  %t177 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t177, ptr %l105, !tbaa !27
  %t178 = load i64, ptr %l15, !tbaa !24
  %t180 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !27
  %t182 = getelementptr i8, ptr %t181, i64 %t178
  %t183 = load i8, ptr %t182, !tbaa !32
  store i8 %t183, ptr %l16, !tbaa !22
  %t185 = load i8, ptr %l16, !tbaa !22
  %t187 = icmp eq i8 %t185, 91
  br i1 %t187, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l110, !tbaa !21
  br label %bb40
bb39:
  %t189 = load i8, ptr %l16, !tbaa !22
  %t191 = icmp eq i8 %t189, 123
  store i1 %t191, ptr %l110, !tbaa !21
  br label %bb40
bb40:
  %t193 = load i1, ptr %l110, !tbaa !21
  br i1 %t193, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l113, !tbaa !21
  br label %bb43
bb42:
  %t194 = load i8, ptr %l16, !tbaa !22
  %t196 = icmp eq i8 %t194, 60
  store i1 %t196, ptr %l113, !tbaa !21
  br label %bb43
bb43:
  %t198 = load i1, ptr %l113, !tbaa !21
  br i1 %t198, label %bb44, label %bb45
bb44:
  %t199 = load i64, ptr %l9, !tbaa !24
  %t202 = add i64 %t199, 1
  store i64 %t202, ptr %l9, !tbaa !24
  br label %bb58
bb45:
  %t204 = load i8, ptr %l16, !tbaa !22
  %t206 = icmp eq i8 %t204, 93
  br i1 %t206, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l121, !tbaa !21
  br label %bb48
bb47:
  %t208 = load i8, ptr %l16, !tbaa !22
  %t210 = icmp eq i8 %t208, 125
  store i1 %t210, ptr %l121, !tbaa !21
  br label %bb48
bb48:
  %t212 = load i1, ptr %l121, !tbaa !21
  br i1 %t212, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l124, !tbaa !21
  br label %bb51
bb50:
  %t213 = load i8, ptr %l16, !tbaa !22
  %t215 = icmp eq i8 %t213, 62
  store i1 %t215, ptr %l124, !tbaa !21
  br label %bb51
bb51:
  %t217 = load i1, ptr %l124, !tbaa !21
  br i1 %t217, label %bb52, label %bb53
bb52:
  %t218 = load i64, ptr %l9, !tbaa !24
  %t221 = sub i64 %t218, 1
  store i64 %t221, ptr %l9, !tbaa !24
  %t223 = load i64, ptr %l9, !tbaa !24
  %t225 = icmp eq i64 %t223, 0
  br i1 %t225, label %bb54, label %bb55
bb53:
  br label %bb57
bb54:
  %t227 = load i64, ptr %l15, !tbaa !24
  %t229 = add i64 %t227, 1
  store i64 %t229, ptr %rv
  br label %ret
bb55:
  br label %bb56
bb56:
  br label %bb57
bb57:
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t231 = load i64, ptr %l14, !tbaa !24
  %t234 = add i64 %t231, 1
  store i64 %t234, ptr %l14, !tbaa !24
  br label %bb34
bb60:
  %t236 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t238 = extractvalue { i64, ptr } %t236, 0
  store i64 %t238, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

@.d0 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"declare ptr @__errno_location()\0A" }>, align 8
@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d2 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"call i32 @sigaction(" }>, align 8
@.d3 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"call i32 @__olang_bionic_sigaction(" }>, align 8
@olang_2esole_2ecompiler__2fruntime__2eBionic_2elocal_2e1 = weak hidden constant i1 false
declare void @__olang_region_release(ptr) noinline
@.d4 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"call i64 @sysconf(i32 " }>, align 8
@.d5 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"call i64 @__olang_bionic_sysconf(i32 " }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
@.d7 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"define available_externally " }>, align 8
@.d8 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d9 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"linux" }>, align 8
@.d10 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"target triple = \22" }>, align 8
@.d11 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"\22\0A\0A" }>, align 8
@.d12 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"\0A!20 = !{!\22olang\22}\0A" }>, align 8
@.d13 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"/runtime/" }>, align 8
declare void @__olang_errpay_pop()
@.d14 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d15 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c": cannot open this file" }>, align 8
@.d16 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"windows" }>, align 8
@.d17 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"; @prof " }>, align 8
@.d18 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"; @bench " }>, align 8
@.d19 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"\22; @if\22 inside another" }>, align 8
@.d20 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"!" }>, align 8
@.d21 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d22 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"san" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d23 = private constant <{ i64, [53 x i8] }> <{ i64 0, [53 x i8] c"a condition that is neither \22san\22 nor an architecture" }>, align 8
@.d24 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"san" }>, align 8
@.d25 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"\22; @else\22 with no \22; @if\22 open" }>, align 8
@.d26 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"\22; @end\22 with no \22; @if\22 open" }>, align 8
@.d27 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c";" }>, align 8
@.d28 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"@@" }>, align 8
@.d29 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"@@" }>, align 8
@.d30 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"an \22@@\22 with no \22@@\22 closing it" }>, align 8
@.d31 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"an @@NAME@@ the compiler knows no fact for" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d32 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"\22; @if\22 with no \22; @end\22" }>, align 8
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2ecompiler__2fruntime__2eIr_2elocal_2e9 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle_in(ptr, ptr)
@.d33 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"android" }>, align 8
@.d34 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"windows" }>, align 8
@.d35 = private constant <{ i64, [45 x i8] }> <{ i64 0, [45 x i8] c"@__olang_tile_on = internal constant i1 false" }>, align 8
@.d36 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c"@__olang_tile_on = internal constant i1 true" }>, align 8
@olang_2esole_2estd_2fprelude_2ftext_3aLineIter_2e0 = weak hidden constant i1 false
@.d37 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"target triple = \22" }>, align 8
@.d38 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"\22\0A\0A" }>, align 8
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@.d39 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"dyncall.ll" }>, align 8
@olang_2esole_2ecompiler__2fruntime__2eText_2elocal_2e6 = weak hidden constant i1 false
@.d40 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"runtime.ll" }>, align 8
@.d41 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"san.ll" }>, align 8
@.d42 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d43 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"prof.ll" }>, align 8
@.d44 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d45 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"windows.ll" }>, align 8
@.d46 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"windows" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d47 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"define " }>, align 8
@olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2e0 = weak hidden constant i1 false
@.d48 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d49 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"define " }>, align 8
@.d50 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"declare " }>, align 8
@olang_2esole_2ecompiler__2fruntime__2eWindows_2elocal_2e10 = weak hidden constant i1 false
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d51 = private constant <{ i64, [61 x i8] }> <{ i64 0, [61 x i8] c"\0A; B12f: the runtime's Windows part, as runtime.Windows says\0A" }>, align 8
@.d52 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d53 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c" = linkonce_odr " }>, align 8
@.d54 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d55 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"$" }>, align 8
@.d56 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c" = comdat any\0A" }>, align 8
@.d57 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", comdat\0A" }>, align 8
@.d58 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"define " }>, align 8
@.d59 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"{" }>, align 8
@.d60 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" !dbg " }>, align 8
@.d61 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"@__olang_crash_handler(" }>, align 8
@.d62 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"@__olang_crash_say(" }>, align 8
@.d63 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"@__olang_san_handler(" }>, align 8
@.d64 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" #1" }>, align 8
@.d65 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" #0" }>, align 8
@.d66 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"#1 {" }>, align 8
@.d67 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"#0 {" }>, align 8
@.d68 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"sanitize_thread " }>, align 8
@.d69 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d70 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"\0Aattributes #0 = { null_pointer_is_valid " }>, align 8
@.d71 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" nounwind }\0A" }>, align 8
@.d72 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"attributes #1 = { null_pointer_is_valid " }>, align 8
@.d73 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" nounwind }\0A" }>, align 8
@.d74 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"declare " }>, align 8
@.d75 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"%" }>, align 8
@.d76 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" = type " }>, align 8
@.d77 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d78 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" = external " }>, align 8
@.d79 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"define internal " }>, align 8
@.d80 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"define private " }>, align 8
@.d81 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" = internal " }>, align 8
@.d82 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c" = private " }>, align 8
@.d83 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"define " }>, align 8
@.d84 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d85 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"declare " }>, align 8
@.d86 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d87 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d88 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
declare ptr @__olang_scope_of(ptr, ptr) noinline
@.d89 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"{" }>, align 8
@.d90 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d91 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d92 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d93 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d94 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" = external " }>, align 8
@.d95 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"thread_local(" }>, align 8
@.d96 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d97 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d98 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"unnamed_addr " }>, align 8
@.d99 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d100 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d101 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"; @" }>, align 8
@.d102 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d103 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"if" }>, align 8
@.d104 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"else" }>, align 8
@.d105 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"end" }>, align 8
@.d106 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d107 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d108 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d109 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"define " }>, align 8
@.d110 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"define internal " }>, align 8
@.d111 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"define private " }>, align 8
@.d112 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"alwaysinline" }>, align 8
@.d113 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"inlinehint" }>, align 8
@.d114 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
declare { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@G_2ecompiler_2fruntime_2eBionicShims = external constant <{ [8 x i8], ptr }>
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_4678f23b07212b71_6204d41da44925a5 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
@G_2ecompiler_2fruntime_2eHeaderTbaa = external constant <{ [8 x i8], ptr }>
declare { i64, ptr } @compiler_2fload_2eStdDir(ptr %v0)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @std_2fio_2ePutErrLn_3cstd_2fprelude_2ftext_3aString_3e({ i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_6e9edb7ac3cc3a13_be559f1d61e4dd6f = external constant [0 x i8]
@olang_loc_6e8de55f6b48d5b6_301f420811d0f7f2 = external constant [0 x i8]
@olang_loc_37c6cc80b337eb95_eeee9a64b49e7a71 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_5fea096add1795b8_392858cd9c11d804 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_b0282b0bffd0a537_97cbf26a9ab19d0b = external constant [0 x i8]
@G_2ecompiler_2fruntime_2eArchs = external constant <{ [8 x i8], ptr, [8 x i8], ptr }>
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_70ff22b8cac083da_c5bb23930b7510e = external constant [0 x i8]
@olang_loc_fb2acf0450ba6c79_597b56b8350f036d = external constant [0 x i8]
@olang_loc_4e5c01328741d84c_96bd53a062766590 = external constant [0 x i8]
@olang_loc_c5a935a141e6de44_d4317e5b19ef6ea0 = external constant [0 x i8]
@olang_loc_6b7f8dd3ec23cfae_1ccbdaa919c4683a = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i1 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2fruntime_2eWinFrom = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
@G_2ecompiler_2fruntime_2eWinTo = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
@olang_loc_48912347760bc49b_7f197caf3eb31ff7 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_606763d33345b49e_888ff486d8884e9a = external constant [0 x i8]
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_dc19f5cc01bc83fd_c395ac342fa7af39 = external constant [0 x i8]
@olang_loc_ea39e132cd3efa0c_1aef6a820179ae38 = external constant [0 x i8]
@olang_loc_d8a12b6fe56d9e39_f2cc2d97d79a0415 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_9d9b73c28e4e3d9a_299346768faaee36 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_9424fbeaf4790ef7_29a43c91e82e5293 = external constant [0 x i8]
@olang_loc_15c1087a8dcee578_9616249aba3f0cc = external constant [0 x i8]
@olang_loc_37b9d9dde30c0555_b630301b751c84f9 = external constant [0 x i8]
@olang_loc_2446b89a84efdb76_2c0483cfef229c5a = external constant [0 x i8]
@olang_loc_d4a9c3df34bd8bd3_6b2d8c232432bdb7 = external constant [0 x i8]
@olang_loc_885af16d4a3d8d64_d0eb96c61f9dafb0 = external constant [0 x i8]
@olang_loc_383c318151cd7051_6709cfbf24f79c8d = external constant [0 x i8]
@olang_loc_b26c87ed9711b455_3749eb6f37e52fe9 = external constant [0 x i8]
@olang_loc_6a493f8daef1bb51_6724bcad8f2aca45 = external constant [0 x i8]
@olang_loc_ba67ff79a761d864_bc768279035b5e68 = external constant [0 x i8]
@G_2ecompiler_2fruntime_2eFactNames = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
@G_2ecompiler_2fruntime_2eFactWin = available_externally constant <{ [120 x i8] }> <{ [120 x i8] c"\90\00\00\00\00\00\00\00\18\00\00\00\00\00\00\00\30\00\00\00\00\00\00\00\58\00\00\00\00\00\00\00\60\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\50\00\00\00\00\00\00\00\38\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\98\00\00\00\00\00\00\00\88\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\F8\00\00\00\00\00\00\00\A0\00\00\00\00\00\00\00\98\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2fruntime_2eFactX86 = available_externally constant <{ [120 x i8] }> <{ [120 x i8] c"\90\00\00\00\00\00\00\00\18\00\00\00\00\00\00\00\30\00\00\00\00\00\00\00\58\00\00\00\00\00\00\00\60\00\00\00\00\00\00\00\13\00\00\00\00\00\00\00\50\00\00\00\00\00\00\00\38\00\00\00\00\00\00\00\C8\00\00\00\00\00\00\00\98\00\00\00\00\00\00\00\88\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\A8\00\00\00\00\00\00\00\78\00\00\00\00\00\00\00\A0\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2fruntime_2eFactArm = available_externally constant <{ [120 x i8] }> <{ [120 x i8] c"\80\00\00\00\00\00\00\00\10\00\00\00\00\00\00\00\30\00\00\00\00\00\00\00\58\00\00\00\00\00\00\00\60\00\00\00\00\00\00\00\13\00\00\00\00\00\00\00\50\00\00\00\00\00\00\00\40\00\00\00\00\00\00\00\38\01\00\00\00\00\00\00\98\00\00\00\00\00\00\00\88\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\B8\01\00\00\00\00\00\00\A0\01\00\00\00\00\00\00\B0\01\00\00\00\00\00\00" }>, align 64
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %a0, i8 %a1)
@olang_loc_b70188616b037137_b122dd4ae5a41093 = external constant [0 x i8]
@olang_loc_77d8800e35f34fda_b111e72f8d20ac36 = external constant [0 x i8]
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
