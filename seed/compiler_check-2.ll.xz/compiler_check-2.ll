; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, [3 x i64] }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, { i64, [2 x i64] }, i32, i1 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1 }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i32, i64, i64, i64, i1, i64, i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/check:b5aWalk" = type { i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr } }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1 }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] } }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/check:errBind" = type { i32, i64, i32, %"compiler/source:Span" }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/check:litv" = type { i1, i1, i1, i64, double, i1 }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
%"compiler/check:ContractAsk" = type { i64, i64, %"compiler/source:Span", i64, %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, [3 x i64] }, { i64, ptr }, { i64, ptr } }
%"compiler/check:ctSource" = type { ptr, ptr, { i64, ptr }, i64, { i64, ptr } }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i32, %"compiler/source:Span" }
%"compiler/typed:ContractInfo" = type { { i64, ptr }, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr }
%"compiler/ast:If" = type { ptr, ptr, ptr }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/check:roFn" = type { i64, i64, { i64, [3 x i64] }, { i64, ptr } }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, ptr, i1 }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr }, ptr }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/ast:Multi" = type { { i64, ptr }, i1, { i64, ptr } }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1 }
%"compiler/check:rawTable" = type { i32, i1, { i64, ptr }, { i64, ptr } }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32 }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr }
%"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" = type { i32, i64 }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr } }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/check:Gap" = type { i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/diag:Said" = type { { i64, ptr }, i64, i64, { i64, ptr } }
%"compiler/check:errNarrow" = type { i64, i32, i64 }
%"compiler/check:nullNarrow" = type { { i64, ptr }, i64, i1 }
define dso_local i1 @compiler_2fcheck_2eassignsWhole(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l17 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i1
  %l25 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t24, i32 0, i32 3
  %t26 = load ptr, ptr %t25
  store ptr %t26, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb14
bb5:
  %t28 = load i32, ptr %l2
  %t30 = trunc i64 57 to i32
  %t31 = icmp eq i32 %t28, %t30
  br i1 %t31, label %bb6, label %bb7
bb6:
  %t33 = load ptr, ptr %l3, !tbaa !29
  %t34 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t37 = call i1 @compiler_2fcheck_2ehitsPath(ptr %v0, ptr %v1, ptr %t33, { i64, ptr } %t34)
  store i1 %t37, ptr %l20
  br label %bb8
bb7:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb9
bb8:
  %t38 = load i1, ptr %l20, !tbaa !21
  store i1 %t38, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t39 = load i1, ptr %l17, !tbaa !21
  br i1 %t39, label %bb10, label %bb11
bb10:
  %t40 = load ptr, ptr %l4, !tbaa !29
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t45 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t40, { i64, ptr } %t42)
  store i1 %t45, ptr %l25
  br label %bb12
bb11:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb13
bb12:
  %t46 = load i1, ptr %l25, !tbaa !21
  %t47 = xor i1 %t46, true
  store i1 %t47, ptr %l21, !tbaa !21
  br label %bb13
bb13:
  %t49 = load i1, ptr %l21, !tbaa !21
  store i1 %t49, ptr %rv
  br label %ret
bb14:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ebangOf(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l13 = alloca { i64, ptr }
  %l18 = alloca i1
  %l25 = alloca i1
  %l32 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i8, ptr %t19, i64 %t16
  %t21 = load i8, ptr %t20, !tbaa !32
  store i8 %t21, ptr %l5, !tbaa !22
  %t23 = load i8, ptr %l5, !tbaa !22
  %t25 = icmp eq i8 %t23, 40
  br i1 %t25, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb7
bb6:
  %t27 = load i8, ptr %l5, !tbaa !22
  %t29 = icmp eq i8 %t27, 91
  store i1 %t29, ptr %l18, !tbaa !21
  br label %bb7
bb7:
  %t31 = load i1, ptr %l18, !tbaa !21
  br i1 %t31, label %bb8, label %bb9
bb8:
  %t32 = load i64, ptr %l1, !tbaa !24
  %t34 = add i64 %t32, 1
  store i64 %t34, ptr %l1, !tbaa !24
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t36 = load i8, ptr %l5, !tbaa !22
  %t38 = icmp eq i8 %t36, 41
  br i1 %t38, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb13
bb12:
  %t40 = load i8, ptr %l5, !tbaa !22
  %t42 = icmp eq i8 %t40, 93
  store i1 %t42, ptr %l25, !tbaa !21
  br label %bb13
bb13:
  %t44 = load i1, ptr %l25, !tbaa !21
  br i1 %t44, label %bb14, label %bb15
bb14:
  %t45 = load i64, ptr %l1, !tbaa !24
  %t47 = sub i64 %t45, 1
  store i64 %t47, ptr %l1, !tbaa !24
  br label %bb16
bb15:
  br label %bb16
bb16:
  %t49 = load i8, ptr %l5, !tbaa !22
  %t51 = icmp eq i8 %t49, 32
  br i1 %t51, label %bb17, label %bb18
bb17:
  %t53 = load i64, ptr %l1, !tbaa !24
  %t55 = icmp eq i64 %t53, 0
  store i1 %t55, ptr %l32, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb19
bb19:
  %t57 = load i1, ptr %l32, !tbaa !21
  br i1 %t57, label %bb20, label %bb21
bb20:
  %t58 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t59 = extractvalue { i64, ptr } { i64 1, ptr @.d0 }, 1
  %t60 = extractvalue { i64, ptr } { i64 1, ptr @.d0 }, 0
  %t62 = extractvalue { i64, ptr } %t58, 1
  %t63 = extractvalue { i64, ptr } %t58, 0
  %t64 = add i64 %t60, %t63
  %t65 = extractvalue { i64, ptr } { i64 1, ptr @.d1 }, 1
  %t66 = extractvalue { i64, ptr } { i64 1, ptr @.d1 }, 0
  %t67 = add i64 %t64, %t66
  %t68 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t67)
  call void @olang_textcopy(ptr %t68, ptr %t59, i64 %t60)
  %t69 = getelementptr i8, ptr %t68, i64 %t60
  call void @olang_textcopy(ptr %t69, ptr %t62, i64 %t63)
  %t70 = getelementptr i8, ptr %t69, i64 %t63
  call void @olang_textcopy(ptr %t70, ptr %t65, i64 %t66)
  %t71 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t68, 1
  call void @__olang_scope_close(ptr %s2)
  store { i64, ptr } %t72, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb23:
  %t74 = load i64, ptr %l3, !tbaa !24
  %t76 = add i64 %t74, 1
  store i64 %t76, ptr %l3, !tbaa !24
  br label %bb1
bb24:
  %t78 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t78, 1
  %t81 = extractvalue { i64, ptr } %t78, 0
  %t82 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t81)
  call void @olang_textcopy(ptr %t82, ptr %t80, i64 %t81)
  %t83 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  store { i64, ptr } %t84, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2ecallLike(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l27 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 12
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t11 = load ptr, ptr %l7, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l7, !tbaa !29
  %t15 = load i64, ptr %t14
  %t17 = icmp eq i64 %t15, 13
  store i1 %t17, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l8, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t21 = load ptr, ptr %l12, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb11, label %bb12
bb11:
  %t24 = load ptr, ptr %l12, !tbaa !29
  %t25 = load i64, ptr %t24
  %t27 = icmp eq i64 %t25, 2
  store i1 %t27, ptr %l13, !tbaa !21
  br label %bb12
bb12:
  %t28 = load i1, ptr %l13, !tbaa !21
  br i1 %t28, label %bb13, label %bb14
bb13:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", ptr }, ptr %t31, i32 0, i32 1
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l1, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = call i1 @compiler_2fcheck_2ecallLike(ptr %v0, ptr %t35)
  store i1 %t37, ptr %l19
  br label %bb16
bb16:
  %t38 = load i1, ptr %l19, !tbaa !21
  store i1 %t38, ptr %rv
  br label %ret
bb17:
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t40 = load ptr, ptr %l20, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb18, label %bb19
bb18:
  %t43 = load ptr, ptr %l20, !tbaa !29
  %t44 = load i64, ptr %t43
  %t46 = icmp eq i64 %t44, 22
  store i1 %t46, ptr %l21, !tbaa !21
  br label %bb19
bb19:
  %t47 = load i1, ptr %l21, !tbaa !21
  br i1 %t47, label %bb20, label %bb21
bb20:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr { i64, [5 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t50, i32 0, i32 1
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l2, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t54 = load ptr, ptr %l2, !tbaa !29
  %t56 = call i1 @compiler_2fcheck_2ecallLike(ptr %v0, ptr %t54)
  store i1 %t56, ptr %l27
  br label %bb23
bb23:
  %t57 = load i1, ptr %l27, !tbaa !21
  store i1 %t57, ptr %rv
  br label %ret
bb24:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eclosedPlace(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l18 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l26 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l35 = alloca i1
  %l36 = alloca i1
  %l39 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i1
  %l48 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i1
  %l56 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb50
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t11 = load ptr, ptr %l11, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l11, !tbaa !29
  %t15 = load i64, ptr %t14
  %t17 = icmp eq i64 %t15, 2
  store i1 %t17, ptr %l12, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l12, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l1, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = call i1 @compiler_2fcheck_2eclosedExpr(ptr %v0, ptr %t25)
  store i1 %t27, ptr %l18
  br label %bb12
bb12:
  %t28 = load i1, ptr %l18, !tbaa !21
  store i1 %t28, ptr %l6, !tbaa !21
  br label %bb50
bb13:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t30 = load ptr, ptr %l19, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb14, label %bb15
bb14:
  %t33 = load ptr, ptr %l19, !tbaa !29
  %t34 = load i64, ptr %t33
  %t36 = icmp eq i64 %t34, 3
  store i1 %t36, ptr %l20, !tbaa !21
  br label %bb15
bb15:
  %t37 = load i1, ptr %l20, !tbaa !21
  br i1 %t37, label %bb16, label %bb17
bb16:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l2, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t46 = call i1 @compiler_2fcheck_2eclosedPlace(ptr %v0, ptr %t44)
  store i1 %t46, ptr %l26
  br label %bb19
bb19:
  %t47 = load i1, ptr %l26, !tbaa !21
  store i1 %t47, ptr %l6, !tbaa !21
  br label %bb50
bb20:
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t49 = load ptr, ptr %l27, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb21, label %bb22
bb21:
  %t52 = load ptr, ptr %l27, !tbaa !29
  %t53 = load i64, ptr %t52
  %t55 = icmp eq i64 %t53, 4
  store i1 %t55, ptr %l28, !tbaa !21
  br label %bb22
bb22:
  %t56 = load i1, ptr %l28, !tbaa !21
  br i1 %t56, label %bb23, label %bb24
bb23:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr { i64, [4 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t59, i32 0, i32 2
  %t61 = load ptr, ptr %t60
  store ptr %t61, ptr %l3, !tbaa !29
  br label %bb25
bb24:
  br label %bb31
bb25:
  %t63 = load ptr, ptr %l3, !tbaa !29
  %t65 = getelementptr %"compiler/typed:Elem", ptr %t63, i32 0, i32 0
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = call i1 @compiler_2fcheck_2eclosedPlace(ptr %v0, ptr %t66)
  store i1 %t68, ptr %l35
  br label %bb26
bb26:
  %t69 = load i1, ptr %l35, !tbaa !21
  br i1 %t69, label %bb27, label %bb28
bb27:
  %t70 = load ptr, ptr %l3, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Elem", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = call i1 @compiler_2fcheck_2eclosedExpr(ptr %v0, ptr %t73)
  store i1 %t75, ptr %l39
  br label %bb29
bb28:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb30
bb29:
  %t76 = load i1, ptr %l39, !tbaa !21
  store i1 %t76, ptr %l36, !tbaa !21
  br label %bb30
bb30:
  %t77 = load i1, ptr %l36, !tbaa !21
  store i1 %t77, ptr %l6, !tbaa !21
  br label %bb50
bb31:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t79 = load ptr, ptr %l40, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb32, label %bb33
bb32:
  %t82 = load ptr, ptr %l40, !tbaa !29
  %t83 = load i64, ptr %t82
  %t85 = icmp eq i64 %t83, 5
  store i1 %t85, ptr %l41, !tbaa !21
  br label %bb33
bb33:
  %t86 = load i1, ptr %l41, !tbaa !21
  br i1 %t86, label %bb34, label %bb35
bb34:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 2
  %t91 = load ptr, ptr %t90
  store ptr %t91, ptr %l4, !tbaa !29
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t93 = load ptr, ptr %l4, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Payload", ptr %t93, i32 0, i32 0
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = call i1 @compiler_2fcheck_2eclosedPlace(ptr %v0, ptr %t96)
  store i1 %t98, ptr %l48
  br label %bb37
bb37:
  %t99 = load i1, ptr %l48, !tbaa !21
  store i1 %t99, ptr %l6, !tbaa !21
  br label %bb50
bb38:
  %t100 = load ptr, ptr %l0, !tbaa !29
  store ptr %t100, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t101 = load ptr, ptr %l49, !tbaa !29
  %t102 = icmp ne ptr %t101, null
  br i1 %t102, label %bb39, label %bb40
bb39:
  %t104 = load ptr, ptr %l49, !tbaa !29
  %t105 = load i64, ptr %t104
  %t107 = icmp eq i64 %t105, 6
  store i1 %t107, ptr %l50, !tbaa !21
  br label %bb40
bb40:
  %t108 = load i1, ptr %l50, !tbaa !21
  br i1 %t108, label %bb41, label %bb42
bb41:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr { i64, [4 x i64] }, ptr %t109, i32 0, i32 1
  %t112 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t111, i32 0, i32 2
  %t113 = load ptr, ptr %t112
  store ptr %t113, ptr %l5, !tbaa !29
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t115 = load ptr, ptr %l5, !tbaa !29
  %t117 = call i1 @compiler_2fcheck_2eclosedExpr(ptr %v0, ptr %t115)
  store i1 %t117, ptr %l56
  br label %bb44
bb44:
  %t118 = load i1, ptr %l56, !tbaa !21
  store i1 %t118, ptr %l6, !tbaa !21
  br label %bb50
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_3ee32a1caa2e355c_4063d0a06727bdc8)
  unreachable
bb50:
  %t119 = load i1, ptr %l6, !tbaa !21
  store i1 %t119, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyDeclaresNames(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l17 = alloca { i64, ptr }
  %l23 = alloca i1
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t35 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresNames(ptr %v0, ptr %v1, ptr %a0, ptr %t28)
  store i1 %t35, ptr %l23
  br label %bb8
bb8:
  %t36 = load i1, ptr %l23, !tbaa !21
  br i1 %t36, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb4
bb13:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyScopesAgree(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca %"compiler/types:Table"
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l23 = alloca %"compiler/types:Table"
  %l24 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l32 = alloca i32
  %l33 = alloca { i64, ptr }
  %l45 = alloca i64
  %l48 = alloca i64
  %l69 = alloca i64
  %l73 = alloca i64
  %l80 = alloca { i64, ptr }
  %l86 = alloca i64
  %l89 = alloca i64
  %l110 = alloca i64
  %l114 = alloca i64
  %l118 = alloca i1
  %l122 = alloca i1
  %l126 = alloca i1
  %l130 = alloca i1
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca i1
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %l23, ptr %t6, i64 256, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %l23, i64 256, i1 false)
  store ptr %l3, ptr %l24, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %l3, i32 %t7)
  store i32 %t10, ptr %l27
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l24, !tbaa !29
  %t12 = load i32, ptr %l27, !tbaa !23
  %t13 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t11, i32 %t12)
  store { i64, ptr } %t13, ptr %l28
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t14, ptr %l4, !tbaa !27
  store ptr %l3, ptr %l29, !tbaa !29
  %t15 = load i32, ptr %l2, !tbaa !23
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %l3, i32 %t15)
  store i32 %t18, ptr %l32
  br label %bb3
bb3:
  %t19 = load ptr, ptr %l29, !tbaa !29
  %t20 = load i32, ptr %l32, !tbaa !23
  %t21 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t19, i32 %t20)
  store { i64, ptr } %t21, ptr %l33
  br label %bb4
bb4:
  %t22 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t28 = extractvalue { i64, ptr } %t22, 0
  %t31 = icmp ne i64 %t25, %t28
  br i1 %t31, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  store i64 1, ptr %l6, !tbaa !24
  %t34 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t34, 0
  store i64 %t36, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t38 = load i64, ptr %l7, !tbaa !24
  %t39 = load i64, ptr %l6, !tbaa !24
  %t42 = icmp sgt i64 %t38, %t39
  br i1 %t42, label %bb8, label %bb9
bb8:
  %t44 = load i64, ptr %l8, !tbaa !24
  %t46 = icmp sgt i64 %t44, 0
  br i1 %t46, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb13
bb10:
  %t48 = load i64, ptr %l7, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = sub i64 %t48, %t49
  %t53 = load i64, ptr %l8, !tbaa !24
  %t56 = add i64 %t52, %t53
  %t58 = sub i64 %t56, 1
  %t59 = load i64, ptr %l8, !tbaa !24
  %t62 = sdiv i64 %t58, %t59
  store i64 %t62, ptr %l48, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l48, !tbaa !24
  br label %bb12
bb12:
  %t64 = load i64, ptr %l48, !tbaa !24
  store i64 %t64, ptr %l45, !tbaa !24
  br label %bb13
bb13:
  %t65 = load i64, ptr %l45, !tbaa !24
  store i64 %t65, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t66 = load i64, ptr %l10, !tbaa !24
  %t67 = load i64, ptr %l9, !tbaa !24
  %t70 = icmp slt i64 %t66, %t67
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb16:
  br label %bb17
bb17:
  %t74 = load i64, ptr %l6, !tbaa !24
  %t75 = load i64, ptr %l10, !tbaa !24
  %t76 = load i64, ptr %l8, !tbaa !24
  %t79 = mul i64 %t75, %t76
  %t82 = add i64 %t74, %t79
  store i64 %t82, ptr %l11, !tbaa !24
  %t84 = load i32, ptr %l1, !tbaa !23
  %t85 = load i64, ptr %l11, !tbaa !24
  %t89 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %l3, i32 %t84, i64 %t85)
  store i64 %t89, ptr %l69
  br label %bb18
bb18:
  %t90 = load i32, ptr %l2, !tbaa !23
  %t91 = load i64, ptr %l11, !tbaa !24
  %t95 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %l3, i32 %t90, i64 %t91)
  store i64 %t95, ptr %l73
  br label %bb19
bb19:
  %t96 = load i64, ptr %l69, !tbaa !24
  %t97 = load i64, ptr %l73, !tbaa !24
  %t98 = icmp ne i64 %t96, %t97
  br i1 %t98, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb23:
  %t101 = load i64, ptr %l10, !tbaa !24
  %t103 = add i64 %t101, 1
  store i64 %t103, ptr %l10, !tbaa !24
  br label %bb14
bb24:
  %t105 = load i32, ptr %l1, !tbaa !23
  %t108 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s0, ptr %l3, i32 %t105)
  store { i64, ptr } %t108, ptr %l80
  br label %bb25
bb25:
  %t109 = load { i64, ptr }, ptr %l80, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t112 = extractvalue { i64, ptr } %t109, 0
  store i64 %t112, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t114 = load i64, ptr %l14, !tbaa !24
  %t115 = load i64, ptr %l13, !tbaa !24
  %t118 = icmp sgt i64 %t114, %t115
  br i1 %t118, label %bb26, label %bb27
bb26:
  %t120 = load i64, ptr %l15, !tbaa !24
  %t122 = icmp sgt i64 %t120, 0
  br i1 %t122, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l86, !tbaa !24
  br label %bb31
bb28:
  %t124 = load i64, ptr %l14, !tbaa !24
  %t125 = load i64, ptr %l13, !tbaa !24
  %t128 = sub i64 %t124, %t125
  %t129 = load i64, ptr %l15, !tbaa !24
  %t132 = add i64 %t128, %t129
  %t134 = sub i64 %t132, 1
  %t135 = load i64, ptr %l15, !tbaa !24
  %t138 = sdiv i64 %t134, %t135
  store i64 %t138, ptr %l89, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l89, !tbaa !24
  br label %bb30
bb30:
  %t140 = load i64, ptr %l89, !tbaa !24
  store i64 %t140, ptr %l86, !tbaa !24
  br label %bb31
bb31:
  %t141 = load i64, ptr %l86, !tbaa !24
  store i64 %t141, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s7
  %t142 = load i64, ptr %l17, !tbaa !24
  %t143 = load i64, ptr %l16, !tbaa !24
  %t146 = icmp slt i64 %t142, %t143
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s7)
  br label %bb54
bb34:
  br label %bb35
bb35:
  %t150 = load i64, ptr %l13, !tbaa !24
  %t151 = load i64, ptr %l17, !tbaa !24
  %t152 = load i64, ptr %l15, !tbaa !24
  %t155 = mul i64 %t151, %t152
  %t158 = add i64 %t150, %t155
  store i64 %t158, ptr %l18, !tbaa !24
  %t160 = load i32, ptr %l1, !tbaa !23
  %t161 = load i64, ptr %l18, !tbaa !24
  %t165 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %l3, i32 %t160, i64 %t161)
  store i64 %t165, ptr %l110
  br label %bb36
bb36:
  %t166 = load i64, ptr %l110, !tbaa !24
  store i64 %t166, ptr %l19, !tbaa !24
  %t167 = load i32, ptr %l2, !tbaa !23
  %t168 = load i64, ptr %l18, !tbaa !24
  %t172 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %l3, i32 %t167, i64 %t168)
  store i64 %t172, ptr %l114
  br label %bb37
bb37:
  %t173 = load i64, ptr %l114, !tbaa !24
  store i64 %t173, ptr %l20, !tbaa !24
  %t174 = load i64, ptr %l19, !tbaa !24
  %t175 = load i64, ptr %l20, !tbaa !24
  %t178 = icmp ne i64 %t174, %t175
  br i1 %t178, label %bb38, label %bb39
bb38:
  %t180 = load i64, ptr %l19, !tbaa !24
  %t181 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t184 = icmp eq i64 %t180, %t181
  br i1 %t184, label %bb40, label %bb41
bb39:
  store i1 false, ptr %l118, !tbaa !21
  br label %bb49
bb40:
  store i1 true, ptr %l122, !tbaa !21
  br label %bb42
bb41:
  %t186 = load i64, ptr %l19, !tbaa !24
  %t187 = load i64, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  %t190 = icmp eq i64 %t186, %t187
  store i1 %t190, ptr %l122, !tbaa !21
  br label %bb42
bb42:
  %t192 = load i1, ptr %l122, !tbaa !21
  br i1 %t192, label %bb43, label %bb44
bb43:
  %t193 = load i64, ptr %l20, !tbaa !24
  %t194 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t197 = icmp eq i64 %t193, %t194
  br i1 %t197, label %bb45, label %bb46
bb44:
  store i1 false, ptr %l126, !tbaa !21
  br label %bb48
bb45:
  store i1 true, ptr %l130, !tbaa !21
  br label %bb47
bb46:
  %t199 = load i64, ptr %l20, !tbaa !24
  %t200 = load i64, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  %t203 = icmp eq i64 %t199, %t200
  store i1 %t203, ptr %l130, !tbaa !21
  br label %bb47
bb47:
  %t205 = load i1, ptr %l130, !tbaa !21
  store i1 %t205, ptr %l126, !tbaa !21
  br label %bb48
bb48:
  %t206 = load i1, ptr %l126, !tbaa !21
  %t207 = xor i1 %t206, true
  store i1 %t207, ptr %l118, !tbaa !21
  br label %bb49
bb49:
  %t209 = load i1, ptr %l118, !tbaa !21
  br i1 %t209, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb51:
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s7)
  br label %bb53
bb53:
  %t211 = load i64, ptr %l17, !tbaa !24
  %t213 = add i64 %t211, 1
  store i64 %t213, ptr %l17, !tbaa !24
  br label %bb32
bb54:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earmPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l23 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l35 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i1
  %l48 = alloca i1
  %l50 = alloca { i64, ptr }
  %l52 = alloca %"compiler/source:Span"
  %l54 = alloca %"compiler/source:Span"
  %l56 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l67 = alloca i1
  %l71 = alloca i1
  %l72 = alloca ptr
  %l73 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca i1
  %l82 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t7 = load ptr, ptr %l10, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l10, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 3
  store i1 %t13, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l11, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  store i1 true, ptr %rv
  br label %ret
bb9:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t17 = load ptr, ptr %l15, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb10, label %bb11
bb10:
  %t20 = load ptr, ptr %l15, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 2
  store i1 %t23, ptr %l16, !tbaa !21
  br label %bb11
bb11:
  %t24 = load i1, ptr %l16, !tbaa !21
  br i1 %t24, label %bb12, label %bb13
bb12:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t27, i32 0, i32 1
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l2, !tbaa !23
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l2, !tbaa !23
  %t35 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l23
  br label %bb15
bb15:
  %t36 = load i1, ptr %l23, !tbaa !21
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %rv
  br label %ret
bb16:
  %t39 = load ptr, ptr %l1, !tbaa !29
  store ptr %t39, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t40 = load ptr, ptr %l25, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb17, label %bb18
bb17:
  %t43 = load ptr, ptr %l25, !tbaa !29
  %t44 = load i64, ptr %t43
  %t46 = icmp eq i64 %t44, 5
  store i1 %t46, ptr %l26, !tbaa !21
  br label %bb18
bb18:
  %t47 = load i1, ptr %l26, !tbaa !21
  br i1 %t47, label %bb19, label %bb20
bb19:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr { i64, [5 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t50, i32 0, i32 2
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l3, !tbaa !29
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Promote", ptr %t55, i32 0, i32 0
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t62 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earmPlace(ptr %v0, ptr %v1, ptr %t54, ptr %t58)
  store i1 %t62, ptr %l35
  br label %bb22
bb22:
  %t63 = load i1, ptr %l35, !tbaa !21
  store i1 %t63, ptr %rv
  br label %ret
bb23:
  %t64 = load ptr, ptr %l1, !tbaa !29
  store ptr %t64, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t65 = load ptr, ptr %l36, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb24, label %bb25
bb24:
  %t68 = load ptr, ptr %l36, !tbaa !29
  %t69 = load i64, ptr %t68
  %t71 = icmp eq i64 %t69, 6
  store i1 %t71, ptr %l37, !tbaa !21
  br label %bb25
bb25:
  %t72 = load i1, ptr %l37, !tbaa !21
  br i1 %t72, label %bb26, label %bb27
bb26:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [5 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t75, i32 0, i32 0
  %t77 = load %"compiler/source:Span", ptr %t76
  store %"compiler/source:Span" %t77, ptr %l4
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr { i64, [5 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t81, i32 0, i32 2
  %t83 = load ptr, ptr %t82
  store ptr %t83, ptr %l5, !tbaa !29
  br label %bb28
bb27:
  br label %bb34
bb28:
  %t85 = load ptr, ptr %l5, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Call", ptr %t85, i32 0, i32 1
  %t88 = load { i64, ptr }, ptr %t87, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t88, 0
  %t92 = icmp sgt i64 %t90, 0
  br i1 %t92, label %bb29, label %bb30
bb29:
  %t94 = load ptr, ptr %l5, !tbaa !29
  %t96 = getelementptr %"compiler/typed:Call", ptr %t94, i32 0, i32 1
  %t97 = load { i64, ptr }, ptr %t96, !tbaa !27
  store { i64, ptr } %t97, ptr %l50, !tbaa !27
  %t98 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr ptr, ptr %t99, i64 0
  %t101 = load ptr, ptr %t100, !tbaa !39
  %t103 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t101)
  store %"compiler/source:Span" %t103, ptr %l52
  br label %bb31
bb30:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb33
bb31:
  %t104 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t104, ptr %l54
  %t107 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %l52, ptr %l54)
  store i1 %t107, ptr %l56
  br label %bb32
bb32:
  %t108 = load i1, ptr %l56, !tbaa !21
  store i1 %t108, ptr %l48, !tbaa !21
  br label %bb33
bb33:
  %t109 = load i1, ptr %l48, !tbaa !21
  store i1 %t109, ptr %rv
  br label %ret
bb34:
  %t110 = load ptr, ptr %l1, !tbaa !29
  store ptr %t110, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t111 = load ptr, ptr %l57, !tbaa !29
  %t112 = icmp ne ptr %t111, null
  br i1 %t112, label %bb35, label %bb36
bb35:
  %t114 = load ptr, ptr %l57, !tbaa !29
  %t115 = load i64, ptr %t114
  %t117 = icmp eq i64 %t115, 14
  store i1 %t117, ptr %l58, !tbaa !21
  br label %bb36
bb36:
  %t118 = load i1, ptr %l58, !tbaa !21
  br i1 %t118, label %bb37, label %bb38
bb37:
  %t119 = load ptr, ptr %l1, !tbaa !29
  %t121 = getelementptr { i64, [5 x i64] }, ptr %t119, i32 0, i32 1
  %t122 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t121, i32 0, i32 2
  %t123 = load ptr, ptr %t122
  store ptr %t123, ptr %l6, !tbaa !29
  br label %bb39
bb38:
  br label %bb44
bb39:
  %t125 = load ptr, ptr %l6, !tbaa !29
  %t127 = getelementptr %"compiler/typed:Try", ptr %t125, i32 0, i32 0
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t130 = icmp eq ptr %t128, null
  %t132 = xor i1 %t130, true
  br i1 %t132, label %bb40, label %bb41
bb40:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load ptr, ptr %l6, !tbaa !29
  %t137 = getelementptr %"compiler/typed:Try", ptr %t135, i32 0, i32 0
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t141 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earmPlace(ptr %v0, ptr %v1, ptr %t134, ptr %t138)
  store i1 %t141, ptr %l71
  br label %bb42
bb41:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb43
bb42:
  %t142 = load i1, ptr %l71, !tbaa !21
  store i1 %t142, ptr %l67, !tbaa !21
  br label %bb43
bb43:
  %t143 = load i1, ptr %l67, !tbaa !21
  store i1 %t143, ptr %rv
  br label %ret
bb44:
  %t144 = load ptr, ptr %l1, !tbaa !29
  store ptr %t144, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t145 = load ptr, ptr %l72, !tbaa !29
  %t146 = icmp ne ptr %t145, null
  br i1 %t146, label %bb45, label %bb46
bb45:
  %t148 = load ptr, ptr %l72, !tbaa !29
  %t149 = load i64, ptr %t148
  %t151 = icmp eq i64 %t149, 11
  store i1 %t151, ptr %l73, !tbaa !21
  br label %bb46
bb46:
  %t152 = load i1, ptr %l73, !tbaa !21
  br i1 %t152, label %bb47, label %bb48
bb47:
  br label %bb53
bb48:
  %t153 = load ptr, ptr %l1, !tbaa !29
  store ptr %t153, ptr %l76, !tbaa !29
  store i1 false, ptr %l77, !tbaa !21
  %t154 = load ptr, ptr %l76, !tbaa !29
  %t155 = icmp ne ptr %t154, null
  br i1 %t155, label %bb49, label %bb50
bb49:
  %t157 = load ptr, ptr %l76, !tbaa !29
  %t158 = load i64, ptr %t157
  %t160 = icmp eq i64 %t158, 13
  store i1 %t160, ptr %l77, !tbaa !21
  br label %bb50
bb50:
  %t161 = load i1, ptr %l77, !tbaa !21
  br i1 %t161, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load ptr, ptr %l1, !tbaa !29
  %t166 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econdChoosesPlace(ptr %v0, ptr %v1, ptr %t162, ptr %t163)
  store i1 %t166, ptr %l82
  br label %bb54
bb54:
  %t167 = load i1, ptr %l82, !tbaa !21
  store i1 %t167, ptr %rv
  br label %ret
bb55:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %rv = alloca { i64, [3 x i64] }
  %t16 = alloca { i64, [3 x i64] }, align 8
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %a0)
  store ptr %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 2
  %t7 = load i64, ptr %t6, !tbaa !24
  %t8 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t9 = load i32, ptr %t8, !tbaa !23
  %t11 = sext i32 %t9 to i64
  %t12 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t15 = sext i32 %t13 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t16
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 0
  store i64 3, ptr %t17
  %t19 = insertvalue { i64, i64, i64 } undef, i64 %t7, 0
  %t21 = insertvalue { i64, i64, i64 } %t19, i64 %t11, 1
  %t23 = insertvalue { i64, i64, i64 } %t21, i64 %t15, 2
  %t24 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 1
  store { i64, i64, i64 } %t23, ptr %t24
  %t25 = load { i64, [3 x i64] }, ptr %t16
  store { i64, [3 x i64] } %t25, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [3 x i64] }, ptr %rv
  ret { i64, [3 x i64] } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l8 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/check:b5aWalk", ptr %t3, i32 0, i32 2
  %t9 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eHas_3cI64_3e(ptr %v1, ptr %t5, i64 %t1)
  store i1 %t9, ptr %l8
  br label %bb1
bb1:
  %t10 = load i1, ptr %l8, !tbaa !21
  %t11 = xor i1 %t10, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/check:b5aWalk", ptr %t13, i32 0, i32 2
  %t16 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t15, i64 %t16)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPlace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l2, !tbaa !29
  store ptr %t5, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t6 = load ptr, ptr %l13, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l13, !tbaa !29
  %t10 = load i64, ptr %t9
  %t12 = icmp eq i64 %t10, 1
  store i1 %t12, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l14, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t16, i32 0, i32 1
  %t18 = load i32, ptr %t17
  store i32 %t18, ptr %l3, !tbaa !23
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t22, i32 0, i32 2
  %t24 = load i64, ptr %t23
  store i64 %t24, ptr %l4, !tbaa !24
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = getelementptr { i64, [4 x i64] }, ptr %t26, i32 0, i32 1
  %t29 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t28, i32 0, i32 3
  %t30 = load i32, ptr %t29
  store i32 %t30, ptr %l5, !tbaa !23
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t34 = load i64, ptr %l4, !tbaa !24
  %t35 = load i32, ptr %l5, !tbaa !23
  %t36 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aGlobal(ptr %v0, ptr %v1, ptr %t32, ptr %t33, i64 %t34, i32 %t35, i32 %t36)
  br label %bb9
bb9:
  br label %bb51
bb10:
  %t42 = load ptr, ptr %l2, !tbaa !29
  store ptr %t42, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t43 = load ptr, ptr %l28, !tbaa !29
  %t44 = icmp ne ptr %t43, null
  br i1 %t44, label %bb11, label %bb12
bb11:
  %t46 = load ptr, ptr %l28, !tbaa !29
  %t47 = load i64, ptr %t46
  %t49 = icmp eq i64 %t47, 2
  store i1 %t49, ptr %l29, !tbaa !21
  br label %bb12
bb12:
  %t50 = load i1, ptr %l29, !tbaa !21
  br i1 %t50, label %bb13, label %bb14
bb13:
  %t51 = load ptr, ptr %l2, !tbaa !29
  %t53 = getelementptr { i64, [4 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t53, i32 0, i32 2
  %t55 = load ptr, ptr %t54
  store ptr %t55, ptr %l6, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t59 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t57, ptr %t58, ptr %t59)
  br label %bb16
bb16:
  br label %bb51
bb17:
  %t64 = load ptr, ptr %l2, !tbaa !29
  store ptr %t64, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t65 = load ptr, ptr %l38, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb18, label %bb19
bb18:
  %t68 = load ptr, ptr %l38, !tbaa !29
  %t69 = load i64, ptr %t68
  %t71 = icmp eq i64 %t69, 3
  store i1 %t71, ptr %l39, !tbaa !21
  br label %bb19
bb19:
  %t72 = load i1, ptr %l39, !tbaa !21
  br i1 %t72, label %bb20, label %bb21
bb20:
  %t73 = load ptr, ptr %l2, !tbaa !29
  %t75 = getelementptr { i64, [4 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t75, i32 0, i32 2
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l7, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t81 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t79, ptr %t80, ptr %t81)
  br label %bb23
bb23:
  br label %bb51
bb24:
  %t86 = load ptr, ptr %l2, !tbaa !29
  store ptr %t86, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t87 = load ptr, ptr %l48, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb25, label %bb26
bb25:
  %t90 = load ptr, ptr %l48, !tbaa !29
  %t91 = load i64, ptr %t90
  %t93 = icmp eq i64 %t91, 4
  store i1 %t93, ptr %l49, !tbaa !21
  br label %bb26
bb26:
  %t94 = load i1, ptr %l49, !tbaa !21
  br i1 %t94, label %bb27, label %bb28
bb27:
  %t95 = load ptr, ptr %l2, !tbaa !29
  %t97 = getelementptr { i64, [4 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t97, i32 0, i32 2
  %t99 = load ptr, ptr %t98
  store ptr %t99, ptr %l8, !tbaa !29
  br label %bb29
bb28:
  br label %bb32
bb29:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t103 = load ptr, ptr %l8, !tbaa !29
  %t105 = getelementptr %"compiler/typed:Elem", ptr %t103, i32 0, i32 0
  %t106 = load ptr, ptr %t105, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t101, ptr %t102, ptr %t106)
  br label %bb30
bb30:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load ptr, ptr %l1, !tbaa !29
  %t113 = load ptr, ptr %l8, !tbaa !29
  %t115 = getelementptr %"compiler/typed:Elem", ptr %t113, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t111, ptr %t112, ptr %t116)
  br label %bb31
bb31:
  br label %bb51
bb32:
  %t121 = load ptr, ptr %l2, !tbaa !29
  store ptr %t121, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t122 = load ptr, ptr %l64, !tbaa !29
  %t123 = icmp ne ptr %t122, null
  br i1 %t123, label %bb33, label %bb34
bb33:
  %t125 = load ptr, ptr %l64, !tbaa !29
  %t126 = load i64, ptr %t125
  %t128 = icmp eq i64 %t126, 5
  store i1 %t128, ptr %l65, !tbaa !21
  br label %bb34
bb34:
  %t129 = load i1, ptr %l65, !tbaa !21
  br i1 %t129, label %bb35, label %bb36
bb35:
  %t130 = load ptr, ptr %l2, !tbaa !29
  %t132 = getelementptr { i64, [4 x i64] }, ptr %t130, i32 0, i32 1
  %t133 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t132, i32 0, i32 2
  %t134 = load ptr, ptr %t133
  store ptr %t134, ptr %l9, !tbaa !29
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load ptr, ptr %l1, !tbaa !29
  %t138 = load ptr, ptr %l9, !tbaa !29
  %t140 = getelementptr %"compiler/typed:Payload", ptr %t138, i32 0, i32 0
  %t141 = load ptr, ptr %t140, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t136, ptr %t137, ptr %t141)
  br label %bb38
bb38:
  br label %bb51
bb39:
  %t146 = load ptr, ptr %l2, !tbaa !29
  store ptr %t146, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t147 = load ptr, ptr %l75, !tbaa !29
  %t148 = icmp ne ptr %t147, null
  br i1 %t148, label %bb40, label %bb41
bb40:
  %t150 = load ptr, ptr %l75, !tbaa !29
  %t151 = load i64, ptr %t150
  %t153 = icmp eq i64 %t151, 6
  store i1 %t153, ptr %l76, !tbaa !21
  br label %bb41
bb41:
  %t154 = load i1, ptr %l76, !tbaa !21
  br i1 %t154, label %bb42, label %bb43
bb42:
  %t155 = load ptr, ptr %l2, !tbaa !29
  %t157 = getelementptr { i64, [4 x i64] }, ptr %t155, i32 0, i32 1
  %t158 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t157, i32 0, i32 2
  %t159 = load ptr, ptr %t158
  store ptr %t159, ptr %l10, !tbaa !29
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load ptr, ptr %l1, !tbaa !29
  %t163 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t161, ptr %t162, ptr %t163)
  br label %bb45
bb45:
  br label %bb51
bb46:
  br i1 true, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_b2a10b57ca8f7dfa_ebdfac3cc9f6695e)
  unreachable
bb51:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eborrowedResult(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i1
  %l19 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i1
  %l30 = alloca i32
  %l35 = alloca i1
  %l40 = alloca i32
  %l49 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Call", ptr %a1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t7 = load ptr, ptr %l9, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l9, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l10, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { i32 }, ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 11
  %t24 = load i32, ptr %l3, !tbaa !23
  %t26 = sext i32 %t24 to i64
  %t29 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t23, i64 %t26)
  store ptr %t29, ptr %l19
  br label %bb6
bb6:
  %t30 = load ptr, ptr %l19, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Body", ptr %t30, i32 0, i32 2
  %t33 = load i32, ptr %t32, !tbaa !23
  store i32 %t33, ptr %l8, !tbaa !23
  br label %bb19
bb7:
  %t35 = load ptr, ptr %l2, !tbaa !29
  store ptr %t35, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t36 = load ptr, ptr %l22, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb8, label %bb9
bb8:
  %t39 = load ptr, ptr %l22, !tbaa !29
  %t40 = load i64, ptr %t39
  %t42 = icmp eq i64 %t40, 2
  store i1 %t42, ptr %l23, !tbaa !21
  br label %bb9
bb9:
  %t43 = load i1, ptr %l23, !tbaa !21
  br i1 %t43, label %bb10, label %bb11
bb10:
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t46 = getelementptr { i64, [3 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { ptr }, ptr %t46, i32 0, i32 0
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l4, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t53 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t50)
  store i32 %t53, ptr %l30
  br label %bb13
bb13:
  %t54 = load i32, ptr %l30, !tbaa !23
  store i32 %t54, ptr %l8, !tbaa !23
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t55 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t55, ptr %l8, !tbaa !23
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_d8b8a4cfeb0897ac_ce33cd750b46e790)
  unreachable
bb19:
  %t57 = load i32, ptr %l8, !tbaa !23
  store i32 %t57, ptr %l5, !tbaa !23
  %t58 = load i32, ptr %l5, !tbaa !23
  %t59 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t62 = icmp eq i32 %t58, %t59
  br i1 %t62, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb23
bb21:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  %t70 = load i32, ptr %l5, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l40
  br label %bb22
bb22:
  %t74 = load i32, ptr %l40
  %t76 = trunc i64 21 to i32
  %t77 = icmp eq i32 %t74, %t76
  %t79 = xor i1 %t77, true
  store i1 %t79, ptr %l35, !tbaa !21
  br label %bb23
bb23:
  %t81 = load i1, ptr %l35, !tbaa !21
  br i1 %t81, label %bb24, label %bb25
bb24:
  store i1 false, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  %t89 = load i32, ptr %l5, !tbaa !23
  %t92 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t88, i32 %t89, i64 0)
  store i64 %t92, ptr %l49
  br label %bb27
bb27:
  %t93 = load i64, ptr %l49, !tbaa !24
  %t94 = icmp sge i64 %t93, 0
  store i1 %t94, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eborrowedSource(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca ptr
  %l9 = alloca i32
  %l12 = alloca i1
  %l13 = alloca i32
  %l20 = alloca i32
  %l23 = alloca i1
  %l24 = alloca i1
  %l29 = alloca i64
  %l33 = alloca i1
  %l37 = alloca i1
  %l40 = alloca ptr
  %l45 = alloca i32
  %l50 = alloca i64
  %l53 = alloca i32
  %l57 = alloca i64
  %l59 = alloca ptr
  %l62 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l65 = alloca i1
  %l66 = alloca i1
  %l70 = alloca i1
  %l71 = alloca ptr
  %l73 = alloca ptr
  %l74 = alloca i1
  %l79 = alloca ptr
  %rv = alloca i64
  %t159 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1)
  store i32 %t4, ptr %l9
  br label %bb1
bb1:
  %t5 = load i32, ptr %l9, !tbaa !23
  store i32 %t5, ptr %l3, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l3, !tbaa !23
  %t10 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l12
  br label %bb2
bb2:
  %t11 = load i1, ptr %l12, !tbaa !21
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t12 = load i32, ptr %l3, !tbaa !23
  store i32 %t12, ptr %l13, !tbaa !23
  br label %bb6
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 2
  %t20 = load i32, ptr %l3, !tbaa !23
  %t21 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t19, i32 %t20, i64 %t21)
  store i32 %t25, ptr %l20
  br label %bb5
bb5:
  %t26 = load i32, ptr %l20, !tbaa !23
  store i32 %t26, ptr %l13, !tbaa !23
  br label %bb6
bb6:
  %t27 = load i32, ptr %l13, !tbaa !23
  store i32 %t27, ptr %l4, !tbaa !23
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l3, !tbaa !23
  %t32 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t28, i32 %t29)
  store i1 %t32, ptr %l23
  br label %bb7
bb7:
  %t33 = load i1, ptr %l23, !tbaa !21
  br i1 %t33, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  %t40 = load i32, ptr %l3, !tbaa !23
  %t43 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t39, i32 %t40)
  store i64 %t43, ptr %l29
  br label %bb10
bb9:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb11
bb10:
  %t44 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t45 = load i64, ptr %l29, !tbaa !24
  %t47 = and i64 %t45, %t44
  %t49 = icmp ne i64 %t47, 0
  store i1 %t49, ptr %l24, !tbaa !21
  br label %bb11
bb11:
  %t51 = load i1, ptr %l24, !tbaa !21
  br i1 %t51, label %bb12, label %bb13
bb12:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t57 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v0, ptr %t52, ptr %t53)
  store i1 %t57, ptr %l37
  br label %bb14
bb13:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb15
bb14:
  %t58 = load i1, ptr %l37, !tbaa !21
  store i1 %t58, ptr %l33, !tbaa !21
  br label %bb15
bb15:
  %t59 = load i1, ptr %l33, !tbaa !21
  br i1 %t59, label %bb16, label %bb17
bb16:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Checker", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = getelementptr %"compiler/generic:Program", ptr %t63, i32 0, i32 2
  store ptr %t65, ptr %l40, !tbaa !29
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = getelementptr %"compiler/generic:Program", ptr %t69, i32 0, i32 2
  %t72 = load i32, ptr %l3, !tbaa !23
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t71, i32 %t72)
  store i32 %t75, ptr %l45
  br label %bb18
bb17:
  br label %bb21
bb18:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/generic:Program", ptr %t79, i32 0, i32 2
  %t82 = load i32, ptr %l3, !tbaa !23
  %t85 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t81, i32 %t82)
  store i64 %t85, ptr %l50
  br label %bb19
bb19:
  %t86 = load i64, ptr @G_2ecompiler_2ftypes_2eOwning, !tbaa !24
  %t87 = load i64, ptr %l50, !tbaa !24
  %t89 = and i64 %t87, %t86
  %t90 = load ptr, ptr %l40, !tbaa !29
  %t91 = load i32, ptr %l45, !tbaa !23
  %t93 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t90, i32 %t91, i64 %t89)
  store i32 %t93, ptr %l53
  br label %bb20
bb20:
  %t94 = load i32, ptr %l53, !tbaa !23
  store i32 %t94, ptr %l4, !tbaa !23
  br label %bb21
bb21:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load %"compiler/source:Span", ptr %l1
  %t97 = load i32, ptr %l4, !tbaa !23
  %t101 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t95, %"compiler/source:Span" %t96, i32 %t97)
  store i64 %t101, ptr %l57
  br label %bb22
bb22:
  %t102 = load i64, ptr %l57, !tbaa !24
  store i64 %t102, ptr %l5, !tbaa !24
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/check:Checker", ptr %t103, i32 0, i32 56
  store ptr %t105, ptr %l59, !tbaa !29
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i64, ptr %l5, !tbaa !24
  %t110 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %t106, i64 %t107)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t110, ptr %l62
  br label %bb23
bb23:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load i32, ptr %l3, !tbaa !23
  %t115 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t111, i32 %t112)
  store i1 %t115, ptr %l65
  br label %bb24
bb24:
  %t116 = load i1, ptr %l65, !tbaa !21
  br i1 %t116, label %bb25, label %bb26
bb25:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load ptr, ptr %l2, !tbaa !29
  %t122 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v0, ptr %t117, ptr %t118)
  store i1 %t122, ptr %l70
  br label %bb27
bb26:
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l71, !tbaa !29
  %t124 = load ptr, ptr %l2, !tbaa !29
  %t126 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %t124)
  store ptr %t126, ptr %l73
  br label %bb28
bb27:
  %t127 = load i1, ptr %l70, !tbaa !21
  store i1 %t127, ptr %l66, !tbaa !21
  br label %bb30
bb28:
  %t128 = load ptr, ptr %l71, !tbaa !29
  %t129 = load ptr, ptr %l73, !tbaa !29
  %t130 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v0, ptr %t128, ptr %t129)
  store i1 %t130, ptr %l74
  br label %bb29
bb29:
  %t131 = load i1, ptr %l74, !tbaa !21
  store i1 %t131, ptr %l66, !tbaa !21
  br label %bb30
bb30:
  %t132 = load ptr, ptr %l59, !tbaa !29
  %t133 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l62
  %t134 = load i1, ptr %l66, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t132, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t133, i1 %t134)
  br label %bb31
bb31:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load ptr, ptr %l2, !tbaa !29
  %t137 = load i32, ptr %l4, !tbaa !23
  %t138 = load %"compiler/source:Span", ptr %l1
  %t143 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t135, ptr %t136, i32 %t137, %"compiler/source:Span" %t138)
  store ptr %t143, ptr %l79
  br label %bb32
bb32:
  %t144 = load ptr, ptr %l79, !tbaa !29
  store ptr %t144, ptr %l6, !tbaa !29
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load i64, ptr %l5, !tbaa !24
  %t147 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTrack(ptr %v0, ptr %v0, ptr %t145, i64 %t146, ptr %t147)
  br label %bb33
bb33:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load %"compiler/source:Span", ptr %l1
  %t154 = load i64, ptr %l5, !tbaa !24
  %t156 = trunc i64 %t154 to i32
  %t158 = load ptr, ptr %l6, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t159
  %t160 = getelementptr { i64, [3 x i64] }, ptr %t159, i32 0, i32 0
  store i64 0, ptr %t160
  %t162 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t153, 0
  %t164 = insertvalue { %"compiler/source:Span", i32, ptr } %t162, i32 %t156, 1
  %t166 = insertvalue { %"compiler/source:Span", i32, ptr } %t164, ptr %t158, 2
  %t167 = getelementptr { i64, [3 x i64] }, ptr %t159, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t166, ptr %t167
  %t168 = load { i64, [3 x i64] }, ptr %t159
  %t170 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t168, ptr %t170
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t152, ptr %t170)
  br label %bb34
bb34:
  %t173 = load i64, ptr %l5, !tbaa !24
  store i64 %t173, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebreakUnless(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l4 = alloca i64
  %lp5 = alloca ptr
  %l8 = alloca i64
  %l19 = alloca ptr
  %l23 = alloca i32
  %l27 = alloca { i64, ptr }
  %l28 = alloca %"compiler/typed:Block"
  %l29 = alloca %"compiler/source:Span"
  %l33 = alloca ptr
  %l35 = alloca %"compiler/typed:If"
  %rv = alloca ptr
  %t15 = alloca { i64, [3 x i64] }, align 8
  %t66 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 33
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 33
  %t10 = load %"compiler/source:Span", ptr %l1
  %t13 = trunc i64 %a3 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t15
  %t16 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 0
  store i64 5, ptr %t16
  %t18 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t10, 0
  %t20 = insertvalue { %"compiler/source:Span", i32, i32 } %t18, i32 0, 1
  %t22 = insertvalue { %"compiler/source:Span", i32, i32 } %t20, i32 %t13, 2
  %t23 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t22, ptr %t23
  %t24 = load { i64, [3 x i64] }, ptr %t15
  %t26 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t24, ptr %t26
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v0, ptr %t9, ptr %t26)
  br label %bb2
bb2:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t29)
  store ptr %t31, ptr %l19
  br label %bb3
bb3:
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t34 = getelementptr %"compiler/check:frame", ptr %t32, i32 0, i32 7
  %t35 = load i64, ptr %t34, !tbaa !24
  %t37 = trunc i64 %t35 to i32
  store i32 %t37, ptr %l23, !tbaa !23
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 33
  %t42 = load i64, ptr %l4, !tbaa !24
  %t45 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t41, i64 %t42)
  store { i64, ptr } %t45, ptr %l27
  br label %bb4
bb4:
  %t46 = load i32, ptr %l23, !tbaa !23
  %t47 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t48 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 %t46, { i64, ptr } %t47)
  store %"compiler/typed:Block" %t48, ptr %l28
  br label %bb5
bb5:
  %t49 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store ptr %t49, ptr %lp5
  %t50 = load %"compiler/typed:Block", ptr %l28
  %t51 = load ptr, ptr %lp5
  store %"compiler/typed:Block" %t50, ptr %t51
  %t52 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t52, ptr %l29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load %"compiler/source:Span", ptr %l1
  %t59 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %t53, %"compiler/source:Span" %t54, ptr %a2)
  store ptr %t59, ptr %l33
  br label %bb6
bb6:
  %t60 = load ptr, ptr %lp5
  %t61 = load ptr, ptr %l33, !tbaa !29
  %t63 = call %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t61, ptr %t60, ptr null)
  store %"compiler/typed:If" %t63, ptr %l35
  br label %bb7
bb7:
  %t64 = load %"compiler/typed:If", ptr %l35
  %t65 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:If" %t64, ptr %t65
  store { i64, [3 x i64] } zeroinitializer, ptr %t66
  %t67 = getelementptr { i64, [3 x i64] }, ptr %t66, i32 0, i32 0
  store i64 3, ptr %t67
  %t68 = load %"compiler/source:Span", ptr %l29
  %t69 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t68, 0
  %t71 = insertvalue { %"compiler/source:Span", ptr } %t69, ptr %t65, 1
  %t72 = getelementptr { i64, [3 x i64] }, ptr %t66, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t71, ptr %t72
  %t73 = load { i64, [3 x i64] }, ptr %t66
  %t75 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t73, ptr %t75
  store ptr %t75, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallOf(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, { i64, ptr } %a4) #0 {
entry:
  %l1 = alloca %"compiler/source:Span"
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, [2 x i64] }
  %l13 = alloca i32
  %l14 = alloca %"compiler/typed:Call"
  %rv = alloca ptr
  %t5 = alloca { i64, [2 x i64] }, align 8
  %t21 = alloca { i64, [5 x i64] }, align 8
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1, ptr %l5
  store i32 %a2, ptr %l6, !tbaa !23
  store ptr %a3, ptr %l7, !tbaa !29
  store { i64, ptr } %a4, ptr %l8, !tbaa !27
  store { i64, [2 x i64] } zeroinitializer, ptr %t5
  %t6 = getelementptr { i64, [2 x i64] }, ptr %t5, i32 0, i32 0
  store i64 0, ptr %t6
  %t7 = load { i64, [2 x i64] }, ptr %t5
  store { i64, [2 x i64] } %t7, ptr %l9
  %t9 = load %"compiler/source:Span", ptr %l1
  %t13 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 0, %"compiler/source:Span" %t9)
  store i32 %t13, ptr %l13
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l7, !tbaa !29
  %t15 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t16 = load { i64, [2 x i64] }, ptr %l9
  %t17 = load i32, ptr %l13, !tbaa !23
  %t18 = call %"compiler/typed:Call" @compiler_2ftyped_3aCall_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t14, { i64, ptr } %t15, { i64, [2 x i64] } %t16, i32 %t17, i1 false)
  store %"compiler/typed:Call" %t18, ptr %l14
  br label %bb2
bb2:
  %t19 = load %"compiler/typed:Call", ptr %l14
  %t20 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/typed:Call" %t19, ptr %t20
  store { i64, [5 x i64] } zeroinitializer, ptr %t21
  %t22 = getelementptr { i64, [5 x i64] }, ptr %t21, i32 0, i32 0
  store i64 6, ptr %t22
  %t23 = load %"compiler/source:Span", ptr %l5
  %t24 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t23, 0
  %t25 = load i32, ptr %l6, !tbaa !23
  %t26 = insertvalue { %"compiler/source:Span", i32, ptr } %t24, i32 %t25, 1
  %t28 = insertvalue { %"compiler/source:Span", i32, ptr } %t26, ptr %t20, 2
  %t29 = getelementptr { i64, [5 x i64] }, ptr %t21, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t28, ptr %t29
  %t30 = load { i64, [5 x i64] }, ptr %t21
  %t32 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t30, ptr %t32
  store ptr %t32, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallValue(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l12 = alloca i32
  %l20 = alloca ptr
  %l25 = alloca i32
  %l28 = alloca ptr
  %l29 = alloca %"compiler/source:Span"
  %l30 = alloca %"compiler/source:Span"
  %l31 = alloca i32
  %l34 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l41 = alloca ptr
  %l44 = alloca i32
  %l49 = alloca i32
  %l50 = alloca i64
  %l54 = alloca ptr
  %l57 = alloca i32
  %l62 = alloca i32
  %l63 = alloca i64
  %l64 = alloca ptr
  %l65 = alloca i64
  %l66 = alloca i32
  %l67 = alloca %"compiler/source:Span"
  %l70 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l73 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca %"compiler/source:Span"
  %l78 = alloca %"compiler/source:Span"
  %l79 = alloca i64
  %l81 = alloca ptr
  %l82 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l89 = alloca ptr
  %l93 = alloca ptr
  %l95 = alloca ptr
  %l98 = alloca ptr
  %l111 = alloca i1
  %l112 = alloca { i64, ptr }
  %l121 = alloca i1
  %l122 = alloca { i64, ptr }
  %l127 = alloca i1
  %l128 = alloca { i64, ptr }
  %l132 = alloca ptr
  %l136 = alloca %"compiler/source:Span"
  %l137 = alloca %"compiler/msgs:Msg"
  %l138 = alloca i64
  %l143 = alloca ptr
  %l146 = alloca i1
  %l147 = alloca { i64, ptr }
  %l153 = alloca i1
  %l156 = alloca i32
  %l158 = alloca i32
  %l160 = alloca i1
  %l161 = alloca { i64, ptr }
  %l166 = alloca ptr
  %l169 = alloca %"compiler/source:Span"
  %l170 = alloca %"compiler/msgs:Msg"
  %l171 = alloca i64
  %l176 = alloca ptr
  %l177 = alloca ptr
  %l178 = alloca %"compiler/source:Span"
  %l181 = alloca { i64, ptr }
  %l183 = alloca %"compiler/msgs:Msg"
  %l184 = alloca i64
  %l189 = alloca ptr
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca ptr
  %t42 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store ptr %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1)
  store i32 %t4, ptr %l12
  br label %bb1
bb1:
  %t5 = load i32, ptr %l12, !tbaa !23
  store i32 %t5, ptr %l5, !tbaa !23
  %t6 = load i32, ptr %l5, !tbaa !23
  %t7 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t10 = icmp eq i32 %t6, %t7
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t12, { i64, ptr } %t13)
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load %"compiler/source:Span", ptr %l1
  %t20 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t16, %"compiler/source:Span" %t17)
  store ptr %t20, ptr %l20
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t21 = load ptr, ptr %l20, !tbaa !29
  store ptr %t21, ptr %rv
  br label %ret
bb6:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l5, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l25
  br label %bb7
bb7:
  %t32 = load i32, ptr %l25
  %t34 = trunc i64 21 to i32
  %t35 = icmp eq i32 %t32, %t34
  br i1 %t35, label %bb8, label %bb9
bb8:
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l28, !tbaa !29
  %t38 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t38, ptr %l29
  %t39 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t39, ptr %l30
  %t40 = load i32, ptr %l5, !tbaa !23
  store i32 %t40, ptr %l31, !tbaa !23
  %t41 = load ptr, ptr %l3, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t42
  %t43 = getelementptr { i64, [3 x i64] }, ptr %t42, i32 0, i32 0
  store i64 2, ptr %t43
  %t45 = insertvalue { ptr } undef, ptr %t41, 0
  %t46 = getelementptr { i64, [3 x i64] }, ptr %t42, i32 0, i32 1
  store { ptr } %t45, ptr %t46
  %t47 = load { i64, [3 x i64] }, ptr %t42
  %t49 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t47, ptr %t49
  store ptr %t49, ptr %l34, !tbaa !29
  %t50 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t50, ptr %l35, !tbaa !27
  %t51 = icmp sge i64 0, 0
  br i1 %t51, label %bb10, label %bb11
bb9:
  br label %bb15
bb10:
  %t53 = icmp sle i64 0, 1152921504606846975
  br i1 %t53, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_c23231398495940d_3184fca2d3133de9)
  unreachable
bb12:
  %t55 = mul i64 0, 8
  %t56 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t55)
  %t57 = insertvalue { i64, ptr } undef, i64 0, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  %t59 = load ptr, ptr %l28, !tbaa !29
  %t60 = load %"compiler/source:Span", ptr %l29
  %t61 = load %"compiler/source:Span", ptr %l30
  %t62 = load i32, ptr %l31, !tbaa !23
  %t63 = load ptr, ptr %l34, !tbaa !29
  %t64 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t66 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v1, ptr %t59, %"compiler/source:Span" %t60, %"compiler/source:Span" %t61, i32 %t62, ptr %t63, i64 -1, ptr null, { i64, ptr } %t64, { i64, ptr } %t58)
  store ptr %t66, ptr %l39
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_c23231398495940d_3184fca2d3133de9)
  unreachable
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t67 = load ptr, ptr %l39, !tbaa !29
  store ptr %t67, ptr %rv
  br label %ret
bb15:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/check:Checker", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  store ptr %t71, ptr %l41, !tbaa !29
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i32, ptr %l5, !tbaa !23
  %t76 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t72, i32 %t73)
  store i32 %t76, ptr %l44
  br label %bb16
bb16:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/generic:Program", ptr %t80, i32 0, i32 0
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = getelementptr %"compiler/load:Loader", ptr %t83, i32 0, i32 3
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t86, { i64, ptr } { i64 4, ptr @.d2 })
  store i32 %t88, ptr %l49
  br label %bb17
bb17:
  %t89 = load ptr, ptr %l41, !tbaa !29
  %t90 = load i32, ptr %l44, !tbaa !23
  %t91 = load i32, ptr %l49, !tbaa !23
  %t92 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t89, i32 %t90, i32 %t91)
  store i64 %t92, ptr %l50
  br label %bb18
bb18:
  %t93 = load i64, ptr %l50, !tbaa !24
  store i64 %t93, ptr %l6, !tbaa !24
  %t94 = load i64, ptr %l6, !tbaa !24
  %t96 = icmp slt i64 %t94, 0
  br i1 %t96, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/check:Checker", ptr %t98, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !29
  store ptr %t101, ptr %l54, !tbaa !29
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load i32, ptr %l5, !tbaa !23
  %t106 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t102, i32 %t103)
  store i32 %t106, ptr %l57
  br label %bb21
bb20:
  br label %bb24
bb21:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/check:Checker", ptr %t107, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/generic:Program", ptr %t110, i32 0, i32 0
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = getelementptr %"compiler/load:Loader", ptr %t113, i32 0, i32 3
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s3, ptr %t116, { i64, ptr } { i64 4, ptr @.d3 })
  store i32 %t118, ptr %l62
  br label %bb22
bb22:
  %t119 = load ptr, ptr %l54, !tbaa !29
  %t120 = load i32, ptr %l57, !tbaa !23
  %t121 = load i32, ptr %l62, !tbaa !23
  %t122 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t119, i32 %t120, i32 %t121)
  store i64 %t122, ptr %l63
  br label %bb23
bb23:
  %t123 = load i64, ptr %l63, !tbaa !24
  store i64 %t123, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb24:
  %t124 = load ptr, ptr %l0, !tbaa !29
  store ptr %t124, ptr %l64, !tbaa !29
  %t125 = load i64, ptr %l6, !tbaa !24
  store i64 %t125, ptr %l65, !tbaa !24
  %t126 = load i32, ptr %l5, !tbaa !23
  store i32 %t126, ptr %l66, !tbaa !23
  %t127 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t127, ptr %l67
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load %"compiler/source:Span", ptr %l2
  %t132 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t128, %"compiler/source:Span" %t129)
  store { i64, ptr } %t132, ptr %l70
  br label %bb25
bb25:
  %t133 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t134 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %s0, { i64, ptr } %t133)
  store { i64, ptr } %t134, ptr %l71
  br label %bb26
bb26:
  %t135 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t135, 0
  %t137 = extractvalue { i64, ptr } %t135, 1
  %t138 = mul i64 %t136, 1
  %t139 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t138)
  call void @llvm.memcpy.p0.p0.i64(ptr %t139, ptr %t137, i64 %t138, i1 false)
  %t140 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t139, 1
  %t142 = load ptr, ptr %l64, !tbaa !29
  %t143 = load i64, ptr %l65, !tbaa !24
  %t144 = load i32, ptr %l66, !tbaa !23
  %t145 = load %"compiler/source:Span", ptr %l67
  %t147 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprivateRole(ptr %v0, ptr %s0, ptr %s0, ptr %t142, i64 %t143, i32 %t144, { i64, ptr } { i64 4, ptr @.d4 }, %"compiler/source:Span" %t145, { i64, ptr } %t141)
  store i1 %t147, ptr %l73
  br label %bb27
bb27:
  %t148 = load i64, ptr %l6, !tbaa !24
  %t150 = icmp sge i64 %t148, 0
  br i1 %t150, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s4
  %t152 = load ptr, ptr %l0, !tbaa !29
  store ptr %t152, ptr %l76, !tbaa !29
  %t153 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t153, ptr %l77
  %t154 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t154, ptr %l78
  %t155 = load i64, ptr %l6, !tbaa !24
  store i64 %t155, ptr %l79, !tbaa !24
  %t156 = load ptr, ptr %l3, !tbaa !29
  store ptr %t156, ptr %l81, !tbaa !29
  %t158 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t158, ptr %l82, !tbaa !27
  %t159 = icmp sge i64 0, 0
  br i1 %t159, label %bb30, label %bb31
bb29:
  br label %bb39
bb30:
  %t161 = icmp sle i64 0, 1152921504606846975
  br i1 %t161, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_dec816aeadd109e0_adcbe0bcced90c1c)
  unreachable
bb32:
  %t163 = mul i64 0, 8
  %t164 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t163)
  %t165 = insertvalue { i64, ptr } undef, i64 0, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t164, 1
  store { i64, ptr } %t166, ptr %l85, !tbaa !27
  %t167 = icmp sge i64 0, 0
  br i1 %t167, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_dec816aeadd109e0_adcbe0bcced90c1c)
  unreachable
bb34:
  %t169 = icmp sle i64 0, 2305843009213693951
  br i1 %t169, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_98ffdf46f6e43303_7907d8ed59f5817f)
  unreachable
bb36:
  %t171 = mul i64 0, 4
  %t172 = call ptr @__olang_scope_alloc_zeroed(ptr %s4, i64 %t171)
  %t173 = insertvalue { i64, ptr } undef, i64 0, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t172, 1
  %t175 = load ptr, ptr %l76, !tbaa !29
  %t176 = load %"compiler/source:Span", ptr %l77
  %t177 = load %"compiler/source:Span", ptr %l78
  %t178 = load i64, ptr %l79, !tbaa !24
  %t179 = load ptr, ptr %l81, !tbaa !29
  %t180 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t181 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t183 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %s4, ptr %t175, %"compiler/source:Span" %t176, %"compiler/source:Span" %t177, i64 %t178, ptr %t179, { i64, ptr } %t180, { i64, ptr } %t181, { i64, ptr } %t174)
  store ptr %t183, ptr %l89
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_98ffdf46f6e43303_7907d8ed59f5817f)
  unreachable
bb38:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t184 = load ptr, ptr %l89, !tbaa !29
  store ptr %t184, ptr %rv
  br label %ret
bb39:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/check:Checker", ptr %t185, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !29
  %t190 = getelementptr %"compiler/generic:Program", ptr %t188, i32 0, i32 0
  %t191 = load ptr, ptr %t190, !tbaa !29
  %t193 = getelementptr %"compiler/load:Loader", ptr %t191, i32 0, i32 5
  store ptr %t193, ptr %l93, !tbaa !29
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t194)
  store ptr %t196, ptr %l95
  br label %bb40
bb40:
  %t197 = load ptr, ptr %l95, !tbaa !29
  %t199 = getelementptr %"compiler/check:frame", ptr %t197, i32 0, i32 1
  %t200 = load i64, ptr %t199, !tbaa !24
  %t201 = load ptr, ptr %l93, !tbaa !29
  %t203 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t201, i64 %t200)
  store ptr %t203, ptr %l98
  br label %bb41
bb41:
  %t204 = load ptr, ptr %l98, !tbaa !29
  %t206 = getelementptr %"compiler/load:Module", ptr %t204, i32 0, i32 6
  %t207 = load ptr, ptr %t206, !tbaa !29
  store ptr %t207, ptr %l7, !tbaa !29
  %t209 = load ptr, ptr %l7, !tbaa !29
  %t211 = icmp eq ptr %t209, null
  br i1 %t211, label %bb42, label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_4b3a1421aaa5396_3ffde41a88bcce4a)
  unreachable
bb43:
  br label %bb44
bb44:
  %t213 = load ptr, ptr %l7, !tbaa !29
  %t216 = getelementptr %"compiler/source:Source", ptr %t213, i32 0, i32 1
  %t217 = load { i64, ptr }, ptr %t216, !tbaa !27
  store { i64, ptr } %t217, ptr %l8, !tbaa !27
  %t219 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t220 = load i32, ptr %t219, !tbaa !23
  %t222 = sext i32 %t220 to i64
  %t224 = sub i64 %t222, 1
  store i64 %t224, ptr %l9, !tbaa !24
  br label %bb45
bb45:
  store %olang.scope zeroinitializer, ptr %s5
  %t226 = load i64, ptr %l9, !tbaa !24
  %t228 = icmp sgt i64 %t226, 0
  br i1 %t228, label %bb46, label %bb47
bb46:
  %t230 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t230, ptr %l112, !tbaa !27
  %t231 = load i64, ptr %l9, !tbaa !24
  %t233 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !27
  %t235 = getelementptr i8, ptr %t234, i64 %t231
  %t236 = load i8, ptr %t235, !tbaa !32
  %t238 = icmp eq i8 %t236, 32
  store i1 %t238, ptr %l111, !tbaa !21
  br label %bb48
bb47:
  store i1 false, ptr %l111, !tbaa !21
  br label %bb48
bb48:
  %t240 = load i1, ptr %l111, !tbaa !21
  %t241 = xor i1 %t240, true
  br i1 %t241, label %bb49, label %bb50
bb49:
  call void @__olang_scope_close(ptr %s5)
  br label %bb53
bb50:
  br label %bb51
bb51:
  %t243 = load i64, ptr %l9, !tbaa !24
  %t245 = sub i64 %t243, 1
  store i64 %t245, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb52
bb52:
  br label %bb45
bb53:
  %t247 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t248 = load i32, ptr %t247, !tbaa !23
  %t250 = icmp sgt i32 %t248, 0
  br i1 %t250, label %bb54, label %bb55
bb54:
  %t252 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t252, ptr %l122, !tbaa !27
  %t253 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t254 = load i32, ptr %t253, !tbaa !23
  %t256 = sext i32 %t254 to i64
  %t258 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t259 = load ptr, ptr %t258, !tbaa !27
  %t260 = getelementptr i8, ptr %t259, i64 %t256
  %t261 = load i8, ptr %t260, !tbaa !32
  %t263 = icmp eq i8 %t261, 40
  store i1 %t263, ptr %l121, !tbaa !21
  br label %bb56
bb55:
  store i1 false, ptr %l121, !tbaa !21
  br label %bb56
bb56:
  %t265 = load i1, ptr %l121, !tbaa !21
  br i1 %t265, label %bb57, label %bb58
bb57:
  %t266 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t266, ptr %l128, !tbaa !27
  %t267 = load i64, ptr %l9, !tbaa !24
  %t269 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !27
  %t271 = getelementptr i8, ptr %t270, i64 %t267
  %t272 = load i8, ptr %t271, !tbaa !32
  %t274 = icmp eq i8 %t272, 34
  store i1 %t274, ptr %l127, !tbaa !21
  br label %bb59
bb58:
  store i1 false, ptr %l127, !tbaa !21
  br label %bb59
bb59:
  %t276 = load i1, ptr %l127, !tbaa !21
  br i1 %t276, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s6
  %t277 = load ptr, ptr %l0, !tbaa !29
  store ptr %t277, ptr %l132, !tbaa !29
  %t278 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t279 = load i32, ptr %t278, !tbaa !23
  %t280 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t281 = load i32, ptr %t280, !tbaa !23
  %t283 = add i32 %t281, 1
  %t286 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s6, i32 %t279, i32 %t283)
  store %"compiler/source:Span" %t286, ptr %l136
  br label %bb62
bb61:
  br label %bb67
bb62:
  %t287 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinPieceCalled(ptr %s6)
  store %"compiler/msgs:Msg" %t287, ptr %l137
  br label %bb63
bb63:
  %t288 = load ptr, ptr %l132, !tbaa !29
  %t289 = load %"compiler/source:Span", ptr %l136
  %t290 = load %"compiler/msgs:Msg", ptr %l137
  %t291 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t288, %"compiler/source:Span" %t289, %"compiler/msgs:Msg" %t290)
  store i64 %t291, ptr %l138
  br label %bb64
bb64:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t293 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t292, { i64, ptr } %t293)
  br label %bb65
bb65:
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t297 = load %"compiler/source:Span", ptr %l1
  %t300 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t296, %"compiler/source:Span" %t297)
  store ptr %t300, ptr %l143
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t301 = load ptr, ptr %l143, !tbaa !29
  store ptr %t301, ptr %rv
  br label %ret
bb67:
  %t302 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t303 = load i32, ptr %t302, !tbaa !23
  %t305 = icmp sgt i32 %t303, 0
  br i1 %t305, label %bb68, label %bb69
bb68:
  %t307 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t307, ptr %l147, !tbaa !27
  %t308 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t309 = load i32, ptr %t308, !tbaa !23
  %t311 = sext i32 %t309 to i64
  %t313 = sub i64 %t311, 1
  %t315 = getelementptr { i64, ptr }, ptr %l147, i32 0, i32 1
  %t316 = load ptr, ptr %t315, !tbaa !27
  %t317 = getelementptr i8, ptr %t316, i64 %t313
  %t318 = load i8, ptr %t317, !tbaa !32
  %t320 = icmp eq i8 %t318, 36
  br i1 %t320, label %bb70, label %bb71
bb69:
  store i1 false, ptr %l146, !tbaa !21
  br label %bb78
bb70:
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t323 = load i32, ptr %l5, !tbaa !23
  %t326 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t322, i32 %t323)
  store i32 %t326, ptr %l156
  br label %bb72
bb71:
  store i1 false, ptr %l153, !tbaa !21
  br label %bb74
bb72:
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t329 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t327)
  store i32 %t329, ptr %l158
  br label %bb73
bb73:
  %t330 = load i32, ptr %l156, !tbaa !23
  %t331 = load i32, ptr %l158, !tbaa !23
  %t332 = icmp eq i32 %t330, %t331
  store i1 %t332, ptr %l153, !tbaa !21
  br label %bb74
bb74:
  %t334 = load i1, ptr %l153, !tbaa !21
  br i1 %t334, label %bb75, label %bb76
bb75:
  store i1 true, ptr %l160, !tbaa !21
  br label %bb77
bb76:
  %t335 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t335, ptr %l161, !tbaa !27
  %t336 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t337 = load i32, ptr %t336, !tbaa !23
  %t339 = sext i32 %t337 to i64
  %t341 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t342 = load ptr, ptr %t341, !tbaa !27
  %t343 = getelementptr i8, ptr %t342, i64 %t339
  %t344 = load i8, ptr %t343, !tbaa !32
  %t346 = icmp eq i8 %t344, 34
  store i1 %t346, ptr %l160, !tbaa !21
  br label %bb77
bb77:
  %t348 = load i1, ptr %l160, !tbaa !21
  store i1 %t348, ptr %l146, !tbaa !21
  br label %bb78
bb78:
  %t349 = load i1, ptr %l146, !tbaa !21
  br i1 %t349, label %bb79, label %bb80
bb79:
  store %olang.scope zeroinitializer, ptr %s7
  %t350 = load ptr, ptr %l0, !tbaa !29
  store ptr %t350, ptr %l166, !tbaa !29
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t352 = load %"compiler/source:Span", ptr %l2
  %t355 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAfter(ptr %v0, ptr %t351, %"compiler/source:Span" %t352, i64 1)
  store %"compiler/source:Span" %t355, ptr %l169
  br label %bb81
bb80:
  br label %bb86
bb81:
  %t356 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinPieceCalled(ptr %s7)
  store %"compiler/msgs:Msg" %t356, ptr %l170
  br label %bb82
bb82:
  %t357 = load ptr, ptr %l166, !tbaa !29
  %t358 = load %"compiler/source:Span", ptr %l169
  %t359 = load %"compiler/msgs:Msg", ptr %l170
  %t360 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t357, %"compiler/source:Span" %t358, %"compiler/msgs:Msg" %t359)
  store i64 %t360, ptr %l171
  br label %bb83
bb83:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t362 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t361, { i64, ptr } %t362)
  br label %bb84
bb84:
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t366 = load %"compiler/source:Span", ptr %l1
  %t369 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t365, %"compiler/source:Span" %t366)
  store ptr %t369, ptr %l176
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t370 = load ptr, ptr %l176, !tbaa !29
  store ptr %t370, ptr %rv
  br label %ret
bb86:
  %t371 = load ptr, ptr %l0, !tbaa !29
  store ptr %t371, ptr %l177, !tbaa !29
  %t372 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t372, ptr %l178
  %t373 = load ptr, ptr %l0, !tbaa !29
  %t374 = load i32, ptr %l5, !tbaa !23
  %t377 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t373, i32 %t374)
  store { i64, ptr } %t377, ptr %l181
  br label %bb87
bb87:
  %t378 = load { i64, ptr }, ptr %l181, !tbaa !27
  %t379 = extractvalue { i64, ptr } %t378, 0
  %t380 = extractvalue { i64, ptr } %t378, 1
  %t381 = mul i64 %t379, 1
  %t382 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t381)
  call void @llvm.memcpy.p0.p0.i64(ptr %t382, ptr %t380, i64 %t381, i1 false)
  %t383 = insertvalue { i64, ptr } undef, i64 %t379, 0
  %t384 = insertvalue { i64, ptr } %t383, ptr %t382, 1
  %t386 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotCallable(ptr %s0, ptr %s0, { i64, ptr } %t384)
  store %"compiler/msgs:Msg" %t386, ptr %l183
  br label %bb88
bb88:
  %t387 = load ptr, ptr %l177, !tbaa !29
  %t388 = load %"compiler/source:Span", ptr %l178
  %t389 = load %"compiler/msgs:Msg", ptr %l183
  %t390 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t387, %"compiler/source:Span" %t388, %"compiler/msgs:Msg" %t389)
  store i64 %t390, ptr %l184
  br label %bb89
bb89:
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t392 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t391, { i64, ptr } %t392)
  br label %bb90
bb90:
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t396 = load %"compiler/source:Span", ptr %l1
  %t399 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t395, %"compiler/source:Span" %t396)
  store ptr %t399, ptr %l189
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s0)
  %t400 = load ptr, ptr %l189, !tbaa !29
  store ptr %t400, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeName(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca ptr
  %l8 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l19 = alloca i1
  %l23 = alloca i1
  %l24 = alloca ptr
  %l27 = alloca ptr
  %l33 = alloca i32
  %l34 = alloca i32
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp sge i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t10 = load i64, ptr %l1, !tbaa !24
  %t13 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t9, i64 %t10)
  store ptr %t13, ptr %l8
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t16 = getelementptr %"compiler/ast:Func", ptr %t14, i32 0, i32 2
  %t17 = load i32, ptr %t16, !tbaa !23
  %t18 = load ptr, ptr %l4, !tbaa !29
  %t20 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t18, i32 %t17)
  store { i64, ptr } %t20, ptr %l11
  br label %bb4
bb4:
  %t21 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t21, ptr %l12, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l13, !tbaa !24
  %t24 = load i64, ptr %l13, !tbaa !24
  %t25 = mul i64 %t24, 1
  %t26 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l14, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l13, !tbaa !24
  %t34 = mul i64 %t33, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t35, ptr %l12, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t36, ptr %rv
  br label %ret
bb5:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 22
  %t40 = load i32, ptr %t39, !tbaa !23
  %t41 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t44 = icmp ne i32 %t40, %t41
  br i1 %t44, label %bb6, label %bb7
bb6:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 22
  %t50 = load i32, ptr %t49, !tbaa !23
  %t53 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t46, i32 %t50)
  store i1 %t53, ptr %l23
  br label %bb8
bb7:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb9
bb8:
  %t54 = load i1, ptr %l23, !tbaa !21
  store i1 %t54, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t55 = load i1, ptr %l19, !tbaa !21
  br i1 %t55, label %bb10, label %bb11
bb10:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l24, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 2
  store ptr %t62, ptr %l27, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 22
  %t72 = load i32, ptr %t71, !tbaa !23
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t68, i32 %t72)
  store i32 %t75, ptr %l33
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t76 = load ptr, ptr %l27, !tbaa !29
  %t77 = load i32, ptr %l33, !tbaa !23
  %t78 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t76, i32 %t77)
  store i32 %t78, ptr %l34
  br label %bb13
bb13:
  %t79 = load ptr, ptr %l24, !tbaa !29
  %t80 = load i32, ptr %l34, !tbaa !23
  %t81 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t79, i32 %t80)
  store { i64, ptr } %t81, ptr %l35
  br label %bb14
bb14:
  %t82 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t82, ptr %l36, !tbaa !27
  %t83 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 0
  store i64 %t84, ptr %l37, !tbaa !24
  %t85 = load i64, ptr %l37, !tbaa !24
  %t86 = mul i64 %t85, 1
  %t87 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t86)
  %t88 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t87, 1
  store { i64, ptr } %t89, ptr %l38, !tbaa !27
  %t90 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = load i64, ptr %l37, !tbaa !24
  %t95 = mul i64 %t94, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t91, ptr %t93, i64 %t95, i1 false)
  %t96 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t96, ptr %l36, !tbaa !27
  %t97 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t97, ptr %rv
  br label %ret
bb15:
  store { i64, ptr } { i64 16, ptr @.d5 }, ptr %l39, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t98, ptr %l40, !tbaa !27
  %t99 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 0
  store i64 %t100, ptr %l41, !tbaa !24
  %t101 = load i64, ptr %l41, !tbaa !24
  %t102 = mul i64 %t101, 1
  %t103 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t102)
  %t104 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t103, 1
  store { i64, ptr } %t105, ptr %l42, !tbaa !27
  %t106 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = load i64, ptr %l41, !tbaa !24
  %t111 = mul i64 %t110, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t107, ptr %t109, i64 %t111, i1 false)
  %t112 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t112, ptr %l40, !tbaa !27
  %t113 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t113, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaptureIn(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i32
  %l25 = alloca i1
  %l35 = alloca i64
  %l40 = alloca ptr
  %l45 = alloca ptr
  %l48 = alloca ptr
  %l52 = alloca %"compiler/typed:Local"
  %l64 = alloca i1
  %l66 = alloca i1
  %l69 = alloca i32
  %l77 = alloca i32
  %l92 = alloca ptr
  %l93 = alloca ptr
  %l99 = alloca %"compiler/typed:Local"
  %l100 = alloca i32
  %l107 = alloca ptr
  %l110 = alloca i32
  %l114 = alloca %"compiler/typed:Capture"
  %l118 = alloca i1
  %l119 = alloca i1
  %l124 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i64
  %t90 = alloca { i64, [4 x i64] }, align 8
  %t139 = alloca { i64, [5 x i64] }, align 8
  %t157 = alloca { i64, [5 x i64] }, align 8
  %t185 = alloca { i64, [2 x i64] }, align 8
  %t252 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 13
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_Hbcd822ae67306ca6a025f17ed2cfb61c(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l16
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l16, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t11 = getelementptr %"compiler/check:frame", ptr %t9, i32 0, i32 8
  %t12 = load i32, ptr %l2, !tbaa !23
  %t15 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t11, i32 %t12)
  %t16 = extractvalue { i32, i64 } %t15, 1
  %t17 = extractvalue { i32, i64 } %t15, 0
  store i32 %t17, ptr %l22
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb3, label %ok.19
ok.19:
  store i64 %t16, ptr %l21
  br label %bb2
bb2:
  %t20 = load i64, ptr %l21, !tbaa !24
  store i64 %t20, ptr %l17, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t21 = load i64, ptr %l17, !tbaa !24
  store i64 %t21, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l5, !tbaa !24
  %t24 = icmp sge i64 %t22, 0
  br i1 %t24, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb8
bb7:
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t28 = getelementptr %"compiler/check:frame", ptr %t26, i32 0, i32 19
  %t29 = load i64, ptr %t28, !tbaa !24
  %t31 = icmp slt i64 %t29, 0
  store i1 %t31, ptr %l25, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l25, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t34 = load i64, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t34, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load ptr, ptr %l4, !tbaa !29
  %t39 = getelementptr %"compiler/check:frame", ptr %t37, i32 0, i32 19
  %t40 = load i64, ptr %t39, !tbaa !24
  %t41 = load i32, ptr %l2, !tbaa !23
  %t42 = load %"compiler/source:Span", ptr %l3
  %t47 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaptureIn(ptr %v0, ptr %t36, i64 %t40, i32 %t41, %"compiler/source:Span" %t42)
  store i64 %t47, ptr %l35
  br label %bb12
bb12:
  %t48 = load i64, ptr %l35, !tbaa !24
  store i64 %t48, ptr %l6, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t51 = icmp slt i64 %t49, 0
  br i1 %t51, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 11
  store ptr %t56, ptr %l40, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 13
  %t60 = load ptr, ptr %l4, !tbaa !29
  %t62 = getelementptr %"compiler/check:frame", ptr %t60, i32 0, i32 19
  %t63 = load i64, ptr %t62, !tbaa !24
  %t66 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_Hbcd822ae67306ca6a025f17ed2cfb61c(ptr %v0, ptr %v0, ptr %t59, i64 %t63)
  store ptr %t66, ptr %l45
  br label %bb16
bb16:
  %t67 = load ptr, ptr %l45, !tbaa !29
  %t69 = getelementptr %"compiler/check:frame", ptr %t67, i32 0, i32 0
  %t70 = load i64, ptr %t69, !tbaa !24
  %t71 = load ptr, ptr %l40, !tbaa !29
  %t73 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t71, i64 %t70)
  store ptr %t73, ptr %l48
  br label %bb17
bb17:
  %t74 = load ptr, ptr %l48, !tbaa !29
  %t76 = getelementptr %"compiler/typed:Body", ptr %t74, i32 0, i32 7
  %t77 = load i64, ptr %l6, !tbaa !24
  %t80 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t76, i64 %t77)
  store %"compiler/typed:Local" %t80, ptr %l52
  br label %bb18
bb18:
  %t81 = getelementptr %"compiler/typed:Local", ptr %l52, i32 0, i32 2
  %t82 = load i32, ptr %t81, !tbaa !23
  store i32 %t82, ptr %l7, !tbaa !23
  %t84 = load %"compiler/source:Span", ptr %l3
  %t85 = load i32, ptr %l7, !tbaa !23
  %t86 = load i64, ptr %l6, !tbaa !24
  %t88 = trunc i64 %t86 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t90
  %t91 = getelementptr { i64, [4 x i64] }, ptr %t90, i32 0, i32 0
  store i64 0, ptr %t91
  %t93 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t84, 0
  %t95 = insertvalue { %"compiler/source:Span", i32, i32 } %t93, i32 %t85, 1
  %t97 = insertvalue { %"compiler/source:Span", i32, i32 } %t95, i32 %t88, 2
  %t98 = getelementptr { i64, [4 x i64] }, ptr %t90, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t97, ptr %t98
  %t99 = load { i64, [4 x i64] }, ptr %t90
  %t101 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t99, ptr %t101
  store ptr %t101, ptr %l8, !tbaa !29
  %t103 = load i32, ptr %l7, !tbaa !23
  store i32 %t103, ptr %l9, !tbaa !23
  store ptr null, ptr %l10, !tbaa !29
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load i32, ptr %l7, !tbaa !23
  %t109 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t105, i32 %t106)
  store i1 %t109, ptr %l64
  br label %bb19
bb19:
  %t110 = load i1, ptr %l64, !tbaa !21
  %t111 = xor i1 %t110, true
  br i1 %t111, label %bb20, label %bb21
bb20:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load i32, ptr %l7, !tbaa !23
  %t117 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t113, i32 %t114)
  store i32 %t117, ptr %l69
  br label %bb22
bb21:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb23
bb22:
  %t118 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t119 = load i32, ptr %l69, !tbaa !23
  %t121 = icmp ne i32 %t119, %t118
  store i1 %t121, ptr %l66, !tbaa !21
  br label %bb23
bb23:
  %t123 = load i1, ptr %l66, !tbaa !21
  br i1 %t123, label %bb24, label %bb25
bb24:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/check:Checker", ptr %t124, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t129 = getelementptr %"compiler/generic:Program", ptr %t127, i32 0, i32 2
  %t130 = load i32, ptr %l7, !tbaa !23
  %t131 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t135 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t129, i32 %t130, i64 %t131)
  store i32 %t135, ptr %l77
  br label %bb26
bb25:
  %t136 = load %"compiler/source:Span", ptr %l3
  %t137 = load i32, ptr %l7, !tbaa !23
  %t138 = load ptr, ptr %l8, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t139
  %t140 = getelementptr { i64, [5 x i64] }, ptr %t139, i32 0, i32 0
  store i64 2, ptr %t140
  %t142 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t136, 0
  %t144 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t142, i32 %t137, 1
  %t146 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t144, ptr %t138, 2
  %t147 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t146, i32 -1, 3
  %t148 = getelementptr { i64, [5 x i64] }, ptr %t139, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t147, ptr %t148
  %t149 = load { i64, [5 x i64] }, ptr %t139
  %t151 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t149, ptr %t151
  store ptr %t151, ptr %l10, !tbaa !29
  br label %bb27
bb26:
  %t153 = load i32, ptr %l77, !tbaa !23
  store i32 %t153, ptr %l9, !tbaa !23
  %t154 = load %"compiler/source:Span", ptr %l3
  %t155 = load i32, ptr %l9, !tbaa !23
  %t156 = load ptr, ptr %l8, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t157
  %t158 = getelementptr { i64, [5 x i64] }, ptr %t157, i32 0, i32 0
  store i64 3, ptr %t158
  %t160 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t154, 0
  %t162 = insertvalue { %"compiler/source:Span", i32, ptr } %t160, i32 %t155, 1
  %t164 = insertvalue { %"compiler/source:Span", i32, ptr } %t162, ptr %t156, 2
  %t165 = getelementptr { i64, [5 x i64] }, ptr %t157, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t164, ptr %t165
  %t166 = load { i64, [5 x i64] }, ptr %t157
  %t168 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t166, ptr %t168
  store ptr %t168, ptr %l10, !tbaa !29
  br label %bb27
bb27:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/check:Checker", ptr %t170, i32 0, i32 11
  %t173 = load ptr, ptr %l4, !tbaa !29
  %t175 = getelementptr %"compiler/check:frame", ptr %t173, i32 0, i32 0
  %t176 = load i64, ptr %t175, !tbaa !24
  %t179 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t172, i64 %t176)
  store ptr %t179, ptr %l92
  br label %bb28
bb28:
  %t180 = load ptr, ptr %l92, !tbaa !29
  store ptr %t180, ptr %l11, !tbaa !29
  %t181 = load ptr, ptr %l11, !tbaa !29
  store ptr %t181, ptr %l93, !tbaa !29
  %t182 = load i32, ptr %l2, !tbaa !23
  %t183 = load %"compiler/source:Span", ptr %l3
  %t184 = load i32, ptr %l9, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t185
  %t186 = getelementptr { i64, [2 x i64] }, ptr %t185, i32 0, i32 0
  store i64 5, ptr %t186
  %t187 = load { i64, [2 x i64] }, ptr %t185
  %t193 = call %"compiler/typed:Local" @compiler_2ftyped_3aLocal_2ector(ptr %s0, i32 %t182, %"compiler/source:Span" %t183, i32 %t184, i32 0, i32 5, { i64, [2 x i64] } %t187)
  store %"compiler/typed:Local" %t193, ptr %l99
  br label %bb29
bb29:
  %t194 = load ptr, ptr %l93, !tbaa !29
  %t195 = load %"compiler/typed:Local", ptr %l99
  %t196 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddLocal(ptr %v0, ptr %t194, %"compiler/typed:Local" %t195)
  store i32 %t196, ptr %l100
  br label %bb30
bb30:
  %t197 = load i32, ptr %l100, !tbaa !23
  %t198 = sext i32 %t197 to i64
  store i64 %t198, ptr %l12, !tbaa !24
  %t200 = load ptr, ptr %l4, !tbaa !29
  %t202 = getelementptr %"compiler/check:frame", ptr %t200, i32 0, i32 8
  %t203 = load i32, ptr %l2, !tbaa !23
  %t204 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %t202, i32 %t203, i64 %t204)
  br label %bb31
bb31:
  %t208 = load ptr, ptr %l4, !tbaa !29
  %t210 = getelementptr %"compiler/check:frame", ptr %t208, i32 0, i32 25
  store ptr %t210, ptr %l107, !tbaa !29
  %t211 = load i64, ptr %l12, !tbaa !24
  %t213 = trunc i64 %t211 to i32
  store i32 %t213, ptr %l110, !tbaa !23
  %t215 = load ptr, ptr %l10, !tbaa !29
  %t217 = icmp eq ptr %t215, null
  br i1 %t217, label %bb32, label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_486b3db7a819736b_b4c2afa2fe5bd5af)
  unreachable
bb33:
  br label %bb34
bb34:
  %t219 = load ptr, ptr %l10, !tbaa !29
  %t220 = load i32, ptr %l110, !tbaa !23
  %t222 = call %"compiler/typed:Capture" @compiler_2ftyped_3aCapture_2ector(ptr %v0, ptr %v0, i32 %t220, ptr %t219)
  store %"compiler/typed:Capture" %t222, ptr %l114
  br label %bb35
bb35:
  %t223 = load %"compiler/typed:Capture", ptr %l114
  %t224 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store %"compiler/typed:Capture" %t223, ptr %t224
  %t225 = load ptr, ptr %l107, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aCapture_26_3e_2e_He39a1cf375adb47168dea91a05758aa9(ptr %v0, ptr %v0, ptr %t225, ptr %t224)
  br label %bb36
bb36:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load i32, ptr %l9, !tbaa !23
  %t231 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t227, i32 %t228)
  store i1 %t231, ptr %l118
  br label %bb37
bb37:
  %t232 = load i1, ptr %l118, !tbaa !21
  br i1 %t232, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l119, !tbaa !21
  br label %bb41
bb39:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t235 = getelementptr %"compiler/check:Checker", ptr %t233, i32 0, i32 1
  %t236 = load ptr, ptr %t235, !tbaa !29
  %t238 = getelementptr %"compiler/generic:Program", ptr %t236, i32 0, i32 2
  %t239 = load i32, ptr %l9, !tbaa !23
  %t242 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t238, i32 %t239)
  store i1 %t242, ptr %l124
  br label %bb40
bb40:
  %t243 = load i1, ptr %l124, !tbaa !21
  store i1 %t243, ptr %l119, !tbaa !21
  br label %bb41
bb41:
  %t244 = load i1, ptr %l119, !tbaa !21
  br i1 %t244, label %bb42, label %bb43
bb42:
  %t245 = load ptr, ptr %l11, !tbaa !29
  %t247 = getelementptr %"compiler/typed:Body", ptr %t245, i32 0, i32 6
  %t248 = load i64, ptr %l12, !tbaa !24
  %t250 = trunc i64 %t248 to i32
  store { i64, [1 x i64] } zeroinitializer, ptr %t252
  %t253 = getelementptr { i64, [1 x i64] }, ptr %t252, i32 0, i32 0
  store i64 4, ptr %t253
  %t255 = insertvalue { i32 } undef, i32 %t250, 0
  %t256 = getelementptr { i64, [1 x i64] }, ptr %t252, i32 0, i32 1
  store { i32 } %t255, ptr %t256
  %t257 = load { i64, [1 x i64] }, ptr %t252
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2ePu_Hdbf2db28b3dbd7714059bb41361f5f89(ptr %v0, ptr %t247, { i64, [1 x i64] } %t257)
  br label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb45
bb45:
  %t260 = load i64, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t260, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i1
  %l21 = alloca i32
  %l24 = alloca i1
  %l27 = alloca i1
  %l34 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l56 = alloca ptr
  %l57 = alloca i1
  %l64 = alloca i1
  %s5 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 15
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t18, i32 0, i32 2
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb27
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t26 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t22, ptr %t23)
  store i32 %t26, ptr %l21
  br label %bb6
bb6:
  %t27 = load i32, ptr %l21, !tbaa !23
  store i32 %t27, ptr %l4, !tbaa !23
  %t28 = load i32, ptr %l4, !tbaa !23
  %t30 = icmp slt i32 %t28, 0
  br i1 %t30, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb10
bb8:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l4, !tbaa !23
  %t36 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t32, i32 %t33)
  store i1 %t36, ptr %l27
  br label %bb9
bb9:
  %t37 = load i1, ptr %l27, !tbaa !21
  %t38 = xor i1 %t37, true
  store i1 %t38, ptr %l24, !tbaa !21
  br label %bb10
bb10:
  %t40 = load i1, ptr %l24, !tbaa !21
  br i1 %t40, label %bb11, label %bb12
bb11:
  store i1 false, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t42, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = getelementptr %"compiler/generic:Program", ptr %t45, i32 0, i32 2
  %t48 = load i32, ptr %l4, !tbaa !23
  %t51 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %t47, i32 %t48)
  store { i64, ptr } %t51, ptr %l34
  br label %bb14
bb14:
  %t52 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t52, ptr %l5, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t57 = icmp eq i64 %t55, 0
  br i1 %t57, label %bb15, label %bb16
bb15:
  store i1 false, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t60 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t60, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t62 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t62, 0
  store i64 %t64, ptr %l8, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s5
  %t66 = load i64, ptr %l7, !tbaa !24
  %t67 = load i64, ptr %l8, !tbaa !24
  %t70 = icmp slt i64 %t66, %t67
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb26
bb20:
  br label %bb21
bb21:
  %t74 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t74, ptr %l46, !tbaa !27
  %t75 = load i64, ptr %l7, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr i32, ptr %t78, i64 %t75
  %t80 = load i32, ptr %t79, !tbaa !33
  %t83 = load i32, ptr %l3, !tbaa !23
  %t86 = icmp eq i32 %t80, %t83
  br i1 %t86, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s5)
  store i1 true, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s5)
  br label %bb25
bb25:
  %t89 = load i64, ptr %l7, !tbaa !24
  %t91 = add i64 %t89, 1
  store i64 %t91, ptr %l7, !tbaa !24
  br label %bb18
bb26:
  store i1 false, ptr %rv
  br label %ret
bb27:
  %t94 = load ptr, ptr %l1, !tbaa !29
  store ptr %t94, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t95 = load ptr, ptr %l56, !tbaa !29
  %t96 = icmp ne ptr %t95, null
  br i1 %t96, label %bb28, label %bb29
bb28:
  %t98 = load ptr, ptr %l56, !tbaa !29
  %t99 = load i64, ptr %t98
  %t101 = icmp eq i64 %t99, 12
  store i1 %t101, ptr %l57, !tbaa !21
  br label %bb29
bb29:
  %t102 = load i1, ptr %l57, !tbaa !21
  br i1 %t102, label %bb30, label %bb31
bb30:
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t105 = getelementptr { i64, [5 x i64] }, ptr %t103, i32 0, i32 1
  %t106 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t105, i32 0, i32 1
  %t107 = load ptr, ptr %t106
  store ptr %t107, ptr %l10, !tbaa !29
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load ptr, ptr %l10, !tbaa !29
  %t113 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseWritten(ptr %v0, ptr %v1, ptr %t109, ptr %t110)
  store i1 %t113, ptr %l64
  br label %bb33
bb33:
  %t114 = load i1, ptr %l64, !tbaa !21
  store i1 %t114, ptr %rv
  br label %ret
bb34:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtIn(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i1
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i1
  %l28 = alloca i64
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i1
  %l46 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtIn(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i64 %t20, ptr %l17
  br label %bb6
bb6:
  %t21 = load i64, ptr %l17, !tbaa !24
  store i64 %t21, ptr %l8, !tbaa !24
  br label %bb29
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t23 = load ptr, ptr %l18, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l18, !tbaa !29
  %t27 = load i64, ptr %t26
  %t29 = icmp eq i64 %t27, 3
  store i1 %t29, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l19, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [5 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 1
  %t35 = load i32, ptr %t34
  store i32 %t35, ptr %l3
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [5 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l4, !tbaa !29
  br label %bb12
bb11:
  br label %bb17
bb12:
  %t43 = load i32, ptr %l3
  %t45 = trunc i64 47 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb13, label %bb14
bb13:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load ptr, ptr %l4, !tbaa !29
  %t52 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtIn(ptr %v0, ptr %v1, ptr %t48, ptr %t49)
  store i64 %t52, ptr %l31
  br label %bb15
bb14:
  store i64 -1, ptr %l28, !tbaa !24
  br label %bb16
bb15:
  %t53 = load i64, ptr %l31, !tbaa !24
  store i64 %t53, ptr %l28, !tbaa !24
  br label %bb16
bb16:
  %t54 = load i64, ptr %l28, !tbaa !24
  store i64 %t54, ptr %l8, !tbaa !24
  br label %bb29
bb17:
  %t55 = load ptr, ptr %l1, !tbaa !29
  store ptr %t55, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t56 = load ptr, ptr %l32, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb18, label %bb19
bb18:
  %t59 = load ptr, ptr %l32, !tbaa !29
  %t60 = load i64, ptr %t59
  %t62 = icmp eq i64 %t60, 5
  store i1 %t62, ptr %l33, !tbaa !21
  br label %bb19
bb19:
  %t63 = load i1, ptr %l33, !tbaa !21
  br i1 %t63, label %bb20, label %bb21
bb20:
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr { i64, [5 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t66, i32 0, i32 1
  %t68 = load i32, ptr %t67
  store i32 %t68, ptr %l5
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr { i64, [5 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t72, i32 0, i32 2
  %t74 = load ptr, ptr %t73
  store ptr %t74, ptr %l6, !tbaa !29
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr { i64, [5 x i64] }, ptr %t76, i32 0, i32 1
  %t79 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t78, i32 0, i32 3
  %t80 = load ptr, ptr %t79
  store ptr %t80, ptr %l7, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i32, ptr %l5
  %t84 = load ptr, ptr %l6, !tbaa !29
  %t85 = load ptr, ptr %l7, !tbaa !29
  %t90 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtOf(ptr %v0, ptr %v1, ptr %v1, ptr %t82, i32 %t83, ptr %t84, ptr %t85)
  store i64 %t90, ptr %l46
  br label %bb23
bb23:
  %t91 = load i64, ptr %l46, !tbaa !24
  store i64 %t91, ptr %l8, !tbaa !24
  br label %bb29
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store i64 -1, ptr %l8, !tbaa !24
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_54e68041531f6906_51860f3f569bf3d2)
  unreachable
bb29:
  %t92 = load i64, ptr %l8, !tbaa !24
  store i64 %t92, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtNamed(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i64
  %l5 = alloca ptr
  %l8 = alloca i64
  %l16 = alloca %"compiler/check:errBind"
  %s2 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %a0)
  store ptr %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l5, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 51
  %t9 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aerrBind_3e_2eLen_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load i64, ptr %l8, !tbaa !24
  %t11 = sub i64 %t10, 1
  store i64 %t11, ptr %l3, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t13 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp sge i64 %t13, 0
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb5:
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = getelementptr %"compiler/check:frame", ptr %t19, i32 0, i32 51
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = call %"compiler/check:errBind" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aerrBind_3e_2eAt_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %t21, i64 %t22)
  store %"compiler/check:errBind" %t25, ptr %l16
  br label %bb7
bb7:
  %t26 = getelementptr %"compiler/check:errBind", ptr %l16, i32 0, i32 0
  %t27 = load i32, ptr %t26, !tbaa !23
  %t31 = icmp eq i32 %t27, %a1
  br i1 %t31, label %bb8, label %bb9
bb8:
  %t33 = load i64, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  store i64 %t33, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = sub i64 %t35, 1
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb3
bb12:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtText(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i32
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca i64
  %l39 = alloca ptr
  %l42 = alloca ptr
  %l46 = alloca %"compiler/check:errBind"
  %l48 = alloca { i64, ptr }
  %l51 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l55 = alloca i32
  %l58 = alloca ptr
  %l60 = alloca i32
  %l62 = alloca i32
  %l63 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l64 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l66 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l70 = alloca i32
  %l79 = alloca { i64, ptr }
  %l86 = alloca i32
  %l92 = alloca i64
  %l95 = alloca i64
  %l116 = alloca { i64, ptr }
  %l119 = alloca i32
  %l131 = alloca i32
  %l136 = alloca i64
  %l142 = alloca ptr
  %l151 = alloca { i64, ptr }
  %l155 = alloca { i64, ptr }
  %l160 = alloca i64
  %l166 = alloca i64
  %l169 = alloca i64
  %l189 = alloca i1
  %l191 = alloca i64
  %l201 = alloca ptr
  %l202 = alloca { i64, ptr }
  %l203 = alloca ptr
  %l208 = alloca i32
  %l209 = alloca { i64, ptr }
  %l211 = alloca { i64, ptr }
  %l214 = alloca { i64, ptr }
  %l225 = alloca i64
  %l229 = alloca ptr
  %l230 = alloca ptr
  %l231 = alloca %"compiler/source:Span"
  %l232 = alloca ptr
  %l234 = alloca i64
  %l236 = alloca { i64, ptr }
  %l238 = alloca ptr
  %l240 = alloca i64
  %l245 = alloca ptr
  %l246 = alloca %"compiler/source:Span"
  %l247 = alloca i32
  %l248 = alloca i32
  %l249 = alloca ptr
  %l250 = alloca %"compiler/source:Span"
  %l254 = alloca %"compiler/check:errBind"
  %l256 = alloca ptr
  %l257 = alloca ptr
  %l258 = alloca %"compiler/source:Span"
  %l259 = alloca i32
  %l262 = alloca i64
  %l263 = alloca ptr
  %l265 = alloca ptr
  %l266 = alloca %"compiler/source:Span"
  %l267 = alloca i32
  %l268 = alloca ptr
  %l269 = alloca ptr
  %l270 = alloca %"compiler/source:Span"
  %l273 = alloca { i64, ptr }
  %l275 = alloca ptr
  %l278 = alloca %"compiler/typed:Cond"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %rv = alloca ptr
  %t512 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l39
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l39, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/generic:Program", ptr %t8, i32 0, i32 2
  store ptr %t10, ptr %l42, !tbaa !29
  %t11 = load ptr, ptr %l3, !tbaa !29
  %t13 = getelementptr %"compiler/check:frame", ptr %t11, i32 0, i32 51
  %t14 = load i64, ptr %l2, !tbaa !24
  %t17 = call %"compiler/check:errBind" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aerrBind_3e_2eAt_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %t13, i64 %t14)
  store %"compiler/check:errBind" %t17, ptr %l46
  br label %bb2
bb2:
  %t18 = getelementptr %"compiler/check:errBind", ptr %l46, i32 0, i32 2
  %t19 = load i32, ptr %t18, !tbaa !23
  %t20 = load ptr, ptr %l42, !tbaa !29
  %t22 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t20, i32 %t19)
  store { i64, ptr } %t22, ptr %l48
  br label %bb3
bb3:
  %t23 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t23, ptr %l4, !tbaa !27
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i64, ptr %l2, !tbaa !24
  %t28 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtNow(ptr %v0, ptr %s0, ptr %t24, i64 %t25)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, ptr %l51
  br label %bb4
bb4:
  %t29 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l51
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t29, ptr %l5
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/generic:Program", ptr %t33, i32 0, i32 2
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t35, { i64, ptr } { i64 3, ptr @.d6 })
  store i32 %t37, ptr %l55
  br label %bb5
bb5:
  %t38 = load i32, ptr %l55, !tbaa !23
  store i32 %t38, ptr %l6, !tbaa !23
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/generic:Program", ptr %t42, i32 0, i32 2
  store ptr %t44, ptr %l58, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t45)
  store i32 %t47, ptr %l60
  br label %bb6
bb6:
  %t48 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t49 = load ptr, ptr %l58, !tbaa !29
  %t50 = load i32, ptr %l60, !tbaa !23
  %t52 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t49, i32 %t50, i64 %t48)
  store i32 %t52, ptr %l62
  br label %bb7
bb7:
  %t53 = load i32, ptr %l62, !tbaa !23
  store i32 %t53, ptr %l7, !tbaa !23
  %t54 = load ptr, ptr @__olang_prog_scope
  %t55 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t54)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t55, ptr %l63
  br label %bb8
bb8:
  %t56 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l63
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t56, ptr %l8
  %t57 = load ptr, ptr @__olang_prog_scope
  %t58 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t57)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t58, ptr %l64
  br label %bb9
bb9:
  %t59 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l64
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t59, ptr %l9
  store ptr %l5, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t61 = load ptr, ptr %l10, !tbaa !29
  %t62 = load i64, ptr %l11, !tbaa !24
  %t65 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %s0, ptr %t61, i64 %t62)
  %t66 = extractvalue { i32, { i64, ptr } } %t65, 1
  %t67 = extractvalue { i32, { i64, ptr } } %t65, 0
  store i32 %t67, ptr %l70
  %t68 = icmp ne i32 %t67, 0
  br i1 %t68, label %bb12, label %ok.69
ok.69:
  store { i64, ptr } %t66, ptr %l69
  br label %bb11
bb11:
  %t70 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t70, ptr %l66, !tbaa !27
  br label %bb16
bb12:
  %t71 = load i32, ptr %l70, !tbaa !23
  %t72 = ashr i32 %t71, 16
  %t74 = icmp eq i32 %t72, 1
  br i1 %t74, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_e4cf7bb5bd488336_42dde517bf840672)
  unreachable
bb15:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb73
bb16:
  %t76 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t76, ptr %l12, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t77, 0
  store i64 %t79, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t81 = load i64, ptr %l14, !tbaa !24
  %t82 = load i64, ptr %l13, !tbaa !24
  %t85 = icmp slt i64 %t81, %t82
  %t87 = xor i1 %t85, true
  br i1 %t87, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb71
bb19:
  br label %bb20
bb20:
  %t89 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t89, ptr %l79, !tbaa !27
  %t90 = load i64, ptr %l14, !tbaa !24
  %t92 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr i32, ptr %t93, i64 %t90
  %t95 = load i32, ptr %t94, !tbaa !33
  store i32 %t95, ptr %l15, !tbaa !23
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  %t103 = load i32, ptr %l15, !tbaa !23
  %t106 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t102, i32 %t103)
  store i32 %t106, ptr %l86
  br label %bb21
bb21:
  %t107 = load i32, ptr %l86, !tbaa !23
  store i32 %t107, ptr %l16, !tbaa !23
  store i64 -1, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  %t108 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t108, 0
  store i64 %t110, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t112 = load i64, ptr %l19, !tbaa !24
  %t113 = load i64, ptr %l18, !tbaa !24
  %t116 = icmp sgt i64 %t112, %t113
  br i1 %t116, label %bb22, label %bb23
bb22:
  %t118 = load i64, ptr %l20, !tbaa !24
  %t120 = icmp sgt i64 %t118, 0
  br i1 %t120, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l92, !tbaa !24
  br label %bb27
bb24:
  %t122 = load i64, ptr %l19, !tbaa !24
  %t123 = load i64, ptr %l18, !tbaa !24
  %t126 = sub i64 %t122, %t123
  %t127 = load i64, ptr %l20, !tbaa !24
  %t130 = add i64 %t126, %t127
  %t132 = sub i64 %t130, 1
  %t133 = load i64, ptr %l20, !tbaa !24
  %t136 = sdiv i64 %t132, %t133
  store i64 %t136, ptr %l95, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l95, !tbaa !24
  br label %bb26
bb26:
  %t138 = load i64, ptr %l95, !tbaa !24
  store i64 %t138, ptr %l92, !tbaa !24
  br label %bb27
bb27:
  %t139 = load i64, ptr %l92, !tbaa !24
  store i64 %t139, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s5
  %t140 = load i64, ptr %l22, !tbaa !24
  %t141 = load i64, ptr %l21, !tbaa !24
  %t144 = icmp slt i64 %t140, %t141
  %t146 = xor i1 %t144, true
  br i1 %t146, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s5)
  br label %bb37
bb30:
  br label %bb31
bb31:
  %t148 = load i64, ptr %l18, !tbaa !24
  %t149 = load i64, ptr %l22, !tbaa !24
  %t150 = load i64, ptr %l20, !tbaa !24
  %t153 = mul i64 %t149, %t150
  %t156 = add i64 %t148, %t153
  store i64 %t156, ptr %l23, !tbaa !24
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/check:Checker", ptr %t158, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = getelementptr %"compiler/generic:Program", ptr %t161, i32 0, i32 2
  %t164 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t164, ptr %l116, !tbaa !27
  %t165 = load i64, ptr %l23, !tbaa !24
  %t167 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !27
  %t169 = getelementptr i32, ptr %t168, i64 %t165
  %t170 = load i32, ptr %t169, !tbaa !33
  %t173 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t163, i32 %t170)
  store i32 %t173, ptr %l119
  br label %bb32
bb32:
  %t174 = load i32, ptr %l16, !tbaa !23
  %t175 = load i32, ptr %l119, !tbaa !23
  %t177 = icmp eq i32 %t175, %t174
  br i1 %t177, label %bb33, label %bb34
bb33:
  %t179 = load i64, ptr %l23, !tbaa !24
  store i64 %t179, ptr %l17, !tbaa !24
  br label %bb35
bb34:
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s5)
  br label %bb36
bb36:
  %t181 = load i64, ptr %l22, !tbaa !24
  %t183 = add i64 %t181, 1
  store i64 %t183, ptr %l22, !tbaa !24
  br label %bb28
bb37:
  %t185 = load i64, ptr %l17, !tbaa !24
  %t187 = icmp slt i64 %t185, 0
  br i1 %t187, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s3)
  br label %bb70
bb39:
  br label %bb40
bb40:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/check:Checker", ptr %t189, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t194 = getelementptr %"compiler/generic:Program", ptr %t192, i32 0, i32 2
  %t195 = load i32, ptr %l16, !tbaa !23
  %t198 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t194, i32 %t195)
  store i32 %t198, ptr %l131
  br label %bb41
bb41:
  %t199 = load i32, ptr %l131, !tbaa !23
  store i32 %t199, ptr %l24, !tbaa !23
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/check:Checker", ptr %t200, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !29
  %t205 = getelementptr %"compiler/generic:Program", ptr %t203, i32 0, i32 2
  %t206 = load i32, ptr %l24, !tbaa !23
  %t209 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t205, i32 %t206)
  store i64 %t209, ptr %l136
  br label %bb42
bb42:
  %t210 = load i64, ptr %l136, !tbaa !24
  store i64 %t210, ptr %l25, !tbaa !24
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/check:Checker", ptr %t211, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t216 = getelementptr %"compiler/generic:Program", ptr %t214, i32 0, i32 0
  %t217 = load ptr, ptr %t216, !tbaa !29
  %t219 = getelementptr %"compiler/load:Loader", ptr %t217, i32 0, i32 5
  %t220 = load i64, ptr %l25, !tbaa !24
  %t223 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t219, i64 %t220)
  store ptr %t223, ptr %l142
  br label %bb43
bb43:
  %t224 = load ptr, ptr %l142, !tbaa !29
  %t226 = getelementptr %"compiler/load:Module", ptr %t224, i32 0, i32 2
  %t227 = load { i64, ptr }, ptr %t226, !tbaa !27
  %t228 = load i64, ptr %l25, !tbaa !24
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"compiler/check:Checker", ptr %t229, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !29
  %t234 = getelementptr %"compiler/generic:Program", ptr %t232, i32 0, i32 0
  %t235 = load ptr, ptr %t234, !tbaa !29
  %t237 = getelementptr %"compiler/load:Loader", ptr %t235, i32 0, i32 7
  %t238 = load i64, ptr %t237, !tbaa !24
  %t241 = icmp eq i64 %t228, %t238
  %t244 = call { i64, ptr } @compiler_2fload_2eErrQualifier(ptr %v0, ptr %s3, { i64, ptr } %t227, i1 %t241)
  store { i64, ptr } %t244, ptr %l151
  br label %bb44
bb44:
  %t245 = load { i64, ptr }, ptr %l151, !tbaa !27
  store { i64, ptr } %t245, ptr %l26, !tbaa !27
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t248 = getelementptr %"compiler/check:Checker", ptr %t246, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !29
  %t250 = load i32, ptr %l24, !tbaa !23
  %t253 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %t249, i32 %t250)
  store { i64, ptr } %t253, ptr %l155
  br label %bb45
bb45:
  %t254 = load { i64, ptr }, ptr %l155, !tbaa !27
  store { i64, ptr } %t254, ptr %l27, !tbaa !27
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t257 = getelementptr %"compiler/check:Checker", ptr %t255, i32 0, i32 1
  %t258 = load ptr, ptr %t257, !tbaa !29
  %t260 = getelementptr %"compiler/generic:Program", ptr %t258, i32 0, i32 2
  %t261 = load i32, ptr %l15, !tbaa !23
  %t264 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t260, i32 %t261)
  store i64 %t264, ptr %l160
  br label %bb46
bb46:
  %t265 = load i64, ptr %l160, !tbaa !65
  store i64 %t265, ptr %l28, !tbaa !65
  store i64 0, ptr %l29, !tbaa !24
  %t266 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t268 = extractvalue { i64, ptr } %t266, 0
  store i64 %t268, ptr %l30, !tbaa !24
  store i64 1, ptr %l31, !tbaa !24
  %t270 = load i64, ptr %l30, !tbaa !24
  %t271 = load i64, ptr %l29, !tbaa !24
  %t274 = icmp sgt i64 %t270, %t271
  br i1 %t274, label %bb47, label %bb48
bb47:
  %t276 = load i64, ptr %l31, !tbaa !24
  %t278 = icmp sgt i64 %t276, 0
  br i1 %t278, label %bb49, label %bb50
bb48:
  store i64 0, ptr %l166, !tbaa !24
  br label %bb52
bb49:
  %t280 = load i64, ptr %l30, !tbaa !24
  %t281 = load i64, ptr %l29, !tbaa !24
  %t284 = sub i64 %t280, %t281
  %t285 = load i64, ptr %l31, !tbaa !24
  %t288 = add i64 %t284, %t285
  %t290 = sub i64 %t288, 1
  %t291 = load i64, ptr %l31, !tbaa !24
  %t294 = sdiv i64 %t290, %t291
  store i64 %t294, ptr %l169, !tbaa !24
  br label %bb51
bb50:
  store i64 0, ptr %l169, !tbaa !24
  br label %bb51
bb51:
  %t296 = load i64, ptr %l169, !tbaa !24
  store i64 %t296, ptr %l166, !tbaa !24
  br label %bb52
bb52:
  %t297 = load i64, ptr %l166, !tbaa !24
  store i64 %t297, ptr %l32, !tbaa !24
  store i64 0, ptr %l33, !tbaa !24
  br label %bb53
bb53:
  store %olang.scope zeroinitializer, ptr %s10
  %t298 = load i64, ptr %l33, !tbaa !24
  %t299 = load i64, ptr %l32, !tbaa !24
  %t302 = icmp slt i64 %t298, %t299
  %t304 = xor i1 %t302, true
  br i1 %t304, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s10)
  br label %bb69
bb55:
  br label %bb56
bb56:
  %t306 = load i64, ptr %l29, !tbaa !24
  %t307 = load i64, ptr %l33, !tbaa !24
  %t308 = load i64, ptr %l31, !tbaa !24
  %t311 = mul i64 %t307, %t308
  %t314 = add i64 %t306, %t311
  store i64 %t314, ptr %l34, !tbaa !24
  %t316 = load i64, ptr %l34, !tbaa !24
  %t318 = icmp slt i64 %t316, 64
  br i1 %t318, label %bb57, label %bb58
bb57:
  %t320 = load i64, ptr %l28, !tbaa !65
  %t321 = load i64, ptr %l34, !tbaa !24
  store i64 %t321, ptr %l191, !tbaa !24
  %t322 = load i64, ptr %l191, !tbaa !24
  %t323 = load i64, ptr %l191, !tbaa !24
  %t324 = shl i64 1, %t323
  %t327 = and i64 %t320, %t324
  %t329 = icmp eq i64 %t327, 0
  store i1 %t329, ptr %l189, !tbaa !21
  br label %bb59
bb58:
  store i1 false, ptr %l189, !tbaa !21
  br label %bb59
bb59:
  %t331 = load i1, ptr %l189, !tbaa !21
  br i1 %t331, label %bb60, label %bb61
bb60:
  call void @__olang_scope_close(ptr %s10)
  br label %bb68
bb61:
  br label %bb62
bb62:
  %t332 = load i64, ptr %l17, !tbaa !24
  %t334 = add i64 %t332, 1
  %t336 = shl i64 %t334, 16
  %t337 = load i64, ptr %l34, !tbaa !24
  %t340 = or i64 %t336, %t337
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l8, i64 %t340)
  br label %bb63
bb63:
  store ptr %l9, ptr %l201, !tbaa !29
  %t343 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t343, ptr %l202, !tbaa !27
  %t344 = load ptr, ptr %l0, !tbaa !29
  store ptr %t344, ptr %l203, !tbaa !29
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t347 = getelementptr %"compiler/check:Checker", ptr %t345, i32 0, i32 1
  %t348 = load ptr, ptr %t347, !tbaa !29
  %t350 = getelementptr %"compiler/generic:Program", ptr %t348, i32 0, i32 2
  %t351 = load i32, ptr %l24, !tbaa !23
  %t354 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t350, i32 %t351)
  store i32 %t354, ptr %l208
  br label %bb64
bb64:
  %t355 = load ptr, ptr %l203, !tbaa !29
  %t356 = load i32, ptr %l208, !tbaa !23
  %t357 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t355, i32 %t356)
  store { i64, ptr } %t357, ptr %l209
  br label %bb65
bb65:
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t359 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t359, ptr %l211, !tbaa !27
  %t360 = load i64, ptr %l34, !tbaa !24
  %t362 = getelementptr { i64, ptr }, ptr %l211, i32 0, i32 1
  %t363 = load ptr, ptr %t362, !tbaa !27
  %t364 = getelementptr i32, ptr %t363, i64 %t360
  %t365 = load i32, ptr %t364, !tbaa !33
  %t368 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t358, i32 %t365)
  store { i64, ptr } %t368, ptr %l214
  br label %bb66
bb66:
  %t369 = load { i64, ptr }, ptr %l202, !tbaa !27
  %t370 = extractvalue { i64, ptr } %t369, 1
  %t371 = extractvalue { i64, ptr } %t369, 0
  %t372 = load { i64, ptr }, ptr %l209, !tbaa !27
  %t373 = extractvalue { i64, ptr } %t372, 1
  %t374 = extractvalue { i64, ptr } %t372, 0
  %t375 = add i64 %t371, %t374
  %t376 = extractvalue { i64, ptr } { i64 1, ptr @.d7 }, 1
  %t377 = extractvalue { i64, ptr } { i64 1, ptr @.d7 }, 0
  %t378 = add i64 %t375, %t377
  %t379 = load { i64, ptr }, ptr %l214, !tbaa !27
  %t380 = extractvalue { i64, ptr } %t379, 1
  %t381 = extractvalue { i64, ptr } %t379, 0
  %t382 = add i64 %t378, %t381
  %t383 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t382)
  call void @olang_textcopy(ptr %t383, ptr %t370, i64 %t371)
  %t384 = getelementptr i8, ptr %t383, i64 %t371
  call void @olang_textcopy(ptr %t384, ptr %t373, i64 %t374)
  %t385 = getelementptr i8, ptr %t384, i64 %t374
  call void @olang_textcopy(ptr %t385, ptr %t376, i64 %t377)
  %t386 = getelementptr i8, ptr %t385, i64 %t377
  call void @olang_textcopy(ptr %t386, ptr %t380, i64 %t381)
  %t387 = insertvalue { i64, ptr } undef, i64 %t382, 0
  %t388 = insertvalue { i64, ptr } %t387, ptr %t383, 1
  %t390 = extractvalue { i64, ptr } %t388, 0
  %t391 = extractvalue { i64, ptr } %t388, 1
  %t392 = mul i64 %t390, 1
  %t393 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t392)
  call void @llvm.memcpy.p0.p0.i64(ptr %t393, ptr %t391, i64 %t392, i1 false)
  %t394 = insertvalue { i64, ptr } undef, i64 %t390, 0
  %t395 = insertvalue { i64, ptr } %t394, ptr %t393, 1
  %t396 = load ptr, ptr %l201, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t396, { i64, ptr } %t395)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s10)
  br label %bb68
bb68:
  %t398 = load i64, ptr %l33, !tbaa !24
  %t400 = add i64 %t398, 1
  store i64 %t400, ptr %l33, !tbaa !24
  br label %bb53
bb69:
  call void @__olang_scope_close(ptr %s3)
  br label %bb70
bb70:
  %t402 = load i64, ptr %l14, !tbaa !24
  %t404 = add i64 %t402, 1
  store i64 %t404, ptr %l14, !tbaa !24
  br label %bb17
bb71:
  %t406 = load i64, ptr %l11, !tbaa !24
  %t407 = load i64, ptr %l13, !tbaa !24
  %t410 = add i64 %t406, %t407
  store i64 %t410, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb72
bb72:
  br label %bb10
bb73:
  %t413 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %s0, ptr %l9)
  store i64 %t413, ptr %l225
  br label %bb74
bb74:
  %t414 = load i64, ptr %l225, !tbaa !24
  %t415 = icmp eq i64 %t414, 0
  br i1 %t415, label %bb75, label %bb76
bb75:
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t418 = load %"compiler/source:Span", ptr %l1
  %t421 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t417, %"compiler/source:Span" %t418)
  store ptr %t421, ptr %l229
  br label %bb77
bb76:
  br label %bb78
bb77:
  call void @__olang_scope_close(ptr %s0)
  %t422 = load ptr, ptr %l229, !tbaa !29
  store ptr %t422, ptr %rv
  br label %ret
bb78:
  %t423 = load ptr, ptr %l0, !tbaa !29
  store ptr %t423, ptr %l230, !tbaa !29
  %t424 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t424, ptr %l231
  store ptr %l9, ptr %l232, !tbaa !29
  %t426 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %s0, ptr %l9)
  store i64 %t426, ptr %l234
  br label %bb79
bb79:
  %t427 = load i64, ptr %l234, !tbaa !24
  %t428 = sub i64 %t427, 1
  %t429 = load ptr, ptr %l232, !tbaa !29
  %t431 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s0, ptr %t429, i64 %t428)
  store { i64, ptr } %t431, ptr %l236
  br label %bb80
bb80:
  %t432 = load i32, ptr %l7, !tbaa !23
  %t433 = load ptr, ptr %l230, !tbaa !29
  %t434 = load %"compiler/source:Span", ptr %l231
  %t435 = load { i64, ptr }, ptr %l236, !tbaa !27
  %t437 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextConst(ptr %v0, ptr %s0, ptr %t433, %"compiler/source:Span" %t434, { i64, ptr } %t435, i32 %t432)
  store ptr %t437, ptr %l238
  br label %bb81
bb81:
  %t438 = load ptr, ptr %l238, !tbaa !29
  store ptr %t438, ptr %l35, !tbaa !29
  %t440 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %s0, ptr %l9)
  store i64 %t440, ptr %l240
  br label %bb82
bb82:
  %t441 = load i64, ptr %l240, !tbaa !24
  %t442 = sub i64 %t441, 2
  store i64 %t442, ptr %l36, !tbaa !24
  br label %bb83
bb83:
  store %olang.scope zeroinitializer, ptr %s17
  %t444 = load i64, ptr %l36, !tbaa !24
  %t446 = icmp sge i64 %t444, 0
  %t448 = xor i1 %t446, true
  br i1 %t448, label %bb84, label %bb85
bb84:
  call void @__olang_scope_close(ptr %s17)
  br label %bb96
bb85:
  br label %bb86
bb86:
  %t450 = load ptr, ptr %l0, !tbaa !29
  store ptr %t450, ptr %l245, !tbaa !29
  %t451 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t451, ptr %l246
  %t452 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t452, ptr %l247, !tbaa !23
  store i32 13, ptr %l248
  %t453 = load ptr, ptr %l0, !tbaa !29
  store ptr %t453, ptr %l249, !tbaa !29
  %t454 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t454, ptr %l250
  %t455 = load ptr, ptr %l3, !tbaa !29
  %t457 = getelementptr %"compiler/check:frame", ptr %t455, i32 0, i32 51
  %t458 = load i64, ptr %l2, !tbaa !24
  %t461 = call %"compiler/check:errBind" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aerrBind_3e_2eAt_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %t457, i64 %t458)
  store %"compiler/check:errBind" %t461, ptr %l254
  br label %bb87
bb87:
  %t462 = getelementptr %"compiler/check:errBind", ptr %l254, i32 0, i32 1
  %t463 = load i64, ptr %t462, !tbaa !24
  %t464 = load ptr, ptr %l249, !tbaa !29
  %t465 = load %"compiler/source:Span", ptr %l250
  %t467 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t464, %"compiler/source:Span" %t465, i64 %t463)
  store ptr %t467, ptr %l256
  br label %bb88
bb88:
  %t468 = load ptr, ptr %l0, !tbaa !29
  store ptr %t468, ptr %l257, !tbaa !29
  %t469 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t469, ptr %l258
  %t470 = load i32, ptr %l6, !tbaa !23
  store i32 %t470, ptr %l259, !tbaa !23
  %t471 = load i64, ptr %l36, !tbaa !24
  %t474 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l8, i64 %t471)
  store i64 %t474, ptr %l262
  br label %bb89
bb89:
  %t475 = load ptr, ptr %l257, !tbaa !29
  %t476 = load %"compiler/source:Span", ptr %l258
  %t477 = load i32, ptr %l259, !tbaa !23
  %t478 = load i64, ptr %l262, !tbaa !24
  %t479 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t475, %"compiler/source:Span" %t476, i32 %t477, i64 %t478)
  store ptr %t479, ptr %l263
  br label %bb90
bb90:
  %t480 = load ptr, ptr %l263, !tbaa !29
  %t481 = load ptr, ptr %l245, !tbaa !29
  %t482 = load %"compiler/source:Span", ptr %l246
  %t483 = load i32, ptr %l247, !tbaa !23
  %t484 = load i32, ptr %l248
  %t485 = load ptr, ptr %l256, !tbaa !29
  %t487 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t481, %"compiler/source:Span" %t482, i32 %t483, i32 %t484, ptr %t485, ptr %t480)
  store ptr %t487, ptr %l265
  br label %bb91
bb91:
  %t488 = load ptr, ptr %l265, !tbaa !29
  %t489 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t489, ptr %l266
  %t490 = load i32, ptr %l7, !tbaa !23
  store i32 %t490, ptr %l267, !tbaa !23
  store ptr %t488, ptr %l268, !tbaa !29
  %t492 = load ptr, ptr %l0, !tbaa !29
  store ptr %t492, ptr %l269, !tbaa !29
  %t493 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t493, ptr %l270
  %t494 = load i64, ptr %l36, !tbaa !24
  %t497 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s0, ptr %l9, i64 %t494)
  store { i64, ptr } %t497, ptr %l273
  br label %bb92
bb92:
  %t498 = load i32, ptr %l7, !tbaa !23
  %t499 = load ptr, ptr %l269, !tbaa !29
  %t500 = load %"compiler/source:Span", ptr %l270
  %t501 = load { i64, ptr }, ptr %l273, !tbaa !27
  %t503 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextConst(ptr %v0, ptr %s0, ptr %t499, %"compiler/source:Span" %t500, { i64, ptr } %t501, i32 %t498)
  store ptr %t503, ptr %l275
  br label %bb93
bb93:
  %t504 = load ptr, ptr %l275, !tbaa !29
  %t505 = load ptr, ptr %l35, !tbaa !29
  %t506 = load ptr, ptr %l268, !tbaa !29
  %t509 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t506, ptr %t504, ptr %t505)
  store %"compiler/typed:Cond" %t509, ptr %l278
  br label %bb94
bb94:
  %t510 = load %"compiler/typed:Cond", ptr %l278
  %t511 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Cond" %t510, ptr %t511
  store { i64, [5 x i64] } zeroinitializer, ptr %t512
  %t513 = getelementptr { i64, [5 x i64] }, ptr %t512, i32 0, i32 0
  store i64 11, ptr %t513
  %t514 = load %"compiler/source:Span", ptr %l266
  %t515 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t514, 0
  %t516 = load i32, ptr %l267, !tbaa !23
  %t517 = insertvalue { %"compiler/source:Span", i32, ptr } %t515, i32 %t516, 1
  %t519 = insertvalue { %"compiler/source:Span", i32, ptr } %t517, ptr %t511, 2
  %t520 = getelementptr { i64, [5 x i64] }, ptr %t512, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t519, ptr %t520
  %t521 = load { i64, [5 x i64] }, ptr %t512
  %t523 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t521, ptr %t523
  store ptr %t523, ptr %l35, !tbaa !29
  call void @__olang_scope_close(ptr %s17)
  br label %bb95
bb95:
  %t525 = load i64, ptr %l36, !tbaa !24
  %t527 = sub i64 %t525, 1
  store i64 %t527, ptr %l36, !tbaa !24
  br label %bb83
bb96:
  %t529 = load ptr, ptr %l35, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t529, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainCmp(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l27 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l39 = alloca %"compiler/source:Span"
  %l41 = alloca %"compiler/source:Span"
  %l43 = alloca { i64, ptr }
  %l45 = alloca %"compiler/source:Span"
  %l48 = alloca ptr
  %l49 = alloca ptr
  %l53 = alloca %"compiler/check:litv"
  %l59 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca ptr
  %l66 = alloca %"compiler/source:Span"
  %l67 = alloca %"compiler/source:Span"
  %l68 = alloca i32
  %l69 = alloca ptr
  %l72 = alloca ptr
  %l74 = alloca %"compiler/source:Span"
  %l76 = alloca %"compiler/source:Span"
  %l77 = alloca ptr
  %l80 = alloca ptr
  %l81 = alloca ptr
  %l85 = alloca %"compiler/check:litv"
  %l89 = alloca ptr
  %l94 = alloca ptr
  %l95 = alloca ptr
  %l96 = alloca %"compiler/source:Span"
  %l97 = alloca %"compiler/source:Span"
  %l98 = alloca i32
  %l99 = alloca ptr
  %l100 = alloca ptr
  %l102 = alloca %"compiler/source:Span"
  %l104 = alloca %"compiler/source:Span"
  %l105 = alloca ptr
  %l106 = alloca ptr
  %l107 = alloca %"compiler/source:Span"
  %l108 = alloca %"compiler/source:Span"
  %l109 = alloca i32
  %l110 = alloca ptr
  %l111 = alloca ptr
  %l113 = alloca %"compiler/source:Span"
  %l115 = alloca %"compiler/source:Span"
  %l116 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Chain", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l13, !tbaa !27
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr ptr, ptr %t8, i64 %t5
  %t10 = load ptr, ptr %t9, !tbaa !39
  store ptr %t10, ptr %l6, !tbaa !29
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t14 = getelementptr %"compiler/ast:Chain", ptr %t12, i32 0, i32 1
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l17, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = add i64 %t16, 1
  %t20 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr ptr, ptr %t21, i64 %t18
  %t23 = load ptr, ptr %t22, !tbaa !39
  store ptr %t23, ptr %l7, !tbaa !29
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr %"compiler/ast:Chain", ptr %t25, i32 0, i32 0
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l22, !tbaa !27
  %t29 = load i64, ptr %l3, !tbaa !24
  %t31 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr i32, ptr %t32, i64 %t29
  %t34 = load i32, ptr %t33
  store i32 %t34, ptr %l8
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t38 = icmp eq ptr %t36, null
  br i1 %t38, label %bb1, label %bb2
bb1:
  %t40 = load ptr, ptr %l5, !tbaa !29
  %t42 = icmp eq ptr %t40, null
  store i1 %t42, ptr %l27, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb3
bb3:
  %t44 = load i1, ptr %l27, !tbaa !21
  br i1 %t44, label %bb4, label %bb5
bb4:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load %"compiler/source:Span", ptr %l1
  %t47 = load i32, ptr %l8
  %t48 = load ptr, ptr %l6, !tbaa !29
  %t49 = load ptr, ptr %l7, !tbaa !29
  %t50 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t57 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebinary(ptr %v0, ptr %v1, ptr %v1, ptr %t45, %"compiler/source:Span" %t46, i32 %t47, ptr %t48, ptr %t49, i32 %t50)
  store ptr %t57, ptr %l36
  br label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t58 = load ptr, ptr %l36, !tbaa !29
  store ptr %t58, ptr %rv
  br label %ret
bb7:
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l37, !tbaa !29
  %t60 = load ptr, ptr %l6, !tbaa !29
  %t62 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t60)
  store %"compiler/source:Span" %t62, ptr %l39
  br label %bb8
bb8:
  %t63 = load ptr, ptr %l7, !tbaa !29
  %t65 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t63)
  store %"compiler/source:Span" %t65, ptr %l41
  br label %bb9
bb9:
  %t66 = load i32, ptr %l8
  %t68 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s0, i32 %t66)
  store { i64, ptr } %t68, ptr %l43
  br label %bb10
bb10:
  %t69 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  %t71 = load ptr, ptr %l37, !tbaa !29
  %t72 = load %"compiler/source:Span", ptr %l39
  %t73 = load %"compiler/source:Span", ptr %l41
  %t75 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t71, %"compiler/source:Span" %t72, %"compiler/source:Span" %t73, i64 %t70)
  store %"compiler/source:Span" %t75, ptr %l45
  br label %bb11
bb11:
  %t76 = load %"compiler/source:Span", ptr %l45
  store %"compiler/source:Span" %t76, ptr %l9
  %t77 = load ptr, ptr %l4, !tbaa !29
  %t79 = icmp eq ptr %t77, null
  br i1 %t79, label %bb12, label %bb13
bb12:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l48, !tbaa !29
  %t82 = load ptr, ptr %l6, !tbaa !29
  store ptr %t82, ptr %l49, !tbaa !29
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l6, !tbaa !29
  %t88 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t83, ptr %t84)
  store %"compiler/check:litv" %t88, ptr %l53
  br label %bb14
bb13:
  br label %bb29
bb14:
  %t89 = load ptr, ptr %l5, !tbaa !29
  %t91 = icmp eq ptr %t89, null
  br i1 %t91, label %bb15, label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_854899d5724a103b_e7dfb19072d83fa7)
  unreachable
bb16:
  br label %bb17
bb17:
  %t93 = load ptr, ptr %l5, !tbaa !29
  %t94 = load i32, ptr %l8
  %t95 = load %"compiler/source:Span", ptr %l9
  %t96 = load ptr, ptr %l48, !tbaa !29
  %t97 = load ptr, ptr %l49, !tbaa !29
  %t98 = load %"compiler/check:litv", ptr %l53
  %t102 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitBeside(ptr %v0, ptr %v1, ptr %t96, ptr %t97, %"compiler/check:litv" %t98, ptr %t93, i32 %t94, %"compiler/source:Span" %t95, i1 false)
  store ptr %t102, ptr %l59
  br label %bb18
bb18:
  %t103 = load ptr, ptr %l59, !tbaa !29
  store ptr %t103, ptr %l10, !tbaa !29
  %t104 = load ptr, ptr %l10, !tbaa !29
  %t106 = icmp eq ptr %t104, null
  br i1 %t106, label %bb19, label %bb20
bb19:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load %"compiler/source:Span", ptr %l1
  %t112 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t108, %"compiler/source:Span" %t109)
  store ptr %t112, ptr %l64
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  %t113 = load ptr, ptr %l64, !tbaa !29
  store ptr %t113, ptr %rv
  br label %ret
bb22:
  %t114 = load ptr, ptr %l0, !tbaa !29
  store ptr %t114, ptr %l65, !tbaa !29
  %t115 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t115, ptr %l66
  %t116 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t116, ptr %l67
  %t117 = load i32, ptr %l8
  store i32 %t117, ptr %l68
  %t118 = load ptr, ptr %l10, !tbaa !29
  store ptr %t118, ptr %l69, !tbaa !29
  %t119 = load ptr, ptr %l5, !tbaa !29
  %t121 = icmp eq ptr %t119, null
  br i1 %t121, label %bb23, label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_852b58c2eb82b3cc_e47a0c64d3951188)
  unreachable
bb24:
  br label %bb25
bb25:
  %t123 = load ptr, ptr %l5, !tbaa !29
  store ptr %t123, ptr %l72, !tbaa !29
  %t124 = load ptr, ptr %l6, !tbaa !29
  %t126 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t124)
  store %"compiler/source:Span" %t126, ptr %l74
  br label %bb26
bb26:
  %t127 = load ptr, ptr %l7, !tbaa !29
  %t129 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t127)
  store %"compiler/source:Span" %t129, ptr %l76
  br label %bb27
bb27:
  %t130 = load ptr, ptr %l65, !tbaa !29
  %t131 = load %"compiler/source:Span", ptr %l66
  %t132 = load %"compiler/source:Span", ptr %l67
  %t133 = load i32, ptr %l68
  %t134 = load ptr, ptr %l69, !tbaa !29
  %t135 = load ptr, ptr %l72, !tbaa !29
  %t136 = load %"compiler/source:Span", ptr %l74
  %t137 = load %"compiler/source:Span", ptr %l76
  %t138 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %t130, %"compiler/source:Span" %t131, %"compiler/source:Span" %t132, i32 %t133, ptr %t134, ptr %t135, %"compiler/source:Span" %t136, %"compiler/source:Span" %t137)
  store ptr %t138, ptr %l77
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s0)
  %t139 = load ptr, ptr %l77, !tbaa !29
  store ptr %t139, ptr %rv
  br label %ret
bb29:
  %t140 = load ptr, ptr %l5, !tbaa !29
  %t142 = icmp eq ptr %t140, null
  br i1 %t142, label %bb30, label %bb31
bb30:
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l80, !tbaa !29
  %t145 = load ptr, ptr %l7, !tbaa !29
  store ptr %t145, ptr %l81, !tbaa !29
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load ptr, ptr %l7, !tbaa !29
  %t151 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t146, ptr %t147)
  store %"compiler/check:litv" %t151, ptr %l85
  br label %bb32
bb31:
  br label %bb41
bb32:
  %t152 = load ptr, ptr %l4, !tbaa !29
  %t153 = load i32, ptr %l8
  %t154 = load %"compiler/source:Span", ptr %l9
  %t155 = load ptr, ptr %l80, !tbaa !29
  %t156 = load ptr, ptr %l81, !tbaa !29
  %t157 = load %"compiler/check:litv", ptr %l85
  %t161 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitBeside(ptr %v0, ptr %v1, ptr %t155, ptr %t156, %"compiler/check:litv" %t157, ptr %t152, i32 %t153, %"compiler/source:Span" %t154, i1 true)
  store ptr %t161, ptr %l89
  br label %bb33
bb33:
  %t162 = load ptr, ptr %l89, !tbaa !29
  store ptr %t162, ptr %l11, !tbaa !29
  %t163 = load ptr, ptr %l11, !tbaa !29
  %t165 = icmp eq ptr %t163, null
  br i1 %t165, label %bb34, label %bb35
bb34:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load %"compiler/source:Span", ptr %l1
  %t171 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t167, %"compiler/source:Span" %t168)
  store ptr %t171, ptr %l94
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_scope_close(ptr %s0)
  %t172 = load ptr, ptr %l94, !tbaa !29
  store ptr %t172, ptr %rv
  br label %ret
bb37:
  %t173 = load ptr, ptr %l0, !tbaa !29
  store ptr %t173, ptr %l95, !tbaa !29
  %t174 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t174, ptr %l96
  %t175 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t175, ptr %l97
  %t176 = load i32, ptr %l8
  store i32 %t176, ptr %l98
  %t177 = load ptr, ptr %l4, !tbaa !29
  store ptr %t177, ptr %l99, !tbaa !29
  %t178 = load ptr, ptr %l11, !tbaa !29
  store ptr %t178, ptr %l100, !tbaa !29
  %t179 = load ptr, ptr %l6, !tbaa !29
  %t181 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t179)
  store %"compiler/source:Span" %t181, ptr %l102
  br label %bb38
bb38:
  %t182 = load ptr, ptr %l7, !tbaa !29
  %t184 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t182)
  store %"compiler/source:Span" %t184, ptr %l104
  br label %bb39
bb39:
  %t185 = load ptr, ptr %l95, !tbaa !29
  %t186 = load %"compiler/source:Span", ptr %l96
  %t187 = load %"compiler/source:Span", ptr %l97
  %t188 = load i32, ptr %l98
  %t189 = load ptr, ptr %l99, !tbaa !29
  %t190 = load ptr, ptr %l100, !tbaa !29
  %t191 = load %"compiler/source:Span", ptr %l102
  %t192 = load %"compiler/source:Span", ptr %l104
  %t193 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %t185, %"compiler/source:Span" %t186, %"compiler/source:Span" %t187, i32 %t188, ptr %t189, ptr %t190, %"compiler/source:Span" %t191, %"compiler/source:Span" %t192)
  store ptr %t193, ptr %l105
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s0)
  %t194 = load ptr, ptr %l105, !tbaa !29
  store ptr %t194, ptr %rv
  br label %ret
bb41:
  %t195 = load ptr, ptr %l0, !tbaa !29
  store ptr %t195, ptr %l106, !tbaa !29
  %t196 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t196, ptr %l107
  %t197 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t197, ptr %l108
  %t198 = load i32, ptr %l8
  store i32 %t198, ptr %l109
  %t199 = load ptr, ptr %l4, !tbaa !29
  store ptr %t199, ptr %l110, !tbaa !29
  %t200 = load ptr, ptr %l5, !tbaa !29
  store ptr %t200, ptr %l111, !tbaa !29
  %t201 = load ptr, ptr %l6, !tbaa !29
  %t203 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t201)
  store %"compiler/source:Span" %t203, ptr %l113
  br label %bb42
bb42:
  %t204 = load ptr, ptr %l7, !tbaa !29
  %t206 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t204)
  store %"compiler/source:Span" %t206, ptr %l115
  br label %bb43
bb43:
  %t207 = load ptr, ptr %l106, !tbaa !29
  %t208 = load %"compiler/source:Span", ptr %l107
  %t209 = load %"compiler/source:Span", ptr %l108
  %t210 = load i32, ptr %l109
  %t211 = load ptr, ptr %l110, !tbaa !29
  %t212 = load ptr, ptr %l111, !tbaa !29
  %t213 = load %"compiler/source:Span", ptr %l113
  %t214 = load %"compiler/source:Span", ptr %l115
  %t215 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %t207, %"compiler/source:Span" %t208, %"compiler/source:Span" %t209, i32 %t210, ptr %t211, ptr %t212, %"compiler/source:Span" %t213, %"compiler/source:Span" %t214)
  store ptr %t215, ptr %l116
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s0)
  %t216 = load ptr, ptr %l116, !tbaa !29
  store ptr %t216, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echarValue(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l10 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
  store { i64, ptr } %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t7 = call { i64, ptr } @compiler_2fscan_2eLiteralBytes(ptr %v0, ptr %s0, { i64, ptr } %t6)
  store { i64, ptr } %t7, ptr %l6
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr i8, ptr %t16, i64 0
  %t18 = load i8, ptr %t17, !tbaa !32
  %t20 = zext i8 %t18 to i64
  store i64 %t20, ptr %l10, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l10, !tbaa !24
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t22 = load i64, ptr %l10, !tbaa !24
  store i64 %t22, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echosenAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca i1
  %l17 = alloca i1
  %l23 = alloca %"compiler/source:Span"
  %l27 = alloca i1
  %l33 = alloca %"compiler/source:Span"
  %l37 = alloca ptr
  %l43 = alloca %"compiler/source:Span"
  %l44 = alloca %"compiler/source:Span"
  %l45 = alloca ptr
  %l46 = alloca i1
  %l54 = alloca %"compiler/source:Span"
  %l55 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 11
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb28
bb5:
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Cond", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = icmp eq ptr %t25, null
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t31 = load ptr, ptr %l3, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Cond", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = icmp eq ptr %t34, null
  br i1 %t36, label %bb8, label %bb9
bb7:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb12
bb8:
  call void @__olang_check_failed(ptr @olang_loc_d9d408bf8806a5b7_73d051fbfd3f3593)
  unreachable
bb9:
  br label %bb10
bb10:
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Cond", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t41)
  store %"compiler/source:Span" %t43, ptr %l23
  br label %bb11
bb11:
  %t44 = getelementptr %"compiler/source:Span", ptr %l23, i32 0, i32 1
  %t45 = load i32, ptr %t44, !tbaa !23
  %t46 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t47 = load i32, ptr %t46, !tbaa !23
  %t50 = icmp sle i32 %t45, %t47
  store i1 %t50, ptr %l17, !tbaa !21
  br label %bb12
bb12:
  %t52 = load i1, ptr %l17, !tbaa !21
  br i1 %t52, label %bb13, label %bb14
bb13:
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Cond", ptr %t53, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = icmp eq ptr %t56, null
  br i1 %t58, label %bb15, label %bb16
bb14:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb19
bb15:
  call void @__olang_check_failed(ptr @olang_loc_d9d408bf8806a5b7_73d051fbfd3f3593)
  unreachable
bb16:
  br label %bb17
bb17:
  %t60 = load ptr, ptr %l3, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Cond", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t63)
  store %"compiler/source:Span" %t65, ptr %l33
  br label %bb18
bb18:
  %t66 = getelementptr %"compiler/source:Span", ptr %l33, i32 0, i32 0
  %t67 = load i32, ptr %t66, !tbaa !23
  %t68 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t69 = load i32, ptr %t68, !tbaa !23
  %t72 = icmp eq i32 %t67, %t69
  store i1 %t72, ptr %l27, !tbaa !21
  br label %bb19
bb19:
  %t74 = load i1, ptr %l27, !tbaa !21
  br i1 %t74, label %bb20, label %bb21
bb20:
  store ptr %a0, ptr %l37, !tbaa !29
  %t76 = load ptr, ptr %l3, !tbaa !29
  %t78 = getelementptr %"compiler/typed:Cond", ptr %t76, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = icmp eq ptr %t79, null
  br i1 %t81, label %bb22, label %bb23
bb21:
  br label %bb27
bb22:
  call void @__olang_check_failed(ptr @olang_loc_d9d408bf8806a5b7_73d051fbfd3f3593)
  unreachable
bb23:
  br label %bb24
bb24:
  %t83 = load ptr, ptr %l3, !tbaa !29
  %t85 = getelementptr %"compiler/typed:Cond", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t86)
  store %"compiler/source:Span" %t88, ptr %l43
  br label %bb25
bb25:
  %t89 = load ptr, ptr %l37, !tbaa !29
  %t90 = load %"compiler/source:Span", ptr %l43
  %t91 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAfter(ptr %v0, ptr %t89, %"compiler/source:Span" %t90, i64 2)
  store %"compiler/source:Span" %t91, ptr %l44
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  %t92 = load %"compiler/source:Span", ptr %l44
  store %"compiler/source:Span" %t92, ptr %rv
  br label %ret
bb27:
  br label %bb36
bb28:
  %t93 = load ptr, ptr %l1, !tbaa !29
  store ptr %t93, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t94 = load ptr, ptr %l45, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb29, label %bb30
bb29:
  %t97 = load ptr, ptr %l45, !tbaa !29
  %t98 = load i64, ptr %t97
  %t100 = icmp eq i64 %t98, 13
  store i1 %t100, ptr %l46, !tbaa !21
  br label %bb30
bb30:
  %t101 = load i1, ptr %l46, !tbaa !21
  br i1 %t101, label %bb31, label %bb32
bb31:
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t104 = getelementptr { i64, [5 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t104, i32 0, i32 0
  %t106 = load %"compiler/source:Span", ptr %t105
  store %"compiler/source:Span" %t106, ptr %l4
  br label %bb33
bb32:
  br label %bb35
bb33:
  store %olang.scope zeroinitializer, ptr %s3
  %t108 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 0
  %t109 = load i32, ptr %t108, !tbaa !23
  %t110 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 0
  %t111 = load i32, ptr %t110, !tbaa !23
  %t113 = add i32 %t111, 5
  %t116 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s3, i32 %t109, i32 %t113)
  store %"compiler/source:Span" %t116, ptr %l54
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t117 = load %"compiler/source:Span", ptr %l54
  store %"compiler/source:Span" %t117, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t118 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 -1, i32 -1)
  store %"compiler/source:Span" %t118, ptr %l55
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s0)
  %t119 = load %"compiler/source:Span", ptr %l55
  store %"compiler/source:Span" %t119, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econstCond(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l6 = alloca i1
  %l10 = alloca ptr
  %l12 = alloca ptr
  %l17 = alloca i32
  %l22 = alloca i32
  %l31 = alloca i64
  %l33 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t6 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsConst(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i1 %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load i1, ptr %l6, !tbaa !21
  %t8 = xor i1 %t7, true
  br i1 %t8, label %bb2, label %bb3
bb2:
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  store ptr %t14, ptr %l10, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t15)
  store ptr %t17, ptr %l12
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l12, !tbaa !29
  %t20 = getelementptr %"compiler/check:frame", ptr %t18, i32 0, i32 4
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t22 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t23 = load ptr, ptr %l10, !tbaa !29
  %t27 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFoldKnown(ptr %v0, ptr %v0, ptr %v1, ptr %t23, ptr %t20, ptr %t21, i32 %t22)
  store i32 %t27, ptr %l17
  br label %bb6
bb6:
  %t28 = load i32, ptr %l17, !tbaa !23
  store i32 %t28, ptr %l2, !tbaa !23
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t35 = load i32, ptr %l2, !tbaa !23
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t38, ptr %l22
  br label %bb7
bb7:
  %t39 = load i32, ptr %l22
  %t41 = trunc i64 26 to i32
  %t42 = icmp eq i32 %t39, %t41
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb8, label %bb9
bb8:
  store i64 -1, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 2
  %t53 = load i32, ptr %l2, !tbaa !23
  %t56 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t52, i32 %t53)
  store i64 %t56, ptr %l31
  br label %bb11
bb11:
  %t57 = load i64, ptr %l31, !tbaa !24
  %t58 = icmp ne i64 %t57, 0
  br i1 %t58, label %bb12, label %bb13
bb12:
  store i64 1, ptr %l33, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb14
bb14:
  %t60 = load i64, ptr %l33, !tbaa !24
  store i64 %t60, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econversionAt(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { { i64, [3 x i64] }, { i64, ptr } }
  %l17 = alloca ptr
  %l21 = alloca i1
  %l25 = alloca i1
  %l27 = alloca i1
  %l28 = alloca i1
  %l30 = alloca i1
  %l40 = alloca { i64, ptr }
  %l43 = alloca ptr
  %l46 = alloca { i64, [2 x i64] }
  %l51 = alloca i32
  %l54 = alloca i64
  %l62 = alloca ptr
  %l63 = alloca ptr
  %l65 = alloca %"compiler/generic:Context"
  %l67 = alloca ptr
  %l70 = alloca i32
  %l73 = alloca i64
  %l75 = alloca ptr
  %l76 = alloca %"compiler/source:Span"
  %l77 = alloca ptr
  %l78 = alloca %"compiler/source:Span"
  %l82 = alloca ptr
  %l84 = alloca ptr
  %l89 = alloca ptr
  %l90 = alloca ptr
  %l94 = alloca { i64, ptr }
  %l95 = alloca %"compiler/typed:Block"
  %l105 = alloca { { i64, [3 x i64] }, { i64, ptr } }
  %l107 = alloca { i64, ptr }
  %l108 = alloca i64
  %l109 = alloca { i64, ptr }
  %l111 = alloca ptr
  %l112 = alloca i64
  %l113 = alloca i64
  %l114 = alloca %"compiler/source:Span"
  %l115 = alloca i64
  %l116 = alloca %"compiler/source:Span"
  %l117 = alloca { i64, ptr }
  %l118 = alloca { i64, [3 x i64] }
  %l121 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l127 = alloca %"compiler/check:ContractAsk"
  %s0 = alloca %olang.scope
  %t70 = alloca { i64, [2 x i64] }, align 8
  %t154 = alloca { i64, [3 x i64] }, align 8
  %t266 = alloca %"compiler/check:ContractAsk", align 8
  %t277 = alloca %"compiler/check:ContractAsk", align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l17
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l17, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 47
  %t8 = load i64, ptr %t7, !tbaa !24
  %t10 = icmp ne i64 %t8, 0
  br i1 %t10, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb4
bb3:
  %t12 = load ptr, ptr %l5, !tbaa !29
  %t14 = getelementptr %"compiler/check:frame", ptr %t12, i32 0, i32 0
  %t15 = load i64, ptr %t14, !tbaa !24
  %t17 = icmp slt i64 %t15, 0
  store i1 %t17, ptr %l21, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l21, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb8
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eevalOnly(ptr %v0, ptr %t20)
  store i1 %t22, ptr %l27
  br label %bb7
bb7:
  %t23 = load i1, ptr %l27, !tbaa !21
  store i1 %t23, ptr %l25, !tbaa !21
  br label %bb8
bb8:
  %t24 = load i1, ptr %l25, !tbaa !21
  br i1 %t24, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb12
bb10:
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t27 = call i1 @compiler_2fcheck_2eclosedExpr(ptr %v0, ptr %t25)
  store i1 %t27, ptr %l30
  br label %bb11
bb11:
  %t28 = load i1, ptr %l30, !tbaa !21
  %t29 = xor i1 %t28, true
  store i1 %t29, ptr %l28, !tbaa !21
  br label %bb12
bb12:
  %t31 = load i1, ptr %l28, !tbaa !21
  br i1 %t31, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  br label %bb15
bb15:
  %t32 = load ptr, ptr %l5, !tbaa !29
  %t34 = getelementptr %"compiler/check:frame", ptr %t32, i32 0, i32 1
  %t35 = load i64, ptr %t34, !tbaa !24
  store i64 %t35, ptr %l6, !tbaa !24
  %t37 = load ptr, ptr %l5, !tbaa !29
  %t39 = getelementptr %"compiler/check:frame", ptr %t37, i32 0, i32 2
  %t40 = load i64, ptr %t39, !tbaa !24
  store i64 %t40, ptr %l7, !tbaa !24
  %t42 = load ptr, ptr %l5, !tbaa !29
  %t44 = getelementptr %"compiler/check:frame", ptr %t42, i32 0, i32 0
  %t45 = load i64, ptr %t44, !tbaa !24
  store i64 %t45, ptr %l8, !tbaa !24
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load %"compiler/source:Span", ptr %l2
  %t51 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t47, %"compiler/source:Span" %t48)
  store { i64, ptr } %t51, ptr %l40
  br label %bb16
bb16:
  %t52 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 1
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t55 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t54)
  call void @olang_textcopy(ptr %t55, ptr %t53, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t60 = extractvalue { i64, ptr } %t57, 1
  %t61 = mul i64 %t59, 1
  %t62 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t61)
  call void @llvm.memcpy.p0.p0.i64(ptr %t62, ptr %t60, i64 %t61, i1 false)
  %t63 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  store { i64, ptr } %t64, ptr %l9, !tbaa !27
  %t66 = load ptr, ptr %l0, !tbaa !29
  store ptr %t66, ptr %l43, !tbaa !29
  %t67 = load i64, ptr %l6, !tbaa !24
  %t68 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t69 = load i32, ptr %t68, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t70
  %t71 = getelementptr { i64, [2 x i64] }, ptr %t70, i32 0, i32 0
  store i64 7, ptr %t71
  %t73 = insertvalue { i64, i32 } undef, i64 %t67, 0
  %t75 = insertvalue { i64, i32 } %t73, i32 %t69, 1
  %t76 = getelementptr { i64, [2 x i64] }, ptr %t70, i32 0, i32 1
  store { i64, i32 } %t75, ptr %t76
  %t77 = load { i64, [2 x i64] }, ptr %t70
  store { i64, [2 x i64] } %t77, ptr %l46
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/check:Checker", ptr %t78, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t83 = getelementptr %"compiler/generic:Program", ptr %t81, i32 0, i32 2
  %t84 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t87 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t83, i32 0, i32 %t84, i32 0, i32 0, i64 0)
  store i32 %t87, ptr %l51
  br label %bb17
bb17:
  %t88 = load i64, ptr %l6, !tbaa !24
  %t89 = load %"compiler/source:Span", ptr %l1
  %t90 = load ptr, ptr %l43, !tbaa !29
  %t91 = load { i64, [2 x i64] }, ptr %l46
  %t92 = load i32, ptr %l51, !tbaa !23
  %t95 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t90, { i64, [2 x i64] } %t91, i32 %t92, i64 %t88, %"compiler/source:Span" %t89)
  store i64 %t95, ptr %l54
  br label %bb18
bb18:
  %t96 = load i64, ptr %l54, !tbaa !24
  store i64 %t96, ptr %l10, !tbaa !24
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 16
  %t100 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t99, i64 %t100, i64 1)
  br label %bb19
bb19:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load i64, ptr %l10, !tbaa !24
  %t105 = load i64, ptr %l6, !tbaa !24
  %t106 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t111 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t103, i64 %t104, i64 %t105, i32 %t106, i32 0)
  store ptr %t111, ptr %l62
  br label %bb20
bb20:
  %t112 = load ptr, ptr %l62, !tbaa !29
  store ptr %t112, ptr %l63, !tbaa !29
  %t114 = load i64, ptr %l6, !tbaa !24
  %t116 = call %"compiler/generic:Context" @compiler_2fgeneric_3aContext_2ector(ptr %v0, i64 %t114, i64 -1)
  store %"compiler/generic:Context" %t116, ptr %l65
  br label %bb21
bb21:
  %t117 = load %"compiler/generic:Context", ptr %l65
  %t118 = load ptr, ptr %l63, !tbaa !29
  %t119 = getelementptr %"compiler/check:frame", ptr %t118, i32 0, i32 4
  store %"compiler/generic:Context" %t117, ptr %t119
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t120)
  store ptr %t122, ptr %l67
  br label %bb22
bb22:
  %t123 = load %"compiler/source:Span", ptr %l1
  %t124 = load ptr, ptr %l67, !tbaa !29
  %t127 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %t124, i32 -1, i32 0, %"compiler/source:Span" %t123)
  store i32 %t127, ptr %l70
  br label %bb23
bb23:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/check:Checker", ptr %t128, i32 0, i32 33
  %t132 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t130)
  store i64 %t132, ptr %l73
  br label %bb24
bb24:
  %t133 = load i64, ptr %l73, !tbaa !24
  store i64 %t133, ptr %l12, !tbaa !24
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t134, i32 0, i32 33
  store ptr %t136, ptr %l75, !tbaa !29
  %t137 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t137, ptr %l76
  %t138 = load ptr, ptr %l0, !tbaa !29
  store ptr %t138, ptr %l77, !tbaa !29
  %t139 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t139, ptr %l78
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load ptr, ptr %l3, !tbaa !29
  %t142 = load i64, ptr %l8, !tbaa !24
  %t146 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v0, ptr %t140, ptr %t141, i64 %t142)
  store ptr %t146, ptr %l82
  br label %bb25
bb25:
  %t147 = load i32, ptr %l4, !tbaa !23
  %t148 = load ptr, ptr %l77, !tbaa !29
  %t149 = load %"compiler/source:Span", ptr %l78
  %t150 = load ptr, ptr %l82, !tbaa !29
  %t152 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efitsTest(ptr %v0, ptr %t148, %"compiler/source:Span" %t149, ptr %t150, i32 %t147)
  store ptr %t152, ptr %l84
  br label %bb26
bb26:
  %t153 = load ptr, ptr %l84, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t154
  %t155 = getelementptr { i64, [3 x i64] }, ptr %t154, i32 0, i32 0
  store i64 6, ptr %t155
  %t156 = load %"compiler/source:Span", ptr %l76
  %t157 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t156, 0
  %t159 = insertvalue { %"compiler/source:Span", ptr } %t157, ptr %t153, 1
  %t160 = getelementptr { i64, [3 x i64] }, ptr %t154, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t159, ptr %t160
  %t161 = load { i64, [3 x i64] }, ptr %t154
  %t163 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t161, ptr %t163
  %t164 = load ptr, ptr %l75, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v0, ptr %t164, ptr %t163)
  br label %bb27
bb27:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t166)
  store ptr %t168, ptr %l89
  br label %bb28
bb28:
  %t169 = load ptr, ptr %l89, !tbaa !29
  store ptr %t169, ptr %l90, !tbaa !29
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/check:Checker", ptr %t170, i32 0, i32 33
  %t173 = load i64, ptr %l12, !tbaa !24
  %t176 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t172, i64 %t173)
  store { i64, ptr } %t176, ptr %l94
  br label %bb29
bb29:
  %t177 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t178 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 0, { i64, ptr } %t177)
  store %"compiler/typed:Block" %t178, ptr %l95
  br label %bb30
bb30:
  %t179 = load %"compiler/typed:Block", ptr %l95
  %t180 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t179, ptr %t180
  %t182 = load ptr, ptr %l90, !tbaa !29
  %t183 = getelementptr %"compiler/typed:Body", ptr %t182, i32 0, i32 11
  store ptr %t180, ptr %t183, !tbaa !29
  %t184 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t184)
  br label %bb31
bb31:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = getelementptr %"compiler/check:Checker", ptr %t186, i32 0, i32 16
  %t189 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t188, i64 %t189, i64 2)
  br label %bb32
bb32:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/check:Checker", ptr %t192, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !29
  %t197 = getelementptr %"compiler/generic:Program", ptr %t195, i32 0, i32 0
  %t198 = load ptr, ptr %t197, !tbaa !29
  %t200 = getelementptr %"compiler/load:Loader", ptr %t198, i32 0, i32 4
  %t201 = load ptr, ptr %t200, !tbaa !29
  %t203 = call { { i64, [3 x i64] }, { i64, ptr } } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTopContext(ptr %v0, ptr %s0, ptr %t201)
  store { { i64, [3 x i64] }, { i64, ptr } } %t203, ptr %l105
  br label %bb33
bb33:
  %t204 = load { { i64, [3 x i64] }, { i64, ptr } }, ptr %l105
  store { { i64, [3 x i64] }, { i64, ptr } } %t204, ptr %l13
  %t205 = getelementptr { { i64, [3 x i64] }, { i64, ptr } }, ptr %l13, i32 0, i32 0
  %t206 = load { i64, [3 x i64] }, ptr %t205
  %t208 = getelementptr { { i64, [3 x i64] }, { i64, ptr } }, ptr %l13, i32 0, i32 1
  %t209 = load { i64, ptr }, ptr %t208, !tbaa !27
  store { i64, ptr } %t209, ptr %l107, !tbaa !27
  %t210 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t210, 0
  store i64 %t211, ptr %l108, !tbaa !24
  %t212 = load i64, ptr %l108, !tbaa !24
  %t213 = mul i64 %t212, 1
  %t214 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t213)
  %t215 = insertvalue { i64, ptr } undef, i64 %t212, 0
  %t216 = insertvalue { i64, ptr } %t215, ptr %t214, 1
  store { i64, ptr } %t216, ptr %l109, !tbaa !27
  %t217 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !27
  %t219 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t220 = load ptr, ptr %t219, !tbaa !27
  %t221 = load i64, ptr %l108, !tbaa !24
  %t222 = mul i64 %t221, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t218, ptr %t220, i64 %t222, i1 false)
  %t223 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t226 = getelementptr %"compiler/check:Checker", ptr %t224, i32 0, i32 79
  store ptr %t226, ptr %l111, !tbaa !29
  %t227 = load i64, ptr %l10, !tbaa !24
  store i64 %t227, ptr %l112, !tbaa !24
  %t228 = load i64, ptr %l7, !tbaa !24
  store i64 %t228, ptr %l113, !tbaa !24
  %t229 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t229, ptr %l114
  %t230 = load i64, ptr %l7, !tbaa !24
  store i64 %t230, ptr %l115, !tbaa !24
  %t231 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t231, ptr %l116
  %t232 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t232, ptr %l117, !tbaa !27
  store { i64, [3 x i64] } %t206, ptr %l118
  %t236 = extractvalue { i64, ptr } %t223, 1
  %t237 = extractvalue { i64, ptr } %t223, 0
  %t238 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t237)
  call void @olang_textcopy(ptr %t238, ptr %t236, i64 %t237)
  %t239 = insertvalue { i64, ptr } undef, i64 %t237, 0
  %t240 = insertvalue { i64, ptr } %t239, ptr %t238, 1
  %t242 = extractvalue { i64, ptr } %t240, 0
  %t243 = extractvalue { i64, ptr } %t240, 1
  %t244 = mul i64 %t242, 1
  %t245 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t244)
  call void @llvm.memcpy.p0.p0.i64(ptr %t245, ptr %t243, i64 %t244, i1 false)
  %t246 = insertvalue { i64, ptr } undef, i64 %t242, 0
  %t247 = insertvalue { i64, ptr } %t246, ptr %t245, 1
  store { i64, ptr } %t247, ptr %l121, !tbaa !27
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load i32, ptr %l4, !tbaa !23
  %t252 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t248, i32 %t249)
  store { i64, ptr } %t252, ptr %l124
  br label %bb34
bb34:
  %t253 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t254 = extractvalue { i64, ptr } %t253, 1
  %t255 = extractvalue { i64, ptr } %t253, 0
  %t256 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t255)
  call void @olang_textcopy(ptr %t256, ptr %t254, i64 %t255)
  %t257 = insertvalue { i64, ptr } undef, i64 %t255, 0
  %t258 = insertvalue { i64, ptr } %t257, ptr %t256, 1
  %t260 = extractvalue { i64, ptr } %t258, 0
  %t261 = extractvalue { i64, ptr } %t258, 1
  %t262 = mul i64 %t260, 1
  %t263 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t262)
  call void @llvm.memcpy.p0.p0.i64(ptr %t263, ptr %t261, i64 %t262, i1 false)
  %t264 = insertvalue { i64, ptr } undef, i64 %t260, 0
  %t265 = insertvalue { i64, ptr } %t264, ptr %t263, 1
  %t267 = load i64, ptr %l112, !tbaa !24
  %t268 = load i64, ptr %l113, !tbaa !24
  %t269 = load %"compiler/source:Span", ptr %l114
  %t270 = load i64, ptr %l115, !tbaa !24
  %t271 = load %"compiler/source:Span", ptr %l116
  %t272 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t273 = load { i64, [3 x i64] }, ptr %l118
  %t274 = load { i64, ptr }, ptr %l121, !tbaa !27
  call void @compiler_2fcheck_3aContractAsk_2ector(ptr %t266, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, i64 %t267, i64 %t268, %"compiler/source:Span" %t269, i64 %t270, %"compiler/source:Span" %t271, { i64, ptr } { i64 0, ptr @.d8 }, { i64, ptr } %t272, { i64, [3 x i64] } %t273, { i64, ptr } %t274, { i64, ptr } %t265)
  call void @llvm.memmove.p0.p0.i64(ptr %l127, ptr %t266, i64 136, i1 false)
  br label %bb35
bb35:
  %t276 = load ptr, ptr %l111, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %t277, ptr %l127, i64 136, i1 false)
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aContractAsk_3e_2_H1e0eaace9d10c5af057a64b660c4ff1f(ptr %v0, ptr %v0, ptr %t276, ptr %t277)
  br label %bb36
bb36:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr %"compiler/check:Checker", ptr %t278, i32 0, i32 80
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t280, i64 -1)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecountPost(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, i64, i64 }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l13 = alloca i64
  %l17 = alloca { i64, i64, i64 }
  %l21 = alloca ptr
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca %"compiler/source:Span"
  %l25 = alloca i32
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca %"compiler/source:Span"
  %l34 = alloca i32
  %l35 = alloca i32
  %l39 = alloca ptr
  %l40 = alloca ptr
  %l41 = alloca %"compiler/source:Span"
  %l43 = alloca i32
  %l44 = alloca ptr
  %l46 = alloca ptr
  %l54 = alloca ptr
  %rv = alloca ptr
  %t38 = alloca { i64, [4 x i64] }, align 8
  %t79 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store ptr null, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 33
  %t10 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l13
  br label %bb4
bb4:
  %t11 = load i64, ptr %l13, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load %"compiler/source:Span", ptr %l1
  %t17 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t12, i32 3, %"compiler/source:Span" %t13)
  store { i64, i64, i64 } %t17, ptr %l17
  br label %bb5
bb5:
  %t18 = load { i64, i64, i64 }, ptr %l17
  store { i64, i64, i64 } %t18, ptr %l4
  %t19 = getelementptr { i64, i64, i64 }, ptr %l4, i32 0, i32 0
  %t20 = load i64, ptr %t19, !tbaa !24
  store i64 %t20, ptr %l5, !tbaa !24
  %t22 = getelementptr { i64, i64, i64 }, ptr %l4, i32 0, i32 1
  %t23 = load i64, ptr %t22, !tbaa !24
  store i64 %t23, ptr %l6, !tbaa !24
  %t25 = getelementptr { i64, i64, i64 }, ptr %l4, i32 0, i32 2
  %t26 = load i64, ptr %t25, !tbaa !24
  store i64 %t26, ptr %l7, !tbaa !24
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l21, !tbaa !29
  %t29 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t29, ptr %l22
  %t30 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t30, ptr %l23
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t31)
  store i32 %t33, ptr %l25
  br label %bb6
bb6:
  %t34 = load i64, ptr %l2, !tbaa !24
  %t36 = trunc i64 %t34 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t38
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 0
  store i64 0, ptr %t39
  %t40 = load %"compiler/source:Span", ptr %l23
  %t41 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t40, 0
  %t42 = load i32, ptr %l25, !tbaa !23
  %t43 = insertvalue { %"compiler/source:Span", i32, i32 } %t41, i32 %t42, 1
  %t45 = insertvalue { %"compiler/source:Span", i32, i32 } %t43, i32 %t36, 2
  %t46 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t45, ptr %t46
  %t47 = load { i64, [4 x i64] }, ptr %t38
  %t49 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t47, ptr %t49
  store ptr %t49, ptr %l30, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l31, !tbaa !29
  %t51 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t51, ptr %l32
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t52)
  store i32 %t54, ptr %l34
  br label %bb7
bb7:
  store i32 3, ptr %l35
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load %"compiler/source:Span", ptr %l1
  %t57 = load i64, ptr %l2, !tbaa !24
  %t61 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t55, %"compiler/source:Span" %t56, i64 %t57)
  store ptr %t61, ptr %l39
  br label %bb8
bb8:
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l40, !tbaa !29
  %t63 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t63, ptr %l41
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t64)
  store i32 %t66, ptr %l43
  br label %bb9
bb9:
  %t67 = load ptr, ptr %l40, !tbaa !29
  %t68 = load %"compiler/source:Span", ptr %l41
  %t69 = load i32, ptr %l43, !tbaa !23
  %t70 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t67, %"compiler/source:Span" %t68, i32 %t69, i64 1)
  store ptr %t70, ptr %l44
  br label %bb10
bb10:
  %t71 = load ptr, ptr %l44, !tbaa !29
  %t72 = load ptr, ptr %l31, !tbaa !29
  %t73 = load %"compiler/source:Span", ptr %l32
  %t74 = load i32, ptr %l34, !tbaa !23
  %t75 = load i32, ptr %l35
  %t76 = load ptr, ptr %l39, !tbaa !29
  %t78 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t72, %"compiler/source:Span" %t73, i32 %t74, i32 %t75, ptr %t76, ptr %t71)
  store ptr %t78, ptr %l46
  br label %bb11
bb11:
  store { i64, [3 x i64] } zeroinitializer, ptr %t79
  %t80 = getelementptr { i64, [3 x i64] }, ptr %t79, i32 0, i32 0
  store i64 1, ptr %t80
  %t81 = load %"compiler/source:Span", ptr %l22
  %t82 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t81, 0
  %t83 = load ptr, ptr %l30, !tbaa !29
  %t84 = insertvalue { %"compiler/source:Span", ptr, ptr } %t82, ptr %t83, 1
  %t85 = load ptr, ptr %l46, !tbaa !29
  %t86 = insertvalue { %"compiler/source:Span", ptr, ptr } %t84, ptr %t85, 2
  %t87 = getelementptr { i64, [3 x i64] }, ptr %t79, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t86, ptr %t87
  %t88 = load { i64, [3 x i64] }, ptr %t79
  %t90 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t88, ptr %t90
  %t91 = load ptr, ptr %l21, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t91, ptr %t90)
  br label %bb12
bb12:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load i64, ptr %l5, !tbaa !24
  %t95 = load i64, ptr %l6, !tbaa !24
  %t96 = load i64, ptr %l7, !tbaa !24
  %t97 = load i64, ptr %l3, !tbaa !24
  %t103 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t93, i64 %t94, i64 %t95, i64 %t96, i64 %t97)
  store ptr %t103, ptr %l54
  br label %bb13
bb13:
  %t104 = load ptr, ptr %l54, !tbaa !29
  store ptr %t104, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectBody(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca ptr
  %l27 = alloca ptr
  %l33 = alloca ptr
  %l38 = alloca i32
  %l39 = alloca { i64, ptr }
  %l40 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l41 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l47 = alloca i64
  %l50 = alloca i64
  %l68 = alloca { i64, ptr }
  %l73 = alloca i1
  %l76 = alloca ptr
  %l81 = alloca i32
  %l86 = alloca i64
  %l90 = alloca i32
  %l93 = alloca ptr
  %l99 = alloca i64
  %l104 = alloca ptr
  %l107 = alloca ptr
  %l109 = alloca { i64, ptr }
  %l110 = alloca i32
  %l111 = alloca i32
  %l116 = alloca i32
  %l119 = alloca ptr
  %l120 = alloca i64
  %l122 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l125 = alloca i32
  %l126 = alloca i32
  %l138 = alloca i64
  %l145 = alloca ptr
  %l146 = alloca i64
  %l148 = alloca i64
  %l149 = alloca i32
  %l154 = alloca i32
  %l155 = alloca ptr
  %l156 = alloca ptr
  %l159 = alloca %"compiler/generic:Context"
  %l163 = alloca ptr
  %l166 = alloca i32
  %l175 = alloca ptr
  %l182 = alloca i32
  %l189 = alloca %"compiler/source:Span"
  %l191 = alloca i32
  %l207 = alloca { i64, ptr }
  %l214 = alloca ptr
  %l216 = alloca i32
  %l218 = alloca %"compiler/source:Span"
  %l221 = alloca i32
  %l230 = alloca ptr
  %l234 = alloca { i64, ptr }
  %l236 = alloca ptr
  %l239 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca i64
  %t225 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectSourceOf(ptr %v0, ptr %t1, i64 %t2)
  store ptr %t5, ptr %l27
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l27, !tbaa !29
  store ptr %t6, ptr %l5, !tbaa !29
  %t7 = load ptr, ptr %l5, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb2, label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_4d78ccd557b2cb07_4b61304073c9a48b)
  unreachable
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l5, !tbaa !29
  store ptr %t11, ptr %l6, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  store ptr %t18, ptr %l33, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 2
  %t25 = load i32, ptr %l3, !tbaa !23
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t28, ptr %l38
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l33, !tbaa !29
  %t30 = load i32, ptr %l38, !tbaa !23
  %t31 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t29, i32 %t30)
  store { i64, ptr } %t31, ptr %l39
  br label %bb6
bb6:
  %t32 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t32, ptr %l7, !tbaa !27
  %t33 = load ptr, ptr @__olang_prog_scope
  %t34 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %t33)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t34, ptr %l40
  br label %bb7
bb7:
  %t35 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l40
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t35, ptr %l8
  %t36 = load ptr, ptr @__olang_prog_scope
  %t37 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t36)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t37, ptr %l41
  br label %bb8
bb8:
  %t38 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l41
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t38, ptr %l9
  store i64 0, ptr %l10, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  store i64 %t41, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t43 = load i64, ptr %l11, !tbaa !24
  %t44 = load i64, ptr %l10, !tbaa !24
  %t47 = icmp sgt i64 %t43, %t44
  br i1 %t47, label %bb9, label %bb10
bb9:
  %t49 = load i64, ptr %l12, !tbaa !24
  %t51 = icmp sgt i64 %t49, 0
  br i1 %t51, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb14
bb11:
  %t53 = load i64, ptr %l11, !tbaa !24
  %t54 = load i64, ptr %l10, !tbaa !24
  %t57 = sub i64 %t53, %t54
  %t58 = load i64, ptr %l12, !tbaa !24
  %t61 = add i64 %t57, %t58
  %t63 = sub i64 %t61, 1
  %t64 = load i64, ptr %l12, !tbaa !24
  %t67 = sdiv i64 %t63, %t64
  store i64 %t67, ptr %l50, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l50, !tbaa !24
  br label %bb13
bb13:
  %t69 = load i64, ptr %l50, !tbaa !24
  store i64 %t69, ptr %l47, !tbaa !24
  br label %bb14
bb14:
  %t70 = load i64, ptr %l47, !tbaa !24
  store i64 %t70, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t71 = load i64, ptr %l14, !tbaa !24
  %t72 = load i64, ptr %l13, !tbaa !24
  %t75 = icmp slt i64 %t71, %t72
  %t77 = xor i1 %t75, true
  br i1 %t77, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb17:
  br label %bb18
bb18:
  %t79 = load i64, ptr %l10, !tbaa !24
  %t80 = load i64, ptr %l14, !tbaa !24
  %t81 = load i64, ptr %l12, !tbaa !24
  %t84 = mul i64 %t80, %t81
  %t87 = add i64 %t79, %t84
  store i64 %t87, ptr %l15, !tbaa !24
  %t89 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t89, ptr %l68, !tbaa !27
  %t90 = load i64, ptr %l15, !tbaa !24
  %t92 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr i32, ptr %t93, i64 %t90
  %t95 = load i32, ptr %t94, !tbaa !33
  store i32 %t95, ptr %l16, !tbaa !23
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load i32, ptr %l16, !tbaa !23
  %t101 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t97, i32 %t98)
  store i1 %t101, ptr %l73
  br label %bb19
bb19:
  %t102 = load i1, ptr %l73, !tbaa !21
  br i1 %t102, label %bb20, label %bb21
bb20:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/check:Checker", ptr %t103, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/generic:Program", ptr %t106, i32 0, i32 2
  store ptr %t108, ptr %l76, !tbaa !29
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/check:Checker", ptr %t109, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = getelementptr %"compiler/generic:Program", ptr %t112, i32 0, i32 2
  %t115 = load i32, ptr %l16, !tbaa !23
  %t118 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t114, i32 %t115)
  store i32 %t118, ptr %l81
  br label %bb22
bb21:
  br label %bb25
bb22:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/check:Checker", ptr %t119, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !29
  %t124 = getelementptr %"compiler/generic:Program", ptr %t122, i32 0, i32 2
  %t125 = load i32, ptr %l16, !tbaa !23
  %t128 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t124, i32 %t125)
  store i64 %t128, ptr %l86
  br label %bb23
bb23:
  %t129 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t131 = xor i64 %t129, -1
  %t132 = load i64, ptr %l86, !tbaa !24
  %t134 = and i64 %t132, %t131
  %t135 = load ptr, ptr %l76, !tbaa !29
  %t136 = load i32, ptr %l81, !tbaa !23
  %t138 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t135, i32 %t136, i64 %t134)
  store i32 %t138, ptr %l90
  br label %bb24
bb24:
  %t139 = load i32, ptr %l90, !tbaa !23
  store i32 %t139, ptr %l16, !tbaa !23
  br label %bb25
bb25:
  %t140 = load i32, ptr %l16, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l8, i32 %t140)
  br label %bb26
bb26:
  store ptr %l9, ptr %l93, !tbaa !29
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/check:Checker", ptr %t143, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t148 = getelementptr %"compiler/generic:Program", ptr %t146, i32 0, i32 2
  %t149 = load i32, ptr %l3, !tbaa !23
  %t150 = load i64, ptr %l15, !tbaa !24
  %t154 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t148, i32 %t149, i64 %t150)
  store i64 %t154, ptr %l99
  br label %bb27
bb27:
  %t155 = load ptr, ptr %l93, !tbaa !29
  %t156 = load i64, ptr %l99, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t155, i64 %t156)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb29:
  %t157 = load i64, ptr %l14, !tbaa !24
  %t159 = add i64 %t157, 1
  store i64 %t159, ptr %l14, !tbaa !24
  br label %bb15
bb30:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/check:Checker", ptr %t161, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !29
  %t166 = getelementptr %"compiler/generic:Program", ptr %t164, i32 0, i32 2
  store ptr %t166, ptr %l104, !tbaa !29
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/check:Checker", ptr %t167, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t172 = getelementptr %"compiler/generic:Program", ptr %t170, i32 0, i32 2
  store ptr %t172, ptr %l107, !tbaa !29
  %t174 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eToAr_H9d0f958437b2bc29fe1d416dfb9901d7(ptr %s0, ptr %s0, ptr %l8)
  store { i64, ptr } %t174, ptr %l109
  br label %bb31
bb31:
  %t175 = load ptr, ptr %l107, !tbaa !29
  %t176 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t177 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t175, { i64, ptr } %t176)
  store i32 %t177, ptr %l110
  br label %bb32
bb32:
  %t178 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t178, ptr %l111, !tbaa !23
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/check:Checker", ptr %t179, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t184 = getelementptr %"compiler/generic:Program", ptr %t182, i32 0, i32 2
  %t185 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  %t188 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %t184, i32 %t185)
  store i32 %t188, ptr %l116
  br label %bb33
bb33:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/check:Checker", ptr %t189, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t194 = getelementptr %"compiler/generic:Program", ptr %t192, i32 0, i32 2
  store ptr %t194, ptr %l119, !tbaa !29
  %t195 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleFn, !tbaa !24
  store i64 %t195, ptr %l120, !tbaa !24
  %t197 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s0, ptr %l9)
  store { i64, ptr } %t197, ptr %l122
  br label %bb34
bb34:
  %t198 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t199 = mul i64 1, 8
  %t200 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t199)
  %t201 = insertvalue { i64, ptr } undef, i64 1, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t200, 1
  store { i64, ptr } %t202, ptr %l124, !tbaa !27
  %t204 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !27
  %t206 = getelementptr i64, ptr %t205, i64 0
  store i64 %t198, ptr %t206, !tbaa !34
  %t207 = load ptr, ptr %l119, !tbaa !29
  %t208 = load i64, ptr %l120, !tbaa !24
  %t209 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t210 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t211 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopes(ptr %v0, ptr %s0, ptr %s0, ptr %t207, i64 %t208, { i64, ptr } %t209, { i64, ptr } %t210)
  store i32 %t211, ptr %l125
  br label %bb35
bb35:
  %t212 = load ptr, ptr %l104, !tbaa !29
  %t213 = load i32, ptr %l110, !tbaa !23
  %t214 = load i32, ptr %l111, !tbaa !23
  %t215 = load i32, ptr %l116, !tbaa !23
  %t216 = load i32, ptr %l125, !tbaa !23
  %t217 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t212, i32 %t213, i32 %t214, i32 %t215, i32 %t216, i64 0)
  store i32 %t217, ptr %l126
  br label %bb36
bb36:
  %t218 = load i32, ptr %l126, !tbaa !23
  store i32 %t218, ptr %l17, !tbaa !23
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load i64, ptr %l1, !tbaa !24
  %t222 = trunc i64 %t220 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t225
  %t226 = getelementptr { i64, [2 x i64] }, ptr %t225, i32 0, i32 0
  store i64 8, ptr %t226
  %t228 = insertvalue { i32, i32, i64 } undef, i32 %t222, 0
  %t230 = insertvalue { i32, i32, i64 } %t228, i32 0, 1
  %t232 = insertvalue { i32, i32, i64 } %t230, i64 %a2, 2
  %t233 = getelementptr { i64, [2 x i64] }, ptr %t225, i32 0, i32 1
  store { i32, i32, i64 } %t232, ptr %t233
  %t234 = load { i64, [2 x i64] }, ptr %t225
  %t235 = load i32, ptr %l17, !tbaa !23
  %t236 = load ptr, ptr %l6, !tbaa !29
  %t238 = getelementptr %"compiler/check:ctSource", ptr %t236, i32 0, i32 3
  %t239 = load i64, ptr %t238, !tbaa !24
  %t240 = load %"compiler/source:Span", ptr %l4
  %t246 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t219, { i64, [2 x i64] } %t234, i32 %t235, i64 %t239, %"compiler/source:Span" %t240)
  store i64 %t246, ptr %l138
  br label %bb37
bb37:
  %t247 = load i64, ptr %l138, !tbaa !24
  store i64 %t247, ptr %l18, !tbaa !24
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t250 = getelementptr %"compiler/check:Checker", ptr %t248, i32 0, i32 16
  %t251 = load i64, ptr %l18, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t250, i64 %t251, i64 1)
  br label %bb38
bb38:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = getelementptr %"compiler/check:Checker", ptr %t254, i32 0, i32 47
  %t257 = load i64, ptr %l18, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t256, i64 %t257, i1 true)
  br label %bb39
bb39:
  %t260 = load ptr, ptr %l0, !tbaa !29
  store ptr %t260, ptr %l145, !tbaa !29
  %t261 = load i64, ptr %l18, !tbaa !24
  store i64 %t261, ptr %l146, !tbaa !24
  %t262 = load ptr, ptr %l6, !tbaa !29
  %t264 = getelementptr %"compiler/check:ctSource", ptr %t262, i32 0, i32 3
  %t265 = load i64, ptr %t264, !tbaa !24
  store i64 %t265, ptr %l148, !tbaa !24
  %t266 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t266, ptr %l149, !tbaa !23
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/check:Checker", ptr %t267, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !29
  %t272 = getelementptr %"compiler/generic:Program", ptr %t270, i32 0, i32 2
  %t273 = load i32, ptr %l17, !tbaa !23
  %t276 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t272, i32 %t273)
  store i32 %t276, ptr %l154
  br label %bb40
bb40:
  %t277 = load ptr, ptr %l145, !tbaa !29
  %t278 = load i64, ptr %l146, !tbaa !24
  %t279 = load i64, ptr %l148, !tbaa !24
  %t280 = load i32, ptr %l149, !tbaa !23
  %t281 = load i32, ptr %l154, !tbaa !23
  %t282 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t277, i64 %t278, i64 %t279, i32 %t280, i32 %t281)
  store ptr %t282, ptr %l155
  br label %bb41
bb41:
  %t283 = load ptr, ptr %l155, !tbaa !29
  store ptr %t283, ptr %l19, !tbaa !29
  %t284 = load ptr, ptr %l19, !tbaa !29
  store ptr %t284, ptr %l156, !tbaa !29
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t286 = load i64, ptr %l1, !tbaa !24
  %t289 = call %"compiler/generic:Context" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectContext(ptr %v0, ptr %v0, ptr %t285, i64 %t286)
  store %"compiler/generic:Context" %t289, ptr %l159
  br label %bb42
bb42:
  %t290 = load %"compiler/generic:Context", ptr %l159
  %t291 = load ptr, ptr %l156, !tbaa !29
  %t292 = getelementptr %"compiler/check:frame", ptr %t291, i32 0, i32 4
  store %"compiler/generic:Context" %t290, ptr %t292
  %t293 = load ptr, ptr %l19, !tbaa !29
  %t294 = load i64, ptr @G_2ecompiler_2fcheck_2eCtReq, !tbaa !24
  %t297 = getelementptr %"compiler/check:frame", ptr %t293, i32 0, i32 47
  store i64 %t294, ptr %t297, !tbaa !24
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t300 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t298)
  store ptr %t300, ptr %l163
  br label %bb43
bb43:
  %t301 = load %"compiler/source:Span", ptr %l4
  %t302 = load ptr, ptr %l163, !tbaa !29
  %t305 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %t302, i32 -1, i32 0, %"compiler/source:Span" %t301)
  store i32 %t305, ptr %l166
  br label %bb44
bb44:
  store i64 0, ptr %l20, !tbaa !24
  %t306 = load ptr, ptr %l6, !tbaa !29
  %t308 = getelementptr %"compiler/check:ctSource", ptr %t306, i32 0, i32 1
  %t309 = load ptr, ptr %t308, !tbaa !29
  %t311 = icmp eq ptr %t309, null
  %t313 = xor i1 %t311, true
  br i1 %t313, label %bb45, label %bb46
bb45:
  %t315 = load i64, ptr %l20, !tbaa !24
  %t316 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t318 = extractvalue { i64, ptr } %t316, 0
  %t321 = icmp slt i64 %t315, %t318
  br i1 %t321, label %bb47, label %bb48
bb46:
  br label %bb61
bb47:
  %t323 = load ptr, ptr %l0, !tbaa !29
  store ptr %t323, ptr %l175, !tbaa !29
  %t324 = load ptr, ptr %l6, !tbaa !29
  %t326 = getelementptr %"compiler/check:ctSource", ptr %t324, i32 0, i32 1
  %t327 = load ptr, ptr %t326, !tbaa !29
  %t329 = icmp eq ptr %t327, null
  br i1 %t329, label %bb49, label %bb50
bb48:
  br label %bb60
bb49:
  call void @__olang_check_failed(ptr @olang_loc_82a7c94587506de8_24388316e0066d9c)
  unreachable
bb50:
  br label %bb51
bb51:
  %t331 = load ptr, ptr %l6, !tbaa !29
  %t333 = getelementptr %"compiler/check:ctSource", ptr %t331, i32 0, i32 1
  %t334 = load ptr, ptr %t333, !tbaa !29
  %t337 = getelementptr %"compiler/ast:Param", ptr %t334, i32 0, i32 1
  %t338 = load i32, ptr %t337, !tbaa !23
  store i32 %t338, ptr %l182, !tbaa !23
  %t339 = load ptr, ptr %l6, !tbaa !29
  %t341 = getelementptr %"compiler/check:ctSource", ptr %t339, i32 0, i32 1
  %t342 = load ptr, ptr %t341, !tbaa !29
  %t344 = icmp eq ptr %t342, null
  br i1 %t344, label %bb52, label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_82a7c94587506de8_24388316e0066d9c)
  unreachable
bb53:
  br label %bb54
bb54:
  %t346 = load ptr, ptr %l6, !tbaa !29
  %t348 = getelementptr %"compiler/check:ctSource", ptr %t346, i32 0, i32 1
  %t349 = load ptr, ptr %t348, !tbaa !29
  %t352 = getelementptr %"compiler/ast:Param", ptr %t349, i32 0, i32 0
  %t353 = load %"compiler/source:Span", ptr %t352
  store %"compiler/source:Span" %t353, ptr %l189
  %t355 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l8, i64 0)
  store i32 %t355, ptr %l191
  br label %bb55
bb55:
  %t356 = load ptr, ptr %l6, !tbaa !29
  %t358 = getelementptr %"compiler/check:ctSource", ptr %t356, i32 0, i32 1
  %t359 = load ptr, ptr %t358, !tbaa !29
  %t361 = icmp eq ptr %t359, null
  br i1 %t361, label %bb56, label %bb57
bb56:
  call void @__olang_check_failed(ptr @olang_loc_82a7c94587506de8_24388316e0066d9c)
  unreachable
bb57:
  br label %bb58
bb58:
  %t363 = load ptr, ptr %l6, !tbaa !29
  %t365 = getelementptr %"compiler/check:ctSource", ptr %t363, i32 0, i32 1
  %t366 = load ptr, ptr %t365, !tbaa !29
  %t369 = getelementptr %"compiler/ast:Param", ptr %t366, i32 0, i32 2
  %t370 = load ptr, ptr %t369, !tbaa !29
  %t371 = load ptr, ptr %l175, !tbaa !29
  %t372 = load i32, ptr %l182, !tbaa !23
  %t373 = load %"compiler/source:Span", ptr %l189
  %t374 = load i32, ptr %l191, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparam(ptr %v0, ptr %v0, ptr %t371, i32 %t372, %"compiler/source:Span" %t373, i32 %t374, i64 0, ptr %t370)
  br label %bb59
bb59:
  br label %bb60
bb60:
  store i64 1, ptr %l20, !tbaa !24
  br label %bb61
bb61:
  %t376 = load ptr, ptr %l6, !tbaa !29
  %t378 = getelementptr %"compiler/check:ctSource", ptr %t376, i32 0, i32 2
  %t379 = load { i64, ptr }, ptr %t378, !tbaa !27
  store { i64, ptr } %t379, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t381 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t383 = extractvalue { i64, ptr } %t381, 0
  store i64 %t383, ptr %l23, !tbaa !24
  br label %bb62
bb62:
  store %olang.scope zeroinitializer, ptr %s8
  %t385 = load i64, ptr %l22, !tbaa !24
  %t386 = load i64, ptr %l23, !tbaa !24
  %t389 = icmp slt i64 %t385, %t386
  %t391 = xor i1 %t389, true
  br i1 %t391, label %bb63, label %bb64
bb63:
  call void @__olang_scope_close(ptr %s8)
  br label %bb72
bb64:
  br label %bb65
bb65:
  %t393 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t393, ptr %l207, !tbaa !27
  %t394 = load i64, ptr %l22, !tbaa !24
  %t396 = getelementptr { i64, ptr }, ptr %l207, i32 0, i32 1
  %t397 = load ptr, ptr %t396, !tbaa !27
  %t398 = getelementptr ptr, ptr %t397, i64 %t394
  %t399 = load ptr, ptr %t398, !tbaa !39
  store ptr %t399, ptr %l24, !tbaa !29
  %t401 = load i64, ptr %l20, !tbaa !24
  %t402 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t404 = extractvalue { i64, ptr } %t402, 0
  %t407 = icmp slt i64 %t401, %t404
  br i1 %t407, label %bb66, label %bb67
bb66:
  %t409 = load ptr, ptr %l0, !tbaa !29
  store ptr %t409, ptr %l214, !tbaa !29
  %t410 = load ptr, ptr %l24, !tbaa !29
  %t412 = getelementptr %"compiler/ast:Param", ptr %t410, i32 0, i32 1
  %t413 = load i32, ptr %t412, !tbaa !23
  store i32 %t413, ptr %l216, !tbaa !23
  %t414 = load ptr, ptr %l24, !tbaa !29
  %t416 = getelementptr %"compiler/ast:Param", ptr %t414, i32 0, i32 0
  %t417 = load %"compiler/source:Span", ptr %t416
  store %"compiler/source:Span" %t417, ptr %l218
  %t418 = load i64, ptr %l20, !tbaa !24
  %t421 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l8, i64 %t418)
  store i32 %t421, ptr %l221
  br label %bb68
bb67:
  br label %bb70
bb68:
  %t422 = load i64, ptr %l20, !tbaa !24
  %t423 = load ptr, ptr %l24, !tbaa !29
  %t425 = getelementptr %"compiler/ast:Param", ptr %t423, i32 0, i32 2
  %t426 = load ptr, ptr %t425, !tbaa !29
  %t427 = load ptr, ptr %l214, !tbaa !29
  %t428 = load i32, ptr %l216, !tbaa !23
  %t429 = load %"compiler/source:Span", ptr %l218
  %t430 = load i32, ptr %l221, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparam(ptr %v0, ptr %v0, ptr %t427, i32 %t428, %"compiler/source:Span" %t429, i32 %t430, i64 %t422, ptr %t426)
  br label %bb69
bb69:
  br label %bb70
bb70:
  %t433 = load i64, ptr %l20, !tbaa !24
  %t435 = add i64 %t433, 1
  store i64 %t435, ptr %l20, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb71
bb71:
  %t437 = load i64, ptr %l22, !tbaa !24
  %t439 = add i64 %t437, 1
  store i64 %t439, ptr %l22, !tbaa !24
  br label %bb62
bb72:
  %t441 = load ptr, ptr %l0, !tbaa !29
  %t443 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t441)
  store ptr %t443, ptr %l230
  br label %bb73
bb73:
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t446 = getelementptr %"compiler/check:Checker", ptr %t444, i32 0, i32 1
  %t447 = load ptr, ptr %t446, !tbaa !29
  %t448 = load i32, ptr %l17, !tbaa !23
  %t451 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t447, i32 %t448)
  store { i64, ptr } %t451, ptr %l234
  br label %bb74
bb74:
  %t452 = load { i64, ptr }, ptr %l234, !tbaa !27
  %t453 = extractvalue { i64, ptr } %t452, 0
  %t454 = extractvalue { i64, ptr } %t452, 1
  %t455 = mul i64 %t453, 8
  %t456 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t455)
  call void @llvm.memcpy.p0.p0.i64(ptr %t456, ptr %t454, i64 %t455, i1 false)
  %t457 = insertvalue { i64, ptr } undef, i64 %t453, 0
  %t458 = insertvalue { i64, ptr } %t457, ptr %t456, 1
  %t459 = load ptr, ptr %l230, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eSetVars(ptr %v0, ptr %s0, ptr %t459, { i64, ptr } %t458)
  br label %bb75
bb75:
  %t461 = load ptr, ptr %l19, !tbaa !29
  store ptr %t461, ptr %l236, !tbaa !29
  %t462 = load ptr, ptr %l0, !tbaa !29
  %t464 = getelementptr %"compiler/check:Checker", ptr %t462, i32 0, i32 33
  %t466 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t464)
  store i64 %t466, ptr %l239
  br label %bb76
bb76:
  %t467 = load i64, ptr %l239, !tbaa !24
  %t468 = load ptr, ptr %l236, !tbaa !29
  %t469 = getelementptr %"compiler/check:frame", ptr %t468, i32 0, i32 50
  store i64 %t467, ptr %t469, !tbaa !24
  %t470 = load i64, ptr %l18, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t470, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i32
  %l14 = alloca %"compiler/source:Span"
  %l26 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/ast:Catch", ptr %t2, i32 0, i32 0
  %t5 = load %"compiler/source:Span", ptr %t4
  %t8 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t1, %"compiler/source:Span" %t5)
  store { i64, ptr } %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t10 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s0, { i64, ptr } %t9, { i64, ptr } { i64 7, ptr @.d9 })
  %t11 = extractvalue { i32, i64 } %t10, 1
  %t12 = extractvalue { i32, i64 } %t10, 0
  store i32 %t12, ptr %l9
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb3, label %ok.14
ok.14:
  store i64 %t11, ptr %l8
  br label %bb2
bb2:
  %t15 = load i64, ptr %l8, !tbaa !24
  store i64 %t15, ptr %l3, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb5
bb5:
  %t16 = load i64, ptr %l3, !tbaa !24
  store i64 %t16, ptr %l2, !tbaa !24
  %t17 = load i64, ptr %l2, !tbaa !24
  %t19 = icmp slt i64 %t17, 0
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t25 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %t21, ptr %t22)
  store %"compiler/source:Span" %t25, ptr %l14
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t26 = load %"compiler/source:Span", ptr %l14
  store %"compiler/source:Span" %t26, ptr %rv
  br label %ret
bb9:
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr %"compiler/ast:Catch", ptr %t27, i32 0, i32 0
  %t30 = getelementptr %"compiler/source:Span", ptr %t29, i32 0, i32 0
  %t31 = load i32, ptr %t30, !tbaa !23
  %t32 = load i64, ptr %l2, !tbaa !24
  %t34 = trunc i64 %t32 to i32
  %t37 = add i32 %t31, %t34
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr %"compiler/ast:Catch", ptr %t38, i32 0, i32 0
  %t41 = getelementptr %"compiler/source:Span", ptr %t40, i32 0, i32 0
  %t42 = load i32, ptr %t41, !tbaa !23
  %t43 = load i64, ptr %l2, !tbaa !24
  %t45 = trunc i64 %t43 to i32
  %t48 = add i32 %t42, %t45
  %t50 = add i32 %t48, 7
  %t53 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t37, i32 %t50)
  store %"compiler/source:Span" %t53, ptr %l26
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t54 = load %"compiler/source:Span", ptr %l26
  store %"compiler/source:Span" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ediscardOr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca i1
  %l18 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l25 = alloca %"compiler/source:Span"
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb11
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t16, i32 %t17)
  store { i64, ptr } %t20, ptr %l12
  br label %bb6
bb6:
  %t21 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t22 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t21, { i64, ptr } { i64 1, ptr @.d10 })
  store i1 %t22, ptr %l13
  br label %bb7
bb7:
  %t23 = load i1, ptr %l13, !tbaa !21
  br i1 %t23, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s1)
  store ptr null, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s1)
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 9
  store i1 true, ptr %t27, !tbaa !21
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t32 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %t28, ptr %t29)
  store ptr %t32, ptr %l18
  br label %bb13
bb13:
  %t33 = load ptr, ptr %l18, !tbaa !29
  store ptr %t33, ptr %l3, !tbaa !29
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t36 = icmp eq ptr %t34, null
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb14, label %bb15
bb14:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l22, !tbaa !29
  %t41 = load ptr, ptr %l3, !tbaa !29
  store ptr %t41, ptr %l23, !tbaa !29
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t42)
  store %"compiler/source:Span" %t44, ptr %l25
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t45 = load ptr, ptr %l22, !tbaa !29
  %t46 = load ptr, ptr %l23, !tbaa !29
  %t47 = load %"compiler/source:Span", ptr %l25
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotCapture(ptr %v0, ptr %v0, ptr %t45, ptr %t46, %"compiler/source:Span" %t47)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t48 = load ptr, ptr %l3, !tbaa !29
  store ptr %t48, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edispatchChecks(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, { i64, ptr } %a4, i32 %a5, %"compiler/typed:ContractInfo" %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l4 = alloca { i64, ptr }
  %l6 = alloca %"compiler/typed:ContractInfo"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca i64
  %l26 = alloca %"compiler/source:Span"
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %lp34 = alloca ptr
  %l36 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l48 = alloca { i64, ptr }
  %l51 = alloca ptr
  %l52 = alloca i1
  %l56 = alloca ptr
  %l58 = alloca %"compiler/source:Span"
  %l61 = alloca i32
  %l64 = alloca i64
  %l65 = alloca ptr
  %l67 = alloca %"compiler/source:Span"
  %l80 = alloca i32
  %l82 = alloca i64
  %l86 = alloca i64
  %l89 = alloca i64
  %l109 = alloca i64
  %l110 = alloca ptr
  %l111 = alloca %"compiler/source:Span"
  %l112 = alloca i64
  %l113 = alloca i32
  %l114 = alloca { i64, ptr }
  %l115 = alloca ptr
  %l116 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l118 = alloca ptr
  %l121 = alloca i32
  %l126 = alloca { i64, ptr }
  %l131 = alloca ptr
  %l134 = alloca %"compiler/source:Span"
  %l135 = alloca i32
  %l137 = alloca ptr
  %l141 = alloca %"compiler/typed:Try"
  %l150 = alloca ptr
  %l155 = alloca i64
  %l161 = alloca %"compiler/source:Span"
  %l162 = alloca ptr
  %l163 = alloca %"compiler/source:Span"
  %l164 = alloca %"compiler/source:Span"
  %l165 = alloca i32
  %l166 = alloca i32
  %l167 = alloca i32
  %l171 = alloca { i64, ptr }
  %l177 = alloca ptr
  %l182 = alloca ptr
  %l184 = alloca ptr
  %l185 = alloca { i64, ptr }
  %l188 = alloca { i64, ptr }
  %l195 = alloca i64
  %l201 = alloca i64
  %l204 = alloca i64
  %l223 = alloca ptr
  %l228 = alloca ptr
  %l231 = alloca %"compiler/source:Span"
  %l232 = alloca i32
  %l233 = alloca ptr
  %l237 = alloca { i64, ptr }
  %l240 = alloca %"compiler/typed:Call"
  %l246 = alloca i1
  %l255 = alloca %"compiler/source:Span"
  %l256 = alloca i32
  %l260 = alloca { i64, ptr }
  %l261 = alloca %"compiler/typed:Seq"
  %l265 = alloca %"compiler/source:Span"
  %l266 = alloca i32
  %l270 = alloca { i64, ptr }
  %l272 = alloca %"compiler/typed:Seq"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca ptr
  %t54 = alloca { i64, [2 x i64] }, align 8
  %t73 = alloca { i64, [3 x i64] }, align 8
  %t225 = alloca { i64, [5 x i64] }, align 8
  %t286 = alloca { i64, [5 x i64] }, align 8
  %t302 = alloca { i64, [3 x i64] }, align 8
  %t448 = alloca { i64, [2 x i64] }, align 8
  %t459 = alloca { i64, [5 x i64] }, align 8
  %t488 = alloca { i64, [3 x i64] }, align 8
  %t513 = alloca { i64, [5 x i64] }, align 8
  %t541 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, ptr } %a4, ptr %l4
  store %"compiler/typed:ContractInfo" %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l36
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l36, !tbaa !29
  store ptr %t4, ptr %l7, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 33
  %t9 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l39
  br label %bb2
bb2:
  %t10 = load i64, ptr %l39, !tbaa !24
  store i64 %t10, ptr %l8, !tbaa !24
  %t11 = load ptr, ptr @__olang_prog_scope
  %t12 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t11)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l40
  br label %bb3
bb3:
  %t13 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l40
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l9
  %t14 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t14, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  store i64 %t18, ptr %l12, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t20 = load i64, ptr %l11, !tbaa !24
  %t21 = load i64, ptr %l12, !tbaa !24
  %t24 = icmp slt i64 %t20, %t21
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb6:
  br label %bb7
bb7:
  %t28 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t28, ptr %l48, !tbaa !27
  %t29 = load i64, ptr %l11, !tbaa !24
  %t31 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr ptr, ptr %t32, i64 %t29
  %t34 = load ptr, ptr %t33, !tbaa !39
  store ptr %t34, ptr %l13, !tbaa !29
  %t36 = load ptr, ptr %l13, !tbaa !29
  store ptr %t36, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t37 = load ptr, ptr %l51, !tbaa !29
  %t38 = icmp ne ptr %t37, null
  br i1 %t38, label %bb8, label %bb9
bb8:
  %t40 = load ptr, ptr %l51, !tbaa !29
  %t41 = load i64, ptr %t40
  %t43 = icmp eq i64 %t41, 0
  store i1 %t43, ptr %l52, !tbaa !21
  br label %bb9
bb9:
  %t44 = load i1, ptr %l52, !tbaa !21
  br i1 %t44, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb14
bb12:
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l9, i64 -1)
  br label %bb13
bb13:
  br label %bb21
bb14:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l56, !tbaa !29
  %t47 = load ptr, ptr %l13, !tbaa !29
  %t49 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t47)
  store %"compiler/source:Span" %t49, ptr %l58
  br label %bb15
bb15:
  %t50 = load ptr, ptr %l13, !tbaa !29
  %t53 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t50)
  store i32 %t53, ptr %l61
  br label %bb16
bb16:
  store { i64, [2 x i64] } zeroinitializer, ptr %t54
  %t55 = getelementptr { i64, [2 x i64] }, ptr %t54, i32 0, i32 0
  store i64 0, ptr %t55
  %t56 = load { i64, [2 x i64] }, ptr %t54
  %t57 = load ptr, ptr %l56, !tbaa !29
  %t58 = load %"compiler/source:Span", ptr %l58
  %t59 = load i32, ptr %l61, !tbaa !23
  %t62 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t57, i32 0, %"compiler/source:Span" %t58, i32 %t59, i32 2, { i64, [2 x i64] } %t56)
  store i64 %t62, ptr %l64
  br label %bb17
bb17:
  %t63 = load i64, ptr %l64, !tbaa !24
  store i64 %t63, ptr %l14, !tbaa !24
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l65, !tbaa !29
  %t65 = load ptr, ptr %l13, !tbaa !29
  %t67 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t65)
  store %"compiler/source:Span" %t67, ptr %l67
  br label %bb18
bb18:
  %t68 = load i64, ptr %l14, !tbaa !24
  %t70 = trunc i64 %t68 to i32
  %t72 = load ptr, ptr %l13, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t73
  %t74 = getelementptr { i64, [3 x i64] }, ptr %t73, i32 0, i32 0
  store i64 0, ptr %t74
  %t75 = load %"compiler/source:Span", ptr %l67
  %t76 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t75, 0
  %t78 = insertvalue { %"compiler/source:Span", i32, ptr } %t76, i32 %t70, 1
  %t80 = insertvalue { %"compiler/source:Span", i32, ptr } %t78, ptr %t72, 2
  %t81 = getelementptr { i64, [3 x i64] }, ptr %t73, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t80, ptr %t81
  %t82 = load { i64, [3 x i64] }, ptr %t73
  %t84 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t82, ptr %t84
  %t85 = load ptr, ptr %l65, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t85, ptr %t84)
  br label %bb19
bb19:
  %t87 = load i64, ptr %l14, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l9, i64 %t87)
  br label %bb20
bb20:
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  %t90 = load i64, ptr %l11, !tbaa !24
  %t92 = add i64 %t90, 1
  store i64 %t92, ptr %l11, !tbaa !24
  br label %bb4
bb23:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t99 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s0, ptr %s0, ptr %t97, { i64, ptr } { i64 20, ptr @.d11 }, { i64, ptr } { i64 13, ptr @.d12 })
  store i32 %t99, ptr %l80
  br label %bb24
bb24:
  %t100 = load i32, ptr %l80, !tbaa !23
  store i32 %t100, ptr %l15, !tbaa !23
  store i64 0, ptr %l16, !tbaa !24
  %t101 = getelementptr %"compiler/typed:ContractInfo", ptr %l6, i32 0, i32 2
  %t103 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t101)
  store i64 %t103, ptr %l82
  br label %bb25
bb25:
  %t104 = load i64, ptr %l82, !tbaa !24
  store i64 %t104, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t105 = load i64, ptr %l17, !tbaa !24
  %t106 = load i64, ptr %l16, !tbaa !24
  %t109 = icmp sgt i64 %t105, %t106
  br i1 %t109, label %bb26, label %bb27
bb26:
  %t111 = load i64, ptr %l18, !tbaa !24
  %t113 = icmp sgt i64 %t111, 0
  br i1 %t113, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l86, !tbaa !24
  br label %bb31
bb28:
  %t115 = load i64, ptr %l17, !tbaa !24
  %t116 = load i64, ptr %l16, !tbaa !24
  %t119 = sub i64 %t115, %t116
  %t120 = load i64, ptr %l18, !tbaa !24
  %t123 = add i64 %t119, %t120
  %t125 = sub i64 %t123, 1
  %t126 = load i64, ptr %l18, !tbaa !24
  %t129 = sdiv i64 %t125, %t126
  store i64 %t129, ptr %l89, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l89, !tbaa !24
  br label %bb30
bb30:
  %t131 = load i64, ptr %l89, !tbaa !24
  store i64 %t131, ptr %l86, !tbaa !24
  br label %bb31
bb31:
  %t132 = load i64, ptr %l86, !tbaa !24
  store i64 %t132, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s7
  %t133 = load i64, ptr %l20, !tbaa !24
  %t134 = load i64, ptr %l19, !tbaa !24
  %t137 = icmp slt i64 %t133, %t134
  %t139 = xor i1 %t137, true
  br i1 %t139, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s7)
  br label %bb65
bb34:
  br label %bb35
bb35:
  %t141 = load i64, ptr %l16, !tbaa !24
  %t142 = load i64, ptr %l20, !tbaa !24
  %t143 = load i64, ptr %l18, !tbaa !24
  %t146 = mul i64 %t142, %t143
  %t149 = add i64 %t141, %t146
  store i64 %t149, ptr %l21, !tbaa !24
  %t151 = getelementptr %"compiler/typed:ContractInfo", ptr %l6, i32 0, i32 2
  %t152 = load i64, ptr %l21, !tbaa !24
  %t155 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t151, i64 %t152)
  store i64 %t155, ptr %l109
  br label %bb36
bb36:
  %t156 = load i64, ptr %l109, !tbaa !24
  store i64 %t156, ptr %l22, !tbaa !24
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l110, !tbaa !29
  %t158 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t158, ptr %l111
  %t159 = load i64, ptr %l22, !tbaa !24
  store i64 %t159, ptr %l112, !tbaa !24
  %t160 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t160, ptr %l113, !tbaa !23
  %t161 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t161, ptr %l114, !tbaa !27
  store ptr %l9, ptr %l115, !tbaa !29
  %t162 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %s7)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t162, ptr %l116
  br label %bb37
bb37:
  %t163 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l116
  %t164 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t163, ptr %t164
  %t165 = load ptr, ptr %l110, !tbaa !29
  %t166 = load %"compiler/source:Span", ptr %l111
  %t167 = load i64, ptr %l112, !tbaa !24
  %t168 = load i32, ptr %l113, !tbaa !23
  %t169 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t170 = load ptr, ptr %l115, !tbaa !29
  %t172 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyCall(ptr %v0, ptr %s0, ptr %s7, ptr %t165, %"compiler/source:Span" %t166, i64 %t167, i32 %t168, { i64, ptr } %t169, ptr %t170, ptr %t164)
  store ptr %t172, ptr %l118
  br label %bb38
bb38:
  %t173 = load ptr, ptr %l118, !tbaa !29
  store ptr %t173, ptr %l23, !tbaa !29
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load i64, ptr %l22, !tbaa !24
  %t178 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyErrors(ptr %v0, ptr %t174, i64 %t175)
  store i32 %t178, ptr %l121
  br label %bb39
bb39:
  %t179 = load i32, ptr %l121, !tbaa !23
  store i32 %t179, ptr %l24, !tbaa !23
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/check:Checker", ptr %t180, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !29
  %t185 = getelementptr %"compiler/generic:Program", ptr %t183, i32 0, i32 2
  %t186 = load i32, ptr %l24, !tbaa !23
  %t189 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t185, i32 %t186)
  store { i64, ptr } %t189, ptr %l126
  br label %bb40
bb40:
  %t190 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t190, 0
  %t193 = icmp sgt i64 %t191, 0
  br i1 %t193, label %bb41, label %bb42
bb41:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t196 = load i32, ptr %l24, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleak(ptr %v0, ptr %t195, i32 %t196)
  br label %bb43
bb42:
  br label %bb49
bb43:
  %t199 = load ptr, ptr %l7, !tbaa !29
  store ptr %t199, ptr %l131, !tbaa !29
  %t200 = load ptr, ptr %l131, !tbaa !29
  %t201 = getelementptr %"compiler/check:frame", ptr %t200, i32 0, i32 16
  %t202 = load i64, ptr %t201, !tbaa !24
  %t204 = add i64 %t202, 1
  %t206 = load ptr, ptr %l131, !tbaa !29
  %t207 = getelementptr %"compiler/check:frame", ptr %t206, i32 0, i32 16
  store i64 %t204, ptr %t207, !tbaa !24
  %t208 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t208, ptr %l134
  %t209 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t209, ptr %l135, !tbaa !23
  %t210 = load ptr, ptr %l23, !tbaa !29
  store ptr %t210, ptr %l137, !tbaa !29
  %t212 = icmp sge i64 0, 0
  br i1 %t212, label %bb44, label %bb45
bb44:
  %t214 = icmp sle i64 0, 1152921504606846975
  br i1 %t214, label %bb46, label %bb47
bb45:
  call void @__olang_check_failed(ptr @olang_loc_fc766b9c907a0b81_82048062a2a05a1d)
  unreachable
bb46:
  %t216 = mul i64 0, 8
  %t217 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t216)
  %t218 = insertvalue { i64, ptr } undef, i64 0, 0
  %t219 = insertvalue { i64, ptr } %t218, ptr %t217, 1
  %t220 = load ptr, ptr %l137, !tbaa !29
  %t222 = call %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t220, { i64, ptr } %t219, i1 false, i1 false)
  store %"compiler/typed:Try" %t222, ptr %l141
  br label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_fc766b9c907a0b81_82048062a2a05a1d)
  unreachable
bb48:
  %t223 = load %"compiler/typed:Try", ptr %l141
  %t224 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/typed:Try" %t223, ptr %t224
  store { i64, [5 x i64] } zeroinitializer, ptr %t225
  %t226 = getelementptr { i64, [5 x i64] }, ptr %t225, i32 0, i32 0
  store i64 14, ptr %t226
  %t227 = load %"compiler/source:Span", ptr %l134
  %t228 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t227, 0
  %t229 = load i32, ptr %l135, !tbaa !23
  %t230 = insertvalue { %"compiler/source:Span", i32, ptr } %t228, i32 %t229, 1
  %t232 = insertvalue { %"compiler/source:Span", i32, ptr } %t230, ptr %t224, 2
  %t233 = getelementptr { i64, [5 x i64] }, ptr %t225, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t232, ptr %t233
  %t234 = load { i64, [5 x i64] }, ptr %t225
  %t236 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t234, ptr %t236
  store ptr %t236, ptr %l23, !tbaa !29
  br label %bb49
bb49:
  %t238 = load i32, ptr %l15, !tbaa !23
  %t239 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t242 = icmp ne i32 %t238, %t239
  br i1 %t242, label %bb50, label %bb51
bb50:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t245 = load i32, ptr %l15, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaks1(ptr %v0, ptr %t244, i32 %t245)
  br label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb53
bb53:
  %t248 = load ptr, ptr %l7, !tbaa !29
  store ptr %t248, ptr %l150, !tbaa !29
  %t249 = load ptr, ptr %l150, !tbaa !29
  %t250 = getelementptr %"compiler/check:frame", ptr %t249, i32 0, i32 16
  %t251 = load i64, ptr %t250, !tbaa !24
  %t253 = add i64 %t251, 1
  %t255 = load ptr, ptr %l150, !tbaa !29
  %t256 = getelementptr %"compiler/check:frame", ptr %t255, i32 0, i32 16
  store i64 %t253, ptr %t256, !tbaa !24
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/check:Checker", ptr %t257, i32 0, i32 32
  %t261 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t259)
  store i64 %t261, ptr %l155
  br label %bb54
bb54:
  %t262 = load i64, ptr %l155, !tbaa !24
  store i64 %t262, ptr %l25, !tbaa !24
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = getelementptr %"compiler/check:Checker", ptr %t263, i32 0, i32 32
  %t266 = load ptr, ptr %l23, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t265, ptr %t266)
  br label %bb55
bb55:
  %t269 = getelementptr %"compiler/typed:ContractInfo", ptr %l6, i32 0, i32 3
  %t270 = load i64, ptr %l21, !tbaa !24
  %t273 = call %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v1, ptr %t269, i64 %t270)
  store %"compiler/source:Span" %t273, ptr %l161
  br label %bb56
bb56:
  %t274 = load %"compiler/source:Span", ptr %l161
  store %"compiler/source:Span" %t274, ptr %l26
  %t275 = load ptr, ptr %l0, !tbaa !29
  store ptr %t275, ptr %l162, !tbaa !29
  %t276 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t276, ptr %l163
  %t277 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t277, ptr %l164
  %t278 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t278, ptr %l165, !tbaa !23
  store i32 36, ptr %l166
  store i32 2, ptr %l167
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = getelementptr %"compiler/check:Checker", ptr %t279, i32 0, i32 32
  %t282 = load i64, ptr %l25, !tbaa !24
  %t285 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t281, i64 %t282)
  store { i64, ptr } %t285, ptr %l171
  br label %bb57
bb57:
  store { i64, [5 x i64] } zeroinitializer, ptr %t286
  %t287 = getelementptr { i64, [5 x i64] }, ptr %t286, i32 0, i32 0
  store i64 9, ptr %t287
  %t288 = load %"compiler/source:Span", ptr %l164
  %t289 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t288, 0
  %t290 = load i32, ptr %l165, !tbaa !23
  %t291 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t289, i32 %t290, 1
  %t292 = load i32, ptr %l166
  %t293 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t291, i32 %t292, 2
  %t294 = load i32, ptr %l167
  %t295 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t293, i32 %t294, 3
  %t296 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t297 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t295, { i64, ptr } %t296, 4
  %t298 = getelementptr { i64, [5 x i64] }, ptr %t286, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t297, ptr %t298
  %t299 = load { i64, [5 x i64] }, ptr %t286
  %t301 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t299, ptr %t301
  store { i64, [3 x i64] } zeroinitializer, ptr %t302
  %t303 = getelementptr { i64, [3 x i64] }, ptr %t302, i32 0, i32 0
  store i64 2, ptr %t303
  %t304 = load %"compiler/source:Span", ptr %l163
  %t305 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t304, 0
  %t307 = insertvalue { %"compiler/source:Span", ptr } %t305, ptr %t301, 1
  %t308 = getelementptr { i64, [3 x i64] }, ptr %t302, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t307, ptr %t308
  %t309 = load { i64, [3 x i64] }, ptr %t302
  %t311 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t309, ptr %t311
  %t312 = load ptr, ptr %l162, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t312, ptr %t311)
  br label %bb58
bb58:
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t316 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t314)
  store ptr %t316, ptr %l177
  br label %bb59
bb59:
  %t317 = load ptr, ptr %l177, !tbaa !29
  %t319 = getelementptr %"compiler/typed:Body", ptr %t317, i32 0, i32 13
  %t320 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t321 = load i32, ptr %t320, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %t319, i32 %t321)
  br label %bb60
bb60:
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t326 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t324)
  store ptr %t326, ptr %l182
  br label %bb61
bb61:
  %t327 = load ptr, ptr %l182, !tbaa !29
  %t329 = getelementptr %"compiler/typed:Body", ptr %t327, i32 0, i32 14
  store ptr %t329, ptr %l184, !tbaa !29
  %t330 = getelementptr %"compiler/typed:ContractInfo", ptr %l6, i32 0, i32 0
  %t331 = load { i64, ptr }, ptr %t330, !tbaa !27
  store { i64, ptr } %t331, ptr %l185, !tbaa !27
  %t332 = getelementptr %"compiler/typed:ContractInfo", ptr %l6, i32 0, i32 4
  %t333 = load i64, ptr %l21, !tbaa !24
  %t336 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v1, ptr %s7, ptr %t332, i64 %t333)
  store { i64, ptr } %t336, ptr %l188
  br label %bb62
bb62:
  %t337 = load { i64, ptr }, ptr %l185, !tbaa !27
  %t338 = extractvalue { i64, ptr } %t337, 1
  %t339 = extractvalue { i64, ptr } %t337, 0
  %t340 = extractvalue { i64, ptr } { i64 2, ptr @.d13 }, 1
  %t341 = extractvalue { i64, ptr } { i64 2, ptr @.d13 }, 0
  %t342 = add i64 %t339, %t341
  %t343 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t344 = extractvalue { i64, ptr } %t343, 1
  %t345 = extractvalue { i64, ptr } %t343, 0
  %t346 = add i64 %t342, %t345
  %t347 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t346)
  call void @olang_textcopy(ptr %t347, ptr %t338, i64 %t339)
  %t348 = getelementptr i8, ptr %t347, i64 %t339
  call void @olang_textcopy(ptr %t348, ptr %t340, i64 %t341)
  %t349 = getelementptr i8, ptr %t348, i64 %t341
  call void @olang_textcopy(ptr %t349, ptr %t344, i64 %t345)
  %t350 = insertvalue { i64, ptr } undef, i64 %t346, 0
  %t351 = insertvalue { i64, ptr } %t350, ptr %t347, 1
  %t353 = extractvalue { i64, ptr } %t351, 0
  %t354 = extractvalue { i64, ptr } %t351, 1
  %t355 = mul i64 %t353, 1
  %t356 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t355)
  call void @llvm.memcpy.p0.p0.i64(ptr %t356, ptr %t354, i64 %t355, i1 false)
  %t357 = insertvalue { i64, ptr } undef, i64 %t353, 0
  %t358 = insertvalue { i64, ptr } %t357, ptr %t356, 1
  %t359 = load ptr, ptr %l184, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t359, { i64, ptr } %t358)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s7)
  br label %bb64
bb64:
  %t361 = load i64, ptr %l20, !tbaa !24
  %t363 = add i64 %t361, 1
  store i64 %t363, ptr %l20, !tbaa !24
  br label %bb32
bb65:
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t367 = getelementptr %"compiler/check:Checker", ptr %t365, i32 0, i32 32
  %t369 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t367)
  store i64 %t369, ptr %l195
  br label %bb66
bb66:
  %t370 = load i64, ptr %l195, !tbaa !24
  store i64 %t370, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  %t371 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t373 = extractvalue { i64, ptr } %t371, 0
  store i64 %t373, ptr %l29, !tbaa !24
  store i64 1, ptr %l30, !tbaa !24
  %t375 = load i64, ptr %l29, !tbaa !24
  %t376 = load i64, ptr %l28, !tbaa !24
  %t379 = icmp sgt i64 %t375, %t376
  br i1 %t379, label %bb67, label %bb68
bb67:
  %t381 = load i64, ptr %l30, !tbaa !24
  %t383 = icmp sgt i64 %t381, 0
  br i1 %t383, label %bb69, label %bb70
bb68:
  store i64 0, ptr %l201, !tbaa !24
  br label %bb72
bb69:
  %t385 = load i64, ptr %l29, !tbaa !24
  %t386 = load i64, ptr %l28, !tbaa !24
  %t389 = sub i64 %t385, %t386
  %t390 = load i64, ptr %l30, !tbaa !24
  %t393 = add i64 %t389, %t390
  %t395 = sub i64 %t393, 1
  %t396 = load i64, ptr %l30, !tbaa !24
  %t399 = sdiv i64 %t395, %t396
  store i64 %t399, ptr %l204, !tbaa !24
  br label %bb71
bb70:
  store i64 0, ptr %l204, !tbaa !24
  br label %bb71
bb71:
  %t401 = load i64, ptr %l204, !tbaa !24
  store i64 %t401, ptr %l201, !tbaa !24
  br label %bb72
bb72:
  %t402 = load i64, ptr %l201, !tbaa !24
  store i64 %t402, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  br label %bb73
bb73:
  store %olang.scope zeroinitializer, ptr %s13
  %t403 = load i64, ptr %l32, !tbaa !24
  %t404 = load i64, ptr %l31, !tbaa !24
  %t407 = icmp slt i64 %t403, %t404
  %t409 = xor i1 %t407, true
  br i1 %t409, label %bb74, label %bb75
bb74:
  call void @__olang_scope_close(ptr %s13)
  br label %bb80
bb75:
  br label %bb76
bb76:
  %t411 = load i64, ptr %l28, !tbaa !24
  %t412 = load i64, ptr %l32, !tbaa !24
  %t413 = load i64, ptr %l30, !tbaa !24
  %t416 = mul i64 %t412, %t413
  %t419 = add i64 %t411, %t416
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t423 = getelementptr %"compiler/check:Checker", ptr %t421, i32 0, i32 32
  store ptr %t423, ptr %l223, !tbaa !29
  %t424 = load ptr, ptr %l0, !tbaa !29
  %t425 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t431 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldArg(ptr %v0, ptr %s0, ptr %t424, { i64, ptr } %t425, ptr %l9, i64 %t419)
  store ptr %t431, ptr %l228
  br label %bb77
bb77:
  %t432 = load ptr, ptr %l223, !tbaa !29
  %t433 = load ptr, ptr %l228, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t432, ptr %t433)
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s13)
  br label %bb79
bb79:
  %t434 = load i64, ptr %l32, !tbaa !24
  %t436 = add i64 %t434, 1
  store i64 %t436, ptr %l32, !tbaa !24
  br label %bb73
bb80:
  %t438 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t438, ptr %l231
  %t439 = load i32, ptr %l2, !tbaa !23
  store i32 %t439, ptr %l232, !tbaa !23
  store ptr %a3, ptr %l233, !tbaa !29
  %t441 = load ptr, ptr %l0, !tbaa !29
  %t443 = getelementptr %"compiler/check:Checker", ptr %t441, i32 0, i32 32
  %t444 = load i64, ptr %l27, !tbaa !24
  %t447 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t443, i64 %t444)
  store { i64, ptr } %t447, ptr %l237
  br label %bb81
bb81:
  store { i64, [2 x i64] } zeroinitializer, ptr %t448
  %t449 = getelementptr { i64, [2 x i64] }, ptr %t448, i32 0, i32 0
  store i64 0, ptr %t449
  %t450 = load { i64, [2 x i64] }, ptr %t448
  %t452 = load ptr, ptr %l233, !tbaa !29
  %t453 = load { i64, ptr }, ptr %l237, !tbaa !27
  %t456 = call %"compiler/typed:Call" @compiler_2ftyped_3aCall_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t452, { i64, ptr } %t453, { i64, [2 x i64] } %t450, i32 %a5, i1 false)
  store %"compiler/typed:Call" %t456, ptr %l240
  br label %bb82
bb82:
  %t457 = load %"compiler/typed:Call", ptr %l240
  %t458 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/typed:Call" %t457, ptr %t458
  store { i64, [5 x i64] } zeroinitializer, ptr %t459
  %t460 = getelementptr { i64, [5 x i64] }, ptr %t459, i32 0, i32 0
  store i64 6, ptr %t460
  %t461 = load %"compiler/source:Span", ptr %l231
  %t462 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t461, 0
  %t463 = load i32, ptr %l232, !tbaa !23
  %t464 = insertvalue { %"compiler/source:Span", i32, ptr } %t462, i32 %t463, 1
  %t466 = insertvalue { %"compiler/source:Span", i32, ptr } %t464, ptr %t458, 2
  %t467 = getelementptr { i64, [5 x i64] }, ptr %t459, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t466, ptr %t467
  %t468 = load { i64, [5 x i64] }, ptr %t459
  %t469 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store ptr %t469, ptr %lp34
  %t471 = load ptr, ptr %lp34
  store { i64, [5 x i64] } %t468, ptr %t471
  %t472 = load i32, ptr %l2, !tbaa !23
  %t473 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t476 = icmp eq i32 %t472, %t473
  br i1 %t476, label %bb83, label %bb84
bb83:
  store i1 true, ptr %l246, !tbaa !21
  br label %bb85
bb84:
  %t478 = load i32, ptr %l2, !tbaa !23
  %t479 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t482 = icmp eq i32 %t478, %t479
  store i1 %t482, ptr %l246, !tbaa !21
  br label %bb85
bb85:
  %t484 = load i1, ptr %l246, !tbaa !21
  br i1 %t484, label %bb86, label %bb87
bb86:
  %t485 = load ptr, ptr %l0, !tbaa !29
  %t486 = load %"compiler/source:Span", ptr %l1
  %t487 = load ptr, ptr %lp34
  store { i64, [3 x i64] } zeroinitializer, ptr %t488
  %t489 = getelementptr { i64, [3 x i64] }, ptr %t488, i32 0, i32 0
  store i64 2, ptr %t489
  %t491 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t486, 0
  %t493 = insertvalue { %"compiler/source:Span", ptr } %t491, ptr %t487, 1
  %t494 = getelementptr { i64, [3 x i64] }, ptr %t488, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t493, ptr %t494
  %t495 = load { i64, [3 x i64] }, ptr %t488
  %t497 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t495, ptr %t497
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t485, ptr %t497)
  br label %bb88
bb87:
  br label %bb91
bb88:
  %t500 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t500, ptr %l255
  %t501 = load i32, ptr %l2, !tbaa !23
  store i32 %t501, ptr %l256, !tbaa !23
  %t502 = load ptr, ptr %l0, !tbaa !29
  %t504 = getelementptr %"compiler/check:Checker", ptr %t502, i32 0, i32 33
  %t505 = load i64, ptr %l8, !tbaa !24
  %t508 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t504, i64 %t505)
  store { i64, ptr } %t508, ptr %l260
  br label %bb89
bb89:
  %t509 = load { i64, ptr }, ptr %l260, !tbaa !27
  %t510 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t509, ptr null)
  store %"compiler/typed:Seq" %t510, ptr %l261
  br label %bb90
bb90:
  %t511 = load %"compiler/typed:Seq", ptr %l261
  %t512 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Seq" %t511, ptr %t512
  store { i64, [5 x i64] } zeroinitializer, ptr %t513
  %t514 = getelementptr { i64, [5 x i64] }, ptr %t513, i32 0, i32 0
  store i64 12, ptr %t514
  %t515 = load %"compiler/source:Span", ptr %l255
  %t516 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t515, 0
  %t517 = load i32, ptr %l256, !tbaa !23
  %t518 = insertvalue { %"compiler/source:Span", i32, ptr } %t516, i32 %t517, 1
  %t520 = insertvalue { %"compiler/source:Span", i32, ptr } %t518, ptr %t512, 2
  %t521 = getelementptr { i64, [5 x i64] }, ptr %t513, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t520, ptr %t521
  %t522 = load { i64, [5 x i64] }, ptr %t513
  %t524 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t522, ptr %t524
  call void @__olang_scope_close(ptr %s0)
  store ptr %t524, ptr %rv
  br label %ret
bb91:
  %t526 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t526, ptr %l265
  %t527 = load i32, ptr %l2, !tbaa !23
  store i32 %t527, ptr %l266, !tbaa !23
  %t528 = load ptr, ptr %l0, !tbaa !29
  %t530 = getelementptr %"compiler/check:Checker", ptr %t528, i32 0, i32 33
  %t531 = load i64, ptr %l8, !tbaa !24
  %t534 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t530, i64 %t531)
  store { i64, ptr } %t534, ptr %l270
  br label %bb92
bb92:
  %t535 = load ptr, ptr %lp34
  %t536 = load { i64, ptr }, ptr %l270, !tbaa !27
  %t538 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t536, ptr %t535)
  store %"compiler/typed:Seq" %t538, ptr %l272
  br label %bb93
bb93:
  %t539 = load %"compiler/typed:Seq", ptr %l272
  %t540 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Seq" %t539, ptr %t540
  store { i64, [5 x i64] } zeroinitializer, ptr %t541
  %t542 = getelementptr { i64, [5 x i64] }, ptr %t541, i32 0, i32 0
  store i64 12, ptr %t542
  %t543 = load %"compiler/source:Span", ptr %l265
  %t544 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t543, 0
  %t545 = load i32, ptr %l266, !tbaa !23
  %t546 = insertvalue { %"compiler/source:Span", i32, ptr } %t544, i32 %t545, 1
  %t548 = insertvalue { %"compiler/source:Span", i32, ptr } %t546, ptr %t540, 2
  %t549 = getelementptr { i64, [5 x i64] }, ptr %t541, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t548, ptr %t549
  %t550 = load { i64, [5 x i64] }, ptr %t541
  %t552 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t550, ptr %t552
  call void @__olang_scope_close(ptr %s0)
  store ptr %t552, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelseDropped(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l17 = alloca i1
  %l18 = alloca ptr
  %l26 = alloca i1
  %l27 = alloca ptr
  %l35 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t18 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 0
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/load:Loader", ptr %t22, i32 0, i32 4
  %t25 = load ptr, ptr %t24, !tbaa !29
  store ptr %t25, ptr %l3, !tbaa !29
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t29 = getelementptr %"compiler/ast:If", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = icmp eq ptr %t30, null
  br i1 %t32, label %bb6, label %bb7
bb6:
  %t34 = load ptr, ptr %l3, !tbaa !29
  store ptr %t34, ptr %l18, !tbaa !29
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"compiler/ast:If", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = icmp eq ptr %t38, null
  br i1 %t40, label %bb8, label %bb9
bb7:
  %t42 = load ptr, ptr %l3, !tbaa !29
  store ptr %t42, ptr %l27, !tbaa !29
  %t43 = load ptr, ptr %l2, !tbaa !29
  %t45 = getelementptr %"compiler/ast:If", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = icmp eq ptr %t46, null
  br i1 %t48, label %bb12, label %bb13
bb8:
  call void @__olang_check_failed(ptr @olang_loc_9f409528a62be557_96e98ebb70e4ac13)
  unreachable
bb9:
  br label %bb10
bb10:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = getelementptr %"compiler/ast:If", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t56 = getelementptr %"compiler/ast:Branch", ptr %t53, i32 0, i32 2
  %t57 = load i64, ptr %t56, !tbaa !24
  %t58 = load ptr, ptr %l18, !tbaa !29
  %t60 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eIsDropped(ptr %v0, ptr %t58, i64 %t57)
  store i1 %t60, ptr %l26
  br label %bb11
bb11:
  %t61 = load i1, ptr %l26, !tbaa !21
  store i1 %t61, ptr %l17, !tbaa !21
  br label %bb16
bb12:
  call void @__olang_check_failed(ptr @olang_loc_9f409528a62be557_96e98ebb70e4ac13)
  unreachable
bb13:
  br label %bb14
bb14:
  %t62 = load ptr, ptr %l2, !tbaa !29
  %t64 = getelementptr %"compiler/ast:If", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t68 = getelementptr %"compiler/ast:Branch", ptr %t65, i32 0, i32 2
  %t69 = load i64, ptr %t68, !tbaa !24
  %t70 = load ptr, ptr %l27, !tbaa !29
  %t72 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eIsCut(ptr %v0, ptr %t70, i64 %t69)
  store i1 %t72, ptr %l35
  br label %bb15
bb15:
  %t73 = load i1, ptr %l35, !tbaa !21
  store i1 %t73, ptr %l17, !tbaa !21
  br label %bb16
bb16:
  %t74 = load i1, ptr %l17, !tbaa !21
  store i1 %t74, ptr %rv
  br label %ret
bb17:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l7 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i64
  %l17 = alloca i32
  %l24 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a2, ptr %l4, !tbaa !65
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t3 = load i32, ptr %l1, !tbaa !23
  %t6 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eallWords(ptr %v0, ptr %t2, i32 %t3)
  store i64 %t6, ptr %l7
  br label %bb1
bb1:
  %t7 = load i64, ptr %l4, !tbaa !65
  %t8 = load i64, ptr %l7, !tbaa !65
  %t9 = and i64 %t7, %t8
  store i64 %t9, ptr %l3, !tbaa !65
  %t11 = load i64, ptr %l3, !tbaa !65
  %t13 = icmp eq i64 %t11, 0
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t15, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = load i64, ptr %l3, !tbaa !65
  store i64 %t17, ptr %l12, !tbaa !65
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eallWords(ptr %v0, ptr %t18, i32 %t19)
  store i64 %t22, ptr %l15
  br label %bb5
bb5:
  %t23 = load i64, ptr %l12, !tbaa !65
  %t24 = load i64, ptr %l15, !tbaa !65
  %t25 = icmp eq i64 %t23, %t24
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t27 = load i32, ptr %l1, !tbaa !23
  store i32 %t27, ptr %l17, !tbaa !23
  br label %bb9
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t35 = load i32, ptr %l1, !tbaa !23
  %t36 = load i64, ptr %l3, !tbaa !65
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %t34, i32 %t35, i64 %t36)
  store i32 %t40, ptr %l24
  br label %bb8
bb8:
  %t41 = load i32, ptr %l24, !tbaa !23
  store i32 %t41, ptr %l17, !tbaa !23
  br label %bb9
bb9:
  %t42 = load i32, ptr %l17, !tbaa !23
  store i32 %t42, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrsText(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l14 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca %"std/prelude/text:StringBuilder"
  %l28 = alloca i64
  %l31 = alloca i64
  %l52 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l64 = alloca i64
  %l65 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t6, i32 %a1)
  store { i64, ptr } %t10, ptr %l14
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t11, ptr %l2, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t16 = icmp eq i64 %t14, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 7, ptr @.d14 }, ptr %l18, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t18, ptr %l19, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 0
  store i64 %t20, ptr %l20, !tbaa !24
  %t21 = load i64, ptr %l20, !tbaa !24
  %t22 = mul i64 %t21, 1
  %t23 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t22)
  %t24 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l21, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = load i64, ptr %l20, !tbaa !24
  %t31 = mul i64 %t30, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t27, ptr %t29, i64 %t31, i1 false)
  %t32 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t32, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t33 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t33, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t34 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t34, ptr %l22
  br label %bb5
bb5:
  %t35 = load %"std/prelude/text:StringBuilder", ptr %l22
  store %"std/prelude/text:StringBuilder" %t35, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 0
  store i64 %t38, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t44 = icmp sgt i64 %t40, %t41
  br i1 %t44, label %bb6, label %bb7
bb6:
  %t46 = load i64, ptr %l6, !tbaa !24
  %t48 = icmp sgt i64 %t46, 0
  br i1 %t48, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb11
bb8:
  %t50 = load i64, ptr %l5, !tbaa !24
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = sub i64 %t50, %t51
  %t55 = load i64, ptr %l6, !tbaa !24
  %t58 = add i64 %t54, %t55
  %t60 = sub i64 %t58, 1
  %t61 = load i64, ptr %l6, !tbaa !24
  %t64 = sdiv i64 %t60, %t61
  store i64 %t64, ptr %l31, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb10
bb10:
  %t66 = load i64, ptr %l31, !tbaa !24
  store i64 %t66, ptr %l28, !tbaa !24
  br label %bb11
bb11:
  %t67 = load i64, ptr %l28, !tbaa !24
  store i64 %t67, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t68 = load i64, ptr %l8, !tbaa !24
  %t69 = load i64, ptr %l7, !tbaa !24
  %t72 = icmp slt i64 %t68, %t69
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb14:
  br label %bb15
bb15:
  %t76 = load i64, ptr %l4, !tbaa !24
  %t77 = load i64, ptr %l8, !tbaa !24
  %t78 = load i64, ptr %l6, !tbaa !24
  %t81 = mul i64 %t77, %t78
  %t84 = add i64 %t76, %t81
  store i64 %t84, ptr %l9, !tbaa !24
  %t86 = load i64, ptr %l9, !tbaa !24
  %t88 = icmp sgt i64 %t86, 0
  br i1 %t88, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l3, { i64, ptr } { i64 2, ptr @.d15 })
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb19
bb19:
  store ptr %l3, ptr %l52, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t92, ptr %l54, !tbaa !27
  %t93 = load i64, ptr %l9, !tbaa !24
  %t95 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr i32, ptr %t96, i64 %t93
  %t98 = load i32, ptr %t97, !tbaa !33
  %t101 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t91, i32 %t98)
  store { i64, ptr } %t101, ptr %l57
  br label %bb20
bb20:
  %t102 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 0
  %t104 = extractvalue { i64, ptr } %t102, 1
  %t105 = mul i64 %t103, 1
  %t106 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t105)
  call void @llvm.memcpy.p0.p0.i64(ptr %t106, ptr %t104, i64 %t105, i1 false)
  %t107 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  %t109 = load ptr, ptr %l52, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %t109, { i64, ptr } %t108)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb22:
  %t111 = load i64, ptr %l8, !tbaa !24
  %t113 = add i64 %t111, 1
  store i64 %t113, ptr %l8, !tbaa !24
  br label %bb12
bb23:
  %t116 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l3)
  store { i64, ptr } %t116, ptr %l62
  br label %bb24
bb24:
  %t117 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t117, ptr %l63, !tbaa !27
  %t118 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t118, 0
  store i64 %t119, ptr %l64, !tbaa !24
  %t120 = load i64, ptr %l64, !tbaa !24
  %t121 = mul i64 %t120, 1
  %t122 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t121)
  %t123 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  store { i64, ptr } %t124, ptr %l65, !tbaa !27
  %t125 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = load i64, ptr %l64, !tbaa !24
  %t130 = mul i64 %t129, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t126, ptr %t128, i64 %t130, i1 false)
  %t131 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t131, ptr %l63, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t132 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t132, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailOp(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/source:Span" %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l35 = alloca %"compiler/source:Span"
  %l37 = alloca %"compiler/msgs:Msg"
  %l38 = alloca %"compiler/msgs:Msg"
  %l39 = alloca %"compiler/msgs:Msg"
  %l40 = alloca i64
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l10, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l4, !tbaa !29
  store ptr %t5, ptr %l11, !tbaa !29
  %t6 = load ptr, ptr %l11, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t6, i32 0, i32 16
  %t8 = load i64, ptr %t7, !tbaa !24
  %t10 = add i64 %t8, 1
  %t12 = load ptr, ptr %l11, !tbaa !29
  %t13 = getelementptr %"compiler/check:frame", ptr %t12, i32 0, i32 16
  store i64 %t10, ptr %t13, !tbaa !24
  store { i64, ptr } %a1, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  store i64 %t18, ptr %l7, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t20 = load i64, ptr %l6, !tbaa !24
  %t21 = load i64, ptr %l7, !tbaa !24
  %t24 = icmp slt i64 %t20, %t21
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t28 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t28, ptr %l21, !tbaa !27
  %t29 = load i64, ptr %l6, !tbaa !24
  %t31 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr i32, ptr %t32, i64 %t29
  %t34 = load i32, ptr %t33, !tbaa !33
  store i32 %t34, ptr %l8, !tbaa !23
  %t36 = load i32, ptr %l8, !tbaa !23
  %t37 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t40 = icmp ne i32 %t36, %t37
  br i1 %t40, label %bb6, label %bb7
bb6:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l8, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaks1(ptr %v0, ptr %t42, i32 %t43)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t46 = load i64, ptr %l6, !tbaa !24
  %t48 = add i64 %t46, 1
  store i64 %t48, ptr %l6, !tbaa !24
  br label %bb2
bb11:
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t52 = getelementptr %"compiler/check:frame", ptr %t50, i32 0, i32 15
  %t53 = load i64, ptr %t52, !tbaa !24
  %t55 = icmp eq i64 %t53, 0
  br i1 %t55, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s5
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l34, !tbaa !29
  store %"compiler/source:Span" %a2, ptr %l35
  br i1 %a3, label %bb14, label %bb15
bb13:
  br label %bb20
bb14:
  %t61 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAsCanFail(ptr %s5)
  store %"compiler/msgs:Msg" %t61, ptr %l38
  br label %bb16
bb15:
  %t62 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnhandledFallibleCall(ptr %s5)
  store %"compiler/msgs:Msg" %t62, ptr %l39
  br label %bb17
bb16:
  %t63 = load %"compiler/msgs:Msg", ptr %l38
  store %"compiler/msgs:Msg" %t63, ptr %l37
  br label %bb18
bb17:
  %t64 = load %"compiler/msgs:Msg", ptr %l39
  store %"compiler/msgs:Msg" %t64, ptr %l37
  br label %bb18
bb18:
  %t65 = load ptr, ptr %l34, !tbaa !29
  %t66 = load %"compiler/source:Span", ptr %l35
  %t67 = load %"compiler/msgs:Msg", ptr %l37
  %t68 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t65, %"compiler/source:Span" %t66, %"compiler/msgs:Msg" %t67)
  store i64 %t68, ptr %l40
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb20
bb20:
  store i32 2, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldTypes(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i1
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l15 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l27 = alloca i64
  %l29 = alloca i64
  %l32 = alloca i64
  %l41 = alloca i64
  %l44 = alloca i64
  %l63 = alloca { i64, ptr }
  %l67 = alloca ptr
  %l69 = alloca ptr
  %l72 = alloca i32
  %l74 = alloca %"compiler/typed:Local"
  %l76 = alloca { i64, ptr }
  %l81 = alloca i1
  %l92 = alloca ptr
  %l93 = alloca i32
  %l98 = alloca i32
  %l103 = alloca i1
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l15, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l20
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l15, !tbaa !29
  %t18 = load i32, ptr %l20, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t17, i32 %t18)
  store { i64, ptr } %t19, ptr %l21
  br label %bb2
bb2:
  %t20 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t20, ptr %l2, !tbaa !27
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t21)
  store ptr %t23, ptr %l23
  br label %bb3
bb3:
  %t24 = load ptr, ptr %l23, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Body", ptr %t24, i32 0, i32 10
  %t27 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t26
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t27, ptr %l3
  %t29 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  store i64 %t31, ptr %l27, !tbaa !24
  %t33 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %l3)
  store i64 %t33, ptr %l29
  br label %bb4
bb4:
  %t34 = load i64, ptr %l27, !tbaa !24
  %t35 = load i64, ptr %l29, !tbaa !24
  %t36 = icmp ne i64 %t34, %t35
  br i1 %t36, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  br label %bb7
bb7:
  %t38 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 0
  store i64 %t40, ptr %l32, !tbaa !24
  %t41 = load i64, ptr %l32, !tbaa !24
  %t42 = icmp sge i64 %t41, 0
  br i1 %t42, label %bb8, label %bb9
bb8:
  %t44 = load i64, ptr %l32, !tbaa !24
  %t45 = icmp sle i64 %t44, 2305843009213693951
  br i1 %t45, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_ad8923f011cb5acf_6f8a151e60866063)
  unreachable
bb10:
  %t47 = load i64, ptr %l32, !tbaa !24
  %t48 = mul i64 %t47, 4
  %t49 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t48)
  %t50 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  store { i64, ptr } %t51, ptr %l4, !tbaa !27
  store i1 false, ptr %l5, !tbaa !21
  store i64 0, ptr %l6, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  store i64 %t55, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t57 = load i64, ptr %l7, !tbaa !24
  %t58 = load i64, ptr %l6, !tbaa !24
  %t61 = icmp sgt i64 %t57, %t58
  br i1 %t61, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_ad8923f011cb5acf_6f8a151e60866063)
  unreachable
bb12:
  %t63 = load i64, ptr %l8, !tbaa !24
  %t65 = icmp sgt i64 %t63, 0
  br i1 %t65, label %bb14, label %bb15
bb13:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb17
bb14:
  %t67 = load i64, ptr %l7, !tbaa !24
  %t68 = load i64, ptr %l6, !tbaa !24
  %t71 = sub i64 %t67, %t68
  %t72 = load i64, ptr %l8, !tbaa !24
  %t75 = add i64 %t71, %t72
  %t77 = sub i64 %t75, 1
  %t78 = load i64, ptr %l8, !tbaa !24
  %t81 = sdiv i64 %t77, %t78
  store i64 %t81, ptr %l44, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb16
bb16:
  %t83 = load i64, ptr %l44, !tbaa !24
  store i64 %t83, ptr %l41, !tbaa !24
  br label %bb17
bb17:
  %t84 = load i64, ptr %l41, !tbaa !24
  store i64 %t84, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s3
  %t85 = load i64, ptr %l10, !tbaa !24
  %t86 = load i64, ptr %l9, !tbaa !24
  %t89 = icmp slt i64 %t85, %t86
  %t91 = xor i1 %t89, true
  br i1 %t91, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb32
bb20:
  br label %bb21
bb21:
  %t93 = load i64, ptr %l6, !tbaa !24
  %t94 = load i64, ptr %l10, !tbaa !24
  %t95 = load i64, ptr %l8, !tbaa !24
  %t98 = mul i64 %t94, %t95
  %t101 = add i64 %t93, %t98
  store i64 %t101, ptr %l11, !tbaa !24
  %t103 = load i64, ptr %l11, !tbaa !24
  %t104 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t104, ptr %l63, !tbaa !27
  %t105 = load i64, ptr %l11, !tbaa !24
  %t107 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr i32, ptr %t108, i64 %t105
  %t110 = load i32, ptr %t109, !tbaa !33
  %t113 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr i32, ptr %t114, i64 %t103
  store i32 %t110, ptr %t115, !tbaa !33
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t116)
  store ptr %t118, ptr %l67
  br label %bb22
bb22:
  %t119 = load ptr, ptr %l67, !tbaa !29
  %t121 = getelementptr %"compiler/typed:Body", ptr %t119, i32 0, i32 7
  store ptr %t121, ptr %l69, !tbaa !29
  %t122 = load i64, ptr %l11, !tbaa !24
  %t125 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %l3, i64 %t122)
  store i32 %t125, ptr %l72
  br label %bb23
bb23:
  %t126 = load i32, ptr %l72, !tbaa !23
  %t127 = sext i32 %t126 to i64
  %t128 = load ptr, ptr %l69, !tbaa !29
  %t130 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t128, i64 %t127)
  store %"compiler/typed:Local" %t130, ptr %l74
  br label %bb24
bb24:
  %t131 = getelementptr %"compiler/typed:Local", ptr %l74, i32 0, i32 2
  %t132 = load i32, ptr %t131, !tbaa !23
  store i32 %t132, ptr %l12, !tbaa !23
  %t134 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t134, ptr %l76, !tbaa !27
  %t135 = load i64, ptr %l11, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr i32, ptr %t138, i64 %t135
  %t140 = load i32, ptr %t139, !tbaa !33
  %t141 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t144 = icmp eq i32 %t140, %t141
  br i1 %t144, label %bb25, label %bb26
bb25:
  %t146 = load i32, ptr %l12, !tbaa !23
  %t147 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t150 = icmp ne i32 %t146, %t147
  store i1 %t150, ptr %l81, !tbaa !21
  br label %bb27
bb26:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb27
bb27:
  %t152 = load i1, ptr %l81, !tbaa !21
  br i1 %t152, label %bb28, label %bb29
bb28:
  %t153 = load i64, ptr %l11, !tbaa !24
  %t154 = load i32, ptr %l12, !tbaa !23
  %t157 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = getelementptr i32, ptr %t158, i64 %t153
  store i32 %t154, ptr %t159, !tbaa !33
  store i1 true, ptr %l5, !tbaa !21
  br label %bb30
bb29:
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb31:
  %t160 = load i64, ptr %l10, !tbaa !24
  %t162 = add i64 %t160, 1
  store i64 %t162, ptr %l10, !tbaa !24
  br label %bb18
bb32:
  %t164 = load i1, ptr %l5, !tbaa !21
  br i1 %t164, label %bb33, label %bb34
bb33:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/check:Checker", ptr %t166, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !29
  %t171 = getelementptr %"compiler/generic:Program", ptr %t169, i32 0, i32 2
  store ptr %t171, ptr %l92, !tbaa !29
  %t172 = load i32, ptr %l1, !tbaa !23
  store i32 %t172, ptr %l93, !tbaa !23
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/check:Checker", ptr %t173, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !29
  %t178 = getelementptr %"compiler/generic:Program", ptr %t176, i32 0, i32 2
  %t179 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t182 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t178, { i64, ptr } %t179)
  store i32 %t182, ptr %l98
  br label %bb35
bb34:
  br label %bb38
bb35:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/check:Checker", ptr %t183, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !29
  %t188 = getelementptr %"compiler/generic:Program", ptr %t186, i32 0, i32 2
  %t189 = load i32, ptr %l1, !tbaa !23
  %t192 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t188, i32 %t189)
  store i1 %t192, ptr %l103
  br label %bb36
bb36:
  %t193 = load ptr, ptr %l92, !tbaa !29
  %t194 = load i32, ptr %l93, !tbaa !23
  %t195 = load i32, ptr %l98, !tbaa !23
  %t196 = load i1, ptr %l103, !tbaa !21
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetStructBody(ptr %v0, ptr %t193, i32 %t194, i32 %t195, i1 %t196)
  br label %bb37
bb37:
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldArg(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l8 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l15 = alloca %"compiler/source:Span"
  %l18 = alloca i64
  %l19 = alloca ptr
  %rv = alloca ptr
  store { i64, ptr } %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t2 = load i64, ptr %l3, !tbaa !24
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t1, i64 %t2)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  %t7 = icmp slt i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t9, ptr %l8, !tbaa !27
  %t10 = load i64, ptr %l3, !tbaa !24
  %t12 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr ptr, ptr %t13, i64 %t10
  %t15 = load ptr, ptr %t14, !tbaa !39
  store ptr %t15, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store ptr %a0, ptr %l11, !tbaa !29
  %t18 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t18, ptr %l12, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  %t26 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t24)
  store %"compiler/source:Span" %t26, ptr %l15
  br label %bb5
bb5:
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t27, i64 %t28)
  store i64 %t31, ptr %l18
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l11, !tbaa !29
  %t33 = load %"compiler/source:Span", ptr %l15
  %t34 = load i64, ptr %l18, !tbaa !24
  %t35 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t32, %"compiler/source:Span" %t33, i64 %t34)
  store ptr %t35, ptr %l19
  br label %bb7
bb7:
  %t36 = load ptr, ptr %l19, !tbaa !29
  store ptr %t36, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritableAt(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i32
  %l7 = alloca i1
  %l16 = alloca i32
  %l23 = alloca i64
  %l27 = alloca i1
  %l36 = alloca i32
  %l39 = alloca ptr
  %l44 = alloca i32
  %l47 = alloca i1
  %l52 = alloca ptr
  %l57 = alloca i32
  %l59 = alloca i1
  %l62 = alloca ptr
  %l67 = alloca i32
  %l69 = alloca i1
  %l75 = alloca i1
  %l80 = alloca i32
  %l83 = alloca ptr
  %l88 = alloca i32
  %l90 = alloca i1
  %l93 = alloca ptr
  %l98 = alloca i32
  %l100 = alloca i1
  %l103 = alloca ptr
  %l108 = alloca i32
  %l111 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t5, %t6
  store i1 %t9, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l7, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l16
  br label %bb7
bb7:
  %t23 = load i32, ptr %l16
  store i32 %t23, ptr %l3
  %t24 = load i32, ptr %l3
  %t26 = trunc i64 20 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb15
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t35 = load i32, ptr %l1, !tbaa !23
  %t38 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t34, i32 %t35)
  store i64 %t38, ptr %l23
  br label %bb11
bb11:
  %t39 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t40 = load i64, ptr %l23, !tbaa !24
  %t42 = and i64 %t40, %t39
  %t44 = icmp ne i64 %t42, 0
  br i1 %t44, label %bb12, label %bb13
bb12:
  %t46 = load i64, ptr %l2, !tbaa !24
  %t48 = icmp sgt i64 %t46, 0
  store i1 %t48, ptr %l27, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb14
bb14:
  %t50 = load i1, ptr %l27, !tbaa !21
  store i1 %t50, ptr %rv
  br label %ret
bb15:
  %t51 = load i32, ptr %l3
  %t53 = trunc i64 19 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb25
bb18:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  %t62 = load i32, ptr %l1, !tbaa !23
  %t65 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t61, i32 %t62)
  store i32 %t65, ptr %l36
  br label %bb19
bb19:
  %t66 = load i32, ptr %l36, !tbaa !23
  %t67 = icmp eq i32 %t66, 0
  br i1 %t67, label %bb20, label %bb21
bb20:
  store i1 false, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l39, !tbaa !29
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 2
  %t77 = load i32, ptr %l1, !tbaa !23
  %t80 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t76, i32 %t77)
  store i32 %t80, ptr %l44
  br label %bb23
bb23:
  %t81 = load i64, ptr %l2, !tbaa !24
  %t83 = add i64 %t81, 1
  %t84 = load ptr, ptr %l39, !tbaa !29
  %t85 = load i32, ptr %l44, !tbaa !23
  %t87 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritableAt(ptr %v0, ptr %t84, i32 %t85, i64 %t83)
  store i1 %t87, ptr %l47
  br label %bb24
bb24:
  %t88 = load i1, ptr %l47, !tbaa !21
  store i1 %t88, ptr %rv
  br label %ret
bb25:
  %t89 = load i32, ptr %l3
  %t91 = trunc i64 22 to i32
  %t92 = icmp eq i32 %t89, %t91
  br i1 %t92, label %bb26, label %bb27
bb26:
  br label %bb30
bb27:
  %t94 = load i32, ptr %l3
  %t96 = trunc i64 23 to i32
  %t97 = icmp eq i32 %t94, %t96
  br i1 %t97, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb33
bb30:
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l52, !tbaa !29
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/check:Checker", ptr %t100, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = getelementptr %"compiler/generic:Program", ptr %t103, i32 0, i32 2
  %t106 = load i32, ptr %l1, !tbaa !23
  %t109 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t105, i32 %t106)
  store i32 %t109, ptr %l57
  br label %bb31
bb31:
  %t110 = load i64, ptr %l2, !tbaa !24
  %t111 = load ptr, ptr %l52, !tbaa !29
  %t112 = load i32, ptr %l57, !tbaa !23
  %t114 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsWritable(ptr %v0, ptr %t111, i32 %t112, i64 %t110)
  store i1 %t114, ptr %l59
  br label %bb32
bb32:
  %t115 = load i1, ptr %l59, !tbaa !21
  store i1 %t115, ptr %rv
  br label %ret
bb33:
  %t116 = load i32, ptr %l3
  %t118 = trunc i64 24 to i32
  %t119 = icmp eq i32 %t116, %t118
  br i1 %t119, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb39
bb36:
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l62, !tbaa !29
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/check:Checker", ptr %t122, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !29
  %t127 = getelementptr %"compiler/generic:Program", ptr %t125, i32 0, i32 2
  %t128 = load i32, ptr %l1, !tbaa !23
  %t131 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t127, i32 %t128)
  store i32 %t131, ptr %l67
  br label %bb37
bb37:
  %t132 = load i64, ptr %l2, !tbaa !24
  %t133 = load ptr, ptr %l62, !tbaa !29
  %t134 = load i32, ptr %l67, !tbaa !23
  %t136 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsWritable(ptr %v0, ptr %t133, i32 %t134, i64 %t132)
  store i1 %t136, ptr %l69
  br label %bb38
bb38:
  %t137 = load i1, ptr %l69, !tbaa !21
  store i1 %t137, ptr %rv
  br label %ret
bb39:
  %t138 = load i32, ptr %l3
  %t140 = trunc i64 18 to i32
  %t141 = icmp eq i32 %t138, %t140
  br i1 %t141, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb63
bb42:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/check:Checker", ptr %t143, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t147 = load i32, ptr %l1, !tbaa !23
  %t150 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t146, i32 %t147)
  store i1 %t150, ptr %l75
  br label %bb43
bb43:
  %t151 = load i1, ptr %l75, !tbaa !21
  %t152 = xor i1 %t151, true
  br i1 %t152, label %bb44, label %bb45
bb44:
  store i1 false, ptr %rv
  br label %ret
bb45:
  br label %bb46
bb46:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load i32, ptr %l1, !tbaa !23
  %t159 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t155, i32 %t156)
  store i32 %t159, ptr %l80
  br label %bb47
bb47:
  %t160 = load i32, ptr %l80
  store i32 %t160, ptr %l4
  %t161 = load i32, ptr %l4
  %t163 = trunc i64 0 to i32
  %t164 = icmp eq i32 %t161, %t163
  br i1 %t164, label %bb48, label %bb49
bb48:
  %t166 = load ptr, ptr %l0, !tbaa !29
  store ptr %t166, ptr %l83, !tbaa !29
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/check:Checker", ptr %t167, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t172 = getelementptr %"compiler/generic:Program", ptr %t170, i32 0, i32 2
  %t173 = load i32, ptr %l1, !tbaa !23
  %t176 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t172, i32 %t173)
  store i32 %t176, ptr %l88
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t177 = load i64, ptr %l2, !tbaa !24
  %t178 = load ptr, ptr %l83, !tbaa !29
  %t179 = load i32, ptr %l88, !tbaa !23
  %t181 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsWritable(ptr %v0, ptr %t178, i32 %t179, i64 %t177)
  store i1 %t181, ptr %l90
  br label %bb51
bb51:
  %t182 = load i1, ptr %l90, !tbaa !21
  store i1 %t182, ptr %rv
  br label %ret
bb52:
  %t183 = load i32, ptr %l4
  %t185 = trunc i64 1 to i32
  %t186 = icmp eq i32 %t183, %t185
  br i1 %t186, label %bb53, label %bb54
bb53:
  %t188 = load ptr, ptr %l0, !tbaa !29
  store ptr %t188, ptr %l93, !tbaa !29
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/check:Checker", ptr %t189, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t194 = getelementptr %"compiler/generic:Program", ptr %t192, i32 0, i32 2
  %t195 = load i32, ptr %l1, !tbaa !23
  %t198 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t194, i32 %t195)
  store i32 %t198, ptr %l98
  br label %bb55
bb54:
  br label %bb57
bb55:
  %t199 = load i64, ptr %l2, !tbaa !24
  %t200 = load ptr, ptr %l93, !tbaa !29
  %t201 = load i32, ptr %l98, !tbaa !23
  %t203 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsWritable(ptr %v0, ptr %t200, i32 %t201, i64 %t199)
  store i1 %t203, ptr %l100
  br label %bb56
bb56:
  %t204 = load i1, ptr %l100, !tbaa !21
  store i1 %t204, ptr %rv
  br label %ret
bb57:
  %t205 = load i32, ptr %l4
  %t207 = trunc i64 4 to i32
  %t208 = icmp eq i32 %t205, %t207
  br i1 %t208, label %bb58, label %bb59
bb58:
  %t210 = load ptr, ptr %l0, !tbaa !29
  store ptr %t210, ptr %l103, !tbaa !29
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/check:Checker", ptr %t211, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t216 = getelementptr %"compiler/generic:Program", ptr %t214, i32 0, i32 2
  %t217 = load i32, ptr %l1, !tbaa !23
  %t220 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t216, i32 %t217)
  store i32 %t220, ptr %l108
  br label %bb60
bb59:
  br label %bb62
bb60:
  %t221 = load i64, ptr %l2, !tbaa !24
  %t223 = add i64 %t221, 1
  %t224 = load ptr, ptr %l103, !tbaa !29
  %t225 = load i32, ptr %l108, !tbaa !23
  %t227 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritableAt(ptr %v0, ptr %t224, i32 %t225, i64 %t223)
  store i1 %t227, ptr %l111
  br label %bb61
bb61:
  %t228 = load i1, ptr %l111, !tbaa !21
  store i1 %t228, ptr %rv
  br label %ret
bb62:
  store i1 false, ptr %rv
  br label %ret
bb63:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %a0) #0 {
entry:
  %l4 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t6, { i64, ptr } { i64 3, ptr @.d16 })
  store i32 %t8, ptr %l4
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t9 = load i32, ptr %l4, !tbaa !23
  store i32 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i64
  %l10 = alloca i64
  %l16 = alloca ptr
  %l19 = alloca i1
  %l25 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca { i64, ptr }
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l7, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 11
  %t10 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l10
  br label %bb3
bb3:
  %t11 = load i64, ptr %l7, !tbaa !24
  %t12 = load i64, ptr %l10, !tbaa !24
  %t13 = icmp sge i64 %t11, %t12
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l6, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 11
  %t20 = load i64, ptr %l1, !tbaa !24
  %t23 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t19, i64 %t20)
  store ptr %t23, ptr %l16
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l16, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Body", ptr %t24, i32 0, i32 1
  %t27 = load { i64, [2 x i64] }, ptr %t26
  store { i64, [2 x i64] } %t27, ptr %l2
  %t29 = load { i64, [2 x i64] }, ptr %l2
  %t31 = extractvalue { i64, [2 x i64] } %t29, 0
  %t32 = icmp eq i64 %t31, 0
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t34 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t35 = getelementptr { i64 }, ptr %t34, i32 0, i32 0
  %t36 = load i64, ptr %t35
  store i64 %t36, ptr %l3, !tbaa !24
  br label %bb11
bb10:
  br label %bb14
bb11:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 2
  store ptr %t43, ptr %l25, !tbaa !29
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t48 = load i64, ptr %l3, !tbaa !24
  %t51 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t47, i64 %t48)
  store i32 %t51, ptr %l29
  br label %bb12
bb12:
  %t52 = load ptr, ptr %l25, !tbaa !29
  %t53 = load i32, ptr %l29, !tbaa !23
  %t54 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t52, i32 %t53)
  store { i64, ptr } %t54, ptr %l30
  br label %bb13
bb13:
  %t55 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 0
  %t58 = icmp sgt i64 %t56, 0
  store i1 %t58, ptr %l19, !tbaa !21
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_9109cadfb541186e_2a46ab96c2b41f0a)
  unreachable
bb19:
  %t60 = load i1, ptr %l19, !tbaa !21
  store i1 %t60, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesIn(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i1
  %l9 = alloca i1
  %l18 = alloca i32
  %l25 = alloca i32
  %l32 = alloca i1
  %l33 = alloca i1
  %l37 = alloca i1
  %l38 = alloca i32
  %l43 = alloca i1
  %l45 = alloca i1
  %l50 = alloca i1
  %l51 = alloca ptr
  %l56 = alloca i32
  %l57 = alloca i64
  %l60 = alloca i1
  %l68 = alloca ptr
  %l73 = alloca i32
  %l77 = alloca i1
  %l80 = alloca ptr
  %l85 = alloca i32
  %l89 = alloca i1
  %l92 = alloca ptr
  %l97 = alloca i32
  %l100 = alloca i1
  %l103 = alloca ptr
  %l108 = alloca i32
  %l112 = alloca i1
  %l117 = alloca ptr
  %l122 = alloca i32
  %l125 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp sgt i64 %t1, 32
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t5, %t6
  store i1 %t9, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l9, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l18
  br label %bb7
bb7:
  %t23 = load i32, ptr %l18
  store i32 %t23, ptr %l4
  %t24 = load i32, ptr %l4
  %t26 = trunc i64 18 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb35
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t35 = load i32, ptr %l1, !tbaa !23
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t38, ptr %l25
  br label %bb11
bb11:
  %t39 = load i32, ptr %l25, !tbaa !23
  store i32 %t39, ptr %l5, !tbaa !23
  %t40 = load i32, ptr %l5, !tbaa !23
  %t42 = icmp eq i32 %t40, 0
  br i1 %t42, label %bb12, label %bb13
bb12:
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 54
  %t48 = load i32, ptr %l1, !tbaa !23
  %t51 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_Hb3133f486435530b533aaf49461c92b5(ptr %v0, ptr %t47, i32 %t48)
  store i1 %t51, ptr %l32
  br label %bb15
bb15:
  %t52 = load i1, ptr %l32, !tbaa !21
  br i1 %t52, label %bb16, label %bb17
bb16:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 54
  %t56 = load i32, ptr %l1, !tbaa !23
  %t59 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H257d83b06934604763b32ef91c51c1d2(ptr %v0, ptr %t55, i32 %t56)
  %t60 = extractvalue { i32, i1 } %t59, 1
  %t61 = extractvalue { i32, i1 } %t59, 0
  store i32 %t61, ptr %l38
  %t62 = icmp ne i32 %t61, 0
  br i1 %t62, label %bb19, label %ok.63
ok.63:
  store i1 %t60, ptr %l37
  br label %bb18
bb17:
  br label %bb22
bb18:
  %t64 = load i1, ptr %l37, !tbaa !21
  store i1 %t64, ptr %l33, !tbaa !21
  br label %bb21
bb19:
  br label %bb20
bb20:
  call void @__olang_ert_req_clear()
  store i1 true, ptr %l33, !tbaa !21
  br label %bb21
bb21:
  %t65 = load i1, ptr %l33, !tbaa !21
  store i1 %t65, ptr %rv
  br label %ret
bb22:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i32, ptr %l5, !tbaa !23
  %t68 = load %"compiler/source:Span", ptr %l2
  %t69 = load i64, ptr %l3, !tbaa !24
  %t74 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistMet(ptr %v0, ptr %t66, i32 %t67, %"compiler/source:Span" %t68, i64 %t69)
  store i1 %t74, ptr %l43
  br label %bb23
bb23:
  %t75 = load i1, ptr %l43, !tbaa !21
  store i1 %t75, ptr %l6, !tbaa !21
  %t76 = load i1, ptr %l6, !tbaa !21
  br i1 %t76, label %bb24, label %bb25
bb24:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/check:Checker", ptr %t78, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t83 = getelementptr %"compiler/generic:Program", ptr %t81, i32 0, i32 2
  %t84 = load i32, ptr %l1, !tbaa !23
  %t87 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t83, i32 %t84)
  store i1 %t87, ptr %l50
  br label %bb26
bb25:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb27
bb26:
  %t88 = load i1, ptr %l50, !tbaa !21
  store i1 %t88, ptr %l45, !tbaa !21
  br label %bb27
bb27:
  %t89 = load i1, ptr %l45, !tbaa !21
  br i1 %t89, label %bb28, label %bb29
bb28:
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l51, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/check:Checker", ptr %t91, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = getelementptr %"compiler/generic:Program", ptr %t94, i32 0, i32 2
  %t97 = load i32, ptr %l1, !tbaa !23
  %t100 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t96, i32 %t97)
  store i32 %t100, ptr %l56
  br label %bb30
bb29:
  br label %bb33
bb30:
  %t101 = load i32, ptr %l56, !tbaa !23
  %t102 = call i64 @compiler_2fgeneric_2eDeclOwner(i32 %t101)
  store i64 %t102, ptr %l57
  br label %bb31
bb31:
  %t103 = load i32, ptr %l5, !tbaa !23
  %t104 = load %"compiler/source:Span", ptr %l2
  %t105 = load ptr, ptr %l51, !tbaa !29
  %t106 = load i64, ptr %l57, !tbaa !24
  %t109 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebound(ptr %v0, ptr %t105, i64 %t106, i32 %t103, %"compiler/source:Span" %t104)
  store i1 %t109, ptr %l60
  br label %bb32
bb32:
  %t110 = load i1, ptr %l60, !tbaa !21
  store i1 %t110, ptr %l6, !tbaa !21
  br label %bb33
bb33:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/check:Checker", ptr %t111, i32 0, i32 54
  %t114 = load i32, ptr %l1, !tbaa !23
  %t115 = load i1, ptr %l6, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H64d9be73b6c9bed004c541bdf7f0ca0a(ptr %v0, ptr %t113, i32 %t114, i1 %t115)
  br label %bb34
bb34:
  %t119 = load i1, ptr %l6, !tbaa !21
  store i1 %t119, ptr %rv
  br label %ret
bb35:
  %t121 = load i32, ptr %l4
  %t123 = trunc i64 20 to i32
  %t124 = icmp eq i32 %t121, %t123
  br i1 %t124, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb41
bb38:
  %t126 = load ptr, ptr %l0, !tbaa !29
  store ptr %t126, ptr %l68, !tbaa !29
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/check:Checker", ptr %t127, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t132 = getelementptr %"compiler/generic:Program", ptr %t130, i32 0, i32 2
  %t133 = load i32, ptr %l1, !tbaa !23
  %t136 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t132, i32 %t133)
  store i32 %t136, ptr %l73
  br label %bb39
bb39:
  %t137 = load %"compiler/source:Span", ptr %l2
  %t138 = load i64, ptr %l3, !tbaa !24
  %t140 = add i64 %t138, 1
  %t141 = load ptr, ptr %l68, !tbaa !29
  %t142 = load i32, ptr %l73, !tbaa !23
  %t145 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesIn(ptr %v0, ptr %t141, i32 %t142, %"compiler/source:Span" %t137, i64 %t140)
  store i1 %t145, ptr %l77
  br label %bb40
bb40:
  %t146 = load i1, ptr %l77, !tbaa !21
  store i1 %t146, ptr %rv
  br label %ret
bb41:
  %t147 = load i32, ptr %l4
  %t149 = trunc i64 19 to i32
  %t150 = icmp eq i32 %t147, %t149
  br i1 %t150, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb47
bb44:
  %t152 = load ptr, ptr %l0, !tbaa !29
  store ptr %t152, ptr %l80, !tbaa !29
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/check:Checker", ptr %t153, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !29
  %t158 = getelementptr %"compiler/generic:Program", ptr %t156, i32 0, i32 2
  %t159 = load i32, ptr %l1, !tbaa !23
  %t162 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t158, i32 %t159)
  store i32 %t162, ptr %l85
  br label %bb45
bb45:
  %t163 = load %"compiler/source:Span", ptr %l2
  %t164 = load i64, ptr %l3, !tbaa !24
  %t166 = add i64 %t164, 1
  %t167 = load ptr, ptr %l80, !tbaa !29
  %t168 = load i32, ptr %l85, !tbaa !23
  %t171 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesIn(ptr %v0, ptr %t167, i32 %t168, %"compiler/source:Span" %t163, i64 %t166)
  store i1 %t171, ptr %l89
  br label %bb46
bb46:
  %t172 = load i1, ptr %l89, !tbaa !21
  store i1 %t172, ptr %rv
  br label %ret
bb47:
  %t173 = load i32, ptr %l4
  %t175 = trunc i64 21 to i32
  %t176 = icmp eq i32 %t173, %t175
  br i1 %t176, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb58
bb50:
  %t178 = load ptr, ptr %l0, !tbaa !29
  store ptr %t178, ptr %l92, !tbaa !29
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/check:Checker", ptr %t179, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t184 = getelementptr %"compiler/generic:Program", ptr %t182, i32 0, i32 2
  %t185 = load i32, ptr %l1, !tbaa !23
  %t188 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t184, i32 %t185)
  store i32 %t188, ptr %l97
  br label %bb51
bb51:
  %t189 = load %"compiler/source:Span", ptr %l2
  %t190 = load i64, ptr %l3, !tbaa !24
  %t191 = load ptr, ptr %l92, !tbaa !29
  %t192 = load i32, ptr %l97, !tbaa !23
  %t195 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistMet(ptr %v0, ptr %t191, i32 %t192, %"compiler/source:Span" %t189, i64 %t190)
  store i1 %t195, ptr %l100
  br label %bb52
bb52:
  %t196 = load i1, ptr %l100, !tbaa !21
  %t197 = xor i1 %t196, true
  br i1 %t197, label %bb53, label %bb54
bb53:
  store i1 false, ptr %rv
  br label %ret
bb54:
  br label %bb55
bb55:
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l103, !tbaa !29
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"compiler/check:Checker", ptr %t201, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !29
  %t206 = getelementptr %"compiler/generic:Program", ptr %t204, i32 0, i32 2
  %t207 = load i32, ptr %l1, !tbaa !23
  %t210 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t206, i32 %t207)
  store i32 %t210, ptr %l108
  br label %bb56
bb56:
  %t211 = load %"compiler/source:Span", ptr %l2
  %t212 = load i64, ptr %l3, !tbaa !24
  %t214 = add i64 %t212, 1
  %t215 = load ptr, ptr %l103, !tbaa !29
  %t216 = load i32, ptr %l108, !tbaa !23
  %t219 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesIn(ptr %v0, ptr %t215, i32 %t216, %"compiler/source:Span" %t211, i64 %t214)
  store i1 %t219, ptr %l112
  br label %bb57
bb57:
  %t220 = load i1, ptr %l112, !tbaa !21
  store i1 %t220, ptr %rv
  br label %ret
bb58:
  %t221 = load i32, ptr %l4
  %t223 = trunc i64 22 to i32
  %t224 = icmp eq i32 %t221, %t223
  br i1 %t224, label %bb59, label %bb60
bb59:
  br label %bb63
bb60:
  %t226 = load i32, ptr %l4
  %t228 = trunc i64 23 to i32
  %t229 = icmp eq i32 %t226, %t228
  br i1 %t229, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb66
bb63:
  %t231 = load ptr, ptr %l0, !tbaa !29
  store ptr %t231, ptr %l117, !tbaa !29
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr %"compiler/check:Checker", ptr %t232, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !29
  %t237 = getelementptr %"compiler/generic:Program", ptr %t235, i32 0, i32 2
  %t238 = load i32, ptr %l1, !tbaa !23
  %t241 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t237, i32 %t238)
  store i32 %t241, ptr %l122
  br label %bb64
bb64:
  %t242 = load %"compiler/source:Span", ptr %l2
  %t243 = load i64, ptr %l3, !tbaa !24
  %t244 = load ptr, ptr %l117, !tbaa !29
  %t245 = load i32, ptr %l122, !tbaa !23
  %t248 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistMet(ptr %v0, ptr %t244, i32 %t245, %"compiler/source:Span" %t242, i64 %t243)
  store i1 %t248, ptr %l125
  br label %bb65
bb65:
  %t249 = load i1, ptr %l125, !tbaa !21
  store i1 %t249, ptr %rv
  br label %ret
bb66:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l5 = alloca i1
  %l8 = alloca i32
  %l11 = alloca i1
  %l15 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l8
  br label %bb4
bb3:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb5
bb4:
  %t12 = load i32, ptr %l8
  %t14 = trunc i64 0 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l5, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t22 = load i32, ptr %l1, !tbaa !23
  %t25 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t21, i32 %t22)
  store i1 %t25, ptr %l15
  br label %bb8
bb7:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb9
bb8:
  %t26 = load i1, ptr %l15, !tbaa !21
  store i1 %t26, ptr %l11, !tbaa !21
  br label %bb9
bb9:
  %t27 = load i1, ptr %l11, !tbaa !21
  store i1 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elambda(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca ptr
  %l18 = alloca i1
  %l19 = alloca i32
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i32
  %l28 = alloca i1
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca ptr
  %l42 = alloca i32
  %lp43 = alloca ptr
  %l48 = alloca ptr
  %l51 = alloca %"compiler/source:Span"
  %l52 = alloca %"compiler/msgs:Msg"
  %l53 = alloca i64
  %l56 = alloca ptr
  %l60 = alloca i1
  %l65 = alloca i32
  %l68 = alloca i32
  %l79 = alloca { i64, ptr }
  %l82 = alloca ptr
  %l87 = alloca i32
  %l88 = alloca { i64, ptr }
  %l95 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca %"compiler/source:Span"
  %l104 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l107 = alloca i64
  %l111 = alloca { i64, ptr }
  %l113 = alloca %"compiler/msgs:Msg"
  %l114 = alloca i64
  %l117 = alloca ptr
  %l118 = alloca i64
  %l126 = alloca i64
  %l129 = alloca i64
  %l147 = alloca { i64, ptr }
  %l153 = alloca i64
  %l155 = alloca { i64, ptr }
  %l159 = alloca i32
  %l163 = alloca i1
  %l165 = alloca i1
  %l168 = alloca ptr
  %l172 = alloca i32
  %l173 = alloca i32
  %l176 = alloca i1
  %l178 = alloca { i64, ptr }
  %l182 = alloca i1
  %l184 = alloca { i64, ptr }
  %l187 = alloca i32
  %l188 = alloca { i64, ptr }
  %l191 = alloca i32
  %l193 = alloca { i64, ptr }
  %l197 = alloca { i64, ptr }
  %l201 = alloca %"compiler/source:Span"
  %l202 = alloca ptr
  %l203 = alloca %"compiler/source:Span"
  %l205 = alloca { i64, ptr }
  %l209 = alloca { i64, ptr }
  %l210 = alloca { i64, ptr }
  %l211 = alloca ptr
  %l212 = alloca { i64, ptr }
  %l219 = alloca %"compiler/source:Span"
  %l220 = alloca { i64, ptr }
  %l221 = alloca %"compiler/msgs:Msg"
  %l222 = alloca i64
  %l225 = alloca ptr
  %l229 = alloca i1
  %l231 = alloca { i64, ptr }
  %l234 = alloca i1
  %l236 = alloca i1
  %l242 = alloca { i64, ptr }
  %l245 = alloca i1
  %l250 = alloca i1
  %l252 = alloca { i64, ptr }
  %l255 = alloca i1
  %l257 = alloca i1
  %l260 = alloca ptr
  %l264 = alloca i32
  %l266 = alloca { i64, ptr }
  %l269 = alloca i32
  %l270 = alloca i1
  %l272 = alloca { i64, ptr }
  %l278 = alloca ptr
  %l282 = alloca i1
  %l283 = alloca i1
  %l285 = alloca { i64, ptr }
  %l288 = alloca i1
  %l289 = alloca i1
  %l292 = alloca ptr
  %l296 = alloca i32
  %l298 = alloca { i64, ptr }
  %l301 = alloca i32
  %l302 = alloca i1
  %l303 = alloca i1
  %l309 = alloca i64
  %l315 = alloca ptr
  %l316 = alloca { i64, ptr }
  %l319 = alloca %"compiler/source:Span"
  %l322 = alloca { i64, ptr }
  %l324 = alloca %"compiler/msgs:Msg"
  %l325 = alloca i64
  %l328 = alloca ptr
  %l332 = alloca i1
  %l334 = alloca { i64, ptr }
  %l337 = alloca i1
  %l340 = alloca { i64, ptr }
  %l343 = alloca ptr
  %l344 = alloca { i64, ptr }
  %l347 = alloca %"compiler/source:Span"
  %l349 = alloca { i64, ptr }
  %l353 = alloca { i64, ptr }
  %l355 = alloca %"compiler/msgs:Msg"
  %l356 = alloca i64
  %l359 = alloca ptr
  %l371 = alloca i64
  %l380 = alloca i64
  %l383 = alloca i64
  %l401 = alloca i64
  %l405 = alloca { i64, ptr }
  %l409 = alloca i32
  %l415 = alloca i32
  %l419 = alloca ptr
  %l424 = alloca i32
  %l425 = alloca i32
  %l429 = alloca i1
  %l430 = alloca ptr
  %l435 = alloca i32
  %l436 = alloca i1
  %l442 = alloca i32
  %l447 = alloca i1
  %l453 = alloca i1
  %l461 = alloca ptr
  %l463 = alloca ptr
  %l469 = alloca i32
  %l477 = alloca i32
  %l481 = alloca i32
  %l486 = alloca i32
  %l491 = alloca i32
  %l493 = alloca ptr
  %l496 = alloca i64
  %l498 = alloca ptr
  %l503 = alloca { i64, [2 x i64] }
  %l511 = alloca i32
  %l515 = alloca i64
  %l525 = alloca ptr
  %l536 = alloca ptr
  %l539 = alloca i32
  %l544 = alloca i64
  %l547 = alloca i64
  %l566 = alloca { i64, ptr }
  %l570 = alloca { i64, ptr }
  %l577 = alloca { i64, ptr }
  %l581 = alloca { i64, ptr }
  %l588 = alloca { i64, ptr }
  %l593 = alloca i1
  %l597 = alloca ptr
  %l599 = alloca ptr
  %l601 = alloca ptr
  %l604 = alloca { i64, ptr }
  %l609 = alloca ptr
  %l611 = alloca ptr
  %l623 = alloca ptr
  %l624 = alloca ptr
  %l627 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l629 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l631 = alloca i32
  %l639 = alloca i32
  %l641 = alloca ptr
  %l647 = alloca i1
  %l649 = alloca ptr
  %l653 = alloca i1
  %l656 = alloca i1
  %l658 = alloca ptr
  %l659 = alloca %"compiler/source:Span"
  %l662 = alloca { i64, ptr }
  %l664 = alloca %"compiler/msgs:Msg"
  %l665 = alloca i64
  %l667 = alloca ptr
  %l670 = alloca { i64, ptr }
  %l676 = alloca ptr
  %l677 = alloca i64
  %l680 = alloca { i64, [3 x i64] }
  %l681 = alloca %"compiler/check:roFn"
  %l685 = alloca i32
  %l688 = alloca ptr
  %l689 = alloca i32
  %l694 = alloca i64
  %l695 = alloca i32
  %l698 = alloca ptr
  %l699 = alloca i32
  %l704 = alloca i64
  %l705 = alloca i32
  %l706 = alloca %"compiler/source:Span"
  %l707 = alloca i32
  %l710 = alloca i32
  %l711 = alloca { i64, ptr }
  %l715 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %rv = alloca ptr
  %t1044 = alloca { i64, [2 x i64] }, align 8
  %t1510 = alloca { i64, [4 x i64] }, align 8
  %t1522 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Func", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/ast:Sig", ptr %t4, i32 0, i32 4
  %t7 = load i1, ptr %t6, !tbaa !21
  br i1 %t7, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l48, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load %"compiler/source:Span", ptr %l1
  %t14 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoreturnSpan(ptr %v0, ptr %t10, %"compiler/source:Span" %t11)
  store %"compiler/source:Span" %t14, ptr %l51
  br label %bb3
bb2:
  br label %bb7
bb3:
  %t15 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoreturnHere(ptr %s1, ptr %s1, { i64, ptr } { i64 8, ptr @.d17 })
  store %"compiler/msgs:Msg" %t15, ptr %l52
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l48, !tbaa !29
  %t17 = load %"compiler/source:Span", ptr %l51
  %t18 = load %"compiler/msgs:Msg", ptr %l52
  %t19 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t16, %"compiler/source:Span" %t17, %"compiler/msgs:Msg" %t18)
  store i64 %t19, ptr %l53
  br label %bb5
bb5:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load %"compiler/source:Span", ptr %l1
  %t24 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t20, %"compiler/source:Span" %t21)
  store ptr %t24, ptr %l56
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t25 = load ptr, ptr %l56, !tbaa !29
  store ptr %t25, ptr %rv
  br label %ret
bb7:
  %t26 = load i32, ptr %l3, !tbaa !23
  %t27 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t30 = icmp ne i32 %t26, %t27
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  %t38 = load i32, ptr %l3, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l65
  br label %bb10
bb9:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb11
bb10:
  %t42 = load i32, ptr %l65
  %t44 = trunc i64 21 to i32
  %t45 = icmp eq i32 %t42, %t44
  store i1 %t45, ptr %l60, !tbaa !21
  br label %bb11
bb11:
  %t47 = load i1, ptr %l60, !tbaa !21
  br i1 %t47, label %bb12, label %bb13
bb12:
  %t48 = load i32, ptr %l3, !tbaa !23
  store i32 %t48, ptr %l68, !tbaa !23
  br label %bb14
bb13:
  %t50 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t50, ptr %l68, !tbaa !23
  br label %bb14
bb14:
  %t52 = load i32, ptr %l68, !tbaa !23
  store i32 %t52, ptr %l4, !tbaa !23
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t55 = getelementptr %"compiler/ast:Func", ptr %t53, i32 0, i32 3
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = getelementptr %"compiler/ast:Sig", ptr %t56, i32 0, i32 0
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  store { i64, ptr } %t59, ptr %l5, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t61, 0
  store i64 %t63, ptr %l6, !tbaa !24
  %t65 = load i32, ptr %l4, !tbaa !23
  %t66 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t69 = icmp ne i32 %t65, %t66
  br i1 %t69, label %bb15, label %bb16
bb15:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 2
  store ptr %t76, ptr %l82, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/generic:Program", ptr %t80, i32 0, i32 2
  %t83 = load i32, ptr %l4, !tbaa !23
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t82, i32 %t83)
  store i32 %t86, ptr %l87
  br label %bb17
bb16:
  %t87 = icmp sge i64 0, 0
  br i1 %t87, label %bb19, label %bb20
bb17:
  %t89 = load ptr, ptr %l82, !tbaa !29
  %t90 = load i32, ptr %l87, !tbaa !23
  %t91 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t89, i32 %t90)
  store { i64, ptr } %t91, ptr %l88
  br label %bb18
bb18:
  %t92 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t92, ptr %l79, !tbaa !27
  br label %bb23
bb19:
  %t93 = icmp sle i64 0, 2305843009213693951
  br i1 %t93, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_d264b31a2a0953e1_a8a3a5518784125d)
  unreachable
bb21:
  %t95 = mul i64 0, 4
  %t96 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t95)
  %t97 = insertvalue { i64, ptr } undef, i64 0, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t96, 1
  store { i64, ptr } %t98, ptr %l79, !tbaa !27
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_d264b31a2a0953e1_a8a3a5518784125d)
  unreachable
bb23:
  %t100 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t100, ptr %l7, !tbaa !27
  %t101 = load i32, ptr %l4, !tbaa !23
  %t102 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t105 = icmp ne i32 %t101, %t102
  br i1 %t105, label %bb24, label %bb25
bb24:
  %t107 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t107, 0
  %t110 = load i64, ptr %l6, !tbaa !24
  %t113 = icmp ne i64 %t109, %t110
  store i1 %t113, ptr %l95, !tbaa !21
  br label %bb26
bb25:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb26
bb26:
  %t115 = load i1, ptr %l95, !tbaa !21
  br i1 %t115, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s2
  %t116 = load ptr, ptr %l0, !tbaa !29
  store ptr %t116, ptr %l100, !tbaa !29
  %t117 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t117, ptr %l101
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load i32, ptr %l4, !tbaa !23
  %t122 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t118, i32 %t119)
  store { i64, ptr } %t122, ptr %l104
  br label %bb29
bb28:
  br label %bb36
bb29:
  %t123 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  %t125 = extractvalue { i64, ptr } %t123, 1
  %t126 = mul i64 %t124, 1
  %t127 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t126)
  call void @llvm.memcpy.p0.p0.i64(ptr %t127, ptr %t125, i64 %t126, i1 false)
  %t128 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  store { i64, ptr } %t129, ptr %l105, !tbaa !27
  %t130 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t130, 0
  store i64 %t132, ptr %l107, !tbaa !24
  %t133 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t133, 0
  %t137 = icmp eq i64 %t135, 1
  br i1 %t137, label %bb30, label %bb31
bb30:
  store { i64, ptr } { i64 0, ptr @.d18 }, ptr %l111, !tbaa !27
  br label %bb32
bb31:
  store { i64, ptr } { i64 1, ptr @.d19 }, ptr %l111, !tbaa !27
  br label %bb32
bb32:
  %t139 = load i64, ptr %l6, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t141 = load i64, ptr %l107, !tbaa !24
  %t142 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t144 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaArity(ptr %s2, ptr %s2, ptr %s2, { i64, ptr } %t140, i64 %t141, { i64, ptr } %t142, i64 %t139)
  store %"compiler/msgs:Msg" %t144, ptr %l113
  br label %bb33
bb33:
  %t145 = load ptr, ptr %l100, !tbaa !29
  %t146 = load %"compiler/source:Span", ptr %l101
  %t147 = load %"compiler/msgs:Msg", ptr %l113
  %t148 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t145, %"compiler/source:Span" %t146, %"compiler/msgs:Msg" %t147)
  store i64 %t148, ptr %l114
  br label %bb34
bb34:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load %"compiler/source:Span", ptr %l1
  %t153 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t149, %"compiler/source:Span" %t150)
  store ptr %t153, ptr %l117
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t154 = load ptr, ptr %l117, !tbaa !29
  store ptr %t154, ptr %rv
  br label %ret
bb36:
  %t155 = load i64, ptr %l6, !tbaa !24
  store i64 %t155, ptr %l118, !tbaa !24
  %t156 = load i64, ptr %l118, !tbaa !24
  %t157 = icmp sge i64 %t156, 0
  br i1 %t157, label %bb37, label %bb38
bb37:
  %t159 = load i64, ptr %l118, !tbaa !24
  %t160 = icmp sle i64 %t159, 2305843009213693951
  br i1 %t160, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_3e7f35b161741bd4_701c2e32dccd3eb0)
  unreachable
bb39:
  %t162 = load i64, ptr %l118, !tbaa !24
  %t163 = mul i64 %t162, 4
  %t164 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t163)
  %t165 = insertvalue { i64, ptr } undef, i64 %t162, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t164, 1
  store { i64, ptr } %t166, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t168 = load i64, ptr %l6, !tbaa !24
  store i64 %t168, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t170 = load i64, ptr %l10, !tbaa !24
  %t171 = load i64, ptr %l9, !tbaa !24
  %t174 = icmp sgt i64 %t170, %t171
  br i1 %t174, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_3e7f35b161741bd4_701c2e32dccd3eb0)
  unreachable
bb41:
  %t176 = load i64, ptr %l11, !tbaa !24
  %t178 = icmp sgt i64 %t176, 0
  br i1 %t178, label %bb43, label %bb44
bb42:
  store i64 0, ptr %l126, !tbaa !24
  br label %bb46
bb43:
  %t180 = load i64, ptr %l10, !tbaa !24
  %t181 = load i64, ptr %l9, !tbaa !24
  %t184 = sub i64 %t180, %t181
  %t185 = load i64, ptr %l11, !tbaa !24
  %t188 = add i64 %t184, %t185
  %t190 = sub i64 %t188, 1
  %t191 = load i64, ptr %l11, !tbaa !24
  %t194 = sdiv i64 %t190, %t191
  store i64 %t194, ptr %l129, !tbaa !24
  br label %bb45
bb44:
  store i64 0, ptr %l129, !tbaa !24
  br label %bb45
bb45:
  %t196 = load i64, ptr %l129, !tbaa !24
  store i64 %t196, ptr %l126, !tbaa !24
  br label %bb46
bb46:
  %t197 = load i64, ptr %l126, !tbaa !24
  store i64 %t197, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb47
bb47:
  store %olang.scope zeroinitializer, ptr %s4
  %t198 = load i64, ptr %l13, !tbaa !24
  %t199 = load i64, ptr %l12, !tbaa !24
  %t202 = icmp slt i64 %t198, %t199
  %t204 = xor i1 %t202, true
  br i1 %t204, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s4)
  br label %bb137
bb49:
  br label %bb50
bb50:
  %t206 = load i64, ptr %l9, !tbaa !24
  %t207 = load i64, ptr %l13, !tbaa !24
  %t208 = load i64, ptr %l11, !tbaa !24
  %t211 = mul i64 %t207, %t208
  %t214 = add i64 %t206, %t211
  store i64 %t214, ptr %l14, !tbaa !24
  %t216 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t216, ptr %l147, !tbaa !27
  %t217 = load i64, ptr %l14, !tbaa !24
  %t219 = getelementptr { i64, ptr }, ptr %l147, i32 0, i32 1
  %t220 = load ptr, ptr %t219, !tbaa !27
  %t221 = getelementptr ptr, ptr %t220, i64 %t217
  %t222 = load ptr, ptr %t221, !tbaa !39
  %t224 = getelementptr %"compiler/ast:Param", ptr %t222, i32 0, i32 2
  %t225 = load ptr, ptr %t224, !tbaa !29
  %t227 = icmp eq ptr %t225, null
  %t229 = xor i1 %t227, true
  br i1 %t229, label %bb51, label %bb52
bb51:
  %t231 = load i64, ptr %l14, !tbaa !24
  store i64 %t231, ptr %l153, !tbaa !24
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t233, ptr %l155, !tbaa !27
  %t234 = load i64, ptr %l14, !tbaa !24
  %t236 = getelementptr { i64, ptr }, ptr %l155, i32 0, i32 1
  %t237 = load ptr, ptr %t236, !tbaa !27
  %t238 = getelementptr ptr, ptr %t237, i64 %t234
  %t239 = load ptr, ptr %t238, !tbaa !39
  %t241 = getelementptr %"compiler/ast:Param", ptr %t239, i32 0, i32 2
  %t242 = load ptr, ptr %t241, !tbaa !29
  %t245 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %t232, ptr %t242)
  store i32 %t245, ptr %l159
  br label %bb53
bb52:
  %t246 = load i32, ptr %l4, !tbaa !23
  %t247 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t250 = icmp ne i32 %t246, %t247
  br i1 %t250, label %bb124, label %bb125
bb53:
  %t252 = load i32, ptr %l159, !tbaa !23
  %t253 = load i64, ptr %l153, !tbaa !24
  %t254 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t255 = load ptr, ptr %t254, !tbaa !27
  %t256 = getelementptr i32, ptr %t255, i64 %t253
  store i32 %t252, ptr %t256, !tbaa !33
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load i64, ptr %l14, !tbaa !24
  %t260 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t261 = load ptr, ptr %t260, !tbaa !27
  %t262 = getelementptr i32, ptr %t261, i64 %t258
  %t263 = load i32, ptr %t262, !tbaa !33
  %t266 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t257, i32 %t263)
  store i1 %t266, ptr %l163
  br label %bb54
bb54:
  %t267 = load i1, ptr %l163, !tbaa !21
  %t268 = xor i1 %t267, true
  br i1 %t268, label %bb55, label %bb56
bb55:
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t272 = getelementptr %"compiler/check:Checker", ptr %t270, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !29
  %t275 = getelementptr %"compiler/generic:Program", ptr %t273, i32 0, i32 2
  store ptr %t275, ptr %l168, !tbaa !29
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t277 = load i64, ptr %l14, !tbaa !24
  %t279 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t280 = load ptr, ptr %t279, !tbaa !27
  %t281 = getelementptr i32, ptr %t280, i64 %t277
  %t282 = load i32, ptr %t281, !tbaa !33
  %t285 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t276, i32 %t282)
  store i32 %t285, ptr %l172
  br label %bb57
bb56:
  store i1 false, ptr %l165, !tbaa !21
  br label %bb59
bb57:
  %t286 = load ptr, ptr %l168, !tbaa !29
  %t287 = load i32, ptr %l172, !tbaa !23
  %t288 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t286, i32 %t287)
  store i32 %t288, ptr %l173
  br label %bb58
bb58:
  %t289 = load i32, ptr %l173
  %t291 = trunc i64 19 to i32
  %t292 = icmp eq i32 %t289, %t291
  store i1 %t292, ptr %l165, !tbaa !21
  br label %bb59
bb59:
  %t294 = load i1, ptr %l165, !tbaa !21
  br i1 %t294, label %bb60, label %bb61
bb60:
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t296 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t296, ptr %l178, !tbaa !27
  %t297 = load i64, ptr %l14, !tbaa !24
  %t299 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t300 = load ptr, ptr %t299, !tbaa !27
  %t301 = getelementptr ptr, ptr %t300, i64 %t297
  %t302 = load ptr, ptr %t301, !tbaa !39
  %t304 = getelementptr %"compiler/ast:Param", ptr %t302, i32 0, i32 2
  %t305 = load ptr, ptr %t304, !tbaa !29
  %t308 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesTypeVar(ptr %v0, ptr %v1, ptr %t295, ptr %t305)
  store i1 %t308, ptr %l182
  br label %bb62
bb61:
  store i1 false, ptr %l176, !tbaa !21
  br label %bb63
bb62:
  %t309 = load i1, ptr %l182, !tbaa !21
  %t310 = xor i1 %t309, true
  store i1 %t310, ptr %l176, !tbaa !21
  br label %bb63
bb63:
  %t312 = load i1, ptr %l176, !tbaa !21
  br i1 %t312, label %bb64, label %bb65
bb64:
  store %olang.scope zeroinitializer, ptr %s6
  %t313 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t313, ptr %l184, !tbaa !27
  %t314 = load i64, ptr %l14, !tbaa !24
  %t316 = getelementptr { i64, ptr }, ptr %l184, i32 0, i32 1
  %t317 = load ptr, ptr %t316, !tbaa !27
  %t318 = getelementptr ptr, ptr %t317, i64 %t314
  %t319 = load ptr, ptr %t318, !tbaa !39
  %t321 = getelementptr %"compiler/ast:Param", ptr %t319, i32 0, i32 0
  %t322 = getelementptr %"compiler/source:Span", ptr %t321, i32 0, i32 0
  %t323 = load i32, ptr %t322, !tbaa !23
  store i32 %t323, ptr %l187, !tbaa !23
  %t324 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t324, ptr %l188, !tbaa !27
  %t325 = load i64, ptr %l14, !tbaa !24
  %t327 = getelementptr { i64, ptr }, ptr %l188, i32 0, i32 1
  %t328 = load ptr, ptr %t327, !tbaa !27
  %t329 = getelementptr ptr, ptr %t328, i64 %t325
  %t330 = load ptr, ptr %t329, !tbaa !39
  %t332 = getelementptr %"compiler/ast:Param", ptr %t330, i32 0, i32 0
  %t333 = getelementptr %"compiler/source:Span", ptr %t332, i32 0, i32 0
  %t334 = load i32, ptr %t333, !tbaa !23
  store i32 %t334, ptr %l191, !tbaa !23
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t336 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t336, ptr %l193, !tbaa !27
  %t337 = load i64, ptr %l14, !tbaa !24
  %t339 = getelementptr { i64, ptr }, ptr %l193, i32 0, i32 1
  %t340 = load ptr, ptr %t339, !tbaa !27
  %t341 = getelementptr ptr, ptr %t340, i64 %t337
  %t342 = load ptr, ptr %t341, !tbaa !39
  %t344 = getelementptr %"compiler/ast:Param", ptr %t342, i32 0, i32 1
  %t345 = load i32, ptr %t344, !tbaa !23
  %t348 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t335, i32 %t345)
  store { i64, ptr } %t348, ptr %l197
  br label %bb66
bb65:
  br label %bb77
bb66:
  %t349 = load { i64, ptr }, ptr %l197, !tbaa !27
  %t350 = extractvalue { i64, ptr } %t349, 0
  %t352 = trunc i64 %t350 to i32
  %t353 = load i32, ptr %l191, !tbaa !23
  %t355 = add i32 %t353, %t352
  %t356 = load i32, ptr %l187, !tbaa !23
  %t358 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s6, i32 %t356, i32 %t355)
  store %"compiler/source:Span" %t358, ptr %l201
  br label %bb67
bb67:
  %t359 = load %"compiler/source:Span", ptr %l201
  %t360 = load ptr, ptr %l0, !tbaa !29
  store ptr %t360, ptr %l202, !tbaa !29
  store %"compiler/source:Span" %t359, ptr %l203
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t363 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t363, ptr %l205, !tbaa !27
  %t364 = load i64, ptr %l14, !tbaa !24
  %t366 = getelementptr { i64, ptr }, ptr %l205, i32 0, i32 1
  %t367 = load ptr, ptr %t366, !tbaa !27
  %t368 = getelementptr ptr, ptr %t367, i64 %t364
  %t369 = load ptr, ptr %t368, !tbaa !39
  %t371 = getelementptr %"compiler/ast:Param", ptr %t369, i32 0, i32 1
  %t372 = load i32, ptr %t371, !tbaa !23
  %t375 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s6, ptr %t362, i32 %t372)
  store { i64, ptr } %t375, ptr %l209
  br label %bb68
bb68:
  %t376 = load { i64, ptr }, ptr %l209, !tbaa !27
  %t377 = extractvalue { i64, ptr } %t376, 0
  %t378 = extractvalue { i64, ptr } %t376, 1
  %t379 = mul i64 %t377, 1
  %t380 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t379)
  call void @llvm.memcpy.p0.p0.i64(ptr %t380, ptr %t378, i64 %t379, i1 false)
  %t381 = insertvalue { i64, ptr } undef, i64 %t377, 0
  %t382 = insertvalue { i64, ptr } %t381, ptr %t380, 1
  store { i64, ptr } %t382, ptr %l210, !tbaa !27
  %t383 = load ptr, ptr %l0, !tbaa !29
  store ptr %t383, ptr %l211, !tbaa !29
  %t384 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t384, ptr %l212, !tbaa !27
  %t385 = load i64, ptr %l14, !tbaa !24
  %t387 = getelementptr { i64, ptr }, ptr %l212, i32 0, i32 1
  %t388 = load ptr, ptr %t387, !tbaa !27
  %t389 = getelementptr ptr, ptr %t388, i64 %t385
  %t390 = load ptr, ptr %t389, !tbaa !39
  %t392 = getelementptr %"compiler/ast:Param", ptr %t390, i32 0, i32 2
  %t393 = load ptr, ptr %t392, !tbaa !29
  store ptr %t393, ptr %l16, !tbaa !29
  %t395 = load ptr, ptr %l16, !tbaa !29
  %t397 = icmp eq ptr %t395, null
  br i1 %t397, label %bb69, label %bb70
bb69:
  call void @__olang_check_failed(ptr @olang_loc_47d9099855f63e09_256685dd40c0f40d)
  unreachable
bb70:
  br label %bb71
bb71:
  %t399 = load ptr, ptr %l16, !tbaa !29
  %t401 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t399)
  store %"compiler/source:Span" %t401, ptr %l219
  br label %bb72
bb72:
  %t402 = load ptr, ptr %l211, !tbaa !29
  %t403 = load %"compiler/source:Span", ptr %l219
  %t404 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t402, %"compiler/source:Span" %t403)
  store { i64, ptr } %t404, ptr %l220
  br label %bb73
bb73:
  %t405 = load { i64, ptr }, ptr %l210, !tbaa !27
  %t406 = load { i64, ptr }, ptr %l220, !tbaa !27
  %t407 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayParamByValue(ptr %s6, ptr %v0, ptr %s6, { i64, ptr } %t405, { i64, ptr } %t406)
  store %"compiler/msgs:Msg" %t407, ptr %l221
  br label %bb74
bb74:
  %t408 = load ptr, ptr %l202, !tbaa !29
  %t409 = load %"compiler/source:Span", ptr %l203
  %t410 = load %"compiler/msgs:Msg", ptr %l221
  %t411 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t408, %"compiler/source:Span" %t409, %"compiler/msgs:Msg" %t410)
  store i64 %t411, ptr %l222
  br label %bb75
bb75:
  %t412 = load ptr, ptr %l0, !tbaa !29
  %t413 = load %"compiler/source:Span", ptr %l1
  %t416 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t412, %"compiler/source:Span" %t413)
  store ptr %t416, ptr %l225
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t417 = load ptr, ptr %l225, !tbaa !29
  store ptr %t417, ptr %rv
  br label %ret
bb77:
  %t418 = load i32, ptr %l4, !tbaa !23
  %t419 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t422 = icmp ne i32 %t418, %t419
  br i1 %t422, label %bb78, label %bb79
bb78:
  %t424 = load ptr, ptr %l0, !tbaa !29
  %t425 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t425, ptr %l231, !tbaa !27
  %t426 = load i64, ptr %l14, !tbaa !24
  %t428 = getelementptr { i64, ptr }, ptr %l231, i32 0, i32 1
  %t429 = load ptr, ptr %t428, !tbaa !27
  %t430 = getelementptr i32, ptr %t429, i64 %t426
  %t431 = load i32, ptr %t430, !tbaa !33
  %t434 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ementionsVar(ptr %v0, ptr %t424, i32 %t431, i64 -1)
  store i1 %t434, ptr %l234
  br label %bb80
bb79:
  store i1 false, ptr %l229, !tbaa !21
  br label %bb81
bb80:
  %t435 = load i1, ptr %l234, !tbaa !21
  %t436 = xor i1 %t435, true
  store i1 %t436, ptr %l229, !tbaa !21
  br label %bb81
bb81:
  %t438 = load i1, ptr %l229, !tbaa !21
  br i1 %t438, label %bb82, label %bb83
bb82:
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t441 = getelementptr %"compiler/check:Checker", ptr %t439, i32 0, i32 1
  %t442 = load ptr, ptr %t441, !tbaa !29
  %t444 = getelementptr %"compiler/generic:Program", ptr %t442, i32 0, i32 2
  %t445 = load i64, ptr %l14, !tbaa !24
  %t447 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t448 = load ptr, ptr %t447, !tbaa !27
  %t449 = getelementptr i32, ptr %t448, i64 %t445
  %t450 = load i32, ptr %t449, !tbaa !33
  %t451 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t451, ptr %l242, !tbaa !27
  %t452 = load i64, ptr %l14, !tbaa !24
  %t454 = getelementptr { i64, ptr }, ptr %l242, i32 0, i32 1
  %t455 = load ptr, ptr %t454, !tbaa !27
  %t456 = getelementptr i32, ptr %t455, i64 %t452
  %t457 = load i32, ptr %t456, !tbaa !33
  %t461 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t444, i32 %t450, i32 %t457)
  store i1 %t461, ptr %l245
  br label %bb84
bb83:
  store i1 false, ptr %l236, !tbaa !21
  br label %bb85
bb84:
  %t462 = load i1, ptr %l245, !tbaa !21
  %t463 = xor i1 %t462, true
  store i1 %t463, ptr %l236, !tbaa !21
  br label %bb85
bb85:
  %t465 = load i1, ptr %l236, !tbaa !21
  br i1 %t465, label %bb86, label %bb87
bb86:
  %t466 = load ptr, ptr %l0, !tbaa !29
  %t467 = load i64, ptr %l14, !tbaa !24
  %t469 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t470 = load ptr, ptr %t469, !tbaa !27
  %t471 = getelementptr i32, ptr %t470, i64 %t467
  %t472 = load i32, ptr %t471, !tbaa !33
  %t475 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t466, i32 %t472)
  store i1 %t475, ptr %l250
  br label %bb88
bb87:
  br label %bb123
bb88:
  %t476 = load ptr, ptr %l0, !tbaa !29
  %t477 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t477, ptr %l252, !tbaa !27
  %t478 = load i64, ptr %l14, !tbaa !24
  %t480 = getelementptr { i64, ptr }, ptr %l252, i32 0, i32 1
  %t481 = load ptr, ptr %t480, !tbaa !27
  %t482 = getelementptr i32, ptr %t481, i64 %t478
  %t483 = load i32, ptr %t482, !tbaa !33
  %t486 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t476, i32 %t483)
  store i1 %t486, ptr %l255
  br label %bb89
bb89:
  %t487 = load i1, ptr %l250, !tbaa !21
  %t488 = load i1, ptr %l255, !tbaa !21
  %t489 = icmp ne i1 %t487, %t488
  br i1 %t489, label %bb90, label %bb91
bb90:
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t493 = getelementptr %"compiler/check:Checker", ptr %t491, i32 0, i32 1
  %t494 = load ptr, ptr %t493, !tbaa !29
  %t496 = getelementptr %"compiler/generic:Program", ptr %t494, i32 0, i32 2
  store ptr %t496, ptr %l260, !tbaa !29
  %t497 = load ptr, ptr %l0, !tbaa !29
  %t498 = load i64, ptr %l14, !tbaa !24
  %t500 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t501 = load ptr, ptr %t500, !tbaa !27
  %t502 = getelementptr i32, ptr %t501, i64 %t498
  %t503 = load i32, ptr %t502, !tbaa !33
  %t506 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t497, i32 %t503)
  store i32 %t506, ptr %l264
  br label %bb92
bb91:
  store i1 false, ptr %l257, !tbaa !21
  br label %bb95
bb92:
  %t507 = load ptr, ptr %l0, !tbaa !29
  %t508 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t508, ptr %l266, !tbaa !27
  %t509 = load i64, ptr %l14, !tbaa !24
  %t511 = getelementptr { i64, ptr }, ptr %l266, i32 0, i32 1
  %t512 = load ptr, ptr %t511, !tbaa !27
  %t513 = getelementptr i32, ptr %t512, i64 %t509
  %t514 = load i32, ptr %t513, !tbaa !33
  %t517 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t507, i32 %t514)
  store i32 %t517, ptr %l269
  br label %bb93
bb93:
  %t518 = load ptr, ptr %l260, !tbaa !29
  %t519 = load i32, ptr %l264, !tbaa !23
  %t520 = load i32, ptr %l269, !tbaa !23
  %t521 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t518, i32 %t519, i32 %t520)
  store i1 %t521, ptr %l270
  br label %bb94
bb94:
  %t522 = load i1, ptr %l270, !tbaa !21
  store i1 %t522, ptr %l257, !tbaa !21
  br label %bb95
bb95:
  %t523 = load i1, ptr %l257, !tbaa !21
  br i1 %t523, label %bb96, label %bb97
bb96:
  store %olang.scope zeroinitializer, ptr %s8
  %t524 = load ptr, ptr %l0, !tbaa !29
  %t525 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t525, ptr %l272, !tbaa !27
  %t526 = load i64, ptr %l14, !tbaa !24
  %t528 = getelementptr { i64, ptr }, ptr %l272, i32 0, i32 1
  %t529 = load ptr, ptr %t528, !tbaa !27
  %t530 = getelementptr ptr, ptr %t529, i64 %t526
  %t531 = load ptr, ptr %t530, !tbaa !39
  %t533 = getelementptr %"compiler/ast:Param", ptr %t531, i32 0, i32 0
  %t534 = load %"compiler/source:Span", ptr %t533
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s8, ptr %t524, %"compiler/source:Span" %t534, { i64, ptr } { i64 74, ptr @.d20 })
  br label %bb98
bb97:
  br label %bb100
bb98:
  %t537 = load ptr, ptr %l0, !tbaa !29
  %t538 = load %"compiler/source:Span", ptr %l1
  %t541 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t537, %"compiler/source:Span" %t538)
  store ptr %t541, ptr %l278
  br label %bb99
bb99:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t542 = load ptr, ptr %l278, !tbaa !29
  store ptr %t542, ptr %rv
  br label %ret
bb100:
  %t543 = load ptr, ptr %l0, !tbaa !29
  %t544 = load i64, ptr %l14, !tbaa !24
  %t546 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t547 = load ptr, ptr %t546, !tbaa !27
  %t548 = getelementptr i32, ptr %t547, i64 %t544
  %t549 = load i32, ptr %t548, !tbaa !33
  %t552 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t543, i32 %t549)
  store i1 %t552, ptr %l282
  br label %bb101
bb101:
  %t553 = load i1, ptr %l282, !tbaa !21
  br i1 %t553, label %bb102, label %bb103
bb102:
  %t554 = load ptr, ptr %l0, !tbaa !29
  %t555 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t555, ptr %l285, !tbaa !27
  %t556 = load i64, ptr %l14, !tbaa !24
  %t558 = getelementptr { i64, ptr }, ptr %l285, i32 0, i32 1
  %t559 = load ptr, ptr %t558, !tbaa !27
  %t560 = getelementptr i32, ptr %t559, i64 %t556
  %t561 = load i32, ptr %t560, !tbaa !33
  %t564 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t554, i32 %t561)
  store i1 %t564, ptr %l288
  br label %bb104
bb103:
  store i1 false, ptr %l283, !tbaa !21
  br label %bb105
bb104:
  %t565 = load i1, ptr %l288, !tbaa !21
  store i1 %t565, ptr %l283, !tbaa !21
  br label %bb105
bb105:
  %t566 = load i1, ptr %l283, !tbaa !21
  br i1 %t566, label %bb106, label %bb107
bb106:
  %t567 = load ptr, ptr %l0, !tbaa !29
  %t569 = getelementptr %"compiler/check:Checker", ptr %t567, i32 0, i32 1
  %t570 = load ptr, ptr %t569, !tbaa !29
  %t572 = getelementptr %"compiler/generic:Program", ptr %t570, i32 0, i32 2
  store ptr %t572, ptr %l292, !tbaa !29
  %t573 = load ptr, ptr %l0, !tbaa !29
  %t574 = load i64, ptr %l14, !tbaa !24
  %t576 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t577 = load ptr, ptr %t576, !tbaa !27
  %t578 = getelementptr i32, ptr %t577, i64 %t574
  %t579 = load i32, ptr %t578, !tbaa !33
  %t582 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t573, i32 %t579)
  store i32 %t582, ptr %l296
  br label %bb108
bb107:
  store i1 false, ptr %l289, !tbaa !21
  br label %bb111
bb108:
  %t583 = load ptr, ptr %l0, !tbaa !29
  %t584 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t584, ptr %l298, !tbaa !27
  %t585 = load i64, ptr %l14, !tbaa !24
  %t587 = getelementptr { i64, ptr }, ptr %l298, i32 0, i32 1
  %t588 = load ptr, ptr %t587, !tbaa !27
  %t589 = getelementptr i32, ptr %t588, i64 %t585
  %t590 = load i32, ptr %t589, !tbaa !33
  %t593 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t583, i32 %t590)
  store i32 %t593, ptr %l301
  br label %bb109
bb109:
  %t594 = load ptr, ptr %l292, !tbaa !29
  %t595 = load i32, ptr %l296, !tbaa !23
  %t596 = load i32, ptr %l301, !tbaa !23
  %t597 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t594, i32 %t595, i32 %t596)
  store i1 %t597, ptr %l302
  br label %bb110
bb110:
  %t598 = load i1, ptr %l302, !tbaa !21
  store i1 %t598, ptr %l289, !tbaa !21
  br label %bb111
bb111:
  %t599 = load i1, ptr %l289, !tbaa !21
  br i1 %t599, label %bb112, label %bb113
bb112:
  %t600 = load ptr, ptr %l0, !tbaa !29
  %t602 = getelementptr %"compiler/check:Checker", ptr %t600, i32 0, i32 1
  %t603 = load ptr, ptr %t602, !tbaa !29
  %t605 = getelementptr %"compiler/generic:Program", ptr %t603, i32 0, i32 2
  %t606 = load i64, ptr %l14, !tbaa !24
  %t608 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t609 = load ptr, ptr %t608, !tbaa !27
  %t610 = getelementptr i32, ptr %t609, i64 %t606
  %t611 = load i32, ptr %t610, !tbaa !33
  %t614 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t605, i32 %t611)
  store i64 %t614, ptr %l309
  br label %bb114
bb113:
  store i1 false, ptr %l303, !tbaa !21
  br label %bb115
bb114:
  %t615 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t616 = load i64, ptr %l309, !tbaa !24
  %t618 = and i64 %t616, %t615
  %t620 = icmp eq i64 %t618, 0
  store i1 %t620, ptr %l303, !tbaa !21
  br label %bb115
bb115:
  %t622 = load i1, ptr %l303, !tbaa !21
  %t625 = xor i1 %t622, true
  br i1 %t625, label %bb116, label %bb117
bb116:
  store %olang.scope zeroinitializer, ptr %s9
  %t627 = load ptr, ptr %l0, !tbaa !29
  store ptr %t627, ptr %l315, !tbaa !29
  %t628 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t628, ptr %l316, !tbaa !27
  %t629 = load i64, ptr %l14, !tbaa !24
  %t631 = getelementptr { i64, ptr }, ptr %l316, i32 0, i32 1
  %t632 = load ptr, ptr %t631, !tbaa !27
  %t633 = getelementptr ptr, ptr %t632, i64 %t629
  %t634 = load ptr, ptr %t633, !tbaa !39
  %t636 = getelementptr %"compiler/ast:Param", ptr %t634, i32 0, i32 0
  %t637 = load %"compiler/source:Span", ptr %t636
  store %"compiler/source:Span" %t637, ptr %l319
  %t638 = load ptr, ptr %l0, !tbaa !29
  %t639 = load i32, ptr %l4, !tbaa !23
  %t642 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t638, i32 %t639)
  store { i64, ptr } %t642, ptr %l322
  br label %bb118
bb117:
  br label %bb122
bb118:
  %t643 = load { i64, ptr }, ptr %l322, !tbaa !27
  %t644 = extractvalue { i64, ptr } %t643, 0
  %t645 = extractvalue { i64, ptr } %t643, 1
  %t646 = mul i64 %t644, 1
  %t647 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t646)
  call void @llvm.memcpy.p0.p0.i64(ptr %t647, ptr %t645, i64 %t646, i1 false)
  %t648 = insertvalue { i64, ptr } undef, i64 %t644, 0
  %t649 = insertvalue { i64, ptr } %t648, ptr %t647, 1
  %t651 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaSignature(ptr %s9, ptr %s9, { i64, ptr } %t649)
  store %"compiler/msgs:Msg" %t651, ptr %l324
  br label %bb119
bb119:
  %t652 = load ptr, ptr %l315, !tbaa !29
  %t653 = load %"compiler/source:Span", ptr %l319
  %t654 = load %"compiler/msgs:Msg", ptr %l324
  %t655 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s9, ptr %t652, %"compiler/source:Span" %t653, %"compiler/msgs:Msg" %t654)
  store i64 %t655, ptr %l325
  br label %bb120
bb120:
  %t656 = load ptr, ptr %l0, !tbaa !29
  %t657 = load %"compiler/source:Span", ptr %l1
  %t660 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t656, %"compiler/source:Span" %t657)
  store ptr %t660, ptr %l328
  br label %bb121
bb121:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t661 = load ptr, ptr %l328, !tbaa !29
  store ptr %t661, ptr %rv
  br label %ret
bb122:
  br label %bb123
bb123:
  br label %bb135
bb124:
  %t662 = load ptr, ptr %l0, !tbaa !29
  %t663 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t663, ptr %l334, !tbaa !27
  %t664 = load i64, ptr %l14, !tbaa !24
  %t666 = getelementptr { i64, ptr }, ptr %l334, i32 0, i32 1
  %t667 = load ptr, ptr %t666, !tbaa !27
  %t668 = getelementptr i32, ptr %t667, i64 %t664
  %t669 = load i32, ptr %t668, !tbaa !33
  %t672 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ementionsVar(ptr %v0, ptr %t662, i32 %t669, i64 -1)
  store i1 %t672, ptr %l337
  br label %bb126
bb125:
  store i1 false, ptr %l332, !tbaa !21
  br label %bb127
bb126:
  %t673 = load i1, ptr %l337, !tbaa !21
  %t674 = xor i1 %t673, true
  store i1 %t674, ptr %l332, !tbaa !21
  br label %bb127
bb127:
  %t676 = load i1, ptr %l332, !tbaa !21
  br i1 %t676, label %bb128, label %bb129
bb128:
  %t677 = load i64, ptr %l14, !tbaa !24
  %t678 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t678, ptr %l340, !tbaa !27
  %t679 = load i64, ptr %l14, !tbaa !24
  %t681 = getelementptr { i64, ptr }, ptr %l340, i32 0, i32 1
  %t682 = load ptr, ptr %t681, !tbaa !27
  %t683 = getelementptr i32, ptr %t682, i64 %t679
  %t684 = load i32, ptr %t683, !tbaa !33
  %t687 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t688 = load ptr, ptr %t687, !tbaa !27
  %t689 = getelementptr i32, ptr %t688, i64 %t677
  store i32 %t684, ptr %t689, !tbaa !33
  br label %bb134
bb129:
  store %olang.scope zeroinitializer, ptr %s12
  %t690 = load ptr, ptr %l0, !tbaa !29
  store ptr %t690, ptr %l343, !tbaa !29
  %t691 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t691, ptr %l344, !tbaa !27
  %t692 = load i64, ptr %l14, !tbaa !24
  %t694 = getelementptr { i64, ptr }, ptr %l344, i32 0, i32 1
  %t695 = load ptr, ptr %t694, !tbaa !27
  %t696 = getelementptr ptr, ptr %t695, i64 %t692
  %t697 = load ptr, ptr %t696, !tbaa !39
  %t699 = getelementptr %"compiler/ast:Param", ptr %t697, i32 0, i32 0
  %t700 = load %"compiler/source:Span", ptr %t699
  store %"compiler/source:Span" %t700, ptr %l347
  %t701 = load ptr, ptr %l0, !tbaa !29
  %t702 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t702, ptr %l349, !tbaa !27
  %t703 = load i64, ptr %l14, !tbaa !24
  %t705 = getelementptr { i64, ptr }, ptr %l349, i32 0, i32 1
  %t706 = load ptr, ptr %t705, !tbaa !27
  %t707 = getelementptr ptr, ptr %t706, i64 %t703
  %t708 = load ptr, ptr %t707, !tbaa !39
  %t710 = getelementptr %"compiler/ast:Param", ptr %t708, i32 0, i32 1
  %t711 = load i32, ptr %t710, !tbaa !23
  %t714 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s12, ptr %t701, i32 %t711)
  store { i64, ptr } %t714, ptr %l353
  br label %bb130
bb130:
  %t715 = load { i64, ptr }, ptr %l353, !tbaa !27
  %t716 = extractvalue { i64, ptr } %t715, 0
  %t717 = extractvalue { i64, ptr } %t715, 1
  %t718 = mul i64 %t716, 1
  %t719 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t718)
  call void @llvm.memcpy.p0.p0.i64(ptr %t719, ptr %t717, i64 %t718, i1 false)
  %t720 = insertvalue { i64, ptr } undef, i64 %t716, 0
  %t721 = insertvalue { i64, ptr } %t720, ptr %t719, 1
  %t723 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaParamUntyped(ptr %s12, ptr %s12, { i64, ptr } %t721)
  store %"compiler/msgs:Msg" %t723, ptr %l355
  br label %bb131
bb131:
  %t724 = load ptr, ptr %l343, !tbaa !29
  %t725 = load %"compiler/source:Span", ptr %l347
  %t726 = load %"compiler/msgs:Msg", ptr %l355
  %t727 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s12, ptr %t724, %"compiler/source:Span" %t725, %"compiler/msgs:Msg" %t726)
  store i64 %t727, ptr %l356
  br label %bb132
bb132:
  %t728 = load ptr, ptr %l0, !tbaa !29
  %t729 = load %"compiler/source:Span", ptr %l1
  %t732 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t728, %"compiler/source:Span" %t729)
  store ptr %t732, ptr %l359
  br label %bb133
bb133:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t733 = load ptr, ptr %l359, !tbaa !29
  store ptr %t733, ptr %rv
  br label %ret
bb134:
  br label %bb135
bb135:
  call void @__olang_scope_close(ptr %s4)
  br label %bb136
bb136:
  %t734 = load i64, ptr %l13, !tbaa !24
  %t736 = add i64 %t734, 1
  store i64 %t736, ptr %l13, !tbaa !24
  br label %bb47
bb137:
  store i1 false, ptr %l18, !tbaa !21
  %t738 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t738, ptr %l19, !tbaa !23
  %t740 = load ptr, ptr %l2, !tbaa !29
  %t742 = getelementptr %"compiler/ast:Func", ptr %t740, i32 0, i32 3
  %t743 = load ptr, ptr %t742, !tbaa !29
  %t745 = getelementptr %"compiler/ast:Sig", ptr %t743, i32 0, i32 1
  %t746 = load { i64, ptr }, ptr %t745, !tbaa !27
  %t748 = extractvalue { i64, ptr } %t746, 0
  %t750 = icmp sgt i64 %t748, 0
  br i1 %t750, label %bb138, label %bb139
bb138:
  store %olang.scope zeroinitializer, ptr %s14
  %t752 = load ptr, ptr %l2, !tbaa !29
  %t754 = getelementptr %"compiler/ast:Func", ptr %t752, i32 0, i32 3
  %t755 = load ptr, ptr %t754, !tbaa !29
  %t757 = getelementptr %"compiler/ast:Sig", ptr %t755, i32 0, i32 1
  %t758 = load { i64, ptr }, ptr %t757, !tbaa !27
  %t760 = extractvalue { i64, ptr } %t758, 0
  store i64 %t760, ptr %l371, !tbaa !24
  %t761 = load i64, ptr %l371, !tbaa !24
  %t762 = icmp sge i64 %t761, 0
  br i1 %t762, label %bb140, label %bb141
bb139:
  %t764 = load i32, ptr %l4, !tbaa !23
  %t765 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t768 = icmp ne i32 %t764, %t765
  br i1 %t768, label %bb162, label %bb163
bb140:
  %t770 = load i64, ptr %l371, !tbaa !24
  %t771 = icmp sle i64 %t770, 2305843009213693951
  br i1 %t771, label %bb142, label %bb143
bb141:
  call void @__olang_check_failed(ptr @olang_loc_7a7c9bdd5ccfbec2_26ff6938088c41e)
  unreachable
bb142:
  %t773 = load i64, ptr %l371, !tbaa !24
  %t774 = mul i64 %t773, 4
  %t775 = call ptr @__olang_scope_alloc_zeroed(ptr %s14, i64 %t774)
  %t776 = insertvalue { i64, ptr } undef, i64 %t773, 0
  %t777 = insertvalue { i64, ptr } %t776, ptr %t775, 1
  store { i64, ptr } %t777, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t779 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t781 = extractvalue { i64, ptr } %t779, 0
  store i64 %t781, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t783 = load i64, ptr %l22, !tbaa !24
  %t784 = load i64, ptr %l21, !tbaa !24
  %t787 = icmp sgt i64 %t783, %t784
  br i1 %t787, label %bb144, label %bb145
bb143:
  call void @__olang_check_failed(ptr @olang_loc_7a7c9bdd5ccfbec2_26ff6938088c41e)
  unreachable
bb144:
  %t789 = load i64, ptr %l23, !tbaa !24
  %t791 = icmp sgt i64 %t789, 0
  br i1 %t791, label %bb146, label %bb147
bb145:
  store i64 0, ptr %l380, !tbaa !24
  br label %bb149
bb146:
  %t793 = load i64, ptr %l22, !tbaa !24
  %t794 = load i64, ptr %l21, !tbaa !24
  %t797 = sub i64 %t793, %t794
  %t798 = load i64, ptr %l23, !tbaa !24
  %t801 = add i64 %t797, %t798
  %t803 = sub i64 %t801, 1
  %t804 = load i64, ptr %l23, !tbaa !24
  %t807 = sdiv i64 %t803, %t804
  store i64 %t807, ptr %l383, !tbaa !24
  br label %bb148
bb147:
  store i64 0, ptr %l383, !tbaa !24
  br label %bb148
bb148:
  %t809 = load i64, ptr %l383, !tbaa !24
  store i64 %t809, ptr %l380, !tbaa !24
  br label %bb149
bb149:
  %t810 = load i64, ptr %l380, !tbaa !24
  store i64 %t810, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb150
bb150:
  store %olang.scope zeroinitializer, ptr %s16
  %t811 = load i64, ptr %l25, !tbaa !24
  %t812 = load i64, ptr %l24, !tbaa !24
  %t815 = icmp slt i64 %t811, %t812
  %t817 = xor i1 %t815, true
  br i1 %t817, label %bb151, label %bb152
bb151:
  call void @__olang_scope_close(ptr %s16)
  br label %bb156
bb152:
  br label %bb153
bb153:
  %t819 = load i64, ptr %l21, !tbaa !24
  %t820 = load i64, ptr %l25, !tbaa !24
  %t821 = load i64, ptr %l23, !tbaa !24
  %t824 = mul i64 %t820, %t821
  %t827 = add i64 %t819, %t824
  store i64 %t827, ptr %l26, !tbaa !24
  %t829 = load i64, ptr %l26, !tbaa !24
  store i64 %t829, ptr %l401, !tbaa !24
  %t830 = load ptr, ptr %l0, !tbaa !29
  %t831 = load ptr, ptr %l2, !tbaa !29
  %t833 = getelementptr %"compiler/ast:Func", ptr %t831, i32 0, i32 3
  %t834 = load ptr, ptr %t833, !tbaa !29
  %t836 = getelementptr %"compiler/ast:Sig", ptr %t834, i32 0, i32 1
  %t837 = load { i64, ptr }, ptr %t836, !tbaa !27
  store { i64, ptr } %t837, ptr %l405, !tbaa !27
  %t838 = load i64, ptr %l26, !tbaa !24
  %t840 = getelementptr { i64, ptr }, ptr %l405, i32 0, i32 1
  %t841 = load ptr, ptr %t840, !tbaa !27
  %t842 = getelementptr ptr, ptr %t841, i64 %t838
  %t843 = load ptr, ptr %t842, !tbaa !39
  %t847 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %t830, ptr %t843)
  store i32 %t847, ptr %l409
  br label %bb154
bb154:
  %t848 = load i32, ptr %l409, !tbaa !23
  %t849 = load i64, ptr %l401, !tbaa !24
  %t850 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t851 = load ptr, ptr %t850, !tbaa !27
  %t852 = getelementptr i32, ptr %t851, i64 %t849
  store i32 %t848, ptr %t852, !tbaa !33
  call void @__olang_scope_close(ptr %s16)
  br label %bb155
bb155:
  %t853 = load i64, ptr %l25, !tbaa !24
  %t855 = add i64 %t853, 1
  store i64 %t855, ptr %l25, !tbaa !24
  br label %bb150
bb156:
  %t857 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t859 = extractvalue { i64, ptr } %t857, 0
  %t861 = icmp eq i64 %t859, 1
  br i1 %t861, label %bb157, label %bb158
bb157:
  %t863 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t864 = load ptr, ptr %t863, !tbaa !27
  %t865 = getelementptr i32, ptr %t864, i64 0
  %t866 = load i32, ptr %t865, !tbaa !33
  store i32 %t866, ptr %l415, !tbaa !23
  br label %bb161
bb158:
  %t868 = load ptr, ptr %l0, !tbaa !29
  %t870 = getelementptr %"compiler/check:Checker", ptr %t868, i32 0, i32 1
  %t871 = load ptr, ptr %t870, !tbaa !29
  %t873 = getelementptr %"compiler/generic:Program", ptr %t871, i32 0, i32 2
  store ptr %t873, ptr %l419, !tbaa !29
  %t874 = load ptr, ptr %l0, !tbaa !29
  %t876 = getelementptr %"compiler/check:Checker", ptr %t874, i32 0, i32 1
  %t877 = load ptr, ptr %t876, !tbaa !29
  %t879 = getelementptr %"compiler/generic:Program", ptr %t877, i32 0, i32 2
  %t880 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t883 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s14, ptr %t879, { i64, ptr } %t880)
  store i32 %t883, ptr %l424
  br label %bb159
bb159:
  %t884 = load ptr, ptr %l419, !tbaa !29
  %t885 = load i32, ptr %l424, !tbaa !23
  %t886 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %t884, i32 %t885)
  store i32 %t886, ptr %l425
  br label %bb160
bb160:
  %t887 = load i32, ptr %l425, !tbaa !23
  store i32 %t887, ptr %l415, !tbaa !23
  br label %bb161
bb161:
  %t888 = load i32, ptr %l415, !tbaa !23
  store i32 %t888, ptr %l19, !tbaa !23
  call void @__olang_scope_close(ptr %s14)
  br label %bb171
bb162:
  %t889 = load ptr, ptr %l0, !tbaa !29
  store ptr %t889, ptr %l430, !tbaa !29
  %t890 = load ptr, ptr %l0, !tbaa !29
  %t892 = getelementptr %"compiler/check:Checker", ptr %t890, i32 0, i32 1
  %t893 = load ptr, ptr %t892, !tbaa !29
  %t895 = getelementptr %"compiler/generic:Program", ptr %t893, i32 0, i32 2
  %t896 = load i32, ptr %l4, !tbaa !23
  %t899 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t895, i32 %t896)
  store i32 %t899, ptr %l435
  br label %bb164
bb163:
  store i1 false, ptr %l429, !tbaa !21
  br label %bb166
bb164:
  %t900 = load ptr, ptr %l430, !tbaa !29
  %t901 = load i32, ptr %l435, !tbaa !23
  %t902 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ementionsVar(ptr %v0, ptr %t900, i32 %t901, i64 -1)
  store i1 %t902, ptr %l436
  br label %bb165
bb165:
  %t903 = load i1, ptr %l436, !tbaa !21
  %t904 = xor i1 %t903, true
  store i1 %t904, ptr %l429, !tbaa !21
  br label %bb166
bb166:
  %t906 = load i1, ptr %l429, !tbaa !21
  br i1 %t906, label %bb167, label %bb168
bb167:
  %t907 = load ptr, ptr %l0, !tbaa !29
  %t909 = getelementptr %"compiler/check:Checker", ptr %t907, i32 0, i32 1
  %t910 = load ptr, ptr %t909, !tbaa !29
  %t912 = getelementptr %"compiler/generic:Program", ptr %t910, i32 0, i32 2
  %t913 = load i32, ptr %l4, !tbaa !23
  %t916 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t912, i32 %t913)
  store i32 %t916, ptr %l442
  br label %bb169
bb168:
  store i1 true, ptr %l18, !tbaa !21
  %t917 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t917, ptr %l19, !tbaa !23
  br label %bb170
bb169:
  %t919 = load i32, ptr %l442, !tbaa !23
  store i32 %t919, ptr %l19, !tbaa !23
  br label %bb170
bb170:
  br label %bb171
bb171:
  store i32 0, ptr %l27, !tbaa !23
  store i1 false, ptr %l28, !tbaa !21
  %t920 = load ptr, ptr %l2, !tbaa !29
  %t922 = getelementptr %"compiler/ast:Func", ptr %t920, i32 0, i32 3
  %t923 = load ptr, ptr %t922, !tbaa !29
  %t925 = getelementptr %"compiler/ast:Sig", ptr %t923, i32 0, i32 2
  %t926 = load i1, ptr %t925, !tbaa !21
  br i1 %t926, label %bb172, label %bb173
bb172:
  %t928 = load ptr, ptr %l2, !tbaa !29
  %t930 = getelementptr %"compiler/ast:Func", ptr %t928, i32 0, i32 3
  %t931 = load ptr, ptr %t930, !tbaa !29
  %t933 = getelementptr %"compiler/ast:Sig", ptr %t931, i32 0, i32 3
  %t934 = load { i64, ptr }, ptr %t933, !tbaa !27
  %t936 = extractvalue { i64, ptr } %t934, 0
  %t938 = icmp eq i64 %t936, 0
  store i1 %t938, ptr %l447, !tbaa !21
  br label %bb174
bb173:
  store i1 false, ptr %l447, !tbaa !21
  br label %bb174
bb174:
  %t940 = load i1, ptr %l447, !tbaa !21
  br i1 %t940, label %bb175, label %bb176
bb175:
  %t941 = load i32, ptr %l4, !tbaa !23
  %t942 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t945 = icmp eq i32 %t941, %t942
  store i1 %t945, ptr %l453, !tbaa !21
  br label %bb177
bb176:
  store i1 false, ptr %l453, !tbaa !21
  br label %bb177
bb177:
  %t947 = load i1, ptr %l453, !tbaa !21
  br i1 %t947, label %bb178, label %bb179
bb178:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb189
bb179:
  %t948 = load ptr, ptr %l2, !tbaa !29
  %t950 = getelementptr %"compiler/ast:Func", ptr %t948, i32 0, i32 3
  %t951 = load ptr, ptr %t950, !tbaa !29
  %t953 = getelementptr %"compiler/ast:Sig", ptr %t951, i32 0, i32 2
  %t954 = load i1, ptr %t953, !tbaa !21
  br i1 %t954, label %bb180, label %bb181
bb180:
  %t956 = load ptr, ptr %l0, !tbaa !29
  %t958 = getelementptr %"compiler/check:Checker", ptr %t956, i32 0, i32 1
  %t959 = load ptr, ptr %t958, !tbaa !29
  store ptr %t959, ptr %l461, !tbaa !29
  %t960 = load ptr, ptr %l0, !tbaa !29
  %t962 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t960)
  store ptr %t962, ptr %l463
  br label %bb182
bb181:
  %t963 = load i32, ptr %l4, !tbaa !23
  %t964 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t967 = icmp ne i32 %t963, %t964
  br i1 %t967, label %bb184, label %bb185
bb182:
  %t969 = load ptr, ptr %l463, !tbaa !29
  %t971 = getelementptr %"compiler/check:frame", ptr %t969, i32 0, i32 4
  %t972 = load ptr, ptr %l2, !tbaa !29
  %t974 = getelementptr %"compiler/ast:Func", ptr %t972, i32 0, i32 3
  %t975 = load ptr, ptr %t974, !tbaa !29
  %t977 = getelementptr %"compiler/ast:Sig", ptr %t975, i32 0, i32 3
  %t978 = load { i64, ptr }, ptr %t977, !tbaa !27
  %t979 = load ptr, ptr %l461, !tbaa !29
  %t982 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorList(ptr %v0, ptr %v0, ptr %v1, ptr %t979, ptr %t971, i1 true, { i64, ptr } %t978)
  store i32 %t982, ptr %l469
  br label %bb183
bb183:
  %t983 = load i32, ptr %l469, !tbaa !23
  store i32 %t983, ptr %l27, !tbaa !23
  br label %bb188
bb184:
  %t984 = load ptr, ptr %l0, !tbaa !29
  %t986 = getelementptr %"compiler/check:Checker", ptr %t984, i32 0, i32 1
  %t987 = load ptr, ptr %t986, !tbaa !29
  %t989 = getelementptr %"compiler/generic:Program", ptr %t987, i32 0, i32 2
  %t990 = load i32, ptr %l4, !tbaa !23
  %t993 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t989, i32 %t990)
  store i32 %t993, ptr %l477
  br label %bb186
bb185:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb187
bb186:
  %t994 = load i32, ptr %l477, !tbaa !23
  store i32 %t994, ptr %l27, !tbaa !23
  br label %bb187
bb187:
  br label %bb188
bb188:
  br label %bb189
bb189:
  %t995 = load i32, ptr %l4, !tbaa !23
  %t996 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t999 = icmp ne i32 %t995, %t996
  br i1 %t999, label %bb190, label %bb191
bb190:
  %t1001 = load ptr, ptr %l0, !tbaa !29
  %t1003 = getelementptr %"compiler/check:Checker", ptr %t1001, i32 0, i32 1
  %t1004 = load ptr, ptr %t1003, !tbaa !29
  %t1006 = getelementptr %"compiler/generic:Program", ptr %t1004, i32 0, i32 2
  %t1007 = load i32, ptr %l4, !tbaa !23
  %t1010 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t1006, i32 %t1007)
  store i32 %t1010, ptr %l486
  br label %bb192
bb191:
  store i32 0, ptr %l481, !tbaa !23
  br label %bb193
bb192:
  %t1011 = load i32, ptr %l486, !tbaa !23
  store i32 %t1011, ptr %l481, !tbaa !23
  br label %bb193
bb193:
  %t1012 = load i32, ptr %l481, !tbaa !23
  store i32 %t1012, ptr %l29, !tbaa !23
  %t1013 = load ptr, ptr %l0, !tbaa !29
  %t1015 = getelementptr %"compiler/check:Checker", ptr %t1013, i32 0, i32 1
  %t1016 = load ptr, ptr %t1015, !tbaa !29
  %t1018 = getelementptr %"compiler/generic:Program", ptr %t1016, i32 0, i32 2
  %t1019 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t1022 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t1018, { i64, ptr } %t1019)
  store i32 %t1022, ptr %l491
  br label %bb194
bb194:
  %t1023 = load i32, ptr %l491, !tbaa !23
  store i32 %t1023, ptr %l30, !tbaa !23
  %t1024 = load ptr, ptr %l0, !tbaa !29
  %t1026 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1024)
  store ptr %t1026, ptr %l493
  br label %bb195
bb195:
  %t1027 = load ptr, ptr %l493, !tbaa !29
  store ptr %t1027, ptr %l31, !tbaa !29
  %t1028 = load ptr, ptr %l0, !tbaa !29
  %t1030 = getelementptr %"compiler/check:Checker", ptr %t1028, i32 0, i32 13
  %t1032 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_H2d42092ce658fb6cce0104fa754a4e33(ptr %v0, ptr %t1030)
  store i64 %t1032, ptr %l496
  br label %bb196
bb196:
  %t1033 = load i64, ptr %l496, !tbaa !24
  %t1034 = sub i64 %t1033, 1
  store i64 %t1034, ptr %l32, !tbaa !24
  %t1036 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1036, ptr %l498, !tbaa !29
  %t1037 = load ptr, ptr %l31, !tbaa !29
  %t1039 = getelementptr %"compiler/check:frame", ptr %t1037, i32 0, i32 0
  %t1040 = load i64, ptr %t1039, !tbaa !24
  %t1042 = trunc i64 %t1040 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t1044
  %t1045 = getelementptr { i64, [2 x i64] }, ptr %t1044, i32 0, i32 0
  store i64 4, ptr %t1045
  %t1047 = insertvalue { i32 } undef, i32 %t1042, 0
  %t1048 = getelementptr { i64, [2 x i64] }, ptr %t1044, i32 0, i32 1
  store { i32 } %t1047, ptr %t1048
  %t1049 = load { i64, [2 x i64] }, ptr %t1044
  store { i64, [2 x i64] } %t1049, ptr %l503
  %t1050 = load ptr, ptr %l0, !tbaa !29
  %t1052 = getelementptr %"compiler/check:Checker", ptr %t1050, i32 0, i32 1
  %t1053 = load ptr, ptr %t1052, !tbaa !29
  %t1055 = getelementptr %"compiler/generic:Program", ptr %t1053, i32 0, i32 2
  %t1056 = load i32, ptr %l30, !tbaa !23
  %t1057 = load i32, ptr %l19, !tbaa !23
  %t1058 = load i32, ptr %l27, !tbaa !23
  %t1059 = load i32, ptr %l29, !tbaa !23
  %t1065 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t1055, i32 %t1056, i32 %t1057, i32 %t1058, i32 %t1059, i64 0)
  store i32 %t1065, ptr %l511
  br label %bb197
bb197:
  %t1066 = load ptr, ptr %l31, !tbaa !29
  %t1068 = getelementptr %"compiler/check:frame", ptr %t1066, i32 0, i32 1
  %t1069 = load i64, ptr %t1068, !tbaa !24
  %t1070 = load %"compiler/source:Span", ptr %l1
  %t1071 = load ptr, ptr %l498, !tbaa !29
  %t1072 = load { i64, [2 x i64] }, ptr %l503
  %t1073 = load i32, ptr %l511, !tbaa !23
  %t1076 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t1071, { i64, [2 x i64] } %t1072, i32 %t1073, i64 %t1069, %"compiler/source:Span" %t1070)
  store i64 %t1076, ptr %l515
  br label %bb198
bb198:
  %t1077 = load i64, ptr %l515, !tbaa !24
  store i64 %t1077, ptr %l33, !tbaa !24
  %t1078 = load ptr, ptr %l0, !tbaa !29
  %t1080 = getelementptr %"compiler/check:Checker", ptr %t1078, i32 0, i32 16
  %t1081 = load i64, ptr %l33, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t1080, i64 %t1081, i64 1)
  br label %bb199
bb199:
  %t1084 = load ptr, ptr %l0, !tbaa !29
  %t1085 = load i64, ptr %l33, !tbaa !24
  %t1086 = load ptr, ptr %l31, !tbaa !29
  %t1088 = getelementptr %"compiler/check:frame", ptr %t1086, i32 0, i32 1
  %t1089 = load i64, ptr %t1088, !tbaa !24
  %t1090 = load i32, ptr %l19, !tbaa !23
  %t1091 = load i32, ptr %l27, !tbaa !23
  %t1097 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t1084, i64 %t1085, i64 %t1089, i32 %t1090, i32 %t1091)
  store ptr %t1097, ptr %l525
  br label %bb200
bb200:
  %t1098 = load ptr, ptr %l525, !tbaa !29
  store ptr %t1098, ptr %l34, !tbaa !29
  %t1099 = load ptr, ptr %l34, !tbaa !29
  %t1100 = load ptr, ptr %l31, !tbaa !29
  %t1102 = getelementptr %"compiler/check:frame", ptr %t1100, i32 0, i32 4
  %t1103 = load %"compiler/generic:Context", ptr %t1102
  %t1106 = getelementptr %"compiler/check:frame", ptr %t1099, i32 0, i32 4
  store %"compiler/generic:Context" %t1103, ptr %t1106
  %t1107 = load ptr, ptr %l34, !tbaa !29
  %t1108 = load i64, ptr %l32, !tbaa !24
  %t1111 = getelementptr %"compiler/check:frame", ptr %t1107, i32 0, i32 19
  store i64 %t1108, ptr %t1111, !tbaa !24
  %t1112 = load ptr, ptr %l34, !tbaa !29
  %t1113 = load i1, ptr %l18, !tbaa !21
  %t1116 = getelementptr %"compiler/check:frame", ptr %t1112, i32 0, i32 20
  store i1 %t1113, ptr %t1116, !tbaa !21
  %t1117 = load ptr, ptr %l34, !tbaa !29
  %t1118 = load i1, ptr %l28, !tbaa !21
  %t1121 = getelementptr %"compiler/check:frame", ptr %t1117, i32 0, i32 21
  store i1 %t1118, ptr %t1121, !tbaa !21
  %t1122 = load ptr, ptr %l0, !tbaa !29
  %t1124 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t1122)
  store ptr %t1124, ptr %l536
  br label %bb201
bb201:
  %t1125 = load %"compiler/source:Span", ptr %l1
  %t1126 = load ptr, ptr %l536, !tbaa !29
  %t1129 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %t1126, i32 -1, i32 0, %"compiler/source:Span" %t1125)
  store i32 %t1129, ptr %l539
  br label %bb202
bb202:
  store i64 0, ptr %l35, !tbaa !24
  %t1130 = load i64, ptr %l6, !tbaa !24
  store i64 %t1130, ptr %l36, !tbaa !24
  store i64 1, ptr %l37, !tbaa !24
  %t1132 = load i64, ptr %l36, !tbaa !24
  %t1133 = load i64, ptr %l35, !tbaa !24
  %t1136 = icmp sgt i64 %t1132, %t1133
  br i1 %t1136, label %bb203, label %bb204
bb203:
  %t1138 = load i64, ptr %l37, !tbaa !24
  %t1140 = icmp sgt i64 %t1138, 0
  br i1 %t1140, label %bb205, label %bb206
bb204:
  store i64 0, ptr %l544, !tbaa !24
  br label %bb208
bb205:
  %t1142 = load i64, ptr %l36, !tbaa !24
  %t1143 = load i64, ptr %l35, !tbaa !24
  %t1146 = sub i64 %t1142, %t1143
  %t1147 = load i64, ptr %l37, !tbaa !24
  %t1150 = add i64 %t1146, %t1147
  %t1152 = sub i64 %t1150, 1
  %t1153 = load i64, ptr %l37, !tbaa !24
  %t1156 = sdiv i64 %t1152, %t1153
  store i64 %t1156, ptr %l547, !tbaa !24
  br label %bb207
bb206:
  store i64 0, ptr %l547, !tbaa !24
  br label %bb207
bb207:
  %t1158 = load i64, ptr %l547, !tbaa !24
  store i64 %t1158, ptr %l544, !tbaa !24
  br label %bb208
bb208:
  %t1159 = load i64, ptr %l544, !tbaa !24
  store i64 %t1159, ptr %l38, !tbaa !24
  store i64 0, ptr %l39, !tbaa !24
  br label %bb209
bb209:
  store %olang.scope zeroinitializer, ptr %s28
  %t1160 = load i64, ptr %l39, !tbaa !24
  %t1161 = load i64, ptr %l38, !tbaa !24
  %t1164 = icmp slt i64 %t1160, %t1161
  %t1166 = xor i1 %t1164, true
  br i1 %t1166, label %bb210, label %bb211
bb210:
  call void @__olang_scope_close(ptr %s28)
  br label %bb219
bb211:
  br label %bb212
bb212:
  %t1168 = load i64, ptr %l35, !tbaa !24
  %t1169 = load i64, ptr %l39, !tbaa !24
  %t1170 = load i64, ptr %l37, !tbaa !24
  %t1173 = mul i64 %t1169, %t1170
  %t1176 = add i64 %t1168, %t1173
  store i64 %t1176, ptr %l40, !tbaa !24
  %t1178 = load ptr, ptr %l0, !tbaa !29
  %t1179 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t1179, ptr %l566, !tbaa !27
  %t1180 = load i64, ptr %l40, !tbaa !24
  %t1182 = getelementptr { i64, ptr }, ptr %l566, i32 0, i32 1
  %t1183 = load ptr, ptr %t1182, !tbaa !27
  %t1184 = getelementptr ptr, ptr %t1183, i64 %t1180
  %t1185 = load ptr, ptr %t1184, !tbaa !39
  %t1187 = getelementptr %"compiler/ast:Param", ptr %t1185, i32 0, i32 1
  %t1188 = load i32, ptr %t1187, !tbaa !23
  %t1189 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t1189, ptr %l570, !tbaa !27
  %t1190 = load i64, ptr %l40, !tbaa !24
  %t1192 = getelementptr { i64, ptr }, ptr %l570, i32 0, i32 1
  %t1193 = load ptr, ptr %t1192, !tbaa !27
  %t1194 = getelementptr ptr, ptr %t1193, i64 %t1190
  %t1195 = load ptr, ptr %t1194, !tbaa !39
  %t1197 = getelementptr %"compiler/ast:Param", ptr %t1195, i32 0, i32 0
  %t1198 = load %"compiler/source:Span", ptr %t1197
  %t1199 = load i64, ptr %l40, !tbaa !24
  %t1201 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t1202 = load ptr, ptr %t1201, !tbaa !27
  %t1203 = getelementptr i32, ptr %t1202, i64 %t1199
  %t1204 = load i32, ptr %t1203, !tbaa !33
  %t1205 = load i64, ptr %l40, !tbaa !24
  %t1206 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t1206, ptr %l577, !tbaa !27
  %t1207 = load i64, ptr %l40, !tbaa !24
  %t1209 = getelementptr { i64, ptr }, ptr %l577, i32 0, i32 1
  %t1210 = load ptr, ptr %t1209, !tbaa !27
  %t1211 = getelementptr ptr, ptr %t1210, i64 %t1207
  %t1212 = load ptr, ptr %t1211, !tbaa !39
  %t1214 = getelementptr %"compiler/ast:Param", ptr %t1212, i32 0, i32 2
  %t1215 = load ptr, ptr %t1214, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparam(ptr %v0, ptr %v1, ptr %t1178, i32 %t1188, %"compiler/source:Span" %t1198, i32 %t1204, i64 %t1205, ptr %t1215)
  br label %bb213
bb213:
  %t1222 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t1222, ptr %l581, !tbaa !27
  %t1223 = load i64, ptr %l40, !tbaa !24
  %t1225 = getelementptr { i64, ptr }, ptr %l581, i32 0, i32 1
  %t1226 = load ptr, ptr %t1225, !tbaa !27
  %t1227 = getelementptr ptr, ptr %t1226, i64 %t1223
  %t1228 = load ptr, ptr %t1227, !tbaa !39
  %t1230 = getelementptr %"compiler/ast:Param", ptr %t1228, i32 0, i32 2
  %t1231 = load ptr, ptr %t1230, !tbaa !29
  %t1233 = icmp eq ptr %t1231, null
  %t1235 = xor i1 %t1233, true
  br i1 %t1235, label %bb214, label %bb215
bb214:
  %t1237 = load ptr, ptr %l0, !tbaa !29
  %t1238 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t1238, ptr %l588, !tbaa !27
  %t1239 = load i64, ptr %l40, !tbaa !24
  %t1241 = getelementptr { i64, ptr }, ptr %l588, i32 0, i32 1
  %t1242 = load ptr, ptr %t1241, !tbaa !27
  %t1243 = getelementptr ptr, ptr %t1242, i64 %t1239
  %t1244 = load ptr, ptr %t1243, !tbaa !39
  %t1245 = load i64, ptr %l40, !tbaa !24
  %t1247 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t1248 = load ptr, ptr %t1247, !tbaa !27
  %t1249 = getelementptr i32, ptr %t1248, i64 %t1245
  %t1250 = load i32, ptr %t1249, !tbaa !33
  %t1254 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamWritten(ptr %v0, ptr %v1, ptr %t1237, ptr %t1244, i32 %t1250, i1 false)
  store i1 %t1254, ptr %l593
  br label %bb216
bb215:
  br label %bb217
bb216:
  br label %bb217
bb217:
  call void @__olang_scope_close(ptr %s28)
  br label %bb218
bb218:
  %t1255 = load i64, ptr %l39, !tbaa !24
  %t1257 = add i64 %t1255, 1
  store i64 %t1257, ptr %l39, !tbaa !24
  br label %bb209
bb219:
  %t1259 = load ptr, ptr %l0, !tbaa !29
  %t1261 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t1259)
  store ptr %t1261, ptr %l597
  br label %bb220
bb220:
  %t1262 = load ptr, ptr %l0, !tbaa !29
  %t1264 = getelementptr %"compiler/check:Checker", ptr %t1262, i32 0, i32 1
  %t1265 = load ptr, ptr %t1264, !tbaa !29
  store ptr %t1265, ptr %l599, !tbaa !29
  %t1266 = load ptr, ptr %l0, !tbaa !29
  %t1268 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t1266)
  store ptr %t1268, ptr %l601
  br label %bb221
bb221:
  %t1269 = load ptr, ptr %l601, !tbaa !29
  %t1271 = getelementptr %"compiler/typed:Body", ptr %t1269, i32 0, i32 2
  %t1272 = load i32, ptr %t1271, !tbaa !23
  %t1273 = load ptr, ptr %l599, !tbaa !29
  %t1275 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t1273, i32 %t1272)
  store { i64, ptr } %t1275, ptr %l604
  br label %bb222
bb222:
  %t1276 = load { i64, ptr }, ptr %l604, !tbaa !27
  %t1277 = extractvalue { i64, ptr } %t1276, 0
  %t1278 = extractvalue { i64, ptr } %t1276, 1
  %t1279 = mul i64 %t1277, 8
  %t1280 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1279)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1280, ptr %t1278, i64 %t1279, i1 false)
  %t1281 = insertvalue { i64, ptr } undef, i64 %t1277, 0
  %t1282 = insertvalue { i64, ptr } %t1281, ptr %t1280, 1
  %t1283 = load ptr, ptr %l597, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eSetVars(ptr %v0, ptr %s0, ptr %t1283, { i64, ptr } %t1282)
  br label %bb223
bb223:
  %t1285 = load ptr, ptr %l0, !tbaa !29
  %t1286 = load ptr, ptr %l2, !tbaa !29
  %t1288 = getelementptr %"compiler/ast:Func", ptr %t1286, i32 0, i32 4
  %t1289 = load { i64, ptr }, ptr %t1288, !tbaa !27
  %t1292 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootStmts(ptr %v0, ptr %v1, ptr %t1285, { i64, ptr } %t1289)
  store ptr %t1292, ptr %l609
  br label %bb224
bb224:
  %t1293 = load ptr, ptr %l609, !tbaa !29
  store ptr %t1293, ptr %l41, !tbaa !29
  %t1294 = load ptr, ptr %l0, !tbaa !29
  %t1296 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t1294)
  store ptr %t1296, ptr %l611
  br label %bb225
bb225:
  %t1297 = load ptr, ptr %l611, !tbaa !29
  %t1298 = load ptr, ptr %l41, !tbaa !29
  %t1302 = getelementptr %"compiler/typed:Body", ptr %t1297, i32 0, i32 11
  store ptr %t1298, ptr %t1302, !tbaa !29
  %t1303 = load ptr, ptr %l34, !tbaa !29
  %t1305 = getelementptr %"compiler/check:frame", ptr %t1303, i32 0, i32 20
  %t1306 = load i1, ptr %t1305, !tbaa !21
  br i1 %t1306, label %bb226, label %bb227
bb226:
  %t1308 = load ptr, ptr %l34, !tbaa !29
  %t1310 = getelementptr %"compiler/check:frame", ptr %t1308, i32 0, i32 20
  store i1 false, ptr %t1310, !tbaa !21
  %t1311 = load ptr, ptr %l34, !tbaa !29
  %t1312 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t1315 = getelementptr %"compiler/check:frame", ptr %t1311, i32 0, i32 5
  store i32 %t1312, ptr %t1315, !tbaa !23
  br label %bb228
bb227:
  br label %bb228
bb228:
  %t1316 = load ptr, ptr %l34, !tbaa !29
  %t1318 = getelementptr %"compiler/check:frame", ptr %t1316, i32 0, i32 5
  %t1319 = load i32, ptr %t1318, !tbaa !23
  store i32 %t1319, ptr %l19, !tbaa !23
  %t1321 = load i1, ptr %l28, !tbaa !21
  br i1 %t1321, label %bb229, label %bb230
bb229:
  store %olang.scope zeroinitializer, ptr %s32
  %t1323 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1323, ptr %l623, !tbaa !29
  %t1324 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1324, ptr %l624, !tbaa !29
  %t1325 = load ptr, ptr %l0, !tbaa !29
  %t1326 = load ptr, ptr %l34, !tbaa !29
  %t1329 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eletOut(ptr %v0, ptr %v0, ptr %s32, ptr %t1325, ptr %t1326)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1329, ptr %l627
  br label %bb231
bb230:
  br label %bb234
bb231:
  %t1330 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l627
  %t1331 = call ptr @__olang_scope_alloc_a(ptr %s32, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1330, ptr %t1331
  %t1332 = load ptr, ptr %l624, !tbaa !29
  %t1334 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emerged(ptr %v0, ptr %s32, ptr %s32, ptr %t1332, ptr %t1331)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1334, ptr %l629
  br label %bb232
bb232:
  %t1335 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l629
  %t1336 = call ptr @__olang_scope_alloc_a(ptr %s32, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1335, ptr %t1336
  %t1337 = load ptr, ptr %l623, !tbaa !29
  %t1339 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecanonicalErrs(ptr %v0, ptr %s32, ptr %t1337, ptr %t1336)
  store i32 %t1339, ptr %l631
  br label %bb233
bb233:
  %t1340 = load i32, ptr %l631, !tbaa !23
  store i32 %t1340, ptr %l27, !tbaa !23
  call void @__olang_scope_close(ptr %s32)
  br label %bb234
bb234:
  %t1341 = load ptr, ptr %l0, !tbaa !29
  %t1343 = getelementptr %"compiler/check:Checker", ptr %t1341, i32 0, i32 1
  %t1344 = load ptr, ptr %t1343, !tbaa !29
  %t1346 = getelementptr %"compiler/generic:Program", ptr %t1344, i32 0, i32 2
  %t1347 = load i32, ptr %l30, !tbaa !23
  %t1348 = load i32, ptr %l19, !tbaa !23
  %t1349 = load i32, ptr %l27, !tbaa !23
  %t1350 = load i32, ptr %l29, !tbaa !23
  %t1356 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t1346, i32 %t1347, i32 %t1348, i32 %t1349, i32 %t1350, i64 0)
  store i32 %t1356, ptr %l639
  br label %bb235
bb235:
  %t1357 = load i32, ptr %l639, !tbaa !23
  store i32 %t1357, ptr %l42, !tbaa !23
  %t1358 = load ptr, ptr %l0, !tbaa !29
  %t1360 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t1358)
  store ptr %t1360, ptr %l641
  br label %bb236
bb236:
  %t1361 = load ptr, ptr %l641, !tbaa !29
  %t1362 = load i32, ptr %l42, !tbaa !23
  %t1365 = getelementptr %"compiler/typed:Body", ptr %t1361, i32 0, i32 2
  store i32 %t1362, ptr %t1365, !tbaa !23
  %t1366 = load i32, ptr %l19, !tbaa !23
  %t1367 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t1370 = icmp ne i32 %t1366, %t1367
  br i1 %t1370, label %bb237, label %bb238
bb237:
  %t1372 = load ptr, ptr %l0, !tbaa !29
  %t1374 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1372)
  store ptr %t1374, ptr %l649
  br label %bb239
bb238:
  store i1 false, ptr %l647, !tbaa !21
  br label %bb240
bb239:
  %t1375 = load ptr, ptr %l649, !tbaa !29
  %t1377 = getelementptr %"compiler/check:frame", ptr %t1375, i32 0, i32 18
  %t1378 = load i1, ptr %t1377, !tbaa !21
  %t1380 = xor i1 %t1378, true
  store i1 %t1380, ptr %l647, !tbaa !21
  br label %bb240
bb240:
  %t1382 = load i1, ptr %l647, !tbaa !21
  br i1 %t1382, label %bb241, label %bb242
bb241:
  %t1383 = load ptr, ptr %l41, !tbaa !29
  %t1386 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t1383)
  store i1 %t1386, ptr %l656
  br label %bb243
bb242:
  store i1 false, ptr %l653, !tbaa !21
  br label %bb244
bb243:
  %t1387 = load i1, ptr %l656, !tbaa !21
  %t1388 = xor i1 %t1387, true
  store i1 %t1388, ptr %l653, !tbaa !21
  br label %bb244
bb244:
  %t1390 = load i1, ptr %l653, !tbaa !21
  br i1 %t1390, label %bb245, label %bb246
bb245:
  store %olang.scope zeroinitializer, ptr %s33
  %t1391 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1391, ptr %l658, !tbaa !29
  %t1392 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1392, ptr %l659
  %t1393 = load ptr, ptr %l0, !tbaa !29
  %t1394 = load i32, ptr %l19, !tbaa !23
  %t1397 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s33, ptr %t1393, i32 %t1394)
  store { i64, ptr } %t1397, ptr %l662
  br label %bb247
bb246:
  br label %bb250
bb247:
  %t1398 = load { i64, ptr }, ptr %l662, !tbaa !27
  %t1399 = extractvalue { i64, ptr } %t1398, 0
  %t1400 = extractvalue { i64, ptr } %t1398, 1
  %t1401 = mul i64 %t1399, 1
  %t1402 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t1401)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1402, ptr %t1400, i64 %t1401, i1 false)
  %t1403 = insertvalue { i64, ptr } undef, i64 %t1399, 0
  %t1404 = insertvalue { i64, ptr } %t1403, ptr %t1402, 1
  %t1406 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMissingReturn(ptr %s33, ptr %s33, { i64, ptr } %t1404)
  store %"compiler/msgs:Msg" %t1406, ptr %l664
  br label %bb248
bb248:
  %t1407 = load ptr, ptr %l658, !tbaa !29
  %t1408 = load %"compiler/source:Span", ptr %l659
  %t1409 = load %"compiler/msgs:Msg", ptr %l664
  %t1410 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s33, ptr %t1407, %"compiler/source:Span" %t1408, %"compiler/msgs:Msg" %t1409)
  store i64 %t1410, ptr %l665
  br label %bb249
bb249:
  call void @__olang_scope_close(ptr %s33)
  br label %bb250
bb250:
  %t1411 = load ptr, ptr %l0, !tbaa !29
  %t1413 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1411)
  store ptr %t1413, ptr %l667
  br label %bb251
bb251:
  %t1414 = load ptr, ptr %l667, !tbaa !29
  %t1416 = getelementptr %"compiler/check:frame", ptr %t1414, i32 0, i32 25
  %t1418 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aCapture_26_3e_2e_Hc9219e836d6ca52518c31537b8e6a8eb(ptr %v0, ptr %v0, ptr %t1416)
  store { i64, ptr } %t1418, ptr %l670
  br label %bb252
bb252:
  %t1419 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t1419, ptr %lp43
  %t1420 = load { i64, ptr }, ptr %l670, !tbaa !27
  %t1421 = load ptr, ptr %lp43
  store { i64, ptr } %t1420, ptr %t1421, !tbaa !27
  %t1422 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t1422)
  br label %bb253
bb253:
  %t1424 = load ptr, ptr %l0, !tbaa !29
  %t1426 = getelementptr %"compiler/check:Checker", ptr %t1424, i32 0, i32 16
  %t1427 = load i64, ptr %l33, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t1426, i64 %t1427, i64 2)
  br label %bb254
bb254:
  %t1430 = load ptr, ptr %l0, !tbaa !29
  %t1432 = getelementptr %"compiler/check:Checker", ptr %t1430, i32 0, i32 61
  store ptr %t1432, ptr %l676, !tbaa !29
  %t1433 = load i64, ptr %l33, !tbaa !24
  store i64 %t1433, ptr %l677, !tbaa !24
  %t1434 = load ptr, ptr %l0, !tbaa !29
  %t1435 = load %"compiler/source:Span", ptr %l1
  %t1438 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t1434, %"compiler/source:Span" %t1435)
  store { i64, [3 x i64] } %t1438, ptr %l680
  br label %bb255
bb255:
  %t1439 = load i64, ptr %l677, !tbaa !24
  %t1440 = load { i64, [3 x i64] }, ptr %l680
  %t1441 = call %"compiler/check:roFn" @compiler_2fcheck_3aroFn_2ector(ptr %v0, ptr %v0, i64 %t1439, i64 0, { i64, [3 x i64] } %t1440, { i64, ptr } { i64 11, ptr @.d21 })
  store %"compiler/check:roFn" %t1441, ptr %l681
  br label %bb256
bb256:
  %t1442 = load ptr, ptr %l676, !tbaa !29
  %t1443 = load %"compiler/check:roFn", ptr %l681
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroFn_3e_2ePush_3ccompiler_2fcheck_3aroFn_3e(ptr %v0, ptr %v0, ptr %t1442, %"compiler/check:roFn" %t1443)
  br label %bb257
bb257:
  %t1444 = load i32, ptr %l4, !tbaa !23
  %t1445 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t1448 = icmp eq i32 %t1444, %t1445
  br i1 %t1448, label %bb258, label %bb259
bb258:
  %t1450 = load ptr, ptr %l0, !tbaa !29
  %t1452 = getelementptr %"compiler/check:Checker", ptr %t1450, i32 0, i32 1
  %t1453 = load ptr, ptr %t1452, !tbaa !29
  %t1455 = getelementptr %"compiler/generic:Program", ptr %t1453, i32 0, i32 2
  store ptr %t1455, ptr %l688, !tbaa !29
  %t1456 = load i32, ptr %l42, !tbaa !23
  store i32 %t1456, ptr %l689, !tbaa !23
  %t1457 = load ptr, ptr %l0, !tbaa !29
  %t1459 = getelementptr %"compiler/check:Checker", ptr %t1457, i32 0, i32 1
  %t1460 = load ptr, ptr %t1459, !tbaa !29
  %t1461 = load ptr, ptr %l2, !tbaa !29
  %t1463 = getelementptr %"compiler/ast:Func", ptr %t1461, i32 0, i32 3
  %t1464 = load ptr, ptr %t1463, !tbaa !29
  %t1467 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSigNames(ptr %v0, ptr %v1, ptr %t1460, ptr %t1464)
  store i64 %t1467, ptr %l694
  br label %bb260
bb259:
  %t1468 = load ptr, ptr %l0, !tbaa !29
  %t1470 = getelementptr %"compiler/check:Checker", ptr %t1468, i32 0, i32 1
  %t1471 = load ptr, ptr %t1470, !tbaa !29
  %t1473 = getelementptr %"compiler/generic:Program", ptr %t1471, i32 0, i32 2
  store ptr %t1473, ptr %l698, !tbaa !29
  %t1474 = load i32, ptr %l42, !tbaa !23
  store i32 %t1474, ptr %l699, !tbaa !23
  %t1475 = load ptr, ptr %l0, !tbaa !29
  %t1477 = getelementptr %"compiler/check:Checker", ptr %t1475, i32 0, i32 1
  %t1478 = load ptr, ptr %t1477, !tbaa !29
  %t1480 = getelementptr %"compiler/generic:Program", ptr %t1478, i32 0, i32 2
  %t1481 = load i32, ptr %l4, !tbaa !23
  %t1484 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesIdOf(ptr %v0, ptr %t1480, i32 %t1481)
  store i64 %t1484, ptr %l704
  br label %bb262
bb260:
  %t1485 = load ptr, ptr %l688, !tbaa !29
  %t1486 = load i32, ptr %l689, !tbaa !23
  %t1487 = load i64, ptr %l694, !tbaa !24
  %t1488 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithNames(ptr %v0, ptr %t1485, i32 %t1486, i64 %t1487)
  store i32 %t1488, ptr %l695
  br label %bb261
bb261:
  %t1489 = load i32, ptr %l695, !tbaa !23
  store i32 %t1489, ptr %l685, !tbaa !23
  br label %bb264
bb262:
  %t1490 = load ptr, ptr %l698, !tbaa !29
  %t1491 = load i32, ptr %l699, !tbaa !23
  %t1492 = load i64, ptr %l704, !tbaa !24
  %t1493 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithNames(ptr %v0, ptr %t1490, i32 %t1491, i64 %t1492)
  store i32 %t1493, ptr %l705
  br label %bb263
bb263:
  %t1494 = load i32, ptr %l705, !tbaa !23
  store i32 %t1494, ptr %l685, !tbaa !23
  br label %bb264
bb264:
  %t1495 = load i32, ptr %l685, !tbaa !23
  %t1496 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1496, ptr %l706
  store i32 %t1495, ptr %l707, !tbaa !23
  %t1498 = load i64, ptr %l33, !tbaa !24
  %t1500 = trunc i64 %t1498 to i32
  store i32 %t1500, ptr %l710, !tbaa !23
  %t1502 = load ptr, ptr %lp43
  %t1503 = load { i64, ptr }, ptr %t1502, !tbaa !27
  store { i64, ptr } %t1503, ptr %l711, !tbaa !27
  %t1504 = load ptr, ptr %l0, !tbaa !29
  %t1505 = load %"compiler/source:Span", ptr %l1
  %t1509 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t1504, i32 5, %"compiler/source:Span" %t1505)
  store i32 %t1509, ptr %l715
  br label %bb265
bb265:
  store { i64, [4 x i64] } zeroinitializer, ptr %t1510
  %t1511 = getelementptr { i64, [4 x i64] }, ptr %t1510, i32 0, i32 0
  store i64 1, ptr %t1511
  %t1512 = load i32, ptr %l710, !tbaa !23
  %t1513 = insertvalue { i32, { i64, ptr }, i32 } undef, i32 %t1512, 0
  %t1514 = load { i64, ptr }, ptr %l711, !tbaa !27
  %t1515 = insertvalue { i32, { i64, ptr }, i32 } %t1513, { i64, ptr } %t1514, 1
  %t1516 = load i32, ptr %l715, !tbaa !23
  %t1517 = insertvalue { i32, { i64, ptr }, i32 } %t1515, i32 %t1516, 2
  %t1518 = getelementptr { i64, [4 x i64] }, ptr %t1510, i32 0, i32 1
  store { i32, { i64, ptr }, i32 } %t1517, ptr %t1518
  %t1519 = load { i64, [4 x i64] }, ptr %t1510
  %t1521 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t1519, ptr %t1521
  store { i64, [5 x i64] } zeroinitializer, ptr %t1522
  %t1523 = getelementptr { i64, [5 x i64] }, ptr %t1522, i32 0, i32 0
  store i64 15, ptr %t1523
  %t1524 = load %"compiler/source:Span", ptr %l706
  %t1525 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1524, 0
  %t1526 = load i32, ptr %l707, !tbaa !23
  %t1527 = insertvalue { %"compiler/source:Span", i32, ptr } %t1525, i32 %t1526, 1
  %t1529 = insertvalue { %"compiler/source:Span", i32, ptr } %t1527, ptr %t1521, 2
  %t1530 = getelementptr { i64, [5 x i64] }, ptr %t1522, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1529, ptr %t1530
  %t1531 = load { i64, [5 x i64] }, ptr %t1522
  %t1533 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t1531, ptr %t1533
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1533, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleft(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca %"compiler/typed:Item"
  %l21 = alloca i32
  %l24 = alloca i64
  %l27 = alloca i64
  %l29 = alloca i64
  %l36 = alloca i64
  %l40 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca i32
  %l53 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l79 = alloca i64
  %l96 = alloca i32
  %l103 = alloca i32
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l21
  br label %bb1
bb1:
  %t11 = load i32, ptr %l21, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordCount(ptr %v0, ptr %t12, i32 %t13)
  store i64 %t16, ptr %l24
  br label %bb2
bb2:
  %t17 = load i64, ptr %l24, !tbaa !24
  store i64 %t17, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp sge i64 %t18, 64
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = sub i64 0, 1
  store i64 %t22, ptr %l27, !tbaa !65
  br label %bb5
bb4:
  %t24 = load i64, ptr %l4, !tbaa !24
  store i64 %t24, ptr %l29, !tbaa !24
  %t25 = load i64, ptr %l29, !tbaa !24
  %t26 = load i64, ptr %l29, !tbaa !24
  %t27 = shl i64 1, %t26
  %t29 = sub i64 %t27, 1
  store i64 %t29, ptr %l27, !tbaa !65
  br label %bb5
bb5:
  %t31 = load i64, ptr %l27, !tbaa !65
  store i64 %t31, ptr %l5, !tbaa !65
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  %t38 = load i32, ptr %l1, !tbaa !23
  %t41 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t37, i32 %t38)
  store i64 %t41, ptr %l36
  br label %bb6
bb6:
  %t42 = load i64, ptr %l5, !tbaa !65
  %t43 = load i64, ptr %l36, !tbaa !65
  %t45 = and i64 %t43, %t42
  store i64 %t45, ptr %l6, !tbaa !65
  store ptr %a2, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t49 = load ptr, ptr %l7, !tbaa !29
  %t50 = load i64, ptr %l8, !tbaa !24
  %t53 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2eR_H9395c9c55f40ca4e18bbadf0b4ab31aa(ptr %v1, ptr %t49, i64 %t50)
  %t54 = extractvalue { i32, { i64, ptr } } %t53, 1
  %t55 = extractvalue { i32, { i64, ptr } } %t53, 0
  store i32 %t55, ptr %l44
  %t56 = icmp ne i32 %t55, 0
  br i1 %t56, label %bb9, label %ok.57
ok.57:
  store { i64, ptr } %t54, ptr %l43
  br label %bb8
bb8:
  %t58 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t58, ptr %l40, !tbaa !27
  br label %bb13
bb9:
  %t59 = load i32, ptr %l44, !tbaa !23
  %t60 = ashr i32 %t59, 16
  %t62 = icmp eq i32 %t60, 1
  br i1 %t62, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_c9e70fc2ae99f8ec_a4a86a2066a83508)
  unreachable
bb12:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb39
bb13:
  %t64 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t64, ptr %l9, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t65, 0
  store i64 %t67, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t69 = load i64, ptr %l11, !tbaa !24
  %t70 = load i64, ptr %l10, !tbaa !24
  %t73 = icmp slt i64 %t69, %t70
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb37
bb16:
  br label %bb17
bb17:
  %t77 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t77, ptr %l53, !tbaa !27
  %t78 = load i64, ptr %l11, !tbaa !24
  %t80 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr ptr, ptr %t81, i64 %t78
  %t83 = load ptr, ptr %t82, !tbaa !39
  store ptr %t83, ptr %l12, !tbaa !29
  %t85 = load ptr, ptr %l12, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Clause", ptr %t85, i32 0, i32 2
  %t88 = load i1, ptr %t87, !tbaa !21
  br i1 %t88, label %bb18, label %bb19
bb18:
  %t90 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  store i32 %t90, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t92 = load ptr, ptr %l12, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Clause", ptr %t92, i32 0, i32 1
  %t95 = load { i64, ptr }, ptr %t94, !tbaa !27
  store { i64, ptr } %t95, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t97 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 0
  store i64 %t99, ptr %l15, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s6
  %t101 = load i64, ptr %l14, !tbaa !24
  %t102 = load i64, ptr %l15, !tbaa !24
  %t105 = icmp slt i64 %t101, %t102
  %t107 = xor i1 %t105, true
  br i1 %t107, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s6)
  br label %bb35
bb23:
  br label %bb24
bb24:
  %t109 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t109, ptr %l67, !tbaa !27
  %t110 = load i64, ptr %l14, !tbaa !24
  %t112 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr %"compiler/typed:Item", ptr %t113, i64 %t110
  %t115 = load %"compiler/typed:Item", ptr %t114
  store %"compiler/typed:Item" %t115, ptr %l16
  %t117 = getelementptr %"compiler/typed:Item", ptr %l16, i32 0, i32 0
  %t118 = load i32, ptr %t117, !tbaa !23
  %t119 = load i32, ptr %l3, !tbaa !23
  %t122 = icmp eq i32 %t118, %t119
  br i1 %t122, label %bb25, label %bb26
bb25:
  %t124 = getelementptr %"compiler/typed:Item", ptr %l16, i32 0, i32 1
  %t125 = load i64, ptr %t124, !tbaa !24
  %t127 = icmp slt i64 %t125, 0
  br i1 %t127, label %bb27, label %bb28
bb26:
  br label %bb33
bb27:
  %t129 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  store i32 %t129, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t131 = getelementptr %"compiler/typed:Item", ptr %l16, i32 0, i32 1
  %t132 = load i64, ptr %t131, !tbaa !24
  %t134 = icmp slt i64 %t132, 64
  br i1 %t134, label %bb30, label %bb31
bb30:
  %t136 = load i64, ptr %l6, !tbaa !65
  %t137 = getelementptr %"compiler/typed:Item", ptr %l16, i32 0, i32 1
  %t138 = load i64, ptr %t137, !tbaa !24
  store i64 %t138, ptr %l79, !tbaa !24
  %t139 = load i64, ptr %l79, !tbaa !24
  %t140 = load i64, ptr %l79, !tbaa !24
  %t141 = shl i64 1, %t140
  %t143 = xor i64 %t141, -1
  %t146 = and i64 %t136, %t143
  store i64 %t146, ptr %l6, !tbaa !65
  br label %bb32
bb31:
  br label %bb32
bb32:
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s6)
  br label %bb34
bb34:
  %t148 = load i64, ptr %l14, !tbaa !24
  %t150 = add i64 %t148, 1
  store i64 %t150, ptr %l14, !tbaa !24
  br label %bb21
bb35:
  call void @__olang_scope_close(ptr %s3)
  br label %bb36
bb36:
  %t152 = load i64, ptr %l11, !tbaa !24
  %t154 = add i64 %t152, 1
  store i64 %t154, ptr %l11, !tbaa !24
  br label %bb14
bb37:
  %t156 = load i64, ptr %l8, !tbaa !24
  %t157 = load i64, ptr %l10, !tbaa !24
  %t160 = add i64 %t156, %t157
  store i64 %t160, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb38
bb38:
  br label %bb7
bb39:
  %t162 = load i64, ptr %l6, !tbaa !65
  %t164 = icmp eq i64 %t162, 0
  br i1 %t164, label %bb40, label %bb41
bb40:
  %t166 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t166, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  %t168 = load i64, ptr %l6, !tbaa !65
  %t169 = load i64, ptr %l5, !tbaa !65
  %t172 = icmp eq i64 %t168, %t169
  br i1 %t172, label %bb43, label %bb44
bb43:
  %t174 = load i32, ptr %l3, !tbaa !23
  store i32 %t174, ptr %l96, !tbaa !23
  br label %bb46
bb44:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/check:Checker", ptr %t176, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !29
  %t181 = getelementptr %"compiler/generic:Program", ptr %t179, i32 0, i32 2
  %t182 = load i32, ptr %l3, !tbaa !23
  %t183 = load i64, ptr %l6, !tbaa !65
  %t187 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %t181, i32 %t182, i64 %t183)
  store i32 %t187, ptr %l103
  br label %bb45
bb45:
  %t188 = load i32, ptr %l103, !tbaa !23
  store i32 %t188, ptr %l96, !tbaa !23
  br label %bb46
bb46:
  %t189 = load i32, ptr %l96, !tbaa !23
  store i32 %t189, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralLocalIn(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l31 = alloca ptr
  %l36 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l42 = alloca i1
  %l43 = alloca i1
  %l47 = alloca i1
  %l48 = alloca i1
  %l52 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l68 = alloca { i64, ptr }
  %l75 = alloca i64
  %s3 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t7 = load ptr, ptr %l16, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l16, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 2
  store i1 %t13, ptr %l17, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l17, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t17, i32 0, i32 1
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l3, !tbaa !23
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [5 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t23, i32 0, i32 2
  %t25 = load ptr, ptr %t24
  store ptr %t25, ptr %l4, !tbaa !29
  br label %bb8
bb7:
  br label %bb34
bb8:
  %t27 = load ptr, ptr %l4, !tbaa !29
  store ptr %t27, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t28 = load ptr, ptr %l24, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t31 = load ptr, ptr %l24, !tbaa !29
  %t32 = load i64, ptr %t31
  %t34 = icmp eq i64 %t32, 0
  store i1 %t34, ptr %l25, !tbaa !21
  br label %bb10
bb10:
  %t35 = load i1, ptr %l25, !tbaa !21
  br i1 %t35, label %bb11, label %bb12
bb11:
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t38 = getelementptr { i64, [4 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t38, i32 0, i32 2
  %t40 = load i32, ptr %t39
  store i32 %t40, ptr %l5, !tbaa !23
  br label %bb13
bb12:
  br label %bb28
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t42)
  store ptr %t44, ptr %l31
  br label %bb14
bb14:
  %t45 = load ptr, ptr %l31, !tbaa !29
  %t47 = getelementptr %"compiler/check:frame", ptr %t45, i32 0, i32 0
  %t48 = load i64, ptr %t47, !tbaa !24
  %t49 = load i32, ptr %l5, !tbaa !23
  %t51 = sext i32 %t49 to i64
  %t54 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s3, i64 %t48, i64 %t51)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t54, ptr %l36
  br label %bb15
bb15:
  %t55 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l36
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t55, ptr %l6
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  %t62 = load i32, ptr %l3, !tbaa !23
  %t63 = load i32, ptr %l2, !tbaa !23
  %t67 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t61, i32 %t62, i32 %t63)
  store i1 %t67, ptr %l42
  br label %bb16
bb16:
  %t68 = load i1, ptr %l42, !tbaa !21
  br i1 %t68, label %bb17, label %bb18
bb17:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 27
  %t72 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l6
  %t75 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t71, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t72)
  store i1 %t75, ptr %l47
  br label %bb19
bb18:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb24
bb19:
  %t76 = load i1, ptr %l47, !tbaa !21
  br i1 %t76, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb23
bb21:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 29
  %t80 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l6
  %t83 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t79, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t80)
  store i1 %t83, ptr %l52
  br label %bb22
bb22:
  %t84 = load i1, ptr %l52, !tbaa !21
  store i1 %t84, ptr %l48, !tbaa !21
  br label %bb23
bb23:
  %t85 = load i1, ptr %l48, !tbaa !21
  store i1 %t85, ptr %l43, !tbaa !21
  br label %bb24
bb24:
  %t86 = load i1, ptr %l43, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load i32, ptr %l5, !tbaa !23
  %t89 = sext i32 %t87 to i64
  call void @__olang_scope_close(ptr %s3)
  store i64 %t89, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s3)
  br label %bb33
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_1a03149f0250e548_14220af7ccd85b74)
  unreachable
bb33:
  br label %bb55
bb34:
  %t91 = load ptr, ptr %l1, !tbaa !29
  store ptr %t91, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t92 = load ptr, ptr %l55, !tbaa !29
  %t93 = icmp ne ptr %t92, null
  br i1 %t93, label %bb35, label %bb36
bb35:
  %t95 = load ptr, ptr %l55, !tbaa !29
  %t96 = load i64, ptr %t95
  %t98 = icmp eq i64 %t96, 9
  store i1 %t98, ptr %l56, !tbaa !21
  br label %bb36
bb36:
  %t99 = load i1, ptr %l56, !tbaa !21
  br i1 %t99, label %bb37, label %bb38
bb37:
  %t100 = load ptr, ptr %l1, !tbaa !29
  %t102 = getelementptr { i64, [5 x i64] }, ptr %t100, i32 0, i32 1
  %t103 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t102, i32 0, i32 4
  %t104 = load { i64, ptr }, ptr %t103
  store { i64, ptr } %t104, ptr %l7, !tbaa !27
  br label %bb39
bb38:
  br label %bb50
bb39:
  %t106 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t106, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t108 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t108, 0
  store i64 %t110, ptr %l10, !tbaa !24
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s8
  %t112 = load i64, ptr %l9, !tbaa !24
  %t113 = load i64, ptr %l10, !tbaa !24
  %t116 = icmp slt i64 %t112, %t113
  %t118 = xor i1 %t116, true
  br i1 %t118, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s8)
  br label %bb49
bb42:
  br label %bb43
bb43:
  %t120 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t120, ptr %l68, !tbaa !27
  %t121 = load i64, ptr %l9, !tbaa !24
  %t123 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = getelementptr ptr, ptr %t124, i64 %t121
  %t126 = load ptr, ptr %t125, !tbaa !39
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t131 = load i32, ptr %l2, !tbaa !23
  %t135 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralLocalIn(ptr %v0, ptr %v1, ptr %t128, ptr %t126, i32 %t131)
  store i64 %t135, ptr %l75
  br label %bb44
bb44:
  %t136 = load i64, ptr %l75, !tbaa !24
  store i64 %t136, ptr %l12, !tbaa !24
  %t137 = load i64, ptr %l12, !tbaa !24
  %t139 = icmp sge i64 %t137, 0
  br i1 %t139, label %bb45, label %bb46
bb45:
  %t141 = load i64, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  store i64 %t141, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s8)
  br label %bb48
bb48:
  %t143 = load i64, ptr %l9, !tbaa !24
  %t145 = add i64 %t143, 1
  store i64 %t145, ptr %l9, !tbaa !24
  br label %bb40
bb49:
  br label %bb55
bb50:
  br i1 true, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_f003e05343083a19_c7eedaa93b775a5)
  unreachable
bb55:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l10 = alloca i1
  %l14 = alloca i64
  %l23 = alloca i64
  %l28 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l42 = alloca ptr
  %l43 = alloca %"compiler/source:Span"
  %l50 = alloca ptr
  %l55 = alloca i64
  %l60 = alloca ptr
  %l64 = alloca { i64, ptr }
  %l71 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca %"compiler/source:Span"
  %l84 = alloca ptr
  %l87 = alloca ptr
  %l88 = alloca %"compiler/source:Span"
  %l93 = alloca ptr
  %t92 = alloca { i64, [3 x i64] }, align 8
  %t168 = alloca { i64, [3 x i64] }, align 8
  %t191 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Match", ptr %t1, i32 0, i32 2
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t11 = getelementptr %"compiler/ast:Match", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t15 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtName(ptr %v0, ptr %v1, ptr %t8, ptr %t12)
  store i64 %t15, ptr %l14
  br label %bb3
bb2:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb4
bb3:
  %t16 = load i64, ptr %l14, !tbaa !24
  %t17 = icmp sge i64 %t16, 0
  store i1 %t17, ptr %l10, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l10, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load %"compiler/source:Span", ptr %l1
  %t22 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtMatch(ptr %v0, ptr %v1, ptr %t20, %"compiler/source:Span" %t21, ptr %t22)
  br label %bb7
bb6:
  br label %bb8
bb7:
  br label %ret
bb8:
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = getelementptr %"compiler/ast:Match", ptr %t26, i32 0, i32 2
  %t29 = load i1, ptr %t28, !tbaa !21
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t35 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchOnType(ptr %v0, ptr %v1, ptr %t31, ptr %t32)
  store i64 %t35, ptr %l23
  br label %bb11
bb10:
  br label %bb26
bb11:
  %t36 = load i64, ptr %l23, !tbaa !24
  store i64 %t36, ptr %l3, !tbaa !24
  %t37 = load i64, ptr %l3, !tbaa !24
  %t39 = icmp eq i64 %t37, -2
  br i1 %t39, label %bb12, label %bb13
bb12:
  br label %ret
bb13:
  br label %bb14
bb14:
  %t41 = load i64, ptr %l3, !tbaa !24
  %t43 = icmp slt i64 %t41, 0
  br i1 %t43, label %bb15, label %bb16
bb15:
  %t45 = load ptr, ptr %l2, !tbaa !29
  %t47 = getelementptr %"compiler/ast:Match", ptr %t45, i32 0, i32 4
  %t48 = load ptr, ptr %t47, !tbaa !29
  store ptr %t48, ptr %l28, !tbaa !29
  br label %bb17
bb16:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = getelementptr %"compiler/ast:Match", ptr %t50, i32 0, i32 3
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !27
  store { i64, ptr } %t53, ptr %l32, !tbaa !27
  %t54 = load i64, ptr %l3, !tbaa !24
  %t56 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr ptr, ptr %t57, i64 %t54
  %t59 = load ptr, ptr %t58, !tbaa !39
  store ptr %t59, ptr %l28, !tbaa !29
  br label %bb17
bb17:
  %t62 = load ptr, ptr %l28, !tbaa !29
  store ptr %t62, ptr %l4, !tbaa !29
  %t63 = load ptr, ptr %l4, !tbaa !29
  %t65 = icmp eq ptr %t63, null
  br i1 %t65, label %bb18, label %bb19
bb18:
  br label %ret
bb19:
  br label %bb20
bb20:
  %t67 = load ptr, ptr %l4, !tbaa !29
  %t69 = getelementptr %"compiler/ast:Case", ptr %t67, i32 0, i32 4
  %t70 = load { i64, ptr }, ptr %t69, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t70, 0
  %t74 = icmp sgt i64 %t72, 0
  br i1 %t74, label %bb21, label %bb22
bb21:
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l42, !tbaa !29
  %t77 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t77, ptr %l43
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load ptr, ptr %l4, !tbaa !29
  %t81 = getelementptr %"compiler/ast:Case", ptr %t79, i32 0, i32 4
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  %t83 = load ptr, ptr %l4, !tbaa !29
  %t85 = getelementptr %"compiler/ast:Case", ptr %t83, i32 0, i32 0
  %t86 = load %"compiler/source:Span", ptr %t85
  %t91 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eblockOf(ptr %v0, ptr %v1, ptr %t78, { i64, ptr } %t82, i32 1, %"compiler/source:Span" %t86)
  store ptr %t91, ptr %l50
  br label %bb23
bb22:
  br label %bb25
bb23:
  store { i64, [3 x i64] } zeroinitializer, ptr %t92
  %t93 = getelementptr { i64, [3 x i64] }, ptr %t92, i32 0, i32 0
  store i64 11, ptr %t93
  %t94 = load %"compiler/source:Span", ptr %l43
  %t95 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t94, 0
  %t96 = load ptr, ptr %l50, !tbaa !29
  %t97 = insertvalue { %"compiler/source:Span", ptr } %t95, ptr %t96, 1
  %t98 = getelementptr { i64, [3 x i64] }, ptr %t92, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t97, ptr %t98
  %t99 = load { i64, [3 x i64] }, ptr %t92
  %t101 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t99, ptr %t101
  %t102 = load ptr, ptr %l42, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t102, ptr %t101)
  br label %bb24
bb24:
  br label %bb25
bb25:
  br label %ret
bb26:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load ptr, ptr %l2, !tbaa !29
  %t108 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elenMatch(ptr %v0, ptr %v1, ptr %t104, ptr %t105)
  store i64 %t108, ptr %l55
  br label %bb27
bb27:
  %t109 = load i64, ptr %l55, !tbaa !24
  store i64 %t109, ptr %l5, !tbaa !24
  %t110 = load i64, ptr %l5, !tbaa !24
  %t112 = icmp ne i64 %t110, -2
  br i1 %t112, label %bb28, label %bb29
bb28:
  %t114 = load i64, ptr %l5, !tbaa !24
  %t116 = icmp slt i64 %t114, 0
  br i1 %t116, label %bb30, label %bb31
bb29:
  br label %bb41
bb30:
  %t118 = load ptr, ptr %l2, !tbaa !29
  %t120 = getelementptr %"compiler/ast:Match", ptr %t118, i32 0, i32 4
  %t121 = load ptr, ptr %t120, !tbaa !29
  store ptr %t121, ptr %l60, !tbaa !29
  br label %bb32
bb31:
  %t123 = load ptr, ptr %l2, !tbaa !29
  %t125 = getelementptr %"compiler/ast:Match", ptr %t123, i32 0, i32 3
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  store { i64, ptr } %t126, ptr %l64, !tbaa !27
  %t127 = load i64, ptr %l5, !tbaa !24
  %t129 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr ptr, ptr %t130, i64 %t127
  %t132 = load ptr, ptr %t131, !tbaa !39
  store ptr %t132, ptr %l60, !tbaa !29
  br label %bb32
bb32:
  %t135 = load ptr, ptr %l60, !tbaa !29
  store ptr %t135, ptr %l6, !tbaa !29
  %t136 = load ptr, ptr %l6, !tbaa !29
  %t138 = icmp eq ptr %t136, null
  %t140 = xor i1 %t138, true
  br i1 %t140, label %bb33, label %bb34
bb33:
  %t142 = load ptr, ptr %l6, !tbaa !29
  %t144 = getelementptr %"compiler/ast:Case", ptr %t142, i32 0, i32 4
  %t145 = load { i64, ptr }, ptr %t144, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t145, 0
  %t149 = icmp sgt i64 %t147, 0
  store i1 %t149, ptr %l71, !tbaa !21
  br label %bb35
bb34:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb35
bb35:
  %t151 = load i1, ptr %l71, !tbaa !21
  br i1 %t151, label %bb36, label %bb37
bb36:
  %t152 = load ptr, ptr %l0, !tbaa !29
  store ptr %t152, ptr %l76, !tbaa !29
  %t153 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t153, ptr %l77
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load ptr, ptr %l6, !tbaa !29
  %t157 = getelementptr %"compiler/ast:Case", ptr %t155, i32 0, i32 4
  %t158 = load { i64, ptr }, ptr %t157, !tbaa !27
  %t159 = load ptr, ptr %l6, !tbaa !29
  %t161 = getelementptr %"compiler/ast:Case", ptr %t159, i32 0, i32 0
  %t162 = load %"compiler/source:Span", ptr %t161
  %t167 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eblockOf(ptr %v0, ptr %v1, ptr %t154, { i64, ptr } %t158, i32 1, %"compiler/source:Span" %t162)
  store ptr %t167, ptr %l84
  br label %bb38
bb37:
  br label %bb40
bb38:
  store { i64, [3 x i64] } zeroinitializer, ptr %t168
  %t169 = getelementptr { i64, [3 x i64] }, ptr %t168, i32 0, i32 0
  store i64 11, ptr %t169
  %t170 = load %"compiler/source:Span", ptr %l77
  %t171 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t170, 0
  %t172 = load ptr, ptr %l84, !tbaa !29
  %t173 = insertvalue { %"compiler/source:Span", ptr } %t171, ptr %t172, 1
  %t174 = getelementptr { i64, [3 x i64] }, ptr %t168, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t173, ptr %t174
  %t175 = load { i64, [3 x i64] }, ptr %t168
  %t177 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t175, ptr %t177
  %t178 = load ptr, ptr %l76, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t178, ptr %t177)
  br label %bb39
bb39:
  br label %bb40
bb40:
  br label %ret
bb41:
  %t180 = load ptr, ptr %l0, !tbaa !29
  store ptr %t180, ptr %l87, !tbaa !29
  %t181 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t181, ptr %l88
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load %"compiler/source:Span", ptr %l1
  %t184 = load ptr, ptr %l2, !tbaa !29
  %t185 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t190 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchExpr(ptr %v0, ptr %v1, ptr %t182, %"compiler/source:Span" %t183, ptr %t184, i1 false, i32 %t185)
  store ptr %t190, ptr %l93
  br label %bb42
bb42:
  store { i64, [3 x i64] } zeroinitializer, ptr %t191
  %t192 = getelementptr { i64, [3 x i64] }, ptr %t191, i32 0, i32 0
  store i64 2, ptr %t192
  %t193 = load %"compiler/source:Span", ptr %l88
  %t194 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t193, 0
  %t195 = load ptr, ptr %l93, !tbaa !29
  %t196 = insertvalue { %"compiler/source:Span", ptr } %t194, ptr %t195, 1
  %t197 = getelementptr { i64, [3 x i64] }, ptr %t191, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t196, ptr %t197
  %t198 = load { i64, [3 x i64] }, ptr %t191
  %t200 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t198, ptr %t200
  %t201 = load ptr, ptr %l87, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t201, ptr %t200)
  br label %bb43
bb43:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emulti(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca %"compiler/source:Span"
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca %"compiler/source:Span"
  %l41 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l42 = alloca ptr
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l49 = alloca i64
  %l50 = alloca ptr
  %l51 = alloca i64
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca ptr
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i64
  %l72 = alloca ptr
  %l80 = alloca i1
  %l85 = alloca { i64, ptr }
  %l89 = alloca ptr
  %l92 = alloca i32
  %l104 = alloca { i64, ptr }
  %l117 = alloca i32
  %l121 = alloca ptr
  %l123 = alloca { i64, ptr }
  %l125 = alloca %"compiler/source:Span"
  %l128 = alloca { i64, ptr }
  %l130 = alloca %"compiler/msgs:Msg"
  %l131 = alloca i64
  %l140 = alloca { i64, ptr }
  %l151 = alloca ptr
  %l156 = alloca i32
  %l157 = alloca { i64, ptr }
  %l162 = alloca ptr
  %l163 = alloca %"compiler/source:Span"
  %l167 = alloca %"compiler/msgs:Msg"
  %l168 = alloca i64
  %l177 = alloca { i64, ptr }
  %l191 = alloca i64
  %l204 = alloca i64
  %l207 = alloca i64
  %l226 = alloca { i64, ptr }
  %l229 = alloca %"compiler/source:Span"
  %l233 = alloca { i64, ptr }
  %l246 = alloca ptr
  %l249 = alloca { i64, ptr }
  %l255 = alloca { i64, ptr }
  %l265 = alloca ptr
  %l266 = alloca ptr
  %l268 = alloca { i64, ptr }
  %l272 = alloca %"compiler/source:Span"
  %l275 = alloca i64
  %l276 = alloca %"compiler/source:Span"
  %l281 = alloca %"compiler/msgs:Msg"
  %l282 = alloca i64
  %l291 = alloca { i64, ptr }
  %l298 = alloca ptr
  %l307 = alloca i64
  %l310 = alloca i64
  %l330 = alloca { i64, ptr }
  %l335 = alloca ptr
  %l336 = alloca ptr
  %l338 = alloca { i64, ptr }
  %l340 = alloca ptr
  %l341 = alloca ptr
  %l344 = alloca { i64, ptr }
  %l347 = alloca i1
  %l349 = alloca i32
  %l351 = alloca { i64, ptr }
  %l354 = alloca %"compiler/source:Span"
  %l355 = alloca i32
  %l357 = alloca i32
  %l359 = alloca i1
  %l360 = alloca ptr
  %l363 = alloca i32
  %l364 = alloca i1
  %l372 = alloca ptr
  %l375 = alloca { i64, ptr }
  %l382 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l383 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l389 = alloca i64
  %l392 = alloca i64
  %l410 = alloca ptr
  %l413 = alloca { i64, ptr }
  %l416 = alloca ptr
  %l421 = alloca i64
  %l423 = alloca { i64, ptr }
  %l426 = alloca { i64, ptr }
  %l427 = alloca i32
  %l436 = alloca { i64, ptr }
  %l442 = alloca i1
  %l443 = alloca ptr
  %l445 = alloca i32
  %l446 = alloca i1
  %l448 = alloca i1
  %l451 = alloca ptr
  %l453 = alloca i32
  %l454 = alloca i1
  %l467 = alloca i64
  %l470 = alloca i64
  %l490 = alloca ptr
  %l493 = alloca i32
  %l496 = alloca ptr
  %l500 = alloca i32
  %l504 = alloca { i64, ptr }
  %l508 = alloca ptr
  %l509 = alloca ptr
  %l511 = alloca { i64, ptr }
  %l514 = alloca %"compiler/source:Span"
  %l517 = alloca i32
  %l520 = alloca i64
  %l521 = alloca ptr
  %l523 = alloca { i64, ptr }
  %l526 = alloca %"compiler/source:Span"
  %l544 = alloca i64
  %l547 = alloca i64
  %l567 = alloca ptr
  %l570 = alloca ptr
  %l571 = alloca %"compiler/source:Span"
  %l574 = alloca ptr
  %l577 = alloca ptr
  %l578 = alloca ptr
  %l579 = alloca %"compiler/source:Span"
  %l582 = alloca i64
  %l583 = alloca ptr
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %t253 = alloca { i64, [2 x i64] }, align 8
  %t270 = alloca { i64, [3 x i64] }, align 8
  %t361 = alloca { i64, [4 x i64] }, align 8
  %t374 = alloca { i64, [4 x i64] }, align 8
  %t653 = alloca { i64, [4 x i64] }, align 8
  %t967 = alloca { i64, [2 x i64] }, align 8
  %t995 = alloca { i64, [3 x i64] }, align 8
  %t1103 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Multi", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t10 = getelementptr %"compiler/ast:Multi", ptr %t8, i32 0, i32 2
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t15 = icmp eq i64 %t13, 1
  br i1 %t15, label %bb1, label %bb2
bb1:
  %t17 = load i64, ptr %l3, !tbaa !24
  %t19 = icmp sgt i64 %t17, 1
  store i1 %t19, ptr %l80, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb3
bb3:
  %t21 = load i1, ptr %l80, !tbaa !21
  br i1 %t21, label %bb4, label %bb5
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t25 = getelementptr %"compiler/ast:Multi", ptr %t23, i32 0, i32 2
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  store { i64, ptr } %t26, ptr %l85, !tbaa !27
  %t27 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr ptr, ptr %t28, i64 0
  %t30 = load ptr, ptr %t29, !tbaa !39
  %t32 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t36 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t22, ptr %t30, i32 %t32)
  store ptr %t36, ptr %l89
  br label %bb6
bb5:
  br label %bb64
bb6:
  %t37 = load ptr, ptr %l89, !tbaa !29
  store ptr %t37, ptr %l4, !tbaa !29
  %t38 = load ptr, ptr %l4, !tbaa !29
  %t41 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t38)
  store i32 %t41, ptr %l92
  br label %bb7
bb7:
  %t42 = load i32, ptr %l92, !tbaa !23
  store i32 %t42, ptr %l5, !tbaa !23
  %t43 = load i32, ptr %l5, !tbaa !23
  %t44 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t47 = icmp eq i32 %t43, %t44
  br i1 %t47, label %bb8, label %bb9
bb8:
  %t49 = load ptr, ptr %l2, !tbaa !29
  %t51 = getelementptr %"compiler/ast:Multi", ptr %t49, i32 0, i32 0
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  store { i64, ptr } %t52, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t54 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t54, 0
  store i64 %t56, ptr %l8, !tbaa !24
  br label %bb10
bb9:
  br label %bb17
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t58 = load i64, ptr %l7, !tbaa !24
  %t59 = load i64, ptr %l8, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s4)
  br label %bb16
bb12:
  br label %bb13
bb13:
  %t66 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t66, ptr %l104, !tbaa !27
  %t67 = load i64, ptr %l7, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr ptr, ptr %t70, i64 %t67
  %t72 = load ptr, ptr %t71, !tbaa !39
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = load ptr, ptr %l2, !tbaa !29
  %t78 = getelementptr %"compiler/ast:Multi", ptr %t76, i32 0, i32 1
  %t79 = load i1, ptr %t78, !tbaa !21
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclareUnknown(ptr %v0, ptr %v1, ptr %t74, ptr %t72, i1 %t79)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb15
bb15:
  %t83 = load i64, ptr %l7, !tbaa !24
  %t85 = add i64 %t83, 1
  store i64 %t85, ptr %l7, !tbaa !24
  br label %bb10
bb16:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb17:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/check:Checker", ptr %t87, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t92 = getelementptr %"compiler/generic:Program", ptr %t90, i32 0, i32 2
  %t93 = load i32, ptr %l5, !tbaa !23
  %t96 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t92, i32 %t93)
  store i32 %t96, ptr %l117
  br label %bb18
bb18:
  %t97 = load i32, ptr %l117
  %t99 = trunc i64 22 to i32
  %t100 = icmp eq i32 %t97, %t99
  %t102 = xor i1 %t100, true
  br i1 %t102, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s6
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l121, !tbaa !29
  %t105 = load ptr, ptr %l2, !tbaa !29
  %t107 = getelementptr %"compiler/ast:Multi", ptr %t105, i32 0, i32 2
  %t108 = load { i64, ptr }, ptr %t107, !tbaa !27
  store { i64, ptr } %t108, ptr %l123, !tbaa !27
  %t109 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr ptr, ptr %t110, i64 0
  %t112 = load ptr, ptr %t111, !tbaa !39
  %t114 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t112)
  store %"compiler/source:Span" %t114, ptr %l125
  br label %bb21
bb20:
  br label %bb32
bb21:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load i32, ptr %l5, !tbaa !23
  %t119 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s6, ptr %t115, i32 %t116)
  store { i64, ptr } %t119, ptr %l128
  br label %bb22
bb22:
  %t120 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t120, 0
  %t122 = extractvalue { i64, ptr } %t120, 1
  %t123 = mul i64 %t121, 1
  %t124 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t123)
  call void @llvm.memcpy.p0.p0.i64(ptr %t124, ptr %t122, i64 %t123, i1 false)
  %t125 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t124, 1
  %t128 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructOneValue(ptr %s6, ptr %s6, { i64, ptr } %t126)
  store %"compiler/msgs:Msg" %t128, ptr %l130
  br label %bb23
bb23:
  %t129 = load ptr, ptr %l121, !tbaa !29
  %t130 = load %"compiler/source:Span", ptr %l125
  %t131 = load %"compiler/msgs:Msg", ptr %l130
  %t132 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t129, %"compiler/source:Span" %t130, %"compiler/msgs:Msg" %t131)
  store i64 %t132, ptr %l131
  br label %bb24
bb24:
  %t133 = load ptr, ptr %l2, !tbaa !29
  %t135 = getelementptr %"compiler/ast:Multi", ptr %t133, i32 0, i32 0
  %t136 = load { i64, ptr }, ptr %t135, !tbaa !27
  store { i64, ptr } %t136, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t138 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t138, 0
  store i64 %t140, ptr %l12, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s8
  %t142 = load i64, ptr %l11, !tbaa !24
  %t143 = load i64, ptr %l12, !tbaa !24
  %t146 = icmp slt i64 %t142, %t143
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s8)
  br label %bb31
bb27:
  br label %bb28
bb28:
  %t150 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t150, ptr %l140, !tbaa !27
  %t151 = load i64, ptr %l11, !tbaa !24
  %t153 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr ptr, ptr %t154, i64 %t151
  %t156 = load ptr, ptr %t155, !tbaa !39
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = load ptr, ptr %l2, !tbaa !29
  %t162 = getelementptr %"compiler/ast:Multi", ptr %t160, i32 0, i32 1
  %t163 = load i1, ptr %t162, !tbaa !21
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclareUnknown(ptr %v0, ptr %v1, ptr %t158, ptr %t156, i1 %t163)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s8)
  br label %bb30
bb30:
  %t167 = load i64, ptr %l11, !tbaa !24
  %t169 = add i64 %t167, 1
  store i64 %t169, ptr %l11, !tbaa !24
  br label %bb25
bb31:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb32:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/check:Checker", ptr %t171, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !29
  %t176 = getelementptr %"compiler/generic:Program", ptr %t174, i32 0, i32 2
  store ptr %t176, ptr %l151, !tbaa !29
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/check:Checker", ptr %t177, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !29
  %t182 = getelementptr %"compiler/generic:Program", ptr %t180, i32 0, i32 2
  %t183 = load i32, ptr %l5, !tbaa !23
  %t186 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t182, i32 %t183)
  store i32 %t186, ptr %l156
  br label %bb33
bb33:
  %t187 = load ptr, ptr %l151, !tbaa !29
  %t188 = load i32, ptr %l156, !tbaa !23
  %t189 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t187, i32 %t188)
  store { i64, ptr } %t189, ptr %l157
  br label %bb34
bb34:
  %t190 = load { i64, ptr }, ptr %l157, !tbaa !27
  store { i64, ptr } %t190, ptr %l14, !tbaa !27
  %t191 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t191, 0
  %t194 = load i64, ptr %l3, !tbaa !24
  %t197 = icmp ne i64 %t193, %t194
  br i1 %t197, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s10
  %t199 = load ptr, ptr %l0, !tbaa !29
  store ptr %t199, ptr %l162, !tbaa !29
  %t200 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t200, ptr %l163
  %t201 = load i64, ptr %l3, !tbaa !24
  %t202 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t202, 0
  %t207 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructCount(ptr %s10, i64 %t201, i64 %t204)
  store %"compiler/msgs:Msg" %t207, ptr %l167
  br label %bb37
bb36:
  br label %bb46
bb37:
  %t208 = load ptr, ptr %l162, !tbaa !29
  %t209 = load %"compiler/source:Span", ptr %l163
  %t210 = load %"compiler/msgs:Msg", ptr %l167
  %t211 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s10, ptr %t208, %"compiler/source:Span" %t209, %"compiler/msgs:Msg" %t210)
  store i64 %t211, ptr %l168
  br label %bb38
bb38:
  %t212 = load ptr, ptr %l2, !tbaa !29
  %t214 = getelementptr %"compiler/ast:Multi", ptr %t212, i32 0, i32 0
  %t215 = load { i64, ptr }, ptr %t214, !tbaa !27
  store { i64, ptr } %t215, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t217 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t219 = extractvalue { i64, ptr } %t217, 0
  store i64 %t219, ptr %l17, !tbaa !24
  br label %bb39
bb39:
  store %olang.scope zeroinitializer, ptr %s12
  %t221 = load i64, ptr %l16, !tbaa !24
  %t222 = load i64, ptr %l17, !tbaa !24
  %t225 = icmp slt i64 %t221, %t222
  %t227 = xor i1 %t225, true
  br i1 %t227, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s12)
  br label %bb45
bb41:
  br label %bb42
bb42:
  %t229 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t229, ptr %l177, !tbaa !27
  %t230 = load i64, ptr %l16, !tbaa !24
  %t232 = getelementptr { i64, ptr }, ptr %l177, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !27
  %t234 = getelementptr ptr, ptr %t233, i64 %t230
  %t235 = load ptr, ptr %t234, !tbaa !39
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = load ptr, ptr %l2, !tbaa !29
  %t241 = getelementptr %"compiler/ast:Multi", ptr %t239, i32 0, i32 1
  %t242 = load i1, ptr %t241, !tbaa !21
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclareUnknown(ptr %v0, ptr %v1, ptr %t237, ptr %t235, i1 %t242)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s12)
  br label %bb44
bb44:
  %t246 = load i64, ptr %l16, !tbaa !24
  %t248 = add i64 %t246, 1
  store i64 %t248, ptr %l16, !tbaa !24
  br label %bb39
bb45:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb46:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load %"compiler/source:Span", ptr %l1
  %t252 = load i32, ptr %l5, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t253
  %t254 = getelementptr { i64, [2 x i64] }, ptr %t253, i32 0, i32 0
  store i64 0, ptr %t254
  %t255 = load { i64, [2 x i64] }, ptr %t253
  %t261 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t250, i32 0, %"compiler/source:Span" %t251, i32 %t252, i32 2, { i64, [2 x i64] } %t255)
  store i64 %t261, ptr %l191
  br label %bb47
bb47:
  %t262 = load i64, ptr %l191, !tbaa !24
  store i64 %t262, ptr %l19, !tbaa !24
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t264 = load %"compiler/source:Span", ptr %l1
  %t265 = load i64, ptr %l19, !tbaa !24
  %t267 = trunc i64 %t265 to i32
  %t269 = load ptr, ptr %l4, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t270
  %t271 = getelementptr { i64, [3 x i64] }, ptr %t270, i32 0, i32 0
  store i64 0, ptr %t271
  %t273 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t264, 0
  %t275 = insertvalue { %"compiler/source:Span", i32, ptr } %t273, i32 %t267, 1
  %t277 = insertvalue { %"compiler/source:Span", i32, ptr } %t275, ptr %t269, 2
  %t278 = getelementptr { i64, [3 x i64] }, ptr %t270, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t277, ptr %t278
  %t279 = load { i64, [3 x i64] }, ptr %t270
  %t281 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t279, ptr %t281
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t263, ptr %t281)
  br label %bb48
bb48:
  store i64 0, ptr %l20, !tbaa !24
  %t284 = load i64, ptr %l3, !tbaa !24
  store i64 %t284, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t286 = load i64, ptr %l21, !tbaa !24
  %t287 = load i64, ptr %l20, !tbaa !24
  %t290 = icmp sgt i64 %t286, %t287
  br i1 %t290, label %bb49, label %bb50
bb49:
  %t292 = load i64, ptr %l22, !tbaa !24
  %t294 = icmp sgt i64 %t292, 0
  br i1 %t294, label %bb51, label %bb52
bb50:
  store i64 0, ptr %l204, !tbaa !24
  br label %bb54
bb51:
  %t296 = load i64, ptr %l21, !tbaa !24
  %t297 = load i64, ptr %l20, !tbaa !24
  %t300 = sub i64 %t296, %t297
  %t301 = load i64, ptr %l22, !tbaa !24
  %t304 = add i64 %t300, %t301
  %t306 = sub i64 %t304, 1
  %t307 = load i64, ptr %l22, !tbaa !24
  %t310 = sdiv i64 %t306, %t307
  store i64 %t310, ptr %l207, !tbaa !24
  br label %bb53
bb52:
  store i64 0, ptr %l207, !tbaa !24
  br label %bb53
bb53:
  %t312 = load i64, ptr %l207, !tbaa !24
  store i64 %t312, ptr %l204, !tbaa !24
  br label %bb54
bb54:
  %t313 = load i64, ptr %l204, !tbaa !24
  store i64 %t313, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb55
bb55:
  store %olang.scope zeroinitializer, ptr %s15
  %t314 = load i64, ptr %l24, !tbaa !24
  %t315 = load i64, ptr %l23, !tbaa !24
  %t318 = icmp slt i64 %t314, %t315
  %t320 = xor i1 %t318, true
  br i1 %t320, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s15)
  br label %bb63
bb57:
  br label %bb58
bb58:
  %t322 = load i64, ptr %l20, !tbaa !24
  %t323 = load i64, ptr %l24, !tbaa !24
  %t324 = load i64, ptr %l22, !tbaa !24
  %t327 = mul i64 %t323, %t324
  %t330 = add i64 %t322, %t327
  store i64 %t330, ptr %l25, !tbaa !24
  %t332 = load ptr, ptr %l2, !tbaa !29
  %t334 = getelementptr %"compiler/ast:Multi", ptr %t332, i32 0, i32 0
  %t335 = load { i64, ptr }, ptr %t334, !tbaa !27
  store { i64, ptr } %t335, ptr %l226, !tbaa !27
  %t336 = load i64, ptr %l25, !tbaa !24
  %t338 = getelementptr { i64, ptr }, ptr %l226, i32 0, i32 1
  %t339 = load ptr, ptr %t338, !tbaa !27
  %t340 = getelementptr ptr, ptr %t339, i64 %t336
  %t341 = load ptr, ptr %t340, !tbaa !39
  %t343 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t341)
  store %"compiler/source:Span" %t343, ptr %l229
  br label %bb59
bb59:
  %t344 = load %"compiler/source:Span", ptr %l229
  store %"compiler/source:Span" %t344, ptr %l26
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t346 = load %"compiler/source:Span", ptr %l26
  %t347 = load %"compiler/source:Span", ptr %l26
  %t348 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t348, ptr %l233, !tbaa !27
  %t349 = load i64, ptr %l25, !tbaa !24
  %t351 = getelementptr { i64, ptr }, ptr %l233, i32 0, i32 1
  %t352 = load ptr, ptr %t351, !tbaa !27
  %t353 = getelementptr i32, ptr %t352, i64 %t349
  %t354 = load i32, ptr %t353, !tbaa !33
  %t355 = load %"compiler/source:Span", ptr %l26
  %t356 = load i32, ptr %l5, !tbaa !23
  %t357 = load i64, ptr %l19, !tbaa !24
  %t359 = trunc i64 %t357 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t361
  %t362 = getelementptr { i64, [4 x i64] }, ptr %t361, i32 0, i32 0
  store i64 0, ptr %t362
  %t364 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t355, 0
  %t366 = insertvalue { %"compiler/source:Span", i32, i32 } %t364, i32 %t356, 1
  %t368 = insertvalue { %"compiler/source:Span", i32, i32 } %t366, i32 %t359, 2
  %t369 = getelementptr { i64, [4 x i64] }, ptr %t361, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t368, ptr %t369
  %t370 = load { i64, [4 x i64] }, ptr %t361
  %t372 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t370, ptr %t372
  %t373 = load i64, ptr %l25, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t374
  %t375 = getelementptr { i64, [4 x i64] }, ptr %t374, i32 0, i32 0
  store i64 3, ptr %t375
  %t377 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t347, 0
  %t379 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t377, i32 %t354, 1
  %t381 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t379, ptr %t372, 2
  %t383 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t381, i64 %t373, 3
  %t384 = getelementptr { i64, [4 x i64] }, ptr %t374, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t383, ptr %t384
  %t385 = load { i64, [4 x i64] }, ptr %t374
  %t387 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t385, ptr %t387
  %t391 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t345, %"compiler/source:Span" %t346, ptr %t387)
  store ptr %t391, ptr %l246
  br label %bb60
bb60:
  %t392 = load ptr, ptr %l246, !tbaa !29
  %t393 = load ptr, ptr %l0, !tbaa !29
  %t394 = load ptr, ptr %l2, !tbaa !29
  %t396 = getelementptr %"compiler/ast:Multi", ptr %t394, i32 0, i32 0
  %t397 = load { i64, ptr }, ptr %t396, !tbaa !27
  store { i64, ptr } %t397, ptr %l249, !tbaa !27
  %t398 = load i64, ptr %l25, !tbaa !24
  %t400 = getelementptr { i64, ptr }, ptr %l249, i32 0, i32 1
  %t401 = load ptr, ptr %t400, !tbaa !27
  %t402 = getelementptr ptr, ptr %t401, i64 %t398
  %t403 = load ptr, ptr %t402, !tbaa !39
  %t404 = load ptr, ptr %l2, !tbaa !29
  %t406 = getelementptr %"compiler/ast:Multi", ptr %t404, i32 0, i32 1
  %t407 = load i1, ptr %t406, !tbaa !21
  %t409 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t409, ptr %l255, !tbaa !27
  %t410 = load i64, ptr %l25, !tbaa !24
  %t412 = getelementptr { i64, ptr }, ptr %l255, i32 0, i32 1
  %t413 = load ptr, ptr %t412, !tbaa !27
  %t414 = getelementptr i32, ptr %t413, i64 %t410
  %t415 = load i32, ptr %t414, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eputTarget(ptr %v0, ptr %v1, ptr %t393, ptr %t403, i1 %t407, ptr %t392, i32 %t415)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s15)
  br label %bb62
bb62:
  %t421 = load i64, ptr %l24, !tbaa !24
  %t423 = add i64 %t421, 1
  store i64 %t423, ptr %l24, !tbaa !24
  br label %bb55
bb63:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb64:
  %t425 = load ptr, ptr %l2, !tbaa !29
  %t427 = getelementptr %"compiler/ast:Multi", ptr %t425, i32 0, i32 2
  %t428 = load { i64, ptr }, ptr %t427, !tbaa !27
  %t430 = extractvalue { i64, ptr } %t428, 0
  %t431 = load i64, ptr %l3, !tbaa !24
  %t434 = icmp ne i64 %t430, %t431
  br i1 %t434, label %bb65, label %bb66
bb65:
  store %olang.scope zeroinitializer, ptr %s17
  %t436 = load ptr, ptr %l0, !tbaa !29
  store ptr %t436, ptr %l265, !tbaa !29
  %t437 = load ptr, ptr %l0, !tbaa !29
  store ptr %t437, ptr %l266, !tbaa !29
  %t438 = load ptr, ptr %l2, !tbaa !29
  %t440 = getelementptr %"compiler/ast:Multi", ptr %t438, i32 0, i32 0
  %t441 = load { i64, ptr }, ptr %t440, !tbaa !27
  store { i64, ptr } %t441, ptr %l268, !tbaa !27
  %t442 = load i64, ptr %l3, !tbaa !24
  %t444 = sub i64 %t442, 1
  %t446 = getelementptr { i64, ptr }, ptr %l268, i32 0, i32 1
  %t447 = load ptr, ptr %t446, !tbaa !27
  %t448 = getelementptr ptr, ptr %t447, i64 %t444
  %t449 = load ptr, ptr %t448, !tbaa !39
  %t451 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t449)
  store %"compiler/source:Span" %t451, ptr %l272
  br label %bb67
bb66:
  br label %bb81
bb67:
  %t452 = load ptr, ptr %l2, !tbaa !29
  %t454 = getelementptr %"compiler/ast:Multi", ptr %t452, i32 0, i32 1
  %t455 = load i1, ptr %t454, !tbaa !21
  br i1 %t455, label %bb68, label %bb69
bb68:
  store i64 2, ptr %l275, !tbaa !24
  br label %bb70
bb69:
  store i64 1, ptr %l275, !tbaa !24
  br label %bb70
bb70:
  %t457 = load ptr, ptr %l266, !tbaa !29
  %t458 = load %"compiler/source:Span", ptr %l272
  %t459 = load i64, ptr %l275, !tbaa !24
  %t460 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAfter(ptr %v0, ptr %t457, %"compiler/source:Span" %t458, i64 %t459)
  store %"compiler/source:Span" %t460, ptr %l276
  br label %bb71
bb71:
  %t461 = load i64, ptr %l3, !tbaa !24
  %t462 = load ptr, ptr %l2, !tbaa !29
  %t464 = getelementptr %"compiler/ast:Multi", ptr %t462, i32 0, i32 2
  %t465 = load { i64, ptr }, ptr %t464, !tbaa !27
  %t467 = extractvalue { i64, ptr } %t465, 0
  %t470 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssignListCount(ptr %s17, i64 %t461, i64 %t467)
  store %"compiler/msgs:Msg" %t470, ptr %l281
  br label %bb72
bb72:
  %t471 = load ptr, ptr %l265, !tbaa !29
  %t472 = load %"compiler/source:Span", ptr %l276
  %t473 = load %"compiler/msgs:Msg", ptr %l281
  %t474 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s17, ptr %t471, %"compiler/source:Span" %t472, %"compiler/msgs:Msg" %t473)
  store i64 %t474, ptr %l282
  br label %bb73
bb73:
  %t475 = load ptr, ptr %l2, !tbaa !29
  %t477 = getelementptr %"compiler/ast:Multi", ptr %t475, i32 0, i32 2
  %t478 = load { i64, ptr }, ptr %t477, !tbaa !27
  store { i64, ptr } %t478, ptr %l28, !tbaa !27
  store i64 0, ptr %l29, !tbaa !24
  %t480 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t482 = extractvalue { i64, ptr } %t480, 0
  store i64 %t482, ptr %l30, !tbaa !24
  br label %bb74
bb74:
  store %olang.scope zeroinitializer, ptr %s19
  %t484 = load i64, ptr %l29, !tbaa !24
  %t485 = load i64, ptr %l30, !tbaa !24
  %t488 = icmp slt i64 %t484, %t485
  %t490 = xor i1 %t488, true
  br i1 %t490, label %bb75, label %bb76
bb75:
  call void @__olang_scope_close(ptr %s19)
  br label %bb80
bb76:
  br label %bb77
bb77:
  %t492 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t492, ptr %l291, !tbaa !27
  %t493 = load i64, ptr %l29, !tbaa !24
  %t495 = getelementptr { i64, ptr }, ptr %l291, i32 0, i32 1
  %t496 = load ptr, ptr %t495, !tbaa !27
  %t497 = getelementptr ptr, ptr %t496, i64 %t493
  %t498 = load ptr, ptr %t497, !tbaa !39
  %t500 = load ptr, ptr %l0, !tbaa !29
  %t503 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t507 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t500, ptr %t498, i32 %t503)
  store ptr %t507, ptr %l298
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s19)
  br label %bb79
bb79:
  %t508 = load i64, ptr %l29, !tbaa !24
  %t510 = add i64 %t508, 1
  store i64 %t510, ptr %l29, !tbaa !24
  br label %bb74
bb80:
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb81:
  %t512 = load ptr, ptr %l2, !tbaa !29
  %t514 = getelementptr %"compiler/ast:Multi", ptr %t512, i32 0, i32 1
  %t515 = load i1, ptr %t514, !tbaa !21
  br i1 %t515, label %bb82, label %bb83
bb82:
  store i64 0, ptr %l32, !tbaa !24
  %t517 = load i64, ptr %l3, !tbaa !24
  store i64 %t517, ptr %l33, !tbaa !24
  store i64 1, ptr %l34, !tbaa !24
  %t519 = load i64, ptr %l33, !tbaa !24
  %t520 = load i64, ptr %l32, !tbaa !24
  %t523 = icmp sgt i64 %t519, %t520
  br i1 %t523, label %bb84, label %bb85
bb83:
  br label %bb111
bb84:
  %t525 = load i64, ptr %l34, !tbaa !24
  %t527 = icmp sgt i64 %t525, 0
  br i1 %t527, label %bb86, label %bb87
bb85:
  store i64 0, ptr %l307, !tbaa !24
  br label %bb89
bb86:
  %t529 = load i64, ptr %l33, !tbaa !24
  %t530 = load i64, ptr %l32, !tbaa !24
  %t533 = sub i64 %t529, %t530
  %t534 = load i64, ptr %l34, !tbaa !24
  %t537 = add i64 %t533, %t534
  %t539 = sub i64 %t537, 1
  %t540 = load i64, ptr %l34, !tbaa !24
  %t543 = sdiv i64 %t539, %t540
  store i64 %t543, ptr %l310, !tbaa !24
  br label %bb88
bb87:
  store i64 0, ptr %l310, !tbaa !24
  br label %bb88
bb88:
  %t545 = load i64, ptr %l310, !tbaa !24
  store i64 %t545, ptr %l307, !tbaa !24
  br label %bb89
bb89:
  %t546 = load i64, ptr %l307, !tbaa !24
  store i64 %t546, ptr %l35, !tbaa !24
  store i64 0, ptr %l36, !tbaa !24
  br label %bb90
bb90:
  store %olang.scope zeroinitializer, ptr %s23
  %t547 = load i64, ptr %l36, !tbaa !24
  %t548 = load i64, ptr %l35, !tbaa !24
  %t551 = icmp slt i64 %t547, %t548
  %t553 = xor i1 %t551, true
  br i1 %t553, label %bb91, label %bb92
bb91:
  call void @__olang_scope_close(ptr %s23)
  br label %bb110
bb92:
  br label %bb93
bb93:
  %t555 = load i64, ptr %l32, !tbaa !24
  %t556 = load i64, ptr %l36, !tbaa !24
  %t557 = load i64, ptr %l34, !tbaa !24
  %t560 = mul i64 %t556, %t557
  %t563 = add i64 %t555, %t560
  store i64 %t563, ptr %l37, !tbaa !24
  %t565 = load ptr, ptr %l0, !tbaa !29
  %t566 = load ptr, ptr %l2, !tbaa !29
  %t568 = getelementptr %"compiler/ast:Multi", ptr %t566, i32 0, i32 2
  %t569 = load { i64, ptr }, ptr %t568, !tbaa !27
  store { i64, ptr } %t569, ptr %l330, !tbaa !27
  %t570 = load i64, ptr %l37, !tbaa !24
  %t572 = getelementptr { i64, ptr }, ptr %l330, i32 0, i32 1
  %t573 = load ptr, ptr %t572, !tbaa !27
  %t574 = getelementptr ptr, ptr %t573, i64 %t570
  %t575 = load ptr, ptr %t574, !tbaa !39
  %t577 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t581 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t565, ptr %t575, i32 %t577)
  store ptr %t581, ptr %l335
  br label %bb94
bb94:
  %t582 = load ptr, ptr %l335, !tbaa !29
  store ptr %t582, ptr %l38, !tbaa !29
  %t583 = load ptr, ptr %l0, !tbaa !29
  store ptr %t583, ptr %l336, !tbaa !29
  %t584 = load ptr, ptr %l2, !tbaa !29
  %t586 = getelementptr %"compiler/ast:Multi", ptr %t584, i32 0, i32 2
  %t587 = load { i64, ptr }, ptr %t586, !tbaa !27
  store { i64, ptr } %t587, ptr %l338, !tbaa !27
  %t588 = load i64, ptr %l37, !tbaa !24
  %t590 = getelementptr { i64, ptr }, ptr %l338, i32 0, i32 1
  %t591 = load ptr, ptr %t590, !tbaa !27
  %t592 = getelementptr ptr, ptr %t591, i64 %t588
  %t593 = load ptr, ptr %t592, !tbaa !39
  store ptr %t593, ptr %l340, !tbaa !29
  %t594 = load ptr, ptr %l38, !tbaa !29
  store ptr %t594, ptr %l341, !tbaa !29
  %t595 = load ptr, ptr %l0, !tbaa !29
  %t596 = load ptr, ptr %l2, !tbaa !29
  %t598 = getelementptr %"compiler/ast:Multi", ptr %t596, i32 0, i32 0
  %t599 = load { i64, ptr }, ptr %t598, !tbaa !27
  store { i64, ptr } %t599, ptr %l344, !tbaa !27
  %t600 = load i64, ptr %l37, !tbaa !24
  %t602 = getelementptr { i64, ptr }, ptr %l344, i32 0, i32 1
  %t603 = load ptr, ptr %t602, !tbaa !27
  %t604 = getelementptr ptr, ptr %t603, i64 %t600
  %t605 = load ptr, ptr %t604, !tbaa !39
  %t608 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estoredName(ptr %v0, ptr %v1, ptr %t595, ptr %t605)
  store i1 %t608, ptr %l347
  br label %bb95
bb95:
  %t609 = load i1, ptr %l347, !tbaa !21
  %t610 = xor i1 %t609, true
  %t611 = load ptr, ptr %l336, !tbaa !29
  %t612 = load ptr, ptr %l340, !tbaa !29
  %t613 = load ptr, ptr %l341, !tbaa !29
  %t615 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferred(ptr %v0, ptr %v1, ptr %v0, ptr %t611, ptr %t612, ptr %t613, i1 %t610)
  store i32 %t615, ptr %l349
  br label %bb96
bb96:
  %t616 = load i32, ptr %l349, !tbaa !23
  store i32 %t616, ptr %l39, !tbaa !23
  %t617 = load ptr, ptr %l2, !tbaa !29
  %t619 = getelementptr %"compiler/ast:Multi", ptr %t617, i32 0, i32 2
  %t620 = load { i64, ptr }, ptr %t619, !tbaa !27
  store { i64, ptr } %t620, ptr %l351, !tbaa !27
  %t621 = load i64, ptr %l37, !tbaa !24
  %t623 = getelementptr { i64, ptr }, ptr %l351, i32 0, i32 1
  %t624 = load ptr, ptr %t623, !tbaa !27
  %t625 = getelementptr ptr, ptr %t624, i64 %t621
  %t626 = load ptr, ptr %t625, !tbaa !39
  %t628 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t626)
  store %"compiler/source:Span" %t628, ptr %l354
  br label %bb97
bb97:
  %t629 = load %"compiler/source:Span", ptr %l354
  store %"compiler/source:Span" %t629, ptr %l40
  %t630 = load i32, ptr %l39, !tbaa !23
  store i32 %t630, ptr %l355, !tbaa !23
  %t631 = load ptr, ptr %l0, !tbaa !29
  %t633 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t631)
  store i32 %t633, ptr %l357
  br label %bb98
bb98:
  %t634 = load i32, ptr %l355, !tbaa !23
  %t635 = load i32, ptr %l357, !tbaa !23
  %t636 = icmp eq i32 %t634, %t635
  br i1 %t636, label %bb99, label %bb100
bb99:
  %t638 = load ptr, ptr %l0, !tbaa !29
  store ptr %t638, ptr %l360, !tbaa !29
  %t639 = load ptr, ptr %l38, !tbaa !29
  %t642 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t639)
  store i32 %t642, ptr %l363
  br label %bb101
bb100:
  store i1 false, ptr %l359, !tbaa !21
  br label %bb103
bb101:
  %t643 = load ptr, ptr %l360, !tbaa !29
  %t644 = load i32, ptr %l363, !tbaa !23
  %t645 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t643, i32 %t644)
  store i1 %t645, ptr %l364
  br label %bb102
bb102:
  %t646 = load i1, ptr %l364, !tbaa !21
  store i1 %t646, ptr %l359, !tbaa !21
  br label %bb103
bb103:
  %t647 = load i1, ptr %l359, !tbaa !21
  br i1 %t647, label %bb104, label %bb105
bb104:
  %t648 = load ptr, ptr %l0, !tbaa !29
  %t649 = load %"compiler/source:Span", ptr %l40
  %t650 = load %"compiler/source:Span", ptr %l40
  %t651 = load i32, ptr %l39, !tbaa !23
  %t652 = load ptr, ptr %l38, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t653
  %t654 = getelementptr { i64, [4 x i64] }, ptr %t653, i32 0, i32 0
  store i64 2, ptr %t654
  %t656 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t650, 0
  %t658 = insertvalue { %"compiler/source:Span", i32, ptr } %t656, i32 %t651, 1
  %t660 = insertvalue { %"compiler/source:Span", i32, ptr } %t658, ptr %t652, 2
  %t661 = getelementptr { i64, [4 x i64] }, ptr %t653, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t660, ptr %t661
  %t662 = load { i64, [4 x i64] }, ptr %t653
  %t664 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t662, ptr %t664
  %t668 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t648, %"compiler/source:Span" %t649, ptr %t664)
  store ptr %t668, ptr %l372
  br label %bb106
bb105:
  br label %bb107
bb106:
  %t669 = load ptr, ptr %l372, !tbaa !29
  store ptr %t669, ptr %l38, !tbaa !29
  br label %bb107
bb107:
  %t670 = load ptr, ptr %l0, !tbaa !29
  %t671 = load ptr, ptr %l2, !tbaa !29
  %t673 = getelementptr %"compiler/ast:Multi", ptr %t671, i32 0, i32 0
  %t674 = load { i64, ptr }, ptr %t673, !tbaa !27
  store { i64, ptr } %t674, ptr %l375, !tbaa !27
  %t675 = load i64, ptr %l37, !tbaa !24
  %t677 = getelementptr { i64, ptr }, ptr %l375, i32 0, i32 1
  %t678 = load ptr, ptr %t677, !tbaa !27
  %t679 = getelementptr ptr, ptr %t678, i64 %t675
  %t680 = load ptr, ptr %t679, !tbaa !39
  %t681 = load ptr, ptr %l38, !tbaa !29
  %t682 = load i32, ptr %l39, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eputTarget(ptr %v0, ptr %v1, ptr %t670, ptr %t680, i1 true, ptr %t681, i32 %t682)
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s23)
  br label %bb109
bb109:
  %t687 = load i64, ptr %l36, !tbaa !24
  %t689 = add i64 %t687, 1
  store i64 %t689, ptr %l36, !tbaa !24
  br label %bb90
bb110:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb111:
  %t691 = load ptr, ptr @__olang_prog_scope
  %t692 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t691)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t692, ptr %l382
  br label %bb112
bb112:
  %t693 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l382
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t693, ptr %l41
  %t694 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t694, ptr %l383
  br label %bb113
bb113:
  %t695 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l383
  %t696 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t695, ptr %t696
  store ptr %t696, ptr %l42, !tbaa !29
  store i64 0, ptr %l43, !tbaa !24
  %t698 = load i64, ptr %l3, !tbaa !24
  store i64 %t698, ptr %l44, !tbaa !24
  store i64 1, ptr %l45, !tbaa !24
  %t700 = load i64, ptr %l44, !tbaa !24
  %t701 = load i64, ptr %l43, !tbaa !24
  %t704 = icmp sgt i64 %t700, %t701
  br i1 %t704, label %bb114, label %bb115
bb114:
  %t706 = load i64, ptr %l45, !tbaa !24
  %t708 = icmp sgt i64 %t706, 0
  br i1 %t708, label %bb116, label %bb117
bb115:
  store i64 0, ptr %l389, !tbaa !24
  br label %bb119
bb116:
  %t710 = load i64, ptr %l44, !tbaa !24
  %t711 = load i64, ptr %l43, !tbaa !24
  %t714 = sub i64 %t710, %t711
  %t715 = load i64, ptr %l45, !tbaa !24
  %t718 = add i64 %t714, %t715
  %t720 = sub i64 %t718, 1
  %t721 = load i64, ptr %l45, !tbaa !24
  %t724 = sdiv i64 %t720, %t721
  store i64 %t724, ptr %l392, !tbaa !24
  br label %bb118
bb117:
  store i64 0, ptr %l392, !tbaa !24
  br label %bb118
bb118:
  %t726 = load i64, ptr %l392, !tbaa !24
  store i64 %t726, ptr %l389, !tbaa !24
  br label %bb119
bb119:
  %t727 = load i64, ptr %l389, !tbaa !24
  store i64 %t727, ptr %l46, !tbaa !24
  store i64 0, ptr %l47, !tbaa !24
  br label %bb120
bb120:
  store %olang.scope zeroinitializer, ptr %s27
  %t728 = load i64, ptr %l47, !tbaa !24
  %t729 = load i64, ptr %l46, !tbaa !24
  %t732 = icmp slt i64 %t728, %t729
  %t734 = xor i1 %t732, true
  br i1 %t734, label %bb121, label %bb122
bb121:
  call void @__olang_scope_close(ptr %s27)
  br label %bb127
bb122:
  br label %bb123
bb123:
  %t736 = load i64, ptr %l43, !tbaa !24
  %t737 = load i64, ptr %l47, !tbaa !24
  %t738 = load i64, ptr %l45, !tbaa !24
  %t741 = mul i64 %t737, %t738
  %t744 = add i64 %t736, %t741
  %t746 = load ptr, ptr %l42, !tbaa !29
  store ptr %t746, ptr %l410, !tbaa !29
  %t747 = load ptr, ptr %l0, !tbaa !29
  %t748 = load ptr, ptr %l2, !tbaa !29
  %t750 = getelementptr %"compiler/ast:Multi", ptr %t748, i32 0, i32 0
  %t751 = load { i64, ptr }, ptr %t750, !tbaa !27
  store { i64, ptr } %t751, ptr %l413, !tbaa !27
  %t754 = getelementptr { i64, ptr }, ptr %l413, i32 0, i32 1
  %t755 = load ptr, ptr %t754, !tbaa !27
  %t756 = getelementptr ptr, ptr %t755, i64 %t744
  %t757 = load ptr, ptr %t756, !tbaa !39
  %t760 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ediscardOr(ptr %v0, ptr %v1, ptr %t747, ptr %t757)
  store ptr %t760, ptr %l416
  br label %bb124
bb124:
  %t761 = load ptr, ptr %l410, !tbaa !29
  %t762 = load ptr, ptr %l416, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2_H5eacc50cc32d6e41ff62f01e24d943f2(ptr %v0, ptr %v0, ptr %t761, ptr %t762)
  br label %bb125
bb125:
  call void @__olang_scope_close(ptr %s27)
  br label %bb126
bb126:
  %t763 = load i64, ptr %l47, !tbaa !24
  %t765 = add i64 %t763, 1
  store i64 %t765, ptr %l47, !tbaa !24
  br label %bb120
bb127:
  %t767 = load ptr, ptr %l0, !tbaa !29
  %t769 = getelementptr %"compiler/check:Checker", ptr %t767, i32 0, i32 8
  %t771 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2eLe_H7b92c806358c31ec0113c885295670e0(ptr %v0, ptr %t769)
  store i64 %t771, ptr %l421
  br label %bb128
bb128:
  %t772 = load i64, ptr %l421, !tbaa !24
  store i64 %t772, ptr %l49, !tbaa !24
  %t773 = load ptr, ptr %l42, !tbaa !29
  store ptr %t773, ptr %l50, !tbaa !29
  store i64 0, ptr %l51, !tbaa !24
  br label %bb129
bb129:
  store %olang.scope zeroinitializer, ptr %s30
  %t775 = load ptr, ptr %l50, !tbaa !29
  %t776 = load i64, ptr %l51, !tbaa !24
  %t779 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2_H3364bcea7de64bc2b6b83bde1edd9d27(ptr %v0, ptr %t775, i64 %t776)
  %t780 = extractvalue { i32, { i64, ptr } } %t779, 1
  %t781 = extractvalue { i32, { i64, ptr } } %t779, 0
  store i32 %t781, ptr %l427
  %t782 = icmp ne i32 %t781, 0
  br i1 %t782, label %bb131, label %ok.783
ok.783:
  store { i64, ptr } %t780, ptr %l426
  br label %bb130
bb130:
  %t784 = load { i64, ptr }, ptr %l426, !tbaa !27
  store { i64, ptr } %t784, ptr %l423, !tbaa !27
  br label %bb135
bb131:
  %t785 = load i32, ptr %l427, !tbaa !23
  %t786 = ashr i32 %t785, 16
  %t788 = icmp eq i32 %t786, 1
  br i1 %t788, label %bb132, label %bb133
bb132:
  br label %bb134
bb133:
  call void @__olang_check_failed(ptr @olang_loc_476fe22cd4409b92_8ac04c158b99cfe6)
  unreachable
bb134:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s30)
  br label %bb157
bb135:
  %t790 = load { i64, ptr }, ptr %l423, !tbaa !27
  store { i64, ptr } %t790, ptr %l52, !tbaa !27
  %t791 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t793 = extractvalue { i64, ptr } %t791, 0
  store i64 %t793, ptr %l53, !tbaa !24
  store i64 0, ptr %l54, !tbaa !24
  br label %bb136
bb136:
  store %olang.scope zeroinitializer, ptr %s31
  %t795 = load i64, ptr %l54, !tbaa !24
  %t796 = load i64, ptr %l53, !tbaa !24
  %t799 = icmp slt i64 %t795, %t796
  %t801 = xor i1 %t799, true
  br i1 %t801, label %bb137, label %bb138
bb137:
  call void @__olang_scope_close(ptr %s31)
  br label %bb155
bb138:
  br label %bb139
bb139:
  %t803 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t803, ptr %l436, !tbaa !27
  %t804 = load i64, ptr %l54, !tbaa !24
  %t806 = getelementptr { i64, ptr }, ptr %l436, i32 0, i32 1
  %t807 = load ptr, ptr %t806, !tbaa !27
  %t808 = getelementptr ptr, ptr %t807, i64 %t804
  %t809 = load ptr, ptr %t808, !tbaa !39
  store ptr %t809, ptr %l55, !tbaa !29
  %t811 = load ptr, ptr %l55, !tbaa !29
  %t813 = icmp eq ptr %t811, null
  %t815 = xor i1 %t813, true
  br i1 %t815, label %bb140, label %bb141
bb140:
  %t817 = load ptr, ptr %l0, !tbaa !29
  store ptr %t817, ptr %l443, !tbaa !29
  %t818 = load ptr, ptr %l55, !tbaa !29
  %t820 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %t818)
  store i32 %t820, ptr %l445
  br label %bb142
bb141:
  store i1 false, ptr %l442, !tbaa !21
  br label %bb144
bb142:
  %t821 = load ptr, ptr %l443, !tbaa !29
  %t822 = load i32, ptr %l445, !tbaa !23
  %t823 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t821, i32 %t822)
  store i1 %t823, ptr %l446
  br label %bb143
bb143:
  %t824 = load i1, ptr %l446, !tbaa !21
  %t825 = xor i1 %t824, true
  store i1 %t825, ptr %l442, !tbaa !21
  br label %bb144
bb144:
  %t827 = load i1, ptr %l442, !tbaa !21
  br i1 %t827, label %bb145, label %bb146
bb145:
  %t828 = load ptr, ptr %l0, !tbaa !29
  %t830 = getelementptr %"compiler/check:Checker", ptr %t828, i32 0, i32 1
  %t831 = load ptr, ptr %t830, !tbaa !29
  %t833 = getelementptr %"compiler/generic:Program", ptr %t831, i32 0, i32 2
  store ptr %t833, ptr %l451, !tbaa !29
  %t834 = load ptr, ptr %l55, !tbaa !29
  %t836 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %t834)
  store i32 %t836, ptr %l453
  br label %bb147
bb146:
  store i1 false, ptr %l448, !tbaa !21
  br label %bb149
bb147:
  %t837 = load ptr, ptr %l451, !tbaa !29
  %t838 = load i32, ptr %l453, !tbaa !23
  %t839 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t837, i32 %t838)
  store i1 %t839, ptr %l454
  br label %bb148
bb148:
  %t840 = load i1, ptr %l454, !tbaa !21
  store i1 %t840, ptr %l448, !tbaa !21
  br label %bb149
bb149:
  %t841 = load i1, ptr %l448, !tbaa !21
  br i1 %t841, label %bb150, label %bb151
bb150:
  %t842 = load ptr, ptr %l0, !tbaa !29
  %t844 = getelementptr %"compiler/check:Checker", ptr %t842, i32 0, i32 8
  %t845 = load ptr, ptr %l55, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2ePu_H51141c7f79c906b1679ae982392c7956(ptr %v0, ptr %v0, ptr %t844, ptr %t845)
  br label %bb152
bb151:
  br label %bb153
bb152:
  br label %bb153
bb153:
  call void @__olang_scope_close(ptr %s31)
  br label %bb154
bb154:
  %t848 = load i64, ptr %l54, !tbaa !24
  %t850 = add i64 %t848, 1
  store i64 %t850, ptr %l54, !tbaa !24
  br label %bb136
bb155:
  %t852 = load i64, ptr %l51, !tbaa !24
  %t853 = load i64, ptr %l53, !tbaa !24
  %t856 = add i64 %t852, %t853
  store i64 %t856, ptr %l51, !tbaa !24
  call void @__olang_scope_close(ptr %s30)
  br label %bb156
bb156:
  br label %bb129
bb157:
  store i64 0, ptr %l56, !tbaa !24
  %t858 = load i64, ptr %l3, !tbaa !24
  store i64 %t858, ptr %l57, !tbaa !24
  store i64 1, ptr %l58, !tbaa !24
  %t860 = load i64, ptr %l57, !tbaa !24
  %t861 = load i64, ptr %l56, !tbaa !24
  %t864 = icmp sgt i64 %t860, %t861
  br i1 %t864, label %bb158, label %bb159
bb158:
  %t866 = load i64, ptr %l58, !tbaa !24
  %t868 = icmp sgt i64 %t866, 0
  br i1 %t868, label %bb160, label %bb161
bb159:
  store i64 0, ptr %l467, !tbaa !24
  br label %bb163
bb160:
  %t870 = load i64, ptr %l57, !tbaa !24
  %t871 = load i64, ptr %l56, !tbaa !24
  %t874 = sub i64 %t870, %t871
  %t875 = load i64, ptr %l58, !tbaa !24
  %t878 = add i64 %t874, %t875
  %t880 = sub i64 %t878, 1
  %t881 = load i64, ptr %l58, !tbaa !24
  %t884 = sdiv i64 %t880, %t881
  store i64 %t884, ptr %l470, !tbaa !24
  br label %bb162
bb161:
  store i64 0, ptr %l470, !tbaa !24
  br label %bb162
bb162:
  %t886 = load i64, ptr %l470, !tbaa !24
  store i64 %t886, ptr %l467, !tbaa !24
  br label %bb163
bb163:
  %t887 = load i64, ptr %l467, !tbaa !24
  store i64 %t887, ptr %l59, !tbaa !24
  store i64 0, ptr %l60, !tbaa !24
  br label %bb164
bb164:
  store %olang.scope zeroinitializer, ptr %s35
  %t888 = load i64, ptr %l60, !tbaa !24
  %t889 = load i64, ptr %l59, !tbaa !24
  %t892 = icmp slt i64 %t888, %t889
  %t894 = xor i1 %t892, true
  br i1 %t894, label %bb165, label %bb166
bb165:
  call void @__olang_scope_close(ptr %s35)
  br label %bb185
bb166:
  br label %bb167
bb167:
  %t896 = load i64, ptr %l56, !tbaa !24
  %t897 = load i64, ptr %l60, !tbaa !24
  %t898 = load i64, ptr %l58, !tbaa !24
  %t901 = mul i64 %t897, %t898
  %t904 = add i64 %t896, %t901
  store i64 %t904, ptr %l61, !tbaa !24
  %t906 = load ptr, ptr %l42, !tbaa !29
  %t907 = load i64, ptr %l61, !tbaa !24
  %t910 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2_Ha849274baa3792788a1b7c8fee45d023(ptr %v0, ptr %s35, ptr %t906, i64 %t907)
  store ptr %t910, ptr %l490
  br label %bb168
bb168:
  %t911 = load ptr, ptr %l490, !tbaa !29
  %t912 = icmp eq ptr %t911, null
  %t914 = xor i1 %t912, true
  br i1 %t914, label %bb169, label %bb170
bb169:
  %t916 = load ptr, ptr %l42, !tbaa !29
  %t917 = load i64, ptr %l61, !tbaa !24
  %t920 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2_Ha849274baa3792788a1b7c8fee45d023(ptr %v0, ptr %v0, ptr %t916, i64 %t917)
  store ptr %t920, ptr %l496
  br label %bb171
bb170:
  %t921 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t921, ptr %l493, !tbaa !23
  br label %bb176
bb171:
  %t923 = load ptr, ptr %l496, !tbaa !29
  store ptr %t923, ptr %l62, !tbaa !29
  %t924 = load ptr, ptr %l62, !tbaa !29
  %t926 = icmp eq ptr %t924, null
  br i1 %t926, label %bb172, label %bb173
bb172:
  call void @__olang_check_failed(ptr @olang_loc_1e0e3f8e77107efc_26f178b75df49a00)
  unreachable
bb173:
  br label %bb174
bb174:
  %t928 = load ptr, ptr %l62, !tbaa !29
  %t930 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %t928)
  store i32 %t930, ptr %l500
  br label %bb175
bb175:
  %t931 = load i32, ptr %l500, !tbaa !23
  store i32 %t931, ptr %l493, !tbaa !23
  br label %bb176
bb176:
  %t932 = load i32, ptr %l493, !tbaa !23
  %t933 = load ptr, ptr %l0, !tbaa !29
  %t934 = load ptr, ptr %l2, !tbaa !29
  %t936 = getelementptr %"compiler/ast:Multi", ptr %t934, i32 0, i32 2
  %t937 = load { i64, ptr }, ptr %t936, !tbaa !27
  store { i64, ptr } %t937, ptr %l504, !tbaa !27
  %t938 = load i64, ptr %l61, !tbaa !24
  %t940 = getelementptr { i64, ptr }, ptr %l504, i32 0, i32 1
  %t941 = load ptr, ptr %t940, !tbaa !27
  %t942 = getelementptr ptr, ptr %t941, i64 %t938
  %t943 = load ptr, ptr %t942, !tbaa !39
  %t948 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %t933, ptr %t943, i32 %t932)
  store ptr %t948, ptr %l508
  br label %bb177
bb177:
  %t949 = load ptr, ptr %l508, !tbaa !29
  store ptr %t949, ptr %l64, !tbaa !29
  %t950 = load ptr, ptr %l0, !tbaa !29
  store ptr %t950, ptr %l509, !tbaa !29
  %t951 = load ptr, ptr %l2, !tbaa !29
  %t953 = getelementptr %"compiler/ast:Multi", ptr %t951, i32 0, i32 2
  %t954 = load { i64, ptr }, ptr %t953, !tbaa !27
  store { i64, ptr } %t954, ptr %l511, !tbaa !27
  %t955 = load i64, ptr %l61, !tbaa !24
  %t957 = getelementptr { i64, ptr }, ptr %l511, i32 0, i32 1
  %t958 = load ptr, ptr %t957, !tbaa !27
  %t959 = getelementptr ptr, ptr %t958, i64 %t955
  %t960 = load ptr, ptr %t959, !tbaa !39
  %t962 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t960)
  store %"compiler/source:Span" %t962, ptr %l514
  br label %bb178
bb178:
  %t963 = load ptr, ptr %l64, !tbaa !29
  %t966 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t963)
  store i32 %t966, ptr %l517
  br label %bb179
bb179:
  store { i64, [2 x i64] } zeroinitializer, ptr %t967
  %t968 = getelementptr { i64, [2 x i64] }, ptr %t967, i32 0, i32 0
  store i64 0, ptr %t968
  %t969 = load { i64, [2 x i64] }, ptr %t967
  %t970 = load ptr, ptr %l509, !tbaa !29
  %t971 = load %"compiler/source:Span", ptr %l514
  %t972 = load i32, ptr %l517, !tbaa !23
  %t975 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t970, i32 0, %"compiler/source:Span" %t971, i32 %t972, i32 2, { i64, [2 x i64] } %t969)
  store i64 %t975, ptr %l520
  br label %bb180
bb180:
  %t976 = load i64, ptr %l520, !tbaa !24
  store i64 %t976, ptr %l65, !tbaa !24
  %t977 = load ptr, ptr %l0, !tbaa !29
  store ptr %t977, ptr %l521, !tbaa !29
  %t978 = load ptr, ptr %l2, !tbaa !29
  %t980 = getelementptr %"compiler/ast:Multi", ptr %t978, i32 0, i32 2
  %t981 = load { i64, ptr }, ptr %t980, !tbaa !27
  store { i64, ptr } %t981, ptr %l523, !tbaa !27
  %t982 = load i64, ptr %l61, !tbaa !24
  %t984 = getelementptr { i64, ptr }, ptr %l523, i32 0, i32 1
  %t985 = load ptr, ptr %t984, !tbaa !27
  %t986 = getelementptr ptr, ptr %t985, i64 %t982
  %t987 = load ptr, ptr %t986, !tbaa !39
  %t989 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t987)
  store %"compiler/source:Span" %t989, ptr %l526
  br label %bb181
bb181:
  %t990 = load i64, ptr %l65, !tbaa !24
  %t992 = trunc i64 %t990 to i32
  %t994 = load ptr, ptr %l64, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t995
  %t996 = getelementptr { i64, [3 x i64] }, ptr %t995, i32 0, i32 0
  store i64 0, ptr %t996
  %t997 = load %"compiler/source:Span", ptr %l526
  %t998 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t997, 0
  %t1000 = insertvalue { %"compiler/source:Span", i32, ptr } %t998, i32 %t992, 1
  %t1002 = insertvalue { %"compiler/source:Span", i32, ptr } %t1000, ptr %t994, 2
  %t1003 = getelementptr { i64, [3 x i64] }, ptr %t995, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1002, ptr %t1003
  %t1004 = load { i64, [3 x i64] }, ptr %t995
  %t1006 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t1004, ptr %t1006
  %t1007 = load ptr, ptr %l521, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t1007, ptr %t1006)
  br label %bb182
bb182:
  %t1009 = load i64, ptr %l65, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l41, i64 %t1009)
  br label %bb183
bb183:
  call void @__olang_scope_close(ptr %s35)
  br label %bb184
bb184:
  %t1012 = load i64, ptr %l60, !tbaa !24
  %t1014 = add i64 %t1012, 1
  store i64 %t1014, ptr %l60, !tbaa !24
  br label %bb164
bb185:
  %t1016 = load ptr, ptr %l0, !tbaa !29
  %t1018 = getelementptr %"compiler/check:Checker", ptr %t1016, i32 0, i32 8
  %t1019 = load i64, ptr %l49, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2eTr_H7b9b9c82633a95f30e02bffa16283320(ptr %v0, ptr %t1018, i64 %t1019)
  br label %bb186
bb186:
  store i64 0, ptr %l66, !tbaa !24
  %t1022 = load i64, ptr %l3, !tbaa !24
  store i64 %t1022, ptr %l67, !tbaa !24
  store i64 1, ptr %l68, !tbaa !24
  %t1024 = load i64, ptr %l67, !tbaa !24
  %t1025 = load i64, ptr %l66, !tbaa !24
  %t1028 = icmp sgt i64 %t1024, %t1025
  br i1 %t1028, label %bb187, label %bb188
bb187:
  %t1030 = load i64, ptr %l68, !tbaa !24
  %t1032 = icmp sgt i64 %t1030, 0
  br i1 %t1032, label %bb189, label %bb190
bb188:
  store i64 0, ptr %l544, !tbaa !24
  br label %bb192
bb189:
  %t1034 = load i64, ptr %l67, !tbaa !24
  %t1035 = load i64, ptr %l66, !tbaa !24
  %t1038 = sub i64 %t1034, %t1035
  %t1039 = load i64, ptr %l68, !tbaa !24
  %t1042 = add i64 %t1038, %t1039
  %t1044 = sub i64 %t1042, 1
  %t1045 = load i64, ptr %l68, !tbaa !24
  %t1048 = sdiv i64 %t1044, %t1045
  store i64 %t1048, ptr %l547, !tbaa !24
  br label %bb191
bb190:
  store i64 0, ptr %l547, !tbaa !24
  br label %bb191
bb191:
  %t1050 = load i64, ptr %l547, !tbaa !24
  store i64 %t1050, ptr %l544, !tbaa !24
  br label %bb192
bb192:
  %t1051 = load i64, ptr %l544, !tbaa !24
  store i64 %t1051, ptr %l69, !tbaa !24
  store i64 0, ptr %l70, !tbaa !24
  br label %bb193
bb193:
  store %olang.scope zeroinitializer, ptr %s38
  %t1052 = load i64, ptr %l70, !tbaa !24
  %t1053 = load i64, ptr %l69, !tbaa !24
  %t1056 = icmp slt i64 %t1052, %t1053
  %t1058 = xor i1 %t1056, true
  br i1 %t1058, label %bb194, label %bb195
bb194:
  call void @__olang_scope_close(ptr %s38)
  br label %bb209
bb195:
  br label %bb196
bb196:
  %t1060 = load i64, ptr %l66, !tbaa !24
  %t1061 = load i64, ptr %l70, !tbaa !24
  %t1062 = load i64, ptr %l68, !tbaa !24
  %t1065 = mul i64 %t1061, %t1062
  %t1068 = add i64 %t1060, %t1065
  store i64 %t1068, ptr %l71, !tbaa !24
  %t1070 = load ptr, ptr %l42, !tbaa !29
  %t1071 = load i64, ptr %l71, !tbaa !24
  %t1074 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2_Ha849274baa3792788a1b7c8fee45d023(ptr %v0, ptr %s38, ptr %t1070, i64 %t1071)
  store ptr %t1074, ptr %l567
  br label %bb197
bb197:
  %t1075 = load ptr, ptr %l567, !tbaa !29
  %t1076 = icmp eq ptr %t1075, null
  %t1078 = xor i1 %t1076, true
  br i1 %t1078, label %bb198, label %bb199
bb198:
  %t1080 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1080, ptr %l570, !tbaa !29
  %t1081 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1081, ptr %l571
  %t1082 = load ptr, ptr %l42, !tbaa !29
  %t1083 = load i64, ptr %l71, !tbaa !24
  %t1086 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2_Ha849274baa3792788a1b7c8fee45d023(ptr %v0, ptr %v0, ptr %t1082, i64 %t1083)
  store ptr %t1086, ptr %l574
  br label %bb200
bb199:
  br label %bb207
bb200:
  %t1087 = load ptr, ptr %l574, !tbaa !29
  store ptr %t1087, ptr %l72, !tbaa !29
  %t1088 = load ptr, ptr %l72, !tbaa !29
  %t1090 = icmp eq ptr %t1088, null
  br i1 %t1090, label %bb201, label %bb202
bb201:
  call void @__olang_check_failed(ptr @olang_loc_c3a1911177000af1_d7f4a899cd404215)
  unreachable
bb202:
  br label %bb203
bb203:
  %t1092 = load ptr, ptr %l72, !tbaa !29
  store ptr %t1092, ptr %l577, !tbaa !29
  %t1093 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1093, ptr %l578, !tbaa !29
  %t1094 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1094, ptr %l579
  %t1095 = load i64, ptr %l71, !tbaa !24
  %t1098 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l41, i64 %t1095)
  store i64 %t1098, ptr %l582
  br label %bb204
bb204:
  %t1099 = load ptr, ptr %l578, !tbaa !29
  %t1100 = load %"compiler/source:Span", ptr %l579
  %t1101 = load i64, ptr %l582, !tbaa !24
  %t1102 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t1099, %"compiler/source:Span" %t1100, i64 %t1101)
  store ptr %t1102, ptr %l583
  br label %bb205
bb205:
  store { i64, [3 x i64] } zeroinitializer, ptr %t1103
  %t1104 = getelementptr { i64, [3 x i64] }, ptr %t1103, i32 0, i32 0
  store i64 1, ptr %t1104
  %t1105 = load %"compiler/source:Span", ptr %l571
  %t1106 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t1105, 0
  %t1107 = load ptr, ptr %l577, !tbaa !29
  %t1108 = insertvalue { %"compiler/source:Span", ptr, ptr } %t1106, ptr %t1107, 1
  %t1109 = load ptr, ptr %l583, !tbaa !29
  %t1110 = insertvalue { %"compiler/source:Span", ptr, ptr } %t1108, ptr %t1109, 2
  %t1111 = getelementptr { i64, [3 x i64] }, ptr %t1103, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t1110, ptr %t1111
  %t1112 = load { i64, [3 x i64] }, ptr %t1103
  %t1114 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t1112, ptr %t1114
  %t1115 = load ptr, ptr %l570, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t1115, ptr %t1114)
  br label %bb206
bb206:
  br label %bb207
bb207:
  call void @__olang_scope_close(ptr %s38)
  br label %bb208
bb208:
  %t1117 = load i64, ptr %l70, !tbaa !24
  %t1119 = add i64 %t1117, 1
  store i64 %t1119, ptr %l70, !tbaa !24
  br label %bb193
bb209:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutBefore(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %l21 = alloca i1
  %l23 = alloca %"compiler/source:Span"
  %l26 = alloca i1
  %l27 = alloca %"compiler/source:Span"
  %l31 = alloca i1
  %l34 = alloca i1
  %l35 = alloca i1
  %l40 = alloca i32
  %l43 = alloca %"compiler/source:Span"
  %l47 = alloca i1
  %l49 = alloca %"compiler/source:Span"
  %l54 = alloca i1
  %l57 = alloca i1
  %l58 = alloca %"compiler/source:Span"
  %l62 = alloca %"compiler/source:Span"
  %l63 = alloca %"compiler/source:Span"
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 4
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l3
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t18, i32 0, i32 1
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l4, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t24, i32 0, i32 2
  %t26 = load i1, ptr %t25
  store i1 %t26, ptr %l5, !tbaa !21
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t30, i32 0, i32 3
  %t32 = load i1, ptr %t31
  store i1 %t32, ptr %l6, !tbaa !21
  br label %bb5
bb4:
  br label %bb43
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t34 = load i1, ptr %l5, !tbaa !21
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb8
bb7:
  %t38 = load i1, ptr %l6, !tbaa !21
  store i1 %t38, ptr %l21, !tbaa !21
  br label %bb8
bb8:
  %t40 = load i1, ptr %l21, !tbaa !21
  br i1 %t40, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s2, i32 -1, i32 -1)
  store %"compiler/source:Span" %t41, ptr %l23
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  %t42 = load %"compiler/source:Span", ptr %l23
  store %"compiler/source:Span" %t42, ptr %rv
  br label %ret
bb12:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l4, !tbaa !29
  %t47 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesTypeVar(ptr %v0, ptr %v1, ptr %t43, ptr %t44)
  store i1 %t47, ptr %l26
  br label %bb13
bb13:
  %t48 = load i1, ptr %l26, !tbaa !21
  br i1 %t48, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t49 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s3, i32 -1, i32 -1)
  store %"compiler/source:Span" %t49, ptr %l27
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s1)
  %t50 = load %"compiler/source:Span", ptr %l27
  store %"compiler/source:Span" %t50, ptr %rv
  br label %ret
bb17:
  %t51 = load i32, ptr %l2, !tbaa !23
  %t52 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t55 = icmp ne i32 %t51, %t52
  br i1 %t55, label %bb18, label %bb19
bb18:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load i32, ptr %l2, !tbaa !23
  %t61 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t57, i32 %t58)
  store i1 %t61, ptr %l34
  br label %bb20
bb19:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb25
bb20:
  %t62 = load i1, ptr %l34, !tbaa !21
  br i1 %t62, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb24
bb22:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  %t69 = load i32, ptr %l2, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t68, i32 %t69)
  store i32 %t72, ptr %l40
  br label %bb23
bb23:
  %t73 = load i32, ptr %l40
  %t75 = trunc i64 25 to i32
  %t76 = icmp eq i32 %t73, %t75
  store i1 %t76, ptr %l35, !tbaa !21
  br label %bb24
bb24:
  %t78 = load i1, ptr %l35, !tbaa !21
  store i1 %t78, ptr %l31, !tbaa !21
  br label %bb25
bb25:
  %t79 = load i1, ptr %l31, !tbaa !21
  br i1 %t79, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  %t80 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s4, i32 -1, i32 -1)
  store %"compiler/source:Span" %t80, ptr %l43
  br label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s1)
  %t81 = load %"compiler/source:Span", ptr %l43
  store %"compiler/source:Span" %t81, ptr %rv
  br label %ret
bb29:
  %t82 = load i32, ptr %l2, !tbaa !23
  %t83 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t86 = icmp eq i32 %t82, %t83
  br i1 %t86, label %bb30, label %bb31
bb30:
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t88)
  store %"compiler/source:Span" %t90, ptr %l49
  br label %bb32
bb31:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb33
bb32:
  %t91 = getelementptr %"compiler/source:Span", ptr %l49, i32 0, i32 1
  %t92 = load i32, ptr %t91, !tbaa !23
  %t93 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t94 = load i32, ptr %t93, !tbaa !23
  %t96 = add i32 %t94, 3
  %t99 = icmp sgt i32 %t92, %t96
  store i1 %t99, ptr %l47, !tbaa !21
  br label %bb33
bb33:
  %t101 = load i1, ptr %l47, !tbaa !21
  br i1 %t101, label %bb34, label %bb35
bb34:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t106 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenRefOrVar(ptr %v0, ptr %v1, ptr %t102, ptr %t103)
  store i1 %t106, ptr %l57
  br label %bb36
bb35:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb37
bb36:
  %t107 = load i1, ptr %l57, !tbaa !21
  store i1 %t107, ptr %l54, !tbaa !21
  br label %bb37
bb37:
  %t108 = load i1, ptr %l54, !tbaa !21
  br i1 %t108, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s5
  %t109 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s5, i32 -1, i32 -1)
  store %"compiler/source:Span" %t109, ptr %l58
  br label %bb40
bb39:
  br label %bb41
bb40:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s1)
  %t110 = load %"compiler/source:Span", ptr %l58
  store %"compiler/source:Span" %t110, ptr %rv
  br label %ret
bb41:
  %t111 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t112 = load i32, ptr %t111, !tbaa !23
  %t113 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t114 = load i32, ptr %t113, !tbaa !23
  %t116 = add i32 %t114, 3
  %t119 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 %t112, i32 %t116)
  store %"compiler/source:Span" %t119, ptr %l62
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s1)
  %t120 = load %"compiler/source:Span", ptr %l62
  store %"compiler/source:Span" %t120, ptr %rv
  br label %ret
bb43:
  store %olang.scope zeroinitializer, ptr %s6
  %t121 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s6, i32 -1, i32 -1)
  store %"compiler/source:Span" %t121, ptr %l63
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s6)
  %t122 = load %"compiler/source:Span", ptr %l63
  store %"compiler/source:Span" %t122, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowedName(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca i64
  %l19 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l3, !tbaa !23
  %t20 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t16, i32 %t17)
  store i64 %t20, ptr %l13
  br label %bb6
bb6:
  %t21 = load i64, ptr %l13, !tbaa !24
  store i64 %t21, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = icmp sge i64 %t22, 0
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i64, ptr %l4, !tbaa !24
  %t32 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowedField(ptr %v0, ptr %t26, i64 %t27, i32 %a2)
  store i64 %t32, ptr %l19
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t33 = load i64, ptr %l19, !tbaa !24
  store i64 %t33, ptr %rv
  br label %ret
bb10:
  br label %bb12
bb11:
  br label %bb12
bb12:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotStmtSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i1
  %l17 = alloca ptr
  %l19 = alloca %"compiler/source:Span"
  %l21 = alloca %"compiler/source:Span"
  %l23 = alloca { i64, ptr }
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca ptr
  %l27 = alloca i1
  %l34 = alloca %"compiler/source:Span"
  %l37 = alloca { i64, ptr }
  %l39 = alloca %"compiler/source:Span"
  %l41 = alloca %"compiler/source:Span"
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t24, i32 0, i32 3
  %t26 = load ptr, ptr %t25
  store ptr %t26, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb10
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l17, !tbaa !29
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t29)
  store %"compiler/source:Span" %t31, ptr %l19
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t32)
  store %"compiler/source:Span" %t34, ptr %l21
  br label %bb7
bb7:
  %t35 = load i32, ptr %l2
  %t37 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s1, i32 %t35)
  store { i64, ptr } %t37, ptr %l23
  br label %bb8
bb8:
  %t38 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  %t40 = load ptr, ptr %l17, !tbaa !29
  %t41 = load %"compiler/source:Span", ptr %l19
  %t42 = load %"compiler/source:Span", ptr %l21
  %t44 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t40, %"compiler/source:Span" %t41, %"compiler/source:Span" %t42, i64 %t39)
  store %"compiler/source:Span" %t44, ptr %l25
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  %t45 = load %"compiler/source:Span", ptr %l25
  store %"compiler/source:Span" %t45, ptr %rv
  br label %ret
bb10:
  %t46 = load ptr, ptr %l1, !tbaa !29
  store ptr %t46, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t47 = load ptr, ptr %l26, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb11, label %bb12
bb11:
  %t50 = load ptr, ptr %l26, !tbaa !29
  %t51 = load i64, ptr %t50
  %t53 = icmp eq i64 %t51, 15
  store i1 %t53, ptr %l27, !tbaa !21
  br label %bb12
bb12:
  %t54 = load i1, ptr %l27, !tbaa !21
  br i1 %t54, label %bb13, label %bb14
bb13:
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr { i64, [5 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t57, i32 0, i32 0
  %t59 = load %"compiler/source:Span", ptr %t58
  store %"compiler/source:Span" %t59, ptr %l5
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr { i64, [5 x i64] }, ptr %t61, i32 0, i32 1
  %t64 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t63, i32 0, i32 2
  %t65 = load i32, ptr %t64
  store i32 %t65, ptr %l6, !tbaa !23
  br label %bb15
bb14:
  br label %bb18
bb15:
  %t67 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t67, ptr %l34
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i32, ptr %l6, !tbaa !23
  %t72 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t68, i32 %t69)
  store { i64, ptr } %t72, ptr %l37
  br label %bb16
bb16:
  %t73 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 0
  %t75 = load %"compiler/source:Span", ptr %l34
  %t77 = call %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %t75, i64 %t74)
  store %"compiler/source:Span" %t77, ptr %l39
  br label %bb17
bb17:
  %t78 = load %"compiler/source:Span", ptr %l39
  store %"compiler/source:Span" %t78, ptr %rv
  br label %ret
bb18:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t79)
  store %"compiler/source:Span" %t81, ptr %l41
  br label %bb19
bb19:
  %t82 = load %"compiler/source:Span", ptr %l41
  store %"compiler/source:Span" %t82, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceWritable(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l18 = alloca ptr
  %l20 = alloca %"compiler/typed:Local"
  %l23 = alloca i1
  %l24 = alloca ptr
  %l26 = alloca ptr
  %l28 = alloca %"compiler/typed:Local"
  %l30 = alloca i1
  %l33 = alloca i1
  %l37 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l51 = alloca ptr
  %l53 = alloca i1
  %l58 = alloca ptr
  %l64 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i1
  %l73 = alloca ptr
  %l76 = alloca i32
  %l77 = alloca i64
  %l81 = alloca ptr
  %l82 = alloca i1
  %l89 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca i1
  %l99 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l109 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb18
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t16)
  store ptr %t18, ptr %l18
  br label %bb6
bb6:
  %t19 = load i32, ptr %l2, !tbaa !23
  %t20 = load ptr, ptr %l18, !tbaa !29
  %t22 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t20, i32 %t19)
  store %"compiler/typed:Local" %t22, ptr %l20
  br label %bb7
bb7:
  %t23 = getelementptr %"compiler/typed:Local", ptr %l20, i32 0, i32 4
  %t24 = load i32, ptr %t23
  %t26 = trunc i64 5 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb8, label %bb9
bb8:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l24, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t30)
  store ptr %t32, ptr %l26
  br label %bb10
bb9:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb13
bb10:
  %t33 = load i32, ptr %l2, !tbaa !23
  %t34 = load ptr, ptr %l26, !tbaa !29
  %t36 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t34, i32 %t33)
  store %"compiler/typed:Local" %t36, ptr %l28
  br label %bb11
bb11:
  %t37 = getelementptr %"compiler/typed:Local", ptr %l28, i32 0, i32 2
  %t38 = load i32, ptr %t37, !tbaa !23
  %t39 = load ptr, ptr %l24, !tbaa !29
  %t41 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t39, i32 %t38)
  store i1 %t41, ptr %l30
  br label %bb12
bb12:
  %t42 = load i1, ptr %l30, !tbaa !21
  %t43 = xor i1 %t42, true
  store i1 %t43, ptr %l23, !tbaa !21
  br label %bb13
bb13:
  %t45 = load i1, ptr %l23, !tbaa !21
  %t46 = xor i1 %t45, true
  br i1 %t46, label %bb14, label %bb15
bb14:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load i32, ptr %l2, !tbaa !23
  %t51 = sext i32 %t49 to i64
  %t54 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLocal(ptr %v0, ptr %t48, i64 %t51)
  store i1 %t54, ptr %l37
  br label %bb16
bb15:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb17
bb16:
  %t55 = load i1, ptr %l37, !tbaa !21
  %t56 = xor i1 %t55, true
  store i1 %t56, ptr %l33, !tbaa !21
  br label %bb17
bb17:
  %t58 = load i1, ptr %l33, !tbaa !21
  store i1 %t58, ptr %l10, !tbaa !21
  br label %bb67
bb18:
  %t59 = load ptr, ptr %l1, !tbaa !29
  store ptr %t59, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t60 = load ptr, ptr %l39, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb19, label %bb20
bb19:
  %t63 = load ptr, ptr %l39, !tbaa !29
  %t64 = load i64, ptr %t63
  %t66 = icmp eq i64 %t64, 1
  store i1 %t66, ptr %l40, !tbaa !21
  br label %bb20
bb20:
  %t67 = load i1, ptr %l40, !tbaa !21
  br i1 %t67, label %bb21, label %bb22
bb21:
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [4 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t70, i32 0, i32 2
  %t72 = load i64, ptr %t71
  store i64 %t72, ptr %l3, !tbaa !24
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t76, i32 0, i32 3
  %t78 = load i32, ptr %t77
  store i32 %t78, ptr %l4, !tbaa !23
  br label %bb23
bb22:
  br label %bb33
bb23:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/check:Checker", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t84 = load i64, ptr %l3, !tbaa !24
  %t85 = load i32, ptr %l4, !tbaa !23
  %t89 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %t83, i64 %t84, i32 %t85)
  store ptr %t89, ptr %l51
  br label %bb24
bb24:
  %t90 = load ptr, ptr %l51, !tbaa !29
  %t91 = icmp eq ptr %t90, null
  br i1 %t91, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb32
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t97 = load i64, ptr %l3, !tbaa !24
  %t98 = load i32, ptr %l4, !tbaa !23
  %t102 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %t96, i64 %t97, i32 %t98)
  store ptr %t102, ptr %l58
  br label %bb27
bb27:
  %t103 = load ptr, ptr %l58, !tbaa !29
  store ptr %t103, ptr %l5, !tbaa !29
  %t104 = load ptr, ptr %l5, !tbaa !29
  %t106 = icmp eq ptr %t104, null
  br i1 %t106, label %bb28, label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_24dda45681d8cee1_6133aaee564c4ee5)
  unreachable
bb29:
  br label %bb30
bb30:
  %t108 = load ptr, ptr %l5, !tbaa !29
  %t111 = getelementptr %"compiler/ast:VarDecl", ptr %t108, i32 0, i32 2
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = call i1 @compiler_2fcheck_2ewrittenMut(ptr %v0, ptr %t112)
  store i1 %t114, ptr %l64
  br label %bb31
bb31:
  %t115 = load i1, ptr %l64, !tbaa !21
  store i1 %t115, ptr %l53, !tbaa !21
  br label %bb32
bb32:
  %t116 = load i1, ptr %l53, !tbaa !21
  store i1 %t116, ptr %l10, !tbaa !21
  br label %bb67
bb33:
  %t117 = load ptr, ptr %l1, !tbaa !29
  store ptr %t117, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t118 = load ptr, ptr %l65, !tbaa !29
  %t119 = icmp ne ptr %t118, null
  br i1 %t119, label %bb34, label %bb35
bb34:
  %t121 = load ptr, ptr %l65, !tbaa !29
  %t122 = load i64, ptr %t121
  %t124 = icmp eq i64 %t122, 2
  store i1 %t124, ptr %l66, !tbaa !21
  br label %bb35
bb35:
  %t125 = load i1, ptr %l66, !tbaa !21
  br i1 %t125, label %bb36, label %bb37
bb36:
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t128 = getelementptr { i64, [4 x i64] }, ptr %t126, i32 0, i32 1
  %t129 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t128, i32 0, i32 2
  %t130 = load ptr, ptr %t129
  store ptr %t130, ptr %l6, !tbaa !29
  br label %bb38
bb37:
  br label %bb41
bb38:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/check:Checker", ptr %t132, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t137 = getelementptr %"compiler/generic:Program", ptr %t135, i32 0, i32 2
  store ptr %t137, ptr %l73, !tbaa !29
  %t138 = load ptr, ptr %l6, !tbaa !29
  %t141 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t138)
  store i32 %t141, ptr %l76
  br label %bb39
bb39:
  %t142 = load ptr, ptr %l73, !tbaa !29
  %t143 = load i32, ptr %l76, !tbaa !23
  %t144 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t142, i32 %t143)
  store i64 %t144, ptr %l77
  br label %bb40
bb40:
  %t145 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t146 = load i64, ptr %l77, !tbaa !24
  %t148 = and i64 %t146, %t145
  %t150 = icmp ne i64 %t148, 0
  store i1 %t150, ptr %l10, !tbaa !21
  br label %bb67
bb41:
  %t152 = load ptr, ptr %l1, !tbaa !29
  store ptr %t152, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t153 = load ptr, ptr %l81, !tbaa !29
  %t154 = icmp ne ptr %t153, null
  br i1 %t154, label %bb42, label %bb43
bb42:
  %t156 = load ptr, ptr %l81, !tbaa !29
  %t157 = load i64, ptr %t156
  %t159 = icmp eq i64 %t157, 3
  store i1 %t159, ptr %l82, !tbaa !21
  br label %bb43
bb43:
  %t160 = load i1, ptr %l82, !tbaa !21
  br i1 %t160, label %bb44, label %bb45
bb44:
  %t161 = load ptr, ptr %l1, !tbaa !29
  %t163 = getelementptr { i64, [4 x i64] }, ptr %t161, i32 0, i32 1
  %t164 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t163, i32 0, i32 2
  %t165 = load ptr, ptr %t164
  store ptr %t165, ptr %l7, !tbaa !29
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load ptr, ptr %l7, !tbaa !29
  %t171 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceWritable(ptr %v0, ptr %v1, ptr %t167, ptr %t168)
  store i1 %t171, ptr %l89
  br label %bb47
bb47:
  %t172 = load i1, ptr %l89, !tbaa !21
  store i1 %t172, ptr %l10, !tbaa !21
  br label %bb67
bb48:
  %t173 = load ptr, ptr %l1, !tbaa !29
  store ptr %t173, ptr %l90, !tbaa !29
  store i1 false, ptr %l91, !tbaa !21
  %t174 = load ptr, ptr %l90, !tbaa !29
  %t175 = icmp ne ptr %t174, null
  br i1 %t175, label %bb49, label %bb50
bb49:
  %t177 = load ptr, ptr %l90, !tbaa !29
  %t178 = load i64, ptr %t177
  %t180 = icmp eq i64 %t178, 4
  store i1 %t180, ptr %l91, !tbaa !21
  br label %bb50
bb50:
  %t181 = load i1, ptr %l91, !tbaa !21
  br i1 %t181, label %bb51, label %bb52
bb51:
  %t182 = load ptr, ptr %l1, !tbaa !29
  %t184 = getelementptr { i64, [4 x i64] }, ptr %t182, i32 0, i32 1
  %t185 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t184, i32 0, i32 2
  %t186 = load ptr, ptr %t185
  store ptr %t186, ptr %l8, !tbaa !29
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load ptr, ptr %l8, !tbaa !29
  %t191 = getelementptr %"compiler/typed:Elem", ptr %t189, i32 0, i32 0
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t195 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceWritable(ptr %v0, ptr %v1, ptr %t188, ptr %t192)
  store i1 %t195, ptr %l99
  br label %bb54
bb54:
  %t196 = load i1, ptr %l99, !tbaa !21
  store i1 %t196, ptr %l10, !tbaa !21
  br label %bb67
bb55:
  %t197 = load ptr, ptr %l1, !tbaa !29
  store ptr %t197, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t198 = load ptr, ptr %l100, !tbaa !29
  %t199 = icmp ne ptr %t198, null
  br i1 %t199, label %bb56, label %bb57
bb56:
  %t201 = load ptr, ptr %l100, !tbaa !29
  %t202 = load i64, ptr %t201
  %t204 = icmp eq i64 %t202, 5
  store i1 %t204, ptr %l101, !tbaa !21
  br label %bb57
bb57:
  %t205 = load i1, ptr %l101, !tbaa !21
  br i1 %t205, label %bb58, label %bb59
bb58:
  %t206 = load ptr, ptr %l1, !tbaa !29
  %t208 = getelementptr { i64, [4 x i64] }, ptr %t206, i32 0, i32 1
  %t209 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t208, i32 0, i32 2
  %t210 = load ptr, ptr %t209
  store ptr %t210, ptr %l9, !tbaa !29
  br label %bb60
bb59:
  br label %bb62
bb60:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load ptr, ptr %l9, !tbaa !29
  %t215 = getelementptr %"compiler/typed:Payload", ptr %t213, i32 0, i32 0
  %t216 = load ptr, ptr %t215, !tbaa !29
  %t219 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceWritable(ptr %v0, ptr %v1, ptr %t212, ptr %t216)
  store i1 %t219, ptr %l109
  br label %bb61
bb61:
  %t220 = load i1, ptr %l109, !tbaa !21
  store i1 %t220, ptr %l10, !tbaa !21
  br label %bb67
bb62:
  br i1 true, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb66
bb65:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb67
bb66:
  call void @__olang_check_failed(ptr @olang_loc_f10316e290a7e1b9_b7814005b7d82bcd)
  unreachable
bb67:
  %t221 = load i1, ptr %l10, !tbaa !21
  store i1 %t221, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainStruct(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l9 = alloca i1
  %l12 = alloca i1
  %l14 = alloca i1
  %l17 = alloca i32
  %l21 = alloca i1
  %l25 = alloca i1
  %l32 = alloca i1
  %l36 = alloca ptr
  %l41 = alloca i32
  %l42 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l56 = alloca i1
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr %l1, !tbaa !23
  %t9 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l12
  br label %bb3
bb3:
  %t10 = load i1, ptr %l12, !tbaa !21
  %t11 = xor i1 %t10, true
  store i1 %t11, ptr %l9, !tbaa !21
  br label %bb4
bb4:
  %t13 = load i1, ptr %l9, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb8
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l1, !tbaa !23
  %t18 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t14, i32 %t15)
  store i32 %t18, ptr %l17
  br label %bb7
bb7:
  %t19 = load i32, ptr %l17
  %t21 = trunc i64 0 to i32
  %t22 = icmp eq i32 %t19, %t21
  %t24 = xor i1 %t22, true
  store i1 %t24, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l14, !tbaa !21
  br i1 %t26, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb12
bb10:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t31 = load i32, ptr %l1, !tbaa !23
  %t34 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t30, i32 %t31)
  store i1 %t34, ptr %l25
  br label %bb11
bb11:
  %t35 = load i1, ptr %l25, !tbaa !21
  %t36 = xor i1 %t35, true
  store i1 %t36, ptr %l21, !tbaa !21
  br label %bb12
bb12:
  %t38 = load i1, ptr %l21, !tbaa !21
  br i1 %t38, label %bb13, label %bb14
bb13:
  store i1 false, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/check:Checker", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/generic:Program", ptr %t43, i32 0, i32 2
  %t46 = load i32, ptr %l1, !tbaa !23
  %t49 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t45, i32 %t46)
  store i1 %t49, ptr %l32
  br label %bb16
bb16:
  %t50 = load i1, ptr %l32, !tbaa !21
  br i1 %t50, label %bb17, label %bb18
bb17:
  store i1 false, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 2
  store ptr %t57, ptr %l36, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = getelementptr %"compiler/generic:Program", ptr %t61, i32 0, i32 2
  %t64 = load i32, ptr %l1, !tbaa !23
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t63, i32 %t64)
  store i32 %t67, ptr %l41
  br label %bb20
bb20:
  %t68 = load ptr, ptr %l36, !tbaa !29
  %t69 = load i32, ptr %l41, !tbaa !23
  %t70 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t68, i32 %t69)
  store { i64, ptr } %t70, ptr %l42
  br label %bb21
bb21:
  %t71 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t71, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t72 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t72, 0
  store i64 %t74, ptr %l5, !tbaa !24
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s4
  %t76 = load i64, ptr %l4, !tbaa !24
  %t77 = load i64, ptr %l5, !tbaa !24
  %t80 = icmp slt i64 %t76, %t77
  %t82 = xor i1 %t80, true
  br i1 %t82, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s4)
  br label %bb31
bb24:
  br label %bb25
bb25:
  %t84 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t84, ptr %l49, !tbaa !27
  %t85 = load i64, ptr %l4, !tbaa !24
  %t87 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr i32, ptr %t88, i64 %t85
  %t90 = load i32, ptr %t89, !tbaa !33
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = load i64, ptr %l2, !tbaa !24
  %t96 = add i64 %t94, 1
  %t100 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainField(ptr %v0, ptr %t92, i32 %t90, i64 %t96)
  store i1 %t100, ptr %l56
  br label %bb26
bb26:
  %t101 = load i1, ptr %l56, !tbaa !21
  %t102 = xor i1 %t101, true
  br i1 %t102, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s4)
  store i1 false, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s4)
  br label %bb30
bb30:
  %t105 = load i64, ptr %l4, !tbaa !24
  %t107 = add i64 %t105, 1
  store i64 %t107, ptr %l4, !tbaa !24
  br label %bb22
bb31:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprivateRole(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i32 %a2, { i64, ptr } %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l9 = alloca i1
  %l12 = alloca i64
  %l15 = alloca ptr
  %l19 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l25 = alloca i1
  %l26 = alloca i1
  %l30 = alloca i64
  %l32 = alloca ptr
  %l40 = alloca ptr
  %l43 = alloca { i64, [3 x i64] }
  %l44 = alloca { i64, ptr }
  %l45 = alloca ptr
  %l48 = alloca i32
  %l49 = alloca { i64, ptr }
  %l53 = alloca %"compiler/msgs:Msg"
  %l54 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 13
  %t9 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_H2d42092ce658fb6cce0104fa754a4e33(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l12
  br label %bb3
bb3:
  %t10 = load i64, ptr %l12, !tbaa !24
  %t11 = icmp eq i64 %t10, 0
  store i1 %t11, ptr %l9, !tbaa !21
  br label %bb4
bb4:
  %t13 = load i1, ptr %l9, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l15, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t20 = load i64, ptr %l1, !tbaa !24
  %t23 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t19, i64 %t20)
  store ptr %t23, ptr %l19
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l19, !tbaa !29
  %t26 = getelementptr %"compiler/ast:Func", ptr %t24, i32 0, i32 2
  %t27 = load i32, ptr %t26, !tbaa !23
  %t28 = load ptr, ptr %l15, !tbaa !29
  %t30 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t28, i32 %t27)
  store { i64, ptr } %t30, ptr %l22
  br label %bb9
bb9:
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t31, ptr %l6, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t36 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t32, { i64, ptr } %t33)
  store i1 %t36, ptr %l25
  br label %bb10
bb10:
  %t37 = load i1, ptr %l25, !tbaa !21
  br i1 %t37, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb15
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t42 = load i64, ptr %l1, !tbaa !24
  %t45 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t41, i64 %t42)
  store i64 %t45, ptr %l30
  br label %bb13
bb13:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t46)
  store ptr %t48, ptr %l32
  br label %bb14
bb14:
  %t49 = load ptr, ptr %l32, !tbaa !29
  %t51 = getelementptr %"compiler/check:frame", ptr %t49, i32 0, i32 1
  %t52 = load i64, ptr %t51, !tbaa !24
  %t53 = load i64, ptr %l30, !tbaa !24
  %t55 = icmp eq i64 %t53, %t52
  store i1 %t55, ptr %l26, !tbaa !21
  br label %bb15
bb15:
  %t57 = load i1, ptr %l26, !tbaa !21
  br i1 %t57, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/load:Loader", ptr %t65, i32 0, i32 4
  %t68 = load ptr, ptr %t67, !tbaa !29
  store ptr %t68, ptr %l40, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t73 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t69, %"compiler/source:Span" %a4)
  store { i64, [3 x i64] } %t73, ptr %l43
  br label %bb19
bb19:
  store { i64, ptr } %a5, ptr %l44, !tbaa !27
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l45, !tbaa !29
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t80 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t76, i32 %a2)
  store i32 %t80, ptr %l48
  br label %bb20
bb20:
  %t81 = load ptr, ptr %l45, !tbaa !29
  %t82 = load i32, ptr %l48, !tbaa !23
  %t83 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t81, i32 %t82)
  store { i64, ptr } %t83, ptr %l49
  br label %bb21
bb21:
  %t84 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 0
  %t86 = extractvalue { i64, ptr } %t84, 1
  %t87 = mul i64 %t85, 1
  %t88 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t87)
  call void @llvm.memcpy.p0.p0.i64(ptr %t88, ptr %t86, i64 %t87, i1 false)
  %t89 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  %t91 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t92 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t93 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t97 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eProtocolPrivate(ptr %v2, ptr %s0, ptr %v0, ptr %v1, ptr %s0, { i64, ptr } %t93, { i64, ptr } %t90, { i64, ptr } %t91, { i64, ptr } %t92)
  store %"compiler/msgs:Msg" %t97, ptr %l53
  br label %bb22
bb22:
  %t98 = load ptr, ptr %l40, !tbaa !29
  %t99 = load { i64, [3 x i64] }, ptr %l43
  %t100 = load %"compiler/msgs:Msg", ptr %l53
  %t101 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %s0, ptr %t98, { i64, [3 x i64] } %t99, %"compiler/msgs:Msg" %t100)
  store i64 %t101, ptr %l54
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawValue(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca i64
  %l24 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca %"compiler/source:Span"
  %l33 = alloca { i64, ptr }
  %l35 = alloca %"compiler/msgs:Msg"
  %l36 = alloca i64
  %l41 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca %"compiler/source:Span"
  %l47 = alloca %"compiler/msgs:Msg"
  %l48 = alloca i64
  %l53 = alloca ptr
  %l57 = alloca ptr
  %l58 = alloca ptr
  %l59 = alloca i1
  %l67 = alloca i1
  %l77 = alloca ptr
  %l81 = alloca ptr
  %l83 = alloca i32
  %l86 = alloca i64
  %l90 = alloca ptr
  %l93 = alloca ptr
  %l98 = alloca i32
  %l99 = alloca { i64, ptr }
  %l106 = alloca ptr
  %l112 = alloca i64
  %l115 = alloca i64
  %l137 = alloca ptr
  %l138 = alloca %"compiler/source:Span"
  %l139 = alloca i32
  %l140 = alloca i32
  %l144 = alloca ptr
  %l145 = alloca ptr
  %l146 = alloca %"compiler/source:Span"
  %l148 = alloca i32
  %l150 = alloca ptr
  %l152 = alloca ptr
  %l153 = alloca %"compiler/source:Span"
  %l154 = alloca i32
  %l155 = alloca ptr
  %l160 = alloca ptr
  %l163 = alloca %"compiler/typed:Cond"
  %l171 = alloca i64
  %l174 = alloca %"compiler/source:Span"
  %l175 = alloca i32
  %l179 = alloca { i64, ptr }
  %l182 = alloca %"compiler/typed:Seq"
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca ptr
  %t290 = alloca { i64, [5 x i64] }, align 8
  %t333 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store { i64, ptr } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l3, !tbaa !23
  %t5 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawsOf(ptr %v0, ptr %t1, i32 %t2)
  store ptr %t5, ptr %l24
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l24, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t9 = getelementptr %"compiler/check:rawTable", ptr %t7, i32 0, i32 0
  %t10 = load i32, ptr %t9, !tbaa !23
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t14 = icmp eq i32 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l29, !tbaa !29
  %t17 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t17, ptr %l30
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l3, !tbaa !23
  %t22 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t18, i32 %t19)
  store { i64, ptr } %t22, ptr %l33
  br label %bb4
bb3:
  br label %bb9
bb4:
  %t23 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 0
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = mul i64 %t24, 1
  %t27 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t26)
  call void @llvm.memcpy.p0.p0.i64(ptr %t27, ptr %t25, i64 %t26, i1 false)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoRawValues(ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %t29, { i64, ptr } { i64 5, ptr @.d22 })
  store %"compiler/msgs:Msg" %t31, ptr %l35
  br label %bb5
bb5:
  %t32 = load ptr, ptr %l29, !tbaa !29
  %t33 = load %"compiler/source:Span", ptr %l30
  %t34 = load %"compiler/msgs:Msg", ptr %l35
  %t35 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t32, %"compiler/source:Span" %t33, %"compiler/msgs:Msg" %t34)
  store i64 %t35, ptr %l36
  br label %bb6
bb6:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t36, { i64, ptr } %t37)
  br label %bb7
bb7:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load %"compiler/source:Span", ptr %l1
  %t44 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t40, %"compiler/source:Span" %t41)
  store ptr %t44, ptr %l41
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  %t45 = load ptr, ptr %l41, !tbaa !29
  store ptr %t45, ptr %rv
  br label %ret
bb9:
  %t46 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t46, 0
  %t50 = icmp sgt i64 %t48, 0
  br i1 %t50, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l45, !tbaa !29
  %t53 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t53, ptr %l46
  %t54 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTakesNoArgs(ptr %s2, ptr %s2, { i64, ptr } { i64 7, ptr @.d23 })
  store %"compiler/msgs:Msg" %t54, ptr %l47
  br label %bb12
bb11:
  br label %bb16
bb12:
  %t55 = load ptr, ptr %l45, !tbaa !29
  %t56 = load %"compiler/source:Span", ptr %l46
  %t57 = load %"compiler/msgs:Msg", ptr %l47
  %t58 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t55, %"compiler/source:Span" %t56, %"compiler/msgs:Msg" %t57)
  store i64 %t58, ptr %l48
  br label %bb13
bb13:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t59, { i64, ptr } %t60)
  br label %bb14
bb14:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load %"compiler/source:Span", ptr %l1
  %t67 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t63, %"compiler/source:Span" %t64)
  store ptr %t67, ptr %l53
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  %t68 = load ptr, ptr %l53, !tbaa !29
  store ptr %t68, ptr %rv
  br label %ret
bb16:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = load %"compiler/source:Span", ptr %l1
  %t75 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t69, ptr %a4, %"compiler/source:Span" %t71)
  store ptr %t75, ptr %l57
  br label %bb17
bb17:
  %t76 = load ptr, ptr %l57, !tbaa !29
  store ptr %t76, ptr %l7, !tbaa !29
  %t77 = load ptr, ptr %l7, !tbaa !29
  store ptr %t77, ptr %l58, !tbaa !29
  store i1 false, ptr %l59, !tbaa !21
  %t78 = load ptr, ptr %l58, !tbaa !29
  %t79 = icmp ne ptr %t78, null
  br i1 %t79, label %bb18, label %bb19
bb18:
  %t81 = load ptr, ptr %l58, !tbaa !29
  %t82 = load i64, ptr %t81
  %t84 = icmp eq i64 %t82, 7
  store i1 %t84, ptr %l59, !tbaa !21
  br label %bb19
bb19:
  %t85 = load i1, ptr %l59, !tbaa !21
  br i1 %t85, label %bb20, label %bb21
bb20:
  %t86 = load ptr, ptr %l7, !tbaa !29
  %t88 = getelementptr { i64, [5 x i64] }, ptr %t86, i32 0, i32 1
  %t89 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t88, i32 0, i32 2
  %t90 = load ptr, ptr %t89
  store ptr %t90, ptr %l8, !tbaa !29
  br label %bb22
bb21:
  br label %bb30
bb22:
  %t92 = load ptr, ptr %l8, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Make", ptr %t92, i32 0, i32 0
  %t95 = load i32, ptr %t94
  %t97 = trunc i64 1 to i32
  %t98 = icmp eq i32 %t95, %t97
  br i1 %t98, label %bb23, label %bb24
bb23:
  %t100 = load ptr, ptr %l8, !tbaa !29
  %t102 = getelementptr %"compiler/typed:Make", ptr %t100, i32 0, i32 2
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t103, 0
  %t107 = icmp eq i64 %t105, 0
  store i1 %t107, ptr %l67, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb25
bb25:
  %t109 = load i1, ptr %l67, !tbaa !21
  br i1 %t109, label %bb26, label %bb27
bb26:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load %"compiler/source:Span", ptr %l1
  %t112 = load ptr, ptr %l6, !tbaa !29
  %t113 = load ptr, ptr %l8, !tbaa !29
  %t115 = getelementptr %"compiler/typed:Make", ptr %t113, i32 0, i32 1
  %t116 = load i64, ptr %t115, !tbaa !24
  %t121 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawOf(ptr %v0, ptr %v0, ptr %t110, %"compiler/source:Span" %t111, ptr %t112, i64 %t116)
  store ptr %t121, ptr %l77
  br label %bb28
bb27:
  br label %bb29
bb28:
  %t122 = load ptr, ptr %l77, !tbaa !29
  store ptr %t122, ptr %rv
  br label %ret
bb29:
  br label %bb31
bb30:
  br label %bb31
bb31:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load %"compiler/source:Span", ptr %l1
  %t125 = load ptr, ptr %l6, !tbaa !29
  %t129 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawOf(ptr %v0, ptr %v0, ptr %t123, %"compiler/source:Span" %t124, ptr %t125, i64 0)
  store ptr %t129, ptr %l81
  br label %bb32
bb32:
  %t130 = load ptr, ptr %l81, !tbaa !29
  %t132 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t130)
  store i32 %t132, ptr %l83
  br label %bb33
bb33:
  %t133 = load i32, ptr %l83, !tbaa !23
  store i32 %t133, ptr %l9, !tbaa !23
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t134, i32 0, i32 33
  %t138 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t136)
  store i64 %t138, ptr %l86
  br label %bb34
bb34:
  %t139 = load i64, ptr %l86, !tbaa !24
  store i64 %t139, ptr %l10, !tbaa !24
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load %"compiler/source:Span", ptr %l1
  %t142 = load ptr, ptr %l7, !tbaa !29
  %t146 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldOf(ptr %v0, ptr %t140, %"compiler/source:Span" %t141, ptr %t142)
  store ptr %t146, ptr %l90
  br label %bb35
bb35:
  %t147 = load ptr, ptr %l90, !tbaa !29
  store ptr %t147, ptr %l11, !tbaa !29
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/check:Checker", ptr %t148, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = getelementptr %"compiler/generic:Program", ptr %t151, i32 0, i32 2
  store ptr %t153, ptr %l93, !tbaa !29
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/check:Checker", ptr %t154, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t159 = getelementptr %"compiler/generic:Program", ptr %t157, i32 0, i32 2
  %t160 = load i32, ptr %l3, !tbaa !23
  %t163 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t159, i32 %t160)
  store i32 %t163, ptr %l98
  br label %bb36
bb36:
  %t164 = load ptr, ptr %l93, !tbaa !29
  %t165 = load i32, ptr %l98, !tbaa !23
  %t166 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t164, i32 %t165)
  store { i64, ptr } %t166, ptr %l99
  br label %bb37
bb37:
  %t167 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t167, 0
  store i64 %t168, ptr %l12, !tbaa !24
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load %"compiler/source:Span", ptr %l1
  %t172 = load ptr, ptr %l6, !tbaa !29
  %t173 = load i64, ptr %l12, !tbaa !24
  %t175 = sub i64 %t173, 1
  %t180 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawOf(ptr %v0, ptr %v0, ptr %t170, %"compiler/source:Span" %t171, ptr %t172, i64 %t175)
  store ptr %t180, ptr %l106
  br label %bb38
bb38:
  %t181 = load ptr, ptr %l106, !tbaa !29
  store ptr %t181, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  %t182 = load i64, ptr %l12, !tbaa !24
  %t184 = sub i64 %t182, 1
  store i64 %t184, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t186 = load i64, ptr %l15, !tbaa !24
  %t187 = load i64, ptr %l14, !tbaa !24
  %t190 = icmp sgt i64 %t186, %t187
  br i1 %t190, label %bb39, label %bb40
bb39:
  %t192 = load i64, ptr %l16, !tbaa !24
  %t194 = icmp sgt i64 %t192, 0
  br i1 %t194, label %bb41, label %bb42
bb40:
  store i64 0, ptr %l112, !tbaa !24
  br label %bb44
bb41:
  %t196 = load i64, ptr %l15, !tbaa !24
  %t197 = load i64, ptr %l14, !tbaa !24
  %t200 = sub i64 %t196, %t197
  %t201 = load i64, ptr %l16, !tbaa !24
  %t204 = add i64 %t200, %t201
  %t206 = sub i64 %t204, 1
  %t207 = load i64, ptr %l16, !tbaa !24
  %t210 = sdiv i64 %t206, %t207
  store i64 %t210, ptr %l115, !tbaa !24
  br label %bb43
bb42:
  store i64 0, ptr %l115, !tbaa !24
  br label %bb43
bb43:
  %t212 = load i64, ptr %l115, !tbaa !24
  store i64 %t212, ptr %l112, !tbaa !24
  br label %bb44
bb44:
  %t213 = load i64, ptr %l112, !tbaa !24
  store i64 %t213, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb45
bb45:
  store %olang.scope zeroinitializer, ptr %s7
  %t214 = load i64, ptr %l18, !tbaa !24
  %t215 = load i64, ptr %l17, !tbaa !24
  %t218 = icmp slt i64 %t214, %t215
  %t220 = xor i1 %t218, true
  br i1 %t220, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s7)
  br label %bb56
bb47:
  br label %bb48
bb48:
  %t222 = load i64, ptr %l14, !tbaa !24
  %t223 = load i64, ptr %l18, !tbaa !24
  %t224 = load i64, ptr %l16, !tbaa !24
  %t227 = mul i64 %t223, %t224
  %t230 = add i64 %t222, %t227
  %t232 = load i64, ptr %l12, !tbaa !24
  %t234 = sub i64 %t232, 2
  %t238 = sub i64 %t234, %t230
  store i64 %t238, ptr %l20, !tbaa !24
  %t240 = load ptr, ptr %l0, !tbaa !29
  store ptr %t240, ptr %l137, !tbaa !29
  %t241 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t241, ptr %l138
  %t242 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t242, ptr %l139, !tbaa !23
  store i32 23, ptr %l140
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t244 = load %"compiler/source:Span", ptr %l1
  %t245 = load ptr, ptr %l11, !tbaa !29
  %t249 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t243, %"compiler/source:Span" %t244, ptr %t245)
  store ptr %t249, ptr %l144
  br label %bb49
bb49:
  %t250 = load ptr, ptr %l0, !tbaa !29
  store ptr %t250, ptr %l145, !tbaa !29
  %t251 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t251, ptr %l146
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t252)
  store i32 %t254, ptr %l148
  br label %bb50
bb50:
  %t255 = load i64, ptr %l20, !tbaa !24
  %t256 = load ptr, ptr %l145, !tbaa !29
  %t257 = load %"compiler/source:Span", ptr %l146
  %t258 = load i32, ptr %l148, !tbaa !23
  %t260 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t256, %"compiler/source:Span" %t257, i32 %t258, i64 %t255)
  store ptr %t260, ptr %l150
  br label %bb51
bb51:
  %t261 = load ptr, ptr %l150, !tbaa !29
  %t262 = load ptr, ptr %l137, !tbaa !29
  %t263 = load %"compiler/source:Span", ptr %l138
  %t264 = load i32, ptr %l139, !tbaa !23
  %t265 = load i32, ptr %l140
  %t266 = load ptr, ptr %l144, !tbaa !29
  %t268 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t262, %"compiler/source:Span" %t263, i32 %t264, i32 %t265, ptr %t266, ptr %t261)
  store ptr %t268, ptr %l152
  br label %bb52
bb52:
  %t269 = load ptr, ptr %l152, !tbaa !29
  %t270 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t270, ptr %l153
  %t271 = load i32, ptr %l9, !tbaa !23
  store i32 %t271, ptr %l154, !tbaa !23
  store ptr %t269, ptr %l155, !tbaa !29
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = load %"compiler/source:Span", ptr %l1
  %t275 = load ptr, ptr %l6, !tbaa !29
  %t276 = load i64, ptr %l20, !tbaa !24
  %t281 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawOf(ptr %v0, ptr %v0, ptr %t273, %"compiler/source:Span" %t274, ptr %t275, i64 %t276)
  store ptr %t281, ptr %l160
  br label %bb53
bb53:
  %t282 = load ptr, ptr %l160, !tbaa !29
  %t283 = load ptr, ptr %l13, !tbaa !29
  %t284 = load ptr, ptr %l155, !tbaa !29
  %t287 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t284, ptr %t282, ptr %t283)
  store %"compiler/typed:Cond" %t287, ptr %l163
  br label %bb54
bb54:
  %t288 = load %"compiler/typed:Cond", ptr %l163
  %t289 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Cond" %t288, ptr %t289
  store { i64, [5 x i64] } zeroinitializer, ptr %t290
  %t291 = getelementptr { i64, [5 x i64] }, ptr %t290, i32 0, i32 0
  store i64 11, ptr %t291
  %t292 = load %"compiler/source:Span", ptr %l153
  %t293 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t292, 0
  %t294 = load i32, ptr %l154, !tbaa !23
  %t295 = insertvalue { %"compiler/source:Span", i32, ptr } %t293, i32 %t294, 1
  %t297 = insertvalue { %"compiler/source:Span", i32, ptr } %t295, ptr %t289, 2
  %t298 = getelementptr { i64, [5 x i64] }, ptr %t290, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t297, ptr %t298
  %t299 = load { i64, [5 x i64] }, ptr %t290
  %t301 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t299, ptr %t301
  store ptr %t301, ptr %l13, !tbaa !29
  call void @__olang_scope_close(ptr %s7)
  br label %bb55
bb55:
  %t303 = load i64, ptr %l18, !tbaa !24
  %t305 = add i64 %t303, 1
  store i64 %t305, ptr %l18, !tbaa !24
  br label %bb45
bb56:
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"compiler/check:Checker", ptr %t307, i32 0, i32 33
  %t311 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t309)
  store i64 %t311, ptr %l171
  br label %bb57
bb57:
  %t312 = load i64, ptr %l10, !tbaa !24
  %t313 = load i64, ptr %l171, !tbaa !24
  %t315 = icmp sgt i64 %t313, %t312
  br i1 %t315, label %bb58, label %bb59
bb58:
  %t317 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t317, ptr %l174
  %t318 = load i32, ptr %l9, !tbaa !23
  store i32 %t318, ptr %l175, !tbaa !23
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t321 = getelementptr %"compiler/check:Checker", ptr %t319, i32 0, i32 33
  %t322 = load i64, ptr %l10, !tbaa !24
  %t325 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t321, i64 %t322)
  store { i64, ptr } %t325, ptr %l179
  br label %bb60
bb59:
  br label %bb62
bb60:
  %t326 = load ptr, ptr %l13, !tbaa !29
  %t328 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t330 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t328, ptr %t326)
  store %"compiler/typed:Seq" %t330, ptr %l182
  br label %bb61
bb61:
  %t331 = load %"compiler/typed:Seq", ptr %l182
  %t332 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Seq" %t331, ptr %t332
  store { i64, [5 x i64] } zeroinitializer, ptr %t333
  %t334 = getelementptr { i64, [5 x i64] }, ptr %t333, i32 0, i32 0
  store i64 12, ptr %t334
  %t335 = load %"compiler/source:Span", ptr %l174
  %t336 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t335, 0
  %t337 = load i32, ptr %l175, !tbaa !23
  %t338 = insertvalue { %"compiler/source:Span", i32, ptr } %t336, i32 %t337, 1
  %t340 = insertvalue { %"compiler/source:Span", i32, ptr } %t338, ptr %t332, 2
  %t341 = getelementptr { i64, [5 x i64] }, ptr %t333, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t340, ptr %t341
  %t342 = load { i64, [5 x i64] }, ptr %t333
  %t344 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t342, ptr %t344
  store ptr %t344, ptr %rv
  br label %ret
bb62:
  %t346 = load ptr, ptr %l13, !tbaa !29
  store ptr %t346, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFollows(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca ptr
  %l7 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l8 = alloca i1
  %l13 = alloca i1
  %l14 = alloca i1
  %l18 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 63
  store ptr %t3, ptr %l4, !tbaa !29
  %t4 = load i64, ptr %l1, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t8 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t4, i64 %t5)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t10 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l7
  %t11 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t9, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t10)
  store i1 %t11, ptr %l8
  br label %bb2
bb2:
  %t12 = load i1, ptr %l8, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i64, ptr %l1, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t20 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %t14, i64 %t15, i64 %t16)
  store i1 %t20, ptr %l13
  br label %bb6
bb6:
  %t21 = load i1, ptr %l13, !tbaa !21
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 16
  %t25 = load i64, ptr %l1, !tbaa !24
  %t28 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t24, i64 %t25)
  store i64 %t28, ptr %l18
  br label %bb9
bb8:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb10
bb9:
  %t29 = load i64, ptr %l18, !tbaa !24
  %t30 = icmp ne i64 %t29, 2
  store i1 %t30, ptr %l14, !tbaa !21
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t32 = load i1, ptr %l14, !tbaa !21
  store i1 %t32, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKeepVal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l14 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l19 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l25 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %a1, i64 %a2)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t9, ptr %l10
  br label %bb4
bb4:
  %t10 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l10
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t10, ptr %l4
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 62
  %t14 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  %t17 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H4c470d2e80d9fd53b2c4a8b35e81296f(ptr %v0, ptr %t13, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t14)
  store i1 %t17, ptr %l14
  br label %bb5
bb5:
  %t18 = load i1, ptr %l14, !tbaa !21
  %t19 = xor i1 %t18, true
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 62
  store ptr %t23, ptr %l17, !tbaa !29
  %t24 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t24, ptr %l18
  %t25 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l19
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t26 = load ptr, ptr %l17, !tbaa !29
  %t27 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l18
  %t28 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H64396385e4e6d43afa926b839ce2258a(ptr %v0, ptr %v0, ptr %t26, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t27, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t28)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 62
  %t32 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  %t35 = call { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H6388cc594ade7977543a45717e2b755f(ptr %v0, ptr %v0, ptr %t31, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t32)
  %t36 = extractvalue { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %t35, 1
  %t37 = extractvalue { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %t35, 0
  store i32 %t37, ptr %l25
  %t38 = icmp ne i32 %t37, 0
  br i1 %t38, label %bb12, label %ok.39
ok.39:
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t36, ptr %l24
  br label %bb11
bb11:
  %t40 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l24
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t40, ptr %l20
  br label %bb14
bb12:
  br label %bb13
bb13:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  %t41 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l20
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t41, ptr %l5
  %t42 = load ptr, ptr %l3, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v1, ptr %l5, ptr %t42)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRead(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i1
  %l10 = alloca ptr
  %l12 = alloca %"compiler/typed:Local"
  %l15 = alloca i1
  %l17 = alloca i1
  %l19 = alloca i1
  %l21 = alloca ptr
  %l25 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l26 = alloca i1
  %l27 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb20
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t16)
  store ptr %t18, ptr %l10
  br label %bb6
bb6:
  %t19 = load i32, ptr %l2, !tbaa !23
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t22 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t20, i32 %t19)
  store %"compiler/typed:Local" %t22, ptr %l12
  br label %bb7
bb7:
  %t23 = getelementptr %"compiler/typed:Local", ptr %l12, i32 0, i32 4
  %t24 = load i32, ptr %t23
  %t26 = trunc i64 0 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb8, label %bb9
bb8:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einGeneric(ptr %v0, ptr %t29)
  store i1 %t31, ptr %l17
  br label %bb10
bb9:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb11
bb10:
  %t32 = load i1, ptr %l17, !tbaa !21
  store i1 %t32, ptr %l15, !tbaa !21
  br label %bb11
bb11:
  %t33 = load i1, ptr %l15, !tbaa !21
  br i1 %t33, label %bb12, label %bb13
bb12:
  store i1 false, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 56
  store ptr %t37, ptr %l21, !tbaa !29
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i32, ptr %l2, !tbaa !23
  %t41 = sext i32 %t39 to i64
  %t44 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %t38, i64 %t41)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t44, ptr %l25
  br label %bb15
bb15:
  %t45 = load ptr, ptr %l21, !tbaa !29
  %t46 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l25
  %t47 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H190b78e3c1eec037529224679e114a85(ptr %v0, ptr %t45, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t46)
  %t48 = extractvalue { i32, i1 } %t47, 1
  %t49 = extractvalue { i32, i1 } %t47, 0
  store i32 %t49, ptr %l27
  %t50 = icmp ne i32 %t49, 0
  br i1 %t50, label %bb17, label %ok.51
ok.51:
  store i1 %t48, ptr %l26
  br label %bb16
bb16:
  %t52 = load i1, ptr %l26, !tbaa !21
  store i1 %t52, ptr %l19, !tbaa !21
  br label %bb19
bb17:
  br label %bb18
bb18:
  call void @__olang_ert_req_clear()
  store i1 true, ptr %l19, !tbaa !21
  br label %bb19
bb19:
  %t53 = load i1, ptr %l19, !tbaa !21
  store i1 %t53, ptr %rv
  br label %ret
bb20:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootStmts(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca %"compiler/typed:Block"
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 33
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryChecks(ptr %v0, ptr %t7)
  br label %bb2
bb2:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t10)
  store ptr %t12, ptr %l9
  br label %bb3
bb3:
  %t13 = load ptr, ptr %l9, !tbaa !29
  %t15 = getelementptr %"compiler/check:frame", ptr %t13, i32 0, i32 38
  %t16 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @compiler_2fcheck_2estoredIn(ptr %v1, ptr %v0, { i64, ptr } %t16, ptr %t15)
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  %t22 = icmp sgt i64 %t20, 0
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %t24, { i64, ptr } %t25)
  br label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb8
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 33
  %t31 = load i64, ptr %l2, !tbaa !24
  %t34 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t30, i64 %t31)
  store { i64, ptr } %t34, ptr %l20
  br label %bb9
bb9:
  %t35 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t36 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 0, { i64, ptr } %t35)
  store %"compiler/typed:Block" %t36, ptr %l21
  br label %bb10
bb10:
  %t37 = load %"compiler/typed:Block", ptr %l21
  %t38 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t37, ptr %t38
  store ptr %t38, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetUnion(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i32
  %l31 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i32
  %l55 = alloca { i64, ptr }
  %l65 = alloca ptr
  %l68 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l70 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l16
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l3
  store ptr %a1, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t7 = load i64, ptr %l5, !tbaa !24
  %t10 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %v1, ptr %t6, i64 %t7)
  %t11 = extractvalue { i32, { i64, ptr } } %t10, 1
  %t12 = extractvalue { i32, { i64, ptr } } %t10, 0
  store i32 %t12, ptr %l22
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb4, label %ok.14
ok.14:
  store { i64, ptr } %t11, ptr %l21
  br label %bb3
bb3:
  %t15 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t15, ptr %l18, !tbaa !27
  br label %bb8
bb4:
  %t16 = load i32, ptr %l22, !tbaa !23
  %t17 = ashr i32 %t16, 16
  %t19 = icmp eq i32 %t17, 1
  br i1 %t19, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_a580b41490f7ba52_8ca18228c95a1fde)
  unreachable
bb7:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb8:
  %t21 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t21, ptr %l6, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  store i64 %t24, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t26 = load i64, ptr %l8, !tbaa !24
  %t27 = load i64, ptr %l7, !tbaa !24
  %t30 = icmp slt i64 %t26, %t27
  %t32 = xor i1 %t30, true
  br i1 %t32, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t34 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t34, ptr %l31, !tbaa !27
  %t35 = load i64, ptr %l8, !tbaa !24
  %t37 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr i32, ptr %t38, i64 %t35
  %t40 = load i32, ptr %t39, !tbaa !33
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l3, i32 %t40)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb14:
  %t45 = load i64, ptr %l8, !tbaa !24
  %t47 = add i64 %t45, 1
  store i64 %t47, ptr %l8, !tbaa !24
  br label %bb9
bb15:
  %t49 = load i64, ptr %l5, !tbaa !24
  %t50 = load i64, ptr %l7, !tbaa !24
  %t53 = add i64 %t49, %t50
  store i64 %t53, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  br label %bb2
bb17:
  store ptr %a2, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s6
  %t57 = load ptr, ptr %l10, !tbaa !29
  %t58 = load i64, ptr %l11, !tbaa !24
  %t61 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %v2, ptr %t57, i64 %t58)
  %t62 = extractvalue { i32, { i64, ptr } } %t61, 1
  %t63 = extractvalue { i32, { i64, ptr } } %t61, 0
  store i32 %t63, ptr %l46
  %t64 = icmp ne i32 %t63, 0
  br i1 %t64, label %bb20, label %ok.65
ok.65:
  store { i64, ptr } %t62, ptr %l45
  br label %bb19
bb19:
  %t66 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t66, ptr %l42, !tbaa !27
  br label %bb24
bb20:
  %t67 = load i32, ptr %l46, !tbaa !23
  %t68 = ashr i32 %t67, 16
  %t70 = icmp eq i32 %t68, 1
  br i1 %t70, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_9332d3d788c23e53_a9219b71b597ec5f)
  unreachable
bb23:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s6)
  br label %bb33
bb24:
  %t72 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t72, ptr %l12, !tbaa !27
  %t73 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t73, 0
  store i64 %t75, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s7
  %t77 = load i64, ptr %l14, !tbaa !24
  %t78 = load i64, ptr %l13, !tbaa !24
  %t81 = icmp slt i64 %t77, %t78
  %t83 = xor i1 %t81, true
  br i1 %t83, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s7)
  br label %bb31
bb27:
  br label %bb28
bb28:
  %t85 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t85, ptr %l55, !tbaa !27
  %t86 = load i64, ptr %l14, !tbaa !24
  %t88 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr i32, ptr %t89, i64 %t86
  %t91 = load i32, ptr %t90, !tbaa !33
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l3, i32 %t91)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s7)
  br label %bb30
bb30:
  %t96 = load i64, ptr %l14, !tbaa !24
  %t98 = add i64 %t96, 1
  store i64 %t98, ptr %l14, !tbaa !24
  br label %bb25
bb31:
  %t100 = load i64, ptr %l11, !tbaa !24
  %t101 = load i64, ptr %l13, !tbaa !24
  %t104 = add i64 %t100, %t101
  store i64 %t104, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb32
bb32:
  br label %bb18
bb33:
  %t106 = load ptr, ptr %l0, !tbaa !29
  store ptr %t106, ptr %l65, !tbaa !29
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t110 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emerged(ptr %v0, ptr %s0, ptr %v3, ptr %t107, ptr %l3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t110, ptr %l68
  br label %bb34
bb34:
  %t111 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l68
  %t112 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t111, ptr %t112
  %t113 = load ptr, ptr %l65, !tbaa !29
  %t115 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enormalSet(ptr %v0, ptr %v3, ptr %v3, ptr %t113, ptr %t112)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t115, ptr %l70
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s0)
  %t116 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l70
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t116, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettle(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l8 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca i32
  %l19 = alloca ptr
  %l23 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l33 = alloca ptr
  %l39 = alloca i32
  %l45 = alloca i32
  %l46 = alloca i32
  %l52 = alloca i32
  %l53 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2, ptr %l5, !tbaa !29
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t7 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eletOut(ptr %v0, ptr %v1, ptr %s0, ptr %t3, ptr %t4)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  %t9 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %t9
  %t10 = load ptr, ptr %l5, !tbaa !29
  %t12 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emerged(ptr %v0, ptr %s0, ptr %s0, ptr %t10, ptr %t9)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l10
  br label %bb2
bb2:
  %t13 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  %t14 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %t14
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t17 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecanonicalErrs(ptr %v0, ptr %s0, ptr %t15, ptr %t14)
  store i32 %t17, ptr %l12
  br label %bb3
bb3:
  %t18 = load i32, ptr %l12, !tbaa !23
  store i32 %t18, ptr %l2, !tbaa !23
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 48
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"compiler/check:frame", ptr %t22, i32 0, i32 0
  %t25 = load i64, ptr %t24, !tbaa !24
  %t26 = load i32, ptr %l2, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e__Hb311157f9ff5cfde66cc01a7f8069ed8(ptr %v0, ptr %t21, i64 %t25, i32 %t26)
  br label %bb4
bb4:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 52
  store ptr %t32, ptr %l19, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr %"compiler/check:frame", ptr %t34, i32 0, i32 0
  %t37 = load i64, ptr %t36, !tbaa !24
  %t40 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyKey(ptr %v0, ptr %t33, i64 %t37)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t40, ptr %l23
  br label %bb5
bb5:
  %t41 = load i32, ptr %l2, !tbaa !23
  %t42 = load ptr, ptr %l19, !tbaa !29
  %t43 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1d7b97a31fca2c92a4527a0b3309f2d1(ptr %v0, ptr %t42, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t43, i32 %t41)
  br label %bb6
bb6:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 11
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr %"compiler/check:frame", ptr %t48, i32 0, i32 0
  %t51 = load i64, ptr %t50, !tbaa !24
  %t54 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t47, i64 %t51)
  store ptr %t54, ptr %l29
  br label %bb7
bb7:
  %t55 = load ptr, ptr %l29, !tbaa !29
  store ptr %t55, ptr %l3, !tbaa !29
  %t56 = load ptr, ptr %l3, !tbaa !29
  store ptr %t56, ptr %l30, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 2
  store ptr %t62, ptr %l33, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  %t69 = load ptr, ptr %l3, !tbaa !29
  %t71 = getelementptr %"compiler/typed:Body", ptr %t69, i32 0, i32 2
  %t72 = load i32, ptr %t71, !tbaa !23
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t68, i32 %t72)
  store i32 %t75, ptr %l39
  br label %bb8
bb8:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/generic:Program", ptr %t79, i32 0, i32 2
  %t82 = load ptr, ptr %l3, !tbaa !29
  %t84 = getelementptr %"compiler/typed:Body", ptr %t82, i32 0, i32 2
  %t85 = load i32, ptr %t84, !tbaa !23
  %t88 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t81, i32 %t85)
  store i32 %t88, ptr %l45
  br label %bb9
bb9:
  %t89 = load i32, ptr %l2, !tbaa !23
  store i32 %t89, ptr %l46, !tbaa !23
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/check:Checker", ptr %t90, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = getelementptr %"compiler/generic:Program", ptr %t93, i32 0, i32 2
  %t96 = load ptr, ptr %l3, !tbaa !29
  %t98 = getelementptr %"compiler/typed:Body", ptr %t96, i32 0, i32 2
  %t99 = load i32, ptr %t98, !tbaa !23
  %t102 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t95, i32 %t99)
  store i32 %t102, ptr %l52
  br label %bb10
bb10:
  %t103 = load ptr, ptr %l33, !tbaa !29
  %t104 = load i32, ptr %l39, !tbaa !23
  %t105 = load i32, ptr %l45, !tbaa !23
  %t106 = load i32, ptr %l46, !tbaa !23
  %t107 = load i32, ptr %l52, !tbaa !23
  %t108 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t103, i32 %t104, i32 %t105, i32 %t106, i32 %t107, i64 0)
  store i32 %t108, ptr %l53
  br label %bb11
bb11:
  %t109 = load i32, ptr %l53, !tbaa !23
  %t110 = load ptr, ptr %l30, !tbaa !29
  %t111 = getelementptr %"compiler/typed:Body", ptr %t110, i32 0, i32 2
  store i32 %t109, ptr %t111, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estepMethod(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i1
  %l5 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i32
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l44 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca %"compiler/source:Span"
  %l47 = alloca ptr
  %l52 = alloca ptr
  %l56 = alloca ptr
  %l57 = alloca i32
  %l59 = alloca { i64, ptr }
  %l60 = alloca i64
  %l63 = alloca ptr
  %l64 = alloca i32
  %l66 = alloca { i64, ptr }
  %l67 = alloca %"compiler/source:Span"
  %l69 = alloca { i64, ptr }
  %l70 = alloca i1
  %l71 = alloca ptr
  %l74 = alloca ptr
  %l77 = alloca ptr
  %l81 = alloca i32
  %l82 = alloca i32
  %l83 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l86 = alloca i32
  %l89 = alloca i1
  %l92 = alloca ptr
  %l93 = alloca %"compiler/source:Span"
  %l94 = alloca i32
  %l97 = alloca ptr
  %l100 = alloca i32
  %l101 = alloca i1
  %l102 = alloca i64
  %l105 = alloca i32
  %l106 = alloca i64
  %l107 = alloca ptr
  %l108 = alloca ptr
  %l109 = alloca %"compiler/source:Span"
  %l110 = alloca %"compiler/source:Span"
  %l111 = alloca i64
  %l118 = alloca ptr
  %l119 = alloca ptr
  %l122 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l129 = alloca ptr
  %l130 = alloca ptr
  %l131 = alloca %"compiler/source:Span"
  %l132 = alloca ptr
  %l137 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  %t31 = alloca { i64, [4 x i64] }, align 8
  %t92 = alloca { i64, [3 x i64] }, align 8
  %t219 = alloca { i64, [4 x i64] }, align 8
  %t277 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l3, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load i1, ptr %l13, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l16, !tbaa !29
  %t11 = load i32, ptr %l3, !tbaa !23
  store i32 %t11, ptr %l17, !tbaa !23
  %t12 = load i1, ptr %l4, !tbaa !21
  br i1 %t12, label %bb5, label %bb6
bb5:
  store { i64, ptr } { i64 3, ptr @.d24 }, ptr %l19, !tbaa !27
  br label %bb7
bb6:
  store { i64, ptr } { i64 3, ptr @.d25 }, ptr %l19, !tbaa !27
  br label %bb7
bb7:
  %t14 = load ptr, ptr %l16, !tbaa !29
  %t15 = load i32, ptr %l17, !tbaa !23
  %t16 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t17 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t14, i32 %t15, { i64, ptr } %t16, i64 0)
  store i64 %t17, ptr %l20
  br label %bb8
bb8:
  %t18 = load i64, ptr %l20, !tbaa !24
  store i64 %t18, ptr %l5, !tbaa !24
  %t19 = load i64, ptr %l5, !tbaa !24
  %t21 = icmp sge i64 %t19, 0
  br i1 %t21, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l23, !tbaa !29
  %t24 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t24, ptr %l24
  %t25 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t25, ptr %l25
  %t26 = load i64, ptr %l5, !tbaa !24
  store i64 %t26, ptr %l26, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l1
  %t29 = load %"compiler/source:Span", ptr %l1
  %t30 = load i32, ptr %l3, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t31
  %t32 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 0
  store i64 7, ptr %t32
  %t34 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t29, 0
  %t36 = insertvalue { %"compiler/source:Span", i32 } %t34, i32 %t30, 1
  %t37 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t36, ptr %t37
  %t38 = load { i64, [4 x i64] }, ptr %t31
  %t40 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t38, ptr %t40
  %t44 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t27, %"compiler/source:Span" %t28, ptr %t40)
  store ptr %t44, ptr %l33
  br label %bb11
bb10:
  br label %bb27
bb11:
  %t45 = load ptr, ptr %l33, !tbaa !29
  store ptr %t45, ptr %l34, !tbaa !29
  %t46 = icmp sge i64 0, 0
  br i1 %t46, label %bb12, label %bb13
bb12:
  %t48 = icmp sle i64 0, 1152921504606846975
  br i1 %t48, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_fe73ad2ef66395ad_6bb388f528f40629)
  unreachable
bb14:
  %t50 = mul i64 0, 8
  %t51 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t50)
  %t52 = insertvalue { i64, ptr } undef, i64 0, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t51, 1
  store { i64, ptr } %t53, ptr %l37, !tbaa !27
  %t54 = icmp sge i64 0, 0
  br i1 %t54, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_fe73ad2ef66395ad_6bb388f528f40629)
  unreachable
bb16:
  %t56 = icmp sle i64 0, 1152921504606846975
  br i1 %t56, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_fe73ad2ef66395ad_6bb388f528f40629)
  unreachable
bb18:
  %t58 = mul i64 0, 8
  %t59 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t58)
  %t60 = insertvalue { i64, ptr } undef, i64 0, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l40, !tbaa !27
  %t62 = icmp sge i64 0, 0
  br i1 %t62, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_fe73ad2ef66395ad_6bb388f528f40629)
  unreachable
bb20:
  %t64 = icmp sle i64 0, 2305843009213693951
  br i1 %t64, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_97840d8df2a94e80_8f65c6ae19d7bb5c)
  unreachable
bb22:
  %t66 = mul i64 0, 4
  %t67 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t66)
  %t68 = insertvalue { i64, ptr } undef, i64 0, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  %t70 = load ptr, ptr %l23, !tbaa !29
  %t71 = load %"compiler/source:Span", ptr %l24
  %t72 = load %"compiler/source:Span", ptr %l25
  %t73 = load i64, ptr %l26, !tbaa !24
  %t74 = load ptr, ptr %l34, !tbaa !29
  %t75 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t78 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %s2, ptr %t70, %"compiler/source:Span" %t71, %"compiler/source:Span" %t72, i64 %t73, ptr %t74, { i64, ptr } %t75, { i64, ptr } %t76, { i64, ptr } %t69)
  store ptr %t78, ptr %l44
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_97840d8df2a94e80_8f65c6ae19d7bb5c)
  unreachable
bb24:
  %t79 = load ptr, ptr %l44, !tbaa !29
  %t80 = load ptr, ptr %l0, !tbaa !29
  store ptr %t80, ptr %l45, !tbaa !29
  %t81 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t81, ptr %l46
  %t82 = load ptr, ptr %l2, !tbaa !29
  store ptr %t82, ptr %l47, !tbaa !29
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i32, ptr %l3, !tbaa !23
  %t86 = load %"compiler/source:Span", ptr %l1
  %t91 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t83, ptr %t79, i32 %t85, %"compiler/source:Span" %t86)
  store ptr %t91, ptr %l52
  br label %bb25
bb25:
  store { i64, [3 x i64] } zeroinitializer, ptr %t92
  %t93 = getelementptr { i64, [3 x i64] }, ptr %t92, i32 0, i32 0
  store i64 1, ptr %t93
  %t94 = load %"compiler/source:Span", ptr %l46
  %t95 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t94, 0
  %t96 = load ptr, ptr %l47, !tbaa !29
  %t97 = insertvalue { %"compiler/source:Span", ptr, ptr } %t95, ptr %t96, 1
  %t98 = load ptr, ptr %l52, !tbaa !29
  %t99 = insertvalue { %"compiler/source:Span", ptr, ptr } %t97, ptr %t98, 2
  %t100 = getelementptr { i64, [3 x i64] }, ptr %t92, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t99, ptr %t100
  %t101 = load { i64, [3 x i64] }, ptr %t92
  %t103 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t101, ptr %t103
  %t104 = load ptr, ptr %l45, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t104, ptr %t103)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb27:
  %t107 = load ptr, ptr %l0, !tbaa !29
  store ptr %t107, ptr %l56, !tbaa !29
  %t108 = load i32, ptr %l3, !tbaa !23
  store i32 %t108, ptr %l57, !tbaa !23
  %t109 = load i1, ptr %l4, !tbaa !21
  br i1 %t109, label %bb28, label %bb29
bb28:
  store { i64, ptr } { i64 4, ptr @.d26 }, ptr %l59, !tbaa !27
  br label %bb30
bb29:
  store { i64, ptr } { i64 5, ptr @.d27 }, ptr %l59, !tbaa !27
  br label %bb30
bb30:
  %t111 = load ptr, ptr %l56, !tbaa !29
  %t112 = load i32, ptr %l57, !tbaa !23
  %t113 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t114 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t111, i32 %t112, { i64, ptr } %t113, i64 1)
  store i64 %t114, ptr %l60
  br label %bb31
bb31:
  %t115 = load i64, ptr %l60, !tbaa !24
  store i64 %t115, ptr %l7, !tbaa !24
  %t116 = load i64, ptr %l7, !tbaa !24
  %t118 = icmp slt i64 %t116, 0
  br i1 %t118, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s3
  %t120 = load ptr, ptr %l0, !tbaa !29
  store ptr %t120, ptr %l63, !tbaa !29
  %t121 = load i32, ptr %l3, !tbaa !23
  store i32 %t121, ptr %l64, !tbaa !23
  %t122 = load i1, ptr %l4, !tbaa !21
  br i1 %t122, label %bb34, label %bb35
bb33:
  br label %bb41
bb34:
  store { i64, ptr } { i64 3, ptr @.d28 }, ptr %l66, !tbaa !27
  br label %bb36
bb35:
  store { i64, ptr } { i64 3, ptr @.d29 }, ptr %l66, !tbaa !27
  br label %bb36
bb36:
  %t124 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t124, ptr %l67
  %t125 = load i1, ptr %l4, !tbaa !21
  br i1 %t125, label %bb37, label %bb38
bb37:
  store { i64, ptr } { i64 4, ptr @.d30 }, ptr %l69, !tbaa !27
  br label %bb39
bb38:
  store { i64, ptr } { i64 4, ptr @.d31 }, ptr %l69, !tbaa !27
  br label %bb39
bb39:
  %t127 = load ptr, ptr %l63, !tbaa !29
  %t128 = load i32, ptr %l64, !tbaa !23
  %t129 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t130 = load %"compiler/source:Span", ptr %l67
  %t131 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t132 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %s3, ptr %s3, ptr %t127, i32 %t128, { i64, ptr } %t129, %"compiler/source:Span" %t130, { i64, ptr } %t131, i64 0, i1 false)
  store i1 %t132, ptr %l70
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t133 = load i1, ptr %l70, !tbaa !21
  store i1 %t133, ptr %rv
  br label %ret
bb41:
  %t134 = load ptr, ptr %l0, !tbaa !29
  store ptr %t134, ptr %l71, !tbaa !29
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = getelementptr %"compiler/generic:Program", ptr %t138, i32 0, i32 2
  store ptr %t140, ptr %l74, !tbaa !29
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/check:Checker", ptr %t141, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t146 = getelementptr %"compiler/generic:Program", ptr %t144, i32 0, i32 2
  store ptr %t146, ptr %l77, !tbaa !29
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/check:Checker", ptr %t147, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t151 = load i64, ptr %l7, !tbaa !24
  %t154 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t150, i64 %t151)
  store i32 %t154, ptr %l81
  br label %bb42
bb42:
  %t155 = load ptr, ptr %l77, !tbaa !29
  %t156 = load i32, ptr %l81, !tbaa !23
  %t157 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t155, i32 %t156)
  store i32 %t157, ptr %l82
  br label %bb43
bb43:
  %t158 = load ptr, ptr %l74, !tbaa !29
  %t159 = load i32, ptr %l82, !tbaa !23
  %t160 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t158, i32 %t159)
  store { i64, ptr } %t160, ptr %l83
  br label %bb44
bb44:
  %t161 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t161, ptr %l84, !tbaa !27
  %t162 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !27
  %t164 = getelementptr i32, ptr %t163, i64 1
  %t165 = load i32, ptr %t164, !tbaa !33
  %t166 = load ptr, ptr %l71, !tbaa !29
  %t168 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t166, i32 %t165)
  store i32 %t168, ptr %l86
  br label %bb45
bb45:
  %t169 = load i32, ptr %l86, !tbaa !23
  store i32 %t169, ptr %l8, !tbaa !23
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load i32, ptr %l8, !tbaa !23
  %t174 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t170, i32 %t171)
  store i1 %t174, ptr %l89
  br label %bb46
bb46:
  %t175 = load i1, ptr %l89, !tbaa !21
  %t176 = xor i1 %t175, true
  br i1 %t176, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  %t179 = load ptr, ptr %l0, !tbaa !29
  store ptr %t179, ptr %l92, !tbaa !29
  %t180 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t180, ptr %l93
  %t181 = load i32, ptr %l8, !tbaa !23
  store i32 %t181, ptr %l94, !tbaa !23
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/check:Checker", ptr %t182, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !29
  %t187 = getelementptr %"compiler/generic:Program", ptr %t185, i32 0, i32 2
  store ptr %t187, ptr %l97, !tbaa !29
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load i32, ptr %l8, !tbaa !23
  %t192 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t188, i32 %t189)
  store i32 %t192, ptr %l100
  br label %bb50
bb50:
  %t193 = load ptr, ptr %l97, !tbaa !29
  %t194 = load i32, ptr %l100, !tbaa !23
  %t195 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t193, i32 %t194)
  store i1 %t195, ptr %l101
  br label %bb51
bb51:
  %t196 = load i1, ptr %l101, !tbaa !21
  br i1 %t196, label %bb52, label %bb53
bb52:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load i32, ptr %l8, !tbaa !23
  %t201 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t197, i32 %t198)
  store i32 %t201, ptr %l105
  br label %bb54
bb53:
  store i64 1, ptr %l102, !tbaa !24
  br label %bb56
bb54:
  %t202 = load i32, ptr %l105, !tbaa !23
  %t203 = call i64 @compiler_2fcheck_2efloatBits(i32 %t202, double 0x3ff0000000000000)
  store i64 %t203, ptr %l106
  br label %bb55
bb55:
  %t204 = load i64, ptr %l106, !tbaa !24
  store i64 %t204, ptr %l102, !tbaa !24
  br label %bb56
bb56:
  %t205 = load ptr, ptr %l92, !tbaa !29
  %t206 = load %"compiler/source:Span", ptr %l93
  %t207 = load i32, ptr %l94, !tbaa !23
  %t208 = load i64, ptr %l102, !tbaa !24
  %t209 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t205, %"compiler/source:Span" %t206, i32 %t207, i64 %t208)
  store ptr %t209, ptr %l107
  br label %bb57
bb57:
  %t210 = load ptr, ptr %l107, !tbaa !29
  store ptr %t210, ptr %l9, !tbaa !29
  %t211 = load ptr, ptr %l0, !tbaa !29
  store ptr %t211, ptr %l108, !tbaa !29
  %t212 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t212, ptr %l109
  %t213 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t213, ptr %l110
  %t214 = load i64, ptr %l7, !tbaa !24
  store i64 %t214, ptr %l111, !tbaa !24
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load %"compiler/source:Span", ptr %l1
  %t217 = load %"compiler/source:Span", ptr %l1
  %t218 = load i32, ptr %l3, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t219
  %t220 = getelementptr { i64, [4 x i64] }, ptr %t219, i32 0, i32 0
  store i64 7, ptr %t220
  %t222 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t217, 0
  %t224 = insertvalue { %"compiler/source:Span", i32 } %t222, i32 %t218, 1
  %t225 = getelementptr { i64, [4 x i64] }, ptr %t219, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t224, ptr %t225
  %t226 = load { i64, [4 x i64] }, ptr %t219
  %t228 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t226, ptr %t228
  %t232 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t215, %"compiler/source:Span" %t216, ptr %t228)
  store ptr %t232, ptr %l118
  br label %bb58
bb58:
  %t233 = load ptr, ptr %l118, !tbaa !29
  store ptr %t233, ptr %l119, !tbaa !29
  %t234 = icmp sge i64 0, 0
  br i1 %t234, label %bb59, label %bb60
bb59:
  %t236 = icmp sle i64 0, 1152921504606846975
  br i1 %t236, label %bb61, label %bb62
bb60:
  call void @__olang_check_failed(ptr @olang_loc_729de81d3b051823_7dce08f61f50e4bf)
  unreachable
bb61:
  %t238 = mul i64 0, 8
  %t239 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t238)
  %t240 = insertvalue { i64, ptr } undef, i64 0, 0
  %t241 = insertvalue { i64, ptr } %t240, ptr %t239, 1
  store { i64, ptr } %t241, ptr %l122, !tbaa !27
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load ptr, ptr %l9, !tbaa !29
  %t246 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %t242, ptr %t243)
  store { i64, ptr } %t246, ptr %l125
  br label %bb63
bb62:
  call void @__olang_check_failed(ptr @olang_loc_729de81d3b051823_7dce08f61f50e4bf)
  unreachable
bb63:
  %t247 = icmp sge i64 0, 0
  br i1 %t247, label %bb64, label %bb65
bb64:
  %t249 = icmp sle i64 0, 2305843009213693951
  br i1 %t249, label %bb66, label %bb67
bb65:
  call void @__olang_check_failed(ptr @olang_loc_97840d8df2a94e80_8f65c6ae19d7bb5c)
  unreachable
bb66:
  %t251 = mul i64 0, 4
  %t252 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t251)
  %t253 = insertvalue { i64, ptr } undef, i64 0, 0
  %t254 = insertvalue { i64, ptr } %t253, ptr %t252, 1
  %t255 = load ptr, ptr %l108, !tbaa !29
  %t256 = load %"compiler/source:Span", ptr %l109
  %t257 = load %"compiler/source:Span", ptr %l110
  %t258 = load i64, ptr %l111, !tbaa !24
  %t259 = load ptr, ptr %l119, !tbaa !29
  %t260 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t261 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t263 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %s0, ptr %t255, %"compiler/source:Span" %t256, %"compiler/source:Span" %t257, i64 %t258, ptr %t259, { i64, ptr } %t260, { i64, ptr } %t261, { i64, ptr } %t254)
  store ptr %t263, ptr %l129
  br label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_97840d8df2a94e80_8f65c6ae19d7bb5c)
  unreachable
bb68:
  %t264 = load ptr, ptr %l129, !tbaa !29
  %t265 = load ptr, ptr %l0, !tbaa !29
  store ptr %t265, ptr %l130, !tbaa !29
  %t266 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t266, ptr %l131
  %t267 = load ptr, ptr %l2, !tbaa !29
  store ptr %t267, ptr %l132, !tbaa !29
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = load i32, ptr %l3, !tbaa !23
  %t271 = load %"compiler/source:Span", ptr %l1
  %t276 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t268, ptr %t264, i32 %t270, %"compiler/source:Span" %t271)
  store ptr %t276, ptr %l137
  br label %bb69
bb69:
  store { i64, [3 x i64] } zeroinitializer, ptr %t277
  %t278 = getelementptr { i64, [3 x i64] }, ptr %t277, i32 0, i32 0
  store i64 1, ptr %t278
  %t279 = load %"compiler/source:Span", ptr %l131
  %t280 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t279, 0
  %t281 = load ptr, ptr %l132, !tbaa !29
  %t282 = insertvalue { %"compiler/source:Span", ptr, ptr } %t280, ptr %t281, 1
  %t283 = load ptr, ptr %l137, !tbaa !29
  %t284 = insertvalue { %"compiler/source:Span", ptr, ptr } %t282, ptr %t283, 2
  %t285 = getelementptr { i64, [3 x i64] }, ptr %t277, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t284, ptr %t285
  %t286 = load { i64, [3 x i64] }, ptr %t277
  %t288 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t286, ptr %t288
  %t289 = load ptr, ptr %l130, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t289, ptr %t288)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitSets(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l11 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l26 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l40 = alloca i1
  %l46 = alloca ptr
  %l48 = alloca i32
  %l50 = alloca i32
  %l54 = alloca { i64, ptr }
  %l58 = alloca %"compiler/source:Span"
  %l59 = alloca %"compiler/msgs:Msg"
  %l60 = alloca i64
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/ast:TypeDecl", ptr %t5, i32 0, i32 3
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = icmp eq ptr %t8, null
  store i1 %t10, ptr %l11, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l11, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t15 = getelementptr %"compiler/ast:TypeDecl", ptr %t13, i32 0, i32 3
  %t16 = load ptr, ptr %t15, !tbaa !29
  store ptr %t16, ptr %l3, !tbaa !29
  %t18 = load ptr, ptr %l3, !tbaa !29
  store ptr %t18, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t19 = load ptr, ptr %l17, !tbaa !29
  %t20 = icmp ne ptr %t19, null
  br i1 %t20, label %bb7, label %bb8
bb7:
  %t22 = load ptr, ptr %l17, !tbaa !29
  %t23 = load i64, ptr %t22
  %t25 = icmp eq i64 %t23, 2
  store i1 %t25, ptr %l18, !tbaa !21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l18, !tbaa !21
  br i1 %t26, label %bb9, label %bb10
bb9:
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t29 = getelementptr { i64, [6 x i64] }, ptr %t27, i32 0, i32 1
  %t30 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t29, i32 0, i32 0
  %t31 = load { i64, ptr }, ptr %t30
  store { i64, ptr } %t31, ptr %l4, !tbaa !27
  br label %bb11
bb10:
  br label %bb30
bb11:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t39 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t33, i64 -1, i64 %a1, i32 %t35, i32 0)
  store ptr %t39, ptr %l26
  br label %bb12
bb12:
  %t40 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t40, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  store i64 %t44, ptr %l7, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l7, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb28
bb15:
  br label %bb16
bb16:
  %t54 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t54, ptr %l34, !tbaa !27
  %t55 = load i64, ptr %l6, !tbaa !24
  %t57 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr ptr, ptr %t58, i64 %t55
  %t60 = load ptr, ptr %t59, !tbaa !39
  store ptr %t60, ptr %l8, !tbaa !29
  %t62 = load ptr, ptr %l8, !tbaa !29
  %t64 = getelementptr %"compiler/ast:Func", ptr %t62, i32 0, i32 3
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/ast:Sig", ptr %t65, i32 0, i32 2
  %t68 = load i1, ptr %t67, !tbaa !21
  br i1 %t68, label %bb17, label %bb18
bb17:
  %t70 = load ptr, ptr %l8, !tbaa !29
  %t72 = getelementptr %"compiler/ast:Func", ptr %t70, i32 0, i32 3
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/ast:Sig", ptr %t73, i32 0, i32 3
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t76, 0
  %t80 = icmp eq i64 %t78, 0
  store i1 %t80, ptr %l40, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb19
bb19:
  %t82 = load i1, ptr %l40, !tbaa !21
  br i1 %t82, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s5
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l46, !tbaa !29
  %t84 = load ptr, ptr %l8, !tbaa !29
  %t86 = getelementptr %"compiler/ast:Func", ptr %t84, i32 0, i32 0
  %t87 = getelementptr %"compiler/source:Span", ptr %t86, i32 0, i32 0
  %t88 = load i32, ptr %t87, !tbaa !23
  store i32 %t88, ptr %l48, !tbaa !23
  %t89 = load ptr, ptr %l8, !tbaa !29
  %t91 = getelementptr %"compiler/ast:Func", ptr %t89, i32 0, i32 0
  %t92 = getelementptr %"compiler/source:Span", ptr %t91, i32 0, i32 0
  %t93 = load i32, ptr %t92, !tbaa !23
  store i32 %t93, ptr %l50, !tbaa !23
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load ptr, ptr %l8, !tbaa !29
  %t97 = getelementptr %"compiler/ast:Func", ptr %t95, i32 0, i32 2
  %t98 = load i32, ptr %t97, !tbaa !23
  %t101 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t94, i32 %t98)
  store { i64, ptr } %t101, ptr %l54
  br label %bb22
bb21:
  br label %bb26
bb22:
  %t102 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 0
  %t105 = trunc i64 %t103 to i32
  %t106 = load i32, ptr %l50, !tbaa !23
  %t108 = add i32 %t106, %t105
  %t109 = load i32, ptr %l48, !tbaa !23
  %t111 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s5, i32 %t109, i32 %t108)
  store %"compiler/source:Span" %t111, ptr %l58
  br label %bb23
bb23:
  %t112 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitErrsUnwritten(ptr %s5)
  store %"compiler/msgs:Msg" %t112, ptr %l59
  br label %bb24
bb24:
  %t113 = load ptr, ptr %l46, !tbaa !29
  %t114 = load %"compiler/source:Span", ptr %l58
  %t115 = load %"compiler/msgs:Msg", ptr %l59
  %t116 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t113, %"compiler/source:Span" %t114, %"compiler/msgs:Msg" %t115)
  store i64 %t116, ptr %l60
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s5)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s4)
  br label %bb27
bb27:
  %t117 = load i64, ptr %l6, !tbaa !24
  %t119 = add i64 %t117, 1
  store i64 %t119, ptr %l6, !tbaa !24
  br label %bb13
bb28:
  %t121 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t121)
  br label %bb29
bb29:
  br label %bb31
bb30:
  br label %bb31
bb31:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunwind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l5 = alloca ptr
  %l8 = alloca i64
  %l12 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l15 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %l16 = alloca i32
  %l22 = alloca i1
  %s1 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %a0)
  store ptr %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l5, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 9
  %t9 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fsour_Hf9d8b9e9334551fc04613fb711673451(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l8
  br label %bb3
bb3:
  %t11 = load i64, ptr %l8, !tbaa !24
  %t13 = icmp sgt i64 %t11, %a1
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb17
bb5:
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr %"compiler/check:frame", ptr %t17, i32 0, i32 9
  %t21 = call { i32, %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fsour_H1b67a9adff6f6c708503322bb7ca7b5e(ptr %v0, ptr %t19)
  %t22 = extractvalue { i32, %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" } %t21, 1
  %t23 = extractvalue { i32, %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" } %t21, 0
  store i32 %t23, ptr %l16
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb8, label %ok.25
ok.25:
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t22, ptr %l15
  br label %bb7
bb7:
  %t26 = load %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l15
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t26, ptr %l12
  br label %bb10
bb8:
  br label %bb9
bb9:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb10:
  %t27 = load %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l12
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t27, ptr %l3
  %t28 = getelementptr %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l3, i32 0, i32 1
  %t29 = load i64, ptr %t28, !tbaa !24
  %t31 = icmp slt i64 %t29, 0
  br i1 %t31, label %bb11, label %bb12
bb11:
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t35 = getelementptr %"compiler/check:frame", ptr %t33, i32 0, i32 8
  %t36 = getelementptr %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l3, i32 0, i32 0
  %t37 = load i32, ptr %t36, !tbaa !23
  %t40 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H7068c8717e9d582db2941dd2bdd79d55(ptr %v0, ptr %t35, i32 %t37)
  store i1 %t40, ptr %l22
  br label %bb13
bb12:
  %t41 = load ptr, ptr %l2, !tbaa !29
  %t43 = getelementptr %"compiler/check:frame", ptr %t41, i32 0, i32 8
  %t44 = getelementptr %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l3, i32 0, i32 0
  %t45 = load i32, ptr %t44, !tbaa !23
  %t46 = getelementptr %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l3, i32 0, i32 1
  %t47 = load i64, ptr %t46, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %t43, i32 %t45, i64 %t47)
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s1)
  br label %bb16
bb16:
  br label %bb2
bb17:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarInArray(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i64 %a3, i1 %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l18 = alloca i32
  %l22 = alloca i1
  %l27 = alloca i64
  %l30 = alloca i1
  %l35 = alloca i64
  %l40 = alloca ptr
  %l45 = alloca i32
  %l50 = alloca i1
  %l53 = alloca ptr
  %l58 = alloca i32
  %l63 = alloca i1
  %l68 = alloca ptr
  %l73 = alloca i32
  %l74 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l90 = alloca i1
  %s7 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l5, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 2
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l18
  br label %bb4
bb4:
  %t16 = load i32, ptr %l18
  store i32 %t16, ptr %l6
  %t17 = load i32, ptr %l6
  %t19 = trunc i64 25 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb16
bb7:
  br i1 %a4, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t30 = load i32, ptr %l1, !tbaa !23
  %t33 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t29, i32 %t30)
  store i64 %t33, ptr %l27
  br label %bb10
bb9:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb11
bb10:
  %t34 = load i64, ptr %l2, !tbaa !24
  %t35 = load i64, ptr %l27, !tbaa !24
  %t37 = icmp eq i64 %t35, %t34
  store i1 %t37, ptr %l22, !tbaa !21
  br label %bb11
bb11:
  %t39 = load i1, ptr %l22, !tbaa !21
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/check:Checker", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/generic:Program", ptr %t43, i32 0, i32 2
  %t46 = load i32, ptr %l1, !tbaa !23
  %t49 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t45, i32 %t46)
  store i64 %t49, ptr %l35
  br label %bb14
bb13:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb15
bb14:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i64, ptr %l35, !tbaa !24
  %t53 = icmp eq i64 %t51, %t50
  store i1 %t53, ptr %l30, !tbaa !21
  br label %bb15
bb15:
  %t55 = load i1, ptr %l30, !tbaa !21
  store i1 %t55, ptr %rv
  br label %ret
bb16:
  %t56 = load i32, ptr %l6
  %t58 = trunc i64 19 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb22
bb19:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l40, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %l1, !tbaa !23
  %t71 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t67, i32 %t68)
  store i32 %t71, ptr %l45
  br label %bb20
bb20:
  %t72 = load i64, ptr %l2, !tbaa !24
  %t73 = load i64, ptr %l3, !tbaa !24
  %t74 = load i64, ptr %l5, !tbaa !24
  %t76 = add i64 %t74, 1
  %t77 = load ptr, ptr %l40, !tbaa !29
  %t78 = load i32, ptr %l45, !tbaa !23
  %t82 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarInArray(ptr %v0, ptr %t77, i32 %t78, i64 %t72, i64 %t73, i1 true, i64 %t76)
  store i1 %t82, ptr %l50
  br label %bb21
bb21:
  %t83 = load i1, ptr %l50, !tbaa !21
  store i1 %t83, ptr %rv
  br label %ret
bb22:
  %t84 = load i32, ptr %l6
  %t86 = trunc i64 20 to i32
  %t87 = icmp eq i32 %t84, %t86
  br i1 %t87, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb28
bb25:
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l53, !tbaa !29
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/check:Checker", ptr %t90, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = getelementptr %"compiler/generic:Program", ptr %t93, i32 0, i32 2
  %t96 = load i32, ptr %l1, !tbaa !23
  %t99 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t95, i32 %t96)
  store i32 %t99, ptr %l58
  br label %bb26
bb26:
  %t100 = load i64, ptr %l2, !tbaa !24
  %t101 = load i64, ptr %l3, !tbaa !24
  %t102 = load i64, ptr %l5, !tbaa !24
  %t104 = add i64 %t102, 1
  %t105 = load ptr, ptr %l53, !tbaa !29
  %t106 = load i32, ptr %l58, !tbaa !23
  %t110 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarInArray(ptr %v0, ptr %t105, i32 %t106, i64 %t100, i64 %t101, i1 false, i64 %t104)
  store i1 %t110, ptr %l63
  br label %bb27
bb27:
  %t111 = load i1, ptr %l63, !tbaa !21
  store i1 %t111, ptr %rv
  br label %ret
bb28:
  %t112 = load i32, ptr %l6
  %t114 = trunc i64 18 to i32
  %t115 = icmp eq i32 %t112, %t114
  br i1 %t115, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb44
bb31:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = getelementptr %"compiler/generic:Program", ptr %t120, i32 0, i32 2
  store ptr %t122, ptr %l68, !tbaa !29
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/check:Checker", ptr %t123, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t128 = getelementptr %"compiler/generic:Program", ptr %t126, i32 0, i32 2
  %t129 = load i32, ptr %l1, !tbaa !23
  %t132 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t128, i32 %t129)
  store i32 %t132, ptr %l73
  br label %bb32
bb32:
  %t133 = load ptr, ptr %l68, !tbaa !29
  %t134 = load i32, ptr %l73, !tbaa !23
  %t135 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t133, i32 %t134)
  store { i64, ptr } %t135, ptr %l74
  br label %bb33
bb33:
  %t136 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t136, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t137 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t137, 0
  store i64 %t139, ptr %l9, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s7
  %t141 = load i64, ptr %l8, !tbaa !24
  %t142 = load i64, ptr %l9, !tbaa !24
  %t145 = icmp slt i64 %t141, %t142
  %t147 = xor i1 %t145, true
  br i1 %t147, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s7)
  br label %bb43
bb36:
  br label %bb37
bb37:
  %t149 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t149, ptr %l81, !tbaa !27
  %t150 = load i64, ptr %l8, !tbaa !24
  %t152 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = getelementptr i32, ptr %t153, i64 %t150
  %t155 = load i32, ptr %t154, !tbaa !33
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = load i64, ptr %l2, !tbaa !24
  %t160 = load i64, ptr %l3, !tbaa !24
  %t161 = load i64, ptr %l5, !tbaa !24
  %t163 = add i64 %t161, 1
  %t169 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarInArray(ptr %v0, ptr %t157, i32 %t155, i64 %t159, i64 %t160, i1 true, i64 %t163)
  store i1 %t169, ptr %l90
  br label %bb38
bb38:
  %t170 = load i1, ptr %l90, !tbaa !21
  br i1 %t170, label %bb39, label %bb40
bb39:
  call void @__olang_scope_close(ptr %s7)
  store i1 true, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s7)
  br label %bb42
bb42:
  %t172 = load i64, ptr %l8, !tbaa !24
  %t174 = add i64 %t172, 1
  store i64 %t174, ptr %l8, !tbaa !24
  br label %bb34
bb43:
  store i1 false, ptr %rv
  br label %ret
bb44:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIter(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i64 %a4, ptr %a5, i32 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, i64, i64 }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca %"compiler/source:Span"
  %l21 = alloca i32
  %l22 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca %"compiler/source:Span"
  %l37 = alloca i32
  %l38 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca %"compiler/source:Span"
  %l43 = alloca i32
  %l44 = alloca ptr
  %l45 = alloca %"compiler/source:Span"
  %l47 = alloca i32
  %l48 = alloca ptr
  %l53 = alloca i64
  %l57 = alloca { i64, i64, i64 }
  %l62 = alloca ptr
  %l67 = alloca ptr
  %l71 = alloca ptr
  %l72 = alloca %"compiler/source:Span"
  %l73 = alloca i64
  %l77 = alloca ptr
  %l81 = alloca ptr
  %l86 = alloca ptr
  %l96 = alloca i64
  %l98 = alloca ptr
  %l101 = alloca i64
  %l102 = alloca i32
  %l103 = alloca i64
  %l105 = alloca ptr
  %l108 = alloca i64
  %l109 = alloca i32
  %l115 = alloca ptr
  %l116 = alloca ptr
  %l117 = alloca %"compiler/source:Span"
  %l118 = alloca ptr
  %l122 = alloca ptr
  %t19 = alloca { i64, [3 x i64] }, align 8
  %t65 = alloca { i64, [3 x i64] }, align 8
  %t220 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l17, !tbaa !29
  %t2 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t2, ptr %l18
  %t3 = load ptr, ptr %l3, !tbaa !29
  %t6 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t3)
  store i32 %t6, ptr %l21
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l17, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l18
  %t9 = load i32, ptr %l21, !tbaa !23
  %t10 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t7, %"compiler/source:Span" %t8, i32 %t9)
  store i64 %t10, ptr %l22
  br label %bb2
bb2:
  %t11 = load i64, ptr %l22, !tbaa !24
  store i64 %t11, ptr %l7, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load %"compiler/source:Span", ptr %l1
  %t14 = load i64, ptr %l7, !tbaa !24
  %t16 = trunc i64 %t14 to i32
  %t18 = load ptr, ptr %l3, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t19
  %t20 = getelementptr { i64, [3 x i64] }, ptr %t19, i32 0, i32 0
  store i64 0, ptr %t20
  %t22 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t13, 0
  %t24 = insertvalue { %"compiler/source:Span", i32, ptr } %t22, i32 %t16, 1
  %t26 = insertvalue { %"compiler/source:Span", i32, ptr } %t24, ptr %t18, 2
  %t27 = getelementptr { i64, [3 x i64] }, ptr %t19, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t26, ptr %t27
  %t28 = load { i64, [3 x i64] }, ptr %t19
  %t30 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t28, ptr %t30
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t12, ptr %t30)
  br label %bb3
bb3:
  store i64 -1, ptr %l8, !tbaa !24
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t35 = getelementptr %"compiler/ast:ForIn", ptr %t33, i32 0, i32 0
  %t36 = load i32, ptr %t35, !tbaa !23
  %t38 = icmp ne i32 %t36, 0
  br i1 %t38, label %bb4, label %bb5
bb4:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l34, !tbaa !29
  %t41 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t41, ptr %l35
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t42)
  store i32 %t44, ptr %l37
  br label %bb6
bb5:
  br label %bb11
bb6:
  %t45 = load ptr, ptr %l34, !tbaa !29
  %t46 = load %"compiler/source:Span", ptr %l35
  %t47 = load i32, ptr %l37, !tbaa !23
  %t48 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t45, %"compiler/source:Span" %t46, i32 %t47)
  store i64 %t48, ptr %l38
  br label %bb7
bb7:
  %t49 = load i64, ptr %l38, !tbaa !24
  store i64 %t49, ptr %l8, !tbaa !24
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l39, !tbaa !29
  %t51 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t51, ptr %l40
  %t52 = load i64, ptr %l8, !tbaa !24
  %t54 = trunc i64 %t52 to i32
  store i32 %t54, ptr %l43, !tbaa !23
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l44, !tbaa !29
  %t57 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t57, ptr %l45
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t58)
  store i32 %t60, ptr %l47
  br label %bb8
bb8:
  %t61 = load ptr, ptr %l44, !tbaa !29
  %t62 = load %"compiler/source:Span", ptr %l45
  %t63 = load i32, ptr %l47, !tbaa !23
  %t64 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t61, %"compiler/source:Span" %t62, i32 %t63, i64 0)
  store ptr %t64, ptr %l48
  br label %bb9
bb9:
  store { i64, [3 x i64] } zeroinitializer, ptr %t65
  %t66 = getelementptr { i64, [3 x i64] }, ptr %t65, i32 0, i32 0
  store i64 0, ptr %t66
  %t67 = load %"compiler/source:Span", ptr %l40
  %t68 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t67, 0
  %t69 = load i32, ptr %l43, !tbaa !23
  %t70 = insertvalue { %"compiler/source:Span", i32, ptr } %t68, i32 %t69, 1
  %t71 = load ptr, ptr %l48, !tbaa !29
  %t72 = insertvalue { %"compiler/source:Span", i32, ptr } %t70, ptr %t71, 2
  %t73 = getelementptr { i64, [3 x i64] }, ptr %t65, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t72, ptr %t73
  %t74 = load { i64, [3 x i64] }, ptr %t65
  %t76 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t74, ptr %t76
  %t77 = load ptr, ptr %l39, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t77, ptr %t76)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 33
  %t83 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t81)
  store i64 %t83, ptr %l53
  br label %bb12
bb12:
  %t84 = load i64, ptr %l53, !tbaa !24
  store i64 %t84, ptr %l9, !tbaa !24
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load %"compiler/source:Span", ptr %l1
  %t90 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t85, i32 2, %"compiler/source:Span" %t86)
  store { i64, i64, i64 } %t90, ptr %l57
  br label %bb13
bb13:
  %t91 = load { i64, i64, i64 }, ptr %l57
  store { i64, i64, i64 } %t91, ptr %l10
  %t92 = getelementptr { i64, i64, i64 }, ptr %l10, i32 0, i32 0
  %t93 = load i64, ptr %t92, !tbaa !24
  store i64 %t93, ptr %l11, !tbaa !24
  %t95 = getelementptr { i64, i64, i64 }, ptr %l10, i32 0, i32 1
  %t96 = load i64, ptr %t95, !tbaa !24
  store i64 %t96, ptr %l12, !tbaa !24
  %t98 = getelementptr { i64, i64, i64 }, ptr %l10, i32 0, i32 2
  %t99 = load i64, ptr %t98, !tbaa !24
  store i64 %t99, ptr %l13, !tbaa !24
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t101)
  store ptr %t103, ptr %l62
  br label %bb14
bb14:
  %t104 = load ptr, ptr %l62, !tbaa !29
  %t106 = getelementptr %"compiler/check:frame", ptr %t104, i32 0, i32 10
  %t107 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t106, i64 %t107)
  br label %bb15
bb15:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t110)
  store ptr %t112, ptr %l67
  br label %bb16
bb16:
  %t113 = load ptr, ptr %l67, !tbaa !29
  %t115 = getelementptr %"compiler/check:frame", ptr %t113, i32 0, i32 11
  %t116 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t115, i64 %t116)
  br label %bb17
bb17:
  %t119 = load ptr, ptr %l0, !tbaa !29
  store ptr %t119, ptr %l71, !tbaa !29
  %t120 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t120, ptr %l72
  store i64 %a4, ptr %l73, !tbaa !24
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load %"compiler/source:Span", ptr %l1
  %t124 = load i64, ptr %l7, !tbaa !24
  %t128 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t122, %"compiler/source:Span" %t123, i64 %t124)
  store ptr %t128, ptr %l77
  br label %bb18
bb18:
  %t129 = icmp sge i64 0, 0
  br i1 %t129, label %bb19, label %bb20
bb19:
  %t131 = icmp sle i64 0, 1152921504606846975
  br i1 %t131, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_fea4cce0f7542395_82370c360b9a7e9)
  unreachable
bb21:
  %t133 = mul i64 0, 8
  %t134 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t133)
  %t135 = insertvalue { i64, ptr } undef, i64 0, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t134, 1
  %t137 = load ptr, ptr %l71, !tbaa !29
  %t138 = load %"compiler/source:Span", ptr %l72
  %t139 = load i64, ptr %l73, !tbaa !24
  %t140 = load ptr, ptr %l77, !tbaa !29
  %t142 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloopCall(ptr %v0, ptr %t137, %"compiler/source:Span" %t138, i64 %t139, ptr %t140, { i64, ptr } %t136)
  store ptr %t142, ptr %l81
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_fea4cce0f7542395_82370c360b9a7e9)
  unreachable
bb23:
  %t143 = load ptr, ptr %l81, !tbaa !29
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load %"compiler/source:Span", ptr %l1
  %t147 = load i64, ptr %l11, !tbaa !24
  %t152 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexhaustedOrBreak(ptr %v0, ptr %t144, %"compiler/source:Span" %t145, ptr %t143, i64 %t147)
  store ptr %t152, ptr %l86
  br label %bb24
bb24:
  %t153 = load ptr, ptr %l86, !tbaa !29
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load %"compiler/source:Span", ptr %l1
  %t156 = load ptr, ptr %l2, !tbaa !29
  %t157 = load i64, ptr %l8, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelementLocals(ptr %v0, ptr %v1, ptr %t154, %"compiler/source:Span" %t155, ptr %t156, i64 %t157, ptr %t153)
  br label %bb25
bb25:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkBody(ptr %v0, ptr %v1, ptr %v2, ptr %t164, ptr %t165, ptr %a5, i32 %a6)
  br label %bb26
bb26:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t172)
  store ptr %t174, ptr %l98
  br label %bb27
bb27:
  %t175 = load ptr, ptr %l98, !tbaa !29
  %t177 = getelementptr %"compiler/check:frame", ptr %t175, i32 0, i32 10
  %t179 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t177)
  %t180 = extractvalue { i32, i64 } %t179, 1
  %t181 = extractvalue { i32, i64 } %t179, 0
  store i32 %t181, ptr %l102
  %t182 = icmp ne i32 %t181, 0
  br i1 %t182, label %bb29, label %ok.183
ok.183:
  store i64 %t180, ptr %l101
  br label %bb28
bb28:
  %t184 = load i64, ptr %l101, !tbaa !24
  store i64 %t184, ptr %l96, !tbaa !24
  br label %bb31
bb29:
  br label %bb30
bb30:
  call void @__olang_ert_req_clear()
  br label %bb31
bb31:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t185)
  store ptr %t187, ptr %l105
  br label %bb32
bb32:
  %t188 = load ptr, ptr %l105, !tbaa !29
  %t190 = getelementptr %"compiler/check:frame", ptr %t188, i32 0, i32 11
  %t192 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t190)
  %t193 = extractvalue { i32, i64 } %t192, 1
  %t194 = extractvalue { i32, i64 } %t192, 0
  store i32 %t194, ptr %l109
  %t195 = icmp ne i32 %t194, 0
  br i1 %t195, label %bb34, label %ok.196
ok.196:
  store i64 %t193, ptr %l108
  br label %bb33
bb33:
  %t197 = load i64, ptr %l108, !tbaa !24
  store i64 %t197, ptr %l103, !tbaa !24
  br label %bb36
bb34:
  br label %bb35
bb35:
  call void @__olang_ert_req_clear()
  br label %bb36
bb36:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t199 = load i64, ptr %l11, !tbaa !24
  %t200 = load i64, ptr %l12, !tbaa !24
  %t201 = load i64, ptr %l13, !tbaa !24
  %t202 = load i64, ptr %l9, !tbaa !24
  %t208 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t198, i64 %t199, i64 %t200, i64 %t201, i64 %t202)
  store ptr %t208, ptr %l115
  br label %bb37
bb37:
  %t209 = load ptr, ptr %l115, !tbaa !29
  %t210 = load ptr, ptr %l0, !tbaa !29
  store ptr %t210, ptr %l116, !tbaa !29
  %t211 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t211, ptr %l117
  store ptr %t209, ptr %l118, !tbaa !29
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load %"compiler/source:Span", ptr %l1
  %t215 = load i64, ptr %l8, !tbaa !24
  %t219 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecountPost(ptr %v0, ptr %t213, %"compiler/source:Span" %t214, i64 %t215)
  store ptr %t219, ptr %l122
  br label %bb38
bb38:
  store { i64, [3 x i64] } zeroinitializer, ptr %t220
  %t221 = getelementptr { i64, [3 x i64] }, ptr %t220, i32 0, i32 0
  store i64 4, ptr %t221
  %t222 = load %"compiler/source:Span", ptr %l117
  %t223 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t222, 0
  %t224 = load ptr, ptr %l118, !tbaa !29
  %t225 = insertvalue { %"compiler/source:Span", ptr, ptr } %t223, ptr %t224, 1
  %t226 = load ptr, ptr %l122, !tbaa !29
  %t227 = insertvalue { %"compiler/source:Span", ptr, ptr } %t225, ptr %t226, 2
  %t228 = getelementptr { i64, [3 x i64] }, ptr %t220, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t227, ptr %t228
  %t229 = load { i64, [3 x i64] }, ptr %t220
  %t231 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t229, ptr %t231
  %t232 = load ptr, ptr %l116, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t232, ptr %t231)
  br label %bb39
bb39:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkRuns(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i64 %a4, ptr %a5, i32 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, i64, i64 }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca { i64, i64, i64 }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l26 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca { i64, i64, i64 }
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l39 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca %"compiler/source:Span"
  %l43 = alloca i32
  %l44 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca %"compiler/source:Span"
  %l49 = alloca i32
  %l50 = alloca ptr
  %l51 = alloca %"compiler/source:Span"
  %l53 = alloca i32
  %l54 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca %"compiler/source:Span"
  %l63 = alloca i32
  %l64 = alloca i64
  %l65 = alloca ptr
  %l66 = alloca %"compiler/source:Span"
  %l69 = alloca i32
  %l70 = alloca ptr
  %l71 = alloca %"compiler/source:Span"
  %l73 = alloca i32
  %l74 = alloca ptr
  %l79 = alloca i64
  %l83 = alloca { i64, i64, i64 }
  %l88 = alloca ptr
  %l93 = alloca ptr
  %l97 = alloca ptr
  %l98 = alloca %"compiler/source:Span"
  %l99 = alloca i64
  %l103 = alloca ptr
  %l104 = alloca ptr
  %l108 = alloca ptr
  %l109 = alloca { i64, ptr }
  %l110 = alloca ptr
  %l113 = alloca i32
  %l117 = alloca i64
  %l118 = alloca ptr
  %l119 = alloca %"compiler/source:Span"
  %l122 = alloca i32
  %l127 = alloca ptr
  %l130 = alloca ptr
  %l131 = alloca %"compiler/source:Span"
  %l133 = alloca i32
  %l134 = alloca i64
  %l135 = alloca ptr
  %l136 = alloca %"compiler/source:Span"
  %l139 = alloca i32
  %l140 = alloca ptr
  %l141 = alloca %"compiler/source:Span"
  %l143 = alloca i32
  %l144 = alloca i32
  %l148 = alloca ptr
  %l149 = alloca ptr
  %l152 = alloca ptr
  %l153 = alloca %"compiler/source:Span"
  %l155 = alloca i32
  %l156 = alloca i64
  %l157 = alloca ptr
  %l158 = alloca %"compiler/source:Span"
  %l161 = alloca i32
  %l162 = alloca ptr
  %l163 = alloca %"compiler/source:Span"
  %l165 = alloca i32
  %l166 = alloca ptr
  %l171 = alloca i64
  %l175 = alloca { i64, i64, i64 }
  %l179 = alloca i64
  %l181 = alloca ptr
  %l184 = alloca i64
  %l185 = alloca i32
  %l187 = alloca ptr
  %l191 = alloca ptr
  %l192 = alloca ptr
  %l193 = alloca %"compiler/source:Span"
  %l194 = alloca ptr
  %l195 = alloca %"compiler/source:Span"
  %l196 = alloca i32
  %l197 = alloca i32
  %l201 = alloca ptr
  %l205 = alloca ptr
  %l207 = alloca ptr
  %l209 = alloca ptr
  %l212 = alloca i32
  %l213 = alloca %"compiler/source:Span"
  %l216 = alloca i32
  %l220 = alloca ptr
  %l223 = alloca ptr
  %l224 = alloca %"compiler/source:Span"
  %l225 = alloca %"compiler/source:Span"
  %l230 = alloca i32
  %l231 = alloca ptr
  %l235 = alloca ptr
  %l237 = alloca %"compiler/typed:Elem"
  %l241 = alloca ptr
  %l251 = alloca i64
  %l253 = alloca ptr
  %l256 = alloca i64
  %l257 = alloca i32
  %l258 = alloca i64
  %l260 = alloca ptr
  %l263 = alloca i64
  %l264 = alloca i32
  %l270 = alloca ptr
  %l273 = alloca i64
  %l277 = alloca { i64, i64, i64 }
  %l281 = alloca ptr
  %l282 = alloca %"compiler/source:Span"
  %l283 = alloca %"compiler/source:Span"
  %l285 = alloca i32
  %l290 = alloca ptr
  %l291 = alloca ptr
  %l292 = alloca %"compiler/source:Span"
  %l294 = alloca i32
  %l295 = alloca i32
  %l299 = alloca ptr
  %l300 = alloca ptr
  %l301 = alloca %"compiler/source:Span"
  %l303 = alloca i32
  %l304 = alloca ptr
  %l306 = alloca ptr
  %l311 = alloca ptr
  %l312 = alloca %"compiler/source:Span"
  %l313 = alloca %"compiler/source:Span"
  %l315 = alloca i32
  %l320 = alloca ptr
  %l321 = alloca ptr
  %l322 = alloca %"compiler/source:Span"
  %l324 = alloca i32
  %l325 = alloca i32
  %l329 = alloca ptr
  %l330 = alloca ptr
  %l331 = alloca %"compiler/source:Span"
  %l333 = alloca i32
  %l334 = alloca ptr
  %l336 = alloca ptr
  %l344 = alloca ptr
  %l352 = alloca ptr
  %l353 = alloca %"compiler/source:Span"
  %l354 = alloca %"compiler/source:Span"
  %l356 = alloca i32
  %l361 = alloca ptr
  %l362 = alloca ptr
  %l363 = alloca %"compiler/source:Span"
  %l365 = alloca i32
  %l366 = alloca i32
  %l370 = alloca ptr
  %l374 = alloca ptr
  %l376 = alloca ptr
  %l384 = alloca ptr
  %t34 = alloca { i64, [3 x i64] }, align 8
  %t80 = alloca { i64, [3 x i64] }, align 8
  %t190 = alloca { i64, [3 x i64] }, align 8
  %t238 = alloca { i64, [3 x i64] }, align 8
  %t277 = alloca { i64, [3 x i64] }, align 8
  %t390 = alloca { i64, [4 x i64] }, align 8
  %t430 = alloca { i64, [4 x i64] }, align 8
  %t535 = alloca { i64, [4 x i64] }, align 8
  %t576 = alloca { i64, [3 x i64] }, align 8
  %t604 = alloca { i64, [4 x i64] }, align 8
  %t645 = alloca { i64, [3 x i64] }, align 8
  %t676 = alloca { i64, [3 x i64] }, align 8
  %t700 = alloca { i64, [4 x i64] }, align 8
  %t739 = alloca { i64, [3 x i64] }, align 8
  %t768 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load %"compiler/source:Span", ptr %l1
  %t7 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eborrowedSource(ptr %v0, ptr %t1, %"compiler/source:Span" %t2, ptr %a3)
  store i64 %t7, ptr %l39
  br label %bb1
bb1:
  %t8 = load i64, ptr %l39, !tbaa !24
  store i64 %t8, ptr %l7, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l40, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t10, ptr %l41
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t11)
  store i32 %t13, ptr %l43
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l40, !tbaa !29
  %t15 = load %"compiler/source:Span", ptr %l41
  %t16 = load i32, ptr %l43, !tbaa !23
  %t17 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t14, %"compiler/source:Span" %t15, i32 %t16)
  store i64 %t17, ptr %l44
  br label %bb3
bb3:
  %t18 = load i64, ptr %l44, !tbaa !24
  store i64 %t18, ptr %l8, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l45, !tbaa !29
  %t20 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t20, ptr %l46
  %t21 = load i64, ptr %l8, !tbaa !24
  %t23 = trunc i64 %t21 to i32
  store i32 %t23, ptr %l49, !tbaa !23
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l50, !tbaa !29
  %t26 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t26, ptr %l51
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t27)
  store i32 %t29, ptr %l53
  br label %bb4
bb4:
  %t30 = load ptr, ptr %l50, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l51
  %t32 = load i32, ptr %l53, !tbaa !23
  %t33 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t30, %"compiler/source:Span" %t31, i32 %t32, i64 0)
  store ptr %t33, ptr %l54
  br label %bb5
bb5:
  store { i64, [3 x i64] } zeroinitializer, ptr %t34
  %t35 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 0
  store i64 0, ptr %t35
  %t36 = load %"compiler/source:Span", ptr %l46
  %t37 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t36, 0
  %t38 = load i32, ptr %l49, !tbaa !23
  %t39 = insertvalue { %"compiler/source:Span", i32, ptr } %t37, i32 %t38, 1
  %t40 = load ptr, ptr %l54, !tbaa !29
  %t41 = insertvalue { %"compiler/source:Span", i32, ptr } %t39, ptr %t40, 2
  %t42 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t41, ptr %t42
  %t43 = load { i64, [3 x i64] }, ptr %t34
  %t45 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t43, ptr %t45
  %t46 = load ptr, ptr %l45, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t46, ptr %t45)
  br label %bb6
bb6:
  store i64 -1, ptr %l9, !tbaa !24
  %t48 = load ptr, ptr %l2, !tbaa !29
  %t50 = getelementptr %"compiler/ast:ForIn", ptr %t48, i32 0, i32 0
  %t51 = load i32, ptr %t50, !tbaa !23
  %t53 = icmp ne i32 %t51, 0
  br i1 %t53, label %bb7, label %bb8
bb7:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l60, !tbaa !29
  %t56 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t56, ptr %l61
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t57)
  store i32 %t59, ptr %l63
  br label %bb9
bb8:
  br label %bb14
bb9:
  %t60 = load ptr, ptr %l60, !tbaa !29
  %t61 = load %"compiler/source:Span", ptr %l61
  %t62 = load i32, ptr %l63, !tbaa !23
  %t63 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t60, %"compiler/source:Span" %t61, i32 %t62)
  store i64 %t63, ptr %l64
  br label %bb10
bb10:
  %t64 = load i64, ptr %l64, !tbaa !24
  store i64 %t64, ptr %l9, !tbaa !24
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l65, !tbaa !29
  %t66 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t66, ptr %l66
  %t67 = load i64, ptr %l9, !tbaa !24
  %t69 = trunc i64 %t67 to i32
  store i32 %t69, ptr %l69, !tbaa !23
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l70, !tbaa !29
  %t72 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t72, ptr %l71
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t73)
  store i32 %t75, ptr %l73
  br label %bb11
bb11:
  %t76 = load ptr, ptr %l70, !tbaa !29
  %t77 = load %"compiler/source:Span", ptr %l71
  %t78 = load i32, ptr %l73, !tbaa !23
  %t79 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t76, %"compiler/source:Span" %t77, i32 %t78, i64 0)
  store ptr %t79, ptr %l74
  br label %bb12
bb12:
  store { i64, [3 x i64] } zeroinitializer, ptr %t80
  %t81 = getelementptr { i64, [3 x i64] }, ptr %t80, i32 0, i32 0
  store i64 0, ptr %t81
  %t82 = load %"compiler/source:Span", ptr %l66
  %t83 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t82, 0
  %t84 = load i32, ptr %l69, !tbaa !23
  %t85 = insertvalue { %"compiler/source:Span", i32, ptr } %t83, i32 %t84, 1
  %t86 = load ptr, ptr %l74, !tbaa !29
  %t87 = insertvalue { %"compiler/source:Span", i32, ptr } %t85, ptr %t86, 2
  %t88 = getelementptr { i64, [3 x i64] }, ptr %t80, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t87, ptr %t88
  %t89 = load { i64, [3 x i64] }, ptr %t80
  %t91 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t89, ptr %t91
  %t92 = load ptr, ptr %l65, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t92, ptr %t91)
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 33
  %t98 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t96)
  store i64 %t98, ptr %l79
  br label %bb15
bb15:
  %t99 = load i64, ptr %l79, !tbaa !24
  store i64 %t99, ptr %l10, !tbaa !24
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load %"compiler/source:Span", ptr %l1
  %t105 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t100, i32 2, %"compiler/source:Span" %t101)
  store { i64, i64, i64 } %t105, ptr %l83
  br label %bb16
bb16:
  %t106 = load { i64, i64, i64 }, ptr %l83
  store { i64, i64, i64 } %t106, ptr %l11
  %t107 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 0
  %t108 = load i64, ptr %t107, !tbaa !24
  store i64 %t108, ptr %l12, !tbaa !24
  %t110 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 1
  %t111 = load i64, ptr %t110, !tbaa !24
  store i64 %t111, ptr %l13, !tbaa !24
  %t113 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 2
  %t114 = load i64, ptr %t113, !tbaa !24
  store i64 %t114, ptr %l14, !tbaa !24
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t116)
  store ptr %t118, ptr %l88
  br label %bb17
bb17:
  %t119 = load ptr, ptr %l88, !tbaa !29
  %t121 = getelementptr %"compiler/check:frame", ptr %t119, i32 0, i32 10
  %t122 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t121, i64 %t122)
  br label %bb18
bb18:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t125)
  store ptr %t127, ptr %l93
  br label %bb19
bb19:
  %t128 = load ptr, ptr %l93, !tbaa !29
  %t130 = getelementptr %"compiler/check:frame", ptr %t128, i32 0, i32 11
  %t131 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t130, i64 %t131)
  br label %bb20
bb20:
  %t134 = load ptr, ptr %l0, !tbaa !29
  store ptr %t134, ptr %l97, !tbaa !29
  %t135 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t135, ptr %l98
  store i64 %a4, ptr %l99, !tbaa !24
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load %"compiler/source:Span", ptr %l1
  %t139 = load i64, ptr %l7, !tbaa !24
  %t143 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t137, %"compiler/source:Span" %t138, i64 %t139)
  store ptr %t143, ptr %l103
  br label %bb21
bb21:
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l104, !tbaa !29
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load %"compiler/source:Span", ptr %l1
  %t147 = load i64, ptr %l8, !tbaa !24
  %t151 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t145, %"compiler/source:Span" %t146, i64 %t147)
  store ptr %t151, ptr %l108
  br label %bb22
bb22:
  %t152 = load ptr, ptr %l104, !tbaa !29
  %t153 = load ptr, ptr %l108, !tbaa !29
  %t154 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %t152, ptr %t153)
  store { i64, ptr } %t154, ptr %l109
  br label %bb23
bb23:
  %t155 = load ptr, ptr %l97, !tbaa !29
  %t156 = load %"compiler/source:Span", ptr %l98
  %t157 = load i64, ptr %l99, !tbaa !24
  %t158 = load ptr, ptr %l103, !tbaa !29
  %t159 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t160 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloopCall(ptr %v0, ptr %t155, %"compiler/source:Span" %t156, i64 %t157, ptr %t158, { i64, ptr } %t159)
  store ptr %t160, ptr %l110
  br label %bb24
bb24:
  %t161 = load ptr, ptr %l110, !tbaa !29
  store ptr %t161, ptr %l15, !tbaa !29
  %t162 = load ptr, ptr %l15, !tbaa !29
  %t165 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t162)
  store i32 %t165, ptr %l113
  br label %bb25
bb25:
  %t166 = load i32, ptr %l113, !tbaa !23
  store i32 %t166, ptr %l16, !tbaa !23
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load %"compiler/source:Span", ptr %l1
  %t169 = load i32, ptr %l16, !tbaa !23
  %t173 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t167, %"compiler/source:Span" %t168, i32 %t169)
  store i64 %t173, ptr %l117
  br label %bb26
bb26:
  %t174 = load i64, ptr %l117, !tbaa !24
  store i64 %t174, ptr %l17, !tbaa !24
  %t175 = load ptr, ptr %l0, !tbaa !29
  store ptr %t175, ptr %l118, !tbaa !29
  %t176 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t176, ptr %l119
  %t177 = load i64, ptr %l17, !tbaa !24
  %t179 = trunc i64 %t177 to i32
  store i32 %t179, ptr %l122, !tbaa !23
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load %"compiler/source:Span", ptr %l1
  %t183 = load ptr, ptr %l15, !tbaa !29
  %t184 = load i64, ptr %l12, !tbaa !24
  %t189 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexhaustedOrBreak(ptr %v0, ptr %t181, %"compiler/source:Span" %t182, ptr %t183, i64 %t184)
  store ptr %t189, ptr %l127
  br label %bb27
bb27:
  store { i64, [3 x i64] } zeroinitializer, ptr %t190
  %t191 = getelementptr { i64, [3 x i64] }, ptr %t190, i32 0, i32 0
  store i64 0, ptr %t191
  %t192 = load %"compiler/source:Span", ptr %l119
  %t193 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t192, 0
  %t194 = load i32, ptr %l122, !tbaa !23
  %t195 = insertvalue { %"compiler/source:Span", i32, ptr } %t193, i32 %t194, 1
  %t196 = load ptr, ptr %l127, !tbaa !29
  %t197 = insertvalue { %"compiler/source:Span", i32, ptr } %t195, ptr %t196, 2
  %t198 = getelementptr { i64, [3 x i64] }, ptr %t190, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t197, ptr %t198
  %t199 = load { i64, [3 x i64] }, ptr %t190
  %t201 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t199, ptr %t201
  %t202 = load ptr, ptr %l118, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t202, ptr %t201)
  br label %bb28
bb28:
  %t204 = load ptr, ptr %l0, !tbaa !29
  store ptr %t204, ptr %l130, !tbaa !29
  %t205 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t205, ptr %l131
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t206)
  store i32 %t208, ptr %l133
  br label %bb29
bb29:
  %t209 = load ptr, ptr %l130, !tbaa !29
  %t210 = load %"compiler/source:Span", ptr %l131
  %t211 = load i32, ptr %l133, !tbaa !23
  %t212 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t209, %"compiler/source:Span" %t210, i32 %t211)
  store i64 %t212, ptr %l134
  br label %bb30
bb30:
  %t213 = load i64, ptr %l134, !tbaa !24
  store i64 %t213, ptr %l18, !tbaa !24
  %t214 = load ptr, ptr %l0, !tbaa !29
  store ptr %t214, ptr %l135, !tbaa !29
  %t215 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t215, ptr %l136
  %t216 = load i64, ptr %l18, !tbaa !24
  %t218 = trunc i64 %t216 to i32
  store i32 %t218, ptr %l139, !tbaa !23
  %t220 = load ptr, ptr %l0, !tbaa !29
  store ptr %t220, ptr %l140, !tbaa !29
  %t221 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t221, ptr %l141
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t222)
  store i32 %t224, ptr %l143
  br label %bb31
bb31:
  store i32 22, ptr %l144
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load %"compiler/source:Span", ptr %l1
  %t227 = load i64, ptr %l17, !tbaa !24
  %t231 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t225, %"compiler/source:Span" %t226, i64 %t227)
  store ptr %t231, ptr %l148
  br label %bb32
bb32:
  %t232 = load ptr, ptr %l140, !tbaa !29
  %t233 = load %"compiler/source:Span", ptr %l141
  %t234 = load i32, ptr %l143, !tbaa !23
  %t235 = load i32, ptr %l144
  %t236 = load ptr, ptr %l148, !tbaa !29
  %t237 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t232, %"compiler/source:Span" %t233, i32 %t234, i32 %t235, ptr %t236, ptr null)
  store ptr %t237, ptr %l149
  br label %bb33
bb33:
  store { i64, [3 x i64] } zeroinitializer, ptr %t238
  %t239 = getelementptr { i64, [3 x i64] }, ptr %t238, i32 0, i32 0
  store i64 0, ptr %t239
  %t240 = load %"compiler/source:Span", ptr %l136
  %t241 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t240, 0
  %t242 = load i32, ptr %l139, !tbaa !23
  %t243 = insertvalue { %"compiler/source:Span", i32, ptr } %t241, i32 %t242, 1
  %t244 = load ptr, ptr %l149, !tbaa !29
  %t245 = insertvalue { %"compiler/source:Span", i32, ptr } %t243, ptr %t244, 2
  %t246 = getelementptr { i64, [3 x i64] }, ptr %t238, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t245, ptr %t246
  %t247 = load { i64, [3 x i64] }, ptr %t238
  %t249 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t247, ptr %t249
  %t250 = load ptr, ptr %l135, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t250, ptr %t249)
  br label %bb34
bb34:
  %t252 = load ptr, ptr %l0, !tbaa !29
  store ptr %t252, ptr %l152, !tbaa !29
  %t253 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t253, ptr %l153
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t254)
  store i32 %t256, ptr %l155
  br label %bb35
bb35:
  %t257 = load ptr, ptr %l152, !tbaa !29
  %t258 = load %"compiler/source:Span", ptr %l153
  %t259 = load i32, ptr %l155, !tbaa !23
  %t260 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t257, %"compiler/source:Span" %t258, i32 %t259)
  store i64 %t260, ptr %l156
  br label %bb36
bb36:
  %t261 = load i64, ptr %l156, !tbaa !24
  store i64 %t261, ptr %l19, !tbaa !24
  %t262 = load ptr, ptr %l0, !tbaa !29
  store ptr %t262, ptr %l157, !tbaa !29
  %t263 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t263, ptr %l158
  %t264 = load i64, ptr %l19, !tbaa !24
  %t266 = trunc i64 %t264 to i32
  store i32 %t266, ptr %l161, !tbaa !23
  %t268 = load ptr, ptr %l0, !tbaa !29
  store ptr %t268, ptr %l162, !tbaa !29
  %t269 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t269, ptr %l163
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t272 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t270)
  store i32 %t272, ptr %l165
  br label %bb37
bb37:
  %t273 = load ptr, ptr %l162, !tbaa !29
  %t274 = load %"compiler/source:Span", ptr %l163
  %t275 = load i32, ptr %l165, !tbaa !23
  %t276 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t273, %"compiler/source:Span" %t274, i32 %t275, i64 0)
  store ptr %t276, ptr %l166
  br label %bb38
bb38:
  store { i64, [3 x i64] } zeroinitializer, ptr %t277
  %t278 = getelementptr { i64, [3 x i64] }, ptr %t277, i32 0, i32 0
  store i64 0, ptr %t278
  %t279 = load %"compiler/source:Span", ptr %l158
  %t280 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t279, 0
  %t281 = load i32, ptr %l161, !tbaa !23
  %t282 = insertvalue { %"compiler/source:Span", i32, ptr } %t280, i32 %t281, 1
  %t283 = load ptr, ptr %l166, !tbaa !29
  %t284 = insertvalue { %"compiler/source:Span", i32, ptr } %t282, ptr %t283, 2
  %t285 = getelementptr { i64, [3 x i64] }, ptr %t277, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t284, ptr %t285
  %t286 = load { i64, [3 x i64] }, ptr %t277
  %t288 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t286, ptr %t288
  %t289 = load ptr, ptr %l157, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t289, ptr %t288)
  br label %bb39
bb39:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t293 = getelementptr %"compiler/check:Checker", ptr %t291, i32 0, i32 33
  %t295 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t293)
  store i64 %t295, ptr %l171
  br label %bb40
bb40:
  %t296 = load i64, ptr %l171, !tbaa !24
  store i64 %t296, ptr %l20, !tbaa !24
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load %"compiler/source:Span", ptr %l1
  %t302 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t297, i32 2, %"compiler/source:Span" %t298)
  store { i64, i64, i64 } %t302, ptr %l175
  br label %bb41
bb41:
  %t303 = load { i64, i64, i64 }, ptr %l175
  store { i64, i64, i64 } %t303, ptr %l21
  %t304 = getelementptr { i64, i64, i64 }, ptr %l21, i32 0, i32 0
  %t305 = load i64, ptr %t304, !tbaa !24
  store i64 %t305, ptr %l22, !tbaa !24
  %t307 = getelementptr { i64, i64, i64 }, ptr %l21, i32 0, i32 1
  %t308 = load i64, ptr %t307, !tbaa !24
  store i64 %t308, ptr %l23, !tbaa !24
  %t310 = getelementptr { i64, i64, i64 }, ptr %l21, i32 0, i32 2
  %t311 = load i64, ptr %t310, !tbaa !24
  store i64 %t311, ptr %l24, !tbaa !24
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t315 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t313)
  store ptr %t315, ptr %l181
  br label %bb42
bb42:
  %t316 = load ptr, ptr %l181, !tbaa !29
  %t318 = getelementptr %"compiler/check:frame", ptr %t316, i32 0, i32 10
  %t320 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t318)
  %t321 = extractvalue { i32, i64 } %t320, 1
  %t322 = extractvalue { i32, i64 } %t320, 0
  store i32 %t322, ptr %l185
  %t323 = icmp ne i32 %t322, 0
  br i1 %t323, label %bb44, label %ok.324
ok.324:
  store i64 %t321, ptr %l184
  br label %bb43
bb43:
  %t325 = load i64, ptr %l184, !tbaa !24
  store i64 %t325, ptr %l179, !tbaa !24
  br label %bb46
bb44:
  br label %bb45
bb45:
  call void @__olang_ert_req_clear()
  br label %bb46
bb46:
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t328 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t326)
  store ptr %t328, ptr %l187
  br label %bb47
bb47:
  %t329 = load ptr, ptr %l187, !tbaa !29
  %t331 = getelementptr %"compiler/check:frame", ptr %t329, i32 0, i32 10
  %t332 = load i64, ptr %l22, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t331, i64 %t332)
  br label %bb48
bb48:
  %t335 = load ptr, ptr %l0, !tbaa !29
  store ptr %t335, ptr %l191, !tbaa !29
  %t336 = load ptr, ptr %l0, !tbaa !29
  store ptr %t336, ptr %l192, !tbaa !29
  %t337 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t337, ptr %l193
  %t338 = load ptr, ptr %l0, !tbaa !29
  store ptr %t338, ptr %l194, !tbaa !29
  %t339 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t339, ptr %l195
  %t340 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t340, ptr %l196, !tbaa !23
  store i32 15, ptr %l197
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t342 = load %"compiler/source:Span", ptr %l1
  %t343 = load i64, ptr %l19, !tbaa !24
  %t347 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t341, %"compiler/source:Span" %t342, i64 %t343)
  store ptr %t347, ptr %l201
  br label %bb49
bb49:
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t349 = load %"compiler/source:Span", ptr %l1
  %t350 = load i64, ptr %l18, !tbaa !24
  %t354 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t348, %"compiler/source:Span" %t349, i64 %t350)
  store ptr %t354, ptr %l205
  br label %bb50
bb50:
  %t355 = load ptr, ptr %l205, !tbaa !29
  %t356 = load ptr, ptr %l194, !tbaa !29
  %t357 = load %"compiler/source:Span", ptr %l195
  %t358 = load i32, ptr %l196, !tbaa !23
  %t359 = load i32, ptr %l197
  %t360 = load ptr, ptr %l201, !tbaa !29
  %t362 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t356, %"compiler/source:Span" %t357, i32 %t358, i32 %t359, ptr %t360, ptr %t355)
  store ptr %t362, ptr %l207
  br label %bb51
bb51:
  %t363 = load i64, ptr %l22, !tbaa !24
  %t364 = load ptr, ptr %l192, !tbaa !29
  %t365 = load %"compiler/source:Span", ptr %l193
  %t366 = load ptr, ptr %l207, !tbaa !29
  %t368 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebreakUnless(ptr %v0, ptr %t364, %"compiler/source:Span" %t365, ptr %t366, i64 %t363)
  store ptr %t368, ptr %l209
  br label %bb52
bb52:
  %t369 = load ptr, ptr %l191, !tbaa !29
  %t370 = load ptr, ptr %l209, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t369, ptr %t370)
  br label %bb53
bb53:
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t372 = load i32, ptr %l16, !tbaa !23
  %t375 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t371, i32 %t372)
  store i32 %t375, ptr %l212
  br label %bb54
bb54:
  %t376 = load i32, ptr %l212, !tbaa !23
  store i32 %t376, ptr %l25, !tbaa !23
  %t377 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t377, ptr %l213
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t379 = load i32, ptr %l16, !tbaa !23
  %t382 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t378, i32 %t379)
  store i32 %t382, ptr %l216
  br label %bb55
bb55:
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t384 = load %"compiler/source:Span", ptr %l1
  %t385 = load i64, ptr %l17, !tbaa !24
  %t389 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t383, %"compiler/source:Span" %t384, i64 %t385)
  store ptr %t389, ptr %l220
  br label %bb56
bb56:
  store { i64, [4 x i64] } zeroinitializer, ptr %t390
  %t391 = getelementptr { i64, [4 x i64] }, ptr %t390, i32 0, i32 0
  store i64 2, ptr %t391
  %t392 = load %"compiler/source:Span", ptr %l213
  %t393 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t392, 0
  %t394 = load i32, ptr %l216, !tbaa !23
  %t395 = insertvalue { %"compiler/source:Span", i32, ptr } %t393, i32 %t394, 1
  %t396 = load ptr, ptr %l220, !tbaa !29
  %t397 = insertvalue { %"compiler/source:Span", i32, ptr } %t395, ptr %t396, 2
  %t398 = getelementptr { i64, [4 x i64] }, ptr %t390, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t397, ptr %t398
  %t399 = load { i64, [4 x i64] }, ptr %t390
  %t401 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t399, ptr %t401
  store ptr %t401, ptr %l26, !tbaa !29
  %t403 = load ptr, ptr %l0, !tbaa !29
  store ptr %t403, ptr %l223, !tbaa !29
  %t404 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t404, ptr %l224
  %t405 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t405, ptr %l225
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t408 = getelementptr %"compiler/check:Checker", ptr %t406, i32 0, i32 1
  %t409 = load ptr, ptr %t408, !tbaa !29
  %t411 = getelementptr %"compiler/generic:Program", ptr %t409, i32 0, i32 2
  %t412 = load i32, ptr %l25, !tbaa !23
  %t415 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t411, i32 %t412)
  store i32 %t415, ptr %l230
  br label %bb57
bb57:
  %t416 = load ptr, ptr %l26, !tbaa !29
  store ptr %t416, ptr %l231, !tbaa !29
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t418 = load %"compiler/source:Span", ptr %l1
  %t419 = load i64, ptr %l19, !tbaa !24
  %t423 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t417, %"compiler/source:Span" %t418, i64 %t419)
  store ptr %t423, ptr %l235
  br label %bb58
bb58:
  %t424 = load ptr, ptr %l231, !tbaa !29
  %t425 = load ptr, ptr %l235, !tbaa !29
  %t427 = call %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t424, ptr %t425, i32 0)
  store %"compiler/typed:Elem" %t427, ptr %l237
  br label %bb59
bb59:
  %t428 = load %"compiler/typed:Elem", ptr %l237
  %t429 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Elem" %t428, ptr %t429
  store { i64, [4 x i64] } zeroinitializer, ptr %t430
  %t431 = getelementptr { i64, [4 x i64] }, ptr %t430, i32 0, i32 0
  store i64 4, ptr %t431
  %t432 = load %"compiler/source:Span", ptr %l225
  %t433 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t432, 0
  %t434 = load i32, ptr %l230, !tbaa !23
  %t435 = insertvalue { %"compiler/source:Span", i32, ptr } %t433, i32 %t434, 1
  %t437 = insertvalue { %"compiler/source:Span", i32, ptr } %t435, ptr %t429, 2
  %t438 = getelementptr { i64, [4 x i64] }, ptr %t430, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t437, ptr %t438
  %t439 = load { i64, [4 x i64] }, ptr %t430
  %t441 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t439, ptr %t441
  %t442 = load ptr, ptr %l223, !tbaa !29
  %t443 = load %"compiler/source:Span", ptr %l224
  %t445 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t442, %"compiler/source:Span" %t443, ptr %t441)
  store ptr %t445, ptr %l241
  br label %bb60
bb60:
  %t446 = load ptr, ptr %l241, !tbaa !29
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t448 = load %"compiler/source:Span", ptr %l1
  %t449 = load ptr, ptr %l2, !tbaa !29
  %t450 = load i64, ptr %l9, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelementLocals(ptr %v0, ptr %v1, ptr %t447, %"compiler/source:Span" %t448, ptr %t449, i64 %t450, ptr %t446)
  br label %bb61
bb61:
  %t457 = load ptr, ptr %l0, !tbaa !29
  %t458 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkBody(ptr %v0, ptr %v1, ptr %v2, ptr %t457, ptr %t458, ptr %a5, i32 %a6)
  br label %bb62
bb62:
  %t465 = load ptr, ptr %l0, !tbaa !29
  %t467 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t465)
  store ptr %t467, ptr %l253
  br label %bb63
bb63:
  %t468 = load ptr, ptr %l253, !tbaa !29
  %t470 = getelementptr %"compiler/check:frame", ptr %t468, i32 0, i32 10
  %t472 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t470)
  %t473 = extractvalue { i32, i64 } %t472, 1
  %t474 = extractvalue { i32, i64 } %t472, 0
  store i32 %t474, ptr %l257
  %t475 = icmp ne i32 %t474, 0
  br i1 %t475, label %bb65, label %ok.476
ok.476:
  store i64 %t473, ptr %l256
  br label %bb64
bb64:
  %t477 = load i64, ptr %l256, !tbaa !24
  store i64 %t477, ptr %l251, !tbaa !24
  br label %bb67
bb65:
  br label %bb66
bb66:
  call void @__olang_ert_req_clear()
  br label %bb67
bb67:
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t480 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t478)
  store ptr %t480, ptr %l260
  br label %bb68
bb68:
  %t481 = load ptr, ptr %l260, !tbaa !29
  %t483 = getelementptr %"compiler/check:frame", ptr %t481, i32 0, i32 11
  %t485 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t483)
  %t486 = extractvalue { i32, i64 } %t485, 1
  %t487 = extractvalue { i32, i64 } %t485, 0
  store i32 %t487, ptr %l264
  %t488 = icmp ne i32 %t487, 0
  br i1 %t488, label %bb70, label %ok.489
ok.489:
  store i64 %t486, ptr %l263
  br label %bb69
bb69:
  %t490 = load i64, ptr %l263, !tbaa !24
  store i64 %t490, ptr %l258, !tbaa !24
  br label %bb72
bb70:
  br label %bb71
bb71:
  call void @__olang_ert_req_clear()
  br label %bb72
bb72:
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t492 = load i64, ptr %l22, !tbaa !24
  %t493 = load i64, ptr %l23, !tbaa !24
  %t494 = load i64, ptr %l24, !tbaa !24
  %t495 = load i64, ptr %l20, !tbaa !24
  %t501 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t491, i64 %t492, i64 %t493, i64 %t494, i64 %t495)
  store ptr %t501, ptr %l270
  br label %bb73
bb73:
  %t502 = load ptr, ptr %l270, !tbaa !29
  store ptr %t502, ptr %l28, !tbaa !29
  %t503 = load ptr, ptr %l0, !tbaa !29
  %t505 = getelementptr %"compiler/check:Checker", ptr %t503, i32 0, i32 33
  %t507 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t505)
  store i64 %t507, ptr %l273
  br label %bb74
bb74:
  %t508 = load i64, ptr %l273, !tbaa !24
  store i64 %t508, ptr %l29, !tbaa !24
  %t509 = load ptr, ptr %l0, !tbaa !29
  %t510 = load %"compiler/source:Span", ptr %l1
  %t514 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t509, i32 3, %"compiler/source:Span" %t510)
  store { i64, i64, i64 } %t514, ptr %l277
  br label %bb75
bb75:
  %t515 = load { i64, i64, i64 }, ptr %l277
  store { i64, i64, i64 } %t515, ptr %l30
  %t516 = getelementptr { i64, i64, i64 }, ptr %l30, i32 0, i32 0
  %t517 = load i64, ptr %t516, !tbaa !24
  store i64 %t517, ptr %l31, !tbaa !24
  %t519 = getelementptr { i64, i64, i64 }, ptr %l30, i32 0, i32 1
  %t520 = load i64, ptr %t519, !tbaa !24
  store i64 %t520, ptr %l32, !tbaa !24
  %t522 = getelementptr { i64, i64, i64 }, ptr %l30, i32 0, i32 2
  %t523 = load i64, ptr %t522, !tbaa !24
  store i64 %t523, ptr %l33, !tbaa !24
  %t525 = load ptr, ptr %l0, !tbaa !29
  store ptr %t525, ptr %l281, !tbaa !29
  %t526 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t526, ptr %l282
  %t527 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t527, ptr %l283
  %t528 = load ptr, ptr %l0, !tbaa !29
  %t530 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t528)
  store i32 %t530, ptr %l285
  br label %bb76
bb76:
  %t531 = load i64, ptr %l19, !tbaa !24
  %t533 = trunc i64 %t531 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t535
  %t536 = getelementptr { i64, [4 x i64] }, ptr %t535, i32 0, i32 0
  store i64 0, ptr %t536
  %t537 = load %"compiler/source:Span", ptr %l283
  %t538 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t537, 0
  %t539 = load i32, ptr %l285, !tbaa !23
  %t540 = insertvalue { %"compiler/source:Span", i32, i32 } %t538, i32 %t539, 1
  %t542 = insertvalue { %"compiler/source:Span", i32, i32 } %t540, i32 %t533, 2
  %t543 = getelementptr { i64, [4 x i64] }, ptr %t535, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t542, ptr %t543
  %t544 = load { i64, [4 x i64] }, ptr %t535
  %t546 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t544, ptr %t546
  store ptr %t546, ptr %l290, !tbaa !29
  %t547 = load ptr, ptr %l0, !tbaa !29
  store ptr %t547, ptr %l291, !tbaa !29
  %t548 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t548, ptr %l292
  %t549 = load ptr, ptr %l0, !tbaa !29
  %t551 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t549)
  store i32 %t551, ptr %l294
  br label %bb77
bb77:
  store i32 3, ptr %l295
  %t552 = load ptr, ptr %l0, !tbaa !29
  %t553 = load %"compiler/source:Span", ptr %l1
  %t554 = load i64, ptr %l19, !tbaa !24
  %t558 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t552, %"compiler/source:Span" %t553, i64 %t554)
  store ptr %t558, ptr %l299
  br label %bb78
bb78:
  %t559 = load ptr, ptr %l0, !tbaa !29
  store ptr %t559, ptr %l300, !tbaa !29
  %t560 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t560, ptr %l301
  %t561 = load ptr, ptr %l0, !tbaa !29
  %t563 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t561)
  store i32 %t563, ptr %l303
  br label %bb79
bb79:
  %t564 = load ptr, ptr %l300, !tbaa !29
  %t565 = load %"compiler/source:Span", ptr %l301
  %t566 = load i32, ptr %l303, !tbaa !23
  %t567 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t564, %"compiler/source:Span" %t565, i32 %t566, i64 1)
  store ptr %t567, ptr %l304
  br label %bb80
bb80:
  %t568 = load ptr, ptr %l304, !tbaa !29
  %t569 = load ptr, ptr %l291, !tbaa !29
  %t570 = load %"compiler/source:Span", ptr %l292
  %t571 = load i32, ptr %l294, !tbaa !23
  %t572 = load i32, ptr %l295
  %t573 = load ptr, ptr %l299, !tbaa !29
  %t575 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t569, %"compiler/source:Span" %t570, i32 %t571, i32 %t572, ptr %t573, ptr %t568)
  store ptr %t575, ptr %l306
  br label %bb81
bb81:
  store { i64, [3 x i64] } zeroinitializer, ptr %t576
  %t577 = getelementptr { i64, [3 x i64] }, ptr %t576, i32 0, i32 0
  store i64 1, ptr %t577
  %t578 = load %"compiler/source:Span", ptr %l282
  %t579 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t578, 0
  %t580 = load ptr, ptr %l290, !tbaa !29
  %t581 = insertvalue { %"compiler/source:Span", ptr, ptr } %t579, ptr %t580, 1
  %t582 = load ptr, ptr %l306, !tbaa !29
  %t583 = insertvalue { %"compiler/source:Span", ptr, ptr } %t581, ptr %t582, 2
  %t584 = getelementptr { i64, [3 x i64] }, ptr %t576, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t583, ptr %t584
  %t585 = load { i64, [3 x i64] }, ptr %t576
  %t587 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t585, ptr %t587
  %t588 = load ptr, ptr %l281, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t588, ptr %t587)
  br label %bb82
bb82:
  %t590 = load i64, ptr %l9, !tbaa !24
  %t592 = icmp sge i64 %t590, 0
  br i1 %t592, label %bb83, label %bb84
bb83:
  %t594 = load ptr, ptr %l0, !tbaa !29
  store ptr %t594, ptr %l311, !tbaa !29
  %t595 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t595, ptr %l312
  %t596 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t596, ptr %l313
  %t597 = load ptr, ptr %l0, !tbaa !29
  %t599 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t597)
  store i32 %t599, ptr %l315
  br label %bb85
bb84:
  br label %bb92
bb85:
  %t600 = load i64, ptr %l9, !tbaa !24
  %t602 = trunc i64 %t600 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t604
  %t605 = getelementptr { i64, [4 x i64] }, ptr %t604, i32 0, i32 0
  store i64 0, ptr %t605
  %t606 = load %"compiler/source:Span", ptr %l313
  %t607 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t606, 0
  %t608 = load i32, ptr %l315, !tbaa !23
  %t609 = insertvalue { %"compiler/source:Span", i32, i32 } %t607, i32 %t608, 1
  %t611 = insertvalue { %"compiler/source:Span", i32, i32 } %t609, i32 %t602, 2
  %t612 = getelementptr { i64, [4 x i64] }, ptr %t604, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t611, ptr %t612
  %t613 = load { i64, [4 x i64] }, ptr %t604
  %t615 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t613, ptr %t615
  store ptr %t615, ptr %l320, !tbaa !29
  %t616 = load ptr, ptr %l0, !tbaa !29
  store ptr %t616, ptr %l321, !tbaa !29
  %t617 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t617, ptr %l322
  %t618 = load ptr, ptr %l0, !tbaa !29
  %t620 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t618)
  store i32 %t620, ptr %l324
  br label %bb86
bb86:
  store i32 3, ptr %l325
  %t621 = load ptr, ptr %l0, !tbaa !29
  %t622 = load %"compiler/source:Span", ptr %l1
  %t623 = load i64, ptr %l9, !tbaa !24
  %t627 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t621, %"compiler/source:Span" %t622, i64 %t623)
  store ptr %t627, ptr %l329
  br label %bb87
bb87:
  %t628 = load ptr, ptr %l0, !tbaa !29
  store ptr %t628, ptr %l330, !tbaa !29
  %t629 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t629, ptr %l331
  %t630 = load ptr, ptr %l0, !tbaa !29
  %t632 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t630)
  store i32 %t632, ptr %l333
  br label %bb88
bb88:
  %t633 = load ptr, ptr %l330, !tbaa !29
  %t634 = load %"compiler/source:Span", ptr %l331
  %t635 = load i32, ptr %l333, !tbaa !23
  %t636 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t633, %"compiler/source:Span" %t634, i32 %t635, i64 1)
  store ptr %t636, ptr %l334
  br label %bb89
bb89:
  %t637 = load ptr, ptr %l334, !tbaa !29
  %t638 = load ptr, ptr %l321, !tbaa !29
  %t639 = load %"compiler/source:Span", ptr %l322
  %t640 = load i32, ptr %l324, !tbaa !23
  %t641 = load i32, ptr %l325
  %t642 = load ptr, ptr %l329, !tbaa !29
  %t644 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t638, %"compiler/source:Span" %t639, i32 %t640, i32 %t641, ptr %t642, ptr %t637)
  store ptr %t644, ptr %l336
  br label %bb90
bb90:
  store { i64, [3 x i64] } zeroinitializer, ptr %t645
  %t646 = getelementptr { i64, [3 x i64] }, ptr %t645, i32 0, i32 0
  store i64 1, ptr %t646
  %t647 = load %"compiler/source:Span", ptr %l312
  %t648 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t647, 0
  %t649 = load ptr, ptr %l320, !tbaa !29
  %t650 = insertvalue { %"compiler/source:Span", ptr, ptr } %t648, ptr %t649, 1
  %t651 = load ptr, ptr %l336, !tbaa !29
  %t652 = insertvalue { %"compiler/source:Span", ptr, ptr } %t650, ptr %t651, 2
  %t653 = getelementptr { i64, [3 x i64] }, ptr %t645, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t652, ptr %t653
  %t654 = load { i64, [3 x i64] }, ptr %t645
  %t656 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t654, ptr %t656
  %t657 = load ptr, ptr %l311, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t657, ptr %t656)
  br label %bb91
bb91:
  br label %bb92
bb92:
  %t659 = load ptr, ptr %l0, !tbaa !29
  %t660 = load i64, ptr %l31, !tbaa !24
  %t661 = load i64, ptr %l32, !tbaa !24
  %t662 = load i64, ptr %l33, !tbaa !24
  %t663 = load i64, ptr %l29, !tbaa !24
  %t669 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t659, i64 %t660, i64 %t661, i64 %t662, i64 %t663)
  store ptr %t669, ptr %l344
  br label %bb93
bb93:
  %t670 = load ptr, ptr %l344, !tbaa !29
  %t671 = load ptr, ptr %l0, !tbaa !29
  %t672 = load %"compiler/source:Span", ptr %l1
  %t673 = load ptr, ptr %l28, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t676
  %t677 = getelementptr { i64, [3 x i64] }, ptr %t676, i32 0, i32 0
  store i64 4, ptr %t677
  %t679 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t672, 0
  %t681 = insertvalue { %"compiler/source:Span", ptr, ptr } %t679, ptr %t673, 1
  %t683 = insertvalue { %"compiler/source:Span", ptr, ptr } %t681, ptr %t670, 2
  %t684 = getelementptr { i64, [3 x i64] }, ptr %t676, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t683, ptr %t684
  %t685 = load { i64, [3 x i64] }, ptr %t676
  %t687 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t685, ptr %t687
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t671, ptr %t687)
  br label %bb94
bb94:
  %t690 = load ptr, ptr %l0, !tbaa !29
  store ptr %t690, ptr %l352, !tbaa !29
  %t691 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t691, ptr %l353
  %t692 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t692, ptr %l354
  %t693 = load ptr, ptr %l0, !tbaa !29
  %t695 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t693)
  store i32 %t695, ptr %l356
  br label %bb95
bb95:
  %t696 = load i64, ptr %l8, !tbaa !24
  %t698 = trunc i64 %t696 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t700
  %t701 = getelementptr { i64, [4 x i64] }, ptr %t700, i32 0, i32 0
  store i64 0, ptr %t701
  %t702 = load %"compiler/source:Span", ptr %l354
  %t703 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t702, 0
  %t704 = load i32, ptr %l356, !tbaa !23
  %t705 = insertvalue { %"compiler/source:Span", i32, i32 } %t703, i32 %t704, 1
  %t707 = insertvalue { %"compiler/source:Span", i32, i32 } %t705, i32 %t698, 2
  %t708 = getelementptr { i64, [4 x i64] }, ptr %t700, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t707, ptr %t708
  %t709 = load { i64, [4 x i64] }, ptr %t700
  %t711 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t709, ptr %t711
  store ptr %t711, ptr %l361, !tbaa !29
  %t712 = load ptr, ptr %l0, !tbaa !29
  store ptr %t712, ptr %l362, !tbaa !29
  %t713 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t713, ptr %l363
  %t714 = load ptr, ptr %l0, !tbaa !29
  %t716 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t714)
  store i32 %t716, ptr %l365
  br label %bb96
bb96:
  store i32 3, ptr %l366
  %t717 = load ptr, ptr %l0, !tbaa !29
  %t718 = load %"compiler/source:Span", ptr %l1
  %t719 = load i64, ptr %l8, !tbaa !24
  %t723 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t717, %"compiler/source:Span" %t718, i64 %t719)
  store ptr %t723, ptr %l370
  br label %bb97
bb97:
  %t724 = load ptr, ptr %l0, !tbaa !29
  %t725 = load %"compiler/source:Span", ptr %l1
  %t726 = load i64, ptr %l18, !tbaa !24
  %t730 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t724, %"compiler/source:Span" %t725, i64 %t726)
  store ptr %t730, ptr %l374
  br label %bb98
bb98:
  %t731 = load ptr, ptr %l374, !tbaa !29
  %t732 = load ptr, ptr %l362, !tbaa !29
  %t733 = load %"compiler/source:Span", ptr %l363
  %t734 = load i32, ptr %l365, !tbaa !23
  %t735 = load i32, ptr %l366
  %t736 = load ptr, ptr %l370, !tbaa !29
  %t738 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t732, %"compiler/source:Span" %t733, i32 %t734, i32 %t735, ptr %t736, ptr %t731)
  store ptr %t738, ptr %l376
  br label %bb99
bb99:
  store { i64, [3 x i64] } zeroinitializer, ptr %t739
  %t740 = getelementptr { i64, [3 x i64] }, ptr %t739, i32 0, i32 0
  store i64 1, ptr %t740
  %t741 = load %"compiler/source:Span", ptr %l353
  %t742 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t741, 0
  %t743 = load ptr, ptr %l361, !tbaa !29
  %t744 = insertvalue { %"compiler/source:Span", ptr, ptr } %t742, ptr %t743, 1
  %t745 = load ptr, ptr %l376, !tbaa !29
  %t746 = insertvalue { %"compiler/source:Span", ptr, ptr } %t744, ptr %t745, 2
  %t747 = getelementptr { i64, [3 x i64] }, ptr %t739, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t746, ptr %t747
  %t748 = load { i64, [3 x i64] }, ptr %t739
  %t750 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t748, ptr %t750
  %t751 = load ptr, ptr %l352, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t751, ptr %t750)
  br label %bb100
bb100:
  %t753 = load ptr, ptr %l0, !tbaa !29
  %t754 = load i64, ptr %l12, !tbaa !24
  %t755 = load i64, ptr %l13, !tbaa !24
  %t756 = load i64, ptr %l14, !tbaa !24
  %t757 = load i64, ptr %l10, !tbaa !24
  %t763 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t753, i64 %t754, i64 %t755, i64 %t756, i64 %t757)
  store ptr %t763, ptr %l384
  br label %bb101
bb101:
  %t764 = load ptr, ptr %l384, !tbaa !29
  %t765 = load ptr, ptr %l0, !tbaa !29
  %t766 = load %"compiler/source:Span", ptr %l1
  store { i64, [3 x i64] } zeroinitializer, ptr %t768
  %t769 = getelementptr { i64, [3 x i64] }, ptr %t768, i32 0, i32 0
  store i64 4, ptr %t769
  %t771 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t766, 0
  %t773 = insertvalue { %"compiler/source:Span", ptr, ptr } %t771, ptr %t764, 1
  %t774 = insertvalue { %"compiler/source:Span", ptr, ptr } %t773, ptr null, 2
  %t775 = getelementptr { i64, [3 x i64] }, ptr %t768, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t774, ptr %t775
  %t776 = load { i64, [3 x i64] }, ptr %t768
  %t778 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t776, ptr %t778
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t765, ptr %t778)
  br label %bb102
bb102:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenMet(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/names:Ref"
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca ptr
  %l21 = alloca i1
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca i32
  %l25 = alloca i32
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca ptr
  %l30 = alloca %"compiler/source:Span"
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca i1
  %l59 = alloca i1
  %l61 = alloca ptr
  %l64 = alloca { i64, ptr }
  %l66 = alloca i1
  %l68 = alloca i1
  %l71 = alloca ptr
  %l73 = alloca ptr
  %l77 = alloca %"compiler/names:Ref"
  %l82 = alloca { i64, ptr }
  %l88 = alloca i1
  %l89 = alloca i1
  %l93 = alloca i1
  %l97 = alloca i1
  %l98 = alloca ptr
  %l99 = alloca %"compiler/source:Span"
  %l100 = alloca ptr
  %l102 = alloca %"compiler/source:Span"
  %l103 = alloca { i64, ptr }
  %l104 = alloca %"compiler/msgs:Msg"
  %l105 = alloca i64
  %l109 = alloca ptr
  %l111 = alloca ptr
  %l115 = alloca %"compiler/names:Ref"
  %l118 = alloca i1
  %l121 = alloca i1
  %l123 = alloca ptr
  %l126 = alloca { i64, ptr }
  %l131 = alloca i1
  %l135 = alloca ptr
  %l140 = alloca i32
  %l141 = alloca i64
  %l143 = alloca { i64, ptr }
  %l148 = alloca { i64, ptr }
  %l151 = alloca i1
  %l155 = alloca ptr
  %l156 = alloca { i64, ptr }
  %l158 = alloca %"compiler/source:Span"
  %l160 = alloca %"compiler/msgs:Msg"
  %l161 = alloca i64
  %l165 = alloca i1
  %l169 = alloca i1
  %l174 = alloca ptr
  %l175 = alloca { i64, ptr }
  %l177 = alloca %"compiler/source:Span"
  %l182 = alloca %"compiler/msgs:Msg"
  %l183 = alloca i64
  %l194 = alloca i64
  %l197 = alloca i64
  %l215 = alloca { i64, ptr }
  %l218 = alloca i1
  %l222 = alloca ptr
  %l223 = alloca i64
  %l224 = alloca ptr
  %l225 = alloca { i64, ptr }
  %l228 = alloca %"compiler/source:Span"
  %l229 = alloca { i64, [3 x i64] }
  %l230 = alloca %"compiler/msgs:Msg"
  %l241 = alloca i1
  %l245 = alloca i1
  %l247 = alloca { i64, ptr }
  %l249 = alloca { i64, ptr }
  %l250 = alloca i1
  %l251 = alloca i1
  %l254 = alloca ptr
  %l255 = alloca { i64, ptr }
  %l257 = alloca %"compiler/source:Span"
  %l260 = alloca %"compiler/msgs:Msg"
  %l261 = alloca i64
  %l270 = alloca { i64, ptr }
  %l273 = alloca ptr
  %l274 = alloca i1
  %l284 = alloca i1
  %l285 = alloca ptr
  %l289 = alloca i1
  %l291 = alloca ptr
  %l295 = alloca %"compiler/source:Span"
  %l296 = alloca ptr
  %l298 = alloca ptr
  %l300 = alloca ptr
  %l304 = alloca i32
  %l305 = alloca { i64, ptr }
  %l307 = alloca %"compiler/msgs:Msg"
  %l308 = alloca i64
  %l310 = alloca ptr
  %l311 = alloca i1
  %l323 = alloca i1
  %l325 = alloca { i64, ptr }
  %l327 = alloca { i64, ptr }
  %l328 = alloca i1
  %l331 = alloca { i64, ptr }
  %l333 = alloca ptr
  %l339 = alloca %"compiler/source:Span"
  %l340 = alloca %"compiler/msgs:Msg"
  %l341 = alloca i64
  %l342 = alloca ptr
  %l344 = alloca %"compiler/source:Span"
  %l345 = alloca %"compiler/msgs:Msg"
  %l346 = alloca i64
  %l351 = alloca i1
  %l357 = alloca ptr
  %l359 = alloca ptr
  %l364 = alloca i32
  %l368 = alloca i1
  %l372 = alloca i1
  %l377 = alloca i32
  %l380 = alloca i1
  %l381 = alloca ptr
  %l386 = alloca i32
  %l387 = alloca i1
  %l388 = alloca ptr
  %l389 = alloca { i64, ptr }
  %l391 = alloca %"compiler/source:Span"
  %l392 = alloca ptr
  %l397 = alloca i32
  %l398 = alloca { i64, ptr }
  %l400 = alloca %"compiler/msgs:Msg"
  %l401 = alloca i64
  %l403 = alloca ptr
  %l404 = alloca i32
  %l405 = alloca { i64, ptr }
  %l407 = alloca %"compiler/source:Span"
  %l408 = alloca i1
  %l409 = alloca ptr
  %l410 = alloca i1
  %l415 = alloca ptr
  %l416 = alloca i1
  %l423 = alloca i1
  %l427 = alloca i1
  %l431 = alloca i1
  %l436 = alloca i1
  %l440 = alloca ptr
  %l442 = alloca ptr
  %l447 = alloca i32
  %l450 = alloca i1
  %l452 = alloca ptr
  %l454 = alloca %"compiler/source:Span"
  %l455 = alloca i32
  %l457 = alloca %"compiler/source:Span"
  %l460 = alloca %"compiler/source:Span"
  %l463 = alloca { i64, ptr }
  %l465 = alloca %"compiler/msgs:Msg"
  %l466 = alloca i64
  %l469 = alloca ptr
  %l470 = alloca i1
  %l477 = alloca i1
  %l478 = alloca ptr
  %l479 = alloca i1
  %l486 = alloca ptr
  %l487 = alloca %"compiler/source:Span"
  %l488 = alloca ptr
  %l490 = alloca %"compiler/source:Span"
  %l491 = alloca { i64, ptr }
  %l492 = alloca %"compiler/msgs:Msg"
  %l493 = alloca i64
  %l495 = alloca ptr
  %l496 = alloca i1
  %l501 = alloca ptr
  %l502 = alloca i1
  %l510 = alloca ptr
  %l512 = alloca %"compiler/source:Span"
  %l513 = alloca %"compiler/msgs:Msg"
  %l514 = alloca i64
  %l517 = alloca ptr
  %l518 = alloca i1
  %l531 = alloca { i64, ptr }
  %l537 = alloca i1
  %l554 = alloca { i64, ptr }
  %l560 = alloca i1
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s44 = alloca %olang.scope
  %s49 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t7 = load ptr, ptr %l46, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l46, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l47, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l47, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t17, i32 0, i32 0
  %t19 = load %"compiler/source:Span", ptr %t18
  store %"compiler/source:Span" %t19, ptr %l2
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [5 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t23, i32 0, i32 1
  %t25 = load { i64, ptr }, ptr %t24
  store { i64, ptr } %t25, ptr %l3, !tbaa !27
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr { i64, [5 x i64] }, ptr %t27, i32 0, i32 1
  %t30 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t29, i32 0, i32 2
  %t31 = load { i64, ptr }, ptr %t30
  store { i64, ptr } %t31, ptr %l4, !tbaa !27
  br label %bb8
bb7:
  br label %bb201
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t37 = icmp eq i64 %t35, 1
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t39)
  store ptr %t41, ptr %l61
  br label %bb11
bb10:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb13
bb11:
  %t42 = load ptr, ptr %l61, !tbaa !29
  %t44 = getelementptr %"compiler/check:frame", ptr %t42, i32 0, i32 4
  %t45 = getelementptr %"compiler/generic:Context", ptr %t44, i32 0, i32 2
  %t46 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t46, ptr %l64, !tbaa !27
  %t47 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr i32, ptr %t48, i64 0
  %t50 = load i32, ptr %t49, !tbaa !33
  %t53 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_He6be2b0836caba7ddc59483ff74db438(ptr %v0, ptr %t45, i32 %t50)
  store i1 %t53, ptr %l66
  br label %bb12
bb12:
  %t54 = load i1, ptr %l66, !tbaa !21
  %t55 = xor i1 %t54, true
  store i1 %t55, ptr %l59, !tbaa !21
  br label %bb13
bb13:
  %t57 = load i1, ptr %l59, !tbaa !21
  br i1 %t57, label %bb14, label %bb15
bb14:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = getelementptr %"compiler/generic:Program", ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !29
  store ptr %t64, ptr %l71, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t65)
  store ptr %t67, ptr %l73
  br label %bb16
bb15:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb18
bb16:
  %t68 = load ptr, ptr %l73, !tbaa !29
  %t70 = getelementptr %"compiler/check:frame", ptr %t68, i32 0, i32 2
  %t71 = load i64, ptr %t70, !tbaa !24
  %t72 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t73 = load i32, ptr %t72, !tbaa !23
  %t74 = load ptr, ptr %l71, !tbaa !29
  %t77 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t74, i64 %t71, i32 %t73)
  store %"compiler/names:Ref" %t77, ptr %l77
  br label %bb17
bb17:
  %t78 = getelementptr %"compiler/names:Ref", ptr %l77, i32 0, i32 0
  %t79 = load i32, ptr %t78
  %t81 = trunc i64 0 to i32
  %t82 = icmp eq i32 %t79, %t81
  store i1 %t82, ptr %l68, !tbaa !21
  br label %bb18
bb18:
  %t84 = load i1, ptr %l68, !tbaa !21
  br i1 %t84, label %bb19, label %bb20
bb19:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load %"compiler/source:Span", ptr %l2
  %t87 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t87, ptr %l82, !tbaa !27
  %t88 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr i32, ptr %t89, i64 0
  %t91 = load i32, ptr %t90, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknownType(ptr %v0, ptr %t85, %"compiler/source:Span" %t86, i32 %t91)
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb22:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t101 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorTypeHeld(ptr %v0, ptr %v1, ptr %t96, ptr %t97)
  store i1 %t101, ptr %l88
  br label %bb23
bb23:
  %t102 = load i1, ptr %l88, !tbaa !21
  br i1 %t102, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l89, !tbaa !21
  br label %bb27
bb25:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t105 = load ptr, ptr %l1, !tbaa !29
  %t109 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitWritten(ptr %v0, ptr %v1, ptr %v1, ptr %t103, ptr %t104, ptr %t105)
  store i1 %t109, ptr %l93
  br label %bb26
bb26:
  %t110 = load i1, ptr %l93, !tbaa !21
  store i1 %t110, ptr %l89, !tbaa !21
  br label %bb27
bb27:
  %t111 = load i1, ptr %l89, !tbaa !21
  br i1 %t111, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t117 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforeignNamed(ptr %v0, ptr %v1, ptr %t113, ptr %t114)
  store i1 %t117, ptr %l97
  br label %bb31
bb31:
  %t118 = load i1, ptr %l97, !tbaa !21
  br i1 %t118, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s5
  %t119 = load ptr, ptr %l0, !tbaa !29
  store ptr %t119, ptr %l98, !tbaa !29
  %t120 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t120, ptr %l99
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l100, !tbaa !29
  %t122 = load ptr, ptr %l1, !tbaa !29
  %t124 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t122)
  store %"compiler/source:Span" %t124, ptr %l102
  br label %bb34
bb33:
  br label %bb38
bb34:
  %t125 = load ptr, ptr %l100, !tbaa !29
  %t126 = load %"compiler/source:Span", ptr %l102
  %t127 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t125, %"compiler/source:Span" %t126)
  store { i64, ptr } %t127, ptr %l103
  br label %bb35
bb35:
  %t128 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t129 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eForeignByValue(ptr %v0, ptr %s5, { i64, ptr } %t128)
  store %"compiler/msgs:Msg" %t129, ptr %l104
  br label %bb36
bb36:
  %t130 = load ptr, ptr %l98, !tbaa !29
  %t131 = load %"compiler/source:Span", ptr %l99
  %t132 = load %"compiler/msgs:Msg", ptr %l104
  %t133 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t130, %"compiler/source:Span" %t131, %"compiler/msgs:Msg" %t132)
  store i64 %t133, ptr %l105
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb38:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = getelementptr %"compiler/generic:Program", ptr %t138, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !29
  store ptr %t141, ptr %l109, !tbaa !29
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t142)
  store ptr %t144, ptr %l111
  br label %bb39
bb39:
  %t145 = load ptr, ptr %l111, !tbaa !29
  %t147 = getelementptr %"compiler/check:frame", ptr %t145, i32 0, i32 2
  %t148 = load i64, ptr %t147, !tbaa !24
  %t149 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t150 = load i32, ptr %t149, !tbaa !23
  %t151 = load ptr, ptr %l109, !tbaa !29
  %t154 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t151, i64 %t148, i32 %t150)
  store %"compiler/names:Ref" %t154, ptr %l115
  br label %bb40
bb40:
  %t155 = load %"compiler/names:Ref", ptr %l115
  store %"compiler/names:Ref" %t155, ptr %l5
  %t156 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t157 = load i32, ptr %t156
  %t159 = trunc i64 4 to i32
  %t160 = icmp eq i32 %t157, %t159
  br i1 %t160, label %bb41, label %bb42
bb41:
  %t162 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 2
  %t163 = load i64, ptr %t162, !tbaa !24
  %t165 = icmp sge i64 %t163, 0
  store i1 %t165, ptr %l118, !tbaa !21
  br label %bb43
bb42:
  store i1 false, ptr %l118, !tbaa !21
  br label %bb43
bb43:
  %t167 = load i1, ptr %l118, !tbaa !21
  br i1 %t167, label %bb44, label %bb45
bb44:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t168)
  store ptr %t170, ptr %l123
  br label %bb46
bb45:
  store i1 false, ptr %l121, !tbaa !21
  br label %bb48
bb46:
  %t171 = load ptr, ptr %l123, !tbaa !29
  %t173 = getelementptr %"compiler/check:frame", ptr %t171, i32 0, i32 4
  %t174 = getelementptr %"compiler/generic:Context", ptr %t173, i32 0, i32 2
  %t175 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t175, ptr %l126, !tbaa !27
  %t176 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t176, 0
  %t180 = sub i64 %t178, 1
  %t182 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !27
  %t184 = getelementptr i32, ptr %t183, i64 %t180
  %t185 = load i32, ptr %t184, !tbaa !33
  %t188 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_He6be2b0836caba7ddc59483ff74db438(ptr %v0, ptr %t174, i32 %t185)
  store i1 %t188, ptr %l131
  br label %bb47
bb47:
  %t189 = load i1, ptr %l131, !tbaa !21
  %t190 = xor i1 %t189, true
  store i1 %t190, ptr %l121, !tbaa !21
  br label %bb48
bb48:
  %t192 = load i1, ptr %l121, !tbaa !21
  br i1 %t192, label %bb49, label %bb50
bb49:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/check:Checker", ptr %t193, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !29
  %t198 = getelementptr %"compiler/generic:Program", ptr %t196, i32 0, i32 2
  store ptr %t198, ptr %l135, !tbaa !29
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr %"compiler/check:Checker", ptr %t199, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !29
  %t203 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 1
  %t204 = load i64, ptr %t203, !tbaa !24
  %t205 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 2
  %t206 = load i64, ptr %t205, !tbaa !24
  %t210 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t202, i64 %t204, i64 %t206)
  store i32 %t210, ptr %l140
  br label %bb51
bb50:
  br label %bb98
bb51:
  %t211 = load ptr, ptr %l135, !tbaa !29
  %t212 = load i32, ptr %l140, !tbaa !23
  %t213 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %t211, i32 %t212)
  store i64 %t213, ptr %l141
  br label %bb52
bb52:
  %t214 = load i64, ptr %l141, !tbaa !24
  store i64 %t214, ptr %l6, !tbaa !24
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t216, ptr %l143, !tbaa !27
  %t217 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t219 = extractvalue { i64, ptr } %t217, 0
  %t221 = sub i64 %t219, 1
  %t223 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !27
  %t225 = getelementptr i32, ptr %t224, i64 %t221
  %t226 = load i32, ptr %t225, !tbaa !33
  %t229 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t215, i32 %t226)
  store { i64, ptr } %t229, ptr %l148
  br label %bb53
bb53:
  %t230 = load { i64, ptr }, ptr %l148, !tbaa !27
  store { i64, ptr } %t230, ptr %l7, !tbaa !27
  %t231 = load i64, ptr %l6, !tbaa !24
  %t233 = icmp eq i64 %t231, 0
  br i1 %t233, label %bb54, label %bb55
bb54:
  %t235 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t237 = extractvalue { i64, ptr } %t235, 0
  %t239 = icmp sgt i64 %t237, 0
  store i1 %t239, ptr %l151, !tbaa !21
  br label %bb56
bb55:
  store i1 false, ptr %l151, !tbaa !21
  br label %bb56
bb56:
  %t241 = load i1, ptr %l151, !tbaa !21
  br i1 %t241, label %bb57, label %bb58
bb57:
  store %olang.scope zeroinitializer, ptr %s7
  %t242 = load ptr, ptr %l0, !tbaa !29
  store ptr %t242, ptr %l155, !tbaa !29
  %t243 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t243, ptr %l156, !tbaa !27
  %t244 = getelementptr { i64, ptr }, ptr %l156, i32 0, i32 1
  %t245 = load ptr, ptr %t244, !tbaa !27
  %t246 = getelementptr ptr, ptr %t245, i64 0
  %t247 = load ptr, ptr %t246, !tbaa !39
  %t249 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t247)
  store %"compiler/source:Span" %t249, ptr %l158
  br label %bb59
bb58:
  br label %bb62
bb59:
  %t250 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t252 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgsOnNonGeneric(ptr %v0, ptr %s7, { i64, ptr } %t250)
  store %"compiler/msgs:Msg" %t252, ptr %l160
  br label %bb60
bb60:
  %t253 = load ptr, ptr %l155, !tbaa !29
  %t254 = load %"compiler/source:Span", ptr %l158
  %t255 = load %"compiler/msgs:Msg", ptr %l160
  %t256 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t253, %"compiler/source:Span" %t254, %"compiler/msgs:Msg" %t255)
  store i64 %t256, ptr %l161
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb62:
  %t258 = load i64, ptr %l6, !tbaa !24
  %t260 = icmp sgt i64 %t258, 0
  br i1 %t260, label %bb63, label %bb64
bb63:
  %t262 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t264 = extractvalue { i64, ptr } %t262, 0
  %t266 = icmp sgt i64 %t264, 0
  store i1 %t266, ptr %l165, !tbaa !21
  br label %bb65
bb64:
  store i1 false, ptr %l165, !tbaa !21
  br label %bb65
bb65:
  %t268 = load i1, ptr %l165, !tbaa !21
  br i1 %t268, label %bb66, label %bb67
bb66:
  %t269 = load i64, ptr %l6, !tbaa !24
  %t270 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t272 = extractvalue { i64, ptr } %t270, 0
  %t275 = icmp ne i64 %t269, %t272
  store i1 %t275, ptr %l169, !tbaa !21
  br label %bb68
bb67:
  store i1 false, ptr %l169, !tbaa !21
  br label %bb68
bb68:
  %t277 = load i1, ptr %l169, !tbaa !21
  br i1 %t277, label %bb69, label %bb70
bb69:
  store %olang.scope zeroinitializer, ptr %s8
  %t278 = load ptr, ptr %l0, !tbaa !29
  store ptr %t278, ptr %l174, !tbaa !29
  %t279 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t279, ptr %l175, !tbaa !27
  %t280 = getelementptr { i64, ptr }, ptr %l175, i32 0, i32 1
  %t281 = load ptr, ptr %t280, !tbaa !27
  %t282 = getelementptr ptr, ptr %t281, i64 0
  %t283 = load ptr, ptr %t282, !tbaa !39
  %t285 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t283)
  store %"compiler/source:Span" %t285, ptr %l177
  br label %bb71
bb70:
  br label %bb97
bb71:
  %t286 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t287 = load i64, ptr %l6, !tbaa !24
  %t288 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t290 = extractvalue { i64, ptr } %t288, 0
  %t294 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgCount(ptr %v0, ptr %s8, { i64, ptr } %t286, i64 %t287, i64 %t290)
  store %"compiler/msgs:Msg" %t294, ptr %l182
  br label %bb72
bb72:
  %t295 = load ptr, ptr %l174, !tbaa !29
  %t296 = load %"compiler/source:Span", ptr %l177
  %t297 = load %"compiler/msgs:Msg", ptr %l182
  %t298 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t295, %"compiler/source:Span" %t296, %"compiler/msgs:Msg" %t297)
  store i64 %t298, ptr %l183
  br label %bb73
bb73:
  %t299 = load i64, ptr %l183, !tbaa !24
  store i64 %t299, ptr %l8, !tbaa !24
  %t300 = load i64, ptr %l6, !tbaa !24
  %t301 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t303 = extractvalue { i64, ptr } %t301, 0
  %t306 = icmp slt i64 %t300, %t303
  br i1 %t306, label %bb74, label %bb75
bb74:
  store i64 0, ptr %l9, !tbaa !24
  %t308 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t310 = extractvalue { i64, ptr } %t308, 0
  %t312 = sub i64 %t310, 1
  store i64 %t312, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t314 = load i64, ptr %l10, !tbaa !24
  %t315 = load i64, ptr %l9, !tbaa !24
  %t318 = icmp sgt i64 %t314, %t315
  br i1 %t318, label %bb76, label %bb77
bb75:
  br label %bb96
bb76:
  %t320 = load i64, ptr %l11, !tbaa !24
  %t322 = icmp sgt i64 %t320, 0
  br i1 %t322, label %bb78, label %bb79
bb77:
  store i64 0, ptr %l194, !tbaa !24
  br label %bb81
bb78:
  %t324 = load i64, ptr %l10, !tbaa !24
  %t325 = load i64, ptr %l9, !tbaa !24
  %t328 = sub i64 %t324, %t325
  %t329 = load i64, ptr %l11, !tbaa !24
  %t332 = add i64 %t328, %t329
  %t334 = sub i64 %t332, 1
  %t335 = load i64, ptr %l11, !tbaa !24
  %t338 = sdiv i64 %t334, %t335
  store i64 %t338, ptr %l197, !tbaa !24
  br label %bb80
bb79:
  store i64 0, ptr %l197, !tbaa !24
  br label %bb80
bb80:
  %t340 = load i64, ptr %l197, !tbaa !24
  store i64 %t340, ptr %l194, !tbaa !24
  br label %bb81
bb81:
  %t341 = load i64, ptr %l194, !tbaa !24
  store i64 %t341, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb82
bb82:
  store %olang.scope zeroinitializer, ptr %s11
  %t342 = load i64, ptr %l13, !tbaa !24
  %t343 = load i64, ptr %l12, !tbaa !24
  %t346 = icmp slt i64 %t342, %t343
  %t348 = xor i1 %t346, true
  br i1 %t348, label %bb83, label %bb84
bb83:
  call void @__olang_scope_close(ptr %s11)
  br label %bb95
bb84:
  br label %bb85
bb85:
  %t350 = load i64, ptr %l9, !tbaa !24
  %t351 = load i64, ptr %l13, !tbaa !24
  %t352 = load i64, ptr %l11, !tbaa !24
  %t355 = mul i64 %t351, %t352
  %t358 = add i64 %t350, %t355
  store i64 %t358, ptr %l14, !tbaa !24
  %t360 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t360, ptr %l215, !tbaa !27
  %t361 = load i64, ptr %l14, !tbaa !24
  %t363 = getelementptr { i64, ptr }, ptr %l215, i32 0, i32 1
  %t364 = load ptr, ptr %t363, !tbaa !27
  %t365 = getelementptr ptr, ptr %t364, i64 %t361
  %t366 = load ptr, ptr %t365, !tbaa !39
  %t368 = call i1 @compiler_2fcheck_2eisFuncTypeRef(ptr %v1, ptr %t366)
  store i1 %t368, ptr %l218
  br label %bb86
bb86:
  %t369 = load i1, ptr %l218, !tbaa !21
  br i1 %t369, label %bb87, label %bb88
bb87:
  store %olang.scope zeroinitializer, ptr %s12
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t372 = getelementptr %"compiler/check:Checker", ptr %t370, i32 0, i32 1
  %t373 = load ptr, ptr %t372, !tbaa !29
  %t375 = getelementptr %"compiler/generic:Program", ptr %t373, i32 0, i32 0
  %t376 = load ptr, ptr %t375, !tbaa !29
  %t378 = getelementptr %"compiler/load:Loader", ptr %t376, i32 0, i32 4
  %t379 = load ptr, ptr %t378, !tbaa !29
  store ptr %t379, ptr %l222, !tbaa !29
  %t380 = load i64, ptr %l8, !tbaa !24
  store i64 %t380, ptr %l223, !tbaa !24
  %t381 = load ptr, ptr %l0, !tbaa !29
  store ptr %t381, ptr %l224, !tbaa !29
  %t382 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t382, ptr %l225, !tbaa !27
  %t383 = load i64, ptr %l14, !tbaa !24
  %t385 = getelementptr { i64, ptr }, ptr %l225, i32 0, i32 1
  %t386 = load ptr, ptr %t385, !tbaa !27
  %t387 = getelementptr ptr, ptr %t386, i64 %t383
  %t388 = load ptr, ptr %t387, !tbaa !39
  %t390 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t388)
  store %"compiler/source:Span" %t390, ptr %l228
  br label %bb89
bb88:
  br label %bb93
bb89:
  %t391 = load ptr, ptr %l224, !tbaa !29
  %t392 = load %"compiler/source:Span", ptr %l228
  %t393 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t391, %"compiler/source:Span" %t392)
  store { i64, [3 x i64] } %t393, ptr %l229
  br label %bb90
bb90:
  %t394 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteGroupFunctionType(ptr %s12)
  store %"compiler/msgs:Msg" %t394, ptr %l230
  br label %bb91
bb91:
  %t395 = load ptr, ptr %l222, !tbaa !29
  %t396 = load i64, ptr %l223, !tbaa !24
  %t397 = load { i64, [3 x i64] }, ptr %l229
  %t398 = load %"compiler/msgs:Msg", ptr %l230
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s12, ptr %t395, i64 %t396, { i64, [3 x i64] } %t397, %"compiler/msgs:Msg" %t398)
  br label %bb92
bb92:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s11)
  br label %bb95
bb93:
  call void @__olang_scope_close(ptr %s11)
  br label %bb94
bb94:
  %t399 = load i64, ptr %l13, !tbaa !24
  %t401 = add i64 %t399, 1
  store i64 %t401, ptr %l13, !tbaa !24
  br label %bb82
bb95:
  br label %bb96
bb96:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb97:
  br label %bb98
bb98:
  %t404 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t406 = extractvalue { i64, ptr } %t404, 0
  %t408 = icmp eq i64 %t406, 0
  br i1 %t408, label %bb99, label %bb100
bb99:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb100:
  br label %bb101
bb101:
  %t411 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t413 = extractvalue { i64, ptr } %t411, 0
  %t415 = icmp eq i64 %t413, 1
  br i1 %t415, label %bb102, label %bb103
bb102:
  %t417 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t419 = extractvalue { i64, ptr } %t417, 0
  %t421 = icmp sgt i64 %t419, 1
  store i1 %t421, ptr %l241, !tbaa !21
  br label %bb104
bb103:
  store i1 false, ptr %l241, !tbaa !21
  br label %bb104
bb104:
  %t423 = load i1, ptr %l241, !tbaa !21
  br i1 %t423, label %bb105, label %bb106
bb105:
  %t424 = load ptr, ptr %l0, !tbaa !29
  %t425 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t425, ptr %l247, !tbaa !27
  %t426 = getelementptr { i64, ptr }, ptr %l247, i32 0, i32 1
  %t427 = load ptr, ptr %t426, !tbaa !27
  %t428 = getelementptr i32, ptr %t427, i64 0
  %t429 = load i32, ptr %t428, !tbaa !33
  %t432 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t424, i32 %t429)
  store { i64, ptr } %t432, ptr %l249
  br label %bb107
bb106:
  store i1 false, ptr %l245, !tbaa !21
  br label %bb109
bb107:
  %t433 = load { i64, ptr }, ptr %l249, !tbaa !27
  %t434 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t433, { i64, ptr } { i64 5, ptr @.d32 })
  store i1 %t434, ptr %l250
  br label %bb108
bb108:
  %t435 = load i1, ptr %l250, !tbaa !21
  store i1 %t435, ptr %l245, !tbaa !21
  br label %bb109
bb109:
  %t436 = load i1, ptr %l245, !tbaa !21
  br i1 %t436, label %bb110, label %bb111
bb110:
  %t437 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t438 = load i32, ptr %t437
  %t440 = trunc i64 7 to i32
  %t441 = icmp eq i32 %t438, %t440
  store i1 %t441, ptr %l251, !tbaa !21
  br label %bb112
bb111:
  store i1 false, ptr %l251, !tbaa !21
  br label %bb112
bb112:
  %t443 = load i1, ptr %l251, !tbaa !21
  br i1 %t443, label %bb113, label %bb114
bb113:
  store %olang.scope zeroinitializer, ptr %s15
  %t444 = load ptr, ptr %l0, !tbaa !29
  store ptr %t444, ptr %l254, !tbaa !29
  %t445 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t445, ptr %l255, !tbaa !27
  %t446 = getelementptr { i64, ptr }, ptr %l255, i32 0, i32 1
  %t447 = load ptr, ptr %t446, !tbaa !27
  %t448 = getelementptr ptr, ptr %t447, i64 1
  %t449 = load ptr, ptr %t448, !tbaa !39
  %t451 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t449)
  store %"compiler/source:Span" %t451, ptr %l257
  br label %bb115
bb114:
  br label %bb118
bb115:
  %t452 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t454 = extractvalue { i64, ptr } %t452, 0
  %t456 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayTooManyArgs(ptr %s15, i64 %t454)
  store %"compiler/msgs:Msg" %t456, ptr %l260
  br label %bb116
bb116:
  %t457 = load ptr, ptr %l254, !tbaa !29
  %t458 = load %"compiler/source:Span", ptr %l257
  %t459 = load %"compiler/msgs:Msg", ptr %l260
  %t460 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s15, ptr %t457, %"compiler/source:Span" %t458, %"compiler/msgs:Msg" %t459)
  store i64 %t460, ptr %l261
  br label %bb117
bb117:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb118:
  %t462 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t462, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t464 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t466 = extractvalue { i64, ptr } %t464, 0
  store i64 %t466, ptr %l17, !tbaa !24
  br label %bb119
bb119:
  store %olang.scope zeroinitializer, ptr %s17
  %t468 = load i64, ptr %l16, !tbaa !24
  %t469 = load i64, ptr %l17, !tbaa !24
  %t472 = icmp slt i64 %t468, %t469
  %t474 = xor i1 %t472, true
  br i1 %t474, label %bb120, label %bb121
bb120:
  call void @__olang_scope_close(ptr %s17)
  br label %bb176
bb121:
  br label %bb122
bb122:
  %t476 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t476, ptr %l270, !tbaa !27
  %t477 = load i64, ptr %l16, !tbaa !24
  %t479 = getelementptr { i64, ptr }, ptr %l270, i32 0, i32 1
  %t480 = load ptr, ptr %t479, !tbaa !27
  %t481 = getelementptr ptr, ptr %t480, i64 %t477
  %t482 = load ptr, ptr %t481, !tbaa !39
  store ptr %t482, ptr %l18, !tbaa !29
  %t484 = load ptr, ptr %l18, !tbaa !29
  store ptr %t484, ptr %l273, !tbaa !29
  store i1 false, ptr %l274, !tbaa !21
  %t485 = load ptr, ptr %l273, !tbaa !29
  %t486 = icmp ne ptr %t485, null
  br i1 %t486, label %bb123, label %bb124
bb123:
  %t488 = load ptr, ptr %l273, !tbaa !29
  %t489 = load i64, ptr %t488
  %t491 = icmp eq i64 %t489, 4
  store i1 %t491, ptr %l274, !tbaa !21
  br label %bb124
bb124:
  %t492 = load i1, ptr %l274, !tbaa !21
  br i1 %t492, label %bb125, label %bb126
bb125:
  %t493 = load ptr, ptr %l18, !tbaa !29
  %t495 = getelementptr { i64, [5 x i64] }, ptr %t493, i32 0, i32 1
  %t496 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t495, i32 0, i32 0
  %t497 = load %"compiler/source:Span", ptr %t496
  store %"compiler/source:Span" %t497, ptr %l19
  %t499 = load ptr, ptr %l18, !tbaa !29
  %t501 = getelementptr { i64, [5 x i64] }, ptr %t499, i32 0, i32 1
  %t502 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t501, i32 0, i32 1
  %t503 = load ptr, ptr %t502
  store ptr %t503, ptr %l20, !tbaa !29
  %t505 = load ptr, ptr %l18, !tbaa !29
  %t507 = getelementptr { i64, [5 x i64] }, ptr %t505, i32 0, i32 1
  %t508 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t507, i32 0, i32 2
  %t509 = load i1, ptr %t508
  store i1 %t509, ptr %l21, !tbaa !21
  br label %bb127
bb126:
  br label %bb144
bb127:
  %t511 = load i1, ptr %l21, !tbaa !21
  br i1 %t511, label %bb128, label %bb129
bb128:
  %t513 = load ptr, ptr %l0, !tbaa !29
  store ptr %t513, ptr %l285, !tbaa !29
  %t514 = load ptr, ptr %l20, !tbaa !29
  %t516 = icmp eq ptr %t514, null
  br i1 %t516, label %bb130, label %bb131
bb129:
  store i1 false, ptr %l284, !tbaa !21
  br label %bb134
bb130:
  call void @__olang_check_failed(ptr @olang_loc_af641ab471d8e1a7_ff13a1c3a1ffb403)
  unreachable
bb131:
  br label %bb132
bb132:
  %t518 = load ptr, ptr %l20, !tbaa !29
  %t519 = load ptr, ptr %l285, !tbaa !29
  %t521 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erefWritten(ptr %v0, ptr %v1, ptr %t519, ptr %t518)
  store i1 %t521, ptr %l289
  br label %bb133
bb133:
  %t522 = load i1, ptr %l289, !tbaa !21
  %t523 = xor i1 %t522, true
  store i1 %t523, ptr %l284, !tbaa !21
  br label %bb134
bb134:
  %t525 = load i1, ptr %l284, !tbaa !21
  br i1 %t525, label %bb135, label %bb136
bb135:
  store %olang.scope zeroinitializer, ptr %s19
  %t526 = load ptr, ptr %l0, !tbaa !29
  store ptr %t526, ptr %l291, !tbaa !29
  %t527 = getelementptr %"compiler/source:Span", ptr %l19, i32 0, i32 0
  %t528 = load i32, ptr %t527, !tbaa !23
  %t529 = getelementptr %"compiler/source:Span", ptr %l19, i32 0, i32 0
  %t530 = load i32, ptr %t529, !tbaa !23
  %t532 = add i32 %t530, 3
  %t535 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s19, i32 %t528, i32 %t532)
  store %"compiler/source:Span" %t535, ptr %l295
  br label %bb137
bb136:
  br label %bb143
bb137:
  %t536 = load ptr, ptr %l0, !tbaa !29
  store ptr %t536, ptr %l296, !tbaa !29
  %t537 = load ptr, ptr %l0, !tbaa !29
  %t539 = getelementptr %"compiler/check:Checker", ptr %t537, i32 0, i32 1
  %t540 = load ptr, ptr %t539, !tbaa !29
  store ptr %t540, ptr %l298, !tbaa !29
  %t541 = load ptr, ptr %l0, !tbaa !29
  %t543 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t541)
  store ptr %t543, ptr %l300
  br label %bb138
bb138:
  %t544 = load ptr, ptr %l300, !tbaa !29
  %t546 = getelementptr %"compiler/check:frame", ptr %t544, i32 0, i32 4
  %t547 = load ptr, ptr %l20, !tbaa !29
  %t548 = load ptr, ptr %l298, !tbaa !29
  %t551 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v0, ptr %v1, ptr %t548, ptr %t546, ptr %t547)
  store i32 %t551, ptr %l304
  br label %bb139
bb139:
  %t552 = load ptr, ptr %l296, !tbaa !29
  %t553 = load i32, ptr %l304, !tbaa !23
  %t554 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s19, ptr %t552, i32 %t553)
  store { i64, ptr } %t554, ptr %l305
  br label %bb140
bb140:
  %t555 = load { i64, ptr }, ptr %l305, !tbaa !27
  %t556 = extractvalue { i64, ptr } %t555, 0
  %t557 = extractvalue { i64, ptr } %t555, 1
  %t558 = mul i64 %t556, 1
  %t559 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t558)
  call void @llvm.memcpy.p0.p0.i64(ptr %t559, ptr %t557, i64 %t558, i1 false)
  %t560 = insertvalue { i64, ptr } undef, i64 %t556, 0
  %t561 = insertvalue { i64, ptr } %t560, ptr %t559, 1
  %t563 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMutOnValueType(ptr %s19, ptr %s19, { i64, ptr } %t561)
  store %"compiler/msgs:Msg" %t563, ptr %l307
  br label %bb141
bb141:
  %t564 = load ptr, ptr %l291, !tbaa !29
  %t565 = load %"compiler/source:Span", ptr %l295
  %t566 = load %"compiler/msgs:Msg", ptr %l307
  %t567 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s19, ptr %t564, %"compiler/source:Span" %t565, %"compiler/msgs:Msg" %t566)
  store i64 %t567, ptr %l308
  br label %bb142
bb142:
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb143:
  br label %bb145
bb144:
  br label %bb145
bb145:
  %t569 = load ptr, ptr %l18, !tbaa !29
  store ptr %t569, ptr %l310, !tbaa !29
  store i1 false, ptr %l311, !tbaa !21
  %t570 = load ptr, ptr %l310, !tbaa !29
  %t571 = icmp ne ptr %t570, null
  br i1 %t571, label %bb146, label %bb147
bb146:
  %t573 = load ptr, ptr %l310, !tbaa !29
  %t574 = load i64, ptr %t573
  %t576 = icmp eq i64 %t574, 3
  store i1 %t576, ptr %l311, !tbaa !21
  br label %bb147
bb147:
  %t577 = load i1, ptr %l311, !tbaa !21
  br i1 %t577, label %bb148, label %bb149
bb148:
  %t578 = load ptr, ptr %l18, !tbaa !29
  %t580 = getelementptr { i64, [5 x i64] }, ptr %t578, i32 0, i32 1
  %t581 = getelementptr { %"compiler/source:Span", ptr, i32, i1 }, ptr %t580, i32 0, i32 0
  %t582 = load %"compiler/source:Span", ptr %t581
  store %"compiler/source:Span" %t582, ptr %l22
  %t584 = load ptr, ptr %l18, !tbaa !29
  %t586 = getelementptr { i64, [5 x i64] }, ptr %t584, i32 0, i32 1
  %t587 = getelementptr { %"compiler/source:Span", ptr, i32, i1 }, ptr %t586, i32 0, i32 2
  %t588 = load i32, ptr %t587
  store i32 %t588, ptr %l23, !tbaa !23
  br label %bb150
bb149:
  br label %bb169
bb150:
  %t590 = load i32, ptr %l23, !tbaa !23
  %t592 = icmp ne i32 %t590, 0
  br i1 %t592, label %bb151, label %bb152
bb151:
  store %olang.scope zeroinitializer, ptr %s22
  %t594 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t596 = extractvalue { i64, ptr } %t594, 0
  %t598 = icmp eq i64 %t596, 1
  br i1 %t598, label %bb153, label %bb154
bb152:
  br label %bb168
bb153:
  %t600 = load ptr, ptr %l0, !tbaa !29
  %t601 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t601, ptr %l325, !tbaa !27
  %t602 = getelementptr { i64, ptr }, ptr %l325, i32 0, i32 1
  %t603 = load ptr, ptr %t602, !tbaa !27
  %t604 = getelementptr i32, ptr %t603, i64 0
  %t605 = load i32, ptr %t604, !tbaa !33
  %t608 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t600, i32 %t605)
  store { i64, ptr } %t608, ptr %l327
  br label %bb155
bb154:
  store i1 false, ptr %l323, !tbaa !21
  br label %bb157
bb155:
  %t609 = load { i64, ptr }, ptr %l327, !tbaa !27
  %t610 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s22, { i64, ptr } %t609, { i64, ptr } { i64 5, ptr @.d33 })
  store i1 %t610, ptr %l328
  br label %bb156
bb156:
  %t611 = load i1, ptr %l328, !tbaa !21
  store i1 %t611, ptr %l323, !tbaa !21
  br label %bb157
bb157:
  %t612 = load i1, ptr %l323, !tbaa !21
  br i1 %t612, label %bb158, label %bb159
bb158:
  store %olang.scope zeroinitializer, ptr %s23
  %t613 = load ptr, ptr %l0, !tbaa !29
  %t614 = load i32, ptr %l23, !tbaa !23
  %t617 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t613, i32 %t614)
  store { i64, ptr } %t617, ptr %l331
  br label %bb160
bb159:
  store %olang.scope zeroinitializer, ptr %s24
  %t618 = load ptr, ptr %l0, !tbaa !29
  store ptr %t618, ptr %l342, !tbaa !29
  %t619 = load ptr, ptr %l18, !tbaa !29
  %t621 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t619)
  store %"compiler/source:Span" %t621, ptr %l344
  br label %bb164
bb160:
  %t622 = load { i64, ptr }, ptr %l331, !tbaa !27
  %t623 = extractvalue { i64, ptr } %t622, 0
  %t625 = load ptr, ptr %l0, !tbaa !29
  store ptr %t625, ptr %l333, !tbaa !29
  %t626 = getelementptr %"compiler/source:Span", ptr %l22, i32 0, i32 1
  %t627 = load i32, ptr %t626, !tbaa !23
  %t630 = trunc i64 %t623 to i32
  %t633 = sub i32 %t627, %t630
  %t634 = getelementptr %"compiler/source:Span", ptr %l22, i32 0, i32 1
  %t635 = load i32, ptr %t634, !tbaa !23
  %t638 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s23, i32 %t633, i32 %t635)
  store %"compiler/source:Span" %t638, ptr %l339
  br label %bb161
bb161:
  %t639 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNamedScopeOnElement(ptr %s23)
  store %"compiler/msgs:Msg" %t639, ptr %l340
  br label %bb162
bb162:
  %t640 = load ptr, ptr %l333, !tbaa !29
  %t641 = load %"compiler/source:Span", ptr %l339
  %t642 = load %"compiler/msgs:Msg", ptr %l340
  %t643 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s23, ptr %t640, %"compiler/source:Span" %t641, %"compiler/msgs:Msg" %t642)
  store i64 %t643, ptr %l341
  br label %bb163
bb163:
  call void @__olang_scope_close(ptr %s23)
  br label %bb167
bb164:
  %t644 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgNamedScope(ptr %s24)
  store %"compiler/msgs:Msg" %t644, ptr %l345
  br label %bb165
bb165:
  %t645 = load ptr, ptr %l342, !tbaa !29
  %t646 = load %"compiler/source:Span", ptr %l344
  %t647 = load %"compiler/msgs:Msg", ptr %l345
  %t648 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s24, ptr %t645, %"compiler/source:Span" %t646, %"compiler/msgs:Msg" %t647)
  store i64 %t648, ptr %l346
  br label %bb166
bb166:
  call void @__olang_scope_close(ptr %s24)
  br label %bb167
bb167:
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb168:
  br label %bb170
bb169:
  br label %bb170
bb170:
  %t650 = load ptr, ptr %l0, !tbaa !29
  %t651 = load ptr, ptr %l18, !tbaa !29
  %t655 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenMet(ptr %v0, ptr %v1, ptr %t650, ptr %t651)
  store i1 %t655, ptr %l351
  br label %bb171
bb171:
  %t656 = load i1, ptr %l351, !tbaa !21
  %t657 = xor i1 %t656, true
  br i1 %t657, label %bb172, label %bb173
bb172:
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb173:
  br label %bb174
bb174:
  call void @__olang_scope_close(ptr %s17)
  br label %bb175
bb175:
  %t660 = load i64, ptr %l16, !tbaa !24
  %t662 = add i64 %t660, 1
  store i64 %t662, ptr %l16, !tbaa !24
  br label %bb119
bb176:
  %t664 = load ptr, ptr %l0, !tbaa !29
  %t666 = getelementptr %"compiler/check:Checker", ptr %t664, i32 0, i32 1
  %t667 = load ptr, ptr %t666, !tbaa !29
  store ptr %t667, ptr %l357, !tbaa !29
  %t668 = load ptr, ptr %l0, !tbaa !29
  %t670 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t668)
  store ptr %t670, ptr %l359
  br label %bb177
bb177:
  %t671 = load ptr, ptr %l359, !tbaa !29
  %t673 = getelementptr %"compiler/check:frame", ptr %t671, i32 0, i32 4
  %t674 = load ptr, ptr %l1, !tbaa !29
  %t676 = load ptr, ptr %l357, !tbaa !29
  %t679 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v0, ptr %v1, ptr %t676, ptr %t673, ptr %t674)
  store i32 %t679, ptr %l364
  br label %bb178
bb178:
  %t680 = load i32, ptr %l364, !tbaa !23
  store i32 %t680, ptr %l25, !tbaa !23
  %t681 = load ptr, ptr %l0, !tbaa !29
  %t683 = getelementptr %"compiler/check:Checker", ptr %t681, i32 0, i32 70
  %t684 = load i1, ptr %t683, !tbaa !21
  %t686 = xor i1 %t684, true
  br i1 %t686, label %bb179, label %bb180
bb179:
  %t688 = load ptr, ptr %l0, !tbaa !29
  %t690 = getelementptr %"compiler/check:Checker", ptr %t688, i32 0, i32 71
  %t691 = load i1, ptr %t690, !tbaa !21
  %t693 = xor i1 %t691, true
  store i1 %t693, ptr %l368, !tbaa !21
  br label %bb181
bb180:
  store i1 false, ptr %l368, !tbaa !21
  br label %bb181
bb181:
  %t695 = load i1, ptr %l368, !tbaa !21
  br i1 %t695, label %bb182, label %bb183
bb182:
  %t696 = load ptr, ptr %l0, !tbaa !29
  %t698 = getelementptr %"compiler/check:Checker", ptr %t696, i32 0, i32 1
  %t699 = load ptr, ptr %t698, !tbaa !29
  %t701 = getelementptr %"compiler/generic:Program", ptr %t699, i32 0, i32 2
  %t702 = load i32, ptr %l25, !tbaa !23
  %t705 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t701, i32 %t702)
  store i32 %t705, ptr %l377
  br label %bb184
bb183:
  store i1 false, ptr %l372, !tbaa !21
  br label %bb185
bb184:
  %t706 = load i32, ptr %l377
  %t708 = trunc i64 19 to i32
  %t709 = icmp eq i32 %t706, %t708
  store i1 %t709, ptr %l372, !tbaa !21
  br label %bb185
bb185:
  %t711 = load i1, ptr %l372, !tbaa !21
  br i1 %t711, label %bb186, label %bb187
bb186:
  %t712 = load ptr, ptr %l0, !tbaa !29
  store ptr %t712, ptr %l381, !tbaa !29
  %t713 = load ptr, ptr %l0, !tbaa !29
  %t715 = getelementptr %"compiler/check:Checker", ptr %t713, i32 0, i32 1
  %t716 = load ptr, ptr %t715, !tbaa !29
  %t718 = getelementptr %"compiler/generic:Program", ptr %t716, i32 0, i32 2
  %t719 = load i32, ptr %l25, !tbaa !23
  %t722 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t718, i32 %t719)
  store i32 %t722, ptr %l386
  br label %bb188
bb187:
  store i1 false, ptr %l380, !tbaa !21
  br label %bb190
bb188:
  %t723 = load ptr, ptr %l381, !tbaa !29
  %t724 = load i32, ptr %l386, !tbaa !23
  %t725 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunArrayValue(ptr %v0, ptr %t723, i32 %t724)
  store i1 %t725, ptr %l387
  br label %bb189
bb189:
  %t726 = load i1, ptr %l387, !tbaa !21
  store i1 %t726, ptr %l380, !tbaa !21
  br label %bb190
bb190:
  %t727 = load i1, ptr %l380, !tbaa !21
  br i1 %t727, label %bb191, label %bb192
bb191:
  store %olang.scope zeroinitializer, ptr %s28
  %t728 = load ptr, ptr %l0, !tbaa !29
  store ptr %t728, ptr %l388, !tbaa !29
  %t729 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t729, ptr %l389, !tbaa !27
  %t730 = getelementptr { i64, ptr }, ptr %l389, i32 0, i32 1
  %t731 = load ptr, ptr %t730, !tbaa !27
  %t732 = getelementptr ptr, ptr %t731, i64 0
  %t733 = load ptr, ptr %t732, !tbaa !39
  %t735 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t733)
  store %"compiler/source:Span" %t735, ptr %l391
  br label %bb193
bb192:
  br label %bb198
bb193:
  %t736 = load ptr, ptr %l0, !tbaa !29
  store ptr %t736, ptr %l392, !tbaa !29
  %t737 = load ptr, ptr %l0, !tbaa !29
  %t739 = getelementptr %"compiler/check:Checker", ptr %t737, i32 0, i32 1
  %t740 = load ptr, ptr %t739, !tbaa !29
  %t742 = getelementptr %"compiler/generic:Program", ptr %t740, i32 0, i32 2
  %t743 = load i32, ptr %l25, !tbaa !23
  %t746 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t742, i32 %t743)
  store i32 %t746, ptr %l397
  br label %bb194
bb194:
  %t747 = load ptr, ptr %l392, !tbaa !29
  %t748 = load i32, ptr %l397, !tbaa !23
  %t749 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s28, ptr %t747, i32 %t748)
  store { i64, ptr } %t749, ptr %l398
  br label %bb195
bb195:
  %t750 = load { i64, ptr }, ptr %l398, !tbaa !27
  %t751 = extractvalue { i64, ptr } %t750, 0
  %t752 = extractvalue { i64, ptr } %t750, 1
  %t753 = mul i64 %t751, 1
  %t754 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t753)
  call void @llvm.memcpy.p0.p0.i64(ptr %t754, ptr %t752, i64 %t753, i1 false)
  %t755 = insertvalue { i64, ptr } undef, i64 %t751, 0
  %t756 = insertvalue { i64, ptr } %t755, ptr %t754, 1
  %t758 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayNestedByValue(ptr %s28, ptr %s28, { i64, ptr } %t756)
  store %"compiler/msgs:Msg" %t758, ptr %l400
  br label %bb196
bb196:
  %t759 = load ptr, ptr %l388, !tbaa !29
  %t760 = load %"compiler/source:Span", ptr %l391
  %t761 = load %"compiler/msgs:Msg", ptr %l400
  %t762 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s28, ptr %t759, %"compiler/source:Span" %t760, %"compiler/msgs:Msg" %t761)
  store i64 %t762, ptr %l401
  br label %bb197
bb197:
  call void @__olang_scope_close(ptr %s28)
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb198:
  %t764 = load ptr, ptr %l0, !tbaa !29
  store ptr %t764, ptr %l403, !tbaa !29
  %t765 = load i32, ptr %l25, !tbaa !23
  store i32 %t765, ptr %l404, !tbaa !23
  %t766 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t766, ptr %l405, !tbaa !27
  %t767 = getelementptr { i64, ptr }, ptr %l405, i32 0, i32 1
  %t768 = load ptr, ptr %t767, !tbaa !27
  %t769 = getelementptr ptr, ptr %t768, i64 0
  %t770 = load ptr, ptr %t769, !tbaa !39
  %t772 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t770)
  store %"compiler/source:Span" %t772, ptr %l407
  br label %bb199
bb199:
  %t773 = load ptr, ptr %l403, !tbaa !29
  %t774 = load i32, ptr %l404, !tbaa !23
  %t775 = load %"compiler/source:Span", ptr %l407
  %t776 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesMet(ptr %v0, ptr %t773, i32 %t774, %"compiler/source:Span" %t775)
  store i1 %t776, ptr %l408
  br label %bb200
bb200:
  call void @__olang_scope_close(ptr %s2)
  %t777 = load i1, ptr %l408, !tbaa !21
  store i1 %t777, ptr %rv
  br label %ret
bb201:
  %t778 = load ptr, ptr %l1, !tbaa !29
  store ptr %t778, ptr %l409, !tbaa !29
  store i1 false, ptr %l410, !tbaa !21
  %t779 = load ptr, ptr %l409, !tbaa !29
  %t780 = icmp ne ptr %t779, null
  br i1 %t780, label %bb202, label %bb203
bb202:
  %t782 = load ptr, ptr %l409, !tbaa !29
  %t783 = load i64, ptr %t782
  %t785 = icmp eq i64 %t783, 3
  store i1 %t785, ptr %l410, !tbaa !21
  br label %bb203
bb203:
  %t786 = load i1, ptr %l410, !tbaa !21
  br i1 %t786, label %bb204, label %bb205
bb204:
  %t787 = load ptr, ptr %l1, !tbaa !29
  %t789 = getelementptr { i64, [5 x i64] }, ptr %t787, i32 0, i32 1
  %t790 = getelementptr { %"compiler/source:Span", ptr, i32, i1 }, ptr %t789, i32 0, i32 1
  %t791 = load ptr, ptr %t790
  store ptr %t791, ptr %l26, !tbaa !29
  br label %bb206
bb205:
  br label %bb239
bb206:
  %t793 = load ptr, ptr %l26, !tbaa !29
  store ptr %t793, ptr %l415, !tbaa !29
  store i1 false, ptr %l416, !tbaa !21
  %t794 = load ptr, ptr %l415, !tbaa !29
  %t795 = icmp ne ptr %t794, null
  br i1 %t795, label %bb207, label %bb208
bb207:
  %t797 = load ptr, ptr %l415, !tbaa !29
  %t798 = load i64, ptr %t797
  %t800 = icmp eq i64 %t798, 5
  store i1 %t800, ptr %l416, !tbaa !21
  br label %bb208
bb208:
  %t801 = load i1, ptr %l416, !tbaa !21
  br i1 %t801, label %bb209, label %bb210
bb209:
  %t802 = load ptr, ptr %l26, !tbaa !29
  %t804 = getelementptr { i64, [5 x i64] }, ptr %t802, i32 0, i32 1
  %t805 = getelementptr { %"compiler/source:Span", ptr }, ptr %t804, i32 0, i32 1
  %t806 = load ptr, ptr %t805
  store ptr %t806, ptr %l27, !tbaa !29
  br label %bb211
bb210:
  br label %bb213
bb211:
  %t808 = load ptr, ptr %l0, !tbaa !29
  %t809 = load ptr, ptr %l27, !tbaa !29
  %t812 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyWritten(ptr %v0, ptr %v1, ptr %t808, ptr %t809)
  store i1 %t812, ptr %l423
  br label %bb212
bb212:
  %t813 = load i1, ptr %l423, !tbaa !21
  store i1 %t813, ptr %rv
  br label %ret
bb213:
  br label %bb214
bb214:
  %t814 = load ptr, ptr %l0, !tbaa !29
  %t815 = load ptr, ptr %l26, !tbaa !29
  %t816 = load ptr, ptr %l1, !tbaa !29
  %t820 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitWritten(ptr %v0, ptr %v1, ptr %v1, ptr %t814, ptr %t815, ptr %t816)
  store i1 %t820, ptr %l427
  br label %bb215
bb215:
  %t821 = load i1, ptr %l427, !tbaa !21
  br i1 %t821, label %bb216, label %bb217
bb216:
  store i1 false, ptr %rv
  br label %ret
bb217:
  br label %bb218
bb218:
  %t823 = load ptr, ptr %l0, !tbaa !29
  %t824 = load ptr, ptr %l26, !tbaa !29
  %t827 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforeignNamed(ptr %v0, ptr %v1, ptr %t823, ptr %t824)
  store i1 %t827, ptr %l431
  br label %bb219
bb219:
  %t828 = load i1, ptr %l431, !tbaa !21
  br i1 %t828, label %bb220, label %bb221
bb220:
  store i1 true, ptr %rv
  br label %ret
bb221:
  br label %bb222
bb222:
  %t830 = load ptr, ptr %l0, !tbaa !29
  %t831 = load ptr, ptr %l26, !tbaa !29
  %t835 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenMet(ptr %v0, ptr %v1, ptr %t830, ptr %t831)
  store i1 %t835, ptr %l436
  br label %bb223
bb223:
  %t836 = load i1, ptr %l436, !tbaa !21
  %t837 = xor i1 %t836, true
  br i1 %t837, label %bb224, label %bb225
bb224:
  store i1 false, ptr %rv
  br label %ret
bb225:
  br label %bb226
bb226:
  %t840 = load ptr, ptr %l0, !tbaa !29
  %t842 = getelementptr %"compiler/check:Checker", ptr %t840, i32 0, i32 1
  %t843 = load ptr, ptr %t842, !tbaa !29
  store ptr %t843, ptr %l440, !tbaa !29
  %t844 = load ptr, ptr %l0, !tbaa !29
  %t846 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t844)
  store ptr %t846, ptr %l442
  br label %bb227
bb227:
  %t847 = load ptr, ptr %l442, !tbaa !29
  %t849 = getelementptr %"compiler/check:frame", ptr %t847, i32 0, i32 4
  %t850 = load ptr, ptr %l26, !tbaa !29
  %t852 = load ptr, ptr %l440, !tbaa !29
  %t855 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v0, ptr %v1, ptr %t852, ptr %t849, ptr %t850)
  store i32 %t855, ptr %l447
  br label %bb228
bb228:
  %t856 = load i32, ptr %l447, !tbaa !23
  store i32 %t856, ptr %l28, !tbaa !23
  %t857 = load ptr, ptr %l0, !tbaa !29
  %t858 = load i32, ptr %l28, !tbaa !23
  %t861 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereferable(ptr %v0, ptr %t857, i32 %t858)
  store i1 %t861, ptr %l450
  br label %bb229
bb229:
  %t862 = load i1, ptr %l450, !tbaa !21
  %t863 = xor i1 %t862, true
  br i1 %t863, label %bb230, label %bb231
bb230:
  store %olang.scope zeroinitializer, ptr %s35
  %t865 = load ptr, ptr %l0, !tbaa !29
  store ptr %t865, ptr %l452, !tbaa !29
  %t866 = load ptr, ptr %l26, !tbaa !29
  %t868 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t866)
  store %"compiler/source:Span" %t868, ptr %l454
  br label %bb232
bb231:
  br label %bb238
bb232:
  %t869 = getelementptr %"compiler/source:Span", ptr %l454, i32 0, i32 1
  %t870 = load i32, ptr %t869, !tbaa !23
  store i32 %t870, ptr %l455, !tbaa !23
  %t871 = load ptr, ptr %l26, !tbaa !29
  %t873 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t871)
  store %"compiler/source:Span" %t873, ptr %l457
  br label %bb233
bb233:
  %t874 = getelementptr %"compiler/source:Span", ptr %l457, i32 0, i32 1
  %t875 = load i32, ptr %t874, !tbaa !23
  %t877 = add i32 %t875, 1
  %t878 = load i32, ptr %l455, !tbaa !23
  %t880 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s35, i32 %t878, i32 %t877)
  store %"compiler/source:Span" %t880, ptr %l460
  br label %bb234
bb234:
  %t881 = load ptr, ptr %l0, !tbaa !29
  %t882 = load i32, ptr %l28, !tbaa !23
  %t885 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s35, ptr %t881, i32 %t882)
  store { i64, ptr } %t885, ptr %l463
  br label %bb235
bb235:
  %t886 = load { i64, ptr }, ptr %l463, !tbaa !27
  %t887 = extractvalue { i64, ptr } %t886, 0
  %t888 = extractvalue { i64, ptr } %t886, 1
  %t889 = mul i64 %t887, 1
  %t890 = call ptr @__olang_scope_alloc(ptr %s35, i64 %t889)
  call void @llvm.memcpy.p0.p0.i64(ptr %t890, ptr %t888, i64 %t889, i1 false)
  %t891 = insertvalue { i64, ptr } undef, i64 %t887, 0
  %t892 = insertvalue { i64, ptr } %t891, ptr %t890, 1
  %t894 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eInvalidReferenceTarget(ptr %s35, ptr %s35, { i64, ptr } %t892)
  store %"compiler/msgs:Msg" %t894, ptr %l465
  br label %bb236
bb236:
  %t895 = load ptr, ptr %l452, !tbaa !29
  %t896 = load %"compiler/source:Span", ptr %l460
  %t897 = load %"compiler/msgs:Msg", ptr %l465
  %t898 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s35, ptr %t895, %"compiler/source:Span" %t896, %"compiler/msgs:Msg" %t897)
  store i64 %t898, ptr %l466
  br label %bb237
bb237:
  call void @__olang_scope_close(ptr %s35)
  store i1 false, ptr %rv
  br label %ret
bb238:
  store i1 true, ptr %rv
  br label %ret
bb239:
  %t901 = load ptr, ptr %l1, !tbaa !29
  store ptr %t901, ptr %l469, !tbaa !29
  store i1 false, ptr %l470, !tbaa !21
  %t902 = load ptr, ptr %l469, !tbaa !29
  %t903 = icmp ne ptr %t902, null
  br i1 %t903, label %bb240, label %bb241
bb240:
  %t905 = load ptr, ptr %l469, !tbaa !29
  %t906 = load i64, ptr %t905
  %t908 = icmp eq i64 %t906, 4
  store i1 %t908, ptr %l470, !tbaa !21
  br label %bb241
bb241:
  %t909 = load i1, ptr %l470, !tbaa !21
  br i1 %t909, label %bb242, label %bb243
bb242:
  %t910 = load ptr, ptr %l1, !tbaa !29
  %t912 = getelementptr { i64, [5 x i64] }, ptr %t910, i32 0, i32 1
  %t913 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t912, i32 0, i32 1
  %t914 = load ptr, ptr %t913
  store ptr %t914, ptr %l29, !tbaa !29
  br label %bb244
bb243:
  br label %bb246
bb244:
  %t916 = load ptr, ptr %l0, !tbaa !29
  %t917 = load ptr, ptr %l29, !tbaa !29
  %t920 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenMet(ptr %v0, ptr %v1, ptr %t916, ptr %t917)
  store i1 %t920, ptr %l477
  br label %bb245
bb245:
  %t921 = load i1, ptr %l477, !tbaa !21
  store i1 %t921, ptr %rv
  br label %ret
bb246:
  %t922 = load ptr, ptr %l1, !tbaa !29
  store ptr %t922, ptr %l478, !tbaa !29
  store i1 false, ptr %l479, !tbaa !21
  %t923 = load ptr, ptr %l478, !tbaa !29
  %t924 = icmp ne ptr %t923, null
  br i1 %t924, label %bb247, label %bb248
bb247:
  %t926 = load ptr, ptr %l478, !tbaa !29
  %t927 = load i64, ptr %t926
  %t929 = icmp eq i64 %t927, 5
  store i1 %t929, ptr %l479, !tbaa !21
  br label %bb248
bb248:
  %t930 = load i1, ptr %l479, !tbaa !21
  br i1 %t930, label %bb249, label %bb250
bb249:
  %t931 = load ptr, ptr %l1, !tbaa !29
  %t933 = getelementptr { i64, [5 x i64] }, ptr %t931, i32 0, i32 1
  %t934 = getelementptr { %"compiler/source:Span", ptr }, ptr %t933, i32 0, i32 0
  %t935 = load %"compiler/source:Span", ptr %t934
  store %"compiler/source:Span" %t935, ptr %l30
  %t937 = load ptr, ptr %l1, !tbaa !29
  %t939 = getelementptr { i64, [5 x i64] }, ptr %t937, i32 0, i32 1
  %t940 = getelementptr { %"compiler/source:Span", ptr }, ptr %t939, i32 0, i32 1
  %t941 = load ptr, ptr %t940
  store ptr %t941, ptr %l31, !tbaa !29
  br label %bb251
bb250:
  br label %bb256
bb251:
  store %olang.scope zeroinitializer, ptr %s37
  %t943 = load ptr, ptr %l0, !tbaa !29
  store ptr %t943, ptr %l486, !tbaa !29
  %t944 = load %"compiler/source:Span", ptr %l30
  store %"compiler/source:Span" %t944, ptr %l487
  %t945 = load ptr, ptr %l0, !tbaa !29
  store ptr %t945, ptr %l488, !tbaa !29
  %t946 = load ptr, ptr %l31, !tbaa !29
  %t948 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t946)
  store %"compiler/source:Span" %t948, ptr %l490
  br label %bb252
bb252:
  %t949 = load ptr, ptr %l488, !tbaa !29
  %t950 = load %"compiler/source:Span", ptr %l490
  %t951 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t949, %"compiler/source:Span" %t950)
  store { i64, ptr } %t951, ptr %l491
  br label %bb253
bb253:
  %t952 = load { i64, ptr }, ptr %l491, !tbaa !27
  %t953 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyNeedsMarker(ptr %v0, ptr %s37, { i64, ptr } %t952)
  store %"compiler/msgs:Msg" %t953, ptr %l492
  br label %bb254
bb254:
  %t954 = load ptr, ptr %l486, !tbaa !29
  %t955 = load %"compiler/source:Span", ptr %l487
  %t956 = load %"compiler/msgs:Msg", ptr %l492
  %t957 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s37, ptr %t954, %"compiler/source:Span" %t955, %"compiler/msgs:Msg" %t956)
  store i64 %t957, ptr %l493
  br label %bb255
bb255:
  call void @__olang_scope_close(ptr %s37)
  store i1 false, ptr %rv
  br label %ret
bb256:
  %t959 = load ptr, ptr %l1, !tbaa !29
  store ptr %t959, ptr %l495, !tbaa !29
  store i1 false, ptr %l496, !tbaa !21
  %t960 = load ptr, ptr %l495, !tbaa !29
  %t961 = icmp ne ptr %t960, null
  br i1 %t961, label %bb257, label %bb258
bb257:
  %t963 = load ptr, ptr %l495, !tbaa !29
  %t964 = load i64, ptr %t963
  %t966 = icmp eq i64 %t964, 2
  store i1 %t966, ptr %l496, !tbaa !21
  br label %bb258
bb258:
  %t967 = load i1, ptr %l496, !tbaa !21
  br i1 %t967, label %bb259, label %bb260
bb259:
  %t968 = load ptr, ptr %l1, !tbaa !29
  %t970 = getelementptr { i64, [5 x i64] }, ptr %t968, i32 0, i32 1
  %t971 = getelementptr { %"compiler/source:Span", ptr }, ptr %t970, i32 0, i32 1
  %t972 = load ptr, ptr %t971
  store ptr %t972, ptr %l32, !tbaa !29
  br label %bb261
bb260:
  br label %bb275
bb261:
  %t974 = load ptr, ptr %l32, !tbaa !29
  store ptr %t974, ptr %l501, !tbaa !29
  store i1 false, ptr %l502, !tbaa !21
  %t975 = load ptr, ptr %l501, !tbaa !29
  %t976 = icmp ne ptr %t975, null
  br i1 %t976, label %bb262, label %bb263
bb262:
  %t978 = load ptr, ptr %l501, !tbaa !29
  %t979 = load i64, ptr %t978
  %t981 = icmp eq i64 %t979, 1
  store i1 %t981, ptr %l502, !tbaa !21
  br label %bb263
bb263:
  %t982 = load i1, ptr %l502, !tbaa !21
  br i1 %t982, label %bb264, label %bb265
bb264:
  %t983 = load ptr, ptr %l32, !tbaa !29
  %t985 = getelementptr { i64, [6 x i64] }, ptr %t983, i32 0, i32 1
  %t986 = getelementptr { { i64, ptr }, ptr }, ptr %t985, i32 0, i32 1
  %t987 = load ptr, ptr %t986
  store ptr %t987, ptr %l33, !tbaa !29
  br label %bb266
bb265:
  br label %bb273
bb266:
  %t989 = load ptr, ptr %l33, !tbaa !29
  %t991 = icmp eq ptr %t989, null
  %t993 = xor i1 %t991, true
  br i1 %t993, label %bb267, label %bb268
bb267:
  store %olang.scope zeroinitializer, ptr %s40
  %t995 = load ptr, ptr %l0, !tbaa !29
  store ptr %t995, ptr %l510, !tbaa !29
  %t996 = load ptr, ptr %l33, !tbaa !29
  %t998 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t996)
  store %"compiler/source:Span" %t998, ptr %l512
  br label %bb269
bb268:
  br label %bb272
bb269:
  %t999 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eRawAnonymous(ptr %s40)
  store %"compiler/msgs:Msg" %t999, ptr %l513
  br label %bb270
bb270:
  %t1000 = load ptr, ptr %l510, !tbaa !29
  %t1001 = load %"compiler/source:Span", ptr %l512
  %t1002 = load %"compiler/msgs:Msg", ptr %l513
  %t1003 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s40, ptr %t1000, %"compiler/source:Span" %t1001, %"compiler/msgs:Msg" %t1002)
  store i64 %t1003, ptr %l514
  br label %bb271
bb271:
  call void @__olang_scope_close(ptr %s40)
  store i1 false, ptr %rv
  br label %ret
bb272:
  br label %bb274
bb273:
  br label %bb274
bb274:
  store i1 true, ptr %rv
  br label %ret
bb275:
  %t1006 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1006, ptr %l517, !tbaa !29
  store i1 false, ptr %l518, !tbaa !21
  %t1007 = load ptr, ptr %l517, !tbaa !29
  %t1008 = icmp ne ptr %t1007, null
  br i1 %t1008, label %bb276, label %bb277
bb276:
  %t1010 = load ptr, ptr %l517, !tbaa !29
  %t1011 = load i64, ptr %t1010
  %t1013 = icmp eq i64 %t1011, 1
  store i1 %t1013, ptr %l518, !tbaa !21
  br label %bb277
bb277:
  %t1014 = load i1, ptr %l518, !tbaa !21
  br i1 %t1014, label %bb278, label %bb279
bb278:
  %t1015 = load ptr, ptr %l1, !tbaa !29
  %t1017 = getelementptr { i64, [5 x i64] }, ptr %t1015, i32 0, i32 1
  %t1018 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1017, i32 0, i32 1
  %t1019 = load ptr, ptr %t1018
  store ptr %t1019, ptr %l34, !tbaa !29
  br label %bb280
bb279:
  br label %bb304
bb280:
  %t1021 = load ptr, ptr %l34, !tbaa !29
  %t1023 = getelementptr %"compiler/ast:Sig", ptr %t1021, i32 0, i32 0
  %t1024 = load { i64, ptr }, ptr %t1023, !tbaa !27
  store { i64, ptr } %t1024, ptr %l35, !tbaa !27
  store i64 0, ptr %l36, !tbaa !24
  %t1026 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t1028 = extractvalue { i64, ptr } %t1026, 0
  store i64 %t1028, ptr %l37, !tbaa !24
  br label %bb281
bb281:
  store %olang.scope zeroinitializer, ptr %s44
  %t1030 = load i64, ptr %l36, !tbaa !24
  %t1031 = load i64, ptr %l37, !tbaa !24
  %t1034 = icmp slt i64 %t1030, %t1031
  %t1036 = xor i1 %t1034, true
  br i1 %t1036, label %bb282, label %bb283
bb282:
  call void @__olang_scope_close(ptr %s44)
  br label %bb290
bb283:
  br label %bb284
bb284:
  %t1038 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t1038, ptr %l531, !tbaa !27
  %t1039 = load i64, ptr %l36, !tbaa !24
  %t1041 = getelementptr { i64, ptr }, ptr %l531, i32 0, i32 1
  %t1042 = load ptr, ptr %t1041, !tbaa !27
  %t1043 = getelementptr ptr, ptr %t1042, i64 %t1039
  %t1044 = load ptr, ptr %t1043, !tbaa !39
  %t1046 = load ptr, ptr %l0, !tbaa !29
  %t1049 = getelementptr %"compiler/ast:Param", ptr %t1044, i32 0, i32 2
  %t1050 = load ptr, ptr %t1049, !tbaa !29
  %t1053 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenMet(ptr %v0, ptr %v1, ptr %t1046, ptr %t1050)
  store i1 %t1053, ptr %l537
  br label %bb285
bb285:
  %t1054 = load i1, ptr %l537, !tbaa !21
  %t1055 = xor i1 %t1054, true
  br i1 %t1055, label %bb286, label %bb287
bb286:
  call void @__olang_scope_close(ptr %s44)
  store i1 false, ptr %rv
  br label %ret
bb287:
  br label %bb288
bb288:
  call void @__olang_scope_close(ptr %s44)
  br label %bb289
bb289:
  %t1058 = load i64, ptr %l36, !tbaa !24
  %t1060 = add i64 %t1058, 1
  store i64 %t1060, ptr %l36, !tbaa !24
  br label %bb281
bb290:
  %t1062 = load ptr, ptr %l34, !tbaa !29
  %t1064 = getelementptr %"compiler/ast:Sig", ptr %t1062, i32 0, i32 1
  %t1065 = load { i64, ptr }, ptr %t1064, !tbaa !27
  %t1067 = extractvalue { i64, ptr } %t1065, 0
  %t1069 = icmp sgt i64 %t1067, 0
  br i1 %t1069, label %bb291, label %bb292
bb291:
  %t1071 = load ptr, ptr %l34, !tbaa !29
  %t1073 = getelementptr %"compiler/ast:Sig", ptr %t1071, i32 0, i32 1
  %t1074 = load { i64, ptr }, ptr %t1073, !tbaa !27
  store { i64, ptr } %t1074, ptr %l39, !tbaa !27
  store i64 0, ptr %l40, !tbaa !24
  %t1076 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t1078 = extractvalue { i64, ptr } %t1076, 0
  store i64 %t1078, ptr %l41, !tbaa !24
  br label %bb293
bb292:
  br label %bb303
bb293:
  store %olang.scope zeroinitializer, ptr %s49
  %t1080 = load i64, ptr %l40, !tbaa !24
  %t1081 = load i64, ptr %l41, !tbaa !24
  %t1084 = icmp slt i64 %t1080, %t1081
  %t1086 = xor i1 %t1084, true
  br i1 %t1086, label %bb294, label %bb295
bb294:
  call void @__olang_scope_close(ptr %s49)
  br label %bb302
bb295:
  br label %bb296
bb296:
  %t1088 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t1088, ptr %l554, !tbaa !27
  %t1089 = load i64, ptr %l40, !tbaa !24
  %t1091 = getelementptr { i64, ptr }, ptr %l554, i32 0, i32 1
  %t1092 = load ptr, ptr %t1091, !tbaa !27
  %t1093 = getelementptr ptr, ptr %t1092, i64 %t1089
  %t1094 = load ptr, ptr %t1093, !tbaa !39
  %t1096 = load ptr, ptr %l0, !tbaa !29
  %t1101 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenMet(ptr %v0, ptr %v1, ptr %t1096, ptr %t1094)
  store i1 %t1101, ptr %l560
  br label %bb297
bb297:
  %t1102 = load i1, ptr %l560, !tbaa !21
  %t1103 = xor i1 %t1102, true
  br i1 %t1103, label %bb298, label %bb299
bb298:
  call void @__olang_scope_close(ptr %s49)
  store i1 false, ptr %rv
  br label %ret
bb299:
  br label %bb300
bb300:
  call void @__olang_scope_close(ptr %s49)
  br label %bb301
bb301:
  %t1106 = load i64, ptr %l40, !tbaa !24
  %t1108 = add i64 %t1106, 1
  store i64 %t1108, ptr %l40, !tbaa !24
  br label %bb293
bb302:
  br label %bb303
bb303:
  store i1 true, ptr %rv
  br label %ret
bb304:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrongCase(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %a0, { i64, ptr } { i64 17, ptr @.d34 }, { i64, ptr } { i64 9, ptr @.d35 }, { i64, ptr } { i64 10, ptr @.d36 })
  store i32 %t3, ptr %l2
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t4 = load i32, ptr %l2, !tbaa !23
  store i32 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2efieldSpans(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l25 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l29 = alloca i1
  %l44 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/ast:StructBody", ptr %t5, i32 0, i32 2
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t12 = icmp eq i64 %t10, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = load ptr, ptr %lp1
  %t15 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t14
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/ast:StructBody", ptr %t17, i32 0, i32 2
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  store i64 %t24, ptr %l4, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t26 = load i64, ptr %l3, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = icmp slt i64 %t26, %t27
  %t32 = xor i1 %t30, true
  br i1 %t32, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb27
bb7:
  br label %bb8
bb8:
  %t34 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t34, ptr %l25, !tbaa !27
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr ptr, ptr %t38, i64 %t35
  %t40 = load ptr, ptr %t39, !tbaa !39
  store ptr %t40, ptr %l5, !tbaa !29
  %t42 = load ptr, ptr %l5, !tbaa !29
  store ptr %t42, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t43 = load ptr, ptr %l28, !tbaa !29
  %t44 = icmp ne ptr %t43, null
  br i1 %t44, label %bb9, label %bb10
bb9:
  %t46 = load ptr, ptr %l28, !tbaa !29
  %t47 = load i64, ptr %t46
  %t49 = icmp eq i64 %t47, 1
  store i1 %t49, ptr %l29, !tbaa !21
  br label %bb10
bb10:
  %t50 = load i1, ptr %l29, !tbaa !21
  br i1 %t50, label %bb11, label %bb12
bb11:
  %t51 = load ptr, ptr %l5, !tbaa !29
  %t53 = getelementptr { i64, [4 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", ptr }, ptr %t53, i32 0, i32 1
  %t55 = load ptr, ptr %t54
  store ptr %t55, ptr %l6, !tbaa !29
  br label %bb13
bb12:
  br label %bb24
bb13:
  %t57 = load ptr, ptr %l6, !tbaa !29
  %t59 = getelementptr %"compiler/ast:VarDecl", ptr %t57, i32 0, i32 5
  %t60 = load i1, ptr %t59, !tbaa !21
  br i1 %t60, label %bb14, label %bb15
bb14:
  %t62 = load ptr, ptr %l6, !tbaa !29
  %t64 = getelementptr %"compiler/ast:VarDecl", ptr %t62, i32 0, i32 1
  %t65 = load { i64, ptr }, ptr %t64, !tbaa !27
  store { i64, ptr } %t65, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t67 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 0
  store i64 %t69, ptr %l9, !tbaa !24
  br label %bb16
bb15:
  br label %bb23
bb16:
  store %olang.scope zeroinitializer, ptr %s7
  %t71 = load i64, ptr %l8, !tbaa !24
  %t72 = load i64, ptr %l9, !tbaa !24
  %t75 = icmp slt i64 %t71, %t72
  %t77 = xor i1 %t75, true
  br i1 %t77, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s7)
  br label %bb22
bb18:
  br label %bb19
bb19:
  %t79 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t79, ptr %l44, !tbaa !27
  %t80 = load i64, ptr %l8, !tbaa !24
  %t82 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr %"compiler/source:Span", ptr %t83, i64 %t80
  %t85 = load %"compiler/source:Span", ptr %t84
  %t87 = load ptr, ptr %lp1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v1, ptr %t87, %"compiler/source:Span" %t85)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s7)
  br label %bb21
bb21:
  %t91 = load i64, ptr %l8, !tbaa !24
  %t93 = add i64 %t91, 1
  store i64 %t93, ptr %l8, !tbaa !24
  br label %bb16
bb22:
  br label %bb23
bb23:
  br label %bb25
bb24:
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s3)
  br label %bb26
bb26:
  %t95 = load i64, ptr %l3, !tbaa !24
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l3, !tbaa !24
  br label %bb5
bb27:
  %t99 = load ptr, ptr %lp1
  %t100 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t99
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t100, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i1 @compiler_2fcheck_2efloatOverflows(i32 %a0, double %a1) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca double
  %l2 = alloca double
  %l5 = alloca i1
  %l27 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  store double %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load double, ptr %l1, !tbaa !26
  %t3 = fcmp ogt double %t1, 0x7fefffffffffffff
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  %t5 = load double, ptr %l1, !tbaa !26
  %t7 = fcmp olt double %t5, 0xffefffffffffffff
  store i1 %t7, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t11 = load double, ptr %l1, !tbaa !26
  store double %t11, ptr %l2, !tbaa !26
  %t13 = load i32, ptr %l0, !tbaa !23
  %t15 = icmp eq i32 %t13, 13
  br i1 %t15, label %bb7, label %bb8
bb7:
  %t17 = load double, ptr %l1, !tbaa !26
  %t19 = fptrunc double %t17 to float
  %t21 = fpext float %t19 to double
  store double %t21, ptr %l2, !tbaa !26
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t23 = load i32, ptr %l0, !tbaa !23
  %t25 = icmp eq i32 %t23, 11
  br i1 %t25, label %bb10, label %bb11
bb10:
  %t27 = load double, ptr %l1, !tbaa !26
  %t29 = fptrunc double %t27 to half
  %t31 = fpext half %t29 to double
  store double %t31, ptr %l2, !tbaa !26
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t33 = load i32, ptr %l0, !tbaa !23
  %t35 = icmp eq i32 %t33, 12
  br i1 %t35, label %bb13, label %bb14
bb13:
  %t37 = load double, ptr %l1, !tbaa !26
  %t39 = fptrunc double %t37 to bfloat
  %t41 = bitcast bfloat %t39 to i16
  %t42 = zext i16 %t41 to i32
  %t43 = shl i32 %t42, 16
  %t44 = bitcast i32 %t43 to float
  %t45 = fpext float %t44 to double
  store double %t45, ptr %l2, !tbaa !26
  br label %bb15
bb14:
  br label %bb15
bb15:
  %t47 = load double, ptr %l2, !tbaa !26
  %t49 = fcmp ogt double %t47, 0x7fefffffffffffff
  br i1 %t49, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb18
bb17:
  %t51 = load double, ptr %l2, !tbaa !26
  %t53 = fcmp olt double %t51, 0xffefffffffffffff
  store i1 %t53, ptr %l27, !tbaa !21
  br label %bb18
bb18:
  %t55 = load i1, ptr %l27, !tbaa !21
  store i1 %t55, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l16 = alloca { i64, ptr }
  %l20 = alloca i1
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Block", ptr %t6, i32 0, i32 1
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t15 = load i64, ptr %l2, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t23, ptr %l16, !tbaa !27
  %t24 = load i64, ptr %l2, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr ptr, ptr %t27, i64 %t24
  %t29 = load ptr, ptr %t28, !tbaa !39
  %t33 = call i1 @compiler_2fcheck_2eleaves(ptr %v0, ptr %t29)
  store i1 %t33, ptr %l20
  br label %bb8
bb8:
  %t34 = load i1, ptr %l20, !tbaa !21
  br i1 %t34, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  %t36 = load i64, ptr %l2, !tbaa !24
  %t38 = add i64 %t36, 1
  store i64 %t38, ptr %l2, !tbaa !24
  br label %bb4
bb13:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2emeetPerm(i64 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %rv = alloca i64
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = and i64 %t1, %t2
  %t6 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t7 = load i64, ptr @G_2ecompiler_2ftypes_2eOwning, !tbaa !24
  %t10 = or i64 %t6, %t7
  %t13 = and i64 %t5, %t10
  %t14 = load i64, ptr %l0, !tbaa !24
  %t15 = load i64, ptr %l1, !tbaa !24
  %t18 = or i64 %t14, %t15
  %t19 = load i64, ptr @G_2ecompiler_2ftypes_2eNullable, !tbaa !24
  %t22 = and i64 %t18, %t19
  %t25 = or i64 %t13, %t22
  store i64 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2enamedFn(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i1
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 15
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l11, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_a1143936e424f416_6a846c9af99dae82)
  unreachable
bb16:
  %t25 = load i1, ptr %l9, !tbaa !21
  store i1 %t25, ptr %l2, !tbaa !21
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_b0c5dfd122db8337_2ed6598a574b6003)
  unreachable
bb22:
  %t26 = load i1, ptr %l2, !tbaa !21
  store i1 %t26, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %v0, i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0
  %t3 = trunc i64 48 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 4, ptr @.d37 }, ptr %l1, !tbaa !27
  br label %bb59
bb4:
  %t6 = load i32, ptr %l0
  %t8 = trunc i64 49 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store { i64, ptr } { i64 5, ptr @.d38 }, ptr %l1, !tbaa !27
  br label %bb59
bb8:
  %t11 = load i32, ptr %l0
  %t13 = trunc i64 50 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 3, ptr @.d39 }, ptr %l1, !tbaa !27
  br label %bb59
bb12:
  %t16 = load i32, ptr %l0
  %t18 = trunc i64 51 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 3, ptr @.d40 }, ptr %l1, !tbaa !27
  br label %bb59
bb16:
  %t21 = load i32, ptr %l0
  %t23 = trunc i64 52 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store { i64, ptr } { i64 3, ptr @.d41 }, ptr %l1, !tbaa !27
  br label %bb59
bb20:
  %t26 = load i32, ptr %l0
  %t28 = trunc i64 53 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store { i64, ptr } { i64 6, ptr @.d42 }, ptr %l1, !tbaa !27
  br label %bb59
bb24:
  %t31 = load i32, ptr %l0
  %t33 = trunc i64 76 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb25, label %bb26
bb25:
  br label %bb33
bb26:
  %t36 = load i32, ptr %l0
  %t38 = trunc i64 78 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb27, label %bb28
bb27:
  br label %bb33
bb28:
  %t41 = load i32, ptr %l0
  %t43 = trunc i64 77 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb29, label %bb30
bb29:
  br label %bb33
bb30:
  %t46 = load i32, ptr %l0
  %t48 = trunc i64 79 to i32
  %t49 = icmp eq i32 %t46, %t48
  br i1 %t49, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  store { i64, ptr } { i64 4, ptr @.d43 }, ptr %l1, !tbaa !27
  br label %bb59
bb34:
  %t51 = load i32, ptr %l0
  %t53 = trunc i64 80 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  store { i64, ptr } { i64 6, ptr @.d44 }, ptr %l1, !tbaa !27
  br label %bb59
bb38:
  %t56 = load i32, ptr %l0
  %t58 = trunc i64 81 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  store { i64, ptr } { i64 5, ptr @.d45 }, ptr %l1, !tbaa !27
  br label %bb59
bb42:
  %t61 = load i32, ptr %l0
  %t63 = trunc i64 82 to i32
  %t64 = icmp eq i32 %t61, %t63
  br i1 %t64, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  store { i64, ptr } { i64 6, ptr @.d46 }, ptr %l1, !tbaa !27
  br label %bb59
bb46:
  %t66 = load i32, ptr %l0
  %t68 = trunc i64 85 to i32
  %t69 = icmp eq i32 %t66, %t68
  br i1 %t69, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  store { i64, ptr } { i64 9, ptr @.d47 }, ptr %l1, !tbaa !27
  br label %bb59
bb50:
  %t71 = load i32, ptr %l0
  %t73 = trunc i64 86 to i32
  %t74 = icmp eq i32 %t71, %t73
  br i1 %t74, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  store { i64, ptr } { i64 10, ptr @.d48 }, ptr %l1, !tbaa !27
  br label %bb59
bb54:
  br i1 true, label %bb55, label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb58
bb57:
  store { i64, ptr } { i64 0, ptr @.d49 }, ptr %l1, !tbaa !27
  br label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_445c35e7b454dfb2_9156676d88e8071e)
  unreachable
bb59:
  %t76 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t76, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2eprimName(ptr %v0, i32 %a0) #0 {
entry:
  %l1 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = sext i32 %a0 to i64
  store i64 %t3, ptr %l1, !tbaa !24
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = icmp eq i64 %t5, 3
  br i1 %t7, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 2, ptr @.d50 }, ptr %l4, !tbaa !27
  br label %bb53
bb4:
  %t9 = load i64, ptr %l1, !tbaa !24
  %t11 = icmp eq i64 %t9, 4
  br i1 %t11, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store { i64, ptr } { i64 3, ptr @.d51 }, ptr %l4, !tbaa !27
  br label %bb53
bb8:
  %t13 = load i64, ptr %l1, !tbaa !24
  %t15 = icmp eq i64 %t13, 5
  br i1 %t15, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 3, ptr @.d52 }, ptr %l4, !tbaa !27
  br label %bb53
bb12:
  %t17 = load i64, ptr %l1, !tbaa !24
  %t19 = icmp eq i64 %t17, 6
  br i1 %t19, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 3, ptr @.d53 }, ptr %l4, !tbaa !27
  br label %bb53
bb16:
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = icmp eq i64 %t21, 7
  br i1 %t23, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store { i64, ptr } { i64 2, ptr @.d54 }, ptr %l4, !tbaa !27
  br label %bb53
bb20:
  %t25 = load i64, ptr %l1, !tbaa !24
  %t27 = icmp eq i64 %t25, 8
  br i1 %t27, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store { i64, ptr } { i64 3, ptr @.d55 }, ptr %l4, !tbaa !27
  br label %bb53
bb24:
  %t29 = load i64, ptr %l1, !tbaa !24
  %t31 = icmp eq i64 %t29, 9
  br i1 %t31, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store { i64, ptr } { i64 3, ptr @.d56 }, ptr %l4, !tbaa !27
  br label %bb53
bb28:
  %t33 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp eq i64 %t33, 10
  br i1 %t35, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store { i64, ptr } { i64 3, ptr @.d57 }, ptr %l4, !tbaa !27
  br label %bb53
bb32:
  %t37 = load i64, ptr %l1, !tbaa !24
  %t39 = icmp eq i64 %t37, 11
  br i1 %t39, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store { i64, ptr } { i64 3, ptr @.d58 }, ptr %l4, !tbaa !27
  br label %bb53
bb36:
  %t41 = load i64, ptr %l1, !tbaa !24
  %t43 = icmp eq i64 %t41, 12
  br i1 %t43, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  store { i64, ptr } { i64 4, ptr @.d59 }, ptr %l4, !tbaa !27
  br label %bb53
bb40:
  %t45 = load i64, ptr %l1, !tbaa !24
  %t47 = icmp eq i64 %t45, 13
  br i1 %t47, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  store { i64, ptr } { i64 3, ptr @.d60 }, ptr %l4, !tbaa !27
  br label %bb53
bb44:
  %t49 = load i64, ptr %l1, !tbaa !24
  %t51 = icmp eq i64 %t49, 14
  br i1 %t51, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  store { i64, ptr } { i64 3, ptr @.d61 }, ptr %l4, !tbaa !27
  br label %bb53
bb48:
  br i1 true, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  store { i64, ptr } { i64 1, ptr @.d62 }, ptr %l4, !tbaa !27
  br label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_25d55d46e6c695b2_1c5feb2a345583d6)
  unreachable
bb53:
  %t53 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t53, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %rv
  br label %ret
bb6:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2erootGaps(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/check:Gap"
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l12 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i32
  %l25 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t5 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 12
  store ptr %t5, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aGap_3e_2eRunFrom_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %t7, i64 %t8)
  %t12 = extractvalue { i32, { i64, ptr } } %t11, 1
  %t13 = extractvalue { i32, { i64, ptr } } %t11, 0
  store i32 %t13, ptr %l16
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb4, label %ok.15
ok.15:
  store { i64, ptr } %t12, ptr %l15
  br label %bb3
bb3:
  %t16 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t16, ptr %l12, !tbaa !27
  br label %bb8
bb4:
  %t17 = load i32, ptr %l16, !tbaa !23
  %t18 = ashr i32 %t17, 16
  %t20 = icmp eq i32 %t18, 1
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_e8d3b00cef07529c_194237a42caab5b0)
  unreachable
bb7:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb8:
  %t22 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t22, ptr %l5, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 0
  store i64 %t25, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t27 = load i64, ptr %l7, !tbaa !24
  %t28 = load i64, ptr %l6, !tbaa !24
  %t31 = icmp slt i64 %t27, %t28
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb11:
  br label %bb12
bb12:
  %t35 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t35, ptr %l25, !tbaa !27
  %t36 = load i64, ptr %l7, !tbaa !24
  %t38 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr %"compiler/check:Gap", ptr %t39, i64 %t36
  %t41 = load %"compiler/check:Gap", ptr %t40
  store %"compiler/check:Gap" %t41, ptr %l8
  %t43 = getelementptr %"compiler/check:Gap", ptr %l8, i32 0, i32 0
  %t44 = load i64, ptr %t43, !tbaa !24
  %t48 = icmp eq i64 %t44, %a1
  br i1 %t48, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t50 = getelementptr %"compiler/check:Gap", ptr %l8, i32 0, i32 2
  %t51 = load { i64, ptr }, ptr %t50, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %l2, { i64, ptr } %t51)
  br label %bb15
bb14:
  br label %bb17
bb15:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l2, { i64, ptr } { i64 2, ptr @.d63 })
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s4)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb18:
  %t55 = load i64, ptr %l7, !tbaa !24
  %t57 = add i64 %t55, 1
  store i64 %t57, ptr %l7, !tbaa !24
  br label %bb9
bb19:
  %t59 = load i64, ptr %l4, !tbaa !24
  %t60 = load i64, ptr %l6, !tbaa !24
  %t63 = add i64 %t59, %t60
  store i64 %t63, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  br label %bb2
bb21:
  %t66 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t66, ptr %l40
  br label %bb22
bb22:
  %t67 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t67, ptr %l41, !tbaa !27
  %t68 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  store i64 %t69, ptr %l42, !tbaa !24
  %t70 = load i64, ptr %l42, !tbaa !24
  %t71 = mul i64 %t70, 1
  %t72 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t71)
  %t73 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  store { i64, ptr } %t74, ptr %l43, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = load i64, ptr %l42, !tbaa !24
  %t80 = mul i64 %t79, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t76, ptr %t78, i64 %t80, i1 false)
  %t81 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t81, ptr %l41, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t82 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t82, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2erootRules(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/diag:Said"
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca ptr
  %l19 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l21 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i32
  %l34 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/load:Loader", ptr %t3, i32 0, i32 5
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/load:Loader", ptr %t6, i32 0, i32 7
  %t9 = load i64, ptr %t8, !tbaa !24
  %t12 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t5, i64 %t9)
  store ptr %t12, ptr %l14
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l14, !tbaa !29
  %t15 = getelementptr %"compiler/load:Module", ptr %t13, i32 0, i32 4
  %t16 = load i64, ptr %t15, !tbaa !24
  store i64 %t16, ptr %l2, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s1
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/load:Loader", ptr %t18, i32 0, i32 4
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAllSaid(ptr %v0, ptr %s1, ptr %t21)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %l19
  br label %bb3
bb3:
  %t24 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  %t25 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %t25
  store ptr %t25, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aSaid_3e_2eRunFrom_3ccompiler_2fdiag_3aSaid_3e(ptr %s1, ptr %t27, i64 %t28)
  %t32 = extractvalue { i32, { i64, ptr } } %t31, 1
  %t33 = extractvalue { i32, { i64, ptr } } %t31, 0
  store i32 %t33, ptr %l25
  %t34 = icmp ne i32 %t33, 0
  br i1 %t34, label %bb6, label %ok.35
ok.35:
  store { i64, ptr } %t32, ptr %l24
  br label %bb5
bb5:
  %t36 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t36, ptr %l21, !tbaa !27
  br label %bb10
bb6:
  %t37 = load i32, ptr %l25, !tbaa !23
  %t38 = ashr i32 %t37, 16
  %t40 = icmp eq i32 %t38, 1
  br i1 %t40, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_1bde8bd2a8f34a58_2374d3532b953474)
  unreachable
bb9:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb10:
  %t42 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t42, ptr %l5, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  store i64 %t45, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t47 = load i64, ptr %l7, !tbaa !24
  %t48 = load i64, ptr %l6, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb13:
  br label %bb14
bb14:
  %t55 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t55, ptr %l34, !tbaa !27
  %t56 = load i64, ptr %l7, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr %"compiler/diag:Said", ptr %t59, i64 %t56
  %t61 = load %"compiler/diag:Said", ptr %t60
  store %"compiler/diag:Said" %t61, ptr %l8
  %t63 = getelementptr %"compiler/diag:Said", ptr %l8, i32 0, i32 1
  %t64 = load i64, ptr %t63, !tbaa !24
  %t65 = load i64, ptr %l2, !tbaa !24
  %t68 = icmp eq i64 %t64, %t65
  br i1 %t68, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t70 = getelementptr %"compiler/diag:Said", ptr %l8, i32 0, i32 0
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t71, 1
  %t74 = extractvalue { i64, ptr } %t71, 0
  %t75 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t74)
  call void @olang_textcopy(ptr %t75, ptr %t73, i64 %t74)
  %t76 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  %t79 = extractvalue { i64, ptr } %t77, 0
  %t80 = extractvalue { i64, ptr } %t77, 1
  %t81 = mul i64 %t79, 1
  %t82 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t81)
  call void @llvm.memcpy.p0.p0.i64(ptr %t82, ptr %t80, i64 %t81, i1 false)
  %t83 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l1, { i64, ptr } %t84)
  br label %bb17
bb16:
  br label %bb19
bb17:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 32)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb20:
  %t88 = load i64, ptr %l7, !tbaa !24
  %t90 = add i64 %t88, 1
  store i64 %t90, ptr %l7, !tbaa !24
  br label %bb11
bb21:
  %t92 = load i64, ptr %l4, !tbaa !24
  %t93 = load i64, ptr %l6, !tbaa !24
  %t96 = add i64 %t92, %t93
  store i64 %t96, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  br label %bb4
bb23:
  call void @__olang_scope_close(ptr %s1)
  %t99 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t99, ptr %l51
  br label %bb24
bb24:
  %t100 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t100, ptr %l52, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 0
  store i64 %t102, ptr %l53, !tbaa !24
  %t103 = load i64, ptr %l53, !tbaa !24
  %t104 = mul i64 %t103, 1
  %t105 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t104)
  %t106 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  store { i64, ptr } %t107, ptr %l54, !tbaa !27
  %t108 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = load i64, ptr %l53, !tbaa !24
  %t113 = mul i64 %t112, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t109, ptr %t111, i64 %t113, i1 false)
  %t114 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t114, ptr %l52, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t115 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t115, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2esamePath(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l40 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t9 = icmp ne i64 %t3, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l2, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = load i64, ptr %l2, !tbaa !24
  %t20 = icmp sgt i64 %t16, %t17
  br i1 %t20, label %bb4, label %bb5
bb4:
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb9
bb6:
  %t26 = load i64, ptr %l3, !tbaa !24
  %t27 = load i64, ptr %l2, !tbaa !24
  %t30 = sub i64 %t26, %t27
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t36 = sub i64 %t34, 1
  %t37 = load i64, ptr %l4, !tbaa !24
  %t40 = sdiv i64 %t36, %t37
  store i64 %t40, ptr %l22, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb8
bb8:
  %t42 = load i64, ptr %l22, !tbaa !24
  store i64 %t42, ptr %l19, !tbaa !24
  br label %bb9
bb9:
  %t43 = load i64, ptr %l19, !tbaa !24
  store i64 %t43, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb12:
  br label %bb13
bb13:
  %t52 = load i64, ptr %l2, !tbaa !24
  %t53 = load i64, ptr %l6, !tbaa !24
  %t54 = load i64, ptr %l4, !tbaa !24
  %t57 = mul i64 %t53, %t54
  %t60 = add i64 %t52, %t57
  store i64 %t60, ptr %l7, !tbaa !24
  %t62 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t62, ptr %l40, !tbaa !27
  %t63 = load i64, ptr %l7, !tbaa !24
  %t65 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr i32, ptr %t66, i64 %t63
  %t68 = load i32, ptr %t67, !tbaa !33
  %t69 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t69, ptr %l43, !tbaa !27
  %t70 = load i64, ptr %l7, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr i32, ptr %t73, i64 %t70
  %t75 = load i32, ptr %t74, !tbaa !33
  %t78 = icmp ne i32 %t68, %t75
  br i1 %t78, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  store i1 false, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb17:
  %t81 = load i64, ptr %l6, !tbaa !24
  %t83 = add i64 %t81, 1
  store i64 %t83, ptr %l6, !tbaa !24
  br label %bb10
bb18:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2estoredExprs(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l16 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t21, ptr %l16, !tbaa !27
  %t22 = load i64, ptr %l3, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr ptr, ptr %t25, i64 %t22
  %t27 = load ptr, ptr %t26, !tbaa !39
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t27, ptr %a1)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb9
bb9:
  %t34 = load i64, ptr %l3, !tbaa !24
  %t36 = add i64 %t34, 1
  store i64 %t36, ptr %l3, !tbaa !24
  br label %bb4
bb10:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t5, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %t7)
  store i32 %t9, ptr %l5
  br label %bb4
bb4:
  %t10 = load i32, ptr %l5, !tbaa !23
  store i32 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2eunpromoted(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Promote", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  store ptr %t19, ptr %rv
  br label %ret
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/check:ctSource" @compiler_2fcheck_3actSource_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3, { i64, ptr } %a4) #0 {
entry:
  %rv = alloca %"compiler/check:ctSource"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/check:ctSource" undef, ptr %a0, 0
  %t14 = insertvalue %"compiler/check:ctSource" %t12, ptr %a1, 1
  %t16 = insertvalue %"compiler/check:ctSource" %t14, { i64, ptr } %a2, 2
  %t18 = insertvalue %"compiler/check:ctSource" %t16, i64 %a3, 3
  %t20 = insertvalue %"compiler/check:ctSource" %t18, { i64, ptr } %a4, 4
  store %"compiler/check:ctSource" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:ctSource", ptr %rv
  ret %"compiler/check:ctSource" %rr
}

define dso_local %"compiler/check:errNarrow" @compiler_2fcheck_3aerrNarrow_2ector(ptr %v0, i64 %a0, i32 %a1, i64 %a2) #0 {
entry:
  %rv = alloca %"compiler/check:errNarrow"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/check:errNarrow" undef, i64 %a0, 0
  %t10 = insertvalue %"compiler/check:errNarrow" %t8, i32 %a1, 1
  %t12 = insertvalue %"compiler/check:errNarrow" %t10, i64 %a2, 2
  store %"compiler/check:errNarrow" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:errNarrow", ptr %rv
  ret %"compiler/check:errNarrow" %rr
}

define dso_local %"compiler/check:nullNarrow" @compiler_2fcheck_3anullNarrow_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i1 %a2) #0 {
entry:
  %rv = alloca %"compiler/check:nullNarrow"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/check:nullNarrow" undef, { i64, ptr } %a0, 0
  %t10 = insertvalue %"compiler/check:nullNarrow" %t8, i64 %a1, 1
  %t12 = insertvalue %"compiler/check:nullNarrow" %t10, i1 %a2, 2
  store %"compiler/check:nullNarrow" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:nullNarrow", ptr %rv
  ret %"compiler/check:nullNarrow" %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant [1 x i8] c"("
@.d1 = private constant [1 x i8] c")"
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/source:Span", ptr %t1, i32 0, i32 0
  %t3 = load i32, ptr %t2, !tbaa !23
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/source:Span", ptr %t4, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  %t9 = icmp eq i32 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb4
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/source:Span", ptr %t11, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/source:Span", ptr %t14, i32 0, i32 1
  %t16 = load i32, ptr %t15, !tbaa !23
  %t19 = icmp eq i32 %t13, %t16
  br i1 %t19, label %bb3, label %bb1
bb3:
  br label %bb4
bb4:
  %t21 = load i1, ptr %l2, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d2 = private constant [4 x i8] c"Call"
@.d3 = private constant [4 x i8] c"call"
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d4 = private constant [4 x i8] c"Call"
@.d5 = private constant [16 x i8] c"this constructor"
declare void @__olang_ert_req_clear()
@.d6 = private constant [3 x i8] c"I32"
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d7 = private constant [1 x i8] c"."
@.d8 = private constant [0 x i8] c""
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d9 = private constant [7 x i8] c"default"
@.d10 = private constant [1 x i8] c"_"
@.d11 = private constant [20 x i8] c"std/prelude/argument"
@.d12 = private constant [13 x i8] c"ArgumentError"
@.d13 = private constant [2 x i8] c": "
@.d14 = private constant [7 x i8] c"nothing"
@.d15 = private constant [2 x i8] c", "
@.d16 = private constant [3 x i8] c"I64"
@.d17 = private constant [8 x i8] c"a lambda"
@.d18 = private constant [0 x i8] c""
@.d19 = private constant [1 x i8] c"s"
@.d20 = private constant [74 x i8] c"a lambda parameter written as a reference where a value is expected (D16a)"
@.d21 = private constant [11 x i8] c"this lambda"
@.d22 = private constant [5 x i8] c"Value"
@.d23 = private constant [7 x i8] c"'Value'"
@.d24 = private constant [3 x i8] c"Inc"
@.d25 = private constant [3 x i8] c"Dec"
@.d26 = private constant [4 x i8] c"Plus"
@.d27 = private constant [5 x i8] c"Minus"
@.d28 = private constant [3 x i8] c"Inc"
@.d29 = private constant [3 x i8] c"Dec"
@.d30 = private constant [4 x i8] c"'++'"
@.d31 = private constant [4 x i8] c"'--'"
@.d32 = private constant [5 x i8] c"Array"
@.d33 = private constant [5 x i8] c"Array"
@.d34 = private constant [17 x i8] c"std/prelude/enums"
@.d35 = private constant [9 x i8] c"CaseError"
@.d36 = private constant [10 x i8] c"WRONG_CASE"
@.d37 = private constant [4 x i8] c"Plus"
@.d38 = private constant [5 x i8] c"Minus"
@.d39 = private constant [3 x i8] c"Mul"
@.d40 = private constant [3 x i8] c"Div"
@.d41 = private constant [3 x i8] c"Rem"
@.d42 = private constant [6 x i8] c"MatMul"
@.d43 = private constant [4 x i8] c"Less"
@.d44 = private constant [6 x i8] c"BitAnd"
@.d45 = private constant [5 x i8] c"BitOr"
@.d46 = private constant [6 x i8] c"BitXor"
@.d47 = private constant [9 x i8] c"ShiftLeft"
@.d48 = private constant [10 x i8] c"ShiftRight"
@.d49 = private constant [0 x i8] c""
@.d50 = private constant [2 x i8] c"I8"
@.d51 = private constant [3 x i8] c"I16"
@.d52 = private constant [3 x i8] c"I32"
@.d53 = private constant [3 x i8] c"I64"
@.d54 = private constant [2 x i8] c"U8"
@.d55 = private constant [3 x i8] c"U16"
@.d56 = private constant [3 x i8] c"U32"
@.d57 = private constant [3 x i8] c"U64"
@.d58 = private constant [3 x i8] c"F16"
@.d59 = private constant [4 x i8] c"BF16"
@.d60 = private constant [3 x i8] c"F32"
@.d61 = private constant [3 x i8] c"F64"
@.d62 = private constant [1 x i8] c"?"
@.d63 = private constant [2 x i8] c"; "
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare i1 @compiler_2fcheck_2ehitsPath(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2eclosedExpr(ptr %v0, ptr %a0)
@olang_loc_3ee32a1caa2e355c_4063d0a06727bdc8 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresNames(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eOwnScope = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ftypes_2eFromTypeVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econdChoosesPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aGlobal(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i32 %a3, i32 %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
@olang_loc_b2a10b57ca8f7dfa_ebdfac3cc9f6695e = external constant [0 x i8]
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@olang_loc_d8b8a4cfeb0897ac_ce33cd750b46e790 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eOwning = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i1 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTrack(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare %"compiler/typed:Call" @compiler_2ftyped_3aCall_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, [2 x i64] } %a2, i32 %a3, i1 %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
@olang_loc_c23231398495940d_3184fca2d3133de9 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, i64 %a5, ptr %a6, { i64, ptr } %a7, { i64, ptr } %a8)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_dec816aeadd109e0_adcbe0bcced90c1c = external constant [0 x i8]
@olang_loc_98ffdf46f6e43303_7907d8ed59f5817f = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, ptr } %a7)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_4b3a1421aaa5396_3ffde41a88bcce4a = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinPieceCalled(ptr %v0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/msgs:Msg" %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAfter(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotCallable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_Hbcd822ae67306ca6a025f17ed2cfb61c(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/typed:Local" @compiler_2ftyped_3aLocal_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, i32 %a4, { i64, [2 x i64] } %a5)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddLocal(ptr %v0, ptr %a0, %"compiler/typed:Local" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_486b3db7a819736b_b4c2afa2fe5bd5af = external constant [0 x i8]
declare %"compiler/typed:Capture" @compiler_2ftyped_3aCapture_2ector(ptr %v0, ptr %v1, i32 %a0, ptr %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aCapture_26_3e_2e_He39a1cf375adb47168dea91a05758aa9(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2ePu_Hdbf2db28b3dbd7714059bb41361f5f89(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, ptr %a3)
@olang_loc_54e68041531f6906_51860f3f569bf3d2 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aerrBind_3e_2eLen_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %a0)
declare %"compiler/check:errBind" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aerrBind_3e_2eAt_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtNow(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_e4cf7bb5bd488336_42dde517bf840672 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fload_2eErrQualifier(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextConst(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2, i32 %a3)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
declare %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebinary(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4, i32 %a5)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3)
declare %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_854899d5724a103b_e7dfb19072d83fa7 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitBeside(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/check:litv" %a2, ptr %a3, i32 %a4, %"compiler/source:Span" %a5, i1 %a6)
@olang_loc_852b58c2eb82b3cc_e47a0c64d3951188 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5, %"compiler/source:Span" %a6, %"compiler/source:Span" %a7)
declare { i64, ptr } @compiler_2fscan_2eLiteralBytes(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_d9d408bf8806a5b7_73d051fbfd3f3593 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsConst(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFoldKnown(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eevalOnly(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4)
declare %"compiler/generic:Context" @compiler_2fgeneric_3aContext_2ector(ptr %v0, i64 %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %a0)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efitsTest(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %a0)
declare { { i64, [3 x i64] }, { i64, ptr } } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTopContext(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fcheck_3aContractAsk_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, i64 %a0, i64 %a1, %"compiler/source:Span" %a2, i64 %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, [3 x i64] } %a7, { i64, ptr } %a8, { i64, ptr } %a9)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aContractAsk_3e_2_H1e0eaace9d10c5af057a64b660c4ff1f(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectSourceOf(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_4d78ccd557b2cb07_4b61304073c9a48b = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eToAr_H9d0f958437b2bc29fe1d416dfb9901d7(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2ftypes_2eDefaultErrT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eRoleFn = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopes(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/generic:Context" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectContext(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@G_2ecompiler_2fcheck_2eCtReq = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@olang_loc_82a7c94587506de8_24388316e0066d9c = external constant [0 x i8]
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparam(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i64 %a4, ptr %a5)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eSetVars(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotCapture(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, [2 x i64] } %a5)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyCall(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i32 %a3, { i64, ptr } %a4, ptr %a5, ptr %a6)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyErrors(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleak(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_fc766b9c907a0b81_82048062a2a05a1d = external constant [0 x i8]
declare %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i1 %a2, i1 %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaks1(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1)
@olang_loc_9f409528a62be557_96e98ebb70e4ac13 = external constant [0 x i8]
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eIsDropped(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eIsCut(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eallWords(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAsCanFail(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnhandledFallibleCall(ptr %v0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
@olang_loc_ad8923f011cb5acf_6f8a151e60866063 = external constant [0 x i8]
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetStructBody(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i1 %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsWritable(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_9109cadfb541186e_2a46ab96c2b41f0a = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_Hb3133f486435530b533aaf49461c92b5(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H257d83b06934604763b32ef91c51c1d2(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistMet(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i64 %a3)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2eDeclOwner(i32 %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebound(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H64d9be73b6c9bed004c541bdf7f0ca0a(ptr %v0, ptr %a0, i32 %a1, i1 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoreturnSpan(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoreturnHere(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_d264b31a2a0953e1_a8a3a5518784125d = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaArity(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2, i64 %a3)
@olang_loc_3e7f35b161741bd4_701c2e32dccd3eb0 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesTypeVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_47d9099855f63e09_256685dd40c0f40d = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayParamByValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ementionsVar(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaSignature(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaParamUntyped(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_7a7c9bdd5ccfbec2_26ff6938088c41e = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorList(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i1 %a2, { i64, ptr } %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_H2d42092ce658fb6cce0104fa754a4e33(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i1 %a3)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eletOut(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emerged(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecanonicalErrs(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMissingReturn(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aCapture_26_3e_2e_Hc9219e836d6ca52518c31537b8e6a8eb(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/check:roFn" @compiler_2fcheck_3aroFn_2ector(ptr %v0, ptr %v1, i64 %a0, i64 %a1, { i64, [3 x i64] } %a2, { i64, ptr } %a3)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroFn_3e_2ePush_3ccompiler_2fcheck_3aroFn_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:roFn" %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSigNames(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesIdOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithNames(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordCount(ptr %v0, ptr %a0, i32 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2eR_H9395c9c55f40ca4e18bbadf0b4ab31aa(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_c9e70fc2ae99f8ec_a4a86a2066a83508 = external constant [0 x i8]
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
@olang_loc_1a03149f0250e548_14220af7ccd85b74 = external constant [0 x i8]
@olang_loc_f003e05343083a19_c7eedaa93b775a5 = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtName(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtMatch(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchOnType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eblockOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2, %"compiler/source:Span" %a3)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elenMatch(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchExpr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i1 %a3, i32 %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclareUnknown(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructOneValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructCount(ptr %v0, i64 %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eputTarget(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2, ptr %a3, i32 %a4)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssignListCount(ptr %v0, i64 %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estoredName(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferred(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i1 %a3)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2ector(ptr %v0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2_H5eacc50cc32d6e41ff62f01e24d943f2(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2eLe_H7b92c806358c31ec0113c885295670e0(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2_H3364bcea7de64bc2b6b83bde1edd9d27(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_476fe22cd4409b92_8ac04c158b99cfe6 = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2ePu_H51141c7f79c906b1679ae982392c7956(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2_Ha849274baa3792788a1b7c8fee45d023(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_1e0e3f8e77107efc_26f178b75df49a00 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2eTr_H7b9b9c82633a95f30e02bffa16283320(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_c3a1911177000af1_d7f4a899cd404215 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenRefOrVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowedField(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %a0, i64 %a1)
declare %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLocal(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_24dda45681d8cee1_6133aaee564c4ee5 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ewrittenMut(ptr %v0, ptr %a0)
@olang_loc_f10316e290a7e1b9_b7814005b7d82bcd = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainField(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eProtocolPrivate(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawsOf(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoRawValues(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTakesNoArgs(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawOf(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldOf(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H4c470d2e80d9fd53b2c4a8b35e81296f(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H64396385e4e6d43afa926b839ce2258a(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a2)
declare { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H6388cc594ade7977543a45717e2b755f(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einGeneric(ptr %v0, ptr %a0)
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H190b78e3c1eec037529224679e114a85(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryChecks(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_a580b41490f7ba52_8ca18228c95a1fde = external constant [0 x i8]
@olang_loc_9332d3d788c23e53_a9219b71b597ec5f = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enormalSet(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e__Hb311157f9ff5cfde66cc01a7f8069ed8(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyKey(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1d7b97a31fca2c92a4527a0b3309f2d1(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3)
@olang_loc_fe73ad2ef66395ad_6bb388f528f40629 = external constant [0 x i8]
@olang_loc_97840d8df2a94e80_8f65c6ae19d7bb5c = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4, i64 %a5, i1 %a6)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2efloatBits(i32 %a0, double %a1)
@olang_loc_729de81d3b051823_7dce08f61f50e4bf = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitErrsUnwritten(ptr %v0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fsour_Hf9d8b9e9334551fc04613fb711673451(ptr %v0, ptr %a0)
declare { i32, %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fsour_H1b67a9adff6f6c708503322bb7ca7b5e(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H7068c8717e9d582db2941dd2bdd79d55(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_fea4cce0f7542395_82370c360b9a7e9 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloopCall(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3, { i64, ptr } %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexhaustedOrBreak(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelementLocals(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, ptr %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkBody(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
declare { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_He6be2b0836caba7ddc59483ff74db438(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknownType(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorTypeHeld(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitWritten(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforeignNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eForeignByValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgsOnNonGeneric(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgCount(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2fcheck_2eisFuncTypeRef(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteGroupFunctionType(ptr %v0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/msgs:Msg" %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayTooManyArgs(ptr %v0, i64 %a0)
@olang_loc_af641ab471d8e1a7_ff13a1c3a1ffb403 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erefWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMutOnValueType(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNamedScopeOnElement(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgNamedScope(ptr %v0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunArrayValue(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayNestedByValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesMet(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereferable(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eInvalidReferenceTarget(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyNeedsMarker(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eRawAnonymous(ptr %v0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i1 @compiler_2fcheck_2eleaves(ptr %v0, ptr %a0)
@G_2ecompiler_2ftypes_2eNullable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@olang_loc_a1143936e424f416_6a846c9af99dae82 = external constant [0 x i8]
@olang_loc_b0c5dfd122db8337_2ed6598a574b6003 = external constant [0 x i8]
@olang_loc_445c35e7b454dfb2_9156676d88e8071e = external constant [0 x i8]
@olang_loc_25d55d46e6c695b2_1c5feb2a345583d6 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aGap_3e_2eRunFrom_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_e8d3b00cef07529c_194237a42caab5b0 = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAllSaid(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aSaid_3e_2eRunFrom_3ccompiler_2fdiag_3aSaid_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_1bde8bd2a8f34a58_2374d3532b953474 = external constant [0 x i8]
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
