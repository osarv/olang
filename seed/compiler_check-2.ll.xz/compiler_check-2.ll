; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, { i64, [2 x i64] }, i32, i1 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/load:Import" = type { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, { i64, ptr }, i64, i64 }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, [3 x i64] }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/cond:Value" = type { i32, i64, double, i64, i64, i1 }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i32, i64, i64, i64, i1, i64, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/cond:Consts" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr }, ptr }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/check:errBind" = type { i32, i64, i32, %"compiler/source:Span" }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/check:errNarrow" = type { i64, i32, i64 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i32, %"compiler/source:Span" }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/check:ctSource" = type { ptr, ptr, { i64, ptr }, i64, { i64, ptr } }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1 }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, ptr, i1 }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/generic:AnySlot" = type { i32, i32, i64, i64, i1, i32 }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1 }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr } }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1 }
%"compiler/check:opShape" = type { { i64, ptr }, i64, i1, i1 }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] } }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/typed:Bind" = type { i32, ptr }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/check:Ask" = type { i64, i64, i32, ptr, i64, { i64, ptr } }
%"compiler/check:AssertAsk" = type { i64, i64, %"compiler/source:Span", %"compiler/source:Span", i64, i64, { i64, ptr }, { i64, [3 x i64] }, { i64, ptr } }
%"compiler/generic:Binding" = type { i64, i64, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/check:reflList" = type { i1, i32, i64, i64 }
%"compiler/ast:Compr" = type { ptr, ptr, i32, i32, ptr, ptr, i1, i64 }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/check:ValueAsk" = type { i32, i64, %"compiler/source:Span", i32, i64, { i64, [3 x i64] } }
%"compiler/check:fixedInit" = type { ptr, i32 }
define dso_local void @compiler_2fcheck_2eCtEns_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 2, ptr @G_2ecompiler_2fcheck_2eCtEns, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2eRoReturned_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 2, ptr @G_2ecompiler_2fcheck_2eRoReturned, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l17 = alloca { i64, ptr }
  %l23 = alloca i1
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t35 = call i1 @compiler_2fcheck_2estmtAssigns(ptr %v0, ptr %v1, ptr %t28, { i64, ptr } %a1)
  store i1 %t35, ptr %l23
  br label %bb8
bb8:
  %t36 = load i1, ptr %l23, !tbaa !21
  br i1 %t36, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb4
bb13:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eclosedCall(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l22 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 4
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Call", ptr %t6, i32 0, i32 2
  %t9 = load { i64, [2 x i64] }, ptr %t8
  %t11 = extractvalue { i64, [2 x i64] } %t9, 0
  %t12 = icmp eq i64 %t11, 0
  %t14 = xor i1 %t12, true
  store i1 %t14, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l4, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Call", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  store ptr %t21, ptr %l1, !tbaa !29
  %t23 = load ptr, ptr %l1, !tbaa !29
  store ptr %t23, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t24 = load ptr, ptr %l12, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb7, label %bb8
bb7:
  %t27 = load ptr, ptr %l12, !tbaa !29
  %t28 = load i64, ptr %t27
  %t30 = icmp eq i64 %t28, 0
  store i1 %t30, ptr %l13, !tbaa !21
  br label %bb8
bb8:
  %t31 = load i1, ptr %l13, !tbaa !21
  br i1 %t31, label %bb9, label %bb10
bb9:
  br label %bb15
bb10:
  %t32 = load ptr, ptr %l1, !tbaa !29
  store ptr %t32, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t33 = load ptr, ptr %l16, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t36 = load ptr, ptr %l16, !tbaa !29
  %t37 = load i64, ptr %t36
  %t39 = icmp eq i64 %t37, 4
  store i1 %t39, ptr %l17, !tbaa !21
  br label %bb12
bb12:
  %t40 = load i1, ptr %l17, !tbaa !21
  br i1 %t40, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/typed:Call", ptr %t41, i32 0, i32 1
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  %t46 = call i1 @compiler_2fcheck_2eclosedAll(ptr %v0, { i64, ptr } %t44)
  store i1 %t46, ptr %l22
  br label %bb16
bb16:
  %t47 = load i1, ptr %l22, !tbaa !21
  store i1 %t47, ptr %rv
  br label %ret
bb17:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca i1
  %l18 = alloca ptr
  %l20 = alloca %"compiler/source:Span"
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca %"compiler/source:Span"
  %l24 = alloca ptr
  %l25 = alloca i1
  %l32 = alloca %"compiler/source:Span"
  %l33 = alloca ptr
  %l34 = alloca i1
  %l39 = alloca %"compiler/source:Span"
  %l40 = alloca ptr
  %l41 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i1
  %l56 = alloca %"compiler/source:Span"
  %l59 = alloca { i64, ptr }
  %l61 = alloca %"compiler/source:Span"
  %l67 = alloca i32
  %l70 = alloca i1
  %l73 = alloca i1
  %l74 = alloca i1
  %l77 = alloca i32
  %l81 = alloca { i64, ptr }
  %l83 = alloca %"compiler/source:Span"
  %l85 = alloca %"compiler/source:Span"
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l10, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 11
  store i1 %t8, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l18, !tbaa !29
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t25 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t23)
  store %"compiler/source:Span" %t25, ptr %l20
  br label %bb6
bb6:
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t28 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t26)
  store %"compiler/source:Span" %t28, ptr %l22
  br label %bb7
bb7:
  %t29 = load ptr, ptr %l18, !tbaa !29
  %t30 = load %"compiler/source:Span", ptr %l20
  %t31 = load %"compiler/source:Span", ptr %l22
  %t32 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t29, %"compiler/source:Span" %t30, %"compiler/source:Span" %t31, i64 2)
  store %"compiler/source:Span" %t32, ptr %l23
  br label %bb8
bb8:
  %t33 = load %"compiler/source:Span", ptr %l23
  store %"compiler/source:Span" %t33, ptr %rv
  br label %ret
bb9:
  %t34 = load ptr, ptr %l1, !tbaa !29
  store ptr %t34, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t35 = load ptr, ptr %l24, !tbaa !29
  %t36 = icmp ne ptr %t35, null
  br i1 %t36, label %bb10, label %bb11
bb10:
  %t38 = load ptr, ptr %l24, !tbaa !29
  %t39 = load i64, ptr %t38
  %t41 = icmp eq i64 %t39, 2
  store i1 %t41, ptr %l25, !tbaa !21
  br label %bb11
bb11:
  %t42 = load i1, ptr %l25, !tbaa !21
  br i1 %t42, label %bb12, label %bb13
bb12:
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr { i64, [5 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", ptr }, ptr %t45, i32 0, i32 1
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l4, !tbaa !29
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t53 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %t49, ptr %t50)
  store %"compiler/source:Span" %t53, ptr %l32
  br label %bb15
bb15:
  %t54 = load %"compiler/source:Span", ptr %l32
  store %"compiler/source:Span" %t54, ptr %rv
  br label %ret
bb16:
  %t55 = load ptr, ptr %l1, !tbaa !29
  store ptr %t55, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t56 = load ptr, ptr %l33, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb17, label %bb18
bb17:
  %t59 = load ptr, ptr %l33, !tbaa !29
  %t60 = load i64, ptr %t59
  %t62 = icmp eq i64 %t60, 5
  store i1 %t62, ptr %l34, !tbaa !21
  br label %bb18
bb18:
  %t63 = load i1, ptr %l34, !tbaa !21
  br i1 %t63, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t68 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopOf(ptr %v0, ptr %v1, ptr %t64, ptr %t65)
  store %"compiler/source:Span" %t68, ptr %l39
  br label %bb22
bb22:
  %t69 = load %"compiler/source:Span", ptr %l39
  store %"compiler/source:Span" %t69, ptr %rv
  br label %ret
bb23:
  %t70 = load ptr, ptr %l1, !tbaa !29
  store ptr %t70, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t71 = load ptr, ptr %l40, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  br i1 %t72, label %bb24, label %bb25
bb24:
  %t74 = load ptr, ptr %l40, !tbaa !29
  %t75 = load i64, ptr %t74
  %t77 = icmp eq i64 %t75, 12
  store i1 %t77, ptr %l41, !tbaa !21
  br label %bb25
bb25:
  %t78 = load i1, ptr %l41, !tbaa !21
  br i1 %t78, label %bb26, label %bb27
bb26:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr { i64, [5 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t81, i32 0, i32 1
  %t83 = load ptr, ptr %t82
  store ptr %t83, ptr %l5, !tbaa !29
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr { i64, [5 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t87, i32 0, i32 2
  %t89 = load { i64, ptr }, ptr %t88
  store { i64, ptr } %t89, ptr %l6, !tbaa !27
  br label %bb28
bb27:
  br label %bb54
bb28:
  %t91 = load ptr, ptr %l5, !tbaa !29
  store ptr %t91, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t92 = load ptr, ptr %l48, !tbaa !29
  %t93 = icmp ne ptr %t92, null
  br i1 %t93, label %bb29, label %bb30
bb29:
  %t95 = load ptr, ptr %l48, !tbaa !29
  %t96 = load i64, ptr %t95
  %t98 = icmp eq i64 %t96, 15
  store i1 %t98, ptr %l49, !tbaa !21
  br label %bb30
bb30:
  %t99 = load i1, ptr %l49, !tbaa !21
  br i1 %t99, label %bb31, label %bb32
bb31:
  %t100 = load ptr, ptr %l5, !tbaa !29
  %t102 = getelementptr { i64, [5 x i64] }, ptr %t100, i32 0, i32 1
  %t103 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t102, i32 0, i32 0
  %t104 = load %"compiler/source:Span", ptr %t103
  store %"compiler/source:Span" %t104, ptr %l7
  %t106 = load ptr, ptr %l5, !tbaa !29
  %t108 = getelementptr { i64, [5 x i64] }, ptr %t106, i32 0, i32 1
  %t109 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t108, i32 0, i32 2
  %t110 = load i32, ptr %t109
  store i32 %t110, ptr %l8, !tbaa !23
  br label %bb33
bb32:
  br label %bb36
bb33:
  %t112 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t112, ptr %l56
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load i32, ptr %l8, !tbaa !23
  %t117 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t113, i32 %t114)
  store { i64, ptr } %t117, ptr %l59
  br label %bb34
bb34:
  %t118 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t118, 0
  %t120 = load %"compiler/source:Span", ptr %l56
  %t122 = call %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %t120, i64 %t119)
  store %"compiler/source:Span" %t122, ptr %l61
  br label %bb35
bb35:
  %t123 = load %"compiler/source:Span", ptr %l61
  store %"compiler/source:Span" %t123, ptr %rv
  br label %ret
bb36:
  br label %bb37
bb37:
  %t124 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t124, 0
  %t128 = icmp eq i64 %t126, 1
  br i1 %t128, label %bb38, label %bb39
bb38:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load ptr, ptr %l5, !tbaa !29
  %t134 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t130, ptr %t131)
  store i32 %t134, ptr %l67
  br label %bb40
bb39:
  br label %bb53
bb40:
  %t135 = load i32, ptr %l67, !tbaa !23
  store i32 %t135, ptr %l9, !tbaa !23
  %t136 = load i32, ptr %l9, !tbaa !23
  %t138 = icmp sge i32 %t136, 0
  br i1 %t138, label %bb41, label %bb42
bb41:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i32, ptr %l9, !tbaa !23
  %t144 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t140, i32 %t141)
  store i1 %t144, ptr %l73
  br label %bb43
bb42:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb44
bb43:
  %t145 = load i1, ptr %l73, !tbaa !21
  store i1 %t145, ptr %l70, !tbaa !21
  br label %bb44
bb44:
  %t146 = load i1, ptr %l70, !tbaa !21
  br i1 %t146, label %bb45, label %bb46
bb45:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load i32, ptr %l9, !tbaa !23
  %t151 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t147, i32 %t148)
  store i32 %t151, ptr %l77
  br label %bb47
bb46:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb48
bb47:
  %t152 = load i32, ptr %l77
  %t154 = trunc i64 4 to i32
  %t155 = icmp eq i32 %t152, %t154
  store i1 %t155, ptr %l74, !tbaa !21
  br label %bb48
bb48:
  %t157 = load i1, ptr %l74, !tbaa !21
  br i1 %t157, label %bb49, label %bb50
bb49:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t159, ptr %l81, !tbaa !27
  %t160 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !27
  %t162 = getelementptr ptr, ptr %t161, i64 0
  %t163 = load ptr, ptr %t162, !tbaa !39
  %t166 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %t158, ptr %t163)
  store %"compiler/source:Span" %t166, ptr %l83
  br label %bb51
bb50:
  br label %bb52
bb51:
  %t167 = load %"compiler/source:Span", ptr %l83
  store %"compiler/source:Span" %t167, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  br label %bb55
bb54:
  br label %bb55
bb55:
  %t168 = load ptr, ptr %l1, !tbaa !29
  %t170 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t168)
  store %"compiler/source:Span" %t170, ptr %l85
  br label %bb56
bb56:
  %t171 = load %"compiler/source:Span", ptr %l85
  store %"compiler/source:Span" %t171, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aModules(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/load:Import"
  %l12 = alloca i1
  %l20 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i32
  %l36 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v1, ptr %t1, i64 %t2)
  store i1 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i1, ptr %l12, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t8 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v1, ptr %t7, i64 %t8, i1 true)
  br label %bb5
bb5:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/load:Loader", ptr %t17, i32 0, i32 5
  %t20 = load i64, ptr %l1, !tbaa !24
  %t23 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t19, i64 %t20)
  store ptr %t23, ptr %l20
  br label %bb6
bb6:
  %t24 = load ptr, ptr %l20, !tbaa !29
  %t26 = getelementptr %"compiler/load:Module", ptr %t24, i32 0, i32 11
  store ptr %t26, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t28 = load ptr, ptr %l4, !tbaa !29
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eRunFrom_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t28, i64 %t29)
  %t33 = extractvalue { i32, { i64, ptr } } %t32, 1
  %t34 = extractvalue { i32, { i64, ptr } } %t32, 0
  store i32 %t34, ptr %l27
  %t35 = icmp ne i32 %t34, 0
  br i1 %t35, label %bb9, label %ok.36
ok.36:
  store { i64, ptr } %t33, ptr %l26
  br label %bb8
bb8:
  %t37 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t37, ptr %l23, !tbaa !27
  br label %bb13
bb9:
  %t38 = load i32, ptr %l27, !tbaa !23
  %t39 = ashr i32 %t38, 16
  %t41 = icmp eq i32 %t39, 1
  br i1 %t41, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_8144c9e107914b58_42c61ae8c534985c)
  unreachable
bb12:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb13:
  %t43 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t43, ptr %l6, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  store i64 %t46, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t48 = load i64, ptr %l8, !tbaa !24
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb16:
  br label %bb17
bb17:
  %t56 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t56, ptr %l36, !tbaa !27
  %t57 = load i64, ptr %l8, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr %"compiler/load:Import", ptr %t60, i64 %t57
  %t62 = load %"compiler/load:Import", ptr %t61
  store %"compiler/load:Import" %t62, ptr %l9
  %t64 = getelementptr %"compiler/load:Import", ptr %l9, i32 0, i32 5
  %t65 = load i64, ptr %t64, !tbaa !24
  %t67 = icmp sge i64 %t65, 0
  br i1 %t67, label %bb18, label %bb19
bb18:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/load:Import", ptr %l9, i32 0, i32 5
  %t71 = load i64, ptr %t70, !tbaa !24
  %t72 = load ptr, ptr %l2, !tbaa !29
  %t73 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aModules(ptr %v0, ptr %v1, ptr %v2, ptr %t69, i64 %t71, ptr %t72, ptr %t73)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb22:
  %t78 = load i64, ptr %l8, !tbaa !24
  %t80 = add i64 %t78, 1
  store i64 %t80, ptr %l8, !tbaa !24
  br label %bb14
bb23:
  %t82 = load i64, ptr %l5, !tbaa !24
  %t83 = load i64, ptr %l7, !tbaa !24
  %t86 = add i64 %t82, %t83
  store i64 %t86, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb24:
  br label %bb7
bb25:
  %t88 = load ptr, ptr %l3, !tbaa !29
  %t89 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t88, i64 %t89)
  br label %bb26
bb26:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuildConst(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca { %"compiler/cond:Value", i1 }
  %l4 = alloca %"compiler/cond:Value"
  %l5 = alloca i1
  %lp6 = alloca ptr
  %l8 = alloca ptr
  %l10 = alloca ptr
  %l13 = alloca { %"compiler/cond:Value", i1 }
  %l17 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca { %"compiler/cond:Value", i1 }
  %l22 = alloca i32
  %l27 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l34 = alloca i32
  %l37 = alloca i64
  %l38 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca %"compiler/source:Span"
  %l44 = alloca i32
  %l48 = alloca i32
  %l50 = alloca i32
  %l52 = alloca ptr
  %l55 = alloca ptr
  %l56 = alloca %"compiler/source:Span"
  %l60 = alloca i32
  %l64 = alloca ptr
  %l73 = alloca { i64, ptr }
  %l74 = alloca %"compiler/source:Span"
  %l77 = alloca ptr
  %l79 = alloca i32
  %l81 = alloca i32
  %l83 = alloca ptr
  %l96 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca ptr
  %t182 = alloca { i64, [2 x i64] }, align 8
  %t190 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 89
  store ptr %t3, ptr %l8, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t4)
  store ptr %t6, ptr %l10
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l10, !tbaa !29
  %t9 = getelementptr %"compiler/check:frame", ptr %t7, i32 0, i32 0
  %t10 = load i64, ptr %t9, !tbaa !24
  %t11 = load ptr, ptr %l8, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t11, i64 %t10, i1 true)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/load:Loader", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  store ptr %t22, ptr %l17, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t27 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t23, i32 %a2)
  store { i64, ptr } %t27, ptr %l20
  br label %bb3
bb3:
  %t28 = load ptr, ptr %l17, !tbaa !29
  %t29 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t30 = call { i32, { %"compiler/cond:Value", i1 } } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eValueOf(ptr %v0, ptr %v0, ptr %t28, { i64, ptr } %t29)
  %t31 = extractvalue { i32, { %"compiler/cond:Value", i1 } } %t30, 1
  %t32 = extractvalue { i32, { %"compiler/cond:Value", i1 } } %t30, 0
  store i32 %t32, ptr %l22
  %t33 = icmp ne i32 %t32, 0
  br i1 %t33, label %bb5, label %ok.34
ok.34:
  store { %"compiler/cond:Value", i1 } %t31, ptr %l21
  br label %bb4
bb4:
  %t35 = load { %"compiler/cond:Value", i1 }, ptr %l21
  store { %"compiler/cond:Value", i1 } %t35, ptr %l13
  br label %bb9
bb5:
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s1
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s1, ptr %t36, %"compiler/source:Span" %t37, { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d0, i32 0, i32 1) })
  br label %bb7
bb7:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load %"compiler/source:Span", ptr %l1
  %t44 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t40, %"compiler/source:Span" %t41)
  store ptr %t44, ptr %l27
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t45 = load ptr, ptr %l27, !tbaa !29
  store ptr %t45, ptr %rv
  br label %ret
bb9:
  %t46 = load { %"compiler/cond:Value", i1 }, ptr %l13
  store { %"compiler/cond:Value", i1 } %t46, ptr %l3
  %t47 = getelementptr { %"compiler/cond:Value", i1 }, ptr %l3, i32 0, i32 0
  %t48 = load %"compiler/cond:Value", ptr %t47
  store %"compiler/cond:Value" %t48, ptr %l4
  %t50 = getelementptr { %"compiler/cond:Value", i1 }, ptr %l3, i32 0, i32 1
  %t51 = load i1, ptr %t50, !tbaa !21
  store i1 %t51, ptr %l5, !tbaa !21
  %t53 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t54 = load i32, ptr %t53
  %t56 = trunc i64 1 to i32
  %t57 = icmp eq i32 %t54, %t56
  br i1 %t57, label %bb10, label %bb11
bb10:
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l32, !tbaa !29
  %t60 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t60, ptr %l33
  %t61 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t61, ptr %l34, !tbaa !23
  %t62 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  %t65 = icmp ne i64 %t63, 0
  br i1 %t65, label %bb12, label %bb13
bb11:
  br label %bb16
bb12:
  store i64 1, ptr %l37, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb14
bb14:
  %t67 = load ptr, ptr %l32, !tbaa !29
  %t68 = load %"compiler/source:Span", ptr %l33
  %t69 = load i32, ptr %l34, !tbaa !23
  %t70 = load i64, ptr %l37, !tbaa !24
  %t71 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t67, %"compiler/source:Span" %t68, i32 %t69, i64 %t70)
  store ptr %t71, ptr %l38
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  %t72 = load ptr, ptr %l38, !tbaa !29
  store ptr %t72, ptr %rv
  br label %ret
bb16:
  %t73 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t74 = load i32, ptr %t73
  %t76 = trunc i64 2 to i32
  %t77 = icmp eq i32 %t74, %t76
  br i1 %t77, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l41, !tbaa !29
  %t80 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t80, ptr %l42
  %t81 = load i1, ptr %l5, !tbaa !21
  br i1 %t81, label %bb19, label %bb20
bb18:
  br label %bb25
bb19:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  %t90 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s3, ptr %t88, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i32 %t90, ptr %l48
  br label %bb21
bb20:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t91)
  store i32 %t93, ptr %l50
  br label %bb22
bb21:
  %t94 = load i32, ptr %l48, !tbaa !23
  store i32 %t94, ptr %l44, !tbaa !23
  br label %bb23
bb22:
  %t95 = load i32, ptr %l50, !tbaa !23
  store i32 %t95, ptr %l44, !tbaa !23
  br label %bb23
bb23:
  %t96 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t97 = load i64, ptr %t96, !tbaa !24
  %t98 = load ptr, ptr %l41, !tbaa !29
  %t99 = load %"compiler/source:Span", ptr %l42
  %t100 = load i32, ptr %l44, !tbaa !23
  %t102 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t98, %"compiler/source:Span" %t99, i32 %t100, i64 %t97)
  store ptr %t102, ptr %l52
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t103 = load ptr, ptr %l52, !tbaa !29
  store ptr %t103, ptr %rv
  br label %ret
bb25:
  %t104 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t105 = load i32, ptr %t104
  %t107 = trunc i64 3 to i32
  %t108 = icmp eq i32 %t105, %t107
  br i1 %t108, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l55, !tbaa !29
  %t111 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t111, ptr %l56
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/check:Checker", ptr %t112, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !29
  %t117 = getelementptr %"compiler/generic:Program", ptr %t115, i32 0, i32 2
  %t119 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s4, ptr %t117, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i32 %t119, ptr %l60
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t120 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 2
  %t121 = load double, ptr %t120, !tbaa !26
  %t123 = bitcast double %t121 to i64
  %t125 = load ptr, ptr %l55, !tbaa !29
  %t126 = load %"compiler/source:Span", ptr %l56
  %t127 = load i32, ptr %l60, !tbaa !23
  %t129 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t125, %"compiler/source:Span" %t126, i32 %t127, i64 %t123)
  store ptr %t129, ptr %l64
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t130 = load ptr, ptr %l64, !tbaa !29
  store ptr %t130, ptr %rv
  br label %ret
bb30:
  %t131 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t132 = load i32, ptr %t131
  %t134 = trunc i64 4 to i32
  %t135 = icmp eq i32 %t132, %t134
  br i1 %t135, label %bb31, label %bb32
bb31:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/check:Checker", ptr %t137, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t142 = getelementptr %"compiler/generic:Program", ptr %t140, i32 0, i32 0
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t145 = getelementptr %"compiler/load:Loader", ptr %t143, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t148 = getelementptr %"compiler/cond:Consts", ptr %t146, i32 0, i32 6
  %t149 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 3
  %t150 = load i64, ptr %t149, !tbaa !24
  %t153 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t148, i64 %t150)
  store { i64, ptr } %t153, ptr %l73
  br label %bb33
bb32:
  br label %bb37
bb33:
  %t154 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t154, ptr %lp6
  %t155 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t156 = load ptr, ptr %lp6
  store { i64, ptr } %t155, ptr %t156, !tbaa !27
  %t157 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t157, ptr %l74
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/check:Checker", ptr %t158, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = getelementptr %"compiler/generic:Program", ptr %t161, i32 0, i32 2
  store ptr %t163, ptr %l77, !tbaa !29
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t164)
  store i32 %t166, ptr %l79
  br label %bb34
bb34:
  %t167 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t168 = load ptr, ptr %l77, !tbaa !29
  %t169 = load i32, ptr %l79, !tbaa !23
  %t171 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t168, i32 %t169, i64 %t167)
  store i32 %t171, ptr %l81
  br label %bb35
bb35:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t172)
  store ptr %t174, ptr %l83
  br label %bb36
bb36:
  %t175 = load ptr, ptr %l83, !tbaa !29
  %t177 = getelementptr %"compiler/check:frame", ptr %t175, i32 0, i32 2
  %t178 = load i64, ptr %t177, !tbaa !24
  %t179 = load ptr, ptr %lp6
  %t180 = load { i64, ptr }, ptr %t179, !tbaa !27
  store { i64, [2 x i64] } zeroinitializer, ptr %t182
  %t183 = getelementptr { i64, [2 x i64] }, ptr %t182, i32 0, i32 0
  store i64 1, ptr %t183
  %t185 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t180, 0
  %t186 = getelementptr { i64, [2 x i64] }, ptr %t182, i32 0, i32 1
  store { { i64, ptr } } %t185, ptr %t186
  %t187 = load { i64, [2 x i64] }, ptr %t182
  %t189 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store { i64, [2 x i64] } %t187, ptr %t189
  store { i64, [5 x i64] } zeroinitializer, ptr %t190
  %t191 = getelementptr { i64, [5 x i64] }, ptr %t190, i32 0, i32 0
  store i64 1, ptr %t191
  %t192 = load %"compiler/source:Span", ptr %l74
  %t193 = insertvalue { %"compiler/source:Span", i32, i64, ptr } undef, %"compiler/source:Span" %t192, 0
  %t194 = load i32, ptr %l81, !tbaa !23
  %t195 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t193, i32 %t194, 1
  %t197 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t195, i64 %t178, 2
  %t199 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t197, ptr %t189, 3
  %t200 = getelementptr { i64, [5 x i64] }, ptr %t190, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, ptr } %t199, ptr %t200
  %t201 = load { i64, [5 x i64] }, ptr %t190
  %t203 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t201, ptr %t203
  call void @__olang_scope_close(ptr %s0)
  store ptr %t203, ptr %rv
  br label %ret
bb37:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s0, ptr %t205, %"compiler/source:Span" %t206, { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d3, i32 0, i32 1) })
  br label %bb38
bb38:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load %"compiler/source:Span", ptr %l1
  %t213 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t209, %"compiler/source:Span" %t210)
  store ptr %t213, ptr %l96
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s0)
  %t214 = load ptr, ptr %l96, !tbaa !29
  store ptr %t214, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtItems(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/generic:Context"
  %l5 = alloca i32
  %l6 = alloca { i64, i32 }
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca ptr
  %l17 = alloca ptr
  %l24 = alloca i32
  %l32 = alloca ptr
  %l35 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l37 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l41 = alloca { i64, i32 }
  %l46 = alloca i1
  %l51 = alloca ptr
  %l54 = alloca i64
  %l56 = alloca i32
  %rv = alloca { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  %t7 = call ptr @compiler_2fcheck_2eexprPath(ptr %v1, ptr %a1)
  store ptr %t7, ptr %l11
  br label %bb2
bb2:
  %t8 = load ptr, ptr %l11, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t11 = icmp eq ptr %t9, null
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t13 = load ptr, ptr %lp2
  %t14 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t13
  %t16 = insertvalue { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 } undef, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, 0
  %t17 = insertvalue { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 } %t16, i1 false, 1
  store { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 } %t17, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t19)
  store ptr %t21, ptr %l17
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l17, !tbaa !29
  %t24 = getelementptr %"compiler/check:frame", ptr %t22, i32 0, i32 4
  %t25 = load %"compiler/generic:Context", ptr %t24
  store %"compiler/generic:Context" %t25, ptr %l4
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t31 = load ptr, ptr %l3, !tbaa !29
  %t35 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorType(ptr %v0, ptr %v0, ptr %v1, ptr %t30, ptr %l4, ptr %t31)
  store i32 %t35, ptr %l24
  br label %bb7
bb7:
  %t36 = load i32, ptr %l24, !tbaa !23
  store i32 %t36, ptr %l5, !tbaa !23
  %t37 = load i32, ptr %l5, !tbaa !23
  %t38 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t41 = icmp ne i32 %t37, %t38
  br i1 %t41, label %bb8, label %bb9
bb8:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t47 = load i32, ptr %l5, !tbaa !23
  %t48 = load ptr, ptr %lp2
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eEntriesOf(ptr %v0, ptr %v2, ptr %t46, i32 %t47, ptr %t48)
  br label %bb10
bb9:
  br label %bb13
bb10:
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l32, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load ptr, ptr %lp2
  %t57 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emerged(ptr %v0, ptr %v2, ptr %v2, ptr %t53, ptr %t54)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t57, ptr %l35
  br label %bb11
bb11:
  %t58 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l35
  %t59 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t58, ptr %t59
  %t60 = load ptr, ptr %l32, !tbaa !29
  %t62 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enormalSet(ptr %v0, ptr %v2, ptr %v2, ptr %t60, ptr %t59)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t62, ptr %l37
  br label %bb12
bb12:
  %t63 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l37
  %t64 = insertvalue { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 } undef, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t63, 0
  %t65 = insertvalue { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 } %t64, i1 true, 1
  store { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 } %t65, ptr %rv
  br label %ret
bb13:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l3, !tbaa !29
  %t71 = call { i64, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorWord(ptr %v0, ptr %v1, ptr %t67, ptr %t68)
  store { i64, i32 } %t71, ptr %l41
  br label %bb14
bb14:
  %t72 = load { i64, i32 }, ptr %l41
  store { i64, i32 } %t72, ptr %l6
  %t73 = getelementptr { i64, i32 }, ptr %l6, i32 0, i32 0
  %t74 = load i64, ptr %t73, !tbaa !24
  store i64 %t74, ptr %l7, !tbaa !24
  %t76 = getelementptr { i64, i32 }, ptr %l6, i32 0, i32 1
  %t77 = load i32, ptr %t76, !tbaa !23
  store i32 %t77, ptr %l8, !tbaa !23
  %t79 = load i64, ptr %l7, !tbaa !24
  %t81 = icmp slt i64 %t79, 0
  br i1 %t81, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb17
bb16:
  %t83 = load i64, ptr %l7, !tbaa !24
  %t85 = icmp sge i64 %t83, 64
  store i1 %t85, ptr %l46, !tbaa !21
  br label %bb17
bb17:
  %t87 = load i1, ptr %l46, !tbaa !21
  br i1 %t87, label %bb18, label %bb19
bb18:
  %t88 = load ptr, ptr %lp2
  %t89 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t88
  %t91 = insertvalue { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 } undef, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t89, 0
  %t92 = insertvalue { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 } %t91, i1 false, 1
  store { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 } %t92, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t94 = load ptr, ptr %lp2
  store ptr %t94, ptr %l51, !tbaa !29
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load i32, ptr %l8, !tbaa !23
  %t97 = load i64, ptr %l7, !tbaa !24
  store i64 %t97, ptr %l54, !tbaa !24
  %t98 = load i64, ptr %l54, !tbaa !24
  %t99 = load i64, ptr %l54, !tbaa !24
  %t100 = shl i64 1, %t99
  %t104 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryOf(ptr %v0, ptr %t95, i32 %t96, i64 %t100)
  store i32 %t104, ptr %l56
  br label %bb21
bb21:
  %t105 = load ptr, ptr %l51, !tbaa !29
  %t106 = load i32, ptr %l56, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t105, i32 %t106)
  br label %bb22
bb22:
  %t107 = load ptr, ptr %lp2
  %t108 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t107
  %t110 = insertvalue { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 } undef, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t108, 0
  %t111 = insertvalue { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 } %t110, i1 true, 1
  store { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 } %t111, ptr %rv
  br label %ret
ret:
  %rr = load { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }, ptr %rv
  ret { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 } %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtLast(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l41 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l54 = alloca ptr
  %l55 = alloca i1
  %l69 = alloca i64
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Match", ptr %t1, i32 0, i32 3
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  store i64 %t6, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t12 = icmp sgt i64 %t8, %t9
  br i1 %t12, label %bb1, label %bb2
bb1:
  %t14 = load i64, ptr %l5, !tbaa !24
  %t16 = icmp sgt i64 %t14, 0
  br i1 %t16, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb6
bb3:
  %t18 = load i64, ptr %l4, !tbaa !24
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = sub i64 %t18, %t19
  %t23 = load i64, ptr %l5, !tbaa !24
  %t26 = add i64 %t22, %t23
  %t28 = sub i64 %t26, 1
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = sdiv i64 %t28, %t29
  store i64 %t32, ptr %l22, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb5
bb5:
  %t34 = load i64, ptr %l22, !tbaa !24
  store i64 %t34, ptr %l19, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l19, !tbaa !24
  store i64 %t35, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load i64, ptr %l7, !tbaa !24
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb9:
  br label %bb10
bb10:
  %t44 = load i64, ptr %l3, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  %t46 = load i64, ptr %l5, !tbaa !24
  %t49 = mul i64 %t45, %t46
  %t52 = add i64 %t44, %t49
  store i64 %t52, ptr %l8, !tbaa !24
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr %"compiler/ast:Match", ptr %t54, i32 0, i32 3
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  store { i64, ptr } %t57, ptr %l41, !tbaa !27
  %t58 = load i64, ptr %l8, !tbaa !24
  %t60 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr ptr, ptr %t61, i64 %t58
  %t63 = load ptr, ptr %t62, !tbaa !39
  %t65 = getelementptr %"compiler/ast:Case", ptr %t63, i32 0, i32 1
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !27
  store { i64, ptr } %t66, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t68 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t68, 0
  store i64 %t70, ptr %l11, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t72 = load i64, ptr %l10, !tbaa !24
  %t73 = load i64, ptr %l11, !tbaa !24
  %t76 = icmp slt i64 %t72, %t73
  %t78 = xor i1 %t76, true
  br i1 %t78, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb13:
  br label %bb14
bb14:
  %t80 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t80, ptr %l51, !tbaa !27
  %t81 = load i64, ptr %l10, !tbaa !24
  %t83 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = getelementptr ptr, ptr %t84, i64 %t81
  %t86 = load ptr, ptr %t85, !tbaa !39
  store ptr %t86, ptr %l54, !tbaa !29
  store i1 false, ptr %l55, !tbaa !21
  %t89 = load ptr, ptr %l54, !tbaa !29
  %t90 = icmp ne ptr %t89, null
  br i1 %t90, label %bb15, label %bb16
bb15:
  %t92 = load ptr, ptr %l54, !tbaa !29
  %t93 = load i64, ptr %t92
  %t95 = icmp eq i64 %t93, 0
  store i1 %t95, ptr %l55, !tbaa !21
  br label %bb16
bb16:
  %t96 = load i1, ptr %l55, !tbaa !21
  br i1 %t96, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t97 = load i64, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  store i64 %t97, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb22:
  %t99 = load i64, ptr %l10, !tbaa !24
  %t101 = add i64 %t99, 1
  store i64 %t101, ptr %l10, !tbaa !24
  br label %bb11
bb23:
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb24:
  %t103 = load i64, ptr %l7, !tbaa !24
  %t105 = add i64 %t103, 1
  store i64 %t105, ptr %l7, !tbaa !24
  br label %bb7
bb25:
  %t107 = load ptr, ptr %l1, !tbaa !29
  %t109 = getelementptr %"compiler/ast:Match", ptr %t107, i32 0, i32 4
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = icmp eq ptr %t110, null
  %t114 = xor i1 %t112, true
  br i1 %t114, label %bb26, label %bb27
bb26:
  store i64 -1, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  br i1 %a2, label %bb29, label %bb30
bb29:
  %t119 = load ptr, ptr %l1, !tbaa !29
  %t121 = getelementptr %"compiler/ast:Match", ptr %t119, i32 0, i32 3
  %t122 = load { i64, ptr }, ptr %t121, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t122, 0
  %t126 = sub i64 %t124, 1
  store i64 %t126, ptr %l69, !tbaa !24
  br label %bb31
bb30:
  store i64 -1, ptr %l69, !tbaa !24
  br label %bb31
bb31:
  %t128 = load i64, ptr %l69, !tbaa !24
  store i64 %t128, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclause(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i32 %a2, i1 %a3, { i64, ptr } %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i1
  %l6 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca i32
  %l18 = alloca %"compiler/source:Span"
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca i1
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i32
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca %"compiler/check:errBind"
  %l36 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l39 = alloca i1
  %l44 = alloca i1
  %l55 = alloca { i64, ptr }
  %l67 = alloca i1
  %l70 = alloca ptr
  %l73 = alloca i64
  %l77 = alloca i1
  %l80 = alloca i32
  %l82 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l89 = alloca %"compiler/source:Span"
  %l91 = alloca { i64, ptr }
  %l101 = alloca i32
  %l102 = alloca ptr
  %l103 = alloca %"compiler/source:Span"
  %l107 = alloca i32
  %l108 = alloca i64
  %l110 = alloca ptr
  %l115 = alloca %"compiler/check:errBind"
  %l125 = alloca i1
  %l130 = alloca i1
  %l133 = alloca { i64, ptr }
  %l137 = alloca ptr
  %l138 = alloca i1
  %l144 = alloca i1
  %l146 = alloca ptr
  %l148 = alloca %"compiler/source:Span"
  %l149 = alloca ptr
  %l151 = alloca %"compiler/source:Span"
  %l152 = alloca { i64, ptr }
  %l153 = alloca %"compiler/msgs:Msg"
  %l154 = alloca i64
  %l155 = alloca { i64, ptr }
  %l157 = alloca i64
  %l158 = alloca i64
  %l168 = alloca ptr
  %l172 = alloca i64
  %l174 = alloca i1
  %l179 = alloca i1
  %l184 = alloca i32
  %l187 = alloca i1
  %l190 = alloca i64
  %l193 = alloca ptr
  %l198 = alloca i32
  %l199 = alloca { i64, ptr }
  %l206 = alloca i1
  %l209 = alloca i1
  %l211 = alloca i1
  %l222 = alloca i64
  %l225 = alloca i64
  %l248 = alloca i32
  %l251 = alloca i1
  %l258 = alloca ptr
  %l263 = alloca i32
  %l264 = alloca { i64, ptr }
  %l269 = alloca { i64, ptr }
  %l273 = alloca i1
  %l276 = alloca i1
  %l278 = alloca i1
  %l283 = alloca i1
  %l284 = alloca i1
  %l286 = alloca { i64, ptr }
  %l289 = alloca i1
  %l291 = alloca ptr
  %l293 = alloca { i64, ptr }
  %l296 = alloca %"compiler/source:Span"
  %l297 = alloca %"compiler/msgs:Msg"
  %l298 = alloca i64
  %l300 = alloca ptr
  %l303 = alloca { i64, ptr }
  %l307 = alloca ptr
  %l313 = alloca { i64, ptr }
  %l319 = alloca %"compiler/check:errBind"
  %l323 = alloca i1
  %l325 = alloca ptr
  %l326 = alloca %"compiler/source:Span"
  %l329 = alloca %"compiler/msgs:Msg"
  %l332 = alloca { i64, ptr }
  %l334 = alloca %"compiler/msgs:Msg"
  %l337 = alloca { i64, ptr }
  %l339 = alloca %"compiler/msgs:Msg"
  %l340 = alloca i64
  %l349 = alloca i64
  %l351 = alloca i1
  %l352 = alloca %"compiler/check:errNarrow"
  %l355 = alloca %"compiler/check:errNarrow"
  %l356 = alloca i32
  %l361 = alloca %"compiler/check:errNarrow"
  %l364 = alloca %"compiler/check:errNarrow"
  %l365 = alloca i32
  %l370 = alloca %"compiler/source:Span"
  %l372 = alloca { i64, ptr }
  %l378 = alloca %"compiler/typed:Clause"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aItem_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l36
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l36
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l6
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t7 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloneBinding(ptr %v0, ptr %v1, ptr %t3, ptr %t4)
  store i1 %t7, ptr %l39
  br label %bb2
bb2:
  %t8 = load i1, ptr %l39, !tbaa !21
  store i1 %t8, ptr %l7, !tbaa !21
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/ast:Catch", ptr %t9, i32 0, i32 1
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t16 = icmp sgt i64 %t14, 0
  br i1 %t16, label %bb3, label %bb4
bb3:
  %t18 = load i1, ptr %l7, !tbaa !21
  %t20 = xor i1 %t18, true
  store i1 %t20, ptr %l44, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb5
bb5:
  %t22 = load i1, ptr %l44, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = getelementptr %"compiler/ast:Catch", ptr %t23, i32 0, i32 1
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  store { i64, ptr } %t26, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t28 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  store i64 %t30, ptr %l10, !tbaa !24
  br label %bb8
bb7:
  br label %bb15
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t32 = load i64, ptr %l9, !tbaa !24
  %t33 = load i64, ptr %l10, !tbaa !24
  %t36 = icmp slt i64 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb10:
  br label %bb11
bb11:
  %t40 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t40, ptr %l55, !tbaa !27
  %t41 = load i64, ptr %l9, !tbaa !24
  %t43 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr ptr, ptr %t44, i64 %t41
  %t46 = load ptr, ptr %t45, !tbaa !39
  %t48 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchItem(ptr %v0, ptr %v1, ptr %s0, ptr %t48, ptr %t46, ptr %l6)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb13:
  %t53 = load i64, ptr %l9, !tbaa !24
  %t55 = add i64 %t53, 1
  store i64 %t55, ptr %l9, !tbaa !24
  br label %bb8
bb14:
  br label %bb15
bb15:
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr %"compiler/ast:Catch", ptr %t57, i32 0, i32 1
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  %t64 = icmp eq i64 %t62, 0
  br i1 %t64, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb18
bb17:
  %t66 = load i1, ptr %l7, !tbaa !21
  store i1 %t66, ptr %l67, !tbaa !21
  br label %bb18
bb18:
  %t68 = load i1, ptr %l67, !tbaa !21
  store i1 %t68, ptr %l12, !tbaa !21
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t69)
  store ptr %t71, ptr %l70
  br label %bb19
bb19:
  %t72 = load ptr, ptr %l70, !tbaa !29
  store ptr %t72, ptr %l13, !tbaa !29
  store i64 -1, ptr %l14, !tbaa !24
  store i32 0, ptr %l15, !tbaa !23
  %t73 = load ptr, ptr %l13, !tbaa !29
  %t75 = getelementptr %"compiler/check:frame", ptr %t73, i32 0, i32 53
  %t77 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aerrBind_3e_2eLen_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %t75)
  store i64 %t77, ptr %l73
  br label %bb20
bb20:
  %t78 = load i64, ptr %l73, !tbaa !24
  store i64 %t78, ptr %l16, !tbaa !24
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr %"compiler/ast:Catch", ptr %t79, i32 0, i32 5
  %t82 = load i32, ptr %t81, !tbaa !23
  %t84 = icmp ne i32 %t82, 0
  br i1 %t84, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l77, !tbaa !21
  br label %bb23
bb22:
  %t86 = load i1, ptr %l7, !tbaa !21
  store i1 %t86, ptr %l77, !tbaa !21
  br label %bb23
bb23:
  %t88 = load i1, ptr %l77, !tbaa !21
  br i1 %t88, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  %t89 = load i1, ptr %l7, !tbaa !21
  br i1 %t89, label %bb26, label %bb27
bb25:
  br label %bb38
bb26:
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t93 = getelementptr %"compiler/ast:Catch", ptr %t91, i32 0, i32 1
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  store { i64, ptr } %t94, ptr %l82, !tbaa !27
  %t95 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr ptr, ptr %t96, i64 0
  %t98 = load ptr, ptr %t97, !tbaa !39
  %t100 = getelementptr %"compiler/ast:Path", ptr %t98, i32 0, i32 1
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !27
  store { i64, ptr } %t101, ptr %l84, !tbaa !27
  %t102 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr i32, ptr %t103, i64 0
  %t105 = load i32, ptr %t104, !tbaa !33
  store i32 %t105, ptr %l80, !tbaa !23
  br label %bb28
bb27:
  %t107 = load ptr, ptr %l1, !tbaa !29
  %t109 = getelementptr %"compiler/ast:Catch", ptr %t107, i32 0, i32 5
  %t110 = load i32, ptr %t109, !tbaa !23
  store i32 %t110, ptr %l80, !tbaa !23
  br label %bb28
bb28:
  %t112 = load i32, ptr %l80, !tbaa !23
  store i32 %t112, ptr %l17, !tbaa !23
  %t113 = load i1, ptr %l7, !tbaa !21
  br i1 %t113, label %bb29, label %bb30
bb29:
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t117 = getelementptr %"compiler/ast:Catch", ptr %t115, i32 0, i32 1
  %t118 = load { i64, ptr }, ptr %t117, !tbaa !27
  store { i64, ptr } %t118, ptr %l91, !tbaa !27
  %t119 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr ptr, ptr %t120, i64 0
  %t122 = load ptr, ptr %t121, !tbaa !39
  %t124 = getelementptr %"compiler/ast:Path", ptr %t122, i32 0, i32 0
  %t125 = load %"compiler/source:Span", ptr %t124
  store %"compiler/source:Span" %t125, ptr %l89
  br label %bb31
bb30:
  %t127 = load ptr, ptr %l1, !tbaa !29
  %t129 = getelementptr %"compiler/ast:Catch", ptr %t127, i32 0, i32 6
  %t130 = load %"compiler/source:Span", ptr %t129
  store %"compiler/source:Span" %t130, ptr %l89
  br label %bb31
bb31:
  %t132 = load %"compiler/source:Span", ptr %l89
  store %"compiler/source:Span" %t132, ptr %l18
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = load i1, ptr %l12, !tbaa !21
  %t142 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etakenSet(ptr %v0, ptr %v2, ptr %s0, ptr %v3, ptr %t133, { i64, ptr } %a4, ptr %l6, i1 %t135, ptr %a5)
  store i32 %t142, ptr %l101
  br label %bb32
bb32:
  %t143 = load i32, ptr %l101, !tbaa !23
  store i32 %t143, ptr %l15, !tbaa !23
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l102, !tbaa !29
  %t145 = load %"compiler/source:Span", ptr %l18
  store %"compiler/source:Span" %t145, ptr %l103
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/check:Checker", ptr %t146, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t151 = getelementptr %"compiler/generic:Program", ptr %t149, i32 0, i32 2
  %t153 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s5, ptr %t151, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store i32 %t153, ptr %l107
  br label %bb33
bb33:
  %t154 = load ptr, ptr %l102, !tbaa !29
  %t155 = load %"compiler/source:Span", ptr %l103
  %t156 = load i32, ptr %l107, !tbaa !23
  %t157 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t154, %"compiler/source:Span" %t155, i32 %t156)
  store i64 %t157, ptr %l108
  br label %bb34
bb34:
  %t158 = load i64, ptr %l108, !tbaa !24
  store i64 %t158, ptr %l14, !tbaa !24
  %t159 = load ptr, ptr %l13, !tbaa !29
  %t161 = getelementptr %"compiler/check:frame", ptr %t159, i32 0, i32 53
  store ptr %t161, ptr %l110, !tbaa !29
  %t162 = load i32, ptr %l17, !tbaa !23
  %t163 = load i64, ptr %l14, !tbaa !24
  %t164 = load i32, ptr %l15, !tbaa !23
  %t165 = load %"compiler/source:Span", ptr %l18
  %t170 = call %"compiler/check:errBind" @compiler_2fcheck_3aerrBind_2ector(ptr %s5, i32 %t162, i64 %t163, i32 %t164, %"compiler/source:Span" %t165)
  store %"compiler/check:errBind" %t170, ptr %l115
  br label %bb35
bb35:
  %t171 = load ptr, ptr %l110, !tbaa !29
  %t172 = load %"compiler/check:errBind", ptr %l115
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aerrBind_3e_2ePus_H8b0879c0f677037d30ab876e02db27f1(ptr %v0, ptr %t171, %"compiler/check:errBind" %t172)
  br label %bb36
bb36:
  %t173 = load ptr, ptr %l13, !tbaa !29
  %t175 = getelementptr %"compiler/check:frame", ptr %t173, i32 0, i32 54
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t175, i1 false)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s5)
  br label %bb38
bb38:
  store ptr null, ptr %l19, !tbaa !29
  %t177 = load ptr, ptr %l1, !tbaa !29
  %t179 = getelementptr %"compiler/ast:Catch", ptr %t177, i32 0, i32 4
  %t180 = load i1, ptr %t179, !tbaa !21
  br i1 %t180, label %bb39, label %bb40
bb39:
  %t182 = load ptr, ptr %l1, !tbaa !29
  %t184 = getelementptr %"compiler/ast:Catch", ptr %t182, i32 0, i32 2
  %t185 = load { i64, ptr }, ptr %t184, !tbaa !27
  store { i64, ptr } %t185, ptr %l20, !tbaa !27
  %t187 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t187, 0
  store i64 %t189, ptr %l21, !tbaa !24
  %t191 = load i1, ptr %l3, !tbaa !21
  br i1 %t191, label %bb41, label %bb42
bb40:
  br label %bb73
bb41:
  %t193 = load ptr, ptr %l1, !tbaa !29
  %t195 = getelementptr %"compiler/ast:Catch", ptr %t193, i32 0, i32 3
  %t196 = load { i64, ptr }, ptr %t195, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t196, 0
  %t200 = icmp eq i64 %t198, 0
  store i1 %t200, ptr %l125, !tbaa !21
  br label %bb43
bb42:
  store i1 false, ptr %l125, !tbaa !21
  br label %bb43
bb43:
  %t202 = load i1, ptr %l125, !tbaa !21
  br i1 %t202, label %bb44, label %bb45
bb44:
  %t203 = load i64, ptr %l21, !tbaa !24
  %t205 = icmp sgt i64 %t203, 0
  store i1 %t205, ptr %l130, !tbaa !21
  br label %bb46
bb45:
  store i1 false, ptr %l130, !tbaa !21
  br label %bb46
bb46:
  %t207 = load i1, ptr %l130, !tbaa !21
  br i1 %t207, label %bb47, label %bb48
bb47:
  %t208 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t208, ptr %l133, !tbaa !27
  %t209 = load i64, ptr %l21, !tbaa !24
  %t211 = sub i64 %t209, 1
  %t213 = getelementptr { i64, ptr }, ptr %l133, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !27
  %t215 = getelementptr ptr, ptr %t214, i64 %t211
  %t216 = load ptr, ptr %t215, !tbaa !39
  store ptr %t216, ptr %l22, !tbaa !29
  %t218 = load ptr, ptr %l22, !tbaa !29
  store ptr %t218, ptr %l137, !tbaa !29
  store i1 false, ptr %l138, !tbaa !21
  %t219 = load ptr, ptr %l137, !tbaa !29
  %t220 = icmp ne ptr %t219, null
  br i1 %t220, label %bb49, label %bb50
bb48:
  br label %bb71
bb49:
  %t222 = load ptr, ptr %l137, !tbaa !29
  %t223 = load i64, ptr %t222
  %t225 = icmp eq i64 %t223, 0
  store i1 %t225, ptr %l138, !tbaa !21
  br label %bb50
bb50:
  %t226 = load i1, ptr %l138, !tbaa !21
  br i1 %t226, label %bb51, label %bb52
bb51:
  %t227 = load ptr, ptr %l22, !tbaa !29
  %t229 = getelementptr { i64, [4 x i64] }, ptr %t227, i32 0, i32 1
  %t230 = getelementptr { %"compiler/source:Span", ptr }, ptr %t229, i32 0, i32 1
  %t231 = load ptr, ptr %t230
  store ptr %t231, ptr %l23, !tbaa !29
  br label %bb53
bb52:
  br label %bb69
bb53:
  %t233 = load ptr, ptr %l23, !tbaa !29
  %t235 = call i1 @compiler_2fcheck_2estmtLike(ptr %v1, ptr %t233)
  store i1 %t235, ptr %l144
  br label %bb54
bb54:
  %t236 = load i1, ptr %l144, !tbaa !21
  %t237 = xor i1 %t236, true
  br i1 %t237, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s9
  %t239 = load ptr, ptr %l0, !tbaa !29
  store ptr %t239, ptr %l146, !tbaa !29
  %t240 = load ptr, ptr %l23, !tbaa !29
  %t242 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t240)
  store %"compiler/source:Span" %t242, ptr %l148
  br label %bb57
bb56:
  br label %bb68
bb57:
  %t243 = load ptr, ptr %l0, !tbaa !29
  store ptr %t243, ptr %l149, !tbaa !29
  %t244 = load ptr, ptr %l23, !tbaa !29
  %t246 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t244)
  store %"compiler/source:Span" %t246, ptr %l151
  br label %bb58
bb58:
  %t247 = load ptr, ptr %l149, !tbaa !29
  %t248 = load %"compiler/source:Span", ptr %l151
  %t249 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t247, %"compiler/source:Span" %t248)
  store { i64, ptr } %t249, ptr %l152
  br label %bb59
bb59:
  %t250 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t251 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eClauseLastValue(ptr %v0, ptr %s9, { i64, ptr } %t250)
  store %"compiler/msgs:Msg" %t251, ptr %l153
  br label %bb60
bb60:
  %t252 = load ptr, ptr %l146, !tbaa !29
  %t253 = load %"compiler/source:Span", ptr %l148
  %t254 = load %"compiler/msgs:Msg", ptr %l153
  %t255 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s9, ptr %t252, %"compiler/source:Span" %t253, %"compiler/msgs:Msg" %t254)
  store i64 %t255, ptr %l154
  br label %bb61
bb61:
  %t256 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t256, ptr %l155, !tbaa !27
  %t257 = load i64, ptr %l21, !tbaa !24
  %t259 = sub i64 %t257, 1
  store i64 %t259, ptr %l157, !tbaa !24
  %t260 = load { i64, ptr }, ptr %l155, !tbaa !27
  %t261 = extractvalue { i64, ptr } %t260, 0
  store i64 %t261, ptr %l158, !tbaa !24
  %t262 = icmp sge i64 0, 0
  br i1 %t262, label %bb62, label %bb63
bb62:
  %t264 = load i64, ptr %l157, !tbaa !24
  %t265 = icmp sle i64 0, %t264
  br i1 %t265, label %bb64, label %bb65
bb63:
  call void @__olang_check_failed(ptr @olang_loc_977e9a9c02703c7b_61f13f164c004b4f)
  unreachable
bb64:
  %t267 = load i64, ptr %l157, !tbaa !24
  %t268 = load i64, ptr %l158, !tbaa !24
  %t269 = icmp sle i64 %t267, %t268
  br i1 %t269, label %bb66, label %bb67
bb65:
  call void @__olang_check_failed(ptr @olang_loc_977e9a9c02703c7b_61f13f164c004b4f)
  unreachable
bb66:
  %t271 = getelementptr { i64, ptr }, ptr %l155, i32 0, i32 1
  %t272 = load ptr, ptr %t271, !tbaa !27
  %t273 = load i64, ptr %l157, !tbaa !24
  %t274 = getelementptr ptr, ptr %t272, i64 0
  %t275 = sub i64 %t273, 0
  %t276 = insertvalue { i64, ptr } undef, i64 %t275, 0
  %t277 = insertvalue { i64, ptr } %t276, ptr %t274, 1
  store { i64, ptr } %t277, ptr %l20, !tbaa !27
  call void @__olang_scope_close(ptr %s9)
  br label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_977e9a9c02703c7b_61f13f164c004b4f)
  unreachable
bb68:
  br label %bb70
bb69:
  br label %bb70
bb70:
  br label %bb71
bb71:
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t280 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t281 = load ptr, ptr %l1, !tbaa !29
  %t283 = getelementptr %"compiler/ast:Catch", ptr %t281, i32 0, i32 0
  %t284 = load %"compiler/source:Span", ptr %t283
  %t289 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eblockOf(ptr %v0, ptr %v1, ptr %t279, { i64, ptr } %t280, i32 4, %"compiler/source:Span" %t284)
  store ptr %t289, ptr %l168
  br label %bb72
bb72:
  %t290 = load ptr, ptr %l168, !tbaa !29
  store ptr %t290, ptr %l19, !tbaa !29
  br label %bb73
bb73:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr %"compiler/check:Checker", ptr %t292, i32 0, i32 32
  %t296 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t294)
  store i64 %t296, ptr %l172
  br label %bb74
bb74:
  %t297 = load i64, ptr %l172, !tbaa !24
  store i64 %t297, ptr %l24, !tbaa !24
  %t298 = load i1, ptr %l3, !tbaa !21
  br i1 %t298, label %bb75, label %bb76
bb75:
  %t300 = load ptr, ptr %l1, !tbaa !29
  %t302 = getelementptr %"compiler/ast:Catch", ptr %t300, i32 0, i32 3
  %t303 = load { i64, ptr }, ptr %t302, !tbaa !27
  %t305 = extractvalue { i64, ptr } %t303, 0
  %t307 = icmp sgt i64 %t305, 0
  store i1 %t307, ptr %l174, !tbaa !21
  br label %bb77
bb76:
  store i1 false, ptr %l174, !tbaa !21
  br label %bb77
bb77:
  %t309 = load i1, ptr %l174, !tbaa !21
  br i1 %t309, label %bb78, label %bb79
bb78:
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t312 = getelementptr %"compiler/check:Checker", ptr %t310, i32 0, i32 1
  %t313 = load ptr, ptr %t312, !tbaa !29
  %t315 = getelementptr %"compiler/generic:Program", ptr %t313, i32 0, i32 2
  %t316 = load i32, ptr %l2, !tbaa !23
  %t319 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t315, i32 %t316)
  store i32 %t319, ptr %l184
  br label %bb80
bb79:
  store i1 false, ptr %l179, !tbaa !21
  br label %bb81
bb80:
  %t320 = load i32, ptr %l184
  %t322 = trunc i64 22 to i32
  %t323 = icmp eq i32 %t320, %t322
  store i1 %t323, ptr %l179, !tbaa !21
  br label %bb81
bb81:
  %t325 = load i1, ptr %l179, !tbaa !21
  br i1 %t325, label %bb82, label %bb83
bb82:
  %t326 = load ptr, ptr %l1, !tbaa !29
  %t328 = getelementptr %"compiler/ast:Catch", ptr %t326, i32 0, i32 3
  %t329 = load { i64, ptr }, ptr %t328, !tbaa !27
  %t331 = extractvalue { i64, ptr } %t329, 0
  store i64 %t331, ptr %l190, !tbaa !24
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t334 = getelementptr %"compiler/check:Checker", ptr %t332, i32 0, i32 1
  %t335 = load ptr, ptr %t334, !tbaa !29
  %t337 = getelementptr %"compiler/generic:Program", ptr %t335, i32 0, i32 2
  store ptr %t337, ptr %l193, !tbaa !29
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t340 = getelementptr %"compiler/check:Checker", ptr %t338, i32 0, i32 1
  %t341 = load ptr, ptr %t340, !tbaa !29
  %t343 = getelementptr %"compiler/generic:Program", ptr %t341, i32 0, i32 2
  %t344 = load i32, ptr %l2, !tbaa !23
  %t347 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t343, i32 %t344)
  store i32 %t347, ptr %l198
  br label %bb84
bb83:
  store i1 false, ptr %l187, !tbaa !21
  br label %bb86
bb84:
  %t348 = load ptr, ptr %l193, !tbaa !29
  %t349 = load i32, ptr %l198, !tbaa !23
  %t350 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t348, i32 %t349)
  store { i64, ptr } %t350, ptr %l199
  br label %bb85
bb85:
  %t351 = load { i64, ptr }, ptr %l199, !tbaa !27
  %t352 = extractvalue { i64, ptr } %t351, 0
  %t353 = load i64, ptr %l190, !tbaa !24
  %t355 = icmp ne i64 %t353, %t352
  store i1 %t355, ptr %l187, !tbaa !21
  br label %bb86
bb86:
  %t357 = load i1, ptr %l187, !tbaa !21
  store i1 %t357, ptr %l25, !tbaa !21
  %t358 = load ptr, ptr %l1, !tbaa !29
  %t360 = getelementptr %"compiler/ast:Catch", ptr %t358, i32 0, i32 3
  %t361 = load { i64, ptr }, ptr %t360, !tbaa !27
  %t363 = extractvalue { i64, ptr } %t361, 0
  %t365 = icmp sgt i64 %t363, 0
  br i1 %t365, label %bb87, label %bb88
bb87:
  %t367 = load i1, ptr %l25, !tbaa !21
  %t369 = xor i1 %t367, true
  store i1 %t369, ptr %l206, !tbaa !21
  br label %bb89
bb88:
  store i1 false, ptr %l206, !tbaa !21
  br label %bb89
bb89:
  %t371 = load i1, ptr %l206, !tbaa !21
  br i1 %t371, label %bb90, label %bb91
bb90:
  %t372 = load i1, ptr %l3, !tbaa !21
  br i1 %t372, label %bb92, label %bb93
bb91:
  store i1 false, ptr %l209, !tbaa !21
  br label %bb95
bb92:
  %t374 = load i32, ptr %l2, !tbaa !23
  %t375 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t378 = icmp eq i32 %t374, %t375
  store i1 %t378, ptr %l211, !tbaa !21
  br label %bb94
bb93:
  store i1 false, ptr %l211, !tbaa !21
  br label %bb94
bb94:
  %t380 = load i1, ptr %l211, !tbaa !21
  %t381 = xor i1 %t380, true
  store i1 %t381, ptr %l209, !tbaa !21
  br label %bb95
bb95:
  %t383 = load i1, ptr %l209, !tbaa !21
  br i1 %t383, label %bb96, label %bb97
bb96:
  store i64 0, ptr %l26, !tbaa !24
  %t384 = load ptr, ptr %l1, !tbaa !29
  %t386 = getelementptr %"compiler/ast:Catch", ptr %t384, i32 0, i32 3
  %t387 = load { i64, ptr }, ptr %t386, !tbaa !27
  %t389 = extractvalue { i64, ptr } %t387, 0
  store i64 %t389, ptr %l27, !tbaa !24
  store i64 1, ptr %l28, !tbaa !24
  %t391 = load i64, ptr %l27, !tbaa !24
  %t392 = load i64, ptr %l26, !tbaa !24
  %t395 = icmp sgt i64 %t391, %t392
  br i1 %t395, label %bb98, label %bb99
bb97:
  br label %bb142
bb98:
  %t397 = load i64, ptr %l28, !tbaa !24
  %t399 = icmp sgt i64 %t397, 0
  br i1 %t399, label %bb100, label %bb101
bb99:
  store i64 0, ptr %l222, !tbaa !24
  br label %bb103
bb100:
  %t401 = load i64, ptr %l27, !tbaa !24
  %t402 = load i64, ptr %l26, !tbaa !24
  %t405 = sub i64 %t401, %t402
  %t406 = load i64, ptr %l28, !tbaa !24
  %t409 = add i64 %t405, %t406
  %t411 = sub i64 %t409, 1
  %t412 = load i64, ptr %l28, !tbaa !24
  %t415 = sdiv i64 %t411, %t412
  store i64 %t415, ptr %l225, !tbaa !24
  br label %bb102
bb101:
  store i64 0, ptr %l225, !tbaa !24
  br label %bb102
bb102:
  %t417 = load i64, ptr %l225, !tbaa !24
  store i64 %t417, ptr %l222, !tbaa !24
  br label %bb103
bb103:
  %t418 = load i64, ptr %l222, !tbaa !24
  store i64 %t418, ptr %l29, !tbaa !24
  store i64 0, ptr %l30, !tbaa !24
  br label %bb104
bb104:
  store %olang.scope zeroinitializer, ptr %s13
  %t419 = load i64, ptr %l30, !tbaa !24
  %t420 = load i64, ptr %l29, !tbaa !24
  %t423 = icmp slt i64 %t419, %t420
  %t425 = xor i1 %t423, true
  br i1 %t425, label %bb105, label %bb106
bb105:
  call void @__olang_scope_close(ptr %s13)
  br label %bb141
bb106:
  br label %bb107
bb107:
  %t427 = load i64, ptr %l26, !tbaa !24
  %t428 = load i64, ptr %l30, !tbaa !24
  %t429 = load i64, ptr %l28, !tbaa !24
  %t432 = mul i64 %t428, %t429
  %t435 = add i64 %t427, %t432
  store i64 %t435, ptr %l31, !tbaa !24
  %t437 = load i32, ptr %l2, !tbaa !23
  store i32 %t437, ptr %l32, !tbaa !23
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t441 = getelementptr %"compiler/check:Checker", ptr %t439, i32 0, i32 1
  %t442 = load ptr, ptr %t441, !tbaa !29
  %t444 = getelementptr %"compiler/generic:Program", ptr %t442, i32 0, i32 2
  %t445 = load i32, ptr %l2, !tbaa !23
  %t448 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t444, i32 %t445)
  store i32 %t448, ptr %l248
  br label %bb108
bb108:
  %t449 = load i32, ptr %l248
  %t451 = trunc i64 22 to i32
  %t452 = icmp eq i32 %t449, %t451
  br i1 %t452, label %bb109, label %bb110
bb109:
  %t454 = load ptr, ptr %l1, !tbaa !29
  %t456 = getelementptr %"compiler/ast:Catch", ptr %t454, i32 0, i32 3
  %t457 = load { i64, ptr }, ptr %t456, !tbaa !27
  %t459 = extractvalue { i64, ptr } %t457, 0
  %t461 = icmp sgt i64 %t459, 1
  store i1 %t461, ptr %l251, !tbaa !21
  br label %bb111
bb110:
  store i1 false, ptr %l251, !tbaa !21
  br label %bb111
bb111:
  %t463 = load i1, ptr %l251, !tbaa !21
  br i1 %t463, label %bb112, label %bb113
bb112:
  %t464 = load ptr, ptr %l0, !tbaa !29
  %t466 = getelementptr %"compiler/check:Checker", ptr %t464, i32 0, i32 1
  %t467 = load ptr, ptr %t466, !tbaa !29
  %t469 = getelementptr %"compiler/generic:Program", ptr %t467, i32 0, i32 2
  store ptr %t469, ptr %l258, !tbaa !29
  %t470 = load ptr, ptr %l0, !tbaa !29
  %t472 = getelementptr %"compiler/check:Checker", ptr %t470, i32 0, i32 1
  %t473 = load ptr, ptr %t472, !tbaa !29
  %t475 = getelementptr %"compiler/generic:Program", ptr %t473, i32 0, i32 2
  %t476 = load i32, ptr %l2, !tbaa !23
  %t479 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t475, i32 %t476)
  store i32 %t479, ptr %l263
  br label %bb114
bb113:
  br label %bb119
bb114:
  %t480 = load ptr, ptr %l258, !tbaa !29
  %t481 = load i32, ptr %l263, !tbaa !23
  %t482 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t480, i32 %t481)
  store { i64, ptr } %t482, ptr %l264
  br label %bb115
bb115:
  %t483 = load { i64, ptr }, ptr %l264, !tbaa !27
  store { i64, ptr } %t483, ptr %l33, !tbaa !27
  %t484 = load i64, ptr %l31, !tbaa !24
  %t485 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t487 = extractvalue { i64, ptr } %t485, 0
  %t490 = icmp slt i64 %t484, %t487
  br i1 %t490, label %bb116, label %bb117
bb116:
  %t492 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t492, ptr %l269, !tbaa !27
  %t493 = load i64, ptr %l31, !tbaa !24
  %t495 = getelementptr { i64, ptr }, ptr %l269, i32 0, i32 1
  %t496 = load ptr, ptr %t495, !tbaa !27
  %t497 = getelementptr i32, ptr %t496, i64 %t493
  %t498 = load i32, ptr %t497, !tbaa !33
  store i32 %t498, ptr %l32, !tbaa !23
  br label %bb118
bb117:
  br label %bb118
bb118:
  br label %bb119
bb119:
  %t500 = load i1, ptr %l3, !tbaa !21
  br i1 %t500, label %bb120, label %bb121
bb120:
  %t502 = load ptr, ptr %l0, !tbaa !29
  %t503 = load i32, ptr %l32, !tbaa !23
  %t506 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t502, i32 %t503)
  store i1 %t506, ptr %l276
  br label %bb122
bb121:
  store i1 false, ptr %l273, !tbaa !21
  br label %bb123
bb122:
  %t507 = load i1, ptr %l276, !tbaa !21
  %t508 = xor i1 %t507, true
  store i1 %t508, ptr %l273, !tbaa !21
  br label %bb123
bb123:
  %t510 = load i1, ptr %l273, !tbaa !21
  br i1 %t510, label %bb124, label %bb125
bb124:
  %t511 = load ptr, ptr %l0, !tbaa !29
  %t513 = getelementptr %"compiler/check:Checker", ptr %t511, i32 0, i32 1
  %t514 = load ptr, ptr %t513, !tbaa !29
  %t516 = getelementptr %"compiler/generic:Program", ptr %t514, i32 0, i32 2
  %t517 = load i32, ptr %l32, !tbaa !23
  %t520 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t516, i32 %t517)
  store i1 %t520, ptr %l283
  br label %bb126
bb125:
  store i1 false, ptr %l278, !tbaa !21
  br label %bb127
bb126:
  %t521 = load i1, ptr %l283, !tbaa !21
  store i1 %t521, ptr %l278, !tbaa !21
  br label %bb127
bb127:
  %t522 = load i1, ptr %l278, !tbaa !21
  br i1 %t522, label %bb128, label %bb129
bb128:
  %t523 = load ptr, ptr %l1, !tbaa !29
  %t525 = getelementptr %"compiler/ast:Catch", ptr %t523, i32 0, i32 3
  %t526 = load { i64, ptr }, ptr %t525, !tbaa !27
  store { i64, ptr } %t526, ptr %l286, !tbaa !27
  %t527 = load i64, ptr %l31, !tbaa !24
  %t529 = getelementptr { i64, ptr }, ptr %l286, i32 0, i32 1
  %t530 = load ptr, ptr %t529, !tbaa !27
  %t531 = getelementptr ptr, ptr %t530, i64 %t527
  %t532 = load ptr, ptr %t531, !tbaa !39
  %t534 = call i1 @compiler_2fcheck_2ebuiltAst(ptr %v1, ptr %t532)
  store i1 %t534, ptr %l289
  br label %bb130
bb129:
  store i1 false, ptr %l284, !tbaa !21
  br label %bb131
bb130:
  %t535 = load i1, ptr %l289, !tbaa !21
  %t536 = xor i1 %t535, true
  store i1 %t536, ptr %l284, !tbaa !21
  br label %bb131
bb131:
  %t538 = load i1, ptr %l284, !tbaa !21
  br i1 %t538, label %bb132, label %bb133
bb132:
  store %olang.scope zeroinitializer, ptr %s16
  %t539 = load ptr, ptr %l0, !tbaa !29
  store ptr %t539, ptr %l291, !tbaa !29
  %t540 = load ptr, ptr %l1, !tbaa !29
  %t542 = getelementptr %"compiler/ast:Catch", ptr %t540, i32 0, i32 3
  %t543 = load { i64, ptr }, ptr %t542, !tbaa !27
  store { i64, ptr } %t543, ptr %l293, !tbaa !27
  %t544 = load i64, ptr %l31, !tbaa !24
  %t546 = getelementptr { i64, ptr }, ptr %l293, i32 0, i32 1
  %t547 = load ptr, ptr %t546, !tbaa !27
  %t548 = getelementptr ptr, ptr %t547, i64 %t544
  %t549 = load ptr, ptr %t548, !tbaa !39
  %t551 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t549)
  store %"compiler/source:Span" %t551, ptr %l296
  br label %bb134
bb133:
  br label %bb137
bb134:
  %t552 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultHoldsReferences(ptr %s16)
  store %"compiler/msgs:Msg" %t552, ptr %l297
  br label %bb135
bb135:
  %t553 = load ptr, ptr %l291, !tbaa !29
  %t554 = load %"compiler/source:Span", ptr %l296
  %t555 = load %"compiler/msgs:Msg", ptr %l297
  %t556 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s16, ptr %t553, %"compiler/source:Span" %t554, %"compiler/msgs:Msg" %t555)
  store i64 %t556, ptr %l298
  br label %bb136
bb136:
  call void @__olang_scope_close(ptr %s16)
  br label %bb137
bb137:
  %t557 = load ptr, ptr %l0, !tbaa !29
  %t559 = getelementptr %"compiler/check:Checker", ptr %t557, i32 0, i32 32
  store ptr %t559, ptr %l300, !tbaa !29
  %t560 = load ptr, ptr %l0, !tbaa !29
  %t561 = load ptr, ptr %l1, !tbaa !29
  %t563 = getelementptr %"compiler/ast:Catch", ptr %t561, i32 0, i32 3
  %t564 = load { i64, ptr }, ptr %t563, !tbaa !27
  store { i64, ptr } %t564, ptr %l303, !tbaa !27
  %t565 = load i64, ptr %l31, !tbaa !24
  %t567 = getelementptr { i64, ptr }, ptr %l303, i32 0, i32 1
  %t568 = load ptr, ptr %t567, !tbaa !27
  %t569 = getelementptr ptr, ptr %t568, i64 %t565
  %t570 = load ptr, ptr %t569, !tbaa !39
  %t571 = load i32, ptr %l32, !tbaa !23
  %t575 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %t560, ptr %t570, i32 %t571)
  store ptr %t575, ptr %l307
  br label %bb138
bb138:
  %t576 = load ptr, ptr %l300, !tbaa !29
  %t577 = load ptr, ptr %l307, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t576, ptr %t577)
  br label %bb139
bb139:
  call void @__olang_scope_close(ptr %s13)
  br label %bb140
bb140:
  %t578 = load i64, ptr %l30, !tbaa !24
  %t580 = add i64 %t578, 1
  store i64 %t580, ptr %l30, !tbaa !24
  br label %bb104
bb141:
  br label %bb142
bb142:
  %t582 = load ptr, ptr %l0, !tbaa !29
  %t584 = getelementptr %"compiler/check:Checker", ptr %t582, i32 0, i32 32
  %t585 = load i64, ptr %l24, !tbaa !24
  %t588 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t584, i64 %t585)
  store { i64, ptr } %t588, ptr %l313
  br label %bb143
bb143:
  %t589 = load { i64, ptr }, ptr %l313, !tbaa !27
  store { i64, ptr } %t589, ptr %l34, !tbaa !27
  %t590 = load i64, ptr %l14, !tbaa !24
  %t592 = icmp sge i64 %t590, 0
  br i1 %t592, label %bb144, label %bb145
bb144:
  %t594 = load ptr, ptr %l13, !tbaa !29
  %t596 = getelementptr %"compiler/check:frame", ptr %t594, i32 0, i32 53
  %t597 = load i64, ptr %l16, !tbaa !24
  %t600 = call %"compiler/check:errBind" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aerrBind_3e_2eAt_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %t596, i64 %t597)
  store %"compiler/check:errBind" %t600, ptr %l319
  br label %bb146
bb145:
  br label %bb184
bb146:
  %t601 = load %"compiler/check:errBind", ptr %l319
  store %"compiler/check:errBind" %t601, ptr %l35
  %t602 = load ptr, ptr %l13, !tbaa !29
  %t604 = getelementptr %"compiler/check:frame", ptr %t602, i32 0, i32 54
  %t605 = load i64, ptr %l16, !tbaa !24
  %t608 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t604, i64 %t605)
  store i1 %t608, ptr %l323
  br label %bb147
bb147:
  %t609 = load i1, ptr %l323, !tbaa !21
  %t610 = xor i1 %t609, true
  br i1 %t610, label %bb148, label %bb149
bb148:
  store %olang.scope zeroinitializer, ptr %s19
  %t612 = load ptr, ptr %l0, !tbaa !29
  store ptr %t612, ptr %l325, !tbaa !29
  %t613 = getelementptr %"compiler/check:errBind", ptr %l35, i32 0, i32 3
  %t614 = load %"compiler/source:Span", ptr %t613
  store %"compiler/source:Span" %t614, ptr %l326
  %t615 = load i1, ptr %l7, !tbaa !21
  %t617 = xor i1 %t615, true
  br i1 %t617, label %bb150, label %bb151
bb149:
  br label %bb158
bb150:
  %t619 = load ptr, ptr %l0, !tbaa !29
  %t620 = getelementptr %"compiler/check:errBind", ptr %l35, i32 0, i32 0
  %t621 = load i32, ptr %t620, !tbaa !23
  %t624 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s19, ptr %t619, i32 %t621)
  store { i64, ptr } %t624, ptr %l332
  br label %bb152
bb151:
  %t625 = load ptr, ptr %l0, !tbaa !29
  %t626 = getelementptr %"compiler/check:errBind", ptr %l35, i32 0, i32 0
  %t627 = load i32, ptr %t626, !tbaa !23
  %t630 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s19, ptr %t625, i32 %t627)
  store { i64, ptr } %t630, ptr %l337
  br label %bb154
bb152:
  %t631 = load { i64, ptr }, ptr %l332, !tbaa !27
  %t632 = extractvalue { i64, ptr } %t631, 0
  %t633 = extractvalue { i64, ptr } %t631, 1
  %t634 = mul i64 %t632, 1
  %t635 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t634)
  call void @llvm.memcpy.p0.p0.i64(ptr %t635, ptr %t633, i64 %t634, i1 false)
  %t636 = insertvalue { i64, ptr } undef, i64 %t632, 0
  %t637 = insertvalue { i64, ptr } %t636, ptr %t635, 1
  %t639 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchNameUnused(ptr %s19, ptr %s19, { i64, ptr } %t637)
  store %"compiler/msgs:Msg" %t639, ptr %l334
  br label %bb153
bb153:
  %t640 = load %"compiler/msgs:Msg", ptr %l334
  store %"compiler/msgs:Msg" %t640, ptr %l329
  br label %bb156
bb154:
  %t641 = load { i64, ptr }, ptr %l337, !tbaa !27
  %t642 = extractvalue { i64, ptr } %t641, 0
  %t643 = extractvalue { i64, ptr } %t641, 1
  %t644 = mul i64 %t642, 1
  %t645 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t644)
  call void @llvm.memcpy.p0.p0.i64(ptr %t645, ptr %t643, i64 %t644, i1 false)
  %t646 = insertvalue { i64, ptr } undef, i64 %t642, 0
  %t647 = insertvalue { i64, ptr } %t646, ptr %t645, 1
  %t649 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchLoneUnused(ptr %s19, ptr %s19, { i64, ptr } %t647)
  store %"compiler/msgs:Msg" %t649, ptr %l339
  br label %bb155
bb155:
  %t650 = load %"compiler/msgs:Msg", ptr %l339
  store %"compiler/msgs:Msg" %t650, ptr %l329
  br label %bb156
bb156:
  %t651 = load ptr, ptr %l325, !tbaa !29
  %t652 = load %"compiler/source:Span", ptr %l326
  %t653 = load %"compiler/msgs:Msg", ptr %l329
  %t654 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s19, ptr %t651, %"compiler/source:Span" %t652, %"compiler/msgs:Msg" %t653)
  store i64 %t654, ptr %l340
  br label %bb157
bb157:
  call void @__olang_scope_close(ptr %s19)
  br label %bb158
bb158:
  %t655 = load ptr, ptr %l13, !tbaa !29
  %t657 = getelementptr %"compiler/check:frame", ptr %t655, i32 0, i32 53
  %t658 = load i64, ptr %l16, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aerrBind_3e_2eTru_Had6203bde6d60a533558c9108ce2d205(ptr %v0, ptr %t657, i64 %t658)
  br label %bb159
bb159:
  %t661 = load ptr, ptr %l13, !tbaa !29
  %t663 = getelementptr %"compiler/check:frame", ptr %t661, i32 0, i32 54
  %t664 = load i64, ptr %l16, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eTruncate_3cBool_3e(ptr %v0, ptr %t663, i64 %t664)
  br label %bb160
bb160:
  br label %bb161
bb161:
  store %olang.scope zeroinitializer, ptr %s20
  %t667 = load ptr, ptr %l13, !tbaa !29
  %t669 = getelementptr %"compiler/check:frame", ptr %t667, i32 0, i32 55
  %t671 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aerrNarrow_3e_2eL_H2a7e7537a6dfd104eb96f9cf86ba43ee(ptr %v0, ptr %t669)
  store i64 %t671, ptr %l349
  br label %bb162
bb162:
  %t672 = load i64, ptr %l349, !tbaa !24
  %t673 = icmp sgt i64 %t672, 0
  br i1 %t673, label %bb163, label %bb164
bb163:
  %t675 = load ptr, ptr %l13, !tbaa !29
  %t677 = getelementptr %"compiler/check:frame", ptr %t675, i32 0, i32 55
  %t679 = call { i32, %"compiler/check:errNarrow" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aerrNarrow_3e_2eL_He0605a0bd9b7ed654a280965e7915dc5(ptr %v0, ptr %t677)
  %t680 = extractvalue { i32, %"compiler/check:errNarrow" } %t679, 1
  %t681 = extractvalue { i32, %"compiler/check:errNarrow" } %t679, 0
  store i32 %t681, ptr %l356
  %t682 = icmp ne i32 %t681, 0
  br i1 %t682, label %bb166, label %ok.683
ok.683:
  store %"compiler/check:errNarrow" %t680, ptr %l355
  br label %bb165
bb164:
  store i1 false, ptr %l351, !tbaa !21
  br label %bb169
bb165:
  %t684 = load %"compiler/check:errNarrow", ptr %l355
  store %"compiler/check:errNarrow" %t684, ptr %l352
  br label %bb168
bb166:
  br label %bb167
bb167:
  call void @__olang_ert_req_clear()
  call void @__olang_check_failed(ptr @olang_loc_b0c35ab29f6de325_6b273ecedc848f99)
  unreachable
bb168:
  %t685 = getelementptr %"compiler/check:errNarrow", ptr %l352, i32 0, i32 0
  %t686 = load i64, ptr %t685, !tbaa !24
  %t687 = load i64, ptr %l16, !tbaa !24
  %t690 = icmp sge i64 %t686, %t687
  store i1 %t690, ptr %l351, !tbaa !21
  br label %bb169
bb169:
  %t692 = load i1, ptr %l351, !tbaa !21
  %t693 = xor i1 %t692, true
  br i1 %t693, label %bb170, label %bb171
bb170:
  call void @__olang_scope_close(ptr %s20)
  br label %bb183
bb171:
  br label %bb172
bb172:
  %t695 = load ptr, ptr %l13, !tbaa !29
  %t697 = getelementptr %"compiler/check:frame", ptr %t695, i32 0, i32 55
  %t699 = call { i32, %"compiler/check:errNarrow" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aerrNarrow_3e_2eP_H4f6a37f2985e5df818fc3525c212ba25(ptr %v0, ptr %t697)
  %t700 = extractvalue { i32, %"compiler/check:errNarrow" } %t699, 1
  %t701 = extractvalue { i32, %"compiler/check:errNarrow" } %t699, 0
  store i32 %t701, ptr %l365
  %t702 = icmp ne i32 %t701, 0
  br i1 %t702, label %bb174, label %ok.703
ok.703:
  store %"compiler/check:errNarrow" %t700, ptr %l364
  br label %bb173
bb173:
  %t704 = load %"compiler/check:errNarrow", ptr %l364
  store %"compiler/check:errNarrow" %t704, ptr %l361
  br label %bb181
bb174:
  %t705 = load i32, ptr %l365, !tbaa !23
  %t706 = icmp eq i32 %t705, 65536
  br i1 %t706, label %bb175, label %bb176
bb175:
  call void @__olang_bang_failed_plain(ptr @olang_loc_642fba5880633f11_d324198387501485)
  unreachable
bb176:
  %t708 = load i32, ptr %l365, !tbaa !23
  %t709 = icmp eq i32 %t708, 65537
  br i1 %t709, label %bb177, label %bb178
bb177:
  call void @__olang_bang_failed_plain(ptr @olang_loc_dc03de3e13d5d679_188e110e6bdd984d)
  unreachable
bb178:
  %t711 = load i32, ptr %l365, !tbaa !23
  %t712 = icmp eq i32 %t711, 65538
  br i1 %t712, label %bb179, label %bb180
bb179:
  call void @__olang_bang_failed_plain(ptr @olang_loc_8c881979be26de92_88008638e9ed454e)
  unreachable
bb180:
  call void @__olang_bang_failed_plain(ptr @olang_loc_17c20fef2a95d0aa_ecd0b220b620764e)
  unreachable
bb181:
  call void @__olang_scope_close(ptr %s20)
  br label %bb182
bb182:
  br label %bb161
bb183:
  br label %bb184
bb184:
  %t714 = load ptr, ptr %l1, !tbaa !29
  %t716 = getelementptr %"compiler/ast:Catch", ptr %t714, i32 0, i32 0
  %t717 = load %"compiler/source:Span", ptr %t716
  store %"compiler/source:Span" %t717, ptr %l370
  %t719 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aItem_3e_2eToArray_3ccompiler_2ftyped_3aItem_3e(ptr %s0, ptr %v0, ptr %l6)
  store { i64, ptr } %t719, ptr %l372
  br label %bb185
bb185:
  %t720 = load i1, ptr %l12, !tbaa !21
  %t721 = load ptr, ptr %l19, !tbaa !29
  %t722 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t723 = load i64, ptr %l14, !tbaa !24
  %t724 = load i32, ptr %l15, !tbaa !23
  %t725 = load %"compiler/source:Span", ptr %l370
  %t726 = load { i64, ptr }, ptr %l372, !tbaa !27
  %t732 = call %"compiler/typed:Clause" @compiler_2ftyped_3aClause_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t725, { i64, ptr } %t726, i1 %t720, ptr %t721, { i64, ptr } %t722, i64 %t723, i32 %t724)
  store %"compiler/typed:Clause" %t732, ptr %l378
  br label %bb186
bb186:
  %t733 = load %"compiler/typed:Clause", ptr %l378
  %t734 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store %"compiler/typed:Clause" %t733, ptr %t734
  call void @__olang_scope_close(ptr %s0)
  store ptr %t734, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca i32
  %l19 = alloca ptr
  %l20 = alloca %"compiler/source:Span"
  %l21 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca %"compiler/source:Span"
  %l24 = alloca i32
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l27 = alloca ptr
  %l28 = alloca %"compiler/source:Span"
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i32
  %l32 = alloca { i64, ptr }
  %l33 = alloca %"compiler/source:Span"
  %l34 = alloca i32
  %l35 = alloca ptr
  %l36 = alloca %"compiler/source:Span"
  %l37 = alloca i32
  %l38 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca %"compiler/source:Span"
  %l41 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca %"compiler/source:Span"
  %l44 = alloca i32
  %l45 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca ptr
  %l48 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca i1
  %l80 = alloca ptr
  %l81 = alloca i1
  %l92 = alloca %"compiler/source:Span"
  %l93 = alloca i32
  %l97 = alloca ptr
  %l101 = alloca i32
  %l104 = alloca ptr
  %l105 = alloca i1
  %l114 = alloca %"compiler/source:Span"
  %l115 = alloca i32
  %l119 = alloca ptr
  %l122 = alloca ptr
  %l123 = alloca i1
  %l132 = alloca %"compiler/source:Span"
  %l133 = alloca i32
  %l138 = alloca ptr
  %l143 = alloca i32
  %l144 = alloca %"compiler/typed:Promote"
  %l148 = alloca ptr
  %l149 = alloca i1
  %l158 = alloca %"compiler/source:Span"
  %l159 = alloca i32
  %l161 = alloca ptr
  %l166 = alloca { i64, ptr }
  %l168 = alloca { i64, [2 x i64] }
  %l173 = alloca i32
  %l176 = alloca %"compiler/typed:Call"
  %l180 = alloca ptr
  %l181 = alloca i1
  %l194 = alloca { i64, ptr }
  %l199 = alloca ptr
  %l206 = alloca ptr
  %l208 = alloca %"compiler/source:Span"
  %l209 = alloca i32
  %l211 = alloca i32
  %l213 = alloca i64
  %l214 = alloca { i64, ptr }
  %l215 = alloca ptr
  %l220 = alloca i32
  %l223 = alloca %"compiler/typed:Make"
  %l227 = alloca ptr
  %l228 = alloca i1
  %l241 = alloca %"compiler/source:Span"
  %l242 = alloca i32
  %l243 = alloca i32
  %l244 = alloca i32
  %l248 = alloca { i64, ptr }
  %l251 = alloca ptr
  %l252 = alloca i1
  %l261 = alloca %"compiler/source:Span"
  %l262 = alloca i32
  %l267 = alloca ptr
  %l272 = alloca ptr
  %l277 = alloca ptr
  %l280 = alloca %"compiler/typed:Slice"
  %l284 = alloca ptr
  %l285 = alloca i1
  %l298 = alloca ptr
  %l305 = alloca ptr
  %l307 = alloca %"compiler/source:Span"
  %l308 = alloca i32
  %l313 = alloca ptr
  %l314 = alloca ptr
  %l319 = alloca ptr
  %l320 = alloca %"compiler/typed:Cond"
  %l324 = alloca ptr
  %l325 = alloca i1
  %l334 = alloca %"compiler/source:Span"
  %l335 = alloca i64
  %l339 = alloca ptr
  %l342 = alloca ptr
  %l343 = alloca i1
  %l352 = alloca ptr
  %l353 = alloca i1
  %l365 = alloca ptr
  %l367 = alloca %"compiler/source:Span"
  %l368 = alloca ptr
  %rv = alloca ptr
  %t31 = alloca { i64, [5 x i64] }, align 8
  %t81 = alloca { i64, [5 x i64] }, align 8
  %t145 = alloca { i64, [5 x i64] }, align 8
  %t196 = alloca { i64, [5 x i64] }, align 8
  %t263 = alloca { i64, [5 x i64] }, align 8
  %t345 = alloca { i64, [5 x i64] }, align 8
  %t459 = alloca { i64, [5 x i64] }, align 8
  %t522 = alloca { i64, [5 x i64] }, align 8
  %t609 = alloca { i64, [5 x i64] }, align 8
  %t706 = alloca { i64, [5 x i64] }, align 8
  %t755 = alloca { i64, [5 x i64] }, align 8
  %t813 = alloca { i64, [4 x i64] }, align 8
  %t821 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t2 = load ptr, ptr %l47, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l47, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l48, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l48, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l3
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l4, !tbaa !23
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t24, i32 0, i32 2
  %t26 = load i64, ptr %t25
  store i64 %t26, ptr %l5, !tbaa !24
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t28 = load %"compiler/source:Span", ptr %l3
  %t29 = load i32, ptr %l4, !tbaa !23
  %t30 = load i64, ptr %l5, !tbaa !24
  store { i64, [5 x i64] } zeroinitializer, ptr %t31
  %t32 = getelementptr { i64, [5 x i64] }, ptr %t31, i32 0, i32 0
  store i64 0, ptr %t32
  %t34 = insertvalue { %"compiler/source:Span", i32, i64 } undef, %"compiler/source:Span" %t28, 0
  %t36 = insertvalue { %"compiler/source:Span", i32, i64 } %t34, i32 %t29, 1
  %t38 = insertvalue { %"compiler/source:Span", i32, i64 } %t36, i64 %t30, 2
  %t39 = getelementptr { i64, [5 x i64] }, ptr %t31, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64 } %t38, ptr %t39
  %t40 = load { i64, [5 x i64] }, ptr %t31
  %t42 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t40, ptr %t42
  store ptr %t42, ptr %rv
  br label %ret
bb6:
  %t44 = load ptr, ptr %l1, !tbaa !29
  store ptr %t44, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t45 = load ptr, ptr %l62, !tbaa !29
  %t46 = icmp ne ptr %t45, null
  br i1 %t46, label %bb7, label %bb8
bb7:
  %t48 = load ptr, ptr %l62, !tbaa !29
  %t49 = load i64, ptr %t48
  %t51 = icmp eq i64 %t49, 1
  store i1 %t51, ptr %l63, !tbaa !21
  br label %bb8
bb8:
  %t52 = load i1, ptr %l63, !tbaa !21
  br i1 %t52, label %bb9, label %bb10
bb9:
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr { i64, [5 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t55, i32 0, i32 0
  %t57 = load %"compiler/source:Span", ptr %t56
  store %"compiler/source:Span" %t57, ptr %l6
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr { i64, [5 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t61, i32 0, i32 1
  %t63 = load i32, ptr %t62
  store i32 %t63, ptr %l7, !tbaa !23
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr { i64, [5 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t67, i32 0, i32 2
  %t69 = load i64, ptr %t68
  store i64 %t69, ptr %l8, !tbaa !24
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr { i64, [5 x i64] }, ptr %t71, i32 0, i32 1
  %t74 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t73, i32 0, i32 3
  %t75 = load ptr, ptr %t74
  store ptr %t75, ptr %l9, !tbaa !29
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t77 = load %"compiler/source:Span", ptr %l6
  %t78 = load i32, ptr %l7, !tbaa !23
  %t79 = load i64, ptr %l8, !tbaa !24
  %t80 = load ptr, ptr %l9, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t81
  %t82 = getelementptr { i64, [5 x i64] }, ptr %t81, i32 0, i32 0
  store i64 1, ptr %t82
  %t84 = insertvalue { %"compiler/source:Span", i32, i64, ptr } undef, %"compiler/source:Span" %t77, 0
  %t86 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t84, i32 %t78, 1
  %t88 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t86, i64 %t79, 2
  %t90 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t88, ptr %t80, 3
  %t91 = getelementptr { i64, [5 x i64] }, ptr %t81, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, ptr } %t90, ptr %t91
  %t92 = load { i64, [5 x i64] }, ptr %t81
  %t94 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t92, ptr %t94
  store ptr %t94, ptr %rv
  br label %ret
bb12:
  %t96 = load ptr, ptr %l1, !tbaa !29
  store ptr %t96, ptr %l80, !tbaa !29
  store i1 false, ptr %l81, !tbaa !21
  %t97 = load ptr, ptr %l80, !tbaa !29
  %t98 = icmp ne ptr %t97, null
  br i1 %t98, label %bb13, label %bb14
bb13:
  %t100 = load ptr, ptr %l80, !tbaa !29
  %t101 = load i64, ptr %t100
  %t103 = icmp eq i64 %t101, 2
  store i1 %t103, ptr %l81, !tbaa !21
  br label %bb14
bb14:
  %t104 = load i1, ptr %l81, !tbaa !21
  br i1 %t104, label %bb15, label %bb16
bb15:
  %t105 = load ptr, ptr %l1, !tbaa !29
  %t107 = getelementptr { i64, [5 x i64] }, ptr %t105, i32 0, i32 1
  %t108 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t107, i32 0, i32 0
  %t109 = load %"compiler/source:Span", ptr %t108
  store %"compiler/source:Span" %t109, ptr %l10
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = getelementptr { i64, [5 x i64] }, ptr %t111, i32 0, i32 1
  %t114 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t113, i32 0, i32 1
  %t115 = load i32, ptr %t114
  store i32 %t115, ptr %l11, !tbaa !23
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr { i64, [5 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t119, i32 0, i32 2
  %t121 = load ptr, ptr %t120
  store ptr %t121, ptr %l12, !tbaa !29
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr { i64, [5 x i64] }, ptr %t123, i32 0, i32 1
  %t126 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t125, i32 0, i32 3
  %t127 = load i32, ptr %t126
  store i32 %t127, ptr %l13, !tbaa !23
  br label %bb17
bb16:
  br label %bb20
bb17:
  %t129 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t129, ptr %l92
  %t130 = load i32, ptr %l11, !tbaa !23
  store i32 %t130, ptr %l93, !tbaa !23
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load ptr, ptr %l12, !tbaa !29
  %t133 = load i64, ptr %l2, !tbaa !24
  %t137 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyPlace(ptr %v0, ptr %v1, ptr %t131, ptr %t132, i64 %t133)
  store ptr %t137, ptr %l97
  br label %bb18
bb18:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load i32, ptr %l13, !tbaa !23
  %t140 = load i64, ptr %l2, !tbaa !24
  %t144 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereSite(ptr %v0, ptr %t138, i32 %t139, i64 %t140)
  store i32 %t144, ptr %l101
  br label %bb19
bb19:
  store { i64, [5 x i64] } zeroinitializer, ptr %t145
  %t146 = getelementptr { i64, [5 x i64] }, ptr %t145, i32 0, i32 0
  store i64 2, ptr %t146
  %t147 = load %"compiler/source:Span", ptr %l92
  %t148 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t147, 0
  %t149 = load i32, ptr %l93, !tbaa !23
  %t150 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t148, i32 %t149, 1
  %t151 = load ptr, ptr %l97, !tbaa !29
  %t152 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t150, ptr %t151, 2
  %t153 = load i32, ptr %l101, !tbaa !23
  %t154 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t152, i32 %t153, 3
  %t155 = getelementptr { i64, [5 x i64] }, ptr %t145, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t154, ptr %t155
  %t156 = load { i64, [5 x i64] }, ptr %t145
  %t158 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t156, ptr %t158
  store ptr %t158, ptr %rv
  br label %ret
bb20:
  %t160 = load ptr, ptr %l1, !tbaa !29
  store ptr %t160, ptr %l104, !tbaa !29
  store i1 false, ptr %l105, !tbaa !21
  %t161 = load ptr, ptr %l104, !tbaa !29
  %t162 = icmp ne ptr %t161, null
  br i1 %t162, label %bb21, label %bb22
bb21:
  %t164 = load ptr, ptr %l104, !tbaa !29
  %t165 = load i64, ptr %t164
  %t167 = icmp eq i64 %t165, 3
  store i1 %t167, ptr %l105, !tbaa !21
  br label %bb22
bb22:
  %t168 = load i1, ptr %l105, !tbaa !21
  br i1 %t168, label %bb23, label %bb24
bb23:
  %t169 = load ptr, ptr %l1, !tbaa !29
  %t171 = getelementptr { i64, [5 x i64] }, ptr %t169, i32 0, i32 1
  %t172 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t171, i32 0, i32 0
  %t173 = load %"compiler/source:Span", ptr %t172
  store %"compiler/source:Span" %t173, ptr %l14
  %t175 = load ptr, ptr %l1, !tbaa !29
  %t177 = getelementptr { i64, [5 x i64] }, ptr %t175, i32 0, i32 1
  %t178 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t177, i32 0, i32 1
  %t179 = load i32, ptr %t178
  store i32 %t179, ptr %l15, !tbaa !23
  %t181 = load ptr, ptr %l1, !tbaa !29
  %t183 = getelementptr { i64, [5 x i64] }, ptr %t181, i32 0, i32 1
  %t184 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t183, i32 0, i32 2
  %t185 = load ptr, ptr %t184
  store ptr %t185, ptr %l16, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t187 = load %"compiler/source:Span", ptr %l14
  store %"compiler/source:Span" %t187, ptr %l114
  %t188 = load i32, ptr %l15, !tbaa !23
  store i32 %t188, ptr %l115, !tbaa !23
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load ptr, ptr %l16, !tbaa !29
  %t191 = load i64, ptr %l2, !tbaa !24
  %t195 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyPlace(ptr %v0, ptr %v1, ptr %t189, ptr %t190, i64 %t191)
  store ptr %t195, ptr %l119
  br label %bb26
bb26:
  store { i64, [5 x i64] } zeroinitializer, ptr %t196
  %t197 = getelementptr { i64, [5 x i64] }, ptr %t196, i32 0, i32 0
  store i64 3, ptr %t197
  %t198 = load %"compiler/source:Span", ptr %l114
  %t199 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t198, 0
  %t200 = load i32, ptr %l115, !tbaa !23
  %t201 = insertvalue { %"compiler/source:Span", i32, ptr } %t199, i32 %t200, 1
  %t202 = load ptr, ptr %l119, !tbaa !29
  %t203 = insertvalue { %"compiler/source:Span", i32, ptr } %t201, ptr %t202, 2
  %t204 = getelementptr { i64, [5 x i64] }, ptr %t196, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t203, ptr %t204
  %t205 = load { i64, [5 x i64] }, ptr %t196
  %t207 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t205, ptr %t207
  store ptr %t207, ptr %rv
  br label %ret
bb27:
  %t209 = load ptr, ptr %l1, !tbaa !29
  store ptr %t209, ptr %l122, !tbaa !29
  store i1 false, ptr %l123, !tbaa !21
  %t210 = load ptr, ptr %l122, !tbaa !29
  %t211 = icmp ne ptr %t210, null
  br i1 %t211, label %bb28, label %bb29
bb28:
  %t213 = load ptr, ptr %l122, !tbaa !29
  %t214 = load i64, ptr %t213
  %t216 = icmp eq i64 %t214, 5
  store i1 %t216, ptr %l123, !tbaa !21
  br label %bb29
bb29:
  %t217 = load i1, ptr %l123, !tbaa !21
  br i1 %t217, label %bb30, label %bb31
bb30:
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = getelementptr { i64, [5 x i64] }, ptr %t218, i32 0, i32 1
  %t221 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t220, i32 0, i32 0
  %t222 = load %"compiler/source:Span", ptr %t221
  store %"compiler/source:Span" %t222, ptr %l17
  %t224 = load ptr, ptr %l1, !tbaa !29
  %t226 = getelementptr { i64, [5 x i64] }, ptr %t224, i32 0, i32 1
  %t227 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t226, i32 0, i32 1
  %t228 = load i32, ptr %t227
  store i32 %t228, ptr %l18, !tbaa !23
  %t230 = load ptr, ptr %l1, !tbaa !29
  %t232 = getelementptr { i64, [5 x i64] }, ptr %t230, i32 0, i32 1
  %t233 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t232, i32 0, i32 2
  %t234 = load ptr, ptr %t233
  store ptr %t234, ptr %l19, !tbaa !29
  br label %bb32
bb31:
  br label %bb36
bb32:
  %t236 = load %"compiler/source:Span", ptr %l17
  store %"compiler/source:Span" %t236, ptr %l132
  %t237 = load i32, ptr %l18, !tbaa !23
  store i32 %t237, ptr %l133, !tbaa !23
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load ptr, ptr %l19, !tbaa !29
  %t241 = getelementptr %"compiler/typed:Promote", ptr %t239, i32 0, i32 0
  %t242 = load ptr, ptr %t241, !tbaa !29
  %t243 = load i64, ptr %l2, !tbaa !24
  %t247 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %t238, ptr %t242, i64 %t243)
  store ptr %t247, ptr %l138
  br label %bb33
bb33:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load ptr, ptr %l19, !tbaa !29
  %t251 = getelementptr %"compiler/typed:Promote", ptr %t249, i32 0, i32 1
  %t252 = load i32, ptr %t251, !tbaa !23
  %t253 = load i64, ptr %l2, !tbaa !24
  %t257 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereSite(ptr %v0, ptr %t248, i32 %t252, i64 %t253)
  store i32 %t257, ptr %l143
  br label %bb34
bb34:
  %t258 = load ptr, ptr %l138, !tbaa !29
  %t259 = load i32, ptr %l143, !tbaa !23
  %t260 = call %"compiler/typed:Promote" @compiler_2ftyped_3aPromote_2ector(ptr %v0, ptr %v0, ptr %t258, i32 %t259)
  store %"compiler/typed:Promote" %t260, ptr %l144
  br label %bb35
bb35:
  %t261 = load %"compiler/typed:Promote", ptr %l144
  %t262 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store %"compiler/typed:Promote" %t261, ptr %t262
  store { i64, [5 x i64] } zeroinitializer, ptr %t263
  %t264 = getelementptr { i64, [5 x i64] }, ptr %t263, i32 0, i32 0
  store i64 5, ptr %t264
  %t265 = load %"compiler/source:Span", ptr %l132
  %t266 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t265, 0
  %t267 = load i32, ptr %l133, !tbaa !23
  %t268 = insertvalue { %"compiler/source:Span", i32, ptr } %t266, i32 %t267, 1
  %t270 = insertvalue { %"compiler/source:Span", i32, ptr } %t268, ptr %t262, 2
  %t271 = getelementptr { i64, [5 x i64] }, ptr %t263, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t270, ptr %t271
  %t272 = load { i64, [5 x i64] }, ptr %t263
  %t274 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t272, ptr %t274
  store ptr %t274, ptr %rv
  br label %ret
bb36:
  %t276 = load ptr, ptr %l1, !tbaa !29
  store ptr %t276, ptr %l148, !tbaa !29
  store i1 false, ptr %l149, !tbaa !21
  %t277 = load ptr, ptr %l148, !tbaa !29
  %t278 = icmp ne ptr %t277, null
  br i1 %t278, label %bb37, label %bb38
bb37:
  %t280 = load ptr, ptr %l148, !tbaa !29
  %t281 = load i64, ptr %t280
  %t283 = icmp eq i64 %t281, 6
  store i1 %t283, ptr %l149, !tbaa !21
  br label %bb38
bb38:
  %t284 = load i1, ptr %l149, !tbaa !21
  br i1 %t284, label %bb39, label %bb40
bb39:
  %t285 = load ptr, ptr %l1, !tbaa !29
  %t287 = getelementptr { i64, [5 x i64] }, ptr %t285, i32 0, i32 1
  %t288 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t287, i32 0, i32 0
  %t289 = load %"compiler/source:Span", ptr %t288
  store %"compiler/source:Span" %t289, ptr %l20
  %t291 = load ptr, ptr %l1, !tbaa !29
  %t293 = getelementptr { i64, [5 x i64] }, ptr %t291, i32 0, i32 1
  %t294 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t293, i32 0, i32 1
  %t295 = load i32, ptr %t294
  store i32 %t295, ptr %l21, !tbaa !23
  %t297 = load ptr, ptr %l1, !tbaa !29
  %t299 = getelementptr { i64, [5 x i64] }, ptr %t297, i32 0, i32 1
  %t300 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t299, i32 0, i32 2
  %t301 = load ptr, ptr %t300
  store ptr %t301, ptr %l22, !tbaa !29
  br label %bb41
bb40:
  br label %bb45
bb41:
  %t303 = load %"compiler/source:Span", ptr %l20
  store %"compiler/source:Span" %t303, ptr %l158
  %t304 = load i32, ptr %l21, !tbaa !23
  store i32 %t304, ptr %l159, !tbaa !23
  %t305 = load ptr, ptr %l22, !tbaa !29
  %t307 = getelementptr %"compiler/typed:Call", ptr %t305, i32 0, i32 0
  %t308 = load ptr, ptr %t307, !tbaa !29
  store ptr %t308, ptr %l161, !tbaa !29
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t310 = load ptr, ptr %l22, !tbaa !29
  %t312 = getelementptr %"compiler/typed:Call", ptr %t310, i32 0, i32 1
  %t313 = load { i64, ptr }, ptr %t312, !tbaa !27
  %t314 = load i64, ptr %l2, !tbaa !24
  %t318 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyAll(ptr %v0, ptr %v1, ptr %t309, { i64, ptr } %t313, i64 %t314)
  store { i64, ptr } %t318, ptr %l166
  br label %bb42
bb42:
  %t319 = load ptr, ptr %l22, !tbaa !29
  %t321 = getelementptr %"compiler/typed:Call", ptr %t319, i32 0, i32 2
  %t322 = load { i64, [2 x i64] }, ptr %t321
  store { i64, [2 x i64] } %t322, ptr %l168
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = load ptr, ptr %l22, !tbaa !29
  %t326 = getelementptr %"compiler/typed:Call", ptr %t324, i32 0, i32 3
  %t327 = load i32, ptr %t326, !tbaa !23
  %t328 = load i64, ptr %l2, !tbaa !24
  %t332 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereSite(ptr %v0, ptr %t323, i32 %t327, i64 %t328)
  store i32 %t332, ptr %l173
  br label %bb43
bb43:
  %t333 = load ptr, ptr %l22, !tbaa !29
  %t335 = getelementptr %"compiler/typed:Call", ptr %t333, i32 0, i32 4
  %t336 = load i1, ptr %t335, !tbaa !21
  %t337 = load ptr, ptr %l161, !tbaa !29
  %t338 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t339 = load { i64, [2 x i64] }, ptr %l168
  %t340 = load i32, ptr %l173, !tbaa !23
  %t342 = call %"compiler/typed:Call" @compiler_2ftyped_3aCall_2ector(ptr %v1, ptr %v0, ptr %v0, ptr %t337, { i64, ptr } %t338, { i64, [2 x i64] } %t339, i32 %t340, i1 %t336)
  store %"compiler/typed:Call" %t342, ptr %l176
  br label %bb44
bb44:
  %t343 = load %"compiler/typed:Call", ptr %l176
  %t344 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/typed:Call" %t343, ptr %t344
  store { i64, [5 x i64] } zeroinitializer, ptr %t345
  %t346 = getelementptr { i64, [5 x i64] }, ptr %t345, i32 0, i32 0
  store i64 6, ptr %t346
  %t347 = load %"compiler/source:Span", ptr %l158
  %t348 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t347, 0
  %t349 = load i32, ptr %l159, !tbaa !23
  %t350 = insertvalue { %"compiler/source:Span", i32, ptr } %t348, i32 %t349, 1
  %t352 = insertvalue { %"compiler/source:Span", i32, ptr } %t350, ptr %t344, 2
  %t353 = getelementptr { i64, [5 x i64] }, ptr %t345, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t352, ptr %t353
  %t354 = load { i64, [5 x i64] }, ptr %t345
  %t356 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t354, ptr %t356
  store ptr %t356, ptr %rv
  br label %ret
bb45:
  %t358 = load ptr, ptr %l1, !tbaa !29
  store ptr %t358, ptr %l180, !tbaa !29
  store i1 false, ptr %l181, !tbaa !21
  %t359 = load ptr, ptr %l180, !tbaa !29
  %t360 = icmp ne ptr %t359, null
  br i1 %t360, label %bb46, label %bb47
bb46:
  %t362 = load ptr, ptr %l180, !tbaa !29
  %t363 = load i64, ptr %t362
  %t365 = icmp eq i64 %t363, 7
  store i1 %t365, ptr %l181, !tbaa !21
  br label %bb47
bb47:
  %t366 = load i1, ptr %l181, !tbaa !21
  br i1 %t366, label %bb48, label %bb49
bb48:
  %t367 = load ptr, ptr %l1, !tbaa !29
  %t369 = getelementptr { i64, [5 x i64] }, ptr %t367, i32 0, i32 1
  %t370 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t369, i32 0, i32 0
  %t371 = load %"compiler/source:Span", ptr %t370
  store %"compiler/source:Span" %t371, ptr %l23
  %t373 = load ptr, ptr %l1, !tbaa !29
  %t375 = getelementptr { i64, [5 x i64] }, ptr %t373, i32 0, i32 1
  %t376 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t375, i32 0, i32 1
  %t377 = load i32, ptr %t376
  store i32 %t377, ptr %l24, !tbaa !23
  %t379 = load ptr, ptr %l1, !tbaa !29
  %t381 = getelementptr { i64, [5 x i64] }, ptr %t379, i32 0, i32 1
  %t382 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t381, i32 0, i32 2
  %t383 = load ptr, ptr %t382
  store ptr %t383, ptr %l25, !tbaa !29
  br label %bb50
bb49:
  br label %bb61
bb50:
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t386 = load ptr, ptr %l25, !tbaa !29
  %t388 = getelementptr %"compiler/typed:Make", ptr %t386, i32 0, i32 2
  %t389 = load { i64, ptr }, ptr %t388, !tbaa !27
  %t390 = load i64, ptr %l2, !tbaa !24
  %t394 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyAll(ptr %v0, ptr %v1, ptr %t385, { i64, ptr } %t389, i64 %t390)
  store { i64, ptr } %t394, ptr %l194
  br label %bb51
bb51:
  %t395 = load { i64, ptr }, ptr %l194, !tbaa !27
  store { i64, ptr } %t395, ptr %l26, !tbaa !27
  store ptr null, ptr %l27, !tbaa !29
  %t396 = load ptr, ptr %l25, !tbaa !29
  %t398 = getelementptr %"compiler/typed:Make", ptr %t396, i32 0, i32 3
  %t399 = load ptr, ptr %t398, !tbaa !29
  %t401 = icmp eq ptr %t399, null
  %t403 = xor i1 %t401, true
  br i1 %t403, label %bb52, label %bb53
bb52:
  %t405 = load ptr, ptr %l0, !tbaa !29
  store ptr %t405, ptr %l199, !tbaa !29
  %t406 = load ptr, ptr %l25, !tbaa !29
  %t408 = getelementptr %"compiler/typed:Make", ptr %t406, i32 0, i32 3
  %t409 = load ptr, ptr %t408, !tbaa !29
  %t411 = icmp eq ptr %t409, null
  br i1 %t411, label %bb54, label %bb55
bb53:
  br label %bb58
bb54:
  call void @__olang_check_failed(ptr @olang_loc_4aef7e9433005aa6_9cd0eb13e1392442)
  unreachable
bb55:
  br label %bb56
bb56:
  %t413 = load ptr, ptr %l25, !tbaa !29
  %t415 = getelementptr %"compiler/typed:Make", ptr %t413, i32 0, i32 3
  %t416 = load ptr, ptr %t415, !tbaa !29
  %t417 = load i64, ptr %l2, !tbaa !24
  %t418 = load ptr, ptr %l199, !tbaa !29
  %t421 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %t418, ptr %t416, i64 %t417)
  store ptr %t421, ptr %l206
  br label %bb57
bb57:
  %t422 = load ptr, ptr %l206, !tbaa !29
  store ptr %t422, ptr %l27, !tbaa !29
  br label %bb58
bb58:
  %t424 = load %"compiler/source:Span", ptr %l23
  store %"compiler/source:Span" %t424, ptr %l208
  %t425 = load i32, ptr %l24, !tbaa !23
  store i32 %t425, ptr %l209, !tbaa !23
  %t426 = load ptr, ptr %l25, !tbaa !29
  %t428 = getelementptr %"compiler/typed:Make", ptr %t426, i32 0, i32 0
  %t429 = load i32, ptr %t428
  store i32 %t429, ptr %l211
  %t430 = load ptr, ptr %l25, !tbaa !29
  %t432 = getelementptr %"compiler/typed:Make", ptr %t430, i32 0, i32 1
  %t433 = load i64, ptr %t432, !tbaa !24
  store i64 %t433, ptr %l213, !tbaa !24
  %t434 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t434, ptr %l214, !tbaa !27
  %t435 = load ptr, ptr %l27, !tbaa !29
  store ptr %t435, ptr %l215, !tbaa !29
  %t436 = load ptr, ptr %l0, !tbaa !29
  %t437 = load ptr, ptr %l25, !tbaa !29
  %t439 = getelementptr %"compiler/typed:Make", ptr %t437, i32 0, i32 4
  %t440 = load i32, ptr %t439, !tbaa !23
  %t441 = load i64, ptr %l2, !tbaa !24
  %t445 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereSite(ptr %v0, ptr %t436, i32 %t440, i64 %t441)
  store i32 %t445, ptr %l220
  br label %bb59
bb59:
  %t446 = load ptr, ptr %l25, !tbaa !29
  %t448 = getelementptr %"compiler/typed:Make", ptr %t446, i32 0, i32 5
  %t449 = load i32, ptr %t448
  %t450 = load i32, ptr %l211
  %t451 = load i64, ptr %l213, !tbaa !24
  %t452 = load { i64, ptr }, ptr %l214, !tbaa !27
  %t453 = load ptr, ptr %l215, !tbaa !29
  %t454 = load i32, ptr %l220, !tbaa !23
  %t456 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t450, i64 %t451, { i64, ptr } %t452, ptr %t453, i32 %t454, i32 %t449)
  store %"compiler/typed:Make" %t456, ptr %l223
  br label %bb60
bb60:
  %t457 = load %"compiler/typed:Make", ptr %l223
  %t458 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store %"compiler/typed:Make" %t457, ptr %t458
  store { i64, [5 x i64] } zeroinitializer, ptr %t459
  %t460 = getelementptr { i64, [5 x i64] }, ptr %t459, i32 0, i32 0
  store i64 7, ptr %t460
  %t461 = load %"compiler/source:Span", ptr %l208
  %t462 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t461, 0
  %t463 = load i32, ptr %l209, !tbaa !23
  %t464 = insertvalue { %"compiler/source:Span", i32, ptr } %t462, i32 %t463, 1
  %t466 = insertvalue { %"compiler/source:Span", i32, ptr } %t464, ptr %t458, 2
  %t467 = getelementptr { i64, [5 x i64] }, ptr %t459, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t466, ptr %t467
  %t468 = load { i64, [5 x i64] }, ptr %t459
  %t470 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t468, ptr %t470
  store ptr %t470, ptr %rv
  br label %ret
bb61:
  %t472 = load ptr, ptr %l1, !tbaa !29
  store ptr %t472, ptr %l227, !tbaa !29
  store i1 false, ptr %l228, !tbaa !21
  %t473 = load ptr, ptr %l227, !tbaa !29
  %t474 = icmp ne ptr %t473, null
  br i1 %t474, label %bb62, label %bb63
bb62:
  %t476 = load ptr, ptr %l227, !tbaa !29
  %t477 = load i64, ptr %t476
  %t479 = icmp eq i64 %t477, 9
  store i1 %t479, ptr %l228, !tbaa !21
  br label %bb63
bb63:
  %t480 = load i1, ptr %l228, !tbaa !21
  br i1 %t480, label %bb64, label %bb65
bb64:
  %t481 = load ptr, ptr %l1, !tbaa !29
  %t483 = getelementptr { i64, [5 x i64] }, ptr %t481, i32 0, i32 1
  %t484 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t483, i32 0, i32 0
  %t485 = load %"compiler/source:Span", ptr %t484
  store %"compiler/source:Span" %t485, ptr %l28
  %t487 = load ptr, ptr %l1, !tbaa !29
  %t489 = getelementptr { i64, [5 x i64] }, ptr %t487, i32 0, i32 1
  %t490 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t489, i32 0, i32 1
  %t491 = load i32, ptr %t490
  store i32 %t491, ptr %l29, !tbaa !23
  %t493 = load ptr, ptr %l1, !tbaa !29
  %t495 = getelementptr { i64, [5 x i64] }, ptr %t493, i32 0, i32 1
  %t496 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t495, i32 0, i32 2
  %t497 = load i32, ptr %t496
  store i32 %t497, ptr %l30
  %t499 = load ptr, ptr %l1, !tbaa !29
  %t501 = getelementptr { i64, [5 x i64] }, ptr %t499, i32 0, i32 1
  %t502 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t501, i32 0, i32 3
  %t503 = load i32, ptr %t502
  store i32 %t503, ptr %l31
  %t505 = load ptr, ptr %l1, !tbaa !29
  %t507 = getelementptr { i64, [5 x i64] }, ptr %t505, i32 0, i32 1
  %t508 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t507, i32 0, i32 4
  %t509 = load { i64, ptr }, ptr %t508
  store { i64, ptr } %t509, ptr %l32, !tbaa !27
  br label %bb66
bb65:
  br label %bb68
bb66:
  %t511 = load %"compiler/source:Span", ptr %l28
  store %"compiler/source:Span" %t511, ptr %l241
  %t512 = load i32, ptr %l29, !tbaa !23
  store i32 %t512, ptr %l242, !tbaa !23
  %t513 = load i32, ptr %l30
  store i32 %t513, ptr %l243
  %t514 = load i32, ptr %l31
  store i32 %t514, ptr %l244
  %t515 = load ptr, ptr %l0, !tbaa !29
  %t516 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t517 = load i64, ptr %l2, !tbaa !24
  %t521 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyAll(ptr %v0, ptr %v1, ptr %t515, { i64, ptr } %t516, i64 %t517)
  store { i64, ptr } %t521, ptr %l248
  br label %bb67
bb67:
  store { i64, [5 x i64] } zeroinitializer, ptr %t522
  %t523 = getelementptr { i64, [5 x i64] }, ptr %t522, i32 0, i32 0
  store i64 9, ptr %t523
  %t524 = load %"compiler/source:Span", ptr %l241
  %t525 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t524, 0
  %t526 = load i32, ptr %l242, !tbaa !23
  %t527 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t525, i32 %t526, 1
  %t528 = load i32, ptr %l243
  %t529 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t527, i32 %t528, 2
  %t530 = load i32, ptr %l244
  %t531 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t529, i32 %t530, 3
  %t532 = load { i64, ptr }, ptr %l248, !tbaa !27
  %t533 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t531, { i64, ptr } %t532, 4
  %t534 = getelementptr { i64, [5 x i64] }, ptr %t522, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t533, ptr %t534
  %t535 = load { i64, [5 x i64] }, ptr %t522
  %t537 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t535, ptr %t537
  store ptr %t537, ptr %rv
  br label %ret
bb68:
  %t539 = load ptr, ptr %l1, !tbaa !29
  store ptr %t539, ptr %l251, !tbaa !29
  store i1 false, ptr %l252, !tbaa !21
  %t540 = load ptr, ptr %l251, !tbaa !29
  %t541 = icmp ne ptr %t540, null
  br i1 %t541, label %bb69, label %bb70
bb69:
  %t543 = load ptr, ptr %l251, !tbaa !29
  %t544 = load i64, ptr %t543
  %t546 = icmp eq i64 %t544, 10
  store i1 %t546, ptr %l252, !tbaa !21
  br label %bb70
bb70:
  %t547 = load i1, ptr %l252, !tbaa !21
  br i1 %t547, label %bb71, label %bb72
bb71:
  %t548 = load ptr, ptr %l1, !tbaa !29
  %t550 = getelementptr { i64, [5 x i64] }, ptr %t548, i32 0, i32 1
  %t551 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t550, i32 0, i32 0
  %t552 = load %"compiler/source:Span", ptr %t551
  store %"compiler/source:Span" %t552, ptr %l33
  %t554 = load ptr, ptr %l1, !tbaa !29
  %t556 = getelementptr { i64, [5 x i64] }, ptr %t554, i32 0, i32 1
  %t557 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t556, i32 0, i32 1
  %t558 = load i32, ptr %t557
  store i32 %t558, ptr %l34, !tbaa !23
  %t560 = load ptr, ptr %l1, !tbaa !29
  %t562 = getelementptr { i64, [5 x i64] }, ptr %t560, i32 0, i32 1
  %t563 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t562, i32 0, i32 2
  %t564 = load ptr, ptr %t563
  store ptr %t564, ptr %l35, !tbaa !29
  br label %bb73
bb72:
  br label %bb78
bb73:
  %t566 = load %"compiler/source:Span", ptr %l33
  store %"compiler/source:Span" %t566, ptr %l261
  %t567 = load i32, ptr %l34, !tbaa !23
  store i32 %t567, ptr %l262, !tbaa !23
  %t568 = load ptr, ptr %l0, !tbaa !29
  %t569 = load ptr, ptr %l35, !tbaa !29
  %t571 = getelementptr %"compiler/typed:Slice", ptr %t569, i32 0, i32 0
  %t572 = load ptr, ptr %t571, !tbaa !29
  %t573 = load i64, ptr %l2, !tbaa !24
  %t577 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyPlace(ptr %v0, ptr %v1, ptr %t568, ptr %t572, i64 %t573)
  store ptr %t577, ptr %l267
  br label %bb74
bb74:
  %t578 = load ptr, ptr %l0, !tbaa !29
  %t579 = load ptr, ptr %l35, !tbaa !29
  %t581 = getelementptr %"compiler/typed:Slice", ptr %t579, i32 0, i32 1
  %t582 = load ptr, ptr %t581, !tbaa !29
  %t583 = load i64, ptr %l2, !tbaa !24
  %t587 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %t578, ptr %t582, i64 %t583)
  store ptr %t587, ptr %l272
  br label %bb75
bb75:
  %t588 = load ptr, ptr %l0, !tbaa !29
  %t589 = load ptr, ptr %l35, !tbaa !29
  %t591 = getelementptr %"compiler/typed:Slice", ptr %t589, i32 0, i32 2
  %t592 = load ptr, ptr %t591, !tbaa !29
  %t593 = load i64, ptr %l2, !tbaa !24
  %t597 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %t588, ptr %t592, i64 %t593)
  store ptr %t597, ptr %l277
  br label %bb76
bb76:
  %t598 = load ptr, ptr %l35, !tbaa !29
  %t600 = getelementptr %"compiler/typed:Slice", ptr %t598, i32 0, i32 3
  %t601 = load i32, ptr %t600
  %t602 = load ptr, ptr %l267, !tbaa !29
  %t603 = load ptr, ptr %l272, !tbaa !29
  %t604 = load ptr, ptr %l277, !tbaa !29
  %t606 = call %"compiler/typed:Slice" @compiler_2ftyped_3aSlice_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t602, ptr %t603, ptr %t604, i32 %t601)
  store %"compiler/typed:Slice" %t606, ptr %l280
  br label %bb77
bb77:
  %t607 = load %"compiler/typed:Slice", ptr %l280
  %t608 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/typed:Slice" %t607, ptr %t608
  store { i64, [5 x i64] } zeroinitializer, ptr %t609
  %t610 = getelementptr { i64, [5 x i64] }, ptr %t609, i32 0, i32 0
  store i64 10, ptr %t610
  %t611 = load %"compiler/source:Span", ptr %l261
  %t612 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t611, 0
  %t613 = load i32, ptr %l262, !tbaa !23
  %t614 = insertvalue { %"compiler/source:Span", i32, ptr } %t612, i32 %t613, 1
  %t616 = insertvalue { %"compiler/source:Span", i32, ptr } %t614, ptr %t608, 2
  %t617 = getelementptr { i64, [5 x i64] }, ptr %t609, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t616, ptr %t617
  %t618 = load { i64, [5 x i64] }, ptr %t609
  %t620 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t618, ptr %t620
  store ptr %t620, ptr %rv
  br label %ret
bb78:
  %t622 = load ptr, ptr %l1, !tbaa !29
  store ptr %t622, ptr %l284, !tbaa !29
  store i1 false, ptr %l285, !tbaa !21
  %t623 = load ptr, ptr %l284, !tbaa !29
  %t624 = icmp ne ptr %t623, null
  br i1 %t624, label %bb79, label %bb80
bb79:
  %t626 = load ptr, ptr %l284, !tbaa !29
  %t627 = load i64, ptr %t626
  %t629 = icmp eq i64 %t627, 11
  store i1 %t629, ptr %l285, !tbaa !21
  br label %bb80
bb80:
  %t630 = load i1, ptr %l285, !tbaa !21
  br i1 %t630, label %bb81, label %bb82
bb81:
  %t631 = load ptr, ptr %l1, !tbaa !29
  %t633 = getelementptr { i64, [5 x i64] }, ptr %t631, i32 0, i32 1
  %t634 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t633, i32 0, i32 0
  %t635 = load %"compiler/source:Span", ptr %t634
  store %"compiler/source:Span" %t635, ptr %l36
  %t637 = load ptr, ptr %l1, !tbaa !29
  %t639 = getelementptr { i64, [5 x i64] }, ptr %t637, i32 0, i32 1
  %t640 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t639, i32 0, i32 1
  %t641 = load i32, ptr %t640
  store i32 %t641, ptr %l37, !tbaa !23
  %t643 = load ptr, ptr %l1, !tbaa !29
  %t645 = getelementptr { i64, [5 x i64] }, ptr %t643, i32 0, i32 1
  %t646 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t645, i32 0, i32 2
  %t647 = load ptr, ptr %t646
  store ptr %t647, ptr %l38, !tbaa !29
  br label %bb83
bb82:
  br label %bb94
bb83:
  store ptr null, ptr %l39, !tbaa !29
  %t649 = load ptr, ptr %l38, !tbaa !29
  %t651 = getelementptr %"compiler/typed:Cond", ptr %t649, i32 0, i32 1
  %t652 = load ptr, ptr %t651, !tbaa !29
  %t654 = icmp eq ptr %t652, null
  %t656 = xor i1 %t654, true
  br i1 %t656, label %bb84, label %bb85
bb84:
  %t658 = load ptr, ptr %l0, !tbaa !29
  store ptr %t658, ptr %l298, !tbaa !29
  %t659 = load ptr, ptr %l38, !tbaa !29
  %t661 = getelementptr %"compiler/typed:Cond", ptr %t659, i32 0, i32 1
  %t662 = load ptr, ptr %t661, !tbaa !29
  %t664 = icmp eq ptr %t662, null
  br i1 %t664, label %bb86, label %bb87
bb85:
  br label %bb90
bb86:
  call void @__olang_check_failed(ptr @olang_loc_89a248f11218248d_cad7b116269b1029)
  unreachable
bb87:
  br label %bb88
bb88:
  %t666 = load ptr, ptr %l38, !tbaa !29
  %t668 = getelementptr %"compiler/typed:Cond", ptr %t666, i32 0, i32 1
  %t669 = load ptr, ptr %t668, !tbaa !29
  %t670 = load i64, ptr %l2, !tbaa !24
  %t671 = load ptr, ptr %l298, !tbaa !29
  %t674 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %t671, ptr %t669, i64 %t670)
  store ptr %t674, ptr %l305
  br label %bb89
bb89:
  %t675 = load ptr, ptr %l305, !tbaa !29
  store ptr %t675, ptr %l39, !tbaa !29
  br label %bb90
bb90:
  %t677 = load %"compiler/source:Span", ptr %l36
  store %"compiler/source:Span" %t677, ptr %l307
  %t678 = load i32, ptr %l37, !tbaa !23
  store i32 %t678, ptr %l308, !tbaa !23
  %t679 = load ptr, ptr %l0, !tbaa !29
  %t680 = load ptr, ptr %l38, !tbaa !29
  %t682 = getelementptr %"compiler/typed:Cond", ptr %t680, i32 0, i32 0
  %t683 = load ptr, ptr %t682, !tbaa !29
  %t684 = load i64, ptr %l2, !tbaa !24
  %t688 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %t679, ptr %t683, i64 %t684)
  store ptr %t688, ptr %l313
  br label %bb91
bb91:
  %t689 = load ptr, ptr %l39, !tbaa !29
  store ptr %t689, ptr %l314, !tbaa !29
  %t690 = load ptr, ptr %l0, !tbaa !29
  %t691 = load ptr, ptr %l38, !tbaa !29
  %t693 = getelementptr %"compiler/typed:Cond", ptr %t691, i32 0, i32 2
  %t694 = load ptr, ptr %t693, !tbaa !29
  %t695 = load i64, ptr %l2, !tbaa !24
  %t699 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %t690, ptr %t694, i64 %t695)
  store ptr %t699, ptr %l319
  br label %bb92
bb92:
  %t700 = load ptr, ptr %l313, !tbaa !29
  %t701 = load ptr, ptr %l314, !tbaa !29
  %t702 = load ptr, ptr %l319, !tbaa !29
  %t703 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t700, ptr %t701, ptr %t702)
  store %"compiler/typed:Cond" %t703, ptr %l320
  br label %bb93
bb93:
  %t704 = load %"compiler/typed:Cond", ptr %l320
  %t705 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Cond" %t704, ptr %t705
  store { i64, [5 x i64] } zeroinitializer, ptr %t706
  %t707 = getelementptr { i64, [5 x i64] }, ptr %t706, i32 0, i32 0
  store i64 11, ptr %t707
  %t708 = load %"compiler/source:Span", ptr %l307
  %t709 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t708, 0
  %t710 = load i32, ptr %l308, !tbaa !23
  %t711 = insertvalue { %"compiler/source:Span", i32, ptr } %t709, i32 %t710, 1
  %t713 = insertvalue { %"compiler/source:Span", i32, ptr } %t711, ptr %t705, 2
  %t714 = getelementptr { i64, [5 x i64] }, ptr %t706, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t713, ptr %t714
  %t715 = load { i64, [5 x i64] }, ptr %t706
  %t717 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t715, ptr %t717
  store ptr %t717, ptr %rv
  br label %ret
bb94:
  %t719 = load ptr, ptr %l1, !tbaa !29
  store ptr %t719, ptr %l324, !tbaa !29
  store i1 false, ptr %l325, !tbaa !21
  %t720 = load ptr, ptr %l324, !tbaa !29
  %t721 = icmp ne ptr %t720, null
  br i1 %t721, label %bb95, label %bb96
bb95:
  %t723 = load ptr, ptr %l324, !tbaa !29
  %t724 = load i64, ptr %t723
  %t726 = icmp eq i64 %t724, 17
  store i1 %t726, ptr %l325, !tbaa !21
  br label %bb96
bb96:
  %t727 = load i1, ptr %l325, !tbaa !21
  br i1 %t727, label %bb97, label %bb98
bb97:
  %t728 = load ptr, ptr %l1, !tbaa !29
  %t730 = getelementptr { i64, [5 x i64] }, ptr %t728, i32 0, i32 1
  %t731 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t730, i32 0, i32 0
  %t732 = load %"compiler/source:Span", ptr %t731
  store %"compiler/source:Span" %t732, ptr %l40
  %t734 = load ptr, ptr %l1, !tbaa !29
  %t736 = getelementptr { i64, [5 x i64] }, ptr %t734, i32 0, i32 1
  %t737 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t736, i32 0, i32 1
  %t738 = load i64, ptr %t737
  store i64 %t738, ptr %l41, !tbaa !24
  %t740 = load ptr, ptr %l1, !tbaa !29
  %t742 = getelementptr { i64, [5 x i64] }, ptr %t740, i32 0, i32 1
  %t743 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t742, i32 0, i32 2
  %t744 = load ptr, ptr %t743
  store ptr %t744, ptr %l42, !tbaa !29
  br label %bb99
bb98:
  br label %bb101
bb99:
  %t746 = load %"compiler/source:Span", ptr %l40
  store %"compiler/source:Span" %t746, ptr %l334
  %t747 = load i64, ptr %l41, !tbaa !24
  store i64 %t747, ptr %l335, !tbaa !24
  %t748 = load ptr, ptr %l0, !tbaa !29
  %t749 = load ptr, ptr %l42, !tbaa !29
  %t750 = load i64, ptr %l2, !tbaa !24
  %t754 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %t748, ptr %t749, i64 %t750)
  store ptr %t754, ptr %l339
  br label %bb100
bb100:
  store { i64, [5 x i64] } zeroinitializer, ptr %t755
  %t756 = getelementptr { i64, [5 x i64] }, ptr %t755, i32 0, i32 0
  store i64 17, ptr %t756
  %t757 = load %"compiler/source:Span", ptr %l334
  %t758 = insertvalue { %"compiler/source:Span", i64, ptr } undef, %"compiler/source:Span" %t757, 0
  %t759 = load i64, ptr %l335, !tbaa !24
  %t760 = insertvalue { %"compiler/source:Span", i64, ptr } %t758, i64 %t759, 1
  %t761 = load ptr, ptr %l339, !tbaa !29
  %t762 = insertvalue { %"compiler/source:Span", i64, ptr } %t760, ptr %t761, 2
  %t763 = getelementptr { i64, [5 x i64] }, ptr %t755, i32 0, i32 1
  store { %"compiler/source:Span", i64, ptr } %t762, ptr %t763
  %t764 = load { i64, [5 x i64] }, ptr %t755
  %t766 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t764, ptr %t766
  store ptr %t766, ptr %rv
  br label %ret
bb101:
  %t768 = load ptr, ptr %l1, !tbaa !29
  store ptr %t768, ptr %l342, !tbaa !29
  store i1 false, ptr %l343, !tbaa !21
  %t769 = load ptr, ptr %l342, !tbaa !29
  %t770 = icmp ne ptr %t769, null
  br i1 %t770, label %bb102, label %bb103
bb102:
  %t772 = load ptr, ptr %l342, !tbaa !29
  %t773 = load i64, ptr %t772
  %t775 = icmp eq i64 %t773, 15
  store i1 %t775, ptr %l343, !tbaa !21
  br label %bb103
bb103:
  %t776 = load i1, ptr %l343, !tbaa !21
  br i1 %t776, label %bb104, label %bb105
bb104:
  %t777 = load ptr, ptr %l1, !tbaa !29
  %t779 = getelementptr { i64, [5 x i64] }, ptr %t777, i32 0, i32 1
  %t780 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t779, i32 0, i32 0
  %t781 = load %"compiler/source:Span", ptr %t780
  store %"compiler/source:Span" %t781, ptr %l43
  %t783 = load ptr, ptr %l1, !tbaa !29
  %t785 = getelementptr { i64, [5 x i64] }, ptr %t783, i32 0, i32 1
  %t786 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t785, i32 0, i32 1
  %t787 = load i32, ptr %t786
  store i32 %t787, ptr %l44, !tbaa !23
  %t789 = load ptr, ptr %l1, !tbaa !29
  %t791 = getelementptr { i64, [5 x i64] }, ptr %t789, i32 0, i32 1
  %t792 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t791, i32 0, i32 2
  %t793 = load ptr, ptr %t792
  store ptr %t793, ptr %l45, !tbaa !29
  br label %bb106
bb105:
  br label %bb114
bb106:
  %t795 = load ptr, ptr %l45, !tbaa !29
  store ptr %t795, ptr %l352, !tbaa !29
  store i1 false, ptr %l353, !tbaa !21
  %t796 = load ptr, ptr %l352, !tbaa !29
  %t797 = icmp ne ptr %t796, null
  br i1 %t797, label %bb107, label %bb108
bb107:
  %t799 = load ptr, ptr %l352, !tbaa !29
  %t800 = load i64, ptr %t799
  %t802 = icmp eq i64 %t800, 0
  store i1 %t802, ptr %l353, !tbaa !21
  br label %bb108
bb108:
  %t803 = load i1, ptr %l353, !tbaa !21
  br i1 %t803, label %bb109, label %bb110
bb109:
  %t804 = load ptr, ptr %l45, !tbaa !29
  %t806 = getelementptr { i64, [4 x i64] }, ptr %t804, i32 0, i32 1
  %t807 = getelementptr { i32 }, ptr %t806, i32 0, i32 0
  %t808 = load i32, ptr %t807
  store i32 %t808, ptr %l46, !tbaa !23
  br label %bb111
bb110:
  br label %bb112
bb111:
  %t810 = load %"compiler/source:Span", ptr %l43
  %t811 = load i32, ptr %l44, !tbaa !23
  %t812 = load i32, ptr %l46, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t813
  %t814 = getelementptr { i64, [4 x i64] }, ptr %t813, i32 0, i32 0
  store i64 0, ptr %t814
  %t816 = insertvalue { i32 } undef, i32 %t812, 0
  %t817 = getelementptr { i64, [4 x i64] }, ptr %t813, i32 0, i32 1
  store { i32 } %t816, ptr %t817
  %t818 = load { i64, [4 x i64] }, ptr %t813
  %t820 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t818, ptr %t820
  store { i64, [5 x i64] } zeroinitializer, ptr %t821
  %t822 = getelementptr { i64, [5 x i64] }, ptr %t821, i32 0, i32 0
  store i64 15, ptr %t822
  %t824 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t810, 0
  %t826 = insertvalue { %"compiler/source:Span", i32, ptr } %t824, i32 %t811, 1
  %t828 = insertvalue { %"compiler/source:Span", i32, ptr } %t826, ptr %t820, 2
  %t829 = getelementptr { i64, [5 x i64] }, ptr %t821, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t828, ptr %t829
  %t830 = load { i64, [5 x i64] }, ptr %t821
  %t832 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t830, ptr %t832
  store ptr %t832, ptr %rv
  br label %ret
bb112:
  br label %bb113
bb113:
  br label %bb115
bb114:
  br label %bb115
bb115:
  %t834 = load ptr, ptr %l0, !tbaa !29
  store ptr %t834, ptr %l365, !tbaa !29
  %t835 = load ptr, ptr %l1, !tbaa !29
  %t837 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t835)
  store %"compiler/source:Span" %t837, ptr %l367
  br label %bb116
bb116:
  %t838 = load ptr, ptr %l365, !tbaa !29
  %t839 = load %"compiler/source:Span", ptr %l367
  %t840 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t838, %"compiler/source:Span" %t839)
  store ptr %t840, ptr %l368
  br label %bb117
bb117:
  %t841 = load ptr, ptr %l368, !tbaa !29
  store ptr %t841, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecoversRows(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca [2 x i64]
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca { i64, ptr }
  %l36 = alloca ptr
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca i64
  %l47 = alloca i1
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca i64
  %l52 = alloca ptr
  %l53 = alloca ptr
  %l54 = alloca i64
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca { i64, ptr }
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i32
  %l66 = alloca { i64, ptr }
  %l67 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l68 = alloca { i64, ptr }
  %l69 = alloca i64
  %l70 = alloca i64
  %l72 = alloca { i64, ptr }
  %l73 = alloca i64
  %l74 = alloca i64
  %l76 = alloca ptr
  %l77 = alloca ptr
  %l78 = alloca i64
  %l79 = alloca { i64, ptr }
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca { i64, ptr }
  %l83 = alloca ptr
  %l84 = alloca ptr
  %l85 = alloca ptr
  %l86 = alloca { i64, ptr }
  %l87 = alloca ptr
  %l88 = alloca ptr
  %l89 = alloca i64
  %l90 = alloca { i64, ptr }
  %l91 = alloca i64
  %l92 = alloca i64
  %l93 = alloca { i64, ptr }
  %l98 = alloca i64
  %l101 = alloca i64
  %l103 = alloca i1
  %l108 = alloca { i64, ptr }
  %l110 = alloca i32
  %l111 = alloca { i64, ptr }
  %l114 = alloca i64
  %l115 = alloca i64
  %l125 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l129 = alloca i32
  %l138 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l144 = alloca i64
  %l155 = alloca i1
  %l158 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l161 = alloca { i64, ptr }
  %l164 = alloca { i64, ptr }
  %l165 = alloca i32
  %l174 = alloca { i64, ptr }
  %l178 = alloca { i64, ptr }
  %l180 = alloca i1
  %l181 = alloca ptr
  %l182 = alloca { i64, ptr }
  %l186 = alloca { i64, ptr }
  %l197 = alloca i1
  %l201 = alloca i64
  %l204 = alloca i64
  %l222 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l225 = alloca { i64, ptr }
  %l228 = alloca { i64, ptr }
  %l229 = alloca i32
  %l238 = alloca { i64, ptr }
  %l242 = alloca { i64, ptr }
  %l244 = alloca i1
  %l245 = alloca i1
  %l247 = alloca { i64, ptr }
  %l249 = alloca i64
  %l252 = alloca ptr
  %l253 = alloca { i64, ptr }
  %l257 = alloca { i64, ptr }
  %l268 = alloca i1
  %l276 = alloca i1
  %l279 = alloca ptr
  %l284 = alloca i32
  %l285 = alloca { i64, ptr }
  %l287 = alloca i64
  %l291 = alloca { i64, ptr }
  %l294 = alloca { i64, ptr }
  %l295 = alloca i32
  %l304 = alloca { i64, ptr }
  %l307 = alloca { i64, ptr }
  %l309 = alloca ptr
  %l310 = alloca i1
  %l315 = alloca ptr
  %l316 = alloca i1
  %l324 = alloca i64
  %l328 = alloca ptr
  %l329 = alloca i1
  %l337 = alloca i64
  %l353 = alloca { i64, ptr }
  %l362 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l365 = alloca { i64, ptr }
  %l368 = alloca { i64, ptr }
  %l369 = alloca i32
  %l378 = alloca { i64, ptr }
  %l382 = alloca { i64, ptr }
  %l384 = alloca i1
  %l385 = alloca ptr
  %l386 = alloca { i64, ptr }
  %l390 = alloca { i64, ptr }
  %l401 = alloca i1
  %l406 = alloca i64
  %l409 = alloca i64
  %l431 = alloca i32
  %l435 = alloca { i64, ptr }
  %l438 = alloca ptr
  %l443 = alloca i32
  %l444 = alloca { i64, ptr }
  %l448 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l456 = alloca { i64, ptr }
  %l470 = alloca { i64, ptr }
  %l477 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l480 = alloca { i64, ptr }
  %l483 = alloca { i64, ptr }
  %l484 = alloca i32
  %l493 = alloca { i64, ptr }
  %l496 = alloca { i64, ptr }
  %l500 = alloca i1
  %l501 = alloca ptr
  %l502 = alloca { i64, ptr }
  %l508 = alloca { i64, ptr }
  %l509 = alloca ptr
  %l510 = alloca i1
  %l515 = alloca ptr
  %l516 = alloca i1
  %l524 = alloca i64
  %l527 = alloca ptr
  %l528 = alloca { i64, ptr }
  %l534 = alloca { i64, ptr }
  %l535 = alloca ptr
  %l536 = alloca i1
  %l546 = alloca i64
  %l549 = alloca i1
  %l555 = alloca ptr
  %l558 = alloca { i64, ptr }
  %l564 = alloca ptr
  %l565 = alloca ptr
  %l567 = alloca { i64, ptr }
  %l570 = alloca i1
  %l576 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l579 = alloca { i64, ptr }
  %l582 = alloca { i64, ptr }
  %l583 = alloca i32
  %l592 = alloca { i64, ptr }
  %l596 = alloca { i64, ptr }
  %l598 = alloca i1
  %l599 = alloca ptr
  %l600 = alloca { i64, ptr }
  %l604 = alloca { i64, ptr }
  %l615 = alloca i1
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %s45 = alloca %olang.scope
  %s47 = alloca %olang.scope
  %s50 = alloca %olang.scope
  %s53 = alloca %olang.scope
  %s54 = alloca %olang.scope
  %s65 = alloca %olang.scope
  %s66 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fast_3aPattern_26_H92ad3d4b1581d96426d44b389947861c(ptr %v1, ptr %t7)
  store i64 %t9, ptr %l98
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t10 = load i64, ptr %l98, !tbaa !24
  %t11 = icmp sgt i64 %t10, 0
  store i1 %t11, ptr %rv
  br label %ret
bb4:
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fast_3aPattern_26_H92ad3d4b1581d96426d44b389947861c(ptr %v1, ptr %t13)
  store i64 %t15, ptr %l101
  br label %bb5
bb5:
  %t16 = load i64, ptr %l101, !tbaa !24
  %t17 = icmp eq i64 %t16, 0
  br i1 %t17, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l103, !tbaa !21
  br label %bb8
bb7:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = icmp sgt i64 %t19, 16
  store i1 %t21, ptr %l103, !tbaa !21
  br label %bb8
bb8:
  %t23 = load i1, ptr %l103, !tbaa !21
  br i1 %t23, label %bb9, label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l108, !tbaa !27
  %t27 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i32, ptr %t28, i64 0
  %t30 = load i32, ptr %t29, !tbaa !33
  %t33 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t25, i32 %t30)
  store i32 %t33, ptr %l110
  br label %bb12
bb12:
  %t34 = load i32, ptr %l110, !tbaa !23
  store i32 %t34, ptr %l4, !tbaa !23
  %t35 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t35, ptr %l111, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t36, 0
  store i64 %t39, ptr %l114, !tbaa !24
  %t40 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  store i64 %t41, ptr %l115, !tbaa !24
  %t42 = icmp sge i64 1, 0
  br i1 %t42, label %bb13, label %bb14
bb13:
  %t44 = load i64, ptr %l114, !tbaa !24
  %t45 = icmp sle i64 1, %t44
  br i1 %t45, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_5751a3eee0d06197_8765202abe0be66b)
  unreachable
bb15:
  %t47 = load i64, ptr %l114, !tbaa !24
  %t48 = load i64, ptr %l115, !tbaa !24
  %t49 = icmp sle i64 %t47, %t48
  br i1 %t49, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_5751a3eee0d06197_8765202abe0be66b)
  unreachable
bb17:
  %t51 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = load i64, ptr %l114, !tbaa !24
  %t54 = getelementptr i32, ptr %t52, i64 1
  %t55 = sub i64 %t53, 1
  %t56 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t54, 1
  store { i64, ptr } %t57, ptr %l5, !tbaa !27
  %t59 = load i32, ptr %l4, !tbaa !23
  %t60 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t63 = icmp eq i32 %t59, %t60
  br i1 %t63, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_5751a3eee0d06197_8765202abe0be66b)
  unreachable
bb19:
  %t65 = insertvalue [2 x i64] undef, i64 0, 0
  %t66 = insertvalue [2 x i64] %t65, i64 0, 1
  store [2 x i64] %t66, ptr %l6
  %t68 = load ptr, ptr %l1, !tbaa !29
  store ptr %t68, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb21
bb20:
  br label %bb119
bb21:
  store %olang.scope zeroinitializer, ptr %s5
  %t70 = load ptr, ptr %l7, !tbaa !29
  %t71 = load i64, ptr %l8, !tbaa !24
  %t74 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fast_3aPattern_26_H8f433a386540269ec523262b43568e5b(ptr %v1, ptr %t70, i64 %t71)
  %t75 = extractvalue { i32, { i64, ptr } } %t74, 1
  %t76 = extractvalue { i32, { i64, ptr } } %t74, 0
  store i32 %t76, ptr %l129
  %t77 = icmp ne i32 %t76, 0
  br i1 %t77, label %bb23, label %ok.78
ok.78:
  store { i64, ptr } %t75, ptr %l128
  br label %bb22
bb22:
  %t79 = load { i64, ptr }, ptr %l128, !tbaa !27
  store { i64, ptr } %t79, ptr %l125, !tbaa !27
  br label %bb27
bb23:
  %t80 = load i32, ptr %l129, !tbaa !23
  %t81 = ashr i32 %t80, 16
  %t83 = icmp eq i32 %t81, 1
  br i1 %t83, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_947efe64310efd31_ddaff5fcfd0a0175)
  unreachable
bb26:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s5)
  br label %bb39
bb27:
  %t85 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t85, ptr %l9, !tbaa !27
  %t86 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  store i64 %t88, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s6
  %t90 = load i64, ptr %l11, !tbaa !24
  %t91 = load i64, ptr %l10, !tbaa !24
  %t94 = icmp slt i64 %t90, %t91
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s6)
  br label %bb37
bb30:
  br label %bb31
bb31:
  %t98 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t98, ptr %l138, !tbaa !27
  %t99 = load i64, ptr %l11, !tbaa !24
  %t101 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr { i64, ptr }, ptr %t102, i64 %t99
  %t104 = load { i64, ptr }, ptr %t103, !tbaa !37
  %t106 = load ptr, ptr %l0, !tbaa !29
  store { i64, ptr } %t104, ptr %l142, !tbaa !27
  %t108 = getelementptr { i64, ptr }, ptr %l142, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr ptr, ptr %t109, i64 0
  %t111 = load ptr, ptr %t110, !tbaa !39
  %t114 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatBool(ptr %v0, ptr %v1, ptr %t106, ptr %t111)
  store i64 %t114, ptr %l144
  br label %bb32
bb32:
  %t115 = load i64, ptr %l144, !tbaa !24
  store i64 %t115, ptr %l13, !tbaa !24
  %t116 = load i64, ptr %l13, !tbaa !24
  %t118 = icmp sge i64 %t116, 0
  br i1 %t118, label %bb33, label %bb34
bb33:
  %t120 = load i64, ptr %l13, !tbaa !24
  %t122 = getelementptr [2 x i64], ptr %l6, i64 0, i64 %t120
  store i64 1, ptr %t122, !tbaa !34
  br label %bb35
bb34:
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s6)
  br label %bb36
bb36:
  %t123 = load i64, ptr %l11, !tbaa !24
  %t125 = add i64 %t123, 1
  store i64 %t125, ptr %l11, !tbaa !24
  br label %bb28
bb37:
  %t127 = load i64, ptr %l8, !tbaa !24
  %t128 = load i64, ptr %l10, !tbaa !24
  %t131 = add i64 %t127, %t128
  store i64 %t131, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb38
bb38:
  br label %bb21
bb39:
  %t133 = getelementptr [2 x i64], ptr %l6, i64 0, i64 0
  %t134 = load i64, ptr %t133, !tbaa !34
  %t136 = icmp eq i64 %t134, 0
  br i1 %t136, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l155, !tbaa !21
  br label %bb42
bb41:
  %t138 = getelementptr [2 x i64], ptr %l6, i64 0, i64 1
  %t139 = load i64, ptr %t138, !tbaa !34
  %t141 = icmp eq i64 %t139, 0
  store i1 %t141, ptr %l155, !tbaa !21
  br label %bb42
bb42:
  %t143 = load i1, ptr %l155, !tbaa !21
  br i1 %t143, label %bb43, label %bb44
bb43:
  %t144 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3ccompiler_2fast_3aPattern_26_3e_26_3e_2ector(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t144, ptr %l158
  br label %bb45
bb44:
  br label %bb72
bb45:
  %t145 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l158
  %t146 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t145, ptr %t146
  store ptr %t146, ptr %l14, !tbaa !29
  %t148 = load ptr, ptr %l1, !tbaa !29
  store ptr %t148, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb46
bb46:
  store %olang.scope zeroinitializer, ptr %s11
  %t150 = load ptr, ptr %l15, !tbaa !29
  %t151 = load i64, ptr %l16, !tbaa !24
  %t154 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fast_3aPattern_26_H8f433a386540269ec523262b43568e5b(ptr %v1, ptr %t150, i64 %t151)
  %t155 = extractvalue { i32, { i64, ptr } } %t154, 1
  %t156 = extractvalue { i32, { i64, ptr } } %t154, 0
  store i32 %t156, ptr %l165
  %t157 = icmp ne i32 %t156, 0
  br i1 %t157, label %bb48, label %ok.158
ok.158:
  store { i64, ptr } %t155, ptr %l164
  br label %bb47
bb47:
  %t159 = load { i64, ptr }, ptr %l164, !tbaa !27
  store { i64, ptr } %t159, ptr %l161, !tbaa !27
  br label %bb52
bb48:
  %t160 = load i32, ptr %l165, !tbaa !23
  %t161 = ashr i32 %t160, 16
  %t163 = icmp eq i32 %t161, 1
  br i1 %t163, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_118f3c4f5f1d1d1a_a5abd0c9524a17be)
  unreachable
bb51:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s11)
  br label %bb70
bb52:
  %t165 = load { i64, ptr }, ptr %l161, !tbaa !27
  store { i64, ptr } %t165, ptr %l17, !tbaa !27
  %t166 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t166, 0
  store i64 %t168, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb53
bb53:
  store %olang.scope zeroinitializer, ptr %s12
  %t170 = load i64, ptr %l19, !tbaa !24
  %t171 = load i64, ptr %l18, !tbaa !24
  %t174 = icmp slt i64 %t170, %t171
  %t176 = xor i1 %t174, true
  br i1 %t176, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s12)
  br label %bb68
bb55:
  br label %bb56
bb56:
  %t178 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t178, ptr %l174, !tbaa !27
  %t179 = load i64, ptr %l19, !tbaa !24
  %t181 = getelementptr { i64, ptr }, ptr %l174, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !27
  %t183 = getelementptr { i64, ptr }, ptr %t182, i64 %t179
  %t184 = load { i64, ptr }, ptr %t183, !tbaa !37
  store { i64, ptr } %t184, ptr %l20, !tbaa !27
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t187, ptr %l178, !tbaa !27
  %t188 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = getelementptr ptr, ptr %t189, i64 0
  %t191 = load ptr, ptr %t190, !tbaa !39
  %t194 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatWild(ptr %v0, ptr %v1, ptr %t186, ptr %t191)
  store i1 %t194, ptr %l180
  br label %bb57
bb57:
  %t195 = load i1, ptr %l180, !tbaa !21
  br i1 %t195, label %bb58, label %bb59
bb58:
  %t196 = load ptr, ptr %l14, !tbaa !29
  store ptr %t196, ptr %l181, !tbaa !29
  %t197 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t197, ptr %l182, !tbaa !27
  %t198 = icmp sge i64 0, 0
  br i1 %t198, label %bb60, label %bb61
bb59:
  br label %bb66
bb60:
  %t200 = icmp sle i64 0, 1152921504606846975
  br i1 %t200, label %bb62, label %bb63
bb61:
  call void @__olang_check_failed(ptr @olang_loc_c9fc6cb82d2178b4_58d58e1b66e9a1c0)
  unreachable
bb62:
  %t202 = mul i64 0, 8
  %t203 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t202)
  %t204 = insertvalue { i64, ptr } undef, i64 0, 0
  %t205 = insertvalue { i64, ptr } %t204, ptr %t203, 1
  %t206 = load { i64, ptr }, ptr %l182, !tbaa !27
  %t208 = call { i64, ptr } @compiler_2fcheck_2epatTail(ptr %v1, { i64, ptr } %t206, { i64, ptr } %t205, i64 0)
  store { i64, ptr } %t208, ptr %l186
  br label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_c9fc6cb82d2178b4_58d58e1b66e9a1c0)
  unreachable
bb64:
  %t209 = load ptr, ptr %l181, !tbaa !29
  %t210 = load { i64, ptr }, ptr %l186, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fast_3aPattern_26_H1d860e259259c4952a7ac353d360c942(ptr %v1, ptr %v1, ptr %t209, { i64, ptr } %t210)
  br label %bb65
bb65:
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s12)
  br label %bb67
bb67:
  %t211 = load i64, ptr %l19, !tbaa !24
  %t213 = add i64 %t211, 1
  store i64 %t213, ptr %l19, !tbaa !24
  br label %bb53
bb68:
  %t215 = load i64, ptr %l16, !tbaa !24
  %t216 = load i64, ptr %l18, !tbaa !24
  %t219 = add i64 %t215, %t216
  store i64 %t219, ptr %l16, !tbaa !24
  call void @__olang_scope_close(ptr %s11)
  br label %bb69
bb69:
  br label %bb46
bb70:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load ptr, ptr %l14, !tbaa !29
  %t223 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t224 = load i64, ptr %l3, !tbaa !24
  %t226 = add i64 %t224, 1
  %t231 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecoversRows(ptr %v0, ptr %v1, ptr %v2, ptr %t221, ptr %t222, { i64, ptr } %t223, i64 %t226)
  store i1 %t231, ptr %l197
  br label %bb71
bb71:
  %t232 = load i1, ptr %l197, !tbaa !21
  store i1 %t232, ptr %rv
  br label %ret
bb72:
  store i64 0, ptr %l21, !tbaa !24
  store i64 2, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t233 = load i64, ptr %l22, !tbaa !24
  %t234 = load i64, ptr %l21, !tbaa !24
  %t237 = icmp sgt i64 %t233, %t234
  br i1 %t237, label %bb73, label %bb74
bb73:
  %t239 = load i64, ptr %l23, !tbaa !24
  %t241 = icmp sgt i64 %t239, 0
  br i1 %t241, label %bb75, label %bb76
bb74:
  store i64 0, ptr %l201, !tbaa !24
  br label %bb78
bb75:
  %t243 = load i64, ptr %l22, !tbaa !24
  %t244 = load i64, ptr %l21, !tbaa !24
  %t247 = sub i64 %t243, %t244
  %t248 = load i64, ptr %l23, !tbaa !24
  %t251 = add i64 %t247, %t248
  %t253 = sub i64 %t251, 1
  %t254 = load i64, ptr %l23, !tbaa !24
  %t257 = sdiv i64 %t253, %t254
  store i64 %t257, ptr %l204, !tbaa !24
  br label %bb77
bb76:
  store i64 0, ptr %l204, !tbaa !24
  br label %bb77
bb77:
  %t259 = load i64, ptr %l204, !tbaa !24
  store i64 %t259, ptr %l201, !tbaa !24
  br label %bb78
bb78:
  %t260 = load i64, ptr %l201, !tbaa !24
  store i64 %t260, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb79
bb79:
  store %olang.scope zeroinitializer, ptr %s16
  %t261 = load i64, ptr %l25, !tbaa !24
  %t262 = load i64, ptr %l24, !tbaa !24
  %t265 = icmp slt i64 %t261, %t262
  %t267 = xor i1 %t265, true
  br i1 %t267, label %bb80, label %bb81
bb80:
  call void @__olang_scope_close(ptr %s16)
  br label %bb118
bb81:
  br label %bb82
bb82:
  %t269 = load i64, ptr %l21, !tbaa !24
  %t270 = load i64, ptr %l25, !tbaa !24
  %t271 = load i64, ptr %l23, !tbaa !24
  %t274 = mul i64 %t270, %t271
  %t277 = add i64 %t269, %t274
  store i64 %t277, ptr %l26, !tbaa !24
  %t279 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3ccompiler_2fast_3aPattern_26_3e_26_3e_2ector(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t279, ptr %l222
  br label %bb83
bb83:
  %t280 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l222
  %t281 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t280, ptr %t281
  store ptr %t281, ptr %l27, !tbaa !29
  %t283 = load ptr, ptr %l1, !tbaa !29
  store ptr %t283, ptr %l28, !tbaa !29
  store i64 0, ptr %l29, !tbaa !24
  br label %bb84
bb84:
  store %olang.scope zeroinitializer, ptr %s18
  %t285 = load ptr, ptr %l28, !tbaa !29
  %t286 = load i64, ptr %l29, !tbaa !24
  %t289 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fast_3aPattern_26_H8f433a386540269ec523262b43568e5b(ptr %v1, ptr %t285, i64 %t286)
  %t290 = extractvalue { i32, { i64, ptr } } %t289, 1
  %t291 = extractvalue { i32, { i64, ptr } } %t289, 0
  store i32 %t291, ptr %l229
  %t292 = icmp ne i32 %t291, 0
  br i1 %t292, label %bb86, label %ok.293
ok.293:
  store { i64, ptr } %t290, ptr %l228
  br label %bb85
bb85:
  %t294 = load { i64, ptr }, ptr %l228, !tbaa !27
  store { i64, ptr } %t294, ptr %l225, !tbaa !27
  br label %bb90
bb86:
  %t295 = load i32, ptr %l229, !tbaa !23
  %t296 = ashr i32 %t295, 16
  %t298 = icmp eq i32 %t296, 1
  br i1 %t298, label %bb87, label %bb88
bb87:
  br label %bb89
bb88:
  call void @__olang_check_failed(ptr @olang_loc_db613885cc0e77fc_341778010d8262c8)
  unreachable
bb89:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s18)
  br label %bb112
bb90:
  %t300 = load { i64, ptr }, ptr %l225, !tbaa !27
  store { i64, ptr } %t300, ptr %l30, !tbaa !27
  %t301 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t303 = extractvalue { i64, ptr } %t301, 0
  store i64 %t303, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  br label %bb91
bb91:
  store %olang.scope zeroinitializer, ptr %s19
  %t305 = load i64, ptr %l32, !tbaa !24
  %t306 = load i64, ptr %l31, !tbaa !24
  %t309 = icmp slt i64 %t305, %t306
  %t311 = xor i1 %t309, true
  br i1 %t311, label %bb92, label %bb93
bb92:
  call void @__olang_scope_close(ptr %s19)
  br label %bb110
bb93:
  br label %bb94
bb94:
  %t313 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t313, ptr %l238, !tbaa !27
  %t314 = load i64, ptr %l32, !tbaa !24
  %t316 = getelementptr { i64, ptr }, ptr %l238, i32 0, i32 1
  %t317 = load ptr, ptr %t316, !tbaa !27
  %t318 = getelementptr { i64, ptr }, ptr %t317, i64 %t314
  %t319 = load { i64, ptr }, ptr %t318, !tbaa !37
  store { i64, ptr } %t319, ptr %l33, !tbaa !27
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t322 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t322, ptr %l242, !tbaa !27
  %t323 = getelementptr { i64, ptr }, ptr %l242, i32 0, i32 1
  %t324 = load ptr, ptr %t323, !tbaa !27
  %t325 = getelementptr ptr, ptr %t324, i64 0
  %t326 = load ptr, ptr %t325, !tbaa !39
  %t329 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatWild(ptr %v0, ptr %v1, ptr %t321, ptr %t326)
  store i1 %t329, ptr %l244
  br label %bb95
bb95:
  %t330 = load i1, ptr %l244, !tbaa !21
  br i1 %t330, label %bb96, label %bb97
bb96:
  store i1 true, ptr %l245, !tbaa !21
  br label %bb99
bb97:
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t332 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t332, ptr %l247, !tbaa !27
  %t333 = getelementptr { i64, ptr }, ptr %l247, i32 0, i32 1
  %t334 = load ptr, ptr %t333, !tbaa !27
  %t335 = getelementptr ptr, ptr %t334, i64 0
  %t336 = load ptr, ptr %t335, !tbaa !39
  %t339 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatBool(ptr %v0, ptr %v1, ptr %t331, ptr %t336)
  store i64 %t339, ptr %l249
  br label %bb98
bb98:
  %t340 = load i64, ptr %l26, !tbaa !24
  %t341 = load i64, ptr %l249, !tbaa !24
  %t343 = icmp eq i64 %t341, %t340
  store i1 %t343, ptr %l245, !tbaa !21
  br label %bb99
bb99:
  %t345 = load i1, ptr %l245, !tbaa !21
  br i1 %t345, label %bb100, label %bb101
bb100:
  %t346 = load ptr, ptr %l27, !tbaa !29
  store ptr %t346, ptr %l252, !tbaa !29
  %t347 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t347, ptr %l253, !tbaa !27
  %t348 = icmp sge i64 0, 0
  br i1 %t348, label %bb102, label %bb103
bb101:
  br label %bb108
bb102:
  %t350 = icmp sle i64 0, 1152921504606846975
  br i1 %t350, label %bb104, label %bb105
bb103:
  call void @__olang_check_failed(ptr @olang_loc_69828742111b34b6_edb4f3b8774a6d1a)
  unreachable
bb104:
  %t352 = mul i64 0, 8
  %t353 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t352)
  %t354 = insertvalue { i64, ptr } undef, i64 0, 0
  %t355 = insertvalue { i64, ptr } %t354, ptr %t353, 1
  %t356 = load { i64, ptr }, ptr %l253, !tbaa !27
  %t358 = call { i64, ptr } @compiler_2fcheck_2epatTail(ptr %v1, { i64, ptr } %t356, { i64, ptr } %t355, i64 0)
  store { i64, ptr } %t358, ptr %l257
  br label %bb106
bb105:
  call void @__olang_check_failed(ptr @olang_loc_69828742111b34b6_edb4f3b8774a6d1a)
  unreachable
bb106:
  %t359 = load ptr, ptr %l252, !tbaa !29
  %t360 = load { i64, ptr }, ptr %l257, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fast_3aPattern_26_H1d860e259259c4952a7ac353d360c942(ptr %v1, ptr %v1, ptr %t359, { i64, ptr } %t360)
  br label %bb107
bb107:
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s19)
  br label %bb109
bb109:
  %t361 = load i64, ptr %l32, !tbaa !24
  %t363 = add i64 %t361, 1
  store i64 %t363, ptr %l32, !tbaa !24
  br label %bb91
bb110:
  %t365 = load i64, ptr %l29, !tbaa !24
  %t366 = load i64, ptr %l31, !tbaa !24
  %t369 = add i64 %t365, %t366
  store i64 %t369, ptr %l29, !tbaa !24
  call void @__olang_scope_close(ptr %s18)
  br label %bb111
bb111:
  br label %bb84
bb112:
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t372 = load ptr, ptr %l27, !tbaa !29
  %t373 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t374 = load i64, ptr %l3, !tbaa !24
  %t376 = add i64 %t374, 1
  %t381 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecoversRows(ptr %v0, ptr %v1, ptr %v2, ptr %t371, ptr %t372, { i64, ptr } %t373, i64 %t376)
  store i1 %t381, ptr %l268
  br label %bb113
bb113:
  %t382 = load i1, ptr %l268, !tbaa !21
  %t383 = xor i1 %t382, true
  br i1 %t383, label %bb114, label %bb115
bb114:
  call void @__olang_scope_close(ptr %s16)
  store i1 false, ptr %rv
  br label %ret
bb115:
  br label %bb116
bb116:
  call void @__olang_scope_close(ptr %s16)
  br label %bb117
bb117:
  %t386 = load i64, ptr %l25, !tbaa !24
  %t388 = add i64 %t386, 1
  store i64 %t388, ptr %l25, !tbaa !24
  br label %bb79
bb118:
  store i1 true, ptr %rv
  br label %ret
bb119:
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t392 = load i32, ptr %l4, !tbaa !23
  %t395 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t391, i32 %t392)
  store i1 %t395, ptr %l276
  br label %bb120
bb120:
  %t396 = load i1, ptr %l276, !tbaa !21
  br i1 %t396, label %bb121, label %bb122
bb121:
  store %olang.scope zeroinitializer, ptr %s24
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t399 = getelementptr %"compiler/check:Checker", ptr %t397, i32 0, i32 1
  %t400 = load ptr, ptr %t399, !tbaa !29
  %t402 = getelementptr %"compiler/generic:Program", ptr %t400, i32 0, i32 2
  store ptr %t402, ptr %l279, !tbaa !29
  %t403 = load ptr, ptr %l0, !tbaa !29
  %t405 = getelementptr %"compiler/check:Checker", ptr %t403, i32 0, i32 1
  %t406 = load ptr, ptr %t405, !tbaa !29
  %t408 = getelementptr %"compiler/generic:Program", ptr %t406, i32 0, i32 2
  %t409 = load i32, ptr %l4, !tbaa !23
  %t412 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t408, i32 %t409)
  store i32 %t412, ptr %l284
  br label %bb123
bb122:
  br label %bb310
bb123:
  %t413 = load ptr, ptr %l279, !tbaa !29
  %t414 = load i32, ptr %l284, !tbaa !23
  %t415 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t413, i32 %t414)
  store { i64, ptr } %t415, ptr %l285
  br label %bb124
bb124:
  %t416 = load { i64, ptr }, ptr %l285, !tbaa !27
  %t417 = extractvalue { i64, ptr } %t416, 0
  store i64 %t417, ptr %l34, !tbaa !24
  %t419 = load i64, ptr %l34, !tbaa !24
  store i64 %t419, ptr %l287, !tbaa !24
  %t420 = load i64, ptr %l287, !tbaa !24
  %t421 = icmp sge i64 %t420, 0
  br i1 %t421, label %bb125, label %bb126
bb125:
  %t423 = load i64, ptr %l287, !tbaa !24
  %t424 = mul i64 %t423, 1
  %t425 = call ptr @__olang_scope_alloc_zeroed(ptr %s24, i64 %t424)
  %t426 = insertvalue { i64, ptr } undef, i64 %t423, 0
  %t427 = insertvalue { i64, ptr } %t426, ptr %t425, 1
  store { i64, ptr } %t427, ptr %l35, !tbaa !27
  %t429 = load ptr, ptr %l1, !tbaa !29
  store ptr %t429, ptr %l36, !tbaa !29
  store i64 0, ptr %l37, !tbaa !24
  br label %bb127
bb126:
  call void @__olang_check_failed(ptr @olang_loc_2c3f271c3afc79d5_c78bf0711ee6c699)
  unreachable
bb127:
  store %olang.scope zeroinitializer, ptr %s26
  %t431 = load ptr, ptr %l36, !tbaa !29
  %t432 = load i64, ptr %l37, !tbaa !24
  %t435 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fast_3aPattern_26_H8f433a386540269ec523262b43568e5b(ptr %v1, ptr %t431, i64 %t432)
  %t436 = extractvalue { i32, { i64, ptr } } %t435, 1
  %t437 = extractvalue { i32, { i64, ptr } } %t435, 0
  store i32 %t437, ptr %l295
  %t438 = icmp ne i32 %t437, 0
  br i1 %t438, label %bb129, label %ok.439
ok.439:
  store { i64, ptr } %t436, ptr %l294
  br label %bb128
bb128:
  %t440 = load { i64, ptr }, ptr %l294, !tbaa !27
  store { i64, ptr } %t440, ptr %l291, !tbaa !27
  br label %bb133
bb129:
  %t441 = load i32, ptr %l295, !tbaa !23
  %t442 = ashr i32 %t441, 16
  %t444 = icmp eq i32 %t442, 1
  br i1 %t444, label %bb130, label %bb131
bb130:
  br label %bb132
bb131:
  call void @__olang_check_failed(ptr @olang_loc_ee24f78eb0215db7_268ab47274f317a3)
  unreachable
bb132:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s26)
  br label %bb166
bb133:
  %t446 = load { i64, ptr }, ptr %l291, !tbaa !27
  store { i64, ptr } %t446, ptr %l38, !tbaa !27
  %t447 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t449 = extractvalue { i64, ptr } %t447, 0
  store i64 %t449, ptr %l39, !tbaa !24
  store i64 0, ptr %l40, !tbaa !24
  br label %bb134
bb134:
  store %olang.scope zeroinitializer, ptr %s27
  %t451 = load i64, ptr %l40, !tbaa !24
  %t452 = load i64, ptr %l39, !tbaa !24
  %t455 = icmp slt i64 %t451, %t452
  %t457 = xor i1 %t455, true
  br i1 %t457, label %bb135, label %bb136
bb135:
  call void @__olang_scope_close(ptr %s27)
  br label %bb164
bb136:
  br label %bb137
bb137:
  %t459 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t459, ptr %l304, !tbaa !27
  %t460 = load i64, ptr %l40, !tbaa !24
  %t462 = getelementptr { i64, ptr }, ptr %l304, i32 0, i32 1
  %t463 = load ptr, ptr %t462, !tbaa !27
  %t464 = getelementptr { i64, ptr }, ptr %t463, i64 %t460
  %t465 = load { i64, ptr }, ptr %t464, !tbaa !37
  store { i64, ptr } %t465, ptr %l307, !tbaa !27
  %t468 = getelementptr { i64, ptr }, ptr %l307, i32 0, i32 1
  %t469 = load ptr, ptr %t468, !tbaa !27
  %t470 = getelementptr ptr, ptr %t469, i64 0
  %t471 = load ptr, ptr %t470, !tbaa !39
  store ptr %t471, ptr %l42, !tbaa !29
  %t473 = load ptr, ptr %l42, !tbaa !29
  store ptr %t473, ptr %l309, !tbaa !29
  store i1 false, ptr %l310, !tbaa !21
  %t474 = load ptr, ptr %l309, !tbaa !29
  %t475 = icmp ne ptr %t474, null
  br i1 %t475, label %bb138, label %bb139
bb138:
  %t477 = load ptr, ptr %l309, !tbaa !29
  %t478 = load i64, ptr %t477
  %t480 = icmp eq i64 %t478, 1
  store i1 %t480, ptr %l310, !tbaa !21
  br label %bb139
bb139:
  %t481 = load i1, ptr %l310, !tbaa !21
  br i1 %t481, label %bb140, label %bb141
bb140:
  %t482 = load ptr, ptr %l42, !tbaa !29
  %t484 = getelementptr { i64, [4 x i64] }, ptr %t482, i32 0, i32 1
  %t485 = getelementptr { %"compiler/source:Span", ptr }, ptr %t484, i32 0, i32 1
  %t486 = load ptr, ptr %t485
  store ptr %t486, ptr %l43, !tbaa !29
  br label %bb146
bb141:
  %t488 = load ptr, ptr %l42, !tbaa !29
  store ptr %t488, ptr %l315, !tbaa !29
  store i1 false, ptr %l316, !tbaa !21
  %t489 = load ptr, ptr %l315, !tbaa !29
  %t490 = icmp ne ptr %t489, null
  br i1 %t490, label %bb142, label %bb143
bb142:
  %t492 = load ptr, ptr %l315, !tbaa !29
  %t493 = load i64, ptr %t492
  %t495 = icmp eq i64 %t493, 4
  store i1 %t495, ptr %l316, !tbaa !21
  br label %bb143
bb143:
  %t496 = load i1, ptr %l316, !tbaa !21
  br i1 %t496, label %bb144, label %bb145
bb144:
  %t497 = load ptr, ptr %l42, !tbaa !29
  %t499 = getelementptr { i64, [4 x i64] }, ptr %t497, i32 0, i32 1
  %t500 = getelementptr { %"compiler/source:Span", ptr }, ptr %t499, i32 0, i32 1
  %t501 = load ptr, ptr %t500
  store ptr %t501, ptr %l43, !tbaa !29
  br label %bb146
bb145:
  br label %bb151
bb146:
  %t503 = load ptr, ptr %l0, !tbaa !29
  %t504 = load ptr, ptr %l43, !tbaa !29
  %t505 = load i32, ptr %l4, !tbaa !23
  %t509 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %t503, ptr %t504, i32 %t505)
  store i64 %t509, ptr %l324
  br label %bb147
bb147:
  %t510 = load i64, ptr %l324, !tbaa !24
  store i64 %t510, ptr %l44, !tbaa !24
  %t511 = load i64, ptr %l44, !tbaa !24
  %t513 = icmp sge i64 %t511, 0
  br i1 %t513, label %bb148, label %bb149
bb148:
  %t515 = load i64, ptr %l44, !tbaa !24
  %t517 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t518 = load ptr, ptr %t517, !tbaa !27
  %t519 = getelementptr i1, ptr %t518, i64 %t515
  store i1 true, ptr %t519, !tbaa !31
  br label %bb150
bb149:
  br label %bb150
bb150:
  br label %bb162
bb151:
  %t520 = load ptr, ptr %l42, !tbaa !29
  store ptr %t520, ptr %l328, !tbaa !29
  store i1 false, ptr %l329, !tbaa !21
  %t521 = load ptr, ptr %l328, !tbaa !29
  %t522 = icmp ne ptr %t521, null
  br i1 %t522, label %bb152, label %bb153
bb152:
  %t524 = load ptr, ptr %l328, !tbaa !29
  %t525 = load i64, ptr %t524
  %t527 = icmp eq i64 %t525, 2
  store i1 %t527, ptr %l329, !tbaa !21
  br label %bb153
bb153:
  %t528 = load i1, ptr %l329, !tbaa !21
  br i1 %t528, label %bb154, label %bb155
bb154:
  %t529 = load ptr, ptr %l42, !tbaa !29
  %t531 = getelementptr { i64, [4 x i64] }, ptr %t529, i32 0, i32 1
  %t532 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t531, i32 0, i32 1
  %t533 = load ptr, ptr %t532
  store ptr %t533, ptr %l45, !tbaa !29
  br label %bb156
bb155:
  br label %bb161
bb156:
  %t535 = load ptr, ptr %l0, !tbaa !29
  %t536 = load ptr, ptr %l45, !tbaa !29
  %t537 = load i32, ptr %l4, !tbaa !23
  %t541 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %t535, ptr %t536, i32 %t537)
  store i64 %t541, ptr %l337
  br label %bb157
bb157:
  %t542 = load i64, ptr %l337, !tbaa !24
  store i64 %t542, ptr %l46, !tbaa !24
  %t543 = load i64, ptr %l46, !tbaa !24
  %t545 = icmp sge i64 %t543, 0
  br i1 %t545, label %bb158, label %bb159
bb158:
  %t547 = load i64, ptr %l46, !tbaa !24
  %t549 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t550 = load ptr, ptr %t549, !tbaa !27
  %t551 = getelementptr i1, ptr %t550, i64 %t547
  store i1 true, ptr %t551, !tbaa !31
  br label %bb160
bb159:
  br label %bb160
bb160:
  br label %bb162
bb161:
  br label %bb162
bb162:
  call void @__olang_scope_close(ptr %s27)
  br label %bb163
bb163:
  %t552 = load i64, ptr %l40, !tbaa !24
  %t554 = add i64 %t552, 1
  store i64 %t554, ptr %l40, !tbaa !24
  br label %bb134
bb164:
  %t556 = load i64, ptr %l37, !tbaa !24
  %t557 = load i64, ptr %l39, !tbaa !24
  %t560 = add i64 %t556, %t557
  store i64 %t560, ptr %l37, !tbaa !24
  call void @__olang_scope_close(ptr %s26)
  br label %bb165
bb165:
  br label %bb127
bb166:
  store i1 true, ptr %l47, !tbaa !21
  %t562 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t562, ptr %l48, !tbaa !27
  store i64 0, ptr %l49, !tbaa !24
  %t564 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t566 = extractvalue { i64, ptr } %t564, 0
  store i64 %t566, ptr %l50, !tbaa !24
  br label %bb167
bb167:
  store %olang.scope zeroinitializer, ptr %s35
  %t568 = load i64, ptr %l49, !tbaa !24
  %t569 = load i64, ptr %l50, !tbaa !24
  %t572 = icmp slt i64 %t568, %t569
  %t574 = xor i1 %t572, true
  br i1 %t574, label %bb168, label %bb169
bb168:
  call void @__olang_scope_close(ptr %s35)
  br label %bb175
bb169:
  br label %bb170
bb170:
  %t576 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t576, ptr %l353, !tbaa !27
  %t577 = load i64, ptr %l49, !tbaa !24
  %t579 = getelementptr { i64, ptr }, ptr %l353, i32 0, i32 1
  %t580 = load ptr, ptr %t579, !tbaa !27
  %t581 = getelementptr i1, ptr %t580, i64 %t577
  %t582 = load i1, ptr %t581, !tbaa !31
  %t586 = xor i1 %t582, true
  br i1 %t586, label %bb171, label %bb172
bb171:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb173
bb172:
  br label %bb173
bb173:
  call void @__olang_scope_close(ptr %s35)
  br label %bb174
bb174:
  %t588 = load i64, ptr %l49, !tbaa !24
  %t590 = add i64 %t588, 1
  store i64 %t590, ptr %l49, !tbaa !24
  br label %bb167
bb175:
  %t592 = load i1, ptr %l47, !tbaa !21
  %t594 = xor i1 %t592, true
  br i1 %t594, label %bb176, label %bb177
bb176:
  %t596 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3ccompiler_2fast_3aPattern_26_3e_26_3e_2ector(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t596, ptr %l362
  br label %bb178
bb177:
  br label %bb205
bb178:
  %t597 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l362
  %t598 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t597, ptr %t598
  store ptr %t598, ptr %l52, !tbaa !29
  %t600 = load ptr, ptr %l1, !tbaa !29
  store ptr %t600, ptr %l53, !tbaa !29
  store i64 0, ptr %l54, !tbaa !24
  br label %bb179
bb179:
  store %olang.scope zeroinitializer, ptr %s40
  %t602 = load ptr, ptr %l53, !tbaa !29
  %t603 = load i64, ptr %l54, !tbaa !24
  %t606 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fast_3aPattern_26_H8f433a386540269ec523262b43568e5b(ptr %v1, ptr %t602, i64 %t603)
  %t607 = extractvalue { i32, { i64, ptr } } %t606, 1
  %t608 = extractvalue { i32, { i64, ptr } } %t606, 0
  store i32 %t608, ptr %l369
  %t609 = icmp ne i32 %t608, 0
  br i1 %t609, label %bb181, label %ok.610
ok.610:
  store { i64, ptr } %t607, ptr %l368
  br label %bb180
bb180:
  %t611 = load { i64, ptr }, ptr %l368, !tbaa !27
  store { i64, ptr } %t611, ptr %l365, !tbaa !27
  br label %bb185
bb181:
  %t612 = load i32, ptr %l369, !tbaa !23
  %t613 = ashr i32 %t612, 16
  %t615 = icmp eq i32 %t613, 1
  br i1 %t615, label %bb182, label %bb183
bb182:
  br label %bb184
bb183:
  call void @__olang_check_failed(ptr @olang_loc_c469e1041e879ee8_15935166e400e15c)
  unreachable
bb184:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s40)
  br label %bb203
bb185:
  %t617 = load { i64, ptr }, ptr %l365, !tbaa !27
  store { i64, ptr } %t617, ptr %l55, !tbaa !27
  %t618 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t620 = extractvalue { i64, ptr } %t618, 0
  store i64 %t620, ptr %l56, !tbaa !24
  store i64 0, ptr %l57, !tbaa !24
  br label %bb186
bb186:
  store %olang.scope zeroinitializer, ptr %s41
  %t622 = load i64, ptr %l57, !tbaa !24
  %t623 = load i64, ptr %l56, !tbaa !24
  %t626 = icmp slt i64 %t622, %t623
  %t628 = xor i1 %t626, true
  br i1 %t628, label %bb187, label %bb188
bb187:
  call void @__olang_scope_close(ptr %s41)
  br label %bb201
bb188:
  br label %bb189
bb189:
  %t630 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t630, ptr %l378, !tbaa !27
  %t631 = load i64, ptr %l57, !tbaa !24
  %t633 = getelementptr { i64, ptr }, ptr %l378, i32 0, i32 1
  %t634 = load ptr, ptr %t633, !tbaa !27
  %t635 = getelementptr { i64, ptr }, ptr %t634, i64 %t631
  %t636 = load { i64, ptr }, ptr %t635, !tbaa !37
  store { i64, ptr } %t636, ptr %l58, !tbaa !27
  %t638 = load ptr, ptr %l0, !tbaa !29
  %t639 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t639, ptr %l382, !tbaa !27
  %t640 = getelementptr { i64, ptr }, ptr %l382, i32 0, i32 1
  %t641 = load ptr, ptr %t640, !tbaa !27
  %t642 = getelementptr ptr, ptr %t641, i64 0
  %t643 = load ptr, ptr %t642, !tbaa !39
  %t646 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatWild(ptr %v0, ptr %v1, ptr %t638, ptr %t643)
  store i1 %t646, ptr %l384
  br label %bb190
bb190:
  %t647 = load i1, ptr %l384, !tbaa !21
  br i1 %t647, label %bb191, label %bb192
bb191:
  %t648 = load ptr, ptr %l52, !tbaa !29
  store ptr %t648, ptr %l385, !tbaa !29
  %t649 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t649, ptr %l386, !tbaa !27
  %t650 = icmp sge i64 0, 0
  br i1 %t650, label %bb193, label %bb194
bb192:
  br label %bb199
bb193:
  %t652 = icmp sle i64 0, 1152921504606846975
  br i1 %t652, label %bb195, label %bb196
bb194:
  call void @__olang_check_failed(ptr @olang_loc_9b1757e0e026f0ba_88a812783a2cd816)
  unreachable
bb195:
  %t654 = mul i64 0, 8
  %t655 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t654)
  %t656 = insertvalue { i64, ptr } undef, i64 0, 0
  %t657 = insertvalue { i64, ptr } %t656, ptr %t655, 1
  %t658 = load { i64, ptr }, ptr %l386, !tbaa !27
  %t660 = call { i64, ptr } @compiler_2fcheck_2epatTail(ptr %v1, { i64, ptr } %t658, { i64, ptr } %t657, i64 0)
  store { i64, ptr } %t660, ptr %l390
  br label %bb197
bb196:
  call void @__olang_check_failed(ptr @olang_loc_9b1757e0e026f0ba_88a812783a2cd816)
  unreachable
bb197:
  %t661 = load ptr, ptr %l385, !tbaa !29
  %t662 = load { i64, ptr }, ptr %l390, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fast_3aPattern_26_H1d860e259259c4952a7ac353d360c942(ptr %v1, ptr %v1, ptr %t661, { i64, ptr } %t662)
  br label %bb198
bb198:
  br label %bb199
bb199:
  call void @__olang_scope_close(ptr %s41)
  br label %bb200
bb200:
  %t663 = load i64, ptr %l57, !tbaa !24
  %t665 = add i64 %t663, 1
  store i64 %t665, ptr %l57, !tbaa !24
  br label %bb186
bb201:
  %t667 = load i64, ptr %l54, !tbaa !24
  %t668 = load i64, ptr %l56, !tbaa !24
  %t671 = add i64 %t667, %t668
  store i64 %t671, ptr %l54, !tbaa !24
  call void @__olang_scope_close(ptr %s40)
  br label %bb202
bb202:
  br label %bb179
bb203:
  %t673 = load ptr, ptr %l0, !tbaa !29
  %t674 = load ptr, ptr %l52, !tbaa !29
  %t675 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t676 = load i64, ptr %l3, !tbaa !24
  %t678 = add i64 %t676, 1
  %t683 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecoversRows(ptr %v0, ptr %v1, ptr %v2, ptr %t673, ptr %t674, { i64, ptr } %t675, i64 %t678)
  store i1 %t683, ptr %l401
  br label %bb204
bb204:
  call void @__olang_scope_close(ptr %s24)
  %t684 = load i1, ptr %l401, !tbaa !21
  store i1 %t684, ptr %rv
  br label %ret
bb205:
  store i64 0, ptr %l59, !tbaa !24
  %t685 = load i64, ptr %l34, !tbaa !24
  store i64 %t685, ptr %l60, !tbaa !24
  store i64 1, ptr %l61, !tbaa !24
  %t687 = load i64, ptr %l60, !tbaa !24
  %t688 = load i64, ptr %l59, !tbaa !24
  %t691 = icmp sgt i64 %t687, %t688
  br i1 %t691, label %bb206, label %bb207
bb206:
  %t693 = load i64, ptr %l61, !tbaa !24
  %t695 = icmp sgt i64 %t693, 0
  br i1 %t695, label %bb208, label %bb209
bb207:
  store i64 0, ptr %l406, !tbaa !24
  br label %bb211
bb208:
  %t697 = load i64, ptr %l60, !tbaa !24
  %t698 = load i64, ptr %l59, !tbaa !24
  %t701 = sub i64 %t697, %t698
  %t702 = load i64, ptr %l61, !tbaa !24
  %t705 = add i64 %t701, %t702
  %t707 = sub i64 %t705, 1
  %t708 = load i64, ptr %l61, !tbaa !24
  %t711 = sdiv i64 %t707, %t708
  store i64 %t711, ptr %l409, !tbaa !24
  br label %bb210
bb209:
  store i64 0, ptr %l409, !tbaa !24
  br label %bb210
bb210:
  %t713 = load i64, ptr %l409, !tbaa !24
  store i64 %t713, ptr %l406, !tbaa !24
  br label %bb211
bb211:
  %t714 = load i64, ptr %l406, !tbaa !24
  store i64 %t714, ptr %l62, !tbaa !24
  store i64 0, ptr %l63, !tbaa !24
  br label %bb212
bb212:
  store %olang.scope zeroinitializer, ptr %s45
  %t715 = load i64, ptr %l63, !tbaa !24
  %t716 = load i64, ptr %l62, !tbaa !24
  %t719 = icmp slt i64 %t715, %t716
  %t721 = xor i1 %t719, true
  br i1 %t721, label %bb213, label %bb214
bb213:
  call void @__olang_scope_close(ptr %s45)
  br label %bb309
bb214:
  br label %bb215
bb215:
  %t723 = load i64, ptr %l59, !tbaa !24
  %t724 = load i64, ptr %l63, !tbaa !24
  %t725 = load i64, ptr %l61, !tbaa !24
  %t728 = mul i64 %t724, %t725
  %t731 = add i64 %t723, %t728
  store i64 %t731, ptr %l64, !tbaa !24
  %t733 = load ptr, ptr %l0, !tbaa !29
  %t735 = getelementptr %"compiler/check:Checker", ptr %t733, i32 0, i32 1
  %t736 = load ptr, ptr %t735, !tbaa !29
  %t737 = load i32, ptr %l4, !tbaa !23
  %t738 = load i64, ptr %l64, !tbaa !24
  %t742 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %t736, i32 %t737, i64 %t738)
  store i32 %t742, ptr %l431
  br label %bb216
bb216:
  %t743 = load i32, ptr %l431, !tbaa !23
  store i32 %t743, ptr %l65, !tbaa !23
  %t744 = load i32, ptr %l65, !tbaa !23
  %t745 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t748 = icmp ne i32 %t744, %t745
  br i1 %t748, label %bb217, label %bb218
bb217:
  %t750 = load ptr, ptr %l0, !tbaa !29
  %t752 = getelementptr %"compiler/check:Checker", ptr %t750, i32 0, i32 1
  %t753 = load ptr, ptr %t752, !tbaa !29
  %t755 = getelementptr %"compiler/generic:Program", ptr %t753, i32 0, i32 2
  store ptr %t755, ptr %l438, !tbaa !29
  %t756 = load ptr, ptr %l0, !tbaa !29
  %t758 = getelementptr %"compiler/check:Checker", ptr %t756, i32 0, i32 1
  %t759 = load ptr, ptr %t758, !tbaa !29
  %t761 = getelementptr %"compiler/generic:Program", ptr %t759, i32 0, i32 2
  %t762 = load i32, ptr %l65, !tbaa !23
  %t765 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t761, i32 %t762)
  store i32 %t765, ptr %l443
  br label %bb219
bb218:
  %t766 = icmp sge i64 0, 0
  br i1 %t766, label %bb221, label %bb222
bb219:
  %t768 = load ptr, ptr %l438, !tbaa !29
  %t769 = load i32, ptr %l443, !tbaa !23
  %t770 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t768, i32 %t769)
  store { i64, ptr } %t770, ptr %l444
  br label %bb220
bb220:
  %t771 = load { i64, ptr }, ptr %l444, !tbaa !27
  store { i64, ptr } %t771, ptr %l435, !tbaa !27
  br label %bb225
bb221:
  %t772 = icmp sle i64 0, 2305843009213693951
  br i1 %t772, label %bb223, label %bb224
bb222:
  call void @__olang_check_failed(ptr @olang_loc_68a324566e074144_ebe2d53601389a48)
  unreachable
bb223:
  %t774 = mul i64 0, 4
  %t775 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t774)
  %t776 = insertvalue { i64, ptr } undef, i64 0, 0
  %t777 = insertvalue { i64, ptr } %t776, ptr %t775, 1
  store { i64, ptr } %t777, ptr %l435, !tbaa !27
  br label %bb225
bb224:
  call void @__olang_check_failed(ptr @olang_loc_68a324566e074144_ebe2d53601389a48)
  unreachable
bb225:
  %t779 = load { i64, ptr }, ptr %l435, !tbaa !27
  store { i64, ptr } %t779, ptr %l66, !tbaa !27
  %t780 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %s45)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t780, ptr %l448
  br label %bb226
bb226:
  %t781 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l448
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t781, ptr %l67
  %t782 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t782, ptr %l68, !tbaa !27
  store i64 0, ptr %l69, !tbaa !24
  %t784 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t786 = extractvalue { i64, ptr } %t784, 0
  store i64 %t786, ptr %l70, !tbaa !24
  br label %bb227
bb227:
  store %olang.scope zeroinitializer, ptr %s47
  %t788 = load i64, ptr %l69, !tbaa !24
  %t789 = load i64, ptr %l70, !tbaa !24
  %t792 = icmp slt i64 %t788, %t789
  %t794 = xor i1 %t792, true
  br i1 %t794, label %bb228, label %bb229
bb228:
  call void @__olang_scope_close(ptr %s47)
  br label %bb233
bb229:
  br label %bb230
bb230:
  %t796 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t796, ptr %l456, !tbaa !27
  %t797 = load i64, ptr %l69, !tbaa !24
  %t799 = getelementptr { i64, ptr }, ptr %l456, i32 0, i32 1
  %t800 = load ptr, ptr %t799, !tbaa !27
  %t801 = getelementptr i32, ptr %t800, i64 %t797
  %t802 = load i32, ptr %t801, !tbaa !33
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s45, ptr %l67, i32 %t802)
  br label %bb231
bb231:
  call void @__olang_scope_close(ptr %s47)
  br label %bb232
bb232:
  %t807 = load i64, ptr %l69, !tbaa !24
  %t809 = add i64 %t807, 1
  store i64 %t809, ptr %l69, !tbaa !24
  br label %bb227
bb233:
  %t811 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t811, ptr %l72, !tbaa !27
  store i64 0, ptr %l73, !tbaa !24
  %t813 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t815 = extractvalue { i64, ptr } %t813, 0
  store i64 %t815, ptr %l74, !tbaa !24
  br label %bb234
bb234:
  store %olang.scope zeroinitializer, ptr %s50
  %t817 = load i64, ptr %l73, !tbaa !24
  %t818 = load i64, ptr %l74, !tbaa !24
  %t821 = icmp slt i64 %t817, %t818
  %t823 = xor i1 %t821, true
  br i1 %t823, label %bb235, label %bb236
bb235:
  call void @__olang_scope_close(ptr %s50)
  br label %bb240
bb236:
  br label %bb237
bb237:
  %t825 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t825, ptr %l470, !tbaa !27
  %t826 = load i64, ptr %l73, !tbaa !24
  %t828 = getelementptr { i64, ptr }, ptr %l470, i32 0, i32 1
  %t829 = load ptr, ptr %t828, !tbaa !27
  %t830 = getelementptr i32, ptr %t829, i64 %t826
  %t831 = load i32, ptr %t830, !tbaa !33
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s45, ptr %l67, i32 %t831)
  br label %bb238
bb238:
  call void @__olang_scope_close(ptr %s50)
  br label %bb239
bb239:
  %t836 = load i64, ptr %l73, !tbaa !24
  %t838 = add i64 %t836, 1
  store i64 %t838, ptr %l73, !tbaa !24
  br label %bb234
bb240:
  %t840 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3ccompiler_2fast_3aPattern_26_3e_26_3e_2ector(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t840, ptr %l477
  br label %bb241
bb241:
  %t841 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l477
  %t842 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t841, ptr %t842
  store ptr %t842, ptr %l76, !tbaa !29
  %t844 = load ptr, ptr %l1, !tbaa !29
  store ptr %t844, ptr %l77, !tbaa !29
  store i64 0, ptr %l78, !tbaa !24
  br label %bb242
bb242:
  store %olang.scope zeroinitializer, ptr %s53
  %t846 = load ptr, ptr %l77, !tbaa !29
  %t847 = load i64, ptr %l78, !tbaa !24
  %t850 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fast_3aPattern_26_H8f433a386540269ec523262b43568e5b(ptr %v1, ptr %t846, i64 %t847)
  %t851 = extractvalue { i32, { i64, ptr } } %t850, 1
  %t852 = extractvalue { i32, { i64, ptr } } %t850, 0
  store i32 %t852, ptr %l484
  %t853 = icmp ne i32 %t852, 0
  br i1 %t853, label %bb244, label %ok.854
ok.854:
  store { i64, ptr } %t851, ptr %l483
  br label %bb243
bb243:
  %t855 = load { i64, ptr }, ptr %l483, !tbaa !27
  store { i64, ptr } %t855, ptr %l480, !tbaa !27
  br label %bb248
bb244:
  %t856 = load i32, ptr %l484, !tbaa !23
  %t857 = ashr i32 %t856, 16
  %t859 = icmp eq i32 %t857, 1
  br i1 %t859, label %bb245, label %bb246
bb245:
  br label %bb247
bb246:
  call void @__olang_check_failed(ptr @olang_loc_c8bfc000fcc4ae6a_9e3397f9e2657b76)
  unreachable
bb247:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s53)
  br label %bb302
bb248:
  %t861 = load { i64, ptr }, ptr %l480, !tbaa !27
  store { i64, ptr } %t861, ptr %l79, !tbaa !27
  %t862 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t864 = extractvalue { i64, ptr } %t862, 0
  store i64 %t864, ptr %l80, !tbaa !24
  store i64 0, ptr %l81, !tbaa !24
  br label %bb249
bb249:
  store %olang.scope zeroinitializer, ptr %s54
  %t866 = load i64, ptr %l81, !tbaa !24
  %t867 = load i64, ptr %l80, !tbaa !24
  %t870 = icmp slt i64 %t866, %t867
  %t872 = xor i1 %t870, true
  br i1 %t872, label %bb250, label %bb251
bb250:
  call void @__olang_scope_close(ptr %s54)
  br label %bb300
bb251:
  br label %bb252
bb252:
  %t874 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t874, ptr %l493, !tbaa !27
  %t875 = load i64, ptr %l81, !tbaa !24
  %t877 = getelementptr { i64, ptr }, ptr %l493, i32 0, i32 1
  %t878 = load ptr, ptr %t877, !tbaa !27
  %t879 = getelementptr { i64, ptr }, ptr %t878, i64 %t875
  %t880 = load { i64, ptr }, ptr %t879, !tbaa !37
  store { i64, ptr } %t880, ptr %l82, !tbaa !27
  %t882 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t882, ptr %l496, !tbaa !27
  %t883 = getelementptr { i64, ptr }, ptr %l496, i32 0, i32 1
  %t884 = load ptr, ptr %t883, !tbaa !27
  %t885 = getelementptr ptr, ptr %t884, i64 0
  %t886 = load ptr, ptr %t885, !tbaa !39
  store ptr %t886, ptr %l83, !tbaa !29
  %t888 = load ptr, ptr %l0, !tbaa !29
  %t889 = load ptr, ptr %l83, !tbaa !29
  %t892 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatWild(ptr %v0, ptr %v1, ptr %t888, ptr %t889)
  store i1 %t892, ptr %l500
  br label %bb253
bb253:
  %t893 = load i1, ptr %l500, !tbaa !21
  br i1 %t893, label %bb254, label %bb255
bb254:
  %t894 = load ptr, ptr %l76, !tbaa !29
  store ptr %t894, ptr %l501, !tbaa !29
  %t895 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t895, ptr %l502, !tbaa !27
  %t896 = icmp sge i64 0, 0
  br i1 %t896, label %bb256, label %bb257
bb255:
  br label %bb262
bb256:
  %t898 = icmp sle i64 0, 1152921504606846975
  br i1 %t898, label %bb258, label %bb259
bb257:
  call void @__olang_check_failed(ptr @olang_loc_1f7873e3e1cd0232_cbe2b7e345defe96)
  unreachable
bb258:
  %t900 = mul i64 0, 8
  %t901 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t900)
  %t902 = insertvalue { i64, ptr } undef, i64 0, 0
  %t903 = insertvalue { i64, ptr } %t902, ptr %t901, 1
  %t904 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t906 = extractvalue { i64, ptr } %t904, 0
  %t907 = load { i64, ptr }, ptr %l502, !tbaa !27
  %t910 = call { i64, ptr } @compiler_2fcheck_2epatTail(ptr %v1, { i64, ptr } %t907, { i64, ptr } %t903, i64 %t906)
  store { i64, ptr } %t910, ptr %l508
  br label %bb260
bb259:
  call void @__olang_check_failed(ptr @olang_loc_1f7873e3e1cd0232_cbe2b7e345defe96)
  unreachable
bb260:
  %t911 = load ptr, ptr %l501, !tbaa !29
  %t912 = load { i64, ptr }, ptr %l508, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fast_3aPattern_26_H1d860e259259c4952a7ac353d360c942(ptr %v1, ptr %v1, ptr %t911, { i64, ptr } %t912)
  br label %bb261
bb261:
  call void @__olang_scope_close(ptr %s54)
  br label %bb299
bb262:
  %t913 = load ptr, ptr %l83, !tbaa !29
  store ptr %t913, ptr %l509, !tbaa !29
  store i1 false, ptr %l510, !tbaa !21
  %t914 = load ptr, ptr %l509, !tbaa !29
  %t915 = icmp ne ptr %t914, null
  br i1 %t915, label %bb263, label %bb264
bb263:
  %t917 = load ptr, ptr %l509, !tbaa !29
  %t918 = load i64, ptr %t917
  %t920 = icmp eq i64 %t918, 1
  store i1 %t920, ptr %l510, !tbaa !21
  br label %bb264
bb264:
  %t921 = load i1, ptr %l510, !tbaa !21
  br i1 %t921, label %bb265, label %bb266
bb265:
  %t922 = load ptr, ptr %l83, !tbaa !29
  %t924 = getelementptr { i64, [4 x i64] }, ptr %t922, i32 0, i32 1
  %t925 = getelementptr { %"compiler/source:Span", ptr }, ptr %t924, i32 0, i32 1
  %t926 = load ptr, ptr %t925
  store ptr %t926, ptr %l84, !tbaa !29
  br label %bb271
bb266:
  %t928 = load ptr, ptr %l83, !tbaa !29
  store ptr %t928, ptr %l515, !tbaa !29
  store i1 false, ptr %l516, !tbaa !21
  %t929 = load ptr, ptr %l515, !tbaa !29
  %t930 = icmp ne ptr %t929, null
  br i1 %t930, label %bb267, label %bb268
bb267:
  %t932 = load ptr, ptr %l515, !tbaa !29
  %t933 = load i64, ptr %t932
  %t935 = icmp eq i64 %t933, 4
  store i1 %t935, ptr %l516, !tbaa !21
  br label %bb268
bb268:
  %t936 = load i1, ptr %l516, !tbaa !21
  br i1 %t936, label %bb269, label %bb270
bb269:
  %t937 = load ptr, ptr %l83, !tbaa !29
  %t939 = getelementptr { i64, [4 x i64] }, ptr %t937, i32 0, i32 1
  %t940 = getelementptr { %"compiler/source:Span", ptr }, ptr %t939, i32 0, i32 1
  %t941 = load ptr, ptr %t940
  store ptr %t941, ptr %l84, !tbaa !29
  br label %bb271
bb270:
  br label %bb282
bb271:
  %t943 = load ptr, ptr %l0, !tbaa !29
  %t944 = load ptr, ptr %l84, !tbaa !29
  %t945 = load i32, ptr %l4, !tbaa !23
  %t949 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %t943, ptr %t944, i32 %t945)
  store i64 %t949, ptr %l524
  br label %bb272
bb272:
  %t950 = load i64, ptr %l64, !tbaa !24
  %t951 = load i64, ptr %l524, !tbaa !24
  %t953 = icmp eq i64 %t951, %t950
  br i1 %t953, label %bb273, label %bb274
bb273:
  %t955 = load ptr, ptr %l76, !tbaa !29
  store ptr %t955, ptr %l527, !tbaa !29
  %t956 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t956, ptr %l528, !tbaa !27
  %t957 = icmp sge i64 0, 0
  br i1 %t957, label %bb275, label %bb276
bb274:
  br label %bb281
bb275:
  %t959 = icmp sle i64 0, 1152921504606846975
  br i1 %t959, label %bb277, label %bb278
bb276:
  call void @__olang_check_failed(ptr @olang_loc_10c0ac77dd4c1e27_6e0957eb7284aeab)
  unreachable
bb277:
  %t961 = mul i64 0, 8
  %t962 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t961)
  %t963 = insertvalue { i64, ptr } undef, i64 0, 0
  %t964 = insertvalue { i64, ptr } %t963, ptr %t962, 1
  %t965 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t967 = extractvalue { i64, ptr } %t965, 0
  %t968 = load { i64, ptr }, ptr %l528, !tbaa !27
  %t971 = call { i64, ptr } @compiler_2fcheck_2epatTail(ptr %v1, { i64, ptr } %t968, { i64, ptr } %t964, i64 %t967)
  store { i64, ptr } %t971, ptr %l534
  br label %bb279
bb278:
  call void @__olang_check_failed(ptr @olang_loc_10c0ac77dd4c1e27_6e0957eb7284aeab)
  unreachable
bb279:
  %t972 = load ptr, ptr %l527, !tbaa !29
  %t973 = load { i64, ptr }, ptr %l534, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fast_3aPattern_26_H1d860e259259c4952a7ac353d360c942(ptr %v1, ptr %v1, ptr %t972, { i64, ptr } %t973)
  br label %bb280
bb280:
  br label %bb281
bb281:
  br label %bb298
bb282:
  %t974 = load ptr, ptr %l83, !tbaa !29
  store ptr %t974, ptr %l535, !tbaa !29
  store i1 false, ptr %l536, !tbaa !21
  %t975 = load ptr, ptr %l535, !tbaa !29
  %t976 = icmp ne ptr %t975, null
  br i1 %t976, label %bb283, label %bb284
bb283:
  %t978 = load ptr, ptr %l535, !tbaa !29
  %t979 = load i64, ptr %t978
  %t981 = icmp eq i64 %t979, 2
  store i1 %t981, ptr %l536, !tbaa !21
  br label %bb284
bb284:
  %t982 = load i1, ptr %l536, !tbaa !21
  br i1 %t982, label %bb285, label %bb286
bb285:
  %t983 = load ptr, ptr %l83, !tbaa !29
  %t985 = getelementptr { i64, [4 x i64] }, ptr %t983, i32 0, i32 1
  %t986 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t985, i32 0, i32 1
  %t987 = load ptr, ptr %t986
  store ptr %t987, ptr %l85, !tbaa !29
  %t989 = load ptr, ptr %l83, !tbaa !29
  %t991 = getelementptr { i64, [4 x i64] }, ptr %t989, i32 0, i32 1
  %t992 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t991, i32 0, i32 2
  %t993 = load { i64, ptr }, ptr %t992
  store { i64, ptr } %t993, ptr %l86, !tbaa !27
  br label %bb287
bb286:
  br label %bb297
bb287:
  %t995 = load ptr, ptr %l0, !tbaa !29
  %t996 = load ptr, ptr %l85, !tbaa !29
  %t997 = load i32, ptr %l4, !tbaa !23
  %t1001 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %t995, ptr %t996, i32 %t997)
  store i64 %t1001, ptr %l546
  br label %bb288
bb288:
  %t1002 = load i64, ptr %l64, !tbaa !24
  %t1003 = load i64, ptr %l546, !tbaa !24
  %t1005 = icmp eq i64 %t1003, %t1002
  br i1 %t1005, label %bb289, label %bb290
bb289:
  %t1007 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t1009 = extractvalue { i64, ptr } %t1007, 0
  %t1010 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t1012 = extractvalue { i64, ptr } %t1010, 0
  %t1015 = icmp eq i64 %t1009, %t1012
  store i1 %t1015, ptr %l549, !tbaa !21
  br label %bb291
bb290:
  store i1 false, ptr %l549, !tbaa !21
  br label %bb291
bb291:
  %t1017 = load i1, ptr %l549, !tbaa !21
  br i1 %t1017, label %bb292, label %bb293
bb292:
  %t1018 = load ptr, ptr %l76, !tbaa !29
  store ptr %t1018, ptr %l555, !tbaa !29
  %t1019 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t1020 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t1023 = call { i64, ptr } @compiler_2fcheck_2epatTail(ptr %v1, { i64, ptr } %t1019, { i64, ptr } %t1020, i64 0)
  store { i64, ptr } %t1023, ptr %l558
  br label %bb294
bb293:
  br label %bb296
bb294:
  %t1024 = load ptr, ptr %l555, !tbaa !29
  %t1025 = load { i64, ptr }, ptr %l558, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fast_3aPattern_26_H1d860e259259c4952a7ac353d360c942(ptr %v1, ptr %v1, ptr %t1024, { i64, ptr } %t1025)
  br label %bb295
bb295:
  br label %bb296
bb296:
  br label %bb298
bb297:
  br label %bb298
bb298:
  call void @__olang_scope_close(ptr %s54)
  br label %bb299
bb299:
  %t1026 = load i64, ptr %l81, !tbaa !24
  %t1028 = add i64 %t1026, 1
  store i64 %t1028, ptr %l81, !tbaa !24
  br label %bb249
bb300:
  %t1030 = load i64, ptr %l78, !tbaa !24
  %t1031 = load i64, ptr %l80, !tbaa !24
  %t1034 = add i64 %t1030, %t1031
  store i64 %t1034, ptr %l78, !tbaa !24
  call void @__olang_scope_close(ptr %s53)
  br label %bb301
bb301:
  br label %bb242
bb302:
  %t1036 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1036, ptr %l564, !tbaa !29
  %t1037 = load ptr, ptr %l76, !tbaa !29
  store ptr %t1037, ptr %l565, !tbaa !29
  %t1039 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eToAr_H9d0f958437b2bc29fe1d416dfb9901d7(ptr %s45, ptr %s45, ptr %l67)
  store { i64, ptr } %t1039, ptr %l567
  br label %bb303
bb303:
  %t1040 = load i64, ptr %l3, !tbaa !24
  %t1042 = add i64 %t1040, 1
  %t1043 = load ptr, ptr %l564, !tbaa !29
  %t1044 = load ptr, ptr %l565, !tbaa !29
  %t1045 = load { i64, ptr }, ptr %l567, !tbaa !27
  %t1047 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecoversRows(ptr %v0, ptr %v1, ptr %s45, ptr %t1043, ptr %t1044, { i64, ptr } %t1045, i64 %t1042)
  store i1 %t1047, ptr %l570
  br label %bb304
bb304:
  %t1048 = load i1, ptr %l570, !tbaa !21
  %t1049 = xor i1 %t1048, true
  br i1 %t1049, label %bb305, label %bb306
bb305:
  call void @__olang_scope_close(ptr %s45)
  call void @__olang_scope_close(ptr %s24)
  store i1 false, ptr %rv
  br label %ret
bb306:
  br label %bb307
bb307:
  call void @__olang_scope_close(ptr %s45)
  br label %bb308
bb308:
  %t1052 = load i64, ptr %l63, !tbaa !24
  %t1054 = add i64 %t1052, 1
  store i64 %t1054, ptr %l63, !tbaa !24
  br label %bb212
bb309:
  call void @__olang_scope_close(ptr %s24)
  store i1 true, ptr %rv
  br label %ret
bb310:
  %t1057 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3ccompiler_2fast_3aPattern_26_3e_26_3e_2ector(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1057, ptr %l576
  br label %bb311
bb311:
  %t1058 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l576
  %t1059 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1058, ptr %t1059
  store ptr %t1059, ptr %l87, !tbaa !29
  %t1061 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1061, ptr %l88, !tbaa !29
  store i64 0, ptr %l89, !tbaa !24
  br label %bb312
bb312:
  store %olang.scope zeroinitializer, ptr %s65
  %t1063 = load ptr, ptr %l88, !tbaa !29
  %t1064 = load i64, ptr %l89, !tbaa !24
  %t1067 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fast_3aPattern_26_H8f433a386540269ec523262b43568e5b(ptr %v1, ptr %t1063, i64 %t1064)
  %t1068 = extractvalue { i32, { i64, ptr } } %t1067, 1
  %t1069 = extractvalue { i32, { i64, ptr } } %t1067, 0
  store i32 %t1069, ptr %l583
  %t1070 = icmp ne i32 %t1069, 0
  br i1 %t1070, label %bb314, label %ok.1071
ok.1071:
  store { i64, ptr } %t1068, ptr %l582
  br label %bb313
bb313:
  %t1072 = load { i64, ptr }, ptr %l582, !tbaa !27
  store { i64, ptr } %t1072, ptr %l579, !tbaa !27
  br label %bb318
bb314:
  %t1073 = load i32, ptr %l583, !tbaa !23
  %t1074 = ashr i32 %t1073, 16
  %t1076 = icmp eq i32 %t1074, 1
  br i1 %t1076, label %bb315, label %bb316
bb315:
  br label %bb317
bb316:
  call void @__olang_check_failed(ptr @olang_loc_d83bd091a88cb87_23defb1826edd97b)
  unreachable
bb317:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s65)
  br label %bb336
bb318:
  %t1078 = load { i64, ptr }, ptr %l579, !tbaa !27
  store { i64, ptr } %t1078, ptr %l90, !tbaa !27
  %t1079 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t1081 = extractvalue { i64, ptr } %t1079, 0
  store i64 %t1081, ptr %l91, !tbaa !24
  store i64 0, ptr %l92, !tbaa !24
  br label %bb319
bb319:
  store %olang.scope zeroinitializer, ptr %s66
  %t1083 = load i64, ptr %l92, !tbaa !24
  %t1084 = load i64, ptr %l91, !tbaa !24
  %t1087 = icmp slt i64 %t1083, %t1084
  %t1089 = xor i1 %t1087, true
  br i1 %t1089, label %bb320, label %bb321
bb320:
  call void @__olang_scope_close(ptr %s66)
  br label %bb334
bb321:
  br label %bb322
bb322:
  %t1091 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t1091, ptr %l592, !tbaa !27
  %t1092 = load i64, ptr %l92, !tbaa !24
  %t1094 = getelementptr { i64, ptr }, ptr %l592, i32 0, i32 1
  %t1095 = load ptr, ptr %t1094, !tbaa !27
  %t1096 = getelementptr { i64, ptr }, ptr %t1095, i64 %t1092
  %t1097 = load { i64, ptr }, ptr %t1096, !tbaa !37
  store { i64, ptr } %t1097, ptr %l93, !tbaa !27
  %t1099 = load ptr, ptr %l0, !tbaa !29
  %t1100 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t1100, ptr %l596, !tbaa !27
  %t1101 = getelementptr { i64, ptr }, ptr %l596, i32 0, i32 1
  %t1102 = load ptr, ptr %t1101, !tbaa !27
  %t1103 = getelementptr ptr, ptr %t1102, i64 0
  %t1104 = load ptr, ptr %t1103, !tbaa !39
  %t1107 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatWild(ptr %v0, ptr %v1, ptr %t1099, ptr %t1104)
  store i1 %t1107, ptr %l598
  br label %bb323
bb323:
  %t1108 = load i1, ptr %l598, !tbaa !21
  br i1 %t1108, label %bb324, label %bb325
bb324:
  %t1109 = load ptr, ptr %l87, !tbaa !29
  store ptr %t1109, ptr %l599, !tbaa !29
  %t1110 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t1110, ptr %l600, !tbaa !27
  %t1111 = icmp sge i64 0, 0
  br i1 %t1111, label %bb326, label %bb327
bb325:
  br label %bb332
bb326:
  %t1113 = icmp sle i64 0, 1152921504606846975
  br i1 %t1113, label %bb328, label %bb329
bb327:
  call void @__olang_check_failed(ptr @olang_loc_e3488d8cce1d625_34e222cdaeebf5a1)
  unreachable
bb328:
  %t1115 = mul i64 0, 8
  %t1116 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t1115)
  %t1117 = insertvalue { i64, ptr } undef, i64 0, 0
  %t1118 = insertvalue { i64, ptr } %t1117, ptr %t1116, 1
  %t1119 = load { i64, ptr }, ptr %l600, !tbaa !27
  %t1121 = call { i64, ptr } @compiler_2fcheck_2epatTail(ptr %v1, { i64, ptr } %t1119, { i64, ptr } %t1118, i64 0)
  store { i64, ptr } %t1121, ptr %l604
  br label %bb330
bb329:
  call void @__olang_check_failed(ptr @olang_loc_e3488d8cce1d625_34e222cdaeebf5a1)
  unreachable
bb330:
  %t1122 = load ptr, ptr %l599, !tbaa !29
  %t1123 = load { i64, ptr }, ptr %l604, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fast_3aPattern_26_H1d860e259259c4952a7ac353d360c942(ptr %v1, ptr %v1, ptr %t1122, { i64, ptr } %t1123)
  br label %bb331
bb331:
  br label %bb332
bb332:
  call void @__olang_scope_close(ptr %s66)
  br label %bb333
bb333:
  %t1124 = load i64, ptr %l92, !tbaa !24
  %t1126 = add i64 %t1124, 1
  store i64 %t1126, ptr %l92, !tbaa !24
  br label %bb319
bb334:
  %t1128 = load i64, ptr %l89, !tbaa !24
  %t1129 = load i64, ptr %l91, !tbaa !24
  %t1132 = add i64 %t1128, %t1129
  store i64 %t1132, ptr %l89, !tbaa !24
  call void @__olang_scope_close(ptr %s65)
  br label %bb335
bb335:
  br label %bb312
bb336:
  %t1134 = load ptr, ptr %l0, !tbaa !29
  %t1135 = load ptr, ptr %l87, !tbaa !29
  %t1136 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t1137 = load i64, ptr %l3, !tbaa !24
  %t1139 = add i64 %t1137, 1
  %t1144 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecoversRows(ptr %v0, ptr %v1, ptr %v2, ptr %t1134, ptr %t1135, { i64, ptr } %t1136, i64 %t1139)
  store i1 %t1144, ptr %l615
  br label %bb337
bb337:
  %t1145 = load i1, ptr %l615, !tbaa !21
  store i1 %t1145, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectSourceOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i64
  %lp11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca ptr
  %l24 = alloca ptr
  %l33 = alloca i64
  %l37 = alloca ptr
  %l49 = alloca ptr
  %l51 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l58 = alloca i64
  %l62 = alloca { i64, ptr }
  %l65 = alloca %"compiler/check:ctSource"
  %l75 = alloca i32
  %l79 = alloca ptr
  %l82 = alloca i1
  %l91 = alloca i64
  %l95 = alloca { i64, ptr }
  %l99 = alloca ptr
  %l100 = alloca i1
  %l108 = alloca i1
  %l132 = alloca %"compiler/check:ctSource"
  %l134 = alloca ptr
  %l135 = alloca i1
  %l142 = alloca i1
  %l160 = alloca %"compiler/check:ctSource"
  %l167 = alloca ptr
  %l171 = alloca { i64, ptr }
  %l172 = alloca { i64, ptr }
  %l175 = alloca ptr
  %l178 = alloca i1
  %l186 = alloca ptr
  %l190 = alloca { i64, ptr }
  %l191 = alloca { i64, ptr }
  %l194 = alloca i32
  %l205 = alloca %"compiler/ast:Param"
  %l213 = alloca ptr
  %l214 = alloca ptr
  %l217 = alloca { i64, ptr }
  %l222 = alloca i64
  %l225 = alloca { i64, ptr }
  %l229 = alloca { i64, ptr }
  %l232 = alloca %"compiler/check:ctSource"
  %s12 = alloca %olang.scope
  %rv = alloca ptr
  %t433 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 11
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l24
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l24, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 1
  %t11 = load { i64, [2 x i64] }, ptr %t10
  store { i64, [2 x i64] } %t11, ptr %l2
  %t13 = load { i64, [2 x i64] }, ptr %l2
  %t15 = extractvalue { i64, [2 x i64] } %t13, 0
  %t16 = icmp eq i64 %t15, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t19 = getelementptr { i64 }, ptr %t18, i32 0, i32 0
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l3, !tbaa !24
  br label %bb4
bb3:
  br label %bb16
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t25, i64 %t26)
  store i64 %t29, ptr %l33
  br label %bb5
bb5:
  %t30 = load i64, ptr %l33, !tbaa !24
  store i64 %t30, ptr %l4, !tbaa !24
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t35 = load i64, ptr %l4, !tbaa !24
  %t38 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t34, i64 %t35)
  store ptr %t38, ptr %l37
  br label %bb6
bb6:
  %t39 = load ptr, ptr %l37, !tbaa !29
  store ptr %t39, ptr %l5, !tbaa !29
  %t40 = load ptr, ptr %l5, !tbaa !29
  %t42 = getelementptr %"compiler/ast:Func", ptr %t40, i32 0, i32 3
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/ast:Sig", ptr %t43, i32 0, i32 5
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = icmp eq ptr %t46, null
  br i1 %t48, label %bb7, label %bb8
bb7:
  store ptr null, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t51 = load ptr, ptr %l5, !tbaa !29
  %t53 = getelementptr %"compiler/ast:Func", ptr %t51, i32 0, i32 3
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/ast:Sig", ptr %t54, i32 0, i32 5
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = icmp eq ptr %t57, null
  br i1 %t59, label %bb10, label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_700945490095e3ab_b793fb317cfa4b47)
  unreachable
bb11:
  br label %bb12
bb12:
  %t61 = load ptr, ptr %l5, !tbaa !29
  %t63 = getelementptr %"compiler/ast:Func", ptr %t61, i32 0, i32 3
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = getelementptr %"compiler/ast:Sig", ptr %t64, i32 0, i32 5
  %t67 = load ptr, ptr %t66, !tbaa !29
  store ptr %t67, ptr %l49, !tbaa !29
  %t68 = load ptr, ptr %l5, !tbaa !29
  %t70 = getelementptr %"compiler/ast:Func", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  store ptr %t71, ptr %l51, !tbaa !29
  %t72 = load ptr, ptr %l5, !tbaa !29
  %t74 = getelementptr %"compiler/ast:Func", ptr %t72, i32 0, i32 3
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t77 = getelementptr %"compiler/ast:Sig", ptr %t75, i32 0, i32 0
  %t78 = load { i64, ptr }, ptr %t77, !tbaa !27
  store { i64, ptr } %t78, ptr %l54, !tbaa !27
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t83 = load i64, ptr %l4, !tbaa !24
  %t86 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t82, i64 %t83)
  store i64 %t86, ptr %l58
  br label %bb13
bb13:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l5, !tbaa !29
  %t90 = getelementptr %"compiler/ast:Func", ptr %t88, i32 0, i32 2
  %t91 = load i32, ptr %t90, !tbaa !23
  %t94 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t87, i32 %t91)
  store { i64, ptr } %t94, ptr %l62
  br label %bb14
bb14:
  %t95 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t95, 1
  %t97 = extractvalue { i64, ptr } %t95, 0
  %t98 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t97)
  call void @olang_textcopy(ptr %t98, ptr %t96, i64 %t97)
  %t99 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = extractvalue { i64, ptr } %t100, 1
  %t104 = mul i64 %t102, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t104)
  call void @llvm.memcpy.p0.p0.i64(ptr %t105, ptr %t103, i64 %t104, i1 false)
  %t106 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  %t108 = load ptr, ptr %l49, !tbaa !29
  %t109 = load ptr, ptr %l51, !tbaa !29
  %t110 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t111 = load i64, ptr %l58, !tbaa !24
  %t113 = call %"compiler/check:ctSource" @compiler_2fcheck_3actSource_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t108, ptr %t109, { i64, ptr } %t110, i64 %t111, { i64, ptr } %t107)
  store %"compiler/check:ctSource" %t113, ptr %l65
  br label %bb15
bb15:
  %t114 = load %"compiler/check:ctSource", ptr %l65
  %t115 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/check:ctSource" %t114, ptr %t115
  store ptr %t115, ptr %rv
  br label %ret
bb16:
  %t117 = load { i64, [2 x i64] }, ptr %l2
  %t119 = extractvalue { i64, [2 x i64] } %t117, 0
  %t120 = icmp eq i64 %t119, 1
  br i1 %t120, label %bb17, label %bb18
bb17:
  %t122 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t123 = getelementptr { i32, i32 }, ptr %t122, i32 0, i32 0
  %t124 = load i32, ptr %t123
  store i32 %t124, ptr %l6, !tbaa !23
  %t126 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t127 = getelementptr { i32, i32 }, ptr %t126, i32 0, i32 1
  %t128 = load i32, ptr %t127
  store i32 %t128, ptr %l7, !tbaa !23
  br label %bb19
bb18:
  br label %bb68
bb19:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/check:Checker", ptr %t130, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t135 = getelementptr %"compiler/generic:Program", ptr %t133, i32 0, i32 2
  %t136 = load i32, ptr %l6, !tbaa !23
  %t139 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t135, i32 %t136)
  store i32 %t139, ptr %l75
  br label %bb20
bb20:
  %t140 = load i32, ptr %l75, !tbaa !23
  store i32 %t140, ptr %l8, !tbaa !23
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/check:Checker", ptr %t141, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t145 = load i32, ptr %l8, !tbaa !23
  %t148 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t144, i32 %t145)
  store ptr %t148, ptr %l79
  br label %bb21
bb21:
  %t149 = load ptr, ptr %l79, !tbaa !29
  store ptr %t149, ptr %l9, !tbaa !29
  %t150 = load ptr, ptr %l9, !tbaa !29
  %t152 = icmp eq ptr %t150, null
  br i1 %t152, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l82, !tbaa !21
  br label %bb24
bb23:
  %t154 = load ptr, ptr %l9, !tbaa !29
  %t156 = getelementptr %"compiler/ast:TypeDecl", ptr %t154, i32 0, i32 3
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t159 = icmp eq ptr %t157, null
  store i1 %t159, ptr %l82, !tbaa !21
  br label %bb24
bb24:
  %t161 = load i1, ptr %l82, !tbaa !21
  br i1 %t161, label %bb25, label %bb26
bb25:
  store ptr null, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/check:Checker", ptr %t163, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !29
  %t168 = getelementptr %"compiler/generic:Program", ptr %t166, i32 0, i32 2
  %t169 = load i32, ptr %l8, !tbaa !23
  %t172 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t168, i32 %t169)
  store i64 %t172, ptr %l91
  br label %bb28
bb28:
  %t173 = load i64, ptr %l91, !tbaa !24
  store i64 %t173, ptr %l10, !tbaa !24
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load ptr, ptr %l9, !tbaa !29
  %t177 = getelementptr %"compiler/ast:TypeDecl", ptr %t175, i32 0, i32 0
  %t178 = load i32, ptr %t177, !tbaa !23
  %t181 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t174, i32 %t178)
  store { i64, ptr } %t181, ptr %l95
  br label %bb29
bb29:
  %t182 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t182, 1
  %t184 = extractvalue { i64, ptr } %t182, 0
  %t185 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t184)
  call void @olang_textcopy(ptr %t185, ptr %t183, i64 %t184)
  %t186 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t185, 1
  %t188 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t188, ptr %lp11
  %t190 = load ptr, ptr %lp11
  store { i64, ptr } %t187, ptr %t190, !tbaa !27
  %t191 = load ptr, ptr %l9, !tbaa !29
  %t193 = getelementptr %"compiler/ast:TypeDecl", ptr %t191, i32 0, i32 3
  %t194 = load ptr, ptr %t193, !tbaa !29
  store ptr %t194, ptr %l12, !tbaa !29
  %t196 = load ptr, ptr %l12, !tbaa !29
  store ptr %t196, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t197 = load ptr, ptr %l99, !tbaa !29
  %t198 = icmp ne ptr %t197, null
  br i1 %t198, label %bb30, label %bb31
bb30:
  %t200 = load ptr, ptr %l99, !tbaa !29
  %t201 = load i64, ptr %t200
  %t203 = icmp eq i64 %t201, 0
  store i1 %t203, ptr %l100, !tbaa !21
  br label %bb31
bb31:
  %t204 = load i1, ptr %l100, !tbaa !21
  br i1 %t204, label %bb32, label %bb33
bb32:
  %t205 = load ptr, ptr %l12, !tbaa !29
  %t207 = getelementptr { i64, [6 x i64] }, ptr %t205, i32 0, i32 1
  %t208 = getelementptr { ptr }, ptr %t207, i32 0, i32 0
  %t209 = load ptr, ptr %t208
  store ptr %t209, ptr %l13, !tbaa !29
  br label %bb34
bb33:
  br label %bb51
bb34:
  %t211 = load ptr, ptr %l13, !tbaa !29
  %t213 = getelementptr %"compiler/ast:StructBody", ptr %t211, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t216 = icmp eq ptr %t214, null
  br i1 %t216, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l108, !tbaa !21
  br label %bb40
bb36:
  %t218 = load ptr, ptr %l13, !tbaa !29
  %t220 = getelementptr %"compiler/ast:StructBody", ptr %t218, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !29
  %t223 = icmp eq ptr %t221, null
  br i1 %t223, label %bb37, label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_98b1a939df7bf83c_dad16d1edd3f2a28)
  unreachable
bb38:
  br label %bb39
bb39:
  %t225 = load ptr, ptr %l13, !tbaa !29
  %t227 = getelementptr %"compiler/ast:StructBody", ptr %t225, i32 0, i32 1
  %t228 = load ptr, ptr %t227, !tbaa !29
  %t231 = getelementptr %"compiler/ast:Sig", ptr %t228, i32 0, i32 5
  %t232 = load ptr, ptr %t231, !tbaa !29
  %t234 = icmp eq ptr %t232, null
  store i1 %t234, ptr %l108, !tbaa !21
  br label %bb40
bb40:
  %t236 = load i1, ptr %l108, !tbaa !21
  br i1 %t236, label %bb41, label %bb42
bb41:
  store ptr null, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  %t238 = load ptr, ptr %l13, !tbaa !29
  %t240 = getelementptr %"compiler/ast:StructBody", ptr %t238, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !29
  %t243 = icmp eq ptr %t241, null
  br i1 %t243, label %bb44, label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_25ec48d7738ec131_33504a893c084afd)
  unreachable
bb45:
  br label %bb46
bb46:
  %t245 = load ptr, ptr %l13, !tbaa !29
  %t247 = getelementptr %"compiler/ast:StructBody", ptr %t245, i32 0, i32 1
  %t248 = load ptr, ptr %t247, !tbaa !29
  %t251 = getelementptr %"compiler/ast:Sig", ptr %t248, i32 0, i32 5
  %t252 = load ptr, ptr %t251, !tbaa !29
  store ptr %t252, ptr %l14, !tbaa !29
  %t254 = load ptr, ptr %l14, !tbaa !29
  %t256 = icmp eq ptr %t254, null
  br i1 %t256, label %bb47, label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_25ec48d7738ec131_33504a893c084afd)
  unreachable
bb48:
  br label %bb49
bb49:
  %t258 = load ptr, ptr %l14, !tbaa !29
  %t259 = load ptr, ptr %l13, !tbaa !29
  %t261 = getelementptr %"compiler/ast:StructBody", ptr %t259, i32 0, i32 0
  %t262 = load { i64, ptr }, ptr %t261, !tbaa !27
  %t263 = load i64, ptr %l10, !tbaa !24
  %t264 = load ptr, ptr %lp11
  %t265 = load { i64, ptr }, ptr %t264, !tbaa !27
  %t270 = call %"compiler/check:ctSource" @compiler_2fcheck_3actSource_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t258, ptr null, { i64, ptr } %t262, i64 %t263, { i64, ptr } %t265)
  store %"compiler/check:ctSource" %t270, ptr %l132
  br label %bb50
bb50:
  %t271 = load %"compiler/check:ctSource", ptr %l132
  %t272 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/check:ctSource" %t271, ptr %t272
  store ptr %t272, ptr %rv
  br label %ret
bb51:
  %t274 = load ptr, ptr %l12, !tbaa !29
  store ptr %t274, ptr %l134, !tbaa !29
  store i1 false, ptr %l135, !tbaa !21
  %t275 = load ptr, ptr %l134, !tbaa !29
  %t276 = icmp ne ptr %t275, null
  br i1 %t276, label %bb52, label %bb53
bb52:
  %t278 = load ptr, ptr %l134, !tbaa !29
  %t279 = load i64, ptr %t278
  %t281 = icmp eq i64 %t279, 3
  store i1 %t281, ptr %l135, !tbaa !21
  br label %bb53
bb53:
  %t282 = load i1, ptr %l135, !tbaa !21
  br i1 %t282, label %bb54, label %bb55
bb54:
  %t283 = load ptr, ptr %l12, !tbaa !29
  %t285 = getelementptr { i64, [6 x i64] }, ptr %t283, i32 0, i32 1
  %t286 = getelementptr { ptr, ptr }, ptr %t285, i32 0, i32 1
  %t287 = load ptr, ptr %t286
  store ptr %t287, ptr %l15, !tbaa !29
  br label %bb56
bb55:
  br label %bb67
bb56:
  %t289 = load ptr, ptr %l15, !tbaa !29
  %t291 = icmp eq ptr %t289, null
  br i1 %t291, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l142, !tbaa !21
  br label %bb59
bb58:
  %t293 = load ptr, ptr %l15, !tbaa !29
  %t295 = getelementptr %"compiler/ast:Func", ptr %t293, i32 0, i32 3
  %t296 = load ptr, ptr %t295, !tbaa !29
  %t298 = getelementptr %"compiler/ast:Sig", ptr %t296, i32 0, i32 5
  %t299 = load ptr, ptr %t298, !tbaa !29
  %t301 = icmp eq ptr %t299, null
  store i1 %t301, ptr %l142, !tbaa !21
  br label %bb59
bb59:
  %t303 = load i1, ptr %l142, !tbaa !21
  br i1 %t303, label %bb60, label %bb61
bb60:
  store ptr null, ptr %rv
  br label %ret
bb61:
  br label %bb62
bb62:
  %t305 = load ptr, ptr %l15, !tbaa !29
  %t307 = getelementptr %"compiler/ast:Func", ptr %t305, i32 0, i32 3
  %t308 = load ptr, ptr %t307, !tbaa !29
  %t310 = getelementptr %"compiler/ast:Sig", ptr %t308, i32 0, i32 5
  %t311 = load ptr, ptr %t310, !tbaa !29
  %t313 = icmp eq ptr %t311, null
  br i1 %t313, label %bb63, label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_1c86c4e2a1d4d52a_afb2831c22759b16)
  unreachable
bb64:
  br label %bb65
bb65:
  %t315 = load ptr, ptr %l15, !tbaa !29
  %t317 = getelementptr %"compiler/ast:Func", ptr %t315, i32 0, i32 3
  %t318 = load ptr, ptr %t317, !tbaa !29
  %t320 = getelementptr %"compiler/ast:Sig", ptr %t318, i32 0, i32 5
  %t321 = load ptr, ptr %t320, !tbaa !29
  %t322 = load ptr, ptr %l15, !tbaa !29
  %t324 = getelementptr %"compiler/ast:Func", ptr %t322, i32 0, i32 3
  %t325 = load ptr, ptr %t324, !tbaa !29
  %t327 = getelementptr %"compiler/ast:Sig", ptr %t325, i32 0, i32 0
  %t328 = load { i64, ptr }, ptr %t327, !tbaa !27
  %t329 = load i64, ptr %l10, !tbaa !24
  %t330 = load ptr, ptr %lp11
  %t331 = load { i64, ptr }, ptr %t330, !tbaa !27
  %t336 = call %"compiler/check:ctSource" @compiler_2fcheck_3actSource_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t321, ptr null, { i64, ptr } %t328, i64 %t329, { i64, ptr } %t331)
  store %"compiler/check:ctSource" %t336, ptr %l160
  br label %bb66
bb66:
  %t337 = load %"compiler/check:ctSource", ptr %l160
  %t338 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/check:ctSource" %t337, ptr %t338
  store ptr %t338, ptr %rv
  br label %ret
bb67:
  store ptr null, ptr %rv
  br label %ret
bb68:
  %t341 = load { i64, [2 x i64] }, ptr %l2
  %t343 = extractvalue { i64, [2 x i64] } %t341, 0
  %t344 = icmp eq i64 %t343, 10
  br i1 %t344, label %bb69, label %bb70
bb69:
  %t346 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t347 = getelementptr { i32, i64 }, ptr %t346, i32 0, i32 0
  %t348 = load i32, ptr %t347
  store i32 %t348, ptr %l16, !tbaa !23
  %t350 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t351 = getelementptr { i32, i64 }, ptr %t350, i32 0, i32 1
  %t352 = load i64, ptr %t351
  store i64 %t352, ptr %l17, !tbaa !24
  br label %bb71
bb70:
  br label %bb93
bb71:
  store %olang.scope zeroinitializer, ptr %s12
  %t354 = load ptr, ptr %l0, !tbaa !29
  store ptr %t354, ptr %l167, !tbaa !29
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t357 = getelementptr %"compiler/check:Checker", ptr %t355, i32 0, i32 1
  %t358 = load ptr, ptr %t357, !tbaa !29
  %t359 = load i32, ptr %l16, !tbaa !23
  %t362 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %t358, i32 %t359)
  store { i64, ptr } %t362, ptr %l171
  br label %bb72
bb72:
  %t363 = load { i64, ptr }, ptr %l171, !tbaa !27
  store { i64, ptr } %t363, ptr %l172, !tbaa !27
  %t364 = load i64, ptr %l17, !tbaa !24
  %t366 = getelementptr { i64, ptr }, ptr %l172, i32 0, i32 1
  %t367 = load ptr, ptr %t366, !tbaa !27
  %t368 = getelementptr %"compiler/generic:AnySlot", ptr %t367, i64 %t364
  %t369 = load %"compiler/generic:AnySlot", ptr %t368
  %t370 = load ptr, ptr %l167, !tbaa !29
  %t372 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitMethod(ptr %v0, ptr %t370, %"compiler/generic:AnySlot" %t369)
  store ptr %t372, ptr %l175
  br label %bb73
bb73:
  %t373 = load ptr, ptr %l175, !tbaa !29
  store ptr %t373, ptr %l18, !tbaa !29
  %t374 = load ptr, ptr %l18, !tbaa !29
  %t376 = icmp eq ptr %t374, null
  br i1 %t376, label %bb74, label %bb75
bb74:
  store i1 true, ptr %l178, !tbaa !21
  br label %bb76
bb75:
  %t378 = load ptr, ptr %l18, !tbaa !29
  %t380 = getelementptr %"compiler/ast:Func", ptr %t378, i32 0, i32 3
  %t381 = load ptr, ptr %t380, !tbaa !29
  %t383 = getelementptr %"compiler/ast:Sig", ptr %t381, i32 0, i32 5
  %t384 = load ptr, ptr %t383, !tbaa !29
  %t386 = icmp eq ptr %t384, null
  store i1 %t386, ptr %l178, !tbaa !21
  br label %bb76
bb76:
  %t388 = load i1, ptr %l178, !tbaa !21
  br i1 %t388, label %bb77, label %bb78
bb77:
  call void @__olang_scope_close(ptr %s12)
  store ptr null, ptr %rv
  br label %ret
bb78:
  br label %bb79
bb79:
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t392 = getelementptr %"compiler/check:Checker", ptr %t390, i32 0, i32 1
  %t393 = load ptr, ptr %t392, !tbaa !29
  %t395 = getelementptr %"compiler/generic:Program", ptr %t393, i32 0, i32 2
  store ptr %t395, ptr %l186, !tbaa !29
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t398 = getelementptr %"compiler/check:Checker", ptr %t396, i32 0, i32 1
  %t399 = load ptr, ptr %t398, !tbaa !29
  %t400 = load i32, ptr %l16, !tbaa !23
  %t403 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %t399, i32 %t400)
  store { i64, ptr } %t403, ptr %l190
  br label %bb80
bb80:
  %t404 = load { i64, ptr }, ptr %l190, !tbaa !27
  store { i64, ptr } %t404, ptr %l191, !tbaa !27
  %t405 = load i64, ptr %l17, !tbaa !24
  %t407 = getelementptr { i64, ptr }, ptr %l191, i32 0, i32 1
  %t408 = load ptr, ptr %t407, !tbaa !27
  %t409 = getelementptr %"compiler/generic:AnySlot", ptr %t408, i64 %t405
  %t410 = getelementptr %"compiler/generic:AnySlot", ptr %t409, i32 0, i32 1
  %t411 = load i32, ptr %t410, !tbaa !23
  %t412 = load ptr, ptr %l186, !tbaa !29
  %t414 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t412, i32 %t411)
  store i32 %t414, ptr %l194
  br label %bb81
bb81:
  %t415 = load i32, ptr %l194, !tbaa !23
  store i32 %t415, ptr %l19, !tbaa !23
  %t416 = load ptr, ptr %l18, !tbaa !29
  %t418 = getelementptr %"compiler/ast:Func", ptr %t416, i32 0, i32 1
  %t419 = load ptr, ptr %t418, !tbaa !29
  store ptr %t419, ptr %l20, !tbaa !29
  %t421 = load ptr, ptr %l20, !tbaa !29
  %t423 = icmp eq ptr %t421, null
  br i1 %t423, label %bb82, label %bb83
bb82:
  %t425 = load ptr, ptr %l18, !tbaa !29
  %t427 = getelementptr %"compiler/ast:Func", ptr %t425, i32 0, i32 0
  %t428 = load %"compiler/source:Span", ptr %t427
  %t429 = load ptr, ptr %l18, !tbaa !29
  %t431 = getelementptr %"compiler/ast:Func", ptr %t429, i32 0, i32 0
  %t432 = load %"compiler/source:Span", ptr %t431
  store { i64, [5 x i64] } zeroinitializer, ptr %t433
  %t434 = getelementptr { i64, [5 x i64] }, ptr %t433, i32 0, i32 0
  store i64 4, ptr %t434
  %t436 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } undef, %"compiler/source:Span" %t432, 0
  %t437 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } %t436, ptr null, 1
  %t438 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } %t437, i1 false, 2
  %t439 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } %t438, i1 false, 3
  %t440 = getelementptr { i64, [5 x i64] }, ptr %t433, i32 0, i32 1
  store { %"compiler/source:Span", ptr, i1, i1 } %t439, ptr %t440
  %t441 = load { i64, [5 x i64] }, ptr %t433
  %t443 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t441, ptr %t443
  %t446 = call %"compiler/ast:Param" @compiler_2fast_3aParam_2ector(ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t428, i32 0, ptr %t443, ptr null)
  store %"compiler/ast:Param" %t446, ptr %l205
  br label %bb84
bb83:
  br label %bb85
bb84:
  %t447 = load %"compiler/ast:Param", ptr %l205
  %t448 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/ast:Param" %t447, ptr %t448
  store ptr %t448, ptr %l20, !tbaa !29
  br label %bb85
bb85:
  %t450 = load ptr, ptr %l18, !tbaa !29
  %t452 = getelementptr %"compiler/ast:Func", ptr %t450, i32 0, i32 3
  %t453 = load ptr, ptr %t452, !tbaa !29
  %t455 = getelementptr %"compiler/ast:Sig", ptr %t453, i32 0, i32 5
  %t456 = load ptr, ptr %t455, !tbaa !29
  %t458 = icmp eq ptr %t456, null
  br i1 %t458, label %bb86, label %bb87
bb86:
  call void @__olang_check_failed(ptr @olang_loc_8b08af1e0b47ad17_714e6cc493d1321b)
  unreachable
bb87:
  br label %bb88
bb88:
  %t460 = load ptr, ptr %l18, !tbaa !29
  %t462 = getelementptr %"compiler/ast:Func", ptr %t460, i32 0, i32 3
  %t463 = load ptr, ptr %t462, !tbaa !29
  %t465 = getelementptr %"compiler/ast:Sig", ptr %t463, i32 0, i32 5
  %t466 = load ptr, ptr %t465, !tbaa !29
  store ptr %t466, ptr %l213, !tbaa !29
  %t467 = load ptr, ptr %l20, !tbaa !29
  store ptr %t467, ptr %l214, !tbaa !29
  %t468 = load ptr, ptr %l18, !tbaa !29
  %t470 = getelementptr %"compiler/ast:Func", ptr %t468, i32 0, i32 3
  %t471 = load ptr, ptr %t470, !tbaa !29
  %t473 = getelementptr %"compiler/ast:Sig", ptr %t471, i32 0, i32 0
  %t474 = load { i64, ptr }, ptr %t473, !tbaa !27
  store { i64, ptr } %t474, ptr %l217, !tbaa !27
  %t475 = load ptr, ptr %l0, !tbaa !29
  %t477 = getelementptr %"compiler/check:Checker", ptr %t475, i32 0, i32 1
  %t478 = load ptr, ptr %t477, !tbaa !29
  %t480 = getelementptr %"compiler/generic:Program", ptr %t478, i32 0, i32 2
  %t481 = load i32, ptr %l19, !tbaa !23
  %t484 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t480, i32 %t481)
  store i64 %t484, ptr %l222
  br label %bb89
bb89:
  %t485 = load ptr, ptr %l0, !tbaa !29
  %t486 = load i32, ptr %l16, !tbaa !23
  %t489 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s12, ptr %t485, i32 %t486)
  store { i64, ptr } %t489, ptr %l225
  br label %bb90
bb90:
  %t490 = load ptr, ptr %l0, !tbaa !29
  %t491 = load ptr, ptr %l18, !tbaa !29
  %t493 = getelementptr %"compiler/ast:Func", ptr %t491, i32 0, i32 2
  %t494 = load i32, ptr %t493, !tbaa !23
  %t497 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t490, i32 %t494)
  store { i64, ptr } %t497, ptr %l229
  br label %bb91
bb91:
  %t498 = load { i64, ptr }, ptr %l225, !tbaa !27
  %t499 = extractvalue { i64, ptr } %t498, 1
  %t500 = extractvalue { i64, ptr } %t498, 0
  %t501 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t502 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t503 = add i64 %t500, %t502
  %t504 = load { i64, ptr }, ptr %l229, !tbaa !27
  %t505 = extractvalue { i64, ptr } %t504, 1
  %t506 = extractvalue { i64, ptr } %t504, 0
  %t507 = add i64 %t503, %t506
  %t508 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t507)
  call void @olang_textcopy(ptr %t508, ptr %t499, i64 %t500)
  %t509 = getelementptr i8, ptr %t508, i64 %t500
  call void @olang_textcopy(ptr %t509, ptr %t501, i64 %t502)
  %t510 = getelementptr i8, ptr %t509, i64 %t502
  call void @olang_textcopy(ptr %t510, ptr %t505, i64 %t506)
  %t511 = insertvalue { i64, ptr } undef, i64 %t507, 0
  %t512 = insertvalue { i64, ptr } %t511, ptr %t508, 1
  %t514 = extractvalue { i64, ptr } %t512, 0
  %t515 = extractvalue { i64, ptr } %t512, 1
  %t516 = mul i64 %t514, 1
  %t517 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t516)
  call void @llvm.memcpy.p0.p0.i64(ptr %t517, ptr %t515, i64 %t516, i1 false)
  %t518 = insertvalue { i64, ptr } undef, i64 %t514, 0
  %t519 = insertvalue { i64, ptr } %t518, ptr %t517, 1
  %t520 = load ptr, ptr %l213, !tbaa !29
  %t521 = load ptr, ptr %l214, !tbaa !29
  %t522 = load { i64, ptr }, ptr %l217, !tbaa !27
  %t523 = load i64, ptr %l222, !tbaa !24
  %t525 = call %"compiler/check:ctSource" @compiler_2fcheck_3actSource_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t520, ptr %t521, { i64, ptr } %t522, i64 %t523, { i64, ptr } %t519)
  store %"compiler/check:ctSource" %t525, ptr %l232
  br label %bb92
bb92:
  %t526 = load %"compiler/check:ctSource", ptr %l232
  %t527 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/check:ctSource" %t526, ptr %t527
  call void @__olang_scope_close(ptr %s12)
  store ptr %t527, ptr %rv
  br label %ret
bb93:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultReads(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l39 = alloca ptr
  %l43 = alloca i1
  %l46 = alloca i1
  %l50 = alloca ptr
  %l53 = alloca { i64, [3 x i64] }
  %l54 = alloca %"compiler/msgs:Msg"
  %l55 = alloca i64
  %l56 = alloca ptr
  %l57 = alloca i1
  %l69 = alloca { i64, ptr }
  %l77 = alloca ptr
  %l78 = alloca i1
  %l91 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s12 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t6 = load ptr, ptr %l19, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l19, !tbaa !29
  %t10 = load i64, ptr %t9
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l20, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l20, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t16, i32 0, i32 0
  %t18 = load %"compiler/source:Span", ptr %t17
  store %"compiler/source:Span" %t18, ptr %l2
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [5 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t22, i32 0, i32 2
  %t24 = load ptr, ptr %t23
  store ptr %t24, ptr %l3, !tbaa !29
  br label %bb8
bb7:
  br label %bb27
bb8:
  %t26 = load ptr, ptr %l3, !tbaa !29
  store ptr %t26, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t27 = load ptr, ptr %l27, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb9, label %bb10
bb9:
  %t30 = load ptr, ptr %l27, !tbaa !29
  %t31 = load i64, ptr %t30
  %t33 = icmp eq i64 %t31, 1
  store i1 %t33, ptr %l28, !tbaa !21
  br label %bb10
bb10:
  %t34 = load i1, ptr %l28, !tbaa !21
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t35 = load ptr, ptr %l3, !tbaa !29
  %t37 = getelementptr { i64, [4 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t37, i32 0, i32 2
  %t39 = load i64, ptr %t38
  store i64 %t39, ptr %l4, !tbaa !24
  %t41 = load ptr, ptr %l3, !tbaa !29
  %t43 = getelementptr { i64, [4 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t43, i32 0, i32 3
  %t45 = load i32, ptr %t44
  store i32 %t45, ptr %l5, !tbaa !23
  br label %bb13
bb12:
  br label %bb25
bb13:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t51 = load i64, ptr %l4, !tbaa !24
  %t52 = load i32, ptr %l5, !tbaa !23
  %t56 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %t50, i64 %t51, i32 %t52)
  store ptr %t56, ptr %l39
  br label %bb14
bb14:
  %t57 = load ptr, ptr %l39, !tbaa !29
  store ptr %t57, ptr %l6, !tbaa !29
  %t58 = load ptr, ptr %l6, !tbaa !29
  %t60 = icmp eq ptr %t58, null
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb15, label %bb16
bb15:
  %t64 = load ptr, ptr %l6, !tbaa !29
  %t66 = getelementptr %"compiler/ast:VarDecl", ptr %t64, i32 0, i32 2
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = call i1 @compiler_2fcheck_2ewrittenMut(ptr %v0, ptr %t67)
  store i1 %t69, ptr %l46
  br label %bb17
bb16:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb18
bb17:
  %t70 = load i1, ptr %l46, !tbaa !21
  store i1 %t70, ptr %l43, !tbaa !21
  br label %bb18
bb18:
  %t71 = load i1, ptr %l43, !tbaa !21
  br i1 %t71, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/check:Checker", ptr %t72, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t77 = getelementptr %"compiler/generic:Program", ptr %t75, i32 0, i32 0
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = getelementptr %"compiler/load:Loader", ptr %t78, i32 0, i32 4
  %t81 = load ptr, ptr %t80, !tbaa !29
  store ptr %t81, ptr %l50, !tbaa !29
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load %"compiler/source:Span", ptr %l2
  %t86 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t82, %"compiler/source:Span" %t83)
  store { i64, [3 x i64] } %t86, ptr %l53
  br label %bb21
bb20:
  br label %bb24
bb21:
  %t87 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultNotComputable(ptr %s4, ptr %s4, { i64, ptr } { i64 63, ptr getelementptr inbounds (<{ i64, [63 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t87, ptr %l54
  br label %bb22
bb22:
  %t88 = load ptr, ptr %l50, !tbaa !29
  %t89 = load { i64, [3 x i64] }, ptr %l53
  %t90 = load %"compiler/msgs:Msg", ptr %l54
  %t91 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %s4, ptr %t88, { i64, [3 x i64] } %t89, %"compiler/msgs:Msg" %t90)
  store i64 %t91, ptr %l55
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s4)
  br label %bb24
bb24:
  br label %bb26
bb25:
  br label %bb26
bb26:
  br label %bb54
bb27:
  %t92 = load ptr, ptr %l1, !tbaa !29
  store ptr %t92, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t93 = load ptr, ptr %l56, !tbaa !29
  %t94 = icmp ne ptr %t93, null
  br i1 %t94, label %bb28, label %bb29
bb28:
  %t96 = load ptr, ptr %l56, !tbaa !29
  %t97 = load i64, ptr %t96
  %t99 = icmp eq i64 %t97, 9
  store i1 %t99, ptr %l57, !tbaa !21
  br label %bb29
bb29:
  %t100 = load i1, ptr %l57, !tbaa !21
  br i1 %t100, label %bb30, label %bb31
bb30:
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t103 = getelementptr { i64, [5 x i64] }, ptr %t101, i32 0, i32 1
  %t104 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t103, i32 0, i32 4
  %t105 = load { i64, ptr }, ptr %t104
  store { i64, ptr } %t105, ptr %l7, !tbaa !27
  br label %bb32
bb31:
  br label %bb40
bb32:
  %t107 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t107, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t109 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t109, 0
  store i64 %t111, ptr %l10, !tbaa !24
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s8
  %t113 = load i64, ptr %l9, !tbaa !24
  %t114 = load i64, ptr %l10, !tbaa !24
  %t117 = icmp slt i64 %t113, %t114
  %t119 = xor i1 %t117, true
  br i1 %t119, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s8)
  br label %bb39
bb35:
  br label %bb36
bb36:
  %t121 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t121, ptr %l69, !tbaa !27
  %t122 = load i64, ptr %l9, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr ptr, ptr %t125, i64 %t122
  %t127 = load ptr, ptr %t126, !tbaa !39
  %t129 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultReads(ptr %v0, ptr %v1, ptr %t129, ptr %t127)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s8)
  br label %bb38
bb38:
  %t134 = load i64, ptr %l9, !tbaa !24
  %t136 = add i64 %t134, 1
  store i64 %t136, ptr %l9, !tbaa !24
  br label %bb33
bb39:
  br label %bb54
bb40:
  %t138 = load ptr, ptr %l1, !tbaa !29
  store ptr %t138, ptr %l77, !tbaa !29
  store i1 false, ptr %l78, !tbaa !21
  %t139 = load ptr, ptr %l77, !tbaa !29
  %t140 = icmp ne ptr %t139, null
  br i1 %t140, label %bb41, label %bb42
bb41:
  %t142 = load ptr, ptr %l77, !tbaa !29
  %t143 = load i64, ptr %t142
  %t145 = icmp eq i64 %t143, 6
  store i1 %t145, ptr %l78, !tbaa !21
  br label %bb42
bb42:
  %t146 = load i1, ptr %l78, !tbaa !21
  br i1 %t146, label %bb43, label %bb44
bb43:
  %t147 = load ptr, ptr %l1, !tbaa !29
  %t149 = getelementptr { i64, [5 x i64] }, ptr %t147, i32 0, i32 1
  %t150 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t149, i32 0, i32 2
  %t151 = load ptr, ptr %t150
  store ptr %t151, ptr %l12, !tbaa !29
  br label %bb45
bb44:
  br label %bb53
bb45:
  %t153 = load ptr, ptr %l12, !tbaa !29
  %t155 = getelementptr %"compiler/typed:Call", ptr %t153, i32 0, i32 1
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  store { i64, ptr } %t156, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t158 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t158, 0
  store i64 %t160, ptr %l15, !tbaa !24
  br label %bb46
bb46:
  store %olang.scope zeroinitializer, ptr %s12
  %t162 = load i64, ptr %l14, !tbaa !24
  %t163 = load i64, ptr %l15, !tbaa !24
  %t166 = icmp slt i64 %t162, %t163
  %t168 = xor i1 %t166, true
  br i1 %t168, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s12)
  br label %bb52
bb48:
  br label %bb49
bb49:
  %t170 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t170, ptr %l91, !tbaa !27
  %t171 = load i64, ptr %l14, !tbaa !24
  %t173 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !27
  %t175 = getelementptr ptr, ptr %t174, i64 %t171
  %t176 = load ptr, ptr %t175, !tbaa !39
  %t178 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultReads(ptr %v0, ptr %v1, ptr %t178, ptr %t176)
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s12)
  br label %bb51
bb51:
  %t183 = load i64, ptr %l14, !tbaa !24
  %t185 = add i64 %t183, 1
  store i64 %t185, ptr %l14, !tbaa !24
  br label %bb46
bb52:
  br label %bb54
bb53:
  br label %bb54
bb54:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edoFor(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, i64, i64 }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, i64, i64 }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l18 = alloca i64
  %l22 = alloca { i64, i64, i64 }
  %l27 = alloca ptr
  %l32 = alloca ptr
  %l41 = alloca i64
  %l43 = alloca ptr
  %l46 = alloca i64
  %l47 = alloca i32
  %l48 = alloca i64
  %l50 = alloca ptr
  %l53 = alloca i64
  %l54 = alloca i32
  %l60 = alloca ptr
  %l63 = alloca i64
  %l67 = alloca { i64, i64, i64 }
  %l71 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca %"compiler/source:Span"
  %l76 = alloca ptr
  %l78 = alloca ptr
  %l84 = alloca ptr
  %t144 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 33
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l18
  br label %bb1
bb1:
  %t6 = load i64, ptr %l18, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  %t12 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t7, i32 2, %"compiler/source:Span" %t8)
  store { i64, i64, i64 } %t12, ptr %l22
  br label %bb2
bb2:
  %t13 = load { i64, i64, i64 }, ptr %l22
  store { i64, i64, i64 } %t13, ptr %l5
  %t14 = getelementptr { i64, i64, i64 }, ptr %l5, i32 0, i32 0
  %t15 = load i64, ptr %t14, !tbaa !24
  store i64 %t15, ptr %l6, !tbaa !24
  %t17 = getelementptr { i64, i64, i64 }, ptr %l5, i32 0, i32 1
  %t18 = load i64, ptr %t17, !tbaa !24
  store i64 %t18, ptr %l7, !tbaa !24
  %t20 = getelementptr { i64, i64, i64 }, ptr %l5, i32 0, i32 2
  %t21 = load i64, ptr %t20, !tbaa !24
  store i64 %t21, ptr %l8, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t23)
  store ptr %t25, ptr %l27
  br label %bb3
bb3:
  %t26 = load ptr, ptr %l27, !tbaa !29
  %t28 = getelementptr %"compiler/check:frame", ptr %t26, i32 0, i32 10
  %t29 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t28, i64 %t29)
  br label %bb4
bb4:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t32)
  store ptr %t34, ptr %l32
  br label %bb5
bb5:
  %t35 = load ptr, ptr %l32, !tbaa !29
  %t37 = getelementptr %"compiler/check:frame", ptr %t35, i32 0, i32 11
  %t38 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t37, i64 %t38)
  br label %bb6
bb6:
  %t41 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t45 = icmp sgt i64 %t43, 0
  br i1 %t45, label %bb7, label %bb8
bb7:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %t47, { i64, ptr } %t48)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t51)
  store ptr %t53, ptr %l43
  br label %bb11
bb11:
  %t54 = load ptr, ptr %l43, !tbaa !29
  %t56 = getelementptr %"compiler/check:frame", ptr %t54, i32 0, i32 10
  %t58 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t56)
  %t59 = extractvalue { i32, i64 } %t58, 1
  %t60 = extractvalue { i32, i64 } %t58, 0
  store i32 %t60, ptr %l47
  %t61 = icmp ne i32 %t60, 0
  br i1 %t61, label %bb13, label %ok.62
ok.62:
  store i64 %t59, ptr %l46
  br label %bb12
bb12:
  %t63 = load i64, ptr %l46, !tbaa !24
  store i64 %t63, ptr %l41, !tbaa !24
  br label %bb15
bb13:
  br label %bb14
bb14:
  call void @__olang_ert_req_clear()
  br label %bb15
bb15:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t64)
  store ptr %t66, ptr %l50
  br label %bb16
bb16:
  %t67 = load ptr, ptr %l50, !tbaa !29
  %t69 = getelementptr %"compiler/check:frame", ptr %t67, i32 0, i32 11
  %t71 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t69)
  %t72 = extractvalue { i32, i64 } %t71, 1
  %t73 = extractvalue { i32, i64 } %t71, 0
  store i32 %t73, ptr %l54
  %t74 = icmp ne i32 %t73, 0
  br i1 %t74, label %bb18, label %ok.75
ok.75:
  store i64 %t72, ptr %l53
  br label %bb17
bb17:
  %t76 = load i64, ptr %l53, !tbaa !24
  store i64 %t76, ptr %l48, !tbaa !24
  br label %bb20
bb18:
  br label %bb19
bb19:
  call void @__olang_ert_req_clear()
  br label %bb20
bb20:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load i64, ptr %l6, !tbaa !24
  %t79 = load i64, ptr %l7, !tbaa !24
  %t80 = load i64, ptr %l8, !tbaa !24
  %t81 = load i64, ptr %l4, !tbaa !24
  %t87 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t77, i64 %t78, i64 %t79, i64 %t80, i64 %t81)
  store ptr %t87, ptr %l60
  br label %bb21
bb21:
  %t88 = load ptr, ptr %l60, !tbaa !29
  store ptr %t88, ptr %l9, !tbaa !29
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/check:Checker", ptr %t89, i32 0, i32 33
  %t93 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t91)
  store i64 %t93, ptr %l63
  br label %bb22
bb22:
  %t94 = load i64, ptr %l63, !tbaa !24
  store i64 %t94, ptr %l10, !tbaa !24
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load %"compiler/source:Span", ptr %l1
  %t100 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t95, i32 3, %"compiler/source:Span" %t96)
  store { i64, i64, i64 } %t100, ptr %l67
  br label %bb23
bb23:
  %t101 = load { i64, i64, i64 }, ptr %l67
  store { i64, i64, i64 } %t101, ptr %l11
  %t102 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 0
  %t103 = load i64, ptr %t102, !tbaa !24
  store i64 %t103, ptr %l12, !tbaa !24
  %t105 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 1
  %t106 = load i64, ptr %t105, !tbaa !24
  store i64 %t106, ptr %l13, !tbaa !24
  %t108 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 2
  %t109 = load i64, ptr %t108, !tbaa !24
  store i64 %t109, ptr %l14, !tbaa !24
  %t111 = load ptr, ptr %l0, !tbaa !29
  store ptr %t111, ptr %l71, !tbaa !29
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l72, !tbaa !29
  %t113 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t113, ptr %l73
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t118 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v2, ptr %t114, ptr %a3)
  store ptr %t118, ptr %l76
  br label %bb24
bb24:
  %t119 = load i64, ptr %l6, !tbaa !24
  %t120 = load ptr, ptr %l72, !tbaa !29
  %t121 = load %"compiler/source:Span", ptr %l73
  %t122 = load ptr, ptr %l76, !tbaa !29
  %t124 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebreakUnless(ptr %v0, ptr %t120, %"compiler/source:Span" %t121, ptr %t122, i64 %t119)
  store ptr %t124, ptr %l78
  br label %bb25
bb25:
  %t125 = load ptr, ptr %l71, !tbaa !29
  %t126 = load ptr, ptr %l78, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t125, ptr %t126)
  br label %bb26
bb26:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load i64, ptr %l12, !tbaa !24
  %t129 = load i64, ptr %l13, !tbaa !24
  %t130 = load i64, ptr %l14, !tbaa !24
  %t131 = load i64, ptr %l10, !tbaa !24
  %t137 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t127, i64 %t128, i64 %t129, i64 %t130, i64 %t131)
  store ptr %t137, ptr %l84
  br label %bb27
bb27:
  %t138 = load ptr, ptr %l84, !tbaa !29
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load %"compiler/source:Span", ptr %l1
  %t141 = load ptr, ptr %l9, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t144
  %t145 = getelementptr { i64, [3 x i64] }, ptr %t144, i32 0, i32 0
  store i64 4, ptr %t145
  %t147 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t140, 0
  %t149 = insertvalue { %"compiler/source:Span", ptr, ptr } %t147, ptr %t141, 1
  %t151 = insertvalue { %"compiler/source:Span", ptr, ptr } %t149, ptr %t138, 2
  %t152 = getelementptr { i64, [3 x i64] }, ptr %t144, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t151, ptr %t152
  %t153 = load { i64, [3 x i64] }, ptr %t144
  %t155 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t153, ptr %t155
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t139, ptr %t155)
  br label %bb28
bb28:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelementLocals(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l6 = alloca i64
  %l10 = alloca i1
  %l13 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca %"compiler/source:Span"
  %l18 = alloca i32
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca %"compiler/source:Span"
  %l26 = alloca i32
  %l30 = alloca ptr
  %l33 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca %"compiler/source:Span"
  %l39 = alloca i32
  %l42 = alloca i64
  %t22 = alloca { i64, [2 x i64] }, align 8
  %t46 = alloca { i64, [3 x i64] }, align 8
  %t70 = alloca { i64, [2 x i64] }, align 8
  %t94 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:ForIn", ptr %t1, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp ne i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t10 = icmp sge i64 %t8, 0
  store i1 %t10, ptr %l10, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l10, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l13, !tbaa !29
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = getelementptr %"compiler/ast:ForIn", ptr %t14, i32 0, i32 0
  %t17 = load i32, ptr %t16, !tbaa !23
  store i32 %t17, ptr %l15, !tbaa !23
  %t18 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t18, ptr %l16
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t19)
  store i32 %t21, ptr %l18
  br label %bb6
bb5:
  br label %bb10
bb6:
  store { i64, [2 x i64] } zeroinitializer, ptr %t22
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t22, i32 0, i32 0
  store i64 0, ptr %t23
  %t24 = load { i64, [2 x i64] }, ptr %t22
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t26 = load i32, ptr %l15, !tbaa !23
  %t27 = load %"compiler/source:Span", ptr %l16
  %t28 = load i32, ptr %l18, !tbaa !23
  %t31 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t25, i32 %t26, %"compiler/source:Span" %t27, i32 %t28, i32 1, { i64, [2 x i64] } %t24)
  store i64 %t31, ptr %l21
  br label %bb7
bb7:
  %t32 = load i64, ptr %l21, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l22, !tbaa !29
  %t34 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t34, ptr %l23
  %t37 = trunc i64 %t32 to i32
  store i32 %t37, ptr %l26, !tbaa !23
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load %"compiler/source:Span", ptr %l1
  %t41 = load i64, ptr %l3, !tbaa !24
  %t45 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t39, %"compiler/source:Span" %t40, i64 %t41)
  store ptr %t45, ptr %l30
  br label %bb8
bb8:
  store { i64, [3 x i64] } zeroinitializer, ptr %t46
  %t47 = getelementptr { i64, [3 x i64] }, ptr %t46, i32 0, i32 0
  store i64 0, ptr %t47
  %t48 = load %"compiler/source:Span", ptr %l23
  %t49 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t48, 0
  %t50 = load i32, ptr %l26, !tbaa !23
  %t51 = insertvalue { %"compiler/source:Span", i32, ptr } %t49, i32 %t50, 1
  %t52 = load ptr, ptr %l30, !tbaa !29
  %t53 = insertvalue { %"compiler/source:Span", i32, ptr } %t51, ptr %t52, 2
  %t54 = getelementptr { i64, [3 x i64] }, ptr %t46, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t53, ptr %t54
  %t55 = load { i64, [3 x i64] }, ptr %t46
  %t57 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t55, ptr %t57
  %t58 = load ptr, ptr %l22, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t58, ptr %t57)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l33, !tbaa !29
  %t61 = load ptr, ptr %l2, !tbaa !29
  %t63 = getelementptr %"compiler/ast:ForIn", ptr %t61, i32 0, i32 1
  %t64 = load i32, ptr %t63, !tbaa !23
  store i32 %t64, ptr %l35, !tbaa !23
  %t65 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t65, ptr %l36
  %t66 = load ptr, ptr %l4, !tbaa !29
  %t69 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t66)
  store i32 %t69, ptr %l39
  br label %bb11
bb11:
  store { i64, [2 x i64] } zeroinitializer, ptr %t70
  %t71 = getelementptr { i64, [2 x i64] }, ptr %t70, i32 0, i32 0
  store i64 5, ptr %t71
  %t72 = load { i64, [2 x i64] }, ptr %t70
  %t73 = load ptr, ptr %l33, !tbaa !29
  %t74 = load i32, ptr %l35, !tbaa !23
  %t75 = load %"compiler/source:Span", ptr %l36
  %t76 = load i32, ptr %l39, !tbaa !23
  %t79 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t73, i32 %t74, %"compiler/source:Span" %t75, i32 %t76, i32 1, { i64, [2 x i64] } %t72)
  store i64 %t79, ptr %l42
  br label %bb12
bb12:
  %t80 = load i64, ptr %l42, !tbaa !24
  store i64 %t80, ptr %l6, !tbaa !24
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load i64, ptr %l6, !tbaa !24
  %t83 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v0, ptr %t81, i64 %t82, ptr %t83)
  br label %bb13
bb13:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load %"compiler/source:Span", ptr %l1
  %t89 = load i64, ptr %l6, !tbaa !24
  %t91 = trunc i64 %t89 to i32
  %t93 = load ptr, ptr %l4, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t94
  %t95 = getelementptr { i64, [3 x i64] }, ptr %t94, i32 0, i32 0
  store i64 0, ptr %t95
  %t97 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t88, 0
  %t99 = insertvalue { %"compiler/source:Span", i32, ptr } %t97, i32 %t91, 1
  %t101 = insertvalue { %"compiler/source:Span", i32, ptr } %t99, ptr %t93, 2
  %t102 = getelementptr { i64, [3 x i64] }, ptr %t94, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t101, ptr %t102
  %t103 = load { i64, [3 x i64] }, ptr %t94
  %t105 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t103, ptr %t105
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t87, ptr %t105)
  br label %bb14
bb14:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrBefore(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i32
  %l18 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i32
  %l28 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca ptr
  %l40 = alloca ptr
  %l45 = alloca i64
  %l46 = alloca ptr
  %l51 = alloca i1
  %l55 = alloca i1
  %l56 = alloca ptr
  %l61 = alloca i32
  %l62 = alloca { i64, ptr }
  %l63 = alloca ptr
  %l68 = alloca i32
  %l69 = alloca { i64, ptr }
  %l70 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l9, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t12, i32 %a1)
  store i32 %t16, ptr %l14
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l9, !tbaa !29
  %t18 = load i32, ptr %l14, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t19, ptr %l15
  br label %bb2
bb2:
  %t20 = load i32, ptr %l15, !tbaa !23
  store i32 %t20, ptr %l3, !tbaa !23
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 2
  store ptr %t26, ptr %l18, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/generic:Program", ptr %t30, i32 0, i32 2
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t32, i32 %a2)
  store i32 %t36, ptr %l23
  br label %bb3
bb3:
  %t37 = load ptr, ptr %l18, !tbaa !29
  %t38 = load i32, ptr %l23, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t39, ptr %l24
  br label %bb4
bb4:
  %t40 = load i32, ptr %l24, !tbaa !23
  store i32 %t40, ptr %l4, !tbaa !23
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/load:Loader", ptr %t47, i32 0, i32 5
  store ptr %t49, ptr %l28, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %l3, !tbaa !23
  %t59 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t55, i32 %t56)
  store i64 %t59, ptr %l33
  br label %bb5
bb5:
  %t60 = load ptr, ptr %l28, !tbaa !29
  %t61 = load i64, ptr %l33, !tbaa !24
  %t62 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t60, i64 %t61)
  store ptr %t62, ptr %l34
  br label %bb6
bb6:
  %t63 = load ptr, ptr %l34, !tbaa !29
  %t65 = getelementptr %"compiler/load:Module", ptr %t63, i32 0, i32 2
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !27
  store { i64, ptr } %t66, ptr %l5, !tbaa !27
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/check:Checker", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/generic:Program", ptr %t71, i32 0, i32 0
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/load:Loader", ptr %t74, i32 0, i32 5
  store ptr %t76, ptr %l40, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/generic:Program", ptr %t80, i32 0, i32 2
  %t83 = load i32, ptr %l4, !tbaa !23
  %t86 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t82, i32 %t83)
  store i64 %t86, ptr %l45
  br label %bb7
bb7:
  %t87 = load ptr, ptr %l40, !tbaa !29
  %t88 = load i64, ptr %l45, !tbaa !24
  %t89 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t87, i64 %t88)
  store ptr %t89, ptr %l46
  br label %bb8
bb8:
  %t90 = load ptr, ptr %l46, !tbaa !29
  %t92 = getelementptr %"compiler/load:Module", ptr %t90, i32 0, i32 2
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  store { i64, ptr } %t93, ptr %l6, !tbaa !27
  %t95 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t99 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v0, { i64, ptr } %t95, { i64, ptr } %t96)
  store i1 %t99, ptr %l51
  br label %bb9
bb9:
  %t100 = load i1, ptr %l51, !tbaa !21
  %t101 = xor i1 %t100, true
  br i1 %t101, label %bb10, label %bb11
bb10:
  %t103 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t107 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v0, { i64, ptr } %t103, { i64, ptr } %t104)
  store i1 %t107, ptr %l55
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t108 = load i1, ptr %l55, !tbaa !21
  store i1 %t108, ptr %rv
  br label %ret
bb13:
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l56, !tbaa !29
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/check:Checker", ptr %t110, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = getelementptr %"compiler/generic:Program", ptr %t113, i32 0, i32 2
  %t116 = load i32, ptr %l3, !tbaa !23
  %t119 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t115, i32 %t116)
  store i32 %t119, ptr %l61
  br label %bb14
bb14:
  %t120 = load ptr, ptr %l56, !tbaa !29
  %t121 = load i32, ptr %l61, !tbaa !23
  %t122 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t120, i32 %t121)
  store { i64, ptr } %t122, ptr %l62
  br label %bb15
bb15:
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l63, !tbaa !29
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/check:Checker", ptr %t124, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t129 = getelementptr %"compiler/generic:Program", ptr %t127, i32 0, i32 2
  %t130 = load i32, ptr %l4, !tbaa !23
  %t133 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t129, i32 %t130)
  store i32 %t133, ptr %l68
  br label %bb16
bb16:
  %t134 = load ptr, ptr %l63, !tbaa !29
  %t135 = load i32, ptr %l68, !tbaa !23
  %t136 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t134, i32 %t135)
  store { i64, ptr } %t136, ptr %l69
  br label %bb17
bb17:
  %t137 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t138 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t139 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v0, { i64, ptr } %t137, { i64, ptr } %t138)
  store i1 %t139, ptr %l70
  br label %bb18
bb18:
  %t140 = load i1, ptr %l70, !tbaa !21
  store i1 %t140, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eescapeRules(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i1
  %l14 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca %"compiler/source:Span"
  %l22 = alloca %"compiler/msgs:Msg"
  %l23 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca %"compiler/source:Span"
  %l32 = alloca { i64, ptr }
  %l33 = alloca %"compiler/msgs:Msg"
  %l34 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca %"compiler/source:Span"
  %l39 = alloca %"compiler/msgs:Msg"
  %l40 = alloca i64
  %l43 = alloca i1
  %l53 = alloca i64
  %l56 = alloca i64
  %l77 = alloca i32
  %l81 = alloca i1
  %l85 = alloca i1
  %l86 = alloca ptr
  %l87 = alloca %"compiler/source:Span"
  %l88 = alloca %"compiler/msgs:Msg"
  %l89 = alloca i64
  %l94 = alloca i32
  %l103 = alloca { i64, ptr }
  %l106 = alloca ptr
  %l107 = alloca %"compiler/source:Span"
  %l109 = alloca ptr
  %l112 = alloca %"compiler/msgs:Msg"
  %l114 = alloca %"compiler/msgs:Msg"
  %l116 = alloca %"compiler/msgs:Msg"
  %l117 = alloca i64
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l16
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l16, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 31
  %t8 = load i64, ptr %t7, !tbaa !24
  %t10 = icmp sge i64 %t8, 0
  br i1 %t10, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l20, !tbaa !29
  %t13 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t13, ptr %l21
  %t14 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeferErrorEscapes(ptr %s1)
  store %"compiler/msgs:Msg" %t14, ptr %l22
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t15 = load ptr, ptr %l20, !tbaa !29
  %t16 = load %"compiler/source:Span", ptr %l21
  %t17 = load %"compiler/msgs:Msg", ptr %l22
  %t18 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t15, %"compiler/source:Span" %t16, %"compiler/msgs:Msg" %t17)
  store i64 %t18, ptr %l23
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb6:
  %t19 = load ptr, ptr %l4, !tbaa !29
  %t21 = getelementptr %"compiler/check:frame", ptr %t19, i32 0, i32 32
  %t22 = load i64, ptr %t21, !tbaa !24
  %t24 = icmp sge i64 %t22, 0
  br i1 %t24, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l27, !tbaa !29
  %t27 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t27, ptr %l28
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l4, !tbaa !29
  %t31 = getelementptr %"compiler/check:frame", ptr %t29, i32 0, i32 33
  %t32 = load i1, ptr %t31, !tbaa !21
  %t35 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emsgOwner(ptr %v0, ptr %s2, ptr %t28, i1 %t32)
  store { i64, ptr } %t35, ptr %l32
  br label %bb9
bb8:
  br label %bb12
bb9:
  %t36 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t37 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertMsgError(ptr %s2, ptr %s2, { i64, ptr } %t36)
  store %"compiler/msgs:Msg" %t37, ptr %l33
  br label %bb10
bb10:
  %t38 = load ptr, ptr %l27, !tbaa !29
  %t39 = load %"compiler/source:Span", ptr %l28
  %t40 = load %"compiler/msgs:Msg", ptr %l33
  %t41 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t38, %"compiler/source:Span" %t39, %"compiler/msgs:Msg" %t40)
  store i64 %t41, ptr %l34
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb12:
  %t42 = load ptr, ptr %l4, !tbaa !29
  %t44 = getelementptr %"compiler/check:frame", ptr %t42, i32 0, i32 29
  %t45 = load i1, ptr %t44, !tbaa !21
  br i1 %t45, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l37, !tbaa !29
  %t48 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t48, ptr %l38
  %t49 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskClauseError(ptr %s3)
  store %"compiler/msgs:Msg" %t49, ptr %l39
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t50 = load ptr, ptr %l37, !tbaa !29
  %t51 = load %"compiler/source:Span", ptr %l38
  %t52 = load %"compiler/msgs:Msg", ptr %l39
  %t53 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t50, %"compiler/source:Span" %t51, %"compiler/msgs:Msg" %t52)
  store i64 %t53, ptr %l40
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %ret
bb17:
  %t54 = load ptr, ptr %l4, !tbaa !29
  %t56 = getelementptr %"compiler/check:frame", ptr %t54, i32 0, i32 12
  %t57 = load i1, ptr %t56, !tbaa !21
  br i1 %t57, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb20
bb19:
  %t59 = load ptr, ptr %l4, !tbaa !29
  %t61 = getelementptr %"compiler/check:frame", ptr %t59, i32 0, i32 23
  %t62 = load i1, ptr %t61, !tbaa !21
  store i1 %t62, ptr %l43, !tbaa !21
  br label %bb20
bb20:
  %t64 = load i1, ptr %l43, !tbaa !21
  br i1 %t64, label %bb21, label %bb22
bb21:
  br label %ret
bb22:
  br label %bb23
bb23:
  %t65 = load i64, ptr %l2, !tbaa !24
  store i64 %t65, ptr %l5, !tbaa !24
  %t67 = load i64, ptr %l2, !tbaa !24
  %t71 = add i64 %t67, %a3
  store i64 %t71, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t73 = load i64, ptr %l6, !tbaa !24
  %t74 = load i64, ptr %l5, !tbaa !24
  %t77 = icmp sgt i64 %t73, %t74
  br i1 %t77, label %bb24, label %bb25
bb24:
  %t79 = load i64, ptr %l7, !tbaa !24
  %t81 = icmp sgt i64 %t79, 0
  br i1 %t81, label %bb26, label %bb27
bb25:
  store i64 0, ptr %l53, !tbaa !24
  br label %bb29
bb26:
  %t83 = load i64, ptr %l6, !tbaa !24
  %t84 = load i64, ptr %l5, !tbaa !24
  %t87 = sub i64 %t83, %t84
  %t88 = load i64, ptr %l7, !tbaa !24
  %t91 = add i64 %t87, %t88
  %t93 = sub i64 %t91, 1
  %t94 = load i64, ptr %l7, !tbaa !24
  %t97 = sdiv i64 %t93, %t94
  store i64 %t97, ptr %l56, !tbaa !24
  br label %bb28
bb27:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb28
bb28:
  %t99 = load i64, ptr %l56, !tbaa !24
  store i64 %t99, ptr %l53, !tbaa !24
  br label %bb29
bb29:
  %t100 = load i64, ptr %l53, !tbaa !24
  store i64 %t100, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s6
  %t101 = load i64, ptr %l9, !tbaa !24
  %t102 = load i64, ptr %l8, !tbaa !24
  %t105 = icmp slt i64 %t101, %t102
  %t107 = xor i1 %t105, true
  br i1 %t107, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s6)
  br label %bb57
bb32:
  br label %bb33
bb33:
  %t109 = load i64, ptr %l5, !tbaa !24
  %t110 = load i64, ptr %l9, !tbaa !24
  %t111 = load i64, ptr %l7, !tbaa !24
  %t114 = mul i64 %t110, %t111
  %t117 = add i64 %t109, %t114
  %t119 = load ptr, ptr %l4, !tbaa !29
  %t121 = getelementptr %"compiler/check:frame", ptr %t119, i32 0, i32 25
  %t125 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t121, i64 %t117)
  store i32 %t125, ptr %l77
  br label %bb34
bb34:
  %t126 = load i32, ptr %l77, !tbaa !23
  store i32 %t126, ptr %l11, !tbaa !23
  %t127 = load ptr, ptr %l4, !tbaa !29
  %t129 = getelementptr %"compiler/check:frame", ptr %t127, i32 0, i32 0
  %t130 = load i64, ptr %t129, !tbaa !24
  %t132 = icmp slt i64 %t130, 0
  br i1 %t132, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l81, !tbaa !21
  br label %bb38
bb36:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load ptr, ptr %l4, !tbaa !29
  %t137 = getelementptr %"compiler/check:frame", ptr %t135, i32 0, i32 0
  %t138 = load i64, ptr %t137, !tbaa !24
  %t141 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisGlobalBody(ptr %v0, ptr %t134, i64 %t138)
  store i1 %t141, ptr %l85
  br label %bb37
bb37:
  %t142 = load i1, ptr %l85, !tbaa !21
  store i1 %t142, ptr %l81, !tbaa !21
  br label %bb38
bb38:
  %t143 = load i1, ptr %l81, !tbaa !21
  br i1 %t143, label %bb39, label %bb40
bb39:
  store %olang.scope zeroinitializer, ptr %s7
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l86, !tbaa !29
  %t145 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t145, ptr %l87
  %t146 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTryNowhereToGo(ptr %s7)
  store %"compiler/msgs:Msg" %t146, ptr %l88
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t147 = load ptr, ptr %l86, !tbaa !29
  %t148 = load %"compiler/source:Span", ptr %l87
  %t149 = load %"compiler/msgs:Msg", ptr %l88
  %t150 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t147, %"compiler/source:Span" %t148, %"compiler/msgs:Msg" %t149)
  store i64 %t150, ptr %l89
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  br label %ret
bb43:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load ptr, ptr %l4, !tbaa !29
  %t154 = getelementptr %"compiler/check:frame", ptr %t152, i32 0, i32 6
  %t155 = load i32, ptr %t154, !tbaa !23
  %t156 = load i32, ptr %l11, !tbaa !23
  %t160 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euncovered(ptr %v0, ptr %t151, i32 %t155, i32 %t156)
  store i32 %t160, ptr %l94
  br label %bb44
bb44:
  %t161 = load i32, ptr %l94, !tbaa !23
  store i32 %t161, ptr %l12, !tbaa !23
  %t162 = load i32, ptr %l12, !tbaa !23
  %t163 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t166 = icmp ne i32 %t162, %t163
  br i1 %t166, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s8
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/check:Checker", ptr %t168, i32 0, i32 5
  %t171 = load i1, ptr %t170, !tbaa !21
  store i1 %t171, ptr %l13, !tbaa !21
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/check:Checker", ptr %t173, i32 0, i32 5
  store i1 true, ptr %t175, !tbaa !21
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load i32, ptr %l12, !tbaa !23
  %t180 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s8, ptr %t176, i32 %t177)
  store { i64, ptr } %t180, ptr %l103
  br label %bb47
bb46:
  br label %bb55
bb47:
  %t181 = load { i64, ptr }, ptr %l103, !tbaa !27
  store { i64, ptr } %t181, ptr %l14, !tbaa !27
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load i1, ptr %l13, !tbaa !21
  %t186 = getelementptr %"compiler/check:Checker", ptr %t182, i32 0, i32 5
  store i1 %t183, ptr %t186, !tbaa !21
  %t187 = load ptr, ptr %l0, !tbaa !29
  store ptr %t187, ptr %l106, !tbaa !29
  %t188 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t188, ptr %l107
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t189)
  store ptr %t191, ptr %l109
  br label %bb48
bb48:
  %t192 = load ptr, ptr %l109, !tbaa !29
  %t194 = getelementptr %"compiler/check:frame", ptr %t192, i32 0, i32 20
  %t195 = load i1, ptr %t194, !tbaa !21
  br i1 %t195, label %bb49, label %bb50
bb49:
  %t197 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t199 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenErrorNotDeclared(ptr %s8, ptr %s8, { i64, ptr } %t197)
  store %"compiler/msgs:Msg" %t199, ptr %l114
  br label %bb51
bb50:
  %t200 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t202 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTryErrorNotDeclared(ptr %s8, ptr %s8, { i64, ptr } %t200)
  store %"compiler/msgs:Msg" %t202, ptr %l116
  br label %bb52
bb51:
  %t203 = load %"compiler/msgs:Msg", ptr %l114
  store %"compiler/msgs:Msg" %t203, ptr %l112
  br label %bb53
bb52:
  %t204 = load %"compiler/msgs:Msg", ptr %l116
  store %"compiler/msgs:Msg" %t204, ptr %l112
  br label %bb53
bb53:
  %t205 = load ptr, ptr %l106, !tbaa !29
  %t206 = load %"compiler/source:Span", ptr %l107
  %t207 = load %"compiler/msgs:Msg", ptr %l112
  %t208 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t205, %"compiler/source:Span" %t206, %"compiler/msgs:Msg" %t207)
  store i64 %t208, ptr %l117
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s6)
  br label %ret
bb55:
  call void @__olang_scope_close(ptr %s6)
  br label %bb56
bb56:
  %t209 = load i64, ptr %l9, !tbaa !24
  %t211 = add i64 %t209, 1
  store i64 %t211, ptr %l9, !tbaa !24
  br label %bb30
bb57:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eevalOnly(ptr %v0, ptr %a0) #0 {
entry:
  %l3 = alloca ptr
  %l6 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %a0)
  store ptr %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 1
  %t7 = load { i64, [2 x i64] }, ptr %t6
  %t11 = extractvalue { i64, [2 x i64] } %t7, 0
  %t12 = icmp eq i64 %t11, 7
  br i1 %t12, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_a993cda7425ca237_a63aa9ad7bf8dd03)
  unreachable
bb10:
  %t14 = load i1, ptr %l6, !tbaa !21
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexhaustedOrBreak(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %lp6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %lp8 = alloca ptr
  %l11 = alloca i32
  %l14 = alloca i64
  %l25 = alloca ptr
  %l29 = alloca i32
  %l33 = alloca { i64, ptr }
  %l34 = alloca %"compiler/typed:Block"
  %l35 = alloca %"compiler/typed:Item"
  %l37 = alloca %"compiler/typed:Item"
  %l41 = alloca { i64, ptr }
  %l43 = alloca %"compiler/typed:Item"
  %l44 = alloca %"compiler/source:Span"
  %l45 = alloca { i64, ptr }
  %l46 = alloca ptr
  %l50 = alloca %"compiler/typed:Clause"
  %l53 = alloca %"compiler/source:Span"
  %l56 = alloca i32
  %l61 = alloca %"compiler/typed:Try"
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t22 = alloca { i64, [3 x i64] }, align 8
  %t70 = alloca i64
  %t128 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s0, ptr %s0, ptr %t4, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d7, i32 0, i32 1) }, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i32 %t6, ptr %l11
  br label %bb1
bb1:
  %t7 = load i32, ptr %l11, !tbaa !23
  store i32 %t7, ptr %l4, !tbaa !23
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/check:Checker", ptr %t8, i32 0, i32 33
  %t12 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l14
  br label %bb2
bb2:
  %t13 = load i64, ptr %l14, !tbaa !24
  store i64 %t13, ptr %l5, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 33
  %t17 = load %"compiler/source:Span", ptr %l1
  %t20 = trunc i64 %a3 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t22
  %t23 = getelementptr { i64, [3 x i64] }, ptr %t22, i32 0, i32 0
  store i64 5, ptr %t23
  %t25 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t17, 0
  %t27 = insertvalue { %"compiler/source:Span", i32, i32 } %t25, i32 0, 1
  %t29 = insertvalue { %"compiler/source:Span", i32, i32 } %t27, i32 %t20, 2
  %t30 = getelementptr { i64, [3 x i64] }, ptr %t22, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t29, ptr %t30
  %t31 = load { i64, [3 x i64] }, ptr %t22
  %t33 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t31, ptr %t33
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v0, ptr %t16, ptr %t33)
  br label %bb3
bb3:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t36)
  store ptr %t38, ptr %l25
  br label %bb4
bb4:
  %t39 = load ptr, ptr %l25, !tbaa !29
  %t41 = getelementptr %"compiler/check:frame", ptr %t39, i32 0, i32 7
  %t42 = load i64, ptr %t41, !tbaa !24
  %t44 = trunc i64 %t42 to i32
  store i32 %t44, ptr %l29, !tbaa !23
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 33
  %t49 = load i64, ptr %l5, !tbaa !24
  %t52 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t48, i64 %t49)
  store { i64, ptr } %t52, ptr %l33
  br label %bb5
bb5:
  %t53 = load i32, ptr %l29, !tbaa !23
  %t54 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t55 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 %t53, { i64, ptr } %t54)
  store %"compiler/typed:Block" %t55, ptr %l34
  br label %bb6
bb6:
  %t56 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store ptr %t56, ptr %lp6
  %t57 = load %"compiler/typed:Block", ptr %l34
  %t58 = load ptr, ptr %lp6
  store %"compiler/typed:Block" %t57, ptr %t58
  store %"compiler/typed:Item" zeroinitializer, ptr %l35
  %t59 = icmp sgt i64 1, 0
  br i1 %t59, label %bb7, label %bb8
bb7:
  %t61 = call %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %v0, i32 0, i64 0)
  store %"compiler/typed:Item" %t61, ptr %l37
  br label %bb9
bb8:
  %t62 = icmp sge i64 1, 0
  br i1 %t62, label %bb10, label %bb11
bb9:
  %t64 = load %"compiler/typed:Item", ptr %l37
  store %"compiler/typed:Item" %t64, ptr %l35
  br label %bb8
bb10:
  %t65 = icmp sle i64 1, 576460752303423487
  br i1 %t65, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_8e26fbb1c5557eef_13e6cc5de085742b)
  unreachable
bb12:
  %t67 = mul i64 1, 16
  %t68 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t67)
  %t69 = load %"compiler/typed:Item", ptr %l35
  store i64 0, ptr %t70
  br label %fill.71
fill.71:
  %t74 = load i64, ptr %t70
  %t75 = icmp slt i64 %t74, 1
  br i1 %t75, label %fillb.72, label %filld.73
fillb.72:
  %t76 = getelementptr %"compiler/typed:Item", ptr %t68, i64 %t74
  store %"compiler/typed:Item" %t69, ptr %t76
  %t77 = add i64 %t74, 1
  store i64 %t77, ptr %t70
  br label %fill.71
filld.73:
  %t78 = insertvalue { i64, ptr } undef, i64 1, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t68, 1
  store { i64, ptr } %t79, ptr %l7, !tbaa !27
  %t81 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t81, ptr %l41, !tbaa !27
  %t82 = load i32, ptr %l4, !tbaa !23
  %t84 = call %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %s0, i32 %t82, i64 -1)
  store %"compiler/typed:Item" %t84, ptr %l43
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_8e26fbb1c5557eef_13e6cc5de085742b)
  unreachable
bb14:
  %t85 = load %"compiler/typed:Item", ptr %l43
  %t86 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr %"compiler/typed:Item", ptr %t87, i64 0
  store %"compiler/typed:Item" %t85, ptr %t88
  %t89 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t89, ptr %l44
  %t90 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t90, ptr %l45, !tbaa !27
  %t91 = load ptr, ptr %lp6
  store ptr %t91, ptr %l46, !tbaa !29
  %t92 = icmp sge i64 0, 0
  br i1 %t92, label %bb15, label %bb16
bb15:
  %t94 = icmp sle i64 0, 1152921504606846975
  br i1 %t94, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_6d702b04e725ae1a_71c02c55b3dfc416)
  unreachable
bb17:
  %t96 = mul i64 0, 8
  %t97 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t96)
  %t98 = insertvalue { i64, ptr } undef, i64 0, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t97, 1
  %t100 = load %"compiler/source:Span", ptr %l44
  %t101 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t102 = load ptr, ptr %l46, !tbaa !29
  %t104 = call %"compiler/typed:Clause" @compiler_2ftyped_3aClause_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t100, { i64, ptr } %t101, i1 false, ptr %t102, { i64, ptr } %t99, i64 -1, i32 0)
  store %"compiler/typed:Clause" %t104, ptr %l50
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_6d702b04e725ae1a_71c02c55b3dfc416)
  unreachable
bb19:
  %t105 = load %"compiler/typed:Clause", ptr %l50
  %t106 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store %"compiler/typed:Clause" %t105, ptr %t106
  %t108 = insertvalue [1 x ptr] undef, ptr %t106, 0
  %t109 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store ptr %t109, ptr %lp8
  %t111 = load ptr, ptr %lp8
  store [1 x ptr] %t108, ptr %t111
  %t112 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t112, ptr %l53
  %t113 = load ptr, ptr %l2, !tbaa !29
  %t116 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t113)
  store i32 %t116, ptr %l56
  br label %bb20
bb20:
  %t117 = load ptr, ptr %l2, !tbaa !29
  %t119 = load ptr, ptr %lp8
  %t121 = insertvalue { i64, ptr } undef, i64 1, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t119, 1
  %t125 = call %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t117, { i64, ptr } %t122, i1 false, i1 true)
  store %"compiler/typed:Try" %t125, ptr %l61
  br label %bb21
bb21:
  %t126 = load %"compiler/typed:Try", ptr %l61
  %t127 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/typed:Try" %t126, ptr %t127
  store { i64, [5 x i64] } zeroinitializer, ptr %t128
  %t129 = getelementptr { i64, [5 x i64] }, ptr %t128, i32 0, i32 0
  store i64 14, ptr %t129
  %t130 = load %"compiler/source:Span", ptr %l53
  %t131 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t130, 0
  %t132 = load i32, ptr %l56, !tbaa !23
  %t133 = insertvalue { %"compiler/source:Span", i32, ptr } %t131, i32 %t132, 1
  %t135 = insertvalue { %"compiler/source:Span", i32, ptr } %t133, ptr %t127, 2
  %t136 = getelementptr { i64, [5 x i64] }, ptr %t128, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t135, ptr %t136
  %t137 = load { i64, [5 x i64] }, ptr %t128
  %t139 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t137, ptr %t139
  call void @__olang_scope_close(ptr %s0)
  store ptr %t139, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexportRules(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, [3 x i64] }
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca %"compiler/source:Span"
  %l17 = alloca i32
  %l21 = alloca ptr
  %l25 = alloca i64
  %l31 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l54 = alloca ptr
  %l55 = alloca { i64, [3 x i64] }
  %l56 = alloca %"compiler/msgs:Msg"
  %l57 = alloca i64
  %l62 = alloca i1
  %l64 = alloca ptr
  %l66 = alloca i64
  %l67 = alloca i64
  %l72 = alloca ptr
  %l73 = alloca { i64, [3 x i64] }
  %l74 = alloca %"compiler/msgs:Msg"
  %l75 = alloca i64
  %l77 = alloca i1
  %l78 = alloca i1
  %l80 = alloca i1
  %l84 = alloca ptr
  %l85 = alloca { i64, [3 x i64] }
  %l87 = alloca { i64, ptr }
  %l89 = alloca %"compiler/msgs:Msg"
  %l90 = alloca i64
  %l94 = alloca i32
  %l97 = alloca ptr
  %l102 = alloca i32
  %l103 = alloca { i64, ptr }
  %l111 = alloca i64
  %l114 = alloca i64
  %l136 = alloca { i64, ptr }
  %l142 = alloca i1
  %l145 = alloca i1
  %l148 = alloca { i64, ptr }
  %l155 = alloca ptr
  %l156 = alloca i64
  %l158 = alloca i64
  %l160 = alloca i64
  %l164 = alloca { i64, ptr }
  %l168 = alloca { i64, ptr }
  %l171 = alloca { i64, [3 x i64] }
  %l174 = alloca { i64, ptr }
  %l176 = alloca %"compiler/msgs:Msg"
  %l177 = alloca i64
  %l184 = alloca i32
  %l188 = alloca i1
  %l192 = alloca i1
  %l203 = alloca i1
  %l206 = alloca i1
  %l207 = alloca i1
  %l210 = alloca i1
  %l215 = alloca ptr
  %l216 = alloca i64
  %l219 = alloca { i64, ptr }
  %l221 = alloca %"compiler/source:Span"
  %l223 = alloca i64
  %l226 = alloca { i64, ptr }
  %l233 = alloca %"compiler/source:Span"
  %l236 = alloca { i64, [3 x i64] }
  %l239 = alloca { i64, ptr }
  %l241 = alloca %"compiler/msgs:Msg"
  %l242 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %t63 = alloca { i64, [3 x i64] }, align 8
  %t349 = alloca { i64, [3 x i64] }, align 8
  %t503 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l21
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l21, !tbaa !29
  store ptr %t9, ptr %l2, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l25
  br label %bb2
bb2:
  %t18 = load i64, ptr %l25, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/load:Loader", ptr %t25, i32 0, i32 5
  %t31 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t27, i64 %t18)
  store ptr %t31, ptr %l31
  br label %bb3
bb3:
  %t32 = load ptr, ptr %l31, !tbaa !29
  %t34 = getelementptr %"compiler/load:Module", ptr %t32, i32 0, i32 4
  %t35 = load i64, ptr %t34, !tbaa !24
  store i64 %t35, ptr %l4, !tbaa !24
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l2, !tbaa !29
  %t40 = getelementptr %"compiler/ast:Func", ptr %t38, i32 0, i32 2
  %t41 = load i32, ptr %t40, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t37, i32 %t41)
  store { i64, ptr } %t44, ptr %l37
  br label %bb4
bb4:
  %t45 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t45, ptr %l5, !tbaa !27
  %t46 = load i64, ptr %l4, !tbaa !24
  %t47 = load ptr, ptr %l2, !tbaa !29
  %t49 = getelementptr %"compiler/ast:Func", ptr %t47, i32 0, i32 0
  %t50 = getelementptr %"compiler/source:Span", ptr %t49, i32 0, i32 0
  %t51 = load i32, ptr %t50, !tbaa !23
  %t53 = sext i32 %t51 to i64
  %t54 = load ptr, ptr %l2, !tbaa !29
  %t56 = getelementptr %"compiler/ast:Func", ptr %t54, i32 0, i32 0
  %t57 = getelementptr %"compiler/source:Span", ptr %t56, i32 0, i32 0
  %t58 = load i32, ptr %t57, !tbaa !23
  %t60 = sext i32 %t58 to i64
  %t62 = add i64 %t60, 6
  store { i64, [3 x i64] } zeroinitializer, ptr %t63
  %t64 = getelementptr { i64, [3 x i64] }, ptr %t63, i32 0, i32 0
  store i64 3, ptr %t64
  %t66 = insertvalue { i64, i64, i64 } undef, i64 %t46, 0
  %t68 = insertvalue { i64, i64, i64 } %t66, i64 %t53, 1
  %t70 = insertvalue { i64, i64, i64 } %t68, i64 %t62, 2
  %t71 = getelementptr { i64, [3 x i64] }, ptr %t63, i32 0, i32 1
  store { i64, i64, i64 } %t70, ptr %t71
  %t72 = load { i64, [3 x i64] }, ptr %t63
  store { i64, [3 x i64] } %t72, ptr %l6
  %t74 = load ptr, ptr %l2, !tbaa !29
  %t76 = getelementptr %"compiler/ast:Func", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = icmp eq ptr %t77, null
  %t81 = xor i1 %t79, true
  br i1 %t81, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 0
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr %"compiler/load:Loader", ptr %t89, i32 0, i32 4
  %t92 = load ptr, ptr %t91, !tbaa !29
  store ptr %t92, ptr %l54, !tbaa !29
  %t93 = load { i64, [3 x i64] }, ptr %l6
  store { i64, [3 x i64] } %t93, ptr %l55
  %t94 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eExportMethod(ptr %s1)
  store %"compiler/msgs:Msg" %t94, ptr %l56
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t95 = load ptr, ptr %l54, !tbaa !29
  %t96 = load { i64, [3 x i64] }, ptr %l55
  %t97 = load %"compiler/msgs:Msg", ptr %l56
  %t98 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s1, ptr %t95, { i64, [3 x i64] } %t96, %"compiler/msgs:Msg" %t97)
  store i64 %t98, ptr %l57
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb9:
  %t99 = load ptr, ptr %l2, !tbaa !29
  %t101 = getelementptr %"compiler/ast:Func", ptr %t99, i32 0, i32 5
  %t102 = load { i64, ptr }, ptr %t101, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t102, 0
  %t106 = icmp sgt i64 %t104, 0
  br i1 %t106, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb14
bb11:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/check:Checker", ptr %t108, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !29
  store ptr %t111, ptr %l64, !tbaa !29
  %t112 = load i64, ptr %l1, !tbaa !24
  %t114 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t112)
  store i64 %t114, ptr %l66
  br label %bb12
bb12:
  %t115 = load ptr, ptr %l64, !tbaa !29
  %t116 = load i64, ptr %l66, !tbaa !24
  %t117 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t115, i64 %t116)
  store i64 %t117, ptr %l67
  br label %bb13
bb13:
  %t118 = load i64, ptr %l67, !tbaa !24
  %t119 = icmp sgt i64 %t118, 0
  store i1 %t119, ptr %l62, !tbaa !21
  br label %bb14
bb14:
  %t121 = load i1, ptr %l62, !tbaa !21
  br i1 %t121, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/check:Checker", ptr %t122, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !29
  %t127 = getelementptr %"compiler/generic:Program", ptr %t125, i32 0, i32 0
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t130 = getelementptr %"compiler/load:Loader", ptr %t128, i32 0, i32 4
  %t131 = load ptr, ptr %t130, !tbaa !29
  store ptr %t131, ptr %l72, !tbaa !29
  %t132 = load { i64, [3 x i64] }, ptr %l6
  store { i64, [3 x i64] } %t132, ptr %l73
  %t133 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eExportGeneric(ptr %s2)
  store %"compiler/msgs:Msg" %t133, ptr %l74
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t134 = load ptr, ptr %l72, !tbaa !29
  %t135 = load { i64, [3 x i64] }, ptr %l73
  %t136 = load %"compiler/msgs:Msg", ptr %l74
  %t137 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s2, ptr %t134, { i64, [3 x i64] } %t135, %"compiler/msgs:Msg" %t136)
  store i64 %t137, ptr %l75
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb19:
  %t138 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t140 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t138, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d9, i32 0, i32 1) })
  store i1 %t140, ptr %l77
  br label %bb20
bb20:
  %t141 = load i1, ptr %l77, !tbaa !21
  br i1 %t141, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l78, !tbaa !21
  br label %bb24
bb22:
  %t142 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t144 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t142, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i1 %t144, ptr %l80
  br label %bb23
bb23:
  %t145 = load i1, ptr %l80, !tbaa !21
  store i1 %t145, ptr %l78, !tbaa !21
  br label %bb24
bb24:
  %t146 = load i1, ptr %l78, !tbaa !21
  br i1 %t146, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s3
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/check:Checker", ptr %t147, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t152 = getelementptr %"compiler/generic:Program", ptr %t150, i32 0, i32 0
  %t153 = load ptr, ptr %t152, !tbaa !29
  %t155 = getelementptr %"compiler/load:Loader", ptr %t153, i32 0, i32 4
  %t156 = load ptr, ptr %t155, !tbaa !29
  store ptr %t156, ptr %l84, !tbaa !29
  %t157 = load { i64, [3 x i64] }, ptr %l6
  store { i64, [3 x i64] } %t157, ptr %l85
  %t158 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t160 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %s3, { i64, ptr } %t158)
  store { i64, ptr } %t160, ptr %l87
  br label %bb27
bb26:
  br label %bb30
bb27:
  %t161 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t161, 0
  %t163 = extractvalue { i64, ptr } %t161, 1
  %t164 = mul i64 %t162, 1
  %t165 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t164)
  call void @llvm.memcpy.p0.p0.i64(ptr %t165, ptr %t163, i64 %t164, i1 false)
  %t166 = insertvalue { i64, ptr } undef, i64 %t162, 0
  %t167 = insertvalue { i64, ptr } %t166, ptr %t165, 1
  %t169 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eExportName(ptr %s3, ptr %s3, { i64, ptr } %t167)
  store %"compiler/msgs:Msg" %t169, ptr %l89
  br label %bb28
bb28:
  %t170 = load ptr, ptr %l84, !tbaa !29
  %t171 = load { i64, [3 x i64] }, ptr %l85
  %t172 = load %"compiler/msgs:Msg", ptr %l89
  %t173 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s3, ptr %t170, { i64, [3 x i64] } %t171, %"compiler/msgs:Msg" %t172)
  store i64 %t173, ptr %l90
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb30:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/check:Checker", ptr %t174, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !29
  %t178 = load i64, ptr %l1, !tbaa !24
  %t181 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t177, i64 %t178)
  store i32 %t181, ptr %l94
  br label %bb31
bb31:
  %t182 = load i32, ptr %l94, !tbaa !23
  store i32 %t182, ptr %l7, !tbaa !23
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/check:Checker", ptr %t183, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !29
  %t188 = getelementptr %"compiler/generic:Program", ptr %t186, i32 0, i32 2
  store ptr %t188, ptr %l97, !tbaa !29
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/check:Checker", ptr %t189, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t194 = getelementptr %"compiler/generic:Program", ptr %t192, i32 0, i32 2
  %t195 = load i32, ptr %l7, !tbaa !23
  %t198 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t194, i32 %t195)
  store i32 %t198, ptr %l102
  br label %bb32
bb32:
  %t199 = load ptr, ptr %l97, !tbaa !29
  %t200 = load i32, ptr %l102, !tbaa !23
  %t201 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t199, i32 %t200)
  store { i64, ptr } %t201, ptr %l103
  br label %bb33
bb33:
  %t202 = load { i64, ptr }, ptr %l103, !tbaa !27
  store { i64, ptr } %t202, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t203 = load ptr, ptr %l2, !tbaa !29
  %t205 = getelementptr %"compiler/ast:Func", ptr %t203, i32 0, i32 3
  %t206 = load ptr, ptr %t205, !tbaa !29
  %t208 = getelementptr %"compiler/ast:Sig", ptr %t206, i32 0, i32 0
  %t209 = load { i64, ptr }, ptr %t208, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t209, 0
  store i64 %t211, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t213 = load i64, ptr %l10, !tbaa !24
  %t214 = load i64, ptr %l9, !tbaa !24
  %t217 = icmp sgt i64 %t213, %t214
  br i1 %t217, label %bb34, label %bb35
bb34:
  %t219 = load i64, ptr %l11, !tbaa !24
  %t221 = icmp sgt i64 %t219, 0
  br i1 %t221, label %bb36, label %bb37
bb35:
  store i64 0, ptr %l111, !tbaa !24
  br label %bb39
bb36:
  %t223 = load i64, ptr %l10, !tbaa !24
  %t224 = load i64, ptr %l9, !tbaa !24
  %t227 = sub i64 %t223, %t224
  %t228 = load i64, ptr %l11, !tbaa !24
  %t231 = add i64 %t227, %t228
  %t233 = sub i64 %t231, 1
  %t234 = load i64, ptr %l11, !tbaa !24
  %t237 = sdiv i64 %t233, %t234
  store i64 %t237, ptr %l114, !tbaa !24
  br label %bb38
bb37:
  store i64 0, ptr %l114, !tbaa !24
  br label %bb38
bb38:
  %t239 = load i64, ptr %l114, !tbaa !24
  store i64 %t239, ptr %l111, !tbaa !24
  br label %bb39
bb39:
  %t240 = load i64, ptr %l111, !tbaa !24
  store i64 %t240, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s5
  %t241 = load i64, ptr %l13, !tbaa !24
  %t242 = load i64, ptr %l12, !tbaa !24
  %t245 = icmp slt i64 %t241, %t242
  %t247 = xor i1 %t245, true
  br i1 %t247, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s5)
  br label %bb59
bb42:
  br label %bb43
bb43:
  %t249 = load i64, ptr %l9, !tbaa !24
  %t250 = load i64, ptr %l13, !tbaa !24
  %t251 = load i64, ptr %l11, !tbaa !24
  %t254 = mul i64 %t250, %t251
  %t257 = add i64 %t249, %t254
  store i64 %t257, ptr %l14, !tbaa !24
  %t259 = load i64, ptr %l14, !tbaa !24
  %t260 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t262 = extractvalue { i64, ptr } %t260, 0
  %t265 = icmp sge i64 %t259, %t262
  br i1 %t265, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s5)
  br label %bb59
bb45:
  br label %bb46
bb46:
  %t267 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t267, ptr %l136, !tbaa !27
  %t268 = load i64, ptr %l14, !tbaa !24
  %t270 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t271 = load ptr, ptr %t270, !tbaa !27
  %t272 = getelementptr i32, ptr %t271, i64 %t268
  %t273 = load i32, ptr %t272, !tbaa !33
  store i32 %t273, ptr %l15, !tbaa !23
  %t275 = load i32, ptr %l15, !tbaa !23
  %t276 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t279 = icmp eq i32 %t275, %t276
  br i1 %t279, label %bb47, label %bb48
bb47:
  store i1 true, ptr %l142, !tbaa !21
  br label %bb50
bb48:
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t282 = load i32, ptr %l15, !tbaa !23
  %t285 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexportParam(ptr %v0, ptr %t281, i32 %t282)
  store i1 %t285, ptr %l145
  br label %bb49
bb49:
  %t286 = load i1, ptr %l145, !tbaa !21
  store i1 %t286, ptr %l142, !tbaa !21
  br label %bb50
bb50:
  %t287 = load i1, ptr %l142, !tbaa !21
  br i1 %t287, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s5)
  br label %bb58
bb52:
  br label %bb53
bb53:
  %t288 = load ptr, ptr %l2, !tbaa !29
  %t290 = getelementptr %"compiler/ast:Func", ptr %t288, i32 0, i32 3
  %t291 = load ptr, ptr %t290, !tbaa !29
  %t293 = getelementptr %"compiler/ast:Sig", ptr %t291, i32 0, i32 0
  %t294 = load { i64, ptr }, ptr %t293, !tbaa !27
  store { i64, ptr } %t294, ptr %l148, !tbaa !27
  %t295 = load i64, ptr %l14, !tbaa !24
  %t297 = getelementptr { i64, ptr }, ptr %l148, i32 0, i32 1
  %t298 = load ptr, ptr %t297, !tbaa !27
  %t299 = getelementptr ptr, ptr %t298, i64 %t295
  %t300 = load ptr, ptr %t299, !tbaa !39
  %t302 = getelementptr %"compiler/ast:Param", ptr %t300, i32 0, i32 0
  %t303 = load %"compiler/source:Span", ptr %t302
  store %"compiler/source:Span" %t303, ptr %l16
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t307 = getelementptr %"compiler/check:Checker", ptr %t305, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !29
  %t310 = getelementptr %"compiler/generic:Program", ptr %t308, i32 0, i32 0
  %t311 = load ptr, ptr %t310, !tbaa !29
  %t313 = getelementptr %"compiler/load:Loader", ptr %t311, i32 0, i32 4
  %t314 = load ptr, ptr %t313, !tbaa !29
  store ptr %t314, ptr %l155, !tbaa !29
  %t315 = load i64, ptr %l4, !tbaa !24
  store i64 %t315, ptr %l156, !tbaa !24
  %t316 = getelementptr %"compiler/source:Span", ptr %l16, i32 0, i32 0
  %t317 = load i32, ptr %t316, !tbaa !23
  %t319 = sext i32 %t317 to i64
  store i64 %t319, ptr %l158, !tbaa !24
  %t320 = getelementptr %"compiler/source:Span", ptr %l16, i32 0, i32 0
  %t321 = load i32, ptr %t320, !tbaa !23
  %t323 = sext i32 %t321 to i64
  store i64 %t323, ptr %l160, !tbaa !24
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t325 = load ptr, ptr %l2, !tbaa !29
  %t327 = getelementptr %"compiler/ast:Func", ptr %t325, i32 0, i32 3
  %t328 = load ptr, ptr %t327, !tbaa !29
  %t330 = getelementptr %"compiler/ast:Sig", ptr %t328, i32 0, i32 0
  %t331 = load { i64, ptr }, ptr %t330, !tbaa !27
  store { i64, ptr } %t331, ptr %l164, !tbaa !27
  %t332 = load i64, ptr %l14, !tbaa !24
  %t334 = getelementptr { i64, ptr }, ptr %l164, i32 0, i32 1
  %t335 = load ptr, ptr %t334, !tbaa !27
  %t336 = getelementptr ptr, ptr %t335, i64 %t332
  %t337 = load ptr, ptr %t336, !tbaa !39
  %t339 = getelementptr %"compiler/ast:Param", ptr %t337, i32 0, i32 1
  %t340 = load i32, ptr %t339, !tbaa !23
  %t343 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t324, i32 %t340)
  store { i64, ptr } %t343, ptr %l168
  br label %bb54
bb54:
  %t344 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t345 = extractvalue { i64, ptr } %t344, 0
  %t346 = load i64, ptr %l160, !tbaa !24
  %t348 = add i64 %t346, %t345
  store { i64, [3 x i64] } zeroinitializer, ptr %t349
  %t350 = getelementptr { i64, [3 x i64] }, ptr %t349, i32 0, i32 0
  store i64 3, ptr %t350
  %t351 = load i64, ptr %l156, !tbaa !24
  %t352 = insertvalue { i64, i64, i64 } undef, i64 %t351, 0
  %t353 = load i64, ptr %l158, !tbaa !24
  %t354 = insertvalue { i64, i64, i64 } %t352, i64 %t353, 1
  %t356 = insertvalue { i64, i64, i64 } %t354, i64 %t348, 2
  %t357 = getelementptr { i64, [3 x i64] }, ptr %t349, i32 0, i32 1
  store { i64, i64, i64 } %t356, ptr %t357
  %t358 = load { i64, [3 x i64] }, ptr %t349
  store { i64, [3 x i64] } %t358, ptr %l171
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t360 = load i32, ptr %l15, !tbaa !23
  %t363 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t359, i32 %t360)
  store { i64, ptr } %t363, ptr %l174
  br label %bb55
bb55:
  %t364 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t365 = extractvalue { i64, ptr } %t364, 0
  %t366 = extractvalue { i64, ptr } %t364, 1
  %t367 = mul i64 %t365, 1
  %t368 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t367)
  call void @llvm.memcpy.p0.p0.i64(ptr %t368, ptr %t366, i64 %t367, i1 false)
  %t369 = insertvalue { i64, ptr } undef, i64 %t365, 0
  %t370 = insertvalue { i64, ptr } %t369, ptr %t368, 1
  %t372 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eExportType(ptr %s5, ptr %s5, { i64, ptr } %t370)
  store %"compiler/msgs:Msg" %t372, ptr %l176
  br label %bb56
bb56:
  %t373 = load ptr, ptr %l155, !tbaa !29
  %t374 = load { i64, [3 x i64] }, ptr %l171
  %t375 = load %"compiler/msgs:Msg", ptr %l176
  %t376 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s5, ptr %t373, { i64, [3 x i64] } %t374, %"compiler/msgs:Msg" %t375)
  store i64 %t376, ptr %l177
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s5)
  br label %bb58
bb58:
  %t377 = load i64, ptr %l13, !tbaa !24
  %t379 = add i64 %t377, 1
  store i64 %t379, ptr %l13, !tbaa !24
  br label %bb40
bb59:
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t383 = getelementptr %"compiler/check:Checker", ptr %t381, i32 0, i32 1
  %t384 = load ptr, ptr %t383, !tbaa !29
  %t386 = getelementptr %"compiler/generic:Program", ptr %t384, i32 0, i32 2
  %t387 = load i32, ptr %l7, !tbaa !23
  %t390 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t386, i32 %t387)
  store i32 %t390, ptr %l184
  br label %bb60
bb60:
  %t391 = load i32, ptr %l184, !tbaa !23
  store i32 %t391, ptr %l17, !tbaa !23
  %t392 = load i32, ptr %l17, !tbaa !23
  %t393 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t396 = icmp eq i32 %t392, %t393
  br i1 %t396, label %bb61, label %bb62
bb61:
  store i1 true, ptr %l188, !tbaa !21
  br label %bb63
bb62:
  %t398 = load i32, ptr %l17, !tbaa !23
  %t399 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t402 = icmp eq i32 %t398, %t399
  store i1 %t402, ptr %l188, !tbaa !21
  br label %bb63
bb63:
  %t404 = load i1, ptr %l188, !tbaa !21
  br i1 %t404, label %bb64, label %bb65
bb64:
  store i1 true, ptr %l192, !tbaa !21
  br label %bb66
bb65:
  %t405 = load ptr, ptr %l2, !tbaa !29
  %t407 = getelementptr %"compiler/ast:Func", ptr %t405, i32 0, i32 3
  %t408 = load ptr, ptr %t407, !tbaa !29
  %t410 = getelementptr %"compiler/ast:Sig", ptr %t408, i32 0, i32 1
  %t411 = load { i64, ptr }, ptr %t410, !tbaa !27
  %t413 = extractvalue { i64, ptr } %t411, 0
  %t415 = icmp eq i64 %t413, 0
  store i1 %t415, ptr %l192, !tbaa !21
  br label %bb66
bb66:
  %t417 = load i1, ptr %l192, !tbaa !21
  br i1 %t417, label %bb67, label %bb68
bb67:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb68:
  br label %bb69
bb69:
  %t418 = load ptr, ptr %l2, !tbaa !29
  %t420 = getelementptr %"compiler/ast:Func", ptr %t418, i32 0, i32 3
  %t421 = load ptr, ptr %t420, !tbaa !29
  %t423 = getelementptr %"compiler/ast:Sig", ptr %t421, i32 0, i32 1
  %t424 = load { i64, ptr }, ptr %t423, !tbaa !27
  %t426 = extractvalue { i64, ptr } %t424, 0
  %t428 = icmp sgt i64 %t426, 1
  br i1 %t428, label %bb70, label %bb71
bb70:
  store i1 true, ptr %l203, !tbaa !21
  br label %bb77
bb71:
  %t430 = load ptr, ptr %l0, !tbaa !29
  %t431 = load i32, ptr %l17, !tbaa !23
  %t434 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %t430, i32 %t431)
  store i1 %t434, ptr %l206
  br label %bb72
bb72:
  %t435 = load i1, ptr %l206, !tbaa !21
  br i1 %t435, label %bb73, label %bb74
bb73:
  store i1 true, ptr %l207, !tbaa !21
  br label %bb76
bb74:
  %t436 = load ptr, ptr %l0, !tbaa !29
  %t437 = load i32, ptr %l17, !tbaa !23
  %t440 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexportArray(ptr %v0, ptr %t436, i32 %t437)
  store i1 %t440, ptr %l210
  br label %bb75
bb75:
  %t441 = load i1, ptr %l210, !tbaa !21
  store i1 %t441, ptr %l207, !tbaa !21
  br label %bb76
bb76:
  %t442 = load i1, ptr %l207, !tbaa !21
  %t443 = xor i1 %t442, true
  store i1 %t443, ptr %l203, !tbaa !21
  br label %bb77
bb77:
  %t445 = load i1, ptr %l203, !tbaa !21
  br i1 %t445, label %bb78, label %bb79
bb78:
  store %olang.scope zeroinitializer, ptr %s10
  %t446 = load ptr, ptr %l0, !tbaa !29
  %t448 = getelementptr %"compiler/check:Checker", ptr %t446, i32 0, i32 1
  %t449 = load ptr, ptr %t448, !tbaa !29
  %t451 = getelementptr %"compiler/generic:Program", ptr %t449, i32 0, i32 0
  %t452 = load ptr, ptr %t451, !tbaa !29
  %t454 = getelementptr %"compiler/load:Loader", ptr %t452, i32 0, i32 4
  %t455 = load ptr, ptr %t454, !tbaa !29
  store ptr %t455, ptr %l215, !tbaa !29
  %t456 = load i64, ptr %l4, !tbaa !24
  store i64 %t456, ptr %l216, !tbaa !24
  %t457 = load ptr, ptr %l2, !tbaa !29
  %t459 = getelementptr %"compiler/ast:Func", ptr %t457, i32 0, i32 3
  %t460 = load ptr, ptr %t459, !tbaa !29
  %t462 = getelementptr %"compiler/ast:Sig", ptr %t460, i32 0, i32 1
  %t463 = load { i64, ptr }, ptr %t462, !tbaa !27
  store { i64, ptr } %t463, ptr %l219, !tbaa !27
  %t464 = getelementptr { i64, ptr }, ptr %l219, i32 0, i32 1
  %t465 = load ptr, ptr %t464, !tbaa !27
  %t466 = getelementptr ptr, ptr %t465, i64 0
  %t467 = load ptr, ptr %t466, !tbaa !39
  %t469 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %t467)
  store %"compiler/source:Span" %t469, ptr %l221
  br label %bb80
bb79:
  br label %bb85
bb80:
  %t470 = getelementptr %"compiler/source:Span", ptr %l221, i32 0, i32 0
  %t471 = load i32, ptr %t470, !tbaa !23
  %t473 = sext i32 %t471 to i64
  store i64 %t473, ptr %l223, !tbaa !24
  %t474 = load ptr, ptr %l2, !tbaa !29
  %t476 = getelementptr %"compiler/ast:Func", ptr %t474, i32 0, i32 3
  %t477 = load ptr, ptr %t476, !tbaa !29
  %t479 = getelementptr %"compiler/ast:Sig", ptr %t477, i32 0, i32 1
  %t480 = load { i64, ptr }, ptr %t479, !tbaa !27
  store { i64, ptr } %t480, ptr %l226, !tbaa !27
  %t481 = load ptr, ptr %l2, !tbaa !29
  %t483 = getelementptr %"compiler/ast:Func", ptr %t481, i32 0, i32 3
  %t484 = load ptr, ptr %t483, !tbaa !29
  %t486 = getelementptr %"compiler/ast:Sig", ptr %t484, i32 0, i32 1
  %t487 = load { i64, ptr }, ptr %t486, !tbaa !27
  %t489 = extractvalue { i64, ptr } %t487, 0
  %t491 = sub i64 %t489, 1
  %t493 = getelementptr { i64, ptr }, ptr %l226, i32 0, i32 1
  %t494 = load ptr, ptr %t493, !tbaa !27
  %t495 = getelementptr ptr, ptr %t494, i64 %t491
  %t496 = load ptr, ptr %t495, !tbaa !39
  %t498 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %t496)
  store %"compiler/source:Span" %t498, ptr %l233
  br label %bb81
bb81:
  %t499 = getelementptr %"compiler/source:Span", ptr %l233, i32 0, i32 1
  %t500 = load i32, ptr %t499, !tbaa !23
  %t502 = sext i32 %t500 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t503
  %t504 = getelementptr { i64, [3 x i64] }, ptr %t503, i32 0, i32 0
  store i64 3, ptr %t504
  %t505 = load i64, ptr %l216, !tbaa !24
  %t506 = insertvalue { i64, i64, i64 } undef, i64 %t505, 0
  %t507 = load i64, ptr %l223, !tbaa !24
  %t508 = insertvalue { i64, i64, i64 } %t506, i64 %t507, 1
  %t510 = insertvalue { i64, i64, i64 } %t508, i64 %t502, 2
  %t511 = getelementptr { i64, [3 x i64] }, ptr %t503, i32 0, i32 1
  store { i64, i64, i64 } %t510, ptr %t511
  %t512 = load { i64, [3 x i64] }, ptr %t503
  store { i64, [3 x i64] } %t512, ptr %l236
  %t513 = load ptr, ptr %l0, !tbaa !29
  %t514 = load i32, ptr %l17, !tbaa !23
  %t517 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s10, ptr %t513, i32 %t514)
  store { i64, ptr } %t517, ptr %l239
  br label %bb82
bb82:
  %t518 = load { i64, ptr }, ptr %l239, !tbaa !27
  %t519 = extractvalue { i64, ptr } %t518, 0
  %t520 = extractvalue { i64, ptr } %t518, 1
  %t521 = mul i64 %t519, 1
  %t522 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t521)
  call void @llvm.memcpy.p0.p0.i64(ptr %t522, ptr %t520, i64 %t521, i1 false)
  %t523 = insertvalue { i64, ptr } undef, i64 %t519, 0
  %t524 = insertvalue { i64, ptr } %t523, ptr %t522, 1
  %t526 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eExportResult(ptr %s10, ptr %s10, { i64, ptr } %t524)
  store %"compiler/msgs:Msg" %t526, ptr %l241
  br label %bb83
bb83:
  %t527 = load ptr, ptr %l215, !tbaa !29
  %t528 = load { i64, [3 x i64] }, ptr %l236
  %t529 = load %"compiler/msgs:Msg", ptr %l241
  %t530 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s10, ptr %t527, { i64, [3 x i64] } %t528, %"compiler/msgs:Msg" %t529)
  store i64 %t530, ptr %l242
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s10)
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternParam(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l6 = alloca i1
  %l11 = alloca i1
  %l16 = alloca i32
  %l19 = alloca i1
  %l25 = alloca i32
  %l34 = alloca i32
  %l37 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i1, ptr %l6, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load i32, ptr %l1, !tbaa !23
  store i32 %t8, ptr %l2, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l2, !tbaa !23
  %t14 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t10, i32 %t11)
  store i1 %t14, ptr %l11
  br label %bb5
bb5:
  %t15 = load i1, ptr %l11, !tbaa !21
  br i1 %t15, label %bb6, label %bb7
bb6:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l16
  br label %bb8
bb7:
  br label %bb13
bb8:
  %t26 = load i32, ptr %l16, !tbaa !23
  store i32 %t26, ptr %l2, !tbaa !23
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l2, !tbaa !23
  %t31 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainStruct(ptr %v0, ptr %t27, i32 %t28, i64 0)
  store i1 %t31, ptr %l19
  br label %bb9
bb9:
  %t32 = load i1, ptr %l19, !tbaa !21
  br i1 %t32, label %bb10, label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  %t40 = load i32, ptr %l2, !tbaa !23
  %t43 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t43, ptr %l25
  br label %bb14
bb14:
  %t44 = load i32, ptr %l25
  %t46 = trunc i64 19 to i32
  %t47 = icmp eq i32 %t44, %t46
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb15, label %bb16
bb15:
  store i1 false, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 2
  %t58 = load i32, ptr %l2, !tbaa !23
  %t61 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t57, i32 %t58)
  store i32 %t61, ptr %l34
  br label %bb18
bb18:
  %t62 = load i32, ptr %l34, !tbaa !23
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t67 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %t63, i32 %t62)
  store i1 %t67, ptr %l37
  br label %bb19
bb19:
  %t68 = load i1, ptr %l37, !tbaa !21
  store i1 %t68, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i32
  %l10 = alloca i1
  %l11 = alloca i1
  %l18 = alloca i1
  %l22 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l2, !tbaa !23
  %t16 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t16, ptr %l10
  br label %bb2
bb2:
  %t17 = load i1, ptr %l10, !tbaa !21
  br i1 %t17, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb5
bb4:
  %t18 = load i32, ptr %l2, !tbaa !23
  %t19 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t22 = icmp eq i32 %t18, %t19
  store i1 %t22, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t24 = load i1, ptr %l11, !tbaa !21
  br i1 %t24, label %bb6, label %bb7
bb6:
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i32, ptr %l1, !tbaa !23
  %t30 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforeignRef(ptr %v0, ptr %t26, i32 %t27)
  store i1 %t30, ptr %l18
  br label %bb9
bb9:
  %t31 = load i1, ptr %l18, !tbaa !21
  br i1 %t31, label %bb10, label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l1, !tbaa !23
  %t37 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainStruct(ptr %v0, ptr %t33, i32 %t34, i64 0)
  store i1 %t37, ptr %l22
  br label %bb13
bb13:
  %t38 = load i1, ptr %l22, !tbaa !21
  store i1 %t38, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailForms(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l13 = alloca i64
  %l17 = alloca i64
  %l20 = alloca i64
  %l41 = alloca ptr
  %l45 = alloca i1
  %l49 = alloca i1
  %l50 = alloca i1
  %l52 = alloca ptr
  %l54 = alloca i64
  %l55 = alloca i64
  %l59 = alloca i1
  %l63 = alloca i64
  %l72 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l80 = alloca i64
  %l83 = alloca i1
  %l89 = alloca i32
  %l92 = alloca i1
  %l93 = alloca i1
  %l96 = alloca ptr
  %l99 = alloca i32
  %l100 = alloca { i64, ptr }
  %l103 = alloca ptr
  %l107 = alloca i64
  %l109 = alloca ptr
  %l110 = alloca ptr
  %l113 = alloca %"compiler/source:Span"
  %l116 = alloca { i64, ptr }
  %l118 = alloca %"compiler/msgs:Msg"
  %l119 = alloca i64
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %t4)
  store i64 %t6, ptr %l13
  br label %bb1
bb1:
  %t7 = load i64, ptr %l13, !tbaa !24
  store i64 %t7, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t12 = icmp sgt i64 %t8, %t9
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t16 = icmp sgt i64 %t14, 0
  br i1 %t16, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb7
bb4:
  %t18 = load i64, ptr %l2, !tbaa !24
  %t19 = load i64, ptr %l1, !tbaa !24
  %t22 = sub i64 %t18, %t19
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = add i64 %t22, %t23
  %t28 = sub i64 %t26, 1
  %t29 = load i64, ptr %l3, !tbaa !24
  %t32 = sdiv i64 %t28, %t29
  store i64 %t32, ptr %l20, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb6
bb6:
  %t34 = load i64, ptr %l20, !tbaa !24
  store i64 %t34, ptr %l17, !tbaa !24
  br label %bb7
bb7:
  %t35 = load i64, ptr %l17, !tbaa !24
  store i64 %t35, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load i64, ptr %l5, !tbaa !24
  %t37 = load i64, ptr %l4, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb62
bb10:
  br label %bb11
bb11:
  %t44 = load i64, ptr %l1, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t46 = load i64, ptr %l3, !tbaa !24
  %t49 = mul i64 %t45, %t46
  %t52 = add i64 %t44, %t49
  store i64 %t52, ptr %l6, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t58 = load i64, ptr %l6, !tbaa !24
  %t61 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t57, i64 %t58)
  store ptr %t61, ptr %l41
  br label %bb12
bb12:
  %t62 = load ptr, ptr %l41, !tbaa !29
  store ptr %t62, ptr %l7, !tbaa !29
  %t63 = load ptr, ptr %l7, !tbaa !29
  %t65 = getelementptr %"compiler/ast:Func", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = icmp eq ptr %t66, null
  br i1 %t68, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb16
bb14:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/check:Checker", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t74 = load i64, ptr %l6, !tbaa !24
  %t77 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %t73, i64 %t74)
  store i1 %t77, ptr %l49
  br label %bb15
bb15:
  %t78 = load i1, ptr %l49, !tbaa !21
  store i1 %t78, ptr %l45, !tbaa !21
  br label %bb16
bb16:
  %t79 = load i1, ptr %l45, !tbaa !21
  br i1 %t79, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb21
bb18:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/check:Checker", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  store ptr %t83, ptr %l52, !tbaa !29
  %t84 = load i64, ptr %l6, !tbaa !24
  %t86 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t84)
  store i64 %t86, ptr %l54
  br label %bb19
bb19:
  %t87 = load ptr, ptr %l52, !tbaa !29
  %t88 = load i64, ptr %l54, !tbaa !24
  %t89 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t87, i64 %t88)
  store i64 %t89, ptr %l55
  br label %bb20
bb20:
  %t90 = load i64, ptr %l55, !tbaa !24
  %t91 = icmp sgt i64 %t90, 0
  store i1 %t91, ptr %l50, !tbaa !21
  br label %bb21
bb21:
  %t93 = load i1, ptr %l50, !tbaa !21
  br i1 %t93, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s2)
  br label %bb61
bb23:
  br label %bb24
bb24:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 3
  %t97 = load i1, ptr %t96, !tbaa !21
  br i1 %t97, label %bb25, label %bb26
bb25:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t103 = load i64, ptr %l6, !tbaa !24
  %t106 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t102, i64 %t103)
  store i64 %t106, ptr %l63
  br label %bb27
bb26:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb28
bb27:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/check:Checker", ptr %t107, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/generic:Program", ptr %t110, i32 0, i32 0
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = getelementptr %"compiler/load:Loader", ptr %t113, i32 0, i32 7
  %t116 = load i64, ptr %t115, !tbaa !24
  %t117 = load i64, ptr %l63, !tbaa !24
  %t119 = icmp ne i64 %t117, %t116
  store i1 %t119, ptr %l59, !tbaa !21
  br label %bb28
bb28:
  %t121 = load i1, ptr %l59, !tbaa !21
  br i1 %t121, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s2)
  br label %bb61
bb30:
  br label %bb31
bb31:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load ptr, ptr %l7, !tbaa !29
  %t125 = getelementptr %"compiler/ast:Func", ptr %t123, i32 0, i32 2
  %t126 = load i32, ptr %t125, !tbaa !23
  %t129 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t122, i32 %t126)
  store { i64, ptr } %t129, ptr %l72
  br label %bb32
bb32:
  %t130 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t130, ptr %l8, !tbaa !27
  %t131 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t131, 0
  %t135 = icmp eq i64 %t133, 0
  br i1 %t135, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s2)
  br label %bb61
bb34:
  br label %bb35
bb35:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t141 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorRole(ptr %v0, ptr %v0, ptr %s2, ptr %t137, { i64, ptr } %t138)
  store { i64, ptr } %t141, ptr %l78
  br label %bb36
bb36:
  %t142 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t142, 0
  %t144 = extractvalue { i64, ptr } %t142, 1
  %t145 = mul i64 %t143, 1
  %t146 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t145)
  call void @llvm.memcpy.p0.p0.i64(ptr %t146, ptr %t144, i64 %t145, i1 false)
  %t147 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  %t150 = call i64 @compiler_2fcheck_2eopShapeOf(ptr %s2, { i64, ptr } %t148)
  store i64 %t150, ptr %l80
  br label %bb37
bb37:
  %t151 = load i64, ptr %l80, !tbaa !24
  store i64 %t151, ptr %l9, !tbaa !24
  %t152 = load i64, ptr %l9, !tbaa !24
  %t154 = icmp slt i64 %t152, 0
  br i1 %t154, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l83, !tbaa !21
  br label %bb40
bb39:
  %t156 = load i64, ptr %l9, !tbaa !24
  %t158 = getelementptr [22 x %"compiler/check:opShape"], ptr @G_2ecompiler_2fcheck_2eOpShapes, i64 0, i64 %t156
  %t159 = getelementptr %"compiler/check:opShape", ptr %t158, i32 0, i32 3
  %t160 = load i1, ptr %t159, !tbaa !21
  store i1 %t160, ptr %l83, !tbaa !21
  br label %bb40
bb40:
  %t162 = load i1, ptr %l83, !tbaa !21
  br i1 %t162, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s2)
  br label %bb61
bb42:
  br label %bb43
bb43:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/check:Checker", ptr %t163, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !29
  %t167 = load i64, ptr %l6, !tbaa !24
  %t170 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t166, i64 %t167)
  store i32 %t170, ptr %l89
  br label %bb44
bb44:
  %t171 = load i32, ptr %l89, !tbaa !23
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t176 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %t172, i32 %t171)
  store i1 %t176, ptr %l92
  br label %bb45
bb45:
  %t177 = load i1, ptr %l92, !tbaa !21
  br i1 %t177, label %bb46, label %bb47
bb46:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr %"compiler/check:Checker", ptr %t178, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !29
  %t183 = getelementptr %"compiler/generic:Program", ptr %t181, i32 0, i32 2
  store ptr %t183, ptr %l96, !tbaa !29
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t185 = load i64, ptr %l6, !tbaa !24
  %t188 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnErrors(ptr %v0, ptr %t184, i64 %t185)
  store i32 %t188, ptr %l99
  br label %bb48
bb47:
  store i1 false, ptr %l93, !tbaa !21
  br label %bb50
bb48:
  %t189 = load ptr, ptr %l96, !tbaa !29
  %t190 = load i32, ptr %l99, !tbaa !23
  %t191 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t189, i32 %t190)
  store { i64, ptr } %t191, ptr %l100
  br label %bb49
bb49:
  %t192 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t192, 0
  %t195 = icmp sgt i64 %t193, 0
  store i1 %t195, ptr %l93, !tbaa !21
  br label %bb50
bb50:
  %t197 = load i1, ptr %l93, !tbaa !21
  br i1 %t197, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s7
  %t198 = load ptr, ptr %l0, !tbaa !29
  store ptr %t198, ptr %l103, !tbaa !29
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr %"compiler/check:Checker", ptr %t199, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !29
  %t203 = load i64, ptr %l6, !tbaa !24
  %t206 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t202, i64 %t203)
  store i64 %t206, ptr %l107
  br label %bb53
bb52:
  br label %bb60
bb53:
  %t207 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t208 = load ptr, ptr %l103, !tbaa !29
  %t209 = load i64, ptr %l107, !tbaa !24
  %t211 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t208, i64 -1, i64 %t209, i32 %t207, i32 0)
  store ptr %t211, ptr %l109
  br label %bb54
bb54:
  %t212 = load ptr, ptr %l0, !tbaa !29
  store ptr %t212, ptr %l110, !tbaa !29
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load ptr, ptr %l7, !tbaa !29
  %t217 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v0, ptr %t213, ptr %t214)
  store %"compiler/source:Span" %t217, ptr %l113
  br label %bb55
bb55:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t219 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t222 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorRole(ptr %v0, ptr %v0, ptr %s7, ptr %t218, { i64, ptr } %t219)
  store { i64, ptr } %t222, ptr %l116
  br label %bb56
bb56:
  %t223 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t224 = extractvalue { i64, ptr } %t223, 0
  %t225 = extractvalue { i64, ptr } %t223, 1
  %t226 = mul i64 %t224, 1
  %t227 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t226)
  call void @llvm.memcpy.p0.p0.i64(ptr %t227, ptr %t225, i64 %t226, i1 false)
  %t228 = insertvalue { i64, ptr } undef, i64 %t224, 0
  %t229 = insertvalue { i64, ptr } %t228, ptr %t227, 1
  %t231 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodCannotFail(ptr %s7, ptr %s7, { i64, ptr } %t229)
  store %"compiler/msgs:Msg" %t231, ptr %l118
  br label %bb57
bb57:
  %t232 = load ptr, ptr %l110, !tbaa !29
  %t233 = load %"compiler/source:Span", ptr %l113
  %t234 = load %"compiler/msgs:Msg", ptr %l118
  %t235 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t232, %"compiler/source:Span" %t233, %"compiler/msgs:Msg" %t234)
  store i64 %t235, ptr %l119
  br label %bb58
bb58:
  %t236 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t236)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s7)
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s2)
  br label %bb61
bb61:
  %t238 = load i64, ptr %l5, !tbaa !24
  %t240 = add i64 %t238, 1
  store i64 %t240, ptr %l5, !tbaa !24
  br label %bb8
bb62:
  %t242 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edrain(ptr %v0, ptr %t242)
  br label %bb63
bb63:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailOp(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/source:Span" %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l35 = alloca %"compiler/source:Span"
  %l37 = alloca %"compiler/msgs:Msg"
  %l38 = alloca %"compiler/msgs:Msg"
  %l39 = alloca %"compiler/msgs:Msg"
  %l40 = alloca i64
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l10, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l4, !tbaa !29
  store ptr %t5, ptr %l11, !tbaa !29
  %t6 = load ptr, ptr %l11, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t6, i32 0, i32 16
  %t8 = load i64, ptr %t7, !tbaa !24
  %t10 = add i64 %t8, 1
  %t12 = load ptr, ptr %l11, !tbaa !29
  %t13 = getelementptr %"compiler/check:frame", ptr %t12, i32 0, i32 16
  store i64 %t10, ptr %t13, !tbaa !24
  store { i64, ptr } %a1, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  store i64 %t18, ptr %l7, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t20 = load i64, ptr %l6, !tbaa !24
  %t21 = load i64, ptr %l7, !tbaa !24
  %t24 = icmp slt i64 %t20, %t21
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t28 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t28, ptr %l21, !tbaa !27
  %t29 = load i64, ptr %l6, !tbaa !24
  %t31 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr i32, ptr %t32, i64 %t29
  %t34 = load i32, ptr %t33, !tbaa !33
  store i32 %t34, ptr %l8, !tbaa !23
  %t36 = load i32, ptr %l8, !tbaa !23
  %t37 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t40 = icmp ne i32 %t36, %t37
  br i1 %t40, label %bb6, label %bb7
bb6:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l8, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaks1(ptr %v0, ptr %t42, i32 %t43)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t46 = load i64, ptr %l6, !tbaa !24
  %t48 = add i64 %t46, 1
  store i64 %t48, ptr %l6, !tbaa !24
  br label %bb2
bb11:
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t52 = getelementptr %"compiler/check:frame", ptr %t50, i32 0, i32 15
  %t53 = load i64, ptr %t52, !tbaa !24
  %t55 = icmp eq i64 %t53, 0
  br i1 %t55, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s5
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l34, !tbaa !29
  store %"compiler/source:Span" %a2, ptr %l35
  br i1 %a3, label %bb14, label %bb15
bb13:
  br label %bb20
bb14:
  %t61 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAsCanFail(ptr %s5)
  store %"compiler/msgs:Msg" %t61, ptr %l38
  br label %bb16
bb15:
  %t62 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnhandledFallibleCall(ptr %s5)
  store %"compiler/msgs:Msg" %t62, ptr %l39
  br label %bb17
bb16:
  %t63 = load %"compiler/msgs:Msg", ptr %l38
  store %"compiler/msgs:Msg" %t63, ptr %l37
  br label %bb18
bb17:
  %t64 = load %"compiler/msgs:Msg", ptr %l39
  store %"compiler/msgs:Msg" %t64, ptr %l37
  br label %bb18
bb18:
  %t65 = load ptr, ptr %l34, !tbaa !29
  %t66 = load %"compiler/source:Span", ptr %l35
  %t67 = load %"compiler/msgs:Msg", ptr %l37
  %t68 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t65, %"compiler/source:Span" %t66, %"compiler/msgs:Msg" %t67)
  store i64 %t68, ptr %l40
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb20
bb20:
  store i32 2, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efirstUncovered(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca { i64, ptr }
  %l37 = alloca i64
  %l40 = alloca i64
  %l62 = alloca i32
  %l66 = alloca { i64, ptr }
  %l69 = alloca ptr
  %l74 = alloca i32
  %l75 = alloca { i64, ptr }
  %l79 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l82 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l86 = alloca i32
  %l95 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l102 = alloca i1
  %l103 = alloca ptr
  %l104 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l111 = alloca ptr
  %l112 = alloca i1
  %l117 = alloca ptr
  %l118 = alloca i1
  %l126 = alloca i64
  %l129 = alloca ptr
  %l130 = alloca { i64, ptr }
  %l136 = alloca { i64, ptr }
  %l137 = alloca ptr
  %l138 = alloca i1
  %l148 = alloca i64
  %l151 = alloca i1
  %l157 = alloca ptr
  %l160 = alloca { i64, ptr }
  %l169 = alloca i1
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l25, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l2, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l30
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l25, !tbaa !29
  %t18 = load i32, ptr %l30, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t17, i32 %t18)
  store { i64, ptr } %t19, ptr %l31
  br label %bb2
bb2:
  %t20 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  store i64 0, ptr %l4, !tbaa !24
  store i64 %t21, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t25 = load i64, ptr %l5, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = icmp sgt i64 %t25, %t26
  br i1 %t29, label %bb3, label %bb4
bb3:
  %t31 = load i64, ptr %l6, !tbaa !24
  %t33 = icmp sgt i64 %t31, 0
  br i1 %t33, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb8
bb5:
  %t35 = load i64, ptr %l5, !tbaa !24
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = sub i64 %t35, %t36
  %t40 = load i64, ptr %l6, !tbaa !24
  %t43 = add i64 %t39, %t40
  %t45 = sub i64 %t43, 1
  %t46 = load i64, ptr %l6, !tbaa !24
  %t49 = sdiv i64 %t45, %t46
  store i64 %t49, ptr %l40, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb7
bb7:
  %t51 = load i64, ptr %l40, !tbaa !24
  store i64 %t51, ptr %l37, !tbaa !24
  br label %bb8
bb8:
  %t52 = load i64, ptr %l37, !tbaa !24
  store i64 %t52, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t53 = load i64, ptr %l8, !tbaa !24
  %t54 = load i64, ptr %l7, !tbaa !24
  %t57 = icmp slt i64 %t53, %t54
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb90
bb11:
  br label %bb12
bb12:
  %t61 = load i64, ptr %l4, !tbaa !24
  %t62 = load i64, ptr %l8, !tbaa !24
  %t63 = load i64, ptr %l6, !tbaa !24
  %t66 = mul i64 %t62, %t63
  %t69 = add i64 %t61, %t66
  store i64 %t69, ptr %l9, !tbaa !24
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t75 = load i32, ptr %l2, !tbaa !23
  %t76 = load i64, ptr %l9, !tbaa !24
  %t80 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %t74, i32 %t75, i64 %t76)
  store i32 %t80, ptr %l62
  br label %bb13
bb13:
  %t81 = load i32, ptr %l62, !tbaa !23
  store i32 %t81, ptr %l10, !tbaa !23
  %t82 = load i32, ptr %l10, !tbaa !23
  %t83 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t86 = icmp ne i32 %t82, %t83
  br i1 %t86, label %bb14, label %bb15
bb14:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/check:Checker", ptr %t88, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = getelementptr %"compiler/generic:Program", ptr %t91, i32 0, i32 2
  store ptr %t93, ptr %l69, !tbaa !29
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t99 = getelementptr %"compiler/generic:Program", ptr %t97, i32 0, i32 2
  %t100 = load i32, ptr %l10, !tbaa !23
  %t103 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t99, i32 %t100)
  store i32 %t103, ptr %l74
  br label %bb16
bb15:
  %t104 = icmp sge i64 0, 0
  br i1 %t104, label %bb18, label %bb19
bb16:
  %t106 = load ptr, ptr %l69, !tbaa !29
  %t107 = load i32, ptr %l74, !tbaa !23
  %t108 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t106, i32 %t107)
  store { i64, ptr } %t108, ptr %l75
  br label %bb17
bb17:
  %t109 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t109, ptr %l66, !tbaa !27
  br label %bb22
bb18:
  %t110 = icmp sle i64 0, 2305843009213693951
  br i1 %t110, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_3f3d818644d50cc7_38dbc52e232a8b93)
  unreachable
bb20:
  %t112 = mul i64 0, 4
  %t113 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t112)
  %t114 = insertvalue { i64, ptr } undef, i64 0, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t113, 1
  store { i64, ptr } %t115, ptr %l66, !tbaa !27
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_3f3d818644d50cc7_38dbc52e232a8b93)
  unreachable
bb22:
  %t117 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t117, ptr %l11, !tbaa !27
  %t118 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3ccompiler_2fast_3aPattern_26_3e_26_3e_2ector(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t118, ptr %l79
  br label %bb23
bb23:
  %t119 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l79
  %t120 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t119, ptr %t120
  store ptr %t120, ptr %l12, !tbaa !29
  store ptr %a1, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s4
  %t124 = load ptr, ptr %l13, !tbaa !29
  %t125 = load i64, ptr %l14, !tbaa !24
  %t128 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fast_3aPattern_26_H8f433a386540269ec523262b43568e5b(ptr %v1, ptr %t124, i64 %t125)
  %t129 = extractvalue { i32, { i64, ptr } } %t128, 1
  %t130 = extractvalue { i32, { i64, ptr } } %t128, 0
  store i32 %t130, ptr %l86
  %t131 = icmp ne i32 %t130, 0
  br i1 %t131, label %bb26, label %ok.132
ok.132:
  store { i64, ptr } %t129, ptr %l85
  br label %bb25
bb25:
  %t133 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t133, ptr %l82, !tbaa !27
  br label %bb30
bb26:
  %t134 = load i32, ptr %l86, !tbaa !23
  %t135 = ashr i32 %t134, 16
  %t137 = icmp eq i32 %t135, 1
  br i1 %t137, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_808d16f594578c21_dfc8c283c70478a5)
  unreachable
bb29:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s4)
  br label %bb84
bb30:
  %t139 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t139, ptr %l15, !tbaa !27
  %t140 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t140, 0
  store i64 %t142, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s5
  %t144 = load i64, ptr %l17, !tbaa !24
  %t145 = load i64, ptr %l16, !tbaa !24
  %t148 = icmp slt i64 %t144, %t145
  %t150 = xor i1 %t148, true
  br i1 %t150, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s5)
  br label %bb82
bb33:
  br label %bb34
bb34:
  %t152 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t152, ptr %l95, !tbaa !27
  %t153 = load i64, ptr %l17, !tbaa !24
  %t155 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !27
  %t157 = getelementptr { i64, ptr }, ptr %t156, i64 %t153
  %t158 = load { i64, ptr }, ptr %t157, !tbaa !37
  store { i64, ptr } %t158, ptr %l18, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t160, ptr %l98, !tbaa !27
  %t161 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr ptr, ptr %t162, i64 0
  %t164 = load ptr, ptr %t163, !tbaa !39
  store ptr %t164, ptr %l19, !tbaa !29
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load ptr, ptr %l19, !tbaa !29
  %t170 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatWild(ptr %v0, ptr %v1, ptr %t166, ptr %t167)
  store i1 %t170, ptr %l102
  br label %bb35
bb35:
  %t171 = load i1, ptr %l102, !tbaa !21
  br i1 %t171, label %bb36, label %bb37
bb36:
  %t172 = load ptr, ptr %l12, !tbaa !29
  store ptr %t172, ptr %l103, !tbaa !29
  %t173 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t173, ptr %l104, !tbaa !27
  %t174 = icmp sge i64 0, 0
  br i1 %t174, label %bb38, label %bb39
bb37:
  br label %bb44
bb38:
  %t176 = icmp sle i64 0, 1152921504606846975
  br i1 %t176, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_1aa49c7f94741e71_4937354175d6cb9d)
  unreachable
bb40:
  %t178 = mul i64 0, 8
  %t179 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t178)
  %t180 = insertvalue { i64, ptr } undef, i64 0, 0
  %t181 = insertvalue { i64, ptr } %t180, ptr %t179, 1
  %t182 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t182, 0
  %t185 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t188 = call { i64, ptr } @compiler_2fcheck_2epatTail(ptr %v1, { i64, ptr } %t185, { i64, ptr } %t181, i64 %t184)
  store { i64, ptr } %t188, ptr %l110
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_1aa49c7f94741e71_4937354175d6cb9d)
  unreachable
bb42:
  %t189 = load ptr, ptr %l103, !tbaa !29
  %t190 = load { i64, ptr }, ptr %l110, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fast_3aPattern_26_H1d860e259259c4952a7ac353d360c942(ptr %v1, ptr %v1, ptr %t189, { i64, ptr } %t190)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s5)
  br label %bb81
bb44:
  %t191 = load ptr, ptr %l19, !tbaa !29
  store ptr %t191, ptr %l111, !tbaa !29
  store i1 false, ptr %l112, !tbaa !21
  %t192 = load ptr, ptr %l111, !tbaa !29
  %t193 = icmp ne ptr %t192, null
  br i1 %t193, label %bb45, label %bb46
bb45:
  %t195 = load ptr, ptr %l111, !tbaa !29
  %t196 = load i64, ptr %t195
  %t198 = icmp eq i64 %t196, 1
  store i1 %t198, ptr %l112, !tbaa !21
  br label %bb46
bb46:
  %t199 = load i1, ptr %l112, !tbaa !21
  br i1 %t199, label %bb47, label %bb48
bb47:
  %t200 = load ptr, ptr %l19, !tbaa !29
  %t202 = getelementptr { i64, [4 x i64] }, ptr %t200, i32 0, i32 1
  %t203 = getelementptr { %"compiler/source:Span", ptr }, ptr %t202, i32 0, i32 1
  %t204 = load ptr, ptr %t203
  store ptr %t204, ptr %l20, !tbaa !29
  br label %bb53
bb48:
  %t206 = load ptr, ptr %l19, !tbaa !29
  store ptr %t206, ptr %l117, !tbaa !29
  store i1 false, ptr %l118, !tbaa !21
  %t207 = load ptr, ptr %l117, !tbaa !29
  %t208 = icmp ne ptr %t207, null
  br i1 %t208, label %bb49, label %bb50
bb49:
  %t210 = load ptr, ptr %l117, !tbaa !29
  %t211 = load i64, ptr %t210
  %t213 = icmp eq i64 %t211, 4
  store i1 %t213, ptr %l118, !tbaa !21
  br label %bb50
bb50:
  %t214 = load i1, ptr %l118, !tbaa !21
  br i1 %t214, label %bb51, label %bb52
bb51:
  %t215 = load ptr, ptr %l19, !tbaa !29
  %t217 = getelementptr { i64, [4 x i64] }, ptr %t215, i32 0, i32 1
  %t218 = getelementptr { %"compiler/source:Span", ptr }, ptr %t217, i32 0, i32 1
  %t219 = load ptr, ptr %t218
  store ptr %t219, ptr %l20, !tbaa !29
  br label %bb53
bb52:
  br label %bb64
bb53:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load ptr, ptr %l20, !tbaa !29
  %t223 = load i32, ptr %l2, !tbaa !23
  %t227 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %t221, ptr %t222, i32 %t223)
  store i64 %t227, ptr %l126
  br label %bb54
bb54:
  %t228 = load i64, ptr %l9, !tbaa !24
  %t229 = load i64, ptr %l126, !tbaa !24
  %t231 = icmp eq i64 %t229, %t228
  br i1 %t231, label %bb55, label %bb56
bb55:
  %t233 = load ptr, ptr %l12, !tbaa !29
  store ptr %t233, ptr %l129, !tbaa !29
  %t234 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t234, ptr %l130, !tbaa !27
  %t235 = icmp sge i64 0, 0
  br i1 %t235, label %bb57, label %bb58
bb56:
  br label %bb63
bb57:
  %t237 = icmp sle i64 0, 1152921504606846975
  br i1 %t237, label %bb59, label %bb60
bb58:
  call void @__olang_check_failed(ptr @olang_loc_1a7e3b998d35a364_c6b9293917078f0)
  unreachable
bb59:
  %t239 = mul i64 0, 8
  %t240 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t239)
  %t241 = insertvalue { i64, ptr } undef, i64 0, 0
  %t242 = insertvalue { i64, ptr } %t241, ptr %t240, 1
  %t243 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t245 = extractvalue { i64, ptr } %t243, 0
  %t246 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t249 = call { i64, ptr } @compiler_2fcheck_2epatTail(ptr %v1, { i64, ptr } %t246, { i64, ptr } %t242, i64 %t245)
  store { i64, ptr } %t249, ptr %l136
  br label %bb61
bb60:
  call void @__olang_check_failed(ptr @olang_loc_1a7e3b998d35a364_c6b9293917078f0)
  unreachable
bb61:
  %t250 = load ptr, ptr %l129, !tbaa !29
  %t251 = load { i64, ptr }, ptr %l136, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fast_3aPattern_26_H1d860e259259c4952a7ac353d360c942(ptr %v1, ptr %v1, ptr %t250, { i64, ptr } %t251)
  br label %bb62
bb62:
  br label %bb63
bb63:
  br label %bb80
bb64:
  %t252 = load ptr, ptr %l19, !tbaa !29
  store ptr %t252, ptr %l137, !tbaa !29
  store i1 false, ptr %l138, !tbaa !21
  %t253 = load ptr, ptr %l137, !tbaa !29
  %t254 = icmp ne ptr %t253, null
  br i1 %t254, label %bb65, label %bb66
bb65:
  %t256 = load ptr, ptr %l137, !tbaa !29
  %t257 = load i64, ptr %t256
  %t259 = icmp eq i64 %t257, 2
  store i1 %t259, ptr %l138, !tbaa !21
  br label %bb66
bb66:
  %t260 = load i1, ptr %l138, !tbaa !21
  br i1 %t260, label %bb67, label %bb68
bb67:
  %t261 = load ptr, ptr %l19, !tbaa !29
  %t263 = getelementptr { i64, [4 x i64] }, ptr %t261, i32 0, i32 1
  %t264 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t263, i32 0, i32 1
  %t265 = load ptr, ptr %t264
  store ptr %t265, ptr %l21, !tbaa !29
  %t267 = load ptr, ptr %l19, !tbaa !29
  %t269 = getelementptr { i64, [4 x i64] }, ptr %t267, i32 0, i32 1
  %t270 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t269, i32 0, i32 2
  %t271 = load { i64, ptr }, ptr %t270
  store { i64, ptr } %t271, ptr %l22, !tbaa !27
  br label %bb69
bb68:
  br label %bb79
bb69:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = load ptr, ptr %l21, !tbaa !29
  %t275 = load i32, ptr %l2, !tbaa !23
  %t279 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %t273, ptr %t274, i32 %t275)
  store i64 %t279, ptr %l148
  br label %bb70
bb70:
  %t280 = load i64, ptr %l9, !tbaa !24
  %t281 = load i64, ptr %l148, !tbaa !24
  %t283 = icmp eq i64 %t281, %t280
  br i1 %t283, label %bb71, label %bb72
bb71:
  %t285 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t287 = extractvalue { i64, ptr } %t285, 0
  %t288 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t290 = extractvalue { i64, ptr } %t288, 0
  %t293 = icmp eq i64 %t287, %t290
  store i1 %t293, ptr %l151, !tbaa !21
  br label %bb73
bb72:
  store i1 false, ptr %l151, !tbaa !21
  br label %bb73
bb73:
  %t295 = load i1, ptr %l151, !tbaa !21
  br i1 %t295, label %bb74, label %bb75
bb74:
  %t296 = load ptr, ptr %l12, !tbaa !29
  store ptr %t296, ptr %l157, !tbaa !29
  %t297 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t298 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t301 = call { i64, ptr } @compiler_2fcheck_2epatTail(ptr %v1, { i64, ptr } %t297, { i64, ptr } %t298, i64 0)
  store { i64, ptr } %t301, ptr %l160
  br label %bb76
bb75:
  br label %bb78
bb76:
  %t302 = load ptr, ptr %l157, !tbaa !29
  %t303 = load { i64, ptr }, ptr %l160, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fast_3aPattern_26_H1d860e259259c4952a7ac353d360c942(ptr %v1, ptr %v1, ptr %t302, { i64, ptr } %t303)
  br label %bb77
bb77:
  br label %bb78
bb78:
  br label %bb80
bb79:
  br label %bb80
bb80:
  call void @__olang_scope_close(ptr %s5)
  br label %bb81
bb81:
  %t304 = load i64, ptr %l17, !tbaa !24
  %t306 = add i64 %t304, 1
  store i64 %t306, ptr %l17, !tbaa !24
  br label %bb31
bb82:
  %t308 = load i64, ptr %l14, !tbaa !24
  %t309 = load i64, ptr %l16, !tbaa !24
  %t312 = add i64 %t308, %t309
  store i64 %t312, ptr %l14, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb83
bb83:
  br label %bb24
bb84:
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t315 = load ptr, ptr %l12, !tbaa !29
  %t316 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t320 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecoversRows(ptr %v0, ptr %v1, ptr %v0, ptr %t314, ptr %t315, { i64, ptr } %t316, i64 1)
  store i1 %t320, ptr %l169
  br label %bb85
bb85:
  %t321 = load i1, ptr %l169, !tbaa !21
  %t322 = xor i1 %t321, true
  br i1 %t322, label %bb86, label %bb87
bb86:
  %t324 = load i64, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  store i64 %t324, ptr %rv
  br label %ret
bb87:
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s2)
  br label %bb89
bb89:
  %t326 = load i64, ptr %l8, !tbaa !24
  %t328 = add i64 %t326, 1
  store i64 %t328, ptr %l8, !tbaa !24
  br label %bb9
bb90:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efitsTest(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i64
  %lp6 = alloca ptr
  %l7 = alloca i64
  %lp8 = alloca ptr
  %l9 = alloca i64
  %lp10 = alloca ptr
  %l13 = alloca i32
  %l16 = alloca i32
  %l19 = alloca i32
  %l21 = alloca i1
  %l25 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l34 = alloca i64
  %l38 = alloca %"compiler/source:Span"
  %l39 = alloca i32
  %l40 = alloca i32
  %l41 = alloca i32
  %l45 = alloca { i64, ptr }
  %l49 = alloca i64
  %l56 = alloca %"compiler/source:Span"
  %l57 = alloca i32
  %l61 = alloca { i64, ptr }
  %l65 = alloca ptr
  %l67 = alloca %"compiler/typed:Seq"
  %l72 = alloca i64
  %l74 = alloca ptr
  %l78 = alloca ptr
  %l79 = alloca %"compiler/source:Span"
  %l82 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l87 = alloca %"compiler/typed:Clause"
  %l88 = alloca %"compiler/source:Span"
  %l89 = alloca i32
  %l92 = alloca { i64, ptr }
  %l93 = alloca %"compiler/typed:Try"
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t62 = alloca { i64, [5 x i64] }, align 8
  %t90 = alloca { i64, [3 x i64] }, align 8
  %t124 = alloca { i64, [5 x i64] }, align 8
  %t195 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1)
  store i32 %t4, ptr %l13
  br label %bb1
bb1:
  %t5 = load i32, ptr %l13, !tbaa !23
  store i32 %t5, ptr %l4, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l4, !tbaa !23
  %t10 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l16
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l3, !tbaa !23
  %t15 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l19
  br label %bb3
bb3:
  %t16 = load i32, ptr %l16, !tbaa !23
  %t17 = load i32, ptr %l19, !tbaa !23
  %t18 = icmp eq i32 %t16, %t17
  br i1 %t18, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb7
bb5:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l4, !tbaa !23
  %t22 = load i32, ptr %l3, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvWords(ptr %v0, ptr %s0, ptr %t20, i32 %t21, i32 %t22)
  store { i64, ptr } %t26, ptr %l25
  br label %bb6
bb6:
  %t27 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t27, 0
  %t30 = icmp eq i64 %t28, 0
  store i1 %t30, ptr %l21, !tbaa !21
  br label %bb7
bb7:
  %t32 = load i1, ptr %l21, !tbaa !21
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load %"compiler/source:Span", ptr %l1
  %t35 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t39 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t33, %"compiler/source:Span" %t34, i32 %t35, i64 1)
  store ptr %t39, ptr %l31
  br label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t40 = load ptr, ptr %l31, !tbaa !29
  store ptr %t40, ptr %rv
  br label %ret
bb11:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 32
  %t45 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t43)
  store i64 %t45, ptr %l34
  br label %bb12
bb12:
  %t46 = load i64, ptr %l34, !tbaa !24
  store i64 %t46, ptr %l5, !tbaa !24
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 32
  %t50 = load ptr, ptr %l2, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t49, ptr %t50)
  br label %bb13
bb13:
  %t53 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t53, ptr %l38
  %t54 = load i32, ptr %l3, !tbaa !23
  store i32 %t54, ptr %l39, !tbaa !23
  store i32 20, ptr %l40
  store i32 2, ptr %l41
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 32
  %t58 = load i64, ptr %l5, !tbaa !24
  %t61 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t57, i64 %t58)
  store { i64, ptr } %t61, ptr %l45
  br label %bb14
bb14:
  store { i64, [5 x i64] } zeroinitializer, ptr %t62
  %t63 = getelementptr { i64, [5 x i64] }, ptr %t62, i32 0, i32 0
  store i64 9, ptr %t63
  %t64 = load %"compiler/source:Span", ptr %l38
  %t65 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t64, 0
  %t66 = load i32, ptr %l39, !tbaa !23
  %t67 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t65, i32 %t66, 1
  %t68 = load i32, ptr %l40
  %t69 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t67, i32 %t68, 2
  %t70 = load i32, ptr %l41
  %t71 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t69, i32 %t70, 3
  %t72 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t73 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t71, { i64, ptr } %t72, 4
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t62, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t73, ptr %t74
  %t75 = load { i64, [5 x i64] }, ptr %t62
  %t76 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store ptr %t76, ptr %lp6
  %t78 = load ptr, ptr %lp6
  store { i64, [5 x i64] } %t75, ptr %t78
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 33
  %t83 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t81)
  store i64 %t83, ptr %l49
  br label %bb15
bb15:
  %t84 = load i64, ptr %l49, !tbaa !24
  store i64 %t84, ptr %l7, !tbaa !24
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 33
  %t88 = load %"compiler/source:Span", ptr %l1
  %t89 = load ptr, ptr %lp6
  store { i64, [3 x i64] } zeroinitializer, ptr %t90
  %t91 = getelementptr { i64, [3 x i64] }, ptr %t90, i32 0, i32 0
  store i64 2, ptr %t91
  %t93 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t88, 0
  %t95 = insertvalue { %"compiler/source:Span", ptr } %t93, ptr %t89, 1
  %t96 = getelementptr { i64, [3 x i64] }, ptr %t90, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t95, ptr %t96
  %t97 = load { i64, [3 x i64] }, ptr %t90
  %t99 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t97, ptr %t99
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v0, ptr %t87, ptr %t99)
  br label %bb16
bb16:
  %t102 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t102, ptr %l56
  %t103 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t103, ptr %l57, !tbaa !23
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/check:Checker", ptr %t104, i32 0, i32 33
  %t107 = load i64, ptr %l7, !tbaa !24
  %t110 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t106, i64 %t107)
  store { i64, ptr } %t110, ptr %l61
  br label %bb17
bb17:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load %"compiler/source:Span", ptr %l1
  %t113 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t117 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t111, %"compiler/source:Span" %t112, i32 %t113, i64 1)
  store ptr %t117, ptr %l65
  br label %bb18
bb18:
  %t118 = load ptr, ptr %l65, !tbaa !29
  %t119 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t121 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t119, ptr %t118)
  store %"compiler/typed:Seq" %t121, ptr %l67
  br label %bb19
bb19:
  %t122 = load %"compiler/typed:Seq", ptr %l67
  %t123 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Seq" %t122, ptr %t123
  store { i64, [5 x i64] } zeroinitializer, ptr %t124
  %t125 = getelementptr { i64, [5 x i64] }, ptr %t124, i32 0, i32 0
  store i64 12, ptr %t125
  %t126 = load %"compiler/source:Span", ptr %l56
  %t127 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t126, 0
  %t128 = load i32, ptr %l57, !tbaa !23
  %t129 = insertvalue { %"compiler/source:Span", i32, ptr } %t127, i32 %t128, 1
  %t131 = insertvalue { %"compiler/source:Span", i32, ptr } %t129, ptr %t123, 2
  %t132 = getelementptr { i64, [5 x i64] }, ptr %t124, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t131, ptr %t132
  %t133 = load { i64, [5 x i64] }, ptr %t124
  %t134 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store ptr %t134, ptr %lp8
  %t136 = load ptr, ptr %lp8
  store { i64, [5 x i64] } %t133, ptr %t136
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/check:Checker", ptr %t137, i32 0, i32 32
  %t141 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t139)
  store i64 %t141, ptr %l72
  br label %bb20
bb20:
  %t142 = load i64, ptr %l72, !tbaa !24
  store i64 %t142, ptr %l9, !tbaa !24
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/check:Checker", ptr %t143, i32 0, i32 32
  store ptr %t145, ptr %l74, !tbaa !29
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load %"compiler/source:Span", ptr %l1
  %t148 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t152 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t146, %"compiler/source:Span" %t147, i32 %t148, i64 0)
  store ptr %t152, ptr %l78
  br label %bb21
bb21:
  %t153 = load ptr, ptr %l74, !tbaa !29
  %t154 = load ptr, ptr %l78, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t153, ptr %t154)
  br label %bb22
bb22:
  %t155 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t155, ptr %l79
  %t156 = icmp sge i64 0, 0
  br i1 %t156, label %bb23, label %bb24
bb23:
  %t158 = icmp sle i64 0, 576460752303423487
  br i1 %t158, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_ce45aa27b33b13c4_efb6d2bad65aad00)
  unreachable
bb25:
  %t160 = mul i64 0, 16
  %t161 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t160)
  %t162 = insertvalue { i64, ptr } undef, i64 0, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t161, 1
  store { i64, ptr } %t163, ptr %l82, !tbaa !27
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/check:Checker", ptr %t164, i32 0, i32 32
  %t167 = load i64, ptr %l9, !tbaa !24
  %t170 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t166, i64 %t167)
  store { i64, ptr } %t170, ptr %l86
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_ce45aa27b33b13c4_efb6d2bad65aad00)
  unreachable
bb27:
  %t171 = load %"compiler/source:Span", ptr %l79
  %t172 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t173 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t174 = call %"compiler/typed:Clause" @compiler_2ftyped_3aClause_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t171, { i64, ptr } %t172, i1 true, ptr null, { i64, ptr } %t173, i64 -1, i32 0)
  store %"compiler/typed:Clause" %t174, ptr %l87
  br label %bb28
bb28:
  %t175 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store ptr %t175, ptr %lp10
  %t176 = load %"compiler/typed:Clause", ptr %l87
  %t177 = load ptr, ptr %lp10
  store %"compiler/typed:Clause" %t176, ptr %t177
  %t178 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t178, ptr %l88
  %t179 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t179, ptr %l89, !tbaa !23
  %t180 = load ptr, ptr %lp8
  %t181 = load ptr, ptr %lp10
  %t182 = mul i64 1, 8
  %t183 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t182)
  %t184 = insertvalue { i64, ptr } undef, i64 1, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t183, 1
  store { i64, ptr } %t185, ptr %l92, !tbaa !27
  %t187 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !27
  %t189 = getelementptr ptr, ptr %t188, i64 0
  store ptr %t181, ptr %t189, !tbaa !39
  %t191 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t192 = call %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t180, { i64, ptr } %t191, i1 false, i1 false)
  store %"compiler/typed:Try" %t192, ptr %l93
  br label %bb29
bb29:
  %t193 = load %"compiler/typed:Try", ptr %l93
  %t194 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/typed:Try" %t193, ptr %t194
  store { i64, [5 x i64] } zeroinitializer, ptr %t195
  %t196 = getelementptr { i64, [5 x i64] }, ptr %t195, i32 0, i32 0
  store i64 14, ptr %t196
  %t197 = load %"compiler/source:Span", ptr %l88
  %t198 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t197, 0
  %t199 = load i32, ptr %l89, !tbaa !23
  %t200 = insertvalue { %"compiler/source:Span", i32, ptr } %t198, i32 %t199, 1
  %t202 = insertvalue { %"compiler/source:Span", i32, ptr } %t200, ptr %t194, 2
  %t203 = getelementptr { i64, [5 x i64] }, ptr %t195, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t202, ptr %t203
  %t204 = load { i64, [5 x i64] }, ptr %t195
  %t206 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t204, ptr %t206
  call void @__olang_scope_close(ptr %s0)
  store ptr %t206, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l8 = alloca i1
  %l12 = alloca i1
  %l13 = alloca i1
  %l14 = alloca ptr
  %l19 = alloca i32
  %l21 = alloca i1
  %l27 = alloca i32
  %l30 = alloca i1
  %l35 = alloca i32
  %l42 = alloca i32
  %l44 = alloca i1
  %l48 = alloca i1
  %l53 = alloca ptr
  %l58 = alloca i32
  %l63 = alloca i32
  %l64 = alloca i1
  %l65 = alloca i1
  %l66 = alloca ptr
  %l71 = alloca i32
  %l76 = alloca i32
  %l77 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t8 = load i32, ptr %l2, !tbaa !23
  %t12 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t6, i32 %t7, i32 %t8)
  store i1 %t12, ptr %l8
  br label %bb1
bb1:
  %t13 = load i1, ptr %l8, !tbaa !21
  br i1 %t13, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l1, !tbaa !23
  %t19 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisOver(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l12
  br label %bb5
bb5:
  %t20 = load i1, ptr %l12, !tbaa !21
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l14, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l1, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l19
  br label %bb8
bb7:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb10
bb8:
  %t32 = load i32, ptr %l2, !tbaa !23
  %t33 = load ptr, ptr %l14, !tbaa !29
  %t34 = load i32, ptr %l19, !tbaa !23
  %t36 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %t33, i32 %t34, i32 %t32)
  store i1 %t36, ptr %l21
  br label %bb9
bb9:
  %t37 = load i1, ptr %l21, !tbaa !21
  store i1 %t37, ptr %l13, !tbaa !21
  br label %bb10
bb10:
  %t38 = load i1, ptr %l13, !tbaa !21
  br i1 %t38, label %bb11, label %bb12
bb11:
  store i1 true, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/check:Checker", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/generic:Program", ptr %t43, i32 0, i32 2
  %t46 = load i32, ptr %l1, !tbaa !23
  %t49 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t45, i32 %t46)
  store i32 %t49, ptr %l27
  br label %bb14
bb14:
  %t50 = load i32, ptr %l27
  %t52 = trunc i64 19 to i32
  %t53 = icmp eq i32 %t50, %t52
  br i1 %t53, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = getelementptr %"compiler/generic:Program", ptr %t58, i32 0, i32 2
  %t61 = load i32, ptr %l2, !tbaa !23
  %t64 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t60, i32 %t61)
  store i32 %t64, ptr %l35
  br label %bb17
bb16:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb18
bb17:
  %t65 = load i32, ptr %l35
  %t67 = trunc i64 19 to i32
  %t68 = icmp eq i32 %t65, %t67
  store i1 %t68, ptr %l30, !tbaa !21
  br label %bb18
bb18:
  %t70 = load i1, ptr %l30, !tbaa !21
  br i1 %t70, label %bb19, label %bb20
bb19:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 2
  %t77 = load i32, ptr %l2, !tbaa !23
  %t80 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t76, i32 %t77)
  store i32 %t80, ptr %l42
  br label %bb21
bb20:
  br label %bb38
bb21:
  %t81 = load i32, ptr %l42, !tbaa !23
  %t82 = icmp ne i32 %t81, 0
  br i1 %t82, label %bb22, label %bb23
bb22:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i32, ptr %l1, !tbaa !23
  %t86 = load i32, ptr %l2, !tbaa !23
  %t90 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elengthsMeet(ptr %v0, ptr %t84, i32 %t85, i32 %t86)
  store i1 %t90, ptr %l48
  br label %bb24
bb23:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb25
bb24:
  %t91 = load i1, ptr %l48, !tbaa !21
  %t92 = xor i1 %t91, true
  store i1 %t92, ptr %l44, !tbaa !21
  br label %bb25
bb25:
  %t94 = load i1, ptr %l44, !tbaa !21
  br i1 %t94, label %bb26, label %bb27
bb26:
  store i1 false, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/check:Checker", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/generic:Program", ptr %t99, i32 0, i32 2
  store ptr %t101, ptr %l53, !tbaa !29
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/check:Checker", ptr %t102, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = getelementptr %"compiler/generic:Program", ptr %t105, i32 0, i32 2
  %t108 = load i32, ptr %l1, !tbaa !23
  %t111 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t107, i32 %t108)
  store i32 %t111, ptr %l58
  br label %bb29
bb29:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/check:Checker", ptr %t112, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !29
  %t117 = getelementptr %"compiler/generic:Program", ptr %t115, i32 0, i32 2
  %t118 = load i32, ptr %l2, !tbaa !23
  %t121 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t117, i32 %t118)
  store i32 %t121, ptr %l63
  br label %bb30
bb30:
  %t122 = load ptr, ptr %l53, !tbaa !29
  %t123 = load i32, ptr %l58, !tbaa !23
  %t124 = load i32, ptr %l63, !tbaa !23
  %t125 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t122, i32 %t123, i32 %t124)
  store i1 %t125, ptr %l64
  br label %bb31
bb31:
  %t126 = load i1, ptr %l64, !tbaa !21
  br i1 %t126, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb37
bb33:
  %t127 = load ptr, ptr %l0, !tbaa !29
  store ptr %t127, ptr %l66, !tbaa !29
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/check:Checker", ptr %t128, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !29
  %t133 = getelementptr %"compiler/generic:Program", ptr %t131, i32 0, i32 2
  %t134 = load i32, ptr %l1, !tbaa !23
  %t137 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t133, i32 %t134)
  store i32 %t137, ptr %l71
  br label %bb34
bb34:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/check:Checker", ptr %t138, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t143 = getelementptr %"compiler/generic:Program", ptr %t141, i32 0, i32 2
  %t144 = load i32, ptr %l2, !tbaa !23
  %t147 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t143, i32 %t144)
  store i32 %t147, ptr %l76
  br label %bb35
bb35:
  %t148 = load ptr, ptr %l66, !tbaa !29
  %t149 = load i32, ptr %l71, !tbaa !23
  %t150 = load i32, ptr %l76, !tbaa !23
  %t151 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %t148, i32 %t149, i32 %t150)
  store i1 %t151, ptr %l77
  br label %bb36
bb36:
  %t152 = load i1, ptr %l77, !tbaa !21
  store i1 %t152, ptr %l65, !tbaa !21
  br label %bb37
bb37:
  %t153 = load i1, ptr %l65, !tbaa !21
  store i1 %t153, ptr %rv
  br label %ret
bb38:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnNameAt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l13 = alloca ptr
  %l17 = alloca i64
  %l23 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l39 = alloca i64
  %l52 = alloca i64
  %l53 = alloca { i64, ptr }
  %l54 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i32
  %l68 = alloca i64
  %l80 = alloca ptr
  %rv = alloca { i64, [3 x i64] }
  %t179 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l13
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l13, !tbaa !29
  store ptr %t9, ptr %l2, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l17
  br label %bb2
bb2:
  %t18 = load i64, ptr %l17, !tbaa !24
  store i64 %t18, ptr %l3, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/load:Loader", ptr %t25, i32 0, i32 5
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t27, i64 %t28)
  store ptr %t31, ptr %l23
  br label %bb3
bb3:
  %t32 = load ptr, ptr %l23, !tbaa !29
  %t34 = getelementptr %"compiler/load:Module", ptr %t32, i32 0, i32 6
  %t35 = load ptr, ptr %t34, !tbaa !29
  store ptr %t35, ptr %l4, !tbaa !29
  %t37 = load ptr, ptr %l4, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  br i1 %t39, label %bb4, label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_a78beee7b0d01a06_c23e8f3cd3901b22)
  unreachable
bb5:
  br label %bb6
bb6:
  %t41 = load ptr, ptr %l4, !tbaa !29
  %t44 = getelementptr %"compiler/source:Source", ptr %t41, i32 0, i32 1
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  store { i64, ptr } %t45, ptr %l5, !tbaa !27
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load ptr, ptr %l2, !tbaa !29
  %t50 = getelementptr %"compiler/ast:Func", ptr %t48, i32 0, i32 2
  %t51 = load i32, ptr %t50, !tbaa !23
  %t54 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t47, i32 %t51)
  store { i64, ptr } %t54, ptr %l34
  br label %bb7
bb7:
  %t55 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t55, ptr %l6, !tbaa !27
  %t56 = load ptr, ptr %l2, !tbaa !29
  %t58 = getelementptr %"compiler/ast:Func", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = icmp eq ptr %t59, null
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb8, label %bb9
bb8:
  %t65 = load ptr, ptr %l2, !tbaa !29
  %t67 = getelementptr %"compiler/ast:Func", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = icmp eq ptr %t68, null
  br i1 %t70, label %bb10, label %bb11
bb9:
  %t72 = load ptr, ptr %l2, !tbaa !29
  %t74 = getelementptr %"compiler/ast:Func", ptr %t72, i32 0, i32 0
  %t75 = getelementptr %"compiler/source:Span", ptr %t74, i32 0, i32 0
  %t76 = load i32, ptr %t75, !tbaa !23
  %t78 = sext i32 %t76 to i64
  %t80 = add i64 %t78, 2
  store i64 %t80, ptr %l39, !tbaa !24
  br label %bb13
bb10:
  call void @__olang_check_failed(ptr @olang_loc_a9ac84188a5d3ced_8a30b05829c2589)
  unreachable
bb11:
  br label %bb12
bb12:
  %t82 = load ptr, ptr %l2, !tbaa !29
  %t84 = getelementptr %"compiler/ast:Func", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t88 = getelementptr %"compiler/ast:Param", ptr %t85, i32 0, i32 0
  %t89 = getelementptr %"compiler/source:Span", ptr %t88, i32 0, i32 1
  %t90 = load i32, ptr %t89, !tbaa !23
  %t92 = sext i32 %t90 to i64
  store i64 %t92, ptr %l39, !tbaa !24
  br label %bb13
bb13:
  %t94 = load i64, ptr %l39, !tbaa !24
  store i64 %t94, ptr %l7, !tbaa !24
  %t95 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t95, ptr %l53, !tbaa !27
  %t96 = load i64, ptr %l7, !tbaa !24
  store i64 %t96, ptr %l54, !tbaa !24
  %t97 = load ptr, ptr %l2, !tbaa !29
  %t99 = getelementptr %"compiler/ast:Func", ptr %t97, i32 0, i32 0
  %t100 = getelementptr %"compiler/source:Span", ptr %t99, i32 0, i32 1
  %t101 = load i32, ptr %t100, !tbaa !23
  %t103 = sext i32 %t101 to i64
  store i64 %t103, ptr %l57, !tbaa !24
  %t104 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 0
  store i64 %t105, ptr %l58, !tbaa !24
  %t106 = load i64, ptr %l54, !tbaa !24
  %t107 = icmp sge i64 %t106, 0
  br i1 %t107, label %bb14, label %bb15
bb14:
  %t109 = load i64, ptr %l54, !tbaa !24
  %t110 = load i64, ptr %l57, !tbaa !24
  %t111 = icmp sle i64 %t109, %t110
  br i1 %t111, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_d343f6dbe85f33a0_61dfe5c423c7544c)
  unreachable
bb16:
  %t113 = load i64, ptr %l57, !tbaa !24
  %t114 = load i64, ptr %l58, !tbaa !24
  %t115 = icmp sle i64 %t113, %t114
  br i1 %t115, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_d343f6dbe85f33a0_61dfe5c423c7544c)
  unreachable
bb18:
  %t117 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = load i64, ptr %l54, !tbaa !24
  %t120 = load i64, ptr %l57, !tbaa !24
  %t121 = getelementptr i8, ptr %t118, i64 %t119
  %t122 = sub i64 %t120, %t119
  %t123 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t121, 1
  %t125 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t128 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v0, { i64, ptr } %t124, { i64, ptr } %t125)
  %t129 = extractvalue { i32, i64 } %t128, 1
  %t130 = extractvalue { i32, i64 } %t128, 0
  store i32 %t130, ptr %l65
  %t131 = icmp ne i32 %t130, 0
  br i1 %t131, label %bb21, label %ok.132
ok.132:
  store i64 %t129, ptr %l64
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_d343f6dbe85f33a0_61dfe5c423c7544c)
  unreachable
bb20:
  %t133 = load i64, ptr %l64, !tbaa !24
  store i64 %t133, ptr %l52, !tbaa !24
  br label %bb23
bb21:
  br label %bb22
bb22:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l52, !tbaa !24
  br label %bb23
bb23:
  %t134 = load i64, ptr %l52, !tbaa !24
  store i64 %t134, ptr %l8, !tbaa !24
  %t135 = load i64, ptr %l8, !tbaa !24
  %t137 = icmp slt i64 %t135, 0
  br i1 %t137, label %bb24, label %bb25
bb24:
  %t139 = load ptr, ptr %l2, !tbaa !29
  %t141 = getelementptr %"compiler/ast:Func", ptr %t139, i32 0, i32 0
  %t142 = getelementptr %"compiler/source:Span", ptr %t141, i32 0, i32 0
  %t143 = load i32, ptr %t142, !tbaa !23
  %t145 = sext i32 %t143 to i64
  store i64 %t145, ptr %l68, !tbaa !24
  br label %bb26
bb25:
  %t147 = load i64, ptr %l7, !tbaa !24
  %t148 = load i64, ptr %l8, !tbaa !24
  %t151 = add i64 %t147, %t148
  store i64 %t151, ptr %l68, !tbaa !24
  br label %bb26
bb26:
  %t153 = load i64, ptr %l68, !tbaa !24
  store i64 %t153, ptr %l9, !tbaa !24
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/check:Checker", ptr %t154, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t159 = getelementptr %"compiler/generic:Program", ptr %t157, i32 0, i32 0
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t162 = getelementptr %"compiler/load:Loader", ptr %t160, i32 0, i32 5
  %t163 = load i64, ptr %l3, !tbaa !24
  %t166 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t162, i64 %t163)
  store ptr %t166, ptr %l80
  br label %bb27
bb27:
  %t167 = load ptr, ptr %l80, !tbaa !29
  %t169 = getelementptr %"compiler/load:Module", ptr %t167, i32 0, i32 4
  %t170 = load i64, ptr %t169, !tbaa !24
  %t171 = load i64, ptr %l9, !tbaa !24
  %t172 = load i64, ptr %l9, !tbaa !24
  %t173 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t175 = extractvalue { i64, ptr } %t173, 0
  %t178 = add i64 %t172, %t175
  store { i64, [3 x i64] } zeroinitializer, ptr %t179
  %t180 = getelementptr { i64, [3 x i64] }, ptr %t179, i32 0, i32 0
  store i64 3, ptr %t180
  %t182 = insertvalue { i64, i64, i64 } undef, i64 %t170, 0
  %t184 = insertvalue { i64, i64, i64 } %t182, i64 %t171, 1
  %t186 = insertvalue { i64, i64, i64 } %t184, i64 %t178, 2
  %t187 = getelementptr { i64, [3 x i64] }, ptr %t179, i32 0, i32 1
  store { i64, i64, i64 } %t186, ptr %t187
  %t188 = load { i64, [3 x i64] }, ptr %t179
  store { i64, [3 x i64] } %t188, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [3 x i64] }, ptr %rv
  ret { i64, [3 x i64] } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca ptr
  %l9 = alloca i64
  %l11 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 13
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_H2d42092ce658fb6cce0104fa754a4e33(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp sgt i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 13
  store ptr %t11, ptr %l6, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 13
  %t16 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_H2d42092ce658fb6cce0104fa754a4e33(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l9
  br label %bb4
bb3:
  %t17 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t19 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t17, 1
  call void @__olang_check_failed_text(ptr @olang_loc_fd7c4531a6f9112_8820f62eca2e3ad6, { i64, ptr } %t20)
  unreachable
bb4:
  %t21 = load i64, ptr %l9, !tbaa !24
  %t22 = sub i64 %t21, 1
  %t23 = load ptr, ptr %l6, !tbaa !29
  %t25 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_Hbcd822ae67306ca6a025f17ed2cfb61c(ptr %v0, ptr %v0, ptr %t23, i64 %t22)
  store ptr %t25, ptr %l11
  br label %bb5
bb5:
  %t26 = load ptr, ptr %l11, !tbaa !29
  store ptr %t26, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l6
  br label %bb1
bb1:
  %t11 = load i32, ptr %l6
  %t13 = trunc i64 20 to i32
  %t14 = icmp eq i32 %t11, %t13
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisTrait(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l6 = alloca i32
  %l9 = alloca i1
  %l12 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l6
  br label %bb1
bb1:
  %t11 = load i32, ptr %l6
  %t13 = trunc i64 18 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  store ptr %t21, ptr %l12, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l1, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l17
  br label %bb4
bb3:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb6
bb4:
  %t32 = load ptr, ptr %l12, !tbaa !29
  %t33 = load i32, ptr %l17, !tbaa !23
  %t34 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t34, ptr %l18
  br label %bb5
bb5:
  %t35 = load i32, ptr %l18
  %t37 = trunc i64 3 to i32
  %t38 = icmp eq i32 %t35, %t37
  store i1 %t38, ptr %l9, !tbaa !21
  br label %bb6
bb6:
  %t40 = load i1, ptr %l9, !tbaa !21
  store i1 %t40, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eknownInt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i1
  %l17 = alloca i64
  %l22 = alloca ptr
  %l24 = alloca i32
  %l26 = alloca i32
  %l28 = alloca ptr
  %l30 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca i32
  %l41 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 -1, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 12
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l3, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t18, i32 0, i32 2
  %t20 = load { i64, ptr }, ptr %t19
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t24 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t28 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamLen(ptr %v0, ptr %v1, ptr %v1, ptr %t22, ptr %t23, { i64, ptr } %t24)
  store i64 %t28, ptr %l17
  br label %bb6
bb6:
  %t29 = load i64, ptr %l17, !tbaa !24
  store i64 %t29, ptr %l2, !tbaa !24
  br label %bb8
bb7:
  br label %bb8
bb8:
  %t30 = load i64, ptr %l2, !tbaa !24
  %t32 = icmp sge i64 %t30, 0
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  store ptr %t39, ptr %l22, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t40)
  store i32 %t42, ptr %l24
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t43 = load i64, ptr %l2, !tbaa !24
  %t44 = load ptr, ptr %l22, !tbaa !29
  %t45 = load i32, ptr %l24, !tbaa !23
  %t47 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t44, i32 %t45, i64 %t43)
  store i32 %t47, ptr %l26
  br label %bb12
bb12:
  %t48 = load i32, ptr %l26, !tbaa !23
  store i32 %t48, ptr %rv
  br label %ret
bb13:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  store ptr %t52, ptr %l28, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t53)
  store ptr %t55, ptr %l30
  br label %bb14
bb14:
  %t56 = load ptr, ptr %l30, !tbaa !29
  %t58 = getelementptr %"compiler/check:frame", ptr %t56, i32 0, i32 4
  store ptr %t58, ptr %l32, !tbaa !29
  %t59 = load ptr, ptr %l1, !tbaa !29
  store ptr %t59, ptr %l33, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t60)
  store i32 %t62, ptr %l35
  br label %bb15
bb15:
  %t63 = load ptr, ptr %l28, !tbaa !29
  %t64 = load ptr, ptr %l32, !tbaa !29
  %t65 = load ptr, ptr %l33, !tbaa !29
  %t66 = load i32, ptr %l35, !tbaa !23
  %t67 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFoldKnown(ptr %v0, ptr %v0, ptr %v1, ptr %t63, ptr %t64, ptr %t65, i32 %t66)
  store i32 %t67, ptr %l36
  br label %bb16
bb16:
  %t68 = load i32, ptr %l36, !tbaa !23
  store i32 %t68, ptr %l5, !tbaa !23
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/generic:Program", ptr %t72, i32 0, i32 2
  %t75 = load i32, ptr %l5, !tbaa !23
  %t78 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t74, i32 %t75)
  store i32 %t78, ptr %l41
  br label %bb17
bb17:
  %t79 = load i32, ptr %l41
  %t81 = trunc i64 26 to i32
  %t82 = icmp eq i32 %t79, %t81
  br i1 %t82, label %bb18, label %bb19
bb18:
  %t84 = load i32, ptr %l5, !tbaa !23
  store i32 %t84, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  store i32 -1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitArray(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l24 = alloca i32
  %l26 = alloca ptr
  %l27 = alloca i1
  %l34 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l45 = alloca i1
  %l46 = alloca i1
  %l49 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l64 = alloca { i64, ptr }
  %l70 = alloca i1
  %l71 = alloca ptr
  %l77 = alloca i1
  %s7 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 18
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t12 = load ptr, ptr %l16, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb7, label %bb8
bb7:
  %t15 = load ptr, ptr %l16, !tbaa !29
  %t16 = load i64, ptr %t15
  %t18 = icmp eq i64 %t16, 16
  store i1 %t18, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t19 = load i1, ptr %l17, !tbaa !21
  br i1 %t19, label %bb9, label %bb10
bb9:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [5 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t22, i32 0, i32 1
  %t24 = load ptr, ptr %t23
  store ptr %t24, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t30 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t26, ptr %t27)
  store i32 %t30, ptr %l24
  br label %bb12
bb12:
  %t31 = load i32, ptr %l24, !tbaa !23
  %t32 = icmp sge i32 %t31, 0
  store i1 %t32, ptr %rv
  br label %ret
bb13:
  %t34 = load ptr, ptr %l1, !tbaa !29
  store ptr %t34, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t35 = load ptr, ptr %l26, !tbaa !29
  %t36 = icmp ne ptr %t35, null
  br i1 %t36, label %bb14, label %bb15
bb14:
  %t38 = load ptr, ptr %l26, !tbaa !29
  %t39 = load i64, ptr %t38
  %t41 = icmp eq i64 %t39, 2
  store i1 %t41, ptr %l27, !tbaa !21
  br label %bb15
bb15:
  %t42 = load i1, ptr %l27, !tbaa !21
  br i1 %t42, label %bb16, label %bb17
bb16:
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr { i64, [5 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", ptr }, ptr %t45, i32 0, i32 1
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l3, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load ptr, ptr %l3, !tbaa !29
  %t53 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitArray(ptr %v0, ptr %v1, ptr %t49, ptr %t50)
  store i1 %t53, ptr %l34
  br label %bb19
bb19:
  %t54 = load i1, ptr %l34, !tbaa !21
  store i1 %t54, ptr %rv
  br label %ret
bb20:
  %t55 = load ptr, ptr %l1, !tbaa !29
  store ptr %t55, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t56 = load ptr, ptr %l35, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb21, label %bb22
bb21:
  %t59 = load ptr, ptr %l35, !tbaa !29
  %t60 = load i64, ptr %t59
  %t62 = icmp eq i64 %t60, 8
  store i1 %t62, ptr %l36, !tbaa !21
  br label %bb22
bb22:
  %t63 = load i1, ptr %l36, !tbaa !21
  br i1 %t63, label %bb23, label %bb24
bb23:
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr { i64, [5 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t66, i32 0, i32 1
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l4, !tbaa !29
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr { i64, [5 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t72, i32 0, i32 3
  %t74 = load ptr, ptr %t73
  store ptr %t74, ptr %l5, !tbaa !29
  br label %bb25
bb24:
  br label %bb31
bb25:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load ptr, ptr %l4, !tbaa !29
  %t80 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitArray(ptr %v0, ptr %v1, ptr %t76, ptr %t77)
  store i1 %t80, ptr %l45
  br label %bb26
bb26:
  %t81 = load i1, ptr %l45, !tbaa !21
  br i1 %t81, label %bb27, label %bb28
bb27:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load ptr, ptr %l5, !tbaa !29
  %t86 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitArray(ptr %v0, ptr %v1, ptr %t82, ptr %t83)
  store i1 %t86, ptr %l49
  br label %bb29
bb28:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb30
bb29:
  %t87 = load i1, ptr %l49, !tbaa !21
  store i1 %t87, ptr %l46, !tbaa !21
  br label %bb30
bb30:
  %t88 = load i1, ptr %l46, !tbaa !21
  store i1 %t88, ptr %rv
  br label %ret
bb31:
  %t89 = load ptr, ptr %l1, !tbaa !29
  store ptr %t89, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t90 = load ptr, ptr %l50, !tbaa !29
  %t91 = icmp ne ptr %t90, null
  br i1 %t91, label %bb32, label %bb33
bb32:
  %t93 = load ptr, ptr %l50, !tbaa !29
  %t94 = load i64, ptr %t93
  %t96 = icmp eq i64 %t94, 24
  store i1 %t96, ptr %l51, !tbaa !21
  br label %bb33
bb33:
  %t97 = load i1, ptr %l51, !tbaa !21
  br i1 %t97, label %bb34, label %bb35
bb34:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr { i64, [5 x i64] }, ptr %t98, i32 0, i32 1
  %t101 = getelementptr { %"compiler/source:Span", ptr }, ptr %t100, i32 0, i32 1
  %t102 = load ptr, ptr %t101
  store ptr %t102, ptr %l6, !tbaa !29
  br label %bb36
bb35:
  br label %bb53
bb36:
  %t104 = load ptr, ptr %l6, !tbaa !29
  %t106 = getelementptr %"compiler/ast:Match", ptr %t104, i32 0, i32 3
  %t107 = load { i64, ptr }, ptr %t106, !tbaa !27
  store { i64, ptr } %t107, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t109 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t109, 0
  store i64 %t111, ptr %l9, !tbaa !24
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s7
  %t113 = load i64, ptr %l8, !tbaa !24
  %t114 = load i64, ptr %l9, !tbaa !24
  %t117 = icmp slt i64 %t113, %t114
  %t119 = xor i1 %t117, true
  br i1 %t119, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s7)
  br label %bb52
bb39:
  br label %bb40
bb40:
  %t121 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t121, ptr %l64, !tbaa !27
  %t122 = load i64, ptr %l8, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr ptr, ptr %t125, i64 %t122
  %t127 = load ptr, ptr %t126, !tbaa !39
  store ptr %t127, ptr %l10, !tbaa !29
  %t129 = load ptr, ptr %l10, !tbaa !29
  %t131 = getelementptr %"compiler/ast:Case", ptr %t129, i32 0, i32 5
  %t132 = load ptr, ptr %t131, !tbaa !29
  %t134 = icmp eq ptr %t132, null
  br i1 %t134, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb47
bb42:
  %t136 = load ptr, ptr %l0, !tbaa !29
  store ptr %t136, ptr %l71, !tbaa !29
  %t137 = load ptr, ptr %l10, !tbaa !29
  %t139 = getelementptr %"compiler/ast:Case", ptr %t137, i32 0, i32 5
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t142 = icmp eq ptr %t140, null
  br i1 %t142, label %bb43, label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_ddeebe9155436d6a_19ee353760b572b6)
  unreachable
bb44:
  br label %bb45
bb45:
  %t144 = load ptr, ptr %l10, !tbaa !29
  %t146 = getelementptr %"compiler/ast:Case", ptr %t144, i32 0, i32 5
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t148 = load ptr, ptr %l71, !tbaa !29
  %t150 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitArray(ptr %v0, ptr %v1, ptr %t148, ptr %t147)
  store i1 %t150, ptr %l77
  br label %bb46
bb46:
  %t151 = load i1, ptr %l77, !tbaa !21
  %t152 = xor i1 %t151, true
  store i1 %t152, ptr %l70, !tbaa !21
  br label %bb47
bb47:
  %t154 = load i1, ptr %l70, !tbaa !21
  br i1 %t154, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s7)
  store i1 false, ptr %rv
  br label %ret
bb49:
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s7)
  br label %bb51
bb51:
  %t156 = load i64, ptr %l8, !tbaa !24
  %t158 = add i64 %t156, 1
  store i64 %t158, ptr %l8, !tbaa !24
  br label %bb37
bb52:
  %t160 = load ptr, ptr %l6, !tbaa !29
  %t162 = getelementptr %"compiler/ast:Match", ptr %t160, i32 0, i32 3
  %t163 = load { i64, ptr }, ptr %t162, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t163, 0
  %t167 = icmp sgt i64 %t165, 0
  store i1 %t167, ptr %rv
  br label %ret
bb53:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca i64
  %l4 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i32
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %a0)
  store ptr %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l4, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 8
  %t10 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t6, i32 %a1)
  %t11 = extractvalue { i32, i64 } %t10, 1
  %t12 = extractvalue { i32, i64 } %t10, 0
  store i32 %t12, ptr %l9
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb3, label %ok.14
ok.14:
  store i64 %t11, ptr %l8
  br label %bb2
bb2:
  %t15 = load i64, ptr %l8, !tbaa !24
  store i64 %t15, ptr %l2, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l2, !tbaa !24
  br label %bb5
bb5:
  %t16 = load i64, ptr %l2, !tbaa !24
  store i64 %t16, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emember(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca %"compiler/names:Ref"
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l15 = alloca ptr
  %l17 = alloca ptr
  %l21 = alloca %"compiler/names:Ref"
  %l22 = alloca %"compiler/source:Span"
  %l25 = alloca { i64, ptr }
  %l27 = alloca %"compiler/source:Span"
  %l30 = alloca ptr
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca %"compiler/source:Span"
  %l36 = alloca i32
  %l41 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca %"compiler/source:Span"
  %l50 = alloca i64
  %l54 = alloca ptr
  %l60 = alloca ptr
  %l68 = alloca ptr
  %l74 = alloca ptr
  %l81 = alloca i32
  %l84 = alloca i1
  %l87 = alloca i1
  %l88 = alloca i1
  %l91 = alloca { i64, ptr }
  %l92 = alloca i1
  %l93 = alloca i1
  %l96 = alloca i1
  %l103 = alloca ptr
  %l106 = alloca ptr
  %l107 = alloca %"compiler/source:Span"
  %l108 = alloca %"compiler/source:Span"
  %l109 = alloca i32
  %l110 = alloca i32
  %l113 = alloca { i64, ptr }
  %l117 = alloca ptr
  %l120 = alloca i32
  %l123 = alloca i1
  %l128 = alloca i32
  %l131 = alloca ptr
  %l132 = alloca %"compiler/source:Span"
  %l133 = alloca %"compiler/source:Span"
  %l134 = alloca i32
  %l135 = alloca i32
  %l140 = alloca ptr
  %l144 = alloca i64
  %l150 = alloca ptr
  %l153 = alloca ptr
  %l158 = alloca ptr
  %l164 = alloca ptr
  %l169 = alloca ptr
  %l173 = alloca ptr
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca ptr
  %t54 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l15, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t8)
  store ptr %t10, ptr %l17
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l17, !tbaa !29
  %t13 = getelementptr %"compiler/check:frame", ptr %t11, i32 0, i32 2
  %t14 = load i64, ptr %t13, !tbaa !24
  %t15 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t16 = load i32, ptr %t15, !tbaa !23
  %t17 = load ptr, ptr %l15, !tbaa !29
  %t20 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %t17, i64 %t14, i32 %t16)
  store %"compiler/names:Ref" %t20, ptr %l21
  br label %bb2
bb2:
  %t21 = load %"compiler/names:Ref", ptr %l21
  store %"compiler/names:Ref" %t21, ptr %l5
  %t22 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t22, ptr %l22
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l3, !tbaa !23
  %t27 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t23, i32 %t24)
  store { i64, ptr } %t27, ptr %l25
  br label %bb3
bb3:
  %t28 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  %t30 = load %"compiler/source:Span", ptr %l22
  %t32 = call %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %t30, i64 %t29)
  store %"compiler/source:Span" %t32, ptr %l27
  br label %bb4
bb4:
  %t33 = load %"compiler/source:Span", ptr %l27
  store %"compiler/source:Span" %t33, ptr %l6
  %t34 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t35 = load i32, ptr %t34
  %t37 = trunc i64 2 to i32
  %t38 = icmp eq i32 %t35, %t37
  br i1 %t38, label %bb5, label %bb6
bb5:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l30, !tbaa !29
  %t41 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t41, ptr %l31
  %t42 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t42, ptr %l32
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 1
  %t45 = load i64, ptr %t44, !tbaa !24
  %t46 = load i32, ptr %l3, !tbaa !23
  %t50 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalType(ptr %v0, ptr %t43, i64 %t45, i32 %t46)
  store i32 %t50, ptr %l36
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t51 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 1
  %t52 = load i64, ptr %t51, !tbaa !24
  %t53 = load i32, ptr %l3, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t54
  %t55 = getelementptr { i64, [4 x i64] }, ptr %t54, i32 0, i32 0
  store i64 1, ptr %t55
  %t56 = load %"compiler/source:Span", ptr %l32
  %t57 = insertvalue { %"compiler/source:Span", i32, i64, i32 } undef, %"compiler/source:Span" %t56, 0
  %t58 = load i32, ptr %l36, !tbaa !23
  %t59 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t57, i32 %t58, 1
  %t61 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t59, i64 %t52, 2
  %t63 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t61, i32 %t53, 3
  %t64 = getelementptr { i64, [4 x i64] }, ptr %t54, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, i32 } %t63, ptr %t64
  %t65 = load { i64, [4 x i64] }, ptr %t54
  %t67 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t65, ptr %t67
  %t68 = load ptr, ptr %l30, !tbaa !29
  %t69 = load %"compiler/source:Span", ptr %l31
  %t71 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t68, %"compiler/source:Span" %t69, ptr %t67)
  store ptr %t71, ptr %l41
  br label %bb8
bb8:
  %t72 = load ptr, ptr %l41, !tbaa !29
  store ptr %t72, ptr %rv
  br label %ret
bb9:
  %t73 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t74 = load i32, ptr %t73
  %t76 = trunc i64 3 to i32
  %t77 = icmp eq i32 %t74, %t76
  br i1 %t77, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l44, !tbaa !29
  %t80 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t80, ptr %l45
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/check:Checker", ptr %t81, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t85 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 1
  %t86 = load i64, ptr %t85, !tbaa !24
  %t87 = load i32, ptr %l3, !tbaa !23
  %t91 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %t84, i64 %t86, i32 %t87)
  store i64 %t91, ptr %l50
  br label %bb12
bb11:
  br label %bb18
bb12:
  %t92 = icmp sge i64 0, 0
  br i1 %t92, label %bb13, label %bb14
bb13:
  %t94 = icmp sle i64 0, 2305843009213693951
  br i1 %t94, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_2c6c6a9e0d4d53fe_41be050b28a8c6c2)
  unreachable
bb15:
  %t96 = mul i64 0, 4
  %t97 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t96)
  %t98 = insertvalue { i64, ptr } undef, i64 0, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t97, 1
  %t100 = load ptr, ptr %l44, !tbaa !29
  %t101 = load %"compiler/source:Span", ptr %l45
  %t102 = load i64, ptr %l50, !tbaa !24
  %t104 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnValue(ptr %v0, ptr %s2, ptr %t100, %"compiler/source:Span" %t101, i64 %t102, { i64, ptr } %t99)
  store ptr %t104, ptr %l54
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_2c6c6a9e0d4d53fe_41be050b28a8c6c2)
  unreachable
bb17:
  call void @__olang_scope_close(ptr %s2)
  %t105 = load ptr, ptr %l54, !tbaa !29
  store ptr %t105, ptr %rv
  br label %ret
bb18:
  %t106 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t107 = load i32, ptr %t106
  %t109 = trunc i64 6 to i32
  %t110 = icmp eq i32 %t107, %t109
  br i1 %t110, label %bb19, label %bb20
bb19:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load %"compiler/source:Span", ptr %l1
  %t114 = load i32, ptr %l3, !tbaa !23
  %t118 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuildConst(ptr %v0, ptr %t112, %"compiler/source:Span" %t113, i32 %t114)
  store ptr %t118, ptr %l60
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t119 = load ptr, ptr %l60, !tbaa !29
  store ptr %t119, ptr %rv
  br label %ret
bb22:
  %t120 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t121 = load i32, ptr %t120
  %t123 = trunc i64 0 to i32
  %t124 = icmp eq i32 %t121, %t123
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load %"compiler/source:Span", ptr %l6
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s4, ptr %t128, %"compiler/source:Span" %t129, { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d12, i32 0, i32 1) })
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load %"compiler/source:Span", ptr %l1
  %t136 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t132, %"compiler/source:Span" %t133)
  store ptr %t136, ptr %l68
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s4)
  %t137 = load ptr, ptr %l68, !tbaa !29
  store ptr %t137, ptr %rv
  br label %ret
bb27:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load %"compiler/source:Span", ptr %l1
  %t140 = load %"compiler/source:Span", ptr %l6
  %t141 = load ptr, ptr %l2, !tbaa !29
  %t142 = load i32, ptr %l3, !tbaa !23
  %t148 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflMember(ptr %v0, ptr %v1, ptr %t138, %"compiler/source:Span" %t139, %"compiler/source:Span" %t140, ptr %t141, i32 %t142)
  store ptr %t148, ptr %l74
  br label %bb28
bb28:
  %t149 = load ptr, ptr %l74, !tbaa !29
  store ptr %t149, ptr %l7, !tbaa !29
  %t150 = load ptr, ptr %l7, !tbaa !29
  %t152 = icmp eq ptr %t150, null
  %t154 = xor i1 %t152, true
  br i1 %t154, label %bb29, label %bb30
bb29:
  %t156 = load ptr, ptr %l7, !tbaa !29
  store ptr %t156, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load ptr, ptr %l2, !tbaa !29
  %t162 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t158, ptr %t159)
  store i32 %t162, ptr %l81
  br label %bb32
bb32:
  %t163 = load i32, ptr %l81, !tbaa !23
  store i32 %t163, ptr %l8, !tbaa !23
  %t164 = load i32, ptr %l8, !tbaa !23
  %t166 = icmp sge i32 %t164, 0
  br i1 %t166, label %bb33, label %bb34
bb33:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load i32, ptr %l8, !tbaa !23
  %t172 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t168, i32 %t169)
  store i1 %t172, ptr %l87
  br label %bb35
bb34:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb45
bb35:
  %t173 = load i1, ptr %l87, !tbaa !21
  br i1 %t173, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l88, !tbaa !21
  br label %bb44
bb37:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load i32, ptr %l3, !tbaa !23
  %t178 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t174, i32 %t175)
  store { i64, ptr } %t178, ptr %l91
  br label %bb38
bb38:
  %t179 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t180 = call i1 @compiler_2fcheck_2eisLimitName(ptr %v0, { i64, ptr } %t179)
  store i1 %t180, ptr %l92
  br label %bb39
bb39:
  %t181 = load i1, ptr %l92, !tbaa !21
  br i1 %t181, label %bb40, label %bb41
bb40:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load i32, ptr %l8, !tbaa !23
  %t186 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t182, i32 %t183)
  store i1 %t186, ptr %l96
  br label %bb42
bb41:
  store i1 false, ptr %l93, !tbaa !21
  br label %bb43
bb42:
  %t187 = load i1, ptr %l96, !tbaa !21
  %t188 = xor i1 %t187, true
  store i1 %t188, ptr %l93, !tbaa !21
  br label %bb43
bb43:
  %t190 = load i1, ptr %l93, !tbaa !21
  store i1 %t190, ptr %l88, !tbaa !21
  br label %bb44
bb44:
  %t191 = load i1, ptr %l88, !tbaa !21
  store i1 %t191, ptr %l84, !tbaa !21
  br label %bb45
bb45:
  %t192 = load i1, ptr %l84, !tbaa !21
  br i1 %t192, label %bb46, label %bb47
bb46:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load %"compiler/source:Span", ptr %l1
  %t195 = load %"compiler/source:Span", ptr %l6
  %t196 = load i32, ptr %l8, !tbaa !23
  %t197 = load i32, ptr %l3, !tbaa !23
  %t203 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elimit(ptr %v0, ptr %t193, %"compiler/source:Span" %t194, %"compiler/source:Span" %t195, i32 %t196, i32 %t197)
  store ptr %t203, ptr %l103
  br label %bb48
bb47:
  br label %bb49
bb48:
  %t204 = load ptr, ptr %l103, !tbaa !29
  store ptr %t204, ptr %rv
  br label %ret
bb49:
  %t205 = load i32, ptr %l8, !tbaa !23
  %t207 = icmp sge i32 %t205, 0
  br i1 %t207, label %bb50, label %bb51
bb50:
  %t209 = load ptr, ptr %l0, !tbaa !29
  store ptr %t209, ptr %l106, !tbaa !29
  %t210 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t210, ptr %l107
  %t211 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t211, ptr %l108
  %t212 = load i32, ptr %l8, !tbaa !23
  store i32 %t212, ptr %l109, !tbaa !23
  %t213 = load i32, ptr %l3, !tbaa !23
  store i32 %t213, ptr %l110, !tbaa !23
  %t214 = icmp sge i64 0, 0
  br i1 %t214, label %bb52, label %bb53
bb51:
  br label %bb61
bb52:
  %t216 = icmp sle i64 0, 1152921504606846975
  br i1 %t216, label %bb54, label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_8d8450bdf58ba933_21a3ad59bc75be77)
  unreachable
bb54:
  %t218 = mul i64 0, 8
  %t219 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t218)
  %t220 = insertvalue { i64, ptr } undef, i64 0, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr %t219, 1
  store { i64, ptr } %t221, ptr %l113, !tbaa !27
  %t222 = icmp sge i64 0, 0
  br i1 %t222, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_8d8450bdf58ba933_21a3ad59bc75be77)
  unreachable
bb56:
  %t224 = icmp sle i64 0, 1152921504606846975
  br i1 %t224, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @olang_loc_c41dfbcd22d81110_5c09edf2d4d23d4)
  unreachable
bb58:
  %t226 = mul i64 0, 8
  %t227 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t226)
  %t228 = insertvalue { i64, ptr } undef, i64 0, 0
  %t229 = insertvalue { i64, ptr } %t228, ptr %t227, 1
  %t230 = load ptr, ptr %l106, !tbaa !29
  %t231 = load %"compiler/source:Span", ptr %l107
  %t232 = load %"compiler/source:Span", ptr %l108
  %t233 = load i32, ptr %l109, !tbaa !23
  %t234 = load i32, ptr %l110, !tbaa !23
  %t235 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t237 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eenumCase(ptr %v0, ptr %v0, ptr %v0, ptr %t230, %"compiler/source:Span" %t231, %"compiler/source:Span" %t232, i32 %t233, i32 %t234, { i64, ptr } %t235, { i64, ptr } %t229)
  store ptr %t237, ptr %l117
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_c41dfbcd22d81110_5c09edf2d4d23d4)
  unreachable
bb60:
  %t238 = load ptr, ptr %l117, !tbaa !29
  store ptr %t238, ptr %rv
  br label %ret
bb61:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load ptr, ptr %l2, !tbaa !29
  %t243 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericNamed(ptr %v0, ptr %v1, ptr %t239, ptr %t240)
  store i32 %t243, ptr %l120
  br label %bb62
bb62:
  %t244 = load i32, ptr %l120, !tbaa !23
  store i32 %t244, ptr %l9, !tbaa !23
  %t245 = load i32, ptr %l9, !tbaa !23
  %t247 = icmp sge i32 %t245, 0
  br i1 %t247, label %bb63, label %bb64
bb63:
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t251 = getelementptr %"compiler/check:Checker", ptr %t249, i32 0, i32 1
  %t252 = load ptr, ptr %t251, !tbaa !29
  %t254 = getelementptr %"compiler/generic:Program", ptr %t252, i32 0, i32 2
  %t255 = load i32, ptr %l9, !tbaa !23
  %t258 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t254, i32 %t255)
  store i32 %t258, ptr %l128
  br label %bb65
bb64:
  store i1 false, ptr %l123, !tbaa !21
  br label %bb66
bb65:
  %t259 = load i32, ptr %l128
  %t261 = trunc i64 1 to i32
  %t262 = icmp eq i32 %t259, %t261
  store i1 %t262, ptr %l123, !tbaa !21
  br label %bb66
bb66:
  %t264 = load i1, ptr %l123, !tbaa !21
  br i1 %t264, label %bb67, label %bb68
bb67:
  %t265 = load ptr, ptr %l0, !tbaa !29
  store ptr %t265, ptr %l131, !tbaa !29
  %t266 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t266, ptr %l132
  %t267 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t267, ptr %l133
  %t268 = load i32, ptr %l9, !tbaa !23
  store i32 %t268, ptr %l134, !tbaa !23
  %t269 = load i32, ptr %l3, !tbaa !23
  store i32 %t269, ptr %l135, !tbaa !23
  %t270 = icmp sge i64 0, 0
  br i1 %t270, label %bb69, label %bb70
bb68:
  br label %bb74
bb69:
  %t272 = icmp sle i64 0, 1152921504606846975
  br i1 %t272, label %bb71, label %bb72
bb70:
  call void @__olang_check_failed(ptr @olang_loc_d2fbf365f111393d_99a61c47f5e25be1)
  unreachable
bb71:
  %t274 = mul i64 0, 8
  %t275 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t274)
  %t276 = insertvalue { i64, ptr } undef, i64 0, 0
  %t277 = insertvalue { i64, ptr } %t276, ptr %t275, 1
  %t279 = load ptr, ptr %l131, !tbaa !29
  %t280 = load %"compiler/source:Span", ptr %l132
  %t281 = load %"compiler/source:Span", ptr %l133
  %t282 = load i32, ptr %l134, !tbaa !23
  %t283 = load i32, ptr %l135, !tbaa !23
  %t286 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericCase(ptr %v0, ptr %v0, ptr %t279, %"compiler/source:Span" %t280, %"compiler/source:Span" %t281, i32 %t282, i32 %t283, { i64, ptr } %t277, i32 %a4)
  store ptr %t286, ptr %l140
  br label %bb73
bb72:
  call void @__olang_check_failed(ptr @olang_loc_d2fbf365f111393d_99a61c47f5e25be1)
  unreachable
bb73:
  %t287 = load ptr, ptr %l140, !tbaa !29
  store ptr %t287, ptr %rv
  br label %ret
bb74:
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t289 = load ptr, ptr %l2, !tbaa !29
  %t290 = load i32, ptr %l3, !tbaa !23
  %t294 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowedName(ptr %v0, ptr %v1, ptr %t288, ptr %t289, i32 %t290)
  store i64 %t294, ptr %l144
  br label %bb75
bb75:
  %t295 = load i64, ptr %l144, !tbaa !24
  store i64 %t295, ptr %l10, !tbaa !24
  %t296 = load i64, ptr %l10, !tbaa !24
  %t298 = icmp sge i64 %t296, 0
  br i1 %t298, label %bb76, label %bb77
bb76:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t301 = load %"compiler/source:Span", ptr %l1
  %t302 = load i64, ptr %l10, !tbaa !24
  %t306 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t300, %"compiler/source:Span" %t301, i64 %t302)
  store ptr %t306, ptr %l150
  br label %bb78
bb77:
  br label %bb79
bb78:
  %t307 = load ptr, ptr %l150, !tbaa !29
  store ptr %t307, ptr %rv
  br label %ret
bb79:
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t309 = load ptr, ptr %l2, !tbaa !29
  %t312 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %t308, ptr %t309)
  store ptr %t312, ptr %l153
  br label %bb80
bb80:
  %t313 = load ptr, ptr %l153, !tbaa !29
  store ptr %t313, ptr %l11, !tbaa !29
  %t314 = load ptr, ptr %l11, !tbaa !29
  %t316 = icmp eq ptr %t314, null
  br i1 %t316, label %bb81, label %bb82
bb81:
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t319 = load %"compiler/source:Span", ptr %l1
  %t322 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t318, %"compiler/source:Span" %t319)
  store ptr %t322, ptr %l158
  br label %bb83
bb82:
  br label %bb84
bb83:
  %t323 = load ptr, ptr %l158, !tbaa !29
  store ptr %t323, ptr %rv
  br label %ret
bb84:
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t325 = load %"compiler/source:Span", ptr %l1
  %t326 = load %"compiler/source:Span", ptr %l6
  %t327 = load ptr, ptr %l11, !tbaa !29
  %t328 = load i32, ptr %l3, !tbaa !23
  %t334 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efield(ptr %v0, ptr %t324, %"compiler/source:Span" %t325, %"compiler/source:Span" %t326, ptr %t327, i32 %t328)
  store ptr %t334, ptr %l164
  br label %bb85
bb85:
  %t335 = load ptr, ptr %l164, !tbaa !29
  store ptr %t335, ptr %l12, !tbaa !29
  %t336 = load ptr, ptr %l12, !tbaa !29
  %t338 = icmp eq ptr %t336, null
  br i1 %t338, label %bb86, label %bb87
bb86:
  %t340 = load ptr, ptr %l0, !tbaa !29
  %t341 = load %"compiler/source:Span", ptr %l1
  %t344 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t340, %"compiler/source:Span" %t341)
  store ptr %t344, ptr %l169
  br label %bb88
bb87:
  br label %bb89
bb88:
  %t345 = load ptr, ptr %l169, !tbaa !29
  store ptr %t345, ptr %rv
  br label %ret
bb89:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t347 = load %"compiler/source:Span", ptr %l1
  %t348 = load ptr, ptr %l12, !tbaa !29
  %t352 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t346, %"compiler/source:Span" %t347, ptr %t348)
  store ptr %t352, ptr %l173
  br label %bb90
bb90:
  %t353 = load ptr, ptr %l173, !tbaa !29
  store ptr %t353, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emustWrite(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i1
  %l4 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i32
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l29 = alloca ptr
  %l31 = alloca %"compiler/typed:Local"
  %l34 = alloca i1
  %l35 = alloca ptr
  %l37 = alloca ptr
  %l39 = alloca %"compiler/typed:Local"
  %l41 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca %"compiler/source:Span"
  %l45 = alloca %"compiler/msgs:Msg"
  %l46 = alloca i64
  %l49 = alloca i1
  %l53 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca %"compiler/source:Span"
  %l56 = alloca ptr
  %l58 = alloca ptr
  %l60 = alloca %"compiler/typed:Local"
  %l62 = alloca { i64, ptr }
  %l64 = alloca %"compiler/msgs:Msg"
  %l65 = alloca i64
  %l75 = alloca ptr
  %l76 = alloca i1
  %l87 = alloca ptr
  %l91 = alloca i1
  %l94 = alloca i1
  %l96 = alloca ptr
  %l97 = alloca %"compiler/source:Span"
  %l100 = alloca { i64, ptr }
  %l101 = alloca %"compiler/msgs:Msg"
  %l102 = alloca i64
  %l103 = alloca ptr
  %l104 = alloca i1
  %l111 = alloca i32
  %l114 = alloca i1
  %l115 = alloca i1
  %l120 = alloca i64
  %l126 = alloca i1
  %l127 = alloca ptr
  %l128 = alloca %"compiler/source:Span"
  %l129 = alloca %"compiler/msgs:Msg"
  %l130 = alloca i64
  %l131 = alloca ptr
  %l132 = alloca ptr
  %l133 = alloca %"compiler/source:Span"
  %l134 = alloca %"compiler/msgs:Msg"
  %l135 = alloca i64
  %l139 = alloca i1
  %l140 = alloca i1
  %l141 = alloca ptr
  %l143 = alloca ptr
  %l144 = alloca ptr
  %l145 = alloca i64
  %l147 = alloca ptr
  %l148 = alloca %"compiler/source:Span"
  %l149 = alloca %"compiler/msgs:Msg"
  %l150 = alloca i64
  %l151 = alloca ptr
  %l152 = alloca i64
  %l154 = alloca ptr
  %l155 = alloca ptr
  %l158 = alloca i1
  %l159 = alloca ptr
  %l161 = alloca ptr
  %l162 = alloca ptr
  %l163 = alloca ptr
  %l164 = alloca i1
  %l171 = alloca ptr
  %l172 = alloca i1
  %l179 = alloca i1
  %l182 = alloca %"compiler/source:Span"
  %l185 = alloca i1
  %l188 = alloca i1
  %l191 = alloca %"compiler/source:Span"
  %l192 = alloca ptr
  %l193 = alloca %"compiler/source:Span"
  %l194 = alloca %"compiler/msgs:Msg"
  %l195 = alloca i64
  %l196 = alloca ptr
  %l197 = alloca %"compiler/source:Span"
  %l198 = alloca %"compiler/msgs:Msg"
  %l199 = alloca i64
  %l204 = alloca ptr
  %l205 = alloca i1
  %l215 = alloca ptr
  %l216 = alloca i1
  %l226 = alloca ptr
  %l227 = alloca i1
  %l232 = alloca i1
  %l233 = alloca ptr
  %l234 = alloca i1
  %l238 = alloca i1
  %l241 = alloca i1
  %l242 = alloca ptr
  %l243 = alloca %"compiler/source:Span"
  %l244 = alloca %"compiler/msgs:Msg"
  %l245 = alloca i64
  %l247 = alloca ptr
  %l248 = alloca %"compiler/source:Span"
  %l250 = alloca %"compiler/msgs:Msg"
  %l251 = alloca %"compiler/msgs:Msg"
  %l252 = alloca %"compiler/msgs:Msg"
  %l253 = alloca i64
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s28 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteWrite(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t6 = load ptr, ptr %l22, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l22, !tbaa !29
  %t10 = load i64, ptr %t9
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l23, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l23, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t16, i32 0, i32 2
  %t18 = load i32, ptr %t17
  store i32 %t18, ptr %l4, !tbaa !23
  br label %bb6
bb5:
  br label %bb37
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t20)
  store ptr %t22, ptr %l29
  br label %bb7
bb7:
  %t23 = load i32, ptr %l4, !tbaa !23
  %t24 = load ptr, ptr %l29, !tbaa !29
  %t26 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t24, i32 %t23)
  store %"compiler/typed:Local" %t26, ptr %l31
  br label %bb8
bb8:
  %t27 = getelementptr %"compiler/typed:Local", ptr %l31, i32 0, i32 4
  %t28 = load i32, ptr %t27
  %t30 = trunc i64 5 to i32
  %t31 = icmp eq i32 %t28, %t30
  br i1 %t31, label %bb9, label %bb10
bb9:
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l35, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t34)
  store ptr %t36, ptr %l37
  br label %bb11
bb10:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb14
bb11:
  %t37 = load i32, ptr %l4, !tbaa !23
  %t38 = load ptr, ptr %l37, !tbaa !29
  %t40 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t38, i32 %t37)
  store %"compiler/typed:Local" %t40, ptr %l39
  br label %bb12
bb12:
  %t41 = getelementptr %"compiler/typed:Local", ptr %l39, i32 0, i32 2
  %t42 = load i32, ptr %t41, !tbaa !23
  %t43 = load ptr, ptr %l35, !tbaa !29
  %t45 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t43, i32 %t42)
  store i1 %t45, ptr %l41
  br label %bb13
bb13:
  %t46 = load i1, ptr %l41, !tbaa !21
  %t47 = xor i1 %t46, true
  store i1 %t47, ptr %l34, !tbaa !21
  br label %bb14
bb14:
  %t49 = load i1, ptr %l34, !tbaa !21
  br i1 %t49, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l43, !tbaa !29
  %t51 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t51, ptr %l44
  %t52 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaptureReadOnly(ptr %s2)
  store %"compiler/msgs:Msg" %t52, ptr %l45
  br label %bb17
bb16:
  %t53 = load i1, ptr %l3, !tbaa !21
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb19, label %bb20
bb17:
  %t57 = load ptr, ptr %l43, !tbaa !29
  %t58 = load %"compiler/source:Span", ptr %l44
  %t59 = load %"compiler/msgs:Msg", ptr %l45
  %t60 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t57, %"compiler/source:Span" %t58, %"compiler/msgs:Msg" %t59)
  store i64 %t60, ptr %l46
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb36
bb19:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i32, ptr %l4, !tbaa !23
  %t64 = sext i32 %t62 to i64
  %t67 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLocal(ptr %v0, ptr %t61, i64 %t64)
  store i1 %t67, ptr %l53
  br label %bb21
bb20:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb22
bb21:
  %t68 = load i1, ptr %l53, !tbaa !21
  store i1 %t68, ptr %l49, !tbaa !21
  br label %bb22
bb22:
  %t69 = load i1, ptr %l49, !tbaa !21
  br i1 %t69, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l54, !tbaa !29
  %t71 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t71, ptr %l55
  %t72 = load ptr, ptr %l0, !tbaa !29
  store ptr %t72, ptr %l56, !tbaa !29
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t73)
  store ptr %t75, ptr %l58
  br label %bb25
bb24:
  %t76 = load i1, ptr %l3, !tbaa !21
  %t78 = xor i1 %t76, true
  br i1 %t78, label %bb31, label %bb32
bb25:
  %t80 = load i32, ptr %l4, !tbaa !23
  %t81 = load ptr, ptr %l58, !tbaa !29
  %t83 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t81, i32 %t80)
  store %"compiler/typed:Local" %t83, ptr %l60
  br label %bb26
bb26:
  %t84 = getelementptr %"compiler/typed:Local", ptr %l60, i32 0, i32 2
  %t85 = load i32, ptr %t84, !tbaa !23
  %t86 = load ptr, ptr %l56, !tbaa !29
  %t88 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFix(ptr %v0, ptr %s4, ptr %t86, i32 0, i32 %t85)
  store { i64, ptr } %t88, ptr %l62
  br label %bb27
bb27:
  %t89 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t89, 0
  %t91 = extractvalue { i64, ptr } %t89, 1
  %t92 = mul i64 %t90, 1
  %t93 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t92)
  call void @llvm.memcpy.p0.p0.i64(ptr %t93, ptr %t91, i64 %t92, i1 false)
  %t94 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t93, 1
  %t97 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyLent(ptr %s4, ptr %s4, { i64, ptr } %t95)
  store %"compiler/msgs:Msg" %t97, ptr %l64
  br label %bb28
bb28:
  %t98 = load ptr, ptr %l54, !tbaa !29
  %t99 = load %"compiler/source:Span", ptr %l55
  %t100 = load %"compiler/msgs:Msg", ptr %l64
  %t101 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t98, %"compiler/source:Span" %t99, %"compiler/msgs:Msg" %t100)
  store i64 %t101, ptr %l65
  br label %bb29
bb29:
  %t102 = load i64, ptr %l65, !tbaa !24
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteRo(ptr %v0, ptr %v1, ptr %t103, i64 %t102, ptr %t105)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s4)
  br label %bb35
bb31:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroNeed(ptr %v0, ptr %v1, ptr %t110, ptr %t111)
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb34
bb34:
  br label %bb35
bb35:
  br label %bb36
bb36:
  br label %bb180
bb37:
  %t115 = load ptr, ptr %l1, !tbaa !29
  store ptr %t115, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t116 = load ptr, ptr %l75, !tbaa !29
  %t117 = icmp ne ptr %t116, null
  br i1 %t117, label %bb38, label %bb39
bb38:
  %t119 = load ptr, ptr %l75, !tbaa !29
  %t120 = load i64, ptr %t119
  %t122 = icmp eq i64 %t120, 1
  store i1 %t122, ptr %l76, !tbaa !21
  br label %bb39
bb39:
  %t123 = load i1, ptr %l76, !tbaa !21
  br i1 %t123, label %bb40, label %bb41
bb40:
  %t124 = load ptr, ptr %l1, !tbaa !29
  %t126 = getelementptr { i64, [4 x i64] }, ptr %t124, i32 0, i32 1
  %t127 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t126, i32 0, i32 2
  %t128 = load i64, ptr %t127
  store i64 %t128, ptr %l6, !tbaa !24
  %t130 = load ptr, ptr %l1, !tbaa !29
  %t132 = getelementptr { i64, [4 x i64] }, ptr %t130, i32 0, i32 1
  %t133 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t132, i32 0, i32 3
  %t134 = load i32, ptr %t133
  store i32 %t134, ptr %l7, !tbaa !23
  br label %bb42
bb41:
  br label %bb54
bb42:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/check:Checker", ptr %t136, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t140 = load i64, ptr %l6, !tbaa !24
  %t141 = load i32, ptr %l7, !tbaa !23
  %t145 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %t139, i64 %t140, i32 %t141)
  store ptr %t145, ptr %l87
  br label %bb43
bb43:
  %t146 = load ptr, ptr %l87, !tbaa !29
  store ptr %t146, ptr %l8, !tbaa !29
  %t147 = load ptr, ptr %l8, !tbaa !29
  %t149 = icmp eq ptr %t147, null
  %t151 = xor i1 %t149, true
  br i1 %t151, label %bb44, label %bb45
bb44:
  %t153 = load ptr, ptr %l8, !tbaa !29
  %t155 = getelementptr %"compiler/ast:VarDecl", ptr %t153, i32 0, i32 2
  %t156 = load ptr, ptr %t155, !tbaa !29
  %t158 = call i1 @compiler_2fcheck_2ewrittenMut(ptr %v0, ptr %t156)
  store i1 %t158, ptr %l94
  br label %bb46
bb45:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb47
bb46:
  %t159 = load i1, ptr %l94, !tbaa !21
  %t160 = xor i1 %t159, true
  store i1 %t160, ptr %l91, !tbaa !21
  br label %bb47
bb47:
  %t162 = load i1, ptr %l91, !tbaa !21
  br i1 %t162, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s8
  %t163 = load ptr, ptr %l0, !tbaa !29
  store ptr %t163, ptr %l96, !tbaa !29
  %t164 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t164, ptr %l97
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load i32, ptr %l7, !tbaa !23
  %t169 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t165, i32 %t166)
  store { i64, ptr } %t169, ptr %l100
  br label %bb50
bb49:
  br label %bb53
bb50:
  %t170 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t171 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eImmutable(ptr %v0, ptr %s8, { i64, ptr } %t170)
  store %"compiler/msgs:Msg" %t171, ptr %l101
  br label %bb51
bb51:
  %t172 = load ptr, ptr %l96, !tbaa !29
  %t173 = load %"compiler/source:Span", ptr %l97
  %t174 = load %"compiler/msgs:Msg", ptr %l101
  %t175 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t172, %"compiler/source:Span" %t173, %"compiler/msgs:Msg" %t174)
  store i64 %t175, ptr %l102
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s8)
  br label %bb53
bb53:
  br label %bb180
bb54:
  %t176 = load ptr, ptr %l1, !tbaa !29
  store ptr %t176, ptr %l103, !tbaa !29
  store i1 false, ptr %l104, !tbaa !21
  %t177 = load ptr, ptr %l103, !tbaa !29
  %t178 = icmp ne ptr %t177, null
  br i1 %t178, label %bb55, label %bb56
bb55:
  %t180 = load ptr, ptr %l103, !tbaa !29
  %t181 = load i64, ptr %t180
  %t183 = icmp eq i64 %t181, 2
  store i1 %t183, ptr %l104, !tbaa !21
  br label %bb56
bb56:
  %t184 = load i1, ptr %l104, !tbaa !21
  br i1 %t184, label %bb57, label %bb58
bb57:
  %t185 = load ptr, ptr %l1, !tbaa !29
  %t187 = getelementptr { i64, [4 x i64] }, ptr %t185, i32 0, i32 1
  %t188 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t187, i32 0, i32 2
  %t189 = load ptr, ptr %t188
  store ptr %t189, ptr %l9, !tbaa !29
  br label %bb59
bb58:
  br label %bb100
bb59:
  %t191 = load ptr, ptr %l9, !tbaa !29
  %t194 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t191)
  store i32 %t194, ptr %l111
  br label %bb60
bb60:
  %t195 = load i32, ptr %l111, !tbaa !23
  store i32 %t195, ptr %l10, !tbaa !23
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load i32, ptr %l10, !tbaa !23
  %t200 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t196, i32 %t197)
  store i1 %t200, ptr %l114
  br label %bb61
bb61:
  %t201 = load i1, ptr %l114, !tbaa !21
  br i1 %t201, label %bb62, label %bb63
bb62:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/check:Checker", ptr %t202, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !29
  %t207 = getelementptr %"compiler/generic:Program", ptr %t205, i32 0, i32 2
  %t208 = load i32, ptr %l10, !tbaa !23
  %t211 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t207, i32 %t208)
  store i64 %t211, ptr %l120
  br label %bb64
bb63:
  store i1 false, ptr %l115, !tbaa !21
  br label %bb65
bb64:
  %t212 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t213 = load i64, ptr %l120, !tbaa !24
  %t215 = and i64 %t213, %t212
  %t217 = icmp eq i64 %t215, 0
  store i1 %t217, ptr %l115, !tbaa !21
  br label %bb65
bb65:
  %t219 = load i1, ptr %l115, !tbaa !21
  br i1 %t219, label %bb66, label %bb67
bb66:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load ptr, ptr %l9, !tbaa !29
  %t224 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecapturedValue(ptr %v0, ptr %v1, ptr %t220, ptr %t221)
  store i1 %t224, ptr %l126
  br label %bb68
bb67:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load i32, ptr %l10, !tbaa !23
  %t229 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t225, i32 %t226)
  store i1 %t229, ptr %l139
  br label %bb77
bb68:
  %t230 = load i1, ptr %l126, !tbaa !21
  br i1 %t230, label %bb69, label %bb70
bb69:
  store %olang.scope zeroinitializer, ptr %s11
  %t231 = load ptr, ptr %l0, !tbaa !29
  store ptr %t231, ptr %l127, !tbaa !29
  %t232 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t232, ptr %l128
  %t233 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaptureReadOnly(ptr %s11)
  store %"compiler/msgs:Msg" %t233, ptr %l129
  br label %bb71
bb70:
  store %olang.scope zeroinitializer, ptr %s12
  %t234 = load ptr, ptr %l0, !tbaa !29
  store ptr %t234, ptr %l131, !tbaa !29
  %t235 = load ptr, ptr %l0, !tbaa !29
  store ptr %t235, ptr %l132, !tbaa !29
  %t236 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t236, ptr %l133
  %t237 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyRefWrite(ptr %s12)
  store %"compiler/msgs:Msg" %t237, ptr %l134
  br label %bb73
bb71:
  %t238 = load ptr, ptr %l127, !tbaa !29
  %t239 = load %"compiler/source:Span", ptr %l128
  %t240 = load %"compiler/msgs:Msg", ptr %l129
  %t241 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s11, ptr %t238, %"compiler/source:Span" %t239, %"compiler/msgs:Msg" %t240)
  store i64 %t241, ptr %l130
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s11)
  br label %bb76
bb73:
  %t242 = load ptr, ptr %l132, !tbaa !29
  %t243 = load %"compiler/source:Span", ptr %l133
  %t244 = load %"compiler/msgs:Msg", ptr %l134
  %t245 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s12, ptr %t242, %"compiler/source:Span" %t243, %"compiler/msgs:Msg" %t244)
  store i64 %t245, ptr %l135
  br label %bb74
bb74:
  %t246 = load ptr, ptr %l9, !tbaa !29
  %t247 = load ptr, ptr %l131, !tbaa !29
  %t248 = load i64, ptr %l135, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteWritable(ptr %v0, ptr %v1, ptr %t247, i64 %t248, ptr %t246)
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s12)
  br label %bb76
bb76:
  br label %bb99
bb77:
  %t250 = load i1, ptr %l139, !tbaa !21
  br i1 %t250, label %bb78, label %bb79
bb78:
  %t251 = load ptr, ptr %l0, !tbaa !29
  store ptr %t251, ptr %l141, !tbaa !29
  %t252 = load ptr, ptr %l9, !tbaa !29
  %t254 = call ptr @compiler_2fcheck_2eunwrapped(ptr %v1, ptr %t252)
  store ptr %t254, ptr %l143
  br label %bb80
bb79:
  store i1 false, ptr %l140, !tbaa !21
  br label %bb83
bb80:
  %t255 = load ptr, ptr %l143, !tbaa !29
  %t256 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %t255)
  store ptr %t256, ptr %l144
  br label %bb81
bb81:
  %t257 = load ptr, ptr %l141, !tbaa !29
  %t258 = load ptr, ptr %l144, !tbaa !29
  %t259 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRoot(ptr %v0, ptr %v1, ptr %t257, ptr %t258)
  store i64 %t259, ptr %l145
  br label %bb82
bb82:
  %t260 = load i64, ptr %l145, !tbaa !24
  %t261 = icmp sge i64 %t260, 0
  store i1 %t261, ptr %l140, !tbaa !21
  br label %bb83
bb83:
  %t263 = load i1, ptr %l140, !tbaa !21
  br i1 %t263, label %bb84, label %bb85
bb84:
  store %olang.scope zeroinitializer, ptr %s14
  %t264 = load ptr, ptr %l0, !tbaa !29
  store ptr %t264, ptr %l147, !tbaa !29
  %t265 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t265, ptr %l148
  %t266 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyWrite(ptr %s14)
  store %"compiler/msgs:Msg" %t266, ptr %l149
  br label %bb86
bb85:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t268 = load i32, ptr %l10, !tbaa !23
  %t271 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t267, i32 %t268)
  store i1 %t271, ptr %l158
  br label %bb91
bb86:
  %t272 = load ptr, ptr %l147, !tbaa !29
  %t273 = load %"compiler/source:Span", ptr %l148
  %t274 = load %"compiler/msgs:Msg", ptr %l149
  %t275 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s14, ptr %t272, %"compiler/source:Span" %t273, %"compiler/msgs:Msg" %t274)
  store i64 %t275, ptr %l150
  br label %bb87
bb87:
  %t276 = load i64, ptr %l150, !tbaa !24
  %t277 = load ptr, ptr %l0, !tbaa !29
  store ptr %t277, ptr %l151, !tbaa !29
  store i64 %t276, ptr %l152, !tbaa !24
  %t279 = load ptr, ptr %l9, !tbaa !29
  %t281 = call ptr @compiler_2fcheck_2eunwrapped(ptr %v1, ptr %t279)
  store ptr %t281, ptr %l154
  br label %bb88
bb88:
  %t282 = load ptr, ptr %l154, !tbaa !29
  %t283 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %t282)
  store ptr %t283, ptr %l155
  br label %bb89
bb89:
  %t284 = load ptr, ptr %l151, !tbaa !29
  %t285 = load i64, ptr %l152, !tbaa !24
  %t286 = load ptr, ptr %l155, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteRo(ptr %v0, ptr %v1, ptr %t284, i64 %t285, ptr %t286)
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s14)
  br label %bb98
bb91:
  %t287 = load i1, ptr %l158, !tbaa !21
  br i1 %t287, label %bb92, label %bb93
bb92:
  %t288 = load ptr, ptr %l0, !tbaa !29
  store ptr %t288, ptr %l159, !tbaa !29
  %t289 = load ptr, ptr %l9, !tbaa !29
  %t291 = call ptr @compiler_2fcheck_2eunwrapped(ptr %v1, ptr %t289)
  store ptr %t291, ptr %l161
  br label %bb94
bb93:
  br label %bb97
bb94:
  %t292 = load ptr, ptr %l161, !tbaa !29
  %t293 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %t292)
  store ptr %t293, ptr %l162
  br label %bb95
bb95:
  %t294 = load ptr, ptr %l159, !tbaa !29
  %t295 = load ptr, ptr %l162, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroNeed(ptr %v0, ptr %v1, ptr %t294, ptr %t295)
  br label %bb96
bb96:
  br label %bb97
bb97:
  br label %bb98
bb98:
  br label %bb99
bb99:
  br label %bb180
bb100:
  %t296 = load ptr, ptr %l1, !tbaa !29
  store ptr %t296, ptr %l163, !tbaa !29
  store i1 false, ptr %l164, !tbaa !21
  %t297 = load ptr, ptr %l163, !tbaa !29
  %t298 = icmp ne ptr %t297, null
  br i1 %t298, label %bb101, label %bb102
bb101:
  %t300 = load ptr, ptr %l163, !tbaa !29
  %t301 = load i64, ptr %t300
  %t303 = icmp eq i64 %t301, 3
  store i1 %t303, ptr %l164, !tbaa !21
  br label %bb102
bb102:
  %t304 = load i1, ptr %l164, !tbaa !21
  br i1 %t304, label %bb103, label %bb104
bb103:
  %t305 = load ptr, ptr %l1, !tbaa !29
  %t307 = getelementptr { i64, [4 x i64] }, ptr %t305, i32 0, i32 1
  %t308 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t307, i32 0, i32 0
  %t309 = load %"compiler/source:Span", ptr %t308
  store %"compiler/source:Span" %t309, ptr %l12
  %t311 = load ptr, ptr %l1, !tbaa !29
  %t313 = getelementptr { i64, [4 x i64] }, ptr %t311, i32 0, i32 1
  %t314 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t313, i32 0, i32 2
  %t315 = load ptr, ptr %t314
  store ptr %t315, ptr %l13, !tbaa !29
  br label %bb105
bb104:
  br label %bb130
bb105:
  %t317 = load ptr, ptr %l13, !tbaa !29
  store ptr %t317, ptr %l171, !tbaa !29
  store i1 false, ptr %l172, !tbaa !21
  %t318 = load ptr, ptr %l171, !tbaa !29
  %t319 = icmp ne ptr %t318, null
  br i1 %t319, label %bb106, label %bb107
bb106:
  %t321 = load ptr, ptr %l171, !tbaa !29
  %t322 = load i64, ptr %t321
  %t324 = icmp eq i64 %t322, 6
  store i1 %t324, ptr %l172, !tbaa !21
  br label %bb107
bb107:
  %t325 = load i1, ptr %l172, !tbaa !21
  br i1 %t325, label %bb108, label %bb109
bb108:
  %t326 = load ptr, ptr %l13, !tbaa !29
  %t328 = getelementptr { i64, [4 x i64] }, ptr %t326, i32 0, i32 1
  %t329 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t328, i32 0, i32 2
  %t330 = load ptr, ptr %t329
  store ptr %t330, ptr %l14, !tbaa !29
  br label %bb110
bb109:
  br label %bb127
bb110:
  %t332 = load i1, ptr %l3, !tbaa !21
  %t334 = xor i1 %t332, true
  br i1 %t334, label %bb111, label %bb112
bb111:
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t337 = load ptr, ptr %l14, !tbaa !29
  %t340 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echosenAt(ptr %v0, ptr %v1, ptr %t336, ptr %t337)
  store %"compiler/source:Span" %t340, ptr %l182
  br label %bb113
bb112:
  store i1 false, ptr %l179, !tbaa !21
  br label %bb114
bb113:
  %t341 = getelementptr %"compiler/source:Span", ptr %l182, i32 0, i32 0
  %t342 = load i32, ptr %t341, !tbaa !23
  %t344 = icmp sge i32 %t342, 0
  store i1 %t344, ptr %l179, !tbaa !21
  br label %bb114
bb114:
  %t346 = load i1, ptr %l179, !tbaa !21
  br i1 %t346, label %bb115, label %bb116
bb115:
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t348 = load ptr, ptr %l14, !tbaa !29
  %t351 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econdChoosesPlace(ptr %v0, ptr %v1, ptr %t347, ptr %t348)
  store i1 %t351, ptr %l188
  br label %bb117
bb116:
  store i1 false, ptr %l185, !tbaa !21
  br label %bb118
bb117:
  %t352 = load i1, ptr %l188, !tbaa !21
  store i1 %t352, ptr %l185, !tbaa !21
  br label %bb118
bb118:
  %t353 = load i1, ptr %l185, !tbaa !21
  br i1 %t353, label %bb119, label %bb120
bb119:
  store %olang.scope zeroinitializer, ptr %s19
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t355 = load %"compiler/source:Span", ptr %l12
  %t358 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elastName(ptr %v0, ptr %t354, %"compiler/source:Span" %t355)
  store %"compiler/source:Span" %t358, ptr %l191
  br label %bb121
bb120:
  br label %bb126
bb121:
  %t359 = load %"compiler/source:Span", ptr %l191
  store %"compiler/source:Span" %t359, ptr %l15
  %t360 = load ptr, ptr %l0, !tbaa !29
  store ptr %t360, ptr %l192, !tbaa !29
  %t361 = load %"compiler/source:Span", ptr %l15
  store %"compiler/source:Span" %t361, ptr %l193
  %t362 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondLentWritable(ptr %s19)
  store %"compiler/msgs:Msg" %t362, ptr %l194
  br label %bb122
bb122:
  %t363 = load ptr, ptr %l192, !tbaa !29
  %t364 = load %"compiler/source:Span", ptr %l193
  %t365 = load %"compiler/msgs:Msg", ptr %l194
  %t366 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s19, ptr %t363, %"compiler/source:Span" %t364, %"compiler/msgs:Msg" %t365)
  store i64 %t366, ptr %l195
  br label %bb123
bb123:
  %t367 = load ptr, ptr %l0, !tbaa !29
  store ptr %t367, ptr %l196, !tbaa !29
  %t368 = load %"compiler/source:Span", ptr %l15
  store %"compiler/source:Span" %t368, ptr %l197
  %t369 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyToWritable(ptr %s19)
  store %"compiler/msgs:Msg" %t369, ptr %l198
  br label %bb124
bb124:
  %t370 = load ptr, ptr %l196, !tbaa !29
  %t371 = load %"compiler/source:Span", ptr %l197
  %t372 = load %"compiler/msgs:Msg", ptr %l198
  %t373 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s19, ptr %t370, %"compiler/source:Span" %t371, %"compiler/msgs:Msg" %t372)
  store i64 %t373, ptr %l199
  br label %bb125
bb125:
  call void @__olang_scope_close(ptr %s19)
  br label %ret
bb126:
  br label %bb128
bb127:
  br label %bb128
bb128:
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t375 = load ptr, ptr %l13, !tbaa !29
  %t376 = load %"compiler/source:Span", ptr %l2
  %t377 = load i1, ptr %l3, !tbaa !21
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emustWrite(ptr %v0, ptr %v1, ptr %t374, ptr %t375, %"compiler/source:Span" %t376, i1 %t377)
  br label %bb129
bb129:
  br label %bb180
bb130:
  %t382 = load ptr, ptr %l1, !tbaa !29
  store ptr %t382, ptr %l204, !tbaa !29
  store i1 false, ptr %l205, !tbaa !21
  %t383 = load ptr, ptr %l204, !tbaa !29
  %t384 = icmp ne ptr %t383, null
  br i1 %t384, label %bb131, label %bb132
bb131:
  %t386 = load ptr, ptr %l204, !tbaa !29
  %t387 = load i64, ptr %t386
  %t389 = icmp eq i64 %t387, 4
  store i1 %t389, ptr %l205, !tbaa !21
  br label %bb132
bb132:
  %t390 = load i1, ptr %l205, !tbaa !21
  br i1 %t390, label %bb133, label %bb134
bb133:
  %t391 = load ptr, ptr %l1, !tbaa !29
  %t393 = getelementptr { i64, [4 x i64] }, ptr %t391, i32 0, i32 1
  %t394 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t393, i32 0, i32 2
  %t395 = load ptr, ptr %t394
  store ptr %t395, ptr %l16, !tbaa !29
  br label %bb135
bb134:
  br label %bb137
bb135:
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t398 = load ptr, ptr %l16, !tbaa !29
  %t400 = getelementptr %"compiler/typed:Elem", ptr %t398, i32 0, i32 0
  %t401 = load ptr, ptr %t400, !tbaa !29
  %t402 = load %"compiler/source:Span", ptr %l2
  %t403 = load i1, ptr %l3, !tbaa !21
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emustWrite(ptr %v0, ptr %v1, ptr %t397, ptr %t401, %"compiler/source:Span" %t402, i1 %t403)
  br label %bb136
bb136:
  br label %bb180
bb137:
  %t408 = load ptr, ptr %l1, !tbaa !29
  store ptr %t408, ptr %l215, !tbaa !29
  store i1 false, ptr %l216, !tbaa !21
  %t409 = load ptr, ptr %l215, !tbaa !29
  %t410 = icmp ne ptr %t409, null
  br i1 %t410, label %bb138, label %bb139
bb138:
  %t412 = load ptr, ptr %l215, !tbaa !29
  %t413 = load i64, ptr %t412
  %t415 = icmp eq i64 %t413, 5
  store i1 %t415, ptr %l216, !tbaa !21
  br label %bb139
bb139:
  %t416 = load i1, ptr %l216, !tbaa !21
  br i1 %t416, label %bb140, label %bb141
bb140:
  %t417 = load ptr, ptr %l1, !tbaa !29
  %t419 = getelementptr { i64, [4 x i64] }, ptr %t417, i32 0, i32 1
  %t420 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t419, i32 0, i32 2
  %t421 = load ptr, ptr %t420
  store ptr %t421, ptr %l17, !tbaa !29
  br label %bb142
bb141:
  br label %bb144
bb142:
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t424 = load ptr, ptr %l17, !tbaa !29
  %t426 = getelementptr %"compiler/typed:Payload", ptr %t424, i32 0, i32 0
  %t427 = load ptr, ptr %t426, !tbaa !29
  %t428 = load %"compiler/source:Span", ptr %l2
  %t429 = load i1, ptr %l3, !tbaa !21
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emustWrite(ptr %v0, ptr %v1, ptr %t423, ptr %t427, %"compiler/source:Span" %t428, i1 %t429)
  br label %bb143
bb143:
  br label %bb180
bb144:
  %t434 = load ptr, ptr %l1, !tbaa !29
  store ptr %t434, ptr %l226, !tbaa !29
  store i1 false, ptr %l227, !tbaa !21
  %t435 = load ptr, ptr %l226, !tbaa !29
  %t436 = icmp ne ptr %t435, null
  br i1 %t436, label %bb145, label %bb146
bb145:
  %t438 = load ptr, ptr %l226, !tbaa !29
  %t439 = load i64, ptr %t438
  %t441 = icmp eq i64 %t439, 6
  store i1 %t441, ptr %l227, !tbaa !21
  br label %bb146
bb146:
  %t442 = load i1, ptr %l227, !tbaa !21
  br i1 %t442, label %bb147, label %bb148
bb147:
  %t443 = load ptr, ptr %l1, !tbaa !29
  %t445 = getelementptr { i64, [4 x i64] }, ptr %t443, i32 0, i32 1
  %t446 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t445, i32 0, i32 2
  %t447 = load ptr, ptr %t446
  store ptr %t447, ptr %l18, !tbaa !29
  br label %bb149
bb148:
  br label %bb179
bb149:
  %t449 = load ptr, ptr %l18, !tbaa !29
  store ptr %t449, ptr %l233, !tbaa !29
  store i1 false, ptr %l234, !tbaa !21
  %t450 = load ptr, ptr %l233, !tbaa !29
  %t451 = icmp ne ptr %t450, null
  br i1 %t451, label %bb150, label %bb151
bb150:
  %t453 = load ptr, ptr %l233, !tbaa !29
  %t454 = load i64, ptr %t453
  %t456 = icmp eq i64 %t454, 14
  store i1 %t456, ptr %l234, !tbaa !21
  br label %bb151
bb151:
  %t457 = load i1, ptr %l234, !tbaa !21
  br i1 %t457, label %bb152, label %bb153
bb152:
  br label %bb154
bb153:
  br label %bb155
bb154:
  store i1 true, ptr %l232, !tbaa !21
  br label %bb160
bb155:
  br i1 true, label %bb156, label %bb157
bb156:
  br label %bb158
bb157:
  br label %bb159
bb158:
  store i1 false, ptr %l232, !tbaa !21
  br label %bb160
bb159:
  call void @__olang_check_failed(ptr @olang_loc_3b10a40791a2a251_bad5d69bdb4172c5)
  unreachable
bb160:
  %t458 = load i1, ptr %l232, !tbaa !21
  store i1 %t458, ptr %l19, !tbaa !21
  %t459 = load i1, ptr %l3, !tbaa !21
  br i1 %t459, label %bb161, label %bb162
bb161:
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t462 = load ptr, ptr %l18, !tbaa !29
  %t465 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowCopy(ptr %v0, ptr %v1, ptr %t461, ptr %t462)
  store i1 %t465, ptr %l241
  br label %bb163
bb162:
  store i1 false, ptr %l238, !tbaa !21
  br label %bb164
bb163:
  %t466 = load i1, ptr %l241, !tbaa !21
  store i1 %t466, ptr %l238, !tbaa !21
  br label %bb164
bb164:
  %t467 = load i1, ptr %l238, !tbaa !21
  br i1 %t467, label %bb165, label %bb166
bb165:
  store %olang.scope zeroinitializer, ptr %s26
  %t468 = load ptr, ptr %l0, !tbaa !29
  store ptr %t468, ptr %l242, !tbaa !29
  %t469 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t469, ptr %l243
  %t470 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNarrowedWrite(ptr %s26)
  store %"compiler/msgs:Msg" %t470, ptr %l244
  br label %bb167
bb166:
  %t471 = load i1, ptr %l3, !tbaa !21
  br i1 %t471, label %bb169, label %bb170
bb167:
  %t473 = load ptr, ptr %l242, !tbaa !29
  %t474 = load %"compiler/source:Span", ptr %l243
  %t475 = load %"compiler/msgs:Msg", ptr %l244
  %t476 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s26, ptr %t473, %"compiler/source:Span" %t474, %"compiler/msgs:Msg" %t475)
  store i64 %t476, ptr %l245
  br label %bb168
bb168:
  call void @__olang_scope_close(ptr %s26)
  br label %bb178
bb169:
  store %olang.scope zeroinitializer, ptr %s28
  %t477 = load ptr, ptr %l0, !tbaa !29
  store ptr %t477, ptr %l247, !tbaa !29
  %t478 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t478, ptr %l248
  %t479 = load i1, ptr %l19, !tbaa !21
  br i1 %t479, label %bb171, label %bb172
bb170:
  br label %bb177
bb171:
  %t481 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssignIntoTried(ptr %s28)
  store %"compiler/msgs:Msg" %t481, ptr %l251
  br label %bb173
bb172:
  %t482 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eWriteIntoCallValue(ptr %s28)
  store %"compiler/msgs:Msg" %t482, ptr %l252
  br label %bb174
bb173:
  %t483 = load %"compiler/msgs:Msg", ptr %l251
  store %"compiler/msgs:Msg" %t483, ptr %l250
  br label %bb175
bb174:
  %t484 = load %"compiler/msgs:Msg", ptr %l252
  store %"compiler/msgs:Msg" %t484, ptr %l250
  br label %bb175
bb175:
  %t485 = load ptr, ptr %l247, !tbaa !29
  %t486 = load %"compiler/source:Span", ptr %l248
  %t487 = load %"compiler/msgs:Msg", ptr %l250
  %t488 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s28, ptr %t485, %"compiler/source:Span" %t486, %"compiler/msgs:Msg" %t487)
  store i64 %t488, ptr %l253
  br label %bb176
bb176:
  call void @__olang_scope_close(ptr %s28)
  br label %bb177
bb177:
  br label %bb178
bb178:
  br label %bb180
bb179:
  br label %bb180
bb180:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutParam(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l7 = alloca %"compiler/source:Span"
  %l10 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l14 = alloca { i64, ptr }
  %l16 = alloca %"compiler/msgs:Msg"
  %l17 = alloca i64
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = load i32, ptr %l2, !tbaa !23
  %t7 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutBefore(ptr %v0, ptr %v1, ptr %t1, ptr %a1, i32 %t3)
  store %"compiler/source:Span" %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t8, ptr %l3
  %t9 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t10 = load i32, ptr %t9, !tbaa !23
  %t12 = icmp sge i32 %t10, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l10, !tbaa !29
  %t15 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t15, ptr %l11
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t16, i32 %t17)
  store { i64, ptr } %t20, ptr %l14
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t21 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  %t29 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMutOnValueParam(ptr %s1, ptr %s1, { i64, ptr } %t27)
  store %"compiler/msgs:Msg" %t29, ptr %l16
  br label %bb5
bb5:
  %t30 = load ptr, ptr %l10, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l11
  %t32 = load %"compiler/msgs:Msg", ptr %l16
  %t33 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t30, %"compiler/source:Span" %t31, %"compiler/msgs:Msg" %t32)
  store i64 %t33, ptr %l17
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoIndex(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l8 = alloca %"compiler/source:Span"
  %l12 = alloca i1
  %l17 = alloca i64
  %l19 = alloca ptr
  %l23 = alloca %"compiler/source:Span"
  %l29 = alloca { i64, ptr }
  %l31 = alloca %"compiler/msgs:Msg"
  %l32 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca %"compiler/source:Span"
  %l37 = alloca { i64, ptr }
  %l39 = alloca %"compiler/msgs:Msg"
  %l40 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebracketIn(ptr %v0, ptr %t1, %"compiler/source:Span" %a1)
  store %"compiler/source:Span" %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t6, ptr %l5
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  %t9 = load %"compiler/source:Span", ptr %l5
  %t13 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %s0, ptr %s0, ptr %t7, i32 %t8, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d13, i32 0, i32 1) }, %"compiler/source:Span" %t9, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d14, i32 0, i32 1) }, i64 1, i1 true)
  store i1 %t13, ptr %l12
  br label %bb2
bb2:
  %t14 = load i1, ptr %l12, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l2, !tbaa !23
  %t19 = add i64 %a4, 1
  %t23 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t15, i32 %t16, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d15, i32 0, i32 1) }, i64 %t19)
  store i64 %t23, ptr %l17
  br label %bb6
bb6:
  %t24 = load i64, ptr %l17, !tbaa !24
  %t25 = icmp sge i64 %t24, 0
  br i1 %t25, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l19, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 41
  %t31 = getelementptr %"compiler/source:Span", ptr %t30, i32 0, i32 0
  %t32 = load i32, ptr %t31, !tbaa !23
  %t34 = icmp sge i32 %t32, 0
  br i1 %t34, label %bb9, label %bb10
bb8:
  br label %bb15
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 41
  %t39 = load %"compiler/source:Span", ptr %t38
  store %"compiler/source:Span" %t39, ptr %l23
  br label %bb11
bb10:
  %t41 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t41, ptr %l23
  br label %bb11
bb11:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t47 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t43, i32 %a3)
  store { i64, ptr } %t47, ptr %l29
  br label %bb12
bb12:
  %t48 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 0
  %t50 = extractvalue { i64, ptr } %t48, 1
  %t51 = mul i64 %t49, 1
  %t52 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t51)
  call void @llvm.memcpy.p0.p0.i64(ptr %t52, ptr %t50, i64 %t51, i1 false)
  %t53 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  %t56 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAtUndeclared(ptr %s2, ptr %s2, { i64, ptr } %t54)
  store %"compiler/msgs:Msg" %t56, ptr %l31
  br label %bb13
bb13:
  %t57 = load ptr, ptr %l19, !tbaa !29
  %t58 = load %"compiler/source:Span", ptr %l23
  %t59 = load %"compiler/msgs:Msg", ptr %l31
  %t60 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t57, %"compiler/source:Span" %t58, %"compiler/msgs:Msg" %t59)
  store i64 %t60, ptr %l32
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb15:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l33, !tbaa !29
  %t62 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t62, ptr %l34
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load i32, ptr %l2, !tbaa !23
  %t67 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t63, i32 %t64)
  store { i64, ptr } %t67, ptr %l37
  br label %bb16
bb16:
  %t68 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  %t70 = extractvalue { i64, ptr } %t68, 1
  %t71 = mul i64 %t69, 1
  %t72 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t70, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  %t76 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotIndexable(ptr %s0, ptr %s0, { i64, ptr } %t74)
  store %"compiler/msgs:Msg" %t76, ptr %l39
  br label %bb17
bb17:
  %t77 = load ptr, ptr %l33, !tbaa !29
  %t78 = load %"compiler/source:Span", ptr %l34
  %t79 = load %"compiler/msgs:Msg", ptr %l39
  %t80 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t77, %"compiler/source:Span" %t78, %"compiler/msgs:Msg" %t79)
  store i64 %t80, ptr %l40
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca ptr
  %l16 = alloca i1
  %l25 = alloca ptr
  %l27 = alloca %"compiler/source:Span"
  %l29 = alloca %"compiler/source:Span"
  %l31 = alloca { i64, ptr }
  %l33 = alloca %"compiler/source:Span"
  %l35 = alloca %"compiler/source:Span"
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopOf(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store %"compiler/source:Span" %t20, ptr %l14
  br label %bb6
bb6:
  %t21 = load %"compiler/source:Span", ptr %l14
  store %"compiler/source:Span" %t21, ptr %rv
  br label %ret
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t23 = load ptr, ptr %l15, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l15, !tbaa !29
  %t27 = load i64, ptr %t26
  %t29 = icmp eq i64 %t27, 5
  store i1 %t29, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l16, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [5 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t33, i32 0, i32 1
  %t35 = load i32, ptr %t34
  store i32 %t35, ptr %l3
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [5 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l4, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr { i64, [5 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t45, i32 0, i32 3
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l5, !tbaa !29
  br label %bb12
bb11:
  br label %bb17
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l25, !tbaa !29
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t52 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t50)
  store %"compiler/source:Span" %t52, ptr %l27
  br label %bb13
bb13:
  %t53 = load ptr, ptr %l5, !tbaa !29
  %t55 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t53)
  store %"compiler/source:Span" %t55, ptr %l29
  br label %bb14
bb14:
  %t56 = load i32, ptr %l3
  %t58 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s2, i32 %t56)
  store { i64, ptr } %t58, ptr %l31
  br label %bb15
bb15:
  %t59 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 0
  %t61 = load ptr, ptr %l25, !tbaa !29
  %t62 = load %"compiler/source:Span", ptr %l27
  %t63 = load %"compiler/source:Span", ptr %l29
  %t65 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t61, %"compiler/source:Span" %t62, %"compiler/source:Span" %t63, i64 %t60)
  store %"compiler/source:Span" %t65, ptr %l33
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  %t66 = load %"compiler/source:Span", ptr %l33
  store %"compiler/source:Span" %t66, ptr %rv
  br label %ret
bb17:
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t69 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t67)
  store %"compiler/source:Span" %t69, ptr %l35
  br label %bb18
bb18:
  %t70 = load %"compiler/source:Span", ptr %l35
  store %"compiler/source:Span" %t70, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamLen(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l9 = alloca { i64, ptr }
  %l11 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i64
  %l18 = alloca i32
  %l20 = alloca ptr
  %l22 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca i32
  %l30 = alloca i32
  %l33 = alloca i1
  %l38 = alloca i32
  %l47 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t10 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLenKey(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t4, ptr %a1, { i64, ptr } %a2)
  store { i64, ptr } %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t14 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t12, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d16, i32 0, i32 1) })
  store i1 %t14, ptr %l11
  br label %bb2
bb2:
  %t15 = load i1, ptr %l11, !tbaa !21
  br i1 %t15, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb6
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 13
  %t20 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_H2d42092ce658fb6cce0104fa754a4e33(ptr %v0, ptr %t18)
  store i64 %t20, ptr %l15
  br label %bb5
bb5:
  %t21 = load i64, ptr %l15, !tbaa !24
  %t22 = icmp eq i64 %t21, 0
  store i1 %t22, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t26)
  store ptr %t28, ptr %l20
  br label %bb10
bb10:
  %t29 = load ptr, ptr %l20, !tbaa !29
  %t31 = getelementptr %"compiler/check:frame", ptr %t29, i32 0, i32 4
  %t32 = getelementptr %"compiler/generic:Context", ptr %t31, i32 0, i32 2
  store ptr %t32, ptr %l22, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = getelementptr %"compiler/load:Loader", ptr %t39, i32 0, i32 3
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t43 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t46 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t42, { i64, ptr } %t43)
  store i32 %t46, ptr %l28
  br label %bb11
bb11:
  %t47 = load ptr, ptr %l22, !tbaa !29
  %t48 = load i32, ptr %l28, !tbaa !23
  %t49 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v0, ptr %t47, i32 %t48)
  %t50 = extractvalue { i32, i32 } %t49, 1
  %t51 = extractvalue { i32, i32 } %t49, 0
  store i32 %t51, ptr %l30
  %t52 = icmp ne i32 %t51, 0
  br i1 %t52, label %bb13, label %ok.53
ok.53:
  store i32 %t50, ptr %l29
  br label %bb12
bb12:
  %t54 = load i32, ptr %l29, !tbaa !23
  store i32 %t54, ptr %l18, !tbaa !23
  br label %bb15
bb13:
  br label %bb14
bb14:
  call void @__olang_ert_req_clear()
  store i32 -1, ptr %l18, !tbaa !23
  br label %bb15
bb15:
  %t55 = load i32, ptr %l18, !tbaa !23
  store i32 %t55, ptr %l4, !tbaa !23
  %t56 = load i32, ptr %l4, !tbaa !23
  %t58 = icmp slt i32 %t56, 0
  br i1 %t58, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb19
bb17:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Checker", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = getelementptr %"compiler/generic:Program", ptr %t63, i32 0, i32 2
  %t66 = load i32, ptr %l4, !tbaa !23
  %t69 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t65, i32 %t66)
  store i32 %t69, ptr %l38
  br label %bb18
bb18:
  %t70 = load i32, ptr %l38
  %t72 = trunc i64 26 to i32
  %t73 = icmp eq i32 %t70, %t72
  %t75 = xor i1 %t73, true
  store i1 %t75, ptr %l33, !tbaa !21
  br label %bb19
bb19:
  %t77 = load i1, ptr %l33, !tbaa !21
  br i1 %t77, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/generic:Program", ptr %t82, i32 0, i32 2
  %t85 = load i32, ptr %l4, !tbaa !23
  %t88 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t84, i32 %t85)
  store i64 %t88, ptr %l47
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  %t89 = load i64, ptr %l47, !tbaa !24
  store i64 %t89, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epattern(ptr %v0, ptr %v1, ptr %a0, ptr %a1, ptr %a2, i32 %a3, ptr %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca i32
  %l13 = alloca i64
  %l14 = alloca { i64, [3 x i64] }
  %l15 = alloca i32
  %l16 = alloca %"compiler/typed:Local"
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca %"compiler/source:Span"
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l27 = alloca i32
  %l28 = alloca i64
  %l29 = alloca %"compiler/source:Span"
  %l30 = alloca ptr
  %l31 = alloca i32
  %l32 = alloca i32
  %lp33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca ptr
  %l39 = alloca ptr
  %l41 = alloca { i64, ptr }
  %l42 = alloca ptr
  %lp44 = alloca ptr
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %lp51 = alloca ptr
  %l52 = alloca %"compiler/source:Span"
  %l53 = alloca ptr
  %l54 = alloca ptr
  %l55 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca i1
  %l84 = alloca ptr
  %l85 = alloca ptr
  %l86 = alloca i1
  %l95 = alloca i64
  %l98 = alloca i1
  %l100 = alloca ptr
  %l104 = alloca %"compiler/typed:Local"
  %l109 = alloca i1
  %l111 = alloca ptr
  %l115 = alloca %"compiler/typed:Local"
  %l125 = alloca i64
  %l128 = alloca { i64, [3 x i64] }
  %l133 = alloca ptr
  %l140 = alloca ptr
  %l142 = alloca ptr
  %l146 = alloca %"compiler/typed:Local"
  %l149 = alloca i1
  %l151 = alloca i1
  %l156 = alloca ptr
  %l160 = alloca %"compiler/typed:Local"
  %l164 = alloca i1
  %l165 = alloca i1
  %l168 = alloca i1
  %l169 = alloca i1
  %l172 = alloca ptr
  %l177 = alloca i32
  %l182 = alloca i32
  %l183 = alloca i1
  %l185 = alloca ptr
  %l189 = alloca %"compiler/typed:Local"
  %l192 = alloca ptr
  %l197 = alloca i32
  %l202 = alloca i64
  %l207 = alloca i64
  %l208 = alloca i64
  %l209 = alloca i32
  %l211 = alloca ptr
  %l216 = alloca ptr
  %l217 = alloca %"compiler/source:Span"
  %l220 = alloca { i64, ptr }
  %l221 = alloca { i64, ptr }
  %l224 = alloca { i64, ptr }
  %l226 = alloca %"compiler/msgs:Msg"
  %l227 = alloca i64
  %l228 = alloca ptr
  %l229 = alloca i64
  %l233 = alloca ptr
  %l234 = alloca ptr
  %l237 = alloca i32
  %l241 = alloca ptr
  %l242 = alloca %"compiler/typed:Bind"
  %l247 = alloca ptr
  %l248 = alloca ptr
  %l249 = alloca i1
  %l258 = alloca i32
  %l262 = alloca i64
  %l269 = alloca ptr
  %l272 = alloca i32
  %l274 = alloca ptr
  %l275 = alloca i1
  %l284 = alloca i32
  %l287 = alloca i1
  %l288 = alloca i1
  %l291 = alloca i1
  %l296 = alloca i32
  %l301 = alloca i32
  %l303 = alloca ptr
  %l304 = alloca %"compiler/source:Span"
  %l307 = alloca { i64, ptr }
  %l309 = alloca %"compiler/source:Span"
  %l313 = alloca %"compiler/msgs:Msg"
  %l314 = alloca i64
  %l318 = alloca ptr
  %l321 = alloca i1
  %l324 = alloca i1
  %l325 = alloca i1
  %l328 = alloca i1
  %l329 = alloca i1
  %l334 = alloca i32
  %l339 = alloca i32
  %l342 = alloca ptr
  %l344 = alloca %"compiler/source:Span"
  %l347 = alloca { i64, ptr }
  %l348 = alloca { i64, ptr }
  %l349 = alloca ptr
  %l351 = alloca %"compiler/source:Span"
  %l352 = alloca { i64, ptr }
  %l353 = alloca { i64, ptr }
  %l355 = alloca %"compiler/msgs:Msg"
  %l356 = alloca i64
  %l360 = alloca ptr
  %l366 = alloca ptr
  %l367 = alloca ptr
  %l368 = alloca i1
  %l379 = alloca i32
  %l383 = alloca i64
  %l386 = alloca ptr
  %l387 = alloca i1
  %l398 = alloca i32
  %l401 = alloca i1
  %l402 = alloca i1
  %l405 = alloca i1
  %l410 = alloca i32
  %l415 = alloca i32
  %l417 = alloca ptr
  %l418 = alloca %"compiler/source:Span"
  %l421 = alloca { i64, ptr }
  %l423 = alloca %"compiler/source:Span"
  %l427 = alloca %"compiler/msgs:Msg"
  %l428 = alloca i64
  %l432 = alloca ptr
  %l433 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l441 = alloca { i64, ptr }
  %l444 = alloca ptr
  %l445 = alloca i1
  %l450 = alloca ptr
  %l451 = alloca i1
  %l458 = alloca ptr
  %l460 = alloca %"compiler/source:Span"
  %l464 = alloca ptr
  %l467 = alloca ptr
  %l468 = alloca %"compiler/source:Span"
  %l469 = alloca ptr
  %l470 = alloca %"compiler/source:Span"
  %l471 = alloca ptr
  %l473 = alloca { i64, ptr }
  %l477 = alloca ptr
  %l482 = alloca ptr
  %l487 = alloca i32
  %l490 = alloca ptr
  %l495 = alloca i32
  %l496 = alloca { i64, ptr }
  %l502 = alloca ptr
  %l503 = alloca %"compiler/source:Span"
  %l505 = alloca i64
  %l509 = alloca { i64, ptr }
  %l512 = alloca %"compiler/msgs:Msg"
  %l513 = alloca i64
  %l517 = alloca ptr
  %l521 = alloca i1
  %l522 = alloca %"compiler/source:Span"
  %l523 = alloca i32
  %l527 = alloca ptr
  %l532 = alloca ptr
  %l537 = alloca i32
  %l538 = alloca { i64, ptr }
  %l539 = alloca { i64, ptr }
  %l542 = alloca %"compiler/source:Span"
  %l543 = alloca i32
  %l547 = alloca %"compiler/typed:Payload"
  %l555 = alloca i64
  %l558 = alloca i64
  %l576 = alloca { i64, ptr }
  %l579 = alloca %"compiler/source:Span"
  %l580 = alloca { i64, ptr }
  %l586 = alloca ptr
  %l587 = alloca %"compiler/source:Span"
  %l588 = alloca ptr
  %l590 = alloca { i64, ptr }
  %l594 = alloca { i64, ptr }
  %l599 = alloca ptr
  %l600 = alloca ptr
  %l604 = alloca ptr
  %l605 = alloca i1
  %l618 = alloca ptr
  %s9 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %rv = alloca ptr
  %t149 = alloca { i64, [2 x i64] }, align 8
  %t900 = alloca { i64, [5 x i64] }, align 8
  %t1018 = alloca { i64, [4 x i64] }, align 8
  %t1068 = alloca { i64, [4 x i64] }, align 8
  %t1149 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l54, !tbaa !29
  store i1 false, ptr %l55, !tbaa !21
  %t2 = load ptr, ptr %l54, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l54, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l55, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l55, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span" }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l6
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load %"compiler/source:Span", ptr %l6
  %t18 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t22 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t16, %"compiler/source:Span" %t17, i32 %t18, i64 1)
  store ptr %t22, ptr %l63
  br label %bb6
bb6:
  %t23 = load ptr, ptr %l63, !tbaa !29
  store ptr %t23, ptr %rv
  br label %ret
bb7:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t25 = load ptr, ptr %l64, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t28 = load ptr, ptr %l64, !tbaa !29
  %t29 = load i64, ptr %t28
  %t31 = icmp eq i64 %t29, 5
  store i1 %t31, ptr %l65, !tbaa !21
  br label %bb9
bb9:
  %t32 = load i1, ptr %l65, !tbaa !21
  br i1 %t32, label %bb10, label %bb11
bb10:
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t35 = getelementptr { i64, [4 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" }, ptr %t35, i32 0, i32 0
  %t37 = load %"compiler/source:Span", ptr %t36
  store %"compiler/source:Span" %t37, ptr %l7
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr { i64, [4 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" }, ptr %t41, i32 0, i32 1
  %t43 = load ptr, ptr %t42
  store ptr %t43, ptr %l8, !tbaa !29
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr { i64, [4 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" }, ptr %t47, i32 0, i32 2
  %t49 = load i32, ptr %t48
  store i32 %t49, ptr %l9, !tbaa !23
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr { i64, [4 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" }, ptr %t53, i32 0, i32 3
  %t55 = load %"compiler/source:Span", ptr %t54
  store %"compiler/source:Span" %t55, ptr %l10
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load %"compiler/source:Span", ptr %l7
  %t59 = load ptr, ptr %l8, !tbaa !29
  %t60 = load i32, ptr %l9, !tbaa !23
  %t61 = load %"compiler/source:Span", ptr %l10
  %t62 = load ptr, ptr %l2, !tbaa !29
  %t63 = load i32, ptr %l3, !tbaa !23
  %t64 = load ptr, ptr %l4, !tbaa !29
  %t73 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeCase(ptr %v0, ptr %v1, ptr %t57, %"compiler/source:Span" %t58, ptr %t59, i32 %t60, %"compiler/source:Span" %t61, ptr %t62, i32 %t63, ptr %t64)
  store ptr %t73, ptr %l84
  br label %bb13
bb13:
  %t74 = load ptr, ptr %l84, !tbaa !29
  store ptr %t74, ptr %rv
  br label %ret
bb14:
  %t75 = load ptr, ptr %l1, !tbaa !29
  store ptr %t75, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t76 = load ptr, ptr %l85, !tbaa !29
  %t77 = icmp ne ptr %t76, null
  br i1 %t77, label %bb15, label %bb16
bb15:
  %t79 = load ptr, ptr %l85, !tbaa !29
  %t80 = load i64, ptr %t79
  %t82 = icmp eq i64 %t80, 3
  store i1 %t82, ptr %l86, !tbaa !21
  br label %bb16
bb16:
  %t83 = load i1, ptr %l86, !tbaa !21
  br i1 %t83, label %bb17, label %bb18
bb17:
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t86 = getelementptr { i64, [4 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", i32 }, ptr %t86, i32 0, i32 0
  %t88 = load %"compiler/source:Span", ptr %t87
  store %"compiler/source:Span" %t88, ptr %l11
  %t90 = load ptr, ptr %l1, !tbaa !29
  %t92 = getelementptr { i64, [4 x i64] }, ptr %t90, i32 0, i32 1
  %t93 = getelementptr { %"compiler/source:Span", i32 }, ptr %t92, i32 0, i32 1
  %t94 = load i32, ptr %t93
  store i32 %t94, ptr %l12, !tbaa !23
  br label %bb19
bb18:
  br label %bb85
bb19:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load i32, ptr %l12, !tbaa !23
  %t100 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t96, i32 %t97)
  store i64 %t100, ptr %l95
  br label %bb20
bb20:
  %t101 = load i64, ptr %l95, !tbaa !24
  store i64 %t101, ptr %l13, !tbaa !24
  %t102 = load i64, ptr %l13, !tbaa !24
  %t104 = icmp slt i64 %t102, 0
  br i1 %t104, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l98, !tbaa !21
  br label %bb25
bb22:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t106)
  store ptr %t108, ptr %l100
  br label %bb23
bb23:
  %t109 = load ptr, ptr %l100, !tbaa !29
  %t111 = getelementptr %"compiler/typed:Body", ptr %t109, i32 0, i32 7
  %t112 = load i64, ptr %l13, !tbaa !24
  %t115 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t111, i64 %t112)
  store %"compiler/typed:Local" %t115, ptr %l104
  br label %bb24
bb24:
  %t116 = getelementptr %"compiler/typed:Local", ptr %l104, i32 0, i32 3
  %t117 = load i32, ptr %t116, !tbaa !23
  %t119 = sext i32 %t117 to i64
  %t120 = load i64, ptr %l5, !tbaa !24
  %t123 = icmp ne i64 %t119, %t120
  store i1 %t123, ptr %l98, !tbaa !21
  br label %bb25
bb25:
  %t125 = load i1, ptr %l98, !tbaa !21
  br i1 %t125, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb30
bb27:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t126)
  store ptr %t128, ptr %l111
  br label %bb28
bb28:
  %t129 = load ptr, ptr %l111, !tbaa !29
  %t131 = getelementptr %"compiler/typed:Body", ptr %t129, i32 0, i32 7
  %t132 = load i64, ptr %l13, !tbaa !24
  %t135 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t131, i64 %t132)
  store %"compiler/typed:Local" %t135, ptr %l115
  br label %bb29
bb29:
  %t136 = getelementptr %"compiler/typed:Local", ptr %l115, i32 0, i32 4
  %t137 = load i32, ptr %t136
  %t139 = trunc i64 4 to i32
  %t140 = icmp eq i32 %t137, %t139
  %t142 = xor i1 %t140, true
  store i1 %t142, ptr %l109, !tbaa !21
  br label %bb30
bb30:
  %t144 = load i1, ptr %l109, !tbaa !21
  br i1 %t144, label %bb31, label %bb32
bb31:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load i32, ptr %l12, !tbaa !23
  %t147 = load %"compiler/source:Span", ptr %l11
  %t148 = load i32, ptr %l3, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t149
  %t150 = getelementptr { i64, [2 x i64] }, ptr %t149, i32 0, i32 0
  store i64 5, ptr %t150
  %t151 = load { i64, [2 x i64] }, ptr %t149
  %t158 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t145, i32 %t146, %"compiler/source:Span" %t147, i32 %t148, i32 4, { i64, [2 x i64] } %t151)
  store i64 %t158, ptr %l125
  br label %bb33
bb32:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/check:Checker", ptr %t159, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !29
  %t164 = getelementptr %"compiler/generic:Program", ptr %t162, i32 0, i32 2
  store ptr %t164, ptr %l140, !tbaa !29
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t165)
  store ptr %t167, ptr %l142
  br label %bb40
bb33:
  %t168 = load i64, ptr %l125, !tbaa !24
  store i64 %t168, ptr %l13, !tbaa !24
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load ptr, ptr %l2, !tbaa !29
  %t173 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceAt(ptr %v0, ptr %v0, ptr %t169, ptr %t170)
  store { i64, [3 x i64] } %t173, ptr %l128
  br label %bb34
bb34:
  %t174 = load { i64, [3 x i64] }, ptr %l128
  store { i64, [3 x i64] } %t174, ptr %l14
  %t175 = load { i64, [3 x i64] }, ptr %l14
  %t177 = extractvalue { i64, [3 x i64] } %t175, 0
  %t178 = icmp eq i64 %t177, 0
  %t180 = xor i1 %t178, true
  br i1 %t180, label %bb35, label %bb36
bb35:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t182)
  store ptr %t184, ptr %l133
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t185 = load ptr, ptr %l133, !tbaa !29
  %t187 = getelementptr %"compiler/check:frame", ptr %t185, i32 0, i32 3
  %t188 = load i64, ptr %l13, !tbaa !24
  %t189 = load { i64, [3 x i64] }, ptr %l14
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_Hc07a7e56a24d8f1225398db99ea19a4b(ptr %v0, ptr %t187, i64 %t188, { i64, [3 x i64] } %t189)
  br label %bb38
bb38:
  br label %bb39
bb39:
  br label %bb78
bb40:
  %t193 = load ptr, ptr %l142, !tbaa !29
  %t195 = getelementptr %"compiler/typed:Body", ptr %t193, i32 0, i32 7
  %t196 = load i64, ptr %l13, !tbaa !24
  %t199 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t195, i64 %t196)
  store %"compiler/typed:Local" %t199, ptr %l146
  br label %bb41
bb41:
  %t200 = getelementptr %"compiler/typed:Local", ptr %l146, i32 0, i32 2
  %t201 = load i32, ptr %t200, !tbaa !23
  %t202 = load i32, ptr %l3, !tbaa !23
  %t203 = load ptr, ptr %l140, !tbaa !29
  %t206 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t203, i32 %t201, i32 %t202)
  store i1 %t206, ptr %l149
  br label %bb42
bb42:
  %t207 = load i1, ptr %l149, !tbaa !21
  %t208 = xor i1 %t207, true
  br i1 %t208, label %bb43, label %bb44
bb43:
  %t210 = load i32, ptr %l3, !tbaa !23
  %t211 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t214 = icmp ne i32 %t210, %t211
  store i1 %t214, ptr %l151, !tbaa !21
  br label %bb45
bb44:
  store i1 false, ptr %l151, !tbaa !21
  br label %bb45
bb45:
  %t216 = load i1, ptr %l151, !tbaa !21
  br i1 %t216, label %bb46, label %bb47
bb46:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t219 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t217)
  store ptr %t219, ptr %l156
  br label %bb48
bb47:
  br label %bb77
bb48:
  %t220 = load ptr, ptr %l156, !tbaa !29
  %t222 = getelementptr %"compiler/typed:Body", ptr %t220, i32 0, i32 7
  %t223 = load i64, ptr %l13, !tbaa !24
  %t226 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t222, i64 %t223)
  store %"compiler/typed:Local" %t226, ptr %l160
  br label %bb49
bb49:
  %t227 = getelementptr %"compiler/typed:Local", ptr %l160, i32 0, i32 2
  %t228 = load i32, ptr %t227, !tbaa !23
  store i32 %t228, ptr %l15, !tbaa !23
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load i32, ptr %l15, !tbaa !23
  %t234 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t230, i32 %t231)
  store i1 %t234, ptr %l164
  br label %bb50
bb50:
  %t235 = load i1, ptr %l164, !tbaa !21
  br i1 %t235, label %bb51, label %bb52
bb51:
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t237 = load i32, ptr %l3, !tbaa !23
  %t240 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t236, i32 %t237)
  store i1 %t240, ptr %l168
  br label %bb53
bb52:
  store i1 false, ptr %l165, !tbaa !21
  br label %bb54
bb53:
  %t241 = load i1, ptr %l168, !tbaa !21
  store i1 %t241, ptr %l165, !tbaa !21
  br label %bb54
bb54:
  %t242 = load i1, ptr %l165, !tbaa !21
  br i1 %t242, label %bb55, label %bb56
bb55:
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t245 = getelementptr %"compiler/check:Checker", ptr %t243, i32 0, i32 1
  %t246 = load ptr, ptr %t245, !tbaa !29
  %t248 = getelementptr %"compiler/generic:Program", ptr %t246, i32 0, i32 2
  store ptr %t248, ptr %l172, !tbaa !29
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t251 = getelementptr %"compiler/check:Checker", ptr %t249, i32 0, i32 1
  %t252 = load ptr, ptr %t251, !tbaa !29
  %t254 = getelementptr %"compiler/generic:Program", ptr %t252, i32 0, i32 2
  %t255 = load i32, ptr %l15, !tbaa !23
  %t258 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t254, i32 %t255)
  store i32 %t258, ptr %l177
  br label %bb57
bb56:
  store i1 false, ptr %l169, !tbaa !21
  br label %bb60
bb57:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t261 = getelementptr %"compiler/check:Checker", ptr %t259, i32 0, i32 1
  %t262 = load ptr, ptr %t261, !tbaa !29
  %t264 = getelementptr %"compiler/generic:Program", ptr %t262, i32 0, i32 2
  %t265 = load i32, ptr %l3, !tbaa !23
  %t268 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t264, i32 %t265)
  store i32 %t268, ptr %l182
  br label %bb58
bb58:
  %t269 = load ptr, ptr %l172, !tbaa !29
  %t270 = load i32, ptr %l177, !tbaa !23
  %t271 = load i32, ptr %l182, !tbaa !23
  %t272 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t269, i32 %t270, i32 %t271)
  store i1 %t272, ptr %l183
  br label %bb59
bb59:
  %t273 = load i1, ptr %l183, !tbaa !21
  store i1 %t273, ptr %l169, !tbaa !21
  br label %bb60
bb60:
  %t274 = load i1, ptr %l169, !tbaa !21
  br i1 %t274, label %bb61, label %bb62
bb61:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t277 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t275)
  store ptr %t277, ptr %l185
  br label %bb63
bb62:
  store %olang.scope zeroinitializer, ptr %s9
  %t278 = load ptr, ptr %l0, !tbaa !29
  store ptr %t278, ptr %l216, !tbaa !29
  %t279 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t279, ptr %l217
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t281 = load i32, ptr %l12, !tbaa !23
  %t284 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s9, ptr %t280, i32 %t281)
  store { i64, ptr } %t284, ptr %l220
  br label %bb72
bb63:
  %t285 = load ptr, ptr %l185, !tbaa !29
  %t287 = getelementptr %"compiler/typed:Body", ptr %t285, i32 0, i32 7
  %t288 = load i64, ptr %l13, !tbaa !24
  %t291 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t287, i64 %t288)
  store %"compiler/typed:Local" %t291, ptr %l189
  br label %bb64
bb64:
  %t292 = load %"compiler/typed:Local", ptr %l189
  store %"compiler/typed:Local" %t292, ptr %l16
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = getelementptr %"compiler/check:Checker", ptr %t293, i32 0, i32 1
  %t296 = load ptr, ptr %t295, !tbaa !29
  %t298 = getelementptr %"compiler/generic:Program", ptr %t296, i32 0, i32 2
  store ptr %t298, ptr %l192, !tbaa !29
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t301 = getelementptr %"compiler/check:Checker", ptr %t299, i32 0, i32 1
  %t302 = load ptr, ptr %t301, !tbaa !29
  %t304 = getelementptr %"compiler/generic:Program", ptr %t302, i32 0, i32 2
  %t305 = load i32, ptr %l15, !tbaa !23
  %t308 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t304, i32 %t305)
  store i32 %t308, ptr %l197
  br label %bb65
bb65:
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t311 = getelementptr %"compiler/check:Checker", ptr %t309, i32 0, i32 1
  %t312 = load ptr, ptr %t311, !tbaa !29
  %t314 = getelementptr %"compiler/generic:Program", ptr %t312, i32 0, i32 2
  %t315 = load i32, ptr %l15, !tbaa !23
  %t318 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t314, i32 %t315)
  store i64 %t318, ptr %l202
  br label %bb66
bb66:
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t321 = getelementptr %"compiler/check:Checker", ptr %t319, i32 0, i32 1
  %t322 = load ptr, ptr %t321, !tbaa !29
  %t324 = getelementptr %"compiler/generic:Program", ptr %t322, i32 0, i32 2
  %t325 = load i32, ptr %l3, !tbaa !23
  %t328 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t324, i32 %t325)
  store i64 %t328, ptr %l207
  br label %bb67
bb67:
  %t329 = load i64, ptr %l202, !tbaa !24
  %t330 = load i64, ptr %l207, !tbaa !24
  %t331 = call i64 @compiler_2fcheck_2emeetPerm(i64 %t329, i64 %t330)
  store i64 %t331, ptr %l208
  br label %bb68
bb68:
  %t332 = load ptr, ptr %l192, !tbaa !29
  %t333 = load i32, ptr %l197, !tbaa !23
  %t334 = load i64, ptr %l208, !tbaa !24
  %t335 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t332, i32 %t333, i64 %t334)
  store i32 %t335, ptr %l209
  br label %bb69
bb69:
  %t336 = load i32, ptr %l209, !tbaa !23
  %t337 = getelementptr %"compiler/typed:Local", ptr %l16, i32 0, i32 2
  store i32 %t336, ptr %t337, !tbaa !23
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t340 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t338)
  store ptr %t340, ptr %l211
  br label %bb70
bb70:
  %t341 = load ptr, ptr %l211, !tbaa !29
  %t343 = getelementptr %"compiler/typed:Body", ptr %t341, i32 0, i32 7
  %t344 = load i64, ptr %l13, !tbaa !24
  %t345 = load %"compiler/typed:Local", ptr %l16
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eSetAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t343, i64 %t344, %"compiler/typed:Local" %t345)
  br label %bb71
bb71:
  br label %bb76
bb72:
  %t349 = load { i64, ptr }, ptr %l220, !tbaa !27
  %t350 = extractvalue { i64, ptr } %t349, 0
  %t351 = extractvalue { i64, ptr } %t349, 1
  %t352 = mul i64 %t350, 1
  %t353 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t352)
  call void @llvm.memcpy.p0.p0.i64(ptr %t353, ptr %t351, i64 %t352, i1 false)
  %t354 = insertvalue { i64, ptr } undef, i64 %t350, 0
  %t355 = insertvalue { i64, ptr } %t354, ptr %t353, 1
  store { i64, ptr } %t355, ptr %l221, !tbaa !27
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t357 = load i32, ptr %l15, !tbaa !23
  %t360 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t356, i32 %t357)
  store { i64, ptr } %t360, ptr %l224
  br label %bb73
bb73:
  %t361 = load { i64, ptr }, ptr %l224, !tbaa !27
  %t362 = extractvalue { i64, ptr } %t361, 0
  %t363 = extractvalue { i64, ptr } %t361, 1
  %t364 = mul i64 %t362, 1
  %t365 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t364)
  call void @llvm.memcpy.p0.p0.i64(ptr %t365, ptr %t363, i64 %t364, i1 false)
  %t366 = insertvalue { i64, ptr } undef, i64 %t362, 0
  %t367 = insertvalue { i64, ptr } %t366, ptr %t365, 1
  %t368 = load { i64, ptr }, ptr %l221, !tbaa !27
  %t370 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAltBindingType(ptr %s9, ptr %s9, ptr %s9, { i64, ptr } %t368, { i64, ptr } %t367)
  store %"compiler/msgs:Msg" %t370, ptr %l226
  br label %bb74
bb74:
  %t371 = load ptr, ptr %l216, !tbaa !29
  %t372 = load %"compiler/source:Span", ptr %l217
  %t373 = load %"compiler/msgs:Msg", ptr %l226
  %t374 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s9, ptr %t371, %"compiler/source:Span" %t372, %"compiler/msgs:Msg" %t373)
  store i64 %t374, ptr %l227
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s9)
  br label %bb76
bb76:
  br label %bb77
bb77:
  br label %bb78
bb78:
  %t375 = load ptr, ptr %l0, !tbaa !29
  store ptr %t375, ptr %l228, !tbaa !29
  %t376 = load i64, ptr %l13, !tbaa !24
  store i64 %t376, ptr %l229, !tbaa !24
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t378 = load %"compiler/source:Span", ptr %l11
  %t379 = load ptr, ptr %l2, !tbaa !29
  %t383 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t377, %"compiler/source:Span" %t378, ptr %t379)
  store ptr %t383, ptr %l233
  br label %bb79
bb79:
  %t384 = load ptr, ptr %l228, !tbaa !29
  %t385 = load i64, ptr %l229, !tbaa !24
  %t386 = load ptr, ptr %l233, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v0, ptr %t384, i64 %t385, ptr %t386)
  br label %bb80
bb80:
  %t387 = load ptr, ptr %l4, !tbaa !29
  store ptr %t387, ptr %l234, !tbaa !29
  %t388 = load i64, ptr %l13, !tbaa !24
  %t390 = trunc i64 %t388 to i32
  store i32 %t390, ptr %l237, !tbaa !23
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t393 = load %"compiler/source:Span", ptr %l11
  %t394 = load ptr, ptr %l2, !tbaa !29
  %t398 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t392, %"compiler/source:Span" %t393, ptr %t394)
  store ptr %t398, ptr %l241
  br label %bb81
bb81:
  %t399 = load i32, ptr %l237, !tbaa !23
  %t400 = load ptr, ptr %l241, !tbaa !29
  %t401 = call %"compiler/typed:Bind" @compiler_2ftyped_3aBind_2ector(ptr %v0, ptr %v0, i32 %t399, ptr %t400)
  store %"compiler/typed:Bind" %t401, ptr %l242
  br label %bb82
bb82:
  %t402 = load %"compiler/typed:Bind", ptr %l242
  %t403 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store %"compiler/typed:Bind" %t402, ptr %t403
  %t404 = load ptr, ptr %l234, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBind_26_3e_2ePus_H9902a4d50743896fa3c9f4890ae04f69(ptr %v0, ptr %v0, ptr %t404, ptr %t403)
  br label %bb83
bb83:
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t407 = load %"compiler/source:Span", ptr %l11
  %t408 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t412 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t406, %"compiler/source:Span" %t407, i32 %t408, i64 1)
  store ptr %t412, ptr %l247
  br label %bb84
bb84:
  %t413 = load ptr, ptr %l247, !tbaa !29
  store ptr %t413, ptr %rv
  br label %ret
bb85:
  %t414 = load ptr, ptr %l1, !tbaa !29
  store ptr %t414, ptr %l248, !tbaa !29
  store i1 false, ptr %l249, !tbaa !21
  %t415 = load ptr, ptr %l248, !tbaa !29
  %t416 = icmp ne ptr %t415, null
  br i1 %t416, label %bb86, label %bb87
bb86:
  %t418 = load ptr, ptr %l248, !tbaa !29
  %t419 = load i64, ptr %t418
  %t421 = icmp eq i64 %t419, 1
  store i1 %t421, ptr %l249, !tbaa !21
  br label %bb87
bb87:
  %t422 = load i1, ptr %l249, !tbaa !21
  br i1 %t422, label %bb88, label %bb89
bb88:
  %t423 = load ptr, ptr %l1, !tbaa !29
  %t425 = getelementptr { i64, [4 x i64] }, ptr %t423, i32 0, i32 1
  %t426 = getelementptr { %"compiler/source:Span", ptr }, ptr %t425, i32 0, i32 0
  %t427 = load %"compiler/source:Span", ptr %t426
  store %"compiler/source:Span" %t427, ptr %l17
  %t429 = load ptr, ptr %l1, !tbaa !29
  %t431 = getelementptr { i64, [4 x i64] }, ptr %t429, i32 0, i32 1
  %t432 = getelementptr { %"compiler/source:Span", ptr }, ptr %t431, i32 0, i32 1
  %t433 = load ptr, ptr %t432
  store ptr %t433, ptr %l18, !tbaa !29
  br label %bb90
bb89:
  br label %bb151
bb90:
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t436 = load i32, ptr %l3, !tbaa !23
  %t439 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t435, i32 %t436)
  store i32 %t439, ptr %l258
  br label %bb91
bb91:
  %t440 = load i32, ptr %l258, !tbaa !23
  store i32 %t440, ptr %l19, !tbaa !23
  %t441 = load ptr, ptr %l0, !tbaa !29
  %t442 = load ptr, ptr %l18, !tbaa !29
  %t443 = load i32, ptr %l19, !tbaa !23
  %t447 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %t441, ptr %t442, i32 %t443)
  store i64 %t447, ptr %l262
  br label %bb92
bb92:
  %t448 = load i64, ptr %l262, !tbaa !24
  store i64 %t448, ptr %l20, !tbaa !24
  %t449 = load i64, ptr %l20, !tbaa !24
  %t451 = icmp sge i64 %t449, 0
  br i1 %t451, label %bb93, label %bb94
bb93:
  %t453 = load ptr, ptr %l0, !tbaa !29
  %t454 = load %"compiler/source:Span", ptr %l17
  %t455 = load ptr, ptr %l2, !tbaa !29
  %t456 = load i64, ptr %l20, !tbaa !24
  %t461 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCase(ptr %v0, ptr %t453, %"compiler/source:Span" %t454, ptr %t455, i64 %t456)
  store ptr %t461, ptr %l269
  br label %bb95
bb94:
  br label %bb96
bb95:
  %t462 = load ptr, ptr %l269, !tbaa !29
  store ptr %t462, ptr %rv
  br label %ret
bb96:
  %t463 = load ptr, ptr %l0, !tbaa !29
  %t464 = load ptr, ptr %l18, !tbaa !29
  %t467 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t463, ptr %t464)
  store i32 %t467, ptr %l272
  br label %bb97
bb97:
  %t468 = load i32, ptr %l272, !tbaa !23
  %t469 = icmp slt i32 %t468, 0
  br i1 %t469, label %bb98, label %bb99
bb98:
  %t471 = load ptr, ptr %l18, !tbaa !29
  store ptr %t471, ptr %l274, !tbaa !29
  store i1 false, ptr %l275, !tbaa !21
  %t472 = load ptr, ptr %l274, !tbaa !29
  %t473 = icmp ne ptr %t472, null
  br i1 %t473, label %bb100, label %bb101
bb99:
  br label %bb149
bb100:
  %t475 = load ptr, ptr %l274, !tbaa !29
  %t476 = load i64, ptr %t475
  %t478 = icmp eq i64 %t476, 15
  store i1 %t478, ptr %l275, !tbaa !21
  br label %bb101
bb101:
  %t479 = load i1, ptr %l275, !tbaa !21
  br i1 %t479, label %bb102, label %bb103
bb102:
  %t480 = load ptr, ptr %l18, !tbaa !29
  %t482 = getelementptr { i64, [5 x i64] }, ptr %t480, i32 0, i32 1
  %t483 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t482, i32 0, i32 1
  %t484 = load ptr, ptr %t483
  store ptr %t484, ptr %l21, !tbaa !29
  %t486 = load ptr, ptr %l18, !tbaa !29
  %t488 = getelementptr { i64, [5 x i64] }, ptr %t486, i32 0, i32 1
  %t489 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t488, i32 0, i32 2
  %t490 = load i32, ptr %t489
  store i32 %t490, ptr %l22, !tbaa !23
  br label %bb104
bb103:
  br label %bb147
bb104:
  %t492 = load ptr, ptr %l0, !tbaa !29
  %t493 = load ptr, ptr %l21, !tbaa !29
  %t496 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t492, ptr %t493)
  store i32 %t496, ptr %l284
  br label %bb105
bb105:
  %t497 = load i32, ptr %l284, !tbaa !23
  store i32 %t497, ptr %l23, !tbaa !23
  %t498 = load ptr, ptr %l0, !tbaa !29
  %t499 = load i32, ptr %l19, !tbaa !23
  %t502 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t498, i32 %t499)
  store i1 %t502, ptr %l287
  br label %bb106
bb106:
  %t503 = load i1, ptr %l287, !tbaa !21
  br i1 %t503, label %bb107, label %bb108
bb107:
  %t504 = load i32, ptr %l23, !tbaa !23
  %t506 = icmp sge i32 %t504, 0
  store i1 %t506, ptr %l288, !tbaa !21
  br label %bb109
bb108:
  store i1 false, ptr %l288, !tbaa !21
  br label %bb109
bb109:
  %t508 = load i1, ptr %l288, !tbaa !21
  br i1 %t508, label %bb110, label %bb111
bb110:
  %t509 = load ptr, ptr %l0, !tbaa !29
  %t511 = getelementptr %"compiler/check:Checker", ptr %t509, i32 0, i32 1
  %t512 = load ptr, ptr %t511, !tbaa !29
  %t514 = getelementptr %"compiler/generic:Program", ptr %t512, i32 0, i32 2
  %t515 = load i32, ptr %l23, !tbaa !23
  %t518 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t514, i32 %t515)
  store i32 %t518, ptr %l296
  br label %bb112
bb111:
  store i1 false, ptr %l291, !tbaa !21
  br label %bb114
bb112:
  %t519 = load ptr, ptr %l0, !tbaa !29
  %t521 = getelementptr %"compiler/check:Checker", ptr %t519, i32 0, i32 1
  %t522 = load ptr, ptr %t521, !tbaa !29
  %t524 = getelementptr %"compiler/generic:Program", ptr %t522, i32 0, i32 2
  %t525 = load i32, ptr %l19, !tbaa !23
  %t528 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t524, i32 %t525)
  store i32 %t528, ptr %l301
  br label %bb113
bb113:
  %t529 = load i32, ptr %l296, !tbaa !23
  %t530 = load i32, ptr %l301, !tbaa !23
  %t531 = icmp eq i32 %t529, %t530
  store i1 %t531, ptr %l291, !tbaa !21
  br label %bb114
bb114:
  %t533 = load i1, ptr %l291, !tbaa !21
  br i1 %t533, label %bb115, label %bb116
bb115:
  store %olang.scope zeroinitializer, ptr %s14
  %t534 = load ptr, ptr %l0, !tbaa !29
  store ptr %t534, ptr %l303, !tbaa !29
  %t535 = load %"compiler/source:Span", ptr %l17
  store %"compiler/source:Span" %t535, ptr %l304
  %t536 = load ptr, ptr %l0, !tbaa !29
  %t537 = load i32, ptr %l22, !tbaa !23
  %t540 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t536, i32 %t537)
  store { i64, ptr } %t540, ptr %l307
  br label %bb117
bb116:
  br label %bb122
bb117:
  %t541 = load { i64, ptr }, ptr %l307, !tbaa !27
  %t542 = extractvalue { i64, ptr } %t541, 0
  %t543 = load %"compiler/source:Span", ptr %l304
  %t545 = call %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %t543, i64 %t542)
  store %"compiler/source:Span" %t545, ptr %l309
  br label %bb118
bb118:
  %t546 = load ptr, ptr %l0, !tbaa !29
  %t547 = load i32, ptr %l19, !tbaa !23
  %t548 = load i32, ptr %l22, !tbaa !23
  %t552 = call %"compiler/msgs:Msg" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoCase(ptr %v0, ptr %s14, ptr %t546, i32 %t547, i32 %t548)
  store %"compiler/msgs:Msg" %t552, ptr %l313
  br label %bb119
bb119:
  %t553 = load ptr, ptr %l303, !tbaa !29
  %t554 = load %"compiler/source:Span", ptr %l309
  %t555 = load %"compiler/msgs:Msg", ptr %l313
  %t556 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s14, ptr %t553, %"compiler/source:Span" %t554, %"compiler/msgs:Msg" %t555)
  store i64 %t556, ptr %l314
  br label %bb120
bb120:
  %t557 = load ptr, ptr %l0, !tbaa !29
  %t558 = load %"compiler/source:Span", ptr %l17
  %t559 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t563 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t557, %"compiler/source:Span" %t558, i32 %t559, i64 0)
  store ptr %t563, ptr %l318
  br label %bb121
bb121:
  call void @__olang_scope_close(ptr %s14)
  %t564 = load ptr, ptr %l318, !tbaa !29
  store ptr %t564, ptr %rv
  br label %ret
bb122:
  %t565 = load i32, ptr %l23, !tbaa !23
  %t567 = icmp sge i32 %t565, 0
  br i1 %t567, label %bb123, label %bb124
bb123:
  %t569 = load ptr, ptr %l0, !tbaa !29
  %t570 = load i32, ptr %l23, !tbaa !23
  %t573 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t569, i32 %t570)
  store i1 %t573, ptr %l324
  br label %bb125
bb124:
  store i1 false, ptr %l321, !tbaa !21
  br label %bb126
bb125:
  %t574 = load i1, ptr %l324, !tbaa !21
  store i1 %t574, ptr %l321, !tbaa !21
  br label %bb126
bb126:
  %t575 = load i1, ptr %l321, !tbaa !21
  br i1 %t575, label %bb127, label %bb128
bb127:
  %t576 = load ptr, ptr %l0, !tbaa !29
  %t577 = load i32, ptr %l19, !tbaa !23
  %t580 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t576, i32 %t577)
  store i1 %t580, ptr %l328
  br label %bb129
bb128:
  store i1 false, ptr %l325, !tbaa !21
  br label %bb135
bb129:
  %t581 = load i1, ptr %l328, !tbaa !21
  br i1 %t581, label %bb130, label %bb131
bb130:
  %t582 = load ptr, ptr %l0, !tbaa !29
  %t584 = getelementptr %"compiler/check:Checker", ptr %t582, i32 0, i32 1
  %t585 = load ptr, ptr %t584, !tbaa !29
  %t587 = getelementptr %"compiler/generic:Program", ptr %t585, i32 0, i32 2
  %t588 = load i32, ptr %l23, !tbaa !23
  %t591 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t587, i32 %t588)
  store i32 %t591, ptr %l334
  br label %bb132
bb131:
  store i1 false, ptr %l329, !tbaa !21
  br label %bb134
bb132:
  %t592 = load ptr, ptr %l0, !tbaa !29
  %t594 = getelementptr %"compiler/check:Checker", ptr %t592, i32 0, i32 1
  %t595 = load ptr, ptr %t594, !tbaa !29
  %t597 = getelementptr %"compiler/generic:Program", ptr %t595, i32 0, i32 2
  %t598 = load i32, ptr %l19, !tbaa !23
  %t601 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t597, i32 %t598)
  store i32 %t601, ptr %l339
  br label %bb133
bb133:
  %t602 = load i32, ptr %l334, !tbaa !23
  %t603 = load i32, ptr %l339, !tbaa !23
  %t604 = icmp eq i32 %t602, %t603
  store i1 %t604, ptr %l329, !tbaa !21
  br label %bb134
bb134:
  %t606 = load i1, ptr %l329, !tbaa !21
  %t607 = xor i1 %t606, true
  store i1 %t607, ptr %l325, !tbaa !21
  br label %bb135
bb135:
  %t609 = load i1, ptr %l325, !tbaa !21
  br i1 %t609, label %bb136, label %bb137
bb136:
  store %olang.scope zeroinitializer, ptr %s15
  %t610 = load ptr, ptr %l0, !tbaa !29
  store ptr %t610, ptr %l342, !tbaa !29
  %t611 = load ptr, ptr %l21, !tbaa !29
  %t613 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t611)
  store %"compiler/source:Span" %t613, ptr %l344
  br label %bb138
bb137:
  br label %bb146
bb138:
  %t614 = load ptr, ptr %l0, !tbaa !29
  %t615 = load i32, ptr %l19, !tbaa !23
  %t618 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s15, ptr %t614, i32 %t615)
  store { i64, ptr } %t618, ptr %l347
  br label %bb139
bb139:
  %t619 = load { i64, ptr }, ptr %l347, !tbaa !27
  %t620 = extractvalue { i64, ptr } %t619, 0
  %t621 = extractvalue { i64, ptr } %t619, 1
  %t622 = mul i64 %t620, 1
  %t623 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t622)
  call void @llvm.memcpy.p0.p0.i64(ptr %t623, ptr %t621, i64 %t622, i1 false)
  %t624 = insertvalue { i64, ptr } undef, i64 %t620, 0
  %t625 = insertvalue { i64, ptr } %t624, ptr %t623, 1
  store { i64, ptr } %t625, ptr %l348, !tbaa !27
  %t626 = load ptr, ptr %l0, !tbaa !29
  store ptr %t626, ptr %l349, !tbaa !29
  %t627 = load ptr, ptr %l21, !tbaa !29
  %t629 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t627)
  store %"compiler/source:Span" %t629, ptr %l351
  br label %bb140
bb140:
  %t630 = load ptr, ptr %l349, !tbaa !29
  %t631 = load %"compiler/source:Span", ptr %l351
  %t632 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t630, %"compiler/source:Span" %t631)
  store { i64, ptr } %t632, ptr %l352
  br label %bb141
bb141:
  %t633 = load { i64, ptr }, ptr %l352, !tbaa !27
  %t634 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %s15, { i64, ptr } %t633)
  store { i64, ptr } %t634, ptr %l353
  br label %bb142
bb142:
  %t635 = load { i64, ptr }, ptr %l353, !tbaa !27
  %t636 = extractvalue { i64, ptr } %t635, 0
  %t637 = extractvalue { i64, ptr } %t635, 1
  %t638 = mul i64 %t636, 1
  %t639 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t638)
  call void @llvm.memcpy.p0.p0.i64(ptr %t639, ptr %t637, i64 %t638, i1 false)
  %t640 = insertvalue { i64, ptr } undef, i64 %t636, 0
  %t641 = insertvalue { i64, ptr } %t640, ptr %t639, 1
  %t642 = load { i64, ptr }, ptr %l348, !tbaa !27
  %t644 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2ePatternType(ptr %s15, ptr %s15, ptr %s15, { i64, ptr } %t642, { i64, ptr } %t641)
  store %"compiler/msgs:Msg" %t644, ptr %l355
  br label %bb143
bb143:
  %t645 = load ptr, ptr %l342, !tbaa !29
  %t646 = load %"compiler/source:Span", ptr %l344
  %t647 = load %"compiler/msgs:Msg", ptr %l355
  %t648 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s15, ptr %t645, %"compiler/source:Span" %t646, %"compiler/msgs:Msg" %t647)
  store i64 %t648, ptr %l356
  br label %bb144
bb144:
  %t649 = load ptr, ptr %l0, !tbaa !29
  %t650 = load %"compiler/source:Span", ptr %l17
  %t651 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t655 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t649, %"compiler/source:Span" %t650, i32 %t651, i64 0)
  store ptr %t655, ptr %l360
  br label %bb145
bb145:
  call void @__olang_scope_close(ptr %s15)
  %t656 = load ptr, ptr %l360, !tbaa !29
  store ptr %t656, ptr %rv
  br label %ret
bb146:
  br label %bb148
bb147:
  br label %bb148
bb148:
  br label %bb149
bb149:
  %t657 = load ptr, ptr %l0, !tbaa !29
  %t658 = load %"compiler/source:Span", ptr %l17
  %t659 = load ptr, ptr %l2, !tbaa !29
  %t660 = load ptr, ptr %l18, !tbaa !29
  %t661 = load i32, ptr %l3, !tbaa !23
  %t667 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTest(ptr %v0, ptr %v1, ptr %t657, %"compiler/source:Span" %t658, ptr %t659, ptr %t660, i32 %t661)
  store ptr %t667, ptr %l366
  br label %bb150
bb150:
  %t668 = load ptr, ptr %l366, !tbaa !29
  store ptr %t668, ptr %rv
  br label %ret
bb151:
  %t669 = load ptr, ptr %l1, !tbaa !29
  store ptr %t669, ptr %l367, !tbaa !29
  store i1 false, ptr %l368, !tbaa !21
  %t670 = load ptr, ptr %l367, !tbaa !29
  %t671 = icmp ne ptr %t670, null
  br i1 %t671, label %bb152, label %bb153
bb152:
  %t673 = load ptr, ptr %l367, !tbaa !29
  %t674 = load i64, ptr %t673
  %t676 = icmp eq i64 %t674, 2
  store i1 %t676, ptr %l368, !tbaa !21
  br label %bb153
bb153:
  %t677 = load i1, ptr %l368, !tbaa !21
  br i1 %t677, label %bb154, label %bb155
bb154:
  %t678 = load ptr, ptr %l1, !tbaa !29
  %t680 = getelementptr { i64, [4 x i64] }, ptr %t678, i32 0, i32 1
  %t681 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t680, i32 0, i32 0
  %t682 = load %"compiler/source:Span", ptr %t681
  store %"compiler/source:Span" %t682, ptr %l24
  %t684 = load ptr, ptr %l1, !tbaa !29
  %t686 = getelementptr { i64, [4 x i64] }, ptr %t684, i32 0, i32 1
  %t687 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t686, i32 0, i32 1
  %t688 = load ptr, ptr %t687
  store ptr %t688, ptr %l25, !tbaa !29
  %t690 = load ptr, ptr %l1, !tbaa !29
  %t692 = getelementptr { i64, [4 x i64] }, ptr %t690, i32 0, i32 1
  %t693 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t692, i32 0, i32 2
  %t694 = load { i64, ptr }, ptr %t693
  store { i64, ptr } %t694, ptr %l26, !tbaa !27
  br label %bb156
bb155:
  br label %bb247
bb156:
  %t696 = load ptr, ptr %l0, !tbaa !29
  %t697 = load i32, ptr %l3, !tbaa !23
  %t700 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t696, i32 %t697)
  store i32 %t700, ptr %l379
  br label %bb157
bb157:
  %t701 = load i32, ptr %l379, !tbaa !23
  store i32 %t701, ptr %l27, !tbaa !23
  %t702 = load ptr, ptr %l0, !tbaa !29
  %t703 = load ptr, ptr %l25, !tbaa !29
  %t704 = load i32, ptr %l27, !tbaa !23
  %t708 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %t702, ptr %t703, i32 %t704)
  store i64 %t708, ptr %l383
  br label %bb158
bb158:
  %t709 = load i64, ptr %l383, !tbaa !24
  store i64 %t709, ptr %l28, !tbaa !24
  %t710 = load i64, ptr %l28, !tbaa !24
  %t712 = icmp slt i64 %t710, 0
  br i1 %t712, label %bb159, label %bb160
bb159:
  %t714 = load ptr, ptr %l25, !tbaa !29
  store ptr %t714, ptr %l386, !tbaa !29
  store i1 false, ptr %l387, !tbaa !21
  %t715 = load ptr, ptr %l386, !tbaa !29
  %t716 = icmp ne ptr %t715, null
  br i1 %t716, label %bb161, label %bb162
bb160:
  br label %bb210
bb161:
  %t718 = load ptr, ptr %l386, !tbaa !29
  %t719 = load i64, ptr %t718
  %t721 = icmp eq i64 %t719, 15
  store i1 %t721, ptr %l387, !tbaa !21
  br label %bb162
bb162:
  %t722 = load i1, ptr %l387, !tbaa !21
  br i1 %t722, label %bb163, label %bb164
bb163:
  %t723 = load ptr, ptr %l25, !tbaa !29
  %t725 = getelementptr { i64, [5 x i64] }, ptr %t723, i32 0, i32 1
  %t726 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t725, i32 0, i32 0
  %t727 = load %"compiler/source:Span", ptr %t726
  store %"compiler/source:Span" %t727, ptr %l29
  %t729 = load ptr, ptr %l25, !tbaa !29
  %t731 = getelementptr { i64, [5 x i64] }, ptr %t729, i32 0, i32 1
  %t732 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t731, i32 0, i32 1
  %t733 = load ptr, ptr %t732
  store ptr %t733, ptr %l30, !tbaa !29
  %t735 = load ptr, ptr %l25, !tbaa !29
  %t737 = getelementptr { i64, [5 x i64] }, ptr %t735, i32 0, i32 1
  %t738 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t737, i32 0, i32 2
  %t739 = load i32, ptr %t738
  store i32 %t739, ptr %l31, !tbaa !23
  br label %bb165
bb164:
  br label %bb184
bb165:
  %t741 = load ptr, ptr %l0, !tbaa !29
  %t742 = load ptr, ptr %l30, !tbaa !29
  %t745 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t741, ptr %t742)
  store i32 %t745, ptr %l398
  br label %bb166
bb166:
  %t746 = load i32, ptr %l398, !tbaa !23
  store i32 %t746, ptr %l32, !tbaa !23
  %t747 = load ptr, ptr %l0, !tbaa !29
  %t748 = load i32, ptr %l27, !tbaa !23
  %t751 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t747, i32 %t748)
  store i1 %t751, ptr %l401
  br label %bb167
bb167:
  %t752 = load i1, ptr %l401, !tbaa !21
  br i1 %t752, label %bb168, label %bb169
bb168:
  %t753 = load i32, ptr %l32, !tbaa !23
  %t755 = icmp sge i32 %t753, 0
  store i1 %t755, ptr %l402, !tbaa !21
  br label %bb170
bb169:
  store i1 false, ptr %l402, !tbaa !21
  br label %bb170
bb170:
  %t757 = load i1, ptr %l402, !tbaa !21
  br i1 %t757, label %bb171, label %bb172
bb171:
  %t758 = load ptr, ptr %l0, !tbaa !29
  %t760 = getelementptr %"compiler/check:Checker", ptr %t758, i32 0, i32 1
  %t761 = load ptr, ptr %t760, !tbaa !29
  %t763 = getelementptr %"compiler/generic:Program", ptr %t761, i32 0, i32 2
  %t764 = load i32, ptr %l32, !tbaa !23
  %t767 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t763, i32 %t764)
  store i32 %t767, ptr %l410
  br label %bb173
bb172:
  store i1 false, ptr %l405, !tbaa !21
  br label %bb175
bb173:
  %t768 = load ptr, ptr %l0, !tbaa !29
  %t770 = getelementptr %"compiler/check:Checker", ptr %t768, i32 0, i32 1
  %t771 = load ptr, ptr %t770, !tbaa !29
  %t773 = getelementptr %"compiler/generic:Program", ptr %t771, i32 0, i32 2
  %t774 = load i32, ptr %l27, !tbaa !23
  %t777 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t773, i32 %t774)
  store i32 %t777, ptr %l415
  br label %bb174
bb174:
  %t778 = load i32, ptr %l410, !tbaa !23
  %t779 = load i32, ptr %l415, !tbaa !23
  %t780 = icmp eq i32 %t778, %t779
  store i1 %t780, ptr %l405, !tbaa !21
  br label %bb175
bb175:
  %t782 = load i1, ptr %l405, !tbaa !21
  br i1 %t782, label %bb176, label %bb177
bb176:
  store %olang.scope zeroinitializer, ptr %s20
  %t783 = load ptr, ptr %l0, !tbaa !29
  store ptr %t783, ptr %l417, !tbaa !29
  %t784 = load %"compiler/source:Span", ptr %l29
  store %"compiler/source:Span" %t784, ptr %l418
  %t785 = load ptr, ptr %l0, !tbaa !29
  %t786 = load i32, ptr %l31, !tbaa !23
  %t789 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t785, i32 %t786)
  store { i64, ptr } %t789, ptr %l421
  br label %bb178
bb177:
  br label %bb183
bb178:
  %t790 = load { i64, ptr }, ptr %l421, !tbaa !27
  %t791 = extractvalue { i64, ptr } %t790, 0
  %t792 = load %"compiler/source:Span", ptr %l418
  %t794 = call %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %t792, i64 %t791)
  store %"compiler/source:Span" %t794, ptr %l423
  br label %bb179
bb179:
  %t795 = load ptr, ptr %l0, !tbaa !29
  %t796 = load i32, ptr %l27, !tbaa !23
  %t797 = load i32, ptr %l31, !tbaa !23
  %t801 = call %"compiler/msgs:Msg" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoCase(ptr %v0, ptr %s20, ptr %t795, i32 %t796, i32 %t797)
  store %"compiler/msgs:Msg" %t801, ptr %l427
  br label %bb180
bb180:
  %t802 = load ptr, ptr %l417, !tbaa !29
  %t803 = load %"compiler/source:Span", ptr %l423
  %t804 = load %"compiler/msgs:Msg", ptr %l427
  %t805 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s20, ptr %t802, %"compiler/source:Span" %t803, %"compiler/msgs:Msg" %t804)
  store i64 %t805, ptr %l428
  br label %bb181
bb181:
  %t806 = load ptr, ptr %l0, !tbaa !29
  %t807 = load %"compiler/source:Span", ptr %l24
  %t808 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t812 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t806, %"compiler/source:Span" %t807, i32 %t808, i64 0)
  store ptr %t812, ptr %l432
  br label %bb182
bb182:
  call void @__olang_scope_close(ptr %s20)
  %t813 = load ptr, ptr %l432, !tbaa !29
  store ptr %t813, ptr %rv
  br label %ret
bb183:
  br label %bb185
bb184:
  br label %bb185
bb185:
  %t814 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t814, ptr %l433
  br label %bb186
bb186:
  %t815 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store ptr %t815, ptr %lp33
  %t816 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l433
  %t817 = load ptr, ptr %lp33
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t816, ptr %t817
  %t818 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t818, ptr %l34, !tbaa !27
  store i64 0, ptr %l35, !tbaa !24
  %t820 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t822 = extractvalue { i64, ptr } %t820, 0
  store i64 %t822, ptr %l36, !tbaa !24
  br label %bb187
bb187:
  store %olang.scope zeroinitializer, ptr %s23
  %t824 = load i64, ptr %l35, !tbaa !24
  %t825 = load i64, ptr %l36, !tbaa !24
  %t828 = icmp slt i64 %t824, %t825
  %t830 = xor i1 %t828, true
  br i1 %t830, label %bb188, label %bb189
bb188:
  call void @__olang_scope_close(ptr %s23)
  br label %bb207
bb189:
  br label %bb190
bb190:
  %t832 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t832, ptr %l441, !tbaa !27
  %t833 = load i64, ptr %l35, !tbaa !24
  %t835 = getelementptr { i64, ptr }, ptr %l441, i32 0, i32 1
  %t836 = load ptr, ptr %t835, !tbaa !27
  %t837 = getelementptr ptr, ptr %t836, i64 %t833
  %t838 = load ptr, ptr %t837, !tbaa !39
  store ptr %t838, ptr %l37, !tbaa !29
  %t840 = load ptr, ptr %l37, !tbaa !29
  store ptr %t840, ptr %l444, !tbaa !29
  store i1 false, ptr %l445, !tbaa !21
  %t841 = load ptr, ptr %l444, !tbaa !29
  %t842 = icmp ne ptr %t841, null
  br i1 %t842, label %bb191, label %bb192
bb191:
  %t844 = load ptr, ptr %l444, !tbaa !29
  %t845 = load i64, ptr %t844
  %t847 = icmp eq i64 %t845, 4
  store i1 %t847, ptr %l445, !tbaa !21
  br label %bb192
bb192:
  %t848 = load i1, ptr %l445, !tbaa !21
  br i1 %t848, label %bb193, label %bb194
bb193:
  %t849 = load ptr, ptr %l37, !tbaa !29
  %t851 = getelementptr { i64, [4 x i64] }, ptr %t849, i32 0, i32 1
  %t852 = getelementptr { %"compiler/source:Span", ptr }, ptr %t851, i32 0, i32 1
  %t853 = load ptr, ptr %t852
  store ptr %t853, ptr %l38, !tbaa !29
  br label %bb199
bb194:
  %t855 = load ptr, ptr %l37, !tbaa !29
  store ptr %t855, ptr %l450, !tbaa !29
  store i1 false, ptr %l451, !tbaa !21
  %t856 = load ptr, ptr %l450, !tbaa !29
  %t857 = icmp ne ptr %t856, null
  br i1 %t857, label %bb195, label %bb196
bb195:
  %t859 = load ptr, ptr %l450, !tbaa !29
  %t860 = load i64, ptr %t859
  %t862 = icmp eq i64 %t860, 1
  store i1 %t862, ptr %l451, !tbaa !21
  br label %bb196
bb196:
  %t863 = load i1, ptr %l451, !tbaa !21
  br i1 %t863, label %bb197, label %bb198
bb197:
  %t864 = load ptr, ptr %l37, !tbaa !29
  %t866 = getelementptr { i64, [4 x i64] }, ptr %t864, i32 0, i32 1
  %t867 = getelementptr { %"compiler/source:Span", ptr }, ptr %t866, i32 0, i32 1
  %t868 = load ptr, ptr %t867
  store ptr %t868, ptr %l38, !tbaa !29
  br label %bb199
bb198:
  br label %bb201
bb199:
  %t870 = load ptr, ptr %lp33
  %t871 = load ptr, ptr %l38, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t870, ptr %t871)
  br label %bb200
bb200:
  br label %bb205
bb201:
  store %olang.scope zeroinitializer, ptr %s25
  %t874 = load ptr, ptr %l0, !tbaa !29
  store ptr %t874, ptr %l458, !tbaa !29
  %t875 = load ptr, ptr %l37, !tbaa !29
  %t877 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t875)
  store %"compiler/source:Span" %t877, ptr %l460
  br label %bb202
bb202:
  %t878 = load ptr, ptr %l458, !tbaa !29
  %t879 = load %"compiler/source:Span", ptr %l460
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s25, ptr %t878, %"compiler/source:Span" %t879, { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d17, i32 0, i32 1) })
  br label %bb203
bb203:
  %t880 = load ptr, ptr %l0, !tbaa !29
  %t881 = load %"compiler/source:Span", ptr %l24
  %t882 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t886 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t880, %"compiler/source:Span" %t881, i32 %t882, i64 0)
  store ptr %t886, ptr %l464
  br label %bb204
bb204:
  call void @__olang_scope_close(ptr %s25)
  call void @__olang_scope_close(ptr %s23)
  %t887 = load ptr, ptr %l464, !tbaa !29
  store ptr %t887, ptr %rv
  br label %ret
bb205:
  call void @__olang_scope_close(ptr %s23)
  br label %bb206
bb206:
  %t888 = load i64, ptr %l35, !tbaa !24
  %t890 = add i64 %t888, 1
  store i64 %t890, ptr %l35, !tbaa !24
  br label %bb187
bb207:
  %t892 = load ptr, ptr %l0, !tbaa !29
  store ptr %t892, ptr %l467, !tbaa !29
  %t893 = load %"compiler/source:Span", ptr %l24
  store %"compiler/source:Span" %t893, ptr %l468
  %t894 = load ptr, ptr %l2, !tbaa !29
  store ptr %t894, ptr %l469, !tbaa !29
  %t895 = load %"compiler/source:Span", ptr %l24
  store %"compiler/source:Span" %t895, ptr %l470
  %t896 = load ptr, ptr %l25, !tbaa !29
  store ptr %t896, ptr %l471, !tbaa !29
  %t897 = load ptr, ptr %lp33
  %t899 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2eToArray_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t897)
  store { i64, ptr } %t899, ptr %l473
  br label %bb208
bb208:
  store { i64, [5 x i64] } zeroinitializer, ptr %t900
  %t901 = getelementptr { i64, [5 x i64] }, ptr %t900, i32 0, i32 0
  store i64 12, ptr %t901
  %t902 = load %"compiler/source:Span", ptr %l470
  %t903 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t902, 0
  %t904 = load ptr, ptr %l471, !tbaa !29
  %t905 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t903, ptr %t904, 1
  %t906 = load { i64, ptr }, ptr %l473, !tbaa !27
  %t907 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t905, { i64, ptr } %t906, 2
  %t908 = getelementptr { i64, [5 x i64] }, ptr %t900, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t907, ptr %t908
  %t909 = load { i64, [5 x i64] }, ptr %t900
  %t911 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t909, ptr %t911
  %t912 = load i32, ptr %l3, !tbaa !23
  %t913 = load ptr, ptr %l467, !tbaa !29
  %t914 = load %"compiler/source:Span", ptr %l468
  %t915 = load ptr, ptr %l469, !tbaa !29
  %t918 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTest(ptr %v0, ptr %v0, ptr %t913, %"compiler/source:Span" %t914, ptr %t915, ptr %t911, i32 %t912)
  store ptr %t918, ptr %l477
  br label %bb209
bb209:
  %t919 = load ptr, ptr %l477, !tbaa !29
  store ptr %t919, ptr %rv
  br label %ret
bb210:
  %t920 = load ptr, ptr %l0, !tbaa !29
  %t921 = load %"compiler/source:Span", ptr %l24
  %t922 = load ptr, ptr %l2, !tbaa !29
  %t923 = load i64, ptr %l28, !tbaa !24
  %t928 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCase(ptr %v0, ptr %t920, %"compiler/source:Span" %t921, ptr %t922, i64 %t923)
  store ptr %t928, ptr %l482
  br label %bb211
bb211:
  %t929 = load ptr, ptr %l482, !tbaa !29
  store ptr %t929, ptr %l39, !tbaa !29
  %t930 = load ptr, ptr %l0, !tbaa !29
  %t932 = getelementptr %"compiler/check:Checker", ptr %t930, i32 0, i32 1
  %t933 = load ptr, ptr %t932, !tbaa !29
  %t934 = load i32, ptr %l27, !tbaa !23
  %t935 = load i64, ptr %l28, !tbaa !24
  %t939 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %t933, i32 %t934, i64 %t935)
  store i32 %t939, ptr %l487
  br label %bb212
bb212:
  %t940 = load i32, ptr %l487, !tbaa !23
  %t941 = load ptr, ptr %l0, !tbaa !29
  %t943 = getelementptr %"compiler/check:Checker", ptr %t941, i32 0, i32 1
  %t944 = load ptr, ptr %t943, !tbaa !29
  %t946 = getelementptr %"compiler/generic:Program", ptr %t944, i32 0, i32 2
  store ptr %t946, ptr %l490, !tbaa !29
  %t947 = load ptr, ptr %l0, !tbaa !29
  %t949 = getelementptr %"compiler/check:Checker", ptr %t947, i32 0, i32 1
  %t950 = load ptr, ptr %t949, !tbaa !29
  %t952 = getelementptr %"compiler/generic:Program", ptr %t950, i32 0, i32 2
  %t956 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t952, i32 %t940)
  store i32 %t956, ptr %l495
  br label %bb213
bb213:
  %t957 = load ptr, ptr %l490, !tbaa !29
  %t958 = load i32, ptr %l495, !tbaa !23
  %t959 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t957, i32 %t958)
  store { i64, ptr } %t959, ptr %l496
  br label %bb214
bb214:
  %t960 = load { i64, ptr }, ptr %l496, !tbaa !27
  store { i64, ptr } %t960, ptr %l41, !tbaa !27
  %t961 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t963 = extractvalue { i64, ptr } %t961, 0
  %t964 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t966 = extractvalue { i64, ptr } %t964, 0
  %t969 = icmp ne i64 %t963, %t966
  br i1 %t969, label %bb215, label %bb216
bb215:
  store %olang.scope zeroinitializer, ptr %s27
  %t971 = load ptr, ptr %l0, !tbaa !29
  store ptr %t971, ptr %l502, !tbaa !29
  %t972 = load %"compiler/source:Span", ptr %l24
  store %"compiler/source:Span" %t972, ptr %l503
  %t973 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t975 = extractvalue { i64, ptr } %t973, 0
  store i64 %t975, ptr %l505, !tbaa !24
  %t976 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t978 = extractvalue { i64, ptr } %t976, 0
  %t980 = icmp eq i64 %t978, 1
  br i1 %t980, label %bb217, label %bb218
bb216:
  br label %bb223
bb217:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l509, !tbaa !27
  br label %bb219
bb218:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l509, !tbaa !27
  br label %bb219
bb219:
  %t982 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t984 = extractvalue { i64, ptr } %t982, 0
  %t985 = load i64, ptr %l505, !tbaa !24
  %t986 = load { i64, ptr }, ptr %l509, !tbaa !27
  %t988 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %s27, ptr %s27, i64 %t985, { i64, ptr } %t986, i64 %t984)
  store %"compiler/msgs:Msg" %t988, ptr %l512
  br label %bb220
bb220:
  %t989 = load ptr, ptr %l502, !tbaa !29
  %t990 = load %"compiler/source:Span", ptr %l503
  %t991 = load %"compiler/msgs:Msg", ptr %l512
  %t992 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s27, ptr %t989, %"compiler/source:Span" %t990, %"compiler/msgs:Msg" %t991)
  store i64 %t992, ptr %l513
  br label %bb221
bb221:
  %t993 = load ptr, ptr %l0, !tbaa !29
  %t994 = load %"compiler/source:Span", ptr %l24
  %t995 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t999 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t993, %"compiler/source:Span" %t994, i32 %t995, i64 0)
  store ptr %t999, ptr %l517
  br label %bb222
bb222:
  call void @__olang_scope_close(ptr %s27)
  %t1000 = load ptr, ptr %l517, !tbaa !29
  store ptr %t1000, ptr %rv
  br label %ret
bb223:
  %t1001 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1001, ptr %l42, !tbaa !29
  %t1003 = load ptr, ptr %l0, !tbaa !29
  %t1004 = load i32, ptr %l3, !tbaa !23
  %t1007 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1003, i32 %t1004)
  store i1 %t1007, ptr %l521
  br label %bb224
bb224:
  %t1008 = load i1, ptr %l521, !tbaa !21
  br i1 %t1008, label %bb225, label %bb226
bb225:
  %t1009 = load %"compiler/source:Span", ptr %l24
  store %"compiler/source:Span" %t1009, ptr %l522
  %t1010 = load i32, ptr %l27, !tbaa !23
  store i32 %t1010, ptr %l523, !tbaa !23
  %t1011 = load ptr, ptr %l0, !tbaa !29
  %t1012 = load %"compiler/source:Span", ptr %l24
  %t1013 = load ptr, ptr %l2, !tbaa !29
  %t1017 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t1011, %"compiler/source:Span" %t1012, ptr %t1013)
  store ptr %t1017, ptr %l527
  br label %bb227
bb226:
  br label %bb228
bb227:
  store { i64, [4 x i64] } zeroinitializer, ptr %t1018
  %t1019 = getelementptr { i64, [4 x i64] }, ptr %t1018, i32 0, i32 0
  store i64 2, ptr %t1019
  %t1020 = load %"compiler/source:Span", ptr %l522
  %t1021 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1020, 0
  %t1022 = load i32, ptr %l523, !tbaa !23
  %t1023 = insertvalue { %"compiler/source:Span", i32, ptr } %t1021, i32 %t1022, 1
  %t1024 = load ptr, ptr %l527, !tbaa !29
  %t1025 = insertvalue { %"compiler/source:Span", i32, ptr } %t1023, ptr %t1024, 2
  %t1026 = getelementptr { i64, [4 x i64] }, ptr %t1018, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1025, ptr %t1026
  %t1027 = load { i64, [4 x i64] }, ptr %t1018
  %t1029 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t1027, ptr %t1029
  store ptr %t1029, ptr %l42, !tbaa !29
  br label %bb228
bb228:
  %t1031 = load ptr, ptr %l0, !tbaa !29
  %t1033 = getelementptr %"compiler/check:Checker", ptr %t1031, i32 0, i32 1
  %t1034 = load ptr, ptr %t1033, !tbaa !29
  %t1036 = getelementptr %"compiler/generic:Program", ptr %t1034, i32 0, i32 2
  store ptr %t1036, ptr %l532, !tbaa !29
  %t1037 = load ptr, ptr %l0, !tbaa !29
  %t1039 = getelementptr %"compiler/check:Checker", ptr %t1037, i32 0, i32 1
  %t1040 = load ptr, ptr %t1039, !tbaa !29
  %t1042 = getelementptr %"compiler/generic:Program", ptr %t1040, i32 0, i32 2
  %t1043 = load i32, ptr %l27, !tbaa !23
  %t1046 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t1042, i32 %t1043)
  store i32 %t1046, ptr %l537
  br label %bb229
bb229:
  %t1047 = load ptr, ptr %l532, !tbaa !29
  %t1048 = load i32, ptr %l537, !tbaa !23
  %t1049 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t1047, i32 %t1048)
  store { i64, ptr } %t1049, ptr %l538
  br label %bb230
bb230:
  %t1050 = load { i64, ptr }, ptr %l538, !tbaa !27
  store { i64, ptr } %t1050, ptr %l539, !tbaa !27
  %t1051 = load i64, ptr %l28, !tbaa !24
  %t1053 = getelementptr { i64, ptr }, ptr %l539, i32 0, i32 1
  %t1054 = load ptr, ptr %t1053, !tbaa !27
  %t1055 = getelementptr i32, ptr %t1054, i64 %t1051
  %t1056 = load i32, ptr %t1055, !tbaa !33
  %t1058 = load %"compiler/source:Span", ptr %l24
  store %"compiler/source:Span" %t1058, ptr %l542
  store i32 %t1056, ptr %l543, !tbaa !23
  %t1060 = load ptr, ptr %l42, !tbaa !29
  %t1061 = load i64, ptr %l28, !tbaa !24
  %t1065 = call %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v0, ptr %t1060, i64 %t1061, i32 0)
  store %"compiler/typed:Payload" %t1065, ptr %l547
  br label %bb231
bb231:
  %t1066 = load %"compiler/typed:Payload", ptr %l547
  %t1067 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Payload" %t1066, ptr %t1067
  store { i64, [4 x i64] } zeroinitializer, ptr %t1068
  %t1069 = getelementptr { i64, [4 x i64] }, ptr %t1068, i32 0, i32 0
  store i64 5, ptr %t1069
  %t1070 = load %"compiler/source:Span", ptr %l542
  %t1071 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1070, 0
  %t1072 = load i32, ptr %l543, !tbaa !23
  %t1073 = insertvalue { %"compiler/source:Span", i32, ptr } %t1071, i32 %t1072, 1
  %t1075 = insertvalue { %"compiler/source:Span", i32, ptr } %t1073, ptr %t1067, 2
  %t1076 = getelementptr { i64, [4 x i64] }, ptr %t1068, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1075, ptr %t1076
  %t1077 = load { i64, [4 x i64] }, ptr %t1068
  %t1078 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store ptr %t1078, ptr %lp44
  %t1080 = load ptr, ptr %lp44
  store { i64, [4 x i64] } %t1077, ptr %t1080
  store i64 0, ptr %l45, !tbaa !24
  %t1081 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t1083 = extractvalue { i64, ptr } %t1081, 0
  store i64 %t1083, ptr %l46, !tbaa !24
  store i64 1, ptr %l47, !tbaa !24
  %t1085 = load i64, ptr %l46, !tbaa !24
  %t1086 = load i64, ptr %l45, !tbaa !24
  %t1089 = icmp sgt i64 %t1085, %t1086
  br i1 %t1089, label %bb232, label %bb233
bb232:
  %t1091 = load i64, ptr %l47, !tbaa !24
  %t1093 = icmp sgt i64 %t1091, 0
  br i1 %t1093, label %bb234, label %bb235
bb233:
  store i64 0, ptr %l555, !tbaa !24
  br label %bb237
bb234:
  %t1095 = load i64, ptr %l46, !tbaa !24
  %t1096 = load i64, ptr %l45, !tbaa !24
  %t1099 = sub i64 %t1095, %t1096
  %t1100 = load i64, ptr %l47, !tbaa !24
  %t1103 = add i64 %t1099, %t1100
  %t1105 = sub i64 %t1103, 1
  %t1106 = load i64, ptr %l47, !tbaa !24
  %t1109 = sdiv i64 %t1105, %t1106
  store i64 %t1109, ptr %l558, !tbaa !24
  br label %bb236
bb235:
  store i64 0, ptr %l558, !tbaa !24
  br label %bb236
bb236:
  %t1111 = load i64, ptr %l558, !tbaa !24
  store i64 %t1111, ptr %l555, !tbaa !24
  br label %bb237
bb237:
  %t1112 = load i64, ptr %l555, !tbaa !24
  store i64 %t1112, ptr %l48, !tbaa !24
  store i64 0, ptr %l49, !tbaa !24
  br label %bb238
bb238:
  store %olang.scope zeroinitializer, ptr %s30
  %t1113 = load i64, ptr %l49, !tbaa !24
  %t1114 = load i64, ptr %l48, !tbaa !24
  %t1117 = icmp slt i64 %t1113, %t1114
  %t1119 = xor i1 %t1117, true
  br i1 %t1119, label %bb239, label %bb240
bb239:
  call void @__olang_scope_close(ptr %s30)
  br label %bb246
bb240:
  br label %bb241
bb241:
  %t1121 = load i64, ptr %l45, !tbaa !24
  %t1122 = load i64, ptr %l49, !tbaa !24
  %t1123 = load i64, ptr %l47, !tbaa !24
  %t1126 = mul i64 %t1122, %t1123
  %t1129 = add i64 %t1121, %t1126
  store i64 %t1129, ptr %l50, !tbaa !24
  %t1131 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t1131, ptr %l576, !tbaa !27
  %t1132 = load i64, ptr %l50, !tbaa !24
  %t1134 = getelementptr { i64, ptr }, ptr %l576, i32 0, i32 1
  %t1135 = load ptr, ptr %t1134, !tbaa !27
  %t1136 = getelementptr ptr, ptr %t1135, i64 %t1132
  %t1137 = load ptr, ptr %t1136, !tbaa !39
  %t1139 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t1137)
  store %"compiler/source:Span" %t1139, ptr %l579
  br label %bb242
bb242:
  %t1140 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t1140, ptr %l580, !tbaa !27
  %t1141 = load i64, ptr %l50, !tbaa !24
  %t1143 = getelementptr { i64, ptr }, ptr %l580, i32 0, i32 1
  %t1144 = load ptr, ptr %t1143, !tbaa !27
  %t1145 = getelementptr i32, ptr %t1144, i64 %t1141
  %t1146 = load i32, ptr %t1145, !tbaa !33
  %t1147 = load ptr, ptr %lp44
  %t1148 = load i64, ptr %l50, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t1149
  %t1150 = getelementptr { i64, [4 x i64] }, ptr %t1149, i32 0, i32 0
  store i64 3, ptr %t1150
  %t1151 = load %"compiler/source:Span", ptr %l579
  %t1152 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t1151, 0
  %t1154 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t1152, i32 %t1146, 1
  %t1156 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t1154, ptr %t1147, 2
  %t1158 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t1156, i64 %t1148, 3
  %t1159 = getelementptr { i64, [4 x i64] }, ptr %t1149, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t1158, ptr %t1159
  %t1160 = load { i64, [4 x i64] }, ptr %t1149
  %t1161 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store ptr %t1161, ptr %lp51
  %t1163 = load ptr, ptr %lp51
  store { i64, [4 x i64] } %t1160, ptr %t1163
  %t1164 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1164, ptr %l586, !tbaa !29
  %t1165 = load %"compiler/source:Span", ptr %l24
  store %"compiler/source:Span" %t1165, ptr %l587
  %t1166 = load ptr, ptr %l39, !tbaa !29
  store ptr %t1166, ptr %l588, !tbaa !29
  %t1167 = load ptr, ptr %l0, !tbaa !29
  %t1168 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t1168, ptr %l590, !tbaa !27
  %t1169 = load i64, ptr %l50, !tbaa !24
  %t1171 = getelementptr { i64, ptr }, ptr %l590, i32 0, i32 1
  %t1172 = load ptr, ptr %t1171, !tbaa !27
  %t1173 = getelementptr ptr, ptr %t1172, i64 %t1169
  %t1174 = load ptr, ptr %t1173, !tbaa !39
  %t1175 = load ptr, ptr %lp51
  %t1176 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t1176, ptr %l594, !tbaa !27
  %t1177 = load i64, ptr %l50, !tbaa !24
  %t1179 = getelementptr { i64, ptr }, ptr %l594, i32 0, i32 1
  %t1180 = load ptr, ptr %t1179, !tbaa !27
  %t1181 = getelementptr i32, ptr %t1180, i64 %t1177
  %t1182 = load i32, ptr %t1181, !tbaa !33
  %t1183 = load ptr, ptr %l4, !tbaa !29
  %t1184 = load i64, ptr %l5, !tbaa !24
  %t1191 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epattern(ptr %v0, ptr %v1, ptr %t1167, ptr %t1174, ptr %t1175, i32 %t1182, ptr %t1183, i64 %t1184)
  store ptr %t1191, ptr %l599
  br label %bb243
bb243:
  %t1192 = load ptr, ptr %l586, !tbaa !29
  %t1193 = load %"compiler/source:Span", ptr %l587
  %t1194 = load ptr, ptr %l588, !tbaa !29
  %t1195 = load ptr, ptr %l599, !tbaa !29
  %t1196 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eand2(ptr %v0, ptr %t1192, %"compiler/source:Span" %t1193, ptr %t1194, ptr %t1195)
  store ptr %t1196, ptr %l600
  br label %bb244
bb244:
  %t1197 = load ptr, ptr %l600, !tbaa !29
  store ptr %t1197, ptr %l39, !tbaa !29
  call void @__olang_scope_close(ptr %s30)
  br label %bb245
bb245:
  %t1198 = load i64, ptr %l49, !tbaa !24
  %t1200 = add i64 %t1198, 1
  store i64 %t1200, ptr %l49, !tbaa !24
  br label %bb238
bb246:
  %t1202 = load ptr, ptr %l39, !tbaa !29
  store ptr %t1202, ptr %rv
  br label %ret
bb247:
  %t1204 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1204, ptr %l604, !tbaa !29
  store i1 false, ptr %l605, !tbaa !21
  %t1205 = load ptr, ptr %l604, !tbaa !29
  %t1206 = icmp ne ptr %t1205, null
  br i1 %t1206, label %bb248, label %bb249
bb248:
  %t1208 = load ptr, ptr %l604, !tbaa !29
  %t1209 = load i64, ptr %t1208
  %t1211 = icmp eq i64 %t1209, 4
  store i1 %t1211, ptr %l605, !tbaa !21
  br label %bb249
bb249:
  %t1212 = load i1, ptr %l605, !tbaa !21
  br i1 %t1212, label %bb250, label %bb251
bb250:
  %t1213 = load ptr, ptr %l1, !tbaa !29
  %t1215 = getelementptr { i64, [4 x i64] }, ptr %t1213, i32 0, i32 1
  %t1216 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1215, i32 0, i32 0
  %t1217 = load %"compiler/source:Span", ptr %t1216
  store %"compiler/source:Span" %t1217, ptr %l52
  %t1219 = load ptr, ptr %l1, !tbaa !29
  %t1221 = getelementptr { i64, [4 x i64] }, ptr %t1219, i32 0, i32 1
  %t1222 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1221, i32 0, i32 1
  %t1223 = load ptr, ptr %t1222
  store ptr %t1223, ptr %l53, !tbaa !29
  br label %bb252
bb251:
  br label %bb254
bb252:
  %t1225 = load ptr, ptr %l0, !tbaa !29
  %t1226 = load ptr, ptr %l53, !tbaa !29
  %t1227 = load ptr, ptr %l2, !tbaa !29
  %t1228 = load i32, ptr %l3, !tbaa !23
  %t1229 = load ptr, ptr %l4, !tbaa !29
  %t1230 = load i64, ptr %l5, !tbaa !24
  %t1237 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprPattern(ptr %v0, ptr %v1, ptr %t1225, ptr %t1226, ptr %t1227, i32 %t1228, ptr %t1229, i64 %t1230, i1 true)
  store ptr %t1237, ptr %l618
  br label %bb253
bb253:
  %t1238 = load ptr, ptr %l618, !tbaa !29
  store ptr %t1238, ptr %rv
  br label %ret
bb254:
  call void @__olang_check_failed(ptr @olang_loc_2bba12d772c132ef_de888473626934f3)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceName(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i1
  %l12 = alloca ptr
  %l14 = alloca %"compiler/typed:Local"
  %l16 = alloca ptr
  %l17 = alloca i1
  %rv = alloca i32
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t18 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %a0)
  store ptr %t18, ptr %l12
  br label %bb6
bb6:
  %t19 = load i32, ptr %l2, !tbaa !23
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t22 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t20, i32 %t19)
  store %"compiler/typed:Local" %t22, ptr %l14
  br label %bb7
bb7:
  %t23 = getelementptr %"compiler/typed:Local", ptr %l14, i32 0, i32 0
  %t24 = load i32, ptr %t23, !tbaa !23
  store i32 %t24, ptr %l4, !tbaa !23
  br label %bb19
bb8:
  %t26 = load ptr, ptr %l1, !tbaa !29
  store ptr %t26, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t27 = load ptr, ptr %l16, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb9, label %bb10
bb9:
  %t30 = load ptr, ptr %l16, !tbaa !29
  %t31 = load i64, ptr %t30
  %t33 = icmp eq i64 %t31, 1
  store i1 %t33, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t34 = load i1, ptr %l17, !tbaa !21
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr { i64, [4 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t37, i32 0, i32 3
  %t39 = load i32, ptr %t38
  store i32 %t39, ptr %l3, !tbaa !23
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t41 = load i32, ptr %l3, !tbaa !23
  store i32 %t41, ptr %l4, !tbaa !23
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i32 0, ptr %l4, !tbaa !23
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_1f453287a90ee701_f75bf1e5be6f432d)
  unreachable
bb19:
  %t43 = load i32, ptr %l4, !tbaa !23
  store i32 %t43, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erefWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l5 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %l18 = alloca i1
  %l21 = alloca ptr
  %l23 = alloca ptr
  %l27 = alloca %"compiler/names:Ref"
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call i1 @compiler_2fcheck_2erefWrittenTop(ptr %v1, ptr %t1)
  store i1 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i1, ptr %l5, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t7 = load ptr, ptr %l7, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb5, label %bb6
bb5:
  %t10 = load ptr, ptr %l7, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t14 = load i1, ptr %l8, !tbaa !21
  br i1 %t14, label %bb7, label %bb8
bb7:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t17, i32 0, i32 0
  %t19 = load %"compiler/source:Span", ptr %t18
  store %"compiler/source:Span" %t19, ptr %l2
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [5 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t23, i32 0, i32 1
  %t25 = load { i64, ptr }, ptr %t24
  store { i64, ptr } %t25, ptr %l3, !tbaa !27
  br label %bb9
bb8:
  br label %bb15
bb9:
  %t27 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t31 = icmp eq i64 %t29, 1
  br i1 %t31, label %bb10, label %bb11
bb10:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !29
  store ptr %t39, ptr %l21, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t40)
  store ptr %t42, ptr %l23
  br label %bb12
bb11:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb14
bb12:
  %t43 = load ptr, ptr %l23, !tbaa !29
  %t45 = getelementptr %"compiler/check:frame", ptr %t43, i32 0, i32 2
  %t46 = load i64, ptr %t45, !tbaa !24
  %t47 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t48 = load i32, ptr %t47, !tbaa !23
  %t49 = load ptr, ptr %l21, !tbaa !29
  %t52 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t49, i64 %t46, i32 %t48)
  store %"compiler/names:Ref" %t52, ptr %l27
  br label %bb13
bb13:
  %t53 = getelementptr %"compiler/names:Ref", ptr %l27, i32 0, i32 0
  %t54 = load i32, ptr %t53
  %t56 = trunc i64 8 to i32
  %t57 = icmp eq i32 %t54, %t56
  store i1 %t57, ptr %l18, !tbaa !21
  br label %bb14
bb14:
  %t59 = load i1, ptr %l18, !tbaa !21
  store i1 %t59, ptr %rv
  br label %ret
bb15:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereset(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca ptr
  %l8 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca ptr
  %l10 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca ptr
  %l14 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca ptr
  %l16 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca ptr
  %l19 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca ptr
  %l21 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca ptr
  %l23 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca ptr
  %l25 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l28 = alloca ptr
  %l29 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l30 = alloca ptr
  %l31 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l32 = alloca ptr
  %l33 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l34 = alloca ptr
  %l35 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l36 = alloca ptr
  %l37 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l38 = alloca ptr
  %l39 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l40 = alloca ptr
  %l41 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l42 = alloca ptr
  %l43 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l44 = alloca ptr
  %l45 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l46 = alloca ptr
  %l47 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l49 = alloca ptr
  %l50 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l51 = alloca ptr
  %l52 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l53 = alloca ptr
  %l54 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l55 = alloca ptr
  %l56 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l57 = alloca ptr
  %l58 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l59 = alloca ptr
  %l60 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l61 = alloca ptr
  %l62 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l63 = alloca ptr
  %l64 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l65 = alloca ptr
  %l66 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l67 = alloca ptr
  %l68 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l69 = alloca ptr
  %l70 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l71 = alloca ptr
  %l72 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l73 = alloca ptr
  %l74 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l75 = alloca ptr
  %l76 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l77 = alloca ptr
  %l78 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l79 = alloca ptr
  %l80 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l81 = alloca ptr
  %l82 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l83 = alloca ptr
  %l84 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l85 = alloca ptr
  %l86 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l87 = alloca ptr
  %l88 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l89 = alloca ptr
  %l90 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l91 = alloca ptr
  %l92 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l93 = alloca ptr
  %l94 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l95 = alloca ptr
  %l96 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l97 = alloca ptr
  %l98 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l99 = alloca ptr
  %l100 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l101 = alloca ptr
  %l102 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l103 = alloca ptr
  %l104 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l105 = alloca ptr
  %l106 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l107 = alloca ptr
  %l108 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l109 = alloca ptr
  %l110 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l111 = alloca ptr
  %l112 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l113 = alloca ptr
  %l114 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l115 = alloca ptr
  %l116 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l1, !tbaa !29
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l2
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l2
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/check:Checker", ptr %t4, i32 0, i32 11
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t5
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l3, !tbaa !29
  %t7 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aGap_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l4
  br label %bb2
bb2:
  %t8 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l4
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t10 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 12
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %t10
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l5, !tbaa !29
  %t12 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l6
  br label %bb3
bb3:
  %t13 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l6
  %t14 = load ptr, ptr %l5, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 91
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %t15
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l7, !tbaa !29
  %t17 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, ptr %l8
  br label %bb4
bb4:
  %t18 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  %t19 = load ptr, ptr %l7, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 96
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t18, ptr %t20
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l9, !tbaa !29
  %t22 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l10
  br label %bb5
bb5:
  %t23 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  %t24 = load ptr, ptr %l9, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 97
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %t25
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResetAny(ptr %v0, ptr %t29)
  br label %bb6
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l13, !tbaa !29
  %t32 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %l14
  br label %bb7
bb7:
  %t33 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l14
  %t34 = load ptr, ptr %l13, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 13
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t33, ptr %t35
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l15, !tbaa !29
  %t37 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t37, ptr %l16
  br label %bb8
bb8:
  %t38 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  %t39 = load ptr, ptr %l15, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 14
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t38, ptr %t40
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 15
  store i64 0, ptr %t43, !tbaa !24
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l18, !tbaa !29
  %t45 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t45, ptr %l19
  br label %bb9
bb9:
  %t46 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  %t47 = load ptr, ptr %l18, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 16
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t46, ptr %t48
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l20, !tbaa !29
  %t50 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t50, ptr %l21
  br label %bb10
bb10:
  %t51 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l21
  %t52 = load ptr, ptr %l20, !tbaa !29
  %t53 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 17
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t51, ptr %t53
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l22, !tbaa !29
  %t55 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t55, ptr %l23
  br label %bb11
bb11:
  %t56 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l23
  %t57 = load ptr, ptr %l22, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 20
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t56, ptr %t58
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l24, !tbaa !29
  %t60 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t60, ptr %l25
  br label %bb12
bb12:
  %t61 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l25
  %t62 = load ptr, ptr %l24, !tbaa !29
  %t63 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 21
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t61, ptr %t63
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t68 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 22
  store i32 %t65, ptr %t68, !tbaa !23
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l28, !tbaa !29
  %t70 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t70, ptr %l29
  br label %bb13
bb13:
  %t71 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l29
  %t72 = load ptr, ptr %l28, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t72, i32 0, i32 23
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t71, ptr %t73
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l30, !tbaa !29
  %t75 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t75, ptr %l31
  br label %bb14
bb14:
  %t76 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l31
  %t77 = load ptr, ptr %l30, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 24
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t76, ptr %t78
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l32, !tbaa !29
  %t80 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t80, ptr %l33
  br label %bb15
bb15:
  %t81 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l33
  %t82 = load ptr, ptr %l32, !tbaa !29
  %t83 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 25
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t81, ptr %t83
  %t84 = load ptr, ptr %l0, !tbaa !29
  store ptr %t84, ptr %l34, !tbaa !29
  %t85 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t85, ptr %l35
  br label %bb16
bb16:
  %t86 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l35
  %t87 = load ptr, ptr %l34, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t87, i32 0, i32 26
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t86, ptr %t88
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l36, !tbaa !29
  %t90 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t90, ptr %l37
  br label %bb17
bb17:
  %t91 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l37
  %t92 = load ptr, ptr %l36, !tbaa !29
  %t93 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 27
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t91, ptr %t93
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l38, !tbaa !29
  %t95 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fsource_3aSpan_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t95, ptr %l39
  br label %bb18
bb18:
  %t96 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l39
  %t97 = load ptr, ptr %l38, !tbaa !29
  %t98 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 28
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t96, ptr %t98
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l40, !tbaa !29
  %t100 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t100, ptr %l41
  br label %bb19
bb19:
  %t101 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l41
  %t102 = load ptr, ptr %l40, !tbaa !29
  %t103 = getelementptr %"compiler/check:Checker", ptr %t102, i32 0, i32 29
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t101, ptr %t103
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l42, !tbaa !29
  %t105 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t105, ptr %l43
  br label %bb20
bb20:
  %t106 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l43
  %t107 = load ptr, ptr %l42, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t107, i32 0, i32 32
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t106, ptr %t108
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l44, !tbaa !29
  %t110 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t110, ptr %l45
  br label %bb21
bb21:
  %t111 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l45
  %t112 = load ptr, ptr %l44, !tbaa !29
  %t113 = getelementptr %"compiler/check:Checker", ptr %t112, i32 0, i32 33
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t111, ptr %t113
  %t114 = load ptr, ptr %l0, !tbaa !29
  store ptr %t114, ptr %l46, !tbaa !29
  %t115 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aatRec_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t115, ptr %l47
  br label %bb22
bb22:
  %t116 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l47
  %t117 = load ptr, ptr %l46, !tbaa !29
  %t118 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 34
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t116, ptr %t118
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/check:Checker", ptr %t119, i32 0, i32 35
  store i32 0, ptr %t121, !tbaa !23
  %t122 = load ptr, ptr %l0, !tbaa !29
  store ptr %t122, ptr %l49, !tbaa !29
  %t123 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t123, ptr %l50
  br label %bb23
bb23:
  %t124 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l50
  %t125 = load ptr, ptr %l49, !tbaa !29
  %t126 = getelementptr %"compiler/check:Checker", ptr %t125, i32 0, i32 47
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t124, ptr %t126
  %t127 = load ptr, ptr %l0, !tbaa !29
  store ptr %t127, ptr %l51, !tbaa !29
  %t128 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t128, ptr %l52
  br label %bb24
bb24:
  %t129 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l52
  %t130 = load ptr, ptr %l51, !tbaa !29
  %t131 = getelementptr %"compiler/check:Checker", ptr %t130, i32 0, i32 48
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t129, ptr %t131
  %t132 = load ptr, ptr %l0, !tbaa !29
  store ptr %t132, ptr %l53, !tbaa !29
  %t133 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t133, ptr %l54
  br label %bb25
bb25:
  %t134 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l54
  %t135 = load ptr, ptr %l53, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 49
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t134, ptr %t136
  %t137 = load ptr, ptr %l0, !tbaa !29
  store ptr %t137, ptr %l55, !tbaa !29
  %t138 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t138, ptr %l56
  br label %bb26
bb26:
  %t139 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l56
  %t140 = load ptr, ptr %l55, !tbaa !29
  %t141 = getelementptr %"compiler/check:Checker", ptr %t140, i32 0, i32 50
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t139, ptr %t141
  %t142 = load ptr, ptr %l0, !tbaa !29
  store ptr %t142, ptr %l57, !tbaa !29
  %t143 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t143, ptr %l58
  br label %bb27
bb27:
  %t144 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l58
  %t145 = load ptr, ptr %l57, !tbaa !29
  %t146 = getelementptr %"compiler/check:Checker", ptr %t145, i32 0, i32 52
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t144, ptr %t146
  %t147 = load ptr, ptr %l0, !tbaa !29
  store ptr %t147, ptr %l59, !tbaa !29
  %t148 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t148, ptr %l60
  br label %bb28
bb28:
  %t149 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l60
  %t150 = load ptr, ptr %l59, !tbaa !29
  %t151 = getelementptr %"compiler/check:Checker", ptr %t150, i32 0, i32 54
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t149, ptr %t151
  %t152 = load ptr, ptr %l0, !tbaa !29
  store ptr %t152, ptr %l61, !tbaa !29
  %t153 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t153, ptr %l62
  br label %bb29
bb29:
  %t154 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l62
  %t155 = load ptr, ptr %l61, !tbaa !29
  %t156 = getelementptr %"compiler/check:Checker", ptr %t155, i32 0, i32 55
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t154, ptr %t156
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l63, !tbaa !29
  %t158 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t158, ptr %l64
  br label %bb30
bb30:
  %t159 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l64
  %t160 = load ptr, ptr %l63, !tbaa !29
  %t161 = getelementptr %"compiler/check:Checker", ptr %t160, i32 0, i32 56
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t159, ptr %t161
  %t162 = load ptr, ptr %l0, !tbaa !29
  store ptr %t162, ptr %l65, !tbaa !29
  %t163 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fcheck_3aroOrigin_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t163, ptr %l66
  br label %bb31
bb31:
  %t164 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l66
  %t165 = load ptr, ptr %l65, !tbaa !29
  %t166 = getelementptr %"compiler/check:Checker", ptr %t165, i32 0, i32 57
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t164, ptr %t166
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l67, !tbaa !29
  %t168 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t168, ptr %l68
  br label %bb32
bb32:
  %t169 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l68
  %t170 = load ptr, ptr %l67, !tbaa !29
  %t171 = getelementptr %"compiler/check:Checker", ptr %t170, i32 0, i32 58
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t169, ptr %t171
  %t172 = load ptr, ptr %l0, !tbaa !29
  store ptr %t172, ptr %l69, !tbaa !29
  %t173 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H94cbbacdefacbf11591e45fa927fb1cb(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t173, ptr %l70
  br label %bb33
bb33:
  %t174 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l70
  %t175 = load ptr, ptr %l69, !tbaa !29
  %t176 = getelementptr %"compiler/check:Checker", ptr %t175, i32 0, i32 59
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t174, ptr %t176
  %t177 = load ptr, ptr %l0, !tbaa !29
  store ptr %t177, ptr %l71, !tbaa !29
  %t178 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroArg_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t178, ptr %l72
  br label %bb34
bb34:
  %t179 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l72
  %t180 = load ptr, ptr %l71, !tbaa !29
  %t181 = getelementptr %"compiler/check:Checker", ptr %t180, i32 0, i32 60
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t179, ptr %t181
  %t182 = load ptr, ptr %l0, !tbaa !29
  store ptr %t182, ptr %l73, !tbaa !29
  %t183 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroFn_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t183, ptr %l74
  br label %bb35
bb35:
  %t184 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l74
  %t185 = load ptr, ptr %l73, !tbaa !29
  %t186 = getelementptr %"compiler/check:Checker", ptr %t185, i32 0, i32 61
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t184, ptr %t186
  %t187 = load ptr, ptr %l0, !tbaa !29
  store ptr %t187, ptr %l75, !tbaa !29
  %t188 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20std_2fprelude_2flis_H596e3d714cead58c6bb1a410db388b73(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t188, ptr %l76
  br label %bb36
bb36:
  %t189 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l76
  %t190 = load ptr, ptr %l75, !tbaa !29
  %t191 = getelementptr %"compiler/check:Checker", ptr %t190, i32 0, i32 62
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t189, ptr %t191
  %t192 = load ptr, ptr %l0, !tbaa !29
  store ptr %t192, ptr %l77, !tbaa !29
  %t193 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t193, ptr %l78
  br label %bb37
bb37:
  %t194 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l78
  %t195 = load ptr, ptr %l77, !tbaa !29
  %t196 = getelementptr %"compiler/check:Checker", ptr %t195, i32 0, i32 63
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t194, ptr %t196
  %t197 = load ptr, ptr %l0, !tbaa !29
  store ptr %t197, ptr %l79, !tbaa !29
  %t198 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t198, ptr %l80
  br label %bb38
bb38:
  %t199 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l80
  %t200 = load ptr, ptr %l79, !tbaa !29
  %t201 = getelementptr %"compiler/check:Checker", ptr %t200, i32 0, i32 64
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t199, ptr %t201
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l81, !tbaa !29
  %t203 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t203, ptr %l82
  br label %bb39
bb39:
  %t204 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l82
  %t205 = load ptr, ptr %l81, !tbaa !29
  %t206 = getelementptr %"compiler/check:Checker", ptr %t205, i32 0, i32 65
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t204, ptr %t206
  %t207 = load ptr, ptr %l0, !tbaa !29
  store ptr %t207, ptr %l83, !tbaa !29
  %t208 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroDeepArg_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t208, ptr %l84
  br label %bb40
bb40:
  %t209 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l84
  %t210 = load ptr, ptr %l83, !tbaa !29
  %t211 = getelementptr %"compiler/check:Checker", ptr %t210, i32 0, i32 66
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t209, ptr %t211
  %t212 = load ptr, ptr %l0, !tbaa !29
  store ptr %t212, ptr %l85, !tbaa !29
  %t213 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroArg_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t213, ptr %l86
  br label %bb41
bb41:
  %t214 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l86
  %t215 = load ptr, ptr %l85, !tbaa !29
  %t216 = getelementptr %"compiler/check:Checker", ptr %t215, i32 0, i32 67
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t214, ptr %t216
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l87, !tbaa !29
  %t218 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t218, ptr %l88
  br label %bb42
bb42:
  %t219 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l88
  %t220 = load ptr, ptr %l87, !tbaa !29
  %t221 = getelementptr %"compiler/check:Checker", ptr %t220, i32 0, i32 68
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t219, ptr %t221
  %t222 = load ptr, ptr %l0, !tbaa !29
  store ptr %t222, ptr %l89, !tbaa !29
  %t223 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t223, ptr %l90
  br label %bb43
bb43:
  %t224 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l90
  %t225 = load ptr, ptr %l89, !tbaa !29
  %t226 = getelementptr %"compiler/check:Checker", ptr %t225, i32 0, i32 69
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t224, ptr %t226
  %t227 = load ptr, ptr %l0, !tbaa !29
  store ptr %t227, ptr %l91, !tbaa !29
  %t228 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAsk_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t228, ptr %l92
  br label %bb44
bb44:
  %t229 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l92
  %t230 = load ptr, ptr %l91, !tbaa !29
  %t231 = getelementptr %"compiler/check:Checker", ptr %t230, i32 0, i32 74
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t229, ptr %t231
  %t232 = load ptr, ptr %l0, !tbaa !29
  store ptr %t232, ptr %l93, !tbaa !29
  %t233 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aEmbedAsk_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t233, ptr %l94
  br label %bb45
bb45:
  %t234 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l94
  %t235 = load ptr, ptr %l93, !tbaa !29
  %t236 = getelementptr %"compiler/check:Checker", ptr %t235, i32 0, i32 75
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t234, ptr %t236
  %t237 = load ptr, ptr %l0, !tbaa !29
  store ptr %t237, ptr %l95, !tbaa !29
  %t238 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAssertAsk_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t238, ptr %l96
  br label %bb46
bb46:
  %t239 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l96
  %t240 = load ptr, ptr %l95, !tbaa !29
  %t241 = getelementptr %"compiler/check:Checker", ptr %t240, i32 0, i32 76
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t239, ptr %t241
  %t242 = load ptr, ptr %l0, !tbaa !29
  store ptr %t242, ptr %l97, !tbaa !29
  %t243 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aValueAsk_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t243, ptr %l98
  br label %bb47
bb47:
  %t244 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l98
  %t245 = load ptr, ptr %l97, !tbaa !29
  %t246 = getelementptr %"compiler/check:Checker", ptr %t245, i32 0, i32 77
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t244, ptr %t246
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l99, !tbaa !29
  %t248 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aContractInfo_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t248, ptr %l100
  br label %bb48
bb48:
  %t249 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l100
  %t250 = load ptr, ptr %l99, !tbaa !29
  %t251 = getelementptr %"compiler/check:Checker", ptr %t250, i32 0, i32 78
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t249, ptr %t251
  %t252 = load ptr, ptr %l0, !tbaa !29
  store ptr %t252, ptr %l101, !tbaa !29
  %t253 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t253, ptr %l102
  br label %bb49
bb49:
  %t254 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l102
  %t255 = load ptr, ptr %l101, !tbaa !29
  %t256 = getelementptr %"compiler/check:Checker", ptr %t255, i32 0, i32 79
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t254, ptr %t256
  %t257 = load ptr, ptr %l0, !tbaa !29
  store ptr %t257, ptr %l103, !tbaa !29
  %t258 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aContractAsk_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t258, ptr %l104
  br label %bb50
bb50:
  %t259 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l104
  %t260 = load ptr, ptr %l103, !tbaa !29
  %t261 = getelementptr %"compiler/check:Checker", ptr %t260, i32 0, i32 80
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t259, ptr %t261
  %t262 = load ptr, ptr %l0, !tbaa !29
  store ptr %t262, ptr %l105, !tbaa !29
  %t263 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t263, ptr %l106
  br label %bb51
bb51:
  %t264 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l106
  %t265 = load ptr, ptr %l105, !tbaa !29
  %t266 = getelementptr %"compiler/check:Checker", ptr %t265, i32 0, i32 81
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t264, ptr %t266
  %t267 = load ptr, ptr %l0, !tbaa !29
  store ptr %t267, ptr %l107, !tbaa !29
  %t268 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t268, ptr %l108
  br label %bb52
bb52:
  %t269 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l108
  %t270 = load ptr, ptr %l107, !tbaa !29
  %t271 = getelementptr %"compiler/check:Checker", ptr %t270, i32 0, i32 82
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t269, ptr %t271
  %t272 = load ptr, ptr %l0, !tbaa !29
  store ptr %t272, ptr %l109, !tbaa !29
  %t273 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t273, ptr %l110
  br label %bb53
bb53:
  %t274 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l110
  %t275 = load ptr, ptr %l109, !tbaa !29
  %t276 = getelementptr %"compiler/check:Checker", ptr %t275, i32 0, i32 85
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t274, ptr %t276
  %t277 = load ptr, ptr %l0, !tbaa !29
  store ptr %t277, ptr %l111, !tbaa !29
  %t278 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fcheck_3afixedInit_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t278, ptr %l112
  br label %bb54
bb54:
  %t279 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l112
  %t280 = load ptr, ptr %l111, !tbaa !29
  %t281 = getelementptr %"compiler/check:Checker", ptr %t280, i32 0, i32 86
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t279, ptr %t281
  %t282 = load ptr, ptr %l0, !tbaa !29
  store ptr %t282, ptr %l113, !tbaa !29
  %t283 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t283, ptr %l114
  br label %bb55
bb55:
  %t284 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l114
  %t285 = load ptr, ptr %l113, !tbaa !29
  %t286 = getelementptr %"compiler/check:Checker", ptr %t285, i32 0, i32 87
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t284, ptr %t286
  %t287 = load ptr, ptr %l0, !tbaa !29
  store ptr %t287, ptr %l115, !tbaa !29
  %t288 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t288, ptr %l116
  br label %bb56
bb56:
  %t289 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l116
  %t290 = load ptr, ptr %l115, !tbaa !29
  %t291 = getelementptr %"compiler/check:Checker", ptr %t290, i32 0, i32 88
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t289, ptr %t291
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erewritten(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l14 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l21 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l22 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a2, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l14, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i64, ptr %t19, i64 %t16
  %t21 = load i64, ptr %t20, !tbaa !34
  %t25 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 87
  store ptr %t25, ptr %l18, !tbaa !29
  %t30 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s2, i64 %a1, i64 %t21)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t30, ptr %l21
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l18, !tbaa !29
  %t32 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l21
  %t33 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t31, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t32)
  store i1 %t33, ptr %l22
  br label %bb6
bb6:
  %t34 = load i1, ptr %l22, !tbaa !21
  br i1 %t34, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t36 = load i64, ptr %l4, !tbaa !24
  %t38 = add i64 %t36, 1
  store i64 %t38, ptr %l4, !tbaa !24
  br label %bb1
bb11:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKeepVal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l14 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l19 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l25 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %a1, i64 %a2)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t9, ptr %l10
  br label %bb4
bb4:
  %t10 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l10
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t10, ptr %l4
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 62
  %t14 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  %t17 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H4c470d2e80d9fd53b2c4a8b35e81296f(ptr %v0, ptr %t13, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t14)
  store i1 %t17, ptr %l14
  br label %bb5
bb5:
  %t18 = load i1, ptr %l14, !tbaa !21
  %t19 = xor i1 %t18, true
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 62
  store ptr %t23, ptr %l17, !tbaa !29
  %t24 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t24, ptr %l18
  %t25 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l19
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t26 = load ptr, ptr %l17, !tbaa !29
  %t27 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l18
  %t28 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H64396385e4e6d43afa926b839ce2258a(ptr %v0, ptr %v0, ptr %t26, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t27, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t28)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 62
  %t32 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  %t35 = call { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H6388cc594ade7977543a45717e2b755f(ptr %v0, ptr %v0, ptr %t31, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t32)
  %t36 = extractvalue { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %t35, 1
  %t37 = extractvalue { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %t35, 0
  store i32 %t37, ptr %l25
  %t38 = icmp ne i32 %t37, 0
  br i1 %t38, label %bb12, label %ok.39
ok.39:
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t36, ptr %l24
  br label %bb11
bb11:
  %t40 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l24
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t40, ptr %l20
  br label %bb14
bb12:
  br label %bb13
bb13:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  %t41 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l20
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t41, ptr %l5
  %t42 = load ptr, ptr %l3, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v1, ptr %l5, ptr %t42)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleFixed(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca %"compiler/check:Ask"
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca %"compiler/check:AssertAsk"
  %l18 = alloca i64
  %l22 = alloca i64
  %l25 = alloca i64
  %l46 = alloca %"compiler/check:Ask"
  %l50 = alloca i1
  %l66 = alloca i64
  %l70 = alloca i64
  %l73 = alloca i64
  %l94 = alloca %"compiler/check:AssertAsk"
  %l98 = alloca i1
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 74
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAsk_3e_2eLen_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l18
  br label %bb1
bb1:
  %t6 = load i64, ptr %l18, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l25, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l25, !tbaa !24
  store i64 %t33, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l22, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l2, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 74
  %t59 = call %"compiler/check:Ask" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAsk_3e_2eAt_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %v0, ptr %t55, i64 %t51)
  store %"compiler/check:Ask" %t59, ptr %l46
  br label %bb12
bb12:
  %t60 = load %"compiler/check:Ask", ptr %l46
  store %"compiler/check:Ask" %t60, ptr %l8
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Ask", ptr %l8, i32 0, i32 4
  %t63 = load i64, ptr %t62, !tbaa !24
  %t64 = getelementptr %"compiler/check:Ask", ptr %l8, i32 0, i32 5
  %t65 = load { i64, ptr }, ptr %t64, !tbaa !27
  %t69 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erewritten(ptr %v0, ptr %v0, ptr %t61, i64 %t63, { i64, ptr } %t65)
  store i1 %t69, ptr %l50
  br label %bb13
bb13:
  %t70 = load i1, ptr %l50, !tbaa !21
  br i1 %t70, label %bb14, label %bb15
bb14:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/check:Ask", ptr %l8, i32 0, i32 3
  %t73 = load ptr, ptr %t72, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eRunning(ptr %v0, ptr %v0, ptr %t71, ptr %t73)
  br label %bb16
bb15:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 74
  %t79 = load i64, ptr %l1, !tbaa !24
  %t80 = load %"compiler/check:Ask", ptr %l8
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAsk_3e_2eSetAt_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %v0, ptr %t78, i64 %t79, %"compiler/check:Ask" %t80)
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t84 = load i64, ptr %l1, !tbaa !24
  %t86 = add i64 %t84, 1
  store i64 %t86, ptr %l1, !tbaa !24
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t88 = load i64, ptr %l6, !tbaa !24
  %t90 = add i64 %t88, 1
  store i64 %t90, ptr %l6, !tbaa !24
  br label %bb8
bb20:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 74
  %t95 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAsk_3e_2eTruncate_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %t94, i64 %t95)
  br label %bb21
bb21:
  store i64 0, ptr %l1, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/check:Checker", ptr %t98, i32 0, i32 76
  %t102 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAssertAsk_3e_2eL_H74c4c659bc848d1046c0a3f6eab69368(ptr %v0, ptr %t100)
  store i64 %t102, ptr %l66
  br label %bb22
bb22:
  %t103 = load i64, ptr %l66, !tbaa !24
  store i64 %t103, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t104 = load i64, ptr %l10, !tbaa !24
  %t105 = load i64, ptr %l9, !tbaa !24
  %t108 = icmp sgt i64 %t104, %t105
  br i1 %t108, label %bb23, label %bb24
bb23:
  %t110 = load i64, ptr %l11, !tbaa !24
  %t112 = icmp sgt i64 %t110, 0
  br i1 %t112, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l70, !tbaa !24
  br label %bb28
bb25:
  %t114 = load i64, ptr %l10, !tbaa !24
  %t115 = load i64, ptr %l9, !tbaa !24
  %t118 = sub i64 %t114, %t115
  %t119 = load i64, ptr %l11, !tbaa !24
  %t122 = add i64 %t118, %t119
  %t124 = sub i64 %t122, 1
  %t125 = load i64, ptr %l11, !tbaa !24
  %t128 = sdiv i64 %t124, %t125
  store i64 %t128, ptr %l73, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l73, !tbaa !24
  br label %bb27
bb27:
  %t130 = load i64, ptr %l73, !tbaa !24
  store i64 %t130, ptr %l70, !tbaa !24
  br label %bb28
bb28:
  %t131 = load i64, ptr %l70, !tbaa !24
  store i64 %t131, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s7
  %t132 = load i64, ptr %l13, !tbaa !24
  %t133 = load i64, ptr %l12, !tbaa !24
  %t136 = icmp slt i64 %t132, %t133
  %t138 = xor i1 %t136, true
  br i1 %t138, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s7)
  br label %bb40
bb31:
  br label %bb32
bb32:
  %t140 = load i64, ptr %l9, !tbaa !24
  %t141 = load i64, ptr %l13, !tbaa !24
  %t142 = load i64, ptr %l11, !tbaa !24
  %t145 = mul i64 %t141, %t142
  %t148 = add i64 %t140, %t145
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/check:Checker", ptr %t150, i32 0, i32 76
  %t156 = call %"compiler/check:AssertAsk" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAssertAsk_3e_2eA_Hdc7a201c0afbc93ed6dfeec3b1f47711(ptr %v0, ptr %v0, ptr %t152, i64 %t148)
  store %"compiler/check:AssertAsk" %t156, ptr %l94
  br label %bb33
bb33:
  %t157 = load %"compiler/check:AssertAsk", ptr %l94
  store %"compiler/check:AssertAsk" %t157, ptr %l15
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/check:AssertAsk", ptr %l15, i32 0, i32 0
  %t160 = load i64, ptr %t159, !tbaa !24
  %t161 = getelementptr %"compiler/check:AssertAsk", ptr %l15, i32 0, i32 6
  %t162 = load { i64, ptr }, ptr %t161, !tbaa !27
  %t166 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erewritten(ptr %v0, ptr %v0, ptr %t158, i64 %t160, { i64, ptr } %t162)
  store i1 %t166, ptr %l98
  br label %bb34
bb34:
  %t167 = load i1, ptr %l98, !tbaa !21
  %t168 = xor i1 %t167, true
  br i1 %t168, label %bb35, label %bb36
bb35:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/check:Checker", ptr %t170, i32 0, i32 76
  %t173 = load i64, ptr %l1, !tbaa !24
  %t174 = load %"compiler/check:AssertAsk", ptr %l15
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAssertAsk_3e_2eS_Hc42af0083e860bde3bfdbe1629d1fbcf(ptr %v0, ptr %v0, ptr %t172, i64 %t173, %"compiler/check:AssertAsk" %t174)
  br label %bb37
bb36:
  br label %bb38
bb37:
  %t178 = load i64, ptr %l1, !tbaa !24
  %t180 = add i64 %t178, 1
  store i64 %t180, ptr %l1, !tbaa !24
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s7)
  br label %bb39
bb39:
  %t182 = load i64, ptr %l13, !tbaa !24
  %t184 = add i64 %t182, 1
  store i64 %t184, ptr %l13, !tbaa !24
  br label %bb29
bb40:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = getelementptr %"compiler/check:Checker", ptr %t186, i32 0, i32 76
  %t189 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAssertAsk_3e_2eT_H5b1bf5f8eb2d6b750ac9501715f6a378(ptr %v0, ptr %t188, i64 %t189)
  br label %bb41
bb41:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eslotCall(ptr %v0, ptr %a0, i32 %a1, i64 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i64
  %l8 = alloca { i64, ptr }
  %l15 = alloca i64
  %l19 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i64
  %l26 = alloca { i64, [3 x i64] }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  %t8 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %t4, i32 %t5)
  store { i64, ptr } %t8, ptr %l8
  br label %bb1
bb1:
  %t9 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  %t12 = icmp eq i64 %t10, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t18 = load i32, ptr %l1, !tbaa !23
  %t23 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSlotKey(ptr %v0, ptr %t17, i32 %t18, i64 %a2)
  store i64 %t23, ptr %l15
  br label %bb5
bb5:
  %t24 = load i64, ptr %l15, !tbaa !24
  store i64 %t24, ptr %l4, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 96
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_Had7920a3eff3220b2e12299d961f9124(ptr %v0, ptr %t27, i64 %t28)
  store i1 %t31, ptr %l19
  br label %bb6
bb6:
  %t32 = load i1, ptr %l19, !tbaa !21
  %t33 = xor i1 %t32, true
  br i1 %t33, label %bb7, label %bb8
bb7:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 96
  store ptr %t37, ptr %l22, !tbaa !29
  %t38 = load i64, ptr %l4, !tbaa !24
  store i64 %t38, ptr %l23, !tbaa !24
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t43 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t39, %"compiler/source:Span" %a3)
  store { i64, [3 x i64] } %t43, ptr %l26
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t44 = load ptr, ptr %l22, !tbaa !29
  %t45 = load i64, ptr %l23, !tbaa !24
  %t46 = load { i64, [3 x i64] }, ptr %l26
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_Hc07a7e56a24d8f1225398db99ea19a4b(ptr %v0, ptr %t44, i64 %t45, { i64, [3 x i64] } %t46)
  br label %bb10
bb10:
  br label %bb11
bb11:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estrInstance(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/generic:Binding"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l15 = alloca i1
  %l19 = alloca i32
  %l21 = alloca i64
  %l25 = alloca i64
  %l28 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca i64
  %l36 = alloca ptr
  %l41 = alloca i32
  %l42 = alloca { i64, ptr }
  %l48 = alloca %"compiler/generic:Binding"
  %l50 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l72 = alloca ptr
  %l74 = alloca ptr
  %l75 = alloca i64
  %l80 = alloca i32
  %l81 = alloca i64
  %l82 = alloca i64
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %t4, i64 %t5)
  store i1 %t8, ptr %l15
  br label %bb1
bb1:
  %t9 = load i1, ptr %l15, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t13, i64 %t14)
  store i32 %t17, ptr %l19
  br label %bb5
bb5:
  %t18 = load i32, ptr %l19, !tbaa !23
  store i32 %t18, ptr %l3, !tbaa !23
  %t19 = load i64, ptr %l1, !tbaa !24
  %t21 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t19)
  store i64 %t21, ptr %l21
  br label %bb6
bb6:
  %t22 = load i64, ptr %l21, !tbaa !24
  store i64 %t22, ptr %l4, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t26, i64 %t27)
  store i64 %t30, ptr %l25
  br label %bb7
bb7:
  %t31 = load i64, ptr %l25, !tbaa !24
  store i64 %t31, ptr %l5, !tbaa !24
  %t32 = load i64, ptr %l5, !tbaa !24
  %t34 = icmp eq i64 %t32, 0
  br i1 %t34, label %bb8, label %bb9
bb8:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l28, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t41 = load i64, ptr %l1, !tbaa !24
  %t44 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %t40, i64 %t41, i32 0)
  store i64 %t44, ptr %l32
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t45 = load ptr, ptr %l28, !tbaa !29
  %t46 = load i64, ptr %l32, !tbaa !24
  %t47 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnBody(ptr %v0, ptr %t45, i64 %t46)
  store i64 %t47, ptr %l33
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb12:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = getelementptr %"compiler/generic:Program", ptr %t51, i32 0, i32 2
  store ptr %t53, ptr %l36, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/generic:Program", ptr %t57, i32 0, i32 2
  %t60 = load i32, ptr %l3, !tbaa !23
  %t63 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t59, i32 %t60)
  store i32 %t63, ptr %l41
  br label %bb13
bb13:
  %t64 = load ptr, ptr %l36, !tbaa !29
  %t65 = load i32, ptr %l41, !tbaa !23
  %t66 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t64, i32 %t65)
  store { i64, ptr } %t66, ptr %l42
  br label %bb14
bb14:
  %t67 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t67, ptr %l6, !tbaa !27
  %t68 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t72 = icmp eq i64 %t70, 0
  br i1 %t72, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb16:
  br label %bb17
bb17:
  %t74 = load i64, ptr %l4, !tbaa !24
  %t75 = load i64, ptr %l5, !tbaa !24
  %t78 = call %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %s0, i64 %t74, i64 %t75)
  store %"compiler/generic:Binding" %t78, ptr %l48
  br label %bb18
bb18:
  %t79 = load %"compiler/generic:Binding", ptr %l48
  store %"compiler/generic:Binding" %t79, ptr %l7
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t81, ptr %l50, !tbaa !27
  %t82 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr i32, ptr %t83, i64 0
  %t85 = load i32, ptr %t84, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %s0, ptr %t80, i32 %t85, i32 %a2, ptr %l7, i1 false, i1 true)
  br label %bb19
bb19:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/check:Checker", ptr %t91, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInferThroughBounds(ptr %v0, ptr %s0, ptr %t94, ptr %l7)
  br label %bb20
bb20:
  %t97 = getelementptr %"compiler/generic:Binding", ptr %l7, i32 0, i32 2
  %t98 = load { i64, ptr }, ptr %t97, !tbaa !27
  store { i64, ptr } %t98, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t100 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t100, 0
  store i64 %t102, ptr %l10, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s5
  %t104 = load i64, ptr %l9, !tbaa !24
  %t105 = load i64, ptr %l10, !tbaa !24
  %t108 = icmp slt i64 %t104, %t105
  %t110 = xor i1 %t108, true
  br i1 %t110, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s5)
  br label %bb29
bb23:
  br label %bb24
bb24:
  %t112 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t112, ptr %l64, !tbaa !27
  %t113 = load i64, ptr %l9, !tbaa !24
  %t115 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr i32, ptr %t116, i64 %t113
  %t118 = load i32, ptr %t117, !tbaa !33
  %t121 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t124 = icmp eq i32 %t118, %t121
  br i1 %t124, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb26:
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s5)
  br label %bb28
bb28:
  %t126 = load i64, ptr %l9, !tbaa !24
  %t128 = add i64 %t126, 1
  store i64 %t128, ptr %l9, !tbaa !24
  br label %bb21
bb29:
  %t130 = load ptr, ptr %l0, !tbaa !29
  store ptr %t130, ptr %l72, !tbaa !29
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/check:Checker", ptr %t131, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !29
  store ptr %t134, ptr %l74, !tbaa !29
  %t135 = load i64, ptr %l1, !tbaa !24
  store i64 %t135, ptr %l75, !tbaa !24
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/check:Checker", ptr %t136, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t141 = getelementptr %"compiler/generic:Program", ptr %t139, i32 0, i32 2
  %t142 = getelementptr %"compiler/generic:Binding", ptr %l7, i32 0, i32 2
  %t143 = load { i64, ptr }, ptr %t142, !tbaa !27
  %t146 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t141, { i64, ptr } %t143)
  store i32 %t146, ptr %l80
  br label %bb30
bb30:
  %t147 = load ptr, ptr %l74, !tbaa !29
  %t148 = load i64, ptr %l75, !tbaa !24
  %t149 = load i32, ptr %l80, !tbaa !23
  %t150 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %t147, i64 %t148, i32 %t149)
  store i64 %t150, ptr %l81
  br label %bb31
bb31:
  %t151 = load ptr, ptr %l72, !tbaa !29
  %t152 = load i64, ptr %l81, !tbaa !24
  %t153 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnBody(ptr %v0, ptr %t151, i64 %t152)
  store i64 %t153, ptr %l82
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etaskDefault(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l9 = alloca ptr
  %l12 = alloca i1
  %l13 = alloca i1
  %l18 = alloca i1
  %l22 = alloca %"compiler/source:Span"
  %l25 = alloca ptr
  %l26 = alloca %"compiler/source:Span"
  %l27 = alloca %"compiler/msgs:Msg"
  %l28 = alloca i64
  %l29 = alloca ptr
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca i32
  %l38 = alloca %"compiler/source:Span"
  %l39 = alloca ptr
  %s2 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i32, ptr %l2, !tbaa !23
  %t8 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t1, ptr %t2, i32 %t4)
  store ptr %t8, ptr %l9
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l9, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l2, !tbaa !23
  %t14 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t10, i32 %t11)
  store i1 %t14, ptr %l12
  br label %bb2
bb2:
  %t15 = load i1, ptr %l12, !tbaa !21
  br i1 %t15, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb6
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t21, i32 %t22)
  store i1 %t25, ptr %l18
  br label %bb5
bb5:
  %t26 = load i1, ptr %l18, !tbaa !21
  store i1 %t26, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l13, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t33 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexistingIn(ptr %v0, ptr %v0, ptr %t28, ptr %t29)
  store %"compiler/source:Span" %t33, ptr %l22
  br label %bb9
bb8:
  br label %bb17
bb9:
  %t34 = load %"compiler/source:Span", ptr %l22
  store %"compiler/source:Span" %t34, ptr %l4
  %t35 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 0
  %t36 = load i32, ptr %t35, !tbaa !23
  %t38 = icmp sge i32 %t36, 0
  br i1 %t38, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l25, !tbaa !29
  %t41 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t41, ptr %l26
  %t42 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskDefaultExisting(ptr %s2)
  store %"compiler/msgs:Msg" %t42, ptr %l27
  br label %bb12
bb11:
  br label %bb16
bb12:
  %t43 = load ptr, ptr %l25, !tbaa !29
  %t44 = load %"compiler/source:Span", ptr %l26
  %t45 = load %"compiler/msgs:Msg", ptr %l27
  %t46 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t43, %"compiler/source:Span" %t44, %"compiler/msgs:Msg" %t45)
  store i64 %t46, ptr %l28
  br label %bb13
bb13:
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l29, !tbaa !29
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t48)
  store %"compiler/source:Span" %t50, ptr %l31
  br label %bb14
bb14:
  %t51 = load ptr, ptr %l29, !tbaa !29
  %t52 = load %"compiler/source:Span", ptr %l31
  %t53 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t51, %"compiler/source:Span" %t52)
  store ptr %t53, ptr %l32
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  %t54 = load ptr, ptr %l32, !tbaa !29
  store ptr %t54, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l33, !tbaa !29
  %t56 = load ptr, ptr %l3, !tbaa !29
  store ptr %t56, ptr %l34, !tbaa !29
  %t57 = load i32, ptr %l2, !tbaa !23
  store i32 %t57, ptr %l35, !tbaa !23
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t62 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %t58, ptr %t59)
  store %"compiler/source:Span" %t62, ptr %l38
  br label %bb18
bb18:
  %t63 = load ptr, ptr %l33, !tbaa !29
  %t64 = load ptr, ptr %l34, !tbaa !29
  %t65 = load i32, ptr %l35, !tbaa !23
  %t66 = load %"compiler/source:Span", ptr %l38
  %t67 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t63, ptr %t64, i32 %t65, %"compiler/source:Span" %t66)
  store ptr %t67, ptr %l39
  br label %bb19
bb19:
  %t68 = load ptr, ptr %l39, !tbaa !29
  store ptr %t68, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextLit(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l7 = alloca i32
  %l9 = alloca i32
  %l11 = alloca ptr
  %l13 = alloca i64
  %l16 = alloca { i64, ptr }
  %rv = alloca ptr
  %t28 = alloca { i64, [2 x i64] }, align 8
  %t36 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1, ptr %l2
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/check:Checker", ptr %t2, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t7 = getelementptr %"compiler/generic:Program", ptr %t5, i32 0, i32 2
  store ptr %t7, ptr %l5, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t8)
  store i32 %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t12 = load ptr, ptr %l5, !tbaa !29
  %t13 = load i32, ptr %l7, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t12, i32 %t13, i64 %t11)
  store i32 %t15, ptr %l9
  br label %bb2
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t16)
  store ptr %t18, ptr %l11
  br label %bb3
bb3:
  %t19 = load ptr, ptr %l11, !tbaa !29
  %t21 = getelementptr %"compiler/check:frame", ptr %t19, i32 0, i32 2
  %t22 = load i64, ptr %t21, !tbaa !24
  store i64 %t22, ptr %l13, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load %"compiler/source:Span", ptr %l1
  %t27 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estrBytes(ptr %v0, ptr %t23, %"compiler/source:Span" %t24)
  store { i64, ptr } %t27, ptr %l16
  br label %bb4
bb4:
  store { i64, [2 x i64] } zeroinitializer, ptr %t28
  %t29 = getelementptr { i64, [2 x i64] }, ptr %t28, i32 0, i32 0
  store i64 1, ptr %t29
  %t30 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t31 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t30, 0
  %t32 = getelementptr { i64, [2 x i64] }, ptr %t28, i32 0, i32 1
  store { { i64, ptr } } %t31, ptr %t32
  %t33 = load { i64, [2 x i64] }, ptr %t28
  %t35 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store { i64, [2 x i64] } %t33, ptr %t35
  store { i64, [5 x i64] } zeroinitializer, ptr %t36
  %t37 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 0
  store i64 1, ptr %t37
  %t38 = load %"compiler/source:Span", ptr %l2
  %t39 = insertvalue { %"compiler/source:Span", i32, i64, ptr } undef, %"compiler/source:Span" %t38, 0
  %t40 = load i32, ptr %l9, !tbaa !23
  %t41 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t39, i32 %t40, 1
  %t42 = load i64, ptr %l13, !tbaa !24
  %t43 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t41, i64 %t42, 2
  %t45 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t43, ptr %t35, 3
  %t46 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, ptr } %t45, ptr %t46
  %t47 = load { i64, [5 x i64] }, ptr %t36
  %t49 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t47, ptr %t49
  store ptr %t49, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 44
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp slt i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s1, ptr %s1, ptr %t12, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d20, i32 0, i32 1) }, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d21, i32 0, i32 1) })
  store i32 %t14, ptr %l7
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t15 = load i32, ptr %l7, !tbaa !23
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 44
  store i32 %t15, ptr %t17, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  br label %bb4
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 44
  %t21 = load i32, ptr %t20, !tbaa !23
  store i32 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeHasEq(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i32
  %l6 = alloca i32
  %l9 = alloca i1
  %l10 = alloca i1
  %l13 = alloca i64
  %l18 = alloca i1
  %l19 = alloca i1
  %l24 = alloca i32
  %l33 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i32, ptr %l6, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l3, !tbaa !23
  %t11 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t7, i32 %t8)
  store i1 %t11, ptr %l9
  br label %bb2
bb2:
  %t12 = load i1, ptr %l9, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l3, !tbaa !23
  %t17 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeqMethod(ptr %v0, ptr %t13, i32 %t14)
  store i64 %t17, ptr %l13
  br label %bb5
bb4:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb6
bb5:
  %t18 = load i64, ptr %l13, !tbaa !24
  %t19 = icmp ne i64 %t18, -1
  store i1 %t19, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t21 = load i1, ptr %l10, !tbaa !21
  br i1 %t21, label %bb7, label %bb8
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l1, !tbaa !23
  %t27 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t23, i32 %t24)
  store i1 %t27, ptr %l18
  br label %bb10
bb10:
  %t28 = load i1, ptr %l18, !tbaa !21
  br i1 %t28, label %bb11, label %bb12
bb11:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t35 = load i32, ptr %l3, !tbaa !23
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t38, ptr %l24
  br label %bb13
bb12:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb14
bb13:
  %t39 = load i32, ptr %l24
  %t41 = trunc i64 19 to i32
  %t42 = icmp eq i32 %t39, %t41
  %t44 = xor i1 %t42, true
  store i1 %t44, ptr %l19, !tbaa !21
  br label %bb14
bb14:
  %t46 = load i1, ptr %l19, !tbaa !21
  br i1 %t46, label %bb15, label %bb16
bb15:
  store i1 false, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load i32, ptr %l3, !tbaa !23
  %t52 = add i64 %a2, 1
  %t56 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epartsHaveEq(ptr %v0, ptr %t48, i32 %t49, i64 %t52)
  store i1 %t56, ptr %l33
  br label %bb18
bb18:
  %t57 = load i1, ptr %l33, !tbaa !21
  store i1 %t57, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunadapted(ptr %v0, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l24 = alloca ptr
  %rv = alloca ptr
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Promote", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  store ptr %t19, ptr %rv
  br label %ret
bb6:
  %t21 = load ptr, ptr %l1, !tbaa !29
  store ptr %t21, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t22 = load ptr, ptr %l13, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t26 = load i64, ptr %t25
  %t28 = icmp eq i64 %t26, 3
  store i1 %t28, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t29 = load i1, ptr %l14, !tbaa !21
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = getelementptr { i64, [5 x i64] }, ptr %t30, i32 0, i32 1
  %t33 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t32, i32 0, i32 0
  %t34 = load %"compiler/source:Span", ptr %t33
  store %"compiler/source:Span" %t34, ptr %l3
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t38, i32 0, i32 2
  %t40 = load ptr, ptr %t39
  store ptr %t40, ptr %l4, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t43 = load %"compiler/source:Span", ptr %l3
  %t44 = load ptr, ptr %l4, !tbaa !29
  %t48 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %a0, %"compiler/source:Span" %t43, ptr %t44)
  store ptr %t48, ptr %l24
  br label %bb12
bb12:
  %t49 = load ptr, ptr %l24, !tbaa !29
  store ptr %t49, ptr %rv
  br label %ret
bb13:
  %t50 = load ptr, ptr %l1, !tbaa !29
  store ptr %t50, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euncovered(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i64
  %l15 = alloca i32
  %l20 = alloca i64
  %l25 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l39 = alloca i32
  %l42 = alloca i64
  %l47 = alloca i64
  %l54 = alloca i64
  %l57 = alloca i64
  %l59 = alloca i64
  %l71 = alloca i32
  %l78 = alloca i32
  %s2 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l15
  br label %bb1
bb1:
  %t11 = load i32, ptr %l15, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %l2, !tbaa !23
  %t21 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t17, i32 %t18)
  store i64 %t21, ptr %l20
  br label %bb2
bb2:
  %t22 = load i64, ptr %l20, !tbaa !65
  store i64 %t22, ptr %l4, !tbaa !65
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  %t32 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t28, i32 %a1)
  store { i64, ptr } %t32, ptr %l25
  br label %bb3
bb3:
  %t33 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t33, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t34 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t34, 0
  store i64 %t36, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t38 = load i64, ptr %l6, !tbaa !24
  %t39 = load i64, ptr %l7, !tbaa !24
  %t42 = icmp slt i64 %t38, %t39
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb6:
  br label %bb7
bb7:
  %t46 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t46, ptr %l32, !tbaa !27
  %t47 = load i64, ptr %l6, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr i32, ptr %t50, i64 %t47
  %t52 = load i32, ptr %t51, !tbaa !33
  store i32 %t52, ptr %l8, !tbaa !23
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/generic:Program", ptr %t57, i32 0, i32 2
  %t60 = load i32, ptr %l8, !tbaa !23
  %t63 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t59, i32 %t60)
  store i32 %t63, ptr %l39
  br label %bb8
bb8:
  %t64 = load i32, ptr %l3, !tbaa !23
  %t65 = load i32, ptr %l39, !tbaa !23
  %t67 = icmp eq i32 %t65, %t64
  br i1 %t67, label %bb9, label %bb10
bb9:
  %t69 = load i64, ptr %l4, !tbaa !65
  store i64 %t69, ptr %l42, !tbaa !65
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/check:Checker", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/generic:Program", ptr %t73, i32 0, i32 2
  %t76 = load i32, ptr %l8, !tbaa !23
  %t79 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t75, i32 %t76)
  store i64 %t79, ptr %l47
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t80 = load i64, ptr %l47, !tbaa !65
  %t81 = xor i64 %t80, -1
  %t82 = load i64, ptr %l42, !tbaa !65
  %t84 = and i64 %t82, %t81
  store i64 %t84, ptr %l4, !tbaa !65
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  %t86 = load i64, ptr %l6, !tbaa !24
  %t88 = add i64 %t86, 1
  store i64 %t88, ptr %l6, !tbaa !24
  br label %bb4
bb14:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i32, ptr %l3, !tbaa !23
  %t94 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordCount(ptr %v0, ptr %t90, i32 %t91)
  store i64 %t94, ptr %l54
  br label %bb15
bb15:
  %t95 = load i64, ptr %l54, !tbaa !24
  store i64 %t95, ptr %l9, !tbaa !24
  %t96 = load i64, ptr %l9, !tbaa !24
  %t98 = icmp sge i64 %t96, 64
  br i1 %t98, label %bb16, label %bb17
bb16:
  %t100 = sub i64 0, 1
  store i64 %t100, ptr %l57, !tbaa !65
  br label %bb18
bb17:
  %t102 = load i64, ptr %l9, !tbaa !24
  store i64 %t102, ptr %l59, !tbaa !24
  %t103 = load i64, ptr %l59, !tbaa !24
  %t104 = load i64, ptr %l59, !tbaa !24
  %t105 = shl i64 1, %t104
  %t107 = sub i64 %t105, 1
  store i64 %t107, ptr %l57, !tbaa !65
  br label %bb18
bb18:
  %t109 = load i64, ptr %l57, !tbaa !65
  store i64 %t109, ptr %l10, !tbaa !65
  %t110 = load i64, ptr %l4, !tbaa !65
  %t111 = load i64, ptr %l10, !tbaa !65
  %t114 = and i64 %t110, %t111
  store i64 %t114, ptr %l4, !tbaa !65
  %t116 = load i64, ptr %l4, !tbaa !65
  %t118 = icmp eq i64 %t116, 0
  br i1 %t118, label %bb19, label %bb20
bb19:
  %t120 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t120, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t122 = load i64, ptr %l4, !tbaa !65
  %t123 = load i64, ptr %l10, !tbaa !65
  %t126 = icmp eq i64 %t122, %t123
  br i1 %t126, label %bb22, label %bb23
bb22:
  %t128 = load i32, ptr %l3, !tbaa !23
  store i32 %t128, ptr %l71, !tbaa !23
  br label %bb25
bb23:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/check:Checker", ptr %t130, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t135 = getelementptr %"compiler/generic:Program", ptr %t133, i32 0, i32 2
  %t136 = load i32, ptr %l3, !tbaa !23
  %t137 = load i64, ptr %l4, !tbaa !65
  %t141 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %t135, i32 %t136, i64 %t137)
  store i32 %t141, ptr %l78
  br label %bb24
bb24:
  %t142 = load i32, ptr %l78, !tbaa !23
  store i32 %t142, ptr %l71, !tbaa !23
  br label %bb25
bb25:
  %t143 = load i32, ptr %l71, !tbaa !23
  store i32 %t143, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrolled(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, %"compiler/check:reflList" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca %"compiler/check:reflList"
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, i64, i64 }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca { i64, i64, i64 }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca { i64, i64, i64 }
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l35 = alloca %"compiler/source:Span"
  %l38 = alloca ptr
  %l39 = alloca %"compiler/source:Span"
  %l40 = alloca %"compiler/msgs:Msg"
  %l41 = alloca i64
  %l42 = alloca ptr
  %l45 = alloca %"compiler/source:Span"
  %l47 = alloca { i64, ptr }
  %l50 = alloca i64
  %l54 = alloca { i64, i64, i64 }
  %l59 = alloca ptr
  %l68 = alloca i64
  %l71 = alloca i64
  %l91 = alloca i64
  %l95 = alloca { i64, i64, i64 }
  %l100 = alloca ptr
  %l104 = alloca ptr
  %l106 = alloca i32
  %l111 = alloca i32
  %l112 = alloca i32
  %l113 = alloca ptr
  %l115 = alloca i32
  %l118 = alloca ptr
  %l120 = alloca i32
  %l122 = alloca i32
  %l123 = alloca i32
  %l147 = alloca i64
  %l149 = alloca ptr
  %l152 = alloca i64
  %l153 = alloca i32
  %l159 = alloca ptr
  %l162 = alloca i64
  %l166 = alloca { i64, i64, i64 }
  %l183 = alloca ptr
  %l201 = alloca i64
  %l203 = alloca ptr
  %l206 = alloca i64
  %l207 = alloca i32
  %l213 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %t234 = alloca { i64, [3 x i64] }, align 8
  %t301 = alloca { i64, [3 x i64] }, align 8
  %t332 = alloca { i64, [3 x i64] }, align 8
  %t356 = alloca { i64, [3 x i64] }, align 8
  %t398 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store %"compiler/check:reflList" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t2 = load i32, ptr %t1, !tbaa !23
  %t3 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = add i32 %t4, 3
  %t9 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t2, i32 %t6)
  store %"compiler/source:Span" %t9, ptr %l35
  br label %bb1
bb1:
  %t10 = load %"compiler/source:Span", ptr %l35
  store %"compiler/source:Span" %t10, ptr %l4
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = getelementptr %"compiler/ast:ForIn", ptr %t11, i32 0, i32 3
  %t14 = load i1, ptr %t13, !tbaa !21
  br i1 %t14, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l38, !tbaa !29
  %t17 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t17, ptr %l39
  %t18 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflTryList(ptr %s1)
  store %"compiler/msgs:Msg" %t18, ptr %l40
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t19 = load ptr, ptr %l38, !tbaa !29
  %t20 = load %"compiler/source:Span", ptr %l39
  %t21 = load %"compiler/msgs:Msg", ptr %l40
  %t22 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t19, %"compiler/source:Span" %t20, %"compiler/msgs:Msg" %t21)
  store i64 %t22, ptr %l41
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb6
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l42, !tbaa !29
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t26 = getelementptr %"compiler/ast:ForIn", ptr %t24, i32 0, i32 2
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t27)
  store %"compiler/source:Span" %t29, ptr %l45
  br label %bb7
bb7:
  %t30 = load %"compiler/check:reflList", ptr %l3
  %t31 = load ptr, ptr %l42, !tbaa !29
  %t32 = load %"compiler/source:Span", ptr %l45
  %t34 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistItems(ptr %v0, ptr %s0, ptr %t31, %"compiler/source:Span" %t32, %"compiler/check:reflList" %t30)
  store { i64, ptr } %t34, ptr %l47
  br label %bb8
bb8:
  %t35 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t35, ptr %l5, !tbaa !27
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 33
  %t40 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t38)
  store i64 %t40, ptr %l50
  br label %bb9
bb9:
  %t41 = load i64, ptr %l50, !tbaa !24
  store i64 %t41, ptr %l6, !tbaa !24
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load %"compiler/source:Span", ptr %l1
  %t47 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t42, i32 2, %"compiler/source:Span" %t43)
  store { i64, i64, i64 } %t47, ptr %l54
  br label %bb10
bb10:
  %t48 = load { i64, i64, i64 }, ptr %l54
  store { i64, i64, i64 } %t48, ptr %l7
  %t49 = getelementptr { i64, i64, i64 }, ptr %l7, i32 0, i32 0
  %t50 = load i64, ptr %t49, !tbaa !24
  store i64 %t50, ptr %l8, !tbaa !24
  %t52 = getelementptr { i64, i64, i64 }, ptr %l7, i32 0, i32 1
  %t53 = load i64, ptr %t52, !tbaa !24
  store i64 %t53, ptr %l9, !tbaa !24
  %t55 = getelementptr { i64, i64, i64 }, ptr %l7, i32 0, i32 2
  %t56 = load i64, ptr %t55, !tbaa !24
  store i64 %t56, ptr %l10, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t58)
  store ptr %t60, ptr %l59
  br label %bb11
bb11:
  %t61 = load ptr, ptr %l59, !tbaa !29
  %t63 = getelementptr %"compiler/check:frame", ptr %t61, i32 0, i32 11
  %t64 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t63, i64 %t64)
  br label %bb12
bb12:
  store i64 0, ptr %l11, !tbaa !24
  %t67 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 0
  store i64 %t69, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t71 = load i64, ptr %l12, !tbaa !24
  %t72 = load i64, ptr %l11, !tbaa !24
  %t75 = icmp sgt i64 %t71, %t72
  br i1 %t75, label %bb13, label %bb14
bb13:
  %t77 = load i64, ptr %l13, !tbaa !24
  %t79 = icmp sgt i64 %t77, 0
  br i1 %t79, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l68, !tbaa !24
  br label %bb18
bb15:
  %t81 = load i64, ptr %l12, !tbaa !24
  %t82 = load i64, ptr %l11, !tbaa !24
  %t85 = sub i64 %t81, %t82
  %t86 = load i64, ptr %l13, !tbaa !24
  %t89 = add i64 %t85, %t86
  %t91 = sub i64 %t89, 1
  %t92 = load i64, ptr %l13, !tbaa !24
  %t95 = sdiv i64 %t91, %t92
  store i64 %t95, ptr %l71, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l71, !tbaa !24
  br label %bb17
bb17:
  %t97 = load i64, ptr %l71, !tbaa !24
  store i64 %t97, ptr %l68, !tbaa !24
  br label %bb18
bb18:
  %t98 = load i64, ptr %l68, !tbaa !24
  store i64 %t98, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t99 = load i64, ptr %l15, !tbaa !24
  %t100 = load i64, ptr %l14, !tbaa !24
  %t103 = icmp slt i64 %t99, %t100
  %t105 = xor i1 %t103, true
  br i1 %t105, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s3)
  br label %bb51
bb21:
  br label %bb22
bb22:
  %t107 = load i64, ptr %l11, !tbaa !24
  %t108 = load i64, ptr %l15, !tbaa !24
  %t109 = load i64, ptr %l13, !tbaa !24
  %t112 = mul i64 %t108, %t109
  %t115 = add i64 %t107, %t112
  store i64 %t115, ptr %l16, !tbaa !24
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 33
  %t121 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t119)
  store i64 %t121, ptr %l91
  br label %bb23
bb23:
  %t122 = load i64, ptr %l91, !tbaa !24
  store i64 %t122, ptr %l17, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load %"compiler/source:Span", ptr %l1
  %t128 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t123, i32 2, %"compiler/source:Span" %t124)
  store { i64, i64, i64 } %t128, ptr %l95
  br label %bb24
bb24:
  %t129 = load { i64, i64, i64 }, ptr %l95
  store { i64, i64, i64 } %t129, ptr %l18
  %t130 = getelementptr { i64, i64, i64 }, ptr %l18, i32 0, i32 0
  %t131 = load i64, ptr %t130, !tbaa !24
  store i64 %t131, ptr %l19, !tbaa !24
  %t133 = getelementptr { i64, i64, i64 }, ptr %l18, i32 0, i32 1
  %t134 = load i64, ptr %t133, !tbaa !24
  store i64 %t134, ptr %l20, !tbaa !24
  %t136 = getelementptr { i64, i64, i64 }, ptr %l18, i32 0, i32 2
  %t137 = load i64, ptr %t136, !tbaa !24
  store i64 %t137, ptr %l21, !tbaa !24
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t139)
  store ptr %t141, ptr %l100
  br label %bb25
bb25:
  %t142 = load ptr, ptr %l100, !tbaa !29
  %t144 = getelementptr %"compiler/check:frame", ptr %t142, i32 0, i32 10
  %t145 = load i64, ptr %l19, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t144, i64 %t145)
  br label %bb26
bb26:
  %t148 = load ptr, ptr %l0, !tbaa !29
  store ptr %t148, ptr %l104, !tbaa !29
  %t149 = load ptr, ptr %l2, !tbaa !29
  %t151 = getelementptr %"compiler/ast:ForIn", ptr %t149, i32 0, i32 1
  %t152 = load i32, ptr %t151, !tbaa !23
  store i32 %t152, ptr %l106, !tbaa !23
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load %"compiler/check:reflList", ptr %l3
  %t155 = load i64, ptr %l16, !tbaa !24
  %t157 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = getelementptr i64, ptr %t158, i64 %t155
  %t160 = load i64, ptr %t159, !tbaa !34
  %t164 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescriptor(ptr %v0, ptr %t153, %"compiler/check:reflList" %t154, i64 %t160)
  store i32 %t164, ptr %l111
  br label %bb27
bb27:
  %t165 = load ptr, ptr %l104, !tbaa !29
  %t166 = load i32, ptr %l106, !tbaa !23
  %t167 = load i32, ptr %l111, !tbaa !23
  %t168 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflBind(ptr %v0, ptr %t165, i32 %t166, i32 %t167)
  store i32 %t168, ptr %l112
  br label %bb28
bb28:
  %t169 = load i32, ptr %l112, !tbaa !23
  store i32 %t169, ptr %l22, !tbaa !23
  %t170 = load ptr, ptr %l0, !tbaa !29
  store ptr %t170, ptr %l113, !tbaa !29
  %t171 = load ptr, ptr %l2, !tbaa !29
  %t173 = getelementptr %"compiler/ast:ForIn", ptr %t171, i32 0, i32 0
  %t174 = load i32, ptr %t173, !tbaa !23
  store i32 %t174, ptr %l115, !tbaa !23
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/check:Checker", ptr %t175, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !29
  %t180 = getelementptr %"compiler/generic:Program", ptr %t178, i32 0, i32 2
  store ptr %t180, ptr %l118, !tbaa !29
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t181)
  store i32 %t183, ptr %l120
  br label %bb29
bb29:
  %t184 = load i64, ptr %l16, !tbaa !24
  %t185 = load ptr, ptr %l118, !tbaa !29
  %t186 = load i32, ptr %l120, !tbaa !23
  %t188 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t185, i32 %t186, i64 %t184)
  store i32 %t188, ptr %l122
  br label %bb30
bb30:
  %t189 = load ptr, ptr %l113, !tbaa !29
  %t190 = load i32, ptr %l115, !tbaa !23
  %t191 = load i32, ptr %l122, !tbaa !23
  %t192 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflBind(ptr %v0, ptr %t189, i32 %t190, i32 %t191)
  store i32 %t192, ptr %l123
  br label %bb31
bb31:
  %t193 = load i32, ptr %l123, !tbaa !23
  store i32 %t193, ptr %l23, !tbaa !23
  %t194 = load ptr, ptr %l2, !tbaa !29
  %t196 = getelementptr %"compiler/ast:ForIn", ptr %t194, i32 0, i32 4
  %t197 = load { i64, ptr }, ptr %t196, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t197, 0
  %t201 = icmp sgt i64 %t199, 0
  br i1 %t201, label %bb32, label %bb33
bb32:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load ptr, ptr %l2, !tbaa !29
  %t206 = getelementptr %"compiler/ast:ForIn", ptr %t204, i32 0, i32 4
  %t207 = load { i64, ptr }, ptr %t206, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %t203, { i64, ptr } %t207)
  br label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb35
bb35:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t211 = load ptr, ptr %l2, !tbaa !29
  %t213 = getelementptr %"compiler/ast:ForIn", ptr %t211, i32 0, i32 0
  %t214 = load i32, ptr %t213, !tbaa !23
  %t215 = load i32, ptr %l23, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflUnbind(ptr %v0, ptr %t210, i32 %t214, i32 %t215)
  br label %bb36
bb36:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load ptr, ptr %l2, !tbaa !29
  %t222 = getelementptr %"compiler/ast:ForIn", ptr %t220, i32 0, i32 1
  %t223 = load i32, ptr %t222, !tbaa !23
  %t224 = load i32, ptr %l22, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflUnbind(ptr %v0, ptr %t219, i32 %t223, i32 %t224)
  br label %bb37
bb37:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load %"compiler/source:Span", ptr %l1
  %t230 = load i64, ptr %l19, !tbaa !24
  %t232 = trunc i64 %t230 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t234
  %t235 = getelementptr { i64, [3 x i64] }, ptr %t234, i32 0, i32 0
  store i64 5, ptr %t235
  %t237 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t229, 0
  %t239 = insertvalue { %"compiler/source:Span", i32, i32 } %t237, i32 0, 1
  %t241 = insertvalue { %"compiler/source:Span", i32, i32 } %t239, i32 %t232, 2
  %t242 = getelementptr { i64, [3 x i64] }, ptr %t234, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t241, ptr %t242
  %t243 = load { i64, [3 x i64] }, ptr %t234
  %t245 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t243, ptr %t245
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t228, ptr %t245)
  br label %bb38
bb38:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t250 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t248)
  store ptr %t250, ptr %l149
  br label %bb39
bb39:
  %t251 = load ptr, ptr %l149, !tbaa !29
  %t253 = getelementptr %"compiler/check:frame", ptr %t251, i32 0, i32 10
  %t255 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t253)
  %t256 = extractvalue { i32, i64 } %t255, 1
  %t257 = extractvalue { i32, i64 } %t255, 0
  store i32 %t257, ptr %l153
  %t258 = icmp ne i32 %t257, 0
  br i1 %t258, label %bb41, label %ok.259
ok.259:
  store i64 %t256, ptr %l152
  br label %bb40
bb40:
  %t260 = load i64, ptr %l152, !tbaa !24
  store i64 %t260, ptr %l147, !tbaa !24
  br label %bb43
bb41:
  br label %bb42
bb42:
  call void @__olang_ert_req_clear()
  br label %bb43
bb43:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t262 = load i64, ptr %l19, !tbaa !24
  %t263 = load i64, ptr %l20, !tbaa !24
  %t264 = load i64, ptr %l21, !tbaa !24
  %t265 = load i64, ptr %l17, !tbaa !24
  %t271 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t261, i64 %t262, i64 %t263, i64 %t264, i64 %t265)
  store ptr %t271, ptr %l159
  br label %bb44
bb44:
  %t272 = load ptr, ptr %l159, !tbaa !29
  store ptr %t272, ptr %l24, !tbaa !29
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/check:Checker", ptr %t273, i32 0, i32 33
  %t277 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t275)
  store i64 %t277, ptr %l162
  br label %bb45
bb45:
  %t278 = load i64, ptr %l162, !tbaa !24
  store i64 %t278, ptr %l25, !tbaa !24
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t280 = load %"compiler/source:Span", ptr %l1
  %t284 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t279, i32 3, %"compiler/source:Span" %t280)
  store { i64, i64, i64 } %t284, ptr %l166
  br label %bb46
bb46:
  %t285 = load { i64, i64, i64 }, ptr %l166
  store { i64, i64, i64 } %t285, ptr %l26
  %t286 = getelementptr { i64, i64, i64 }, ptr %l26, i32 0, i32 0
  %t287 = load i64, ptr %t286, !tbaa !24
  store i64 %t287, ptr %l27, !tbaa !24
  %t289 = getelementptr { i64, i64, i64 }, ptr %l26, i32 0, i32 1
  %t290 = load i64, ptr %t289, !tbaa !24
  store i64 %t290, ptr %l28, !tbaa !24
  %t292 = getelementptr { i64, i64, i64 }, ptr %l26, i32 0, i32 2
  %t293 = load i64, ptr %t292, !tbaa !24
  store i64 %t293, ptr %l29, !tbaa !24
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t296 = load %"compiler/source:Span", ptr %l1
  %t297 = load i64, ptr %l19, !tbaa !24
  %t299 = trunc i64 %t297 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t301
  %t302 = getelementptr { i64, [3 x i64] }, ptr %t301, i32 0, i32 0
  store i64 5, ptr %t302
  %t304 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t296, 0
  %t306 = insertvalue { %"compiler/source:Span", i32, i32 } %t304, i32 0, 1
  %t308 = insertvalue { %"compiler/source:Span", i32, i32 } %t306, i32 %t299, 2
  %t309 = getelementptr { i64, [3 x i64] }, ptr %t301, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t308, ptr %t309
  %t310 = load { i64, [3 x i64] }, ptr %t301
  %t312 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t310, ptr %t312
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t295, ptr %t312)
  br label %bb47
bb47:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t316 = load i64, ptr %l27, !tbaa !24
  %t317 = load i64, ptr %l28, !tbaa !24
  %t318 = load i64, ptr %l29, !tbaa !24
  %t319 = load i64, ptr %l25, !tbaa !24
  %t325 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t315, i64 %t316, i64 %t317, i64 %t318, i64 %t319)
  store ptr %t325, ptr %l183
  br label %bb48
bb48:
  %t326 = load ptr, ptr %l183, !tbaa !29
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t328 = load %"compiler/source:Span", ptr %l1
  %t329 = load ptr, ptr %l24, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t332
  %t333 = getelementptr { i64, [3 x i64] }, ptr %t332, i32 0, i32 0
  store i64 4, ptr %t333
  %t335 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t328, 0
  %t337 = insertvalue { %"compiler/source:Span", ptr, ptr } %t335, ptr %t329, 1
  %t339 = insertvalue { %"compiler/source:Span", ptr, ptr } %t337, ptr %t326, 2
  %t340 = getelementptr { i64, [3 x i64] }, ptr %t332, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t339, ptr %t340
  %t341 = load { i64, [3 x i64] }, ptr %t332
  %t343 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t341, ptr %t343
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t327, ptr %t343)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s3)
  br label %bb50
bb50:
  %t346 = load i64, ptr %l15, !tbaa !24
  %t348 = add i64 %t346, 1
  store i64 %t348, ptr %l15, !tbaa !24
  br label %bb19
bb51:
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t351 = load %"compiler/source:Span", ptr %l1
  %t352 = load i64, ptr %l8, !tbaa !24
  %t354 = trunc i64 %t352 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t356
  %t357 = getelementptr { i64, [3 x i64] }, ptr %t356, i32 0, i32 0
  store i64 5, ptr %t357
  %t359 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t351, 0
  %t361 = insertvalue { %"compiler/source:Span", i32, i32 } %t359, i32 0, 1
  %t363 = insertvalue { %"compiler/source:Span", i32, i32 } %t361, i32 %t354, 2
  %t364 = getelementptr { i64, [3 x i64] }, ptr %t356, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t363, ptr %t364
  %t365 = load { i64, [3 x i64] }, ptr %t356
  %t367 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t365, ptr %t367
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t350, ptr %t367)
  br label %bb52
bb52:
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t372 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t370)
  store ptr %t372, ptr %l203
  br label %bb53
bb53:
  %t373 = load ptr, ptr %l203, !tbaa !29
  %t375 = getelementptr %"compiler/check:frame", ptr %t373, i32 0, i32 11
  %t377 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t375)
  %t378 = extractvalue { i32, i64 } %t377, 1
  %t379 = extractvalue { i32, i64 } %t377, 0
  store i32 %t379, ptr %l207
  %t380 = icmp ne i32 %t379, 0
  br i1 %t380, label %bb55, label %ok.381
ok.381:
  store i64 %t378, ptr %l206
  br label %bb54
bb54:
  %t382 = load i64, ptr %l206, !tbaa !24
  store i64 %t382, ptr %l201, !tbaa !24
  br label %bb57
bb55:
  br label %bb56
bb56:
  call void @__olang_ert_req_clear()
  br label %bb57
bb57:
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t384 = load i64, ptr %l8, !tbaa !24
  %t385 = load i64, ptr %l9, !tbaa !24
  %t386 = load i64, ptr %l10, !tbaa !24
  %t387 = load i64, ptr %l6, !tbaa !24
  %t393 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t383, i64 %t384, i64 %t385, i64 %t386, i64 %t387)
  store ptr %t393, ptr %l213
  br label %bb58
bb58:
  %t394 = load ptr, ptr %l213, !tbaa !29
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t396 = load %"compiler/source:Span", ptr %l1
  store { i64, [3 x i64] } zeroinitializer, ptr %t398
  %t399 = getelementptr { i64, [3 x i64] }, ptr %t398, i32 0, i32 0
  store i64 4, ptr %t399
  %t401 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t396, 0
  %t403 = insertvalue { %"compiler/source:Span", ptr, ptr } %t401, ptr %t394, 1
  %t404 = insertvalue { %"compiler/source:Span", ptr, ptr } %t403, ptr null, 2
  %t405 = getelementptr { i64, [3 x i64] }, ptr %t398, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t404, ptr %t405
  %t406 = load { i64, [3 x i64] }, ptr %t398
  %t408 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t406, ptr %t408
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t395, ptr %t408)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrolledCompr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, %"compiler/check:reflList" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca %"compiler/check:reflList"
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i1
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l24 = alloca i32
  %l25 = alloca ptr
  %l28 = alloca %"compiler/source:Span"
  %l30 = alloca { i64, ptr }
  %l33 = alloca i64
  %l39 = alloca i64
  %l42 = alloca i64
  %l60 = alloca ptr
  %l62 = alloca i32
  %l67 = alloca i32
  %l68 = alloca i32
  %l69 = alloca ptr
  %l71 = alloca i32
  %l74 = alloca ptr
  %l76 = alloca i32
  %l78 = alloca i32
  %l79 = alloca i32
  %l87 = alloca i64
  %l90 = alloca ptr
  %l96 = alloca %"compiler/source:Span"
  %l97 = alloca %"compiler/msgs:Msg"
  %l98 = alloca i64
  %l106 = alloca ptr
  %l109 = alloca i1
  %l111 = alloca ptr
  %l113 = alloca ptr
  %l116 = alloca %"compiler/source:Span"
  %l118 = alloca i1
  %l137 = alloca { i64, ptr }
  %l140 = alloca ptr
  %l141 = alloca i32
  %l144 = alloca ptr
  %l146 = alloca i32
  %l148 = alloca i32
  %l149 = alloca i32
  %l150 = alloca %"compiler/source:Span"
  %l151 = alloca i32
  %l152 = alloca i32
  %l153 = alloca { i64, ptr }
  %l157 = alloca i32
  %l159 = alloca %"compiler/typed:Make"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca ptr
  %t288 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store %"compiler/check:reflList" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t4 = getelementptr %"compiler/ast:Compr", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t8 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store i32 %t8, ptr %l24
  br label %bb1
bb1:
  %t9 = load i32, ptr %l24, !tbaa !23
  store i32 %t9, ptr %l4, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l25, !tbaa !29
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = getelementptr %"compiler/ast:Compr", ptr %t11, i32 0, i32 4
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t14)
  store %"compiler/source:Span" %t16, ptr %l28
  br label %bb2
bb2:
  %t17 = load %"compiler/check:reflList", ptr %l3
  %t18 = load ptr, ptr %l25, !tbaa !29
  %t19 = load %"compiler/source:Span", ptr %l28
  %t21 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistItems(ptr %v0, ptr %s0, ptr %t18, %"compiler/source:Span" %t19, %"compiler/check:reflList" %t17)
  store { i64, ptr } %t21, ptr %l30
  br label %bb3
bb3:
  %t22 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t22, ptr %l5, !tbaa !27
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 32
  %t27 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t25)
  store i64 %t27, ptr %l33
  br label %bb4
bb4:
  %t28 = load i64, ptr %l33, !tbaa !24
  store i64 %t28, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  store i64 %t31, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t33 = load i64, ptr %l9, !tbaa !24
  %t34 = load i64, ptr %l8, !tbaa !24
  %t37 = icmp sgt i64 %t33, %t34
  br i1 %t37, label %bb5, label %bb6
bb5:
  %t39 = load i64, ptr %l10, !tbaa !24
  %t41 = icmp sgt i64 %t39, 0
  br i1 %t41, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb10
bb7:
  %t43 = load i64, ptr %l9, !tbaa !24
  %t44 = load i64, ptr %l8, !tbaa !24
  %t47 = sub i64 %t43, %t44
  %t48 = load i64, ptr %l10, !tbaa !24
  %t51 = add i64 %t47, %t48
  %t53 = sub i64 %t51, 1
  %t54 = load i64, ptr %l10, !tbaa !24
  %t57 = sdiv i64 %t53, %t54
  store i64 %t57, ptr %l42, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb9
bb9:
  %t59 = load i64, ptr %l42, !tbaa !24
  store i64 %t59, ptr %l39, !tbaa !24
  br label %bb10
bb10:
  %t60 = load i64, ptr %l39, !tbaa !24
  store i64 %t60, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t61 = load i64, ptr %l12, !tbaa !24
  %t62 = load i64, ptr %l11, !tbaa !24
  %t65 = icmp slt i64 %t61, %t62
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb47
bb13:
  br label %bb14
bb14:
  %t69 = load i64, ptr %l8, !tbaa !24
  %t70 = load i64, ptr %l12, !tbaa !24
  %t71 = load i64, ptr %l10, !tbaa !24
  %t74 = mul i64 %t70, %t71
  %t77 = add i64 %t69, %t74
  store i64 %t77, ptr %l13, !tbaa !24
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l60, !tbaa !29
  %t80 = load ptr, ptr %l2, !tbaa !29
  %t82 = getelementptr %"compiler/ast:Compr", ptr %t80, i32 0, i32 3
  %t83 = load i32, ptr %t82, !tbaa !23
  store i32 %t83, ptr %l62, !tbaa !23
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load %"compiler/check:reflList", ptr %l3
  %t86 = load i64, ptr %l13, !tbaa !24
  %t88 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr i64, ptr %t89, i64 %t86
  %t91 = load i64, ptr %t90, !tbaa !34
  %t95 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescriptor(ptr %v0, ptr %t84, %"compiler/check:reflList" %t85, i64 %t91)
  store i32 %t95, ptr %l67
  br label %bb15
bb15:
  %t96 = load ptr, ptr %l60, !tbaa !29
  %t97 = load i32, ptr %l62, !tbaa !23
  %t98 = load i32, ptr %l67, !tbaa !23
  %t99 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflBind(ptr %v0, ptr %t96, i32 %t97, i32 %t98)
  store i32 %t99, ptr %l68
  br label %bb16
bb16:
  %t100 = load i32, ptr %l68, !tbaa !23
  store i32 %t100, ptr %l14, !tbaa !23
  %t101 = load ptr, ptr %l0, !tbaa !29
  store ptr %t101, ptr %l69, !tbaa !29
  %t102 = load ptr, ptr %l2, !tbaa !29
  %t104 = getelementptr %"compiler/ast:Compr", ptr %t102, i32 0, i32 2
  %t105 = load i32, ptr %t104, !tbaa !23
  store i32 %t105, ptr %l71, !tbaa !23
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/generic:Program", ptr %t109, i32 0, i32 2
  store ptr %t111, ptr %l74, !tbaa !29
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t112)
  store i32 %t114, ptr %l76
  br label %bb17
bb17:
  %t115 = load i64, ptr %l13, !tbaa !24
  %t116 = load ptr, ptr %l74, !tbaa !29
  %t117 = load i32, ptr %l76, !tbaa !23
  %t119 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t116, i32 %t117, i64 %t115)
  store i32 %t119, ptr %l78
  br label %bb18
bb18:
  %t120 = load ptr, ptr %l69, !tbaa !29
  %t121 = load i32, ptr %l71, !tbaa !23
  %t122 = load i32, ptr %l78, !tbaa !23
  %t123 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflBind(ptr %v0, ptr %t120, i32 %t121, i32 %t122)
  store i32 %t123, ptr %l79
  br label %bb19
bb19:
  %t124 = load i32, ptr %l79, !tbaa !23
  store i32 %t124, ptr %l15, !tbaa !23
  store i1 true, ptr %l16, !tbaa !21
  %t125 = load ptr, ptr %l2, !tbaa !29
  %t127 = getelementptr %"compiler/ast:Compr", ptr %t125, i32 0, i32 5
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t130 = icmp eq ptr %t128, null
  %t132 = xor i1 %t130, true
  br i1 %t132, label %bb20, label %bb21
bb20:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load ptr, ptr %l2, !tbaa !29
  %t137 = getelementptr %"compiler/ast:Compr", ptr %t135, i32 0, i32 5
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t141 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDecide(ptr %v0, ptr %v1, ptr %t134, ptr %t138)
  store i64 %t141, ptr %l87
  br label %bb22
bb21:
  br label %bb32
bb22:
  %t142 = load i64, ptr %l87, !tbaa !24
  store i64 %t142, ptr %l17, !tbaa !24
  %t143 = load i64, ptr %l17, !tbaa !24
  %t145 = icmp slt i64 %t143, 0
  br i1 %t145, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  %t147 = load ptr, ptr %l0, !tbaa !29
  store ptr %t147, ptr %l90, !tbaa !29
  %t148 = load ptr, ptr %l2, !tbaa !29
  %t150 = getelementptr %"compiler/ast:Compr", ptr %t148, i32 0, i32 5
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = icmp eq ptr %t151, null
  br i1 %t153, label %bb25, label %bb26
bb24:
  %t155 = load i64, ptr %l17, !tbaa !24
  %t157 = icmp eq i64 %t155, 1
  store i1 %t157, ptr %l16, !tbaa !21
  br label %bb31
bb25:
  call void @__olang_check_failed(ptr @olang_loc_ef99e54d7427d8e6_6c42201a9dddf792)
  unreachable
bb26:
  br label %bb27
bb27:
  %t159 = load ptr, ptr %l2, !tbaa !29
  %t161 = getelementptr %"compiler/ast:Compr", ptr %t159, i32 0, i32 5
  %t162 = load ptr, ptr %t161, !tbaa !29
  %t164 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t162)
  store %"compiler/source:Span" %t164, ptr %l96
  br label %bb28
bb28:
  %t165 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflFilterUndecided(ptr %s4)
  store %"compiler/msgs:Msg" %t165, ptr %l97
  br label %bb29
bb29:
  %t166 = load ptr, ptr %l90, !tbaa !29
  %t167 = load %"compiler/source:Span", ptr %l96
  %t168 = load %"compiler/msgs:Msg", ptr %l97
  %t169 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t166, %"compiler/source:Span" %t167, %"compiler/msgs:Msg" %t168)
  store i64 %t169, ptr %l98
  br label %bb30
bb30:
  store i1 false, ptr %l16, !tbaa !21
  call void @__olang_scope_close(ptr %s4)
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t170 = load i1, ptr %l16, !tbaa !21
  br i1 %t170, label %bb33, label %bb34
bb33:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load ptr, ptr %l2, !tbaa !29
  %t175 = getelementptr %"compiler/ast:Compr", ptr %t173, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !29
  %t177 = load i32, ptr %l4, !tbaa !23
  %t181 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %t172, ptr %t176, i32 %t177)
  store ptr %t181, ptr %l106
  br label %bb35
bb34:
  br label %bb43
bb35:
  %t182 = load ptr, ptr %l106, !tbaa !29
  store ptr %t182, ptr %l18, !tbaa !29
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load i32, ptr %l4, !tbaa !23
  %t187 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t183, i32 %t184)
  store i1 %t187, ptr %l109
  br label %bb36
bb36:
  %t188 = load i1, ptr %l109, !tbaa !21
  %t189 = xor i1 %t188, true
  br i1 %t189, label %bb37, label %bb38
bb37:
  %t191 = load ptr, ptr %l0, !tbaa !29
  store ptr %t191, ptr %l111, !tbaa !29
  %t192 = load ptr, ptr %l18, !tbaa !29
  store ptr %t192, ptr %l113, !tbaa !29
  %t194 = load ptr, ptr %l2, !tbaa !29
  %t196 = getelementptr %"compiler/ast:Compr", ptr %t194, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !29
  %t199 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t197)
  store %"compiler/source:Span" %t199, ptr %l116
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t200 = load i64, ptr @G_2ecompiler_2fcheck_2eRoStored, !tbaa !24
  %t201 = load ptr, ptr %l111, !tbaa !29
  %t202 = load ptr, ptr %l113, !tbaa !29
  %t203 = load %"compiler/source:Span", ptr %l116
  %t205 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v0, ptr %t201, ptr %t202, %"compiler/source:Span" %t203, i64 %t200)
  store i1 %t205, ptr %l118
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/check:Checker", ptr %t206, i32 0, i32 32
  %t209 = load ptr, ptr %l18, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t208, ptr %t209)
  br label %bb42
bb42:
  %t212 = load i64, ptr %l7, !tbaa !24
  %t214 = add i64 %t212, 1
  store i64 %t214, ptr %l7, !tbaa !24
  br label %bb43
bb43:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = load ptr, ptr %l2, !tbaa !29
  %t219 = getelementptr %"compiler/ast:Compr", ptr %t217, i32 0, i32 2
  %t220 = load i32, ptr %t219, !tbaa !23
  %t221 = load i32, ptr %l15, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflUnbind(ptr %v0, ptr %t216, i32 %t220, i32 %t221)
  br label %bb44
bb44:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load ptr, ptr %l2, !tbaa !29
  %t228 = getelementptr %"compiler/ast:Compr", ptr %t226, i32 0, i32 3
  %t229 = load i32, ptr %t228, !tbaa !23
  %t230 = load i32, ptr %l14, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflUnbind(ptr %v0, ptr %t225, i32 %t229, i32 %t230)
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s2)
  br label %bb46
bb46:
  %t234 = load i64, ptr %l12, !tbaa !24
  %t236 = add i64 %t234, 1
  store i64 %t236, ptr %l12, !tbaa !24
  br label %bb11
bb47:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/check:Checker", ptr %t238, i32 0, i32 32
  %t241 = load i64, ptr %l6, !tbaa !24
  %t244 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t240, i64 %t241)
  store { i64, ptr } %t244, ptr %l137
  br label %bb48
bb48:
  %t245 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t245, ptr %l19, !tbaa !27
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t248 = getelementptr %"compiler/check:Checker", ptr %t246, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !29
  %t251 = getelementptr %"compiler/generic:Program", ptr %t249, i32 0, i32 2
  store ptr %t251, ptr %l140, !tbaa !29
  %t252 = load i32, ptr %l4, !tbaa !23
  store i32 %t252, ptr %l141, !tbaa !23
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/check:Checker", ptr %t253, i32 0, i32 1
  %t256 = load ptr, ptr %t255, !tbaa !29
  %t258 = getelementptr %"compiler/generic:Program", ptr %t256, i32 0, i32 2
  store ptr %t258, ptr %l144, !tbaa !29
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t261 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t259)
  store i32 %t261, ptr %l146
  br label %bb49
bb49:
  %t262 = load i64, ptr %l7, !tbaa !24
  %t263 = load ptr, ptr %l144, !tbaa !29
  %t264 = load i32, ptr %l146, !tbaa !23
  %t266 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t263, i32 %t264, i64 %t262)
  store i32 %t266, ptr %l148
  br label %bb50
bb50:
  %t267 = load ptr, ptr %l140, !tbaa !29
  %t268 = load i32, ptr %l141, !tbaa !23
  %t269 = load i32, ptr %l148, !tbaa !23
  %t270 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t267, i32 %t268, i32 %t269)
  store i32 %t270, ptr %l149
  br label %bb51
bb51:
  %t271 = load i32, ptr %l149, !tbaa !23
  %t272 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t272, ptr %l150
  store i32 %t271, ptr %l151, !tbaa !23
  store i32 2, ptr %l152
  %t274 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t274, ptr %l153, !tbaa !27
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t276 = load %"compiler/source:Span", ptr %l1
  %t280 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t275, i32 1, %"compiler/source:Span" %t276)
  store i32 %t280, ptr %l157
  br label %bb52
bb52:
  %t281 = load i32, ptr %l152
  %t282 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t283 = load i32, ptr %l157, !tbaa !23
  %t285 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t281, i64 0, { i64, ptr } %t282, ptr null, i32 %t283, i32 0)
  store %"compiler/typed:Make" %t285, ptr %l159
  br label %bb53
bb53:
  %t286 = load %"compiler/typed:Make", ptr %l159
  %t287 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store %"compiler/typed:Make" %t286, ptr %t287
  store { i64, [5 x i64] } zeroinitializer, ptr %t288
  %t289 = getelementptr { i64, [5 x i64] }, ptr %t288, i32 0, i32 0
  store i64 7, ptr %t289
  %t290 = load %"compiler/source:Span", ptr %l150
  %t291 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t290, 0
  %t292 = load i32, ptr %l151, !tbaa !23
  %t293 = insertvalue { %"compiler/source:Span", i32, ptr } %t291, i32 %t292, 1
  %t295 = insertvalue { %"compiler/source:Span", i32, ptr } %t293, ptr %t287, 2
  %t296 = getelementptr { i64, [5 x i64] }, ptr %t288, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t295, ptr %t296
  %t297 = load { i64, [5 x i64] }, ptr %t288
  %t299 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t297, ptr %t299
  call void @__olang_scope_close(ptr %s0)
  store ptr %t299, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunwrapNull(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %lp10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %lp15 = alloca ptr
  %l16 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca i1
  %l31 = alloca i1
  %l34 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca %"compiler/source:Span"
  %l37 = alloca i32
  %l38 = alloca i32
  %l39 = alloca ptr
  %l43 = alloca ptr
  %l45 = alloca ptr
  %l48 = alloca i64
  %l56 = alloca ptr
  %l60 = alloca i32
  %l64 = alloca { i64, ptr }
  %l65 = alloca %"compiler/typed:Block"
  %l67 = alloca ptr
  %l68 = alloca %"compiler/source:Span"
  %l71 = alloca %"compiler/typed:If"
  %l75 = alloca %"compiler/source:Span"
  %l80 = alloca i32
  %l84 = alloca { i64, ptr }
  %l85 = alloca %"compiler/source:Span"
  %l90 = alloca i32
  %l95 = alloca %"compiler/typed:Seq"
  %l101 = alloca i64
  %l107 = alloca i64
  %l120 = alloca ptr
  %l121 = alloca %"compiler/source:Span"
  %l122 = alloca i32
  %l123 = alloca i32
  %l127 = alloca ptr
  %l131 = alloca ptr
  %l133 = alloca ptr
  %l136 = alloca i64
  %l144 = alloca ptr
  %l148 = alloca i32
  %l152 = alloca { i64, ptr }
  %l153 = alloca %"compiler/typed:Block"
  %l155 = alloca ptr
  %l156 = alloca %"compiler/source:Span"
  %l159 = alloca %"compiler/typed:If"
  %l163 = alloca ptr
  %l164 = alloca %"compiler/source:Span"
  %l165 = alloca %"compiler/source:Span"
  %l170 = alloca i32
  %l176 = alloca ptr
  %l177 = alloca %"compiler/source:Span"
  %l182 = alloca i32
  %l186 = alloca { i64, ptr }
  %l189 = alloca %"compiler/typed:Seq"
  %rv = alloca ptr
  %t73 = alloca { i64, [3 x i64] }, align 8
  %t120 = alloca { i64, [3 x i64] }, align 8
  %t163 = alloca { i64, [5 x i64] }, align 8
  %t182 = alloca { i64, [5 x i64] }, align 8
  %t204 = alloca { i64, [2 x i64] }, align 8
  %t229 = alloca { i64, [3 x i64] }, align 8
  %t279 = alloca { i64, [3 x i64] }, align 8
  %t326 = alloca { i64, [3 x i64] }, align 8
  %t355 = alloca { i64, [4 x i64] }, align 8
  %t397 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1)
  store i32 %t4, ptr %l19
  br label %bb1
bb1:
  %t5 = load i32, ptr %l19, !tbaa !23
  store i32 %t5, ptr %l3, !tbaa !23
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t7 = load ptr, ptr %l20, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = load ptr, ptr %l20, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 2
  store i1 %t13, ptr %l21, !tbaa !21
  br label %bb3
bb3:
  %t14 = load i1, ptr %l21, !tbaa !21
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t17, i32 0, i32 0
  %t19 = load %"compiler/source:Span", ptr %t18
  store %"compiler/source:Span" %t19, ptr %l4
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr { i64, [5 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t23, i32 0, i32 2
  %t25 = load ptr, ptr %t24
  store ptr %t25, ptr %l5, !tbaa !29
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t29 = getelementptr { i64, [5 x i64] }, ptr %t27, i32 0, i32 1
  %t30 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t29, i32 0, i32 3
  %t31 = load i32, ptr %t30
  store i32 %t31, ptr %l6, !tbaa !23
  br label %bb6
bb5:
  br label %bb25
bb6:
  %t33 = load ptr, ptr %l5, !tbaa !29
  %t35 = call i1 @compiler_2fcheck_2epurePlace(ptr %v0, ptr %t33)
  store i1 %t35, ptr %l31
  br label %bb7
bb7:
  %t36 = load i1, ptr %l31, !tbaa !21
  br i1 %t36, label %bb8, label %bb9
bb8:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 33
  %t41 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t39)
  store i64 %t41, ptr %l34
  br label %bb10
bb9:
  br label %bb24
bb10:
  %t42 = load i64, ptr %l34, !tbaa !24
  store i64 %t42, ptr %l7, !tbaa !24
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l35, !tbaa !29
  %t44 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t44, ptr %l36
  %t45 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t45, ptr %l37, !tbaa !23
  store i32 19, ptr %l38
  %t46 = load ptr, ptr %l2, !tbaa !29
  store ptr %t46, ptr %l39, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load %"compiler/source:Span", ptr %l1
  %t49 = load i32, ptr %l3, !tbaa !23
  %t53 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t47, %"compiler/source:Span" %t48, i32 %t49, i64 0)
  store ptr %t53, ptr %l43
  br label %bb11
bb11:
  %t54 = load ptr, ptr %l43, !tbaa !29
  %t55 = load ptr, ptr %l35, !tbaa !29
  %t56 = load %"compiler/source:Span", ptr %l36
  %t57 = load i32, ptr %l37, !tbaa !23
  %t58 = load i32, ptr %l38
  %t59 = load ptr, ptr %l39, !tbaa !29
  %t61 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t55, %"compiler/source:Span" %t56, i32 %t57, i32 %t58, ptr %t59, ptr %t54)
  store ptr %t61, ptr %l45
  br label %bb12
bb12:
  %t62 = load ptr, ptr %l45, !tbaa !29
  store ptr %t62, ptr %l8, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 33
  %t67 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t65)
  store i64 %t67, ptr %l48
  br label %bb13
bb13:
  %t68 = load i64, ptr %l48, !tbaa !24
  store i64 %t68, ptr %l9, !tbaa !24
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 33
  %t72 = load %"compiler/source:Span", ptr %l1
  store { i64, [3 x i64] } zeroinitializer, ptr %t73
  %t74 = getelementptr { i64, [3 x i64] }, ptr %t73, i32 0, i32 0
  store i64 9, ptr %t74
  %t76 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t72, 0
  %t78 = insertvalue { %"compiler/source:Span", i32, ptr } %t76, i32 1, 1
  %t79 = insertvalue { %"compiler/source:Span", i32, ptr } %t78, ptr null, 2
  %t80 = getelementptr { i64, [3 x i64] }, ptr %t73, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t79, ptr %t80
  %t81 = load { i64, [3 x i64] }, ptr %t73
  %t83 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t81, ptr %t83
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v0, ptr %t71, ptr %t83)
  br label %bb14
bb14:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t86)
  store ptr %t88, ptr %l56
  br label %bb15
bb15:
  %t89 = load ptr, ptr %l56, !tbaa !29
  %t91 = getelementptr %"compiler/check:frame", ptr %t89, i32 0, i32 7
  %t92 = load i64, ptr %t91, !tbaa !24
  %t94 = trunc i64 %t92 to i32
  store i32 %t94, ptr %l60, !tbaa !23
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/check:Checker", ptr %t96, i32 0, i32 33
  %t99 = load i64, ptr %l9, !tbaa !24
  %t102 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t98, i64 %t99)
  store { i64, ptr } %t102, ptr %l64
  br label %bb16
bb16:
  %t103 = load i32, ptr %l60, !tbaa !23
  %t104 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t105 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 %t103, { i64, ptr } %t104)
  store %"compiler/typed:Block" %t105, ptr %l65
  br label %bb17
bb17:
  %t106 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store ptr %t106, ptr %lp10
  %t107 = load %"compiler/typed:Block", ptr %l65
  %t108 = load ptr, ptr %lp10
  store %"compiler/typed:Block" %t107, ptr %t108
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/check:Checker", ptr %t109, i32 0, i32 33
  store ptr %t111, ptr %l67, !tbaa !29
  %t112 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t112, ptr %l68
  %t113 = load ptr, ptr %l8, !tbaa !29
  %t114 = load ptr, ptr %lp10
  %t117 = call %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t113, ptr %t114, ptr null)
  store %"compiler/typed:If" %t117, ptr %l71
  br label %bb18
bb18:
  %t118 = load %"compiler/typed:If", ptr %l71
  %t119 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:If" %t118, ptr %t119
  store { i64, [3 x i64] } zeroinitializer, ptr %t120
  %t121 = getelementptr { i64, [3 x i64] }, ptr %t120, i32 0, i32 0
  store i64 3, ptr %t121
  %t122 = load %"compiler/source:Span", ptr %l68
  %t123 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t122, 0
  %t125 = insertvalue { %"compiler/source:Span", ptr } %t123, ptr %t119, 1
  %t126 = getelementptr { i64, [3 x i64] }, ptr %t120, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t125, ptr %t126
  %t127 = load { i64, [3 x i64] }, ptr %t120
  %t129 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t127, ptr %t129
  %t130 = load ptr, ptr %l67, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v0, ptr %t130, ptr %t129)
  br label %bb19
bb19:
  %t132 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t132, ptr %l75
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/check:Checker", ptr %t133, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t138 = getelementptr %"compiler/generic:Program", ptr %t136, i32 0, i32 2
  %t139 = load i32, ptr %l3, !tbaa !23
  %t142 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %t138, i32 %t139)
  store i32 %t142, ptr %l80
  br label %bb20
bb20:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/check:Checker", ptr %t143, i32 0, i32 33
  %t146 = load i64, ptr %l7, !tbaa !24
  %t149 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t145, i64 %t146)
  store { i64, ptr } %t149, ptr %l84
  br label %bb21
bb21:
  %t150 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t150, ptr %l85
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/check:Checker", ptr %t151, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t156 = getelementptr %"compiler/generic:Program", ptr %t154, i32 0, i32 2
  %t157 = load i32, ptr %l3, !tbaa !23
  %t160 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %t156, i32 %t157)
  store i32 %t160, ptr %l90
  br label %bb22
bb22:
  %t161 = load ptr, ptr %l5, !tbaa !29
  %t162 = load i32, ptr %l6, !tbaa !23
  store { i64, [5 x i64] } zeroinitializer, ptr %t163
  %t164 = getelementptr { i64, [5 x i64] }, ptr %t163, i32 0, i32 0
  store i64 2, ptr %t164
  %t165 = load %"compiler/source:Span", ptr %l85
  %t166 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t165, 0
  %t167 = load i32, ptr %l90, !tbaa !23
  %t168 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t166, i32 %t167, 1
  %t170 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t168, ptr %t161, 2
  %t172 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t170, i32 %t162, 3
  %t173 = getelementptr { i64, [5 x i64] }, ptr %t163, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t172, ptr %t173
  %t174 = load { i64, [5 x i64] }, ptr %t163
  %t176 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t174, ptr %t176
  %t177 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t179 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t177, ptr %t176)
  store %"compiler/typed:Seq" %t179, ptr %l95
  br label %bb23
bb23:
  %t180 = load %"compiler/typed:Seq", ptr %l95
  %t181 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Seq" %t180, ptr %t181
  store { i64, [5 x i64] } zeroinitializer, ptr %t182
  %t183 = getelementptr { i64, [5 x i64] }, ptr %t182, i32 0, i32 0
  store i64 12, ptr %t183
  %t184 = load %"compiler/source:Span", ptr %l75
  %t185 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t184, 0
  %t186 = load i32, ptr %l80, !tbaa !23
  %t187 = insertvalue { %"compiler/source:Span", i32, ptr } %t185, i32 %t186, 1
  %t189 = insertvalue { %"compiler/source:Span", i32, ptr } %t187, ptr %t181, 2
  %t190 = getelementptr { i64, [5 x i64] }, ptr %t182, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t189, ptr %t190
  %t191 = load { i64, [5 x i64] }, ptr %t182
  %t193 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t191, ptr %t193
  store ptr %t193, ptr %rv
  br label %ret
bb24:
  br label %bb26
bb25:
  br label %bb26
bb26:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/check:Checker", ptr %t195, i32 0, i32 33
  %t199 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t197)
  store i64 %t199, ptr %l101
  br label %bb27
bb27:
  %t200 = load i64, ptr %l101, !tbaa !24
  store i64 %t200, ptr %l11, !tbaa !24
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load %"compiler/source:Span", ptr %l1
  %t203 = load i32, ptr %l3, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t204
  %t205 = getelementptr { i64, [2 x i64] }, ptr %t204, i32 0, i32 0
  store i64 5, ptr %t205
  %t206 = load { i64, [2 x i64] }, ptr %t204
  %t212 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t201, i32 0, %"compiler/source:Span" %t202, i32 %t203, i32 1, { i64, [2 x i64] } %t206)
  store i64 %t212, ptr %l107
  br label %bb28
bb28:
  %t213 = load i64, ptr %l107, !tbaa !24
  store i64 %t213, ptr %l12, !tbaa !24
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load i64, ptr %l12, !tbaa !24
  %t216 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v0, ptr %t214, i64 %t215, ptr %t216)
  br label %bb29
bb29:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"compiler/check:Checker", ptr %t220, i32 0, i32 33
  %t223 = load %"compiler/source:Span", ptr %l1
  %t224 = load i64, ptr %l12, !tbaa !24
  %t226 = trunc i64 %t224 to i32
  %t228 = load ptr, ptr %l2, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t229
  %t230 = getelementptr { i64, [3 x i64] }, ptr %t229, i32 0, i32 0
  store i64 0, ptr %t230
  %t232 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t223, 0
  %t234 = insertvalue { %"compiler/source:Span", i32, ptr } %t232, i32 %t226, 1
  %t236 = insertvalue { %"compiler/source:Span", i32, ptr } %t234, ptr %t228, 2
  %t237 = getelementptr { i64, [3 x i64] }, ptr %t229, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t236, ptr %t237
  %t238 = load { i64, [3 x i64] }, ptr %t229
  %t240 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t238, ptr %t240
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v0, ptr %t222, ptr %t240)
  br label %bb30
bb30:
  %t243 = load ptr, ptr %l0, !tbaa !29
  store ptr %t243, ptr %l120, !tbaa !29
  %t244 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t244, ptr %l121
  %t245 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t245, ptr %l122, !tbaa !23
  store i32 19, ptr %l123
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t247 = load %"compiler/source:Span", ptr %l1
  %t248 = load i64, ptr %l12, !tbaa !24
  %t252 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t246, %"compiler/source:Span" %t247, i64 %t248)
  store ptr %t252, ptr %l127
  br label %bb31
bb31:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t254 = load %"compiler/source:Span", ptr %l1
  %t255 = load i32, ptr %l3, !tbaa !23
  %t259 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t253, %"compiler/source:Span" %t254, i32 %t255, i64 0)
  store ptr %t259, ptr %l131
  br label %bb32
bb32:
  %t260 = load ptr, ptr %l131, !tbaa !29
  %t261 = load ptr, ptr %l120, !tbaa !29
  %t262 = load %"compiler/source:Span", ptr %l121
  %t263 = load i32, ptr %l122, !tbaa !23
  %t264 = load i32, ptr %l123
  %t265 = load ptr, ptr %l127, !tbaa !29
  %t267 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t261, %"compiler/source:Span" %t262, i32 %t263, i32 %t264, ptr %t265, ptr %t260)
  store ptr %t267, ptr %l133
  br label %bb33
bb33:
  %t268 = load ptr, ptr %l133, !tbaa !29
  store ptr %t268, ptr %l13, !tbaa !29
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"compiler/check:Checker", ptr %t269, i32 0, i32 33
  %t273 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t271)
  store i64 %t273, ptr %l136
  br label %bb34
bb34:
  %t274 = load i64, ptr %l136, !tbaa !24
  store i64 %t274, ptr %l14, !tbaa !24
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t277 = getelementptr %"compiler/check:Checker", ptr %t275, i32 0, i32 33
  %t278 = load %"compiler/source:Span", ptr %l1
  store { i64, [3 x i64] } zeroinitializer, ptr %t279
  %t280 = getelementptr { i64, [3 x i64] }, ptr %t279, i32 0, i32 0
  store i64 9, ptr %t280
  %t282 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t278, 0
  %t284 = insertvalue { %"compiler/source:Span", i32, ptr } %t282, i32 1, 1
  %t285 = insertvalue { %"compiler/source:Span", i32, ptr } %t284, ptr null, 2
  %t286 = getelementptr { i64, [3 x i64] }, ptr %t279, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t285, ptr %t286
  %t287 = load { i64, [3 x i64] }, ptr %t279
  %t289 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t287, ptr %t289
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v0, ptr %t277, ptr %t289)
  br label %bb35
bb35:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t292)
  store ptr %t294, ptr %l144
  br label %bb36
bb36:
  %t295 = load ptr, ptr %l144, !tbaa !29
  %t297 = getelementptr %"compiler/check:frame", ptr %t295, i32 0, i32 7
  %t298 = load i64, ptr %t297, !tbaa !24
  %t300 = trunc i64 %t298 to i32
  store i32 %t300, ptr %l148, !tbaa !23
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t304 = getelementptr %"compiler/check:Checker", ptr %t302, i32 0, i32 33
  %t305 = load i64, ptr %l14, !tbaa !24
  %t308 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t304, i64 %t305)
  store { i64, ptr } %t308, ptr %l152
  br label %bb37
bb37:
  %t309 = load i32, ptr %l148, !tbaa !23
  %t310 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t311 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 %t309, { i64, ptr } %t310)
  store %"compiler/typed:Block" %t311, ptr %l153
  br label %bb38
bb38:
  %t312 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store ptr %t312, ptr %lp15
  %t313 = load %"compiler/typed:Block", ptr %l153
  %t314 = load ptr, ptr %lp15
  store %"compiler/typed:Block" %t313, ptr %t314
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t317 = getelementptr %"compiler/check:Checker", ptr %t315, i32 0, i32 33
  store ptr %t317, ptr %l155, !tbaa !29
  %t318 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t318, ptr %l156
  %t319 = load ptr, ptr %l13, !tbaa !29
  %t320 = load ptr, ptr %lp15
  %t323 = call %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t319, ptr %t320, ptr null)
  store %"compiler/typed:If" %t323, ptr %l159
  br label %bb39
bb39:
  %t324 = load %"compiler/typed:If", ptr %l159
  %t325 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:If" %t324, ptr %t325
  store { i64, [3 x i64] } zeroinitializer, ptr %t326
  %t327 = getelementptr { i64, [3 x i64] }, ptr %t326, i32 0, i32 0
  store i64 3, ptr %t327
  %t328 = load %"compiler/source:Span", ptr %l156
  %t329 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t328, 0
  %t331 = insertvalue { %"compiler/source:Span", ptr } %t329, ptr %t325, 1
  %t332 = getelementptr { i64, [3 x i64] }, ptr %t326, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t331, ptr %t332
  %t333 = load { i64, [3 x i64] }, ptr %t326
  %t335 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t333, ptr %t335
  %t336 = load ptr, ptr %l155, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v0, ptr %t336, ptr %t335)
  br label %bb40
bb40:
  %t338 = load ptr, ptr %l0, !tbaa !29
  store ptr %t338, ptr %l163, !tbaa !29
  %t339 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t339, ptr %l164
  %t340 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t340, ptr %l165
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t343 = getelementptr %"compiler/check:Checker", ptr %t341, i32 0, i32 1
  %t344 = load ptr, ptr %t343, !tbaa !29
  %t346 = getelementptr %"compiler/generic:Program", ptr %t344, i32 0, i32 2
  %t347 = load i32, ptr %l3, !tbaa !23
  %t350 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %t346, i32 %t347)
  store i32 %t350, ptr %l170
  br label %bb41
bb41:
  %t351 = load i64, ptr %l12, !tbaa !24
  %t353 = trunc i64 %t351 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t355
  %t356 = getelementptr { i64, [4 x i64] }, ptr %t355, i32 0, i32 0
  store i64 0, ptr %t356
  %t357 = load %"compiler/source:Span", ptr %l165
  %t358 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t357, 0
  %t359 = load i32, ptr %l170, !tbaa !23
  %t360 = insertvalue { %"compiler/source:Span", i32, i32 } %t358, i32 %t359, 1
  %t362 = insertvalue { %"compiler/source:Span", i32, i32 } %t360, i32 %t353, 2
  %t363 = getelementptr { i64, [4 x i64] }, ptr %t355, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t362, ptr %t363
  %t364 = load { i64, [4 x i64] }, ptr %t355
  %t366 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t364, ptr %t366
  %t367 = load ptr, ptr %l163, !tbaa !29
  %t368 = load %"compiler/source:Span", ptr %l164
  %t370 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t367, %"compiler/source:Span" %t368, ptr %t366)
  store ptr %t370, ptr %l176
  br label %bb42
bb42:
  %t371 = load ptr, ptr %l176, !tbaa !29
  store ptr %t371, ptr %l16, !tbaa !29
  %t372 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t372, ptr %l177
  %t373 = load ptr, ptr %l0, !tbaa !29
  %t375 = getelementptr %"compiler/check:Checker", ptr %t373, i32 0, i32 1
  %t376 = load ptr, ptr %t375, !tbaa !29
  %t378 = getelementptr %"compiler/generic:Program", ptr %t376, i32 0, i32 2
  %t379 = load i32, ptr %l3, !tbaa !23
  %t382 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %t378, i32 %t379)
  store i32 %t382, ptr %l182
  br label %bb43
bb43:
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t385 = getelementptr %"compiler/check:Checker", ptr %t383, i32 0, i32 33
  %t386 = load i64, ptr %l11, !tbaa !24
  %t389 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t385, i64 %t386)
  store { i64, ptr } %t389, ptr %l186
  br label %bb44
bb44:
  %t390 = load ptr, ptr %l16, !tbaa !29
  %t392 = load { i64, ptr }, ptr %l186, !tbaa !27
  %t394 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t392, ptr %t390)
  store %"compiler/typed:Seq" %t394, ptr %l189
  br label %bb45
bb45:
  %t395 = load %"compiler/typed:Seq", ptr %l189
  %t396 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Seq" %t395, ptr %t396
  store { i64, [5 x i64] } zeroinitializer, ptr %t397
  %t398 = getelementptr { i64, [5 x i64] }, ptr %t397, i32 0, i32 0
  store i64 12, ptr %t398
  %t399 = load %"compiler/source:Span", ptr %l177
  %t400 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t399, 0
  %t401 = load i32, ptr %l182, !tbaa !23
  %t402 = insertvalue { %"compiler/source:Span", i32, ptr } %t400, i32 %t401, 1
  %t404 = insertvalue { %"compiler/source:Span", i32, ptr } %t402, ptr %t396, 2
  %t405 = getelementptr { i64, [5 x i64] }, ptr %t397, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t404, ptr %t405
  %t406 = load { i64, [5 x i64] }, ptr %t397
  %t408 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t406, ptr %t408
  store ptr %t408, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTest(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l8 = alloca ptr
  %l11 = alloca i1
  %l12 = alloca i32
  %l15 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i1
  %l29 = alloca ptr
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l42 = alloca %"compiler/msgs:Msg"
  %l43 = alloca i64
  %l47 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca %"compiler/source:Span"
  %l50 = alloca %"compiler/source:Span"
  %l51 = alloca i32
  %l52 = alloca ptr
  %l56 = alloca ptr
  %l58 = alloca ptr
  %l59 = alloca ptr
  %l60 = alloca %"compiler/source:Span"
  %l62 = alloca %"compiler/source:Span"
  %l63 = alloca ptr
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  store ptr %t2, ptr %l8, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t5 = load i32, ptr %l4, !tbaa !23
  %t8 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t4, i32 %t5)
  store i1 %t8, ptr %l11
  br label %bb1
bb1:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l4, !tbaa !23
  %t14 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %t10, i32 %t11)
  store i32 %t14, ptr %l15
  br label %bb4
bb3:
  %t15 = load i32, ptr %l4, !tbaa !23
  store i32 %t15, ptr %l12, !tbaa !23
  br label %bb5
bb4:
  %t17 = load i32, ptr %l15, !tbaa !23
  store i32 %t17, ptr %l12, !tbaa !23
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l6, !tbaa !29
  %t19 = load ptr, ptr %l8, !tbaa !29
  %t20 = load i32, ptr %l12, !tbaa !23
  %t21 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t18, ptr %t19, i32 %t20)
  store ptr %t21, ptr %l17
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l17, !tbaa !29
  store ptr %t22, ptr %l5, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l18, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l4, !tbaa !23
  %t28 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t28, ptr %l21
  br label %bb7
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l22, !tbaa !29
  %t30 = load ptr, ptr %l5, !tbaa !29
  %t33 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t30)
  store i32 %t33, ptr %l25
  br label %bb8
bb8:
  %t34 = load ptr, ptr %l22, !tbaa !29
  %t35 = load i32, ptr %l25, !tbaa !23
  %t36 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t36, ptr %l26
  br label %bb9
bb9:
  %t37 = load ptr, ptr %l18, !tbaa !29
  %t38 = load i32, ptr %l21, !tbaa !23
  %t39 = load i32, ptr %l26, !tbaa !23
  %t40 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emeets(ptr %v0, ptr %t37, i32 %t38, i32 %t39)
  store i1 %t40, ptr %l27
  br label %bb10
bb10:
  %t41 = load i1, ptr %l27, !tbaa !21
  %t42 = xor i1 %t41, true
  br i1 %t42, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s1
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l29, !tbaa !29
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t47 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t45)
  store %"compiler/source:Span" %t47, ptr %l31
  br label %bb13
bb12:
  br label %bb20
bb13:
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l32, !tbaa !29
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i32, ptr %l4, !tbaa !23
  %t53 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t53, ptr %l35
  br label %bb14
bb14:
  %t54 = load ptr, ptr %l32, !tbaa !29
  %t55 = load i32, ptr %l35, !tbaa !23
  %t56 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t54, i32 %t55)
  store { i64, ptr } %t56, ptr %l36
  br label %bb15
bb15:
  %t57 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t57, 0
  %t59 = extractvalue { i64, ptr } %t57, 1
  %t60 = mul i64 %t58, 1
  %t61 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t60)
  call void @llvm.memcpy.p0.p0.i64(ptr %t61, ptr %t59, i64 %t60, i1 false)
  %t62 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t61, 1
  store { i64, ptr } %t63, ptr %l37, !tbaa !27
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l5, !tbaa !29
  %t68 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etyOf(ptr %v0, ptr %v0, ptr %s1, ptr %t64, ptr %t65)
  store { i64, ptr } %t68, ptr %l40
  br label %bb16
bb16:
  %t69 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  %t71 = extractvalue { i64, ptr } %t69, 1
  %t72 = mul i64 %t70, 1
  %t73 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t72)
  call void @llvm.memcpy.p0.p0.i64(ptr %t73, ptr %t71, i64 %t72, i1 false)
  %t74 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  %t76 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t78 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseValueType(ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %t76, { i64, ptr } %t75)
  store %"compiler/msgs:Msg" %t78, ptr %l42
  br label %bb17
bb17:
  %t79 = load ptr, ptr %l29, !tbaa !29
  %t80 = load %"compiler/source:Span", ptr %l31
  %t81 = load %"compiler/msgs:Msg", ptr %l42
  %t82 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t79, %"compiler/source:Span" %t80, %"compiler/msgs:Msg" %t81)
  store i64 %t82, ptr %l43
  br label %bb18
bb18:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load %"compiler/source:Span", ptr %l1
  %t85 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t89 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t83, %"compiler/source:Span" %t84, i32 %t85, i64 0)
  store ptr %t89, ptr %l47
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s1)
  %t90 = load ptr, ptr %l47, !tbaa !29
  store ptr %t90, ptr %rv
  br label %ret
bb20:
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l48, !tbaa !29
  %t92 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t92, ptr %l49
  %t93 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t93, ptr %l50
  store i32 75, ptr %l51
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l52, !tbaa !29
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load %"compiler/source:Span", ptr %l1
  %t101 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t95, %"compiler/source:Span" %t96, ptr %a2)
  store ptr %t101, ptr %l56
  br label %bb21
bb21:
  %t102 = load %"compiler/source:Span", ptr %l1
  %t103 = load ptr, ptr %l52, !tbaa !29
  %t104 = load ptr, ptr %l56, !tbaa !29
  %t106 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t103, ptr %t104, %"compiler/source:Span" %t102)
  store ptr %t106, ptr %l58
  br label %bb22
bb22:
  %t107 = load ptr, ptr %l5, !tbaa !29
  store ptr %t107, ptr %l59, !tbaa !29
  %t108 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t108, ptr %l60
  %t109 = load ptr, ptr %l3, !tbaa !29
  %t111 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t109)
  store %"compiler/source:Span" %t111, ptr %l62
  br label %bb23
bb23:
  %t112 = load ptr, ptr %l48, !tbaa !29
  %t113 = load %"compiler/source:Span", ptr %l49
  %t114 = load %"compiler/source:Span", ptr %l50
  %t115 = load i32, ptr %l51
  %t116 = load ptr, ptr %l58, !tbaa !29
  %t117 = load ptr, ptr %l59, !tbaa !29
  %t118 = load %"compiler/source:Span", ptr %l60
  %t119 = load %"compiler/source:Span", ptr %l62
  %t120 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %t112, %"compiler/source:Span" %t113, %"compiler/source:Span" %t114, i32 %t115, ptr %t116, ptr %t117, %"compiler/source:Span" %t118, %"compiler/source:Span" %t119)
  store ptr %t120, ptr %l63
  br label %bb24
bb24:
  %t121 = load ptr, ptr %l63, !tbaa !29
  store ptr %t121, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIndexed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i64 %a4, i64 %a5, ptr %a6, i32 %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, i64, i64 }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca { i64, i64, i64 }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l27 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca %"compiler/source:Span"
  %l31 = alloca i32
  %l32 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca %"compiler/source:Span"
  %l37 = alloca i32
  %l38 = alloca ptr
  %l39 = alloca %"compiler/source:Span"
  %l41 = alloca i32
  %l42 = alloca ptr
  %l47 = alloca i64
  %l51 = alloca { i64, i64, i64 }
  %l56 = alloca ptr
  %l61 = alloca ptr
  %l68 = alloca ptr
  %l69 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca %"compiler/source:Span"
  %l74 = alloca %"compiler/source:Span"
  %l75 = alloca i64
  %l79 = alloca ptr
  %l80 = alloca ptr
  %l83 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l90 = alloca ptr
  %l91 = alloca ptr
  %l92 = alloca ptr
  %l93 = alloca %"compiler/source:Span"
  %l94 = alloca ptr
  %l95 = alloca %"compiler/source:Span"
  %l96 = alloca i32
  %l97 = alloca i32
  %l101 = alloca ptr
  %l104 = alloca ptr
  %l106 = alloca ptr
  %l107 = alloca ptr
  %l108 = alloca %"compiler/source:Span"
  %l109 = alloca %"compiler/source:Span"
  %l110 = alloca i64
  %l114 = alloca ptr
  %l115 = alloca ptr
  %l118 = alloca { i64, ptr }
  %l119 = alloca ptr
  %l123 = alloca ptr
  %l124 = alloca { i64, ptr }
  %l128 = alloca ptr
  %l132 = alloca ptr
  %l133 = alloca ptr
  %l145 = alloca i64
  %l147 = alloca ptr
  %l150 = alloca i64
  %l151 = alloca i32
  %l152 = alloca i64
  %l154 = alloca ptr
  %l157 = alloca i64
  %l158 = alloca i32
  %l164 = alloca ptr
  %l167 = alloca i64
  %l171 = alloca { i64, i64, i64 }
  %l175 = alloca ptr
  %l176 = alloca %"compiler/source:Span"
  %l177 = alloca %"compiler/source:Span"
  %l179 = alloca i32
  %l184 = alloca ptr
  %l185 = alloca ptr
  %l186 = alloca %"compiler/source:Span"
  %l188 = alloca i32
  %l189 = alloca i32
  %l193 = alloca ptr
  %l194 = alloca ptr
  %l195 = alloca %"compiler/source:Span"
  %l197 = alloca i32
  %l198 = alloca ptr
  %l200 = alloca ptr
  %l208 = alloca ptr
  %s0 = alloca %olang.scope
  %t34 = alloca { i64, [3 x i64] }, align 8
  %t335 = alloca { i64, [4 x i64] }, align 8
  %t376 = alloca { i64, [3 x i64] }, align 8
  %t407 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load %"compiler/source:Span", ptr %l1
  %t7 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eborrowedSource(ptr %v0, ptr %t1, %"compiler/source:Span" %t2, ptr %a3)
  store i64 %t7, ptr %l27
  br label %bb1
bb1:
  %t8 = load i64, ptr %l27, !tbaa !24
  store i64 %t8, ptr %l8, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l28, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t10, ptr %l29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t11)
  store i32 %t13, ptr %l31
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l28, !tbaa !29
  %t15 = load %"compiler/source:Span", ptr %l29
  %t16 = load i32, ptr %l31, !tbaa !23
  %t17 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t14, %"compiler/source:Span" %t15, i32 %t16)
  store i64 %t17, ptr %l32
  br label %bb3
bb3:
  %t18 = load i64, ptr %l32, !tbaa !24
  store i64 %t18, ptr %l9, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l33, !tbaa !29
  %t20 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t20, ptr %l34
  %t21 = load i64, ptr %l9, !tbaa !24
  %t23 = trunc i64 %t21 to i32
  store i32 %t23, ptr %l37, !tbaa !23
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l38, !tbaa !29
  %t26 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t26, ptr %l39
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t27)
  store i32 %t29, ptr %l41
  br label %bb4
bb4:
  %t30 = load ptr, ptr %l38, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l39
  %t32 = load i32, ptr %l41, !tbaa !23
  %t33 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t30, %"compiler/source:Span" %t31, i32 %t32, i64 0)
  store ptr %t33, ptr %l42
  br label %bb5
bb5:
  store { i64, [3 x i64] } zeroinitializer, ptr %t34
  %t35 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 0
  store i64 0, ptr %t35
  %t36 = load %"compiler/source:Span", ptr %l34
  %t37 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t36, 0
  %t38 = load i32, ptr %l37, !tbaa !23
  %t39 = insertvalue { %"compiler/source:Span", i32, ptr } %t37, i32 %t38, 1
  %t40 = load ptr, ptr %l42, !tbaa !29
  %t41 = insertvalue { %"compiler/source:Span", i32, ptr } %t39, ptr %t40, 2
  %t42 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t41, ptr %t42
  %t43 = load { i64, [3 x i64] }, ptr %t34
  %t45 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t43, ptr %t45
  %t46 = load ptr, ptr %l33, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t46, ptr %t45)
  br label %bb6
bb6:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 33
  %t52 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t50)
  store i64 %t52, ptr %l47
  br label %bb7
bb7:
  %t53 = load i64, ptr %l47, !tbaa !24
  store i64 %t53, ptr %l10, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l1
  %t59 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t54, i32 2, %"compiler/source:Span" %t55)
  store { i64, i64, i64 } %t59, ptr %l51
  br label %bb8
bb8:
  %t60 = load { i64, i64, i64 }, ptr %l51
  store { i64, i64, i64 } %t60, ptr %l11
  %t61 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 0
  %t62 = load i64, ptr %t61, !tbaa !24
  store i64 %t62, ptr %l12, !tbaa !24
  %t64 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 1
  %t65 = load i64, ptr %t64, !tbaa !24
  store i64 %t65, ptr %l13, !tbaa !24
  %t67 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 2
  %t68 = load i64, ptr %t67, !tbaa !24
  store i64 %t68, ptr %l14, !tbaa !24
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t70)
  store ptr %t72, ptr %l56
  br label %bb9
bb9:
  %t73 = load ptr, ptr %l56, !tbaa !29
  %t75 = getelementptr %"compiler/check:frame", ptr %t73, i32 0, i32 10
  %t76 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t75, i64 %t76)
  br label %bb10
bb10:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t79)
  store ptr %t81, ptr %l61
  br label %bb11
bb11:
  %t82 = load ptr, ptr %l61, !tbaa !29
  %t84 = getelementptr %"compiler/check:frame", ptr %t82, i32 0, i32 11
  %t85 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t84, i64 %t85)
  br label %bb12
bb12:
  %t88 = load ptr, ptr %l2, !tbaa !29
  %t90 = getelementptr %"compiler/ast:ForIn", ptr %t88, i32 0, i32 3
  %t91 = load i1, ptr %t90, !tbaa !21
  br i1 %t91, label %bb13, label %bb14
bb13:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t93)
  store ptr %t95, ptr %l68
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t96 = load ptr, ptr %l68, !tbaa !29
  store ptr %t96, ptr %l69, !tbaa !29
  %t97 = load ptr, ptr %l69, !tbaa !29
  %t98 = getelementptr %"compiler/check:frame", ptr %t97, i32 0, i32 15
  %t99 = load i64, ptr %t98, !tbaa !24
  %t101 = add i64 %t99, 1
  %t103 = load ptr, ptr %l69, !tbaa !29
  %t104 = getelementptr %"compiler/check:frame", ptr %t103, i32 0, i32 15
  store i64 %t101, ptr %t104, !tbaa !24
  br label %bb16
bb16:
  %t105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t105, ptr %l72, !tbaa !29
  %t106 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t106, ptr %l73
  %t107 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t107, ptr %l74
  store i64 %a5, ptr %l75, !tbaa !24
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load %"compiler/source:Span", ptr %l1
  %t111 = load i64, ptr %l8, !tbaa !24
  %t115 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t109, %"compiler/source:Span" %t110, i64 %t111)
  store ptr %t115, ptr %l79
  br label %bb17
bb17:
  %t116 = load ptr, ptr %l79, !tbaa !29
  store ptr %t116, ptr %l80, !tbaa !29
  %t117 = icmp sge i64 0, 0
  br i1 %t117, label %bb18, label %bb19
bb18:
  %t119 = icmp sle i64 0, 1152921504606846975
  br i1 %t119, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_5c35d65bf515aa44_9edccba99dd9b7f8)
  unreachable
bb20:
  %t121 = mul i64 0, 8
  %t122 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t121)
  %t123 = insertvalue { i64, ptr } undef, i64 0, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  store { i64, ptr } %t124, ptr %l83, !tbaa !27
  %t125 = icmp sge i64 0, 0
  br i1 %t125, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_5c35d65bf515aa44_9edccba99dd9b7f8)
  unreachable
bb22:
  %t127 = icmp sle i64 0, 1152921504606846975
  br i1 %t127, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_5c35d65bf515aa44_9edccba99dd9b7f8)
  unreachable
bb24:
  %t129 = mul i64 0, 8
  %t130 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t129)
  %t131 = insertvalue { i64, ptr } undef, i64 0, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  store { i64, ptr } %t132, ptr %l86, !tbaa !27
  %t133 = icmp sge i64 0, 0
  br i1 %t133, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_5c35d65bf515aa44_9edccba99dd9b7f8)
  unreachable
bb26:
  %t135 = icmp sle i64 0, 2305843009213693951
  br i1 %t135, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_19568a04807ed851_528b5bfe222c3865)
  unreachable
bb28:
  %t137 = mul i64 0, 4
  %t138 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t137)
  %t139 = insertvalue { i64, ptr } undef, i64 0, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr %t138, 1
  %t141 = load ptr, ptr %l72, !tbaa !29
  %t142 = load %"compiler/source:Span", ptr %l73
  %t143 = load %"compiler/source:Span", ptr %l74
  %t144 = load i64, ptr %l75, !tbaa !24
  %t145 = load ptr, ptr %l80, !tbaa !29
  %t146 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t147 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t149 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %s0, ptr %t141, %"compiler/source:Span" %t142, %"compiler/source:Span" %t143, i64 %t144, ptr %t145, { i64, ptr } %t146, { i64, ptr } %t147, { i64, ptr } %t140)
  store ptr %t149, ptr %l90
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_19568a04807ed851_528b5bfe222c3865)
  unreachable
bb30:
  %t150 = load ptr, ptr %l90, !tbaa !29
  store ptr %t150, ptr %l15, !tbaa !29
  %t151 = load ptr, ptr %l0, !tbaa !29
  store ptr %t151, ptr %l91, !tbaa !29
  %t152 = load ptr, ptr %l0, !tbaa !29
  store ptr %t152, ptr %l92, !tbaa !29
  %t153 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t153, ptr %l93
  %t154 = load ptr, ptr %l0, !tbaa !29
  store ptr %t154, ptr %l94, !tbaa !29
  %t155 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t155, ptr %l95
  %t156 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t156, ptr %l96, !tbaa !23
  store i32 15, ptr %l97
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load %"compiler/source:Span", ptr %l1
  %t159 = load i64, ptr %l9, !tbaa !24
  %t163 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t157, %"compiler/source:Span" %t158, i64 %t159)
  store ptr %t163, ptr %l101
  br label %bb31
bb31:
  %t164 = load ptr, ptr %l15, !tbaa !29
  %t166 = load ptr, ptr %l94, !tbaa !29
  %t167 = load %"compiler/source:Span", ptr %l95
  %t168 = load i32, ptr %l96, !tbaa !23
  %t169 = load i32, ptr %l97
  %t170 = load ptr, ptr %l101, !tbaa !29
  %t172 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t166, %"compiler/source:Span" %t167, i32 %t168, i32 %t169, ptr %t170, ptr %t164)
  store ptr %t172, ptr %l104
  br label %bb32
bb32:
  %t173 = load i64, ptr %l12, !tbaa !24
  %t174 = load ptr, ptr %l92, !tbaa !29
  %t175 = load %"compiler/source:Span", ptr %l93
  %t176 = load ptr, ptr %l104, !tbaa !29
  %t178 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebreakUnless(ptr %v0, ptr %t174, %"compiler/source:Span" %t175, ptr %t176, i64 %t173)
  store ptr %t178, ptr %l106
  br label %bb33
bb33:
  %t179 = load ptr, ptr %l91, !tbaa !29
  %t180 = load ptr, ptr %l106, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t179, ptr %t180)
  br label %bb34
bb34:
  %t181 = load ptr, ptr %l0, !tbaa !29
  store ptr %t181, ptr %l107, !tbaa !29
  %t182 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t182, ptr %l108
  %t183 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t183, ptr %l109
  store i64 %a4, ptr %l110, !tbaa !24
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load %"compiler/source:Span", ptr %l1
  %t187 = load i64, ptr %l8, !tbaa !24
  %t191 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t185, %"compiler/source:Span" %t186, i64 %t187)
  store ptr %t191, ptr %l114
  br label %bb35
bb35:
  %t192 = load ptr, ptr %l114, !tbaa !29
  store ptr %t192, ptr %l115, !tbaa !29
  %t193 = icmp sge i64 0, 0
  br i1 %t193, label %bb36, label %bb37
bb36:
  %t195 = icmp sle i64 0, 1152921504606846975
  br i1 %t195, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_130b25e968db6b32_47c65c95f253846)
  unreachable
bb38:
  %t197 = mul i64 0, 8
  %t198 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t197)
  %t199 = insertvalue { i64, ptr } undef, i64 0, 0
  %t200 = insertvalue { i64, ptr } %t199, ptr %t198, 1
  store { i64, ptr } %t200, ptr %l118, !tbaa !27
  %t201 = load ptr, ptr %l0, !tbaa !29
  store ptr %t201, ptr %l119, !tbaa !29
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load %"compiler/source:Span", ptr %l1
  %t204 = load i64, ptr %l9, !tbaa !24
  %t208 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t202, %"compiler/source:Span" %t203, i64 %t204)
  store ptr %t208, ptr %l123
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_130b25e968db6b32_47c65c95f253846)
  unreachable
bb40:
  %t209 = load ptr, ptr %l119, !tbaa !29
  %t210 = load ptr, ptr %l123, !tbaa !29
  %t211 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %t209, ptr %t210)
  store { i64, ptr } %t211, ptr %l124
  br label %bb41
bb41:
  %t212 = icmp sge i64 0, 0
  br i1 %t212, label %bb42, label %bb43
bb42:
  %t214 = icmp sle i64 0, 2305843009213693951
  br i1 %t214, label %bb44, label %bb45
bb43:
  call void @__olang_check_failed(ptr @olang_loc_19568a04807ed851_528b5bfe222c3865)
  unreachable
bb44:
  %t216 = mul i64 0, 4
  %t217 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t216)
  %t218 = insertvalue { i64, ptr } undef, i64 0, 0
  %t219 = insertvalue { i64, ptr } %t218, ptr %t217, 1
  %t220 = load ptr, ptr %l107, !tbaa !29
  %t221 = load %"compiler/source:Span", ptr %l108
  %t222 = load %"compiler/source:Span", ptr %l109
  %t223 = load i64, ptr %l110, !tbaa !24
  %t224 = load ptr, ptr %l115, !tbaa !29
  %t225 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t226 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t228 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %s0, ptr %t220, %"compiler/source:Span" %t221, %"compiler/source:Span" %t222, i64 %t223, ptr %t224, { i64, ptr } %t225, { i64, ptr } %t226, { i64, ptr } %t219)
  store ptr %t228, ptr %l128
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_19568a04807ed851_528b5bfe222c3865)
  unreachable
bb46:
  %t229 = load ptr, ptr %l128, !tbaa !29
  store ptr %t229, ptr %l16, !tbaa !29
  %t230 = load ptr, ptr %l2, !tbaa !29
  %t232 = getelementptr %"compiler/ast:ForIn", ptr %t230, i32 0, i32 3
  %t233 = load i1, ptr %t232, !tbaa !21
  br i1 %t233, label %bb47, label %bb48
bb47:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t235)
  store ptr %t237, ptr %l132
  br label %bb49
bb48:
  br label %bb50
bb49:
  %t238 = load ptr, ptr %l132, !tbaa !29
  store ptr %t238, ptr %l133, !tbaa !29
  %t239 = load ptr, ptr %l133, !tbaa !29
  %t240 = getelementptr %"compiler/check:frame", ptr %t239, i32 0, i32 15
  %t241 = load i64, ptr %t240, !tbaa !24
  %t243 = sub i64 %t241, 1
  %t245 = load ptr, ptr %l133, !tbaa !29
  %t246 = getelementptr %"compiler/check:frame", ptr %t245, i32 0, i32 15
  store i64 %t243, ptr %t246, !tbaa !24
  br label %bb50
bb50:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load %"compiler/source:Span", ptr %l1
  %t249 = load ptr, ptr %l2, !tbaa !29
  %t250 = load i64, ptr %l9, !tbaa !24
  %t251 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelementLocals(ptr %v0, ptr %v1, ptr %t247, %"compiler/source:Span" %t248, ptr %t249, i64 %t250, ptr %t251)
  br label %bb51
bb51:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkBody(ptr %v0, ptr %v1, ptr %v2, ptr %t257, ptr %t258, ptr %a6, i32 %a7)
  br label %bb52
bb52:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t267 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t265)
  store ptr %t267, ptr %l147
  br label %bb53
bb53:
  %t268 = load ptr, ptr %l147, !tbaa !29
  %t270 = getelementptr %"compiler/check:frame", ptr %t268, i32 0, i32 10
  %t272 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t270)
  %t273 = extractvalue { i32, i64 } %t272, 1
  %t274 = extractvalue { i32, i64 } %t272, 0
  store i32 %t274, ptr %l151
  %t275 = icmp ne i32 %t274, 0
  br i1 %t275, label %bb55, label %ok.276
ok.276:
  store i64 %t273, ptr %l150
  br label %bb54
bb54:
  %t277 = load i64, ptr %l150, !tbaa !24
  store i64 %t277, ptr %l145, !tbaa !24
  br label %bb57
bb55:
  br label %bb56
bb56:
  call void @__olang_ert_req_clear()
  br label %bb57
bb57:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t278)
  store ptr %t280, ptr %l154
  br label %bb58
bb58:
  %t281 = load ptr, ptr %l154, !tbaa !29
  %t283 = getelementptr %"compiler/check:frame", ptr %t281, i32 0, i32 11
  %t285 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t283)
  %t286 = extractvalue { i32, i64 } %t285, 1
  %t287 = extractvalue { i32, i64 } %t285, 0
  store i32 %t287, ptr %l158
  %t288 = icmp ne i32 %t287, 0
  br i1 %t288, label %bb60, label %ok.289
ok.289:
  store i64 %t286, ptr %l157
  br label %bb59
bb59:
  %t290 = load i64, ptr %l157, !tbaa !24
  store i64 %t290, ptr %l152, !tbaa !24
  br label %bb62
bb60:
  br label %bb61
bb61:
  call void @__olang_ert_req_clear()
  br label %bb62
bb62:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t292 = load i64, ptr %l12, !tbaa !24
  %t293 = load i64, ptr %l13, !tbaa !24
  %t294 = load i64, ptr %l14, !tbaa !24
  %t295 = load i64, ptr %l10, !tbaa !24
  %t301 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t291, i64 %t292, i64 %t293, i64 %t294, i64 %t295)
  store ptr %t301, ptr %l164
  br label %bb63
bb63:
  %t302 = load ptr, ptr %l164, !tbaa !29
  store ptr %t302, ptr %l17, !tbaa !29
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"compiler/check:Checker", ptr %t303, i32 0, i32 33
  %t307 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t305)
  store i64 %t307, ptr %l167
  br label %bb64
bb64:
  %t308 = load i64, ptr %l167, !tbaa !24
  store i64 %t308, ptr %l18, !tbaa !24
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t310 = load %"compiler/source:Span", ptr %l1
  %t314 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t309, i32 3, %"compiler/source:Span" %t310)
  store { i64, i64, i64 } %t314, ptr %l171
  br label %bb65
bb65:
  %t315 = load { i64, i64, i64 }, ptr %l171
  store { i64, i64, i64 } %t315, ptr %l19
  %t316 = getelementptr { i64, i64, i64 }, ptr %l19, i32 0, i32 0
  %t317 = load i64, ptr %t316, !tbaa !24
  store i64 %t317, ptr %l20, !tbaa !24
  %t319 = getelementptr { i64, i64, i64 }, ptr %l19, i32 0, i32 1
  %t320 = load i64, ptr %t319, !tbaa !24
  store i64 %t320, ptr %l21, !tbaa !24
  %t322 = getelementptr { i64, i64, i64 }, ptr %l19, i32 0, i32 2
  %t323 = load i64, ptr %t322, !tbaa !24
  store i64 %t323, ptr %l22, !tbaa !24
  %t325 = load ptr, ptr %l0, !tbaa !29
  store ptr %t325, ptr %l175, !tbaa !29
  %t326 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t326, ptr %l176
  %t327 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t327, ptr %l177
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t330 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t328)
  store i32 %t330, ptr %l179
  br label %bb66
bb66:
  %t331 = load i64, ptr %l9, !tbaa !24
  %t333 = trunc i64 %t331 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t335
  %t336 = getelementptr { i64, [4 x i64] }, ptr %t335, i32 0, i32 0
  store i64 0, ptr %t336
  %t337 = load %"compiler/source:Span", ptr %l177
  %t338 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t337, 0
  %t339 = load i32, ptr %l179, !tbaa !23
  %t340 = insertvalue { %"compiler/source:Span", i32, i32 } %t338, i32 %t339, 1
  %t342 = insertvalue { %"compiler/source:Span", i32, i32 } %t340, i32 %t333, 2
  %t343 = getelementptr { i64, [4 x i64] }, ptr %t335, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t342, ptr %t343
  %t344 = load { i64, [4 x i64] }, ptr %t335
  %t346 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t344, ptr %t346
  store ptr %t346, ptr %l184, !tbaa !29
  %t347 = load ptr, ptr %l0, !tbaa !29
  store ptr %t347, ptr %l185, !tbaa !29
  %t348 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t348, ptr %l186
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t351 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t349)
  store i32 %t351, ptr %l188
  br label %bb67
bb67:
  store i32 3, ptr %l189
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t353 = load %"compiler/source:Span", ptr %l1
  %t354 = load i64, ptr %l9, !tbaa !24
  %t358 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t352, %"compiler/source:Span" %t353, i64 %t354)
  store ptr %t358, ptr %l193
  br label %bb68
bb68:
  %t359 = load ptr, ptr %l0, !tbaa !29
  store ptr %t359, ptr %l194, !tbaa !29
  %t360 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t360, ptr %l195
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t363 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t361)
  store i32 %t363, ptr %l197
  br label %bb69
bb69:
  %t364 = load ptr, ptr %l194, !tbaa !29
  %t365 = load %"compiler/source:Span", ptr %l195
  %t366 = load i32, ptr %l197, !tbaa !23
  %t367 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t364, %"compiler/source:Span" %t365, i32 %t366, i64 1)
  store ptr %t367, ptr %l198
  br label %bb70
bb70:
  %t368 = load ptr, ptr %l198, !tbaa !29
  %t369 = load ptr, ptr %l185, !tbaa !29
  %t370 = load %"compiler/source:Span", ptr %l186
  %t371 = load i32, ptr %l188, !tbaa !23
  %t372 = load i32, ptr %l189
  %t373 = load ptr, ptr %l193, !tbaa !29
  %t375 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t369, %"compiler/source:Span" %t370, i32 %t371, i32 %t372, ptr %t373, ptr %t368)
  store ptr %t375, ptr %l200
  br label %bb71
bb71:
  store { i64, [3 x i64] } zeroinitializer, ptr %t376
  %t377 = getelementptr { i64, [3 x i64] }, ptr %t376, i32 0, i32 0
  store i64 1, ptr %t377
  %t378 = load %"compiler/source:Span", ptr %l176
  %t379 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t378, 0
  %t380 = load ptr, ptr %l184, !tbaa !29
  %t381 = insertvalue { %"compiler/source:Span", ptr, ptr } %t379, ptr %t380, 1
  %t382 = load ptr, ptr %l200, !tbaa !29
  %t383 = insertvalue { %"compiler/source:Span", ptr, ptr } %t381, ptr %t382, 2
  %t384 = getelementptr { i64, [3 x i64] }, ptr %t376, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t383, ptr %t384
  %t385 = load { i64, [3 x i64] }, ptr %t376
  %t387 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t385, ptr %t387
  %t388 = load ptr, ptr %l175, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t388, ptr %t387)
  br label %bb72
bb72:
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t391 = load i64, ptr %l20, !tbaa !24
  %t392 = load i64, ptr %l21, !tbaa !24
  %t393 = load i64, ptr %l22, !tbaa !24
  %t394 = load i64, ptr %l18, !tbaa !24
  %t400 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t390, i64 %t391, i64 %t392, i64 %t393, i64 %t394)
  store ptr %t400, ptr %l208
  br label %bb73
bb73:
  %t401 = load ptr, ptr %l208, !tbaa !29
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t403 = load %"compiler/source:Span", ptr %l1
  %t404 = load ptr, ptr %l17, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t407
  %t408 = getelementptr { i64, [3 x i64] }, ptr %t407, i32 0, i32 0
  store i64 4, ptr %t408
  %t410 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t403, 0
  %t412 = insertvalue { %"compiler/source:Span", ptr, ptr } %t410, ptr %t404, 1
  %t414 = insertvalue { %"compiler/source:Span", ptr, ptr } %t412, ptr %t401, 2
  %t415 = getelementptr { i64, [3 x i64] }, ptr %t407, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t414, ptr %t415
  %t416 = load { i64, [3 x i64] }, ptr %t407
  %t418 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t416, ptr %t418
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t402, ptr %t418)
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eyieldStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l6 = alloca { i64, [3 x i64] }
  %l7 = alloca ptr
  %l9 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l17 = alloca ptr
  %l18 = alloca %"compiler/source:Span"
  %l22 = alloca i1
  %l26 = alloca %"compiler/msgs:Msg"
  %l27 = alloca %"compiler/msgs:Msg"
  %l28 = alloca %"compiler/msgs:Msg"
  %l29 = alloca i64
  %l34 = alloca ptr
  %l38 = alloca ptr
  %l39 = alloca %"compiler/source:Span"
  %l40 = alloca %"compiler/msgs:Msg"
  %l41 = alloca i64
  %l44 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca %"compiler/source:Span"
  %l48 = alloca %"compiler/msgs:Msg"
  %l49 = alloca i64
  %l52 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca %"compiler/source:Span"
  %l56 = alloca %"compiler/msgs:Msg"
  %l57 = alloca i64
  %l62 = alloca ptr
  %l64 = alloca { i64, [3 x i64] }
  %l68 = alloca ptr
  %l71 = alloca i32
  %l73 = alloca i32
  %l75 = alloca i1
  %l76 = alloca ptr
  %l79 = alloca i32
  %l80 = alloca i1
  %l88 = alloca ptr
  %l91 = alloca i1
  %l93 = alloca ptr
  %l95 = alloca ptr
  %l97 = alloca %"compiler/source:Span"
  %l99 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %t152 = alloca { i64, [4 x i64] }, align 8
  %t193 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l9, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  %t7 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t8 = load i32, ptr %t7, !tbaa !23
  %t10 = add i32 %t8, 5
  %t13 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t6, i32 %t10)
  store %"compiler/source:Span" %t13, ptr %l13
  br label %bb2
bb2:
  %t14 = load %"compiler/source:Span", ptr %l13
  store %"compiler/source:Span" %t14, ptr %l4
  %t15 = load ptr, ptr %l3, !tbaa !29
  %t17 = getelementptr %"compiler/check:frame", ptr %t15, i32 0, i32 20
  %t18 = load i1, ptr %t17, !tbaa !21
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l17, !tbaa !29
  %t23 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t23, ptr %l18
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t26 = getelementptr %"compiler/check:frame", ptr %t24, i32 0, i32 19
  %t27 = load i64, ptr %t26, !tbaa !24
  %t29 = icmp sge i64 %t27, 0
  br i1 %t29, label %bb5, label %bb6
bb4:
  br label %bb15
bb5:
  %t31 = load ptr, ptr %l3, !tbaa !29
  %t33 = getelementptr %"compiler/check:frame", ptr %t31, i32 0, i32 31
  %t34 = load i64, ptr %t33, !tbaa !24
  %t36 = icmp slt i64 %t34, 0
  store i1 %t36, ptr %l22, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb7
bb7:
  %t38 = load i1, ptr %l22, !tbaa !21
  br i1 %t38, label %bb8, label %bb9
bb8:
  %t39 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eYieldInLambda(ptr %s1)
  store %"compiler/msgs:Msg" %t39, ptr %l27
  br label %bb10
bb9:
  %t40 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eYieldOutside(ptr %s1)
  store %"compiler/msgs:Msg" %t40, ptr %l28
  br label %bb11
bb10:
  %t41 = load %"compiler/msgs:Msg", ptr %l27
  store %"compiler/msgs:Msg" %t41, ptr %l26
  br label %bb12
bb11:
  %t42 = load %"compiler/msgs:Msg", ptr %l28
  store %"compiler/msgs:Msg" %t42, ptr %l26
  br label %bb12
bb12:
  %t43 = load ptr, ptr %l17, !tbaa !29
  %t44 = load %"compiler/source:Span", ptr %l18
  %t45 = load %"compiler/msgs:Msg", ptr %l26
  %t46 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t43, %"compiler/source:Span" %t44, %"compiler/msgs:Msg" %t45)
  store i64 %t46, ptr %l29
  br label %bb13
bb13:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load ptr, ptr %l2, !tbaa !29
  %t50 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t54 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t47, ptr %t48, i32 %t50)
  store ptr %t54, ptr %l34
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb15:
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t57 = getelementptr %"compiler/check:frame", ptr %t55, i32 0, i32 31
  %t58 = load i64, ptr %t57, !tbaa !24
  %t60 = icmp sge i64 %t58, 0
  br i1 %t60, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s2
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l38, !tbaa !29
  %t63 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t63, ptr %l39
  %t64 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eYieldInDefer(ptr %s2)
  store %"compiler/msgs:Msg" %t64, ptr %l40
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t65 = load ptr, ptr %l38, !tbaa !29
  %t66 = load %"compiler/source:Span", ptr %l39
  %t67 = load %"compiler/msgs:Msg", ptr %l40
  %t68 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t65, %"compiler/source:Span" %t66, %"compiler/msgs:Msg" %t67)
  store i64 %t68, ptr %l41
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb20:
  %t69 = load ptr, ptr %l3, !tbaa !29
  %t71 = getelementptr %"compiler/check:frame", ptr %t69, i32 0, i32 35
  %t73 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t71)
  store i64 %t73, ptr %l44
  br label %bb21
bb21:
  %t74 = load i64, ptr %l44, !tbaa !24
  %t75 = icmp sgt i64 %t74, 0
  br i1 %t75, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s3
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l46, !tbaa !29
  %t78 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t78, ptr %l47
  %t79 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eYieldInJoin(ptr %s3)
  store %"compiler/msgs:Msg" %t79, ptr %l48
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t80 = load ptr, ptr %l46, !tbaa !29
  %t81 = load %"compiler/source:Span", ptr %l47
  %t82 = load %"compiler/msgs:Msg", ptr %l48
  %t83 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t80, %"compiler/source:Span" %t81, %"compiler/msgs:Msg" %t82)
  store i64 %t83, ptr %l49
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb26:
  %t84 = load ptr, ptr %l3, !tbaa !29
  %t86 = getelementptr %"compiler/check:frame", ptr %t84, i32 0, i32 21
  %t88 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t86)
  store i64 %t88, ptr %l52
  br label %bb27
bb27:
  %t89 = load i64, ptr %l52, !tbaa !24
  %t90 = icmp sgt i64 %t89, 0
  br i1 %t90, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s4
  %t92 = load ptr, ptr %l0, !tbaa !29
  store ptr %t92, ptr %l54, !tbaa !29
  %t93 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t93, ptr %l55
  %t94 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eYieldPastDefer(ptr %s4)
  store %"compiler/msgs:Msg" %t94, ptr %l56
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t95 = load ptr, ptr %l54, !tbaa !29
  %t96 = load %"compiler/source:Span", ptr %l55
  %t97 = load %"compiler/msgs:Msg", ptr %l56
  %t98 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t95, %"compiler/source:Span" %t96, %"compiler/msgs:Msg" %t97)
  store i64 %t98, ptr %l57
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb32:
  %t99 = load ptr, ptr %l3, !tbaa !29
  %t101 = getelementptr %"compiler/check:frame", ptr %t99, i32 0, i32 5
  %t102 = load i32, ptr %t101, !tbaa !23
  store i32 %t102, ptr %l5, !tbaa !23
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/check:Checker", ptr %t104, i32 0, i32 10
  %t107 = load { i64, [3 x i64] }, ptr %t106
  store { i64, [3 x i64] } %t107, ptr %l6
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l62, !tbaa !29
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresultAt(ptr %v0, ptr %t110, i64 0)
  store { i64, [3 x i64] } %t112, ptr %l64
  br label %bb33
bb33:
  %t113 = load { i64, [3 x i64] }, ptr %l64
  %t114 = load ptr, ptr %l62, !tbaa !29
  %t115 = getelementptr %"compiler/check:Checker", ptr %t114, i32 0, i32 10
  store { i64, [3 x i64] } %t113, ptr %t115
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load ptr, ptr %l2, !tbaa !29
  %t118 = load i32, ptr %l5, !tbaa !23
  %t122 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %t116, ptr %t117, i32 %t118)
  store ptr %t122, ptr %l68
  br label %bb34
bb34:
  %t123 = load ptr, ptr %l68, !tbaa !29
  store ptr %t123, ptr %l7, !tbaa !29
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load { i64, [3 x i64] }, ptr %l6
  %t128 = getelementptr %"compiler/check:Checker", ptr %t124, i32 0, i32 10
  store { i64, [3 x i64] } %t125, ptr %t128
  %t129 = load i32, ptr %l5, !tbaa !23
  store i32 %t129, ptr %l71, !tbaa !23
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t130)
  store i32 %t132, ptr %l73
  br label %bb35
bb35:
  %t133 = load i32, ptr %l71, !tbaa !23
  %t134 = load i32, ptr %l73, !tbaa !23
  %t135 = icmp eq i32 %t133, %t134
  br i1 %t135, label %bb36, label %bb37
bb36:
  %t137 = load ptr, ptr %l0, !tbaa !29
  store ptr %t137, ptr %l76, !tbaa !29
  %t138 = load ptr, ptr %l7, !tbaa !29
  %t141 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t138)
  store i32 %t141, ptr %l79
  br label %bb38
bb37:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb40
bb38:
  %t142 = load ptr, ptr %l76, !tbaa !29
  %t143 = load i32, ptr %l79, !tbaa !23
  %t144 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t142, i32 %t143)
  store i1 %t144, ptr %l80
  br label %bb39
bb39:
  %t145 = load i1, ptr %l80, !tbaa !21
  store i1 %t145, ptr %l75, !tbaa !21
  br label %bb40
bb40:
  %t146 = load i1, ptr %l75, !tbaa !21
  br i1 %t146, label %bb41, label %bb42
bb41:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load %"compiler/source:Span", ptr %l1
  %t149 = load %"compiler/source:Span", ptr %l1
  %t150 = load i32, ptr %l5, !tbaa !23
  %t151 = load ptr, ptr %l7, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t152
  %t153 = getelementptr { i64, [4 x i64] }, ptr %t152, i32 0, i32 0
  store i64 2, ptr %t153
  %t155 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t149, 0
  %t157 = insertvalue { %"compiler/source:Span", i32, ptr } %t155, i32 %t150, 1
  %t159 = insertvalue { %"compiler/source:Span", i32, ptr } %t157, ptr %t151, 2
  %t160 = getelementptr { i64, [4 x i64] }, ptr %t152, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t159, ptr %t160
  %t161 = load { i64, [4 x i64] }, ptr %t152
  %t163 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t161, ptr %t163
  %t167 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t147, %"compiler/source:Span" %t148, ptr %t163)
  store ptr %t167, ptr %l88
  br label %bb43
bb42:
  br label %bb44
bb43:
  %t168 = load ptr, ptr %l88, !tbaa !29
  store ptr %t168, ptr %l7, !tbaa !29
  br label %bb44
bb44:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load i32, ptr %l5, !tbaa !23
  %t173 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t169, i32 %t170)
  store i1 %t173, ptr %l91
  br label %bb45
bb45:
  %t174 = load i1, ptr %l91, !tbaa !21
  %t175 = xor i1 %t174, true
  br i1 %t175, label %bb46, label %bb47
bb46:
  %t177 = load ptr, ptr %l0, !tbaa !29
  store ptr %t177, ptr %l93, !tbaa !29
  %t178 = load ptr, ptr %l7, !tbaa !29
  store ptr %t178, ptr %l95, !tbaa !29
  %t180 = load ptr, ptr %l2, !tbaa !29
  %t182 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t180)
  store %"compiler/source:Span" %t182, ptr %l97
  br label %bb48
bb47:
  br label %bb50
bb48:
  %t183 = load i64, ptr @G_2ecompiler_2fcheck_2eRoReturned, !tbaa !24
  %t184 = load ptr, ptr %l93, !tbaa !29
  %t185 = load ptr, ptr %l95, !tbaa !29
  %t186 = load %"compiler/source:Span", ptr %l97
  %t188 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v0, ptr %t184, ptr %t185, %"compiler/source:Span" %t186, i64 %t183)
  store i1 %t188, ptr %l99
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load %"compiler/source:Span", ptr %l1
  %t191 = load ptr, ptr %l7, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t193
  %t194 = getelementptr { i64, [3 x i64] }, ptr %t193, i32 0, i32 0
  store i64 16, ptr %t194
  %t196 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t190, 0
  %t198 = insertvalue { %"compiler/source:Span", ptr } %t196, ptr %t191, 1
  %t199 = getelementptr { i64, [3 x i64] }, ptr %t193, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t198, ptr %t199
  %t200 = load { i64, [3 x i64] }, ptr %t193
  %t202 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t200, ptr %t202
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t189, ptr %t202)
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2eexprBreaks(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l13 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l23 = alloca i1
  %l24 = alloca i1
  %l28 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l38 = alloca i1
  %l39 = alloca i1
  %l43 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l53 = alloca i1
  %l54 = alloca i1
  %l58 = alloca i1
  %l59 = alloca i1
  %l64 = alloca i1
  %l71 = alloca i1
  %l72 = alloca ptr
  %l73 = alloca i1
  %l82 = alloca i1
  %l83 = alloca i1
  %l87 = alloca i1
  %l88 = alloca i1
  %l93 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca i1
  %l103 = alloca i1
  %l104 = alloca ptr
  %l105 = alloca i1
  %l112 = alloca i1
  %l113 = alloca ptr
  %l114 = alloca i1
  %l123 = alloca i1
  %l124 = alloca ptr
  %l125 = alloca i1
  %l133 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t7 = load ptr, ptr %l14, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l14, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 14
  store i1 %t13, ptr %l15, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l15, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t17, i32 0, i32 2
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb14
bb8:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Try", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t25 = load i32, ptr %l1, !tbaa !23
  %t28 = call i1 @compiler_2fcheck_2eexprBreaks(ptr %v0, ptr %t24, i32 %t25)
  store i1 %t28, ptr %l23
  br label %bb9
bb9:
  %t29 = load i1, ptr %l23, !tbaa !21
  br i1 %t29, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb13
bb11:
  %t30 = load ptr, ptr %l2, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Try", ptr %t30, i32 0, i32 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  %t34 = load i32, ptr %l1, !tbaa !23
  %t37 = call i1 @compiler_2fcheck_2eclausesBreak(ptr %v0, { i64, ptr } %t33, i32 %t34)
  store i1 %t37, ptr %l28
  br label %bb12
bb12:
  %t38 = load i1, ptr %l28, !tbaa !21
  store i1 %t38, ptr %l24, !tbaa !21
  br label %bb13
bb13:
  %t39 = load i1, ptr %l24, !tbaa !21
  store i1 %t39, ptr %l13, !tbaa !21
  br label %bb94
bb14:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t41 = load ptr, ptr %l29, !tbaa !29
  %t42 = icmp ne ptr %t41, null
  br i1 %t42, label %bb15, label %bb16
bb15:
  %t44 = load ptr, ptr %l29, !tbaa !29
  %t45 = load i64, ptr %t44
  %t47 = icmp eq i64 %t45, 12
  store i1 %t47, ptr %l30, !tbaa !21
  br label %bb16
bb16:
  %t48 = load i1, ptr %l30, !tbaa !21
  br i1 %t48, label %bb17, label %bb18
bb17:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr { i64, [5 x i64] }, ptr %t49, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t51, i32 0, i32 2
  %t53 = load ptr, ptr %t52
  store ptr %t53, ptr %l3, !tbaa !29
  br label %bb19
bb18:
  br label %bb25
bb19:
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Seq", ptr %t55, i32 0, i32 0
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  %t59 = load i32, ptr %l1, !tbaa !23
  %t62 = call i1 @compiler_2fcheck_2estmtsBreak(ptr %v0, { i64, ptr } %t58, i32 %t59)
  store i1 %t62, ptr %l38
  br label %bb20
bb20:
  %t63 = load i1, ptr %l38, !tbaa !21
  br i1 %t63, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb24
bb22:
  %t64 = load ptr, ptr %l3, !tbaa !29
  %t66 = getelementptr %"compiler/typed:Seq", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t68 = load i32, ptr %l1, !tbaa !23
  %t71 = call i1 @compiler_2fcheck_2eexprBreaks(ptr %v0, ptr %t67, i32 %t68)
  store i1 %t71, ptr %l43
  br label %bb23
bb23:
  %t72 = load i1, ptr %l43, !tbaa !21
  store i1 %t72, ptr %l39, !tbaa !21
  br label %bb24
bb24:
  %t73 = load i1, ptr %l39, !tbaa !21
  store i1 %t73, ptr %l13, !tbaa !21
  br label %bb94
bb25:
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t75 = load ptr, ptr %l44, !tbaa !29
  %t76 = icmp ne ptr %t75, null
  br i1 %t76, label %bb26, label %bb27
bb26:
  %t78 = load ptr, ptr %l44, !tbaa !29
  %t79 = load i64, ptr %t78
  %t81 = icmp eq i64 %t79, 13
  store i1 %t81, ptr %l45, !tbaa !21
  br label %bb27
bb27:
  %t82 = load i1, ptr %l45, !tbaa !21
  br i1 %t82, label %bb28, label %bb29
bb28:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr { i64, [5 x i64] }, ptr %t83, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t85, i32 0, i32 2
  %t87 = load ptr, ptr %t86
  store ptr %t87, ptr %l4, !tbaa !29
  br label %bb30
bb29:
  br label %bb46
bb30:
  %t89 = load ptr, ptr %l4, !tbaa !29
  %t91 = getelementptr %"compiler/typed:Match", ptr %t89, i32 0, i32 0
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  %t93 = load i32, ptr %l1, !tbaa !23
  %t96 = call i1 @compiler_2fcheck_2estmtsBreak(ptr %v0, { i64, ptr } %t92, i32 %t93)
  store i1 %t96, ptr %l53
  br label %bb31
bb31:
  %t97 = load i1, ptr %l53, !tbaa !21
  br i1 %t97, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb35
bb33:
  %t98 = load ptr, ptr %l4, !tbaa !29
  %t100 = getelementptr %"compiler/typed:Match", ptr %t98, i32 0, i32 1
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !27
  %t102 = load i32, ptr %l1, !tbaa !23
  %t105 = call i1 @compiler_2fcheck_2earmsBreak(ptr %v0, { i64, ptr } %t101, i32 %t102)
  store i1 %t105, ptr %l58
  br label %bb34
bb34:
  %t106 = load i1, ptr %l58, !tbaa !21
  store i1 %t106, ptr %l54, !tbaa !21
  br label %bb35
bb35:
  %t107 = load i1, ptr %l54, !tbaa !21
  br i1 %t107, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l59, !tbaa !21
  br label %bb45
bb37:
  %t108 = load ptr, ptr %l4, !tbaa !29
  %t110 = getelementptr %"compiler/typed:Match", ptr %t108, i32 0, i32 2
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = icmp eq ptr %t111, null
  %t115 = xor i1 %t113, true
  br i1 %t115, label %bb38, label %bb39
bb38:
  %t117 = load ptr, ptr %l4, !tbaa !29
  %t119 = getelementptr %"compiler/typed:Match", ptr %t117, i32 0, i32 2
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = icmp eq ptr %t120, null
  br i1 %t122, label %bb40, label %bb41
bb39:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb44
bb40:
  call void @__olang_check_failed(ptr @olang_loc_a0498c486f94284f_fcfc69224e16b833)
  unreachable
bb41:
  br label %bb42
bb42:
  %t124 = load ptr, ptr %l4, !tbaa !29
  %t126 = getelementptr %"compiler/typed:Match", ptr %t124, i32 0, i32 2
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t128 = load i32, ptr %l1, !tbaa !23
  %t131 = call i1 @compiler_2fcheck_2earmBreaks(ptr %v0, ptr %t127, i32 %t128)
  store i1 %t131, ptr %l71
  br label %bb43
bb43:
  %t132 = load i1, ptr %l71, !tbaa !21
  store i1 %t132, ptr %l64, !tbaa !21
  br label %bb44
bb44:
  %t133 = load i1, ptr %l64, !tbaa !21
  store i1 %t133, ptr %l59, !tbaa !21
  br label %bb45
bb45:
  %t134 = load i1, ptr %l59, !tbaa !21
  store i1 %t134, ptr %l13, !tbaa !21
  br label %bb94
bb46:
  %t135 = load ptr, ptr %l0, !tbaa !29
  store ptr %t135, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t136 = load ptr, ptr %l72, !tbaa !29
  %t137 = icmp ne ptr %t136, null
  br i1 %t137, label %bb47, label %bb48
bb47:
  %t139 = load ptr, ptr %l72, !tbaa !29
  %t140 = load i64, ptr %t139
  %t142 = icmp eq i64 %t140, 11
  store i1 %t142, ptr %l73, !tbaa !21
  br label %bb48
bb48:
  %t143 = load i1, ptr %l73, !tbaa !21
  br i1 %t143, label %bb49, label %bb50
bb49:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr { i64, [5 x i64] }, ptr %t144, i32 0, i32 1
  %t147 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t146, i32 0, i32 2
  %t148 = load ptr, ptr %t147
  store ptr %t148, ptr %l5, !tbaa !29
  br label %bb51
bb50:
  br label %bb61
bb51:
  %t150 = load ptr, ptr %l5, !tbaa !29
  %t152 = getelementptr %"compiler/typed:Cond", ptr %t150, i32 0, i32 0
  %t153 = load ptr, ptr %t152, !tbaa !29
  %t155 = load i32, ptr %l1, !tbaa !23
  %t158 = call i1 @compiler_2fcheck_2eexprBreaks(ptr %v0, ptr %t153, i32 %t155)
  store i1 %t158, ptr %l82
  br label %bb52
bb52:
  %t159 = load i1, ptr %l82, !tbaa !21
  br i1 %t159, label %bb53, label %bb54
bb53:
  store i1 true, ptr %l83, !tbaa !21
  br label %bb56
bb54:
  %t160 = load ptr, ptr %l5, !tbaa !29
  %t162 = getelementptr %"compiler/typed:Cond", ptr %t160, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !29
  %t164 = load i32, ptr %l1, !tbaa !23
  %t167 = call i1 @compiler_2fcheck_2eexprBreaks(ptr %v0, ptr %t163, i32 %t164)
  store i1 %t167, ptr %l87
  br label %bb55
bb55:
  %t168 = load i1, ptr %l87, !tbaa !21
  store i1 %t168, ptr %l83, !tbaa !21
  br label %bb56
bb56:
  %t169 = load i1, ptr %l83, !tbaa !21
  br i1 %t169, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l88, !tbaa !21
  br label %bb60
bb58:
  %t170 = load ptr, ptr %l5, !tbaa !29
  %t172 = getelementptr %"compiler/typed:Cond", ptr %t170, i32 0, i32 2
  %t173 = load ptr, ptr %t172, !tbaa !29
  %t175 = load i32, ptr %l1, !tbaa !23
  %t178 = call i1 @compiler_2fcheck_2eexprBreaks(ptr %v0, ptr %t173, i32 %t175)
  store i1 %t178, ptr %l93
  br label %bb59
bb59:
  %t179 = load i1, ptr %l93, !tbaa !21
  store i1 %t179, ptr %l88, !tbaa !21
  br label %bb60
bb60:
  %t180 = load i1, ptr %l88, !tbaa !21
  store i1 %t180, ptr %l13, !tbaa !21
  br label %bb94
bb61:
  %t181 = load ptr, ptr %l0, !tbaa !29
  store ptr %t181, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t182 = load ptr, ptr %l94, !tbaa !29
  %t183 = icmp ne ptr %t182, null
  br i1 %t183, label %bb62, label %bb63
bb62:
  %t185 = load ptr, ptr %l94, !tbaa !29
  %t186 = load i64, ptr %t185
  %t188 = icmp eq i64 %t186, 6
  store i1 %t188, ptr %l95, !tbaa !21
  br label %bb63
bb63:
  %t189 = load i1, ptr %l95, !tbaa !21
  br i1 %t189, label %bb64, label %bb65
bb64:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t192 = getelementptr { i64, [5 x i64] }, ptr %t190, i32 0, i32 1
  %t193 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t192, i32 0, i32 2
  %t194 = load ptr, ptr %t193
  store ptr %t194, ptr %l6, !tbaa !29
  br label %bb66
bb65:
  br label %bb68
bb66:
  %t196 = load ptr, ptr %l6, !tbaa !29
  %t198 = getelementptr %"compiler/typed:Call", ptr %t196, i32 0, i32 1
  %t199 = load { i64, ptr }, ptr %t198, !tbaa !27
  %t200 = load i32, ptr %l1, !tbaa !23
  %t203 = call i1 @compiler_2fcheck_2eexprsBreak(ptr %v0, { i64, ptr } %t199, i32 %t200)
  store i1 %t203, ptr %l103
  br label %bb67
bb67:
  %t204 = load i1, ptr %l103, !tbaa !21
  store i1 %t204, ptr %l13, !tbaa !21
  br label %bb94
bb68:
  %t205 = load ptr, ptr %l0, !tbaa !29
  store ptr %t205, ptr %l104, !tbaa !29
  store i1 false, ptr %l105, !tbaa !21
  %t206 = load ptr, ptr %l104, !tbaa !29
  %t207 = icmp ne ptr %t206, null
  br i1 %t207, label %bb69, label %bb70
bb69:
  %t209 = load ptr, ptr %l104, !tbaa !29
  %t210 = load i64, ptr %t209
  %t212 = icmp eq i64 %t210, 9
  store i1 %t212, ptr %l105, !tbaa !21
  br label %bb70
bb70:
  %t213 = load i1, ptr %l105, !tbaa !21
  br i1 %t213, label %bb71, label %bb72
bb71:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr { i64, [5 x i64] }, ptr %t214, i32 0, i32 1
  %t217 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t216, i32 0, i32 4
  %t218 = load { i64, ptr }, ptr %t217
  store { i64, ptr } %t218, ptr %l7, !tbaa !27
  br label %bb73
bb72:
  br label %bb75
bb73:
  %t220 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t221 = load i32, ptr %l1, !tbaa !23
  %t224 = call i1 @compiler_2fcheck_2eexprsBreak(ptr %v0, { i64, ptr } %t220, i32 %t221)
  store i1 %t224, ptr %l112
  br label %bb74
bb74:
  %t225 = load i1, ptr %l112, !tbaa !21
  store i1 %t225, ptr %l13, !tbaa !21
  br label %bb94
bb75:
  %t226 = load ptr, ptr %l0, !tbaa !29
  store ptr %t226, ptr %l113, !tbaa !29
  store i1 false, ptr %l114, !tbaa !21
  %t227 = load ptr, ptr %l113, !tbaa !29
  %t228 = icmp ne ptr %t227, null
  br i1 %t228, label %bb76, label %bb77
bb76:
  %t230 = load ptr, ptr %l113, !tbaa !29
  %t231 = load i64, ptr %t230
  %t233 = icmp eq i64 %t231, 5
  store i1 %t233, ptr %l114, !tbaa !21
  br label %bb77
bb77:
  %t234 = load i1, ptr %l114, !tbaa !21
  br i1 %t234, label %bb78, label %bb79
bb78:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr { i64, [5 x i64] }, ptr %t235, i32 0, i32 1
  %t238 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t237, i32 0, i32 2
  %t239 = load ptr, ptr %t238
  store ptr %t239, ptr %l8, !tbaa !29
  br label %bb80
bb79:
  br label %bb82
bb80:
  %t241 = load ptr, ptr %l8, !tbaa !29
  %t243 = getelementptr %"compiler/typed:Promote", ptr %t241, i32 0, i32 0
  %t244 = load ptr, ptr %t243, !tbaa !29
  %t246 = load i32, ptr %l1, !tbaa !23
  %t249 = call i1 @compiler_2fcheck_2eexprBreaks(ptr %v0, ptr %t244, i32 %t246)
  store i1 %t249, ptr %l123
  br label %bb81
bb81:
  %t250 = load i1, ptr %l123, !tbaa !21
  store i1 %t250, ptr %l13, !tbaa !21
  br label %bb94
bb82:
  %t251 = load ptr, ptr %l0, !tbaa !29
  store ptr %t251, ptr %l124, !tbaa !29
  store i1 false, ptr %l125, !tbaa !21
  %t252 = load ptr, ptr %l124, !tbaa !29
  %t253 = icmp ne ptr %t252, null
  br i1 %t253, label %bb83, label %bb84
bb83:
  %t255 = load ptr, ptr %l124, !tbaa !29
  %t256 = load i64, ptr %t255
  %t258 = icmp eq i64 %t256, 17
  store i1 %t258, ptr %l125, !tbaa !21
  br label %bb84
bb84:
  %t259 = load i1, ptr %l125, !tbaa !21
  br i1 %t259, label %bb85, label %bb86
bb85:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t262 = getelementptr { i64, [5 x i64] }, ptr %t260, i32 0, i32 1
  %t263 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t262, i32 0, i32 2
  %t264 = load ptr, ptr %t263
  store ptr %t264, ptr %l9, !tbaa !29
  br label %bb87
bb86:
  br label %bb89
bb87:
  %t266 = load ptr, ptr %l9, !tbaa !29
  %t268 = load i32, ptr %l1, !tbaa !23
  %t271 = call i1 @compiler_2fcheck_2eexprBreaks(ptr %v0, ptr %t266, i32 %t268)
  store i1 %t271, ptr %l133
  br label %bb88
bb88:
  %t272 = load i1, ptr %l133, !tbaa !21
  store i1 %t272, ptr %l13, !tbaa !21
  br label %bb94
bb89:
  br i1 true, label %bb90, label %bb91
bb90:
  br label %bb92
bb91:
  br label %bb93
bb92:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb94
bb93:
  call void @__olang_check_failed(ptr @olang_loc_c9ff66f8ef4bd5b7_7fc0b0455d81db0b)
  unreachable
bb94:
  %t273 = load i1, ptr %l13, !tbaa !21
  store i1 %t273, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ematchAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l14 = alloca { i64, ptr }
  %l20 = alloca i1
  %l28 = alloca i1
  %l37 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Match", ptr %t1, i32 0, i32 3
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l14, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  %t28 = getelementptr %"compiler/ast:Case", ptr %t24, i32 0, i32 4
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t33 = call i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %t29, { i64, ptr } %t30)
  store i1 %t33, ptr %l20
  br label %bb5
bb5:
  %t34 = load i1, ptr %l20, !tbaa !21
  br i1 %t34, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb9:
  %t36 = load i64, ptr %l3, !tbaa !24
  %t38 = add i64 %t36, 1
  store i64 %t38, ptr %l3, !tbaa !24
  br label %bb1
bb10:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/ast:Match", ptr %t40, i32 0, i32 4
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = icmp eq ptr %t43, null
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb11, label %bb12
bb11:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/ast:Match", ptr %t49, i32 0, i32 4
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = icmp eq ptr %t52, null
  br i1 %t54, label %bb13, label %bb14
bb12:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb17
bb13:
  call void @__olang_check_failed(ptr @olang_loc_bff01f20505ccdb5_4aab420456ab469)
  unreachable
bb14:
  br label %bb15
bb15:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/ast:Match", ptr %t56, i32 0, i32 4
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t62 = getelementptr %"compiler/ast:Case", ptr %t59, i32 0, i32 4
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t67 = call i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %t63, { i64, ptr } %t64)
  store i1 %t67, ptr %l37
  br label %bb16
bb16:
  %t68 = load i1, ptr %l37, !tbaa !21
  store i1 %t68, ptr %l28, !tbaa !21
  br label %bb17
bb17:
  %t69 = load i1, ptr %l28, !tbaa !21
  store i1 %t69, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2estmtLike(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l27 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l36 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 12
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb17
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t11 = load ptr, ptr %l8, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t15 = load i64, ptr %t14
  %t17 = icmp eq i64 %t15, 13
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l9, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb17
bb8:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = load i64, ptr %t23
  %t26 = icmp eq i64 %t24, 22
  store i1 %t26, ptr %l13, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l13, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  br label %bb17
bb12:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t29 = load ptr, ptr %l16, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb13, label %bb14
bb13:
  %t32 = load ptr, ptr %l16, !tbaa !29
  %t33 = load i64, ptr %t32
  %t35 = icmp eq i64 %t33, 4
  store i1 %t35, ptr %l17, !tbaa !21
  br label %bb14
bb14:
  %t36 = load i1, ptr %l17, !tbaa !21
  br i1 %t36, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb39
bb18:
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t38 = load ptr, ptr %l20, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb19, label %bb20
bb19:
  %t41 = load ptr, ptr %l20, !tbaa !29
  %t42 = load i64, ptr %t41
  %t44 = icmp eq i64 %t42, 2
  store i1 %t44, ptr %l21, !tbaa !21
  br label %bb20
bb20:
  %t45 = load i1, ptr %l21, !tbaa !21
  br i1 %t45, label %bb21, label %bb22
bb21:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr { i64, [5 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", ptr }, ptr %t48, i32 0, i32 1
  %t50 = load ptr, ptr %t49
  store ptr %t50, ptr %l1, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = call i1 @compiler_2fcheck_2estmtLike(ptr %v0, ptr %t52)
  store i1 %t54, ptr %l27
  br label %bb24
bb24:
  %t55 = load i1, ptr %l27, !tbaa !21
  store i1 %t55, ptr %l3, !tbaa !21
  br label %bb39
bb25:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t57 = load ptr, ptr %l28, !tbaa !29
  %t58 = icmp ne ptr %t57, null
  br i1 %t58, label %bb26, label %bb27
bb26:
  %t60 = load ptr, ptr %l28, !tbaa !29
  %t61 = load i64, ptr %t60
  %t63 = icmp eq i64 %t61, 3
  store i1 %t63, ptr %l29, !tbaa !21
  br label %bb27
bb27:
  %t64 = load i1, ptr %l29, !tbaa !21
  br i1 %t64, label %bb28, label %bb29
bb28:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr { i64, [5 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t67, i32 0, i32 1
  %t69 = load i32, ptr %t68
  store i32 %t69, ptr %l2
  br label %bb30
bb29:
  br label %bb34
bb30:
  %t71 = load i32, ptr %l2
  %t73 = trunc i64 73 to i32
  %t74 = icmp eq i32 %t71, %t73
  br i1 %t74, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb33
bb32:
  %t76 = load i32, ptr %l2
  %t78 = trunc i64 74 to i32
  %t79 = icmp eq i32 %t76, %t78
  store i1 %t79, ptr %l36, !tbaa !21
  br label %bb33
bb33:
  %t81 = load i1, ptr %l36, !tbaa !21
  store i1 %t81, ptr %l3, !tbaa !21
  br label %bb39
bb34:
  br i1 true, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_d195b38137e2d30_7d67c1d5e7f3802c)
  unreachable
bb39:
  %t82 = load i1, ptr %l3, !tbaa !21
  store i1 %t82, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2estoredCase(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Case", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t4, ptr %t5)
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/ast:Case", ptr %t8, i32 0, i32 4
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  %t12 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %t11, ptr %t12)
  br label %bb2
bb2:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/ast:Case", ptr %t15, i32 0, i32 5
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t19 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t18, ptr %t19)
  br label %bb3
bb3:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/check:Ask" @compiler_2fcheck_3aAsk_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, i64 %a1, i32 %a2, ptr %a3, i64 %a4, { i64, ptr } %a5) #0 {
entry:
  %rv = alloca %"compiler/check:Ask"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/check:Ask" undef, i64 %a0, 0
  %t16 = insertvalue %"compiler/check:Ask" %t14, i64 %a1, 1
  %t18 = insertvalue %"compiler/check:Ask" %t16, i32 %a2, 2
  %t20 = insertvalue %"compiler/check:Ask" %t18, ptr %a3, 3
  %t22 = insertvalue %"compiler/check:Ask" %t20, i64 %a4, 4
  %t24 = insertvalue %"compiler/check:Ask" %t22, { i64, ptr } %a5, 5
  store %"compiler/check:Ask" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:Ask", ptr %rv
  ret %"compiler/check:Ask" %rr
}

define dso_local %"compiler/check:ValueAsk" @compiler_2fcheck_3aValueAsk_2ector(ptr %v0, i32 %a0, i64 %a1, %"compiler/source:Span" %a2, i32 %a3, i64 %a4, { i64, [3 x i64] } %a5) #0 {
entry:
  %rv = alloca %"compiler/check:ValueAsk"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/check:ValueAsk" undef, i32 %a0, 0
  %t16 = insertvalue %"compiler/check:ValueAsk" %t14, i64 %a1, 1
  %t18 = insertvalue %"compiler/check:ValueAsk" %t16, %"compiler/source:Span" %a2, 2
  %t20 = insertvalue %"compiler/check:ValueAsk" %t18, i32 %a3, 3
  %t22 = insertvalue %"compiler/check:ValueAsk" %t20, i64 %a4, 4
  %t24 = insertvalue %"compiler/check:ValueAsk" %t22, { i64, [3 x i64] } %a5, 5
  store %"compiler/check:ValueAsk" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:ValueAsk", ptr %rv
  ret %"compiler/check:ValueAsk" %rr
}

define dso_local %"compiler/check:errBind" @compiler_2fcheck_3aerrBind_2ector(ptr %v0, i32 %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %rv = alloca %"compiler/check:errBind"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/check:errBind" undef, i32 %a0, 0
  %t12 = insertvalue %"compiler/check:errBind" %t10, i64 %a1, 1
  %t14 = insertvalue %"compiler/check:errBind" %t12, i32 %a2, 2
  %t16 = insertvalue %"compiler/check:errBind" %t14, %"compiler/source:Span" %a3, 3
  store %"compiler/check:errBind" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:errBind", ptr %rv
  ret %"compiler/check:errBind" %rr
}

define dso_local %"compiler/check:fixedInit" @compiler_2fcheck_3afixedInit_2ector(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %rv = alloca %"compiler/check:fixedInit"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/check:fixedInit" undef, ptr %a0, 0
  %t8 = insertvalue %"compiler/check:fixedInit" %t6, i32 %a1, 1
  store %"compiler/check:fixedInit" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:fixedInit", ptr %rv
  ret %"compiler/check:fixedInit" %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr)
declare void @__olang_ert_req_clear()
@.d0 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"a build constant without a value" }>, align 8
@.d1 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d2 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.d3 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"a build constant of this kind (B10)" }>, align 8
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aItem_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aItem_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d4 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_bang_failed_plain(ptr)
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d5 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d6 = private constant <{ i64, [63 x i8] }> <{ i64 0, [63 x i8] c"it reads a mutable global, whose value is the running program's" }>, align 8
@.d7 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"std/prelude/iterator" }>, align 8
@.d8 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Exhausted" }>, align 8
@.d9 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"main" }>, align 8
@.d10 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"__olang_" }>, align 8
@.d11 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c"the checker asked for a frame with none open" }>, align 8
declare void @__olang_check_failed_text(ptr, { i64, ptr })
@.d12 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c"a member reached through an import, of this kind" }>, align 8
@.d13 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"At" }>, align 8
@.d14 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"'x[i]'" }>, align 8
@.d15 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"SetAt" }>, align 8
@.d16 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d17 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"a binding in a call compared as a value (S13d)" }>, align 8
@.d18 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d19 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d20 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"std/prelude/text" }>, align 8
@.d21 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"String" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@G_2ecompiler_2fcheck_2eCtEns = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eRoReturned = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2estmtAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2eclosedAll(ptr %v0, { i64, ptr } %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eRunFrom_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_8144c9e107914b58_42c61ae8c534985c = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { %"compiler/cond:Value", i1 } } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eValueOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2eexprPath(ptr %v0, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eEntriesOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emerged(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enormalSet(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorWord(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloneBinding(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aerrBind_3e_2eLen_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etakenSet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %a2, i1 %a3, ptr %a4)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aerrBind_3e_2ePus_H8b0879c0f677037d30ab876e02db27f1(ptr %v0, ptr %a0, %"compiler/check:errBind" %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eClauseLastValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/msgs:Msg" %a2)
@olang_loc_977e9a9c02703c7b_61f13f164c004b4f = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eblockOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2, %"compiler/source:Span" %a3)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ebuiltAst(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultHoldsReferences(ptr %v0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/check:errBind" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aerrBind_3e_2eAt_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchNameUnused(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCatchLoneUnused(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aerrBind_3e_2eTru_Had6203bde6d60a533558c9108ce2d205(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eTruncate_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aerrNarrow_3e_2eL_H2a7e7537a6dfd104eb96f9cf86ba43ee(ptr %v0, ptr %a0)
declare { i32, %"compiler/check:errNarrow" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aerrNarrow_3e_2eL_He0605a0bd9b7ed654a280965e7915dc5(ptr %v0, ptr %a0)
@olang_loc_b0c35ab29f6de325_6b273ecedc848f99 = external constant [0 x i8]
declare { i32, %"compiler/check:errNarrow" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aerrNarrow_3e_2eP_H4f6a37f2985e5df818fc3525c212ba25(ptr %v0, ptr %a0)
@olang_loc_642fba5880633f11_d324198387501485 = external constant [0 x i8]
@olang_loc_dc03de3e13d5d679_188e110e6bdd984d = external constant [0 x i8]
@olang_loc_8c881979be26de92_88008638e9ed454e = external constant [0 x i8]
@olang_loc_17c20fef2a95d0aa_ecd0b220b620764e = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aItem_3e_2eToArray_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/typed:Clause" @compiler_2ftyped_3aClause_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, %"compiler/source:Span" %a0, { i64, ptr } %a1, i1 %a2, ptr %a3, { i64, ptr } %a4, i64 %a5, i32 %a6)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereSite(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare %"compiler/typed:Promote" @compiler_2ftyped_3aPromote_2ector(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyAll(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare %"compiler/typed:Call" @compiler_2ftyped_3aCall_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, [2 x i64] } %a2, i32 %a3, i1 %a4)
@olang_loc_4aef7e9433005aa6_9cd0eb13e1392442 = external constant [0 x i8]
declare %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, i64 %a1, { i64, ptr } %a2, ptr %a3, i32 %a4, i32 %a5)
declare %"compiler/typed:Slice" @compiler_2ftyped_3aSlice_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
@olang_loc_89a248f11218248d_cad7b116269b1029 = external constant [0 x i8]
declare %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fast_3aPattern_26_H92ad3d4b1581d96426d44b389947861c(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_5751a3eee0d06197_8765202abe0be66b = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fast_3aPattern_26_H8f433a386540269ec523262b43568e5b(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_947efe64310efd31_ddaff5fcfd0a0175 = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatBool(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3ccompiler_2fast_3aPattern_26_3e_26_3e_2ector(ptr %v0)
@olang_loc_118f3c4f5f1d1d1a_a5abd0c9524a17be = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatWild(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_c9fc6cb82d2178b4_58d58e1b66e9a1c0 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2epatTail(ptr %v0, { i64, ptr } %a0, { i64, ptr } %a1, i64 %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fast_3aPattern_26_H1d860e259259c4952a7ac353d360c942(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_db613885cc0e77fc_341778010d8262c8 = external constant [0 x i8]
@olang_loc_69828742111b34b6_edb4f3b8774a6d1a = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_2c3f271c3afc79d5_c78bf0711ee6c699 = external constant [0 x i8]
@olang_loc_ee24f78eb0215db7_268ab47274f317a3 = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
@olang_loc_c469e1041e879ee8_15935166e400e15c = external constant [0 x i8]
@olang_loc_9b1757e0e026f0ba_88a812783a2cd816 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_68a324566e074144_ebe2d53601389a48 = external constant [0 x i8]
@olang_loc_c8bfc000fcc4ae6a_9e3397f9e2657b76 = external constant [0 x i8]
@olang_loc_1f7873e3e1cd0232_cbe2b7e345defe96 = external constant [0 x i8]
@olang_loc_10c0ac77dd4c1e27_6e0957eb7284aeab = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eToAr_H9d0f958437b2bc29fe1d416dfb9901d7(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_d83bd091a88cb87_23defb1826edd97b = external constant [0 x i8]
@olang_loc_e3488d8cce1d625_34e222cdaeebf5a1 = external constant [0 x i8]
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_700945490095e3ab_b793fb317cfa4b47 = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/check:ctSource" @compiler_2fcheck_3actSource_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3, { i64, ptr } %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_98b1a939df7bf83c_dad16d1edd3f2a28 = external constant [0 x i8]
@olang_loc_25ec48d7738ec131_33504a893c084afd = external constant [0 x i8]
@olang_loc_1c86c4e2a1d4d52a_afb2831c22759b16 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitMethod(ptr %v0, ptr %a0, %"compiler/generic:AnySlot" %a1)
declare %"compiler/ast:Param" @compiler_2fast_3aParam_2ector(ptr %v0, ptr %v1, ptr %v2, %"compiler/source:Span" %a0, i32 %a1, ptr %a2, ptr %a3)
@olang_loc_8b08af1e0b47ad17_714e6cc493d1321b = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ewrittenMut(ptr %v0, ptr %a0)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultNotComputable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebreakUnless(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %a0, ptr %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, [2 x i64] } %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeferErrorEscapes(ptr %v0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emsgOwner(ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertMsgError(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskClauseError(ptr %v0)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisGlobalBody(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTryNowhereToGo(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenErrorNotDeclared(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTryErrorNotDeclared(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %a0)
@olang_loc_a993cda7425ca237_a63aa9ad7bf8dd03 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1)
declare %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %v0, i32 %a0, i64 %a1)
@olang_loc_8e26fbb1c5557eef_13e6cc5de085742b = external constant [0 x i8]
@olang_loc_6d702b04e725ae1a_71c02c55b3dfc416 = external constant [0 x i8]
declare %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i1 %a2, i1 %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eExportMethod(ptr %v0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eExportGeneric(ptr %v0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eExportName(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexportParam(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eExportType(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexportArray(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eExportResult(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainStruct(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforeignRef(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %a0)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorRole(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2eopShapeOf(ptr %v0, { i64, ptr } %a0)
@G_2ecompiler_2fcheck_2eOpShapes = external constant <{ [8 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [16 x i8] }>
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnErrors(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodCannotFail(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edrain(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaks1(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAsCanFail(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnhandledFallibleCall(ptr %v0)
@olang_loc_3f3d818644d50cc7_38dbc52e232a8b93 = external constant [0 x i8]
@olang_loc_808d16f594578c21_dfc8c283c70478a5 = external constant [0 x i8]
@olang_loc_1aa49c7f94741e71_4937354175d6cb9d = external constant [0 x i8]
@olang_loc_1a7e3b998d35a364_c6b9293917078f0 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvWords(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1)
@olang_loc_ce45aa27b33b13c4_efb6d2bad65aad00 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisOver(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elengthsMeet(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_a78beee7b0d01a06_c23e8f3cd3901b22 = external constant [0 x i8]
@olang_loc_a9ac84188a5d3ced_8a30b05829c2589 = external constant [0 x i8]
@olang_loc_d343f6dbe85f33a0_61dfe5c423c7544c = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_H2d42092ce658fb6cce0104fa754a4e33(ptr %v0, ptr %a0)
@olang_loc_fd7c4531a6f9112_8820f62eca2e3ad6 = external constant [0 x i8]
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_Hbcd822ae67306ca6a025f17ed2cfb61c(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFoldKnown(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
@olang_loc_ddeebe9155436d6a_19ee353760b572b6 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalType(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_2c6c6a9e0d4d53fe_41be050b28a8c6c2 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnValue(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, { i64, ptr } %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflMember(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, i32 %a4)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2eisLimitName(ptr %v0, { i64, ptr } %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elimit(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4)
@olang_loc_8d8450bdf58ba933_21a3ad59bc75be77 = external constant [0 x i8]
@olang_loc_c41dfbcd22d81110_5c09edf2d4d23d4 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eenumCase(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, ptr } %a5, { i64, ptr } %a6)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_d2fbf365f111393d_99a61c47f5e25be1 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericCase(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, ptr } %a5, i32 %a6)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowedName(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efield(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, i32 %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteWrite(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaptureReadOnly(ptr %v0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLocal(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFix(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyLent(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteRo(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroNeed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eImmutable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecapturedValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyRefWrite(ptr %v0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteWritable(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare ptr @compiler_2fcheck_2eunwrapped(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyCopyWrite(ptr %v0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echosenAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econdChoosesPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elastName(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondLentWritable(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadOnlyToWritable(ptr %v0)
@olang_loc_3b10a40791a2a251_bad5d69bdb4172c5 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowCopy(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNarrowedWrite(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssignIntoTried(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eWriteIntoCallValue(ptr %v0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutBefore(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMutOnValueParam(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebracketIn(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4, i64 %a5, i1 %a6)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAtUndeclared(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotIndexable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLenKey(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeCase(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, %"compiler/source:Span" %a4, ptr %a5, i32 %a6, ptr %a7)
declare %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_Hc07a7e56a24d8f1225398db99ea19a4b(ptr %v0, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2)
declare i64 @compiler_2fcheck_2emeetPerm(i64 %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eSetAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1, %"compiler/typed:Local" %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAltBindingType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/typed:Bind" @compiler_2ftyped_3aBind_2ector(ptr %v0, ptr %v1, i32 %a0, ptr %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBind_26_3e_2ePus_H9902a4d50743896fa3c9f4890ae04f69(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCase(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare %"compiler/msgs:Msg" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoCase(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2ePatternType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2eToArray_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1, i64 %a2)
declare %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eand2(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprPattern(ptr %v0, ptr %v1, ptr %a0, ptr %a1, ptr %a2, i32 %a3, ptr %a4, i64 %a5, i1 %a6)
@olang_loc_2bba12d772c132ef_de888473626934f3 = external constant [0 x i8]
@olang_loc_1f453287a90ee701_f75bf1e5be6f432d = external constant [0 x i8]
declare i1 @compiler_2fcheck_2erefWrittenTop(ptr %v0, ptr %a0)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aGap_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResetAny(ptr %v0, ptr %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fsource_3aSpan_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aatRec_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2ftypes_3aListId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fcheck_3aroOrigin_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H94cbbacdefacbf11591e45fa927fb1cb(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroArg_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroFn_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20std_2fprelude_2flis_H596e3d714cead58c6bb1a410db388b73(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroDeepArg_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAsk_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aEmbedAsk_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAssertAsk_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aValueAsk_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aContractInfo_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aContractAsk_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20compiler_2fcheck_3afixedInit_3e_2ector(ptr %v0)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H4c470d2e80d9fd53b2c4a8b35e81296f(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H64396385e4e6d43afa926b839ce2258a(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a2)
declare { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H6388cc594ade7977543a45717e2b755f(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAsk_3e_2eLen_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %a0)
declare %"compiler/check:Ask" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAsk_3e_2eAt_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eRunning(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAsk_3e_2eSetAt_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/check:Ask" %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAsk_3e_2eTruncate_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAssertAsk_3e_2eL_H74c4c659bc848d1046c0a3f6eab69368(ptr %v0, ptr %a0)
declare %"compiler/check:AssertAsk" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAssertAsk_3e_2eA_Hdc7a201c0afbc93ed6dfeec3b1f47711(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAssertAsk_3e_2eS_Hc42af0083e860bde3bfdbe1629d1fbcf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/check:AssertAsk" %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAssertAsk_3e_2eT_H5b1bf5f8eb2d6b750ac9501715f6a378(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSlotKey(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_Had7920a3eff3220b2e12299d961f9124(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnBody(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %v0, i64 %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i1 %a4, i1 %a5)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInferThroughBounds(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexistingIn(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskDefaultExisting(ptr %v0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estrBytes(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeqMethod(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epartsHaveEq(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordCount(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflTryList(ptr %v0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistItems(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/check:reflList" %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescriptor(ptr %v0, ptr %a0, %"compiler/check:reflList" %a1, i64 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflBind(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflUnbind(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDecide(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_ef99e54d7427d8e6_6c42201a9dddf792 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflFilterUndecided(ptr %v0)
@G_2ecompiler_2fcheck_2eRoStored = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i64 %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare i1 @compiler_2fcheck_2epurePlace(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
declare %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emeets(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etyOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseValueType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5, %"compiler/source:Span" %a6, %"compiler/source:Span" %a7)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eborrowedSource(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
@olang_loc_5c35d65bf515aa44_9edccba99dd9b7f8 = external constant [0 x i8]
@olang_loc_19568a04807ed851_528b5bfe222c3865 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, ptr } %a7)
@olang_loc_130b25e968db6b32_47c65c95f253846 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkBody(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eYieldInLambda(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eYieldOutside(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eYieldInDefer(ptr %v0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eYieldInJoin(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eYieldPastDefer(ptr %v0)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresultAt(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2eclausesBreak(ptr %v0, { i64, ptr } %a0, i32 %a1)
declare i1 @compiler_2fcheck_2estmtsBreak(ptr %v0, { i64, ptr } %a0, i32 %a1)
declare i1 @compiler_2fcheck_2earmsBreak(ptr %v0, { i64, ptr } %a0, i32 %a1)
@olang_loc_a0498c486f94284f_fcfc69224e16b833 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2earmBreaks(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2eexprsBreak(ptr %v0, { i64, ptr } %a0, i32 %a1)
@olang_loc_c9ff66f8ef4bd5b7_7fc0b0455d81db0b = external constant [0 x i8]
@olang_loc_bff01f20505ccdb5_4aab420456ab469 = external constant [0 x i8]
@olang_loc_d195b38137e2d30_7d67c1d5e7f3802c = external constant [0 x i8]
declare void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aItem_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
