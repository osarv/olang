; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/check:opShape" = type { { i64, ptr }, i64, i1, i1 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/check:b5aWalk" = type { i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1 }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, [3 x i64] }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr } }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i32, i64, i64, i64, i64, i64, i1, i64, i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64 }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] } }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1 }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/ast:If" = type { ptr, ptr, ptr }
%"compiler/check:roFn" = type { i64, i64, { i64, [3 x i64] }, { i64, ptr } }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1 }
%"compiler/check:litv" = type { i1, i1, i1, i64, double, i1 }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"compiler/ast:Multi" = type { { i64, ptr }, i1, { i64, ptr } }
%"compiler/check:narrowed" = type { i64, i64, i32, i64, i64 }
%"compiler/load:Import" = type { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, { i64, ptr }, i64, i64 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, { i64, [2 x i64] }, i32, i1 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1 }
%"compiler/generic:Unmet" = type { i64, i32, i32, i1, i1, i1 }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr } }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/check:Gap" = type { i64, %"compiler/source:Span", { i64, ptr } }
define dso_local void @compiler_2fcheck_2eOpShapes_2einit() #0 {
entry:
  %l0 = alloca %"compiler/check:opShape"
  %l1 = alloca %"compiler/check:opShape"
  %l2 = alloca %"compiler/check:opShape"
  %l3 = alloca %"compiler/check:opShape"
  %l4 = alloca %"compiler/check:opShape"
  %l5 = alloca %"compiler/check:opShape"
  %l6 = alloca %"compiler/check:opShape"
  %l7 = alloca %"compiler/check:opShape"
  %l8 = alloca %"compiler/check:opShape"
  %l9 = alloca %"compiler/check:opShape"
  %l10 = alloca %"compiler/check:opShape"
  %l11 = alloca %"compiler/check:opShape"
  %l12 = alloca %"compiler/check:opShape"
  %l13 = alloca %"compiler/check:opShape"
  %l14 = alloca %"compiler/check:opShape"
  %l15 = alloca %"compiler/check:opShape"
  %l16 = alloca %"compiler/check:opShape"
  %l17 = alloca %"compiler/check:opShape"
  %l18 = alloca %"compiler/check:opShape"
  %l19 = alloca %"compiler/check:opShape"
  %l20 = alloca %"compiler/check:opShape"
  %l21 = alloca %"compiler/check:opShape"
  %l22 = alloca [22 x %"compiler/check:opShape"]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = load ptr, ptr @__olang_prog_scope
  %t3 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t1, ptr %t2, { i64, ptr } { i64 4, ptr @.d0 }, i64 1, i1 true, i1 true)
  store %"compiler/check:opShape" %t3, ptr %l0
  br label %bb1
bb1:
  %t4 = load ptr, ptr @__olang_prog_scope
  %t5 = load ptr, ptr @__olang_prog_scope
  %t6 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t4, ptr %t5, { i64, ptr } { i64 5, ptr @.d1 }, i64 1, i1 true, i1 true)
  store %"compiler/check:opShape" %t6, ptr %l1
  br label %bb2
bb2:
  %t7 = load ptr, ptr @__olang_prog_scope
  %t8 = load ptr, ptr @__olang_prog_scope
  %t9 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t7, ptr %t8, { i64, ptr } { i64 3, ptr @.d2 }, i64 1, i1 true, i1 true)
  store %"compiler/check:opShape" %t9, ptr %l2
  br label %bb3
bb3:
  %t10 = load ptr, ptr @__olang_prog_scope
  %t11 = load ptr, ptr @__olang_prog_scope
  %t12 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t10, ptr %t11, { i64, ptr } { i64 3, ptr @.d3 }, i64 1, i1 true, i1 true)
  store %"compiler/check:opShape" %t12, ptr %l3
  br label %bb4
bb4:
  %t13 = load ptr, ptr @__olang_prog_scope
  %t14 = load ptr, ptr @__olang_prog_scope
  %t15 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t13, ptr %t14, { i64, ptr } { i64 3, ptr @.d4 }, i64 1, i1 true, i1 true)
  store %"compiler/check:opShape" %t15, ptr %l4
  br label %bb5
bb5:
  %t16 = load ptr, ptr @__olang_prog_scope
  %t17 = load ptr, ptr @__olang_prog_scope
  %t18 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t16, ptr %t17, { i64, ptr } { i64 6, ptr @.d5 }, i64 1, i1 true, i1 true)
  store %"compiler/check:opShape" %t18, ptr %l5
  br label %bb6
bb6:
  %t19 = load ptr, ptr @__olang_prog_scope
  %t20 = load ptr, ptr @__olang_prog_scope
  %t21 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t19, ptr %t20, { i64, ptr } { i64 3, ptr @.d6 }, i64 0, i1 true, i1 true)
  store %"compiler/check:opShape" %t21, ptr %l6
  br label %bb7
bb7:
  %t22 = load ptr, ptr @__olang_prog_scope
  %t23 = load ptr, ptr @__olang_prog_scope
  %t24 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t22, ptr %t23, { i64, ptr } { i64 4, ptr @.d7 }, i64 1, i1 true, i1 true)
  store %"compiler/check:opShape" %t24, ptr %l7
  br label %bb8
bb8:
  %t25 = load ptr, ptr @__olang_prog_scope
  %t26 = load ptr, ptr @__olang_prog_scope
  %t27 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t25, ptr %t26, { i64, ptr } { i64 2, ptr @.d8 }, i64 1, i1 true, i1 true)
  store %"compiler/check:opShape" %t27, ptr %l8
  br label %bb9
bb9:
  %t28 = load ptr, ptr @__olang_prog_scope
  %t29 = load ptr, ptr @__olang_prog_scope
  %t30 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t28, ptr %t29, { i64, ptr } { i64 5, ptr @.d9 }, i64 2, i1 false, i1 true)
  store %"compiler/check:opShape" %t30, ptr %l9
  br label %bb10
bb10:
  %t31 = load ptr, ptr @__olang_prog_scope
  %t32 = load ptr, ptr @__olang_prog_scope
  %t33 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t31, ptr %t32, { i64, ptr } { i64 5, ptr @.d10 }, i64 2, i1 true, i1 true)
  store %"compiler/check:opShape" %t33, ptr %l10
  br label %bb11
bb11:
  %t34 = load ptr, ptr @__olang_prog_scope
  %t35 = load ptr, ptr @__olang_prog_scope
  %t36 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t34, ptr %t35, { i64, ptr } { i64 6, ptr @.d11 }, i64 1, i1 true, i1 true)
  store %"compiler/check:opShape" %t36, ptr %l11
  br label %bb12
bb12:
  %t37 = load ptr, ptr @__olang_prog_scope
  %t38 = load ptr, ptr @__olang_prog_scope
  %t39 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t37, ptr %t38, { i64, ptr } { i64 5, ptr @.d12 }, i64 1, i1 true, i1 true)
  store %"compiler/check:opShape" %t39, ptr %l12
  br label %bb13
bb13:
  %t40 = load ptr, ptr @__olang_prog_scope
  %t41 = load ptr, ptr @__olang_prog_scope
  %t42 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t40, ptr %t41, { i64, ptr } { i64 6, ptr @.d13 }, i64 1, i1 true, i1 true)
  store %"compiler/check:opShape" %t42, ptr %l13
  br label %bb14
bb14:
  %t43 = load ptr, ptr @__olang_prog_scope
  %t44 = load ptr, ptr @__olang_prog_scope
  %t45 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t43, ptr %t44, { i64, ptr } { i64 9, ptr @.d14 }, i64 1, i1 true, i1 true)
  store %"compiler/check:opShape" %t45, ptr %l14
  br label %bb15
bb15:
  %t46 = load ptr, ptr @__olang_prog_scope
  %t47 = load ptr, ptr @__olang_prog_scope
  %t48 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t46, ptr %t47, { i64, ptr } { i64 10, ptr @.d15 }, i64 1, i1 true, i1 true)
  store %"compiler/check:opShape" %t48, ptr %l15
  br label %bb16
bb16:
  %t49 = load ptr, ptr @__olang_prog_scope
  %t50 = load ptr, ptr @__olang_prog_scope
  %t51 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t49, ptr %t50, { i64, ptr } { i64 6, ptr @.d16 }, i64 0, i1 true, i1 true)
  store %"compiler/check:opShape" %t51, ptr %l16
  br label %bb17
bb17:
  %t52 = load ptr, ptr @__olang_prog_scope
  %t53 = load ptr, ptr @__olang_prog_scope
  %t54 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t52, ptr %t53, { i64, ptr } { i64 3, ptr @.d17 }, i64 0, i1 true, i1 true)
  store %"compiler/check:opShape" %t54, ptr %l17
  br label %bb18
bb18:
  %t55 = load ptr, ptr @__olang_prog_scope
  %t56 = load ptr, ptr @__olang_prog_scope
  %t57 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t55, ptr %t56, { i64, ptr } { i64 3, ptr @.d18 }, i64 0, i1 true, i1 true)
  store %"compiler/check:opShape" %t57, ptr %l18
  br label %bb19
bb19:
  %t58 = load ptr, ptr @__olang_prog_scope
  %t59 = load ptr, ptr @__olang_prog_scope
  %t60 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t58, ptr %t59, { i64, ptr } { i64 3, ptr @.d19 }, i64 0, i1 true, i1 false)
  store %"compiler/check:opShape" %t60, ptr %l19
  br label %bb20
bb20:
  %t61 = load ptr, ptr @__olang_prog_scope
  %t62 = load ptr, ptr @__olang_prog_scope
  %t63 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t61, ptr %t62, { i64, ptr } { i64 2, ptr @.d20 }, i64 1, i1 true, i1 false)
  store %"compiler/check:opShape" %t63, ptr %l20
  br label %bb21
bb21:
  %t64 = load ptr, ptr @__olang_prog_scope
  %t65 = load ptr, ptr @__olang_prog_scope
  %t66 = call %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %t64, ptr %t65, { i64, ptr } { i64 3, ptr @.d21 }, i64 0, i1 true, i1 false)
  store %"compiler/check:opShape" %t66, ptr %l21
  br label %bb22
bb22:
  %t67 = load %"compiler/check:opShape", ptr %l0
  %t68 = load %"compiler/check:opShape", ptr %l1
  %t69 = load %"compiler/check:opShape", ptr %l2
  %t70 = load %"compiler/check:opShape", ptr %l3
  %t71 = load %"compiler/check:opShape", ptr %l4
  %t72 = load %"compiler/check:opShape", ptr %l5
  %t73 = load %"compiler/check:opShape", ptr %l6
  %t74 = load %"compiler/check:opShape", ptr %l7
  %t75 = load %"compiler/check:opShape", ptr %l8
  %t76 = load %"compiler/check:opShape", ptr %l9
  %t77 = load %"compiler/check:opShape", ptr %l10
  %t78 = load %"compiler/check:opShape", ptr %l11
  %t79 = load %"compiler/check:opShape", ptr %l12
  %t80 = load %"compiler/check:opShape", ptr %l13
  %t81 = load %"compiler/check:opShape", ptr %l14
  %t82 = load %"compiler/check:opShape", ptr %l15
  %t83 = load %"compiler/check:opShape", ptr %l16
  %t84 = load %"compiler/check:opShape", ptr %l17
  %t85 = load %"compiler/check:opShape", ptr %l18
  %t86 = load %"compiler/check:opShape", ptr %l19
  %t87 = load %"compiler/check:opShape", ptr %l20
  %t88 = load %"compiler/check:opShape", ptr %l21
  %t89 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 0
  store %"compiler/check:opShape" %t67, ptr %t89
  %t90 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 1
  store %"compiler/check:opShape" %t68, ptr %t90
  %t91 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 2
  store %"compiler/check:opShape" %t69, ptr %t91
  %t92 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 3
  store %"compiler/check:opShape" %t70, ptr %t92
  %t93 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 4
  store %"compiler/check:opShape" %t71, ptr %t93
  %t94 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 5
  store %"compiler/check:opShape" %t72, ptr %t94
  %t95 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 6
  store %"compiler/check:opShape" %t73, ptr %t95
  %t96 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 7
  store %"compiler/check:opShape" %t74, ptr %t96
  %t97 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 8
  store %"compiler/check:opShape" %t75, ptr %t97
  %t98 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 9
  store %"compiler/check:opShape" %t76, ptr %t98
  %t99 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 10
  store %"compiler/check:opShape" %t77, ptr %t99
  %t100 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 11
  store %"compiler/check:opShape" %t78, ptr %t100
  %t101 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 12
  store %"compiler/check:opShape" %t79, ptr %t101
  %t102 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 13
  store %"compiler/check:opShape" %t80, ptr %t102
  %t103 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 14
  store %"compiler/check:opShape" %t81, ptr %t103
  %t104 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 15
  store %"compiler/check:opShape" %t82, ptr %t104
  %t105 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 16
  store %"compiler/check:opShape" %t83, ptr %t105
  %t106 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 17
  store %"compiler/check:opShape" %t84, ptr %t106
  %t107 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 18
  store %"compiler/check:opShape" %t85, ptr %t107
  %t108 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 19
  store %"compiler/check:opShape" %t86, ptr %t108
  %t109 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 20
  store %"compiler/check:opShape" %t87, ptr %t109
  %t110 = getelementptr [22 x %"compiler/check:opShape"], ptr %l22, i64 0, i64 21
  store %"compiler/check:opShape" %t88, ptr %t110
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2fcheck_2eOpShapes, ptr %l22, i64 704, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l17 = alloca { i64, ptr }
  %l23 = alloca i1
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t35 = call i1 @compiler_2fcheck_2estmtAssigns(ptr %v0, ptr %v1, ptr %t28, { i64, ptr } %a1)
  store i1 %t35, ptr %l23
  br label %bb8
bb8:
  %t36 = load i1, ptr %l23, !tbaa !21
  br i1 %t36, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb4
bb13:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ebangOf(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l13 = alloca { i64, ptr }
  %l18 = alloca i1
  %l25 = alloca i1
  %l32 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i8, ptr %t19, i64 %t16
  %t21 = load i8, ptr %t20, !tbaa !32
  store i8 %t21, ptr %l5, !tbaa !22
  %t23 = load i8, ptr %l5, !tbaa !22
  %t25 = icmp eq i8 %t23, 40
  br i1 %t25, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb7
bb6:
  %t27 = load i8, ptr %l5, !tbaa !22
  %t29 = icmp eq i8 %t27, 91
  store i1 %t29, ptr %l18, !tbaa !21
  br label %bb7
bb7:
  %t31 = load i1, ptr %l18, !tbaa !21
  br i1 %t31, label %bb8, label %bb9
bb8:
  %t32 = load i64, ptr %l1, !tbaa !24
  %t34 = add i64 %t32, 1
  store i64 %t34, ptr %l1, !tbaa !24
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t36 = load i8, ptr %l5, !tbaa !22
  %t38 = icmp eq i8 %t36, 41
  br i1 %t38, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb13
bb12:
  %t40 = load i8, ptr %l5, !tbaa !22
  %t42 = icmp eq i8 %t40, 93
  store i1 %t42, ptr %l25, !tbaa !21
  br label %bb13
bb13:
  %t44 = load i1, ptr %l25, !tbaa !21
  br i1 %t44, label %bb14, label %bb15
bb14:
  %t45 = load i64, ptr %l1, !tbaa !24
  %t47 = sub i64 %t45, 1
  store i64 %t47, ptr %l1, !tbaa !24
  br label %bb16
bb15:
  br label %bb16
bb16:
  %t49 = load i8, ptr %l5, !tbaa !22
  %t51 = icmp eq i8 %t49, 32
  br i1 %t51, label %bb17, label %bb18
bb17:
  %t53 = load i64, ptr %l1, !tbaa !24
  %t55 = icmp eq i64 %t53, 0
  store i1 %t55, ptr %l32, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb19
bb19:
  %t57 = load i1, ptr %l32, !tbaa !21
  br i1 %t57, label %bb20, label %bb21
bb20:
  %t58 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t59 = extractvalue { i64, ptr } { i64 1, ptr @.d22 }, 1
  %t60 = extractvalue { i64, ptr } { i64 1, ptr @.d22 }, 0
  %t62 = extractvalue { i64, ptr } %t58, 1
  %t63 = extractvalue { i64, ptr } %t58, 0
  %t64 = add i64 %t60, %t63
  %t65 = extractvalue { i64, ptr } { i64 1, ptr @.d23 }, 1
  %t66 = extractvalue { i64, ptr } { i64 1, ptr @.d23 }, 0
  %t67 = add i64 %t64, %t66
  %t68 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t67)
  call void @olang_textcopy(ptr %t68, ptr %t59, i64 %t60)
  %t69 = getelementptr i8, ptr %t68, i64 %t60
  call void @olang_textcopy(ptr %t69, ptr %t62, i64 %t63)
  %t70 = getelementptr i8, ptr %t69, i64 %t63
  call void @olang_textcopy(ptr %t70, ptr %t65, i64 %t66)
  %t71 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t68, 1
  call void @__olang_scope_close(ptr %s2)
  store { i64, ptr } %t72, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb23:
  %t74 = load i64, ptr %l3, !tbaa !24
  %t76 = add i64 %t74, 1
  store i64 %t76, ptr %l3, !tbaa !24
  br label %bb1
bb24:
  %t78 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t78, 1
  %t81 = extractvalue { i64, ptr } %t78, 0
  %t82 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t81)
  call void @olang_textcopy(ptr %t82, ptr %t80, i64 %t81)
  %t83 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  store { i64, ptr } %t84, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eExprBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l4 = alloca ptr
  %l5 = alloca i64
  %l8 = alloca { i64, ptr }
  %l14 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store ptr %a0, ptr %l4, !tbaa !29
  store i64 %a1, ptr %l5, !tbaa !24
  %t3 = icmp sge i64 0, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = icmp sle i64 0, 2305843009213693951
  br i1 %t5, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_a6ae1e9a693d05c9_888d1f7981f90365)
  unreachable
bb3:
  %t7 = mul i64 0, 4
  %t8 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t7)
  %t9 = insertvalue { i64, ptr } undef, i64 0, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  store { i64, ptr } %t10, ptr %l8, !tbaa !27
  %t11 = icmp sge i64 0, 0
  br i1 %t11, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_a6ae1e9a693d05c9_888d1f7981f90365)
  unreachable
bb5:
  %t13 = icmp sle i64 0, 2305843009213693951
  br i1 %t13, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_a6ae1e9a693d05c9_888d1f7981f90365)
  unreachable
bb7:
  %t15 = mul i64 0, 4
  %t16 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 0, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t22 = load i64, ptr %l5, !tbaa !24
  %t23 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t27 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eExprBodyIn(ptr %v0, ptr %s0, ptr %s0, ptr %v1, ptr %t21, i64 %t22, i64 -1, { i64, ptr } %t23, { i64, ptr } %t18, ptr %a2, i32 %a3)
  store i64 %t27, ptr %l14
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_a6ae1e9a693d05c9_888d1f7981f90365)
  unreachable
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load i64, ptr %l14, !tbaa !24
  store i64 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPlace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l2, !tbaa !29
  store ptr %t5, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t6 = load ptr, ptr %l13, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l13, !tbaa !29
  %t10 = load i64, ptr %t9
  %t12 = icmp eq i64 %t10, 1
  store i1 %t12, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l14, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t16, i32 0, i32 1
  %t18 = load i32, ptr %t17
  store i32 %t18, ptr %l3, !tbaa !23
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t22, i32 0, i32 2
  %t24 = load i64, ptr %t23
  store i64 %t24, ptr %l4, !tbaa !24
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = getelementptr { i64, [4 x i64] }, ptr %t26, i32 0, i32 1
  %t29 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t28, i32 0, i32 3
  %t30 = load i32, ptr %t29
  store i32 %t30, ptr %l5, !tbaa !23
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t34 = load i64, ptr %l4, !tbaa !24
  %t35 = load i32, ptr %l5, !tbaa !23
  %t36 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aGlobal(ptr %v0, ptr %v1, ptr %t32, ptr %t33, i64 %t34, i32 %t35, i32 %t36)
  br label %bb9
bb9:
  br label %bb51
bb10:
  %t42 = load ptr, ptr %l2, !tbaa !29
  store ptr %t42, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t43 = load ptr, ptr %l28, !tbaa !29
  %t44 = icmp ne ptr %t43, null
  br i1 %t44, label %bb11, label %bb12
bb11:
  %t46 = load ptr, ptr %l28, !tbaa !29
  %t47 = load i64, ptr %t46
  %t49 = icmp eq i64 %t47, 2
  store i1 %t49, ptr %l29, !tbaa !21
  br label %bb12
bb12:
  %t50 = load i1, ptr %l29, !tbaa !21
  br i1 %t50, label %bb13, label %bb14
bb13:
  %t51 = load ptr, ptr %l2, !tbaa !29
  %t53 = getelementptr { i64, [4 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t53, i32 0, i32 2
  %t55 = load ptr, ptr %t54
  store ptr %t55, ptr %l6, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t59 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t57, ptr %t58, ptr %t59)
  br label %bb16
bb16:
  br label %bb51
bb17:
  %t64 = load ptr, ptr %l2, !tbaa !29
  store ptr %t64, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t65 = load ptr, ptr %l38, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb18, label %bb19
bb18:
  %t68 = load ptr, ptr %l38, !tbaa !29
  %t69 = load i64, ptr %t68
  %t71 = icmp eq i64 %t69, 3
  store i1 %t71, ptr %l39, !tbaa !21
  br label %bb19
bb19:
  %t72 = load i1, ptr %l39, !tbaa !21
  br i1 %t72, label %bb20, label %bb21
bb20:
  %t73 = load ptr, ptr %l2, !tbaa !29
  %t75 = getelementptr { i64, [4 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t75, i32 0, i32 2
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l7, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t81 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t79, ptr %t80, ptr %t81)
  br label %bb23
bb23:
  br label %bb51
bb24:
  %t86 = load ptr, ptr %l2, !tbaa !29
  store ptr %t86, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t87 = load ptr, ptr %l48, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb25, label %bb26
bb25:
  %t90 = load ptr, ptr %l48, !tbaa !29
  %t91 = load i64, ptr %t90
  %t93 = icmp eq i64 %t91, 4
  store i1 %t93, ptr %l49, !tbaa !21
  br label %bb26
bb26:
  %t94 = load i1, ptr %l49, !tbaa !21
  br i1 %t94, label %bb27, label %bb28
bb27:
  %t95 = load ptr, ptr %l2, !tbaa !29
  %t97 = getelementptr { i64, [4 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t97, i32 0, i32 2
  %t99 = load ptr, ptr %t98
  store ptr %t99, ptr %l8, !tbaa !29
  br label %bb29
bb28:
  br label %bb32
bb29:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t103 = load ptr, ptr %l8, !tbaa !29
  %t105 = getelementptr %"compiler/typed:Elem", ptr %t103, i32 0, i32 0
  %t106 = load ptr, ptr %t105, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t101, ptr %t102, ptr %t106)
  br label %bb30
bb30:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load ptr, ptr %l1, !tbaa !29
  %t113 = load ptr, ptr %l8, !tbaa !29
  %t115 = getelementptr %"compiler/typed:Elem", ptr %t113, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t111, ptr %t112, ptr %t116)
  br label %bb31
bb31:
  br label %bb51
bb32:
  %t121 = load ptr, ptr %l2, !tbaa !29
  store ptr %t121, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t122 = load ptr, ptr %l64, !tbaa !29
  %t123 = icmp ne ptr %t122, null
  br i1 %t123, label %bb33, label %bb34
bb33:
  %t125 = load ptr, ptr %l64, !tbaa !29
  %t126 = load i64, ptr %t125
  %t128 = icmp eq i64 %t126, 5
  store i1 %t128, ptr %l65, !tbaa !21
  br label %bb34
bb34:
  %t129 = load i1, ptr %l65, !tbaa !21
  br i1 %t129, label %bb35, label %bb36
bb35:
  %t130 = load ptr, ptr %l2, !tbaa !29
  %t132 = getelementptr { i64, [4 x i64] }, ptr %t130, i32 0, i32 1
  %t133 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t132, i32 0, i32 2
  %t134 = load ptr, ptr %t133
  store ptr %t134, ptr %l9, !tbaa !29
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load ptr, ptr %l1, !tbaa !29
  %t138 = load ptr, ptr %l9, !tbaa !29
  %t140 = getelementptr %"compiler/typed:Payload", ptr %t138, i32 0, i32 0
  %t141 = load ptr, ptr %t140, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t136, ptr %t137, ptr %t141)
  br label %bb38
bb38:
  br label %bb51
bb39:
  %t146 = load ptr, ptr %l2, !tbaa !29
  store ptr %t146, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t147 = load ptr, ptr %l75, !tbaa !29
  %t148 = icmp ne ptr %t147, null
  br i1 %t148, label %bb40, label %bb41
bb40:
  %t150 = load ptr, ptr %l75, !tbaa !29
  %t151 = load i64, ptr %t150
  %t153 = icmp eq i64 %t151, 6
  store i1 %t153, ptr %l76, !tbaa !21
  br label %bb41
bb41:
  %t154 = load i1, ptr %l76, !tbaa !21
  br i1 %t154, label %bb42, label %bb43
bb42:
  %t155 = load ptr, ptr %l2, !tbaa !29
  %t157 = getelementptr { i64, [4 x i64] }, ptr %t155, i32 0, i32 1
  %t158 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t157, i32 0, i32 2
  %t159 = load ptr, ptr %t158
  store ptr %t159, ptr %l10, !tbaa !29
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load ptr, ptr %l1, !tbaa !29
  %t163 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t161, ptr %t162, ptr %t163)
  br label %bb45
bb45:
  br label %bb51
bb46:
  br i1 true, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_b2a10b57ca8f7dfa_ebdfac3cc9f6695e)
  unreachable
bb51:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l24 = alloca i1
  %l28 = alloca i1
  %l31 = alloca i1
  %l35 = alloca i1
  %l43 = alloca i32
  %l46 = alloca ptr
  %l47 = alloca ptr
  %l52 = alloca i32
  %l69 = alloca ptr
  %l70 = alloca i32
  %l75 = alloca i32
  %l76 = alloca i64
  %l79 = alloca ptr
  %l80 = alloca ptr
  %l84 = alloca i64
  %l90 = alloca i1
  %l94 = alloca ptr
  %l99 = alloca i32
  %l100 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l119 = alloca ptr
  %l124 = alloca i32
  %l125 = alloca { i64, ptr }
  %l132 = alloca { i64, ptr }
  %l144 = alloca ptr
  %l145 = alloca ptr
  %l150 = alloca i32
  %l159 = alloca ptr
  %l164 = alloca i32
  %l165 = alloca { i64, ptr }
  %l172 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s18 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i32, ptr %l2, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t5, %t6
  store i1 %t9, ptr %l24, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l24, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i32, ptr %l2, !tbaa !23
  %t14 = icmp eq i32 %t12, 0
  store i1 %t14, ptr %l28, !tbaa !21
  br label %bb6
bb6:
  %t16 = load i1, ptr %l28, !tbaa !21
  br i1 %t16, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb10
bb8:
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr %"compiler/check:b5aWalk", ptr %t17, i32 0, i32 5
  %t20 = load i32, ptr %l2, !tbaa !23
  %t23 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_Hb3133f486435530b533aaf49461c92b5(ptr %v1, ptr %t19, i32 %t20)
  store i1 %t23, ptr %l35
  br label %bb9
bb9:
  %t24 = load i1, ptr %l35, !tbaa !21
  store i1 %t24, ptr %l31, !tbaa !21
  br label %bb10
bb10:
  %t25 = load i1, ptr %l31, !tbaa !21
  br i1 %t25, label %bb11, label %bb12
bb11:
  br label %ret
bb12:
  br label %bb13
bb13:
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr %"compiler/check:b5aWalk", ptr %t26, i32 0, i32 5
  %t29 = load i32, ptr %l2, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H64d9be73b6c9bed004c541bdf7f0ca0a(ptr %v1, ptr %t28, i32 %t29, i1 true)
  br label %bb14
bb14:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  %t38 = load i32, ptr %l2, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l43
  br label %bb15
bb15:
  %t42 = load i32, ptr %l43
  store i32 %t42, ptr %l4
  %t43 = load i32, ptr %l4
  %t45 = trunc i64 20 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb21
bb18:
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l46, !tbaa !29
  %t49 = load ptr, ptr %l1, !tbaa !29
  store ptr %t49, ptr %l47, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %l2, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t59, ptr %l52
  br label %bb19
bb19:
  %t60 = load i64, ptr %l3, !tbaa !24
  %t62 = add i64 %t60, 1
  %t63 = load ptr, ptr %l46, !tbaa !29
  %t64 = load ptr, ptr %l47, !tbaa !29
  %t65 = load i32, ptr %l52, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStr(ptr %v0, ptr %v1, ptr %t63, ptr %t64, i32 %t65, i64 %t62)
  br label %bb20
bb20:
  br label %bb82
bb21:
  %t67 = load i32, ptr %l4
  %t69 = trunc i64 18 to i32
  %t70 = icmp eq i32 %t67, %t69
  br i1 %t70, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb60
bb24:
  store %olang.scope zeroinitializer, ptr %s4
  %t72 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } { i64 3, ptr @.d24 }, 0
  %t73 = insertvalue [2 x { i64, ptr }] %t72, { i64, ptr } { i64 3, ptr @.d25 }, 1
  %t75 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 32, i64 8)
  store [2 x { i64, ptr }] %t73, ptr %t75
  store ptr %t75, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  %t77 = load ptr, ptr %l5
  store i64 2, ptr %l7, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s5
  %t80 = load i64, ptr %l6, !tbaa !24
  %t81 = load i64, ptr %l7, !tbaa !24
  %t84 = icmp slt i64 %t80, %t81
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s5)
  br label %bb37
bb27:
  br label %bb28
bb28:
  %t88 = load ptr, ptr %l5
  %t89 = load i64, ptr %l6, !tbaa !24
  %t92 = getelementptr [2 x { i64, ptr }], ptr %t88, i64 0, i64 %t89
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !37
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/check:Checker", ptr %t95, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !29
  store ptr %t98, ptr %l69, !tbaa !29
  %t99 = load i32, ptr %l2, !tbaa !23
  store i32 %t99, ptr %l70, !tbaa !23
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/check:Checker", ptr %t100, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = getelementptr %"compiler/generic:Program", ptr %t103, i32 0, i32 2
  %t106 = getelementptr %"compiler/types:Table", ptr %t105, i32 0, i32 0
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t109 = load ptr, ptr @__olang_prog_scope
  %t112 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %t109, ptr %t107, { i64, ptr } %t93)
  store i32 %t112, ptr %l75
  br label %bb29
bb29:
  %t113 = load ptr, ptr %l69, !tbaa !29
  %t114 = load i32, ptr %l70, !tbaa !23
  %t115 = load i32, ptr %l75, !tbaa !23
  %t116 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t113, i32 %t114, i32 %t115)
  store i64 %t116, ptr %l76
  br label %bb30
bb30:
  %t117 = load i64, ptr %l76, !tbaa !24
  store i64 %t117, ptr %l9, !tbaa !24
  %t118 = load i64, ptr %l9, !tbaa !24
  %t120 = icmp sge i64 %t118, 0
  br i1 %t120, label %bb31, label %bb32
bb31:
  %t122 = load ptr, ptr %l0, !tbaa !29
  store ptr %t122, ptr %l79, !tbaa !29
  %t123 = load ptr, ptr %l1, !tbaa !29
  store ptr %t123, ptr %l80, !tbaa !29
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load i64, ptr %l9, !tbaa !24
  %t126 = load i32, ptr %l2, !tbaa !23
  %t130 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStrBody(ptr %v0, ptr %t124, i64 %t125, i32 %t126)
  store i64 %t130, ptr %l84
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t131 = load ptr, ptr %l79, !tbaa !29
  %t132 = load ptr, ptr %l80, !tbaa !29
  %t133 = load i64, ptr %l84, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aFn(ptr %v0, ptr %v1, ptr %t131, ptr %t132, i64 %t133)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  br label %ret
bb35:
  call void @__olang_scope_close(ptr %s5)
  br label %bb36
bb36:
  %t134 = load i64, ptr %l6, !tbaa !24
  %t136 = add i64 %t134, 1
  store i64 %t136, ptr %l6, !tbaa !24
  br label %bb25
bb37:
  call void @__olang_scope_close(ptr %s4)
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/check:Checker", ptr %t138, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t142 = load i32, ptr %l2, !tbaa !23
  %t145 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t141, i32 %t142)
  store i1 %t145, ptr %l90
  br label %bb38
bb38:
  %t146 = load i1, ptr %l90, !tbaa !21
  %t147 = xor i1 %t146, true
  br i1 %t147, label %bb39, label %bb40
bb39:
  br label %ret
bb40:
  br label %bb41
bb41:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/check:Checker", ptr %t149, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !29
  %t154 = getelementptr %"compiler/generic:Program", ptr %t152, i32 0, i32 2
  store ptr %t154, ptr %l94, !tbaa !29
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/check:Checker", ptr %t155, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t160 = getelementptr %"compiler/generic:Program", ptr %t158, i32 0, i32 2
  %t161 = load i32, ptr %l2, !tbaa !23
  %t164 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t160, i32 %t161)
  store i32 %t164, ptr %l99
  br label %bb42
bb42:
  %t165 = load ptr, ptr %l94, !tbaa !29
  %t166 = load i32, ptr %l99, !tbaa !23
  %t167 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t165, i32 %t166)
  store { i64, ptr } %t167, ptr %l100
  br label %bb43
bb43:
  %t168 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t168, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t169 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t169, 0
  store i64 %t171, ptr %l12, !tbaa !24
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s10
  %t173 = load i64, ptr %l11, !tbaa !24
  %t174 = load i64, ptr %l12, !tbaa !24
  %t177 = icmp slt i64 %t173, %t174
  %t179 = xor i1 %t177, true
  br i1 %t179, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s10)
  br label %bb50
bb46:
  br label %bb47
bb47:
  %t181 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t181, ptr %l107, !tbaa !27
  %t182 = load i64, ptr %l11, !tbaa !24
  %t184 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = getelementptr i32, ptr %t185, i64 %t182
  %t187 = load i32, ptr %t186, !tbaa !33
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load ptr, ptr %l1, !tbaa !29
  %t192 = load i64, ptr %l3, !tbaa !24
  %t194 = add i64 %t192, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStr(ptr %v0, ptr %v1, ptr %t189, ptr %t190, i32 %t187, i64 %t194)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s10)
  br label %bb49
bb49:
  %t199 = load i64, ptr %l11, !tbaa !24
  %t201 = add i64 %t199, 1
  store i64 %t201, ptr %l11, !tbaa !24
  br label %bb44
bb50:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/check:Checker", ptr %t203, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !29
  %t208 = getelementptr %"compiler/generic:Program", ptr %t206, i32 0, i32 2
  store ptr %t208, ptr %l119, !tbaa !29
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/check:Checker", ptr %t209, i32 0, i32 1
  %t212 = load ptr, ptr %t211, !tbaa !29
  %t214 = getelementptr %"compiler/generic:Program", ptr %t212, i32 0, i32 2
  %t215 = load i32, ptr %l2, !tbaa !23
  %t218 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t214, i32 %t215)
  store i32 %t218, ptr %l124
  br label %bb51
bb51:
  %t219 = load ptr, ptr %l119, !tbaa !29
  %t220 = load i32, ptr %l124, !tbaa !23
  %t221 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t219, i32 %t220)
  store { i64, ptr } %t221, ptr %l125
  br label %bb52
bb52:
  %t222 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t222, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t223 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t225 = extractvalue { i64, ptr } %t223, 0
  store i64 %t225, ptr %l16, !tbaa !24
  br label %bb53
bb53:
  store %olang.scope zeroinitializer, ptr %s13
  %t227 = load i64, ptr %l15, !tbaa !24
  %t228 = load i64, ptr %l16, !tbaa !24
  %t231 = icmp slt i64 %t227, %t228
  %t233 = xor i1 %t231, true
  br i1 %t233, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s13)
  br label %bb59
bb55:
  br label %bb56
bb56:
  %t235 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t235, ptr %l132, !tbaa !27
  %t236 = load i64, ptr %l15, !tbaa !24
  %t238 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t239 = load ptr, ptr %t238, !tbaa !27
  %t240 = getelementptr i32, ptr %t239, i64 %t236
  %t241 = load i32, ptr %t240, !tbaa !33
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t244 = load ptr, ptr %l1, !tbaa !29
  %t246 = load i64, ptr %l3, !tbaa !24
  %t248 = add i64 %t246, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStr(ptr %v0, ptr %v1, ptr %t243, ptr %t244, i32 %t241, i64 %t248)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s13)
  br label %bb58
bb58:
  %t253 = load i64, ptr %l15, !tbaa !24
  %t255 = add i64 %t253, 1
  store i64 %t255, ptr %l15, !tbaa !24
  br label %bb53
bb59:
  br label %bb82
bb60:
  %t257 = load i32, ptr %l4
  %t259 = trunc i64 19 to i32
  %t260 = icmp eq i32 %t257, %t259
  br i1 %t260, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb66
bb63:
  %t262 = load ptr, ptr %l0, !tbaa !29
  store ptr %t262, ptr %l144, !tbaa !29
  %t263 = load ptr, ptr %l1, !tbaa !29
  store ptr %t263, ptr %l145, !tbaa !29
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t266 = getelementptr %"compiler/check:Checker", ptr %t264, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !29
  %t269 = getelementptr %"compiler/generic:Program", ptr %t267, i32 0, i32 2
  %t270 = load i32, ptr %l2, !tbaa !23
  %t273 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t269, i32 %t270)
  store i32 %t273, ptr %l150
  br label %bb64
bb64:
  %t274 = load i64, ptr %l3, !tbaa !24
  %t276 = add i64 %t274, 1
  %t277 = load ptr, ptr %l144, !tbaa !29
  %t278 = load ptr, ptr %l145, !tbaa !29
  %t279 = load i32, ptr %l150, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStr(ptr %v0, ptr %v1, ptr %t277, ptr %t278, i32 %t279, i64 %t276)
  br label %bb65
bb65:
  br label %bb82
bb66:
  %t281 = load i32, ptr %l4
  %t283 = trunc i64 22 to i32
  %t284 = icmp eq i32 %t281, %t283
  br i1 %t284, label %bb67, label %bb68
bb67:
  br label %bb71
bb68:
  %t286 = load i32, ptr %l4
  %t288 = trunc i64 23 to i32
  %t289 = icmp eq i32 %t286, %t288
  br i1 %t289, label %bb69, label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb81
bb71:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t293 = getelementptr %"compiler/check:Checker", ptr %t291, i32 0, i32 1
  %t294 = load ptr, ptr %t293, !tbaa !29
  %t296 = getelementptr %"compiler/generic:Program", ptr %t294, i32 0, i32 2
  store ptr %t296, ptr %l159, !tbaa !29
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t299 = getelementptr %"compiler/check:Checker", ptr %t297, i32 0, i32 1
  %t300 = load ptr, ptr %t299, !tbaa !29
  %t302 = getelementptr %"compiler/generic:Program", ptr %t300, i32 0, i32 2
  %t303 = load i32, ptr %l2, !tbaa !23
  %t306 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t302, i32 %t303)
  store i32 %t306, ptr %l164
  br label %bb72
bb72:
  %t307 = load ptr, ptr %l159, !tbaa !29
  %t308 = load i32, ptr %l164, !tbaa !23
  %t309 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t307, i32 %t308)
  store { i64, ptr } %t309, ptr %l165
  br label %bb73
bb73:
  %t310 = load { i64, ptr }, ptr %l165, !tbaa !27
  store { i64, ptr } %t310, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t311 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t313 = extractvalue { i64, ptr } %t311, 0
  store i64 %t313, ptr %l20, !tbaa !24
  br label %bb74
bb74:
  store %olang.scope zeroinitializer, ptr %s18
  %t315 = load i64, ptr %l19, !tbaa !24
  %t316 = load i64, ptr %l20, !tbaa !24
  %t319 = icmp slt i64 %t315, %t316
  %t321 = xor i1 %t319, true
  br i1 %t321, label %bb75, label %bb76
bb75:
  call void @__olang_scope_close(ptr %s18)
  br label %bb80
bb76:
  br label %bb77
bb77:
  %t323 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t323, ptr %l172, !tbaa !27
  %t324 = load i64, ptr %l19, !tbaa !24
  %t326 = getelementptr { i64, ptr }, ptr %l172, i32 0, i32 1
  %t327 = load ptr, ptr %t326, !tbaa !27
  %t328 = getelementptr i32, ptr %t327, i64 %t324
  %t329 = load i32, ptr %t328, !tbaa !33
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t332 = load ptr, ptr %l1, !tbaa !29
  %t334 = load i64, ptr %l3, !tbaa !24
  %t336 = add i64 %t334, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStr(ptr %v0, ptr %v1, ptr %t331, ptr %t332, i32 %t329, i64 %t336)
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s18)
  br label %bb79
bb79:
  %t341 = load i64, ptr %l19, !tbaa !24
  %t343 = add i64 %t341, 1
  store i64 %t343, ptr %l19, !tbaa !24
  br label %bb74
bb80:
  br label %bb82
bb81:
  br label %bb82
bb82:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebadOver(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i1
  %l7 = alloca i1
  %l10 = alloca i32
  %l19 = alloca i32
  %l22 = alloca i1
  %l23 = alloca i1
  %l26 = alloca i32
  %l30 = alloca i1
  %l35 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i1, ptr %l5, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb5
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i32, ptr %l1, !tbaa !23
  %t13 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t9, i32 %t10)
  store i32 %t13, ptr %l10
  br label %bb4
bb4:
  %t14 = load i32, ptr %l10
  %t16 = trunc i64 4 to i32
  %t17 = icmp eq i32 %t14, %t16
  %t19 = xor i1 %t17, true
  store i1 %t19, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t21 = load i1, ptr %l7, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  %t29 = load i32, ptr %l1, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t32, ptr %l19
  br label %bb9
bb9:
  %t33 = load i32, ptr %l19, !tbaa !23
  store i32 %t33, ptr %l2, !tbaa !23
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i32, ptr %l2, !tbaa !23
  %t38 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t34, i32 %t35)
  store i1 %t38, ptr %l22
  br label %bb10
bb10:
  %t39 = load i1, ptr %l22, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l2, !tbaa !23
  %t44 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t40, i32 %t41)
  store i32 %t44, ptr %l26
  br label %bb13
bb12:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb18
bb13:
  %t45 = load i32, ptr %l26
  %t47 = trunc i64 4 to i32
  %t48 = icmp eq i32 %t45, %t47
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb17
bb15:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 2
  %t58 = load i32, ptr %l2, !tbaa !23
  %t61 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t57, i32 %t58)
  store i32 %t61, ptr %l35
  br label %bb16
bb16:
  %t62 = load i32, ptr %l35, !tbaa !23
  %t63 = icmp ne i32 %t62, 0
  store i1 %t63, ptr %l30, !tbaa !21
  br label %bb17
bb17:
  %t65 = load i1, ptr %l30, !tbaa !21
  store i1 %t65, ptr %l23, !tbaa !21
  br label %bb18
bb18:
  %t66 = load i1, ptr %l23, !tbaa !21
  store i1 %t66, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebraceAfter(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l10 = alloca i32
  %l16 = alloca %"compiler/source:Span"
  %l22 = alloca i32
  %l24 = alloca { i64, ptr }
  %l30 = alloca %"compiler/source:Span"
  %l37 = alloca ptr
  %l39 = alloca ptr
  %l42 = alloca ptr
  %l56 = alloca i1
  %l57 = alloca { i64, ptr }
  %l69 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Case", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  %t8 = xor i1 %t6, true
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/ast:Case", ptr %t10, i32 0, i32 3
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = icmp eq ptr %t13, null
  br i1 %t15, label %bb3, label %bb4
bb2:
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr %"compiler/ast:Case", ptr %t17, i32 0, i32 1
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb7, label %bb8
bb3:
  call void @__olang_check_failed(ptr @olang_loc_6eddca2d598ce6fb_9d8bffc2796cf667)
  unreachable
bb4:
  br label %bb5
bb5:
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr %"compiler/ast:Case", ptr %t26, i32 0, i32 3
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t29)
  store %"compiler/source:Span" %t31, ptr %l16
  br label %bb6
bb6:
  %t32 = getelementptr %"compiler/source:Span", ptr %l16, i32 0, i32 1
  %t33 = load i32, ptr %t32, !tbaa !23
  store i32 %t33, ptr %l10, !tbaa !23
  br label %bb11
bb7:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr %"compiler/ast:Case", ptr %t35, i32 0, i32 1
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l24, !tbaa !27
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr %"compiler/ast:Case", ptr %t39, i32 0, i32 1
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t46 = sub i64 %t44, 1
  %t48 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr ptr, ptr %t49, i64 %t46
  %t51 = load ptr, ptr %t50, !tbaa !39
  %t53 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t51)
  store %"compiler/source:Span" %t53, ptr %l30
  br label %bb9
bb8:
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr %"compiler/ast:Case", ptr %t54, i32 0, i32 0
  %t57 = getelementptr %"compiler/source:Span", ptr %t56, i32 0, i32 0
  %t58 = load i32, ptr %t57, !tbaa !23
  store i32 %t58, ptr %l22, !tbaa !23
  br label %bb10
bb9:
  %t60 = getelementptr %"compiler/source:Span", ptr %l30, i32 0, i32 1
  %t61 = load i32, ptr %t60, !tbaa !23
  store i32 %t61, ptr %l22, !tbaa !23
  br label %bb10
bb10:
  %t63 = load i32, ptr %l22, !tbaa !23
  store i32 %t63, ptr %l10, !tbaa !23
  br label %bb11
bb11:
  %t64 = load i32, ptr %l10, !tbaa !23
  store i32 %t64, ptr %l2, !tbaa !23
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = getelementptr %"compiler/generic:Program", ptr %t68, i32 0, i32 0
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/load:Loader", ptr %t71, i32 0, i32 5
  store ptr %t73, ptr %l37, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t74)
  store ptr %t76, ptr %l39
  br label %bb12
bb12:
  %t77 = load ptr, ptr %l39, !tbaa !29
  %t79 = getelementptr %"compiler/check:frame", ptr %t77, i32 0, i32 1
  %t80 = load i64, ptr %t79, !tbaa !24
  %t81 = load ptr, ptr %l37, !tbaa !29
  %t83 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t81, i64 %t80)
  store ptr %t83, ptr %l42
  br label %bb13
bb13:
  %t84 = load ptr, ptr %l42, !tbaa !29
  %t86 = getelementptr %"compiler/load:Module", ptr %t84, i32 0, i32 6
  %t87 = load ptr, ptr %t86, !tbaa !29
  store ptr %t87, ptr %l3, !tbaa !29
  %t89 = load ptr, ptr %l3, !tbaa !29
  %t91 = icmp eq ptr %t89, null
  br i1 %t91, label %bb14, label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_f64a0f855cc2648c_4038adf1240cd248)
  unreachable
bb15:
  br label %bb16
bb16:
  %t93 = load ptr, ptr %l3, !tbaa !29
  %t96 = getelementptr %"compiler/source:Source", ptr %t93, i32 0, i32 1
  %t97 = load { i64, ptr }, ptr %t96, !tbaa !27
  store { i64, ptr } %t97, ptr %l4, !tbaa !27
  %t99 = load i32, ptr %l2, !tbaa !23
  %t101 = sext i32 %t99 to i64
  store i64 %t101, ptr %l5, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s1
  %t103 = load i64, ptr %l5, !tbaa !24
  %t104 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t109 = icmp slt i64 %t103, %t106
  br i1 %t109, label %bb18, label %bb19
bb18:
  %t111 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t111, ptr %l57, !tbaa !27
  %t112 = load i64, ptr %l5, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr i8, ptr %t115, i64 %t112
  %t117 = load i8, ptr %t116, !tbaa !32
  %t119 = icmp ne i8 %t117, 123
  store i1 %t119, ptr %l56, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb20
bb20:
  %t121 = load i1, ptr %l56, !tbaa !21
  %t122 = xor i1 %t121, true
  br i1 %t122, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s1)
  br label %bb25
bb22:
  br label %bb23
bb23:
  %t124 = load i64, ptr %l5, !tbaa !24
  %t126 = add i64 %t124, 1
  store i64 %t126, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb24
bb24:
  br label %bb17
bb25:
  %t128 = load i64, ptr %l5, !tbaa !24
  %t130 = trunc i64 %t128 to i32
  %t131 = load i64, ptr %l5, !tbaa !24
  %t133 = add i64 %t131, 1
  %t135 = trunc i64 %t133 to i32
  %t138 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t130, i32 %t135)
  store %"compiler/source:Span" %t138, ptr %l69
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  %t139 = load %"compiler/source:Span", ptr %l69
  store %"compiler/source:Span" %t139, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebranchBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l18 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Branch", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sge i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/check:Checker", ptr %t8, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/generic:Program", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/load:Loader", ptr %t14, i32 0, i32 4
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/ast:Branch", ptr %t18, i32 0, i32 2
  %t21 = load i64, ptr %t20, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eReopen(ptr %v0, ptr %t17, i64 %t21)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"compiler/ast:Branch", ptr %t25, i32 0, i32 1
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/ast:Branch", ptr %t29, i32 0, i32 0
  %t32 = load %"compiler/source:Span", ptr %t31
  %t37 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eblockOf(ptr %v0, ptr %v1, ptr %t24, { i64, ptr } %t28, i32 1, %"compiler/source:Span" %t32)
  store ptr %t37, ptr %l18
  br label %bb5
bb5:
  %t38 = load ptr, ptr %l18, !tbaa !29
  store ptr %t38, ptr %l2, !tbaa !29
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr %"compiler/ast:Branch", ptr %t39, i32 0, i32 2
  %t42 = load i64, ptr %t41, !tbaa !24
  %t44 = icmp sge i64 %t42, 0
  br i1 %t44, label %bb6, label %bb7
bb6:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 0
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/load:Loader", ptr %t52, i32 0, i32 4
  %t55 = load ptr, ptr %t54, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t55)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t57 = load ptr, ptr %l2, !tbaa !29
  store ptr %t57, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaptureIn(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i32
  %l25 = alloca i1
  %l35 = alloca i64
  %l40 = alloca ptr
  %l45 = alloca ptr
  %l48 = alloca ptr
  %l52 = alloca %"compiler/typed:Local"
  %l64 = alloca i1
  %l66 = alloca i1
  %l69 = alloca i32
  %l77 = alloca i32
  %l92 = alloca ptr
  %l93 = alloca ptr
  %l99 = alloca %"compiler/typed:Local"
  %l100 = alloca i32
  %l107 = alloca ptr
  %l110 = alloca i32
  %l114 = alloca %"compiler/typed:Capture"
  %l118 = alloca i1
  %l119 = alloca i1
  %l124 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i64
  %t90 = alloca { i64, [4 x i64] }, align 8
  %t139 = alloca { i64, [5 x i64] }, align 8
  %t157 = alloca { i64, [5 x i64] }, align 8
  %t185 = alloca { i64, [2 x i64] }, align 8
  %t252 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 12
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_Hbcd822ae67306ca6a025f17ed2cfb61c(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l16
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l16, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t11 = getelementptr %"compiler/check:frame", ptr %t9, i32 0, i32 8
  %t12 = load i32, ptr %l2, !tbaa !23
  %t15 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t11, i32 %t12)
  %t16 = extractvalue { i32, i64 } %t15, 1
  %t17 = extractvalue { i32, i64 } %t15, 0
  store i32 %t17, ptr %l22
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb3, label %ok.19
ok.19:
  store i64 %t16, ptr %l21
  br label %bb2
bb2:
  %t20 = load i64, ptr %l21, !tbaa !24
  store i64 %t20, ptr %l17, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  store i64 -1, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t21 = load i64, ptr %l17, !tbaa !24
  store i64 %t21, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l5, !tbaa !24
  %t24 = icmp sge i64 %t22, 0
  br i1 %t24, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb8
bb7:
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t28 = getelementptr %"compiler/check:frame", ptr %t26, i32 0, i32 21
  %t29 = load i64, ptr %t28, !tbaa !24
  %t31 = icmp slt i64 %t29, 0
  store i1 %t31, ptr %l25, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l25, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t34 = load i64, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t34, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load ptr, ptr %l4, !tbaa !29
  %t39 = getelementptr %"compiler/check:frame", ptr %t37, i32 0, i32 21
  %t40 = load i64, ptr %t39, !tbaa !24
  %t41 = load i32, ptr %l2, !tbaa !23
  %t42 = load %"compiler/source:Span", ptr %l3
  %t47 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaptureIn(ptr %v0, ptr %t36, i64 %t40, i32 %t41, %"compiler/source:Span" %t42)
  store i64 %t47, ptr %l35
  br label %bb12
bb12:
  %t48 = load i64, ptr %l35, !tbaa !24
  store i64 %t48, ptr %l6, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t51 = icmp slt i64 %t49, 0
  br i1 %t51, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 10
  store ptr %t56, ptr %l40, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 12
  %t60 = load ptr, ptr %l4, !tbaa !29
  %t62 = getelementptr %"compiler/check:frame", ptr %t60, i32 0, i32 21
  %t63 = load i64, ptr %t62, !tbaa !24
  %t66 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_Hbcd822ae67306ca6a025f17ed2cfb61c(ptr %v0, ptr %v0, ptr %t59, i64 %t63)
  store ptr %t66, ptr %l45
  br label %bb16
bb16:
  %t67 = load ptr, ptr %l45, !tbaa !29
  %t69 = getelementptr %"compiler/check:frame", ptr %t67, i32 0, i32 0
  %t70 = load i64, ptr %t69, !tbaa !24
  %t71 = load ptr, ptr %l40, !tbaa !29
  %t73 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t71, i64 %t70)
  store ptr %t73, ptr %l48
  br label %bb17
bb17:
  %t74 = load ptr, ptr %l48, !tbaa !29
  %t76 = getelementptr %"compiler/typed:Body", ptr %t74, i32 0, i32 7
  %t77 = load i64, ptr %l6, !tbaa !24
  %t80 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t76, i64 %t77)
  store %"compiler/typed:Local" %t80, ptr %l52
  br label %bb18
bb18:
  %t81 = getelementptr %"compiler/typed:Local", ptr %l52, i32 0, i32 2
  %t82 = load i32, ptr %t81, !tbaa !23
  store i32 %t82, ptr %l7, !tbaa !23
  %t84 = load %"compiler/source:Span", ptr %l3
  %t85 = load i32, ptr %l7, !tbaa !23
  %t86 = load i64, ptr %l6, !tbaa !24
  %t88 = trunc i64 %t86 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t90
  %t91 = getelementptr { i64, [4 x i64] }, ptr %t90, i32 0, i32 0
  store i64 0, ptr %t91
  %t93 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t84, 0
  %t95 = insertvalue { %"compiler/source:Span", i32, i32 } %t93, i32 %t85, 1
  %t97 = insertvalue { %"compiler/source:Span", i32, i32 } %t95, i32 %t88, 2
  %t98 = getelementptr { i64, [4 x i64] }, ptr %t90, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t97, ptr %t98
  %t99 = load { i64, [4 x i64] }, ptr %t90
  %t101 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t99, ptr %t101
  store ptr %t101, ptr %l8, !tbaa !29
  %t103 = load i32, ptr %l7, !tbaa !23
  store i32 %t103, ptr %l9, !tbaa !23
  store ptr null, ptr %l10, !tbaa !29
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load i32, ptr %l7, !tbaa !23
  %t109 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t105, i32 %t106)
  store i1 %t109, ptr %l64
  br label %bb19
bb19:
  %t110 = load i1, ptr %l64, !tbaa !21
  %t111 = xor i1 %t110, true
  br i1 %t111, label %bb20, label %bb21
bb20:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load i32, ptr %l7, !tbaa !23
  %t117 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t113, i32 %t114)
  store i32 %t117, ptr %l69
  br label %bb22
bb21:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb23
bb22:
  %t118 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t119 = load i32, ptr %l69, !tbaa !23
  %t121 = icmp ne i32 %t119, %t118
  store i1 %t121, ptr %l66, !tbaa !21
  br label %bb23
bb23:
  %t123 = load i1, ptr %l66, !tbaa !21
  br i1 %t123, label %bb24, label %bb25
bb24:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/check:Checker", ptr %t124, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t129 = getelementptr %"compiler/generic:Program", ptr %t127, i32 0, i32 2
  %t130 = load i32, ptr %l7, !tbaa !23
  %t131 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t135 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t129, i32 %t130, i64 %t131)
  store i32 %t135, ptr %l77
  br label %bb26
bb25:
  %t136 = load %"compiler/source:Span", ptr %l3
  %t137 = load i32, ptr %l7, !tbaa !23
  %t138 = load ptr, ptr %l8, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t139
  %t140 = getelementptr { i64, [5 x i64] }, ptr %t139, i32 0, i32 0
  store i64 2, ptr %t140
  %t142 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t136, 0
  %t144 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t142, i32 %t137, 1
  %t146 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t144, ptr %t138, 2
  %t147 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t146, i32 -1, 3
  %t148 = getelementptr { i64, [5 x i64] }, ptr %t139, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t147, ptr %t148
  %t149 = load { i64, [5 x i64] }, ptr %t139
  %t151 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t149, ptr %t151
  store ptr %t151, ptr %l10, !tbaa !29
  br label %bb27
bb26:
  %t153 = load i32, ptr %l77, !tbaa !23
  store i32 %t153, ptr %l9, !tbaa !23
  %t154 = load %"compiler/source:Span", ptr %l3
  %t155 = load i32, ptr %l9, !tbaa !23
  %t156 = load ptr, ptr %l8, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t157
  %t158 = getelementptr { i64, [5 x i64] }, ptr %t157, i32 0, i32 0
  store i64 3, ptr %t158
  %t160 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t154, 0
  %t162 = insertvalue { %"compiler/source:Span", i32, ptr } %t160, i32 %t155, 1
  %t164 = insertvalue { %"compiler/source:Span", i32, ptr } %t162, ptr %t156, 2
  %t165 = getelementptr { i64, [5 x i64] }, ptr %t157, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t164, ptr %t165
  %t166 = load { i64, [5 x i64] }, ptr %t157
  %t168 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t166, ptr %t168
  store ptr %t168, ptr %l10, !tbaa !29
  br label %bb27
bb27:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/check:Checker", ptr %t170, i32 0, i32 10
  %t173 = load ptr, ptr %l4, !tbaa !29
  %t175 = getelementptr %"compiler/check:frame", ptr %t173, i32 0, i32 0
  %t176 = load i64, ptr %t175, !tbaa !24
  %t179 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t172, i64 %t176)
  store ptr %t179, ptr %l92
  br label %bb28
bb28:
  %t180 = load ptr, ptr %l92, !tbaa !29
  store ptr %t180, ptr %l11, !tbaa !29
  %t181 = load ptr, ptr %l11, !tbaa !29
  store ptr %t181, ptr %l93, !tbaa !29
  %t182 = load i32, ptr %l2, !tbaa !23
  %t183 = load %"compiler/source:Span", ptr %l3
  %t184 = load i32, ptr %l9, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t185
  %t186 = getelementptr { i64, [2 x i64] }, ptr %t185, i32 0, i32 0
  store i64 5, ptr %t186
  %t187 = load { i64, [2 x i64] }, ptr %t185
  %t193 = call %"compiler/typed:Local" @compiler_2ftyped_3aLocal_2ector(ptr %s0, i32 %t182, %"compiler/source:Span" %t183, i32 %t184, i32 0, i32 5, { i64, [2 x i64] } %t187)
  store %"compiler/typed:Local" %t193, ptr %l99
  br label %bb29
bb29:
  %t194 = load ptr, ptr %l93, !tbaa !29
  %t195 = load %"compiler/typed:Local", ptr %l99
  %t196 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddLocal(ptr %v0, ptr %t194, %"compiler/typed:Local" %t195)
  store i32 %t196, ptr %l100
  br label %bb30
bb30:
  %t197 = load i32, ptr %l100, !tbaa !23
  %t198 = sext i32 %t197 to i64
  store i64 %t198, ptr %l12, !tbaa !24
  %t200 = load ptr, ptr %l4, !tbaa !29
  %t202 = getelementptr %"compiler/check:frame", ptr %t200, i32 0, i32 8
  %t203 = load i32, ptr %l2, !tbaa !23
  %t204 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %t202, i32 %t203, i64 %t204)
  br label %bb31
bb31:
  %t208 = load ptr, ptr %l4, !tbaa !29
  %t210 = getelementptr %"compiler/check:frame", ptr %t208, i32 0, i32 27
  store ptr %t210, ptr %l107, !tbaa !29
  %t211 = load i64, ptr %l12, !tbaa !24
  %t213 = trunc i64 %t211 to i32
  store i32 %t213, ptr %l110, !tbaa !23
  %t215 = load ptr, ptr %l10, !tbaa !29
  %t217 = icmp eq ptr %t215, null
  br i1 %t217, label %bb32, label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_486b3db7a819736b_b4c2afa2fe5bd5af)
  unreachable
bb33:
  br label %bb34
bb34:
  %t219 = load ptr, ptr %l10, !tbaa !29
  %t220 = load i32, ptr %l110, !tbaa !23
  %t222 = call %"compiler/typed:Capture" @compiler_2ftyped_3aCapture_2ector(ptr %v0, ptr %v0, i32 %t220, ptr %t219)
  store %"compiler/typed:Capture" %t222, ptr %l114
  br label %bb35
bb35:
  %t223 = load %"compiler/typed:Capture", ptr %l114
  %t224 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store %"compiler/typed:Capture" %t223, ptr %t224
  %t225 = load ptr, ptr %l107, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aCapture_26_3e_2e_He39a1cf375adb47168dea91a05758aa9(ptr %v0, ptr %v0, ptr %t225, ptr %t224)
  br label %bb36
bb36:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load i32, ptr %l9, !tbaa !23
  %t231 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t227, i32 %t228)
  store i1 %t231, ptr %l118
  br label %bb37
bb37:
  %t232 = load i1, ptr %l118, !tbaa !21
  br i1 %t232, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l119, !tbaa !21
  br label %bb41
bb39:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t235 = getelementptr %"compiler/check:Checker", ptr %t233, i32 0, i32 1
  %t236 = load ptr, ptr %t235, !tbaa !29
  %t238 = getelementptr %"compiler/generic:Program", ptr %t236, i32 0, i32 2
  %t239 = load i32, ptr %l9, !tbaa !23
  %t242 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t238, i32 %t239)
  store i1 %t242, ptr %l124
  br label %bb40
bb40:
  %t243 = load i1, ptr %l124, !tbaa !21
  store i1 %t243, ptr %l119, !tbaa !21
  br label %bb41
bb41:
  %t244 = load i1, ptr %l119, !tbaa !21
  br i1 %t244, label %bb42, label %bb43
bb42:
  %t245 = load ptr, ptr %l11, !tbaa !29
  %t247 = getelementptr %"compiler/typed:Body", ptr %t245, i32 0, i32 6
  %t248 = load i64, ptr %l12, !tbaa !24
  %t250 = trunc i64 %t248 to i32
  store { i64, [1 x i64] } zeroinitializer, ptr %t252
  %t253 = getelementptr { i64, [1 x i64] }, ptr %t252, i32 0, i32 0
  store i64 4, ptr %t253
  %t255 = insertvalue { i32 } undef, i32 %t250, 0
  %t256 = getelementptr { i64, [1 x i64] }, ptr %t252, i32 0, i32 1
  store { i32 } %t255, ptr %t256
  %t257 = load { i64, [1 x i64] }, ptr %t252
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2ePu_Hdbf2db28b3dbd7714059bb41361f5f89(ptr %v0, ptr %t247, { i64, [1 x i64] } %t257)
  br label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb45
bb45:
  %t260 = load i64, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t260, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseName(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l6 = alloca %"compiler/names:Ref"
  %l7 = alloca ptr
  %l8 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l29 = alloca ptr
  %l31 = alloca ptr
  %l35 = alloca %"compiler/names:Ref"
  %l38 = alloca ptr
  %l39 = alloca %"compiler/source:Span"
  %l42 = alloca { i64, ptr }
  %l44 = alloca %"compiler/msgs:Msg"
  %l45 = alloca i64
  %l47 = alloca ptr
  %l49 = alloca ptr
  %l54 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l58 = alloca i1
  %l61 = alloca i1
  %l64 = alloca i64
  %l67 = alloca ptr
  %l68 = alloca %"compiler/source:Span"
  %l71 = alloca { i64, ptr }
  %l73 = alloca %"compiler/msgs:Msg"
  %l74 = alloca i64
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l3, !tbaa !29
  br label %bb9
bb4:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 4
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", ptr }, ptr %t27, i32 0, i32 1
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l3, !tbaa !29
  br label %bb9
bb8:
  br label %bb41
bb9:
  %t31 = load ptr, ptr %l3, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb10, label %bb11
bb10:
  %t35 = load ptr, ptr %l19, !tbaa !29
  %t36 = load i64, ptr %t35
  %t38 = icmp eq i64 %t36, 0
  store i1 %t38, ptr %l20, !tbaa !21
  br label %bb11
bb11:
  %t39 = load i1, ptr %l20, !tbaa !21
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32 }, ptr %t42, i32 0, i32 0
  %t44 = load %"compiler/source:Span", ptr %t43
  store %"compiler/source:Span" %t44, ptr %l4
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = getelementptr { i64, [5 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", i32 }, ptr %t48, i32 0, i32 1
  %t50 = load i32, ptr %t49
  store i32 %t50, ptr %l5, !tbaa !23
  br label %bb14
bb13:
  br label %bb39
bb14:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  store ptr %t58, ptr %l29, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t59)
  store ptr %t61, ptr %l31
  br label %bb15
bb15:
  %t62 = load ptr, ptr %l31, !tbaa !29
  %t64 = getelementptr %"compiler/check:frame", ptr %t62, i32 0, i32 2
  %t65 = load i64, ptr %t64, !tbaa !24
  %t66 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 0
  %t67 = load i32, ptr %t66, !tbaa !23
  %t68 = load ptr, ptr %l29, !tbaa !29
  %t71 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t68, i64 %t65, i32 %t67)
  store %"compiler/names:Ref" %t71, ptr %l35
  br label %bb16
bb16:
  %t72 = load %"compiler/names:Ref", ptr %l35
  store %"compiler/names:Ref" %t72, ptr %l6
  %t73 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 0
  %t74 = load i32, ptr %t73
  %t76 = trunc i64 0 to i32
  %t77 = icmp eq i32 %t74, %t76
  br i1 %t77, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l38, !tbaa !29
  %t80 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t80, ptr %l39
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load i32, ptr %l5, !tbaa !23
  %t85 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s3, ptr %t81, i32 %t82)
  store { i64, ptr } %t85, ptr %l42
  br label %bb19
bb18:
  br label %bb25
bb19:
  %t86 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 0
  %t88 = extractvalue { i64, ptr } %t86, 1
  %t89 = mul i64 %t87, 1
  %t90 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t89)
  call void @llvm.memcpy.p0.p0.i64(ptr %t90, ptr %t88, i64 %t89, i1 false)
  %t91 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t90, 1
  %t94 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseUnknownName(ptr %s3, ptr %s3, { i64, ptr } %t92)
  store %"compiler/msgs:Msg" %t94, ptr %l44
  br label %bb20
bb20:
  %t95 = load ptr, ptr %l38, !tbaa !29
  %t96 = load %"compiler/source:Span", ptr %l39
  %t97 = load %"compiler/msgs:Msg", ptr %l44
  %t98 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t95, %"compiler/source:Span" %t96, %"compiler/msgs:Msg" %t97)
  store i64 %t98, ptr %l45
  br label %bb21
bb21:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 67
  store ptr %t101, ptr %l47, !tbaa !29
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t102)
  store ptr %t104, ptr %l49
  br label %bb22
bb22:
  %t105 = load ptr, ptr %l49, !tbaa !29
  %t107 = getelementptr %"compiler/check:frame", ptr %t105, i32 0, i32 0
  %t108 = load i64, ptr %t107, !tbaa !24
  %t109 = load i32, ptr %l5, !tbaa !23
  %t111 = sext i32 %t109 to i64
  %t114 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s3, i64 %t108, i64 %t111)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t114, ptr %l54
  br label %bb23
bb23:
  %t115 = load ptr, ptr %l47, !tbaa !29
  %t116 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l54
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t115, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t116, i1 true)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb25:
  %t118 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 0
  %t119 = load i32, ptr %t118
  %t121 = trunc i64 1 to i32
  %t122 = icmp eq i32 %t119, %t121
  br i1 %t122, label %bb26, label %bb27
bb26:
  %t124 = load i64, ptr %l2, !tbaa !24
  %t126 = icmp sge i64 %t124, 0
  store i1 %t126, ptr %l58, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb28
bb28:
  %t128 = load i1, ptr %l58, !tbaa !21
  br i1 %t128, label %bb29, label %bb30
bb29:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load i32, ptr %l5, !tbaa !23
  %t133 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t129, i32 %t130)
  store i64 %t133, ptr %l64
  br label %bb31
bb30:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb32
bb31:
  %t134 = load i64, ptr %l2, !tbaa !24
  %t135 = load i64, ptr %l64, !tbaa !24
  %t137 = icmp eq i64 %t135, %t134
  store i1 %t137, ptr %l61, !tbaa !21
  br label %bb32
bb32:
  %t139 = load i1, ptr %l61, !tbaa !21
  br i1 %t139, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s4
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l67, !tbaa !29
  %t141 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t141, ptr %l68
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load i32, ptr %l5, !tbaa !23
  %t146 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s4, ptr %t142, i32 %t143)
  store { i64, ptr } %t146, ptr %l71
  br label %bb35
bb34:
  br label %bb38
bb35:
  %t147 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t147, 0
  %t149 = extractvalue { i64, ptr } %t147, 1
  %t150 = mul i64 %t148, 1
  %t151 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t150)
  call void @llvm.memcpy.p0.p0.i64(ptr %t151, ptr %t149, i64 %t150, i1 false)
  %t152 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t151, 1
  %t155 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseIsSubject(ptr %s4, ptr %s4, { i64, ptr } %t153)
  store %"compiler/msgs:Msg" %t155, ptr %l73
  br label %bb36
bb36:
  %t156 = load ptr, ptr %l67, !tbaa !29
  %t157 = load %"compiler/source:Span", ptr %l68
  %t158 = load %"compiler/msgs:Msg", ptr %l73
  %t159 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t156, %"compiler/source:Span" %t157, %"compiler/msgs:Msg" %t158)
  store i64 %t159, ptr %l74
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s4)
  store i1 true, ptr %rv
  br label %ret
bb38:
  br label %bb40
bb39:
  br label %bb40
bb40:
  br label %bb42
bb41:
  br label %bb42
bb42:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainFrom(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, i64 %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca %"compiler/source:Span"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %lp13 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l27 = alloca %"compiler/source:Span"
  %l29 = alloca { i64, ptr }
  %l33 = alloca %"compiler/source:Span"
  %l35 = alloca { i64, ptr }
  %l37 = alloca %"compiler/source:Span"
  %l42 = alloca ptr
  %l43 = alloca %"compiler/source:Span"
  %l44 = alloca %"compiler/source:Span"
  %l45 = alloca i32
  %l46 = alloca ptr
  %l53 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l58 = alloca %"compiler/source:Span"
  %l60 = alloca { i64, ptr }
  %l64 = alloca %"compiler/source:Span"
  %l65 = alloca ptr
  %l72 = alloca ptr
  %l74 = alloca i32
  %l78 = alloca i64
  %l81 = alloca i64
  %l83 = alloca ptr
  %l84 = alloca %"compiler/source:Span"
  %l87 = alloca i32
  %l94 = alloca ptr
  %l97 = alloca ptr
  %l98 = alloca %"compiler/source:Span"
  %l99 = alloca %"compiler/source:Span"
  %l100 = alloca i32
  %l101 = alloca ptr
  %l105 = alloca ptr
  %l107 = alloca { i64, ptr }
  %l110 = alloca %"compiler/source:Span"
  %l112 = alloca { i64, ptr }
  %l116 = alloca %"compiler/source:Span"
  %l117 = alloca ptr
  %l118 = alloca %"compiler/source:Span"
  %l119 = alloca i32
  %l123 = alloca { i64, ptr }
  %l126 = alloca %"compiler/typed:Seq"
  %l129 = alloca ptr
  %l130 = alloca %"compiler/source:Span"
  %l131 = alloca ptr
  %l132 = alloca i64
  %l134 = alloca i64
  %l138 = alloca ptr
  %l139 = alloca ptr
  %l140 = alloca %"compiler/source:Span"
  %l141 = alloca i32
  %l142 = alloca ptr
  %l144 = alloca ptr
  %l148 = alloca ptr
  %l149 = alloca %"compiler/typed:Cond"
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t171 = alloca { i64, [3 x i64] }, align 8
  %t249 = alloca { i64, [5 x i64] }, align 8
  %t302 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Chain", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  store i64 %t6, ptr %l6, !tbaa !24
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t10 = getelementptr %"compiler/ast:Chain", ptr %t8, i32 0, i32 0
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  store { i64, ptr } %t11, ptr %l19, !tbaa !27
  %t12 = load i64, ptr %l4, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i32, ptr %t15, i64 %t12
  %t17 = load i32, ptr %t16
  store i32 %t17, ptr %l7
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l22, !tbaa !29
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t22 = getelementptr %"compiler/ast:Chain", ptr %t20, i32 0, i32 1
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l24, !tbaa !27
  %t24 = load i64, ptr %l4, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr ptr, ptr %t27, i64 %t24
  %t29 = load ptr, ptr %t28, !tbaa !39
  %t31 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t29)
  store %"compiler/source:Span" %t31, ptr %l27
  br label %bb1
bb1:
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t34 = getelementptr %"compiler/ast:Chain", ptr %t32, i32 0, i32 1
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  store { i64, ptr } %t35, ptr %l29, !tbaa !27
  %t36 = load i64, ptr %l4, !tbaa !24
  %t38 = add i64 %t36, 1
  %t40 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr ptr, ptr %t41, i64 %t38
  %t43 = load ptr, ptr %t42, !tbaa !39
  %t45 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t43)
  store %"compiler/source:Span" %t45, ptr %l33
  br label %bb2
bb2:
  %t46 = load i32, ptr %l7
  %t48 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s0, i32 %t46)
  store { i64, ptr } %t48, ptr %l35
  br label %bb3
bb3:
  %t49 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  %t51 = load ptr, ptr %l22, !tbaa !29
  %t52 = load %"compiler/source:Span", ptr %l27
  %t53 = load %"compiler/source:Span", ptr %l33
  %t55 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t51, %"compiler/source:Span" %t52, %"compiler/source:Span" %t53, i64 %t50)
  store %"compiler/source:Span" %t55, ptr %l37
  br label %bb4
bb4:
  %t56 = load %"compiler/source:Span", ptr %l37
  store %"compiler/source:Span" %t56, ptr %l8
  %t57 = load i64, ptr %l4, !tbaa !24
  %t59 = add i64 %t57, 2
  %t60 = load i64, ptr %l6, !tbaa !24
  %t63 = icmp sge i64 %t59, %t60
  br i1 %t63, label %bb5, label %bb6
bb5:
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l42, !tbaa !29
  %t66 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t66, ptr %l43
  %t67 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t67, ptr %l44
  %t68 = load i32, ptr %l7
  store i32 %t68, ptr %l45
  %t69 = load ptr, ptr %l5, !tbaa !29
  store ptr %t69, ptr %l46, !tbaa !29
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/check:Checker", ptr %t70, i32 0, i32 31
  %t73 = load i64, ptr %l3, !tbaa !24
  %t74 = load i64, ptr %l4, !tbaa !24
  %t77 = add i64 %t73, %t74
  %t79 = add i64 %t77, 1
  %t82 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t72, i64 %t79)
  store ptr %t82, ptr %l53
  br label %bb7
bb6:
  br label %bb11
bb7:
  %t83 = load ptr, ptr %l2, !tbaa !29
  %t85 = getelementptr %"compiler/ast:Chain", ptr %t83, i32 0, i32 1
  %t86 = load { i64, ptr }, ptr %t85, !tbaa !27
  store { i64, ptr } %t86, ptr %l55, !tbaa !27
  %t87 = load i64, ptr %l4, !tbaa !24
  %t89 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr ptr, ptr %t90, i64 %t87
  %t92 = load ptr, ptr %t91, !tbaa !39
  %t94 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t92)
  store %"compiler/source:Span" %t94, ptr %l58
  br label %bb8
bb8:
  %t95 = load ptr, ptr %l2, !tbaa !29
  %t97 = getelementptr %"compiler/ast:Chain", ptr %t95, i32 0, i32 1
  %t98 = load { i64, ptr }, ptr %t97, !tbaa !27
  store { i64, ptr } %t98, ptr %l60, !tbaa !27
  %t99 = load i64, ptr %l4, !tbaa !24
  %t101 = add i64 %t99, 1
  %t103 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = getelementptr ptr, ptr %t104, i64 %t101
  %t106 = load ptr, ptr %t105, !tbaa !39
  %t108 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t106)
  store %"compiler/source:Span" %t108, ptr %l64
  br label %bb9
bb9:
  %t109 = load ptr, ptr %l42, !tbaa !29
  %t110 = load %"compiler/source:Span", ptr %l43
  %t111 = load %"compiler/source:Span", ptr %l44
  %t112 = load i32, ptr %l45
  %t113 = load ptr, ptr %l46, !tbaa !29
  %t114 = load ptr, ptr %l53, !tbaa !29
  %t115 = load %"compiler/source:Span", ptr %l58
  %t116 = load %"compiler/source:Span", ptr %l64
  %t117 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %t109, %"compiler/source:Span" %t110, %"compiler/source:Span" %t111, i32 %t112, ptr %t113, ptr %t114, %"compiler/source:Span" %t115, %"compiler/source:Span" %t116)
  store ptr %t117, ptr %l65
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t118 = load ptr, ptr %l65, !tbaa !29
  store ptr %t118, ptr %rv
  br label %ret
bb11:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/check:Checker", ptr %t119, i32 0, i32 31
  %t122 = load i64, ptr %l3, !tbaa !24
  %t123 = load i64, ptr %l4, !tbaa !24
  %t126 = add i64 %t122, %t123
  %t128 = add i64 %t126, 1
  %t131 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %s0, ptr %t121, i64 %t128)
  store ptr %t131, ptr %l72
  br label %bb12
bb12:
  %t132 = load ptr, ptr %l72, !tbaa !29
  %t134 = call i32 @compiler_2fcheck_2etypeOf(ptr %s0, ptr %t132)
  store i32 %t134, ptr %l74
  br label %bb13
bb13:
  %t135 = load i32, ptr %l74, !tbaa !23
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load %"compiler/source:Span", ptr %l1
  %t142 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t136, %"compiler/source:Span" %t137, i32 %t135)
  store i64 %t142, ptr %l78
  br label %bb14
bb14:
  %t143 = load i64, ptr %l78, !tbaa !24
  store i64 %t143, ptr %l10, !tbaa !24
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/check:Checker", ptr %t144, i32 0, i32 32
  %t148 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t146)
  store i64 %t148, ptr %l81
  br label %bb15
bb15:
  %t149 = load i64, ptr %l81, !tbaa !24
  store i64 %t149, ptr %l11, !tbaa !24
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/check:Checker", ptr %t150, i32 0, i32 32
  store ptr %t152, ptr %l83, !tbaa !29
  %t153 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t153, ptr %l84
  %t154 = load i64, ptr %l10, !tbaa !24
  %t156 = trunc i64 %t154 to i32
  store i32 %t156, ptr %l87, !tbaa !23
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/check:Checker", ptr %t158, i32 0, i32 31
  %t161 = load i64, ptr %l3, !tbaa !24
  %t162 = load i64, ptr %l4, !tbaa !24
  %t165 = add i64 %t161, %t162
  %t167 = add i64 %t165, 1
  %t170 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t160, i64 %t167)
  store ptr %t170, ptr %l94
  br label %bb16
bb16:
  store { i64, [3 x i64] } zeroinitializer, ptr %t171
  %t172 = getelementptr { i64, [3 x i64] }, ptr %t171, i32 0, i32 0
  store i64 0, ptr %t172
  %t173 = load %"compiler/source:Span", ptr %l84
  %t174 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t173, 0
  %t175 = load i32, ptr %l87, !tbaa !23
  %t176 = insertvalue { %"compiler/source:Span", i32, ptr } %t174, i32 %t175, 1
  %t177 = load ptr, ptr %l94, !tbaa !29
  %t178 = insertvalue { %"compiler/source:Span", i32, ptr } %t176, ptr %t177, 2
  %t179 = getelementptr { i64, [3 x i64] }, ptr %t171, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t178, ptr %t179
  %t180 = load { i64, [3 x i64] }, ptr %t171
  %t182 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t180, ptr %t182
  %t183 = load ptr, ptr %l83, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v0, ptr %t183, ptr %t182)
  br label %bb17
bb17:
  %t185 = load ptr, ptr %l0, !tbaa !29
  store ptr %t185, ptr %l97, !tbaa !29
  %t186 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t186, ptr %l98
  %t187 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t187, ptr %l99
  %t188 = load i32, ptr %l7
  store i32 %t188, ptr %l100
  %t189 = load ptr, ptr %l5, !tbaa !29
  store ptr %t189, ptr %l101, !tbaa !29
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load %"compiler/source:Span", ptr %l1
  %t192 = load i64, ptr %l10, !tbaa !24
  %t196 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t190, %"compiler/source:Span" %t191, i64 %t192)
  store ptr %t196, ptr %l105
  br label %bb18
bb18:
  %t197 = load ptr, ptr %l2, !tbaa !29
  %t199 = getelementptr %"compiler/ast:Chain", ptr %t197, i32 0, i32 1
  %t200 = load { i64, ptr }, ptr %t199, !tbaa !27
  store { i64, ptr } %t200, ptr %l107, !tbaa !27
  %t201 = load i64, ptr %l4, !tbaa !24
  %t203 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !27
  %t205 = getelementptr ptr, ptr %t204, i64 %t201
  %t206 = load ptr, ptr %t205, !tbaa !39
  %t208 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t206)
  store %"compiler/source:Span" %t208, ptr %l110
  br label %bb19
bb19:
  %t209 = load ptr, ptr %l2, !tbaa !29
  %t211 = getelementptr %"compiler/ast:Chain", ptr %t209, i32 0, i32 1
  %t212 = load { i64, ptr }, ptr %t211, !tbaa !27
  store { i64, ptr } %t212, ptr %l112, !tbaa !27
  %t213 = load i64, ptr %l4, !tbaa !24
  %t215 = add i64 %t213, 1
  %t217 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !27
  %t219 = getelementptr ptr, ptr %t218, i64 %t215
  %t220 = load ptr, ptr %t219, !tbaa !39
  %t222 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t220)
  store %"compiler/source:Span" %t222, ptr %l116
  br label %bb20
bb20:
  %t223 = load ptr, ptr %l97, !tbaa !29
  %t224 = load %"compiler/source:Span", ptr %l98
  %t225 = load %"compiler/source:Span", ptr %l99
  %t226 = load i32, ptr %l100
  %t227 = load ptr, ptr %l101, !tbaa !29
  %t228 = load ptr, ptr %l105, !tbaa !29
  %t229 = load %"compiler/source:Span", ptr %l110
  %t230 = load %"compiler/source:Span", ptr %l116
  %t231 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %t223, %"compiler/source:Span" %t224, %"compiler/source:Span" %t225, i32 %t226, ptr %t227, ptr %t228, %"compiler/source:Span" %t229, %"compiler/source:Span" %t230)
  store ptr %t231, ptr %l117
  br label %bb21
bb21:
  %t232 = load ptr, ptr %l117, !tbaa !29
  store ptr %t232, ptr %l12, !tbaa !29
  %t233 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t233, ptr %l118
  %t234 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t234, ptr %l119, !tbaa !23
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/check:Checker", ptr %t235, i32 0, i32 32
  %t238 = load i64, ptr %l11, !tbaa !24
  %t241 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t237, i64 %t238)
  store { i64, ptr } %t241, ptr %l123
  br label %bb22
bb22:
  %t242 = load ptr, ptr %l12, !tbaa !29
  %t244 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t246 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t244, ptr %t242)
  store %"compiler/typed:Seq" %t246, ptr %l126
  br label %bb23
bb23:
  %t247 = load %"compiler/typed:Seq", ptr %l126
  %t248 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Seq" %t247, ptr %t248
  store { i64, [5 x i64] } zeroinitializer, ptr %t249
  %t250 = getelementptr { i64, [5 x i64] }, ptr %t249, i32 0, i32 0
  store i64 12, ptr %t250
  %t251 = load %"compiler/source:Span", ptr %l118
  %t252 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t251, 0
  %t253 = load i32, ptr %l119, !tbaa !23
  %t254 = insertvalue { %"compiler/source:Span", i32, ptr } %t252, i32 %t253, 1
  %t256 = insertvalue { %"compiler/source:Span", i32, ptr } %t254, ptr %t248, 2
  %t257 = getelementptr { i64, [5 x i64] }, ptr %t249, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t256, ptr %t257
  %t258 = load { i64, [5 x i64] }, ptr %t249
  %t259 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store ptr %t259, ptr %lp13
  %t261 = load ptr, ptr %lp13
  store { i64, [5 x i64] } %t258, ptr %t261
  %t262 = load ptr, ptr %l0, !tbaa !29
  store ptr %t262, ptr %l129, !tbaa !29
  %t263 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t263, ptr %l130
  %t264 = load ptr, ptr %l2, !tbaa !29
  store ptr %t264, ptr %l131, !tbaa !29
  %t265 = load i64, ptr %l3, !tbaa !24
  store i64 %t265, ptr %l132, !tbaa !24
  %t266 = load i64, ptr %l4, !tbaa !24
  %t268 = add i64 %t266, 1
  store i64 %t268, ptr %l134, !tbaa !24
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t270 = load %"compiler/source:Span", ptr %l1
  %t271 = load i64, ptr %l10, !tbaa !24
  %t275 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t269, %"compiler/source:Span" %t270, i64 %t271)
  store ptr %t275, ptr %l138
  br label %bb24
bb24:
  %t276 = load ptr, ptr %l129, !tbaa !29
  %t277 = load %"compiler/source:Span", ptr %l130
  %t278 = load ptr, ptr %l131, !tbaa !29
  %t279 = load i64, ptr %l132, !tbaa !24
  %t280 = load i64, ptr %l134, !tbaa !24
  %t281 = load ptr, ptr %l138, !tbaa !29
  %t282 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainFrom(ptr %v0, ptr %v1, ptr %t276, %"compiler/source:Span" %t277, ptr %t278, i64 %t279, i64 %t280, ptr %t281)
  store ptr %t282, ptr %l139
  br label %bb25
bb25:
  %t283 = load ptr, ptr %l139, !tbaa !29
  %t284 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t284, ptr %l140
  %t285 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t285, ptr %l141, !tbaa !23
  %t286 = load ptr, ptr %lp13
  store ptr %t286, ptr %l142, !tbaa !29
  store ptr %t283, ptr %l144, !tbaa !29
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t290 = load %"compiler/source:Span", ptr %l1
  %t291 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t295 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t289, %"compiler/source:Span" %t290, i32 %t291, i64 0)
  store ptr %t295, ptr %l148
  br label %bb26
bb26:
  %t296 = load ptr, ptr %l142, !tbaa !29
  %t297 = load ptr, ptr %l144, !tbaa !29
  %t298 = load ptr, ptr %l148, !tbaa !29
  %t299 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t296, ptr %t297, ptr %t298)
  store %"compiler/typed:Cond" %t299, ptr %l149
  br label %bb27
bb27:
  %t300 = load %"compiler/typed:Cond", ptr %l149
  %t301 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Cond" %t300, ptr %t301
  store { i64, [5 x i64] } zeroinitializer, ptr %t302
  %t303 = getelementptr { i64, [5 x i64] }, ptr %t302, i32 0, i32 0
  store i64 11, ptr %t303
  %t304 = load %"compiler/source:Span", ptr %l140
  %t305 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t304, 0
  %t306 = load i32, ptr %l141, !tbaa !23
  %t307 = insertvalue { %"compiler/source:Span", i32, ptr } %t305, i32 %t306, 1
  %t309 = insertvalue { %"compiler/source:Span", i32, ptr } %t307, ptr %t301, 2
  %t310 = getelementptr { i64, [5 x i64] }, ptr %t302, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t309, ptr %t310
  %t311 = load { i64, [5 x i64] }, ptr %t302
  %t313 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t311, ptr %t313
  call void @__olang_scope_close(ptr %s0)
  store ptr %t313, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echarValue(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l19 = alloca i8
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
  store { i64, ptr } %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = icmp slt i64 %t9, 3
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i64 0, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t14, ptr %l10, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr i8, ptr %t16, i64 1
  %t18 = load i8, ptr %t17, !tbaa !32
  %t20 = icmp ne i8 %t18, 92
  br i1 %t20, label %bb5, label %bb6
bb5:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l13, !tbaa !27
  %t23 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr i8, ptr %t24, i64 1
  %t26 = load i8, ptr %t25, !tbaa !32
  %t29 = zext i8 %t26 to i64
  store i64 %t29, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t31 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t31, ptr %l17, !tbaa !27
  %t32 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr i8, ptr %t33, i64 2
  %t35 = load i8, ptr %t34, !tbaa !32
  %t37 = call i8 @compiler_2fcheck_2eunescape(i8 %t35)
  store i8 %t37, ptr %l19
  br label %bb8
bb8:
  %t38 = load i8, ptr %l19, !tbaa !22
  %t39 = zext i8 %t38 to i64
  store i64 %t39, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckedPrim(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l6 = alloca i64
  %l9 = alloca i64
  %l16 = alloca %"compiler/source:Span"
  %l17 = alloca i32
  %l18 = alloca i32
  %l22 = alloca i32
  %l26 = alloca { i64, ptr }
  %rv = alloca ptr
  %t36 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 31
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l6, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 31
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t9, ptr %a4)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 31
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t15, ptr %a5)
  br label %bb3
bb3:
  store %"compiler/source:Span" %a1, ptr %l16
  %t20 = load i32, ptr %l2, !tbaa !23
  store i32 %t20, ptr %l17, !tbaa !23
  %t21 = load i32, ptr %l3
  store i32 %t21, ptr %l18
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l3
  %t24 = load i32, ptr %l2, !tbaa !23
  %t28 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earithCheck(ptr %v0, ptr %t22, i32 %t23, i32 %t24)
  store i32 %t28, ptr %l22
  br label %bb4
bb4:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 31
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t31, i64 %t32)
  store { i64, ptr } %t35, ptr %l26
  br label %bb5
bb5:
  store { i64, [5 x i64] } zeroinitializer, ptr %t36
  %t37 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 0
  store i64 9, ptr %t37
  %t38 = load %"compiler/source:Span", ptr %l16
  %t39 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t38, 0
  %t40 = load i32, ptr %l17, !tbaa !23
  %t41 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t39, i32 %t40, 1
  %t42 = load i32, ptr %l18
  %t43 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t41, i32 %t42, 2
  %t44 = load i32, ptr %l22
  %t45 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t43, i32 %t44, 3
  %t46 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t47 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t45, { i64, ptr } %t46, 4
  %t48 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t47, ptr %t48
  %t49 = load { i64, [5 x i64] }, ptr %t36
  %t51 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t49, ptr %t51
  store ptr %t51, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econstruct(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca i32
  %l8 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i64
  %l12 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca i64
  %l23 = alloca i1
  %l25 = alloca i1
  %l29 = alloca i1
  %l35 = alloca ptr
  %l38 = alloca i32
  %l41 = alloca i1
  %l43 = alloca ptr
  %l48 = alloca i32
  %l49 = alloca i64
  %l56 = alloca ptr
  %l62 = alloca i32
  %l68 = alloca ptr
  %l71 = alloca i64
  %l76 = alloca ptr
  %l77 = alloca %"compiler/source:Span"
  %l78 = alloca %"compiler/source:Span"
  %l79 = alloca i32
  %l84 = alloca ptr
  %l85 = alloca { i64, ptr }
  %l89 = alloca ptr
  %l95 = alloca i1
  %l98 = alloca i1
  %l103 = alloca ptr
  %l109 = alloca i32
  %l115 = alloca i64
  %l119 = alloca i1
  %l121 = alloca { i64, ptr }
  %l123 = alloca i1
  %l126 = alloca ptr
  %l127 = alloca %"compiler/source:Span"
  %l128 = alloca %"compiler/source:Span"
  %l129 = alloca i32
  %l134 = alloca ptr
  %l135 = alloca { i64, ptr }
  %l139 = alloca ptr
  %l141 = alloca ptr
  %l142 = alloca i32
  %l143 = alloca { i64, ptr }
  %l145 = alloca %"compiler/source:Span"
  %l147 = alloca { i64, ptr }
  %l154 = alloca ptr
  %l155 = alloca %"compiler/source:Span"
  %l158 = alloca %"compiler/msgs:Msg"
  %l159 = alloca i64
  %l162 = alloca ptr
  %l167 = alloca i32
  %l168 = alloca ptr
  %l169 = alloca ptr
  %l170 = alloca { i64, ptr }
  %l172 = alloca ptr
  %l174 = alloca { i64, ptr }
  %l176 = alloca i1
  %l177 = alloca i32
  %l180 = alloca ptr
  %l181 = alloca { i64, ptr }
  %l183 = alloca %"compiler/source:Span"
  %l184 = alloca ptr
  %l187 = alloca i32
  %l191 = alloca i1
  %l198 = alloca i1
  %l199 = alloca i1
  %l202 = alloca i1
  %l207 = alloca ptr
  %l208 = alloca ptr
  %l211 = alloca i32
  %l213 = alloca i1
  %l214 = alloca i1
  %l215 = alloca ptr
  %l218 = alloca i32
  %l220 = alloca i1
  %l223 = alloca i1
  %l224 = alloca ptr
  %l225 = alloca %"compiler/source:Span"
  %l226 = alloca ptr
  %l229 = alloca ptr
  %l230 = alloca i32
  %l235 = alloca i64
  %l236 = alloca i32
  %l237 = alloca ptr
  %l239 = alloca ptr
  %l243 = alloca i1
  %l246 = alloca ptr
  %l249 = alloca i32
  %l250 = alloca i32
  %l253 = alloca i1
  %l258 = alloca i32
  %l263 = alloca i1
  %l264 = alloca i64
  %l267 = alloca ptr
  %l268 = alloca %"compiler/source:Span"
  %l269 = alloca %"compiler/source:Span"
  %l275 = alloca i32
  %l278 = alloca ptr
  %l284 = alloca i32
  %l285 = alloca ptr
  %l293 = alloca ptr
  %l297 = alloca i1
  %l303 = alloca ptr
  %l304 = alloca ptr
  %l305 = alloca %"compiler/source:Span"
  %l306 = alloca ptr
  %l307 = alloca ptr
  %l308 = alloca i32
  %l309 = alloca { i64, ptr }
  %l311 = alloca %"compiler/source:Span"
  %l312 = alloca ptr
  %l314 = alloca ptr
  %l315 = alloca ptr
  %l316 = alloca { i64, ptr }
  %l318 = alloca %"compiler/source:Span"
  %l321 = alloca { i64, ptr }
  %l322 = alloca { i64, ptr }
  %l325 = alloca { i64, ptr }
  %l327 = alloca %"compiler/msgs:Msg"
  %l328 = alloca i64
  %l331 = alloca ptr
  %l334 = alloca ptr
  %l335 = alloca %"compiler/source:Span"
  %l338 = alloca { i64, ptr }
  %l339 = alloca { i64, ptr }
  %l341 = alloca %"compiler/msgs:Msg"
  %l342 = alloca i64
  %l347 = alloca ptr
  %l352 = alloca ptr
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca ptr
  %t127 = alloca { i64, [1 x i64] }, align 8
  %t238 = alloca { i64, [1 x i64] }, align 8
  %t537 = alloca { i64, [5 x i64] }, align 8
  %t572 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l3, !tbaa !23
  %t3 = load %"compiler/source:Span", ptr %l2
  %t7 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesMet(ptr %v0, ptr %t1, i32 %t2, %"compiler/source:Span" %t3)
  store i1 %t7, ptr %l23
  br label %bb1
bb1:
  %t8 = load i1, ptr %l23, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb5
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t15 = load i32, ptr %l3, !tbaa !23
  %t18 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t14, i32 %t15)
  store i1 %t18, ptr %l29
  br label %bb4
bb4:
  %t19 = load i1, ptr %l29, !tbaa !21
  %t20 = xor i1 %t19, true
  store i1 %t20, ptr %l25, !tbaa !21
  br label %bb5
bb5:
  %t22 = load i1, ptr %l25, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t23, { i64, ptr } %t24)
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l1
  %t31 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t27, %"compiler/source:Span" %t28)
  store ptr %t31, ptr %l35
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t32 = load ptr, ptr %l35, !tbaa !29
  store ptr %t32, ptr %rv
  br label %ret
bb10:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l3, !tbaa !23
  %t37 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l38
  br label %bb11
bb11:
  %t38 = load i32, ptr %l38
  store i32 %t38, ptr %l5
  %t39 = load i32, ptr %l5
  %t41 = trunc i64 0 to i32
  %t42 = icmp eq i32 %t39, %t41
  br i1 %t42, label %bb12, label %bb13
bb12:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  store ptr %t47, ptr %l43, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = getelementptr %"compiler/generic:Program", ptr %t51, i32 0, i32 2
  %t54 = load i32, ptr %l3, !tbaa !23
  %t57 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t53, i32 %t54)
  store i32 %t57, ptr %l48
  br label %bb14
bb13:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb16
bb14:
  %t58 = load ptr, ptr %l43, !tbaa !29
  %t59 = load i32, ptr %l48, !tbaa !23
  %t60 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorVars(ptr %v0, ptr %t58, i32 %t59)
  store i64 %t60, ptr %l49
  br label %bb15
bb15:
  %t61 = load i64, ptr %l49, !tbaa !24
  %t62 = icmp sgt i64 %t61, 0
  store i1 %t62, ptr %l41, !tbaa !21
  br label %bb16
bb16:
  %t64 = load i1, ptr %l41, !tbaa !21
  br i1 %t64, label %bb17, label %bb18
bb17:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load %"compiler/source:Span", ptr %l1
  %t67 = load %"compiler/source:Span", ptr %l2
  %t68 = load i32, ptr %l3, !tbaa !23
  %t69 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t75 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etwinCall(ptr %v0, ptr %v1, ptr %t65, %"compiler/source:Span" %t66, %"compiler/source:Span" %t67, i32 %t68, { i64, ptr } %t69)
  store ptr %t75, ptr %l56
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s0)
  %t76 = load ptr, ptr %l56, !tbaa !29
  store ptr %t76, ptr %rv
  br label %ret
bb20:
  %t77 = load i32, ptr %l5
  %t79 = trunc i64 0 to i32
  %t80 = icmp eq i32 %t77, %t79
  br i1 %t80, label %bb21, label %bb22
bb21:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t86 = load i32, ptr %l3, !tbaa !23
  %t89 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t85, i32 %t86)
  store i32 %t89, ptr %l62
  br label %bb23
bb22:
  br label %bb34
bb23:
  %t90 = load i32, ptr %l62, !tbaa !23
  store i32 %t90, ptr %l6, !tbaa !23
  %t91 = load i32, ptr %l6, !tbaa !23
  %t92 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t95 = icmp eq i32 %t91, %t92
  br i1 %t95, label %bb24, label %bb25
bb24:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load %"compiler/source:Span", ptr %l1
  %t101 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t97, %"compiler/source:Span" %t98)
  store ptr %t101, ptr %l68
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_scope_close(ptr %s0)
  %t102 = load ptr, ptr %l68, !tbaa !29
  store ptr %t102, ptr %rv
  br label %ret
bb27:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load i32, ptr %l3, !tbaa !23
  %t107 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBody(ptr %v0, ptr %t103, i32 %t104)
  store i64 %t107, ptr %l71
  br label %bb28
bb28:
  %t108 = load i64, ptr %l71, !tbaa !24
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/check:Checker", ptr %t109, i32 0, i32 21
  %t112 = load i32, ptr %t111, !tbaa !23
  store i32 %t112, ptr %l8, !tbaa !23
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load i32, ptr %l3, !tbaa !23
  %t118 = getelementptr %"compiler/check:Checker", ptr %t114, i32 0, i32 21
  store i32 %t115, ptr %t118, !tbaa !23
  %t119 = load ptr, ptr %l0, !tbaa !29
  store ptr %t119, ptr %l76, !tbaa !29
  %t120 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t120, ptr %l77
  %t121 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t121, ptr %l78
  %t122 = load i32, ptr %l6, !tbaa !23
  store i32 %t122, ptr %l79, !tbaa !23
  %t125 = trunc i64 %t108 to i32
  store { i64, [1 x i64] } zeroinitializer, ptr %t127
  %t128 = getelementptr { i64, [1 x i64] }, ptr %t127, i32 0, i32 0
  store i64 0, ptr %t128
  %t130 = insertvalue { i32 } undef, i32 %t125, 0
  %t131 = getelementptr { i64, [1 x i64] }, ptr %t127, i32 0, i32 1
  store { i32 } %t130, ptr %t131
  %t132 = load { i64, [1 x i64] }, ptr %t127
  %t134 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store { i64, [1 x i64] } %t132, ptr %t134
  store ptr %t134, ptr %l84, !tbaa !29
  %t135 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t135, ptr %l85, !tbaa !27
  %t136 = icmp sge i64 0, 0
  br i1 %t136, label %bb29, label %bb30
bb29:
  %t138 = icmp sle i64 0, 1152921504606846975
  br i1 %t138, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_77e9ca8727c07af9_ddc1fd4e636ee49d)
  unreachable
bb31:
  %t140 = mul i64 0, 8
  %t141 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t140)
  %t142 = insertvalue { i64, ptr } undef, i64 0, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  %t144 = load ptr, ptr %l76, !tbaa !29
  %t145 = load %"compiler/source:Span", ptr %l77
  %t146 = load %"compiler/source:Span", ptr %l78
  %t147 = load i32, ptr %l79, !tbaa !23
  %t148 = load ptr, ptr %l84, !tbaa !29
  %t149 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t151 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v1, ptr %t144, %"compiler/source:Span" %t145, %"compiler/source:Span" %t146, i32 %t147, ptr %t148, i64 -1, ptr null, { i64, ptr } %t149, { i64, ptr } %t143)
  store ptr %t151, ptr %l89
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_77e9ca8727c07af9_ddc1fd4e636ee49d)
  unreachable
bb33:
  %t152 = load ptr, ptr %l89, !tbaa !29
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load i32, ptr %l8, !tbaa !23
  %t157 = getelementptr %"compiler/check:Checker", ptr %t153, i32 0, i32 21
  store i32 %t154, ptr %t157, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store ptr %t152, ptr %rv
  br label %ret
bb34:
  %t160 = load i32, ptr %l5
  %t162 = trunc i64 4 to i32
  %t163 = icmp eq i32 %t160, %t162
  br i1 %t163, label %bb35, label %bb36
bb35:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load i32, ptr %l3, !tbaa !23
  %t169 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebadOver(ptr %v0, ptr %t165, i32 %t166)
  store i1 %t169, ptr %l98
  br label %bb37
bb36:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb38
bb37:
  %t170 = load i1, ptr %l98, !tbaa !21
  store i1 %t170, ptr %l95, !tbaa !21
  br label %bb38
bb38:
  %t171 = load i1, ptr %l95, !tbaa !21
  br i1 %t171, label %bb39, label %bb40
bb39:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t172, { i64, ptr } %t173)
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load %"compiler/source:Span", ptr %l1
  %t180 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t176, %"compiler/source:Span" %t177)
  store ptr %t180, ptr %l103
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s0)
  %t181 = load ptr, ptr %l103, !tbaa !29
  store ptr %t181, ptr %rv
  br label %ret
bb43:
  %t182 = load i32, ptr %l5
  %t184 = trunc i64 4 to i32
  %t185 = icmp eq i32 %t182, %t184
  br i1 %t185, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s6
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/check:Checker", ptr %t187, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !29
  %t191 = load i32, ptr %l3, !tbaa !23
  %t194 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t190, i32 %t191)
  store i32 %t194, ptr %l109
  br label %bb46
bb45:
  br label %bb147
bb46:
  %t195 = load i32, ptr %l109, !tbaa !23
  store i32 %t195, ptr %l10, !tbaa !23
  %t196 = load i32, ptr %l10, !tbaa !23
  %t197 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t200 = icmp ne i32 %t196, %t197
  br i1 %t200, label %bb47, label %bb48
bb47:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load i32, ptr %l3, !tbaa !23
  %t206 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBody(ptr %v0, ptr %t202, i32 %t203)
  store i64 %t206, ptr %l115
  br label %bb49
bb48:
  br label %bb64
bb49:
  %t207 = load i64, ptr %l115, !tbaa !24
  store i64 %t207, ptr %l11, !tbaa !24
  %t208 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t210 = extractvalue { i64, ptr } %t208, 0
  %t212 = icmp eq i64 %t210, 1
  br i1 %t212, label %bb50, label %bb51
bb50:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t215, ptr %l121, !tbaa !27
  %t216 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = getelementptr ptr, ptr %t217, i64 0
  %t219 = load ptr, ptr %t218, !tbaa !39
  %t222 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t214, ptr %t219)
  store i1 %t222, ptr %l123
  br label %bb52
bb51:
  store i1 false, ptr %l119, !tbaa !21
  br label %bb53
bb52:
  %t223 = load i1, ptr %l123, !tbaa !21
  store i1 %t223, ptr %l119, !tbaa !21
  br label %bb53
bb53:
  %t224 = load i1, ptr %l119, !tbaa !21
  store i1 %t224, ptr %l12, !tbaa !21
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load i1, ptr %l12, !tbaa !21
  %t229 = getelementptr %"compiler/check:Checker", ptr %t225, i32 0, i32 36
  store i1 %t226, ptr %t229, !tbaa !21
  %t230 = load ptr, ptr %l0, !tbaa !29
  store ptr %t230, ptr %l126, !tbaa !29
  %t231 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t231, ptr %l127
  %t232 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t232, ptr %l128
  %t233 = load i32, ptr %l10, !tbaa !23
  store i32 %t233, ptr %l129, !tbaa !23
  %t234 = load i64, ptr %l11, !tbaa !24
  %t236 = trunc i64 %t234 to i32
  store { i64, [1 x i64] } zeroinitializer, ptr %t238
  %t239 = getelementptr { i64, [1 x i64] }, ptr %t238, i32 0, i32 0
  store i64 0, ptr %t239
  %t241 = insertvalue { i32 } undef, i32 %t236, 0
  %t242 = getelementptr { i64, [1 x i64] }, ptr %t238, i32 0, i32 1
  store { i32 } %t241, ptr %t242
  %t243 = load { i64, [1 x i64] }, ptr %t238
  %t245 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store { i64, [1 x i64] } %t243, ptr %t245
  store ptr %t245, ptr %l134, !tbaa !29
  %t246 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t246, ptr %l135, !tbaa !27
  %t247 = icmp sge i64 0, 0
  br i1 %t247, label %bb54, label %bb55
bb54:
  %t249 = icmp sle i64 0, 1152921504606846975
  br i1 %t249, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_5759851fa91ce76c_a0f65aa07f0891f0)
  unreachable
bb56:
  %t251 = mul i64 0, 8
  %t252 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t251)
  %t253 = insertvalue { i64, ptr } undef, i64 0, 0
  %t254 = insertvalue { i64, ptr } %t253, ptr %t252, 1
  %t255 = load ptr, ptr %l126, !tbaa !29
  %t256 = load %"compiler/source:Span", ptr %l127
  %t257 = load %"compiler/source:Span", ptr %l128
  %t258 = load i32, ptr %l129, !tbaa !23
  %t259 = load ptr, ptr %l134, !tbaa !29
  %t260 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t262 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v1, ptr %t255, %"compiler/source:Span" %t256, %"compiler/source:Span" %t257, i32 %t258, ptr %t259, i64 -1, ptr null, { i64, ptr } %t260, { i64, ptr } %t254)
  store ptr %t262, ptr %l139
  br label %bb58
bb57:
  call void @__olang_check_failed(ptr @olang_loc_5759851fa91ce76c_a0f65aa07f0891f0)
  unreachable
bb58:
  %t263 = load ptr, ptr %l139, !tbaa !29
  store ptr %t263, ptr %l13, !tbaa !29
  %t264 = load i1, ptr %l12, !tbaa !21
  br i1 %t264, label %bb59, label %bb60
bb59:
  %t266 = load ptr, ptr %l0, !tbaa !29
  store ptr %t266, ptr %l141, !tbaa !29
  store i32 0, ptr %l142
  %t267 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t267, ptr %l143, !tbaa !27
  %t268 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t269 = load ptr, ptr %t268, !tbaa !27
  %t270 = getelementptr ptr, ptr %t269, i64 0
  %t271 = load ptr, ptr %t270, !tbaa !39
  %t273 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t271)
  store %"compiler/source:Span" %t273, ptr %l145
  br label %bb61
bb60:
  br label %bb63
bb61:
  %t274 = load i32, ptr %l3, !tbaa !23
  %t275 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t275, ptr %l147, !tbaa !27
  %t276 = getelementptr { i64, ptr }, ptr %l147, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !27
  %t278 = getelementptr ptr, ptr %t277, i64 0
  %t279 = load ptr, ptr %t278, !tbaa !39
  %t281 = load ptr, ptr %l141, !tbaa !29
  %t282 = load i32, ptr %l142
  %t283 = load %"compiler/source:Span", ptr %l145
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2easkValue(ptr %v0, ptr %v1, ptr %t281, i32 %t282, %"compiler/source:Span" %t283, i32 %t274, ptr %t279)
  br label %bb62
bb62:
  br label %bb63
bb63:
  %t286 = load ptr, ptr %l13, !tbaa !29
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t286, ptr %rv
  br label %ret
bb64:
  %t288 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t290 = extractvalue { i64, ptr } %t288, 0
  %t292 = icmp ne i64 %t290, 1
  br i1 %t292, label %bb65, label %bb66
bb65:
  store %olang.scope zeroinitializer, ptr %s9
  %t294 = load ptr, ptr %l0, !tbaa !29
  store ptr %t294, ptr %l154, !tbaa !29
  %t295 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t295, ptr %l155
  %t296 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t298 = extractvalue { i64, ptr } %t296, 0
  %t300 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %s9, ptr %s9, i64 1, { i64, ptr } { i64 0, ptr @.d26 }, i64 %t298)
  store %"compiler/msgs:Msg" %t300, ptr %l158
  br label %bb67
bb66:
  br label %bb70
bb67:
  %t301 = load ptr, ptr %l154, !tbaa !29
  %t302 = load %"compiler/source:Span", ptr %l155
  %t303 = load %"compiler/msgs:Msg", ptr %l158
  %t304 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s9, ptr %t301, %"compiler/source:Span" %t302, %"compiler/msgs:Msg" %t303)
  store i64 %t304, ptr %l159
  br label %bb68
bb68:
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t306 = load %"compiler/source:Span", ptr %l1
  %t309 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t305, %"compiler/source:Span" %t306)
  store ptr %t309, ptr %l162
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t310 = load ptr, ptr %l162, !tbaa !29
  store ptr %t310, ptr %rv
  br label %ret
bb70:
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t313 = getelementptr %"compiler/check:Checker", ptr %t311, i32 0, i32 1
  %t314 = load ptr, ptr %t313, !tbaa !29
  %t316 = getelementptr %"compiler/generic:Program", ptr %t314, i32 0, i32 2
  %t317 = load i32, ptr %l3, !tbaa !23
  %t320 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t316, i32 %t317)
  store i32 %t320, ptr %l167
  br label %bb71
bb71:
  %t321 = load i32, ptr %l167, !tbaa !23
  store i32 %t321, ptr %l14, !tbaa !23
  %t322 = load ptr, ptr %l0, !tbaa !29
  store ptr %t322, ptr %l168, !tbaa !29
  %t323 = load ptr, ptr %l0, !tbaa !29
  store ptr %t323, ptr %l169, !tbaa !29
  %t324 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t324, ptr %l170, !tbaa !27
  %t325 = getelementptr { i64, ptr }, ptr %l170, i32 0, i32 1
  %t326 = load ptr, ptr %t325, !tbaa !27
  %t327 = getelementptr ptr, ptr %t326, i64 0
  %t328 = load ptr, ptr %t327, !tbaa !39
  store ptr %t328, ptr %l172, !tbaa !29
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t331 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t331, ptr %l174, !tbaa !27
  %t332 = getelementptr { i64, ptr }, ptr %l174, i32 0, i32 1
  %t333 = load ptr, ptr %t332, !tbaa !27
  %t334 = getelementptr ptr, ptr %t333, i64 0
  %t335 = load ptr, ptr %t334, !tbaa !39
  %t338 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t330, ptr %t335)
  store i1 %t338, ptr %l176
  br label %bb72
bb72:
  %t339 = load i1, ptr %l176, !tbaa !21
  br i1 %t339, label %bb73, label %bb74
bb73:
  %t340 = load i32, ptr %l3, !tbaa !23
  store i32 %t340, ptr %l177, !tbaa !23
  br label %bb75
bb74:
  %t342 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t342, ptr %l177, !tbaa !23
  br label %bb75
bb75:
  %t344 = load ptr, ptr %l169, !tbaa !29
  %t345 = load ptr, ptr %l172, !tbaa !29
  %t346 = load i32, ptr %l177, !tbaa !23
  %t347 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t344, ptr %t345, i32 %t346)
  store ptr %t347, ptr %l180
  br label %bb76
bb76:
  %t348 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t348, ptr %l181, !tbaa !27
  %t349 = getelementptr { i64, ptr }, ptr %l181, i32 0, i32 1
  %t350 = load ptr, ptr %t349, !tbaa !27
  %t351 = getelementptr ptr, ptr %t350, i64 0
  %t352 = load ptr, ptr %t351, !tbaa !39
  %t354 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t352)
  store %"compiler/source:Span" %t354, ptr %l183
  br label %bb77
bb77:
  %t355 = load ptr, ptr %l168, !tbaa !29
  %t356 = load ptr, ptr %l180, !tbaa !29
  %t357 = load %"compiler/source:Span", ptr %l183
  %t358 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t355, ptr %t356, %"compiler/source:Span" %t357)
  store ptr %t358, ptr %l184
  br label %bb78
bb78:
  %t359 = load ptr, ptr %l184, !tbaa !29
  store ptr %t359, ptr %l15, !tbaa !29
  %t360 = load ptr, ptr %l15, !tbaa !29
  %t363 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t360)
  store i32 %t363, ptr %l187
  br label %bb79
bb79:
  %t364 = load i32, ptr %l187, !tbaa !23
  store i32 %t364, ptr %l16, !tbaa !23
  %t365 = load i32, ptr %l16, !tbaa !23
  %t366 = load i32, ptr %l3, !tbaa !23
  %t369 = icmp eq i32 %t365, %t366
  br i1 %t369, label %bb80, label %bb81
bb80:
  store i1 true, ptr %l191, !tbaa !21
  br label %bb82
bb81:
  %t371 = load i32, ptr %l16, !tbaa !23
  %t372 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t375 = icmp eq i32 %t371, %t372
  store i1 %t375, ptr %l191, !tbaa !21
  br label %bb82
bb82:
  %t377 = load i1, ptr %l191, !tbaa !21
  br i1 %t377, label %bb83, label %bb84
bb83:
  %t378 = load ptr, ptr %l15, !tbaa !29
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t378, ptr %rv
  br label %ret
bb84:
  br label %bb85
bb85:
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t381 = load i32, ptr %l16, !tbaa !23
  %t384 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t380, i32 %t381)
  store i1 %t384, ptr %l198
  br label %bb86
bb86:
  %t385 = load i1, ptr %l198, !tbaa !21
  br i1 %t385, label %bb87, label %bb88
bb87:
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t387 = load i32, ptr %l3, !tbaa !23
  %t390 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t386, i32 %t387)
  store i1 %t390, ptr %l202
  br label %bb89
bb88:
  store i1 false, ptr %l199, !tbaa !21
  br label %bb90
bb89:
  %t391 = load i1, ptr %l202, !tbaa !21
  store i1 %t391, ptr %l199, !tbaa !21
  br label %bb90
bb90:
  %t392 = load i1, ptr %l199, !tbaa !21
  br i1 %t392, label %bb91, label %bb92
bb91:
  %t393 = load ptr, ptr %l0, !tbaa !29
  %t394 = load %"compiler/source:Span", ptr %l1
  %t395 = load ptr, ptr %l15, !tbaa !29
  %t396 = load i32, ptr %l3, !tbaa !23
  %t401 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t393, %"compiler/source:Span" %t394, ptr %t395, i32 %t396)
  store ptr %t401, ptr %l207
  br label %bb93
bb92:
  br label %bb94
bb93:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t402 = load ptr, ptr %l207, !tbaa !29
  store ptr %t402, ptr %rv
  br label %ret
bb94:
  %t403 = load ptr, ptr %l0, !tbaa !29
  store ptr %t403, ptr %l208, !tbaa !29
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t405 = load i32, ptr %l16, !tbaa !23
  %t408 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t404, i32 %t405)
  store i32 %t408, ptr %l211
  br label %bb95
bb95:
  %t409 = load i32, ptr %l14, !tbaa !23
  %t410 = load ptr, ptr %l208, !tbaa !29
  %t411 = load i32, ptr %l211, !tbaa !23
  %t413 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %t410, i32 %t411, i32 %t409)
  store i1 %t413, ptr %l213
  br label %bb96
bb96:
  %t414 = load i1, ptr %l213, !tbaa !21
  br i1 %t414, label %bb97, label %bb98
bb97:
  store i1 true, ptr %l214, !tbaa !21
  br label %bb101
bb98:
  %t415 = load ptr, ptr %l0, !tbaa !29
  store ptr %t415, ptr %l215, !tbaa !29
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t417 = load i32, ptr %l16, !tbaa !23
  %t420 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t416, i32 %t417)
  store i32 %t420, ptr %l218
  br label %bb99
bb99:
  %t421 = load i32, ptr %l14, !tbaa !23
  %t422 = load ptr, ptr %l215, !tbaa !29
  %t423 = load i32, ptr %l218, !tbaa !23
  %t425 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esameRepr(ptr %v0, ptr %t422, i32 %t423, i32 %t421)
  store i1 %t425, ptr %l220
  br label %bb100
bb100:
  %t426 = load i1, ptr %l220, !tbaa !21
  store i1 %t426, ptr %l214, !tbaa !21
  br label %bb101
bb101:
  %t427 = load i1, ptr %l214, !tbaa !21
  br i1 %t427, label %bb102, label %bb103
bb102:
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t429 = load i32, ptr %l16, !tbaa !23
  %t432 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t428, i32 %t429)
  store i1 %t432, ptr %l223
  br label %bb104
bb103:
  br label %bb140
bb104:
  %t433 = load i1, ptr %l223, !tbaa !21
  br i1 %t433, label %bb105, label %bb106
bb105:
  %t434 = load ptr, ptr %l0, !tbaa !29
  store ptr %t434, ptr %l224, !tbaa !29
  %t435 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t435, ptr %l225
  %t436 = load ptr, ptr %l15, !tbaa !29
  store ptr %t436, ptr %l226, !tbaa !29
  %t437 = load ptr, ptr %l0, !tbaa !29
  %t439 = getelementptr %"compiler/check:Checker", ptr %t437, i32 0, i32 1
  %t440 = load ptr, ptr %t439, !tbaa !29
  %t442 = getelementptr %"compiler/generic:Program", ptr %t440, i32 0, i32 2
  store ptr %t442, ptr %l229, !tbaa !29
  %t443 = load i32, ptr %l3, !tbaa !23
  store i32 %t443, ptr %l230, !tbaa !23
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t446 = getelementptr %"compiler/check:Checker", ptr %t444, i32 0, i32 1
  %t447 = load ptr, ptr %t446, !tbaa !29
  %t449 = getelementptr %"compiler/generic:Program", ptr %t447, i32 0, i32 2
  %t450 = load i32, ptr %l16, !tbaa !23
  %t453 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t449, i32 %t450)
  store i64 %t453, ptr %l235
  br label %bb107
bb106:
  br label %bb110
bb107:
  %t454 = load ptr, ptr %l229, !tbaa !29
  %t455 = load i32, ptr %l230, !tbaa !23
  %t456 = load i64, ptr %l235, !tbaa !24
  %t457 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t454, i32 %t455, i64 %t456)
  store i32 %t457, ptr %l236
  br label %bb108
bb108:
  %t458 = load ptr, ptr %l224, !tbaa !29
  %t459 = load %"compiler/source:Span", ptr %l225
  %t460 = load ptr, ptr %l226, !tbaa !29
  %t461 = load i32, ptr %l236, !tbaa !23
  %t462 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t458, %"compiler/source:Span" %t459, ptr %t460, i32 %t461)
  store ptr %t462, ptr %l237
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t463 = load ptr, ptr %l237, !tbaa !29
  store ptr %t463, ptr %rv
  br label %ret
bb110:
  %t464 = load ptr, ptr %l15, !tbaa !29
  %t466 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %t464)
  store ptr %t466, ptr %l239
  br label %bb111
bb111:
  %t467 = load ptr, ptr %l239, !tbaa !29
  store ptr %t467, ptr %l17, !tbaa !29
  %t468 = load ptr, ptr %l17, !tbaa !29
  %t470 = icmp eq ptr %t468, null
  %t472 = xor i1 %t470, true
  br i1 %t472, label %bb112, label %bb113
bb112:
  %t474 = load ptr, ptr %l0, !tbaa !29
  %t476 = getelementptr %"compiler/check:Checker", ptr %t474, i32 0, i32 1
  %t477 = load ptr, ptr %t476, !tbaa !29
  %t479 = getelementptr %"compiler/generic:Program", ptr %t477, i32 0, i32 2
  store ptr %t479, ptr %l246, !tbaa !29
  %t480 = load ptr, ptr %l0, !tbaa !29
  %t481 = load i32, ptr %l16, !tbaa !23
  %t484 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t480, i32 %t481)
  store i32 %t484, ptr %l249
  br label %bb114
bb113:
  store i1 false, ptr %l243, !tbaa !21
  br label %bb116
bb114:
  %t485 = load ptr, ptr %l246, !tbaa !29
  %t486 = load i32, ptr %l249, !tbaa !23
  %t487 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t485, i32 %t486)
  store i32 %t487, ptr %l250
  br label %bb115
bb115:
  %t488 = load i32, ptr %l250
  %t490 = trunc i64 19 to i32
  %t491 = icmp eq i32 %t488, %t490
  store i1 %t491, ptr %l243, !tbaa !21
  br label %bb116
bb116:
  %t493 = load i1, ptr %l243, !tbaa !21
  br i1 %t493, label %bb117, label %bb118
bb117:
  %t494 = load ptr, ptr %l0, !tbaa !29
  %t496 = getelementptr %"compiler/check:Checker", ptr %t494, i32 0, i32 1
  %t497 = load ptr, ptr %t496, !tbaa !29
  %t499 = getelementptr %"compiler/generic:Program", ptr %t497, i32 0, i32 2
  %t500 = load i32, ptr %l14, !tbaa !23
  %t503 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t499, i32 %t500)
  store i32 %t503, ptr %l258
  br label %bb119
bb118:
  store i1 false, ptr %l253, !tbaa !21
  br label %bb120
bb119:
  %t504 = load i32, ptr %l258
  %t506 = trunc i64 19 to i32
  %t507 = icmp eq i32 %t504, %t506
  store i1 %t507, ptr %l253, !tbaa !21
  br label %bb120
bb120:
  %t509 = load i1, ptr %l253, !tbaa !21
  br i1 %t509, label %bb121, label %bb122
bb121:
  %t510 = load ptr, ptr %l0, !tbaa !29
  %t511 = load ptr, ptr %l17, !tbaa !29
  %t514 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceWritable(ptr %v0, ptr %v0, ptr %t510, ptr %t511)
  store i1 %t514, ptr %l263
  br label %bb123
bb122:
  br label %bb131
bb123:
  %t515 = load i1, ptr %l263, !tbaa !21
  br i1 %t515, label %bb124, label %bb125
bb124:
  %t516 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  store i64 %t516, ptr %l264, !tbaa !24
  br label %bb126
bb125:
  %t518 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  store i64 %t518, ptr %l264, !tbaa !24
  br label %bb126
bb126:
  %t520 = load i64, ptr %l264, !tbaa !24
  store i64 %t520, ptr %l18, !tbaa !24
  %t521 = load ptr, ptr %l0, !tbaa !29
  store ptr %t521, ptr %l267, !tbaa !29
  %t522 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t522, ptr %l268
  %t523 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t523, ptr %l269
  %t524 = load ptr, ptr %l0, !tbaa !29
  %t526 = getelementptr %"compiler/check:Checker", ptr %t524, i32 0, i32 1
  %t527 = load ptr, ptr %t526, !tbaa !29
  %t529 = getelementptr %"compiler/generic:Program", ptr %t527, i32 0, i32 2
  %t530 = load i32, ptr %l16, !tbaa !23
  %t531 = load i64, ptr %l18, !tbaa !24
  %t535 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t529, i32 %t530, i64 %t531)
  store i32 %t535, ptr %l275
  br label %bb127
bb127:
  %t536 = load ptr, ptr %l17, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t537
  %t538 = getelementptr { i64, [5 x i64] }, ptr %t537, i32 0, i32 0
  store i64 3, ptr %t538
  %t539 = load %"compiler/source:Span", ptr %l269
  %t540 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t539, 0
  %t541 = load i32, ptr %l275, !tbaa !23
  %t542 = insertvalue { %"compiler/source:Span", i32, ptr } %t540, i32 %t541, 1
  %t544 = insertvalue { %"compiler/source:Span", i32, ptr } %t542, ptr %t536, 2
  %t545 = getelementptr { i64, [5 x i64] }, ptr %t537, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t544, ptr %t545
  %t546 = load { i64, [5 x i64] }, ptr %t537
  %t548 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t546, ptr %t548
  store ptr %t548, ptr %l278, !tbaa !29
  %t549 = load ptr, ptr %l0, !tbaa !29
  %t551 = getelementptr %"compiler/check:Checker", ptr %t549, i32 0, i32 1
  %t552 = load ptr, ptr %t551, !tbaa !29
  %t554 = getelementptr %"compiler/generic:Program", ptr %t552, i32 0, i32 2
  %t555 = load i32, ptr %l3, !tbaa !23
  %t556 = load i64, ptr %l18, !tbaa !24
  %t560 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t554, i32 %t555, i64 %t556)
  store i32 %t560, ptr %l284
  br label %bb128
bb128:
  %t561 = load ptr, ptr %l267, !tbaa !29
  %t562 = load %"compiler/source:Span", ptr %l268
  %t563 = load ptr, ptr %l278, !tbaa !29
  %t564 = load i32, ptr %l284, !tbaa !23
  %t565 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t561, %"compiler/source:Span" %t562, ptr %t563, i32 %t564)
  store ptr %t565, ptr %l285
  br label %bb129
bb129:
  %t566 = load ptr, ptr %l285, !tbaa !29
  %t567 = load ptr, ptr %l0, !tbaa !29
  %t568 = load %"compiler/source:Span", ptr %l1
  %t569 = load %"compiler/source:Span", ptr %l1
  %t570 = load i32, ptr %l3, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t572
  %t573 = getelementptr { i64, [4 x i64] }, ptr %t572, i32 0, i32 0
  store i64 2, ptr %t573
  %t575 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t569, 0
  %t577 = insertvalue { %"compiler/source:Span", i32, ptr } %t575, i32 %t570, 1
  %t579 = insertvalue { %"compiler/source:Span", i32, ptr } %t577, ptr %t566, 2
  %t580 = getelementptr { i64, [4 x i64] }, ptr %t572, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t579, ptr %t580
  %t581 = load { i64, [4 x i64] }, ptr %t572
  %t583 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t581, ptr %t583
  %t587 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t567, %"compiler/source:Span" %t568, ptr %t583)
  store ptr %t587, ptr %l293
  br label %bb130
bb130:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t588 = load ptr, ptr %l293, !tbaa !29
  store ptr %t588, ptr %rv
  br label %ret
bb131:
  %t589 = load ptr, ptr %l0, !tbaa !29
  %t590 = load i32, ptr %l16, !tbaa !23
  %t591 = load i32, ptr %l14, !tbaa !23
  %t595 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %t589, i32 %t590, i32 %t591)
  store i1 %t595, ptr %l297
  br label %bb132
bb132:
  %t596 = load i1, ptr %l297, !tbaa !21
  %t597 = xor i1 %t596, true
  br i1 %t597, label %bb133, label %bb134
bb133:
  %t599 = load ptr, ptr %l0, !tbaa !29
  %t600 = load %"compiler/source:Span", ptr %l1
  %t601 = load ptr, ptr %l15, !tbaa !29
  %t602 = load i32, ptr %l3, !tbaa !23
  %t607 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t599, %"compiler/source:Span" %t600, ptr %t601, i32 %t602)
  store ptr %t607, ptr %l303
  br label %bb135
bb134:
  br label %bb136
bb135:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t608 = load ptr, ptr %l303, !tbaa !29
  store ptr %t608, ptr %rv
  br label %ret
bb136:
  %t609 = load ptr, ptr %l0, !tbaa !29
  store ptr %t609, ptr %l304, !tbaa !29
  %t610 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t610, ptr %l305
  %t611 = load ptr, ptr %l0, !tbaa !29
  store ptr %t611, ptr %l306, !tbaa !29
  %t612 = load ptr, ptr %l15, !tbaa !29
  store ptr %t612, ptr %l307, !tbaa !29
  %t613 = load i32, ptr %l14, !tbaa !23
  store i32 %t613, ptr %l308, !tbaa !23
  %t614 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t614, ptr %l309, !tbaa !27
  %t615 = getelementptr { i64, ptr }, ptr %l309, i32 0, i32 1
  %t616 = load ptr, ptr %t615, !tbaa !27
  %t617 = getelementptr ptr, ptr %t616, i64 0
  %t618 = load ptr, ptr %t617, !tbaa !39
  %t620 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t618)
  store %"compiler/source:Span" %t620, ptr %l311
  br label %bb137
bb137:
  %t621 = load ptr, ptr %l306, !tbaa !29
  %t622 = load ptr, ptr %l307, !tbaa !29
  %t623 = load i32, ptr %l308, !tbaa !23
  %t624 = load %"compiler/source:Span", ptr %l311
  %t625 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t621, ptr %t622, i32 %t623, %"compiler/source:Span" %t624)
  store ptr %t625, ptr %l312
  br label %bb138
bb138:
  %t626 = load i32, ptr %l3, !tbaa !23
  %t627 = load ptr, ptr %l304, !tbaa !29
  %t628 = load %"compiler/source:Span", ptr %l305
  %t629 = load ptr, ptr %l312, !tbaa !29
  %t631 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t627, %"compiler/source:Span" %t628, ptr %t629, i32 %t626)
  store ptr %t631, ptr %l314
  br label %bb139
bb139:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t632 = load ptr, ptr %l314, !tbaa !29
  store ptr %t632, ptr %rv
  br label %ret
bb140:
  %t633 = load ptr, ptr %l0, !tbaa !29
  store ptr %t633, ptr %l315, !tbaa !29
  %t634 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t634, ptr %l316, !tbaa !27
  %t635 = getelementptr { i64, ptr }, ptr %l316, i32 0, i32 1
  %t636 = load ptr, ptr %t635, !tbaa !27
  %t637 = getelementptr ptr, ptr %t636, i64 0
  %t638 = load ptr, ptr %t637, !tbaa !39
  %t640 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t638)
  store %"compiler/source:Span" %t640, ptr %l318
  br label %bb141
bb141:
  %t641 = load ptr, ptr %l0, !tbaa !29
  %t642 = load i32, ptr %l14, !tbaa !23
  %t645 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s6, ptr %t641, i32 %t642)
  store { i64, ptr } %t645, ptr %l321
  br label %bb142
bb142:
  %t646 = load { i64, ptr }, ptr %l321, !tbaa !27
  %t647 = extractvalue { i64, ptr } %t646, 0
  %t648 = extractvalue { i64, ptr } %t646, 1
  %t649 = mul i64 %t647, 1
  %t650 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t649)
  call void @llvm.memcpy.p0.p0.i64(ptr %t650, ptr %t648, i64 %t649, i1 false)
  %t651 = insertvalue { i64, ptr } undef, i64 %t647, 0
  %t652 = insertvalue { i64, ptr } %t651, ptr %t650, 1
  store { i64, ptr } %t652, ptr %l322, !tbaa !27
  %t653 = load ptr, ptr %l0, !tbaa !29
  %t654 = load i32, ptr %l16, !tbaa !23
  %t657 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s6, ptr %t653, i32 %t654)
  store { i64, ptr } %t657, ptr %l325
  br label %bb143
bb143:
  %t658 = load { i64, ptr }, ptr %l325, !tbaa !27
  %t659 = extractvalue { i64, ptr } %t658, 0
  %t660 = extractvalue { i64, ptr } %t658, 1
  %t661 = mul i64 %t659, 1
  %t662 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t661)
  call void @llvm.memcpy.p0.p0.i64(ptr %t662, ptr %t660, i64 %t661, i1 false)
  %t663 = insertvalue { i64, ptr } undef, i64 %t659, 0
  %t664 = insertvalue { i64, ptr } %t663, ptr %t662, 1
  %t665 = load { i64, ptr }, ptr %l322, !tbaa !27
  %t667 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeMismatch(ptr %s6, ptr %s6, ptr %s6, { i64, ptr } %t665, { i64, ptr } %t664)
  store %"compiler/msgs:Msg" %t667, ptr %l327
  br label %bb144
bb144:
  %t668 = load ptr, ptr %l315, !tbaa !29
  %t669 = load %"compiler/source:Span", ptr %l318
  %t670 = load %"compiler/msgs:Msg", ptr %l327
  %t671 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t668, %"compiler/source:Span" %t669, %"compiler/msgs:Msg" %t670)
  store i64 %t671, ptr %l328
  br label %bb145
bb145:
  %t672 = load ptr, ptr %l0, !tbaa !29
  %t673 = load %"compiler/source:Span", ptr %l1
  %t676 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t672, %"compiler/source:Span" %t673)
  store ptr %t676, ptr %l331
  br label %bb146
bb146:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t677 = load ptr, ptr %l331, !tbaa !29
  store ptr %t677, ptr %rv
  br label %ret
bb147:
  %t678 = load i32, ptr %l5
  %t680 = trunc i64 1 to i32
  %t681 = icmp eq i32 %t678, %t680
  br i1 %t681, label %bb148, label %bb149
bb148:
  store %olang.scope zeroinitializer, ptr %s16
  %t683 = load ptr, ptr %l0, !tbaa !29
  store ptr %t683, ptr %l334, !tbaa !29
  %t684 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t684, ptr %l335
  %t685 = load ptr, ptr %l0, !tbaa !29
  %t686 = load %"compiler/source:Span", ptr %l2
  %t689 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t685, %"compiler/source:Span" %t686)
  store { i64, ptr } %t689, ptr %l338
  br label %bb150
bb149:
  br label %bb156
bb150:
  %t690 = load { i64, ptr }, ptr %l338, !tbaa !27
  %t691 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %s16, { i64, ptr } %t690)
  store { i64, ptr } %t691, ptr %l339
  br label %bb151
bb151:
  %t692 = load { i64, ptr }, ptr %l339, !tbaa !27
  %t693 = extractvalue { i64, ptr } %t692, 0
  %t694 = extractvalue { i64, ptr } %t692, 1
  %t695 = mul i64 %t693, 1
  %t696 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t695)
  call void @llvm.memcpy.p0.p0.i64(ptr %t696, ptr %t694, i64 %t695, i1 false)
  %t697 = insertvalue { i64, ptr } undef, i64 %t693, 0
  %t698 = insertvalue { i64, ptr } %t697, ptr %t696, 1
  %t700 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeHasNoConstructor(ptr %s16, ptr %s16, { i64, ptr } %t698)
  store %"compiler/msgs:Msg" %t700, ptr %l341
  br label %bb152
bb152:
  %t701 = load ptr, ptr %l334, !tbaa !29
  %t702 = load %"compiler/source:Span", ptr %l335
  %t703 = load %"compiler/msgs:Msg", ptr %l341
  %t704 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s16, ptr %t701, %"compiler/source:Span" %t702, %"compiler/msgs:Msg" %t703)
  store i64 %t704, ptr %l342
  br label %bb153
bb153:
  %t705 = load ptr, ptr %l0, !tbaa !29
  %t706 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t705, { i64, ptr } %t706)
  br label %bb154
bb154:
  %t709 = load ptr, ptr %l0, !tbaa !29
  %t710 = load %"compiler/source:Span", ptr %l1
  %t713 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t709, %"compiler/source:Span" %t710)
  store ptr %t713, ptr %l347
  br label %bb155
bb155:
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  %t714 = load ptr, ptr %l347, !tbaa !29
  store ptr %t714, ptr %rv
  br label %ret
bb156:
  %t715 = load ptr, ptr %l0, !tbaa !29
  %t716 = load %"compiler/source:Span", ptr %l2
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s0, ptr %t715, %"compiler/source:Span" %t716, { i64, ptr } { i64 26, ptr @.d27 })
  br label %bb157
bb157:
  %t719 = load ptr, ptr %l0, !tbaa !29
  %t720 = load %"compiler/source:Span", ptr %l1
  %t723 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t719, %"compiler/source:Span" %t720)
  store ptr %t723, ptr %l352
  br label %bb158
bb158:
  call void @__olang_scope_close(ptr %s0)
  %t724 = load ptr, ptr %l352, !tbaa !29
  store ptr %t724, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edecls(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l29 = alloca i1
  %l42 = alloca { i64, ptr }
  %l46 = alloca ptr
  %l50 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l54 = alloca i64
  %l57 = alloca ptr
  %l58 = alloca i1
  %l78 = alloca ptr
  %l79 = alloca i1
  %l103 = alloca ptr
  %l104 = alloca i1
  %l109 = alloca ptr
  %l110 = alloca i64
  %l111 = alloca ptr
  %l114 = alloca ptr
  %l115 = alloca i64
  %l121 = alloca %"compiler/source:Span"
  %l123 = alloca i64
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  store { i64, ptr } %a2, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l6, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l6, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb54
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t15, ptr %l25, !tbaa !27
  %t16 = load i64, ptr %l5, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l7, !tbaa !29
  %t23 = load ptr, ptr %l7, !tbaa !29
  store ptr %t23, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t24 = load ptr, ptr %l28, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l28, !tbaa !29
  %t28 = load i64, ptr %t27
  %t30 = icmp eq i64 %t28, 3
  store i1 %t30, ptr %l29, !tbaa !21
  br label %bb6
bb6:
  %t31 = load i1, ptr %l29, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l7, !tbaa !29
  %t34 = getelementptr { i64, [4 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", ptr }, ptr %t34, i32 0, i32 1
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l8, !tbaa !29
  br label %bb9
bb8:
  br label %bb19
bb9:
  %t38 = load ptr, ptr %l8, !tbaa !29
  %t40 = getelementptr %"compiler/ast:VarDecl", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  store i64 %t45, ptr %l11, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s5
  %t47 = load i64, ptr %l10, !tbaa !24
  %t48 = load i64, ptr %l11, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s5)
  br label %bb18
bb12:
  br label %bb13
bb13:
  %t55 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t55, ptr %l42, !tbaa !27
  %t56 = load i64, ptr %l10, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i32, ptr %t59, i64 %t56
  %t61 = load i32, ptr %t60, !tbaa !33
  store i32 %t61, ptr %l12, !tbaa !23
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 24
  store ptr %t65, ptr %l46, !tbaa !29
  %t66 = load i64, ptr %l1, !tbaa !24
  %t67 = load i32, ptr %l12, !tbaa !23
  %t69 = sext i32 %t67 to i64
  %t72 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s5, i64 %t66, i64 %t69)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t72, ptr %l50
  br label %bb14
bb14:
  %t73 = load ptr, ptr %l46, !tbaa !29
  %t74 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l50
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_Hb6f924c91b81223120b2cba278ece4a6(ptr %v0, ptr %t73, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t74)
  br label %bb15
bb15:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i64, ptr %l1, !tbaa !24
  %t77 = load i32, ptr %l12, !tbaa !23
  %t81 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalBody(ptr %v0, ptr %t75, i64 %t76, i32 %t77)
  store i64 %t81, ptr %l54
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s5)
  br label %bb17
bb17:
  %t82 = load i64, ptr %l10, !tbaa !24
  %t84 = add i64 %t82, 1
  store i64 %t84, ptr %l10, !tbaa !24
  br label %bb10
bb18:
  br label %bb52
bb19:
  %t86 = load ptr, ptr %l7, !tbaa !29
  store ptr %t86, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t87 = load ptr, ptr %l57, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb20, label %bb21
bb20:
  %t90 = load ptr, ptr %l57, !tbaa !29
  %t91 = load i64, ptr %t90
  %t93 = icmp eq i64 %t91, 6
  store i1 %t93, ptr %l58, !tbaa !21
  br label %bb21
bb21:
  %t94 = load i1, ptr %l58, !tbaa !21
  br i1 %t94, label %bb22, label %bb23
bb22:
  %t95 = load ptr, ptr %l7, !tbaa !29
  %t97 = getelementptr { i64, [4 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } }, ptr %t97, i32 0, i32 0
  %t99 = load %"compiler/source:Span", ptr %t98
  store %"compiler/source:Span" %t99, ptr %l13
  %t101 = load ptr, ptr %l7, !tbaa !29
  %t103 = getelementptr { i64, [4 x i64] }, ptr %t101, i32 0, i32 1
  %t104 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } }, ptr %t103, i32 0, i32 2
  %t105 = load { i64, ptr }, ptr %t104
  store { i64, ptr } %t105, ptr %l14, !tbaa !27
  br label %bb24
bb23:
  br label %bb29
bb24:
  %t107 = load i64, ptr %l1, !tbaa !24
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/check:Checker", ptr %t108, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = getelementptr %"compiler/generic:Program", ptr %t111, i32 0, i32 0
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = getelementptr %"compiler/load:Loader", ptr %t114, i32 0, i32 7
  %t117 = load i64, ptr %t116, !tbaa !24
  %t120 = icmp eq i64 %t107, %t117
  br i1 %t120, label %bb25, label %bb26
bb25:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load i64, ptr %l1, !tbaa !24
  %t124 = load %"compiler/source:Span", ptr %l13
  %t125 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t126 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etestBody(ptr %v0, ptr %v1, ptr %t122, i64 %t123, %"compiler/source:Span" %t124, { i64, ptr } %t125, i64 %t126)
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb28
bb28:
  %t132 = load i64, ptr %l3, !tbaa !24
  %t134 = add i64 %t132, 1
  store i64 %t134, ptr %l3, !tbaa !24
  br label %bb52
bb29:
  %t136 = load ptr, ptr %l7, !tbaa !29
  store ptr %t136, ptr %l78, !tbaa !29
  store i1 false, ptr %l79, !tbaa !21
  %t137 = load ptr, ptr %l78, !tbaa !29
  %t138 = icmp ne ptr %t137, null
  br i1 %t138, label %bb30, label %bb31
bb30:
  %t140 = load ptr, ptr %l78, !tbaa !29
  %t141 = load i64, ptr %t140
  %t143 = icmp eq i64 %t141, 2
  store i1 %t143, ptr %l79, !tbaa !21
  br label %bb31
bb31:
  %t144 = load i1, ptr %l79, !tbaa !21
  br i1 %t144, label %bb32, label %bb33
bb32:
  %t145 = load ptr, ptr %l7, !tbaa !29
  %t147 = getelementptr { i64, [4 x i64] }, ptr %t145, i32 0, i32 1
  %t148 = getelementptr { %"compiler/source:Span", ptr }, ptr %t147, i32 0, i32 0
  %t149 = load %"compiler/source:Span", ptr %t148
  store %"compiler/source:Span" %t149, ptr %l15
  %t151 = load ptr, ptr %l7, !tbaa !29
  %t153 = getelementptr { i64, [4 x i64] }, ptr %t151, i32 0, i32 1
  %t154 = getelementptr { %"compiler/source:Span", ptr }, ptr %t153, i32 0, i32 1
  %t155 = load ptr, ptr %t154
  store ptr %t155, ptr %l16, !tbaa !29
  br label %bb34
bb33:
  br label %bb39
bb34:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load i64, ptr %l1, !tbaa !24
  %t159 = load %"compiler/source:Span", ptr %l15
  %t160 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeRules(ptr %v0, ptr %v1, ptr %t157, i64 %t158, %"compiler/source:Span" %t159, ptr %t160)
  br label %bb35
bb35:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load i64, ptr %l1, !tbaa !24
  %t168 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaredCtor(ptr %v0, ptr %v1, ptr %t166, i64 %t167, ptr %t168)
  br label %bb36
bb36:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i64, ptr %l1, !tbaa !24
  %t175 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitSets(ptr %v0, ptr %v1, ptr %t173, i64 %t174, ptr %t175)
  br label %bb37
bb37:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load i64, ptr %l1, !tbaa !24
  %t182 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitHeader(ptr %v0, ptr %v1, ptr %t180, i64 %t181, ptr %t182)
  br label %bb38
bb38:
  br label %bb52
bb39:
  %t187 = load ptr, ptr %l7, !tbaa !29
  store ptr %t187, ptr %l103, !tbaa !29
  store i1 false, ptr %l104, !tbaa !21
  %t188 = load ptr, ptr %l103, !tbaa !29
  %t189 = icmp ne ptr %t188, null
  br i1 %t189, label %bb40, label %bb41
bb40:
  %t191 = load ptr, ptr %l103, !tbaa !29
  %t192 = load i64, ptr %t191
  %t194 = icmp eq i64 %t192, 7
  store i1 %t194, ptr %l104, !tbaa !21
  br label %bb41
bb41:
  %t195 = load i1, ptr %l104, !tbaa !21
  br i1 %t195, label %bb42, label %bb43
bb42:
  %t196 = load ptr, ptr %l7, !tbaa !29
  %t198 = getelementptr { i64, [4 x i64] }, ptr %t196, i32 0, i32 1
  %t199 = getelementptr { %"compiler/source:Span", ptr }, ptr %t198, i32 0, i32 1
  %t200 = load ptr, ptr %t199
  store ptr %t200, ptr %l17, !tbaa !29
  br label %bb44
bb43:
  br label %bb51
bb44:
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l109, !tbaa !29
  %t203 = load i64, ptr %l1, !tbaa !24
  store i64 %t203, ptr %l110, !tbaa !24
  %t204 = load ptr, ptr %l17, !tbaa !29
  store ptr %t204, ptr %l111, !tbaa !29
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/check:Checker", ptr %t205, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !29
  %t210 = getelementptr %"compiler/generic:Program", ptr %t208, i32 0, i32 0
  %t211 = load ptr, ptr %t210, !tbaa !29
  store ptr %t211, ptr %l114, !tbaa !29
  %t212 = load i64, ptr %l1, !tbaa !24
  store i64 %t212, ptr %l115, !tbaa !24
  %t213 = load ptr, ptr %l17, !tbaa !29
  %t215 = getelementptr %"compiler/ast:TopIf", ptr %t213, i32 0, i32 0
  %t216 = load ptr, ptr %t215, !tbaa !29
  %t218 = icmp eq ptr %t216, null
  br i1 %t218, label %bb45, label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_9f7e5ad647601e13_a7b1cb3e26ad346f)
  unreachable
bb46:
  br label %bb47
bb47:
  %t220 = load ptr, ptr %l17, !tbaa !29
  %t222 = getelementptr %"compiler/ast:TopIf", ptr %t220, i32 0, i32 0
  %t223 = load ptr, ptr %t222, !tbaa !29
  %t225 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t223)
  store %"compiler/source:Span" %t225, ptr %l121
  br label %bb48
bb48:
  %t226 = getelementptr %"compiler/source:Span", ptr %l121, i32 0, i32 0
  %t227 = load i32, ptr %t226, !tbaa !23
  %t228 = load ptr, ptr %l114, !tbaa !29
  %t229 = load i64, ptr %l115, !tbaa !24
  %t231 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eChosen(ptr %v0, ptr %t228, i64 %t229, i32 %t227)
  store i64 %t231, ptr %l123
  br label %bb49
bb49:
  %t232 = load ptr, ptr %l109, !tbaa !29
  %t233 = load i64, ptr %l110, !tbaa !24
  %t234 = load ptr, ptr %l111, !tbaa !29
  %t235 = load i64, ptr %l123, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclsIf(ptr %v0, ptr %v1, ptr %t232, i64 %t233, ptr %t234, i64 %t235, i64 0)
  br label %bb50
bb50:
  br label %bb52
bb51:
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s2)
  br label %bb53
bb53:
  %t236 = load i64, ptr %l5, !tbaa !24
  %t238 = add i64 %t236, 1
  store i64 %t238, ptr %l5, !tbaa !24
  br label %bb1
bb54:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederivedCheckedAt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l9 = alloca i64
  %l15 = alloca ptr
  %l22 = alloca i32
  %l29 = alloca ptr
  %l32 = alloca %"compiler/source:Span"
  %l35 = alloca { i64, ptr }
  %l37 = alloca %"compiler/msgs:Msg"
  %l38 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l49 = alloca i64
  %l51 = alloca ptr
  %l54 = alloca %"compiler/source:Span"
  %l55 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca { i64, ptr }
  %l60 = alloca %"compiler/msgs:Msg"
  %l61 = alloca i64
  %l63 = alloca ptr
  %l64 = alloca ptr
  %l73 = alloca i32
  %l78 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l3, !tbaa !23
  %t3 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  %t9 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t1, i32 %t2, { i64, ptr } { i64 9, ptr @.d28 }, i64 %t5)
  store i64 %t9, ptr %l9
  br label %bb1
bb1:
  %t10 = load i64, ptr %l9, !tbaa !24
  %t11 = icmp sge i64 %t10, 0
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = icmp sge i64 0, 0
  br i1 %t13, label %bb4, label %bb5
bb3:
  br label %bb8
bb4:
  %t15 = icmp sle i64 0, 1152921504606846975
  br i1 %t15, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_77184c1d82837de9_1cf0b29343463305)
  unreachable
bb6:
  %t17 = mul i64 0, 8
  %t18 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 0, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t20, ptr %rv
  br label %ret
bb7:
  call void @__olang_check_failed(ptr @olang_loc_77184c1d82837de9_1cf0b29343463305)
  unreachable
bb8:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t22)
  store ptr %t24, ptr %l15
  br label %bb9
bb9:
  %t25 = load ptr, ptr %l15, !tbaa !29
  %t27 = getelementptr %"compiler/check:frame", ptr %t25, i32 0, i32 16
  %t28 = load i64, ptr %t27, !tbaa !24
  %t30 = icmp eq i64 %t28, 0
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i64, ptr @G_2ecompiler_2fcheck_2eBounds, !tbaa !65
  %t37 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckOp(ptr %v0, ptr %t32, i32 0, i64 %t33)
  store i32 %t37, ptr %l22
  br label %bb12
bb11:
  br label %bb17
bb12:
  %t38 = icmp sge i64 0, 0
  br i1 %t38, label %bb13, label %bb14
bb13:
  %t40 = icmp sle i64 0, 1152921504606846975
  br i1 %t40, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_f35f30377e494c1c_7f1bf7df374d1e98)
  unreachable
bb15:
  %t42 = mul i64 0, 8
  %t43 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 0, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t45, ptr %rv
  br label %ret
bb16:
  call void @__olang_check_failed(ptr @olang_loc_f35f30377e494c1c_7f1bf7df374d1e98)
  unreachable
bb17:
  %t47 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  %t51 = icmp ne i64 %t49, 1
  br i1 %t51, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s3
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l29, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l1
  %t58 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebracketIn(ptr %v0, ptr %t54, %"compiler/source:Span" %t55)
  store %"compiler/source:Span" %t58, ptr %l32
  br label %bb20
bb19:
  br label %bb29
bb20:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i32, ptr %l3, !tbaa !23
  %t63 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t59, i32 %t60)
  store { i64, ptr } %t63, ptr %l35
  br label %bb21
bb21:
  %t64 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  %t66 = extractvalue { i64, ptr } %t64, 1
  %t67 = mul i64 %t65, 1
  %t68 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t67)
  call void @llvm.memcpy.p0.p0.i64(ptr %t68, ptr %t66, i64 %t67, i1 false)
  %t69 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t68, 1
  %t72 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTryMultiIndexNeedsTryat(ptr %s3, ptr %s3, ptr %s3, { i64, ptr } %t70, { i64, ptr } { i64 9, ptr @.d29 })
  store %"compiler/msgs:Msg" %t72, ptr %l37
  br label %bb22
bb22:
  %t73 = load ptr, ptr %l29, !tbaa !29
  %t74 = load %"compiler/source:Span", ptr %l32
  %t75 = load %"compiler/msgs:Msg", ptr %l37
  %t76 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t73, %"compiler/source:Span" %t74, %"compiler/msgs:Msg" %t75)
  store i64 %t76, ptr %l38
  br label %bb23
bb23:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t77)
  store ptr %t79, ptr %l40
  br label %bb24
bb24:
  %t80 = load ptr, ptr %l40, !tbaa !29
  store ptr %t80, ptr %l41, !tbaa !29
  %t81 = load ptr, ptr %l41, !tbaa !29
  %t82 = getelementptr %"compiler/check:frame", ptr %t81, i32 0, i32 17
  %t83 = load i64, ptr %t82, !tbaa !24
  %t85 = add i64 %t83, 1
  %t87 = load ptr, ptr %l41, !tbaa !29
  %t88 = getelementptr %"compiler/check:frame", ptr %t87, i32 0, i32 17
  store i64 %t85, ptr %t88, !tbaa !24
  %t89 = icmp sge i64 0, 0
  br i1 %t89, label %bb25, label %bb26
bb25:
  %t91 = icmp sle i64 0, 1152921504606846975
  br i1 %t91, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_be9b28680965c17f_ec7705667e82647b)
  unreachable
bb27:
  %t93 = mul i64 0, 8
  %t94 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t93)
  %t95 = insertvalue { i64, ptr } undef, i64 0, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t96, ptr %rv
  br label %ret
bb28:
  call void @__olang_check_failed(ptr @olang_loc_be9b28680965c17f_ec7705667e82647b)
  unreachable
bb29:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load i32, ptr %l3, !tbaa !23
  %t102 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t98, i32 %t99, { i64, ptr } { i64 3, ptr @.d30 }, i64 0)
  store i64 %t102, ptr %l49
  br label %bb30
bb30:
  %t103 = load i64, ptr %l49, !tbaa !24
  %t104 = icmp slt i64 %t103, 0
  br i1 %t104, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s4
  %t106 = load ptr, ptr %l0, !tbaa !29
  store ptr %t106, ptr %l51, !tbaa !29
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load %"compiler/source:Span", ptr %l1
  %t111 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebracketIn(ptr %v0, ptr %t107, %"compiler/source:Span" %t108)
  store %"compiler/source:Span" %t111, ptr %l54
  br label %bb33
bb32:
  br label %bb43
bb33:
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l55, !tbaa !29
  %t113 = load ptr, ptr %l2, !tbaa !29
  %t115 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %t113)
  store i32 %t115, ptr %l57
  br label %bb34
bb34:
  %t116 = load ptr, ptr %l55, !tbaa !29
  %t117 = load i32, ptr %l57, !tbaa !23
  %t118 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s4, ptr %t116, i32 %t117)
  store { i64, ptr } %t118, ptr %l58
  br label %bb35
bb35:
  %t119 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t119, 0
  %t121 = extractvalue { i64, ptr } %t119, 1
  %t122 = mul i64 %t120, 1
  %t123 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t122)
  call void @llvm.memcpy.p0.p0.i64(ptr %t123, ptr %t121, i64 %t122, i1 false)
  %t124 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t123, 1
  %t127 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTryIndexNeedsLen(ptr %s4, ptr %s4, { i64, ptr } %t125)
  store %"compiler/msgs:Msg" %t127, ptr %l60
  br label %bb36
bb36:
  %t128 = load ptr, ptr %l51, !tbaa !29
  %t129 = load %"compiler/source:Span", ptr %l54
  %t130 = load %"compiler/msgs:Msg", ptr %l60
  %t131 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t128, %"compiler/source:Span" %t129, %"compiler/msgs:Msg" %t130)
  store i64 %t131, ptr %l61
  br label %bb37
bb37:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t132)
  store ptr %t134, ptr %l63
  br label %bb38
bb38:
  %t135 = load ptr, ptr %l63, !tbaa !29
  store ptr %t135, ptr %l64, !tbaa !29
  %t136 = load ptr, ptr %l64, !tbaa !29
  %t137 = getelementptr %"compiler/check:frame", ptr %t136, i32 0, i32 17
  %t138 = load i64, ptr %t137, !tbaa !24
  %t140 = add i64 %t138, 1
  %t142 = load ptr, ptr %l64, !tbaa !29
  %t143 = getelementptr %"compiler/check:frame", ptr %t142, i32 0, i32 17
  store i64 %t140, ptr %t143, !tbaa !24
  %t144 = icmp sge i64 0, 0
  br i1 %t144, label %bb39, label %bb40
bb39:
  %t146 = icmp sle i64 0, 1152921504606846975
  br i1 %t146, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_c8857a233d9e8faa_24519e517389b3e6)
  unreachable
bb41:
  %t148 = mul i64 0, 8
  %t149 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t148)
  %t150 = insertvalue { i64, ptr } undef, i64 0, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t151, ptr %rv
  br label %ret
bb42:
  call void @__olang_check_failed(ptr @olang_loc_c8857a233d9e8faa_24519e517389b3e6)
  unreachable
bb43:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load i64, ptr @G_2ecompiler_2fcheck_2eBounds, !tbaa !65
  %t158 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckOp(ptr %v0, ptr %t153, i32 0, i64 %t154)
  store i32 %t158, ptr %l73
  br label %bb44
bb44:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load %"compiler/source:Span", ptr %l1
  %t161 = load ptr, ptr %l2, !tbaa !29
  %t162 = load i32, ptr %l3, !tbaa !23
  %t163 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t163, ptr %l78, !tbaa !27
  %t164 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !27
  %t166 = getelementptr ptr, ptr %t165, i64 0
  %t167 = load ptr, ptr %t166, !tbaa !39
  %t173 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einRange(ptr %v0, ptr %v1, ptr %t159, %"compiler/source:Span" %t160, ptr %t161, i32 %t162, ptr %t167)
  store { i64, ptr } %t173, ptr %l80
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s0)
  %t174 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t174, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelseHolds(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l20 = alloca i1
  %l24 = alloca ptr
  %l32 = alloca i1
  %l33 = alloca i1
  %l37 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 5
  store i1 %t13, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l7, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", ptr }, ptr %t17, i32 0, i32 1
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb23
bb8:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"compiler/ast:If", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = icmp eq ptr %t24, null
  br i1 %t26, label %bb9, label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_50a05787c39822f3_4820228f4f4dc477)
  unreachable
bb10:
  br label %bb11
bb11:
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = getelementptr %"compiler/ast:If", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t34 = getelementptr %"compiler/ast:Branch", ptr %t31, i32 0, i32 2
  %t35 = load i64, ptr %t34, !tbaa !24
  %t37 = icmp sge i64 %t35, 0
  br i1 %t37, label %bb12, label %bb13
bb12:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/generic:Program", ptr %t42, i32 0, i32 0
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = getelementptr %"compiler/load:Loader", ptr %t45, i32 0, i32 4
  %t48 = load ptr, ptr %t47, !tbaa !29
  store ptr %t48, ptr %l24, !tbaa !29
  %t49 = load ptr, ptr %l2, !tbaa !29
  %t51 = getelementptr %"compiler/ast:If", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = icmp eq ptr %t52, null
  br i1 %t54, label %bb14, label %bb15
bb13:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb18
bb14:
  call void @__olang_check_failed(ptr @olang_loc_50a05787c39822f3_4820228f4f4dc477)
  unreachable
bb15:
  br label %bb16
bb16:
  %t56 = load ptr, ptr %l2, !tbaa !29
  %t58 = getelementptr %"compiler/ast:If", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t62 = getelementptr %"compiler/ast:Branch", ptr %t59, i32 0, i32 2
  %t63 = load i64, ptr %t62, !tbaa !24
  %t64 = load ptr, ptr %l24, !tbaa !29
  %t66 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHolds(ptr %v0, ptr %t64, i64 %t63)
  store i1 %t66, ptr %l32
  br label %bb17
bb17:
  %t67 = load i1, ptr %l32, !tbaa !21
  store i1 %t67, ptr %l20, !tbaa !21
  br label %bb18
bb18:
  %t68 = load i1, ptr %l20, !tbaa !21
  br i1 %t68, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb22
bb20:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load ptr, ptr %l2, !tbaa !29
  %t72 = getelementptr %"compiler/ast:If", ptr %t70, i32 0, i32 2
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t76 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelseHolds(ptr %v0, ptr %v1, ptr %t69, ptr %t73)
  store i1 %t76, ptr %l37
  br label %bb21
bb21:
  %t77 = load i1, ptr %l37, !tbaa !21
  store i1 %t77, ptr %l33, !tbaa !21
  br label %bb22
bb22:
  %t78 = load i1, ptr %l33, !tbaa !21
  store i1 %t78, ptr %rv
  br label %ret
bb23:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKeep(ptr %v0, ptr %v0, ptr %t1, ptr %t2)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 32
  %t8 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v0, ptr %t7, ptr %t8)
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeqMethod(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i64
  %l17 = alloca i1
  %l18 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca i32
  %l27 = alloca i32
  %l28 = alloca i64
  %l31 = alloca i1
  %l34 = alloca ptr
  %l37 = alloca ptr
  %l41 = alloca i32
  %l42 = alloca i32
  %l43 = alloca { i64, ptr }
  %l50 = alloca i64
  %l52 = alloca ptr
  %l56 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  store i32 %t5, ptr %l5, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/load:Loader", ptr %t12, i32 0, i32 3
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t15, { i64, ptr } { i64 2, ptr @.d31 })
  store i32 %t17, ptr %l10
  br label %bb1
bb1:
  %t18 = load ptr, ptr %l4, !tbaa !29
  %t19 = load i32, ptr %l5, !tbaa !23
  %t20 = load i32, ptr %l10, !tbaa !23
  %t21 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t18, i32 %t19, i32 %t20)
  store i64 %t21, ptr %l11
  br label %bb2
bb2:
  %t22 = load i64, ptr %l11, !tbaa !24
  store i64 %t22, ptr %l2, !tbaa !24
  %t23 = load i64, ptr %l2, !tbaa !24
  %t25 = icmp sge i64 %t23, 0
  br i1 %t25, label %bb3, label %bb4
bb3:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l1, !tbaa !23
  %t29 = load i64, ptr %l2, !tbaa !24
  %t33 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeqShaped(ptr %v0, ptr %t27, i32 %t28, i64 %t29)
  store i1 %t33, ptr %l17
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t34 = load i1, ptr %l17, !tbaa !21
  br i1 %t34, label %bb6, label %bb7
bb6:
  %t35 = load i64, ptr %l2, !tbaa !24
  store i64 %t35, ptr %l18, !tbaa !24
  br label %bb8
bb7:
  store i64 -1, ptr %l18, !tbaa !24
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t37 = load i64, ptr %l18, !tbaa !24
  store i64 %t37, ptr %rv
  br label %ret
bb9:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  store ptr %t41, ptr %l21, !tbaa !29
  %t42 = load i32, ptr %l1, !tbaa !23
  store i32 %t42, ptr %l22, !tbaa !23
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 0
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/load:Loader", ptr %t49, i32 0, i32 3
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t52, { i64, ptr } { i64 2, ptr @.d32 })
  store i32 %t54, ptr %l27
  br label %bb10
bb10:
  %t55 = load ptr, ptr %l21, !tbaa !29
  %t56 = load i32, ptr %l22, !tbaa !23
  %t57 = load i32, ptr %l27, !tbaa !23
  %t58 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t55, i32 %t56, i32 %t57)
  store i64 %t58, ptr %l28
  br label %bb11
bb11:
  %t59 = load i64, ptr %l28, !tbaa !24
  store i64 %t59, ptr %l2, !tbaa !24
  %t60 = load i64, ptr %l2, !tbaa !24
  %t62 = icmp slt i64 %t60, 0
  br i1 %t62, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb17
bb13:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  store ptr %t69, ptr %l34, !tbaa !29
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/check:Checker", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/generic:Program", ptr %t73, i32 0, i32 2
  store ptr %t75, ptr %l37, !tbaa !29
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t80 = load i64, ptr %l2, !tbaa !24
  %t83 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t79, i64 %t80)
  store i32 %t83, ptr %l41
  br label %bb14
bb14:
  %t84 = load ptr, ptr %l37, !tbaa !29
  %t85 = load i32, ptr %l41, !tbaa !23
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t84, i32 %t85)
  store i32 %t86, ptr %l42
  br label %bb15
bb15:
  %t87 = load ptr, ptr %l34, !tbaa !29
  %t88 = load i32, ptr %l42, !tbaa !23
  %t89 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t87, i32 %t88)
  store { i64, ptr } %t89, ptr %l43
  br label %bb16
bb16:
  %t90 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  %t93 = icmp ne i64 %t91, 2
  store i1 %t93, ptr %l31, !tbaa !21
  br label %bb17
bb17:
  %t95 = load i1, ptr %l31, !tbaa !21
  br i1 %t95, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t101 = load i64, ptr %l2, !tbaa !24
  %t104 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t100, i64 %t101)
  store i64 %t104, ptr %l50
  br label %bb21
bb21:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t105)
  store ptr %t107, ptr %l52
  br label %bb22
bb22:
  %t108 = load ptr, ptr %l52, !tbaa !29
  %t110 = getelementptr %"compiler/check:frame", ptr %t108, i32 0, i32 1
  %t111 = load i64, ptr %t110, !tbaa !24
  %t112 = load i64, ptr %l50, !tbaa !24
  %t114 = icmp eq i64 %t112, %t111
  br i1 %t114, label %bb23, label %bb24
bb23:
  %t116 = load i64, ptr %l2, !tbaa !24
  store i64 %t116, ptr %l56, !tbaa !24
  br label %bb25
bb24:
  store i64 -2, ptr %l56, !tbaa !24
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t118 = load i64, ptr %l56, !tbaa !24
  store i64 %t118, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorTypeHeld(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"compiler/names:Ref"
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i1
  %l21 = alloca ptr
  %l23 = alloca ptr
  %l27 = alloca %"compiler/names:Ref"
  %l33 = alloca ptr
  %l35 = alloca ptr
  %l39 = alloca %"compiler/names:Ref"
  %l43 = alloca i1
  %l49 = alloca ptr
  %l54 = alloca i32
  %l55 = alloca i32
  %l61 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l67 = alloca ptr
  %l74 = alloca %"compiler/source:Span"
  %l77 = alloca %"compiler/msgs:Msg"
  %l78 = alloca i64
  %l80 = alloca ptr
  %l81 = alloca i1
  %l89 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca i1
  %l98 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t7 = load ptr, ptr %l11, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l11, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l12, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l12, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t17, i32 0, i32 0
  %t19 = load %"compiler/source:Span", ptr %t18
  store %"compiler/source:Span" %t19, ptr %l2
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [5 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t23, i32 0, i32 1
  %t25 = load { i64, ptr }, ptr %t24
  store { i64, ptr } %t25, ptr %l3, !tbaa !27
  br label %bb8
bb7:
  br label %bb31
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/generic:Program", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  store ptr %t33, ptr %l21, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t34)
  store ptr %t36, ptr %l23
  br label %bb9
bb9:
  %t37 = load ptr, ptr %l23, !tbaa !29
  %t39 = getelementptr %"compiler/check:frame", ptr %t37, i32 0, i32 2
  %t40 = load i64, ptr %t39, !tbaa !24
  %t41 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t42 = load i32, ptr %t41, !tbaa !23
  %t43 = load ptr, ptr %l21, !tbaa !29
  %t46 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t43, i64 %t40, i32 %t42)
  store %"compiler/names:Ref" %t46, ptr %l27
  br label %bb10
bb10:
  %t47 = load %"compiler/names:Ref", ptr %l27
  store %"compiler/names:Ref" %t47, ptr %l4
  %t48 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t48, 0
  %t52 = icmp sgt i64 %t50, 1
  br i1 %t52, label %bb11, label %bb12
bb11:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/generic:Program", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  store ptr %t60, ptr %l33, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t61)
  store ptr %t63, ptr %l35
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t64 = load ptr, ptr %l35, !tbaa !29
  %t66 = getelementptr %"compiler/check:frame", ptr %t64, i32 0, i32 2
  %t67 = load i64, ptr %t66, !tbaa !24
  %t68 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t69 = load i32, ptr %t68, !tbaa !23
  %t70 = load ptr, ptr %l33, !tbaa !29
  %t73 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %t70, i64 %t67, i32 %t69)
  store %"compiler/names:Ref" %t73, ptr %l39
  br label %bb14
bb14:
  %t74 = load %"compiler/names:Ref", ptr %l39
  store %"compiler/names:Ref" %t74, ptr %l4
  br label %bb15
bb15:
  %t75 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t76 = load i32, ptr %t75
  %t78 = trunc i64 4 to i32
  %t79 = icmp eq i32 %t76, %t78
  %t81 = xor i1 %t79, true
  br i1 %t81, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb18
bb17:
  %t83 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 2
  %t84 = load i64, ptr %t83, !tbaa !24
  %t86 = icmp slt i64 %t84, 0
  store i1 %t86, ptr %l43, !tbaa !21
  br label %bb18
bb18:
  %t88 = load i1, ptr %l43, !tbaa !21
  br i1 %t88, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/check:Checker", ptr %t90, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = getelementptr %"compiler/generic:Program", ptr %t93, i32 0, i32 2
  store ptr %t95, ptr %l49, !tbaa !29
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/check:Checker", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t100 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 1
  %t101 = load i64, ptr %t100, !tbaa !24
  %t102 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 2
  %t103 = load i64, ptr %t102, !tbaa !24
  %t107 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t99, i64 %t101, i64 %t103)
  store i32 %t107, ptr %l54
  br label %bb22
bb22:
  %t108 = load ptr, ptr %l49, !tbaa !29
  %t109 = load i32, ptr %l54, !tbaa !23
  %t110 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t108, i32 %t109)
  store i32 %t110, ptr %l55
  br label %bb23
bb23:
  %t111 = load i32, ptr %l55
  %t113 = trunc i64 2 to i32
  %t114 = icmp eq i32 %t111, %t113
  %t116 = xor i1 %t114, true
  br i1 %t116, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t120, ptr %l61, !tbaa !27
  %t121 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t121, 0
  %t125 = sub i64 %t123, 1
  %t127 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = getelementptr i32, ptr %t128, i64 %t125
  %t130 = load i32, ptr %t129, !tbaa !33
  %t133 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t119, i32 %t130)
  store { i64, ptr } %t133, ptr %l66
  br label %bb27
bb27:
  %t134 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t134, ptr %l5, !tbaa !27
  %t135 = load ptr, ptr %l0, !tbaa !29
  store ptr %t135, ptr %l67, !tbaa !29
  %t136 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t137 = load i32, ptr %t136, !tbaa !23
  %t138 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t138, 0
  %t142 = trunc i64 %t140 to i32
  %t145 = sub i32 %t137, %t142
  %t146 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t147 = load i32, ptr %t146, !tbaa !23
  %t150 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s2, i32 %t145, i32 %t147)
  store %"compiler/source:Span" %t150, ptr %l74
  br label %bb28
bb28:
  %t151 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t152 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t155 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorTypeAsValue(ptr %v0, ptr %v0, ptr %s2, { i64, ptr } %t151, { i64, ptr } %t152)
  store %"compiler/msgs:Msg" %t155, ptr %l77
  br label %bb29
bb29:
  %t156 = load ptr, ptr %l67, !tbaa !29
  %t157 = load %"compiler/source:Span", ptr %l74
  %t158 = load %"compiler/msgs:Msg", ptr %l77
  %t159 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t156, %"compiler/source:Span" %t157, %"compiler/msgs:Msg" %t158)
  store i64 %t159, ptr %l78
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb31:
  %t161 = load ptr, ptr %l1, !tbaa !29
  store ptr %t161, ptr %l80, !tbaa !29
  store i1 false, ptr %l81, !tbaa !21
  %t162 = load ptr, ptr %l80, !tbaa !29
  %t163 = icmp ne ptr %t162, null
  br i1 %t163, label %bb32, label %bb33
bb32:
  %t165 = load ptr, ptr %l80, !tbaa !29
  %t166 = load i64, ptr %t165
  %t168 = icmp eq i64 %t166, 3
  store i1 %t168, ptr %l81, !tbaa !21
  br label %bb33
bb33:
  %t169 = load i1, ptr %l81, !tbaa !21
  br i1 %t169, label %bb34, label %bb35
bb34:
  %t170 = load ptr, ptr %l1, !tbaa !29
  %t172 = getelementptr { i64, [5 x i64] }, ptr %t170, i32 0, i32 1
  %t173 = getelementptr { %"compiler/source:Span", ptr, i32, i1 }, ptr %t172, i32 0, i32 1
  %t174 = load ptr, ptr %t173
  store ptr %t174, ptr %l6, !tbaa !29
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load ptr, ptr %l6, !tbaa !29
  %t181 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorTypeHeld(ptr %v0, ptr %v1, ptr %t176, ptr %t177)
  store i1 %t181, ptr %l89
  br label %bb37
bb37:
  %t182 = load i1, ptr %l89, !tbaa !21
  store i1 %t182, ptr %rv
  br label %ret
bb38:
  %t183 = load ptr, ptr %l1, !tbaa !29
  store ptr %t183, ptr %l90, !tbaa !29
  store i1 false, ptr %l91, !tbaa !21
  %t184 = load ptr, ptr %l90, !tbaa !29
  %t185 = icmp ne ptr %t184, null
  br i1 %t185, label %bb39, label %bb40
bb39:
  %t187 = load ptr, ptr %l90, !tbaa !29
  %t188 = load i64, ptr %t187
  %t190 = icmp eq i64 %t188, 4
  store i1 %t190, ptr %l91, !tbaa !21
  br label %bb40
bb40:
  %t191 = load i1, ptr %l91, !tbaa !21
  br i1 %t191, label %bb41, label %bb42
bb41:
  %t192 = load ptr, ptr %l1, !tbaa !29
  %t194 = getelementptr { i64, [5 x i64] }, ptr %t192, i32 0, i32 1
  %t195 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t194, i32 0, i32 1
  %t196 = load ptr, ptr %t195
  store ptr %t196, ptr %l7, !tbaa !29
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t199 = load ptr, ptr %l7, !tbaa !29
  %t202 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorTypeHeld(ptr %v0, ptr %v1, ptr %t198, ptr %t199)
  store i1 %t202, ptr %l98
  br label %bb44
bb44:
  %t203 = load i1, ptr %l98, !tbaa !21
  store i1 %t203, ptr %rv
  br label %ret
bb45:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldTypeAt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l11 = alloca i1
  %l14 = alloca i1
  %l19 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca { i64, ptr }
  %l30 = alloca i32
  %l31 = alloca { i64, ptr }
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l5, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 14
  %t7 = load i32, ptr %t6, !tbaa !23
  store i32 %t7, ptr %l2, !tbaa !23
  %t9 = load i32, ptr %l2, !tbaa !23
  %t10 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t13 = icmp eq i32 %t9, %t10
  br i1 %t13, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb5
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l2, !tbaa !23
  %t19 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l14
  br label %bb4
bb4:
  %t20 = load i1, ptr %l14, !tbaa !21
  %t21 = xor i1 %t20, true
  store i1 %t21, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t23 = load i1, ptr %l11, !tbaa !21
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t24 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t24, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/generic:Program", ptr %t29, i32 0, i32 2
  store ptr %t31, ptr %l19, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  %t38 = load i32, ptr %l2, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l24
  br label %bb9
bb9:
  %t42 = load ptr, ptr %l19, !tbaa !29
  %t43 = load i32, ptr %l24, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t42, i32 %t43)
  store { i64, ptr } %t44, ptr %l25
  br label %bb10
bb10:
  %t45 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t45, ptr %l3, !tbaa !27
  %t46 = load i64, ptr %l1, !tbaa !24
  %t47 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  %t52 = icmp slt i64 %t46, %t49
  br i1 %t52, label %bb11, label %bb12
bb11:
  %t54 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t54, ptr %l31, !tbaa !27
  %t55 = load i64, ptr %l1, !tbaa !24
  %t57 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr i32, ptr %t58, i64 %t55
  %t60 = load i32, ptr %t59, !tbaa !33
  store i32 %t60, ptr %l30, !tbaa !23
  br label %bb13
bb12:
  %t62 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t62, ptr %l30, !tbaa !23
  br label %bb13
bb13:
  %t64 = load i32, ptr %l30, !tbaa !23
  store i32 %t64, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnValue(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca %"compiler/generic:Origin"
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l12 = alloca ptr
  %l15 = alloca i1
  %l19 = alloca i1
  %l21 = alloca i1
  %l23 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i64
  %l33 = alloca ptr
  %l38 = alloca i64
  %l45 = alloca i64
  %l48 = alloca ptr
  %l49 = alloca %"compiler/source:Span"
  %l53 = alloca { i64, ptr }
  %l54 = alloca %"compiler/msgs:Msg"
  %l55 = alloca i64
  %l58 = alloca ptr
  %l62 = alloca i1
  %l66 = alloca i64
  %l70 = alloca ptr
  %l71 = alloca %"compiler/source:Span"
  %l75 = alloca { i64, ptr }
  %l76 = alloca %"compiler/msgs:Msg"
  %l77 = alloca i64
  %l80 = alloca ptr
  %l85 = alloca i32
  %l90 = alloca i1
  %l94 = alloca ptr
  %l96 = alloca ptr
  %l97 = alloca i64
  %l98 = alloca i32
  %l101 = alloca { i64, [3 x i64] }
  %l102 = alloca i1
  %l105 = alloca ptr
  %l108 = alloca i1
  %l112 = alloca i1
  %l117 = alloca ptr
  %l121 = alloca i32
  %l126 = alloca ptr
  %l128 = alloca ptr
  %l130 = alloca i64
  %l131 = alloca %"compiler/source:Span"
  %l133 = alloca i64
  %l134 = alloca %"compiler/generic:Origin"
  %l139 = alloca i64
  %l145 = alloca i1
  %l146 = alloca ptr
  %l150 = alloca i32
  %l152 = alloca i1
  %l156 = alloca ptr
  %l159 = alloca i64
  %l163 = alloca i32
  %l166 = alloca i1
  %l169 = alloca ptr
  %l174 = alloca i32
  %l179 = alloca i32
  %l182 = alloca i32
  %l187 = alloca i32
  %l188 = alloca i32
  %l190 = alloca ptr
  %l191 = alloca i64
  %l194 = alloca { i64, [3 x i64] }
  %l195 = alloca ptr
  %l199 = alloca ptr
  %l202 = alloca { i64, ptr }
  %l205 = alloca %"compiler/check:roFn"
  %l209 = alloca ptr
  %l213 = alloca i1
  %l217 = alloca i64
  %l220 = alloca ptr
  %l225 = alloca i32
  %l226 = alloca { i64, ptr }
  %l231 = alloca ptr
  %l232 = alloca i32
  %l237 = alloca i64
  %l238 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca ptr
  %t502 = alloca { i64, [4 x i64] }, align 8
  %t510 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 0, ptr %l4, !tbaa !23
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sge i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %t8, i64 %t9)
  store i1 %t12, ptr %l19
  br label %bb3
bb2:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb4
bb3:
  %t13 = load i1, ptr %l19, !tbaa !21
  %t14 = xor i1 %t13, true
  store i1 %t14, ptr %l15, !tbaa !21
  br label %bb4
bb4:
  %t16 = load i1, ptr %l15, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  store ptr %t20, ptr %l23, !tbaa !29
  %t21 = load i64, ptr %l2, !tbaa !24
  %t23 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t21)
  store i64 %t23, ptr %l25
  br label %bb7
bb6:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb9
bb7:
  %t24 = load ptr, ptr %l23, !tbaa !29
  %t25 = load i64, ptr %l25, !tbaa !24
  %t26 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t24, i64 %t25)
  store i64 %t26, ptr %l26
  br label %bb8
bb8:
  %t27 = load i64, ptr %l26, !tbaa !24
  %t28 = icmp sgt i64 %t27, 0
  store i1 %t28, ptr %l21, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l21, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load i64, ptr %l2, !tbaa !24
  %t33 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t31)
  store i64 %t33, ptr %l29
  br label %bb12
bb11:
  br label %bb48
bb12:
  %t34 = load i64, ptr %l29, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t39 = load i64, ptr %l2, !tbaa !24
  %t42 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t38, i64 %t39)
  store ptr %t42, ptr %l33
  br label %bb13
bb13:
  %t43 = load ptr, ptr %l33, !tbaa !29
  store ptr %t43, ptr %l6, !tbaa !29
  %t44 = load ptr, ptr %l6, !tbaa !29
  %t46 = getelementptr %"compiler/ast:Func", ptr %t44, i32 0, i32 5
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  %t51 = icmp sgt i64 %t49, 0
  br i1 %t51, label %bb14, label %bb15
bb14:
  %t53 = load ptr, ptr %l6, !tbaa !29
  %t55 = getelementptr %"compiler/ast:Func", ptr %t53, i32 0, i32 5
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t56, 0
  store i64 %t58, ptr %l38, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb16
bb16:
  %t60 = load i64, ptr %l38, !tbaa !24
  store i64 %t60, ptr %l7, !tbaa !24
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/check:Checker", ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t65 = load i64, ptr %l5, !tbaa !24
  %t68 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t64, i64 %t65)
  store i64 %t68, ptr %l45
  br label %bb17
bb17:
  %t69 = load i64, ptr %l7, !tbaa !24
  %t70 = load i64, ptr %l45, !tbaa !24
  %t72 = icmp sgt i64 %t70, %t69
  br i1 %t72, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s2
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l48, !tbaa !29
  %t75 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t75, ptr %l49
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load ptr, ptr %l6, !tbaa !29
  %t79 = getelementptr %"compiler/ast:Func", ptr %t77, i32 0, i32 2
  %t80 = load i32, ptr %t79, !tbaa !23
  %t83 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t76, i32 %t80)
  store { i64, ptr } %t83, ptr %l53
  br label %bb20
bb19:
  br label %bb24
bb20:
  %t84 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t85 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLengthsNotAValue(ptr %v0, ptr %s2, { i64, ptr } %t84)
  store %"compiler/msgs:Msg" %t85, ptr %l54
  br label %bb21
bb21:
  %t86 = load ptr, ptr %l48, !tbaa !29
  %t87 = load %"compiler/source:Span", ptr %l49
  %t88 = load %"compiler/msgs:Msg", ptr %l54
  %t89 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t86, %"compiler/source:Span" %t87, %"compiler/msgs:Msg" %t88)
  store i64 %t89, ptr %l55
  br label %bb22
bb22:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load %"compiler/source:Span", ptr %l1
  %t94 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t90, %"compiler/source:Span" %t91)
  store ptr %t94, ptr %l58
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t95 = load ptr, ptr %l58, !tbaa !29
  store ptr %t95, ptr %rv
  br label %ret
bb24:
  %t96 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t96, 0
  %t100 = icmp eq i64 %t98, 0
  br i1 %t100, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb28
bb26:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/check:Checker", ptr %t102, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t106 = load i64, ptr %l5, !tbaa !24
  %t109 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t105, i64 %t106)
  store i64 %t109, ptr %l66
  br label %bb27
bb27:
  %t110 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t110, 0
  %t113 = load i64, ptr %l66, !tbaa !24
  %t115 = icmp ne i64 %t113, %t112
  store i1 %t115, ptr %l62, !tbaa !21
  br label %bb28
bb28:
  %t117 = load i1, ptr %l62, !tbaa !21
  br i1 %t117, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s3
  %t118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t118, ptr %l70, !tbaa !29
  %t119 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t119, ptr %l71
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load ptr, ptr %l6, !tbaa !29
  %t123 = getelementptr %"compiler/ast:Func", ptr %t121, i32 0, i32 2
  %t124 = load i32, ptr %t123, !tbaa !23
  %t127 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t120, i32 %t124)
  store { i64, ptr } %t127, ptr %l75
  br label %bb31
bb30:
  br label %bb35
bb31:
  %t128 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t129 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenericNotAValue(ptr %v0, ptr %s3, { i64, ptr } %t128)
  store %"compiler/msgs:Msg" %t129, ptr %l76
  br label %bb32
bb32:
  %t130 = load ptr, ptr %l70, !tbaa !29
  %t131 = load %"compiler/source:Span", ptr %l71
  %t132 = load %"compiler/msgs:Msg", ptr %l76
  %t133 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t130, %"compiler/source:Span" %t131, %"compiler/msgs:Msg" %t132)
  store i64 %t133, ptr %l77
  br label %bb33
bb33:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load %"compiler/source:Span", ptr %l1
  %t138 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t134, %"compiler/source:Span" %t135)
  store ptr %t138, ptr %l80
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t139 = load ptr, ptr %l80, !tbaa !29
  store ptr %t139, ptr %rv
  br label %ret
bb35:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/check:Checker", ptr %t140, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t145 = getelementptr %"compiler/generic:Program", ptr %t143, i32 0, i32 2
  %t146 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t149 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %t145, { i64, ptr } %t146)
  store i32 %t149, ptr %l85
  br label %bb36
bb36:
  %t150 = load i32, ptr %l85, !tbaa !23
  store i32 %t150, ptr %l4, !tbaa !23
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load i64, ptr %l5, !tbaa !24
  %t153 = load i32, ptr %l4, !tbaa !23
  %t154 = load %"compiler/source:Span", ptr %l1
  %t159 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebound(ptr %v0, ptr %t151, i64 %t152, i32 %t153, %"compiler/source:Span" %t154)
  store i1 %t159, ptr %l90
  br label %bb37
bb37:
  %t160 = load i1, ptr %l90, !tbaa !21
  %t161 = xor i1 %t160, true
  br i1 %t161, label %bb38, label %bb39
bb38:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load %"compiler/source:Span", ptr %l1
  %t167 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t163, %"compiler/source:Span" %t164)
  store ptr %t167, ptr %l94
  br label %bb40
bb39:
  br label %bb41
bb40:
  call void @__olang_scope_close(ptr %s0)
  %t168 = load ptr, ptr %l94, !tbaa !29
  store ptr %t168, ptr %rv
  br label %ret
bb41:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/check:Checker", ptr %t169, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !29
  store ptr %t172, ptr %l96, !tbaa !29
  %t173 = load i64, ptr %l2, !tbaa !24
  store i64 %t173, ptr %l97, !tbaa !24
  %t174 = load i32, ptr %l4, !tbaa !23
  store i32 %t174, ptr %l98, !tbaa !23
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load i64, ptr %l2, !tbaa !24
  %t179 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnNameAt(ptr %v0, ptr %t175, i64 %t176)
  store { i64, [3 x i64] } %t179, ptr %l101
  br label %bb42
bb42:
  %t180 = load ptr, ptr %l96, !tbaa !29
  %t181 = load i64, ptr %l97, !tbaa !24
  %t182 = load i32, ptr %l98, !tbaa !23
  %t183 = load { i64, [3 x i64] }, ptr %l101
  %t184 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnTooDeep(ptr %v0, ptr %t180, i64 %t181, i32 %t182, { i64, [3 x i64] } %t183)
  store i1 %t184, ptr %l102
  br label %bb43
bb43:
  %t185 = load i1, ptr %l102, !tbaa !21
  br i1 %t185, label %bb44, label %bb45
bb44:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load %"compiler/source:Span", ptr %l1
  %t190 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t186, %"compiler/source:Span" %t187)
  store ptr %t190, ptr %l105
  br label %bb46
bb45:
  br label %bb47
bb46:
  call void @__olang_scope_close(ptr %s0)
  %t191 = load ptr, ptr %l105, !tbaa !29
  store ptr %t191, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  %t192 = load i64, ptr %l2, !tbaa !24
  %t194 = icmp slt i64 %t192, 0
  br i1 %t194, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l108, !tbaa !21
  br label %bb52
bb50:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/check:Checker", ptr %t196, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !29
  %t200 = load i64, ptr %l2, !tbaa !24
  %t203 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %t199, i64 %t200)
  store i1 %t203, ptr %l112
  br label %bb51
bb51:
  %t204 = load i1, ptr %l112, !tbaa !21
  store i1 %t204, ptr %l108, !tbaa !21
  br label %bb52
bb52:
  %t205 = load i1, ptr %l108, !tbaa !21
  br i1 %t205, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s6
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t207 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s6, ptr %t206, %"compiler/source:Span" %t207, { i64, ptr } { i64 35, ptr @.d33 })
  br label %bb55
bb54:
  br label %bb57
bb55:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t211 = load %"compiler/source:Span", ptr %l1
  %t214 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t210, %"compiler/source:Span" %t211)
  store ptr %t214, ptr %l117
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t215 = load ptr, ptr %l117, !tbaa !29
  store ptr %t215, ptr %rv
  br label %ret
bb57:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/check:Checker", ptr %t216, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !29
  %t220 = load i64, ptr %l2, !tbaa !24
  %t223 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t219, i64 %t220)
  store i32 %t223, ptr %l121
  br label %bb58
bb58:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t226 = getelementptr %"compiler/check:Checker", ptr %t224, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !29
  %t229 = getelementptr %"compiler/generic:Program", ptr %t227, i32 0, i32 30
  %t230 = load %"compiler/generic:Origin", ptr %t229
  store %"compiler/generic:Origin" %t230, ptr %l8
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr %"compiler/check:Checker", ptr %t232, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !29
  store ptr %t235, ptr %l126, !tbaa !29
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t238 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t236)
  store ptr %t238, ptr %l128
  br label %bb59
bb59:
  %t239 = load ptr, ptr %l128, !tbaa !29
  %t241 = getelementptr %"compiler/check:frame", ptr %t239, i32 0, i32 2
  %t242 = load i64, ptr %t241, !tbaa !24
  store i64 %t242, ptr %l130, !tbaa !24
  %t243 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t243, ptr %l131
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecurInst(ptr %v0, ptr %t244)
  store i64 %t246, ptr %l133
  br label %bb60
bb60:
  %t247 = load i64, ptr %l130, !tbaa !24
  %t248 = load %"compiler/source:Span", ptr %l131
  %t249 = load i64, ptr %l133, !tbaa !24
  %t250 = call %"compiler/generic:Origin" @compiler_2fgeneric_3aOrigin_2ector(ptr %s0, i64 %t247, %"compiler/source:Span" %t248, i64 %t249)
  store %"compiler/generic:Origin" %t250, ptr %l134
  br label %bb61
bb61:
  %t251 = load %"compiler/generic:Origin", ptr %l134
  %t252 = load ptr, ptr %l126, !tbaa !29
  %t253 = getelementptr %"compiler/generic:Program", ptr %t252, i32 0, i32 30
  store %"compiler/generic:Origin" %t251, ptr %t253
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = getelementptr %"compiler/check:Checker", ptr %t254, i32 0, i32 1
  %t257 = load ptr, ptr %t256, !tbaa !29
  %t258 = load i64, ptr %l2, !tbaa !24
  %t259 = load i32, ptr %l4, !tbaa !23
  %t263 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %t257, i64 %t258, i32 %t259)
  store i64 %t263, ptr %l139
  br label %bb62
bb62:
  %t264 = load i64, ptr %l139, !tbaa !24
  store i64 %t264, ptr %l9, !tbaa !24
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t267 = getelementptr %"compiler/check:Checker", ptr %t265, i32 0, i32 1
  %t268 = load ptr, ptr %t267, !tbaa !29
  %t269 = load %"compiler/generic:Origin", ptr %l8
  %t272 = getelementptr %"compiler/generic:Program", ptr %t268, i32 0, i32 30
  store %"compiler/generic:Origin" %t269, ptr %t272
  %t273 = load i32, ptr %l4, !tbaa !23
  %t275 = icmp ne i32 %t273, 0
  br i1 %t275, label %bb63, label %bb64
bb63:
  %t277 = load ptr, ptr %l0, !tbaa !29
  store ptr %t277, ptr %l146, !tbaa !29
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr %"compiler/check:Checker", ptr %t278, i32 0, i32 1
  %t281 = load ptr, ptr %t280, !tbaa !29
  %t282 = load i64, ptr %l9, !tbaa !24
  %t285 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %t281, i64 %t282)
  store i32 %t285, ptr %l150
  br label %bb65
bb64:
  store i1 false, ptr %l145, !tbaa !21
  br label %bb67
bb65:
  %t286 = load %"compiler/source:Span", ptr %l1
  %t287 = load ptr, ptr %l146, !tbaa !29
  %t288 = load i32, ptr %l150, !tbaa !23
  %t290 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesMet(ptr %v0, ptr %t287, i32 %t288, %"compiler/source:Span" %t286)
  store i1 %t290, ptr %l152
  br label %bb66
bb66:
  %t291 = load i1, ptr %l152, !tbaa !21
  %t292 = xor i1 %t291, true
  store i1 %t292, ptr %l145, !tbaa !21
  br label %bb67
bb67:
  %t294 = load i1, ptr %l145, !tbaa !21
  br i1 %t294, label %bb68, label %bb69
bb68:
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t296 = load %"compiler/source:Span", ptr %l1
  %t299 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t295, %"compiler/source:Span" %t296)
  store ptr %t299, ptr %l156
  br label %bb70
bb69:
  br label %bb71
bb70:
  call void @__olang_scope_close(ptr %s0)
  %t300 = load ptr, ptr %l156, !tbaa !29
  store ptr %t300, ptr %rv
  br label %ret
bb71:
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t302 = load i64, ptr %l9, !tbaa !24
  %t305 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnBody(ptr %v0, ptr %t301, i64 %t302)
  store i64 %t305, ptr %l159
  br label %bb72
bb72:
  %t306 = load i64, ptr %l159, !tbaa !24
  store i64 %t306, ptr %l10, !tbaa !24
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"compiler/check:Checker", ptr %t307, i32 0, i32 1
  %t310 = load ptr, ptr %t309, !tbaa !29
  %t311 = load i64, ptr %l9, !tbaa !24
  %t314 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %t310, i64 %t311)
  store i32 %t314, ptr %l163
  br label %bb73
bb73:
  %t315 = load i32, ptr %l163, !tbaa !23
  store i32 %t315, ptr %l11, !tbaa !23
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t317 = load i32, ptr %l11, !tbaa !23
  %t320 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %t316, i32 %t317)
  store i1 %t320, ptr %l166
  br label %bb74
bb74:
  %t321 = load i1, ptr %l166, !tbaa !21
  br i1 %t321, label %bb75, label %bb76
bb75:
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t324 = getelementptr %"compiler/check:Checker", ptr %t322, i32 0, i32 1
  %t325 = load ptr, ptr %t324, !tbaa !29
  %t327 = getelementptr %"compiler/generic:Program", ptr %t325, i32 0, i32 2
  store ptr %t327, ptr %l169, !tbaa !29
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t330 = getelementptr %"compiler/check:Checker", ptr %t328, i32 0, i32 1
  %t331 = load ptr, ptr %t330, !tbaa !29
  %t333 = getelementptr %"compiler/generic:Program", ptr %t331, i32 0, i32 2
  %t334 = load i32, ptr %l11, !tbaa !23
  %t337 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t333, i32 %t334)
  store i32 %t337, ptr %l174
  br label %bb77
bb76:
  br label %bb82
bb77:
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t340 = getelementptr %"compiler/check:Checker", ptr %t338, i32 0, i32 1
  %t341 = load ptr, ptr %t340, !tbaa !29
  %t343 = getelementptr %"compiler/generic:Program", ptr %t341, i32 0, i32 2
  %t344 = load i32, ptr %l11, !tbaa !23
  %t347 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t343, i32 %t344)
  store i32 %t347, ptr %l179
  br label %bb78
bb78:
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t349 = load i64, ptr %l10, !tbaa !24
  %t352 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyErrors(ptr %v0, ptr %t348, i64 %t349)
  store i32 %t352, ptr %l182
  br label %bb79
bb79:
  %t353 = load ptr, ptr %l0, !tbaa !29
  %t355 = getelementptr %"compiler/check:Checker", ptr %t353, i32 0, i32 1
  %t356 = load ptr, ptr %t355, !tbaa !29
  %t358 = getelementptr %"compiler/generic:Program", ptr %t356, i32 0, i32 2
  %t359 = load i32, ptr %l11, !tbaa !23
  %t362 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t358, i32 %t359)
  store i32 %t362, ptr %l187
  br label %bb80
bb80:
  %t363 = load ptr, ptr %l169, !tbaa !29
  %t364 = load i32, ptr %l174, !tbaa !23
  %t365 = load i32, ptr %l179, !tbaa !23
  %t366 = load i32, ptr %l182, !tbaa !23
  %t367 = load i32, ptr %l187, !tbaa !23
  %t368 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t363, i32 %t364, i32 %t365, i32 %t366, i32 %t367, i64 0)
  store i32 %t368, ptr %l188
  br label %bb81
bb81:
  %t369 = load i32, ptr %l188, !tbaa !23
  store i32 %t369, ptr %l11, !tbaa !23
  br label %bb82
bb82:
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t372 = getelementptr %"compiler/check:Checker", ptr %t370, i32 0, i32 59
  store ptr %t372, ptr %l190, !tbaa !29
  %t373 = load i64, ptr %l10, !tbaa !24
  store i64 %t373, ptr %l191, !tbaa !24
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t375 = load %"compiler/source:Span", ptr %l1
  %t378 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t374, %"compiler/source:Span" %t375)
  store { i64, [3 x i64] } %t378, ptr %l194
  br label %bb83
bb83:
  %t379 = load ptr, ptr %l0, !tbaa !29
  store ptr %t379, ptr %l195, !tbaa !29
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t382 = getelementptr %"compiler/check:Checker", ptr %t380, i32 0, i32 1
  %t383 = load ptr, ptr %t382, !tbaa !29
  %t384 = load i64, ptr %l2, !tbaa !24
  %t387 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t383, i64 %t384)
  store ptr %t387, ptr %l199
  br label %bb84
bb84:
  %t388 = load ptr, ptr %l199, !tbaa !29
  %t390 = getelementptr %"compiler/ast:Func", ptr %t388, i32 0, i32 2
  %t391 = load i32, ptr %t390, !tbaa !23
  %t392 = load ptr, ptr %l195, !tbaa !29
  %t394 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t392, i32 %t391)
  store { i64, ptr } %t394, ptr %l202
  br label %bb85
bb85:
  %t395 = extractvalue { i64, ptr } { i64 1, ptr @.d34 }, 1
  %t396 = extractvalue { i64, ptr } { i64 1, ptr @.d34 }, 0
  %t397 = load { i64, ptr }, ptr %l202, !tbaa !27
  %t398 = extractvalue { i64, ptr } %t397, 1
  %t399 = extractvalue { i64, ptr } %t397, 0
  %t400 = add i64 %t396, %t399
  %t401 = extractvalue { i64, ptr } { i64 1, ptr @.d35 }, 1
  %t402 = extractvalue { i64, ptr } { i64 1, ptr @.d35 }, 0
  %t403 = add i64 %t400, %t402
  %t404 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t403)
  call void @olang_textcopy(ptr %t404, ptr %t395, i64 %t396)
  %t405 = getelementptr i8, ptr %t404, i64 %t396
  call void @olang_textcopy(ptr %t405, ptr %t398, i64 %t399)
  %t406 = getelementptr i8, ptr %t405, i64 %t399
  call void @olang_textcopy(ptr %t406, ptr %t401, i64 %t402)
  %t407 = insertvalue { i64, ptr } undef, i64 %t403, 0
  %t408 = insertvalue { i64, ptr } %t407, ptr %t404, 1
  %t410 = extractvalue { i64, ptr } %t408, 0
  %t411 = extractvalue { i64, ptr } %t408, 1
  %t412 = mul i64 %t410, 1
  %t413 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t412)
  call void @llvm.memcpy.p0.p0.i64(ptr %t413, ptr %t411, i64 %t412, i1 false)
  %t414 = insertvalue { i64, ptr } undef, i64 %t410, 0
  %t415 = insertvalue { i64, ptr } %t414, ptr %t413, 1
  %t416 = load i64, ptr %l191, !tbaa !24
  %t417 = load { i64, [3 x i64] }, ptr %l194
  %t419 = call %"compiler/check:roFn" @compiler_2fcheck_3aroFn_2ector(ptr %v0, ptr %v0, i64 %t416, i64 0, { i64, [3 x i64] } %t417, { i64, ptr } %t415)
  store %"compiler/check:roFn" %t419, ptr %l205
  br label %bb86
bb86:
  %t420 = load ptr, ptr %l190, !tbaa !29
  %t421 = load %"compiler/check:roFn", ptr %l205
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroFn_3e_2ePush_3ccompiler_2fcheck_3aroFn_3e(ptr %v0, ptr %v0, ptr %t420, %"compiler/check:roFn" %t421)
  br label %bb87
bb87:
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t424 = getelementptr %"compiler/check:Checker", ptr %t422, i32 0, i32 1
  %t425 = load ptr, ptr %t424, !tbaa !29
  %t426 = load i64, ptr %l2, !tbaa !24
  %t429 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t425, i64 %t426)
  store ptr %t429, ptr %l209
  br label %bb88
bb88:
  %t430 = load ptr, ptr %l209, !tbaa !29
  store ptr %t430, ptr %l12, !tbaa !29
  %t431 = load ptr, ptr %l12, !tbaa !29
  %t433 = getelementptr %"compiler/ast:Func", ptr %t431, i32 0, i32 1
  %t434 = load ptr, ptr %t433, !tbaa !29
  %t436 = icmp eq ptr %t434, null
  br i1 %t436, label %bb89, label %bb90
bb89:
  %t438 = load ptr, ptr %l12, !tbaa !29
  %t440 = getelementptr %"compiler/ast:Func", ptr %t438, i32 0, i32 3
  %t441 = load ptr, ptr %t440, !tbaa !29
  %t443 = getelementptr %"compiler/ast:Sig", ptr %t441, i32 0, i32 0
  %t444 = load { i64, ptr }, ptr %t443, !tbaa !27
  %t446 = extractvalue { i64, ptr } %t444, 0
  store i64 %t446, ptr %l217, !tbaa !24
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t449 = getelementptr %"compiler/check:Checker", ptr %t447, i32 0, i32 1
  %t450 = load ptr, ptr %t449, !tbaa !29
  %t452 = getelementptr %"compiler/generic:Program", ptr %t450, i32 0, i32 2
  store ptr %t452, ptr %l220, !tbaa !29
  %t453 = load ptr, ptr %l0, !tbaa !29
  %t455 = getelementptr %"compiler/check:Checker", ptr %t453, i32 0, i32 1
  %t456 = load ptr, ptr %t455, !tbaa !29
  %t458 = getelementptr %"compiler/generic:Program", ptr %t456, i32 0, i32 2
  %t459 = load i32, ptr %l11, !tbaa !23
  %t462 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t458, i32 %t459)
  store i32 %t462, ptr %l225
  br label %bb91
bb90:
  store i1 false, ptr %l213, !tbaa !21
  br label %bb93
bb91:
  %t463 = load ptr, ptr %l220, !tbaa !29
  %t464 = load i32, ptr %l225, !tbaa !23
  %t465 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t463, i32 %t464)
  store { i64, ptr } %t465, ptr %l226
  br label %bb92
bb92:
  %t466 = load { i64, ptr }, ptr %l226, !tbaa !27
  %t467 = extractvalue { i64, ptr } %t466, 0
  %t468 = load i64, ptr %l217, !tbaa !24
  %t470 = icmp eq i64 %t468, %t467
  store i1 %t470, ptr %l213, !tbaa !21
  br label %bb93
bb93:
  %t472 = load i1, ptr %l213, !tbaa !21
  br i1 %t472, label %bb94, label %bb95
bb94:
  %t473 = load ptr, ptr %l0, !tbaa !29
  %t475 = getelementptr %"compiler/check:Checker", ptr %t473, i32 0, i32 1
  %t476 = load ptr, ptr %t475, !tbaa !29
  %t478 = getelementptr %"compiler/generic:Program", ptr %t476, i32 0, i32 2
  store ptr %t478, ptr %l231, !tbaa !29
  %t479 = load i32, ptr %l11, !tbaa !23
  store i32 %t479, ptr %l232, !tbaa !23
  %t480 = load ptr, ptr %l0, !tbaa !29
  %t482 = getelementptr %"compiler/check:Checker", ptr %t480, i32 0, i32 1
  %t483 = load ptr, ptr %t482, !tbaa !29
  %t484 = load ptr, ptr %l12, !tbaa !29
  %t486 = getelementptr %"compiler/ast:Func", ptr %t484, i32 0, i32 3
  %t487 = load ptr, ptr %t486, !tbaa !29
  %t490 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSigNames(ptr %v0, ptr %v0, ptr %t483, ptr %t487)
  store i64 %t490, ptr %l237
  br label %bb96
bb95:
  br label %bb98
bb96:
  %t491 = load ptr, ptr %l231, !tbaa !29
  %t492 = load i32, ptr %l232, !tbaa !23
  %t493 = load i64, ptr %l237, !tbaa !24
  %t494 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithNames(ptr %v0, ptr %t491, i32 %t492, i64 %t493)
  store i32 %t494, ptr %l238
  br label %bb97
bb97:
  %t495 = load i32, ptr %l238, !tbaa !23
  store i32 %t495, ptr %l11, !tbaa !23
  br label %bb98
bb98:
  %t496 = load %"compiler/source:Span", ptr %l1
  %t497 = load i32, ptr %l11, !tbaa !23
  %t498 = load i64, ptr %l10, !tbaa !24
  %t500 = trunc i64 %t498 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t502
  %t503 = getelementptr { i64, [4 x i64] }, ptr %t502, i32 0, i32 0
  store i64 0, ptr %t503
  %t505 = insertvalue { i32 } undef, i32 %t500, 0
  %t506 = getelementptr { i64, [4 x i64] }, ptr %t502, i32 0, i32 1
  store { i32 } %t505, ptr %t506
  %t507 = load { i64, [4 x i64] }, ptr %t502
  %t509 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t507, ptr %t509
  store { i64, [5 x i64] } zeroinitializer, ptr %t510
  %t511 = getelementptr { i64, [5 x i64] }, ptr %t510, i32 0, i32 0
  store i64 15, ptr %t511
  %t513 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t496, 0
  %t515 = insertvalue { %"compiler/source:Span", i32, ptr } %t513, i32 %t497, 1
  %t517 = insertvalue { %"compiler/source:Span", i32, ptr } %t515, ptr %t509, 2
  %t518 = getelementptr { i64, [5 x i64] }, ptr %t510, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t517, ptr %t518
  %t519 = load { i64, [5 x i64] }, ptr %t510
  %t521 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t519, ptr %t521
  call void @__olang_scope_close(ptr %s0)
  store ptr %t521, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l6 = alloca %"compiler/check:litv"
  %l11 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca %"compiler/check:litv"
  %l15 = alloca { i1, i64 }
  %l16 = alloca i1
  %l17 = alloca i64
  %l18 = alloca %"compiler/check:litv"
  %l19 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca %"compiler/check:litv"
  %l23 = alloca %"compiler/check:litv"
  %l24 = alloca double
  %l25 = alloca double
  %l26 = alloca { i1, i64 }
  %l27 = alloca i1
  %l28 = alloca i64
  %l29 = alloca { i1, i64 }
  %l30 = alloca i1
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca %"compiler/check:litv"
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l40 = alloca %"compiler/check:litv"
  %l41 = alloca ptr
  %l42 = alloca i1
  %l51 = alloca { i64, ptr }
  %l57 = alloca i1
  %l58 = alloca { i64, ptr }
  %l61 = alloca i1
  %l62 = alloca { i64, ptr }
  %l65 = alloca i1
  %l66 = alloca { i64, ptr }
  %l69 = alloca i1
  %l70 = alloca { i64, ptr }
  %l73 = alloca i1
  %l74 = alloca { i64, ptr }
  %l77 = alloca i64
  %l78 = alloca { i64, ptr }
  %l79 = alloca i64
  %l80 = alloca i32
  %l81 = alloca i64
  %l82 = alloca i32
  %l83 = alloca %"compiler/check:litv"
  %l86 = alloca %"compiler/check:litv"
  %l88 = alloca i64
  %l89 = alloca { i64, ptr }
  %l90 = alloca i64
  %l91 = alloca i32
  %l92 = alloca i64
  %l93 = alloca i32
  %l94 = alloca i64
  %l95 = alloca { i64, ptr }
  %l96 = alloca i64
  %l97 = alloca i32
  %l98 = alloca i64
  %l99 = alloca i32
  %l100 = alloca %"compiler/check:litv"
  %l103 = alloca %"compiler/check:litv"
  %l105 = alloca %"compiler/check:litv"
  %l110 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l114 = alloca double
  %l116 = alloca double
  %l117 = alloca i32
  %l118 = alloca %"compiler/check:litv"
  %l120 = alloca %"compiler/check:litv"
  %l121 = alloca %"compiler/check:litv"
  %l122 = alloca ptr
  %l123 = alloca i1
  %l131 = alloca %"compiler/check:litv"
  %l132 = alloca ptr
  %l133 = alloca i1
  %l143 = alloca %"compiler/check:litv"
  %l146 = alloca %"compiler/check:litv"
  %l152 = alloca %"compiler/check:litv"
  %l154 = alloca { i1, i64 }
  %l159 = alloca %"compiler/check:litv"
  %l163 = alloca %"compiler/check:litv"
  %l164 = alloca %"compiler/check:litv"
  %l167 = alloca i1
  %l170 = alloca i1
  %l175 = alloca %"compiler/check:litv"
  %l178 = alloca %"compiler/check:litv"
  %l179 = alloca ptr
  %l180 = alloca i1
  %l191 = alloca %"compiler/check:litv"
  %l194 = alloca %"compiler/check:litv"
  %l197 = alloca i1
  %l200 = alloca %"compiler/check:litv"
  %l202 = alloca i1
  %l205 = alloca i1
  %l207 = alloca %"compiler/check:litv"
  %l209 = alloca double
  %l214 = alloca double
  %l223 = alloca %"compiler/check:litv"
  %l229 = alloca %"compiler/check:litv"
  %l235 = alloca %"compiler/check:litv"
  %l241 = alloca %"compiler/check:litv"
  %l242 = alloca %"compiler/check:litv"
  %l244 = alloca { i1, i64 }
  %l248 = alloca { i1, i64 }
  %l257 = alloca %"compiler/check:litv"
  %l265 = alloca %"compiler/check:litv"
  %l270 = alloca i1
  %l275 = alloca %"compiler/check:litv"
  %l282 = alloca i1
  %l286 = alloca %"compiler/check:litv"
  %l289 = alloca i1
  %l292 = alloca i1
  %l297 = alloca i64
  %l303 = alloca i64
  %l311 = alloca %"compiler/check:litv"
  %l313 = alloca i1
  %l315 = alloca i1
  %l319 = alloca %"compiler/check:litv"
  %l321 = alloca i1
  %l325 = alloca i1
  %l327 = alloca %"compiler/check:litv"
  %l332 = alloca i1
  %l335 = alloca i1
  %l339 = alloca i1
  %l346 = alloca %"compiler/check:litv"
  %l349 = alloca i1
  %l352 = alloca i1
  %l358 = alloca %"compiler/check:litv"
  %l361 = alloca i1
  %l364 = alloca i1
  %l367 = alloca i1
  %l372 = alloca i64
  %l376 = alloca i64
  %l380 = alloca %"compiler/check:litv"
  %l382 = alloca %"compiler/check:litv"
  %l385 = alloca i1
  %l388 = alloca i1
  %l392 = alloca i64
  %l394 = alloca %"compiler/check:litv"
  %l395 = alloca %"compiler/check:litv"
  %l396 = alloca %"compiler/check:litv"
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %rv = alloca %"compiler/check:litv"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t5, ptr %l40
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t6 = load %"compiler/check:litv", ptr %l40
  store %"compiler/check:litv" %t6, ptr %rv
  br label %ret
bb4:
  %t7 = load ptr, ptr %l1, !tbaa !29
  store ptr %t7, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t8 = load ptr, ptr %l41, !tbaa !29
  %t9 = icmp ne ptr %t8, null
  br i1 %t9, label %bb5, label %bb6
bb5:
  %t11 = load ptr, ptr %l41, !tbaa !29
  %t12 = load i64, ptr %t11
  %t14 = icmp eq i64 %t12, 1
  store i1 %t14, ptr %l42, !tbaa !21
  br label %bb6
bb6:
  %t15 = load i1, ptr %l42, !tbaa !21
  br i1 %t15, label %bb7, label %bb8
bb7:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 0
  %t20 = load %"compiler/source:Span", ptr %t19
  store %"compiler/source:Span" %t20, ptr %l2
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32 }, ptr %t24, i32 0, i32 1
  %t26 = load i32, ptr %t25
  store i32 %t26, ptr %l3
  br label %bb9
bb8:
  br label %bb66
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load %"compiler/source:Span", ptr %l2
  %t32 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t28, %"compiler/source:Span" %t29)
  store { i64, ptr } %t32, ptr %l51
  br label %bb10
bb10:
  %t33 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t33, ptr %l4, !tbaa !27
  %t34 = load i32, ptr %l3
  %t36 = trunc i64 2 to i32
  %t37 = icmp eq i32 %t34, %t36
  br i1 %t37, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t39 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t43 = icmp sgt i64 %t41, 2
  br i1 %t43, label %bb13, label %bb14
bb12:
  br label %bb54
bb13:
  %t45 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t45, ptr %l58, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr i8, ptr %t47, i64 0
  %t49 = load i8, ptr %t48, !tbaa !32
  %t51 = icmp eq i8 %t49, 48
  store i1 %t51, ptr %l57, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb15
bb15:
  %t53 = load i1, ptr %l57, !tbaa !21
  br i1 %t53, label %bb16, label %bb17
bb16:
  %t54 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t54, ptr %l62, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr i8, ptr %t56, i64 1
  %t58 = load i8, ptr %t57, !tbaa !32
  %t60 = icmp eq i8 %t58, 120
  br i1 %t60, label %bb18, label %bb19
bb17:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb27
bb18:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb20
bb19:
  %t62 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t62, ptr %l66, !tbaa !27
  %t63 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i8, ptr %t64, i64 1
  %t66 = load i8, ptr %t65, !tbaa !32
  %t68 = icmp eq i8 %t66, 88
  store i1 %t68, ptr %l65, !tbaa !21
  br label %bb20
bb20:
  %t70 = load i1, ptr %l65, !tbaa !21
  br i1 %t70, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l69, !tbaa !21
  br label %bb23
bb22:
  %t71 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t71, ptr %l70, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr i8, ptr %t73, i64 1
  %t75 = load i8, ptr %t74, !tbaa !32
  %t77 = icmp eq i8 %t75, 98
  store i1 %t77, ptr %l69, !tbaa !21
  br label %bb23
bb23:
  %t79 = load i1, ptr %l69, !tbaa !21
  br i1 %t79, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb26
bb25:
  %t80 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t80, ptr %l74, !tbaa !27
  %t81 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr i8, ptr %t82, i64 1
  %t84 = load i8, ptr %t83, !tbaa !32
  %t86 = icmp eq i8 %t84, 66
  store i1 %t86, ptr %l73, !tbaa !21
  br label %bb26
bb26:
  %t88 = load i1, ptr %l73, !tbaa !21
  store i1 %t88, ptr %l61, !tbaa !21
  br label %bb27
bb27:
  %t89 = load i1, ptr %l61, !tbaa !21
  br i1 %t89, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s4
  %t90 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t90, ptr %l78, !tbaa !27
  %t91 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s4, i64 0)
  %t92 = extractvalue { i32, i64 } %t91, 1
  %t93 = extractvalue { i32, i64 } %t91, 0
  store i32 %t93, ptr %l80
  %t94 = icmp ne i32 %t93, 0
  br i1 %t94, label %bb31, label %ok.95
ok.95:
  store i64 %t92, ptr %l79
  br label %bb30
bb29:
  br label %bb38
bb30:
  %t96 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t97 = load i64, ptr %l79, !tbaa !24
  %t98 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseUint(ptr %v0, { i64, ptr } %t96, i64 %t97)
  %t99 = extractvalue { i32, i64 } %t98, 1
  %t100 = extractvalue { i32, i64 } %t98, 0
  store i32 %t100, ptr %l82
  %t101 = icmp ne i32 %t100, 0
  br i1 %t101, label %bb34, label %ok.102
ok.102:
  store i64 %t99, ptr %l81
  br label %bb33
bb31:
  br label %bb32
bb32:
  %t103 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t103, ptr %l83
  br label %bb35
bb33:
  %t104 = load i64, ptr %l81, !tbaa !65
  store i64 %t104, ptr %l77, !tbaa !65
  br label %bb36
bb34:
  br label %bb32
bb35:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  %t105 = load %"compiler/check:litv", ptr %l83
  store %"compiler/check:litv" %t105, ptr %rv
  br label %ret
bb36:
  %t106 = load i64, ptr %l77, !tbaa !65
  %t110 = call %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %t106)
  store %"compiler/check:litv" %t110, ptr %l86
  br label %bb37
bb37:
  %t111 = load %"compiler/check:litv", ptr %l86
  store %"compiler/check:litv" %t111, ptr %l6
  %t112 = getelementptr %"compiler/check:litv", ptr %l6, i32 0, i32 5
  store i1 true, ptr %t112, !tbaa !21
  %t113 = load %"compiler/check:litv", ptr %l6
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  store %"compiler/check:litv" %t113, ptr %rv
  br label %ret
bb38:
  %t115 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t115, ptr %l89, !tbaa !27
  %t116 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s3, i64 0)
  %t117 = extractvalue { i32, i64 } %t116, 1
  %t118 = extractvalue { i32, i64 } %t116, 0
  store i32 %t118, ptr %l91
  %t119 = icmp ne i32 %t118, 0
  br i1 %t119, label %bb40, label %ok.120
ok.120:
  store i64 %t117, ptr %l90
  br label %bb39
bb39:
  %t121 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t122 = load i64, ptr %l90, !tbaa !24
  %t123 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %t121, i64 %t122)
  %t124 = extractvalue { i32, i64 } %t123, 1
  %t125 = extractvalue { i32, i64 } %t123, 0
  store i32 %t125, ptr %l93
  %t126 = icmp ne i32 %t125, 0
  br i1 %t126, label %bb43, label %ok.127
ok.127:
  store i64 %t124, ptr %l92
  br label %bb42
bb40:
  br label %bb41
bb41:
  store %olang.scope zeroinitializer, ptr %s6
  %t128 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t128, ptr %l95, !tbaa !27
  %t129 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s6, i64 0)
  %t130 = extractvalue { i32, i64 } %t129, 1
  %t131 = extractvalue { i32, i64 } %t129, 0
  store i32 %t131, ptr %l97
  %t132 = icmp ne i32 %t131, 0
  br i1 %t132, label %bb45, label %ok.133
ok.133:
  store i64 %t130, ptr %l96
  br label %bb44
bb42:
  %t134 = load i64, ptr %l92, !tbaa !24
  store i64 %t134, ptr %l88, !tbaa !24
  br label %bb52
bb43:
  br label %bb41
bb44:
  %t135 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t136 = load i64, ptr %l96, !tbaa !24
  %t137 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseUint(ptr %v0, { i64, ptr } %t135, i64 %t136)
  %t138 = extractvalue { i32, i64 } %t137, 1
  %t139 = extractvalue { i32, i64 } %t137, 0
  store i32 %t139, ptr %l99
  %t140 = icmp ne i32 %t139, 0
  br i1 %t140, label %bb48, label %ok.141
ok.141:
  store i64 %t138, ptr %l98
  br label %bb47
bb45:
  br label %bb46
bb46:
  %t142 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t142, ptr %l100
  br label %bb49
bb47:
  %t143 = load i64, ptr %l98, !tbaa !65
  store i64 %t143, ptr %l94, !tbaa !65
  br label %bb50
bb48:
  br label %bb46
bb49:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s3)
  %t144 = load %"compiler/check:litv", ptr %l100
  store %"compiler/check:litv" %t144, ptr %rv
  br label %ret
bb50:
  %t145 = load i64, ptr %l94, !tbaa !65
  %t149 = call %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %s6, i1 true, i1 false, i1 true, i64 %t145, double 0x0000000000000000)
  store %"compiler/check:litv" %t149, ptr %l103
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s3)
  %t150 = load %"compiler/check:litv", ptr %l103
  store %"compiler/check:litv" %t150, ptr %rv
  br label %ret
bb52:
  %t151 = load i64, ptr %l88, !tbaa !24
  %t154 = call %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %t151)
  store %"compiler/check:litv" %t154, ptr %l105
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s3)
  %t155 = load %"compiler/check:litv", ptr %l105
  store %"compiler/check:litv" %t155, ptr %rv
  br label %ret
bb54:
  %t156 = load i32, ptr %l3
  %t158 = trunc i64 3 to i32
  %t159 = icmp eq i32 %t156, %t158
  br i1 %t159, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s8
  %t161 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } { i64 1, ptr @.d36 }, ptr %l110, !tbaa !27
  store { i64, ptr } { i64 0, ptr @.d37 }, ptr %l111, !tbaa !27
  %t164 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t165 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t166 = call { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s8, ptr %s8, ptr %s8, { i64, ptr } %t161, { i64, ptr } %t164, { i64, ptr } %t165)
  store { i64, ptr } %t166, ptr %l112
  br label %bb57
bb56:
  br label %bb64
bb57:
  %t167 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t171 = call { i32, double } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseFloat(ptr %s8, { i64, ptr } %t167)
  %t172 = extractvalue { i32, double } %t171, 1
  %t173 = extractvalue { i32, double } %t171, 0
  store i32 %t173, ptr %l117
  %t174 = icmp ne i32 %t173, 0
  br i1 %t174, label %bb59, label %ok.175
ok.175:
  store double %t172, ptr %l116
  br label %bb58
bb58:
  %t176 = load double, ptr %l116, !tbaa !26
  store double %t176, ptr %l114, !tbaa !26
  br label %bb62
bb59:
  br label %bb60
bb60:
  %t177 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t177, ptr %l118
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s8)
  %t178 = load %"compiler/check:litv", ptr %l118
  store %"compiler/check:litv" %t178, ptr %rv
  br label %ret
bb62:
  %t179 = load double, ptr %l114, !tbaa !26
  %t182 = call %"compiler/check:litv" @compiler_2fcheck_2efloatLit(double %t179)
  store %"compiler/check:litv" %t182, ptr %l120
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s8)
  %t183 = load %"compiler/check:litv", ptr %l120
  store %"compiler/check:litv" %t183, ptr %rv
  br label %ret
bb64:
  %t184 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t184, ptr %l121
  br label %bb65
bb65:
  %t185 = load %"compiler/check:litv", ptr %l121
  store %"compiler/check:litv" %t185, ptr %rv
  br label %ret
bb66:
  %t186 = load ptr, ptr %l1, !tbaa !29
  store ptr %t186, ptr %l122, !tbaa !29
  store i1 false, ptr %l123, !tbaa !21
  %t187 = load ptr, ptr %l122, !tbaa !29
  %t188 = icmp ne ptr %t187, null
  br i1 %t188, label %bb67, label %bb68
bb67:
  %t190 = load ptr, ptr %l122, !tbaa !29
  %t191 = load i64, ptr %t190
  %t193 = icmp eq i64 %t191, 2
  store i1 %t193, ptr %l123, !tbaa !21
  br label %bb68
bb68:
  %t194 = load i1, ptr %l123, !tbaa !21
  br i1 %t194, label %bb69, label %bb70
bb69:
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t197 = getelementptr { i64, [5 x i64] }, ptr %t195, i32 0, i32 1
  %t198 = getelementptr { %"compiler/source:Span", ptr }, ptr %t197, i32 0, i32 1
  %t199 = load ptr, ptr %t198
  store ptr %t199, ptr %l11, !tbaa !29
  br label %bb71
bb70:
  br label %bb73
bb71:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load ptr, ptr %l11, !tbaa !29
  %t206 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t201, ptr %t202)
  store %"compiler/check:litv" %t206, ptr %l131
  br label %bb72
bb72:
  %t207 = load %"compiler/check:litv", ptr %l131
  store %"compiler/check:litv" %t207, ptr %rv
  br label %ret
bb73:
  %t208 = load ptr, ptr %l1, !tbaa !29
  store ptr %t208, ptr %l132, !tbaa !29
  store i1 false, ptr %l133, !tbaa !21
  %t209 = load ptr, ptr %l132, !tbaa !29
  %t210 = icmp ne ptr %t209, null
  br i1 %t210, label %bb74, label %bb75
bb74:
  %t212 = load ptr, ptr %l132, !tbaa !29
  %t213 = load i64, ptr %t212
  %t215 = icmp eq i64 %t213, 3
  store i1 %t215, ptr %l133, !tbaa !21
  br label %bb75
bb75:
  %t216 = load i1, ptr %l133, !tbaa !21
  br i1 %t216, label %bb76, label %bb77
bb76:
  %t217 = load ptr, ptr %l1, !tbaa !29
  %t219 = getelementptr { i64, [5 x i64] }, ptr %t217, i32 0, i32 1
  %t220 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t219, i32 0, i32 1
  %t221 = load i32, ptr %t220
  store i32 %t221, ptr %l12
  %t223 = load ptr, ptr %l1, !tbaa !29
  %t225 = getelementptr { i64, [5 x i64] }, ptr %t223, i32 0, i32 1
  %t226 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t225, i32 0, i32 2
  %t227 = load ptr, ptr %t226
  store ptr %t227, ptr %l13, !tbaa !29
  br label %bb78
bb77:
  br label %bb108
bb78:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t230 = load ptr, ptr %l13, !tbaa !29
  %t234 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t229, ptr %t230)
  store %"compiler/check:litv" %t234, ptr %l143
  br label %bb79
bb79:
  %t235 = load %"compiler/check:litv", ptr %l143
  store %"compiler/check:litv" %t235, ptr %l14
  %t236 = getelementptr %"compiler/check:litv", ptr %l14, i32 0, i32 0
  %t237 = load i1, ptr %t236, !tbaa !21
  %t239 = xor i1 %t237, true
  br i1 %t239, label %bb80, label %bb81
bb80:
  %t241 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t241, ptr %l146
  br label %bb82
bb81:
  br label %bb83
bb82:
  %t242 = load %"compiler/check:litv", ptr %l146
  store %"compiler/check:litv" %t242, ptr %rv
  br label %ret
bb83:
  %t243 = load i32, ptr %l12
  %t245 = trunc i64 50 to i32
  %t246 = icmp eq i32 %t243, %t245
  br i1 %t246, label %bb84, label %bb85
bb84:
  %t248 = getelementptr %"compiler/check:litv", ptr %l14, i32 0, i32 1
  %t249 = load i1, ptr %t248, !tbaa !21
  br i1 %t249, label %bb86, label %bb87
bb85:
  br label %bb96
bb86:
  %t251 = getelementptr %"compiler/check:litv", ptr %l14, i32 0, i32 4
  %t252 = load double, ptr %t251, !tbaa !26
  %t254 = fneg double %t252
  %t256 = call %"compiler/check:litv" @compiler_2fcheck_2efloatLit(double %t254)
  store %"compiler/check:litv" %t256, ptr %l152
  br label %bb88
bb87:
  br label %bb89
bb88:
  %t257 = load %"compiler/check:litv", ptr %l152
  store %"compiler/check:litv" %t257, ptr %rv
  br label %ret
bb89:
  %t258 = load %"compiler/check:litv", ptr %l14
  %t260 = call { i1, i64 } @compiler_2fcheck_2emagOf(%"compiler/check:litv" %t258)
  store { i1, i64 } %t260, ptr %l154
  br label %bb90
bb90:
  %t261 = load { i1, i64 }, ptr %l154
  store { i1, i64 } %t261, ptr %l15
  %t262 = getelementptr { i1, i64 }, ptr %l15, i32 0, i32 0
  %t263 = load i1, ptr %t262, !tbaa !21
  store i1 %t263, ptr %l16, !tbaa !21
  %t265 = getelementptr { i1, i64 }, ptr %l15, i32 0, i32 1
  %t266 = load i64, ptr %t265, !tbaa !65
  store i64 %t266, ptr %l17, !tbaa !65
  %t268 = load i64, ptr %l17, !tbaa !65
  %t270 = icmp ne i64 %t268, 0
  br i1 %t270, label %bb91, label %bb92
bb91:
  %t272 = load i1, ptr %l16, !tbaa !21
  %t274 = xor i1 %t272, true
  %t275 = load i64, ptr %l17, !tbaa !65
  %t278 = call %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 %t274, i64 %t275)
  store %"compiler/check:litv" %t278, ptr %l163
  br label %bb93
bb92:
  %t279 = call %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 0)
  store %"compiler/check:litv" %t279, ptr %l164
  br label %bb94
bb93:
  %t280 = load %"compiler/check:litv", ptr %l163
  store %"compiler/check:litv" %t280, ptr %l159
  br label %bb95
bb94:
  %t281 = load %"compiler/check:litv", ptr %l164
  store %"compiler/check:litv" %t281, ptr %l159
  br label %bb95
bb95:
  %t282 = load %"compiler/check:litv", ptr %l159
  store %"compiler/check:litv" %t282, ptr %rv
  br label %ret
bb96:
  %t283 = load i32, ptr %l12
  %t285 = trunc i64 84 to i32
  %t286 = icmp eq i32 %t283, %t285
  br i1 %t286, label %bb97, label %bb98
bb97:
  %t288 = getelementptr %"compiler/check:litv", ptr %l14, i32 0, i32 1
  %t289 = load i1, ptr %t288, !tbaa !21
  %t291 = xor i1 %t289, true
  store i1 %t291, ptr %l167, !tbaa !21
  br label %bb99
bb98:
  store i1 false, ptr %l167, !tbaa !21
  br label %bb99
bb99:
  %t293 = load i1, ptr %l167, !tbaa !21
  br i1 %t293, label %bb100, label %bb101
bb100:
  %t294 = getelementptr %"compiler/check:litv", ptr %l14, i32 0, i32 2
  %t295 = load i1, ptr %t294, !tbaa !21
  %t297 = xor i1 %t295, true
  store i1 %t297, ptr %l170, !tbaa !21
  br label %bb102
bb101:
  store i1 false, ptr %l170, !tbaa !21
  br label %bb102
bb102:
  %t299 = load i1, ptr %l170, !tbaa !21
  br i1 %t299, label %bb103, label %bb104
bb103:
  %t300 = getelementptr %"compiler/check:litv", ptr %l14, i32 0, i32 3
  %t301 = load i64, ptr %t300, !tbaa !24
  %t303 = xor i64 %t301, -1
  %t305 = call %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %t303)
  store %"compiler/check:litv" %t305, ptr %l175
  br label %bb105
bb104:
  br label %bb106
bb105:
  %t306 = load %"compiler/check:litv", ptr %l175
  store %"compiler/check:litv" %t306, ptr %l18
  %t307 = getelementptr %"compiler/check:litv", ptr %l14, i32 0, i32 5
  %t308 = load i1, ptr %t307, !tbaa !21
  %t310 = getelementptr %"compiler/check:litv", ptr %l18, i32 0, i32 5
  store i1 %t308, ptr %t310, !tbaa !21
  %t311 = load %"compiler/check:litv", ptr %l18
  store %"compiler/check:litv" %t311, ptr %rv
  br label %ret
bb106:
  %t313 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t313, ptr %l178
  br label %bb107
bb107:
  %t314 = load %"compiler/check:litv", ptr %l178
  store %"compiler/check:litv" %t314, ptr %rv
  br label %ret
bb108:
  %t315 = load ptr, ptr %l1, !tbaa !29
  store ptr %t315, ptr %l179, !tbaa !29
  store i1 false, ptr %l180, !tbaa !21
  %t316 = load ptr, ptr %l179, !tbaa !29
  %t317 = icmp ne ptr %t316, null
  br i1 %t317, label %bb109, label %bb110
bb109:
  %t319 = load ptr, ptr %l179, !tbaa !29
  %t320 = load i64, ptr %t319
  %t322 = icmp eq i64 %t320, 5
  store i1 %t322, ptr %l180, !tbaa !21
  br label %bb110
bb110:
  %t323 = load i1, ptr %l180, !tbaa !21
  br i1 %t323, label %bb111, label %bb112
bb111:
  %t324 = load ptr, ptr %l1, !tbaa !29
  %t326 = getelementptr { i64, [5 x i64] }, ptr %t324, i32 0, i32 1
  %t327 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t326, i32 0, i32 1
  %t328 = load i32, ptr %t327
  store i32 %t328, ptr %l19
  %t330 = load ptr, ptr %l1, !tbaa !29
  %t332 = getelementptr { i64, [5 x i64] }, ptr %t330, i32 0, i32 1
  %t333 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t332, i32 0, i32 2
  %t334 = load ptr, ptr %t333
  store ptr %t334, ptr %l20, !tbaa !29
  %t336 = load ptr, ptr %l1, !tbaa !29
  %t338 = getelementptr { i64, [5 x i64] }, ptr %t336, i32 0, i32 1
  %t339 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t338, i32 0, i32 3
  %t340 = load ptr, ptr %t339
  store ptr %t340, ptr %l21, !tbaa !29
  br label %bb113
bb112:
  br label %bb270
bb113:
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t343 = load ptr, ptr %l20, !tbaa !29
  %t346 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efoldPart(ptr %v0, ptr %v1, ptr %t342, ptr %t343)
  store %"compiler/check:litv" %t346, ptr %l191
  br label %bb114
bb114:
  %t347 = load %"compiler/check:litv", ptr %l191
  store %"compiler/check:litv" %t347, ptr %l22
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t349 = load ptr, ptr %l21, !tbaa !29
  %t352 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efoldPart(ptr %v0, ptr %v1, ptr %t348, ptr %t349)
  store %"compiler/check:litv" %t352, ptr %l194
  br label %bb115
bb115:
  %t353 = load %"compiler/check:litv", ptr %l194
  store %"compiler/check:litv" %t353, ptr %l23
  %t354 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 0
  %t355 = load i1, ptr %t354, !tbaa !21
  %t357 = xor i1 %t355, true
  br i1 %t357, label %bb116, label %bb117
bb116:
  store i1 true, ptr %l197, !tbaa !21
  br label %bb118
bb117:
  %t359 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 0
  %t360 = load i1, ptr %t359, !tbaa !21
  %t362 = xor i1 %t360, true
  store i1 %t362, ptr %l197, !tbaa !21
  br label %bb118
bb118:
  %t364 = load i1, ptr %l197, !tbaa !21
  br i1 %t364, label %bb119, label %bb120
bb119:
  %t365 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t365, ptr %l200
  br label %bb121
bb120:
  br label %bb122
bb121:
  %t366 = load %"compiler/check:litv", ptr %l200
  store %"compiler/check:litv" %t366, ptr %rv
  br label %ret
bb122:
  %t367 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 1
  %t368 = load i1, ptr %t367, !tbaa !21
  br i1 %t368, label %bb123, label %bb124
bb123:
  store i1 true, ptr %l202, !tbaa !21
  br label %bb125
bb124:
  %t370 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 1
  %t371 = load i1, ptr %t370, !tbaa !21
  store i1 %t371, ptr %l202, !tbaa !21
  br label %bb125
bb125:
  %t373 = load i1, ptr %l202, !tbaa !21
  br i1 %t373, label %bb126, label %bb127
bb126:
  %t374 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 2
  %t375 = load i1, ptr %t374, !tbaa !21
  br i1 %t375, label %bb128, label %bb129
bb127:
  br label %bb158
bb128:
  store i1 true, ptr %l205, !tbaa !21
  br label %bb130
bb129:
  %t377 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 2
  %t378 = load i1, ptr %t377, !tbaa !21
  store i1 %t378, ptr %l205, !tbaa !21
  br label %bb130
bb130:
  %t380 = load i1, ptr %l205, !tbaa !21
  br i1 %t380, label %bb131, label %bb132
bb131:
  %t381 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t381, ptr %l207
  br label %bb133
bb132:
  br label %bb134
bb133:
  %t382 = load %"compiler/check:litv", ptr %l207
  store %"compiler/check:litv" %t382, ptr %rv
  br label %ret
bb134:
  %t383 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 1
  %t384 = load i1, ptr %t383, !tbaa !21
  br i1 %t384, label %bb135, label %bb136
bb135:
  %t386 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 4
  %t387 = load double, ptr %t386, !tbaa !26
  store double %t387, ptr %l209, !tbaa !26
  br label %bb137
bb136:
  %t389 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 3
  %t390 = load i64, ptr %t389, !tbaa !24
  %t392 = sitofp i64 %t390 to double
  store double %t392, ptr %l209, !tbaa !26
  br label %bb137
bb137:
  %t394 = load double, ptr %l209, !tbaa !26
  store double %t394, ptr %l24, !tbaa !26
  %t395 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 1
  %t396 = load i1, ptr %t395, !tbaa !21
  br i1 %t396, label %bb138, label %bb139
bb138:
  %t398 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 4
  %t399 = load double, ptr %t398, !tbaa !26
  store double %t399, ptr %l214, !tbaa !26
  br label %bb140
bb139:
  %t401 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 3
  %t402 = load i64, ptr %t401, !tbaa !24
  %t404 = sitofp i64 %t402 to double
  store double %t404, ptr %l214, !tbaa !26
  br label %bb140
bb140:
  %t406 = load double, ptr %l214, !tbaa !26
  store double %t406, ptr %l25, !tbaa !26
  %t407 = load i32, ptr %l19
  %t409 = trunc i64 49 to i32
  %t410 = icmp eq i32 %t407, %t409
  br i1 %t410, label %bb141, label %bb142
bb141:
  %t412 = load double, ptr %l24, !tbaa !26
  %t413 = load double, ptr %l25, !tbaa !26
  %t416 = fadd double %t412, %t413
  %t418 = call %"compiler/check:litv" @compiler_2fcheck_2efloatLit(double %t416)
  store %"compiler/check:litv" %t418, ptr %l223
  br label %bb143
bb142:
  br label %bb144
bb143:
  %t419 = load %"compiler/check:litv", ptr %l223
  store %"compiler/check:litv" %t419, ptr %rv
  br label %ret
bb144:
  %t420 = load i32, ptr %l19
  %t422 = trunc i64 50 to i32
  %t423 = icmp eq i32 %t420, %t422
  br i1 %t423, label %bb145, label %bb146
bb145:
  %t425 = load double, ptr %l24, !tbaa !26
  %t426 = load double, ptr %l25, !tbaa !26
  %t429 = fsub double %t425, %t426
  %t431 = call %"compiler/check:litv" @compiler_2fcheck_2efloatLit(double %t429)
  store %"compiler/check:litv" %t431, ptr %l229
  br label %bb147
bb146:
  br label %bb148
bb147:
  %t432 = load %"compiler/check:litv", ptr %l229
  store %"compiler/check:litv" %t432, ptr %rv
  br label %ret
bb148:
  %t433 = load i32, ptr %l19
  %t435 = trunc i64 51 to i32
  %t436 = icmp eq i32 %t433, %t435
  br i1 %t436, label %bb149, label %bb150
bb149:
  %t438 = load double, ptr %l24, !tbaa !26
  %t439 = load double, ptr %l25, !tbaa !26
  %t442 = fmul double %t438, %t439
  %t444 = call %"compiler/check:litv" @compiler_2fcheck_2efloatLit(double %t442)
  store %"compiler/check:litv" %t444, ptr %l235
  br label %bb151
bb150:
  br label %bb152
bb151:
  %t445 = load %"compiler/check:litv", ptr %l235
  store %"compiler/check:litv" %t445, ptr %rv
  br label %ret
bb152:
  %t446 = load i32, ptr %l19
  %t448 = trunc i64 52 to i32
  %t449 = icmp eq i32 %t446, %t448
  br i1 %t449, label %bb153, label %bb154
bb153:
  %t451 = load double, ptr %l24, !tbaa !26
  %t452 = load double, ptr %l25, !tbaa !26
  %t455 = fdiv double %t451, %t452
  %t457 = call %"compiler/check:litv" @compiler_2fcheck_2efloatLit(double %t455)
  store %"compiler/check:litv" %t457, ptr %l241
  br label %bb155
bb154:
  br label %bb156
bb155:
  %t458 = load %"compiler/check:litv", ptr %l241
  store %"compiler/check:litv" %t458, ptr %rv
  br label %ret
bb156:
  %t459 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t459, ptr %l242
  br label %bb157
bb157:
  %t460 = load %"compiler/check:litv", ptr %l242
  store %"compiler/check:litv" %t460, ptr %rv
  br label %ret
bb158:
  %t461 = load %"compiler/check:litv", ptr %l22
  %t463 = call { i1, i64 } @compiler_2fcheck_2emagOf(%"compiler/check:litv" %t461)
  store { i1, i64 } %t463, ptr %l244
  br label %bb159
bb159:
  %t464 = load { i1, i64 }, ptr %l244
  store { i1, i64 } %t464, ptr %l26
  %t465 = getelementptr { i1, i64 }, ptr %l26, i32 0, i32 0
  %t466 = load i1, ptr %t465, !tbaa !21
  store i1 %t466, ptr %l27, !tbaa !21
  %t468 = getelementptr { i1, i64 }, ptr %l26, i32 0, i32 1
  %t469 = load i64, ptr %t468, !tbaa !65
  store i64 %t469, ptr %l28, !tbaa !65
  %t471 = load %"compiler/check:litv", ptr %l23
  %t473 = call { i1, i64 } @compiler_2fcheck_2emagOf(%"compiler/check:litv" %t471)
  store { i1, i64 } %t473, ptr %l248
  br label %bb160
bb160:
  %t474 = load { i1, i64 }, ptr %l248
  store { i1, i64 } %t474, ptr %l29
  %t475 = getelementptr { i1, i64 }, ptr %l29, i32 0, i32 0
  %t476 = load i1, ptr %t475, !tbaa !21
  store i1 %t476, ptr %l30, !tbaa !21
  %t478 = getelementptr { i1, i64 }, ptr %l29, i32 0, i32 1
  %t479 = load i64, ptr %t478, !tbaa !65
  store i64 %t479, ptr %l31, !tbaa !65
  %t481 = load i32, ptr %l19
  %t483 = trunc i64 49 to i32
  %t484 = icmp eq i32 %t481, %t483
  br i1 %t484, label %bb161, label %bb162
bb161:
  %t486 = load i1, ptr %l27, !tbaa !21
  %t487 = load i64, ptr %l28, !tbaa !65
  %t488 = load i1, ptr %l30, !tbaa !21
  %t489 = load i64, ptr %l31, !tbaa !65
  %t494 = call %"compiler/check:litv" @compiler_2fcheck_2eaddMag(i1 %t486, i64 %t487, i1 %t488, i64 %t489)
  store %"compiler/check:litv" %t494, ptr %l257
  br label %bb163
bb162:
  br label %bb164
bb163:
  %t495 = load %"compiler/check:litv", ptr %l257
  store %"compiler/check:litv" %t495, ptr %rv
  br label %ret
bb164:
  %t496 = load i32, ptr %l19
  %t498 = trunc i64 50 to i32
  %t499 = icmp eq i32 %t496, %t498
  br i1 %t499, label %bb165, label %bb166
bb165:
  %t501 = load i1, ptr %l27, !tbaa !21
  %t502 = load i64, ptr %l28, !tbaa !65
  %t503 = load i1, ptr %l30, !tbaa !21
  %t505 = xor i1 %t503, true
  %t506 = load i64, ptr %l31, !tbaa !65
  %t511 = call %"compiler/check:litv" @compiler_2fcheck_2eaddMag(i1 %t501, i64 %t502, i1 %t505, i64 %t506)
  store %"compiler/check:litv" %t511, ptr %l265
  br label %bb167
bb166:
  br label %bb168
bb167:
  %t512 = load %"compiler/check:litv", ptr %l265
  store %"compiler/check:litv" %t512, ptr %rv
  br label %ret
bb168:
  %t513 = load i32, ptr %l19
  %t515 = trunc i64 51 to i32
  %t516 = icmp eq i32 %t513, %t515
  br i1 %t516, label %bb169, label %bb170
bb169:
  %t518 = load i64, ptr %l28, !tbaa !65
  %t520 = icmp ne i64 %t518, 0
  br i1 %t520, label %bb171, label %bb172
bb170:
  br label %bb182
bb171:
  %t522 = load i64, ptr %l31, !tbaa !65
  %t523 = load i64, ptr %l28, !tbaa !65
  %t525 = udiv i64 -1, %t523
  %t528 = icmp ugt i64 %t522, %t525
  store i1 %t528, ptr %l270, !tbaa !21
  br label %bb173
bb172:
  store i1 false, ptr %l270, !tbaa !21
  br label %bb173
bb173:
  %t530 = load i1, ptr %l270, !tbaa !21
  br i1 %t530, label %bb174, label %bb175
bb174:
  %t531 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t531, ptr %l275
  br label %bb176
bb175:
  br label %bb177
bb176:
  %t532 = load %"compiler/check:litv", ptr %l275
  store %"compiler/check:litv" %t532, ptr %rv
  br label %ret
bb177:
  %t533 = load i64, ptr %l28, !tbaa !65
  %t534 = load i64, ptr %l31, !tbaa !65
  %t537 = mul i64 %t533, %t534
  store i64 %t537, ptr %l32, !tbaa !65
  %t539 = load i1, ptr %l27, !tbaa !21
  %t540 = load i1, ptr %l30, !tbaa !21
  %t543 = icmp ne i1 %t539, %t540
  br i1 %t543, label %bb178, label %bb179
bb178:
  %t545 = load i64, ptr %l32, !tbaa !65
  %t547 = icmp ne i64 %t545, 0
  store i1 %t547, ptr %l282, !tbaa !21
  br label %bb180
bb179:
  store i1 false, ptr %l282, !tbaa !21
  br label %bb180
bb180:
  %t549 = load i64, ptr %l32, !tbaa !65
  %t550 = load i1, ptr %l282, !tbaa !21
  %t552 = call %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 %t550, i64 %t549)
  store %"compiler/check:litv" %t552, ptr %l286
  br label %bb181
bb181:
  %t553 = load %"compiler/check:litv", ptr %l286
  store %"compiler/check:litv" %t553, ptr %rv
  br label %ret
bb182:
  %t554 = load i32, ptr %l19
  %t556 = trunc i64 81 to i32
  %t557 = icmp eq i32 %t554, %t556
  br i1 %t557, label %bb183, label %bb184
bb183:
  store i1 true, ptr %l289, !tbaa !21
  br label %bb185
bb184:
  %t559 = load i32, ptr %l19
  %t561 = trunc i64 82 to i32
  %t562 = icmp eq i32 %t559, %t561
  store i1 %t562, ptr %l289, !tbaa !21
  br label %bb185
bb185:
  %t564 = load i1, ptr %l289, !tbaa !21
  br i1 %t564, label %bb186, label %bb187
bb186:
  store i1 true, ptr %l292, !tbaa !21
  br label %bb188
bb187:
  %t565 = load i32, ptr %l19
  %t567 = trunc i64 83 to i32
  %t568 = icmp eq i32 %t565, %t567
  store i1 %t568, ptr %l292, !tbaa !21
  br label %bb188
bb188:
  %t570 = load i1, ptr %l292, !tbaa !21
  br i1 %t570, label %bb189, label %bb190
bb189:
  %t571 = load i32, ptr %l19
  %t573 = trunc i64 81 to i32
  %t574 = icmp eq i32 %t571, %t573
  br i1 %t574, label %bb191, label %bb192
bb190:
  br label %bb211
bb191:
  %t576 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 3
  %t577 = load i64, ptr %t576, !tbaa !24
  %t578 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 3
  %t579 = load i64, ptr %t578, !tbaa !24
  %t582 = and i64 %t577, %t579
  store i64 %t582, ptr %l297, !tbaa !24
  br label %bb196
bb192:
  %t584 = load i32, ptr %l19
  %t586 = trunc i64 82 to i32
  %t587 = icmp eq i32 %t584, %t586
  br i1 %t587, label %bb193, label %bb194
bb193:
  %t589 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 3
  %t590 = load i64, ptr %t589, !tbaa !24
  %t591 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 3
  %t592 = load i64, ptr %t591, !tbaa !24
  %t595 = or i64 %t590, %t592
  store i64 %t595, ptr %l303, !tbaa !24
  br label %bb195
bb194:
  %t597 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 3
  %t598 = load i64, ptr %t597, !tbaa !24
  %t599 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 3
  %t600 = load i64, ptr %t599, !tbaa !24
  %t603 = xor i64 %t598, %t600
  store i64 %t603, ptr %l303, !tbaa !24
  br label %bb195
bb195:
  %t605 = load i64, ptr %l303, !tbaa !24
  store i64 %t605, ptr %l297, !tbaa !24
  br label %bb196
bb196:
  %t606 = load i64, ptr %l297, !tbaa !24
  store i64 %t606, ptr %l33, !tbaa !24
  %t607 = load i64, ptr %l33, !tbaa !24
  %t609 = call %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %t607)
  store %"compiler/check:litv" %t609, ptr %l311
  br label %bb197
bb197:
  %t610 = load %"compiler/check:litv", ptr %l311
  store %"compiler/check:litv" %t610, ptr %l34
  %t611 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 2
  %t612 = load i1, ptr %t611, !tbaa !21
  br i1 %t612, label %bb198, label %bb199
bb198:
  store i1 true, ptr %l313, !tbaa !21
  br label %bb200
bb199:
  %t614 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 2
  %t615 = load i1, ptr %t614, !tbaa !21
  store i1 %t615, ptr %l313, !tbaa !21
  br label %bb200
bb200:
  %t617 = load i1, ptr %l313, !tbaa !21
  br i1 %t617, label %bb201, label %bb202
bb201:
  %t618 = load i64, ptr %l33, !tbaa !24
  %t620 = icmp slt i64 %t618, 0
  store i1 %t620, ptr %l315, !tbaa !21
  br label %bb203
bb202:
  store i1 false, ptr %l315, !tbaa !21
  br label %bb203
bb203:
  %t622 = load i1, ptr %l315, !tbaa !21
  br i1 %t622, label %bb204, label %bb205
bb204:
  store %olang.scope zeroinitializer, ptr %s29
  %t623 = load i64, ptr %l33, !tbaa !24
  %t625 = call %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %s29, i1 true, i1 false, i1 true, i64 %t623, double 0x0000000000000000)
  store %"compiler/check:litv" %t625, ptr %l319
  br label %bb206
bb205:
  br label %bb207
bb206:
  %t626 = load %"compiler/check:litv", ptr %l319
  store %"compiler/check:litv" %t626, ptr %l34
  call void @__olang_scope_close(ptr %s29)
  br label %bb207
bb207:
  %t627 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 5
  %t628 = load i1, ptr %t627, !tbaa !21
  br i1 %t628, label %bb208, label %bb209
bb208:
  store i1 true, ptr %l321, !tbaa !21
  br label %bb210
bb209:
  %t630 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 5
  %t631 = load i1, ptr %t630, !tbaa !21
  store i1 %t631, ptr %l321, !tbaa !21
  br label %bb210
bb210:
  %t633 = load i1, ptr %l321, !tbaa !21
  %t634 = getelementptr %"compiler/check:litv", ptr %l34, i32 0, i32 5
  store i1 %t633, ptr %t634, !tbaa !21
  %t635 = load %"compiler/check:litv", ptr %l34
  store %"compiler/check:litv" %t635, ptr %rv
  br label %ret
bb211:
  %t637 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 2
  %t638 = load i1, ptr %t637, !tbaa !21
  br i1 %t638, label %bb212, label %bb213
bb212:
  store i1 true, ptr %l325, !tbaa !21
  br label %bb214
bb213:
  %t640 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 2
  %t641 = load i1, ptr %t640, !tbaa !21
  store i1 %t641, ptr %l325, !tbaa !21
  br label %bb214
bb214:
  %t643 = load i1, ptr %l325, !tbaa !21
  br i1 %t643, label %bb215, label %bb216
bb215:
  %t644 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t644, ptr %l327
  br label %bb217
bb216:
  br label %bb218
bb217:
  %t645 = load %"compiler/check:litv", ptr %l327
  store %"compiler/check:litv" %t645, ptr %rv
  br label %ret
bb218:
  %t646 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 3
  %t647 = load i64, ptr %t646, !tbaa !24
  store i64 %t647, ptr %l35, !tbaa !24
  %t649 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 3
  %t650 = load i64, ptr %t649, !tbaa !24
  store i64 %t650, ptr %l36, !tbaa !24
  %t652 = load i32, ptr %l19
  %t654 = trunc i64 52 to i32
  %t655 = icmp eq i32 %t652, %t654
  br i1 %t655, label %bb219, label %bb220
bb219:
  %t657 = load i64, ptr %l36, !tbaa !24
  %t659 = icmp ne i64 %t657, 0
  store i1 %t659, ptr %l332, !tbaa !21
  br label %bb221
bb220:
  store i1 false, ptr %l332, !tbaa !21
  br label %bb221
bb221:
  %t661 = load i1, ptr %l332, !tbaa !21
  br i1 %t661, label %bb222, label %bb223
bb222:
  %t662 = load i64, ptr %l35, !tbaa !24
  %t663 = sub i64 -9223372036854775807, 1
  %t666 = icmp eq i64 %t662, %t663
  br i1 %t666, label %bb224, label %bb225
bb223:
  store i1 false, ptr %l335, !tbaa !21
  br label %bb227
bb224:
  %t668 = load i64, ptr %l36, !tbaa !24
  %t670 = icmp eq i64 %t668, -1
  store i1 %t670, ptr %l339, !tbaa !21
  br label %bb226
bb225:
  store i1 false, ptr %l339, !tbaa !21
  br label %bb226
bb226:
  %t672 = load i1, ptr %l339, !tbaa !21
  %t673 = xor i1 %t672, true
  store i1 %t673, ptr %l335, !tbaa !21
  br label %bb227
bb227:
  %t675 = load i1, ptr %l335, !tbaa !21
  br i1 %t675, label %bb228, label %bb229
bb228:
  %t676 = load i64, ptr %l35, !tbaa !24
  %t677 = load i64, ptr %l36, !tbaa !24
  %t680 = sdiv i64 %t676, %t677
  %t682 = call %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %t680)
  store %"compiler/check:litv" %t682, ptr %l346
  br label %bb230
bb229:
  br label %bb231
bb230:
  %t683 = load %"compiler/check:litv", ptr %l346
  store %"compiler/check:litv" %t683, ptr %rv
  br label %ret
bb231:
  %t684 = load i32, ptr %l19
  %t686 = trunc i64 53 to i32
  %t687 = icmp eq i32 %t684, %t686
  br i1 %t687, label %bb232, label %bb233
bb232:
  %t689 = load i64, ptr %l36, !tbaa !24
  %t691 = icmp ne i64 %t689, 0
  store i1 %t691, ptr %l349, !tbaa !21
  br label %bb234
bb233:
  store i1 false, ptr %l349, !tbaa !21
  br label %bb234
bb234:
  %t693 = load i1, ptr %l349, !tbaa !21
  br i1 %t693, label %bb235, label %bb236
bb235:
  %t694 = load i64, ptr %l36, !tbaa !24
  %t696 = icmp ne i64 %t694, -1
  store i1 %t696, ptr %l352, !tbaa !21
  br label %bb237
bb236:
  store i1 false, ptr %l352, !tbaa !21
  br label %bb237
bb237:
  %t698 = load i1, ptr %l352, !tbaa !21
  br i1 %t698, label %bb238, label %bb239
bb238:
  %t699 = load i64, ptr %l35, !tbaa !24
  %t700 = load i64, ptr %l36, !tbaa !24
  %t703 = srem i64 %t699, %t700
  %t705 = call %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %t703)
  store %"compiler/check:litv" %t705, ptr %l358
  br label %bb240
bb239:
  br label %bb241
bb240:
  %t706 = load %"compiler/check:litv", ptr %l358
  store %"compiler/check:litv" %t706, ptr %rv
  br label %ret
bb241:
  %t707 = load i32, ptr %l19
  %t709 = trunc i64 86 to i32
  %t710 = icmp eq i32 %t707, %t709
  br i1 %t710, label %bb242, label %bb243
bb242:
  %t712 = load i1, ptr %l27, !tbaa !21
  %t714 = xor i1 %t712, true
  store i1 %t714, ptr %l361, !tbaa !21
  br label %bb244
bb243:
  store i1 false, ptr %l361, !tbaa !21
  br label %bb244
bb244:
  %t716 = load i1, ptr %l361, !tbaa !21
  br i1 %t716, label %bb245, label %bb246
bb245:
  %t717 = load i64, ptr %l36, !tbaa !24
  %t719 = icmp sge i64 %t717, 0
  store i1 %t719, ptr %l364, !tbaa !21
  br label %bb247
bb246:
  store i1 false, ptr %l364, !tbaa !21
  br label %bb247
bb247:
  %t721 = load i1, ptr %l364, !tbaa !21
  br i1 %t721, label %bb248, label %bb249
bb248:
  %t722 = load i64, ptr %l36, !tbaa !24
  %t724 = icmp slt i64 %t722, 64
  store i1 %t724, ptr %l367, !tbaa !21
  br label %bb250
bb249:
  store i1 false, ptr %l367, !tbaa !21
  br label %bb250
bb250:
  %t726 = load i1, ptr %l367, !tbaa !21
  br i1 %t726, label %bb251, label %bb252
bb251:
  %t727 = load i64, ptr %l28, !tbaa !65
  %t728 = load i64, ptr %l36, !tbaa !24
  store i64 %t728, ptr %l372, !tbaa !65
  %t731 = load i64, ptr %l372, !tbaa !65
  %t732 = load i64, ptr %l372, !tbaa !65
  %t733 = shl i64 %t727, %t732
  store i64 %t733, ptr %l37, !tbaa !65
  %t735 = load i64, ptr %l37, !tbaa !65
  %t736 = load i64, ptr %l36, !tbaa !24
  store i64 %t736, ptr %l376, !tbaa !65
  %t739 = load i64, ptr %l376, !tbaa !65
  %t740 = load i64, ptr %l376, !tbaa !65
  %t741 = lshr i64 %t735, %t740
  %t742 = load i64, ptr %l28, !tbaa !65
  %t745 = icmp ne i64 %t741, %t742
  br i1 %t745, label %bb253, label %bb254
bb252:
  br label %bb258
bb253:
  %t747 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t747, ptr %l380
  br label %bb255
bb254:
  br label %bb256
bb255:
  %t748 = load %"compiler/check:litv", ptr %l380
  store %"compiler/check:litv" %t748, ptr %rv
  br label %ret
bb256:
  %t749 = load i64, ptr %l37, !tbaa !65
  %t751 = call %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 false, i64 %t749)
  store %"compiler/check:litv" %t751, ptr %l382
  br label %bb257
bb257:
  %t752 = load %"compiler/check:litv", ptr %l382
  store %"compiler/check:litv" %t752, ptr %rv
  br label %ret
bb258:
  %t753 = load i32, ptr %l19
  %t755 = trunc i64 87 to i32
  %t756 = icmp eq i32 %t753, %t755
  br i1 %t756, label %bb259, label %bb260
bb259:
  %t758 = load i64, ptr %l36, !tbaa !24
  %t760 = icmp sge i64 %t758, 0
  store i1 %t760, ptr %l385, !tbaa !21
  br label %bb261
bb260:
  store i1 false, ptr %l385, !tbaa !21
  br label %bb261
bb261:
  %t762 = load i1, ptr %l385, !tbaa !21
  br i1 %t762, label %bb262, label %bb263
bb262:
  %t763 = load i64, ptr %l36, !tbaa !24
  %t765 = icmp slt i64 %t763, 64
  store i1 %t765, ptr %l388, !tbaa !21
  br label %bb264
bb263:
  store i1 false, ptr %l388, !tbaa !21
  br label %bb264
bb264:
  %t767 = load i1, ptr %l388, !tbaa !21
  br i1 %t767, label %bb265, label %bb266
bb265:
  %t768 = load i64, ptr %l35, !tbaa !24
  %t769 = load i64, ptr %l36, !tbaa !24
  store i64 %t769, ptr %l392, !tbaa !24
  %t771 = load i64, ptr %l392, !tbaa !24
  %t772 = load i64, ptr %l392, !tbaa !24
  %t773 = ashr i64 %t768, %t772
  %t775 = call %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %t773)
  store %"compiler/check:litv" %t775, ptr %l394
  br label %bb267
bb266:
  br label %bb268
bb267:
  %t776 = load %"compiler/check:litv", ptr %l394
  store %"compiler/check:litv" %t776, ptr %rv
  br label %ret
bb268:
  %t777 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t777, ptr %l395
  br label %bb269
bb269:
  %t778 = load %"compiler/check:litv", ptr %l395
  store %"compiler/check:litv" %t778, ptr %rv
  br label %ret
bb270:
  %t779 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t779, ptr %l396
  br label %bb271
bb271:
  %t780 = load %"compiler/check:litv", ptr %l396
  store %"compiler/check:litv" %t780, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalBody(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l16 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l17 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i32
  %l30 = alloca ptr
  %l31 = alloca %"compiler/source:Span"
  %l41 = alloca i64
  %l44 = alloca i64
  %l63 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l74 = alloca ptr
  %l77 = alloca { i64, [2 x i64] }
  %l82 = alloca i32
  %l85 = alloca i64
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i64
  %t133 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i32, ptr %l2, !tbaa !23
  %t4 = sext i32 %t2 to i64
  %t7 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t1, i64 %t4)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t7, ptr %l16
  br label %bb1
bb1:
  %t8 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l16
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t8, ptr %l3
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 22
  %t12 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l3
  %t15 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t11, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t12)
  %t16 = extractvalue { i32, i64 } %t15, 1
  %t17 = extractvalue { i32, i64 } %t15, 0
  store i32 %t17, ptr %l22
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb3, label %ok.19
ok.19:
  store i64 %t16, ptr %l21
  br label %bb2
bb2:
  %t20 = load i64, ptr %l21, !tbaa !24
  store i64 %t20, ptr %l17, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  store i64 -1, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t21 = load i64, ptr %l17, !tbaa !24
  store i64 %t21, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = icmp sge i64 %t22, 0
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = load i64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t26, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t32 = load i64, ptr %l1, !tbaa !24
  %t33 = load i32, ptr %l2, !tbaa !23
  %t37 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %t31, i64 %t32, i32 %t33)
  store ptr %t37, ptr %l30
  br label %bb9
bb9:
  %t38 = load ptr, ptr %l30, !tbaa !29
  store ptr %t38, ptr %l5, !tbaa !29
  %t39 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t39, ptr %l31
  br label %bb10
bb10:
  %t40 = load %"compiler/source:Span", ptr %l31
  store %"compiler/source:Span" %t40, ptr %l6
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t43 = icmp eq ptr %t41, null
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb11, label %bb12
bb11:
  store i64 0, ptr %l7, !tbaa !24
  %t47 = load ptr, ptr %l5, !tbaa !29
  %t49 = getelementptr %"compiler/ast:VarDecl", ptr %t47, i32 0, i32 0
  %t50 = load { i64, ptr }, ptr %t49, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t50, 0
  store i64 %t52, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t54 = load i64, ptr %l8, !tbaa !24
  %t55 = load i64, ptr %l7, !tbaa !24
  %t58 = icmp sgt i64 %t54, %t55
  br i1 %t58, label %bb13, label %bb14
bb12:
  br label %bb28
bb13:
  %t60 = load i64, ptr %l9, !tbaa !24
  %t62 = icmp sgt i64 %t60, 0
  br i1 %t62, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb18
bb15:
  %t64 = load i64, ptr %l8, !tbaa !24
  %t65 = load i64, ptr %l7, !tbaa !24
  %t68 = sub i64 %t64, %t65
  %t69 = load i64, ptr %l9, !tbaa !24
  %t72 = add i64 %t68, %t69
  %t74 = sub i64 %t72, 1
  %t75 = load i64, ptr %l9, !tbaa !24
  %t78 = sdiv i64 %t74, %t75
  store i64 %t78, ptr %l44, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb17
bb17:
  %t80 = load i64, ptr %l44, !tbaa !24
  store i64 %t80, ptr %l41, !tbaa !24
  br label %bb18
bb18:
  %t81 = load i64, ptr %l41, !tbaa !24
  store i64 %t81, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t82 = load i64, ptr %l11, !tbaa !24
  %t83 = load i64, ptr %l10, !tbaa !24
  %t86 = icmp slt i64 %t82, %t83
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s4)
  br label %bb27
bb21:
  br label %bb22
bb22:
  %t90 = load i64, ptr %l7, !tbaa !24
  %t91 = load i64, ptr %l11, !tbaa !24
  %t92 = load i64, ptr %l9, !tbaa !24
  %t95 = mul i64 %t91, %t92
  %t98 = add i64 %t90, %t95
  store i64 %t98, ptr %l12, !tbaa !24
  %t100 = load ptr, ptr %l5, !tbaa !29
  %t102 = getelementptr %"compiler/ast:VarDecl", ptr %t100, i32 0, i32 0
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  store { i64, ptr } %t103, ptr %l63, !tbaa !27
  %t104 = load i64, ptr %l12, !tbaa !24
  %t106 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr i32, ptr %t107, i64 %t104
  %t109 = load i32, ptr %t108, !tbaa !33
  %t110 = load i32, ptr %l2, !tbaa !23
  %t113 = icmp eq i32 %t109, %t110
  br i1 %t113, label %bb23, label %bb24
bb23:
  %t115 = load ptr, ptr %l5, !tbaa !29
  %t117 = getelementptr %"compiler/ast:VarDecl", ptr %t115, i32 0, i32 1
  %t118 = load { i64, ptr }, ptr %t117, !tbaa !27
  store { i64, ptr } %t118, ptr %l69, !tbaa !27
  %t119 = load i64, ptr %l12, !tbaa !24
  %t121 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr %"compiler/source:Span", ptr %t122, i64 %t119
  %t124 = load %"compiler/source:Span", ptr %t123
  store %"compiler/source:Span" %t124, ptr %l6
  br label %bb25
bb24:
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s4)
  br label %bb26
bb26:
  %t126 = load i64, ptr %l11, !tbaa !24
  %t128 = add i64 %t126, 1
  store i64 %t128, ptr %l11, !tbaa !24
  br label %bb19
bb27:
  br label %bb28
bb28:
  %t130 = load ptr, ptr %l0, !tbaa !29
  store ptr %t130, ptr %l74, !tbaa !29
  %t131 = load i64, ptr %l1, !tbaa !24
  %t132 = load i32, ptr %l2, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t133
  %t134 = getelementptr { i64, [2 x i64] }, ptr %t133, i32 0, i32 0
  store i64 6, ptr %t134
  %t136 = insertvalue { i64, i32 } undef, i64 %t131, 0
  %t138 = insertvalue { i64, i32 } %t136, i32 %t132, 1
  %t139 = getelementptr { i64, [2 x i64] }, ptr %t133, i32 0, i32 1
  store { i64, i32 } %t138, ptr %t139
  %t140 = load { i64, [2 x i64] }, ptr %t133
  store { i64, [2 x i64] } %t140, ptr %l77
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/check:Checker", ptr %t141, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t146 = getelementptr %"compiler/generic:Program", ptr %t144, i32 0, i32 2
  %t147 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t150 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t146, i32 0, i32 %t147, i32 0, i32 0, i64 0)
  store i32 %t150, ptr %l82
  br label %bb29
bb29:
  %t151 = load i64, ptr %l1, !tbaa !24
  %t152 = load %"compiler/source:Span", ptr %l6
  %t153 = load ptr, ptr %l74, !tbaa !29
  %t154 = load { i64, [2 x i64] }, ptr %l77
  %t155 = load i32, ptr %l82, !tbaa !23
  %t158 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t153, { i64, [2 x i64] } %t154, i32 %t155, i64 %t151, %"compiler/source:Span" %t152)
  store i64 %t158, ptr %l85
  br label %bb30
bb30:
  %t159 = load i64, ptr %l85, !tbaa !24
  store i64 %t159, ptr %l4, !tbaa !24
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/check:Checker", ptr %t160, i32 0, i32 22
  %t163 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l3
  %t164 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %t162, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t163, i64 %t164)
  br label %bb31
bb31:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeck(ptr %v0, ptr %t168, i64 %t169)
  br label %bb32
bb32:
  %t172 = load i64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t172, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eindexPlace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca ptr
  %l15 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %t1, ptr %a2)
  store ptr %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l7, !tbaa !29
  store ptr %t6, ptr %l4, !tbaa !29
  %t7 = load ptr, ptr %l4, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb2, label %bb3
bb2:
  store ptr null, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = load ptr, ptr %l4, !tbaa !29
  %t20 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelemPlace(ptr %v0, ptr %v2, ptr %t12, %"compiler/source:Span" %a1, ptr %t14, { i64, ptr } %a3)
  store ptr %t20, ptr %l15
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l15, !tbaa !29
  store ptr %t21, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstHoldsItself(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i1
  %l19 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca { i64, ptr }
  %l27 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l33 = alloca i64
  %l36 = alloca i64
  %l54 = alloca i64
  %l56 = alloca i64
  %l58 = alloca i1
  %l60 = alloca { i64, ptr }
  %l64 = alloca i1
  %l65 = alloca ptr
  %l68 = alloca %"compiler/source:Span"
  %l71 = alloca { i64, ptr }
  %l73 = alloca %"compiler/msgs:Msg"
  %l74 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  %t8 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t4, i32 %t5)
  store i1 %t8, ptr %l15
  br label %bb1
bb1:
  %t9 = load i1, ptr %l15, !tbaa !21
  %t10 = xor i1 %t9, true
  br i1 %t10, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  store ptr %t17, ptr %l19, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 2
  %t24 = load i32, ptr %l1, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l24
  br label %bb5
bb5:
  %t28 = load ptr, ptr %l19, !tbaa !29
  %t29 = load i32, ptr %l24, !tbaa !23
  %t30 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t28, i32 %t29)
  store { i64, ptr } %t30, ptr %l25
  br label %bb6
bb6:
  %t31 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t31, ptr %l4, !tbaa !27
  %t34 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2efieldSpans(ptr %v1, ptr %s0, ptr %a3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t34, ptr %l27
  br label %bb7
bb7:
  %t35 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l27
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t35, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 0
  store i64 %t38, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t40 = load i64, ptr %l7, !tbaa !24
  %t41 = load i64, ptr %l6, !tbaa !24
  %t44 = icmp sgt i64 %t40, %t41
  br i1 %t44, label %bb8, label %bb9
bb8:
  %t46 = load i64, ptr %l8, !tbaa !24
  %t48 = icmp sgt i64 %t46, 0
  br i1 %t48, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb13
bb10:
  %t50 = load i64, ptr %l7, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = sub i64 %t50, %t51
  %t55 = load i64, ptr %l8, !tbaa !24
  %t58 = add i64 %t54, %t55
  %t60 = sub i64 %t58, 1
  %t61 = load i64, ptr %l8, !tbaa !24
  %t64 = sdiv i64 %t60, %t61
  store i64 %t64, ptr %l36, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb12
bb12:
  %t66 = load i64, ptr %l36, !tbaa !24
  store i64 %t66, ptr %l33, !tbaa !24
  br label %bb13
bb13:
  %t67 = load i64, ptr %l33, !tbaa !24
  store i64 %t67, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t68 = load i64, ptr %l10, !tbaa !24
  %t69 = load i64, ptr %l9, !tbaa !24
  %t72 = icmp slt i64 %t68, %t69
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb16:
  br label %bb17
bb17:
  %t76 = load i64, ptr %l6, !tbaa !24
  %t77 = load i64, ptr %l10, !tbaa !24
  %t78 = load i64, ptr %l8, !tbaa !24
  %t81 = mul i64 %t77, %t78
  %t84 = add i64 %t76, %t81
  store i64 %t84, ptr %l11, !tbaa !24
  %t86 = load i64, ptr %l11, !tbaa !24
  store i64 %t86, ptr %l54, !tbaa !24
  %t88 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eLen_3ccompiler_2fsource_3aSpan_3e(ptr %s0, ptr %l5)
  store i64 %t88, ptr %l56
  br label %bb18
bb18:
  %t89 = load i64, ptr %l54, !tbaa !24
  %t90 = load i64, ptr %l56, !tbaa !24
  %t91 = icmp slt i64 %t89, %t90
  br i1 %t91, label %bb19, label %bb20
bb19:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t94, ptr %l60, !tbaa !27
  %t95 = load i64, ptr %l11, !tbaa !24
  %t97 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr i32, ptr %t98, i64 %t95
  %t100 = load i32, ptr %t99, !tbaa !33
  %t101 = load i32, ptr %l1, !tbaa !23
  %t105 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsInst(ptr %v0, ptr %t93, i32 %t100, i32 %t101, i64 0)
  store i1 %t105, ptr %l64
  br label %bb21
bb20:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb22
bb21:
  %t106 = load i1, ptr %l64, !tbaa !21
  store i1 %t106, ptr %l58, !tbaa !21
  br label %bb22
bb22:
  %t107 = load i1, ptr %l58, !tbaa !21
  br i1 %t107, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l65, !tbaa !29
  %t109 = load i64, ptr %l11, !tbaa !24
  %t112 = call %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %s0, ptr %l5, i64 %t109)
  store %"compiler/source:Span" %t112, ptr %l68
  br label %bb25
bb24:
  br label %bb29
bb25:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load i32, ptr %l1, !tbaa !23
  %t117 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s4, ptr %t113, i32 %t114)
  store { i64, ptr } %t117, ptr %l71
  br label %bb26
bb26:
  %t118 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t118, 0
  %t120 = extractvalue { i64, ptr } %t118, 1
  %t121 = mul i64 %t119, 1
  %t122 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t121)
  call void @llvm.memcpy.p0.p0.i64(ptr %t122, ptr %t120, i64 %t121, i1 false)
  %t123 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  %t126 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeHoldsItself(ptr %s4, ptr %s4, { i64, ptr } %t124)
  store %"compiler/msgs:Msg" %t126, ptr %l73
  br label %bb27
bb27:
  %t127 = load ptr, ptr %l65, !tbaa !29
  %t128 = load %"compiler/source:Span", ptr %l68
  %t129 = load %"compiler/msgs:Msg", ptr %l73
  %t130 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t127, %"compiler/source:Span" %t128, %"compiler/msgs:Msg" %t129)
  store i64 %t130, ptr %l74
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb29:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb30:
  %t131 = load i64, ptr %l10, !tbaa !24
  %t133 = add i64 %t131, 1
  store i64 %t133, ptr %l10, !tbaa !24
  br label %bb14
bb31:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisGlobalBody(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l6 = alloca ptr
  %l9 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 10
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l6, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 1
  %t11 = load { i64, [2 x i64] }, ptr %t10
  %t15 = extractvalue { i64, [2 x i64] } %t11, 0
  %t16 = icmp eq i64 %t15, 6
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb5
bb4:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_4bb92e4e6aa9fa92_ae49a41c9a1a92ee)
  unreachable
bb10:
  %t18 = load i1, ptr %l9, !tbaa !21
  store i1 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l6
  br label %bb1
bb1:
  %t11 = load i32, ptr %l6
  %t13 = trunc i64 20 to i32
  %t14 = icmp eq i32 %t11, %t13
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elambda(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca ptr
  %l18 = alloca i1
  %l19 = alloca i32
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i32
  %l28 = alloca i1
  %l29 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca i32
  %l36 = alloca ptr
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca i32
  %lp48 = alloca ptr
  %l53 = alloca ptr
  %l56 = alloca %"compiler/source:Span"
  %l57 = alloca %"compiler/msgs:Msg"
  %l58 = alloca i64
  %l61 = alloca ptr
  %l65 = alloca i1
  %l70 = alloca i32
  %l73 = alloca i32
  %l84 = alloca { i64, ptr }
  %l87 = alloca ptr
  %l92 = alloca i32
  %l93 = alloca { i64, ptr }
  %l100 = alloca i1
  %l105 = alloca ptr
  %l106 = alloca %"compiler/source:Span"
  %l109 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l112 = alloca i64
  %l116 = alloca { i64, ptr }
  %l118 = alloca %"compiler/msgs:Msg"
  %l119 = alloca i64
  %l122 = alloca ptr
  %l123 = alloca i64
  %l131 = alloca i64
  %l134 = alloca i64
  %l152 = alloca { i64, ptr }
  %l158 = alloca i64
  %l160 = alloca { i64, ptr }
  %l164 = alloca i32
  %l168 = alloca i1
  %l170 = alloca i1
  %l173 = alloca ptr
  %l177 = alloca i32
  %l178 = alloca i32
  %l181 = alloca i1
  %l183 = alloca { i64, ptr }
  %l187 = alloca i1
  %l189 = alloca { i64, ptr }
  %l192 = alloca i32
  %l193 = alloca { i64, ptr }
  %l196 = alloca i32
  %l198 = alloca { i64, ptr }
  %l202 = alloca { i64, ptr }
  %l206 = alloca %"compiler/source:Span"
  %l207 = alloca ptr
  %l208 = alloca %"compiler/source:Span"
  %l210 = alloca { i64, ptr }
  %l214 = alloca { i64, ptr }
  %l215 = alloca { i64, ptr }
  %l216 = alloca ptr
  %l217 = alloca { i64, ptr }
  %l224 = alloca %"compiler/source:Span"
  %l225 = alloca { i64, ptr }
  %l226 = alloca %"compiler/msgs:Msg"
  %l227 = alloca i64
  %l230 = alloca ptr
  %l234 = alloca i1
  %l236 = alloca { i64, ptr }
  %l239 = alloca i1
  %l241 = alloca i1
  %l247 = alloca { i64, ptr }
  %l250 = alloca i1
  %l255 = alloca i1
  %l257 = alloca { i64, ptr }
  %l260 = alloca i1
  %l262 = alloca i1
  %l265 = alloca ptr
  %l269 = alloca i32
  %l271 = alloca { i64, ptr }
  %l274 = alloca i32
  %l275 = alloca i1
  %l277 = alloca { i64, ptr }
  %l283 = alloca ptr
  %l287 = alloca i1
  %l288 = alloca i1
  %l290 = alloca { i64, ptr }
  %l293 = alloca i1
  %l294 = alloca i1
  %l297 = alloca ptr
  %l301 = alloca i32
  %l303 = alloca { i64, ptr }
  %l306 = alloca i32
  %l307 = alloca i1
  %l308 = alloca i1
  %l314 = alloca i64
  %l320 = alloca ptr
  %l321 = alloca { i64, ptr }
  %l324 = alloca %"compiler/source:Span"
  %l327 = alloca { i64, ptr }
  %l329 = alloca %"compiler/msgs:Msg"
  %l330 = alloca i64
  %l333 = alloca ptr
  %l337 = alloca i1
  %l339 = alloca { i64, ptr }
  %l342 = alloca i1
  %l345 = alloca { i64, ptr }
  %l348 = alloca ptr
  %l349 = alloca { i64, ptr }
  %l352 = alloca %"compiler/source:Span"
  %l354 = alloca { i64, ptr }
  %l358 = alloca { i64, ptr }
  %l360 = alloca %"compiler/msgs:Msg"
  %l361 = alloca i64
  %l364 = alloca ptr
  %l376 = alloca i64
  %l385 = alloca i64
  %l388 = alloca i64
  %l406 = alloca i64
  %l410 = alloca { i64, ptr }
  %l414 = alloca i32
  %l420 = alloca i32
  %l424 = alloca ptr
  %l429 = alloca i32
  %l430 = alloca i32
  %l434 = alloca i1
  %l435 = alloca ptr
  %l440 = alloca i32
  %l441 = alloca i1
  %l447 = alloca i32
  %l452 = alloca i1
  %l458 = alloca i1
  %l465 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l482 = alloca { i64, ptr }
  %l485 = alloca ptr
  %l487 = alloca ptr
  %l489 = alloca ptr
  %l493 = alloca i32
  %l498 = alloca ptr
  %l500 = alloca { i64, ptr }
  %l501 = alloca i32
  %l509 = alloca i32
  %l513 = alloca i32
  %l518 = alloca i32
  %l523 = alloca i32
  %l525 = alloca ptr
  %l528 = alloca i64
  %l530 = alloca ptr
  %l535 = alloca { i64, [2 x i64] }
  %l543 = alloca i32
  %l547 = alloca i64
  %l557 = alloca ptr
  %l568 = alloca ptr
  %l571 = alloca i32
  %l576 = alloca i64
  %l579 = alloca i64
  %l598 = alloca { i64, ptr }
  %l602 = alloca { i64, ptr }
  %l609 = alloca { i64, ptr }
  %l613 = alloca { i64, ptr }
  %l620 = alloca { i64, ptr }
  %l625 = alloca i1
  %l629 = alloca ptr
  %l631 = alloca ptr
  %l633 = alloca ptr
  %l636 = alloca { i64, ptr }
  %l641 = alloca ptr
  %l643 = alloca ptr
  %l655 = alloca ptr
  %l656 = alloca ptr
  %l659 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l661 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l663 = alloca i32
  %l671 = alloca i32
  %l673 = alloca ptr
  %l679 = alloca i1
  %l681 = alloca ptr
  %l685 = alloca i1
  %l688 = alloca i1
  %l690 = alloca ptr
  %l691 = alloca %"compiler/source:Span"
  %l694 = alloca { i64, ptr }
  %l696 = alloca %"compiler/msgs:Msg"
  %l697 = alloca i64
  %l699 = alloca ptr
  %l702 = alloca { i64, ptr }
  %l708 = alloca ptr
  %l709 = alloca i64
  %l712 = alloca { i64, [3 x i64] }
  %l713 = alloca %"compiler/check:roFn"
  %l717 = alloca i32
  %l720 = alloca ptr
  %l721 = alloca i32
  %l726 = alloca i64
  %l727 = alloca i32
  %l730 = alloca ptr
  %l731 = alloca i32
  %l736 = alloca i64
  %l737 = alloca i32
  %l738 = alloca %"compiler/source:Span"
  %l739 = alloca i32
  %l742 = alloca i32
  %l743 = alloca { i64, ptr }
  %l747 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %rv = alloca ptr
  %t1105 = alloca { i64, [2 x i64] }, align 8
  %t1571 = alloca { i64, [4 x i64] }, align 8
  %t1583 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Func", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/ast:Sig", ptr %t4, i32 0, i32 4
  %t7 = load i1, ptr %t6, !tbaa !21
  br i1 %t7, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l53, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load %"compiler/source:Span", ptr %l1
  %t14 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoreturnSpan(ptr %v0, ptr %t10, %"compiler/source:Span" %t11)
  store %"compiler/source:Span" %t14, ptr %l56
  br label %bb3
bb2:
  br label %bb7
bb3:
  %t15 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoreturnHere(ptr %s1, ptr %s1, { i64, ptr } { i64 8, ptr @.d38 })
  store %"compiler/msgs:Msg" %t15, ptr %l57
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l53, !tbaa !29
  %t17 = load %"compiler/source:Span", ptr %l56
  %t18 = load %"compiler/msgs:Msg", ptr %l57
  %t19 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t16, %"compiler/source:Span" %t17, %"compiler/msgs:Msg" %t18)
  store i64 %t19, ptr %l58
  br label %bb5
bb5:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load %"compiler/source:Span", ptr %l1
  %t24 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t20, %"compiler/source:Span" %t21)
  store ptr %t24, ptr %l61
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t25 = load ptr, ptr %l61, !tbaa !29
  store ptr %t25, ptr %rv
  br label %ret
bb7:
  %t26 = load i32, ptr %l3, !tbaa !23
  %t27 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t30 = icmp ne i32 %t26, %t27
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  %t38 = load i32, ptr %l3, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l70
  br label %bb10
bb9:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb11
bb10:
  %t42 = load i32, ptr %l70
  %t44 = trunc i64 21 to i32
  %t45 = icmp eq i32 %t42, %t44
  store i1 %t45, ptr %l65, !tbaa !21
  br label %bb11
bb11:
  %t47 = load i1, ptr %l65, !tbaa !21
  br i1 %t47, label %bb12, label %bb13
bb12:
  %t48 = load i32, ptr %l3, !tbaa !23
  store i32 %t48, ptr %l73, !tbaa !23
  br label %bb14
bb13:
  %t50 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t50, ptr %l73, !tbaa !23
  br label %bb14
bb14:
  %t52 = load i32, ptr %l73, !tbaa !23
  store i32 %t52, ptr %l4, !tbaa !23
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t55 = getelementptr %"compiler/ast:Func", ptr %t53, i32 0, i32 3
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = getelementptr %"compiler/ast:Sig", ptr %t56, i32 0, i32 0
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  store { i64, ptr } %t59, ptr %l5, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t61, 0
  store i64 %t63, ptr %l6, !tbaa !24
  %t65 = load i32, ptr %l4, !tbaa !23
  %t66 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t69 = icmp ne i32 %t65, %t66
  br i1 %t69, label %bb15, label %bb16
bb15:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 2
  store ptr %t76, ptr %l87, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/generic:Program", ptr %t80, i32 0, i32 2
  %t83 = load i32, ptr %l4, !tbaa !23
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t82, i32 %t83)
  store i32 %t86, ptr %l92
  br label %bb17
bb16:
  %t88 = load ptr, ptr @__olang_prog_scope
  %t89 = call ptr @__olang_scope_alloc(ptr %t88, i64 0)
  store [0 x i32] zeroinitializer, ptr %t89
  %t90 = insertvalue { i64, ptr } undef, i64 0, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  %t93 = extractvalue { i64, ptr } %t91, 0
  %t94 = extractvalue { i64, ptr } %t91, 1
  %t95 = mul i64 %t93, 4
  %t96 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t95)
  call void @llvm.memcpy.p0.p0.i64(ptr %t96, ptr %t94, i64 %t95, i1 false)
  %t97 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t96, 1
  store { i64, ptr } %t98, ptr %l84, !tbaa !27
  br label %bb19
bb17:
  %t100 = load ptr, ptr %l87, !tbaa !29
  %t101 = load i32, ptr %l92, !tbaa !23
  %t102 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t100, i32 %t101)
  store { i64, ptr } %t102, ptr %l93
  br label %bb18
bb18:
  %t103 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t103, ptr %l84, !tbaa !27
  br label %bb19
bb19:
  %t104 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t104, ptr %l7, !tbaa !27
  %t105 = load i32, ptr %l4, !tbaa !23
  %t106 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t109 = icmp ne i32 %t105, %t106
  br i1 %t109, label %bb20, label %bb21
bb20:
  %t111 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t111, 0
  %t114 = load i64, ptr %l6, !tbaa !24
  %t117 = icmp ne i64 %t113, %t114
  store i1 %t117, ptr %l100, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb22
bb22:
  %t119 = load i1, ptr %l100, !tbaa !21
  br i1 %t119, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s2
  %t120 = load ptr, ptr %l0, !tbaa !29
  store ptr %t120, ptr %l105, !tbaa !29
  %t121 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t121, ptr %l106
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load i32, ptr %l4, !tbaa !23
  %t126 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t122, i32 %t123)
  store { i64, ptr } %t126, ptr %l109
  br label %bb25
bb24:
  br label %bb32
bb25:
  %t127 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t127, 0
  %t129 = extractvalue { i64, ptr } %t127, 1
  %t130 = mul i64 %t128, 1
  %t131 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t130)
  call void @llvm.memcpy.p0.p0.i64(ptr %t131, ptr %t129, i64 %t130, i1 false)
  %t132 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr %t131, 1
  store { i64, ptr } %t133, ptr %l110, !tbaa !27
  %t134 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t134, 0
  store i64 %t136, ptr %l112, !tbaa !24
  %t137 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t137, 0
  %t141 = icmp eq i64 %t139, 1
  br i1 %t141, label %bb26, label %bb27
bb26:
  store { i64, ptr } { i64 0, ptr @.d39 }, ptr %l116, !tbaa !27
  br label %bb28
bb27:
  store { i64, ptr } { i64 1, ptr @.d40 }, ptr %l116, !tbaa !27
  br label %bb28
bb28:
  %t143 = load i64, ptr %l6, !tbaa !24
  %t144 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t145 = load i64, ptr %l112, !tbaa !24
  %t146 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t148 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaArity(ptr %s2, ptr %s2, ptr %s2, { i64, ptr } %t144, i64 %t145, { i64, ptr } %t146, i64 %t143)
  store %"compiler/msgs:Msg" %t148, ptr %l118
  br label %bb29
bb29:
  %t149 = load ptr, ptr %l105, !tbaa !29
  %t150 = load %"compiler/source:Span", ptr %l106
  %t151 = load %"compiler/msgs:Msg", ptr %l118
  %t152 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t149, %"compiler/source:Span" %t150, %"compiler/msgs:Msg" %t151)
  store i64 %t152, ptr %l119
  br label %bb30
bb30:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load %"compiler/source:Span", ptr %l1
  %t157 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t153, %"compiler/source:Span" %t154)
  store ptr %t157, ptr %l122
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t158 = load ptr, ptr %l122, !tbaa !29
  store ptr %t158, ptr %rv
  br label %ret
bb32:
  %t159 = load i64, ptr %l6, !tbaa !24
  store i64 %t159, ptr %l123, !tbaa !24
  %t160 = load i64, ptr %l123, !tbaa !24
  %t161 = icmp sge i64 %t160, 0
  br i1 %t161, label %bb33, label %bb34
bb33:
  %t163 = load i64, ptr %l123, !tbaa !24
  %t164 = icmp sle i64 %t163, 2305843009213693951
  br i1 %t164, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_d264b31a2a0953e1_a8a3a5518784125d)
  unreachable
bb35:
  %t166 = load i64, ptr %l123, !tbaa !24
  %t167 = mul i64 %t166, 4
  %t168 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t167)
  %t169 = insertvalue { i64, ptr } undef, i64 %t166, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t168, 1
  store { i64, ptr } %t170, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t172 = load i64, ptr %l6, !tbaa !24
  store i64 %t172, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t174 = load i64, ptr %l10, !tbaa !24
  %t175 = load i64, ptr %l9, !tbaa !24
  %t178 = icmp sgt i64 %t174, %t175
  br i1 %t178, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_d264b31a2a0953e1_a8a3a5518784125d)
  unreachable
bb37:
  %t180 = load i64, ptr %l11, !tbaa !24
  %t182 = icmp sgt i64 %t180, 0
  br i1 %t182, label %bb39, label %bb40
bb38:
  store i64 0, ptr %l131, !tbaa !24
  br label %bb42
bb39:
  %t184 = load i64, ptr %l10, !tbaa !24
  %t185 = load i64, ptr %l9, !tbaa !24
  %t188 = sub i64 %t184, %t185
  %t189 = load i64, ptr %l11, !tbaa !24
  %t192 = add i64 %t188, %t189
  %t194 = sub i64 %t192, 1
  %t195 = load i64, ptr %l11, !tbaa !24
  %t198 = sdiv i64 %t194, %t195
  store i64 %t198, ptr %l134, !tbaa !24
  br label %bb41
bb40:
  store i64 0, ptr %l134, !tbaa !24
  br label %bb41
bb41:
  %t200 = load i64, ptr %l134, !tbaa !24
  store i64 %t200, ptr %l131, !tbaa !24
  br label %bb42
bb42:
  %t201 = load i64, ptr %l131, !tbaa !24
  store i64 %t201, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb43
bb43:
  store %olang.scope zeroinitializer, ptr %s4
  %t202 = load i64, ptr %l13, !tbaa !24
  %t203 = load i64, ptr %l12, !tbaa !24
  %t206 = icmp slt i64 %t202, %t203
  %t208 = xor i1 %t206, true
  br i1 %t208, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s4)
  br label %bb133
bb45:
  br label %bb46
bb46:
  %t210 = load i64, ptr %l9, !tbaa !24
  %t211 = load i64, ptr %l13, !tbaa !24
  %t212 = load i64, ptr %l11, !tbaa !24
  %t215 = mul i64 %t211, %t212
  %t218 = add i64 %t210, %t215
  store i64 %t218, ptr %l14, !tbaa !24
  %t220 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t220, ptr %l152, !tbaa !27
  %t221 = load i64, ptr %l14, !tbaa !24
  %t223 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !27
  %t225 = getelementptr ptr, ptr %t224, i64 %t221
  %t226 = load ptr, ptr %t225, !tbaa !39
  %t228 = getelementptr %"compiler/ast:Param", ptr %t226, i32 0, i32 2
  %t229 = load ptr, ptr %t228, !tbaa !29
  %t231 = icmp eq ptr %t229, null
  %t233 = xor i1 %t231, true
  br i1 %t233, label %bb47, label %bb48
bb47:
  %t235 = load i64, ptr %l14, !tbaa !24
  store i64 %t235, ptr %l158, !tbaa !24
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t237 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t237, ptr %l160, !tbaa !27
  %t238 = load i64, ptr %l14, !tbaa !24
  %t240 = getelementptr { i64, ptr }, ptr %l160, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !27
  %t242 = getelementptr ptr, ptr %t241, i64 %t238
  %t243 = load ptr, ptr %t242, !tbaa !39
  %t245 = getelementptr %"compiler/ast:Param", ptr %t243, i32 0, i32 2
  %t246 = load ptr, ptr %t245, !tbaa !29
  %t249 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %t236, ptr %t246)
  store i32 %t249, ptr %l164
  br label %bb49
bb48:
  %t250 = load i32, ptr %l4, !tbaa !23
  %t251 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t254 = icmp ne i32 %t250, %t251
  br i1 %t254, label %bb120, label %bb121
bb49:
  %t256 = load i32, ptr %l164, !tbaa !23
  %t257 = load i64, ptr %l158, !tbaa !24
  %t258 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t259 = load ptr, ptr %t258, !tbaa !27
  %t260 = getelementptr i32, ptr %t259, i64 %t257
  store i32 %t256, ptr %t260, !tbaa !33
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t262 = load i64, ptr %l14, !tbaa !24
  %t264 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t265 = load ptr, ptr %t264, !tbaa !27
  %t266 = getelementptr i32, ptr %t265, i64 %t262
  %t267 = load i32, ptr %t266, !tbaa !33
  %t270 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t261, i32 %t267)
  store i1 %t270, ptr %l168
  br label %bb50
bb50:
  %t271 = load i1, ptr %l168, !tbaa !21
  %t272 = xor i1 %t271, true
  br i1 %t272, label %bb51, label %bb52
bb51:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/check:Checker", ptr %t274, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !29
  %t279 = getelementptr %"compiler/generic:Program", ptr %t277, i32 0, i32 2
  store ptr %t279, ptr %l173, !tbaa !29
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t281 = load i64, ptr %l14, !tbaa !24
  %t283 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !27
  %t285 = getelementptr i32, ptr %t284, i64 %t281
  %t286 = load i32, ptr %t285, !tbaa !33
  %t289 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t280, i32 %t286)
  store i32 %t289, ptr %l177
  br label %bb53
bb52:
  store i1 false, ptr %l170, !tbaa !21
  br label %bb55
bb53:
  %t290 = load ptr, ptr %l173, !tbaa !29
  %t291 = load i32, ptr %l177, !tbaa !23
  %t292 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t290, i32 %t291)
  store i32 %t292, ptr %l178
  br label %bb54
bb54:
  %t293 = load i32, ptr %l178
  %t295 = trunc i64 19 to i32
  %t296 = icmp eq i32 %t293, %t295
  store i1 %t296, ptr %l170, !tbaa !21
  br label %bb55
bb55:
  %t298 = load i1, ptr %l170, !tbaa !21
  br i1 %t298, label %bb56, label %bb57
bb56:
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t300 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t300, ptr %l183, !tbaa !27
  %t301 = load i64, ptr %l14, !tbaa !24
  %t303 = getelementptr { i64, ptr }, ptr %l183, i32 0, i32 1
  %t304 = load ptr, ptr %t303, !tbaa !27
  %t305 = getelementptr ptr, ptr %t304, i64 %t301
  %t306 = load ptr, ptr %t305, !tbaa !39
  %t308 = getelementptr %"compiler/ast:Param", ptr %t306, i32 0, i32 2
  %t309 = load ptr, ptr %t308, !tbaa !29
  %t312 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesTypeVar(ptr %v0, ptr %v1, ptr %t299, ptr %t309)
  store i1 %t312, ptr %l187
  br label %bb58
bb57:
  store i1 false, ptr %l181, !tbaa !21
  br label %bb59
bb58:
  %t313 = load i1, ptr %l187, !tbaa !21
  %t314 = xor i1 %t313, true
  store i1 %t314, ptr %l181, !tbaa !21
  br label %bb59
bb59:
  %t316 = load i1, ptr %l181, !tbaa !21
  br i1 %t316, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s6
  %t317 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t317, ptr %l189, !tbaa !27
  %t318 = load i64, ptr %l14, !tbaa !24
  %t320 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t321 = load ptr, ptr %t320, !tbaa !27
  %t322 = getelementptr ptr, ptr %t321, i64 %t318
  %t323 = load ptr, ptr %t322, !tbaa !39
  %t325 = getelementptr %"compiler/ast:Param", ptr %t323, i32 0, i32 0
  %t326 = getelementptr %"compiler/source:Span", ptr %t325, i32 0, i32 0
  %t327 = load i32, ptr %t326, !tbaa !23
  store i32 %t327, ptr %l192, !tbaa !23
  %t328 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t328, ptr %l193, !tbaa !27
  %t329 = load i64, ptr %l14, !tbaa !24
  %t331 = getelementptr { i64, ptr }, ptr %l193, i32 0, i32 1
  %t332 = load ptr, ptr %t331, !tbaa !27
  %t333 = getelementptr ptr, ptr %t332, i64 %t329
  %t334 = load ptr, ptr %t333, !tbaa !39
  %t336 = getelementptr %"compiler/ast:Param", ptr %t334, i32 0, i32 0
  %t337 = getelementptr %"compiler/source:Span", ptr %t336, i32 0, i32 0
  %t338 = load i32, ptr %t337, !tbaa !23
  store i32 %t338, ptr %l196, !tbaa !23
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t340 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t340, ptr %l198, !tbaa !27
  %t341 = load i64, ptr %l14, !tbaa !24
  %t343 = getelementptr { i64, ptr }, ptr %l198, i32 0, i32 1
  %t344 = load ptr, ptr %t343, !tbaa !27
  %t345 = getelementptr ptr, ptr %t344, i64 %t341
  %t346 = load ptr, ptr %t345, !tbaa !39
  %t348 = getelementptr %"compiler/ast:Param", ptr %t346, i32 0, i32 1
  %t349 = load i32, ptr %t348, !tbaa !23
  %t352 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t339, i32 %t349)
  store { i64, ptr } %t352, ptr %l202
  br label %bb62
bb61:
  br label %bb73
bb62:
  %t353 = load { i64, ptr }, ptr %l202, !tbaa !27
  %t354 = extractvalue { i64, ptr } %t353, 0
  %t356 = trunc i64 %t354 to i32
  %t357 = load i32, ptr %l196, !tbaa !23
  %t359 = add i32 %t357, %t356
  %t360 = load i32, ptr %l192, !tbaa !23
  %t362 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s6, i32 %t360, i32 %t359)
  store %"compiler/source:Span" %t362, ptr %l206
  br label %bb63
bb63:
  %t363 = load %"compiler/source:Span", ptr %l206
  %t364 = load ptr, ptr %l0, !tbaa !29
  store ptr %t364, ptr %l207, !tbaa !29
  store %"compiler/source:Span" %t363, ptr %l208
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t367 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t367, ptr %l210, !tbaa !27
  %t368 = load i64, ptr %l14, !tbaa !24
  %t370 = getelementptr { i64, ptr }, ptr %l210, i32 0, i32 1
  %t371 = load ptr, ptr %t370, !tbaa !27
  %t372 = getelementptr ptr, ptr %t371, i64 %t368
  %t373 = load ptr, ptr %t372, !tbaa !39
  %t375 = getelementptr %"compiler/ast:Param", ptr %t373, i32 0, i32 1
  %t376 = load i32, ptr %t375, !tbaa !23
  %t379 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s6, ptr %t366, i32 %t376)
  store { i64, ptr } %t379, ptr %l214
  br label %bb64
bb64:
  %t380 = load { i64, ptr }, ptr %l214, !tbaa !27
  %t381 = extractvalue { i64, ptr } %t380, 0
  %t382 = extractvalue { i64, ptr } %t380, 1
  %t383 = mul i64 %t381, 1
  %t384 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t383)
  call void @llvm.memcpy.p0.p0.i64(ptr %t384, ptr %t382, i64 %t383, i1 false)
  %t385 = insertvalue { i64, ptr } undef, i64 %t381, 0
  %t386 = insertvalue { i64, ptr } %t385, ptr %t384, 1
  store { i64, ptr } %t386, ptr %l215, !tbaa !27
  %t387 = load ptr, ptr %l0, !tbaa !29
  store ptr %t387, ptr %l216, !tbaa !29
  %t388 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t388, ptr %l217, !tbaa !27
  %t389 = load i64, ptr %l14, !tbaa !24
  %t391 = getelementptr { i64, ptr }, ptr %l217, i32 0, i32 1
  %t392 = load ptr, ptr %t391, !tbaa !27
  %t393 = getelementptr ptr, ptr %t392, i64 %t389
  %t394 = load ptr, ptr %t393, !tbaa !39
  %t396 = getelementptr %"compiler/ast:Param", ptr %t394, i32 0, i32 2
  %t397 = load ptr, ptr %t396, !tbaa !29
  store ptr %t397, ptr %l16, !tbaa !29
  %t399 = load ptr, ptr %l16, !tbaa !29
  %t401 = icmp eq ptr %t399, null
  br i1 %t401, label %bb65, label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_9765c214aae0d14_3e0d6126973403f8)
  unreachable
bb66:
  br label %bb67
bb67:
  %t403 = load ptr, ptr %l16, !tbaa !29
  %t405 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t403)
  store %"compiler/source:Span" %t405, ptr %l224
  br label %bb68
bb68:
  %t406 = load ptr, ptr %l216, !tbaa !29
  %t407 = load %"compiler/source:Span", ptr %l224
  %t408 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t406, %"compiler/source:Span" %t407)
  store { i64, ptr } %t408, ptr %l225
  br label %bb69
bb69:
  %t409 = load { i64, ptr }, ptr %l215, !tbaa !27
  %t410 = load { i64, ptr }, ptr %l225, !tbaa !27
  %t411 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayParamByValue(ptr %s6, ptr %v0, ptr %s6, { i64, ptr } %t409, { i64, ptr } %t410)
  store %"compiler/msgs:Msg" %t411, ptr %l226
  br label %bb70
bb70:
  %t412 = load ptr, ptr %l207, !tbaa !29
  %t413 = load %"compiler/source:Span", ptr %l208
  %t414 = load %"compiler/msgs:Msg", ptr %l226
  %t415 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t412, %"compiler/source:Span" %t413, %"compiler/msgs:Msg" %t414)
  store i64 %t415, ptr %l227
  br label %bb71
bb71:
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t417 = load %"compiler/source:Span", ptr %l1
  %t420 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t416, %"compiler/source:Span" %t417)
  store ptr %t420, ptr %l230
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t421 = load ptr, ptr %l230, !tbaa !29
  store ptr %t421, ptr %rv
  br label %ret
bb73:
  %t422 = load i32, ptr %l4, !tbaa !23
  %t423 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t426 = icmp ne i32 %t422, %t423
  br i1 %t426, label %bb74, label %bb75
bb74:
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t429 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t429, ptr %l236, !tbaa !27
  %t430 = load i64, ptr %l14, !tbaa !24
  %t432 = getelementptr { i64, ptr }, ptr %l236, i32 0, i32 1
  %t433 = load ptr, ptr %t432, !tbaa !27
  %t434 = getelementptr i32, ptr %t433, i64 %t430
  %t435 = load i32, ptr %t434, !tbaa !33
  %t438 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ementionsVar(ptr %v0, ptr %t428, i32 %t435, i64 -1)
  store i1 %t438, ptr %l239
  br label %bb76
bb75:
  store i1 false, ptr %l234, !tbaa !21
  br label %bb77
bb76:
  %t439 = load i1, ptr %l239, !tbaa !21
  %t440 = xor i1 %t439, true
  store i1 %t440, ptr %l234, !tbaa !21
  br label %bb77
bb77:
  %t442 = load i1, ptr %l234, !tbaa !21
  br i1 %t442, label %bb78, label %bb79
bb78:
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t445 = getelementptr %"compiler/check:Checker", ptr %t443, i32 0, i32 1
  %t446 = load ptr, ptr %t445, !tbaa !29
  %t448 = getelementptr %"compiler/generic:Program", ptr %t446, i32 0, i32 2
  %t449 = load i64, ptr %l14, !tbaa !24
  %t451 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t452 = load ptr, ptr %t451, !tbaa !27
  %t453 = getelementptr i32, ptr %t452, i64 %t449
  %t454 = load i32, ptr %t453, !tbaa !33
  %t455 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t455, ptr %l247, !tbaa !27
  %t456 = load i64, ptr %l14, !tbaa !24
  %t458 = getelementptr { i64, ptr }, ptr %l247, i32 0, i32 1
  %t459 = load ptr, ptr %t458, !tbaa !27
  %t460 = getelementptr i32, ptr %t459, i64 %t456
  %t461 = load i32, ptr %t460, !tbaa !33
  %t465 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t448, i32 %t454, i32 %t461)
  store i1 %t465, ptr %l250
  br label %bb80
bb79:
  store i1 false, ptr %l241, !tbaa !21
  br label %bb81
bb80:
  %t466 = load i1, ptr %l250, !tbaa !21
  %t467 = xor i1 %t466, true
  store i1 %t467, ptr %l241, !tbaa !21
  br label %bb81
bb81:
  %t469 = load i1, ptr %l241, !tbaa !21
  br i1 %t469, label %bb82, label %bb83
bb82:
  %t470 = load ptr, ptr %l0, !tbaa !29
  %t471 = load i64, ptr %l14, !tbaa !24
  %t473 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t474 = load ptr, ptr %t473, !tbaa !27
  %t475 = getelementptr i32, ptr %t474, i64 %t471
  %t476 = load i32, ptr %t475, !tbaa !33
  %t479 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t470, i32 %t476)
  store i1 %t479, ptr %l255
  br label %bb84
bb83:
  br label %bb119
bb84:
  %t480 = load ptr, ptr %l0, !tbaa !29
  %t481 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t481, ptr %l257, !tbaa !27
  %t482 = load i64, ptr %l14, !tbaa !24
  %t484 = getelementptr { i64, ptr }, ptr %l257, i32 0, i32 1
  %t485 = load ptr, ptr %t484, !tbaa !27
  %t486 = getelementptr i32, ptr %t485, i64 %t482
  %t487 = load i32, ptr %t486, !tbaa !33
  %t490 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t480, i32 %t487)
  store i1 %t490, ptr %l260
  br label %bb85
bb85:
  %t491 = load i1, ptr %l255, !tbaa !21
  %t492 = load i1, ptr %l260, !tbaa !21
  %t493 = icmp ne i1 %t491, %t492
  br i1 %t493, label %bb86, label %bb87
bb86:
  %t495 = load ptr, ptr %l0, !tbaa !29
  %t497 = getelementptr %"compiler/check:Checker", ptr %t495, i32 0, i32 1
  %t498 = load ptr, ptr %t497, !tbaa !29
  %t500 = getelementptr %"compiler/generic:Program", ptr %t498, i32 0, i32 2
  store ptr %t500, ptr %l265, !tbaa !29
  %t501 = load ptr, ptr %l0, !tbaa !29
  %t502 = load i64, ptr %l14, !tbaa !24
  %t504 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t505 = load ptr, ptr %t504, !tbaa !27
  %t506 = getelementptr i32, ptr %t505, i64 %t502
  %t507 = load i32, ptr %t506, !tbaa !33
  %t510 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t501, i32 %t507)
  store i32 %t510, ptr %l269
  br label %bb88
bb87:
  store i1 false, ptr %l262, !tbaa !21
  br label %bb91
bb88:
  %t511 = load ptr, ptr %l0, !tbaa !29
  %t512 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t512, ptr %l271, !tbaa !27
  %t513 = load i64, ptr %l14, !tbaa !24
  %t515 = getelementptr { i64, ptr }, ptr %l271, i32 0, i32 1
  %t516 = load ptr, ptr %t515, !tbaa !27
  %t517 = getelementptr i32, ptr %t516, i64 %t513
  %t518 = load i32, ptr %t517, !tbaa !33
  %t521 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t511, i32 %t518)
  store i32 %t521, ptr %l274
  br label %bb89
bb89:
  %t522 = load ptr, ptr %l265, !tbaa !29
  %t523 = load i32, ptr %l269, !tbaa !23
  %t524 = load i32, ptr %l274, !tbaa !23
  %t525 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t522, i32 %t523, i32 %t524)
  store i1 %t525, ptr %l275
  br label %bb90
bb90:
  %t526 = load i1, ptr %l275, !tbaa !21
  store i1 %t526, ptr %l262, !tbaa !21
  br label %bb91
bb91:
  %t527 = load i1, ptr %l262, !tbaa !21
  br i1 %t527, label %bb92, label %bb93
bb92:
  store %olang.scope zeroinitializer, ptr %s8
  %t528 = load ptr, ptr %l0, !tbaa !29
  %t529 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t529, ptr %l277, !tbaa !27
  %t530 = load i64, ptr %l14, !tbaa !24
  %t532 = getelementptr { i64, ptr }, ptr %l277, i32 0, i32 1
  %t533 = load ptr, ptr %t532, !tbaa !27
  %t534 = getelementptr ptr, ptr %t533, i64 %t530
  %t535 = load ptr, ptr %t534, !tbaa !39
  %t537 = getelementptr %"compiler/ast:Param", ptr %t535, i32 0, i32 0
  %t538 = load %"compiler/source:Span", ptr %t537
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s8, ptr %t528, %"compiler/source:Span" %t538, { i64, ptr } { i64 74, ptr @.d41 })
  br label %bb94
bb93:
  br label %bb96
bb94:
  %t541 = load ptr, ptr %l0, !tbaa !29
  %t542 = load %"compiler/source:Span", ptr %l1
  %t545 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t541, %"compiler/source:Span" %t542)
  store ptr %t545, ptr %l283
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t546 = load ptr, ptr %l283, !tbaa !29
  store ptr %t546, ptr %rv
  br label %ret
bb96:
  %t547 = load ptr, ptr %l0, !tbaa !29
  %t548 = load i64, ptr %l14, !tbaa !24
  %t550 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t551 = load ptr, ptr %t550, !tbaa !27
  %t552 = getelementptr i32, ptr %t551, i64 %t548
  %t553 = load i32, ptr %t552, !tbaa !33
  %t556 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t547, i32 %t553)
  store i1 %t556, ptr %l287
  br label %bb97
bb97:
  %t557 = load i1, ptr %l287, !tbaa !21
  br i1 %t557, label %bb98, label %bb99
bb98:
  %t558 = load ptr, ptr %l0, !tbaa !29
  %t559 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t559, ptr %l290, !tbaa !27
  %t560 = load i64, ptr %l14, !tbaa !24
  %t562 = getelementptr { i64, ptr }, ptr %l290, i32 0, i32 1
  %t563 = load ptr, ptr %t562, !tbaa !27
  %t564 = getelementptr i32, ptr %t563, i64 %t560
  %t565 = load i32, ptr %t564, !tbaa !33
  %t568 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t558, i32 %t565)
  store i1 %t568, ptr %l293
  br label %bb100
bb99:
  store i1 false, ptr %l288, !tbaa !21
  br label %bb101
bb100:
  %t569 = load i1, ptr %l293, !tbaa !21
  store i1 %t569, ptr %l288, !tbaa !21
  br label %bb101
bb101:
  %t570 = load i1, ptr %l288, !tbaa !21
  br i1 %t570, label %bb102, label %bb103
bb102:
  %t571 = load ptr, ptr %l0, !tbaa !29
  %t573 = getelementptr %"compiler/check:Checker", ptr %t571, i32 0, i32 1
  %t574 = load ptr, ptr %t573, !tbaa !29
  %t576 = getelementptr %"compiler/generic:Program", ptr %t574, i32 0, i32 2
  store ptr %t576, ptr %l297, !tbaa !29
  %t577 = load ptr, ptr %l0, !tbaa !29
  %t578 = load i64, ptr %l14, !tbaa !24
  %t580 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t581 = load ptr, ptr %t580, !tbaa !27
  %t582 = getelementptr i32, ptr %t581, i64 %t578
  %t583 = load i32, ptr %t582, !tbaa !33
  %t586 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t577, i32 %t583)
  store i32 %t586, ptr %l301
  br label %bb104
bb103:
  store i1 false, ptr %l294, !tbaa !21
  br label %bb107
bb104:
  %t587 = load ptr, ptr %l0, !tbaa !29
  %t588 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t588, ptr %l303, !tbaa !27
  %t589 = load i64, ptr %l14, !tbaa !24
  %t591 = getelementptr { i64, ptr }, ptr %l303, i32 0, i32 1
  %t592 = load ptr, ptr %t591, !tbaa !27
  %t593 = getelementptr i32, ptr %t592, i64 %t589
  %t594 = load i32, ptr %t593, !tbaa !33
  %t597 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t587, i32 %t594)
  store i32 %t597, ptr %l306
  br label %bb105
bb105:
  %t598 = load ptr, ptr %l297, !tbaa !29
  %t599 = load i32, ptr %l301, !tbaa !23
  %t600 = load i32, ptr %l306, !tbaa !23
  %t601 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t598, i32 %t599, i32 %t600)
  store i1 %t601, ptr %l307
  br label %bb106
bb106:
  %t602 = load i1, ptr %l307, !tbaa !21
  store i1 %t602, ptr %l294, !tbaa !21
  br label %bb107
bb107:
  %t603 = load i1, ptr %l294, !tbaa !21
  br i1 %t603, label %bb108, label %bb109
bb108:
  %t604 = load ptr, ptr %l0, !tbaa !29
  %t606 = getelementptr %"compiler/check:Checker", ptr %t604, i32 0, i32 1
  %t607 = load ptr, ptr %t606, !tbaa !29
  %t609 = getelementptr %"compiler/generic:Program", ptr %t607, i32 0, i32 2
  %t610 = load i64, ptr %l14, !tbaa !24
  %t612 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t613 = load ptr, ptr %t612, !tbaa !27
  %t614 = getelementptr i32, ptr %t613, i64 %t610
  %t615 = load i32, ptr %t614, !tbaa !33
  %t618 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t609, i32 %t615)
  store i64 %t618, ptr %l314
  br label %bb110
bb109:
  store i1 false, ptr %l308, !tbaa !21
  br label %bb111
bb110:
  %t619 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t620 = load i64, ptr %l314, !tbaa !24
  %t622 = and i64 %t620, %t619
  %t624 = icmp eq i64 %t622, 0
  store i1 %t624, ptr %l308, !tbaa !21
  br label %bb111
bb111:
  %t626 = load i1, ptr %l308, !tbaa !21
  %t629 = xor i1 %t626, true
  br i1 %t629, label %bb112, label %bb113
bb112:
  store %olang.scope zeroinitializer, ptr %s9
  %t631 = load ptr, ptr %l0, !tbaa !29
  store ptr %t631, ptr %l320, !tbaa !29
  %t632 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t632, ptr %l321, !tbaa !27
  %t633 = load i64, ptr %l14, !tbaa !24
  %t635 = getelementptr { i64, ptr }, ptr %l321, i32 0, i32 1
  %t636 = load ptr, ptr %t635, !tbaa !27
  %t637 = getelementptr ptr, ptr %t636, i64 %t633
  %t638 = load ptr, ptr %t637, !tbaa !39
  %t640 = getelementptr %"compiler/ast:Param", ptr %t638, i32 0, i32 0
  %t641 = load %"compiler/source:Span", ptr %t640
  store %"compiler/source:Span" %t641, ptr %l324
  %t642 = load ptr, ptr %l0, !tbaa !29
  %t643 = load i32, ptr %l4, !tbaa !23
  %t646 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t642, i32 %t643)
  store { i64, ptr } %t646, ptr %l327
  br label %bb114
bb113:
  br label %bb118
bb114:
  %t647 = load { i64, ptr }, ptr %l327, !tbaa !27
  %t648 = extractvalue { i64, ptr } %t647, 0
  %t649 = extractvalue { i64, ptr } %t647, 1
  %t650 = mul i64 %t648, 1
  %t651 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t650)
  call void @llvm.memcpy.p0.p0.i64(ptr %t651, ptr %t649, i64 %t650, i1 false)
  %t652 = insertvalue { i64, ptr } undef, i64 %t648, 0
  %t653 = insertvalue { i64, ptr } %t652, ptr %t651, 1
  %t655 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaSignature(ptr %s9, ptr %s9, { i64, ptr } %t653)
  store %"compiler/msgs:Msg" %t655, ptr %l329
  br label %bb115
bb115:
  %t656 = load ptr, ptr %l320, !tbaa !29
  %t657 = load %"compiler/source:Span", ptr %l324
  %t658 = load %"compiler/msgs:Msg", ptr %l329
  %t659 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s9, ptr %t656, %"compiler/source:Span" %t657, %"compiler/msgs:Msg" %t658)
  store i64 %t659, ptr %l330
  br label %bb116
bb116:
  %t660 = load ptr, ptr %l0, !tbaa !29
  %t661 = load %"compiler/source:Span", ptr %l1
  %t664 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t660, %"compiler/source:Span" %t661)
  store ptr %t664, ptr %l333
  br label %bb117
bb117:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t665 = load ptr, ptr %l333, !tbaa !29
  store ptr %t665, ptr %rv
  br label %ret
bb118:
  br label %bb119
bb119:
  br label %bb131
bb120:
  %t666 = load ptr, ptr %l0, !tbaa !29
  %t667 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t667, ptr %l339, !tbaa !27
  %t668 = load i64, ptr %l14, !tbaa !24
  %t670 = getelementptr { i64, ptr }, ptr %l339, i32 0, i32 1
  %t671 = load ptr, ptr %t670, !tbaa !27
  %t672 = getelementptr i32, ptr %t671, i64 %t668
  %t673 = load i32, ptr %t672, !tbaa !33
  %t676 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ementionsVar(ptr %v0, ptr %t666, i32 %t673, i64 -1)
  store i1 %t676, ptr %l342
  br label %bb122
bb121:
  store i1 false, ptr %l337, !tbaa !21
  br label %bb123
bb122:
  %t677 = load i1, ptr %l342, !tbaa !21
  %t678 = xor i1 %t677, true
  store i1 %t678, ptr %l337, !tbaa !21
  br label %bb123
bb123:
  %t680 = load i1, ptr %l337, !tbaa !21
  br i1 %t680, label %bb124, label %bb125
bb124:
  %t681 = load i64, ptr %l14, !tbaa !24
  %t682 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t682, ptr %l345, !tbaa !27
  %t683 = load i64, ptr %l14, !tbaa !24
  %t685 = getelementptr { i64, ptr }, ptr %l345, i32 0, i32 1
  %t686 = load ptr, ptr %t685, !tbaa !27
  %t687 = getelementptr i32, ptr %t686, i64 %t683
  %t688 = load i32, ptr %t687, !tbaa !33
  %t691 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t692 = load ptr, ptr %t691, !tbaa !27
  %t693 = getelementptr i32, ptr %t692, i64 %t681
  store i32 %t688, ptr %t693, !tbaa !33
  br label %bb130
bb125:
  store %olang.scope zeroinitializer, ptr %s12
  %t694 = load ptr, ptr %l0, !tbaa !29
  store ptr %t694, ptr %l348, !tbaa !29
  %t695 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t695, ptr %l349, !tbaa !27
  %t696 = load i64, ptr %l14, !tbaa !24
  %t698 = getelementptr { i64, ptr }, ptr %l349, i32 0, i32 1
  %t699 = load ptr, ptr %t698, !tbaa !27
  %t700 = getelementptr ptr, ptr %t699, i64 %t696
  %t701 = load ptr, ptr %t700, !tbaa !39
  %t703 = getelementptr %"compiler/ast:Param", ptr %t701, i32 0, i32 0
  %t704 = load %"compiler/source:Span", ptr %t703
  store %"compiler/source:Span" %t704, ptr %l352
  %t705 = load ptr, ptr %l0, !tbaa !29
  %t706 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t706, ptr %l354, !tbaa !27
  %t707 = load i64, ptr %l14, !tbaa !24
  %t709 = getelementptr { i64, ptr }, ptr %l354, i32 0, i32 1
  %t710 = load ptr, ptr %t709, !tbaa !27
  %t711 = getelementptr ptr, ptr %t710, i64 %t707
  %t712 = load ptr, ptr %t711, !tbaa !39
  %t714 = getelementptr %"compiler/ast:Param", ptr %t712, i32 0, i32 1
  %t715 = load i32, ptr %t714, !tbaa !23
  %t718 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s12, ptr %t705, i32 %t715)
  store { i64, ptr } %t718, ptr %l358
  br label %bb126
bb126:
  %t719 = load { i64, ptr }, ptr %l358, !tbaa !27
  %t720 = extractvalue { i64, ptr } %t719, 0
  %t721 = extractvalue { i64, ptr } %t719, 1
  %t722 = mul i64 %t720, 1
  %t723 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t722)
  call void @llvm.memcpy.p0.p0.i64(ptr %t723, ptr %t721, i64 %t722, i1 false)
  %t724 = insertvalue { i64, ptr } undef, i64 %t720, 0
  %t725 = insertvalue { i64, ptr } %t724, ptr %t723, 1
  %t727 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaParamUntyped(ptr %s12, ptr %s12, { i64, ptr } %t725)
  store %"compiler/msgs:Msg" %t727, ptr %l360
  br label %bb127
bb127:
  %t728 = load ptr, ptr %l348, !tbaa !29
  %t729 = load %"compiler/source:Span", ptr %l352
  %t730 = load %"compiler/msgs:Msg", ptr %l360
  %t731 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s12, ptr %t728, %"compiler/source:Span" %t729, %"compiler/msgs:Msg" %t730)
  store i64 %t731, ptr %l361
  br label %bb128
bb128:
  %t732 = load ptr, ptr %l0, !tbaa !29
  %t733 = load %"compiler/source:Span", ptr %l1
  %t736 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t732, %"compiler/source:Span" %t733)
  store ptr %t736, ptr %l364
  br label %bb129
bb129:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t737 = load ptr, ptr %l364, !tbaa !29
  store ptr %t737, ptr %rv
  br label %ret
bb130:
  br label %bb131
bb131:
  call void @__olang_scope_close(ptr %s4)
  br label %bb132
bb132:
  %t738 = load i64, ptr %l13, !tbaa !24
  %t740 = add i64 %t738, 1
  store i64 %t740, ptr %l13, !tbaa !24
  br label %bb43
bb133:
  store i1 false, ptr %l18, !tbaa !21
  %t742 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t742, ptr %l19, !tbaa !23
  %t744 = load ptr, ptr %l2, !tbaa !29
  %t746 = getelementptr %"compiler/ast:Func", ptr %t744, i32 0, i32 3
  %t747 = load ptr, ptr %t746, !tbaa !29
  %t749 = getelementptr %"compiler/ast:Sig", ptr %t747, i32 0, i32 1
  %t750 = load { i64, ptr }, ptr %t749, !tbaa !27
  %t752 = extractvalue { i64, ptr } %t750, 0
  %t754 = icmp sgt i64 %t752, 0
  br i1 %t754, label %bb134, label %bb135
bb134:
  store %olang.scope zeroinitializer, ptr %s14
  %t756 = load ptr, ptr %l2, !tbaa !29
  %t758 = getelementptr %"compiler/ast:Func", ptr %t756, i32 0, i32 3
  %t759 = load ptr, ptr %t758, !tbaa !29
  %t761 = getelementptr %"compiler/ast:Sig", ptr %t759, i32 0, i32 1
  %t762 = load { i64, ptr }, ptr %t761, !tbaa !27
  %t764 = extractvalue { i64, ptr } %t762, 0
  store i64 %t764, ptr %l376, !tbaa !24
  %t765 = load i64, ptr %l376, !tbaa !24
  %t766 = icmp sge i64 %t765, 0
  br i1 %t766, label %bb136, label %bb137
bb135:
  %t768 = load i32, ptr %l4, !tbaa !23
  %t769 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t772 = icmp ne i32 %t768, %t769
  br i1 %t772, label %bb158, label %bb159
bb136:
  %t774 = load i64, ptr %l376, !tbaa !24
  %t775 = icmp sle i64 %t774, 2305843009213693951
  br i1 %t775, label %bb138, label %bb139
bb137:
  call void @__olang_check_failed(ptr @olang_loc_5a62442bf09cb677_66ce856a58ef9453)
  unreachable
bb138:
  %t777 = load i64, ptr %l376, !tbaa !24
  %t778 = mul i64 %t777, 4
  %t779 = call ptr @__olang_scope_alloc_zeroed(ptr %s14, i64 %t778)
  %t780 = insertvalue { i64, ptr } undef, i64 %t777, 0
  %t781 = insertvalue { i64, ptr } %t780, ptr %t779, 1
  store { i64, ptr } %t781, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t783 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t785 = extractvalue { i64, ptr } %t783, 0
  store i64 %t785, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t787 = load i64, ptr %l22, !tbaa !24
  %t788 = load i64, ptr %l21, !tbaa !24
  %t791 = icmp sgt i64 %t787, %t788
  br i1 %t791, label %bb140, label %bb141
bb139:
  call void @__olang_check_failed(ptr @olang_loc_5a62442bf09cb677_66ce856a58ef9453)
  unreachable
bb140:
  %t793 = load i64, ptr %l23, !tbaa !24
  %t795 = icmp sgt i64 %t793, 0
  br i1 %t795, label %bb142, label %bb143
bb141:
  store i64 0, ptr %l385, !tbaa !24
  br label %bb145
bb142:
  %t797 = load i64, ptr %l22, !tbaa !24
  %t798 = load i64, ptr %l21, !tbaa !24
  %t801 = sub i64 %t797, %t798
  %t802 = load i64, ptr %l23, !tbaa !24
  %t805 = add i64 %t801, %t802
  %t807 = sub i64 %t805, 1
  %t808 = load i64, ptr %l23, !tbaa !24
  %t811 = sdiv i64 %t807, %t808
  store i64 %t811, ptr %l388, !tbaa !24
  br label %bb144
bb143:
  store i64 0, ptr %l388, !tbaa !24
  br label %bb144
bb144:
  %t813 = load i64, ptr %l388, !tbaa !24
  store i64 %t813, ptr %l385, !tbaa !24
  br label %bb145
bb145:
  %t814 = load i64, ptr %l385, !tbaa !24
  store i64 %t814, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb146
bb146:
  store %olang.scope zeroinitializer, ptr %s16
  %t815 = load i64, ptr %l25, !tbaa !24
  %t816 = load i64, ptr %l24, !tbaa !24
  %t819 = icmp slt i64 %t815, %t816
  %t821 = xor i1 %t819, true
  br i1 %t821, label %bb147, label %bb148
bb147:
  call void @__olang_scope_close(ptr %s16)
  br label %bb152
bb148:
  br label %bb149
bb149:
  %t823 = load i64, ptr %l21, !tbaa !24
  %t824 = load i64, ptr %l25, !tbaa !24
  %t825 = load i64, ptr %l23, !tbaa !24
  %t828 = mul i64 %t824, %t825
  %t831 = add i64 %t823, %t828
  store i64 %t831, ptr %l26, !tbaa !24
  %t833 = load i64, ptr %l26, !tbaa !24
  store i64 %t833, ptr %l406, !tbaa !24
  %t834 = load ptr, ptr %l0, !tbaa !29
  %t835 = load ptr, ptr %l2, !tbaa !29
  %t837 = getelementptr %"compiler/ast:Func", ptr %t835, i32 0, i32 3
  %t838 = load ptr, ptr %t837, !tbaa !29
  %t840 = getelementptr %"compiler/ast:Sig", ptr %t838, i32 0, i32 1
  %t841 = load { i64, ptr }, ptr %t840, !tbaa !27
  store { i64, ptr } %t841, ptr %l410, !tbaa !27
  %t842 = load i64, ptr %l26, !tbaa !24
  %t844 = getelementptr { i64, ptr }, ptr %l410, i32 0, i32 1
  %t845 = load ptr, ptr %t844, !tbaa !27
  %t846 = getelementptr ptr, ptr %t845, i64 %t842
  %t847 = load ptr, ptr %t846, !tbaa !39
  %t851 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %t834, ptr %t847)
  store i32 %t851, ptr %l414
  br label %bb150
bb150:
  %t852 = load i32, ptr %l414, !tbaa !23
  %t853 = load i64, ptr %l406, !tbaa !24
  %t854 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t855 = load ptr, ptr %t854, !tbaa !27
  %t856 = getelementptr i32, ptr %t855, i64 %t853
  store i32 %t852, ptr %t856, !tbaa !33
  call void @__olang_scope_close(ptr %s16)
  br label %bb151
bb151:
  %t857 = load i64, ptr %l25, !tbaa !24
  %t859 = add i64 %t857, 1
  store i64 %t859, ptr %l25, !tbaa !24
  br label %bb146
bb152:
  %t861 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t863 = extractvalue { i64, ptr } %t861, 0
  %t865 = icmp eq i64 %t863, 1
  br i1 %t865, label %bb153, label %bb154
bb153:
  %t867 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t868 = load ptr, ptr %t867, !tbaa !27
  %t869 = getelementptr i32, ptr %t868, i64 0
  %t870 = load i32, ptr %t869, !tbaa !33
  store i32 %t870, ptr %l420, !tbaa !23
  br label %bb157
bb154:
  %t872 = load ptr, ptr %l0, !tbaa !29
  %t874 = getelementptr %"compiler/check:Checker", ptr %t872, i32 0, i32 1
  %t875 = load ptr, ptr %t874, !tbaa !29
  %t877 = getelementptr %"compiler/generic:Program", ptr %t875, i32 0, i32 2
  store ptr %t877, ptr %l424, !tbaa !29
  %t878 = load ptr, ptr %l0, !tbaa !29
  %t880 = getelementptr %"compiler/check:Checker", ptr %t878, i32 0, i32 1
  %t881 = load ptr, ptr %t880, !tbaa !29
  %t883 = getelementptr %"compiler/generic:Program", ptr %t881, i32 0, i32 2
  %t884 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t887 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s14, ptr %t883, { i64, ptr } %t884)
  store i32 %t887, ptr %l429
  br label %bb155
bb155:
  %t888 = load ptr, ptr %l424, !tbaa !29
  %t889 = load i32, ptr %l429, !tbaa !23
  %t890 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %t888, i32 %t889)
  store i32 %t890, ptr %l430
  br label %bb156
bb156:
  %t891 = load i32, ptr %l430, !tbaa !23
  store i32 %t891, ptr %l420, !tbaa !23
  br label %bb157
bb157:
  %t892 = load i32, ptr %l420, !tbaa !23
  store i32 %t892, ptr %l19, !tbaa !23
  call void @__olang_scope_close(ptr %s14)
  br label %bb167
bb158:
  %t893 = load ptr, ptr %l0, !tbaa !29
  store ptr %t893, ptr %l435, !tbaa !29
  %t894 = load ptr, ptr %l0, !tbaa !29
  %t896 = getelementptr %"compiler/check:Checker", ptr %t894, i32 0, i32 1
  %t897 = load ptr, ptr %t896, !tbaa !29
  %t899 = getelementptr %"compiler/generic:Program", ptr %t897, i32 0, i32 2
  %t900 = load i32, ptr %l4, !tbaa !23
  %t903 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t899, i32 %t900)
  store i32 %t903, ptr %l440
  br label %bb160
bb159:
  store i1 false, ptr %l434, !tbaa !21
  br label %bb162
bb160:
  %t904 = load ptr, ptr %l435, !tbaa !29
  %t905 = load i32, ptr %l440, !tbaa !23
  %t906 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ementionsVar(ptr %v0, ptr %t904, i32 %t905, i64 -1)
  store i1 %t906, ptr %l441
  br label %bb161
bb161:
  %t907 = load i1, ptr %l441, !tbaa !21
  %t908 = xor i1 %t907, true
  store i1 %t908, ptr %l434, !tbaa !21
  br label %bb162
bb162:
  %t910 = load i1, ptr %l434, !tbaa !21
  br i1 %t910, label %bb163, label %bb164
bb163:
  %t911 = load ptr, ptr %l0, !tbaa !29
  %t913 = getelementptr %"compiler/check:Checker", ptr %t911, i32 0, i32 1
  %t914 = load ptr, ptr %t913, !tbaa !29
  %t916 = getelementptr %"compiler/generic:Program", ptr %t914, i32 0, i32 2
  %t917 = load i32, ptr %l4, !tbaa !23
  %t920 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t916, i32 %t917)
  store i32 %t920, ptr %l447
  br label %bb165
bb164:
  store i1 true, ptr %l18, !tbaa !21
  %t921 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t921, ptr %l19, !tbaa !23
  br label %bb166
bb165:
  %t923 = load i32, ptr %l447, !tbaa !23
  store i32 %t923, ptr %l19, !tbaa !23
  br label %bb166
bb166:
  br label %bb167
bb167:
  store i32 0, ptr %l27, !tbaa !23
  store i1 false, ptr %l28, !tbaa !21
  %t924 = load ptr, ptr %l2, !tbaa !29
  %t926 = getelementptr %"compiler/ast:Func", ptr %t924, i32 0, i32 3
  %t927 = load ptr, ptr %t926, !tbaa !29
  %t929 = getelementptr %"compiler/ast:Sig", ptr %t927, i32 0, i32 2
  %t930 = load i1, ptr %t929, !tbaa !21
  br i1 %t930, label %bb168, label %bb169
bb168:
  %t932 = load ptr, ptr %l2, !tbaa !29
  %t934 = getelementptr %"compiler/ast:Func", ptr %t932, i32 0, i32 3
  %t935 = load ptr, ptr %t934, !tbaa !29
  %t937 = getelementptr %"compiler/ast:Sig", ptr %t935, i32 0, i32 3
  %t938 = load { i64, ptr }, ptr %t937, !tbaa !27
  %t940 = extractvalue { i64, ptr } %t938, 0
  %t942 = icmp eq i64 %t940, 0
  store i1 %t942, ptr %l452, !tbaa !21
  br label %bb170
bb169:
  store i1 false, ptr %l452, !tbaa !21
  br label %bb170
bb170:
  %t944 = load i1, ptr %l452, !tbaa !21
  br i1 %t944, label %bb171, label %bb172
bb171:
  %t945 = load i32, ptr %l4, !tbaa !23
  %t946 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t949 = icmp eq i32 %t945, %t946
  store i1 %t949, ptr %l458, !tbaa !21
  br label %bb173
bb172:
  store i1 false, ptr %l458, !tbaa !21
  br label %bb173
bb173:
  %t951 = load i1, ptr %l458, !tbaa !21
  br i1 %t951, label %bb174, label %bb175
bb174:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb199
bb175:
  %t952 = load ptr, ptr %l2, !tbaa !29
  %t954 = getelementptr %"compiler/ast:Func", ptr %t952, i32 0, i32 3
  %t955 = load ptr, ptr %t954, !tbaa !29
  %t957 = getelementptr %"compiler/ast:Sig", ptr %t955, i32 0, i32 2
  %t958 = load i1, ptr %t957, !tbaa !21
  br i1 %t958, label %bb176, label %bb177
bb176:
  store %olang.scope zeroinitializer, ptr %s23
  %t960 = load ptr, ptr @__olang_prog_scope
  %t961 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %t960)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t961, ptr %l465
  br label %bb178
bb177:
  %t962 = load i32, ptr %l4, !tbaa !23
  %t963 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t966 = icmp ne i32 %t962, %t963
  br i1 %t966, label %bb194, label %bb195
bb178:
  %t968 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l465
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t968, ptr %l29
  %t969 = load ptr, ptr %l2, !tbaa !29
  %t971 = getelementptr %"compiler/ast:Func", ptr %t969, i32 0, i32 3
  %t972 = load ptr, ptr %t971, !tbaa !29
  %t974 = getelementptr %"compiler/ast:Sig", ptr %t972, i32 0, i32 3
  %t975 = load { i64, ptr }, ptr %t974, !tbaa !27
  %t977 = extractvalue { i64, ptr } %t975, 0
  %t979 = icmp eq i64 %t977, 0
  br i1 %t979, label %bb179, label %bb180
bb179:
  %t981 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s23, ptr %l29, i32 %t981)
  br label %bb181
bb180:
  br label %bb182
bb181:
  br label %bb182
bb182:
  %t984 = load ptr, ptr %l2, !tbaa !29
  %t986 = getelementptr %"compiler/ast:Func", ptr %t984, i32 0, i32 3
  %t987 = load ptr, ptr %t986, !tbaa !29
  %t989 = getelementptr %"compiler/ast:Sig", ptr %t987, i32 0, i32 3
  %t990 = load { i64, ptr }, ptr %t989, !tbaa !27
  store { i64, ptr } %t990, ptr %l30, !tbaa !27
  store i64 0, ptr %l31, !tbaa !24
  %t992 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t994 = extractvalue { i64, ptr } %t992, 0
  store i64 %t994, ptr %l32, !tbaa !24
  br label %bb183
bb183:
  store %olang.scope zeroinitializer, ptr %s26
  %t996 = load i64, ptr %l31, !tbaa !24
  %t997 = load i64, ptr %l32, !tbaa !24
  %t1000 = icmp slt i64 %t996, %t997
  %t1002 = xor i1 %t1000, true
  br i1 %t1002, label %bb184, label %bb185
bb184:
  call void @__olang_scope_close(ptr %s26)
  br label %bb191
bb185:
  br label %bb186
bb186:
  %t1004 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t1004, ptr %l482, !tbaa !27
  %t1005 = load i64, ptr %l31, !tbaa !24
  %t1007 = getelementptr { i64, ptr }, ptr %l482, i32 0, i32 1
  %t1008 = load ptr, ptr %t1007, !tbaa !27
  %t1009 = getelementptr ptr, ptr %t1008, i64 %t1005
  %t1010 = load ptr, ptr %t1009, !tbaa !39
  store ptr %t1010, ptr %l33, !tbaa !29
  store ptr %l29, ptr %l485, !tbaa !29
  %t1012 = load ptr, ptr %l0, !tbaa !29
  %t1014 = getelementptr %"compiler/check:Checker", ptr %t1012, i32 0, i32 1
  %t1015 = load ptr, ptr %t1014, !tbaa !29
  store ptr %t1015, ptr %l487, !tbaa !29
  %t1016 = load ptr, ptr %l0, !tbaa !29
  %t1018 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1016)
  store ptr %t1018, ptr %l489
  br label %bb187
bb187:
  %t1019 = load ptr, ptr %l489, !tbaa !29
  %t1021 = getelementptr %"compiler/check:frame", ptr %t1019, i32 0, i32 4
  %t1022 = load ptr, ptr %l33, !tbaa !29
  %t1023 = load ptr, ptr %l487, !tbaa !29
  %t1026 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorType(ptr %v0, ptr %v0, ptr %v1, ptr %t1023, ptr %t1021, ptr %t1022)
  store i32 %t1026, ptr %l493
  br label %bb188
bb188:
  %t1027 = load ptr, ptr %l485, !tbaa !29
  %t1028 = load i32, ptr %l493, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s23, ptr %t1027, i32 %t1028)
  br label %bb189
bb189:
  call void @__olang_scope_close(ptr %s26)
  br label %bb190
bb190:
  %t1029 = load i64, ptr %l31, !tbaa !24
  %t1031 = add i64 %t1029, 1
  store i64 %t1031, ptr %l31, !tbaa !24
  br label %bb183
bb191:
  %t1033 = load ptr, ptr %l0, !tbaa !29
  %t1035 = getelementptr %"compiler/check:Checker", ptr %t1033, i32 0, i32 1
  %t1036 = load ptr, ptr %t1035, !tbaa !29
  %t1038 = getelementptr %"compiler/generic:Program", ptr %t1036, i32 0, i32 2
  store ptr %t1038, ptr %l498, !tbaa !29
  %t1040 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eToAr_H9d0f958437b2bc29fe1d416dfb9901d7(ptr %s23, ptr %s23, ptr %l29)
  store { i64, ptr } %t1040, ptr %l500
  br label %bb192
bb192:
  %t1041 = load ptr, ptr %l498, !tbaa !29
  %t1042 = load { i64, ptr }, ptr %l500, !tbaa !27
  %t1043 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s23, ptr %t1041, { i64, ptr } %t1042)
  store i32 %t1043, ptr %l501
  br label %bb193
bb193:
  %t1044 = load i32, ptr %l501, !tbaa !23
  store i32 %t1044, ptr %l27, !tbaa !23
  call void @__olang_scope_close(ptr %s23)
  br label %bb198
bb194:
  %t1045 = load ptr, ptr %l0, !tbaa !29
  %t1047 = getelementptr %"compiler/check:Checker", ptr %t1045, i32 0, i32 1
  %t1048 = load ptr, ptr %t1047, !tbaa !29
  %t1050 = getelementptr %"compiler/generic:Program", ptr %t1048, i32 0, i32 2
  %t1051 = load i32, ptr %l4, !tbaa !23
  %t1054 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t1050, i32 %t1051)
  store i32 %t1054, ptr %l509
  br label %bb196
bb195:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb197
bb196:
  %t1055 = load i32, ptr %l509, !tbaa !23
  store i32 %t1055, ptr %l27, !tbaa !23
  br label %bb197
bb197:
  br label %bb198
bb198:
  br label %bb199
bb199:
  %t1056 = load i32, ptr %l4, !tbaa !23
  %t1057 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t1060 = icmp ne i32 %t1056, %t1057
  br i1 %t1060, label %bb200, label %bb201
bb200:
  %t1062 = load ptr, ptr %l0, !tbaa !29
  %t1064 = getelementptr %"compiler/check:Checker", ptr %t1062, i32 0, i32 1
  %t1065 = load ptr, ptr %t1064, !tbaa !29
  %t1067 = getelementptr %"compiler/generic:Program", ptr %t1065, i32 0, i32 2
  %t1068 = load i32, ptr %l4, !tbaa !23
  %t1071 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t1067, i32 %t1068)
  store i32 %t1071, ptr %l518
  br label %bb202
bb201:
  store i32 0, ptr %l513, !tbaa !23
  br label %bb203
bb202:
  %t1072 = load i32, ptr %l518, !tbaa !23
  store i32 %t1072, ptr %l513, !tbaa !23
  br label %bb203
bb203:
  %t1073 = load i32, ptr %l513, !tbaa !23
  store i32 %t1073, ptr %l34, !tbaa !23
  %t1074 = load ptr, ptr %l0, !tbaa !29
  %t1076 = getelementptr %"compiler/check:Checker", ptr %t1074, i32 0, i32 1
  %t1077 = load ptr, ptr %t1076, !tbaa !29
  %t1079 = getelementptr %"compiler/generic:Program", ptr %t1077, i32 0, i32 2
  %t1080 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t1083 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t1079, { i64, ptr } %t1080)
  store i32 %t1083, ptr %l523
  br label %bb204
bb204:
  %t1084 = load i32, ptr %l523, !tbaa !23
  store i32 %t1084, ptr %l35, !tbaa !23
  %t1085 = load ptr, ptr %l0, !tbaa !29
  %t1087 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1085)
  store ptr %t1087, ptr %l525
  br label %bb205
bb205:
  %t1088 = load ptr, ptr %l525, !tbaa !29
  store ptr %t1088, ptr %l36, !tbaa !29
  %t1089 = load ptr, ptr %l0, !tbaa !29
  %t1091 = getelementptr %"compiler/check:Checker", ptr %t1089, i32 0, i32 12
  %t1093 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_H2d42092ce658fb6cce0104fa754a4e33(ptr %v0, ptr %t1091)
  store i64 %t1093, ptr %l528
  br label %bb206
bb206:
  %t1094 = load i64, ptr %l528, !tbaa !24
  %t1095 = sub i64 %t1094, 1
  store i64 %t1095, ptr %l37, !tbaa !24
  %t1097 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1097, ptr %l530, !tbaa !29
  %t1098 = load ptr, ptr %l36, !tbaa !29
  %t1100 = getelementptr %"compiler/check:frame", ptr %t1098, i32 0, i32 0
  %t1101 = load i64, ptr %t1100, !tbaa !24
  %t1103 = trunc i64 %t1101 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t1105
  %t1106 = getelementptr { i64, [2 x i64] }, ptr %t1105, i32 0, i32 0
  store i64 4, ptr %t1106
  %t1108 = insertvalue { i32 } undef, i32 %t1103, 0
  %t1109 = getelementptr { i64, [2 x i64] }, ptr %t1105, i32 0, i32 1
  store { i32 } %t1108, ptr %t1109
  %t1110 = load { i64, [2 x i64] }, ptr %t1105
  store { i64, [2 x i64] } %t1110, ptr %l535
  %t1111 = load ptr, ptr %l0, !tbaa !29
  %t1113 = getelementptr %"compiler/check:Checker", ptr %t1111, i32 0, i32 1
  %t1114 = load ptr, ptr %t1113, !tbaa !29
  %t1116 = getelementptr %"compiler/generic:Program", ptr %t1114, i32 0, i32 2
  %t1117 = load i32, ptr %l35, !tbaa !23
  %t1118 = load i32, ptr %l19, !tbaa !23
  %t1119 = load i32, ptr %l27, !tbaa !23
  %t1120 = load i32, ptr %l34, !tbaa !23
  %t1126 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t1116, i32 %t1117, i32 %t1118, i32 %t1119, i32 %t1120, i64 0)
  store i32 %t1126, ptr %l543
  br label %bb207
bb207:
  %t1127 = load ptr, ptr %l36, !tbaa !29
  %t1129 = getelementptr %"compiler/check:frame", ptr %t1127, i32 0, i32 1
  %t1130 = load i64, ptr %t1129, !tbaa !24
  %t1131 = load %"compiler/source:Span", ptr %l1
  %t1132 = load ptr, ptr %l530, !tbaa !29
  %t1133 = load { i64, [2 x i64] }, ptr %l535
  %t1134 = load i32, ptr %l543, !tbaa !23
  %t1137 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t1132, { i64, [2 x i64] } %t1133, i32 %t1134, i64 %t1130, %"compiler/source:Span" %t1131)
  store i64 %t1137, ptr %l547
  br label %bb208
bb208:
  %t1138 = load i64, ptr %l547, !tbaa !24
  store i64 %t1138, ptr %l38, !tbaa !24
  %t1139 = load ptr, ptr %l0, !tbaa !29
  %t1141 = getelementptr %"compiler/check:Checker", ptr %t1139, i32 0, i32 15
  %t1142 = load i64, ptr %l38, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t1141, i64 %t1142, i64 1)
  br label %bb209
bb209:
  %t1145 = load ptr, ptr %l0, !tbaa !29
  %t1146 = load i64, ptr %l38, !tbaa !24
  %t1147 = load ptr, ptr %l36, !tbaa !29
  %t1149 = getelementptr %"compiler/check:frame", ptr %t1147, i32 0, i32 1
  %t1150 = load i64, ptr %t1149, !tbaa !24
  %t1151 = load i32, ptr %l19, !tbaa !23
  %t1152 = load i32, ptr %l27, !tbaa !23
  %t1158 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t1145, i64 %t1146, i64 %t1150, i32 %t1151, i32 %t1152)
  store ptr %t1158, ptr %l557
  br label %bb210
bb210:
  %t1159 = load ptr, ptr %l557, !tbaa !29
  store ptr %t1159, ptr %l39, !tbaa !29
  %t1160 = load ptr, ptr %l39, !tbaa !29
  %t1161 = load ptr, ptr %l36, !tbaa !29
  %t1163 = getelementptr %"compiler/check:frame", ptr %t1161, i32 0, i32 4
  %t1164 = load %"compiler/generic:Context", ptr %t1163
  %t1167 = getelementptr %"compiler/check:frame", ptr %t1160, i32 0, i32 4
  store %"compiler/generic:Context" %t1164, ptr %t1167
  %t1168 = load ptr, ptr %l39, !tbaa !29
  %t1169 = load i64, ptr %l37, !tbaa !24
  %t1172 = getelementptr %"compiler/check:frame", ptr %t1168, i32 0, i32 21
  store i64 %t1169, ptr %t1172, !tbaa !24
  %t1173 = load ptr, ptr %l39, !tbaa !29
  %t1174 = load i1, ptr %l18, !tbaa !21
  %t1177 = getelementptr %"compiler/check:frame", ptr %t1173, i32 0, i32 22
  store i1 %t1174, ptr %t1177, !tbaa !21
  %t1178 = load ptr, ptr %l39, !tbaa !29
  %t1179 = load i1, ptr %l28, !tbaa !21
  %t1182 = getelementptr %"compiler/check:frame", ptr %t1178, i32 0, i32 23
  store i1 %t1179, ptr %t1182, !tbaa !21
  %t1183 = load ptr, ptr %l0, !tbaa !29
  %t1185 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t1183)
  store ptr %t1185, ptr %l568
  br label %bb211
bb211:
  %t1186 = load %"compiler/source:Span", ptr %l1
  %t1187 = load ptr, ptr %l568, !tbaa !29
  %t1190 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %t1187, i32 -1, i32 0, %"compiler/source:Span" %t1186)
  store i32 %t1190, ptr %l571
  br label %bb212
bb212:
  store i64 0, ptr %l40, !tbaa !24
  %t1191 = load i64, ptr %l6, !tbaa !24
  store i64 %t1191, ptr %l41, !tbaa !24
  store i64 1, ptr %l42, !tbaa !24
  %t1193 = load i64, ptr %l41, !tbaa !24
  %t1194 = load i64, ptr %l40, !tbaa !24
  %t1197 = icmp sgt i64 %t1193, %t1194
  br i1 %t1197, label %bb213, label %bb214
bb213:
  %t1199 = load i64, ptr %l42, !tbaa !24
  %t1201 = icmp sgt i64 %t1199, 0
  br i1 %t1201, label %bb215, label %bb216
bb214:
  store i64 0, ptr %l576, !tbaa !24
  br label %bb218
bb215:
  %t1203 = load i64, ptr %l41, !tbaa !24
  %t1204 = load i64, ptr %l40, !tbaa !24
  %t1207 = sub i64 %t1203, %t1204
  %t1208 = load i64, ptr %l42, !tbaa !24
  %t1211 = add i64 %t1207, %t1208
  %t1213 = sub i64 %t1211, 1
  %t1214 = load i64, ptr %l42, !tbaa !24
  %t1217 = sdiv i64 %t1213, %t1214
  store i64 %t1217, ptr %l579, !tbaa !24
  br label %bb217
bb216:
  store i64 0, ptr %l579, !tbaa !24
  br label %bb217
bb217:
  %t1219 = load i64, ptr %l579, !tbaa !24
  store i64 %t1219, ptr %l576, !tbaa !24
  br label %bb218
bb218:
  %t1220 = load i64, ptr %l576, !tbaa !24
  store i64 %t1220, ptr %l43, !tbaa !24
  store i64 0, ptr %l44, !tbaa !24
  br label %bb219
bb219:
  store %olang.scope zeroinitializer, ptr %s32
  %t1221 = load i64, ptr %l44, !tbaa !24
  %t1222 = load i64, ptr %l43, !tbaa !24
  %t1225 = icmp slt i64 %t1221, %t1222
  %t1227 = xor i1 %t1225, true
  br i1 %t1227, label %bb220, label %bb221
bb220:
  call void @__olang_scope_close(ptr %s32)
  br label %bb229
bb221:
  br label %bb222
bb222:
  %t1229 = load i64, ptr %l40, !tbaa !24
  %t1230 = load i64, ptr %l44, !tbaa !24
  %t1231 = load i64, ptr %l42, !tbaa !24
  %t1234 = mul i64 %t1230, %t1231
  %t1237 = add i64 %t1229, %t1234
  store i64 %t1237, ptr %l45, !tbaa !24
  %t1239 = load ptr, ptr %l0, !tbaa !29
  %t1240 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t1240, ptr %l598, !tbaa !27
  %t1241 = load i64, ptr %l45, !tbaa !24
  %t1243 = getelementptr { i64, ptr }, ptr %l598, i32 0, i32 1
  %t1244 = load ptr, ptr %t1243, !tbaa !27
  %t1245 = getelementptr ptr, ptr %t1244, i64 %t1241
  %t1246 = load ptr, ptr %t1245, !tbaa !39
  %t1248 = getelementptr %"compiler/ast:Param", ptr %t1246, i32 0, i32 1
  %t1249 = load i32, ptr %t1248, !tbaa !23
  %t1250 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t1250, ptr %l602, !tbaa !27
  %t1251 = load i64, ptr %l45, !tbaa !24
  %t1253 = getelementptr { i64, ptr }, ptr %l602, i32 0, i32 1
  %t1254 = load ptr, ptr %t1253, !tbaa !27
  %t1255 = getelementptr ptr, ptr %t1254, i64 %t1251
  %t1256 = load ptr, ptr %t1255, !tbaa !39
  %t1258 = getelementptr %"compiler/ast:Param", ptr %t1256, i32 0, i32 0
  %t1259 = load %"compiler/source:Span", ptr %t1258
  %t1260 = load i64, ptr %l45, !tbaa !24
  %t1262 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t1263 = load ptr, ptr %t1262, !tbaa !27
  %t1264 = getelementptr i32, ptr %t1263, i64 %t1260
  %t1265 = load i32, ptr %t1264, !tbaa !33
  %t1266 = load i64, ptr %l45, !tbaa !24
  %t1267 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t1267, ptr %l609, !tbaa !27
  %t1268 = load i64, ptr %l45, !tbaa !24
  %t1270 = getelementptr { i64, ptr }, ptr %l609, i32 0, i32 1
  %t1271 = load ptr, ptr %t1270, !tbaa !27
  %t1272 = getelementptr ptr, ptr %t1271, i64 %t1268
  %t1273 = load ptr, ptr %t1272, !tbaa !39
  %t1275 = getelementptr %"compiler/ast:Param", ptr %t1273, i32 0, i32 2
  %t1276 = load ptr, ptr %t1275, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparam(ptr %v0, ptr %v1, ptr %t1239, i32 %t1249, %"compiler/source:Span" %t1259, i32 %t1265, i64 %t1266, ptr %t1276)
  br label %bb223
bb223:
  %t1283 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t1283, ptr %l613, !tbaa !27
  %t1284 = load i64, ptr %l45, !tbaa !24
  %t1286 = getelementptr { i64, ptr }, ptr %l613, i32 0, i32 1
  %t1287 = load ptr, ptr %t1286, !tbaa !27
  %t1288 = getelementptr ptr, ptr %t1287, i64 %t1284
  %t1289 = load ptr, ptr %t1288, !tbaa !39
  %t1291 = getelementptr %"compiler/ast:Param", ptr %t1289, i32 0, i32 2
  %t1292 = load ptr, ptr %t1291, !tbaa !29
  %t1294 = icmp eq ptr %t1292, null
  %t1296 = xor i1 %t1294, true
  br i1 %t1296, label %bb224, label %bb225
bb224:
  %t1298 = load ptr, ptr %l0, !tbaa !29
  %t1299 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t1299, ptr %l620, !tbaa !27
  %t1300 = load i64, ptr %l45, !tbaa !24
  %t1302 = getelementptr { i64, ptr }, ptr %l620, i32 0, i32 1
  %t1303 = load ptr, ptr %t1302, !tbaa !27
  %t1304 = getelementptr ptr, ptr %t1303, i64 %t1300
  %t1305 = load ptr, ptr %t1304, !tbaa !39
  %t1306 = load i64, ptr %l45, !tbaa !24
  %t1308 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t1309 = load ptr, ptr %t1308, !tbaa !27
  %t1310 = getelementptr i32, ptr %t1309, i64 %t1306
  %t1311 = load i32, ptr %t1310, !tbaa !33
  %t1315 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamWritten(ptr %v0, ptr %v1, ptr %t1298, ptr %t1305, i32 %t1311, i1 false)
  store i1 %t1315, ptr %l625
  br label %bb226
bb225:
  br label %bb227
bb226:
  br label %bb227
bb227:
  call void @__olang_scope_close(ptr %s32)
  br label %bb228
bb228:
  %t1316 = load i64, ptr %l44, !tbaa !24
  %t1318 = add i64 %t1316, 1
  store i64 %t1318, ptr %l44, !tbaa !24
  br label %bb219
bb229:
  %t1320 = load ptr, ptr %l0, !tbaa !29
  %t1322 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t1320)
  store ptr %t1322, ptr %l629
  br label %bb230
bb230:
  %t1323 = load ptr, ptr %l0, !tbaa !29
  %t1325 = getelementptr %"compiler/check:Checker", ptr %t1323, i32 0, i32 1
  %t1326 = load ptr, ptr %t1325, !tbaa !29
  store ptr %t1326, ptr %l631, !tbaa !29
  %t1327 = load ptr, ptr %l0, !tbaa !29
  %t1329 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t1327)
  store ptr %t1329, ptr %l633
  br label %bb231
bb231:
  %t1330 = load ptr, ptr %l633, !tbaa !29
  %t1332 = getelementptr %"compiler/typed:Body", ptr %t1330, i32 0, i32 2
  %t1333 = load i32, ptr %t1332, !tbaa !23
  %t1334 = load ptr, ptr %l631, !tbaa !29
  %t1336 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t1334, i32 %t1333)
  store { i64, ptr } %t1336, ptr %l636
  br label %bb232
bb232:
  %t1337 = load { i64, ptr }, ptr %l636, !tbaa !27
  %t1338 = extractvalue { i64, ptr } %t1337, 0
  %t1339 = extractvalue { i64, ptr } %t1337, 1
  %t1340 = mul i64 %t1338, 8
  %t1341 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1340)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1341, ptr %t1339, i64 %t1340, i1 false)
  %t1342 = insertvalue { i64, ptr } undef, i64 %t1338, 0
  %t1343 = insertvalue { i64, ptr } %t1342, ptr %t1341, 1
  %t1344 = load ptr, ptr %l629, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eSetVars(ptr %v0, ptr %s0, ptr %t1344, { i64, ptr } %t1343)
  br label %bb233
bb233:
  %t1346 = load ptr, ptr %l0, !tbaa !29
  %t1347 = load ptr, ptr %l2, !tbaa !29
  %t1349 = getelementptr %"compiler/ast:Func", ptr %t1347, i32 0, i32 4
  %t1350 = load { i64, ptr }, ptr %t1349, !tbaa !27
  %t1353 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootStmts(ptr %v0, ptr %v1, ptr %t1346, { i64, ptr } %t1350)
  store ptr %t1353, ptr %l641
  br label %bb234
bb234:
  %t1354 = load ptr, ptr %l641, !tbaa !29
  store ptr %t1354, ptr %l46, !tbaa !29
  %t1355 = load ptr, ptr %l0, !tbaa !29
  %t1357 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t1355)
  store ptr %t1357, ptr %l643
  br label %bb235
bb235:
  %t1358 = load ptr, ptr %l643, !tbaa !29
  %t1359 = load ptr, ptr %l46, !tbaa !29
  %t1363 = getelementptr %"compiler/typed:Body", ptr %t1358, i32 0, i32 11
  store ptr %t1359, ptr %t1363, !tbaa !29
  %t1364 = load ptr, ptr %l39, !tbaa !29
  %t1366 = getelementptr %"compiler/check:frame", ptr %t1364, i32 0, i32 22
  %t1367 = load i1, ptr %t1366, !tbaa !21
  br i1 %t1367, label %bb236, label %bb237
bb236:
  %t1369 = load ptr, ptr %l39, !tbaa !29
  %t1371 = getelementptr %"compiler/check:frame", ptr %t1369, i32 0, i32 22
  store i1 false, ptr %t1371, !tbaa !21
  %t1372 = load ptr, ptr %l39, !tbaa !29
  %t1373 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t1376 = getelementptr %"compiler/check:frame", ptr %t1372, i32 0, i32 5
  store i32 %t1373, ptr %t1376, !tbaa !23
  br label %bb238
bb237:
  br label %bb238
bb238:
  %t1377 = load ptr, ptr %l39, !tbaa !29
  %t1379 = getelementptr %"compiler/check:frame", ptr %t1377, i32 0, i32 5
  %t1380 = load i32, ptr %t1379, !tbaa !23
  store i32 %t1380, ptr %l19, !tbaa !23
  %t1382 = load i1, ptr %l28, !tbaa !21
  br i1 %t1382, label %bb239, label %bb240
bb239:
  store %olang.scope zeroinitializer, ptr %s36
  %t1384 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1384, ptr %l655, !tbaa !29
  %t1385 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1385, ptr %l656, !tbaa !29
  %t1386 = load ptr, ptr %l0, !tbaa !29
  %t1387 = load ptr, ptr %l39, !tbaa !29
  %t1390 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eletOut(ptr %v0, ptr %v0, ptr %s36, ptr %t1386, ptr %t1387)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1390, ptr %l659
  br label %bb241
bb240:
  br label %bb244
bb241:
  %t1391 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l659
  %t1392 = call ptr @__olang_scope_alloc_a(ptr %s36, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1391, ptr %t1392
  %t1393 = load ptr, ptr %l656, !tbaa !29
  %t1395 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emerged(ptr %v0, ptr %s36, ptr %s36, ptr %t1393, ptr %t1392)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1395, ptr %l661
  br label %bb242
bb242:
  %t1396 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l661
  %t1397 = call ptr @__olang_scope_alloc_a(ptr %s36, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1396, ptr %t1397
  %t1398 = load ptr, ptr %l655, !tbaa !29
  %t1400 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecanonicalErrs(ptr %v0, ptr %s36, ptr %t1398, ptr %t1397)
  store i32 %t1400, ptr %l663
  br label %bb243
bb243:
  %t1401 = load i32, ptr %l663, !tbaa !23
  store i32 %t1401, ptr %l27, !tbaa !23
  call void @__olang_scope_close(ptr %s36)
  br label %bb244
bb244:
  %t1402 = load ptr, ptr %l0, !tbaa !29
  %t1404 = getelementptr %"compiler/check:Checker", ptr %t1402, i32 0, i32 1
  %t1405 = load ptr, ptr %t1404, !tbaa !29
  %t1407 = getelementptr %"compiler/generic:Program", ptr %t1405, i32 0, i32 2
  %t1408 = load i32, ptr %l35, !tbaa !23
  %t1409 = load i32, ptr %l19, !tbaa !23
  %t1410 = load i32, ptr %l27, !tbaa !23
  %t1411 = load i32, ptr %l34, !tbaa !23
  %t1417 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t1407, i32 %t1408, i32 %t1409, i32 %t1410, i32 %t1411, i64 0)
  store i32 %t1417, ptr %l671
  br label %bb245
bb245:
  %t1418 = load i32, ptr %l671, !tbaa !23
  store i32 %t1418, ptr %l47, !tbaa !23
  %t1419 = load ptr, ptr %l0, !tbaa !29
  %t1421 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t1419)
  store ptr %t1421, ptr %l673
  br label %bb246
bb246:
  %t1422 = load ptr, ptr %l673, !tbaa !29
  %t1423 = load i32, ptr %l47, !tbaa !23
  %t1426 = getelementptr %"compiler/typed:Body", ptr %t1422, i32 0, i32 2
  store i32 %t1423, ptr %t1426, !tbaa !23
  %t1427 = load i32, ptr %l19, !tbaa !23
  %t1428 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t1431 = icmp ne i32 %t1427, %t1428
  br i1 %t1431, label %bb247, label %bb248
bb247:
  %t1433 = load ptr, ptr %l0, !tbaa !29
  %t1435 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1433)
  store ptr %t1435, ptr %l681
  br label %bb249
bb248:
  store i1 false, ptr %l679, !tbaa !21
  br label %bb250
bb249:
  %t1436 = load ptr, ptr %l681, !tbaa !29
  %t1438 = getelementptr %"compiler/check:frame", ptr %t1436, i32 0, i32 20
  %t1439 = load i1, ptr %t1438, !tbaa !21
  %t1441 = xor i1 %t1439, true
  store i1 %t1441, ptr %l679, !tbaa !21
  br label %bb250
bb250:
  %t1443 = load i1, ptr %l679, !tbaa !21
  br i1 %t1443, label %bb251, label %bb252
bb251:
  %t1444 = load ptr, ptr %l46, !tbaa !29
  %t1447 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t1444)
  store i1 %t1447, ptr %l688
  br label %bb253
bb252:
  store i1 false, ptr %l685, !tbaa !21
  br label %bb254
bb253:
  %t1448 = load i1, ptr %l688, !tbaa !21
  %t1449 = xor i1 %t1448, true
  store i1 %t1449, ptr %l685, !tbaa !21
  br label %bb254
bb254:
  %t1451 = load i1, ptr %l685, !tbaa !21
  br i1 %t1451, label %bb255, label %bb256
bb255:
  store %olang.scope zeroinitializer, ptr %s37
  %t1452 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1452, ptr %l690, !tbaa !29
  %t1453 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1453, ptr %l691
  %t1454 = load ptr, ptr %l0, !tbaa !29
  %t1455 = load i32, ptr %l19, !tbaa !23
  %t1458 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s37, ptr %t1454, i32 %t1455)
  store { i64, ptr } %t1458, ptr %l694
  br label %bb257
bb256:
  br label %bb260
bb257:
  %t1459 = load { i64, ptr }, ptr %l694, !tbaa !27
  %t1460 = extractvalue { i64, ptr } %t1459, 0
  %t1461 = extractvalue { i64, ptr } %t1459, 1
  %t1462 = mul i64 %t1460, 1
  %t1463 = call ptr @__olang_scope_alloc(ptr %s37, i64 %t1462)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1463, ptr %t1461, i64 %t1462, i1 false)
  %t1464 = insertvalue { i64, ptr } undef, i64 %t1460, 0
  %t1465 = insertvalue { i64, ptr } %t1464, ptr %t1463, 1
  %t1467 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMissingReturn(ptr %s37, ptr %s37, { i64, ptr } %t1465)
  store %"compiler/msgs:Msg" %t1467, ptr %l696
  br label %bb258
bb258:
  %t1468 = load ptr, ptr %l690, !tbaa !29
  %t1469 = load %"compiler/source:Span", ptr %l691
  %t1470 = load %"compiler/msgs:Msg", ptr %l696
  %t1471 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s37, ptr %t1468, %"compiler/source:Span" %t1469, %"compiler/msgs:Msg" %t1470)
  store i64 %t1471, ptr %l697
  br label %bb259
bb259:
  call void @__olang_scope_close(ptr %s37)
  br label %bb260
bb260:
  %t1472 = load ptr, ptr %l0, !tbaa !29
  %t1474 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1472)
  store ptr %t1474, ptr %l699
  br label %bb261
bb261:
  %t1475 = load ptr, ptr %l699, !tbaa !29
  %t1477 = getelementptr %"compiler/check:frame", ptr %t1475, i32 0, i32 27
  %t1479 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aCapture_26_3e_2e_Hc9219e836d6ca52518c31537b8e6a8eb(ptr %v0, ptr %v0, ptr %t1477)
  store { i64, ptr } %t1479, ptr %l702
  br label %bb262
bb262:
  %t1480 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t1480, ptr %lp48
  %t1481 = load { i64, ptr }, ptr %l702, !tbaa !27
  %t1482 = load ptr, ptr %lp48
  store { i64, ptr } %t1481, ptr %t1482, !tbaa !27
  %t1483 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t1483)
  br label %bb263
bb263:
  %t1485 = load ptr, ptr %l0, !tbaa !29
  %t1487 = getelementptr %"compiler/check:Checker", ptr %t1485, i32 0, i32 15
  %t1488 = load i64, ptr %l38, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t1487, i64 %t1488, i64 2)
  br label %bb264
bb264:
  %t1491 = load ptr, ptr %l0, !tbaa !29
  %t1493 = getelementptr %"compiler/check:Checker", ptr %t1491, i32 0, i32 59
  store ptr %t1493, ptr %l708, !tbaa !29
  %t1494 = load i64, ptr %l38, !tbaa !24
  store i64 %t1494, ptr %l709, !tbaa !24
  %t1495 = load ptr, ptr %l0, !tbaa !29
  %t1496 = load %"compiler/source:Span", ptr %l1
  %t1499 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t1495, %"compiler/source:Span" %t1496)
  store { i64, [3 x i64] } %t1499, ptr %l712
  br label %bb265
bb265:
  %t1500 = load i64, ptr %l709, !tbaa !24
  %t1501 = load { i64, [3 x i64] }, ptr %l712
  %t1502 = call %"compiler/check:roFn" @compiler_2fcheck_3aroFn_2ector(ptr %v0, ptr %v0, i64 %t1500, i64 0, { i64, [3 x i64] } %t1501, { i64, ptr } { i64 11, ptr @.d42 })
  store %"compiler/check:roFn" %t1502, ptr %l713
  br label %bb266
bb266:
  %t1503 = load ptr, ptr %l708, !tbaa !29
  %t1504 = load %"compiler/check:roFn", ptr %l713
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroFn_3e_2ePush_3ccompiler_2fcheck_3aroFn_3e(ptr %v0, ptr %v0, ptr %t1503, %"compiler/check:roFn" %t1504)
  br label %bb267
bb267:
  %t1505 = load i32, ptr %l4, !tbaa !23
  %t1506 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t1509 = icmp eq i32 %t1505, %t1506
  br i1 %t1509, label %bb268, label %bb269
bb268:
  %t1511 = load ptr, ptr %l0, !tbaa !29
  %t1513 = getelementptr %"compiler/check:Checker", ptr %t1511, i32 0, i32 1
  %t1514 = load ptr, ptr %t1513, !tbaa !29
  %t1516 = getelementptr %"compiler/generic:Program", ptr %t1514, i32 0, i32 2
  store ptr %t1516, ptr %l720, !tbaa !29
  %t1517 = load i32, ptr %l47, !tbaa !23
  store i32 %t1517, ptr %l721, !tbaa !23
  %t1518 = load ptr, ptr %l0, !tbaa !29
  %t1520 = getelementptr %"compiler/check:Checker", ptr %t1518, i32 0, i32 1
  %t1521 = load ptr, ptr %t1520, !tbaa !29
  %t1522 = load ptr, ptr %l2, !tbaa !29
  %t1524 = getelementptr %"compiler/ast:Func", ptr %t1522, i32 0, i32 3
  %t1525 = load ptr, ptr %t1524, !tbaa !29
  %t1528 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSigNames(ptr %v0, ptr %v1, ptr %t1521, ptr %t1525)
  store i64 %t1528, ptr %l726
  br label %bb270
bb269:
  %t1529 = load ptr, ptr %l0, !tbaa !29
  %t1531 = getelementptr %"compiler/check:Checker", ptr %t1529, i32 0, i32 1
  %t1532 = load ptr, ptr %t1531, !tbaa !29
  %t1534 = getelementptr %"compiler/generic:Program", ptr %t1532, i32 0, i32 2
  store ptr %t1534, ptr %l730, !tbaa !29
  %t1535 = load i32, ptr %l47, !tbaa !23
  store i32 %t1535, ptr %l731, !tbaa !23
  %t1536 = load ptr, ptr %l0, !tbaa !29
  %t1538 = getelementptr %"compiler/check:Checker", ptr %t1536, i32 0, i32 1
  %t1539 = load ptr, ptr %t1538, !tbaa !29
  %t1541 = getelementptr %"compiler/generic:Program", ptr %t1539, i32 0, i32 2
  %t1542 = load i32, ptr %l4, !tbaa !23
  %t1545 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesIdOf(ptr %v0, ptr %t1541, i32 %t1542)
  store i64 %t1545, ptr %l736
  br label %bb272
bb270:
  %t1546 = load ptr, ptr %l720, !tbaa !29
  %t1547 = load i32, ptr %l721, !tbaa !23
  %t1548 = load i64, ptr %l726, !tbaa !24
  %t1549 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithNames(ptr %v0, ptr %t1546, i32 %t1547, i64 %t1548)
  store i32 %t1549, ptr %l727
  br label %bb271
bb271:
  %t1550 = load i32, ptr %l727, !tbaa !23
  store i32 %t1550, ptr %l717, !tbaa !23
  br label %bb274
bb272:
  %t1551 = load ptr, ptr %l730, !tbaa !29
  %t1552 = load i32, ptr %l731, !tbaa !23
  %t1553 = load i64, ptr %l736, !tbaa !24
  %t1554 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithNames(ptr %v0, ptr %t1551, i32 %t1552, i64 %t1553)
  store i32 %t1554, ptr %l737
  br label %bb273
bb273:
  %t1555 = load i32, ptr %l737, !tbaa !23
  store i32 %t1555, ptr %l717, !tbaa !23
  br label %bb274
bb274:
  %t1556 = load i32, ptr %l717, !tbaa !23
  %t1557 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1557, ptr %l738
  store i32 %t1556, ptr %l739, !tbaa !23
  %t1559 = load i64, ptr %l38, !tbaa !24
  %t1561 = trunc i64 %t1559 to i32
  store i32 %t1561, ptr %l742, !tbaa !23
  %t1563 = load ptr, ptr %lp48
  %t1564 = load { i64, ptr }, ptr %t1563, !tbaa !27
  store { i64, ptr } %t1564, ptr %l743, !tbaa !27
  %t1565 = load ptr, ptr %l0, !tbaa !29
  %t1566 = load %"compiler/source:Span", ptr %l1
  %t1570 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t1565, i32 5, %"compiler/source:Span" %t1566)
  store i32 %t1570, ptr %l747
  br label %bb275
bb275:
  store { i64, [4 x i64] } zeroinitializer, ptr %t1571
  %t1572 = getelementptr { i64, [4 x i64] }, ptr %t1571, i32 0, i32 0
  store i64 1, ptr %t1572
  %t1573 = load i32, ptr %l742, !tbaa !23
  %t1574 = insertvalue { i32, { i64, ptr }, i32 } undef, i32 %t1573, 0
  %t1575 = load { i64, ptr }, ptr %l743, !tbaa !27
  %t1576 = insertvalue { i32, { i64, ptr }, i32 } %t1574, { i64, ptr } %t1575, 1
  %t1577 = load i32, ptr %l747, !tbaa !23
  %t1578 = insertvalue { i32, { i64, ptr }, i32 } %t1576, i32 %t1577, 2
  %t1579 = getelementptr { i64, [4 x i64] }, ptr %t1571, i32 0, i32 1
  store { i32, { i64, ptr }, i32 } %t1578, ptr %t1579
  %t1580 = load { i64, [4 x i64] }, ptr %t1571
  %t1582 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t1580, ptr %t1582
  store { i64, [5 x i64] } zeroinitializer, ptr %t1583
  %t1584 = getelementptr { i64, [5 x i64] }, ptr %t1583, i32 0, i32 0
  store i64 15, ptr %t1584
  %t1585 = load %"compiler/source:Span", ptr %l738
  %t1586 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1585, 0
  %t1587 = load i32, ptr %l739, !tbaa !23
  %t1588 = insertvalue { %"compiler/source:Span", i32, ptr } %t1586, i32 %t1587, 1
  %t1590 = insertvalue { %"compiler/source:Span", i32, ptr } %t1588, ptr %t1582, 2
  %t1591 = getelementptr { i64, [5 x i64] }, ptr %t1583, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1590, ptr %t1591
  %t1592 = load { i64, [5 x i64] }, ptr %t1583
  %t1594 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t1592, ptr %t1594
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1594, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elastName(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca { i64, ptr }
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l16 = alloca i1
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l22 = alloca i1
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l42 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t2 = load %"compiler/source:Span", ptr %l1
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %a0, %"compiler/source:Span" %t2)
  store { i64, ptr } %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l12, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = sub i64 %t16, 1
  %t20 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 %t18
  %t23 = load i8, ptr %t22, !tbaa !32
  %t25 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t23)
  store i1 %t25, ptr %l16
  br label %bb5
bb4:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb13
bb5:
  %t26 = load i1, ptr %l16, !tbaa !21
  br i1 %t26, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb9
bb7:
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t27, ptr %l18, !tbaa !27
  %t28 = load i64, ptr %l3, !tbaa !24
  %t30 = sub i64 %t28, 1
  %t32 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr i8, ptr %t33, i64 %t30
  %t35 = load i8, ptr %t34, !tbaa !32
  %t37 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t35)
  store i1 %t37, ptr %l22
  br label %bb8
bb8:
  %t38 = load i1, ptr %l22, !tbaa !21
  store i1 %t38, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t39 = load i1, ptr %l17, !tbaa !21
  br i1 %t39, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb12
bb11:
  %t40 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t40, ptr %l24, !tbaa !27
  %t41 = load i64, ptr %l3, !tbaa !24
  %t43 = sub i64 %t41, 1
  %t45 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr i8, ptr %t46, i64 %t43
  %t48 = load i8, ptr %t47, !tbaa !32
  %t50 = icmp eq i8 %t48, 95
  store i1 %t50, ptr %l23, !tbaa !21
  br label %bb12
bb12:
  %t52 = load i1, ptr %l23, !tbaa !21
  store i1 %t52, ptr %l11, !tbaa !21
  br label %bb13
bb13:
  %t53 = load i1, ptr %l11, !tbaa !21
  %t54 = xor i1 %t53, true
  br i1 %t54, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s1)
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t56 = load i64, ptr %l3, !tbaa !24
  %t58 = sub i64 %t56, 1
  store i64 %t58, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb17
bb17:
  br label %bb2
bb18:
  %t60 = load i64, ptr %l3, !tbaa !24
  %t61 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t66 = icmp eq i64 %t60, %t63
  br i1 %t66, label %bb19, label %bb20
bb19:
  %t68 = load %"compiler/source:Span", ptr %l1
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/source:Span" %t68, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t70 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t71 = load i32, ptr %t70, !tbaa !23
  %t72 = load i64, ptr %l3, !tbaa !24
  %t74 = trunc i64 %t72 to i32
  %t77 = add i32 %t71, %t74
  %t78 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t79 = load i32, ptr %t78, !tbaa !23
  %t82 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t77, i32 %t79)
  store %"compiler/source:Span" %t82, ptr %l42
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t83 = load %"compiler/source:Span", ptr %l42
  store %"compiler/source:Span" %t83, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaks1(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l3 = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %a0)
  store ptr %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 25
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t6, i32 %a1)
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFits(ptr %v0, ptr %a0, %"compiler/check:litv" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/check:litv"
  %l3 = alloca i32
  %l6 = alloca i32
  %l11 = alloca i1
  %l19 = alloca i1
  %l20 = alloca i1
  %l23 = alloca i1
  %l29 = alloca i1
  %l33 = alloca i1
  %l40 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/check:litv" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t1, i32 %a2)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i32, ptr %l6, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t16, ptr %l11
  br label %bb2
bb2:
  %t17 = load i1, ptr %l11, !tbaa !21
  %t18 = xor i1 %t17, true
  br i1 %t18, label %bb3, label %bb4
bb3:
  store i1 false, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t21 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 1
  %t22 = load i1, ptr %t21, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t30 = load i32, ptr %l3, !tbaa !23
  %t33 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t29, i32 %t30)
  store i1 %t33, ptr %l19
  br label %bb8
bb7:
  br label %bb13
bb8:
  %t34 = load i1, ptr %l19, !tbaa !21
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t35 = load i32, ptr %l3, !tbaa !23
  %t36 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 4
  %t37 = load double, ptr %t36, !tbaa !26
  %t40 = call i1 @compiler_2fcheck_2efloatOverflows(i32 %t35, double %t37)
  store i1 %t40, ptr %l23
  br label %bb11
bb10:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb12
bb11:
  %t41 = load i1, ptr %l23, !tbaa !21
  %t42 = xor i1 %t41, true
  store i1 %t42, ptr %l20, !tbaa !21
  br label %bb12
bb12:
  %t44 = load i1, ptr %l20, !tbaa !21
  store i1 %t44, ptr %rv
  br label %ret
bb13:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = getelementptr %"compiler/generic:Program", ptr %t48, i32 0, i32 2
  %t51 = load i32, ptr %l3, !tbaa !23
  %t54 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t50, i32 %t51)
  store i1 %t54, ptr %l29
  br label %bb14
bb14:
  %t55 = load i1, ptr %l29, !tbaa !21
  br i1 %t55, label %bb15, label %bb16
bb15:
  %t56 = load i32, ptr %l3, !tbaa !23
  %t57 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t58 = load i64, ptr %t57, !tbaa !24
  %t60 = sitofp i64 %t58 to double
  %t63 = call i1 @compiler_2fcheck_2efloatOverflows(i32 %t56, double %t60)
  store i1 %t63, ptr %l33
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t64 = load i1, ptr %l33, !tbaa !21
  %t65 = xor i1 %t64, true
  store i1 %t65, ptr %rv
  br label %ret
bb18:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Program", ptr %t70, i32 0, i32 2
  %t73 = load %"compiler/check:litv", ptr %l1
  %t74 = load i32, ptr %l3, !tbaa !23
  %t78 = call i1 @compiler_2fcheck_2eintFits(ptr %v0, ptr %t72, %"compiler/check:litv" %t73, i32 %t74)
  store i1 %t78, ptr %l40
  br label %bb19
bb19:
  %t79 = load i1, ptr %l40, !tbaa !21
  store i1 %t79, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emulti(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca %"compiler/source:Span"
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca %"compiler/source:Span"
  %l41 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l42 = alloca ptr
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l49 = alloca i64
  %l50 = alloca ptr
  %l51 = alloca i64
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca ptr
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i64
  %l72 = alloca ptr
  %l80 = alloca i1
  %l85 = alloca { i64, ptr }
  %l89 = alloca ptr
  %l92 = alloca i32
  %l104 = alloca { i64, ptr }
  %l117 = alloca i32
  %l121 = alloca ptr
  %l123 = alloca { i64, ptr }
  %l125 = alloca %"compiler/source:Span"
  %l128 = alloca { i64, ptr }
  %l130 = alloca %"compiler/msgs:Msg"
  %l131 = alloca i64
  %l140 = alloca { i64, ptr }
  %l151 = alloca ptr
  %l156 = alloca i32
  %l157 = alloca { i64, ptr }
  %l162 = alloca ptr
  %l163 = alloca %"compiler/source:Span"
  %l167 = alloca %"compiler/msgs:Msg"
  %l168 = alloca i64
  %l177 = alloca { i64, ptr }
  %l191 = alloca i64
  %l204 = alloca i64
  %l207 = alloca i64
  %l226 = alloca { i64, ptr }
  %l229 = alloca %"compiler/source:Span"
  %l233 = alloca { i64, ptr }
  %l246 = alloca ptr
  %l249 = alloca { i64, ptr }
  %l255 = alloca { i64, ptr }
  %l265 = alloca ptr
  %l266 = alloca ptr
  %l268 = alloca { i64, ptr }
  %l272 = alloca %"compiler/source:Span"
  %l275 = alloca i64
  %l276 = alloca %"compiler/source:Span"
  %l281 = alloca %"compiler/msgs:Msg"
  %l282 = alloca i64
  %l291 = alloca { i64, ptr }
  %l298 = alloca ptr
  %l307 = alloca i64
  %l310 = alloca i64
  %l330 = alloca { i64, ptr }
  %l335 = alloca ptr
  %l336 = alloca ptr
  %l338 = alloca { i64, ptr }
  %l340 = alloca ptr
  %l341 = alloca ptr
  %l344 = alloca { i64, ptr }
  %l347 = alloca i1
  %l349 = alloca i32
  %l351 = alloca { i64, ptr }
  %l354 = alloca %"compiler/source:Span"
  %l355 = alloca i32
  %l357 = alloca i32
  %l359 = alloca i1
  %l360 = alloca ptr
  %l363 = alloca i32
  %l364 = alloca i1
  %l372 = alloca ptr
  %l375 = alloca { i64, ptr }
  %l382 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l383 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l389 = alloca i64
  %l392 = alloca i64
  %l410 = alloca ptr
  %l413 = alloca { i64, ptr }
  %l416 = alloca ptr
  %l421 = alloca i64
  %l423 = alloca { i64, ptr }
  %l426 = alloca { i64, ptr }
  %l427 = alloca i32
  %l436 = alloca { i64, ptr }
  %l442 = alloca i1
  %l443 = alloca ptr
  %l445 = alloca i32
  %l446 = alloca i1
  %l448 = alloca i1
  %l451 = alloca ptr
  %l453 = alloca i32
  %l454 = alloca i1
  %l467 = alloca i64
  %l470 = alloca i64
  %l490 = alloca ptr
  %l493 = alloca i32
  %l496 = alloca ptr
  %l500 = alloca i32
  %l504 = alloca { i64, ptr }
  %l508 = alloca ptr
  %l509 = alloca ptr
  %l511 = alloca { i64, ptr }
  %l514 = alloca %"compiler/source:Span"
  %l517 = alloca i32
  %l520 = alloca i64
  %l521 = alloca ptr
  %l523 = alloca { i64, ptr }
  %l526 = alloca %"compiler/source:Span"
  %l544 = alloca i64
  %l547 = alloca i64
  %l567 = alloca ptr
  %l570 = alloca ptr
  %l571 = alloca %"compiler/source:Span"
  %l574 = alloca ptr
  %l577 = alloca ptr
  %l578 = alloca ptr
  %l579 = alloca %"compiler/source:Span"
  %l582 = alloca i64
  %l583 = alloca ptr
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %t253 = alloca { i64, [2 x i64] }, align 8
  %t270 = alloca { i64, [3 x i64] }, align 8
  %t361 = alloca { i64, [4 x i64] }, align 8
  %t374 = alloca { i64, [4 x i64] }, align 8
  %t653 = alloca { i64, [4 x i64] }, align 8
  %t967 = alloca { i64, [2 x i64] }, align 8
  %t995 = alloca { i64, [3 x i64] }, align 8
  %t1103 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Multi", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t10 = getelementptr %"compiler/ast:Multi", ptr %t8, i32 0, i32 2
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t15 = icmp eq i64 %t13, 1
  br i1 %t15, label %bb1, label %bb2
bb1:
  %t17 = load i64, ptr %l3, !tbaa !24
  %t19 = icmp sgt i64 %t17, 1
  store i1 %t19, ptr %l80, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb3
bb3:
  %t21 = load i1, ptr %l80, !tbaa !21
  br i1 %t21, label %bb4, label %bb5
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t25 = getelementptr %"compiler/ast:Multi", ptr %t23, i32 0, i32 2
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  store { i64, ptr } %t26, ptr %l85, !tbaa !27
  %t27 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr ptr, ptr %t28, i64 0
  %t30 = load ptr, ptr %t29, !tbaa !39
  %t32 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t36 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t22, ptr %t30, i32 %t32)
  store ptr %t36, ptr %l89
  br label %bb6
bb5:
  br label %bb64
bb6:
  %t37 = load ptr, ptr %l89, !tbaa !29
  store ptr %t37, ptr %l4, !tbaa !29
  %t38 = load ptr, ptr %l4, !tbaa !29
  %t41 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t38)
  store i32 %t41, ptr %l92
  br label %bb7
bb7:
  %t42 = load i32, ptr %l92, !tbaa !23
  store i32 %t42, ptr %l5, !tbaa !23
  %t43 = load i32, ptr %l5, !tbaa !23
  %t44 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t47 = icmp eq i32 %t43, %t44
  br i1 %t47, label %bb8, label %bb9
bb8:
  %t49 = load ptr, ptr %l2, !tbaa !29
  %t51 = getelementptr %"compiler/ast:Multi", ptr %t49, i32 0, i32 0
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  store { i64, ptr } %t52, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t54 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t54, 0
  store i64 %t56, ptr %l8, !tbaa !24
  br label %bb10
bb9:
  br label %bb17
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t58 = load i64, ptr %l7, !tbaa !24
  %t59 = load i64, ptr %l8, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s4)
  br label %bb16
bb12:
  br label %bb13
bb13:
  %t66 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t66, ptr %l104, !tbaa !27
  %t67 = load i64, ptr %l7, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr ptr, ptr %t70, i64 %t67
  %t72 = load ptr, ptr %t71, !tbaa !39
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = load ptr, ptr %l2, !tbaa !29
  %t78 = getelementptr %"compiler/ast:Multi", ptr %t76, i32 0, i32 1
  %t79 = load i1, ptr %t78, !tbaa !21
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclareUnknown(ptr %v0, ptr %v1, ptr %t74, ptr %t72, i1 %t79)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb15
bb15:
  %t83 = load i64, ptr %l7, !tbaa !24
  %t85 = add i64 %t83, 1
  store i64 %t85, ptr %l7, !tbaa !24
  br label %bb10
bb16:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb17:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/check:Checker", ptr %t87, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t92 = getelementptr %"compiler/generic:Program", ptr %t90, i32 0, i32 2
  %t93 = load i32, ptr %l5, !tbaa !23
  %t96 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t92, i32 %t93)
  store i32 %t96, ptr %l117
  br label %bb18
bb18:
  %t97 = load i32, ptr %l117
  %t99 = trunc i64 22 to i32
  %t100 = icmp eq i32 %t97, %t99
  %t102 = xor i1 %t100, true
  br i1 %t102, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s6
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l121, !tbaa !29
  %t105 = load ptr, ptr %l2, !tbaa !29
  %t107 = getelementptr %"compiler/ast:Multi", ptr %t105, i32 0, i32 2
  %t108 = load { i64, ptr }, ptr %t107, !tbaa !27
  store { i64, ptr } %t108, ptr %l123, !tbaa !27
  %t109 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr ptr, ptr %t110, i64 0
  %t112 = load ptr, ptr %t111, !tbaa !39
  %t114 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t112)
  store %"compiler/source:Span" %t114, ptr %l125
  br label %bb21
bb20:
  br label %bb32
bb21:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load i32, ptr %l5, !tbaa !23
  %t119 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s6, ptr %t115, i32 %t116)
  store { i64, ptr } %t119, ptr %l128
  br label %bb22
bb22:
  %t120 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t120, 0
  %t122 = extractvalue { i64, ptr } %t120, 1
  %t123 = mul i64 %t121, 1
  %t124 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t123)
  call void @llvm.memcpy.p0.p0.i64(ptr %t124, ptr %t122, i64 %t123, i1 false)
  %t125 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t124, 1
  %t128 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructOneValue(ptr %s6, ptr %s6, { i64, ptr } %t126)
  store %"compiler/msgs:Msg" %t128, ptr %l130
  br label %bb23
bb23:
  %t129 = load ptr, ptr %l121, !tbaa !29
  %t130 = load %"compiler/source:Span", ptr %l125
  %t131 = load %"compiler/msgs:Msg", ptr %l130
  %t132 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t129, %"compiler/source:Span" %t130, %"compiler/msgs:Msg" %t131)
  store i64 %t132, ptr %l131
  br label %bb24
bb24:
  %t133 = load ptr, ptr %l2, !tbaa !29
  %t135 = getelementptr %"compiler/ast:Multi", ptr %t133, i32 0, i32 0
  %t136 = load { i64, ptr }, ptr %t135, !tbaa !27
  store { i64, ptr } %t136, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t138 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t138, 0
  store i64 %t140, ptr %l12, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s8
  %t142 = load i64, ptr %l11, !tbaa !24
  %t143 = load i64, ptr %l12, !tbaa !24
  %t146 = icmp slt i64 %t142, %t143
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s8)
  br label %bb31
bb27:
  br label %bb28
bb28:
  %t150 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t150, ptr %l140, !tbaa !27
  %t151 = load i64, ptr %l11, !tbaa !24
  %t153 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr ptr, ptr %t154, i64 %t151
  %t156 = load ptr, ptr %t155, !tbaa !39
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = load ptr, ptr %l2, !tbaa !29
  %t162 = getelementptr %"compiler/ast:Multi", ptr %t160, i32 0, i32 1
  %t163 = load i1, ptr %t162, !tbaa !21
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclareUnknown(ptr %v0, ptr %v1, ptr %t158, ptr %t156, i1 %t163)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s8)
  br label %bb30
bb30:
  %t167 = load i64, ptr %l11, !tbaa !24
  %t169 = add i64 %t167, 1
  store i64 %t169, ptr %l11, !tbaa !24
  br label %bb25
bb31:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb32:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/check:Checker", ptr %t171, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !29
  %t176 = getelementptr %"compiler/generic:Program", ptr %t174, i32 0, i32 2
  store ptr %t176, ptr %l151, !tbaa !29
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/check:Checker", ptr %t177, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !29
  %t182 = getelementptr %"compiler/generic:Program", ptr %t180, i32 0, i32 2
  %t183 = load i32, ptr %l5, !tbaa !23
  %t186 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t182, i32 %t183)
  store i32 %t186, ptr %l156
  br label %bb33
bb33:
  %t187 = load ptr, ptr %l151, !tbaa !29
  %t188 = load i32, ptr %l156, !tbaa !23
  %t189 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t187, i32 %t188)
  store { i64, ptr } %t189, ptr %l157
  br label %bb34
bb34:
  %t190 = load { i64, ptr }, ptr %l157, !tbaa !27
  store { i64, ptr } %t190, ptr %l14, !tbaa !27
  %t191 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t191, 0
  %t194 = load i64, ptr %l3, !tbaa !24
  %t197 = icmp ne i64 %t193, %t194
  br i1 %t197, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s10
  %t199 = load ptr, ptr %l0, !tbaa !29
  store ptr %t199, ptr %l162, !tbaa !29
  %t200 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t200, ptr %l163
  %t201 = load i64, ptr %l3, !tbaa !24
  %t202 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t202, 0
  %t207 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructCount(ptr %s10, i64 %t201, i64 %t204)
  store %"compiler/msgs:Msg" %t207, ptr %l167
  br label %bb37
bb36:
  br label %bb46
bb37:
  %t208 = load ptr, ptr %l162, !tbaa !29
  %t209 = load %"compiler/source:Span", ptr %l163
  %t210 = load %"compiler/msgs:Msg", ptr %l167
  %t211 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s10, ptr %t208, %"compiler/source:Span" %t209, %"compiler/msgs:Msg" %t210)
  store i64 %t211, ptr %l168
  br label %bb38
bb38:
  %t212 = load ptr, ptr %l2, !tbaa !29
  %t214 = getelementptr %"compiler/ast:Multi", ptr %t212, i32 0, i32 0
  %t215 = load { i64, ptr }, ptr %t214, !tbaa !27
  store { i64, ptr } %t215, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t217 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t219 = extractvalue { i64, ptr } %t217, 0
  store i64 %t219, ptr %l17, !tbaa !24
  br label %bb39
bb39:
  store %olang.scope zeroinitializer, ptr %s12
  %t221 = load i64, ptr %l16, !tbaa !24
  %t222 = load i64, ptr %l17, !tbaa !24
  %t225 = icmp slt i64 %t221, %t222
  %t227 = xor i1 %t225, true
  br i1 %t227, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s12)
  br label %bb45
bb41:
  br label %bb42
bb42:
  %t229 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t229, ptr %l177, !tbaa !27
  %t230 = load i64, ptr %l16, !tbaa !24
  %t232 = getelementptr { i64, ptr }, ptr %l177, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !27
  %t234 = getelementptr ptr, ptr %t233, i64 %t230
  %t235 = load ptr, ptr %t234, !tbaa !39
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = load ptr, ptr %l2, !tbaa !29
  %t241 = getelementptr %"compiler/ast:Multi", ptr %t239, i32 0, i32 1
  %t242 = load i1, ptr %t241, !tbaa !21
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclareUnknown(ptr %v0, ptr %v1, ptr %t237, ptr %t235, i1 %t242)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s12)
  br label %bb44
bb44:
  %t246 = load i64, ptr %l16, !tbaa !24
  %t248 = add i64 %t246, 1
  store i64 %t248, ptr %l16, !tbaa !24
  br label %bb39
bb45:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb46:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load %"compiler/source:Span", ptr %l1
  %t252 = load i32, ptr %l5, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t253
  %t254 = getelementptr { i64, [2 x i64] }, ptr %t253, i32 0, i32 0
  store i64 0, ptr %t254
  %t255 = load { i64, [2 x i64] }, ptr %t253
  %t261 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t250, i32 0, %"compiler/source:Span" %t251, i32 %t252, i32 2, { i64, [2 x i64] } %t255)
  store i64 %t261, ptr %l191
  br label %bb47
bb47:
  %t262 = load i64, ptr %l191, !tbaa !24
  store i64 %t262, ptr %l19, !tbaa !24
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t264 = load %"compiler/source:Span", ptr %l1
  %t265 = load i64, ptr %l19, !tbaa !24
  %t267 = trunc i64 %t265 to i32
  %t269 = load ptr, ptr %l4, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t270
  %t271 = getelementptr { i64, [3 x i64] }, ptr %t270, i32 0, i32 0
  store i64 0, ptr %t271
  %t273 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t264, 0
  %t275 = insertvalue { %"compiler/source:Span", i32, ptr } %t273, i32 %t267, 1
  %t277 = insertvalue { %"compiler/source:Span", i32, ptr } %t275, ptr %t269, 2
  %t278 = getelementptr { i64, [3 x i64] }, ptr %t270, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t277, ptr %t278
  %t279 = load { i64, [3 x i64] }, ptr %t270
  %t281 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t279, ptr %t281
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t263, ptr %t281)
  br label %bb48
bb48:
  store i64 0, ptr %l20, !tbaa !24
  %t284 = load i64, ptr %l3, !tbaa !24
  store i64 %t284, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t286 = load i64, ptr %l21, !tbaa !24
  %t287 = load i64, ptr %l20, !tbaa !24
  %t290 = icmp sgt i64 %t286, %t287
  br i1 %t290, label %bb49, label %bb50
bb49:
  %t292 = load i64, ptr %l22, !tbaa !24
  %t294 = icmp sgt i64 %t292, 0
  br i1 %t294, label %bb51, label %bb52
bb50:
  store i64 0, ptr %l204, !tbaa !24
  br label %bb54
bb51:
  %t296 = load i64, ptr %l21, !tbaa !24
  %t297 = load i64, ptr %l20, !tbaa !24
  %t300 = sub i64 %t296, %t297
  %t301 = load i64, ptr %l22, !tbaa !24
  %t304 = add i64 %t300, %t301
  %t306 = sub i64 %t304, 1
  %t307 = load i64, ptr %l22, !tbaa !24
  %t310 = sdiv i64 %t306, %t307
  store i64 %t310, ptr %l207, !tbaa !24
  br label %bb53
bb52:
  store i64 0, ptr %l207, !tbaa !24
  br label %bb53
bb53:
  %t312 = load i64, ptr %l207, !tbaa !24
  store i64 %t312, ptr %l204, !tbaa !24
  br label %bb54
bb54:
  %t313 = load i64, ptr %l204, !tbaa !24
  store i64 %t313, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb55
bb55:
  store %olang.scope zeroinitializer, ptr %s15
  %t314 = load i64, ptr %l24, !tbaa !24
  %t315 = load i64, ptr %l23, !tbaa !24
  %t318 = icmp slt i64 %t314, %t315
  %t320 = xor i1 %t318, true
  br i1 %t320, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s15)
  br label %bb63
bb57:
  br label %bb58
bb58:
  %t322 = load i64, ptr %l20, !tbaa !24
  %t323 = load i64, ptr %l24, !tbaa !24
  %t324 = load i64, ptr %l22, !tbaa !24
  %t327 = mul i64 %t323, %t324
  %t330 = add i64 %t322, %t327
  store i64 %t330, ptr %l25, !tbaa !24
  %t332 = load ptr, ptr %l2, !tbaa !29
  %t334 = getelementptr %"compiler/ast:Multi", ptr %t332, i32 0, i32 0
  %t335 = load { i64, ptr }, ptr %t334, !tbaa !27
  store { i64, ptr } %t335, ptr %l226, !tbaa !27
  %t336 = load i64, ptr %l25, !tbaa !24
  %t338 = getelementptr { i64, ptr }, ptr %l226, i32 0, i32 1
  %t339 = load ptr, ptr %t338, !tbaa !27
  %t340 = getelementptr ptr, ptr %t339, i64 %t336
  %t341 = load ptr, ptr %t340, !tbaa !39
  %t343 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t341)
  store %"compiler/source:Span" %t343, ptr %l229
  br label %bb59
bb59:
  %t344 = load %"compiler/source:Span", ptr %l229
  store %"compiler/source:Span" %t344, ptr %l26
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t346 = load %"compiler/source:Span", ptr %l26
  %t347 = load %"compiler/source:Span", ptr %l26
  %t348 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t348, ptr %l233, !tbaa !27
  %t349 = load i64, ptr %l25, !tbaa !24
  %t351 = getelementptr { i64, ptr }, ptr %l233, i32 0, i32 1
  %t352 = load ptr, ptr %t351, !tbaa !27
  %t353 = getelementptr i32, ptr %t352, i64 %t349
  %t354 = load i32, ptr %t353, !tbaa !33
  %t355 = load %"compiler/source:Span", ptr %l26
  %t356 = load i32, ptr %l5, !tbaa !23
  %t357 = load i64, ptr %l19, !tbaa !24
  %t359 = trunc i64 %t357 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t361
  %t362 = getelementptr { i64, [4 x i64] }, ptr %t361, i32 0, i32 0
  store i64 0, ptr %t362
  %t364 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t355, 0
  %t366 = insertvalue { %"compiler/source:Span", i32, i32 } %t364, i32 %t356, 1
  %t368 = insertvalue { %"compiler/source:Span", i32, i32 } %t366, i32 %t359, 2
  %t369 = getelementptr { i64, [4 x i64] }, ptr %t361, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t368, ptr %t369
  %t370 = load { i64, [4 x i64] }, ptr %t361
  %t372 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t370, ptr %t372
  %t373 = load i64, ptr %l25, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t374
  %t375 = getelementptr { i64, [4 x i64] }, ptr %t374, i32 0, i32 0
  store i64 3, ptr %t375
  %t377 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t347, 0
  %t379 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t377, i32 %t354, 1
  %t381 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t379, ptr %t372, 2
  %t383 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t381, i64 %t373, 3
  %t384 = getelementptr { i64, [4 x i64] }, ptr %t374, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t383, ptr %t384
  %t385 = load { i64, [4 x i64] }, ptr %t374
  %t387 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t385, ptr %t387
  %t391 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t345, %"compiler/source:Span" %t346, ptr %t387)
  store ptr %t391, ptr %l246
  br label %bb60
bb60:
  %t392 = load ptr, ptr %l246, !tbaa !29
  %t393 = load ptr, ptr %l0, !tbaa !29
  %t394 = load ptr, ptr %l2, !tbaa !29
  %t396 = getelementptr %"compiler/ast:Multi", ptr %t394, i32 0, i32 0
  %t397 = load { i64, ptr }, ptr %t396, !tbaa !27
  store { i64, ptr } %t397, ptr %l249, !tbaa !27
  %t398 = load i64, ptr %l25, !tbaa !24
  %t400 = getelementptr { i64, ptr }, ptr %l249, i32 0, i32 1
  %t401 = load ptr, ptr %t400, !tbaa !27
  %t402 = getelementptr ptr, ptr %t401, i64 %t398
  %t403 = load ptr, ptr %t402, !tbaa !39
  %t404 = load ptr, ptr %l2, !tbaa !29
  %t406 = getelementptr %"compiler/ast:Multi", ptr %t404, i32 0, i32 1
  %t407 = load i1, ptr %t406, !tbaa !21
  %t409 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t409, ptr %l255, !tbaa !27
  %t410 = load i64, ptr %l25, !tbaa !24
  %t412 = getelementptr { i64, ptr }, ptr %l255, i32 0, i32 1
  %t413 = load ptr, ptr %t412, !tbaa !27
  %t414 = getelementptr i32, ptr %t413, i64 %t410
  %t415 = load i32, ptr %t414, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eputTarget(ptr %v0, ptr %v1, ptr %t393, ptr %t403, i1 %t407, ptr %t392, i32 %t415)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s15)
  br label %bb62
bb62:
  %t421 = load i64, ptr %l24, !tbaa !24
  %t423 = add i64 %t421, 1
  store i64 %t423, ptr %l24, !tbaa !24
  br label %bb55
bb63:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb64:
  %t425 = load ptr, ptr %l2, !tbaa !29
  %t427 = getelementptr %"compiler/ast:Multi", ptr %t425, i32 0, i32 2
  %t428 = load { i64, ptr }, ptr %t427, !tbaa !27
  %t430 = extractvalue { i64, ptr } %t428, 0
  %t431 = load i64, ptr %l3, !tbaa !24
  %t434 = icmp ne i64 %t430, %t431
  br i1 %t434, label %bb65, label %bb66
bb65:
  store %olang.scope zeroinitializer, ptr %s17
  %t436 = load ptr, ptr %l0, !tbaa !29
  store ptr %t436, ptr %l265, !tbaa !29
  %t437 = load ptr, ptr %l0, !tbaa !29
  store ptr %t437, ptr %l266, !tbaa !29
  %t438 = load ptr, ptr %l2, !tbaa !29
  %t440 = getelementptr %"compiler/ast:Multi", ptr %t438, i32 0, i32 0
  %t441 = load { i64, ptr }, ptr %t440, !tbaa !27
  store { i64, ptr } %t441, ptr %l268, !tbaa !27
  %t442 = load i64, ptr %l3, !tbaa !24
  %t444 = sub i64 %t442, 1
  %t446 = getelementptr { i64, ptr }, ptr %l268, i32 0, i32 1
  %t447 = load ptr, ptr %t446, !tbaa !27
  %t448 = getelementptr ptr, ptr %t447, i64 %t444
  %t449 = load ptr, ptr %t448, !tbaa !39
  %t451 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t449)
  store %"compiler/source:Span" %t451, ptr %l272
  br label %bb67
bb66:
  br label %bb81
bb67:
  %t452 = load ptr, ptr %l2, !tbaa !29
  %t454 = getelementptr %"compiler/ast:Multi", ptr %t452, i32 0, i32 1
  %t455 = load i1, ptr %t454, !tbaa !21
  br i1 %t455, label %bb68, label %bb69
bb68:
  store i64 2, ptr %l275, !tbaa !24
  br label %bb70
bb69:
  store i64 1, ptr %l275, !tbaa !24
  br label %bb70
bb70:
  %t457 = load ptr, ptr %l266, !tbaa !29
  %t458 = load %"compiler/source:Span", ptr %l272
  %t459 = load i64, ptr %l275, !tbaa !24
  %t460 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAfter(ptr %v0, ptr %t457, %"compiler/source:Span" %t458, i64 %t459)
  store %"compiler/source:Span" %t460, ptr %l276
  br label %bb71
bb71:
  %t461 = load i64, ptr %l3, !tbaa !24
  %t462 = load ptr, ptr %l2, !tbaa !29
  %t464 = getelementptr %"compiler/ast:Multi", ptr %t462, i32 0, i32 2
  %t465 = load { i64, ptr }, ptr %t464, !tbaa !27
  %t467 = extractvalue { i64, ptr } %t465, 0
  %t470 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssignListCount(ptr %s17, i64 %t461, i64 %t467)
  store %"compiler/msgs:Msg" %t470, ptr %l281
  br label %bb72
bb72:
  %t471 = load ptr, ptr %l265, !tbaa !29
  %t472 = load %"compiler/source:Span", ptr %l276
  %t473 = load %"compiler/msgs:Msg", ptr %l281
  %t474 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s17, ptr %t471, %"compiler/source:Span" %t472, %"compiler/msgs:Msg" %t473)
  store i64 %t474, ptr %l282
  br label %bb73
bb73:
  %t475 = load ptr, ptr %l2, !tbaa !29
  %t477 = getelementptr %"compiler/ast:Multi", ptr %t475, i32 0, i32 2
  %t478 = load { i64, ptr }, ptr %t477, !tbaa !27
  store { i64, ptr } %t478, ptr %l28, !tbaa !27
  store i64 0, ptr %l29, !tbaa !24
  %t480 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t482 = extractvalue { i64, ptr } %t480, 0
  store i64 %t482, ptr %l30, !tbaa !24
  br label %bb74
bb74:
  store %olang.scope zeroinitializer, ptr %s19
  %t484 = load i64, ptr %l29, !tbaa !24
  %t485 = load i64, ptr %l30, !tbaa !24
  %t488 = icmp slt i64 %t484, %t485
  %t490 = xor i1 %t488, true
  br i1 %t490, label %bb75, label %bb76
bb75:
  call void @__olang_scope_close(ptr %s19)
  br label %bb80
bb76:
  br label %bb77
bb77:
  %t492 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t492, ptr %l291, !tbaa !27
  %t493 = load i64, ptr %l29, !tbaa !24
  %t495 = getelementptr { i64, ptr }, ptr %l291, i32 0, i32 1
  %t496 = load ptr, ptr %t495, !tbaa !27
  %t497 = getelementptr ptr, ptr %t496, i64 %t493
  %t498 = load ptr, ptr %t497, !tbaa !39
  %t500 = load ptr, ptr %l0, !tbaa !29
  %t503 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t507 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t500, ptr %t498, i32 %t503)
  store ptr %t507, ptr %l298
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s19)
  br label %bb79
bb79:
  %t508 = load i64, ptr %l29, !tbaa !24
  %t510 = add i64 %t508, 1
  store i64 %t510, ptr %l29, !tbaa !24
  br label %bb74
bb80:
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb81:
  %t512 = load ptr, ptr %l2, !tbaa !29
  %t514 = getelementptr %"compiler/ast:Multi", ptr %t512, i32 0, i32 1
  %t515 = load i1, ptr %t514, !tbaa !21
  br i1 %t515, label %bb82, label %bb83
bb82:
  store i64 0, ptr %l32, !tbaa !24
  %t517 = load i64, ptr %l3, !tbaa !24
  store i64 %t517, ptr %l33, !tbaa !24
  store i64 1, ptr %l34, !tbaa !24
  %t519 = load i64, ptr %l33, !tbaa !24
  %t520 = load i64, ptr %l32, !tbaa !24
  %t523 = icmp sgt i64 %t519, %t520
  br i1 %t523, label %bb84, label %bb85
bb83:
  br label %bb111
bb84:
  %t525 = load i64, ptr %l34, !tbaa !24
  %t527 = icmp sgt i64 %t525, 0
  br i1 %t527, label %bb86, label %bb87
bb85:
  store i64 0, ptr %l307, !tbaa !24
  br label %bb89
bb86:
  %t529 = load i64, ptr %l33, !tbaa !24
  %t530 = load i64, ptr %l32, !tbaa !24
  %t533 = sub i64 %t529, %t530
  %t534 = load i64, ptr %l34, !tbaa !24
  %t537 = add i64 %t533, %t534
  %t539 = sub i64 %t537, 1
  %t540 = load i64, ptr %l34, !tbaa !24
  %t543 = sdiv i64 %t539, %t540
  store i64 %t543, ptr %l310, !tbaa !24
  br label %bb88
bb87:
  store i64 0, ptr %l310, !tbaa !24
  br label %bb88
bb88:
  %t545 = load i64, ptr %l310, !tbaa !24
  store i64 %t545, ptr %l307, !tbaa !24
  br label %bb89
bb89:
  %t546 = load i64, ptr %l307, !tbaa !24
  store i64 %t546, ptr %l35, !tbaa !24
  store i64 0, ptr %l36, !tbaa !24
  br label %bb90
bb90:
  store %olang.scope zeroinitializer, ptr %s23
  %t547 = load i64, ptr %l36, !tbaa !24
  %t548 = load i64, ptr %l35, !tbaa !24
  %t551 = icmp slt i64 %t547, %t548
  %t553 = xor i1 %t551, true
  br i1 %t553, label %bb91, label %bb92
bb91:
  call void @__olang_scope_close(ptr %s23)
  br label %bb110
bb92:
  br label %bb93
bb93:
  %t555 = load i64, ptr %l32, !tbaa !24
  %t556 = load i64, ptr %l36, !tbaa !24
  %t557 = load i64, ptr %l34, !tbaa !24
  %t560 = mul i64 %t556, %t557
  %t563 = add i64 %t555, %t560
  store i64 %t563, ptr %l37, !tbaa !24
  %t565 = load ptr, ptr %l0, !tbaa !29
  %t566 = load ptr, ptr %l2, !tbaa !29
  %t568 = getelementptr %"compiler/ast:Multi", ptr %t566, i32 0, i32 2
  %t569 = load { i64, ptr }, ptr %t568, !tbaa !27
  store { i64, ptr } %t569, ptr %l330, !tbaa !27
  %t570 = load i64, ptr %l37, !tbaa !24
  %t572 = getelementptr { i64, ptr }, ptr %l330, i32 0, i32 1
  %t573 = load ptr, ptr %t572, !tbaa !27
  %t574 = getelementptr ptr, ptr %t573, i64 %t570
  %t575 = load ptr, ptr %t574, !tbaa !39
  %t577 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t581 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t565, ptr %t575, i32 %t577)
  store ptr %t581, ptr %l335
  br label %bb94
bb94:
  %t582 = load ptr, ptr %l335, !tbaa !29
  store ptr %t582, ptr %l38, !tbaa !29
  %t583 = load ptr, ptr %l0, !tbaa !29
  store ptr %t583, ptr %l336, !tbaa !29
  %t584 = load ptr, ptr %l2, !tbaa !29
  %t586 = getelementptr %"compiler/ast:Multi", ptr %t584, i32 0, i32 2
  %t587 = load { i64, ptr }, ptr %t586, !tbaa !27
  store { i64, ptr } %t587, ptr %l338, !tbaa !27
  %t588 = load i64, ptr %l37, !tbaa !24
  %t590 = getelementptr { i64, ptr }, ptr %l338, i32 0, i32 1
  %t591 = load ptr, ptr %t590, !tbaa !27
  %t592 = getelementptr ptr, ptr %t591, i64 %t588
  %t593 = load ptr, ptr %t592, !tbaa !39
  store ptr %t593, ptr %l340, !tbaa !29
  %t594 = load ptr, ptr %l38, !tbaa !29
  store ptr %t594, ptr %l341, !tbaa !29
  %t595 = load ptr, ptr %l0, !tbaa !29
  %t596 = load ptr, ptr %l2, !tbaa !29
  %t598 = getelementptr %"compiler/ast:Multi", ptr %t596, i32 0, i32 0
  %t599 = load { i64, ptr }, ptr %t598, !tbaa !27
  store { i64, ptr } %t599, ptr %l344, !tbaa !27
  %t600 = load i64, ptr %l37, !tbaa !24
  %t602 = getelementptr { i64, ptr }, ptr %l344, i32 0, i32 1
  %t603 = load ptr, ptr %t602, !tbaa !27
  %t604 = getelementptr ptr, ptr %t603, i64 %t600
  %t605 = load ptr, ptr %t604, !tbaa !39
  %t608 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estoredName(ptr %v0, ptr %v1, ptr %t595, ptr %t605)
  store i1 %t608, ptr %l347
  br label %bb95
bb95:
  %t609 = load i1, ptr %l347, !tbaa !21
  %t610 = xor i1 %t609, true
  %t611 = load ptr, ptr %l336, !tbaa !29
  %t612 = load ptr, ptr %l340, !tbaa !29
  %t613 = load ptr, ptr %l341, !tbaa !29
  %t615 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferred(ptr %v0, ptr %v1, ptr %v0, ptr %t611, ptr %t612, ptr %t613, i1 %t610)
  store i32 %t615, ptr %l349
  br label %bb96
bb96:
  %t616 = load i32, ptr %l349, !tbaa !23
  store i32 %t616, ptr %l39, !tbaa !23
  %t617 = load ptr, ptr %l2, !tbaa !29
  %t619 = getelementptr %"compiler/ast:Multi", ptr %t617, i32 0, i32 2
  %t620 = load { i64, ptr }, ptr %t619, !tbaa !27
  store { i64, ptr } %t620, ptr %l351, !tbaa !27
  %t621 = load i64, ptr %l37, !tbaa !24
  %t623 = getelementptr { i64, ptr }, ptr %l351, i32 0, i32 1
  %t624 = load ptr, ptr %t623, !tbaa !27
  %t625 = getelementptr ptr, ptr %t624, i64 %t621
  %t626 = load ptr, ptr %t625, !tbaa !39
  %t628 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t626)
  store %"compiler/source:Span" %t628, ptr %l354
  br label %bb97
bb97:
  %t629 = load %"compiler/source:Span", ptr %l354
  store %"compiler/source:Span" %t629, ptr %l40
  %t630 = load i32, ptr %l39, !tbaa !23
  store i32 %t630, ptr %l355, !tbaa !23
  %t631 = load ptr, ptr %l0, !tbaa !29
  %t633 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t631)
  store i32 %t633, ptr %l357
  br label %bb98
bb98:
  %t634 = load i32, ptr %l355, !tbaa !23
  %t635 = load i32, ptr %l357, !tbaa !23
  %t636 = icmp eq i32 %t634, %t635
  br i1 %t636, label %bb99, label %bb100
bb99:
  %t638 = load ptr, ptr %l0, !tbaa !29
  store ptr %t638, ptr %l360, !tbaa !29
  %t639 = load ptr, ptr %l38, !tbaa !29
  %t642 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t639)
  store i32 %t642, ptr %l363
  br label %bb101
bb100:
  store i1 false, ptr %l359, !tbaa !21
  br label %bb103
bb101:
  %t643 = load ptr, ptr %l360, !tbaa !29
  %t644 = load i32, ptr %l363, !tbaa !23
  %t645 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t643, i32 %t644)
  store i1 %t645, ptr %l364
  br label %bb102
bb102:
  %t646 = load i1, ptr %l364, !tbaa !21
  store i1 %t646, ptr %l359, !tbaa !21
  br label %bb103
bb103:
  %t647 = load i1, ptr %l359, !tbaa !21
  br i1 %t647, label %bb104, label %bb105
bb104:
  %t648 = load ptr, ptr %l0, !tbaa !29
  %t649 = load %"compiler/source:Span", ptr %l40
  %t650 = load %"compiler/source:Span", ptr %l40
  %t651 = load i32, ptr %l39, !tbaa !23
  %t652 = load ptr, ptr %l38, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t653
  %t654 = getelementptr { i64, [4 x i64] }, ptr %t653, i32 0, i32 0
  store i64 2, ptr %t654
  %t656 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t650, 0
  %t658 = insertvalue { %"compiler/source:Span", i32, ptr } %t656, i32 %t651, 1
  %t660 = insertvalue { %"compiler/source:Span", i32, ptr } %t658, ptr %t652, 2
  %t661 = getelementptr { i64, [4 x i64] }, ptr %t653, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t660, ptr %t661
  %t662 = load { i64, [4 x i64] }, ptr %t653
  %t664 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t662, ptr %t664
  %t668 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t648, %"compiler/source:Span" %t649, ptr %t664)
  store ptr %t668, ptr %l372
  br label %bb106
bb105:
  br label %bb107
bb106:
  %t669 = load ptr, ptr %l372, !tbaa !29
  store ptr %t669, ptr %l38, !tbaa !29
  br label %bb107
bb107:
  %t670 = load ptr, ptr %l0, !tbaa !29
  %t671 = load ptr, ptr %l2, !tbaa !29
  %t673 = getelementptr %"compiler/ast:Multi", ptr %t671, i32 0, i32 0
  %t674 = load { i64, ptr }, ptr %t673, !tbaa !27
  store { i64, ptr } %t674, ptr %l375, !tbaa !27
  %t675 = load i64, ptr %l37, !tbaa !24
  %t677 = getelementptr { i64, ptr }, ptr %l375, i32 0, i32 1
  %t678 = load ptr, ptr %t677, !tbaa !27
  %t679 = getelementptr ptr, ptr %t678, i64 %t675
  %t680 = load ptr, ptr %t679, !tbaa !39
  %t681 = load ptr, ptr %l38, !tbaa !29
  %t682 = load i32, ptr %l39, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eputTarget(ptr %v0, ptr %v1, ptr %t670, ptr %t680, i1 true, ptr %t681, i32 %t682)
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s23)
  br label %bb109
bb109:
  %t687 = load i64, ptr %l36, !tbaa !24
  %t689 = add i64 %t687, 1
  store i64 %t689, ptr %l36, !tbaa !24
  br label %bb90
bb110:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb111:
  %t691 = load ptr, ptr @__olang_prog_scope
  %t692 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t691)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t692, ptr %l382
  br label %bb112
bb112:
  %t693 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l382
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t693, ptr %l41
  %t694 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t694, ptr %l383
  br label %bb113
bb113:
  %t695 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l383
  %t696 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t695, ptr %t696
  store ptr %t696, ptr %l42, !tbaa !29
  store i64 0, ptr %l43, !tbaa !24
  %t698 = load i64, ptr %l3, !tbaa !24
  store i64 %t698, ptr %l44, !tbaa !24
  store i64 1, ptr %l45, !tbaa !24
  %t700 = load i64, ptr %l44, !tbaa !24
  %t701 = load i64, ptr %l43, !tbaa !24
  %t704 = icmp sgt i64 %t700, %t701
  br i1 %t704, label %bb114, label %bb115
bb114:
  %t706 = load i64, ptr %l45, !tbaa !24
  %t708 = icmp sgt i64 %t706, 0
  br i1 %t708, label %bb116, label %bb117
bb115:
  store i64 0, ptr %l389, !tbaa !24
  br label %bb119
bb116:
  %t710 = load i64, ptr %l44, !tbaa !24
  %t711 = load i64, ptr %l43, !tbaa !24
  %t714 = sub i64 %t710, %t711
  %t715 = load i64, ptr %l45, !tbaa !24
  %t718 = add i64 %t714, %t715
  %t720 = sub i64 %t718, 1
  %t721 = load i64, ptr %l45, !tbaa !24
  %t724 = sdiv i64 %t720, %t721
  store i64 %t724, ptr %l392, !tbaa !24
  br label %bb118
bb117:
  store i64 0, ptr %l392, !tbaa !24
  br label %bb118
bb118:
  %t726 = load i64, ptr %l392, !tbaa !24
  store i64 %t726, ptr %l389, !tbaa !24
  br label %bb119
bb119:
  %t727 = load i64, ptr %l389, !tbaa !24
  store i64 %t727, ptr %l46, !tbaa !24
  store i64 0, ptr %l47, !tbaa !24
  br label %bb120
bb120:
  store %olang.scope zeroinitializer, ptr %s27
  %t728 = load i64, ptr %l47, !tbaa !24
  %t729 = load i64, ptr %l46, !tbaa !24
  %t732 = icmp slt i64 %t728, %t729
  %t734 = xor i1 %t732, true
  br i1 %t734, label %bb121, label %bb122
bb121:
  call void @__olang_scope_close(ptr %s27)
  br label %bb127
bb122:
  br label %bb123
bb123:
  %t736 = load i64, ptr %l43, !tbaa !24
  %t737 = load i64, ptr %l47, !tbaa !24
  %t738 = load i64, ptr %l45, !tbaa !24
  %t741 = mul i64 %t737, %t738
  %t744 = add i64 %t736, %t741
  %t746 = load ptr, ptr %l42, !tbaa !29
  store ptr %t746, ptr %l410, !tbaa !29
  %t747 = load ptr, ptr %l0, !tbaa !29
  %t748 = load ptr, ptr %l2, !tbaa !29
  %t750 = getelementptr %"compiler/ast:Multi", ptr %t748, i32 0, i32 0
  %t751 = load { i64, ptr }, ptr %t750, !tbaa !27
  store { i64, ptr } %t751, ptr %l413, !tbaa !27
  %t754 = getelementptr { i64, ptr }, ptr %l413, i32 0, i32 1
  %t755 = load ptr, ptr %t754, !tbaa !27
  %t756 = getelementptr ptr, ptr %t755, i64 %t744
  %t757 = load ptr, ptr %t756, !tbaa !39
  %t760 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ediscardOr(ptr %v0, ptr %v1, ptr %t747, ptr %t757)
  store ptr %t760, ptr %l416
  br label %bb124
bb124:
  %t761 = load ptr, ptr %l410, !tbaa !29
  %t762 = load ptr, ptr %l416, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2_H5eacc50cc32d6e41ff62f01e24d943f2(ptr %v0, ptr %v0, ptr %t761, ptr %t762)
  br label %bb125
bb125:
  call void @__olang_scope_close(ptr %s27)
  br label %bb126
bb126:
  %t763 = load i64, ptr %l47, !tbaa !24
  %t765 = add i64 %t763, 1
  store i64 %t765, ptr %l47, !tbaa !24
  br label %bb120
bb127:
  %t767 = load ptr, ptr %l0, !tbaa !29
  %t769 = getelementptr %"compiler/check:Checker", ptr %t767, i32 0, i32 7
  %t771 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2eLe_H7b92c806358c31ec0113c885295670e0(ptr %v0, ptr %t769)
  store i64 %t771, ptr %l421
  br label %bb128
bb128:
  %t772 = load i64, ptr %l421, !tbaa !24
  store i64 %t772, ptr %l49, !tbaa !24
  %t773 = load ptr, ptr %l42, !tbaa !29
  store ptr %t773, ptr %l50, !tbaa !29
  store i64 0, ptr %l51, !tbaa !24
  br label %bb129
bb129:
  store %olang.scope zeroinitializer, ptr %s30
  %t775 = load ptr, ptr %l50, !tbaa !29
  %t776 = load i64, ptr %l51, !tbaa !24
  %t779 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2_H3364bcea7de64bc2b6b83bde1edd9d27(ptr %v0, ptr %t775, i64 %t776)
  %t780 = extractvalue { i32, { i64, ptr } } %t779, 1
  %t781 = extractvalue { i32, { i64, ptr } } %t779, 0
  store i32 %t781, ptr %l427
  %t782 = icmp ne i32 %t781, 0
  br i1 %t782, label %bb131, label %ok.783
ok.783:
  store { i64, ptr } %t780, ptr %l426
  br label %bb130
bb130:
  %t784 = load { i64, ptr }, ptr %l426, !tbaa !27
  store { i64, ptr } %t784, ptr %l423, !tbaa !27
  br label %bb135
bb131:
  %t785 = load i32, ptr %l427, !tbaa !23
  %t786 = ashr i32 %t785, 16
  %t788 = icmp eq i32 %t786, 1
  br i1 %t788, label %bb132, label %bb133
bb132:
  br label %bb134
bb133:
  call void @__olang_check_failed(ptr @olang_loc_476fe22cd4409b92_8ac04c158b99cfe6)
  unreachable
bb134:
  call void @__olang_scope_close(ptr %s30)
  br label %bb157
bb135:
  %t790 = load { i64, ptr }, ptr %l423, !tbaa !27
  store { i64, ptr } %t790, ptr %l52, !tbaa !27
  %t791 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t793 = extractvalue { i64, ptr } %t791, 0
  store i64 %t793, ptr %l53, !tbaa !24
  store i64 0, ptr %l54, !tbaa !24
  br label %bb136
bb136:
  store %olang.scope zeroinitializer, ptr %s31
  %t795 = load i64, ptr %l54, !tbaa !24
  %t796 = load i64, ptr %l53, !tbaa !24
  %t799 = icmp slt i64 %t795, %t796
  %t801 = xor i1 %t799, true
  br i1 %t801, label %bb137, label %bb138
bb137:
  call void @__olang_scope_close(ptr %s31)
  br label %bb155
bb138:
  br label %bb139
bb139:
  %t803 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t803, ptr %l436, !tbaa !27
  %t804 = load i64, ptr %l54, !tbaa !24
  %t806 = getelementptr { i64, ptr }, ptr %l436, i32 0, i32 1
  %t807 = load ptr, ptr %t806, !tbaa !27
  %t808 = getelementptr ptr, ptr %t807, i64 %t804
  %t809 = load ptr, ptr %t808, !tbaa !39
  store ptr %t809, ptr %l55, !tbaa !29
  %t811 = load ptr, ptr %l55, !tbaa !29
  %t813 = icmp eq ptr %t811, null
  %t815 = xor i1 %t813, true
  br i1 %t815, label %bb140, label %bb141
bb140:
  %t817 = load ptr, ptr %l0, !tbaa !29
  store ptr %t817, ptr %l443, !tbaa !29
  %t818 = load ptr, ptr %l55, !tbaa !29
  %t820 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %t818)
  store i32 %t820, ptr %l445
  br label %bb142
bb141:
  store i1 false, ptr %l442, !tbaa !21
  br label %bb144
bb142:
  %t821 = load ptr, ptr %l443, !tbaa !29
  %t822 = load i32, ptr %l445, !tbaa !23
  %t823 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t821, i32 %t822)
  store i1 %t823, ptr %l446
  br label %bb143
bb143:
  %t824 = load i1, ptr %l446, !tbaa !21
  %t825 = xor i1 %t824, true
  store i1 %t825, ptr %l442, !tbaa !21
  br label %bb144
bb144:
  %t827 = load i1, ptr %l442, !tbaa !21
  br i1 %t827, label %bb145, label %bb146
bb145:
  %t828 = load ptr, ptr %l0, !tbaa !29
  %t830 = getelementptr %"compiler/check:Checker", ptr %t828, i32 0, i32 1
  %t831 = load ptr, ptr %t830, !tbaa !29
  %t833 = getelementptr %"compiler/generic:Program", ptr %t831, i32 0, i32 2
  store ptr %t833, ptr %l451, !tbaa !29
  %t834 = load ptr, ptr %l55, !tbaa !29
  %t836 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %t834)
  store i32 %t836, ptr %l453
  br label %bb147
bb146:
  store i1 false, ptr %l448, !tbaa !21
  br label %bb149
bb147:
  %t837 = load ptr, ptr %l451, !tbaa !29
  %t838 = load i32, ptr %l453, !tbaa !23
  %t839 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t837, i32 %t838)
  store i1 %t839, ptr %l454
  br label %bb148
bb148:
  %t840 = load i1, ptr %l454, !tbaa !21
  store i1 %t840, ptr %l448, !tbaa !21
  br label %bb149
bb149:
  %t841 = load i1, ptr %l448, !tbaa !21
  br i1 %t841, label %bb150, label %bb151
bb150:
  %t842 = load ptr, ptr %l0, !tbaa !29
  %t844 = getelementptr %"compiler/check:Checker", ptr %t842, i32 0, i32 7
  %t845 = load ptr, ptr %l55, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2ePu_H51141c7f79c906b1679ae982392c7956(ptr %v0, ptr %v0, ptr %t844, ptr %t845)
  br label %bb152
bb151:
  br label %bb153
bb152:
  br label %bb153
bb153:
  call void @__olang_scope_close(ptr %s31)
  br label %bb154
bb154:
  %t848 = load i64, ptr %l54, !tbaa !24
  %t850 = add i64 %t848, 1
  store i64 %t850, ptr %l54, !tbaa !24
  br label %bb136
bb155:
  %t852 = load i64, ptr %l51, !tbaa !24
  %t853 = load i64, ptr %l53, !tbaa !24
  %t856 = add i64 %t852, %t853
  store i64 %t856, ptr %l51, !tbaa !24
  call void @__olang_scope_close(ptr %s30)
  br label %bb156
bb156:
  br label %bb129
bb157:
  store i64 0, ptr %l56, !tbaa !24
  %t858 = load i64, ptr %l3, !tbaa !24
  store i64 %t858, ptr %l57, !tbaa !24
  store i64 1, ptr %l58, !tbaa !24
  %t860 = load i64, ptr %l57, !tbaa !24
  %t861 = load i64, ptr %l56, !tbaa !24
  %t864 = icmp sgt i64 %t860, %t861
  br i1 %t864, label %bb158, label %bb159
bb158:
  %t866 = load i64, ptr %l58, !tbaa !24
  %t868 = icmp sgt i64 %t866, 0
  br i1 %t868, label %bb160, label %bb161
bb159:
  store i64 0, ptr %l467, !tbaa !24
  br label %bb163
bb160:
  %t870 = load i64, ptr %l57, !tbaa !24
  %t871 = load i64, ptr %l56, !tbaa !24
  %t874 = sub i64 %t870, %t871
  %t875 = load i64, ptr %l58, !tbaa !24
  %t878 = add i64 %t874, %t875
  %t880 = sub i64 %t878, 1
  %t881 = load i64, ptr %l58, !tbaa !24
  %t884 = sdiv i64 %t880, %t881
  store i64 %t884, ptr %l470, !tbaa !24
  br label %bb162
bb161:
  store i64 0, ptr %l470, !tbaa !24
  br label %bb162
bb162:
  %t886 = load i64, ptr %l470, !tbaa !24
  store i64 %t886, ptr %l467, !tbaa !24
  br label %bb163
bb163:
  %t887 = load i64, ptr %l467, !tbaa !24
  store i64 %t887, ptr %l59, !tbaa !24
  store i64 0, ptr %l60, !tbaa !24
  br label %bb164
bb164:
  store %olang.scope zeroinitializer, ptr %s35
  %t888 = load i64, ptr %l60, !tbaa !24
  %t889 = load i64, ptr %l59, !tbaa !24
  %t892 = icmp slt i64 %t888, %t889
  %t894 = xor i1 %t892, true
  br i1 %t894, label %bb165, label %bb166
bb165:
  call void @__olang_scope_close(ptr %s35)
  br label %bb185
bb166:
  br label %bb167
bb167:
  %t896 = load i64, ptr %l56, !tbaa !24
  %t897 = load i64, ptr %l60, !tbaa !24
  %t898 = load i64, ptr %l58, !tbaa !24
  %t901 = mul i64 %t897, %t898
  %t904 = add i64 %t896, %t901
  store i64 %t904, ptr %l61, !tbaa !24
  %t906 = load ptr, ptr %l42, !tbaa !29
  %t907 = load i64, ptr %l61, !tbaa !24
  %t910 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2_Ha849274baa3792788a1b7c8fee45d023(ptr %v0, ptr %s35, ptr %t906, i64 %t907)
  store ptr %t910, ptr %l490
  br label %bb168
bb168:
  %t911 = load ptr, ptr %l490, !tbaa !29
  %t912 = icmp eq ptr %t911, null
  %t914 = xor i1 %t912, true
  br i1 %t914, label %bb169, label %bb170
bb169:
  %t916 = load ptr, ptr %l42, !tbaa !29
  %t917 = load i64, ptr %l61, !tbaa !24
  %t920 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2_Ha849274baa3792788a1b7c8fee45d023(ptr %v0, ptr %v0, ptr %t916, i64 %t917)
  store ptr %t920, ptr %l496
  br label %bb171
bb170:
  %t921 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t921, ptr %l493, !tbaa !23
  br label %bb176
bb171:
  %t923 = load ptr, ptr %l496, !tbaa !29
  store ptr %t923, ptr %l62, !tbaa !29
  %t924 = load ptr, ptr %l62, !tbaa !29
  %t926 = icmp eq ptr %t924, null
  br i1 %t926, label %bb172, label %bb173
bb172:
  call void @__olang_check_failed(ptr @olang_loc_1e0e3f8e77107efc_26f178b75df49a00)
  unreachable
bb173:
  br label %bb174
bb174:
  %t928 = load ptr, ptr %l62, !tbaa !29
  %t930 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %t928)
  store i32 %t930, ptr %l500
  br label %bb175
bb175:
  %t931 = load i32, ptr %l500, !tbaa !23
  store i32 %t931, ptr %l493, !tbaa !23
  br label %bb176
bb176:
  %t932 = load i32, ptr %l493, !tbaa !23
  %t933 = load ptr, ptr %l0, !tbaa !29
  %t934 = load ptr, ptr %l2, !tbaa !29
  %t936 = getelementptr %"compiler/ast:Multi", ptr %t934, i32 0, i32 2
  %t937 = load { i64, ptr }, ptr %t936, !tbaa !27
  store { i64, ptr } %t937, ptr %l504, !tbaa !27
  %t938 = load i64, ptr %l61, !tbaa !24
  %t940 = getelementptr { i64, ptr }, ptr %l504, i32 0, i32 1
  %t941 = load ptr, ptr %t940, !tbaa !27
  %t942 = getelementptr ptr, ptr %t941, i64 %t938
  %t943 = load ptr, ptr %t942, !tbaa !39
  %t948 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %t933, ptr %t943, i32 %t932)
  store ptr %t948, ptr %l508
  br label %bb177
bb177:
  %t949 = load ptr, ptr %l508, !tbaa !29
  store ptr %t949, ptr %l64, !tbaa !29
  %t950 = load ptr, ptr %l0, !tbaa !29
  store ptr %t950, ptr %l509, !tbaa !29
  %t951 = load ptr, ptr %l2, !tbaa !29
  %t953 = getelementptr %"compiler/ast:Multi", ptr %t951, i32 0, i32 2
  %t954 = load { i64, ptr }, ptr %t953, !tbaa !27
  store { i64, ptr } %t954, ptr %l511, !tbaa !27
  %t955 = load i64, ptr %l61, !tbaa !24
  %t957 = getelementptr { i64, ptr }, ptr %l511, i32 0, i32 1
  %t958 = load ptr, ptr %t957, !tbaa !27
  %t959 = getelementptr ptr, ptr %t958, i64 %t955
  %t960 = load ptr, ptr %t959, !tbaa !39
  %t962 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t960)
  store %"compiler/source:Span" %t962, ptr %l514
  br label %bb178
bb178:
  %t963 = load ptr, ptr %l64, !tbaa !29
  %t966 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t963)
  store i32 %t966, ptr %l517
  br label %bb179
bb179:
  store { i64, [2 x i64] } zeroinitializer, ptr %t967
  %t968 = getelementptr { i64, [2 x i64] }, ptr %t967, i32 0, i32 0
  store i64 0, ptr %t968
  %t969 = load { i64, [2 x i64] }, ptr %t967
  %t970 = load ptr, ptr %l509, !tbaa !29
  %t971 = load %"compiler/source:Span", ptr %l514
  %t972 = load i32, ptr %l517, !tbaa !23
  %t975 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t970, i32 0, %"compiler/source:Span" %t971, i32 %t972, i32 2, { i64, [2 x i64] } %t969)
  store i64 %t975, ptr %l520
  br label %bb180
bb180:
  %t976 = load i64, ptr %l520, !tbaa !24
  store i64 %t976, ptr %l65, !tbaa !24
  %t977 = load ptr, ptr %l0, !tbaa !29
  store ptr %t977, ptr %l521, !tbaa !29
  %t978 = load ptr, ptr %l2, !tbaa !29
  %t980 = getelementptr %"compiler/ast:Multi", ptr %t978, i32 0, i32 2
  %t981 = load { i64, ptr }, ptr %t980, !tbaa !27
  store { i64, ptr } %t981, ptr %l523, !tbaa !27
  %t982 = load i64, ptr %l61, !tbaa !24
  %t984 = getelementptr { i64, ptr }, ptr %l523, i32 0, i32 1
  %t985 = load ptr, ptr %t984, !tbaa !27
  %t986 = getelementptr ptr, ptr %t985, i64 %t982
  %t987 = load ptr, ptr %t986, !tbaa !39
  %t989 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t987)
  store %"compiler/source:Span" %t989, ptr %l526
  br label %bb181
bb181:
  %t990 = load i64, ptr %l65, !tbaa !24
  %t992 = trunc i64 %t990 to i32
  %t994 = load ptr, ptr %l64, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t995
  %t996 = getelementptr { i64, [3 x i64] }, ptr %t995, i32 0, i32 0
  store i64 0, ptr %t996
  %t997 = load %"compiler/source:Span", ptr %l526
  %t998 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t997, 0
  %t1000 = insertvalue { %"compiler/source:Span", i32, ptr } %t998, i32 %t992, 1
  %t1002 = insertvalue { %"compiler/source:Span", i32, ptr } %t1000, ptr %t994, 2
  %t1003 = getelementptr { i64, [3 x i64] }, ptr %t995, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1002, ptr %t1003
  %t1004 = load { i64, [3 x i64] }, ptr %t995
  %t1006 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t1004, ptr %t1006
  %t1007 = load ptr, ptr %l521, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t1007, ptr %t1006)
  br label %bb182
bb182:
  %t1009 = load i64, ptr %l65, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l41, i64 %t1009)
  br label %bb183
bb183:
  call void @__olang_scope_close(ptr %s35)
  br label %bb184
bb184:
  %t1012 = load i64, ptr %l60, !tbaa !24
  %t1014 = add i64 %t1012, 1
  store i64 %t1014, ptr %l60, !tbaa !24
  br label %bb164
bb185:
  %t1016 = load ptr, ptr %l0, !tbaa !29
  %t1018 = getelementptr %"compiler/check:Checker", ptr %t1016, i32 0, i32 7
  %t1019 = load i64, ptr %l49, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2eTr_H7b9b9c82633a95f30e02bffa16283320(ptr %v0, ptr %t1018, i64 %t1019)
  br label %bb186
bb186:
  store i64 0, ptr %l66, !tbaa !24
  %t1022 = load i64, ptr %l3, !tbaa !24
  store i64 %t1022, ptr %l67, !tbaa !24
  store i64 1, ptr %l68, !tbaa !24
  %t1024 = load i64, ptr %l67, !tbaa !24
  %t1025 = load i64, ptr %l66, !tbaa !24
  %t1028 = icmp sgt i64 %t1024, %t1025
  br i1 %t1028, label %bb187, label %bb188
bb187:
  %t1030 = load i64, ptr %l68, !tbaa !24
  %t1032 = icmp sgt i64 %t1030, 0
  br i1 %t1032, label %bb189, label %bb190
bb188:
  store i64 0, ptr %l544, !tbaa !24
  br label %bb192
bb189:
  %t1034 = load i64, ptr %l67, !tbaa !24
  %t1035 = load i64, ptr %l66, !tbaa !24
  %t1038 = sub i64 %t1034, %t1035
  %t1039 = load i64, ptr %l68, !tbaa !24
  %t1042 = add i64 %t1038, %t1039
  %t1044 = sub i64 %t1042, 1
  %t1045 = load i64, ptr %l68, !tbaa !24
  %t1048 = sdiv i64 %t1044, %t1045
  store i64 %t1048, ptr %l547, !tbaa !24
  br label %bb191
bb190:
  store i64 0, ptr %l547, !tbaa !24
  br label %bb191
bb191:
  %t1050 = load i64, ptr %l547, !tbaa !24
  store i64 %t1050, ptr %l544, !tbaa !24
  br label %bb192
bb192:
  %t1051 = load i64, ptr %l544, !tbaa !24
  store i64 %t1051, ptr %l69, !tbaa !24
  store i64 0, ptr %l70, !tbaa !24
  br label %bb193
bb193:
  store %olang.scope zeroinitializer, ptr %s38
  %t1052 = load i64, ptr %l70, !tbaa !24
  %t1053 = load i64, ptr %l69, !tbaa !24
  %t1056 = icmp slt i64 %t1052, %t1053
  %t1058 = xor i1 %t1056, true
  br i1 %t1058, label %bb194, label %bb195
bb194:
  call void @__olang_scope_close(ptr %s38)
  br label %bb209
bb195:
  br label %bb196
bb196:
  %t1060 = load i64, ptr %l66, !tbaa !24
  %t1061 = load i64, ptr %l70, !tbaa !24
  %t1062 = load i64, ptr %l68, !tbaa !24
  %t1065 = mul i64 %t1061, %t1062
  %t1068 = add i64 %t1060, %t1065
  store i64 %t1068, ptr %l71, !tbaa !24
  %t1070 = load ptr, ptr %l42, !tbaa !29
  %t1071 = load i64, ptr %l71, !tbaa !24
  %t1074 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2_Ha849274baa3792788a1b7c8fee45d023(ptr %v0, ptr %s38, ptr %t1070, i64 %t1071)
  store ptr %t1074, ptr %l567
  br label %bb197
bb197:
  %t1075 = load ptr, ptr %l567, !tbaa !29
  %t1076 = icmp eq ptr %t1075, null
  %t1078 = xor i1 %t1076, true
  br i1 %t1078, label %bb198, label %bb199
bb198:
  %t1080 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1080, ptr %l570, !tbaa !29
  %t1081 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1081, ptr %l571
  %t1082 = load ptr, ptr %l42, !tbaa !29
  %t1083 = load i64, ptr %l71, !tbaa !24
  %t1086 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2_Ha849274baa3792788a1b7c8fee45d023(ptr %v0, ptr %v0, ptr %t1082, i64 %t1083)
  store ptr %t1086, ptr %l574
  br label %bb200
bb199:
  br label %bb207
bb200:
  %t1087 = load ptr, ptr %l574, !tbaa !29
  store ptr %t1087, ptr %l72, !tbaa !29
  %t1088 = load ptr, ptr %l72, !tbaa !29
  %t1090 = icmp eq ptr %t1088, null
  br i1 %t1090, label %bb201, label %bb202
bb201:
  call void @__olang_check_failed(ptr @olang_loc_c3a1911177000af1_d7f4a899cd404215)
  unreachable
bb202:
  br label %bb203
bb203:
  %t1092 = load ptr, ptr %l72, !tbaa !29
  store ptr %t1092, ptr %l577, !tbaa !29
  %t1093 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1093, ptr %l578, !tbaa !29
  %t1094 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1094, ptr %l579
  %t1095 = load i64, ptr %l71, !tbaa !24
  %t1098 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l41, i64 %t1095)
  store i64 %t1098, ptr %l582
  br label %bb204
bb204:
  %t1099 = load ptr, ptr %l578, !tbaa !29
  %t1100 = load %"compiler/source:Span", ptr %l579
  %t1101 = load i64, ptr %l582, !tbaa !24
  %t1102 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t1099, %"compiler/source:Span" %t1100, i64 %t1101)
  store ptr %t1102, ptr %l583
  br label %bb205
bb205:
  store { i64, [3 x i64] } zeroinitializer, ptr %t1103
  %t1104 = getelementptr { i64, [3 x i64] }, ptr %t1103, i32 0, i32 0
  store i64 1, ptr %t1104
  %t1105 = load %"compiler/source:Span", ptr %l571
  %t1106 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t1105, 0
  %t1107 = load ptr, ptr %l577, !tbaa !29
  %t1108 = insertvalue { %"compiler/source:Span", ptr, ptr } %t1106, ptr %t1107, 1
  %t1109 = load ptr, ptr %l583, !tbaa !29
  %t1110 = insertvalue { %"compiler/source:Span", ptr, ptr } %t1108, ptr %t1109, 2
  %t1111 = getelementptr { i64, [3 x i64] }, ptr %t1103, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t1110, ptr %t1111
  %t1112 = load { i64, [3 x i64] }, ptr %t1103
  %t1114 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t1112, ptr %t1114
  %t1115 = load ptr, ptr %l570, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t1115, ptr %t1114)
  br label %bb206
bb206:
  br label %bb207
bb207:
  call void @__olang_scope_close(ptr %s38)
  br label %bb208
bb208:
  %t1117 = load i64, ptr %l70, !tbaa !24
  %t1119 = add i64 %t1117, 1
  store i64 %t1119, ptr %l70, !tbaa !24
  br label %bb193
bb209:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutBefore(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %l21 = alloca i1
  %l23 = alloca %"compiler/source:Span"
  %l26 = alloca i1
  %l27 = alloca %"compiler/source:Span"
  %l31 = alloca i1
  %l34 = alloca i1
  %l35 = alloca i1
  %l40 = alloca i32
  %l43 = alloca %"compiler/source:Span"
  %l47 = alloca i1
  %l49 = alloca %"compiler/source:Span"
  %l54 = alloca i1
  %l57 = alloca i1
  %l58 = alloca %"compiler/source:Span"
  %l62 = alloca %"compiler/source:Span"
  %l63 = alloca %"compiler/source:Span"
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 4
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l3
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t18, i32 0, i32 1
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l4, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t24, i32 0, i32 2
  %t26 = load i1, ptr %t25
  store i1 %t26, ptr %l5, !tbaa !21
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t30, i32 0, i32 3
  %t32 = load i1, ptr %t31
  store i1 %t32, ptr %l6, !tbaa !21
  br label %bb5
bb4:
  br label %bb43
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t34 = load i1, ptr %l5, !tbaa !21
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb8
bb7:
  %t38 = load i1, ptr %l6, !tbaa !21
  store i1 %t38, ptr %l21, !tbaa !21
  br label %bb8
bb8:
  %t40 = load i1, ptr %l21, !tbaa !21
  br i1 %t40, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s2, i32 -1, i32 -1)
  store %"compiler/source:Span" %t41, ptr %l23
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  %t42 = load %"compiler/source:Span", ptr %l23
  store %"compiler/source:Span" %t42, ptr %rv
  br label %ret
bb12:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l4, !tbaa !29
  %t47 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesTypeVar(ptr %v0, ptr %v1, ptr %t43, ptr %t44)
  store i1 %t47, ptr %l26
  br label %bb13
bb13:
  %t48 = load i1, ptr %l26, !tbaa !21
  br i1 %t48, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t49 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s3, i32 -1, i32 -1)
  store %"compiler/source:Span" %t49, ptr %l27
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s1)
  %t50 = load %"compiler/source:Span", ptr %l27
  store %"compiler/source:Span" %t50, ptr %rv
  br label %ret
bb17:
  %t51 = load i32, ptr %l2, !tbaa !23
  %t52 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t55 = icmp ne i32 %t51, %t52
  br i1 %t55, label %bb18, label %bb19
bb18:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load i32, ptr %l2, !tbaa !23
  %t61 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t57, i32 %t58)
  store i1 %t61, ptr %l34
  br label %bb20
bb19:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb25
bb20:
  %t62 = load i1, ptr %l34, !tbaa !21
  br i1 %t62, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb24
bb22:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  %t69 = load i32, ptr %l2, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t68, i32 %t69)
  store i32 %t72, ptr %l40
  br label %bb23
bb23:
  %t73 = load i32, ptr %l40
  %t75 = trunc i64 25 to i32
  %t76 = icmp eq i32 %t73, %t75
  store i1 %t76, ptr %l35, !tbaa !21
  br label %bb24
bb24:
  %t78 = load i1, ptr %l35, !tbaa !21
  store i1 %t78, ptr %l31, !tbaa !21
  br label %bb25
bb25:
  %t79 = load i1, ptr %l31, !tbaa !21
  br i1 %t79, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  %t80 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s4, i32 -1, i32 -1)
  store %"compiler/source:Span" %t80, ptr %l43
  br label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s1)
  %t81 = load %"compiler/source:Span", ptr %l43
  store %"compiler/source:Span" %t81, ptr %rv
  br label %ret
bb29:
  %t82 = load i32, ptr %l2, !tbaa !23
  %t83 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t86 = icmp eq i32 %t82, %t83
  br i1 %t86, label %bb30, label %bb31
bb30:
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t88)
  store %"compiler/source:Span" %t90, ptr %l49
  br label %bb32
bb31:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb33
bb32:
  %t91 = getelementptr %"compiler/source:Span", ptr %l49, i32 0, i32 1
  %t92 = load i32, ptr %t91, !tbaa !23
  %t93 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t94 = load i32, ptr %t93, !tbaa !23
  %t96 = add i32 %t94, 3
  %t99 = icmp sgt i32 %t92, %t96
  store i1 %t99, ptr %l47, !tbaa !21
  br label %bb33
bb33:
  %t101 = load i1, ptr %l47, !tbaa !21
  br i1 %t101, label %bb34, label %bb35
bb34:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t106 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenRefOrVar(ptr %v0, ptr %v1, ptr %t102, ptr %t103)
  store i1 %t106, ptr %l57
  br label %bb36
bb35:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb37
bb36:
  %t107 = load i1, ptr %l57, !tbaa !21
  store i1 %t107, ptr %l54, !tbaa !21
  br label %bb37
bb37:
  %t108 = load i1, ptr %l54, !tbaa !21
  br i1 %t108, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s5
  %t109 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s5, i32 -1, i32 -1)
  store %"compiler/source:Span" %t109, ptr %l58
  br label %bb40
bb39:
  br label %bb41
bb40:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s1)
  %t110 = load %"compiler/source:Span", ptr %l58
  store %"compiler/source:Span" %t110, ptr %rv
  br label %ret
bb41:
  %t111 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t112 = load i32, ptr %t111, !tbaa !23
  %t113 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t114 = load i32, ptr %t113, !tbaa !23
  %t116 = add i32 %t114, 3
  %t119 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 %t112, i32 %t116)
  store %"compiler/source:Span" %t119, ptr %l62
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s1)
  %t120 = load %"compiler/source:Span", ptr %l62
  store %"compiler/source:Span" %t120, ptr %rv
  br label %ret
bb43:
  store %olang.scope zeroinitializer, ptr %s6
  %t121 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s6, i32 -1, i32 -1)
  store %"compiler/source:Span" %t121, ptr %l63
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s6)
  %t122 = load %"compiler/source:Span", ptr %l63
  store %"compiler/source:Span" %t122, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrow(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca ptr
  %l22 = alloca ptr
  %l25 = alloca i32
  %l28 = alloca i32
  %l31 = alloca i64
  %l34 = alloca ptr
  %l37 = alloca ptr
  %l42 = alloca i32
  %l43 = alloca i32
  %l44 = alloca { i64, ptr }
  %l58 = alloca i1
  %l59 = alloca %"compiler/source:Span"
  %l60 = alloca i32
  %l64 = alloca ptr
  %l69 = alloca ptr
  %l74 = alloca i32
  %l75 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l79 = alloca %"compiler/source:Span"
  %l80 = alloca i32
  %l84 = alloca %"compiler/typed:Payload"
  %l93 = alloca i64
  %l96 = alloca i64
  %l116 = alloca { i64, ptr }
  %l121 = alloca i64
  %l125 = alloca { i64, ptr }
  %l132 = alloca ptr
  %l150 = alloca ptr
  %l157 = alloca %"compiler/check:narrowed"
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %t64 = alloca { i64, [4 x i64] }, align 8
  %t94 = alloca { i64, [4 x i64] }, align 8
  %t144 = alloca { i64, [4 x i64] }, align 8
  %t216 = alloca { i64, [2 x i64] }, align 8
  %t238 = alloca { i64, [4 x i64] }, align 8
  %t270 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l22
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l22, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t5, i64 %t6)
  store i32 %t9, ptr %l25
  br label %bb2
bb2:
  %t10 = load i32, ptr %l25, !tbaa !23
  store i32 %t10, ptr %l5, !tbaa !23
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l5, !tbaa !23
  %t15 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l28
  br label %bb3
bb3:
  %t16 = load i32, ptr %l28, !tbaa !23
  store i32 %t16, ptr %l6, !tbaa !23
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t19 = getelementptr %"compiler/check:frame", ptr %t17, i32 0, i32 44
  %t21 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t19)
  store i64 %t21, ptr %l31
  br label %bb4
bb4:
  %t22 = load i64, ptr %l31, !tbaa !24
  store i64 %t22, ptr %l7, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  store ptr %t28, ptr %l34, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  store ptr %t34, ptr %l37, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t39 = load i32, ptr %l6, !tbaa !23
  %t40 = load i64, ptr %l3, !tbaa !24
  %t44 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %t38, i32 %t39, i64 %t40)
  store i32 %t44, ptr %l42
  br label %bb5
bb5:
  %t45 = load ptr, ptr %l37, !tbaa !29
  %t46 = load i32, ptr %l42, !tbaa !23
  %t47 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t45, i32 %t46)
  store i32 %t47, ptr %l43
  br label %bb6
bb6:
  %t48 = load ptr, ptr %l34, !tbaa !29
  %t49 = load i32, ptr %l43, !tbaa !23
  %t50 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t48, i32 %t49)
  store { i64, ptr } %t50, ptr %l44
  br label %bb7
bb7:
  %t51 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t51, ptr %l8, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t56 = icmp sgt i64 %t54, 0
  br i1 %t56, label %bb8, label %bb9
bb8:
  %t58 = load %"compiler/source:Span", ptr %l1
  %t59 = load i32, ptr %l5, !tbaa !23
  %t60 = load i64, ptr %l2, !tbaa !24
  %t62 = trunc i64 %t60 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t64
  %t65 = getelementptr { i64, [4 x i64] }, ptr %t64, i32 0, i32 0
  store i64 0, ptr %t65
  %t67 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t58, 0
  %t69 = insertvalue { %"compiler/source:Span", i32, i32 } %t67, i32 %t59, 1
  %t71 = insertvalue { %"compiler/source:Span", i32, i32 } %t69, i32 %t62, 2
  %t72 = getelementptr { i64, [4 x i64] }, ptr %t64, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t71, ptr %t72
  %t73 = load { i64, [4 x i64] }, ptr %t64
  %t75 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t73, ptr %t75
  store ptr %t75, ptr %l9, !tbaa !29
  %t77 = load ptr, ptr %l9, !tbaa !29
  store ptr %t77, ptr %l10, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load i32, ptr %l5, !tbaa !23
  %t83 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t79, i32 %t80)
  store i1 %t83, ptr %l58
  br label %bb10
bb9:
  br label %bb35
bb10:
  %t84 = load i1, ptr %l58, !tbaa !21
  br i1 %t84, label %bb11, label %bb12
bb11:
  %t85 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t85, ptr %l59
  %t86 = load i32, ptr %l6, !tbaa !23
  store i32 %t86, ptr %l60, !tbaa !23
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load %"compiler/source:Span", ptr %l1
  %t89 = load ptr, ptr %l9, !tbaa !29
  %t93 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t87, %"compiler/source:Span" %t88, ptr %t89)
  store ptr %t93, ptr %l64
  br label %bb13
bb12:
  br label %bb14
bb13:
  store { i64, [4 x i64] } zeroinitializer, ptr %t94
  %t95 = getelementptr { i64, [4 x i64] }, ptr %t94, i32 0, i32 0
  store i64 2, ptr %t95
  %t96 = load %"compiler/source:Span", ptr %l59
  %t97 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t96, 0
  %t98 = load i32, ptr %l60, !tbaa !23
  %t99 = insertvalue { %"compiler/source:Span", i32, ptr } %t97, i32 %t98, 1
  %t100 = load ptr, ptr %l64, !tbaa !29
  %t101 = insertvalue { %"compiler/source:Span", i32, ptr } %t99, ptr %t100, 2
  %t102 = getelementptr { i64, [4 x i64] }, ptr %t94, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t101, ptr %t102
  %t103 = load { i64, [4 x i64] }, ptr %t94
  %t105 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t103, ptr %t105
  store ptr %t105, ptr %l10, !tbaa !29
  br label %bb14
bb14:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/check:Checker", ptr %t107, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/generic:Program", ptr %t110, i32 0, i32 2
  store ptr %t112, ptr %l69, !tbaa !29
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/check:Checker", ptr %t113, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = getelementptr %"compiler/generic:Program", ptr %t116, i32 0, i32 2
  %t119 = load i32, ptr %l6, !tbaa !23
  %t122 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t118, i32 %t119)
  store i32 %t122, ptr %l74
  br label %bb15
bb15:
  %t123 = load ptr, ptr %l69, !tbaa !29
  %t124 = load i32, ptr %l74, !tbaa !23
  %t125 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t123, i32 %t124)
  store { i64, ptr } %t125, ptr %l75
  br label %bb16
bb16:
  %t126 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t126, ptr %l76, !tbaa !27
  %t127 = load i64, ptr %l3, !tbaa !24
  %t129 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr i32, ptr %t130, i64 %t127
  %t132 = load i32, ptr %t131, !tbaa !33
  %t134 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t134, ptr %l79
  store i32 %t132, ptr %l80, !tbaa !23
  %t136 = load ptr, ptr %l10, !tbaa !29
  %t137 = load i64, ptr %l3, !tbaa !24
  %t141 = call %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v0, ptr %t136, i64 %t137, i32 0)
  store %"compiler/typed:Payload" %t141, ptr %l84
  br label %bb17
bb17:
  %t142 = load %"compiler/typed:Payload", ptr %l84
  %t143 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Payload" %t142, ptr %t143
  store { i64, [4 x i64] } zeroinitializer, ptr %t144
  %t145 = getelementptr { i64, [4 x i64] }, ptr %t144, i32 0, i32 0
  store i64 5, ptr %t145
  %t146 = load %"compiler/source:Span", ptr %l79
  %t147 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t146, 0
  %t148 = load i32, ptr %l80, !tbaa !23
  %t149 = insertvalue { %"compiler/source:Span", i32, ptr } %t147, i32 %t148, 1
  %t151 = insertvalue { %"compiler/source:Span", i32, ptr } %t149, ptr %t143, 2
  %t152 = getelementptr { i64, [4 x i64] }, ptr %t144, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t151, ptr %t152
  %t153 = load { i64, [4 x i64] }, ptr %t144
  %t155 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t153, ptr %t155
  store ptr %t155, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  %t157 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t157, 0
  store i64 %t159, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t161 = load i64, ptr %l14, !tbaa !24
  %t162 = load i64, ptr %l13, !tbaa !24
  %t165 = icmp sgt i64 %t161, %t162
  br i1 %t165, label %bb18, label %bb19
bb18:
  %t167 = load i64, ptr %l15, !tbaa !24
  %t169 = icmp sgt i64 %t167, 0
  br i1 %t169, label %bb20, label %bb21
bb19:
  store i64 0, ptr %l93, !tbaa !24
  br label %bb23
bb20:
  %t171 = load i64, ptr %l14, !tbaa !24
  %t172 = load i64, ptr %l13, !tbaa !24
  %t175 = sub i64 %t171, %t172
  %t176 = load i64, ptr %l15, !tbaa !24
  %t179 = add i64 %t175, %t176
  %t181 = sub i64 %t179, 1
  %t182 = load i64, ptr %l15, !tbaa !24
  %t185 = sdiv i64 %t181, %t182
  store i64 %t185, ptr %l96, !tbaa !24
  br label %bb22
bb21:
  store i64 0, ptr %l96, !tbaa !24
  br label %bb22
bb22:
  %t187 = load i64, ptr %l96, !tbaa !24
  store i64 %t187, ptr %l93, !tbaa !24
  br label %bb23
bb23:
  %t188 = load i64, ptr %l93, !tbaa !24
  store i64 %t188, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s4
  %t189 = load i64, ptr %l17, !tbaa !24
  %t190 = load i64, ptr %l16, !tbaa !24
  %t193 = icmp slt i64 %t189, %t190
  %t195 = xor i1 %t193, true
  br i1 %t195, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s4)
  br label %bb34
bb26:
  br label %bb27
bb27:
  %t197 = load i64, ptr %l13, !tbaa !24
  %t198 = load i64, ptr %l17, !tbaa !24
  %t199 = load i64, ptr %l15, !tbaa !24
  %t202 = mul i64 %t198, %t199
  %t205 = add i64 %t197, %t202
  store i64 %t205, ptr %l18, !tbaa !24
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load %"compiler/source:Span", ptr %l1
  %t209 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t209, ptr %l116, !tbaa !27
  %t210 = load i64, ptr %l18, !tbaa !24
  %t212 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t213 = load ptr, ptr %t212, !tbaa !27
  %t214 = getelementptr i32, ptr %t213, i64 %t210
  %t215 = load i32, ptr %t214, !tbaa !33
  store { i64, [2 x i64] } zeroinitializer, ptr %t216
  %t217 = getelementptr { i64, [2 x i64] }, ptr %t216, i32 0, i32 0
  store i64 5, ptr %t217
  %t218 = load { i64, [2 x i64] }, ptr %t216
  %t224 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t207, i32 0, %"compiler/source:Span" %t208, i32 %t215, i32 4, { i64, [2 x i64] } %t218)
  store i64 %t224, ptr %l121
  br label %bb28
bb28:
  %t225 = load i64, ptr %l121, !tbaa !24
  store i64 %t225, ptr %l19, !tbaa !24
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t227 = load %"compiler/source:Span", ptr %l1
  %t228 = load %"compiler/source:Span", ptr %l1
  %t229 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t229, ptr %l125, !tbaa !27
  %t230 = load i64, ptr %l18, !tbaa !24
  %t232 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !27
  %t234 = getelementptr i32, ptr %t233, i64 %t230
  %t235 = load i32, ptr %t234, !tbaa !33
  %t236 = load ptr, ptr %l12, !tbaa !29
  %t237 = load i64, ptr %l18, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t238
  %t239 = getelementptr { i64, [4 x i64] }, ptr %t238, i32 0, i32 0
  store i64 3, ptr %t239
  %t241 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t228, 0
  %t243 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t241, i32 %t235, 1
  %t245 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t243, ptr %t236, 2
  %t247 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t245, i64 %t237, 3
  %t248 = getelementptr { i64, [4 x i64] }, ptr %t238, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t247, ptr %t248
  %t249 = load { i64, [4 x i64] }, ptr %t238
  %t251 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t249, ptr %t251
  %t255 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t226, %"compiler/source:Span" %t227, ptr %t251)
  store ptr %t255, ptr %l132
  br label %bb29
bb29:
  %t256 = load ptr, ptr %l132, !tbaa !29
  store ptr %t256, ptr %l20, !tbaa !29
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load i64, ptr %l19, !tbaa !24
  %t259 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v0, ptr %t257, i64 %t258, ptr %t259)
  br label %bb30
bb30:
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t264 = load %"compiler/source:Span", ptr %l1
  %t265 = load i64, ptr %l19, !tbaa !24
  %t267 = trunc i64 %t265 to i32
  %t269 = load ptr, ptr %l20, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t270
  %t271 = getelementptr { i64, [3 x i64] }, ptr %t270, i32 0, i32 0
  store i64 0, ptr %t271
  %t273 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t264, 0
  %t275 = insertvalue { %"compiler/source:Span", i32, ptr } %t273, i32 %t267, 1
  %t277 = insertvalue { %"compiler/source:Span", i32, ptr } %t275, ptr %t269, 2
  %t278 = getelementptr { i64, [3 x i64] }, ptr %t270, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t277, ptr %t278
  %t279 = load { i64, [3 x i64] }, ptr %t270
  %t281 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t279, ptr %t281
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t263, ptr %t281)
  br label %bb31
bb31:
  %t284 = load ptr, ptr %l4, !tbaa !29
  %t286 = getelementptr %"compiler/check:frame", ptr %t284, i32 0, i32 44
  %t287 = load i64, ptr %l19, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t286, i64 %t287)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s4)
  br label %bb33
bb33:
  %t290 = load i64, ptr %l17, !tbaa !24
  %t292 = add i64 %t290, 1
  store i64 %t292, ptr %l17, !tbaa !24
  br label %bb24
bb34:
  br label %bb35
bb35:
  %t294 = load ptr, ptr %l4, !tbaa !29
  %t296 = getelementptr %"compiler/check:frame", ptr %t294, i32 0, i32 43
  store ptr %t296, ptr %l150, !tbaa !29
  %t297 = load i64, ptr %l2, !tbaa !24
  %t298 = load i64, ptr %l3, !tbaa !24
  %t299 = load i32, ptr %l6, !tbaa !23
  %t300 = load i64, ptr %l7, !tbaa !24
  %t301 = load ptr, ptr %l4, !tbaa !29
  %t303 = getelementptr %"compiler/check:frame", ptr %t301, i32 0, i32 7
  %t304 = load i64, ptr %t303, !tbaa !24
  %t310 = call %"compiler/check:narrowed" @compiler_2fcheck_3anarrowed_2ector(ptr %s0, i64 %t297, i64 %t298, i32 %t299, i64 %t300, i64 %t304)
  store %"compiler/check:narrowed" %t310, ptr %l157
  br label %bb36
bb36:
  %t311 = load ptr, ptr %l150, !tbaa !29
  %t312 = load %"compiler/check:narrowed", ptr %l157
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anarrowed_3e_2ePu_H8ca7ff483075a23de06ba27b878260e2(ptr %v0, ptr %t311, %"compiler/check:narrowed" %t312)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4, i64 %a5, i1 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca ptr
  %l15 = alloca %"compiler/source:Span"
  %l19 = alloca i1
  %l22 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i32
  %l33 = alloca i32
  %l34 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i32
  %l43 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l47 = alloca i32
  %l48 = alloca i64
  %l54 = alloca ptr
  %l57 = alloca ptr
  %l61 = alloca i32
  %l62 = alloca i32
  %l63 = alloca { i64, ptr }
  %l67 = alloca i1
  %l77 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l99 = alloca ptr
  %l100 = alloca %"compiler/source:Span"
  %l103 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l105 = alloca ptr
  %l109 = alloca ptr
  %l112 = alloca { i64, ptr }
  %l116 = alloca %"compiler/msgs:Msg"
  %l117 = alloca i64
  %l121 = alloca ptr
  %l125 = alloca ptr
  %l129 = alloca i64
  %l130 = alloca ptr
  %l138 = alloca ptr
  %l139 = alloca i64
  %l145 = alloca { i64, [3 x i64] }
  %l149 = alloca { i64, ptr }
  %l151 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i1
  %t311 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i64 %a5, ptr %l5
  store i1 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb4
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t7, i32 %t8)
  store i1 %t11, ptr %l22
  br label %bb3
bb3:
  %t12 = load i1, ptr %l22, !tbaa !21
  %t13 = xor i1 %t12, true
  store i1 %t13, ptr %l19, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l19, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  store ptr %t20, ptr %l26, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  store i32 %t21, ptr %l27, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 0
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/load:Loader", ptr %t28, i32 0, i32 3
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t32 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t35 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %t31, { i64, ptr } %t32)
  store i32 %t35, ptr %l33
  br label %bb8
bb8:
  %t36 = load ptr, ptr %l26, !tbaa !29
  %t37 = load i32, ptr %l27, !tbaa !23
  %t38 = load i32, ptr %l33, !tbaa !23
  %t39 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t36, i32 %t37, i32 %t38)
  store i64 %t39, ptr %l34
  br label %bb9
bb9:
  %t40 = load i64, ptr %l34, !tbaa !24
  store i64 %t40, ptr %l7, !tbaa !24
  %t41 = load i64, ptr %l7, !tbaa !24
  %t43 = icmp slt i64 %t41, 0
  br i1 %t43, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  store ptr %t48, ptr %l38, !tbaa !29
  %t49 = load i32, ptr %l1, !tbaa !23
  store i32 %t49, ptr %l39, !tbaa !23
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 0
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = getelementptr %"compiler/load:Loader", ptr %t56, i32 0, i32 3
  %t59 = load ptr, ptr %t58, !tbaa !29
  store ptr %t59, ptr %l43, !tbaa !29
  %t60 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t62 = call { i64, ptr } @compiler_2fcheck_2elowerFirst(ptr %v1, ptr %s2, { i64, ptr } %t60)
  store { i64, ptr } %t62, ptr %l45
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t63 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 0
  %t65 = extractvalue { i64, ptr } %t63, 1
  %t66 = mul i64 %t64, 1
  %t67 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t66)
  call void @llvm.memcpy.p0.p0.i64(ptr %t67, ptr %t65, i64 %t66, i1 false)
  %t68 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  %t70 = load ptr, ptr %l43, !tbaa !29
  %t72 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s2, ptr %t70, { i64, ptr } %t69)
  store i32 %t72, ptr %l47
  br label %bb13
bb13:
  %t73 = load ptr, ptr %l38, !tbaa !29
  %t74 = load i32, ptr %l39, !tbaa !23
  %t75 = load i32, ptr %l47, !tbaa !23
  %t76 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t73, i32 %t74, i32 %t75)
  store i64 %t76, ptr %l48
  br label %bb14
bb14:
  %t77 = load i64, ptr %l48, !tbaa !24
  store i64 %t77, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  %t78 = load i64, ptr %l7, !tbaa !24
  %t80 = icmp slt i64 %t78, 0
  br i1 %t80, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  store ptr %t88, ptr %l54, !tbaa !29
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/check:Checker", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t94 = getelementptr %"compiler/generic:Program", ptr %t92, i32 0, i32 2
  store ptr %t94, ptr %l57, !tbaa !29
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/check:Checker", ptr %t95, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t99 = load i64, ptr %l7, !tbaa !24
  %t102 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t98, i64 %t99)
  store i32 %t102, ptr %l61
  br label %bb19
bb19:
  %t103 = load ptr, ptr %l57, !tbaa !29
  %t104 = load i32, ptr %l61, !tbaa !23
  %t105 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t103, i32 %t104)
  store i32 %t105, ptr %l62
  br label %bb20
bb20:
  %t106 = load ptr, ptr %l54, !tbaa !29
  %t107 = load i32, ptr %l62, !tbaa !23
  %t108 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t106, i32 %t107)
  store { i64, ptr } %t108, ptr %l63
  br label %bb21
bb21:
  %t109 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  %t112 = sub i64 %t110, 1
  store i64 %t112, ptr %l8, !tbaa !24
  %t114 = load i1, ptr %l6, !tbaa !21
  br i1 %t114, label %bb22, label %bb23
bb22:
  %t116 = load i64, ptr %l8, !tbaa !24
  %t117 = load i64, ptr %l5, !tbaa !24
  %t120 = icmp sge i64 %t116, %t117
  store i1 %t120, ptr %l67, !tbaa !21
  br label %bb24
bb23:
  %t122 = load i64, ptr %l8, !tbaa !24
  %t123 = load i64, ptr %l5, !tbaa !24
  %t126 = icmp eq i64 %t122, %t123
  store i1 %t126, ptr %l67, !tbaa !21
  br label %bb24
bb24:
  %t128 = load i1, ptr %l67, !tbaa !21
  br i1 %t128, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t130 = load i64, ptr %l8, !tbaa !24
  %t132 = icmp eq i64 %t130, 0
  br i1 %t132, label %bb28, label %bb29
bb28:
  store { i64, ptr } { i64 13, ptr @.d43 }, ptr %l77, !tbaa !27
  br label %bb33
bb29:
  %t134 = load i64, ptr %l8, !tbaa !24
  %t136 = icmp eq i64 %t134, 1
  br i1 %t136, label %bb30, label %bb31
bb30:
  store { i64, ptr } { i64 13, ptr @.d44 }, ptr %l80, !tbaa !27
  br label %bb32
bb31:
  %t138 = load i64, ptr %l8, !tbaa !24
  %t140 = call i64 @__olang_fmt_i64(ptr null, i64 %t138)
  %t141 = extractvalue { i64, ptr } { i64 11, ptr @.d45 }, 1
  %t142 = extractvalue { i64, ptr } { i64 11, ptr @.d45 }, 0
  %t143 = add i64 %t140, %t142
  %t144 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t143)
  %t145 = call i64 @__olang_fmt_i64(ptr %t144, i64 %t138)
  %t146 = getelementptr i8, ptr %t144, i64 %t140
  call void @olang_textcopy(ptr %t146, ptr %t141, i64 %t142)
  %t147 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t144, 1
  %t150 = extractvalue { i64, ptr } %t148, 0
  %t151 = extractvalue { i64, ptr } %t148, 1
  %t152 = mul i64 %t150, 1
  %t153 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t152)
  call void @llvm.memcpy.p0.p0.i64(ptr %t153, ptr %t151, i64 %t152, i1 false)
  %t154 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t153, 1
  store { i64, ptr } %t155, ptr %l80, !tbaa !27
  br label %bb32
bb32:
  %t157 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t157, ptr %l77, !tbaa !27
  br label %bb33
bb33:
  %t158 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t158, ptr %l9, !tbaa !27
  %t159 = load i64, ptr %l5, !tbaa !24
  %t161 = icmp eq i64 %t159, 1
  br i1 %t161, label %bb34, label %bb35
bb34:
  store { i64, ptr } { i64 3, ptr @.d46 }, ptr %l86, !tbaa !27
  br label %bb36
bb35:
  %t163 = load i64, ptr %l5, !tbaa !24
  %t165 = call i64 @__olang_fmt_i64(ptr null, i64 %t163)
  %t166 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t165)
  %t167 = call i64 @__olang_fmt_i64(ptr %t166, i64 %t163)
  %t168 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t169 = insertvalue { i64, ptr } %t168, ptr %t166, 1
  %t171 = extractvalue { i64, ptr } %t169, 0
  %t172 = extractvalue { i64, ptr } %t169, 1
  %t173 = mul i64 %t171, 1
  %t174 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t173)
  call void @llvm.memcpy.p0.p0.i64(ptr %t174, ptr %t172, i64 %t173, i1 false)
  %t175 = insertvalue { i64, ptr } undef, i64 %t171, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t174, 1
  store { i64, ptr } %t176, ptr %l86, !tbaa !27
  br label %bb36
bb36:
  %t178 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t178, ptr %l10, !tbaa !27
  %t179 = load i64, ptr %l5, !tbaa !24
  %t181 = icmp eq i64 %t179, 0
  br i1 %t181, label %bb37, label %bb38
bb37:
  store { i64, ptr } { i64 4, ptr @.d47 }, ptr %l92, !tbaa !27
  br label %bb42
bb38:
  %t183 = load i1, ptr %l6, !tbaa !21
  br i1 %t183, label %bb39, label %bb40
bb39:
  %t185 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t186 = extractvalue { i64, ptr } { i64 9, ptr @.d48 }, 1
  %t187 = extractvalue { i64, ptr } { i64 9, ptr @.d48 }, 0
  %t189 = extractvalue { i64, ptr } %t185, 1
  %t190 = extractvalue { i64, ptr } %t185, 0
  %t191 = add i64 %t187, %t190
  %t192 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t191)
  call void @olang_textcopy(ptr %t192, ptr %t186, i64 %t187)
  %t193 = getelementptr i8, ptr %t192, i64 %t187
  call void @olang_textcopy(ptr %t193, ptr %t189, i64 %t190)
  %t194 = insertvalue { i64, ptr } undef, i64 %t191, 0
  %t195 = insertvalue { i64, ptr } %t194, ptr %t192, 1
  %t197 = extractvalue { i64, ptr } %t195, 0
  %t198 = extractvalue { i64, ptr } %t195, 1
  %t199 = mul i64 %t197, 1
  %t200 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t199)
  call void @llvm.memcpy.p0.p0.i64(ptr %t200, ptr %t198, i64 %t199, i1 false)
  %t201 = insertvalue { i64, ptr } undef, i64 %t197, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t200, 1
  store { i64, ptr } %t202, ptr %l94, !tbaa !27
  br label %bb41
bb40:
  %t204 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t204, ptr %l94, !tbaa !27
  br label %bb41
bb41:
  %t206 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t206, ptr %l92, !tbaa !27
  br label %bb42
bb42:
  %t207 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t207, ptr %l11, !tbaa !27
  %t208 = load ptr, ptr %l0, !tbaa !29
  store ptr %t208, ptr %l99, !tbaa !29
  store %"compiler/source:Span" %a3, ptr %l100
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t211 = load i32, ptr %l1, !tbaa !23
  %t214 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t210, i32 %t211)
  store { i64, ptr } %t214, ptr %l103
  br label %bb43
bb43:
  %t215 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t215, 0
  %t217 = extractvalue { i64, ptr } %t215, 1
  %t218 = mul i64 %t216, 1
  %t219 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t218)
  call void @llvm.memcpy.p0.p0.i64(ptr %t219, ptr %t217, i64 %t218, i1 false)
  %t220 = insertvalue { i64, ptr } undef, i64 %t216, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr %t219, 1
  store { i64, ptr } %t221, ptr %l104, !tbaa !27
  %t222 = load ptr, ptr %l0, !tbaa !29
  store ptr %t222, ptr %l105, !tbaa !29
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = getelementptr %"compiler/check:Checker", ptr %t223, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !29
  %t227 = load i64, ptr %l7, !tbaa !24
  %t230 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t226, i64 %t227)
  store ptr %t230, ptr %l109
  br label %bb44
bb44:
  %t231 = load ptr, ptr %l109, !tbaa !29
  %t233 = getelementptr %"compiler/ast:Func", ptr %t231, i32 0, i32 2
  %t234 = load i32, ptr %t233, !tbaa !23
  %t235 = load ptr, ptr %l105, !tbaa !29
  %t237 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t235, i32 %t234)
  store { i64, ptr } %t237, ptr %l112
  br label %bb45
bb45:
  %t238 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t240 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t241 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t242 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t246 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotTheOperator(ptr %s0, ptr %v0, ptr %s0, ptr %v2, ptr %s0, ptr %s0, { i64, ptr } %t241, { i64, ptr } %t242, { i64, ptr } %t238, { i64, ptr } %a4, { i64, ptr } %t240)
  store %"compiler/msgs:Msg" %t246, ptr %l116
  br label %bb46
bb46:
  %t247 = load ptr, ptr %l99, !tbaa !29
  %t248 = load %"compiler/source:Span", ptr %l100
  %t249 = load %"compiler/msgs:Msg", ptr %l116
  %t250 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t247, %"compiler/source:Span" %t248, %"compiler/msgs:Msg" %t249)
  store i64 %t250, ptr %l117
  br label %bb47
bb47:
  %t251 = load i64, ptr %l117, !tbaa !24
  store i64 %t251, ptr %l12, !tbaa !24
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr %"compiler/check:Checker", ptr %t252, i32 0, i32 1
  %t255 = load ptr, ptr %t254, !tbaa !29
  %t256 = load i64, ptr %l7, !tbaa !24
  %t259 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t255, i64 %t256)
  store ptr %t259, ptr %l121
  br label %bb48
bb48:
  %t260 = load ptr, ptr %l121, !tbaa !29
  store ptr %t260, ptr %l13, !tbaa !29
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"compiler/check:Checker", ptr %t261, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !29
  %t266 = getelementptr %"compiler/generic:Program", ptr %t264, i32 0, i32 0
  %t267 = load ptr, ptr %t266, !tbaa !29
  %t269 = getelementptr %"compiler/load:Loader", ptr %t267, i32 0, i32 5
  store ptr %t269, ptr %l125, !tbaa !29
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t272 = getelementptr %"compiler/check:Checker", ptr %t270, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !29
  %t274 = load i64, ptr %l7, !tbaa !24
  %t277 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t273, i64 %t274)
  store i64 %t277, ptr %l129
  br label %bb49
bb49:
  %t278 = load ptr, ptr %l125, !tbaa !29
  %t279 = load i64, ptr %l129, !tbaa !24
  %t280 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t278, i64 %t279)
  store ptr %t280, ptr %l130
  br label %bb50
bb50:
  %t281 = load ptr, ptr %l130, !tbaa !29
  %t283 = getelementptr %"compiler/load:Module", ptr %t281, i32 0, i32 4
  %t284 = load i64, ptr %t283, !tbaa !24
  %t286 = load ptr, ptr %l13, !tbaa !29
  %t288 = getelementptr %"compiler/ast:Func", ptr %t286, i32 0, i32 0
  %t289 = load %"compiler/source:Span", ptr %t288
  store %"compiler/source:Span" %t289, ptr %l15
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t293 = getelementptr %"compiler/check:Checker", ptr %t291, i32 0, i32 1
  %t294 = load ptr, ptr %t293, !tbaa !29
  %t296 = getelementptr %"compiler/generic:Program", ptr %t294, i32 0, i32 0
  %t297 = load ptr, ptr %t296, !tbaa !29
  %t299 = getelementptr %"compiler/load:Loader", ptr %t297, i32 0, i32 4
  %t300 = load ptr, ptr %t299, !tbaa !29
  store ptr %t300, ptr %l138, !tbaa !29
  %t301 = load i64, ptr %l12, !tbaa !24
  store i64 %t301, ptr %l139, !tbaa !24
  %t303 = getelementptr %"compiler/source:Span", ptr %l15, i32 0, i32 0
  %t304 = load i32, ptr %t303, !tbaa !23
  %t306 = sext i32 %t304 to i64
  %t307 = getelementptr %"compiler/source:Span", ptr %l15, i32 0, i32 1
  %t308 = load i32, ptr %t307, !tbaa !23
  %t310 = sext i32 %t308 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t311
  %t312 = getelementptr { i64, [3 x i64] }, ptr %t311, i32 0, i32 0
  store i64 3, ptr %t312
  %t314 = insertvalue { i64, i64, i64 } undef, i64 %t284, 0
  %t316 = insertvalue { i64, i64, i64 } %t314, i64 %t306, 1
  %t318 = insertvalue { i64, i64, i64 } %t316, i64 %t310, 2
  %t319 = getelementptr { i64, [3 x i64] }, ptr %t311, i32 0, i32 1
  store { i64, i64, i64 } %t318, ptr %t319
  %t320 = load { i64, [3 x i64] }, ptr %t311
  store { i64, [3 x i64] } %t320, ptr %l145
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t322 = load ptr, ptr %l13, !tbaa !29
  %t324 = getelementptr %"compiler/ast:Func", ptr %t322, i32 0, i32 2
  %t325 = load i32, ptr %t324, !tbaa !23
  %t328 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s0, ptr %t321, i32 %t325)
  store { i64, ptr } %t328, ptr %l149
  br label %bb51
bb51:
  %t329 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t330 = extractvalue { i64, ptr } %t329, 0
  %t331 = extractvalue { i64, ptr } %t329, 1
  %t332 = mul i64 %t330, 1
  %t333 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t332)
  call void @llvm.memcpy.p0.p0.i64(ptr %t333, ptr %t331, i64 %t332, i1 false)
  %t334 = insertvalue { i64, ptr } undef, i64 %t330, 0
  %t335 = insertvalue { i64, ptr } %t334, ptr %t333, 1
  %t337 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDeclaredHere(ptr %s0, ptr %s0, { i64, ptr } %t335)
  store %"compiler/msgs:Msg" %t337, ptr %l151
  br label %bb52
bb52:
  %t338 = load ptr, ptr %l138, !tbaa !29
  %t339 = load i64, ptr %l139, !tbaa !24
  %t340 = load { i64, [3 x i64] }, ptr %l145
  %t341 = load %"compiler/msgs:Msg", ptr %l151
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s0, ptr %t338, i64 %t339, { i64, [3 x i64] } %t340, %"compiler/msgs:Msg" %t341)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoverrideClash(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca i1
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i32
  %l20 = alloca i32
  %l23 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l36 = alloca i32
  %l39 = alloca i1
  %l41 = alloca i1
  %l46 = alloca i1
  %l51 = alloca ptr
  %l57 = alloca i64
  %l60 = alloca i1
  %l67 = alloca i32
  %l70 = alloca ptr
  %l75 = alloca i32
  %l76 = alloca { i64, ptr }
  %l87 = alloca i64
  %l90 = alloca i64
  %l113 = alloca { i64, ptr }
  %l116 = alloca i1
  %l117 = alloca i1
  %l121 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l127 = alloca i1
  %l135 = alloca i32
  %l137 = alloca i1
  %l142 = alloca i1
  %l143 = alloca i1
  %l146 = alloca ptr
  %l147 = alloca i32
  %l152 = alloca i32
  %l153 = alloca i1
  %l156 = alloca ptr
  %l160 = alloca i64
  %l162 = alloca ptr
  %l163 = alloca ptr
  %l166 = alloca %"compiler/source:Span"
  %l170 = alloca { i64, ptr }
  %l171 = alloca %"compiler/msgs:Msg"
  %l172 = alloca i64
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t4, i64 %t5)
  store i32 %t8, ptr %l20
  br label %bb1
bb1:
  %t9 = load i32, ptr %l20, !tbaa !23
  store i32 %t9, ptr %l2, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  store ptr %t15, ptr %l23, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l28
  br label %bb2
bb2:
  %t26 = load ptr, ptr %l23, !tbaa !29
  %t27 = load i32, ptr %l28, !tbaa !23
  %t28 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t26, i32 %t27)
  store { i64, ptr } %t28, ptr %l29
  br label %bb3
bb3:
  %t29 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t29, ptr %l3, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  %t34 = icmp eq i64 %t32, 0
  br i1 %t34, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  br label %bb6
bb6:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t37, ptr %l34, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr i32, ptr %t39, i64 0
  %t41 = load i32, ptr %t40, !tbaa !33
  %t44 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t36, i32 %t41)
  store i32 %t44, ptr %l36
  br label %bb7
bb7:
  %t45 = load i32, ptr %l36, !tbaa !23
  store i32 %t45, ptr %l4, !tbaa !23
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i32, ptr %l4, !tbaa !23
  %t50 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t46, i32 %t47)
  store i1 %t50, ptr %l39
  br label %bb8
bb8:
  %t51 = load i1, ptr %l39, !tbaa !21
  %t52 = xor i1 %t51, true
  br i1 %t52, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb12
bb10:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/generic:Program", ptr %t57, i32 0, i32 2
  %t60 = load i32, ptr %l4, !tbaa !23
  %t63 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t59, i32 %t60)
  store i1 %t63, ptr %l46
  br label %bb11
bb11:
  %t64 = load i1, ptr %l46, !tbaa !21
  %t65 = xor i1 %t64, true
  store i1 %t65, ptr %l41, !tbaa !21
  br label %bb12
bb12:
  %t67 = load i1, ptr %l41, !tbaa !21
  br i1 %t67, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  br label %bb15
bb15:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/check:Checker", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t72 = load i64, ptr %l1, !tbaa !24
  %t75 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t71, i64 %t72)
  store ptr %t75, ptr %l51
  br label %bb16
bb16:
  %t76 = load ptr, ptr %l51, !tbaa !29
  store ptr %t76, ptr %l5, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t81 = load i32, ptr %l4, !tbaa !23
  %t82 = load ptr, ptr %l5, !tbaa !29
  %t84 = getelementptr %"compiler/ast:Func", ptr %t82, i32 0, i32 2
  %t85 = load i32, ptr %t84, !tbaa !23
  %t89 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultMethod(ptr %v0, ptr %t80, i32 %t81, i32 %t85)
  store i64 %t89, ptr %l57
  br label %bb17
bb17:
  %t90 = load i64, ptr %l57, !tbaa !24
  store i64 %t90, ptr %l6, !tbaa !24
  %t91 = load i64, ptr %l6, !tbaa !24
  %t93 = icmp slt i64 %t91, 0
  br i1 %t93, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb20
bb19:
  %t95 = load i64, ptr %l6, !tbaa !24
  %t96 = load i64, ptr %l1, !tbaa !24
  %t99 = icmp eq i64 %t95, %t96
  store i1 %t99, ptr %l60, !tbaa !21
  br label %bb20
bb20:
  %t101 = load i1, ptr %l60, !tbaa !21
  br i1 %t101, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb22:
  br label %bb23
bb23:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/check:Checker", ptr %t102, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t106 = load i64, ptr %l6, !tbaa !24
  %t109 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t105, i64 %t106)
  store i32 %t109, ptr %l67
  br label %bb24
bb24:
  %t110 = load i32, ptr %l67, !tbaa !23
  store i32 %t110, ptr %l7, !tbaa !23
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/check:Checker", ptr %t111, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = getelementptr %"compiler/generic:Program", ptr %t114, i32 0, i32 2
  store ptr %t116, ptr %l70, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = getelementptr %"compiler/generic:Program", ptr %t120, i32 0, i32 2
  %t123 = load i32, ptr %l7, !tbaa !23
  %t126 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t122, i32 %t123)
  store i32 %t126, ptr %l75
  br label %bb25
bb25:
  %t127 = load ptr, ptr %l70, !tbaa !29
  %t128 = load i32, ptr %l75, !tbaa !23
  %t129 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t127, i32 %t128)
  store { i64, ptr } %t129, ptr %l76
  br label %bb26
bb26:
  %t130 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t130, ptr %l8, !tbaa !27
  %t131 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t131, 0
  %t134 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t134, 0
  %t139 = icmp eq i64 %t133, %t136
  store i1 %t139, ptr %l9, !tbaa !21
  store i64 1, ptr %l10, !tbaa !24
  %t141 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t141, 0
  store i64 %t143, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t145 = load i64, ptr %l11, !tbaa !24
  %t146 = load i64, ptr %l10, !tbaa !24
  %t149 = icmp sgt i64 %t145, %t146
  br i1 %t149, label %bb27, label %bb28
bb27:
  %t151 = load i64, ptr %l12, !tbaa !24
  %t153 = icmp sgt i64 %t151, 0
  br i1 %t153, label %bb29, label %bb30
bb28:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb32
bb29:
  %t155 = load i64, ptr %l11, !tbaa !24
  %t156 = load i64, ptr %l10, !tbaa !24
  %t159 = sub i64 %t155, %t156
  %t160 = load i64, ptr %l12, !tbaa !24
  %t163 = add i64 %t159, %t160
  %t165 = sub i64 %t163, 1
  %t166 = load i64, ptr %l12, !tbaa !24
  %t169 = sdiv i64 %t165, %t166
  store i64 %t169, ptr %l90, !tbaa !24
  br label %bb31
bb30:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb31
bb31:
  %t171 = load i64, ptr %l90, !tbaa !24
  store i64 %t171, ptr %l87, !tbaa !24
  br label %bb32
bb32:
  %t172 = load i64, ptr %l87, !tbaa !24
  store i64 %t172, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s5
  %t173 = load i64, ptr %l14, !tbaa !24
  %t174 = load i64, ptr %l13, !tbaa !24
  %t177 = icmp slt i64 %t173, %t174
  %t179 = xor i1 %t177, true
  br i1 %t179, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s5)
  br label %bb49
bb35:
  br label %bb36
bb36:
  %t181 = load i64, ptr %l10, !tbaa !24
  %t182 = load i64, ptr %l14, !tbaa !24
  %t183 = load i64, ptr %l12, !tbaa !24
  %t186 = mul i64 %t182, %t183
  %t189 = add i64 %t181, %t186
  store i64 %t189, ptr %l15, !tbaa !24
  %t191 = load i1, ptr %l9, !tbaa !21
  %t193 = xor i1 %t191, true
  br i1 %t193, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s5)
  br label %bb49
bb38:
  br label %bb39
bb39:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/check:Checker", ptr %t195, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !29
  %t200 = getelementptr %"compiler/generic:Program", ptr %t198, i32 0, i32 2
  %t201 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t201, ptr %l113, !tbaa !27
  %t202 = load i64, ptr %l15, !tbaa !24
  %t204 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !27
  %t206 = getelementptr i32, ptr %t205, i64 %t202
  %t207 = load i32, ptr %t206, !tbaa !33
  %t210 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t200, i32 %t207)
  store i1 %t210, ptr %l116
  br label %bb40
bb40:
  %t211 = load i1, ptr %l116, !tbaa !21
  br i1 %t211, label %bb41, label %bb42
bb41:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/check:Checker", ptr %t212, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !29
  %t217 = getelementptr %"compiler/generic:Program", ptr %t215, i32 0, i32 2
  %t218 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t218, ptr %l121, !tbaa !27
  %t219 = load i64, ptr %l15, !tbaa !24
  %t221 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t222 = load ptr, ptr %t221, !tbaa !27
  %t223 = getelementptr i32, ptr %t222, i64 %t219
  %t224 = load i32, ptr %t223, !tbaa !33
  %t225 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t225, ptr %l124, !tbaa !27
  %t226 = load i64, ptr %l15, !tbaa !24
  %t228 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t229 = load ptr, ptr %t228, !tbaa !27
  %t230 = getelementptr i32, ptr %t229, i64 %t226
  %t231 = load i32, ptr %t230, !tbaa !33
  %t235 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t217, i32 %t224, i32 %t231)
  store i1 %t235, ptr %l127
  br label %bb43
bb42:
  store i1 false, ptr %l117, !tbaa !21
  br label %bb44
bb43:
  %t236 = load i1, ptr %l127, !tbaa !21
  %t237 = xor i1 %t236, true
  store i1 %t237, ptr %l117, !tbaa !21
  br label %bb44
bb44:
  %t239 = load i1, ptr %l117, !tbaa !21
  br i1 %t239, label %bb45, label %bb46
bb45:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb47
bb46:
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s5)
  br label %bb48
bb48:
  %t240 = load i64, ptr %l14, !tbaa !24
  %t242 = add i64 %t240, 1
  store i64 %t242, ptr %l14, !tbaa !24
  br label %bb33
bb49:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr %"compiler/check:Checker", ptr %t244, i32 0, i32 1
  %t247 = load ptr, ptr %t246, !tbaa !29
  %t249 = getelementptr %"compiler/generic:Program", ptr %t247, i32 0, i32 2
  %t250 = load i32, ptr %l7, !tbaa !23
  %t253 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t249, i32 %t250)
  store i32 %t253, ptr %l135
  br label %bb50
bb50:
  %t254 = load i32, ptr %l135, !tbaa !23
  store i32 %t254, ptr %l16, !tbaa !23
  %t255 = load i1, ptr %l9, !tbaa !21
  br i1 %t255, label %bb51, label %bb52
bb51:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/check:Checker", ptr %t257, i32 0, i32 1
  %t260 = load ptr, ptr %t259, !tbaa !29
  %t262 = getelementptr %"compiler/generic:Program", ptr %t260, i32 0, i32 2
  %t263 = load i32, ptr %l16, !tbaa !23
  %t266 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t262, i32 %t263)
  store i1 %t266, ptr %l142
  br label %bb53
bb52:
  store i1 false, ptr %l137, !tbaa !21
  br label %bb54
bb53:
  %t267 = load i1, ptr %l142, !tbaa !21
  store i1 %t267, ptr %l137, !tbaa !21
  br label %bb54
bb54:
  %t268 = load i1, ptr %l137, !tbaa !21
  br i1 %t268, label %bb55, label %bb56
bb55:
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"compiler/check:Checker", ptr %t269, i32 0, i32 1
  %t272 = load ptr, ptr %t271, !tbaa !29
  %t274 = getelementptr %"compiler/generic:Program", ptr %t272, i32 0, i32 2
  store ptr %t274, ptr %l146, !tbaa !29
  %t275 = load i32, ptr %l16, !tbaa !23
  store i32 %t275, ptr %l147, !tbaa !23
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t278 = getelementptr %"compiler/check:Checker", ptr %t276, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !29
  %t281 = getelementptr %"compiler/generic:Program", ptr %t279, i32 0, i32 2
  %t282 = load i32, ptr %l2, !tbaa !23
  %t285 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t281, i32 %t282)
  store i32 %t285, ptr %l152
  br label %bb57
bb56:
  store i1 false, ptr %l143, !tbaa !21
  br label %bb59
bb57:
  %t286 = load ptr, ptr %l146, !tbaa !29
  %t287 = load i32, ptr %l147, !tbaa !23
  %t288 = load i32, ptr %l152, !tbaa !23
  %t289 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t286, i32 %t287, i32 %t288)
  store i1 %t289, ptr %l153
  br label %bb58
bb58:
  %t290 = load i1, ptr %l153, !tbaa !21
  %t291 = xor i1 %t290, true
  store i1 %t291, ptr %l143, !tbaa !21
  br label %bb59
bb59:
  %t293 = load i1, ptr %l143, !tbaa !21
  br i1 %t293, label %bb60, label %bb61
bb60:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb62
bb61:
  br label %bb62
bb62:
  %t294 = load i1, ptr %l9, !tbaa !21
  br i1 %t294, label %bb63, label %bb64
bb63:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb64:
  br label %bb65
bb65:
  %t296 = load ptr, ptr %l0, !tbaa !29
  store ptr %t296, ptr %l156, !tbaa !29
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t299 = getelementptr %"compiler/check:Checker", ptr %t297, i32 0, i32 1
  %t300 = load ptr, ptr %t299, !tbaa !29
  %t301 = load i64, ptr %l1, !tbaa !24
  %t304 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t300, i64 %t301)
  store i64 %t304, ptr %l160
  br label %bb66
bb66:
  %t305 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t306 = load ptr, ptr %l156, !tbaa !29
  %t307 = load i64, ptr %l160, !tbaa !24
  %t309 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t306, i64 -1, i64 %t307, i32 %t305, i32 0)
  store ptr %t309, ptr %l162
  br label %bb67
bb67:
  %t310 = load ptr, ptr %l0, !tbaa !29
  store ptr %t310, ptr %l163, !tbaa !29
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t312 = load ptr, ptr %l5, !tbaa !29
  %t315 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v0, ptr %t311, ptr %t312)
  store %"compiler/source:Span" %t315, ptr %l166
  br label %bb68
bb68:
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t317 = load ptr, ptr %l5, !tbaa !29
  %t319 = getelementptr %"compiler/ast:Func", ptr %t317, i32 0, i32 2
  %t320 = load i32, ptr %t319, !tbaa !23
  %t323 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t316, i32 %t320)
  store { i64, ptr } %t323, ptr %l170
  br label %bb69
bb69:
  %t324 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t325 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOverrideSignature(ptr %v0, ptr %s0, { i64, ptr } %t324)
  store %"compiler/msgs:Msg" %t325, ptr %l171
  br label %bb70
bb70:
  %t326 = load ptr, ptr %l163, !tbaa !29
  %t327 = load %"compiler/source:Span", ptr %l166
  %t328 = load %"compiler/msgs:Msg", ptr %l171
  %t329 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t326, %"compiler/source:Span" %t327, %"compiler/msgs:Msg" %t328)
  store i64 %t329, ptr %l172
  br label %bb71
bb71:
  %t330 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t330)
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eowningIn(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l14 = alloca i1
  %l23 = alloca i32
  %l30 = alloca i64
  %l36 = alloca i1
  %l41 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l61 = alloca i1
  %l68 = alloca i1
  %l73 = alloca i32
  %l75 = alloca ptr
  %l80 = alloca i32
  %l83 = alloca i1
  %l86 = alloca i1
  %l90 = alloca i1
  %l91 = alloca i1
  %l94 = alloca ptr
  %l99 = alloca i32
  %l100 = alloca i32
  %l105 = alloca ptr
  %l110 = alloca i32
  %l111 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l125 = alloca i1
  %s5 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t5, %t6
  store i1 %t9, ptr %l14, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l14, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l23
  br label %bb7
bb7:
  %t23 = load i32, ptr %l23
  store i32 %t23, ptr %l3
  %t24 = load i32, ptr %l3
  %t26 = trunc i64 20 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb8, label %bb9
bb8:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t35 = load i32, ptr %l1, !tbaa !23
  %t38 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t34, i32 %t35)
  store i64 %t38, ptr %l30
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t39 = load i64, ptr @G_2ecompiler_2ftypes_2eOwning, !tbaa !24
  %t40 = load i64, ptr %l30, !tbaa !24
  %t42 = and i64 %t40, %t39
  %t44 = icmp ne i64 %t42, 0
  store i1 %t44, ptr %rv
  br label %ret
bb11:
  %t46 = load i32, ptr %l3
  %t48 = trunc i64 22 to i32
  %t49 = icmp eq i32 %t46, %t48
  br i1 %t49, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb14
bb13:
  %t51 = load i32, ptr %l3
  %t53 = trunc i64 23 to i32
  %t54 = icmp eq i32 %t51, %t53
  store i1 %t54, ptr %l36, !tbaa !21
  br label %bb14
bb14:
  %t56 = load i1, ptr %l36, !tbaa !21
  br i1 %t56, label %bb15, label %bb16
bb15:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 2
  store ptr %t62, ptr %l41, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  %t69 = load i32, ptr %l1, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t68, i32 %t69)
  store i32 %t72, ptr %l46
  br label %bb17
bb16:
  br label %bb29
bb17:
  %t73 = load ptr, ptr %l41, !tbaa !29
  %t74 = load i32, ptr %l46, !tbaa !23
  %t75 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t73, i32 %t74)
  store { i64, ptr } %t75, ptr %l47
  br label %bb18
bb18:
  %t76 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t76, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t77 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t77, 0
  store i64 %t79, ptr %l6, !tbaa !24
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  %t81 = load i64, ptr %l5, !tbaa !24
  %t82 = load i64, ptr %l6, !tbaa !24
  %t85 = icmp slt i64 %t81, %t82
  %t87 = xor i1 %t85, true
  br i1 %t87, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s5)
  br label %bb28
bb21:
  br label %bb22
bb22:
  %t89 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t89, ptr %l54, !tbaa !27
  %t90 = load i64, ptr %l5, !tbaa !24
  %t92 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr i32, ptr %t93, i64 %t90
  %t95 = load i32, ptr %t94, !tbaa !33
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = load i64, ptr %l2, !tbaa !24
  %t101 = add i64 %t99, 1
  %t105 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eowningIn(ptr %v0, ptr %t97, i32 %t95, i64 %t101)
  store i1 %t105, ptr %l61
  br label %bb23
bb23:
  %t106 = load i1, ptr %l61, !tbaa !21
  br i1 %t106, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s5)
  store i1 true, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s5)
  br label %bb27
bb27:
  %t108 = load i64, ptr %l5, !tbaa !24
  %t110 = add i64 %t108, 1
  store i64 %t110, ptr %l5, !tbaa !24
  br label %bb19
bb28:
  store i1 false, ptr %rv
  br label %ret
bb29:
  %t113 = load i32, ptr %l3
  %t115 = trunc i64 19 to i32
  %t116 = icmp eq i32 %t113, %t115
  br i1 %t116, label %bb30, label %bb31
bb30:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/check:Checker", ptr %t118, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t123 = getelementptr %"compiler/generic:Program", ptr %t121, i32 0, i32 2
  %t124 = load i32, ptr %l1, !tbaa !23
  %t127 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t123, i32 %t124)
  store i32 %t127, ptr %l73
  br label %bb32
bb31:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb33
bb32:
  %t128 = load i32, ptr %l73, !tbaa !23
  %t129 = icmp ne i32 %t128, 0
  store i1 %t129, ptr %l68, !tbaa !21
  br label %bb33
bb33:
  %t131 = load i1, ptr %l68, !tbaa !21
  br i1 %t131, label %bb34, label %bb35
bb34:
  %t132 = load ptr, ptr %l0, !tbaa !29
  store ptr %t132, ptr %l75, !tbaa !29
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/check:Checker", ptr %t133, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t138 = getelementptr %"compiler/generic:Program", ptr %t136, i32 0, i32 2
  %t139 = load i32, ptr %l1, !tbaa !23
  %t142 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t138, i32 %t139)
  store i32 %t142, ptr %l80
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t143 = load i64, ptr %l2, !tbaa !24
  %t145 = add i64 %t143, 1
  %t146 = load ptr, ptr %l75, !tbaa !29
  %t147 = load i32, ptr %l80, !tbaa !23
  %t149 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eowningIn(ptr %v0, ptr %t146, i32 %t147, i64 %t145)
  store i1 %t149, ptr %l83
  br label %bb37
bb37:
  %t150 = load i1, ptr %l83, !tbaa !21
  store i1 %t150, ptr %rv
  br label %ret
bb38:
  %t151 = load i32, ptr %l3
  %t153 = trunc i64 18 to i32
  %t154 = icmp eq i32 %t151, %t153
  br i1 %t154, label %bb39, label %bb40
bb39:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/check:Checker", ptr %t156, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t160 = load i32, ptr %l1, !tbaa !23
  %t163 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t159, i32 %t160)
  store i1 %t163, ptr %l90
  br label %bb41
bb40:
  store i1 false, ptr %l86, !tbaa !21
  br label %bb42
bb41:
  %t164 = load i1, ptr %l90, !tbaa !21
  store i1 %t164, ptr %l86, !tbaa !21
  br label %bb42
bb42:
  %t165 = load i1, ptr %l86, !tbaa !21
  br i1 %t165, label %bb43, label %bb44
bb43:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/check:Checker", ptr %t166, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !29
  %t171 = getelementptr %"compiler/generic:Program", ptr %t169, i32 0, i32 2
  store ptr %t171, ptr %l94, !tbaa !29
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr %"compiler/check:Checker", ptr %t172, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !29
  %t177 = getelementptr %"compiler/generic:Program", ptr %t175, i32 0, i32 2
  %t178 = load i32, ptr %l1, !tbaa !23
  %t181 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t177, i32 %t178)
  store i32 %t181, ptr %l99
  br label %bb45
bb44:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb47
bb45:
  %t182 = load ptr, ptr %l94, !tbaa !29
  %t183 = load i32, ptr %l99, !tbaa !23
  %t184 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t182, i32 %t183)
  store i32 %t184, ptr %l100
  br label %bb46
bb46:
  %t185 = load i32, ptr %l100
  %t187 = trunc i64 0 to i32
  %t188 = icmp eq i32 %t185, %t187
  store i1 %t188, ptr %l91, !tbaa !21
  br label %bb47
bb47:
  %t190 = load i1, ptr %l91, !tbaa !21
  br i1 %t190, label %bb48, label %bb49
bb48:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/check:Checker", ptr %t191, i32 0, i32 1
  %t194 = load ptr, ptr %t193, !tbaa !29
  %t196 = getelementptr %"compiler/generic:Program", ptr %t194, i32 0, i32 2
  store ptr %t196, ptr %l105, !tbaa !29
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/check:Checker", ptr %t197, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !29
  %t202 = getelementptr %"compiler/generic:Program", ptr %t200, i32 0, i32 2
  %t203 = load i32, ptr %l1, !tbaa !23
  %t206 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t202, i32 %t203)
  store i32 %t206, ptr %l110
  br label %bb50
bb49:
  br label %bb62
bb50:
  %t207 = load ptr, ptr %l105, !tbaa !29
  %t208 = load i32, ptr %l110, !tbaa !23
  %t209 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t207, i32 %t208)
  store { i64, ptr } %t209, ptr %l111
  br label %bb51
bb51:
  %t210 = load { i64, ptr }, ptr %l111, !tbaa !27
  store { i64, ptr } %t210, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t211 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t211, 0
  store i64 %t213, ptr %l10, !tbaa !24
  br label %bb52
bb52:
  store %olang.scope zeroinitializer, ptr %s11
  %t215 = load i64, ptr %l9, !tbaa !24
  %t216 = load i64, ptr %l10, !tbaa !24
  %t219 = icmp slt i64 %t215, %t216
  %t221 = xor i1 %t219, true
  br i1 %t221, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s11)
  br label %bb61
bb54:
  br label %bb55
bb55:
  %t223 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t223, ptr %l118, !tbaa !27
  %t224 = load i64, ptr %l9, !tbaa !24
  %t226 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !27
  %t228 = getelementptr i32, ptr %t227, i64 %t224
  %t229 = load i32, ptr %t228, !tbaa !33
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t233 = load i64, ptr %l2, !tbaa !24
  %t235 = add i64 %t233, 1
  %t239 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eowningIn(ptr %v0, ptr %t231, i32 %t229, i64 %t235)
  store i1 %t239, ptr %l125
  br label %bb56
bb56:
  %t240 = load i1, ptr %l125, !tbaa !21
  br i1 %t240, label %bb57, label %bb58
bb57:
  call void @__olang_scope_close(ptr %s11)
  store i1 true, ptr %rv
  br label %ret
bb58:
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s11)
  br label %bb60
bb60:
  %t242 = load i64, ptr %l9, !tbaa !24
  %t244 = add i64 %t242, 1
  store i64 %t244, ptr %l9, !tbaa !24
  br label %bb52
bb61:
  br label %bb62
bb62:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparam(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i64 %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca ptr
  %l7 = alloca i64
  %l9 = alloca ptr
  %l14 = alloca { i64, [2 x i64] }
  %l21 = alloca i64
  %l23 = alloca ptr
  %l33 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca i64
  %l39 = alloca { i64, [3 x i64] }
  store ptr %a0, ptr %l0
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/check:Checker", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 2
  %t11 = load ptr, ptr %l9, !tbaa !29
  %t14 = call { i64, [2 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eParamMark(ptr %v0, ptr %v0, ptr %t11, ptr %t9, i64 %a4)
  store { i64, [2 x i64] } %t14, ptr %l14
  br label %bb2
bb2:
  %t15 = load { i64, [2 x i64] }, ptr %l14
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t27 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t16, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 0, { i64, [2 x i64] } %t15)
  store i64 %t27, ptr %l21
  br label %bb3
bb3:
  %t28 = load i64, ptr %l21, !tbaa !24
  store i64 %t28, ptr %l7, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t29)
  store ptr %t31, ptr %l23
  br label %bb4
bb4:
  %t32 = load ptr, ptr %l23, !tbaa !29
  %t34 = getelementptr %"compiler/typed:Body", ptr %t32, i32 0, i32 5
  %t35 = load i64, ptr %l7, !tbaa !24
  %t37 = trunc i64 %t35 to i32
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2ePus_H9afb0399fee55ed1ef4b4d03ad72cb66(ptr %v0, ptr %t34, i32 %t37)
  br label %bb5
bb5:
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t43 = icmp eq ptr %t41, null
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb6, label %bb7
bb6:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t47)
  store ptr %t49, ptr %l33
  br label %bb8
bb7:
  br label %bb11
bb8:
  %t50 = load ptr, ptr %l33, !tbaa !29
  %t52 = getelementptr %"compiler/check:frame", ptr %t50, i32 0, i32 3
  store ptr %t52, ptr %l35, !tbaa !29
  %t53 = load i64, ptr %l7, !tbaa !24
  store i64 %t53, ptr %l36, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l5, !tbaa !29
  %t58 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeWrittenAt(ptr %v0, ptr %v1, ptr %t54, ptr %t55)
  store { i64, [3 x i64] } %t58, ptr %l39
  br label %bb9
bb9:
  %t59 = load ptr, ptr %l35, !tbaa !29
  %t60 = load i64, ptr %l36, !tbaa !24
  %t61 = load { i64, [3 x i64] }, ptr %l39
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_Hc07a7e56a24d8f1225398db99ea19a4b(ptr %v0, ptr %t59, i64 %t60, { i64, [3 x i64] } %t61)
  br label %bb10
bb10:
  br label %bb11
bb11:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatWild(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t11 = load ptr, ptr %l6, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l6, !tbaa !29
  %t15 = load i64, ptr %t14
  %t17 = icmp eq i64 %t15, 3
  store i1 %t17, ptr %l7, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l7, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim3(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l6 = alloca i64
  %l9 = alloca i64
  %l19 = alloca %"compiler/source:Span"
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca i32
  %l28 = alloca { i64, ptr }
  %rv = alloca ptr
  %t38 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 31
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l6, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 31
  %t10 = load ptr, ptr %l3, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t9, ptr %t10)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 31
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t15, ptr %a4)
  br label %bb3
bb3:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 31
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t21, ptr %a5)
  br label %bb4
bb4:
  store %"compiler/source:Span" %a1, ptr %l19
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t29 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t26)
  store i32 %t29, ptr %l22
  br label %bb5
bb5:
  store i32 %a2, ptr %l23
  store i32 2, ptr %l24
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 31
  %t34 = load i64, ptr %l6, !tbaa !24
  %t37 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t33, i64 %t34)
  store { i64, ptr } %t37, ptr %l28
  br label %bb6
bb6:
  store { i64, [5 x i64] } zeroinitializer, ptr %t38
  %t39 = getelementptr { i64, [5 x i64] }, ptr %t38, i32 0, i32 0
  store i64 9, ptr %t39
  %t40 = load %"compiler/source:Span", ptr %l19
  %t41 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t40, 0
  %t42 = load i32, ptr %l22, !tbaa !23
  %t43 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t41, i32 %t42, 1
  %t44 = load i32, ptr %l23
  %t45 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t43, i32 %t44, 2
  %t46 = load i32, ptr %l24
  %t47 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t45, i32 %t46, 3
  %t48 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t49 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t47, { i64, ptr } %t48, 4
  %t50 = getelementptr { i64, [5 x i64] }, ptr %t38, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t49, ptr %t50
  %t51 = load { i64, [5 x i64] }, ptr %t38
  %t53 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t51, ptr %t53
  store ptr %t53, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2equalifierFor(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"compiler/load:Import"
  %l8 = alloca { i64, ptr }
  %l12 = alloca i64
  %l14 = alloca i1
  %l15 = alloca i64
  %l17 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l30 = alloca ptr
  %l33 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i32
  %l49 = alloca { i64, ptr }
  %l59 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i32
  %l63 = alloca { i64, ptr }
  %l65 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i64
  %l81 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l83 = alloca i64
  %l84 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 12
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_H2d42092ce658fb6cce0104fa754a4e33(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i64, ptr %l12, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb5
bb3:
  %t9 = load i64, ptr %l1, !tbaa !24
  store i64 %t9, ptr %l15, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t10)
  store ptr %t12, ptr %l17
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l17, !tbaa !29
  %t15 = getelementptr %"compiler/check:frame", ptr %t13, i32 0, i32 1
  %t16 = load i64, ptr %t15, !tbaa !24
  %t17 = load i64, ptr %l15, !tbaa !24
  %t19 = icmp eq i64 %t17, %t16
  store i1 %t19, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t21 = load i1, ptr %l14, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 0, ptr @.d49 }, ptr %l21, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t22, ptr %l22, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 0
  store i64 %t24, ptr %l23, !tbaa !24
  %t25 = load i64, ptr %l23, !tbaa !24
  %t26 = mul i64 %t25, 1
  %t27 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  store { i64, ptr } %t29, ptr %l24, !tbaa !27
  %t30 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = load i64, ptr %l23, !tbaa !24
  %t35 = mul i64 %t34, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t31, ptr %t33, i64 %t35, i1 false)
  %t36 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t36, ptr %l22, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t37, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 0
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/load:Loader", ptr %t44, i32 0, i32 5
  store ptr %t46, ptr %l28, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t47)
  store ptr %t49, ptr %l30
  br label %bb9
bb9:
  %t50 = load ptr, ptr %l30, !tbaa !29
  %t52 = getelementptr %"compiler/check:frame", ptr %t50, i32 0, i32 1
  %t53 = load i64, ptr %t52, !tbaa !24
  %t54 = load ptr, ptr %l28, !tbaa !29
  %t56 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t54, i64 %t53)
  store ptr %t56, ptr %l33
  br label %bb10
bb10:
  %t57 = load ptr, ptr %l33, !tbaa !29
  %t59 = getelementptr %"compiler/load:Module", ptr %t57, i32 0, i32 11
  store ptr %t59, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t61 = load ptr, ptr %l2, !tbaa !29
  %t62 = load i64, ptr %l3, !tbaa !24
  %t65 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eRunFrom_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t61, i64 %t62)
  %t66 = extractvalue { i32, { i64, ptr } } %t65, 1
  %t67 = extractvalue { i32, { i64, ptr } } %t65, 0
  store i32 %t67, ptr %l40
  %t68 = icmp ne i32 %t67, 0
  br i1 %t68, label %bb13, label %ok.69
ok.69:
  store { i64, ptr } %t66, ptr %l39
  br label %bb12
bb12:
  %t70 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t70, ptr %l36, !tbaa !27
  br label %bb17
bb13:
  %t71 = load i32, ptr %l40, !tbaa !23
  %t72 = ashr i32 %t71, 16
  %t74 = icmp eq i32 %t72, 1
  br i1 %t74, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_d39e2cfbcd38cb5a_4efeb51c01075546)
  unreachable
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb41
bb17:
  %t76 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t76, ptr %l4, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t77, 0
  store i64 %t79, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  %t81 = load i64, ptr %l6, !tbaa !24
  %t82 = load i64, ptr %l5, !tbaa !24
  %t85 = icmp slt i64 %t81, %t82
  %t87 = xor i1 %t85, true
  br i1 %t87, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s4)
  br label %bb39
bb20:
  br label %bb21
bb21:
  %t89 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t89, ptr %l49, !tbaa !27
  %t90 = load i64, ptr %l6, !tbaa !24
  %t92 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr %"compiler/load:Import", ptr %t93, i64 %t90
  %t95 = load %"compiler/load:Import", ptr %t94
  store %"compiler/load:Import" %t95, ptr %l7
  %t97 = getelementptr %"compiler/load:Import", ptr %l7, i32 0, i32 5
  %t98 = load i64, ptr %t97, !tbaa !24
  %t99 = load i64, ptr %l1, !tbaa !24
  %t102 = icmp ne i64 %t98, %t99
  br i1 %t102, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb38
bb23:
  br label %bb24
bb24:
  %t104 = getelementptr %"compiler/load:Import", ptr %l7, i32 0, i32 2
  %t105 = load { i64, ptr }, ptr %t104, !tbaa !27
  store { i64, ptr } %t105, ptr %l8, !tbaa !27
  %t107 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t107, 0
  %t111 = icmp eq i64 %t109, 0
  br i1 %t111, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s6
  %t113 = getelementptr %"compiler/load:Import", ptr %l7, i32 0, i32 3
  %t114 = load { i64, ptr }, ptr %t113, !tbaa !27
  %t116 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s6, { i64, ptr } %t114, { i64, ptr } { i64 1, ptr @.d50 })
  %t117 = extractvalue { i32, i64 } %t116, 1
  %t118 = extractvalue { i32, i64 } %t116, 0
  store i32 %t118, ptr %l62
  %t119 = icmp ne i32 %t118, 0
  br i1 %t119, label %bb28, label %ok.120
ok.120:
  store i64 %t117, ptr %l61
  br label %bb27
bb26:
  br label %bb37
bb27:
  %t121 = load i64, ptr %l61, !tbaa !24
  store i64 %t121, ptr %l59, !tbaa !24
  br label %bb30
bb28:
  br label %bb29
bb29:
  store i64 -1, ptr %l59, !tbaa !24
  br label %bb30
bb30:
  %t122 = load i64, ptr %l59, !tbaa !24
  %t123 = getelementptr %"compiler/load:Import", ptr %l7, i32 0, i32 3
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  store { i64, ptr } %t124, ptr %l63, !tbaa !27
  %t127 = add i64 %t122, 1
  store i64 %t127, ptr %l65, !tbaa !24
  %t128 = getelementptr %"compiler/load:Import", ptr %l7, i32 0, i32 3
  %t129 = load { i64, ptr }, ptr %t128, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t129, 0
  store i64 %t132, ptr %l68, !tbaa !24
  %t133 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 0
  store i64 %t134, ptr %l69, !tbaa !24
  %t135 = load i64, ptr %l65, !tbaa !24
  %t136 = icmp sge i64 %t135, 0
  br i1 %t136, label %bb31, label %bb32
bb31:
  %t138 = load i64, ptr %l65, !tbaa !24
  %t139 = load i64, ptr %l68, !tbaa !24
  %t140 = icmp sle i64 %t138, %t139
  br i1 %t140, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_4138b01f2eedcaec_10fcf95e1b11f8e8)
  unreachable
bb33:
  %t142 = load i64, ptr %l68, !tbaa !24
  %t143 = load i64, ptr %l69, !tbaa !24
  %t144 = icmp sle i64 %t142, %t143
  br i1 %t144, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_4138b01f2eedcaec_10fcf95e1b11f8e8)
  unreachable
bb35:
  %t146 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = load i64, ptr %l65, !tbaa !24
  %t149 = load i64, ptr %l68, !tbaa !24
  %t150 = getelementptr i8, ptr %t147, i64 %t148
  %t151 = sub i64 %t149, %t148
  %t152 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t150, 1
  store { i64, ptr } %t153, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_4138b01f2eedcaec_10fcf95e1b11f8e8)
  unreachable
bb37:
  %t155 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t155, 1
  %t158 = extractvalue { i64, ptr } %t155, 0
  %t159 = extractvalue { i64, ptr } { i64 1, ptr @.d51 }, 1
  %t160 = extractvalue { i64, ptr } { i64 1, ptr @.d51 }, 0
  %t161 = add i64 %t158, %t160
  %t162 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t161)
  call void @olang_textcopy(ptr %t162, ptr %t157, i64 %t158)
  %t163 = getelementptr i8, ptr %t162, i64 %t158
  call void @olang_textcopy(ptr %t163, ptr %t159, i64 %t160)
  %t164 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t165 = insertvalue { i64, ptr } %t164, ptr %t162, 1
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  store { i64, ptr } %t165, ptr %rv
  br label %ret
bb38:
  %t167 = load i64, ptr %l6, !tbaa !24
  %t169 = add i64 %t167, 1
  store i64 %t169, ptr %l6, !tbaa !24
  br label %bb18
bb39:
  %t171 = load i64, ptr %l3, !tbaa !24
  %t172 = load i64, ptr %l5, !tbaa !24
  %t175 = add i64 %t171, %t172
  store i64 %t175, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb40
bb40:
  br label %bb11
bb41:
  store { i64, ptr } { i64 0, ptr @.d52 }, ptr %l81, !tbaa !27
  %t177 = load { i64, ptr }, ptr %l81, !tbaa !27
  store { i64, ptr } %t177, ptr %l82, !tbaa !27
  %t178 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t178, 0
  store i64 %t179, ptr %l83, !tbaa !24
  %t180 = load i64, ptr %l83, !tbaa !24
  %t181 = mul i64 %t180, 1
  %t182 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t181)
  %t183 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t182, 1
  store { i64, ptr } %t184, ptr %l84, !tbaa !27
  %t185 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !27
  %t187 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !27
  %t189 = load i64, ptr %l83, !tbaa !24
  %t190 = mul i64 %t189, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t186, ptr %t188, i64 %t190, i1 false)
  %t191 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t191, ptr %l82, !tbaa !27
  %t192 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t192, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroBorrowedFrom(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i1
  %l21 = alloca i1
  %l27 = alloca ptr
  %l34 = alloca i64
  %l44 = alloca i64
  %l47 = alloca i64
  %l70 = alloca i64
  %l74 = alloca i1
  %l78 = alloca i1
  %l82 = alloca i1
  %s4 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Call", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t8 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyOfCallee(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store i64 %t8, ptr %l15
  br label %bb1
bb1:
  %t9 = load i64, ptr %l15, !tbaa !24
  store i64 %t9, ptr %l2, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp slt i64 %t10, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb5
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i64, ptr %l2, !tbaa !24
  %t18 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %t14, i64 %t15)
  store i1 %t18, ptr %l21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l21, !tbaa !21
  %t20 = xor i1 %t19, true
  store i1 %t20, ptr %l18, !tbaa !21
  br label %bb5
bb5:
  %t22 = load i1, ptr %l18, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  store i64 -1, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 10
  %t27 = load i64, ptr %l2, !tbaa !24
  %t30 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t26, i64 %t27)
  store ptr %t30, ptr %l27
  br label %bb9
bb9:
  %t31 = load ptr, ptr %l27, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Body", ptr %t31, i32 0, i32 2
  %t34 = load i32, ptr %t33, !tbaa !23
  store i32 %t34, ptr %l3, !tbaa !23
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = getelementptr %"compiler/generic:Program", ptr %t39, i32 0, i32 2
  %t42 = load i32, ptr %l3, !tbaa !23
  %t45 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t41, i32 %t42, i64 0)
  store i64 %t45, ptr %l34
  br label %bb10
bb10:
  %t46 = load i64, ptr %l34, !tbaa !24
  store i64 %t46, ptr %l4, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t49 = icmp slt i64 %t47, 0
  br i1 %t49, label %bb11, label %bb12
bb11:
  store i64 -1, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  store i64 0, ptr %l5, !tbaa !24
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr %"compiler/typed:Call", ptr %t52, i32 0, i32 1
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 0
  store i64 %t57, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t59 = load i64, ptr %l6, !tbaa !24
  %t60 = load i64, ptr %l5, !tbaa !24
  %t63 = icmp sgt i64 %t59, %t60
  br i1 %t63, label %bb14, label %bb15
bb14:
  %t65 = load i64, ptr %l7, !tbaa !24
  %t67 = icmp sgt i64 %t65, 0
  br i1 %t67, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb19
bb16:
  %t69 = load i64, ptr %l6, !tbaa !24
  %t70 = load i64, ptr %l5, !tbaa !24
  %t73 = sub i64 %t69, %t70
  %t74 = load i64, ptr %l7, !tbaa !24
  %t77 = add i64 %t73, %t74
  %t79 = sub i64 %t77, 1
  %t80 = load i64, ptr %l7, !tbaa !24
  %t83 = sdiv i64 %t79, %t80
  store i64 %t83, ptr %l47, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb18
bb18:
  %t85 = load i64, ptr %l47, !tbaa !24
  store i64 %t85, ptr %l44, !tbaa !24
  br label %bb19
bb19:
  %t86 = load i64, ptr %l44, !tbaa !24
  store i64 %t86, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s4
  %t87 = load i64, ptr %l9, !tbaa !24
  %t88 = load i64, ptr %l8, !tbaa !24
  %t91 = icmp slt i64 %t87, %t88
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s4)
  br label %bb36
bb22:
  br label %bb23
bb23:
  %t95 = load i64, ptr %l5, !tbaa !24
  %t96 = load i64, ptr %l9, !tbaa !24
  %t97 = load i64, ptr %l7, !tbaa !24
  %t100 = mul i64 %t96, %t97
  %t103 = add i64 %t95, %t100
  store i64 %t103, ptr %l10, !tbaa !24
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/check:Checker", ptr %t105, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t110 = getelementptr %"compiler/generic:Program", ptr %t108, i32 0, i32 2
  %t111 = load i32, ptr %l3, !tbaa !23
  %t112 = load i64, ptr %l10, !tbaa !24
  %t116 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t110, i32 %t111, i64 %t112)
  store i64 %t116, ptr %l70
  br label %bb24
bb24:
  %t117 = load i64, ptr %l70, !tbaa !24
  store i64 %t117, ptr %l11, !tbaa !24
  %t118 = load i64, ptr %l10, !tbaa !24
  %t119 = load i64, ptr %l4, !tbaa !24
  %t122 = icmp eq i64 %t118, %t119
  br i1 %t122, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb27
bb26:
  %t124 = load i64, ptr %l11, !tbaa !24
  %t125 = load i64, ptr %l4, !tbaa !24
  %t128 = icmp eq i64 %t124, %t125
  store i1 %t128, ptr %l74, !tbaa !21
  br label %bb27
bb27:
  %t130 = load i1, ptr %l74, !tbaa !21
  br i1 %t130, label %bb28, label %bb29
bb28:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i64, ptr %l2, !tbaa !24
  %t133 = load i64, ptr %l10, !tbaa !24
  %t137 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %t131, i64 %t132, i64 %t133)
  store i1 %t137, ptr %l82
  br label %bb30
bb29:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb31
bb30:
  %t138 = load i1, ptr %l82, !tbaa !21
  store i1 %t138, ptr %l78, !tbaa !21
  br label %bb31
bb31:
  %t139 = load i1, ptr %l78, !tbaa !21
  br i1 %t139, label %bb32, label %bb33
bb32:
  %t140 = load i64, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  store i64 %t140, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s4)
  br label %bb35
bb35:
  %t142 = load i64, ptr %l9, !tbaa !24
  %t144 = add i64 %t142, 1
  store i64 %t144, ptr %l9, !tbaa !24
  br label %bb20
bb36:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCopied(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %l18 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l25 = alloca ptr
  %l31 = alloca i1
  %l32 = alloca i1
  %l36 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i1
  %l47 = alloca i1
  %l48 = alloca ptr
  %l54 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l63 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca i1
  %l74 = alloca i1
  %l75 = alloca ptr
  %l81 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i1
  %l90 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t21 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i1 %t21, ptr %l18
  br label %bb6
bb6:
  %t22 = load i1, ptr %l18, !tbaa !21
  store i1 %t22, ptr %l8, !tbaa !21
  br label %bb66
bb7:
  %t23 = load ptr, ptr %l1, !tbaa !29
  store ptr %t23, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t24 = load ptr, ptr %l19, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb8, label %bb9
bb8:
  %t27 = load ptr, ptr %l19, !tbaa !29
  %t28 = load i64, ptr %t27
  %t30 = icmp eq i64 %t28, 11
  store i1 %t30, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t31 = load i1, ptr %l20, !tbaa !21
  br i1 %t31, label %bb10, label %bb11
bb10:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr { i64, [5 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t34, i32 0, i32 2
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb21
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l25, !tbaa !29
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Cond", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = icmp eq ptr %t42, null
  br i1 %t44, label %bb13, label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_64f1128892bbfadb_2fd1650a543ec847)
  unreachable
bb14:
  br label %bb15
bb15:
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = getelementptr %"compiler/typed:Cond", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t50 = load ptr, ptr %l25, !tbaa !29
  %t52 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCopied(ptr %v0, ptr %v1, ptr %t50, ptr %t49)
  store i1 %t52, ptr %l31
  br label %bb16
bb16:
  %t53 = load i1, ptr %l31, !tbaa !21
  br i1 %t53, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb20
bb18:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Cond", ptr %t55, i32 0, i32 2
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t61 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCopied(ptr %v0, ptr %v1, ptr %t54, ptr %t58)
  store i1 %t61, ptr %l36
  br label %bb19
bb19:
  %t62 = load i1, ptr %l36, !tbaa !21
  store i1 %t62, ptr %l32, !tbaa !21
  br label %bb20
bb20:
  %t63 = load i1, ptr %l32, !tbaa !21
  store i1 %t63, ptr %l8, !tbaa !21
  br label %bb66
bb21:
  %t64 = load ptr, ptr %l1, !tbaa !29
  store ptr %t64, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t65 = load ptr, ptr %l37, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb22, label %bb23
bb22:
  %t68 = load ptr, ptr %l37, !tbaa !29
  %t69 = load i64, ptr %t68
  %t71 = icmp eq i64 %t69, 12
  store i1 %t71, ptr %l38, !tbaa !21
  br label %bb23
bb23:
  %t72 = load i1, ptr %l38, !tbaa !21
  br i1 %t72, label %bb24, label %bb25
bb24:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [5 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t75, i32 0, i32 2
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l4, !tbaa !29
  br label %bb26
bb25:
  br label %bb34
bb26:
  %t79 = load ptr, ptr %l4, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Seq", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = icmp eq ptr %t82, null
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb27, label %bb28
bb27:
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l48, !tbaa !29
  %t89 = load ptr, ptr %l4, !tbaa !29
  %t91 = getelementptr %"compiler/typed:Seq", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t94 = icmp eq ptr %t92, null
  br i1 %t94, label %bb29, label %bb30
bb28:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb33
bb29:
  call void @__olang_check_failed(ptr @olang_loc_9b328daa59c12fec_530ed6f7b483a728)
  unreachable
bb30:
  br label %bb31
bb31:
  %t96 = load ptr, ptr %l4, !tbaa !29
  %t98 = getelementptr %"compiler/typed:Seq", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t100 = load ptr, ptr %l48, !tbaa !29
  %t102 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCopied(ptr %v0, ptr %v1, ptr %t100, ptr %t99)
  store i1 %t102, ptr %l54
  br label %bb32
bb32:
  %t103 = load i1, ptr %l54, !tbaa !21
  store i1 %t103, ptr %l47, !tbaa !21
  br label %bb33
bb33:
  %t104 = load i1, ptr %l47, !tbaa !21
  store i1 %t104, ptr %l8, !tbaa !21
  br label %bb66
bb34:
  %t105 = load ptr, ptr %l1, !tbaa !29
  store ptr %t105, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t106 = load ptr, ptr %l55, !tbaa !29
  %t107 = icmp ne ptr %t106, null
  br i1 %t107, label %bb35, label %bb36
bb35:
  %t109 = load ptr, ptr %l55, !tbaa !29
  %t110 = load i64, ptr %t109
  %t112 = icmp eq i64 %t110, 13
  store i1 %t112, ptr %l56, !tbaa !21
  br label %bb36
bb36:
  %t113 = load i1, ptr %l56, !tbaa !21
  br i1 %t113, label %bb37, label %bb38
bb37:
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = getelementptr { i64, [5 x i64] }, ptr %t114, i32 0, i32 1
  %t117 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t116, i32 0, i32 2
  %t118 = load ptr, ptr %t117
  store ptr %t118, ptr %l5, !tbaa !29
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load ptr, ptr %l5, !tbaa !29
  %t124 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroMatch(ptr %v0, ptr %v1, ptr %t120, ptr %t121)
  store i1 %t124, ptr %l63
  br label %bb40
bb40:
  %t125 = load i1, ptr %l63, !tbaa !21
  store i1 %t125, ptr %l8, !tbaa !21
  br label %bb66
bb41:
  %t126 = load ptr, ptr %l1, !tbaa !29
  store ptr %t126, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t127 = load ptr, ptr %l64, !tbaa !29
  %t128 = icmp ne ptr %t127, null
  br i1 %t128, label %bb42, label %bb43
bb42:
  %t130 = load ptr, ptr %l64, !tbaa !29
  %t131 = load i64, ptr %t130
  %t133 = icmp eq i64 %t131, 14
  store i1 %t133, ptr %l65, !tbaa !21
  br label %bb43
bb43:
  %t134 = load i1, ptr %l65, !tbaa !21
  br i1 %t134, label %bb44, label %bb45
bb44:
  %t135 = load ptr, ptr %l1, !tbaa !29
  %t137 = getelementptr { i64, [5 x i64] }, ptr %t135, i32 0, i32 1
  %t138 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t137, i32 0, i32 2
  %t139 = load ptr, ptr %t138
  store ptr %t139, ptr %l6, !tbaa !29
  br label %bb46
bb45:
  br label %bb54
bb46:
  %t141 = load ptr, ptr %l6, !tbaa !29
  %t143 = getelementptr %"compiler/typed:Try", ptr %t141, i32 0, i32 0
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t146 = icmp eq ptr %t144, null
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb47, label %bb48
bb47:
  %t150 = load ptr, ptr %l0, !tbaa !29
  store ptr %t150, ptr %l75, !tbaa !29
  %t151 = load ptr, ptr %l6, !tbaa !29
  %t153 = getelementptr %"compiler/typed:Try", ptr %t151, i32 0, i32 0
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t156 = icmp eq ptr %t154, null
  br i1 %t156, label %bb49, label %bb50
bb48:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb53
bb49:
  call void @__olang_check_failed(ptr @olang_loc_aa71917389f82fa1_ab8db462134cc7fd)
  unreachable
bb50:
  br label %bb51
bb51:
  %t158 = load ptr, ptr %l6, !tbaa !29
  %t160 = getelementptr %"compiler/typed:Try", ptr %t158, i32 0, i32 0
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t162 = load ptr, ptr %l75, !tbaa !29
  %t164 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCopied(ptr %v0, ptr %v1, ptr %t162, ptr %t161)
  store i1 %t164, ptr %l81
  br label %bb52
bb52:
  %t165 = load i1, ptr %l81, !tbaa !21
  store i1 %t165, ptr %l74, !tbaa !21
  br label %bb53
bb53:
  %t166 = load i1, ptr %l74, !tbaa !21
  store i1 %t166, ptr %l8, !tbaa !21
  br label %bb66
bb54:
  %t167 = load ptr, ptr %l1, !tbaa !29
  store ptr %t167, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t168 = load ptr, ptr %l82, !tbaa !29
  %t169 = icmp ne ptr %t168, null
  br i1 %t169, label %bb55, label %bb56
bb55:
  %t171 = load ptr, ptr %l82, !tbaa !29
  %t172 = load i64, ptr %t171
  %t174 = icmp eq i64 %t172, 6
  store i1 %t174, ptr %l83, !tbaa !21
  br label %bb56
bb56:
  %t175 = load i1, ptr %l83, !tbaa !21
  br i1 %t175, label %bb57, label %bb58
bb57:
  %t176 = load ptr, ptr %l1, !tbaa !29
  %t178 = getelementptr { i64, [5 x i64] }, ptr %t176, i32 0, i32 1
  %t179 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t178, i32 0, i32 2
  %t180 = load ptr, ptr %t179
  store ptr %t180, ptr %l7, !tbaa !29
  br label %bb59
bb58:
  br label %bb61
bb59:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load ptr, ptr %l7, !tbaa !29
  %t186 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCallCopy(ptr %v0, ptr %v1, ptr %t182, ptr %t183)
  store i1 %t186, ptr %l90
  br label %bb60
bb60:
  %t187 = load i1, ptr %l90, !tbaa !21
  store i1 %t187, ptr %l8, !tbaa !21
  br label %bb66
bb61:
  br i1 true, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb65
bb64:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_45c1f7cb36e76579_9732da1c199d4515)
  unreachable
bb66:
  %t188 = load i1, ptr %l8, !tbaa !21
  store i1 %t188, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKeepVal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l14 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l19 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l25 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %a1, i64 %a2)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t9, ptr %l10
  br label %bb4
bb4:
  %t10 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l10
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t10, ptr %l4
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 60
  %t14 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  %t17 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H4c470d2e80d9fd53b2c4a8b35e81296f(ptr %v0, ptr %t13, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t14)
  store i1 %t17, ptr %l14
  br label %bb5
bb5:
  %t18 = load i1, ptr %l14, !tbaa !21
  %t19 = xor i1 %t18, true
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 60
  store ptr %t23, ptr %l17, !tbaa !29
  %t24 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t24, ptr %l18
  %t25 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l19
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t26 = load ptr, ptr %l17, !tbaa !29
  %t27 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l18
  %t28 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H64396385e4e6d43afa926b839ce2258a(ptr %v0, ptr %v0, ptr %t26, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t27, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t28)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 60
  %t32 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  %t35 = call { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H6388cc594ade7977543a45717e2b755f(ptr %v0, ptr %v0, ptr %t31, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t32)
  %t36 = extractvalue { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %t35, 1
  %t37 = extractvalue { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %t35, 0
  store i32 %t37, ptr %l25
  %t38 = icmp ne i32 %t37, 0
  br i1 %t38, label %bb12, label %ok.39
ok.39:
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t36, ptr %l24
  br label %bb11
bb11:
  %t40 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l24
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t40, ptr %l20
  br label %bb14
bb12:
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  %t41 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l20
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t41, ptr %l5
  %t42 = load ptr, ptr %l3, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v1, ptr %l5, ptr %t42)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootLocal(ptr %v0, ptr %v1, ptr %t1, ptr %a1)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i64, ptr %l2, !tbaa !24
  %t15 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLocal(ptr %v0, ptr %t11, i64 %t12)
  store i1 %t15, ptr %l11
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb5
bb4:
  %t16 = load i1, ptr %l11, !tbaa !21
  store i1 %t16, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l8, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t18 = load i64, ptr %l2, !tbaa !24
  store i64 %t18, ptr %l12, !tbaa !24
  br label %bb8
bb7:
  store i64 -1, ptr %l12, !tbaa !24
  br label %bb8
bb8:
  %t20 = load i64, ptr %l12, !tbaa !24
  store i64 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esamePlace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca i1
  %l56 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i1
  %l80 = alloca i1
  %l84 = alloca i1
  %l86 = alloca ptr
  %l87 = alloca i1
  %l92 = alloca ptr
  %l93 = alloca i1
  %l103 = alloca i1
  %l105 = alloca ptr
  %l106 = alloca i1
  %l111 = alloca ptr
  %l112 = alloca i1
  %l122 = alloca i1
  %l128 = alloca i1
  %l130 = alloca ptr
  %l131 = alloca i1
  %l136 = alloca ptr
  %l137 = alloca i1
  %l143 = alloca ptr
  %l145 = alloca ptr
  %l149 = alloca i1
  %l153 = alloca i1
  %l157 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t2 = load ptr, ptr %l21, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l21, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l22, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l22, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb12
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t17 = load ptr, ptr %l27, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l27, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l28, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l28, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t27, i32 0, i32 2
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l4, !tbaa !23
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t31 = load i32, ptr %l3, !tbaa !23
  %t32 = load i32, ptr %l4, !tbaa !23
  %t35 = icmp eq i32 %t31, %t32
  store i1 %t35, ptr %rv
  br label %ret
bb11:
  store i1 false, ptr %rv
  br label %ret
bb12:
  %t38 = load ptr, ptr %l1, !tbaa !29
  store ptr %t38, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t39 = load ptr, ptr %l37, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb13, label %bb14
bb13:
  %t42 = load ptr, ptr %l37, !tbaa !29
  %t43 = load i64, ptr %t42
  %t45 = icmp eq i64 %t43, 1
  store i1 %t45, ptr %l38, !tbaa !21
  br label %bb14
bb14:
  %t46 = load i1, ptr %l38, !tbaa !21
  br i1 %t46, label %bb15, label %bb16
bb15:
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr { i64, [4 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t49, i32 0, i32 2
  %t51 = load i64, ptr %t50
  store i64 %t51, ptr %l5, !tbaa !24
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr { i64, [4 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t55, i32 0, i32 3
  %t57 = load i32, ptr %t56
  store i32 %t57, ptr %l6, !tbaa !23
  br label %bb17
bb16:
  br label %bb27
bb17:
  %t59 = load ptr, ptr %l2, !tbaa !29
  store ptr %t59, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t60 = load ptr, ptr %l45, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb18, label %bb19
bb18:
  %t63 = load ptr, ptr %l45, !tbaa !29
  %t64 = load i64, ptr %t63
  %t66 = icmp eq i64 %t64, 1
  store i1 %t66, ptr %l46, !tbaa !21
  br label %bb19
bb19:
  %t67 = load i1, ptr %l46, !tbaa !21
  br i1 %t67, label %bb20, label %bb21
bb20:
  %t68 = load ptr, ptr %l2, !tbaa !29
  %t70 = getelementptr { i64, [4 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t70, i32 0, i32 2
  %t72 = load i64, ptr %t71
  store i64 %t72, ptr %l7, !tbaa !24
  %t74 = load ptr, ptr %l2, !tbaa !29
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t76, i32 0, i32 3
  %t78 = load i32, ptr %t77
  store i32 %t78, ptr %l8, !tbaa !23
  br label %bb22
bb21:
  br label %bb26
bb22:
  %t80 = load i64, ptr %l5, !tbaa !24
  %t81 = load i64, ptr %l7, !tbaa !24
  %t84 = icmp eq i64 %t80, %t81
  br i1 %t84, label %bb23, label %bb24
bb23:
  %t86 = load i32, ptr %l6, !tbaa !23
  %t87 = load i32, ptr %l8, !tbaa !23
  %t90 = icmp eq i32 %t86, %t87
  store i1 %t90, ptr %l56, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb25
bb25:
  %t92 = load i1, ptr %l56, !tbaa !21
  store i1 %t92, ptr %rv
  br label %ret
bb26:
  store i1 false, ptr %rv
  br label %ret
bb27:
  %t94 = load ptr, ptr %l1, !tbaa !29
  store ptr %t94, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t95 = load ptr, ptr %l61, !tbaa !29
  %t96 = icmp ne ptr %t95, null
  br i1 %t96, label %bb28, label %bb29
bb28:
  %t98 = load ptr, ptr %l61, !tbaa !29
  %t99 = load i64, ptr %t98
  %t101 = icmp eq i64 %t99, 3
  store i1 %t101, ptr %l62, !tbaa !21
  br label %bb29
bb29:
  %t102 = load i1, ptr %l62, !tbaa !21
  br i1 %t102, label %bb30, label %bb31
bb30:
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t105 = getelementptr { i64, [4 x i64] }, ptr %t103, i32 0, i32 1
  %t106 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t105, i32 0, i32 2
  %t107 = load ptr, ptr %t106
  store ptr %t107, ptr %l9, !tbaa !29
  %t109 = load ptr, ptr %l1, !tbaa !29
  %t111 = getelementptr { i64, [4 x i64] }, ptr %t109, i32 0, i32 1
  %t112 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t111, i32 0, i32 3
  %t113 = load i64, ptr %t112
  store i64 %t113, ptr %l10, !tbaa !24
  br label %bb32
bb31:
  br label %bb43
bb32:
  %t115 = load ptr, ptr %l2, !tbaa !29
  store ptr %t115, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t116 = load ptr, ptr %l69, !tbaa !29
  %t117 = icmp ne ptr %t116, null
  br i1 %t117, label %bb33, label %bb34
bb33:
  %t119 = load ptr, ptr %l69, !tbaa !29
  %t120 = load i64, ptr %t119
  %t122 = icmp eq i64 %t120, 3
  store i1 %t122, ptr %l70, !tbaa !21
  br label %bb34
bb34:
  %t123 = load i1, ptr %l70, !tbaa !21
  br i1 %t123, label %bb35, label %bb36
bb35:
  %t124 = load ptr, ptr %l2, !tbaa !29
  %t126 = getelementptr { i64, [4 x i64] }, ptr %t124, i32 0, i32 1
  %t127 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t126, i32 0, i32 2
  %t128 = load ptr, ptr %t127
  store ptr %t128, ptr %l11, !tbaa !29
  %t130 = load ptr, ptr %l2, !tbaa !29
  %t132 = getelementptr { i64, [4 x i64] }, ptr %t130, i32 0, i32 1
  %t133 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t132, i32 0, i32 3
  %t134 = load i64, ptr %t133
  store i64 %t134, ptr %l12, !tbaa !24
  br label %bb37
bb36:
  br label %bb42
bb37:
  %t136 = load i64, ptr %l10, !tbaa !24
  %t137 = load i64, ptr %l12, !tbaa !24
  %t140 = icmp eq i64 %t136, %t137
  br i1 %t140, label %bb38, label %bb39
bb38:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load ptr, ptr %l9, !tbaa !29
  %t144 = load ptr, ptr %l11, !tbaa !29
  %t148 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esamePlace(ptr %v0, ptr %v1, ptr %v2, ptr %t142, ptr %t143, ptr %t144)
  store i1 %t148, ptr %l84
  br label %bb40
bb39:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb41
bb40:
  %t149 = load i1, ptr %l84, !tbaa !21
  store i1 %t149, ptr %l80, !tbaa !21
  br label %bb41
bb41:
  %t150 = load i1, ptr %l80, !tbaa !21
  store i1 %t150, ptr %rv
  br label %ret
bb42:
  store i1 false, ptr %rv
  br label %ret
bb43:
  %t152 = load ptr, ptr %l1, !tbaa !29
  store ptr %t152, ptr %l86, !tbaa !29
  store i1 false, ptr %l87, !tbaa !21
  %t153 = load ptr, ptr %l86, !tbaa !29
  %t154 = icmp ne ptr %t153, null
  br i1 %t154, label %bb44, label %bb45
bb44:
  %t156 = load ptr, ptr %l86, !tbaa !29
  %t157 = load i64, ptr %t156
  %t159 = icmp eq i64 %t157, 4
  store i1 %t159, ptr %l87, !tbaa !21
  br label %bb45
bb45:
  %t160 = load i1, ptr %l87, !tbaa !21
  br i1 %t160, label %bb46, label %bb47
bb46:
  %t161 = load ptr, ptr %l1, !tbaa !29
  %t163 = getelementptr { i64, [4 x i64] }, ptr %t161, i32 0, i32 1
  %t164 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t163, i32 0, i32 2
  %t165 = load ptr, ptr %t164
  store ptr %t165, ptr %l13, !tbaa !29
  br label %bb48
bb47:
  br label %bb56
bb48:
  %t167 = load ptr, ptr %l2, !tbaa !29
  store ptr %t167, ptr %l92, !tbaa !29
  store i1 false, ptr %l93, !tbaa !21
  %t168 = load ptr, ptr %l92, !tbaa !29
  %t169 = icmp ne ptr %t168, null
  br i1 %t169, label %bb49, label %bb50
bb49:
  %t171 = load ptr, ptr %l92, !tbaa !29
  %t172 = load i64, ptr %t171
  %t174 = icmp eq i64 %t172, 4
  store i1 %t174, ptr %l93, !tbaa !21
  br label %bb50
bb50:
  %t175 = load i1, ptr %l93, !tbaa !21
  br i1 %t175, label %bb51, label %bb52
bb51:
  %t176 = load ptr, ptr %l2, !tbaa !29
  %t178 = getelementptr { i64, [4 x i64] }, ptr %t176, i32 0, i32 1
  %t179 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t178, i32 0, i32 2
  %t180 = load ptr, ptr %t179
  store ptr %t180, ptr %l14, !tbaa !29
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load ptr, ptr %l13, !tbaa !29
  %t185 = getelementptr %"compiler/typed:Elem", ptr %t183, i32 0, i32 0
  %t186 = load ptr, ptr %t185, !tbaa !29
  %t187 = load ptr, ptr %l14, !tbaa !29
  %t189 = getelementptr %"compiler/typed:Elem", ptr %t187, i32 0, i32 0
  %t190 = load ptr, ptr %t189, !tbaa !29
  %t194 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esamePlace(ptr %v0, ptr %v1, ptr %v2, ptr %t182, ptr %t186, ptr %t190)
  store i1 %t194, ptr %l103
  br label %bb54
bb54:
  %t195 = load i1, ptr %l103, !tbaa !21
  store i1 %t195, ptr %rv
  br label %ret
bb55:
  store i1 false, ptr %rv
  br label %ret
bb56:
  %t197 = load ptr, ptr %l1, !tbaa !29
  store ptr %t197, ptr %l105, !tbaa !29
  store i1 false, ptr %l106, !tbaa !21
  %t198 = load ptr, ptr %l105, !tbaa !29
  %t199 = icmp ne ptr %t198, null
  br i1 %t199, label %bb57, label %bb58
bb57:
  %t201 = load ptr, ptr %l105, !tbaa !29
  %t202 = load i64, ptr %t201
  %t204 = icmp eq i64 %t202, 5
  store i1 %t204, ptr %l106, !tbaa !21
  br label %bb58
bb58:
  %t205 = load i1, ptr %l106, !tbaa !21
  br i1 %t205, label %bb59, label %bb60
bb59:
  %t206 = load ptr, ptr %l1, !tbaa !29
  %t208 = getelementptr { i64, [4 x i64] }, ptr %t206, i32 0, i32 1
  %t209 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t208, i32 0, i32 2
  %t210 = load ptr, ptr %t209
  store ptr %t210, ptr %l15, !tbaa !29
  br label %bb61
bb60:
  br label %bb72
bb61:
  %t212 = load ptr, ptr %l2, !tbaa !29
  store ptr %t212, ptr %l111, !tbaa !29
  store i1 false, ptr %l112, !tbaa !21
  %t213 = load ptr, ptr %l111, !tbaa !29
  %t214 = icmp ne ptr %t213, null
  br i1 %t214, label %bb62, label %bb63
bb62:
  %t216 = load ptr, ptr %l111, !tbaa !29
  %t217 = load i64, ptr %t216
  %t219 = icmp eq i64 %t217, 5
  store i1 %t219, ptr %l112, !tbaa !21
  br label %bb63
bb63:
  %t220 = load i1, ptr %l112, !tbaa !21
  br i1 %t220, label %bb64, label %bb65
bb64:
  %t221 = load ptr, ptr %l2, !tbaa !29
  %t223 = getelementptr { i64, [4 x i64] }, ptr %t221, i32 0, i32 1
  %t224 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t223, i32 0, i32 2
  %t225 = load ptr, ptr %t224
  store ptr %t225, ptr %l16, !tbaa !29
  br label %bb66
bb65:
  br label %bb71
bb66:
  %t227 = load ptr, ptr %l15, !tbaa !29
  %t229 = getelementptr %"compiler/typed:Payload", ptr %t227, i32 0, i32 1
  %t230 = load i64, ptr %t229, !tbaa !24
  %t231 = load ptr, ptr %l16, !tbaa !29
  %t233 = getelementptr %"compiler/typed:Payload", ptr %t231, i32 0, i32 1
  %t234 = load i64, ptr %t233, !tbaa !24
  %t237 = icmp eq i64 %t230, %t234
  br i1 %t237, label %bb67, label %bb68
bb67:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load ptr, ptr %l15, !tbaa !29
  %t242 = getelementptr %"compiler/typed:Payload", ptr %t240, i32 0, i32 0
  %t243 = load ptr, ptr %t242, !tbaa !29
  %t244 = load ptr, ptr %l16, !tbaa !29
  %t246 = getelementptr %"compiler/typed:Payload", ptr %t244, i32 0, i32 0
  %t247 = load ptr, ptr %t246, !tbaa !29
  %t251 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esamePlace(ptr %v0, ptr %v1, ptr %v2, ptr %t239, ptr %t243, ptr %t247)
  store i1 %t251, ptr %l128
  br label %bb69
bb68:
  store i1 false, ptr %l122, !tbaa !21
  br label %bb70
bb69:
  %t252 = load i1, ptr %l128, !tbaa !21
  store i1 %t252, ptr %l122, !tbaa !21
  br label %bb70
bb70:
  %t253 = load i1, ptr %l122, !tbaa !21
  store i1 %t253, ptr %rv
  br label %ret
bb71:
  store i1 false, ptr %rv
  br label %ret
bb72:
  %t255 = load ptr, ptr %l1, !tbaa !29
  store ptr %t255, ptr %l130, !tbaa !29
  store i1 false, ptr %l131, !tbaa !21
  %t256 = load ptr, ptr %l130, !tbaa !29
  %t257 = icmp ne ptr %t256, null
  br i1 %t257, label %bb73, label %bb74
bb73:
  %t259 = load ptr, ptr %l130, !tbaa !29
  %t260 = load i64, ptr %t259
  %t262 = icmp eq i64 %t260, 2
  store i1 %t262, ptr %l131, !tbaa !21
  br label %bb74
bb74:
  %t263 = load i1, ptr %l131, !tbaa !21
  br i1 %t263, label %bb75, label %bb76
bb75:
  %t264 = load ptr, ptr %l1, !tbaa !29
  %t266 = getelementptr { i64, [4 x i64] }, ptr %t264, i32 0, i32 1
  %t267 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t266, i32 0, i32 2
  %t268 = load ptr, ptr %t267
  store ptr %t268, ptr %l17, !tbaa !29
  br label %bb77
bb76:
  br label %bb93
bb77:
  %t270 = load ptr, ptr %l2, !tbaa !29
  store ptr %t270, ptr %l136, !tbaa !29
  store i1 false, ptr %l137, !tbaa !21
  %t271 = load ptr, ptr %l136, !tbaa !29
  %t272 = icmp ne ptr %t271, null
  br i1 %t272, label %bb78, label %bb79
bb78:
  %t274 = load ptr, ptr %l136, !tbaa !29
  %t275 = load i64, ptr %t274
  %t277 = icmp eq i64 %t275, 2
  store i1 %t277, ptr %l137, !tbaa !21
  br label %bb79
bb79:
  %t278 = load i1, ptr %l137, !tbaa !21
  br i1 %t278, label %bb80, label %bb81
bb80:
  %t279 = load ptr, ptr %l2, !tbaa !29
  %t281 = getelementptr { i64, [4 x i64] }, ptr %t279, i32 0, i32 1
  %t282 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t281, i32 0, i32 2
  %t283 = load ptr, ptr %t282
  store ptr %t283, ptr %l18, !tbaa !29
  br label %bb82
bb81:
  br label %bb92
bb82:
  %t285 = load ptr, ptr %l17, !tbaa !29
  %t287 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %t285)
  store ptr %t287, ptr %l143
  br label %bb83
bb83:
  %t288 = load ptr, ptr %l143, !tbaa !29
  store ptr %t288, ptr %l19, !tbaa !29
  %t289 = load ptr, ptr %l18, !tbaa !29
  %t291 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v2, ptr %t289)
  store ptr %t291, ptr %l145
  br label %bb84
bb84:
  %t292 = load ptr, ptr %l145, !tbaa !29
  store ptr %t292, ptr %l20, !tbaa !29
  %t293 = load ptr, ptr %l19, !tbaa !29
  %t295 = icmp eq ptr %t293, null
  %t297 = xor i1 %t295, true
  br i1 %t297, label %bb85, label %bb86
bb85:
  %t299 = load ptr, ptr %l20, !tbaa !29
  %t301 = icmp eq ptr %t299, null
  %t303 = xor i1 %t301, true
  store i1 %t303, ptr %l149, !tbaa !21
  br label %bb87
bb86:
  store i1 false, ptr %l149, !tbaa !21
  br label %bb87
bb87:
  %t305 = load i1, ptr %l149, !tbaa !21
  br i1 %t305, label %bb88, label %bb89
bb88:
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load ptr, ptr %l19, !tbaa !29
  %t308 = load ptr, ptr %l20, !tbaa !29
  %t312 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esamePlace(ptr %v0, ptr %v1, ptr %v2, ptr %t306, ptr %t307, ptr %t308)
  store i1 %t312, ptr %l157
  br label %bb90
bb89:
  store i1 false, ptr %l153, !tbaa !21
  br label %bb91
bb90:
  %t313 = load i1, ptr %l157, !tbaa !21
  store i1 %t313, ptr %l153, !tbaa !21
  br label %bb91
bb91:
  %t314 = load i1, ptr %l153, !tbaa !21
  store i1 %t314, ptr %rv
  br label %ret
bb92:
  store i1 false, ptr %rv
  br label %ret
bb93:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettle(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l8 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca i32
  %l19 = alloca ptr
  %l23 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l33 = alloca ptr
  %l39 = alloca i32
  %l45 = alloca i32
  %l46 = alloca i32
  %l52 = alloca i32
  %l53 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2, ptr %l5, !tbaa !29
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t7 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eletOut(ptr %v0, ptr %v1, ptr %s0, ptr %t3, ptr %t4)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  %t9 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %t9
  %t10 = load ptr, ptr %l5, !tbaa !29
  %t12 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emerged(ptr %v0, ptr %s0, ptr %s0, ptr %t10, ptr %t9)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l10
  br label %bb2
bb2:
  %t13 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  %t14 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %t14
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t17 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecanonicalErrs(ptr %v0, ptr %s0, ptr %t15, ptr %t14)
  store i32 %t17, ptr %l12
  br label %bb3
bb3:
  %t18 = load i32, ptr %l12, !tbaa !23
  store i32 %t18, ptr %l2, !tbaa !23
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 46
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"compiler/check:frame", ptr %t22, i32 0, i32 0
  %t25 = load i64, ptr %t24, !tbaa !24
  %t26 = load i32, ptr %l2, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e__Hb311157f9ff5cfde66cc01a7f8069ed8(ptr %v0, ptr %t21, i64 %t25, i32 %t26)
  br label %bb4
bb4:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 50
  store ptr %t32, ptr %l19, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr %"compiler/check:frame", ptr %t34, i32 0, i32 0
  %t37 = load i64, ptr %t36, !tbaa !24
  %t40 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyKey(ptr %v0, ptr %t33, i64 %t37)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t40, ptr %l23
  br label %bb5
bb5:
  %t41 = load i32, ptr %l2, !tbaa !23
  %t42 = load ptr, ptr %l19, !tbaa !29
  %t43 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1d7b97a31fca2c92a4527a0b3309f2d1(ptr %v0, ptr %t42, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t43, i32 %t41)
  br label %bb6
bb6:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 10
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr %"compiler/check:frame", ptr %t48, i32 0, i32 0
  %t51 = load i64, ptr %t50, !tbaa !24
  %t54 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t47, i64 %t51)
  store ptr %t54, ptr %l29
  br label %bb7
bb7:
  %t55 = load ptr, ptr %l29, !tbaa !29
  store ptr %t55, ptr %l3, !tbaa !29
  %t56 = load ptr, ptr %l3, !tbaa !29
  store ptr %t56, ptr %l30, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 2
  store ptr %t62, ptr %l33, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  %t69 = load ptr, ptr %l3, !tbaa !29
  %t71 = getelementptr %"compiler/typed:Body", ptr %t69, i32 0, i32 2
  %t72 = load i32, ptr %t71, !tbaa !23
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t68, i32 %t72)
  store i32 %t75, ptr %l39
  br label %bb8
bb8:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/generic:Program", ptr %t79, i32 0, i32 2
  %t82 = load ptr, ptr %l3, !tbaa !29
  %t84 = getelementptr %"compiler/typed:Body", ptr %t82, i32 0, i32 2
  %t85 = load i32, ptr %t84, !tbaa !23
  %t88 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t81, i32 %t85)
  store i32 %t88, ptr %l45
  br label %bb9
bb9:
  %t89 = load i32, ptr %l2, !tbaa !23
  store i32 %t89, ptr %l46, !tbaa !23
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/check:Checker", ptr %t90, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = getelementptr %"compiler/generic:Program", ptr %t93, i32 0, i32 2
  %t96 = load ptr, ptr %l3, !tbaa !29
  %t98 = getelementptr %"compiler/typed:Body", ptr %t96, i32 0, i32 2
  %t99 = load i32, ptr %t98, !tbaa !23
  %t102 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t95, i32 %t99)
  store i32 %t102, ptr %l52
  br label %bb10
bb10:
  %t103 = load ptr, ptr %l33, !tbaa !29
  %t104 = load i32, ptr %l39, !tbaa !23
  %t105 = load i32, ptr %l45, !tbaa !23
  %t106 = load i32, ptr %l46, !tbaa !23
  %t107 = load i32, ptr %l52, !tbaa !23
  %t108 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t103, i32 %t104, i32 %t105, i32 %t106, i32 %t107, i64 0)
  store i32 %t108, ptr %l53
  br label %bb11
bb11:
  %t109 = load i32, ptr %l53, !tbaa !23
  %t110 = load ptr, ptr %l30, !tbaa !29
  %t111 = getelementptr %"compiler/typed:Body", ptr %t110, i32 0, i32 2
  store i32 %t109, ptr %t111, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estrReceivers(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i64
  %l50 = alloca i64
  %l52 = alloca i1
  %l54 = alloca ptr
  %l56 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l57 = alloca i1
  %l62 = alloca ptr
  %l71 = alloca i64
  %l75 = alloca ptr
  %l79 = alloca { i64, ptr }
  %l83 = alloca i1
  %l85 = alloca i1
  %l87 = alloca i1
  %l89 = alloca i1
  %l91 = alloca i1
  %l94 = alloca i1
  %l100 = alloca i64
  %l106 = alloca ptr
  %l122 = alloca i64
  %l123 = alloca { i64, ptr }
  %l124 = alloca i64
  %l127 = alloca i64
  %l128 = alloca i64
  %l134 = alloca i64
  %l135 = alloca i32
  %l138 = alloca i64
  %l148 = alloca ptr
  %l154 = alloca ptr
  %l162 = alloca { i64, [3 x i64] }
  %l163 = alloca %"compiler/msgs:Msg"
  %l164 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %t306 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l19
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/check:Checker", ptr %t3, i32 0, i32 10
  %t7 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %t5)
  store i64 %t7, ptr %l22
  br label %bb2
bb2:
  %t8 = load i64, ptr %l22, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb8
bb5:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l29, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb7
bb7:
  %t35 = load i64, ptr %l29, !tbaa !24
  store i64 %t35, ptr %l26, !tbaa !24
  br label %bb8
bb8:
  %t36 = load i64, ptr %l26, !tbaa !24
  store i64 %t36, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb72
bb11:
  br label %bb12
bb12:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l7, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 15
  %t58 = load i64, ptr %l7, !tbaa !24
  %t61 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t57, i64 %t58)
  store i64 %t61, ptr %l50
  br label %bb13
bb13:
  %t62 = load i64, ptr %l50, !tbaa !24
  %t63 = icmp ne i64 %t62, 2
  br i1 %t63, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb18
bb15:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 56
  store ptr %t67, ptr %l54, !tbaa !29
  %t68 = load i64, ptr %l7, !tbaa !24
  %t70 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s2, i64 %t68, i64 0)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t70, ptr %l56
  br label %bb16
bb16:
  %t71 = load ptr, ptr %l54, !tbaa !29
  %t72 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l56
  %t73 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t71, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t72)
  store i1 %t73, ptr %l57
  br label %bb17
bb17:
  %t74 = load i1, ptr %l57, !tbaa !21
  %t75 = xor i1 %t74, true
  store i1 %t75, ptr %l52, !tbaa !21
  br label %bb18
bb18:
  %t77 = load i1, ptr %l52, !tbaa !21
  br i1 %t77, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb71
bb20:
  br label %bb21
bb21:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/check:Checker", ptr %t78, i32 0, i32 10
  %t81 = load i64, ptr %l7, !tbaa !24
  %t84 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t80, i64 %t81)
  store ptr %t84, ptr %l62
  br label %bb22
bb22:
  %t85 = load ptr, ptr %l62, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Body", ptr %t85, i32 0, i32 1
  %t88 = load { i64, [2 x i64] }, ptr %t87
  store { i64, [2 x i64] } %t88, ptr %l8
  %t90 = load { i64, [2 x i64] }, ptr %l8
  %t92 = extractvalue { i64, [2 x i64] } %t90, 0
  %t93 = icmp eq i64 %t92, 0
  br i1 %t93, label %bb23, label %bb24
bb23:
  %t95 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t96 = getelementptr { i64 }, ptr %t95, i32 0, i32 0
  %t97 = load i64, ptr %t96
  store i64 %t97, ptr %l9, !tbaa !24
  br label %bb25
bb24:
  br label %bb69
bb25:
  store %olang.scope zeroinitializer, ptr %s4
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t103 = load i64, ptr %l9, !tbaa !24
  %t106 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t102, i64 %t103)
  store i64 %t106, ptr %l71
  br label %bb26
bb26:
  %t107 = load i64, ptr %l71, !tbaa !24
  store i64 %t107, ptr %l10, !tbaa !24
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/check:Checker", ptr %t108, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t112 = load i64, ptr %l10, !tbaa !24
  %t115 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t111, i64 %t112)
  store ptr %t115, ptr %l75
  br label %bb27
bb27:
  %t116 = load ptr, ptr %l75, !tbaa !29
  store ptr %t116, ptr %l11, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load ptr, ptr %l11, !tbaa !29
  %t120 = getelementptr %"compiler/ast:Func", ptr %t118, i32 0, i32 2
  %t121 = load i32, ptr %t120, !tbaa !23
  %t124 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t117, i32 %t121)
  store { i64, ptr } %t124, ptr %l79
  br label %bb28
bb28:
  %t125 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t125, ptr %l12, !tbaa !27
  %t126 = load ptr, ptr %l11, !tbaa !29
  %t128 = getelementptr %"compiler/ast:Func", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = icmp eq ptr %t129, null
  br i1 %t131, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l83, !tbaa !21
  br label %bb36
bb30:
  %t133 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t135 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t133, { i64, ptr } { i64 3, ptr @.d53 })
  store i1 %t135, ptr %l85
  br label %bb31
bb31:
  %t136 = load i1, ptr %l85, !tbaa !21
  %t137 = xor i1 %t136, true
  br i1 %t137, label %bb32, label %bb33
bb32:
  %t139 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t141 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t139, { i64, ptr } { i64 3, ptr @.d54 })
  store i1 %t141, ptr %l89
  br label %bb34
bb33:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb35
bb34:
  %t142 = load i1, ptr %l89, !tbaa !21
  %t143 = xor i1 %t142, true
  store i1 %t143, ptr %l87, !tbaa !21
  br label %bb35
bb35:
  %t145 = load i1, ptr %l87, !tbaa !21
  store i1 %t145, ptr %l83, !tbaa !21
  br label %bb36
bb36:
  %t146 = load i1, ptr %l83, !tbaa !21
  br i1 %t146, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l91, !tbaa !21
  br label %bb40
bb38:
  %t147 = load i64, ptr %l10, !tbaa !24
  %t150 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %l1, i64 %t147)
  store i1 %t150, ptr %l94
  br label %bb39
bb39:
  %t151 = load i1, ptr %l94, !tbaa !21
  store i1 %t151, ptr %l91, !tbaa !21
  br label %bb40
bb40:
  %t152 = load i1, ptr %l91, !tbaa !21
  br i1 %t152, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  br label %bb71
bb42:
  br label %bb43
bb43:
  %t153 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s0, ptr %l1, i64 %t153, i1 true)
  br label %bb44
bb44:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/check:Checker", ptr %t156, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t160 = load i64, ptr %l10, !tbaa !24
  %t163 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t159, i64 %t160)
  store i64 %t163, ptr %l100
  br label %bb45
bb45:
  %t164 = load i64, ptr %l100, !tbaa !24
  store i64 %t164, ptr %l13, !tbaa !24
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/check:Checker", ptr %t165, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t170 = getelementptr %"compiler/generic:Program", ptr %t168, i32 0, i32 0
  %t171 = load ptr, ptr %t170, !tbaa !29
  %t173 = getelementptr %"compiler/load:Loader", ptr %t171, i32 0, i32 5
  %t174 = load i64, ptr %l13, !tbaa !24
  %t177 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t173, i64 %t174)
  store ptr %t177, ptr %l106
  br label %bb46
bb46:
  %t178 = load ptr, ptr %l106, !tbaa !29
  %t180 = getelementptr %"compiler/load:Module", ptr %t178, i32 0, i32 6
  %t181 = load ptr, ptr %t180, !tbaa !29
  store ptr %t181, ptr %l14, !tbaa !29
  %t183 = load ptr, ptr %l14, !tbaa !29
  %t185 = icmp eq ptr %t183, null
  br i1 %t185, label %bb47, label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_7cf0066f219391e3_f59e2f38f1229917)
  unreachable
bb48:
  br label %bb49
bb49:
  %t187 = load ptr, ptr %l14, !tbaa !29
  %t190 = getelementptr %"compiler/source:Source", ptr %t187, i32 0, i32 1
  %t191 = load { i64, ptr }, ptr %t190, !tbaa !27
  store { i64, ptr } %t191, ptr %l15, !tbaa !27
  %t193 = load ptr, ptr %l11, !tbaa !29
  %t195 = getelementptr %"compiler/ast:Func", ptr %t193, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !29
  %t198 = icmp eq ptr %t196, null
  br i1 %t198, label %bb50, label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_93e3a02800d00d4_2c47855b6b12ccf8)
  unreachable
bb51:
  br label %bb52
bb52:
  %t200 = load ptr, ptr %l11, !tbaa !29
  %t202 = getelementptr %"compiler/ast:Func", ptr %t200, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !29
  %t206 = getelementptr %"compiler/ast:Param", ptr %t203, i32 0, i32 0
  %t207 = getelementptr %"compiler/source:Span", ptr %t206, i32 0, i32 1
  %t208 = load i32, ptr %t207, !tbaa !23
  %t210 = sext i32 %t208 to i64
  store i64 %t210, ptr %l16, !tbaa !24
  %t212 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t212, ptr %l123, !tbaa !27
  %t213 = load i64, ptr %l16, !tbaa !24
  store i64 %t213, ptr %l124, !tbaa !24
  %t214 = load ptr, ptr %l11, !tbaa !29
  %t216 = getelementptr %"compiler/ast:Func", ptr %t214, i32 0, i32 0
  %t217 = getelementptr %"compiler/source:Span", ptr %t216, i32 0, i32 1
  %t218 = load i32, ptr %t217, !tbaa !23
  %t220 = sext i32 %t218 to i64
  store i64 %t220, ptr %l127, !tbaa !24
  %t221 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t222 = extractvalue { i64, ptr } %t221, 0
  store i64 %t222, ptr %l128, !tbaa !24
  %t223 = load i64, ptr %l124, !tbaa !24
  %t224 = icmp sge i64 %t223, 0
  br i1 %t224, label %bb53, label %bb54
bb53:
  %t226 = load i64, ptr %l124, !tbaa !24
  %t227 = load i64, ptr %l127, !tbaa !24
  %t228 = icmp sle i64 %t226, %t227
  br i1 %t228, label %bb55, label %bb56
bb54:
  call void @__olang_check_failed(ptr @olang_loc_ead499c86a25c3f7_b1128c547d2ccfbb)
  unreachable
bb55:
  %t230 = load i64, ptr %l127, !tbaa !24
  %t231 = load i64, ptr %l128, !tbaa !24
  %t232 = icmp sle i64 %t230, %t231
  br i1 %t232, label %bb57, label %bb58
bb56:
  call void @__olang_check_failed(ptr @olang_loc_ead499c86a25c3f7_b1128c547d2ccfbb)
  unreachable
bb57:
  %t234 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = load i64, ptr %l124, !tbaa !24
  %t237 = load i64, ptr %l127, !tbaa !24
  %t238 = getelementptr i8, ptr %t235, i64 %t236
  %t239 = sub i64 %t237, %t236
  %t240 = insertvalue { i64, ptr } undef, i64 %t239, 0
  %t241 = insertvalue { i64, ptr } %t240, ptr %t238, 1
  %t242 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t245 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v0, { i64, ptr } %t241, { i64, ptr } %t242)
  %t246 = extractvalue { i32, i64 } %t245, 1
  %t247 = extractvalue { i32, i64 } %t245, 0
  store i32 %t247, ptr %l135
  %t248 = icmp ne i32 %t247, 0
  br i1 %t248, label %bb60, label %ok.249
ok.249:
  store i64 %t246, ptr %l134
  br label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_ead499c86a25c3f7_b1128c547d2ccfbb)
  unreachable
bb59:
  %t250 = load i64, ptr %l134, !tbaa !24
  store i64 %t250, ptr %l122, !tbaa !24
  br label %bb62
bb60:
  br label %bb61
bb61:
  store i64 -1, ptr %l122, !tbaa !24
  br label %bb62
bb62:
  %t251 = load i64, ptr %l122, !tbaa !24
  store i64 %t251, ptr %l17, !tbaa !24
  %t252 = load i64, ptr %l17, !tbaa !24
  %t254 = icmp slt i64 %t252, 0
  br i1 %t254, label %bb63, label %bb64
bb63:
  %t256 = load ptr, ptr %l11, !tbaa !29
  %t258 = getelementptr %"compiler/ast:Func", ptr %t256, i32 0, i32 0
  %t259 = getelementptr %"compiler/source:Span", ptr %t258, i32 0, i32 0
  %t260 = load i32, ptr %t259, !tbaa !23
  %t262 = sext i32 %t260 to i64
  store i64 %t262, ptr %l138, !tbaa !24
  br label %bb65
bb64:
  %t264 = load i64, ptr %l16, !tbaa !24
  %t265 = load i64, ptr %l17, !tbaa !24
  %t268 = add i64 %t264, %t265
  store i64 %t268, ptr %l138, !tbaa !24
  br label %bb65
bb65:
  %t270 = load i64, ptr %l138, !tbaa !24
  store i64 %t270, ptr %l18, !tbaa !24
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t273 = getelementptr %"compiler/check:Checker", ptr %t271, i32 0, i32 1
  %t274 = load ptr, ptr %t273, !tbaa !29
  %t276 = getelementptr %"compiler/generic:Program", ptr %t274, i32 0, i32 0
  %t277 = load ptr, ptr %t276, !tbaa !29
  %t279 = getelementptr %"compiler/load:Loader", ptr %t277, i32 0, i32 4
  %t280 = load ptr, ptr %t279, !tbaa !29
  store ptr %t280, ptr %l148, !tbaa !29
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t283 = getelementptr %"compiler/check:Checker", ptr %t281, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !29
  %t286 = getelementptr %"compiler/generic:Program", ptr %t284, i32 0, i32 0
  %t287 = load ptr, ptr %t286, !tbaa !29
  %t289 = getelementptr %"compiler/load:Loader", ptr %t287, i32 0, i32 5
  %t290 = load i64, ptr %l13, !tbaa !24
  %t293 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t289, i64 %t290)
  store ptr %t293, ptr %l154
  br label %bb66
bb66:
  %t294 = load ptr, ptr %l154, !tbaa !29
  %t296 = getelementptr %"compiler/load:Module", ptr %t294, i32 0, i32 4
  %t297 = load i64, ptr %t296, !tbaa !24
  %t298 = load i64, ptr %l18, !tbaa !24
  %t299 = load i64, ptr %l18, !tbaa !24
  %t300 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t302 = extractvalue { i64, ptr } %t300, 0
  %t305 = add i64 %t299, %t302
  store { i64, [3 x i64] } zeroinitializer, ptr %t306
  %t307 = getelementptr { i64, [3 x i64] }, ptr %t306, i32 0, i32 0
  store i64 3, ptr %t307
  %t309 = insertvalue { i64, i64, i64 } undef, i64 %t297, 0
  %t311 = insertvalue { i64, i64, i64 } %t309, i64 %t298, 1
  %t313 = insertvalue { i64, i64, i64 } %t311, i64 %t305, 2
  %t314 = getelementptr { i64, [3 x i64] }, ptr %t306, i32 0, i32 1
  store { i64, i64, i64 } %t313, ptr %t314
  %t315 = load { i64, [3 x i64] }, ptr %t306
  store { i64, [3 x i64] } %t315, ptr %l162
  %t316 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eStrReceiverWritable(ptr %s4)
  store %"compiler/msgs:Msg" %t316, ptr %l163
  br label %bb67
bb67:
  %t317 = load ptr, ptr %l148, !tbaa !29
  %t318 = load { i64, [3 x i64] }, ptr %l162
  %t319 = load %"compiler/msgs:Msg", ptr %l163
  %t320 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s4, ptr %t317, { i64, [3 x i64] } %t318, %"compiler/msgs:Msg" %t319)
  store i64 %t320, ptr %l164
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s4)
  br label %bb70
bb69:
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s2)
  br label %bb71
bb71:
  %t321 = load i64, ptr %l6, !tbaa !24
  %t323 = add i64 %t321, 1
  store i64 %t323, ptr %l6, !tbaa !24
  br label %bb9
bb72:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitHeader(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca i1
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i32
  %l27 = alloca %"compiler/generic:Unmet"
  %l30 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i1
  %l47 = alloca i1
  %l56 = alloca i64
  %l63 = alloca i32
  %l67 = alloca ptr
  %l68 = alloca ptr
  %l72 = alloca %"compiler/generic:Context"
  %l76 = alloca i32
  %l84 = alloca { i64, ptr }
  %l90 = alloca i1
  %l92 = alloca ptr
  %l94 = alloca %"compiler/source:Span"
  %l95 = alloca ptr
  %l97 = alloca %"compiler/source:Span"
  %l98 = alloca { i64, ptr }
  %l99 = alloca %"compiler/msgs:Msg"
  %l100 = alloca i64
  %l105 = alloca i1
  %l109 = alloca i1
  %l113 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca { i64, ptr }
  %l117 = alloca %"compiler/source:Span"
  %l121 = alloca { i64, ptr }
  %l123 = alloca %"compiler/msgs:Msg"
  %l124 = alloca i64
  %l127 = alloca i1
  %l139 = alloca { i64, ptr }
  %l145 = alloca i1
  %l147 = alloca i32
  %l149 = alloca ptr
  %l151 = alloca ptr
  %l156 = alloca i32
  %l160 = alloca i32
  %l171 = alloca i1
  %l173 = alloca ptr
  %l175 = alloca %"compiler/source:Span"
  %l176 = alloca ptr
  %l178 = alloca %"compiler/source:Span"
  %l179 = alloca { i64, ptr }
  %l180 = alloca %"compiler/msgs:Msg"
  %l181 = alloca i64
  %l185 = alloca { i64, ptr }
  %l187 = alloca i64
  %l198 = alloca { i64, ptr }
  %l205 = alloca %"compiler/generic:Unmet"
  %l208 = alloca i1
  %l210 = alloca ptr
  %l212 = alloca %"compiler/source:Span"
  %l215 = alloca { i64, ptr }
  %l216 = alloca { i64, ptr }
  %l220 = alloca { i64, ptr }
  %l221 = alloca { i64, ptr }
  %l224 = alloca { i64, ptr }
  %l226 = alloca %"compiler/msgs:Msg"
  %l227 = alloca i64
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/ast:TypeDecl", ptr %t5, i32 0, i32 3
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = icmp eq ptr %t8, null
  store i1 %t10, ptr %l30, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l30, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t15 = getelementptr %"compiler/ast:TypeDecl", ptr %t13, i32 0, i32 3
  %t16 = load ptr, ptr %t15, !tbaa !29
  store ptr %t16, ptr %l3, !tbaa !29
  %t18 = load ptr, ptr %l3, !tbaa !29
  store ptr %t18, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t19 = load ptr, ptr %l36, !tbaa !29
  %t20 = icmp ne ptr %t19, null
  br i1 %t20, label %bb7, label %bb8
bb7:
  %t22 = load ptr, ptr %l36, !tbaa !29
  %t23 = load i64, ptr %t22
  %t25 = icmp eq i64 %t23, 2
  store i1 %t25, ptr %l37, !tbaa !21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l37, !tbaa !21
  br i1 %t26, label %bb9, label %bb10
bb9:
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t29 = getelementptr { i64, [6 x i64] }, ptr %t27, i32 0, i32 1
  %t30 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t29, i32 0, i32 1
  %t31 = load { i64, ptr }, ptr %t30
  store { i64, ptr } %t31, ptr %l4, !tbaa !27
  %t33 = load ptr, ptr %l3, !tbaa !29
  %t35 = getelementptr { i64, [6 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t35, i32 0, i32 2
  %t37 = load { i64, ptr }, ptr %t36
  store { i64, ptr } %t37, ptr %l5, !tbaa !27
  br label %bb11
bb10:
  br label %bb113
bb11:
  %t39 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t43 = icmp eq i64 %t41, 0
  br i1 %t43, label %bb12, label %bb13
bb12:
  %t45 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t49 = icmp eq i64 %t47, 0
  store i1 %t49, ptr %l47, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb14
bb14:
  %t51 = load i1, ptr %l47, !tbaa !21
  br i1 %t51, label %bb15, label %bb16
bb15:
  br label %ret
bb16:
  br label %bb17
bb17:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t56 = load i64, ptr %l1, !tbaa !24
  %t57 = load ptr, ptr %l2, !tbaa !29
  %t59 = getelementptr %"compiler/ast:TypeDecl", ptr %t57, i32 0, i32 0
  %t60 = load i32, ptr %t59, !tbaa !23
  %t64 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %t55, i64 %t56, i32 %t60)
  store i64 %t64, ptr %l56
  br label %bb18
bb18:
  %t65 = load i64, ptr %l56, !tbaa !24
  store i64 %t65, ptr %l6, !tbaa !24
  %t66 = load i64, ptr %l6, !tbaa !24
  %t68 = icmp slt i64 %t66, 0
  br i1 %t68, label %bb19, label %bb20
bb19:
  br label %ret
bb20:
  br label %bb21
bb21:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/check:Checker", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t74 = load i64, ptr %l1, !tbaa !24
  %t75 = load i64, ptr %l6, !tbaa !24
  %t79 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t73, i64 %t74, i64 %t75)
  store i32 %t79, ptr %l63
  br label %bb22
bb22:
  %t80 = load i32, ptr %l63, !tbaa !23
  store i32 %t80, ptr %l7, !tbaa !23
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load i64, ptr %l1, !tbaa !24
  %t83 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t87 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t81, i64 -1, i64 %t82, i32 %t83, i32 0)
  store ptr %t87, ptr %l67
  br label %bb23
bb23:
  %t88 = load ptr, ptr %l67, !tbaa !29
  store ptr %t88, ptr %l68, !tbaa !29
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/check:Checker", ptr %t90, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t94 = load i32, ptr %l7, !tbaa !23
  %t97 = call %"compiler/generic:Context" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclContext(ptr %v0, ptr %v0, ptr %t93, i32 %t94)
  store %"compiler/generic:Context" %t97, ptr %l72
  br label %bb24
bb24:
  %t98 = load %"compiler/generic:Context", ptr %l72
  %t99 = load ptr, ptr %l68, !tbaa !29
  %t100 = getelementptr %"compiler/check:frame", ptr %t99, i32 0, i32 4
  store %"compiler/generic:Context" %t98, ptr %t100
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/check:Checker", ptr %t101, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t105 = load i32, ptr %l7, !tbaa !23
  %t108 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t104, i32 %t105)
  store i32 %t108, ptr %l76
  br label %bb25
bb25:
  %t109 = load i32, ptr %l76, !tbaa !23
  store i32 %t109, ptr %l9, !tbaa !23
  store i1 false, ptr %l10, !tbaa !21
  %t110 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t110, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t112 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t112, 0
  store i64 %t114, ptr %l13, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s6
  %t116 = load i64, ptr %l12, !tbaa !24
  %t117 = load i64, ptr %l13, !tbaa !24
  %t120 = icmp slt i64 %t116, %t117
  %t122 = xor i1 %t120, true
  br i1 %t122, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s6)
  br label %bb40
bb28:
  br label %bb29
bb29:
  %t124 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t124, ptr %l84, !tbaa !27
  %t125 = load i64, ptr %l12, !tbaa !24
  %t127 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = getelementptr ptr, ptr %t128, i64 %t125
  %t130 = load ptr, ptr %t129, !tbaa !39
  store ptr %t130, ptr %l14, !tbaa !29
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load i64, ptr %l1, !tbaa !24
  %t134 = load ptr, ptr %l14, !tbaa !29
  %t138 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitRef(ptr %v0, ptr %v1, ptr %t132, i64 %t133, ptr %t134)
  store i1 %t138, ptr %l90
  br label %bb30
bb30:
  %t139 = load i1, ptr %l90, !tbaa !21
  %t140 = xor i1 %t139, true
  br i1 %t140, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s7
  %t142 = load ptr, ptr %l0, !tbaa !29
  store ptr %t142, ptr %l92, !tbaa !29
  %t143 = load ptr, ptr %l14, !tbaa !29
  %t145 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t143)
  store %"compiler/source:Span" %t145, ptr %l94
  br label %bb33
bb32:
  br label %bb38
bb33:
  %t146 = load ptr, ptr %l0, !tbaa !29
  store ptr %t146, ptr %l95, !tbaa !29
  %t147 = load ptr, ptr %l14, !tbaa !29
  %t149 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t147)
  store %"compiler/source:Span" %t149, ptr %l97
  br label %bb34
bb34:
  %t150 = load ptr, ptr %l95, !tbaa !29
  %t151 = load %"compiler/source:Span", ptr %l97
  %t152 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t150, %"compiler/source:Span" %t151)
  store { i64, ptr } %t152, ptr %l98
  br label %bb35
bb35:
  %t153 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t154 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitExtendsNotTrait(ptr %v0, ptr %s7, { i64, ptr } %t153)
  store %"compiler/msgs:Msg" %t154, ptr %l99
  br label %bb36
bb36:
  %t155 = load ptr, ptr %l92, !tbaa !29
  %t156 = load %"compiler/source:Span", ptr %l94
  %t157 = load %"compiler/msgs:Msg", ptr %l99
  %t158 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t155, %"compiler/source:Span" %t156, %"compiler/msgs:Msg" %t157)
  store i64 %t158, ptr %l100
  br label %bb37
bb37:
  store i1 true, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s7)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s6)
  br label %bb39
bb39:
  %t159 = load i64, ptr %l12, !tbaa !24
  %t161 = add i64 %t159, 1
  store i64 %t161, ptr %l12, !tbaa !24
  br label %bb26
bb40:
  %t163 = load i1, ptr %l10, !tbaa !21
  %t165 = xor i1 %t163, true
  br i1 %t165, label %bb41, label %bb42
bb41:
  %t167 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t167, 0
  %t171 = icmp sgt i64 %t169, 0
  store i1 %t171, ptr %l105, !tbaa !21
  br label %bb43
bb42:
  store i1 false, ptr %l105, !tbaa !21
  br label %bb43
bb43:
  %t173 = load i1, ptr %l105, !tbaa !21
  br i1 %t173, label %bb44, label %bb45
bb44:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load i32, ptr %l7, !tbaa !23
  %t176 = load i32, ptr %l9, !tbaa !23
  %t180 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereachesTrait(ptr %v0, ptr %t174, i32 %t175, i32 %t176, i64 0)
  store i1 %t180, ptr %l113
  br label %bb46
bb45:
  store i1 false, ptr %l109, !tbaa !21
  br label %bb47
bb46:
  %t181 = load i1, ptr %l113, !tbaa !21
  store i1 %t181, ptr %l109, !tbaa !21
  br label %bb47
bb47:
  %t182 = load i1, ptr %l109, !tbaa !21
  br i1 %t182, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s9
  %t183 = load ptr, ptr %l0, !tbaa !29
  store ptr %t183, ptr %l114, !tbaa !29
  %t184 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t184, ptr %l115, !tbaa !27
  %t185 = getelementptr { i64, ptr }, ptr %l115, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !27
  %t187 = getelementptr ptr, ptr %t186, i64 0
  %t188 = load ptr, ptr %t187, !tbaa !39
  %t190 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t188)
  store %"compiler/source:Span" %t190, ptr %l117
  br label %bb50
bb49:
  br label %bb54
bb50:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t192 = load ptr, ptr %l2, !tbaa !29
  %t194 = getelementptr %"compiler/ast:TypeDecl", ptr %t192, i32 0, i32 0
  %t195 = load i32, ptr %t194, !tbaa !23
  %t198 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s9, ptr %t191, i32 %t195)
  store { i64, ptr } %t198, ptr %l121
  br label %bb51
bb51:
  %t199 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t200 = extractvalue { i64, ptr } %t199, 0
  %t201 = extractvalue { i64, ptr } %t199, 1
  %t202 = mul i64 %t200, 1
  %t203 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t202)
  call void @llvm.memcpy.p0.p0.i64(ptr %t203, ptr %t201, i64 %t202, i1 false)
  %t204 = insertvalue { i64, ptr } undef, i64 %t200, 0
  %t205 = insertvalue { i64, ptr } %t204, ptr %t203, 1
  %t207 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitExtendsItself(ptr %s9, ptr %s9, { i64, ptr } %t205)
  store %"compiler/msgs:Msg" %t207, ptr %l123
  br label %bb52
bb52:
  %t208 = load ptr, ptr %l114, !tbaa !29
  %t209 = load %"compiler/source:Span", ptr %l117
  %t210 = load %"compiler/msgs:Msg", ptr %l123
  %t211 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s9, ptr %t208, %"compiler/source:Span" %t209, %"compiler/msgs:Msg" %t210)
  store i64 %t211, ptr %l124
  br label %bb53
bb53:
  store i1 true, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s9)
  br label %bb54
bb54:
  %t212 = load i1, ptr %l10, !tbaa !21
  %t214 = xor i1 %t212, true
  br i1 %t214, label %bb55, label %bb56
bb55:
  %t216 = load ptr, ptr %l2, !tbaa !29
  %t218 = getelementptr %"compiler/ast:TypeDecl", ptr %t216, i32 0, i32 1
  %t219 = load { i64, ptr }, ptr %t218, !tbaa !27
  %t221 = extractvalue { i64, ptr } %t219, 0
  %t223 = icmp eq i64 %t221, 0
  store i1 %t223, ptr %l127, !tbaa !21
  br label %bb57
bb56:
  store i1 false, ptr %l127, !tbaa !21
  br label %bb57
bb57:
  %t225 = load i1, ptr %l127, !tbaa !21
  store i1 %t225, ptr %l15, !tbaa !21
  %t226 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t226, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t228 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t230 = extractvalue { i64, ptr } %t228, 0
  store i64 %t230, ptr %l18, !tbaa !24
  br label %bb58
bb58:
  store %olang.scope zeroinitializer, ptr %s11
  %t232 = load i64, ptr %l17, !tbaa !24
  %t233 = load i64, ptr %l18, !tbaa !24
  %t236 = icmp slt i64 %t232, %t233
  %t238 = xor i1 %t236, true
  br i1 %t238, label %bb59, label %bb60
bb59:
  call void @__olang_scope_close(ptr %s11)
  br label %bb111
bb60:
  br label %bb61
bb61:
  %t240 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t240, ptr %l139, !tbaa !27
  %t241 = load i64, ptr %l17, !tbaa !24
  %t243 = getelementptr { i64, ptr }, ptr %l139, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !27
  %t245 = getelementptr ptr, ptr %t244, i64 %t241
  %t246 = load ptr, ptr %t245, !tbaa !39
  store ptr %t246, ptr %l19, !tbaa !29
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load i64, ptr %l1, !tbaa !24
  %t250 = load ptr, ptr %l19, !tbaa !29
  %t254 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitRef(ptr %v0, ptr %v1, ptr %t248, i64 %t249, ptr %t250)
  store i1 %t254, ptr %l145
  br label %bb62
bb62:
  %t255 = load i1, ptr %l145, !tbaa !21
  store i1 %t255, ptr %l20, !tbaa !21
  %t256 = load i1, ptr %l20, !tbaa !21
  br i1 %t256, label %bb63, label %bb64
bb63:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t260 = getelementptr %"compiler/check:Checker", ptr %t258, i32 0, i32 1
  %t261 = load ptr, ptr %t260, !tbaa !29
  store ptr %t261, ptr %l149, !tbaa !29
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t264 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t262)
  store ptr %t264, ptr %l151
  br label %bb65
bb64:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t266 = load ptr, ptr %l19, !tbaa !29
  %t270 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %t265, ptr %t266)
  store i32 %t270, ptr %l160
  br label %bb67
bb65:
  %t271 = load ptr, ptr %l151, !tbaa !29
  %t273 = getelementptr %"compiler/check:frame", ptr %t271, i32 0, i32 4
  %t274 = load ptr, ptr %l19, !tbaa !29
  %t276 = load ptr, ptr %l149, !tbaa !29
  %t279 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v0, ptr %v1, ptr %t276, ptr %t273, ptr %t274)
  store i32 %t279, ptr %l156
  br label %bb66
bb66:
  %t280 = load i32, ptr %l156, !tbaa !23
  store i32 %t280, ptr %l147, !tbaa !23
  br label %bb68
bb67:
  %t281 = load i32, ptr %l160, !tbaa !23
  store i32 %t281, ptr %l147, !tbaa !23
  br label %bb68
bb68:
  %t282 = load i32, ptr %l147, !tbaa !23
  store i32 %t282, ptr %l21, !tbaa !23
  %t283 = load i32, ptr %l21, !tbaa !23
  %t284 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t287 = icmp eq i32 %t283, %t284
  br i1 %t287, label %bb69, label %bb70
bb69:
  call void @__olang_scope_close(ptr %s11)
  br label %bb110
bb70:
  br label %bb71
bb71:
  %t289 = load i32, ptr %l21, !tbaa !23
  %t291 = insertvalue [1 x i32] undef, i32 %t289, 0
  %t293 = load ptr, ptr @__olang_prog_scope
  %t294 = call ptr @__olang_scope_alloc(ptr %t293, i64 4)
  store [1 x i32] %t291, ptr %t294
  %t295 = insertvalue { i64, ptr } undef, i64 1, 0
  %t296 = insertvalue { i64, ptr } %t295, ptr %t294, 1
  store { i64, ptr } %t296, ptr %l22, !tbaa !27
  %t298 = load i1, ptr %l20, !tbaa !21
  br i1 %t298, label %bb72, label %bb73
bb72:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr %"compiler/check:Checker", ptr %t300, i32 0, i32 1
  %t303 = load ptr, ptr %t302, !tbaa !29
  %t304 = load i32, ptr %l21, !tbaa !23
  %t307 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsClosedTrait(ptr %v0, ptr %t303, i32 %t304)
  store i1 %t307, ptr %l171
  br label %bb74
bb73:
  br label %bb87
bb74:
  %t308 = load i1, ptr %l171, !tbaa !21
  %t309 = xor i1 %t308, true
  br i1 %t309, label %bb75, label %bb76
bb75:
  store %olang.scope zeroinitializer, ptr %s14
  %t311 = load ptr, ptr %l0, !tbaa !29
  store ptr %t311, ptr %l173, !tbaa !29
  %t312 = load ptr, ptr %l19, !tbaa !29
  %t314 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t312)
  store %"compiler/source:Span" %t314, ptr %l175
  br label %bb77
bb76:
  br label %bb82
bb77:
  %t315 = load ptr, ptr %l0, !tbaa !29
  store ptr %t315, ptr %l176, !tbaa !29
  %t316 = load ptr, ptr %l19, !tbaa !29
  %t318 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t316)
  store %"compiler/source:Span" %t318, ptr %l178
  br label %bb78
bb78:
  %t319 = load ptr, ptr %l176, !tbaa !29
  %t320 = load %"compiler/source:Span", ptr %l178
  %t321 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t319, %"compiler/source:Span" %t320)
  store { i64, ptr } %t321, ptr %l179
  br label %bb79
bb79:
  %t322 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t323 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitMemberOpen(ptr %v0, ptr %s14, { i64, ptr } %t322)
  store %"compiler/msgs:Msg" %t323, ptr %l180
  br label %bb80
bb80:
  %t324 = load ptr, ptr %l173, !tbaa !29
  %t325 = load %"compiler/source:Span", ptr %l175
  %t326 = load %"compiler/msgs:Msg", ptr %l180
  %t327 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s14, ptr %t324, %"compiler/source:Span" %t325, %"compiler/msgs:Msg" %t326)
  store i64 %t327, ptr %l181
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s11)
  br label %bb110
bb82:
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t330 = getelementptr %"compiler/check:Checker", ptr %t328, i32 0, i32 1
  %t331 = load ptr, ptr %t330, !tbaa !29
  %t332 = load i32, ptr %l21, !tbaa !23
  %t335 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMembers(ptr %v0, ptr %s11, ptr %t331, i32 %t332)
  store { i64, ptr } %t335, ptr %l185
  br label %bb83
bb83:
  %t336 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t337 = extractvalue { i64, ptr } %t336, 0
  %t338 = load { i64, ptr }, ptr %l185, !tbaa !27
  %t339 = extractvalue { i64, ptr } %t338, 0
  store i64 %t339, ptr %l187, !tbaa !24
  %t341 = load i64, ptr %l187, !tbaa !24
  %t342 = icmp eq i64 %t337, %t341
  br i1 %t342, label %bb84, label %bb85
bb84:
  %t344 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t345 = load ptr, ptr %t344, !tbaa !27
  %t346 = getelementptr { i64, ptr }, ptr %l185, i32 0, i32 1
  %t347 = load ptr, ptr %t346, !tbaa !27
  %t348 = load i64, ptr %l187, !tbaa !24
  %t349 = mul i64 %t348, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t345, ptr %t347, i64 %t349, i1 false)
  br label %bb86
bb85:
  %t350 = load { i64, ptr }, ptr %l185, !tbaa !27
  store { i64, ptr } %t350, ptr %l22, !tbaa !27
  br label %bb86
bb86:
  br label %bb87
bb87:
  %t351 = load i1, ptr %l15, !tbaa !21
  %t353 = xor i1 %t351, true
  br i1 %t353, label %bb88, label %bb89
bb88:
  call void @__olang_scope_close(ptr %s11)
  br label %bb110
bb89:
  br label %bb90
bb90:
  %t355 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t355, ptr %l23, !tbaa !27
  store i64 0, ptr %l24, !tbaa !24
  %t357 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t359 = extractvalue { i64, ptr } %t357, 0
  store i64 %t359, ptr %l25, !tbaa !24
  br label %bb91
bb91:
  store %olang.scope zeroinitializer, ptr %s17
  %t361 = load i64, ptr %l24, !tbaa !24
  %t362 = load i64, ptr %l25, !tbaa !24
  %t365 = icmp slt i64 %t361, %t362
  %t367 = xor i1 %t365, true
  br i1 %t367, label %bb92, label %bb93
bb92:
  call void @__olang_scope_close(ptr %s17)
  br label %bb109
bb93:
  br label %bb94
bb94:
  %t369 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t369, ptr %l198, !tbaa !27
  %t370 = load i64, ptr %l24, !tbaa !24
  %t372 = getelementptr { i64, ptr }, ptr %l198, i32 0, i32 1
  %t373 = load ptr, ptr %t372, !tbaa !27
  %t374 = getelementptr i32, ptr %t373, i64 %t370
  %t375 = load i32, ptr %t374, !tbaa !33
  store i32 %t375, ptr %l26, !tbaa !23
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t379 = getelementptr %"compiler/check:Checker", ptr %t377, i32 0, i32 1
  %t380 = load ptr, ptr %t379, !tbaa !29
  %t381 = load i32, ptr %l26, !tbaa !23
  %t382 = load i32, ptr %l9, !tbaa !23
  %t386 = call %"compiler/generic:Unmet" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMissing(ptr %v0, ptr %t380, i32 %t381, i32 %t382, i1 false, i64 0)
  store %"compiler/generic:Unmet" %t386, ptr %l205
  br label %bb95
bb95:
  %t387 = load %"compiler/generic:Unmet", ptr %l205
  store %"compiler/generic:Unmet" %t387, ptr %l27
  %t388 = getelementptr %"compiler/generic:Unmet", ptr %l27, i32 0, i32 0
  %t389 = load i64, ptr %t388, !tbaa !24
  %t391 = icmp sge i64 %t389, 0
  br i1 %t391, label %bb96, label %bb97
bb96:
  %t393 = getelementptr %"compiler/generic:Unmet", ptr %l27, i32 0, i32 3
  %t394 = load i1, ptr %t393, !tbaa !21
  store i1 %t394, ptr %l208, !tbaa !21
  br label %bb98
bb97:
  store i1 false, ptr %l208, !tbaa !21
  br label %bb98
bb98:
  %t396 = load i1, ptr %l208, !tbaa !21
  br i1 %t396, label %bb99, label %bb100
bb99:
  store %olang.scope zeroinitializer, ptr %s18
  %t397 = load ptr, ptr %l0, !tbaa !29
  store ptr %t397, ptr %l210, !tbaa !29
  %t398 = load ptr, ptr %l19, !tbaa !29
  %t400 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t398)
  store %"compiler/source:Span" %t400, ptr %l212
  br label %bb101
bb100:
  br label %bb107
bb101:
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t402 = load i32, ptr %l26, !tbaa !23
  %t405 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s18, ptr %t401, i32 %t402)
  store { i64, ptr } %t405, ptr %l215
  br label %bb102
bb102:
  %t406 = load { i64, ptr }, ptr %l215, !tbaa !27
  %t407 = extractvalue { i64, ptr } %t406, 0
  %t408 = extractvalue { i64, ptr } %t406, 1
  %t409 = mul i64 %t407, 1
  %t410 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t409)
  call void @llvm.memcpy.p0.p0.i64(ptr %t410, ptr %t408, i64 %t409, i1 false)
  %t411 = insertvalue { i64, ptr } undef, i64 %t407, 0
  %t412 = insertvalue { i64, ptr } %t411, ptr %t410, 1
  store { i64, ptr } %t412, ptr %l216, !tbaa !27
  %t413 = load ptr, ptr %l0, !tbaa !29
  %t414 = load ptr, ptr %l2, !tbaa !29
  %t416 = getelementptr %"compiler/ast:TypeDecl", ptr %t414, i32 0, i32 0
  %t417 = load i32, ptr %t416, !tbaa !23
  %t420 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s18, ptr %t413, i32 %t417)
  store { i64, ptr } %t420, ptr %l220
  br label %bb103
bb103:
  %t421 = load { i64, ptr }, ptr %l220, !tbaa !27
  %t422 = extractvalue { i64, ptr } %t421, 0
  %t423 = extractvalue { i64, ptr } %t421, 1
  %t424 = mul i64 %t422, 1
  %t425 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t424)
  call void @llvm.memcpy.p0.p0.i64(ptr %t425, ptr %t423, i64 %t424, i1 false)
  %t426 = insertvalue { i64, ptr } undef, i64 %t422, 0
  %t427 = insertvalue { i64, ptr } %t426, ptr %t425, 1
  store { i64, ptr } %t427, ptr %l221, !tbaa !27
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t429 = getelementptr %"compiler/generic:Unmet", ptr %l27, i32 0, i32 2
  %t430 = load i32, ptr %t429, !tbaa !23
  %t433 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s18, ptr %t428, i32 %t430)
  store { i64, ptr } %t433, ptr %l224
  br label %bb104
bb104:
  %t434 = load { i64, ptr }, ptr %l224, !tbaa !27
  %t435 = extractvalue { i64, ptr } %t434, 0
  %t436 = extractvalue { i64, ptr } %t434, 1
  %t437 = mul i64 %t435, 1
  %t438 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t437)
  call void @llvm.memcpy.p0.p0.i64(ptr %t438, ptr %t436, i64 %t437, i1 false)
  %t439 = insertvalue { i64, ptr } undef, i64 %t435, 0
  %t440 = insertvalue { i64, ptr } %t439, ptr %t438, 1
  %t441 = load { i64, ptr }, ptr %l216, !tbaa !27
  %t442 = load { i64, ptr }, ptr %l221, !tbaa !27
  %t444 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitMemberMissing(ptr %s18, ptr %s18, ptr %s18, ptr %s18, { i64, ptr } %t441, { i64, ptr } %t442, { i64, ptr } %t440)
  store %"compiler/msgs:Msg" %t444, ptr %l226
  br label %bb105
bb105:
  %t445 = load ptr, ptr %l210, !tbaa !29
  %t446 = load %"compiler/source:Span", ptr %l212
  %t447 = load %"compiler/msgs:Msg", ptr %l226
  %t448 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s18, ptr %t445, %"compiler/source:Span" %t446, %"compiler/msgs:Msg" %t447)
  store i64 %t448, ptr %l227
  br label %bb106
bb106:
  call void @__olang_scope_close(ptr %s18)
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s17)
  br label %bb108
bb108:
  %t449 = load i64, ptr %l24, !tbaa !24
  %t451 = add i64 %t449, 1
  store i64 %t451, ptr %l24, !tbaa !24
  br label %bb91
bb109:
  call void @__olang_scope_close(ptr %s11)
  br label %bb110
bb110:
  %t453 = load i64, ptr %l17, !tbaa !24
  %t455 = add i64 %t453, 1
  store i64 %t455, ptr %l17, !tbaa !24
  br label %bb58
bb111:
  %t457 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t457)
  br label %bb112
bb112:
  br label %bb114
bb113:
  br label %bb114
bb114:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca i32
  %l7 = alloca i32
  %l10 = alloca i1
  %l15 = alloca i32
  %l18 = alloca i1
  %l19 = alloca i1
  %l30 = alloca ptr
  %rv = alloca ptr
  %t41 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1)
  store i32 %t4, ptr %l7
  br label %bb1
bb1:
  %t5 = load i32, ptr %l7, !tbaa !23
  store i32 %t5, ptr %l3, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l3, !tbaa !23
  %t10 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l10
  br label %bb2
bb2:
  %t11 = load i1, ptr %l10, !tbaa !21
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %l3, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l15
  br label %bb5
bb4:
  br label %bb14
bb5:
  %t22 = load i32, ptr %l15, !tbaa !23
  store i32 %t22, ptr %l4, !tbaa !23
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l4, !tbaa !23
  %t27 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t23, i32 %t24)
  store i1 %t27, ptr %l18
  br label %bb6
bb6:
  %t28 = load i1, ptr %l18, !tbaa !21
  br i1 %t28, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb9
bb8:
  %t29 = load i32, ptr %l4, !tbaa !23
  %t30 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t33 = icmp eq i32 %t29, %t30
  store i1 %t33, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t35 = load i1, ptr %l19, !tbaa !21
  br i1 %t35, label %bb10, label %bb11
bb10:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load %"compiler/source:Span", ptr %l2
  %t38 = load %"compiler/source:Span", ptr %l2
  %t39 = load i32, ptr %l4, !tbaa !23
  %t40 = load ptr, ptr %l1, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t41
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t41, i32 0, i32 0
  store i64 2, ptr %t42
  %t44 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t38, 0
  %t46 = insertvalue { %"compiler/source:Span", i32, ptr } %t44, i32 %t39, 1
  %t48 = insertvalue { %"compiler/source:Span", i32, ptr } %t46, ptr %t40, 2
  %t49 = getelementptr { i64, [4 x i64] }, ptr %t41, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t48, ptr %t49
  %t50 = load { i64, [4 x i64] }, ptr %t41
  %t52 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t50, ptr %t52
  %t56 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t36, %"compiler/source:Span" %t37, ptr %t52)
  store ptr %t56, ptr %l30
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t57 = load ptr, ptr %l30, !tbaa !29
  store ptr %t57, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t58 = load ptr, ptr %l1, !tbaa !29
  store ptr %t58, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTest(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l8 = alloca ptr
  %l11 = alloca i1
  %l12 = alloca i32
  %l15 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i1
  %l29 = alloca ptr
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l42 = alloca %"compiler/msgs:Msg"
  %l43 = alloca i64
  %l47 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca %"compiler/source:Span"
  %l50 = alloca %"compiler/source:Span"
  %l51 = alloca i32
  %l52 = alloca ptr
  %l56 = alloca ptr
  %l58 = alloca ptr
  %l59 = alloca ptr
  %l60 = alloca %"compiler/source:Span"
  %l62 = alloca %"compiler/source:Span"
  %l63 = alloca ptr
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  store ptr %t2, ptr %l8, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t5 = load i32, ptr %l4, !tbaa !23
  %t8 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t4, i32 %t5)
  store i1 %t8, ptr %l11
  br label %bb1
bb1:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l4, !tbaa !23
  %t14 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %t10, i32 %t11)
  store i32 %t14, ptr %l15
  br label %bb4
bb3:
  %t15 = load i32, ptr %l4, !tbaa !23
  store i32 %t15, ptr %l12, !tbaa !23
  br label %bb5
bb4:
  %t17 = load i32, ptr %l15, !tbaa !23
  store i32 %t17, ptr %l12, !tbaa !23
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l6, !tbaa !29
  %t19 = load ptr, ptr %l8, !tbaa !29
  %t20 = load i32, ptr %l12, !tbaa !23
  %t21 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t18, ptr %t19, i32 %t20)
  store ptr %t21, ptr %l17
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l17, !tbaa !29
  store ptr %t22, ptr %l5, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l18, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l4, !tbaa !23
  %t28 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t28, ptr %l21
  br label %bb7
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l22, !tbaa !29
  %t30 = load ptr, ptr %l5, !tbaa !29
  %t33 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t30)
  store i32 %t33, ptr %l25
  br label %bb8
bb8:
  %t34 = load ptr, ptr %l22, !tbaa !29
  %t35 = load i32, ptr %l25, !tbaa !23
  %t36 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t36, ptr %l26
  br label %bb9
bb9:
  %t37 = load ptr, ptr %l18, !tbaa !29
  %t38 = load i32, ptr %l21, !tbaa !23
  %t39 = load i32, ptr %l26, !tbaa !23
  %t40 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emeets(ptr %v0, ptr %t37, i32 %t38, i32 %t39)
  store i1 %t40, ptr %l27
  br label %bb10
bb10:
  %t41 = load i1, ptr %l27, !tbaa !21
  %t42 = xor i1 %t41, true
  br i1 %t42, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s1
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l29, !tbaa !29
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t47 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t45)
  store %"compiler/source:Span" %t47, ptr %l31
  br label %bb13
bb12:
  br label %bb20
bb13:
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l32, !tbaa !29
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i32, ptr %l4, !tbaa !23
  %t53 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t53, ptr %l35
  br label %bb14
bb14:
  %t54 = load ptr, ptr %l32, !tbaa !29
  %t55 = load i32, ptr %l35, !tbaa !23
  %t56 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t54, i32 %t55)
  store { i64, ptr } %t56, ptr %l36
  br label %bb15
bb15:
  %t57 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t57, 0
  %t59 = extractvalue { i64, ptr } %t57, 1
  %t60 = mul i64 %t58, 1
  %t61 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t60)
  call void @llvm.memcpy.p0.p0.i64(ptr %t61, ptr %t59, i64 %t60, i1 false)
  %t62 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t61, 1
  store { i64, ptr } %t63, ptr %l37, !tbaa !27
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l5, !tbaa !29
  %t68 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etyOf(ptr %v0, ptr %v0, ptr %s1, ptr %t64, ptr %t65)
  store { i64, ptr } %t68, ptr %l40
  br label %bb16
bb16:
  %t69 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  %t71 = extractvalue { i64, ptr } %t69, 1
  %t72 = mul i64 %t70, 1
  %t73 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t72)
  call void @llvm.memcpy.p0.p0.i64(ptr %t73, ptr %t71, i64 %t72, i1 false)
  %t74 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  %t76 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t78 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseValueType(ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %t76, { i64, ptr } %t75)
  store %"compiler/msgs:Msg" %t78, ptr %l42
  br label %bb17
bb17:
  %t79 = load ptr, ptr %l29, !tbaa !29
  %t80 = load %"compiler/source:Span", ptr %l31
  %t81 = load %"compiler/msgs:Msg", ptr %l42
  %t82 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t79, %"compiler/source:Span" %t80, %"compiler/msgs:Msg" %t81)
  store i64 %t82, ptr %l43
  br label %bb18
bb18:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load %"compiler/source:Span", ptr %l1
  %t85 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t89 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t83, %"compiler/source:Span" %t84, i32 %t85, i64 0)
  store ptr %t89, ptr %l47
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s1)
  %t90 = load ptr, ptr %l47, !tbaa !29
  store ptr %t90, ptr %rv
  br label %ret
bb20:
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l48, !tbaa !29
  %t92 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t92, ptr %l49
  %t93 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t93, ptr %l50
  store i32 73, ptr %l51
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l52, !tbaa !29
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load %"compiler/source:Span", ptr %l1
  %t101 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t95, %"compiler/source:Span" %t96, ptr %a2)
  store ptr %t101, ptr %l56
  br label %bb21
bb21:
  %t102 = load %"compiler/source:Span", ptr %l1
  %t103 = load ptr, ptr %l52, !tbaa !29
  %t104 = load ptr, ptr %l56, !tbaa !29
  %t106 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t103, ptr %t104, %"compiler/source:Span" %t102)
  store ptr %t106, ptr %l58
  br label %bb22
bb22:
  %t107 = load ptr, ptr %l5, !tbaa !29
  store ptr %t107, ptr %l59, !tbaa !29
  %t108 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t108, ptr %l60
  %t109 = load ptr, ptr %l3, !tbaa !29
  %t111 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t109)
  store %"compiler/source:Span" %t111, ptr %l62
  br label %bb23
bb23:
  %t112 = load ptr, ptr %l48, !tbaa !29
  %t113 = load %"compiler/source:Span", ptr %l49
  %t114 = load %"compiler/source:Span", ptr %l50
  %t115 = load i32, ptr %l51
  %t116 = load ptr, ptr %l58, !tbaa !29
  %t117 = load ptr, ptr %l59, !tbaa !29
  %t118 = load %"compiler/source:Span", ptr %l60
  %t119 = load %"compiler/source:Span", ptr %l62
  %t120 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %t112, %"compiler/source:Span" %t113, %"compiler/source:Span" %t114, i32 %t115, ptr %t116, ptr %t117, %"compiler/source:Span" %t118, %"compiler/source:Span" %t119)
  store ptr %t120, ptr %l63
  br label %bb24
bb24:
  %t121 = load ptr, ptr %l63, !tbaa !29
  store ptr %t121, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarInArray(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i64 %a3, i1 %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l18 = alloca i32
  %l22 = alloca i1
  %l27 = alloca i64
  %l30 = alloca i1
  %l35 = alloca i64
  %l40 = alloca ptr
  %l45 = alloca i32
  %l50 = alloca i1
  %l53 = alloca ptr
  %l58 = alloca i32
  %l63 = alloca i1
  %l68 = alloca ptr
  %l73 = alloca i32
  %l74 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l90 = alloca i1
  %s7 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l5, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 2
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l18
  br label %bb4
bb4:
  %t16 = load i32, ptr %l18
  store i32 %t16, ptr %l6
  %t17 = load i32, ptr %l6
  %t19 = trunc i64 25 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb16
bb7:
  br i1 %a4, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t30 = load i32, ptr %l1, !tbaa !23
  %t33 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t29, i32 %t30)
  store i64 %t33, ptr %l27
  br label %bb10
bb9:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb11
bb10:
  %t34 = load i64, ptr %l2, !tbaa !24
  %t35 = load i64, ptr %l27, !tbaa !24
  %t37 = icmp eq i64 %t35, %t34
  store i1 %t37, ptr %l22, !tbaa !21
  br label %bb11
bb11:
  %t39 = load i1, ptr %l22, !tbaa !21
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/check:Checker", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/generic:Program", ptr %t43, i32 0, i32 2
  %t46 = load i32, ptr %l1, !tbaa !23
  %t49 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t45, i32 %t46)
  store i64 %t49, ptr %l35
  br label %bb14
bb13:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb15
bb14:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i64, ptr %l35, !tbaa !24
  %t53 = icmp eq i64 %t51, %t50
  store i1 %t53, ptr %l30, !tbaa !21
  br label %bb15
bb15:
  %t55 = load i1, ptr %l30, !tbaa !21
  store i1 %t55, ptr %rv
  br label %ret
bb16:
  %t56 = load i32, ptr %l6
  %t58 = trunc i64 19 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb22
bb19:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l40, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %l1, !tbaa !23
  %t71 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t67, i32 %t68)
  store i32 %t71, ptr %l45
  br label %bb20
bb20:
  %t72 = load i64, ptr %l2, !tbaa !24
  %t73 = load i64, ptr %l3, !tbaa !24
  %t74 = load i64, ptr %l5, !tbaa !24
  %t76 = add i64 %t74, 1
  %t77 = load ptr, ptr %l40, !tbaa !29
  %t78 = load i32, ptr %l45, !tbaa !23
  %t82 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarInArray(ptr %v0, ptr %t77, i32 %t78, i64 %t72, i64 %t73, i1 true, i64 %t76)
  store i1 %t82, ptr %l50
  br label %bb21
bb21:
  %t83 = load i1, ptr %l50, !tbaa !21
  store i1 %t83, ptr %rv
  br label %ret
bb22:
  %t84 = load i32, ptr %l6
  %t86 = trunc i64 20 to i32
  %t87 = icmp eq i32 %t84, %t86
  br i1 %t87, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb28
bb25:
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l53, !tbaa !29
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/check:Checker", ptr %t90, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = getelementptr %"compiler/generic:Program", ptr %t93, i32 0, i32 2
  %t96 = load i32, ptr %l1, !tbaa !23
  %t99 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t95, i32 %t96)
  store i32 %t99, ptr %l58
  br label %bb26
bb26:
  %t100 = load i64, ptr %l2, !tbaa !24
  %t101 = load i64, ptr %l3, !tbaa !24
  %t102 = load i64, ptr %l5, !tbaa !24
  %t104 = add i64 %t102, 1
  %t105 = load ptr, ptr %l53, !tbaa !29
  %t106 = load i32, ptr %l58, !tbaa !23
  %t110 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarInArray(ptr %v0, ptr %t105, i32 %t106, i64 %t100, i64 %t101, i1 false, i64 %t104)
  store i1 %t110, ptr %l63
  br label %bb27
bb27:
  %t111 = load i1, ptr %l63, !tbaa !21
  store i1 %t111, ptr %rv
  br label %ret
bb28:
  %t112 = load i32, ptr %l6
  %t114 = trunc i64 18 to i32
  %t115 = icmp eq i32 %t112, %t114
  br i1 %t115, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb44
bb31:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = getelementptr %"compiler/generic:Program", ptr %t120, i32 0, i32 2
  store ptr %t122, ptr %l68, !tbaa !29
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/check:Checker", ptr %t123, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t128 = getelementptr %"compiler/generic:Program", ptr %t126, i32 0, i32 2
  %t129 = load i32, ptr %l1, !tbaa !23
  %t132 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t128, i32 %t129)
  store i32 %t132, ptr %l73
  br label %bb32
bb32:
  %t133 = load ptr, ptr %l68, !tbaa !29
  %t134 = load i32, ptr %l73, !tbaa !23
  %t135 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t133, i32 %t134)
  store { i64, ptr } %t135, ptr %l74
  br label %bb33
bb33:
  %t136 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t136, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t137 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t137, 0
  store i64 %t139, ptr %l9, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s7
  %t141 = load i64, ptr %l8, !tbaa !24
  %t142 = load i64, ptr %l9, !tbaa !24
  %t145 = icmp slt i64 %t141, %t142
  %t147 = xor i1 %t145, true
  br i1 %t147, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s7)
  br label %bb43
bb36:
  br label %bb37
bb37:
  %t149 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t149, ptr %l81, !tbaa !27
  %t150 = load i64, ptr %l8, !tbaa !24
  %t152 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = getelementptr i32, ptr %t153, i64 %t150
  %t155 = load i32, ptr %t154, !tbaa !33
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = load i64, ptr %l2, !tbaa !24
  %t160 = load i64, ptr %l3, !tbaa !24
  %t161 = load i64, ptr %l5, !tbaa !24
  %t163 = add i64 %t161, 1
  %t169 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarInArray(ptr %v0, ptr %t157, i32 %t155, i64 %t159, i64 %t160, i1 true, i64 %t163)
  store i1 %t169, ptr %l90
  br label %bb38
bb38:
  %t170 = load i1, ptr %l90, !tbaa !21
  br i1 %t170, label %bb39, label %bb40
bb39:
  call void @__olang_scope_close(ptr %s7)
  store i1 true, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s7)
  br label %bb42
bb42:
  %t172 = load i64, ptr %l8, !tbaa !24
  %t174 = add i64 %t172, 1
  store i64 %t174, ptr %l8, !tbaa !24
  br label %bb34
bb43:
  store i1 false, ptr %rv
  br label %ret
bb44:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkRuns(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i64 %a4, ptr %a5, i32 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, i64, i64 }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca { i64, i64, i64 }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l26 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca { i64, i64, i64 }
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l39 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca %"compiler/source:Span"
  %l43 = alloca i32
  %l44 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca %"compiler/source:Span"
  %l49 = alloca i32
  %l50 = alloca ptr
  %l51 = alloca %"compiler/source:Span"
  %l53 = alloca i32
  %l54 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca %"compiler/source:Span"
  %l63 = alloca i32
  %l64 = alloca i64
  %l65 = alloca ptr
  %l66 = alloca %"compiler/source:Span"
  %l69 = alloca i32
  %l70 = alloca ptr
  %l71 = alloca %"compiler/source:Span"
  %l73 = alloca i32
  %l74 = alloca ptr
  %l79 = alloca i64
  %l83 = alloca { i64, i64, i64 }
  %l88 = alloca ptr
  %l93 = alloca ptr
  %l97 = alloca ptr
  %l98 = alloca %"compiler/source:Span"
  %l99 = alloca i64
  %l103 = alloca ptr
  %l104 = alloca ptr
  %l108 = alloca ptr
  %l109 = alloca { i64, ptr }
  %l110 = alloca ptr
  %l113 = alloca i32
  %l117 = alloca i64
  %l118 = alloca ptr
  %l119 = alloca %"compiler/source:Span"
  %l122 = alloca i32
  %l127 = alloca ptr
  %l130 = alloca ptr
  %l131 = alloca %"compiler/source:Span"
  %l133 = alloca i32
  %l134 = alloca i64
  %l135 = alloca ptr
  %l136 = alloca %"compiler/source:Span"
  %l139 = alloca i32
  %l140 = alloca ptr
  %l141 = alloca %"compiler/source:Span"
  %l143 = alloca i32
  %l144 = alloca i32
  %l148 = alloca ptr
  %l149 = alloca ptr
  %l152 = alloca ptr
  %l153 = alloca %"compiler/source:Span"
  %l155 = alloca i32
  %l156 = alloca i64
  %l157 = alloca ptr
  %l158 = alloca %"compiler/source:Span"
  %l161 = alloca i32
  %l162 = alloca ptr
  %l163 = alloca %"compiler/source:Span"
  %l165 = alloca i32
  %l166 = alloca ptr
  %l171 = alloca i64
  %l175 = alloca { i64, i64, i64 }
  %l179 = alloca i64
  %l181 = alloca ptr
  %l184 = alloca i64
  %l185 = alloca i32
  %l187 = alloca ptr
  %l191 = alloca ptr
  %l192 = alloca ptr
  %l193 = alloca %"compiler/source:Span"
  %l194 = alloca ptr
  %l195 = alloca %"compiler/source:Span"
  %l196 = alloca i32
  %l197 = alloca i32
  %l201 = alloca ptr
  %l205 = alloca ptr
  %l207 = alloca ptr
  %l209 = alloca ptr
  %l212 = alloca i32
  %l213 = alloca %"compiler/source:Span"
  %l216 = alloca i32
  %l220 = alloca ptr
  %l223 = alloca ptr
  %l224 = alloca %"compiler/source:Span"
  %l225 = alloca %"compiler/source:Span"
  %l230 = alloca i32
  %l231 = alloca ptr
  %l235 = alloca ptr
  %l237 = alloca %"compiler/typed:Elem"
  %l241 = alloca ptr
  %l251 = alloca i64
  %l253 = alloca ptr
  %l256 = alloca i64
  %l257 = alloca i32
  %l258 = alloca i64
  %l260 = alloca ptr
  %l263 = alloca i64
  %l264 = alloca i32
  %l270 = alloca ptr
  %l273 = alloca i64
  %l277 = alloca { i64, i64, i64 }
  %l281 = alloca ptr
  %l282 = alloca %"compiler/source:Span"
  %l283 = alloca %"compiler/source:Span"
  %l285 = alloca i32
  %l290 = alloca ptr
  %l291 = alloca ptr
  %l292 = alloca %"compiler/source:Span"
  %l294 = alloca i32
  %l295 = alloca i32
  %l299 = alloca ptr
  %l300 = alloca ptr
  %l301 = alloca %"compiler/source:Span"
  %l303 = alloca i32
  %l304 = alloca ptr
  %l306 = alloca ptr
  %l311 = alloca ptr
  %l312 = alloca %"compiler/source:Span"
  %l313 = alloca %"compiler/source:Span"
  %l315 = alloca i32
  %l320 = alloca ptr
  %l321 = alloca ptr
  %l322 = alloca %"compiler/source:Span"
  %l324 = alloca i32
  %l325 = alloca i32
  %l329 = alloca ptr
  %l330 = alloca ptr
  %l331 = alloca %"compiler/source:Span"
  %l333 = alloca i32
  %l334 = alloca ptr
  %l336 = alloca ptr
  %l344 = alloca ptr
  %l352 = alloca ptr
  %l353 = alloca %"compiler/source:Span"
  %l354 = alloca %"compiler/source:Span"
  %l356 = alloca i32
  %l361 = alloca ptr
  %l362 = alloca ptr
  %l363 = alloca %"compiler/source:Span"
  %l365 = alloca i32
  %l366 = alloca i32
  %l370 = alloca ptr
  %l374 = alloca ptr
  %l376 = alloca ptr
  %l384 = alloca ptr
  %t34 = alloca { i64, [3 x i64] }, align 8
  %t80 = alloca { i64, [3 x i64] }, align 8
  %t190 = alloca { i64, [3 x i64] }, align 8
  %t238 = alloca { i64, [3 x i64] }, align 8
  %t277 = alloca { i64, [3 x i64] }, align 8
  %t390 = alloca { i64, [4 x i64] }, align 8
  %t430 = alloca { i64, [4 x i64] }, align 8
  %t535 = alloca { i64, [4 x i64] }, align 8
  %t576 = alloca { i64, [3 x i64] }, align 8
  %t604 = alloca { i64, [4 x i64] }, align 8
  %t645 = alloca { i64, [3 x i64] }, align 8
  %t676 = alloca { i64, [3 x i64] }, align 8
  %t700 = alloca { i64, [4 x i64] }, align 8
  %t739 = alloca { i64, [3 x i64] }, align 8
  %t768 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load %"compiler/source:Span", ptr %l1
  %t7 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eborrowedSource(ptr %v0, ptr %t1, %"compiler/source:Span" %t2, ptr %a3)
  store i64 %t7, ptr %l39
  br label %bb1
bb1:
  %t8 = load i64, ptr %l39, !tbaa !24
  store i64 %t8, ptr %l7, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l40, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t10, ptr %l41
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t11)
  store i32 %t13, ptr %l43
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l40, !tbaa !29
  %t15 = load %"compiler/source:Span", ptr %l41
  %t16 = load i32, ptr %l43, !tbaa !23
  %t17 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t14, %"compiler/source:Span" %t15, i32 %t16)
  store i64 %t17, ptr %l44
  br label %bb3
bb3:
  %t18 = load i64, ptr %l44, !tbaa !24
  store i64 %t18, ptr %l8, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l45, !tbaa !29
  %t20 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t20, ptr %l46
  %t21 = load i64, ptr %l8, !tbaa !24
  %t23 = trunc i64 %t21 to i32
  store i32 %t23, ptr %l49, !tbaa !23
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l50, !tbaa !29
  %t26 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t26, ptr %l51
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t27)
  store i32 %t29, ptr %l53
  br label %bb4
bb4:
  %t30 = load ptr, ptr %l50, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l51
  %t32 = load i32, ptr %l53, !tbaa !23
  %t33 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t30, %"compiler/source:Span" %t31, i32 %t32, i64 0)
  store ptr %t33, ptr %l54
  br label %bb5
bb5:
  store { i64, [3 x i64] } zeroinitializer, ptr %t34
  %t35 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 0
  store i64 0, ptr %t35
  %t36 = load %"compiler/source:Span", ptr %l46
  %t37 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t36, 0
  %t38 = load i32, ptr %l49, !tbaa !23
  %t39 = insertvalue { %"compiler/source:Span", i32, ptr } %t37, i32 %t38, 1
  %t40 = load ptr, ptr %l54, !tbaa !29
  %t41 = insertvalue { %"compiler/source:Span", i32, ptr } %t39, ptr %t40, 2
  %t42 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t41, ptr %t42
  %t43 = load { i64, [3 x i64] }, ptr %t34
  %t45 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t43, ptr %t45
  %t46 = load ptr, ptr %l45, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t46, ptr %t45)
  br label %bb6
bb6:
  store i64 -1, ptr %l9, !tbaa !24
  %t48 = load ptr, ptr %l2, !tbaa !29
  %t50 = getelementptr %"compiler/ast:ForIn", ptr %t48, i32 0, i32 0
  %t51 = load i32, ptr %t50, !tbaa !23
  %t53 = icmp ne i32 %t51, 0
  br i1 %t53, label %bb7, label %bb8
bb7:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l60, !tbaa !29
  %t56 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t56, ptr %l61
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t57)
  store i32 %t59, ptr %l63
  br label %bb9
bb8:
  br label %bb14
bb9:
  %t60 = load ptr, ptr %l60, !tbaa !29
  %t61 = load %"compiler/source:Span", ptr %l61
  %t62 = load i32, ptr %l63, !tbaa !23
  %t63 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t60, %"compiler/source:Span" %t61, i32 %t62)
  store i64 %t63, ptr %l64
  br label %bb10
bb10:
  %t64 = load i64, ptr %l64, !tbaa !24
  store i64 %t64, ptr %l9, !tbaa !24
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l65, !tbaa !29
  %t66 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t66, ptr %l66
  %t67 = load i64, ptr %l9, !tbaa !24
  %t69 = trunc i64 %t67 to i32
  store i32 %t69, ptr %l69, !tbaa !23
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l70, !tbaa !29
  %t72 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t72, ptr %l71
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t73)
  store i32 %t75, ptr %l73
  br label %bb11
bb11:
  %t76 = load ptr, ptr %l70, !tbaa !29
  %t77 = load %"compiler/source:Span", ptr %l71
  %t78 = load i32, ptr %l73, !tbaa !23
  %t79 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t76, %"compiler/source:Span" %t77, i32 %t78, i64 0)
  store ptr %t79, ptr %l74
  br label %bb12
bb12:
  store { i64, [3 x i64] } zeroinitializer, ptr %t80
  %t81 = getelementptr { i64, [3 x i64] }, ptr %t80, i32 0, i32 0
  store i64 0, ptr %t81
  %t82 = load %"compiler/source:Span", ptr %l66
  %t83 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t82, 0
  %t84 = load i32, ptr %l69, !tbaa !23
  %t85 = insertvalue { %"compiler/source:Span", i32, ptr } %t83, i32 %t84, 1
  %t86 = load ptr, ptr %l74, !tbaa !29
  %t87 = insertvalue { %"compiler/source:Span", i32, ptr } %t85, ptr %t86, 2
  %t88 = getelementptr { i64, [3 x i64] }, ptr %t80, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t87, ptr %t88
  %t89 = load { i64, [3 x i64] }, ptr %t80
  %t91 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t89, ptr %t91
  %t92 = load ptr, ptr %l65, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t92, ptr %t91)
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 32
  %t98 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t96)
  store i64 %t98, ptr %l79
  br label %bb15
bb15:
  %t99 = load i64, ptr %l79, !tbaa !24
  store i64 %t99, ptr %l10, !tbaa !24
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load %"compiler/source:Span", ptr %l1
  %t105 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t100, i32 2, %"compiler/source:Span" %t101)
  store { i64, i64, i64 } %t105, ptr %l83
  br label %bb16
bb16:
  %t106 = load { i64, i64, i64 }, ptr %l83
  store { i64, i64, i64 } %t106, ptr %l11
  %t107 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 0
  %t108 = load i64, ptr %t107, !tbaa !24
  store i64 %t108, ptr %l12, !tbaa !24
  %t110 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 1
  %t111 = load i64, ptr %t110, !tbaa !24
  store i64 %t111, ptr %l13, !tbaa !24
  %t113 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 2
  %t114 = load i64, ptr %t113, !tbaa !24
  store i64 %t114, ptr %l14, !tbaa !24
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t116)
  store ptr %t118, ptr %l88
  br label %bb17
bb17:
  %t119 = load ptr, ptr %l88, !tbaa !29
  %t121 = getelementptr %"compiler/check:frame", ptr %t119, i32 0, i32 10
  %t122 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t121, i64 %t122)
  br label %bb18
bb18:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t125)
  store ptr %t127, ptr %l93
  br label %bb19
bb19:
  %t128 = load ptr, ptr %l93, !tbaa !29
  %t130 = getelementptr %"compiler/check:frame", ptr %t128, i32 0, i32 11
  %t131 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t130, i64 %t131)
  br label %bb20
bb20:
  %t134 = load ptr, ptr %l0, !tbaa !29
  store ptr %t134, ptr %l97, !tbaa !29
  %t135 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t135, ptr %l98
  store i64 %a4, ptr %l99, !tbaa !24
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load %"compiler/source:Span", ptr %l1
  %t139 = load i64, ptr %l7, !tbaa !24
  %t143 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t137, %"compiler/source:Span" %t138, i64 %t139)
  store ptr %t143, ptr %l103
  br label %bb21
bb21:
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l104, !tbaa !29
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load %"compiler/source:Span", ptr %l1
  %t147 = load i64, ptr %l8, !tbaa !24
  %t151 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t145, %"compiler/source:Span" %t146, i64 %t147)
  store ptr %t151, ptr %l108
  br label %bb22
bb22:
  %t152 = load ptr, ptr %l104, !tbaa !29
  %t153 = load ptr, ptr %l108, !tbaa !29
  %t154 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %t152, ptr %t153)
  store { i64, ptr } %t154, ptr %l109
  br label %bb23
bb23:
  %t155 = load ptr, ptr %l97, !tbaa !29
  %t156 = load %"compiler/source:Span", ptr %l98
  %t157 = load i64, ptr %l99, !tbaa !24
  %t158 = load ptr, ptr %l103, !tbaa !29
  %t159 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t160 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloopCall(ptr %v0, ptr %t155, %"compiler/source:Span" %t156, i64 %t157, ptr %t158, { i64, ptr } %t159)
  store ptr %t160, ptr %l110
  br label %bb24
bb24:
  %t161 = load ptr, ptr %l110, !tbaa !29
  store ptr %t161, ptr %l15, !tbaa !29
  %t162 = load ptr, ptr %l15, !tbaa !29
  %t165 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t162)
  store i32 %t165, ptr %l113
  br label %bb25
bb25:
  %t166 = load i32, ptr %l113, !tbaa !23
  store i32 %t166, ptr %l16, !tbaa !23
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load %"compiler/source:Span", ptr %l1
  %t169 = load i32, ptr %l16, !tbaa !23
  %t173 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t167, %"compiler/source:Span" %t168, i32 %t169)
  store i64 %t173, ptr %l117
  br label %bb26
bb26:
  %t174 = load i64, ptr %l117, !tbaa !24
  store i64 %t174, ptr %l17, !tbaa !24
  %t175 = load ptr, ptr %l0, !tbaa !29
  store ptr %t175, ptr %l118, !tbaa !29
  %t176 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t176, ptr %l119
  %t177 = load i64, ptr %l17, !tbaa !24
  %t179 = trunc i64 %t177 to i32
  store i32 %t179, ptr %l122, !tbaa !23
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load %"compiler/source:Span", ptr %l1
  %t183 = load ptr, ptr %l15, !tbaa !29
  %t184 = load i64, ptr %l12, !tbaa !24
  %t189 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexhaustedOrBreak(ptr %v0, ptr %t181, %"compiler/source:Span" %t182, ptr %t183, i64 %t184)
  store ptr %t189, ptr %l127
  br label %bb27
bb27:
  store { i64, [3 x i64] } zeroinitializer, ptr %t190
  %t191 = getelementptr { i64, [3 x i64] }, ptr %t190, i32 0, i32 0
  store i64 0, ptr %t191
  %t192 = load %"compiler/source:Span", ptr %l119
  %t193 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t192, 0
  %t194 = load i32, ptr %l122, !tbaa !23
  %t195 = insertvalue { %"compiler/source:Span", i32, ptr } %t193, i32 %t194, 1
  %t196 = load ptr, ptr %l127, !tbaa !29
  %t197 = insertvalue { %"compiler/source:Span", i32, ptr } %t195, ptr %t196, 2
  %t198 = getelementptr { i64, [3 x i64] }, ptr %t190, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t197, ptr %t198
  %t199 = load { i64, [3 x i64] }, ptr %t190
  %t201 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t199, ptr %t201
  %t202 = load ptr, ptr %l118, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t202, ptr %t201)
  br label %bb28
bb28:
  %t204 = load ptr, ptr %l0, !tbaa !29
  store ptr %t204, ptr %l130, !tbaa !29
  %t205 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t205, ptr %l131
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t206)
  store i32 %t208, ptr %l133
  br label %bb29
bb29:
  %t209 = load ptr, ptr %l130, !tbaa !29
  %t210 = load %"compiler/source:Span", ptr %l131
  %t211 = load i32, ptr %l133, !tbaa !23
  %t212 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t209, %"compiler/source:Span" %t210, i32 %t211)
  store i64 %t212, ptr %l134
  br label %bb30
bb30:
  %t213 = load i64, ptr %l134, !tbaa !24
  store i64 %t213, ptr %l18, !tbaa !24
  %t214 = load ptr, ptr %l0, !tbaa !29
  store ptr %t214, ptr %l135, !tbaa !29
  %t215 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t215, ptr %l136
  %t216 = load i64, ptr %l18, !tbaa !24
  %t218 = trunc i64 %t216 to i32
  store i32 %t218, ptr %l139, !tbaa !23
  %t220 = load ptr, ptr %l0, !tbaa !29
  store ptr %t220, ptr %l140, !tbaa !29
  %t221 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t221, ptr %l141
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t222)
  store i32 %t224, ptr %l143
  br label %bb31
bb31:
  store i32 22, ptr %l144
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load %"compiler/source:Span", ptr %l1
  %t227 = load i64, ptr %l17, !tbaa !24
  %t231 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t225, %"compiler/source:Span" %t226, i64 %t227)
  store ptr %t231, ptr %l148
  br label %bb32
bb32:
  %t232 = load ptr, ptr %l140, !tbaa !29
  %t233 = load %"compiler/source:Span", ptr %l141
  %t234 = load i32, ptr %l143, !tbaa !23
  %t235 = load i32, ptr %l144
  %t236 = load ptr, ptr %l148, !tbaa !29
  %t237 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t232, %"compiler/source:Span" %t233, i32 %t234, i32 %t235, ptr %t236, ptr null)
  store ptr %t237, ptr %l149
  br label %bb33
bb33:
  store { i64, [3 x i64] } zeroinitializer, ptr %t238
  %t239 = getelementptr { i64, [3 x i64] }, ptr %t238, i32 0, i32 0
  store i64 0, ptr %t239
  %t240 = load %"compiler/source:Span", ptr %l136
  %t241 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t240, 0
  %t242 = load i32, ptr %l139, !tbaa !23
  %t243 = insertvalue { %"compiler/source:Span", i32, ptr } %t241, i32 %t242, 1
  %t244 = load ptr, ptr %l149, !tbaa !29
  %t245 = insertvalue { %"compiler/source:Span", i32, ptr } %t243, ptr %t244, 2
  %t246 = getelementptr { i64, [3 x i64] }, ptr %t238, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t245, ptr %t246
  %t247 = load { i64, [3 x i64] }, ptr %t238
  %t249 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t247, ptr %t249
  %t250 = load ptr, ptr %l135, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t250, ptr %t249)
  br label %bb34
bb34:
  %t252 = load ptr, ptr %l0, !tbaa !29
  store ptr %t252, ptr %l152, !tbaa !29
  %t253 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t253, ptr %l153
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t254)
  store i32 %t256, ptr %l155
  br label %bb35
bb35:
  %t257 = load ptr, ptr %l152, !tbaa !29
  %t258 = load %"compiler/source:Span", ptr %l153
  %t259 = load i32, ptr %l155, !tbaa !23
  %t260 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t257, %"compiler/source:Span" %t258, i32 %t259)
  store i64 %t260, ptr %l156
  br label %bb36
bb36:
  %t261 = load i64, ptr %l156, !tbaa !24
  store i64 %t261, ptr %l19, !tbaa !24
  %t262 = load ptr, ptr %l0, !tbaa !29
  store ptr %t262, ptr %l157, !tbaa !29
  %t263 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t263, ptr %l158
  %t264 = load i64, ptr %l19, !tbaa !24
  %t266 = trunc i64 %t264 to i32
  store i32 %t266, ptr %l161, !tbaa !23
  %t268 = load ptr, ptr %l0, !tbaa !29
  store ptr %t268, ptr %l162, !tbaa !29
  %t269 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t269, ptr %l163
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t272 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t270)
  store i32 %t272, ptr %l165
  br label %bb37
bb37:
  %t273 = load ptr, ptr %l162, !tbaa !29
  %t274 = load %"compiler/source:Span", ptr %l163
  %t275 = load i32, ptr %l165, !tbaa !23
  %t276 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t273, %"compiler/source:Span" %t274, i32 %t275, i64 0)
  store ptr %t276, ptr %l166
  br label %bb38
bb38:
  store { i64, [3 x i64] } zeroinitializer, ptr %t277
  %t278 = getelementptr { i64, [3 x i64] }, ptr %t277, i32 0, i32 0
  store i64 0, ptr %t278
  %t279 = load %"compiler/source:Span", ptr %l158
  %t280 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t279, 0
  %t281 = load i32, ptr %l161, !tbaa !23
  %t282 = insertvalue { %"compiler/source:Span", i32, ptr } %t280, i32 %t281, 1
  %t283 = load ptr, ptr %l166, !tbaa !29
  %t284 = insertvalue { %"compiler/source:Span", i32, ptr } %t282, ptr %t283, 2
  %t285 = getelementptr { i64, [3 x i64] }, ptr %t277, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t284, ptr %t285
  %t286 = load { i64, [3 x i64] }, ptr %t277
  %t288 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t286, ptr %t288
  %t289 = load ptr, ptr %l157, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t289, ptr %t288)
  br label %bb39
bb39:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t293 = getelementptr %"compiler/check:Checker", ptr %t291, i32 0, i32 32
  %t295 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t293)
  store i64 %t295, ptr %l171
  br label %bb40
bb40:
  %t296 = load i64, ptr %l171, !tbaa !24
  store i64 %t296, ptr %l20, !tbaa !24
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load %"compiler/source:Span", ptr %l1
  %t302 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t297, i32 2, %"compiler/source:Span" %t298)
  store { i64, i64, i64 } %t302, ptr %l175
  br label %bb41
bb41:
  %t303 = load { i64, i64, i64 }, ptr %l175
  store { i64, i64, i64 } %t303, ptr %l21
  %t304 = getelementptr { i64, i64, i64 }, ptr %l21, i32 0, i32 0
  %t305 = load i64, ptr %t304, !tbaa !24
  store i64 %t305, ptr %l22, !tbaa !24
  %t307 = getelementptr { i64, i64, i64 }, ptr %l21, i32 0, i32 1
  %t308 = load i64, ptr %t307, !tbaa !24
  store i64 %t308, ptr %l23, !tbaa !24
  %t310 = getelementptr { i64, i64, i64 }, ptr %l21, i32 0, i32 2
  %t311 = load i64, ptr %t310, !tbaa !24
  store i64 %t311, ptr %l24, !tbaa !24
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t315 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t313)
  store ptr %t315, ptr %l181
  br label %bb42
bb42:
  %t316 = load ptr, ptr %l181, !tbaa !29
  %t318 = getelementptr %"compiler/check:frame", ptr %t316, i32 0, i32 10
  %t320 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t318)
  %t321 = extractvalue { i32, i64 } %t320, 1
  %t322 = extractvalue { i32, i64 } %t320, 0
  store i32 %t322, ptr %l185
  %t323 = icmp ne i32 %t322, 0
  br i1 %t323, label %bb44, label %ok.324
ok.324:
  store i64 %t321, ptr %l184
  br label %bb43
bb43:
  %t325 = load i64, ptr %l184, !tbaa !24
  store i64 %t325, ptr %l179, !tbaa !24
  br label %bb46
bb44:
  br label %bb45
bb45:
  br label %bb46
bb46:
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t328 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t326)
  store ptr %t328, ptr %l187
  br label %bb47
bb47:
  %t329 = load ptr, ptr %l187, !tbaa !29
  %t331 = getelementptr %"compiler/check:frame", ptr %t329, i32 0, i32 10
  %t332 = load i64, ptr %l22, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t331, i64 %t332)
  br label %bb48
bb48:
  %t335 = load ptr, ptr %l0, !tbaa !29
  store ptr %t335, ptr %l191, !tbaa !29
  %t336 = load ptr, ptr %l0, !tbaa !29
  store ptr %t336, ptr %l192, !tbaa !29
  %t337 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t337, ptr %l193
  %t338 = load ptr, ptr %l0, !tbaa !29
  store ptr %t338, ptr %l194, !tbaa !29
  %t339 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t339, ptr %l195
  %t340 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t340, ptr %l196, !tbaa !23
  store i32 15, ptr %l197
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t342 = load %"compiler/source:Span", ptr %l1
  %t343 = load i64, ptr %l19, !tbaa !24
  %t347 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t341, %"compiler/source:Span" %t342, i64 %t343)
  store ptr %t347, ptr %l201
  br label %bb49
bb49:
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t349 = load %"compiler/source:Span", ptr %l1
  %t350 = load i64, ptr %l18, !tbaa !24
  %t354 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t348, %"compiler/source:Span" %t349, i64 %t350)
  store ptr %t354, ptr %l205
  br label %bb50
bb50:
  %t355 = load ptr, ptr %l205, !tbaa !29
  %t356 = load ptr, ptr %l194, !tbaa !29
  %t357 = load %"compiler/source:Span", ptr %l195
  %t358 = load i32, ptr %l196, !tbaa !23
  %t359 = load i32, ptr %l197
  %t360 = load ptr, ptr %l201, !tbaa !29
  %t362 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t356, %"compiler/source:Span" %t357, i32 %t358, i32 %t359, ptr %t360, ptr %t355)
  store ptr %t362, ptr %l207
  br label %bb51
bb51:
  %t363 = load i64, ptr %l22, !tbaa !24
  %t364 = load ptr, ptr %l192, !tbaa !29
  %t365 = load %"compiler/source:Span", ptr %l193
  %t366 = load ptr, ptr %l207, !tbaa !29
  %t368 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebreakUnless(ptr %v0, ptr %t364, %"compiler/source:Span" %t365, ptr %t366, i64 %t363)
  store ptr %t368, ptr %l209
  br label %bb52
bb52:
  %t369 = load ptr, ptr %l191, !tbaa !29
  %t370 = load ptr, ptr %l209, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t369, ptr %t370)
  br label %bb53
bb53:
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t372 = load i32, ptr %l16, !tbaa !23
  %t375 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t371, i32 %t372)
  store i32 %t375, ptr %l212
  br label %bb54
bb54:
  %t376 = load i32, ptr %l212, !tbaa !23
  store i32 %t376, ptr %l25, !tbaa !23
  %t377 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t377, ptr %l213
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t379 = load i32, ptr %l16, !tbaa !23
  %t382 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t378, i32 %t379)
  store i32 %t382, ptr %l216
  br label %bb55
bb55:
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t384 = load %"compiler/source:Span", ptr %l1
  %t385 = load i64, ptr %l17, !tbaa !24
  %t389 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t383, %"compiler/source:Span" %t384, i64 %t385)
  store ptr %t389, ptr %l220
  br label %bb56
bb56:
  store { i64, [4 x i64] } zeroinitializer, ptr %t390
  %t391 = getelementptr { i64, [4 x i64] }, ptr %t390, i32 0, i32 0
  store i64 2, ptr %t391
  %t392 = load %"compiler/source:Span", ptr %l213
  %t393 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t392, 0
  %t394 = load i32, ptr %l216, !tbaa !23
  %t395 = insertvalue { %"compiler/source:Span", i32, ptr } %t393, i32 %t394, 1
  %t396 = load ptr, ptr %l220, !tbaa !29
  %t397 = insertvalue { %"compiler/source:Span", i32, ptr } %t395, ptr %t396, 2
  %t398 = getelementptr { i64, [4 x i64] }, ptr %t390, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t397, ptr %t398
  %t399 = load { i64, [4 x i64] }, ptr %t390
  %t401 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t399, ptr %t401
  store ptr %t401, ptr %l26, !tbaa !29
  %t403 = load ptr, ptr %l0, !tbaa !29
  store ptr %t403, ptr %l223, !tbaa !29
  %t404 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t404, ptr %l224
  %t405 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t405, ptr %l225
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t408 = getelementptr %"compiler/check:Checker", ptr %t406, i32 0, i32 1
  %t409 = load ptr, ptr %t408, !tbaa !29
  %t411 = getelementptr %"compiler/generic:Program", ptr %t409, i32 0, i32 2
  %t412 = load i32, ptr %l25, !tbaa !23
  %t415 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t411, i32 %t412)
  store i32 %t415, ptr %l230
  br label %bb57
bb57:
  %t416 = load ptr, ptr %l26, !tbaa !29
  store ptr %t416, ptr %l231, !tbaa !29
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t418 = load %"compiler/source:Span", ptr %l1
  %t419 = load i64, ptr %l19, !tbaa !24
  %t423 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t417, %"compiler/source:Span" %t418, i64 %t419)
  store ptr %t423, ptr %l235
  br label %bb58
bb58:
  %t424 = load ptr, ptr %l231, !tbaa !29
  %t425 = load ptr, ptr %l235, !tbaa !29
  %t427 = call %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t424, ptr %t425, i32 0)
  store %"compiler/typed:Elem" %t427, ptr %l237
  br label %bb59
bb59:
  %t428 = load %"compiler/typed:Elem", ptr %l237
  %t429 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Elem" %t428, ptr %t429
  store { i64, [4 x i64] } zeroinitializer, ptr %t430
  %t431 = getelementptr { i64, [4 x i64] }, ptr %t430, i32 0, i32 0
  store i64 4, ptr %t431
  %t432 = load %"compiler/source:Span", ptr %l225
  %t433 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t432, 0
  %t434 = load i32, ptr %l230, !tbaa !23
  %t435 = insertvalue { %"compiler/source:Span", i32, ptr } %t433, i32 %t434, 1
  %t437 = insertvalue { %"compiler/source:Span", i32, ptr } %t435, ptr %t429, 2
  %t438 = getelementptr { i64, [4 x i64] }, ptr %t430, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t437, ptr %t438
  %t439 = load { i64, [4 x i64] }, ptr %t430
  %t441 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t439, ptr %t441
  %t442 = load ptr, ptr %l223, !tbaa !29
  %t443 = load %"compiler/source:Span", ptr %l224
  %t445 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t442, %"compiler/source:Span" %t443, ptr %t441)
  store ptr %t445, ptr %l241
  br label %bb60
bb60:
  %t446 = load ptr, ptr %l241, !tbaa !29
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t448 = load %"compiler/source:Span", ptr %l1
  %t449 = load ptr, ptr %l2, !tbaa !29
  %t450 = load i64, ptr %l9, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelementLocals(ptr %v0, ptr %v1, ptr %t447, %"compiler/source:Span" %t448, ptr %t449, i64 %t450, ptr %t446)
  br label %bb61
bb61:
  %t457 = load ptr, ptr %l0, !tbaa !29
  %t458 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkBody(ptr %v0, ptr %v1, ptr %v2, ptr %t457, ptr %t458, ptr %a5, i32 %a6)
  br label %bb62
bb62:
  %t465 = load ptr, ptr %l0, !tbaa !29
  %t467 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t465)
  store ptr %t467, ptr %l253
  br label %bb63
bb63:
  %t468 = load ptr, ptr %l253, !tbaa !29
  %t470 = getelementptr %"compiler/check:frame", ptr %t468, i32 0, i32 10
  %t472 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t470)
  %t473 = extractvalue { i32, i64 } %t472, 1
  %t474 = extractvalue { i32, i64 } %t472, 0
  store i32 %t474, ptr %l257
  %t475 = icmp ne i32 %t474, 0
  br i1 %t475, label %bb65, label %ok.476
ok.476:
  store i64 %t473, ptr %l256
  br label %bb64
bb64:
  %t477 = load i64, ptr %l256, !tbaa !24
  store i64 %t477, ptr %l251, !tbaa !24
  br label %bb67
bb65:
  br label %bb66
bb66:
  br label %bb67
bb67:
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t480 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t478)
  store ptr %t480, ptr %l260
  br label %bb68
bb68:
  %t481 = load ptr, ptr %l260, !tbaa !29
  %t483 = getelementptr %"compiler/check:frame", ptr %t481, i32 0, i32 11
  %t485 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t483)
  %t486 = extractvalue { i32, i64 } %t485, 1
  %t487 = extractvalue { i32, i64 } %t485, 0
  store i32 %t487, ptr %l264
  %t488 = icmp ne i32 %t487, 0
  br i1 %t488, label %bb70, label %ok.489
ok.489:
  store i64 %t486, ptr %l263
  br label %bb69
bb69:
  %t490 = load i64, ptr %l263, !tbaa !24
  store i64 %t490, ptr %l258, !tbaa !24
  br label %bb72
bb70:
  br label %bb71
bb71:
  br label %bb72
bb72:
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t492 = load i64, ptr %l22, !tbaa !24
  %t493 = load i64, ptr %l23, !tbaa !24
  %t494 = load i64, ptr %l24, !tbaa !24
  %t495 = load i64, ptr %l20, !tbaa !24
  %t501 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t491, i64 %t492, i64 %t493, i64 %t494, i64 %t495)
  store ptr %t501, ptr %l270
  br label %bb73
bb73:
  %t502 = load ptr, ptr %l270, !tbaa !29
  store ptr %t502, ptr %l28, !tbaa !29
  %t503 = load ptr, ptr %l0, !tbaa !29
  %t505 = getelementptr %"compiler/check:Checker", ptr %t503, i32 0, i32 32
  %t507 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t505)
  store i64 %t507, ptr %l273
  br label %bb74
bb74:
  %t508 = load i64, ptr %l273, !tbaa !24
  store i64 %t508, ptr %l29, !tbaa !24
  %t509 = load ptr, ptr %l0, !tbaa !29
  %t510 = load %"compiler/source:Span", ptr %l1
  %t514 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t509, i32 3, %"compiler/source:Span" %t510)
  store { i64, i64, i64 } %t514, ptr %l277
  br label %bb75
bb75:
  %t515 = load { i64, i64, i64 }, ptr %l277
  store { i64, i64, i64 } %t515, ptr %l30
  %t516 = getelementptr { i64, i64, i64 }, ptr %l30, i32 0, i32 0
  %t517 = load i64, ptr %t516, !tbaa !24
  store i64 %t517, ptr %l31, !tbaa !24
  %t519 = getelementptr { i64, i64, i64 }, ptr %l30, i32 0, i32 1
  %t520 = load i64, ptr %t519, !tbaa !24
  store i64 %t520, ptr %l32, !tbaa !24
  %t522 = getelementptr { i64, i64, i64 }, ptr %l30, i32 0, i32 2
  %t523 = load i64, ptr %t522, !tbaa !24
  store i64 %t523, ptr %l33, !tbaa !24
  %t525 = load ptr, ptr %l0, !tbaa !29
  store ptr %t525, ptr %l281, !tbaa !29
  %t526 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t526, ptr %l282
  %t527 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t527, ptr %l283
  %t528 = load ptr, ptr %l0, !tbaa !29
  %t530 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t528)
  store i32 %t530, ptr %l285
  br label %bb76
bb76:
  %t531 = load i64, ptr %l19, !tbaa !24
  %t533 = trunc i64 %t531 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t535
  %t536 = getelementptr { i64, [4 x i64] }, ptr %t535, i32 0, i32 0
  store i64 0, ptr %t536
  %t537 = load %"compiler/source:Span", ptr %l283
  %t538 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t537, 0
  %t539 = load i32, ptr %l285, !tbaa !23
  %t540 = insertvalue { %"compiler/source:Span", i32, i32 } %t538, i32 %t539, 1
  %t542 = insertvalue { %"compiler/source:Span", i32, i32 } %t540, i32 %t533, 2
  %t543 = getelementptr { i64, [4 x i64] }, ptr %t535, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t542, ptr %t543
  %t544 = load { i64, [4 x i64] }, ptr %t535
  %t546 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t544, ptr %t546
  store ptr %t546, ptr %l290, !tbaa !29
  %t547 = load ptr, ptr %l0, !tbaa !29
  store ptr %t547, ptr %l291, !tbaa !29
  %t548 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t548, ptr %l292
  %t549 = load ptr, ptr %l0, !tbaa !29
  %t551 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t549)
  store i32 %t551, ptr %l294
  br label %bb77
bb77:
  store i32 3, ptr %l295
  %t552 = load ptr, ptr %l0, !tbaa !29
  %t553 = load %"compiler/source:Span", ptr %l1
  %t554 = load i64, ptr %l19, !tbaa !24
  %t558 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t552, %"compiler/source:Span" %t553, i64 %t554)
  store ptr %t558, ptr %l299
  br label %bb78
bb78:
  %t559 = load ptr, ptr %l0, !tbaa !29
  store ptr %t559, ptr %l300, !tbaa !29
  %t560 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t560, ptr %l301
  %t561 = load ptr, ptr %l0, !tbaa !29
  %t563 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t561)
  store i32 %t563, ptr %l303
  br label %bb79
bb79:
  %t564 = load ptr, ptr %l300, !tbaa !29
  %t565 = load %"compiler/source:Span", ptr %l301
  %t566 = load i32, ptr %l303, !tbaa !23
  %t567 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t564, %"compiler/source:Span" %t565, i32 %t566, i64 1)
  store ptr %t567, ptr %l304
  br label %bb80
bb80:
  %t568 = load ptr, ptr %l304, !tbaa !29
  %t569 = load ptr, ptr %l291, !tbaa !29
  %t570 = load %"compiler/source:Span", ptr %l292
  %t571 = load i32, ptr %l294, !tbaa !23
  %t572 = load i32, ptr %l295
  %t573 = load ptr, ptr %l299, !tbaa !29
  %t575 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t569, %"compiler/source:Span" %t570, i32 %t571, i32 %t572, ptr %t573, ptr %t568)
  store ptr %t575, ptr %l306
  br label %bb81
bb81:
  store { i64, [3 x i64] } zeroinitializer, ptr %t576
  %t577 = getelementptr { i64, [3 x i64] }, ptr %t576, i32 0, i32 0
  store i64 1, ptr %t577
  %t578 = load %"compiler/source:Span", ptr %l282
  %t579 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t578, 0
  %t580 = load ptr, ptr %l290, !tbaa !29
  %t581 = insertvalue { %"compiler/source:Span", ptr, ptr } %t579, ptr %t580, 1
  %t582 = load ptr, ptr %l306, !tbaa !29
  %t583 = insertvalue { %"compiler/source:Span", ptr, ptr } %t581, ptr %t582, 2
  %t584 = getelementptr { i64, [3 x i64] }, ptr %t576, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t583, ptr %t584
  %t585 = load { i64, [3 x i64] }, ptr %t576
  %t587 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t585, ptr %t587
  %t588 = load ptr, ptr %l281, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t588, ptr %t587)
  br label %bb82
bb82:
  %t590 = load i64, ptr %l9, !tbaa !24
  %t592 = icmp sge i64 %t590, 0
  br i1 %t592, label %bb83, label %bb84
bb83:
  %t594 = load ptr, ptr %l0, !tbaa !29
  store ptr %t594, ptr %l311, !tbaa !29
  %t595 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t595, ptr %l312
  %t596 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t596, ptr %l313
  %t597 = load ptr, ptr %l0, !tbaa !29
  %t599 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t597)
  store i32 %t599, ptr %l315
  br label %bb85
bb84:
  br label %bb92
bb85:
  %t600 = load i64, ptr %l9, !tbaa !24
  %t602 = trunc i64 %t600 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t604
  %t605 = getelementptr { i64, [4 x i64] }, ptr %t604, i32 0, i32 0
  store i64 0, ptr %t605
  %t606 = load %"compiler/source:Span", ptr %l313
  %t607 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t606, 0
  %t608 = load i32, ptr %l315, !tbaa !23
  %t609 = insertvalue { %"compiler/source:Span", i32, i32 } %t607, i32 %t608, 1
  %t611 = insertvalue { %"compiler/source:Span", i32, i32 } %t609, i32 %t602, 2
  %t612 = getelementptr { i64, [4 x i64] }, ptr %t604, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t611, ptr %t612
  %t613 = load { i64, [4 x i64] }, ptr %t604
  %t615 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t613, ptr %t615
  store ptr %t615, ptr %l320, !tbaa !29
  %t616 = load ptr, ptr %l0, !tbaa !29
  store ptr %t616, ptr %l321, !tbaa !29
  %t617 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t617, ptr %l322
  %t618 = load ptr, ptr %l0, !tbaa !29
  %t620 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t618)
  store i32 %t620, ptr %l324
  br label %bb86
bb86:
  store i32 3, ptr %l325
  %t621 = load ptr, ptr %l0, !tbaa !29
  %t622 = load %"compiler/source:Span", ptr %l1
  %t623 = load i64, ptr %l9, !tbaa !24
  %t627 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t621, %"compiler/source:Span" %t622, i64 %t623)
  store ptr %t627, ptr %l329
  br label %bb87
bb87:
  %t628 = load ptr, ptr %l0, !tbaa !29
  store ptr %t628, ptr %l330, !tbaa !29
  %t629 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t629, ptr %l331
  %t630 = load ptr, ptr %l0, !tbaa !29
  %t632 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t630)
  store i32 %t632, ptr %l333
  br label %bb88
bb88:
  %t633 = load ptr, ptr %l330, !tbaa !29
  %t634 = load %"compiler/source:Span", ptr %l331
  %t635 = load i32, ptr %l333, !tbaa !23
  %t636 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t633, %"compiler/source:Span" %t634, i32 %t635, i64 1)
  store ptr %t636, ptr %l334
  br label %bb89
bb89:
  %t637 = load ptr, ptr %l334, !tbaa !29
  %t638 = load ptr, ptr %l321, !tbaa !29
  %t639 = load %"compiler/source:Span", ptr %l322
  %t640 = load i32, ptr %l324, !tbaa !23
  %t641 = load i32, ptr %l325
  %t642 = load ptr, ptr %l329, !tbaa !29
  %t644 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t638, %"compiler/source:Span" %t639, i32 %t640, i32 %t641, ptr %t642, ptr %t637)
  store ptr %t644, ptr %l336
  br label %bb90
bb90:
  store { i64, [3 x i64] } zeroinitializer, ptr %t645
  %t646 = getelementptr { i64, [3 x i64] }, ptr %t645, i32 0, i32 0
  store i64 1, ptr %t646
  %t647 = load %"compiler/source:Span", ptr %l312
  %t648 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t647, 0
  %t649 = load ptr, ptr %l320, !tbaa !29
  %t650 = insertvalue { %"compiler/source:Span", ptr, ptr } %t648, ptr %t649, 1
  %t651 = load ptr, ptr %l336, !tbaa !29
  %t652 = insertvalue { %"compiler/source:Span", ptr, ptr } %t650, ptr %t651, 2
  %t653 = getelementptr { i64, [3 x i64] }, ptr %t645, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t652, ptr %t653
  %t654 = load { i64, [3 x i64] }, ptr %t645
  %t656 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t654, ptr %t656
  %t657 = load ptr, ptr %l311, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t657, ptr %t656)
  br label %bb91
bb91:
  br label %bb92
bb92:
  %t659 = load ptr, ptr %l0, !tbaa !29
  %t660 = load i64, ptr %l31, !tbaa !24
  %t661 = load i64, ptr %l32, !tbaa !24
  %t662 = load i64, ptr %l33, !tbaa !24
  %t663 = load i64, ptr %l29, !tbaa !24
  %t669 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t659, i64 %t660, i64 %t661, i64 %t662, i64 %t663)
  store ptr %t669, ptr %l344
  br label %bb93
bb93:
  %t670 = load ptr, ptr %l344, !tbaa !29
  %t671 = load ptr, ptr %l0, !tbaa !29
  %t672 = load %"compiler/source:Span", ptr %l1
  %t673 = load ptr, ptr %l28, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t676
  %t677 = getelementptr { i64, [3 x i64] }, ptr %t676, i32 0, i32 0
  store i64 4, ptr %t677
  %t679 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t672, 0
  %t681 = insertvalue { %"compiler/source:Span", ptr, ptr } %t679, ptr %t673, 1
  %t683 = insertvalue { %"compiler/source:Span", ptr, ptr } %t681, ptr %t670, 2
  %t684 = getelementptr { i64, [3 x i64] }, ptr %t676, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t683, ptr %t684
  %t685 = load { i64, [3 x i64] }, ptr %t676
  %t687 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t685, ptr %t687
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t671, ptr %t687)
  br label %bb94
bb94:
  %t690 = load ptr, ptr %l0, !tbaa !29
  store ptr %t690, ptr %l352, !tbaa !29
  %t691 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t691, ptr %l353
  %t692 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t692, ptr %l354
  %t693 = load ptr, ptr %l0, !tbaa !29
  %t695 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t693)
  store i32 %t695, ptr %l356
  br label %bb95
bb95:
  %t696 = load i64, ptr %l8, !tbaa !24
  %t698 = trunc i64 %t696 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t700
  %t701 = getelementptr { i64, [4 x i64] }, ptr %t700, i32 0, i32 0
  store i64 0, ptr %t701
  %t702 = load %"compiler/source:Span", ptr %l354
  %t703 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t702, 0
  %t704 = load i32, ptr %l356, !tbaa !23
  %t705 = insertvalue { %"compiler/source:Span", i32, i32 } %t703, i32 %t704, 1
  %t707 = insertvalue { %"compiler/source:Span", i32, i32 } %t705, i32 %t698, 2
  %t708 = getelementptr { i64, [4 x i64] }, ptr %t700, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t707, ptr %t708
  %t709 = load { i64, [4 x i64] }, ptr %t700
  %t711 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t709, ptr %t711
  store ptr %t711, ptr %l361, !tbaa !29
  %t712 = load ptr, ptr %l0, !tbaa !29
  store ptr %t712, ptr %l362, !tbaa !29
  %t713 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t713, ptr %l363
  %t714 = load ptr, ptr %l0, !tbaa !29
  %t716 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t714)
  store i32 %t716, ptr %l365
  br label %bb96
bb96:
  store i32 3, ptr %l366
  %t717 = load ptr, ptr %l0, !tbaa !29
  %t718 = load %"compiler/source:Span", ptr %l1
  %t719 = load i64, ptr %l8, !tbaa !24
  %t723 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t717, %"compiler/source:Span" %t718, i64 %t719)
  store ptr %t723, ptr %l370
  br label %bb97
bb97:
  %t724 = load ptr, ptr %l0, !tbaa !29
  %t725 = load %"compiler/source:Span", ptr %l1
  %t726 = load i64, ptr %l18, !tbaa !24
  %t730 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t724, %"compiler/source:Span" %t725, i64 %t726)
  store ptr %t730, ptr %l374
  br label %bb98
bb98:
  %t731 = load ptr, ptr %l374, !tbaa !29
  %t732 = load ptr, ptr %l362, !tbaa !29
  %t733 = load %"compiler/source:Span", ptr %l363
  %t734 = load i32, ptr %l365, !tbaa !23
  %t735 = load i32, ptr %l366
  %t736 = load ptr, ptr %l370, !tbaa !29
  %t738 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t732, %"compiler/source:Span" %t733, i32 %t734, i32 %t735, ptr %t736, ptr %t731)
  store ptr %t738, ptr %l376
  br label %bb99
bb99:
  store { i64, [3 x i64] } zeroinitializer, ptr %t739
  %t740 = getelementptr { i64, [3 x i64] }, ptr %t739, i32 0, i32 0
  store i64 1, ptr %t740
  %t741 = load %"compiler/source:Span", ptr %l353
  %t742 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t741, 0
  %t743 = load ptr, ptr %l361, !tbaa !29
  %t744 = insertvalue { %"compiler/source:Span", ptr, ptr } %t742, ptr %t743, 1
  %t745 = load ptr, ptr %l376, !tbaa !29
  %t746 = insertvalue { %"compiler/source:Span", ptr, ptr } %t744, ptr %t745, 2
  %t747 = getelementptr { i64, [3 x i64] }, ptr %t739, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t746, ptr %t747
  %t748 = load { i64, [3 x i64] }, ptr %t739
  %t750 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t748, ptr %t750
  %t751 = load ptr, ptr %l352, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t751, ptr %t750)
  br label %bb100
bb100:
  %t753 = load ptr, ptr %l0, !tbaa !29
  %t754 = load i64, ptr %l12, !tbaa !24
  %t755 = load i64, ptr %l13, !tbaa !24
  %t756 = load i64, ptr %l14, !tbaa !24
  %t757 = load i64, ptr %l10, !tbaa !24
  %t763 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t753, i64 %t754, i64 %t755, i64 %t756, i64 %t757)
  store ptr %t763, ptr %l384
  br label %bb101
bb101:
  %t764 = load ptr, ptr %l384, !tbaa !29
  %t765 = load ptr, ptr %l0, !tbaa !29
  %t766 = load %"compiler/source:Span", ptr %l1
  store { i64, [3 x i64] } zeroinitializer, ptr %t768
  %t769 = getelementptr { i64, [3 x i64] }, ptr %t768, i32 0, i32 0
  store i64 4, ptr %t769
  %t771 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t766, 0
  %t773 = insertvalue { %"compiler/source:Span", ptr, ptr } %t771, ptr %t764, 1
  %t774 = insertvalue { %"compiler/source:Span", ptr, ptr } %t773, ptr null, 2
  %t775 = getelementptr { i64, [3 x i64] }, ptr %t768, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t774, ptr %t775
  %t776 = load { i64, [3 x i64] }, ptr %t768
  %t778 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t776, ptr %t778
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t765, ptr %t778)
  br label %bb102
bb102:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewholeNarrowed(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/check:narrowed"
  %l10 = alloca ptr
  %l12 = alloca ptr
  %l15 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l41 = alloca ptr
  %l44 = alloca i64
  %l48 = alloca %"compiler/check:narrowed"
  %l53 = alloca ptr
  %l58 = alloca i32
  %l59 = alloca ptr
  %l61 = alloca ptr
  %l64 = alloca i1
  %l72 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l12
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l12, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 43
  %t9 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anarrowed_3e_2eLe_H3e76598dd6b4a90eb80e3d16fe1b70d0(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l15
  br label %bb2
bb2:
  %t10 = load i64, ptr %l15, !tbaa !24
  store i64 %t10, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp sgt i64 %t11, %t12
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load i64, ptr %l5, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb8
bb5:
  %t21 = load i64, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = sub i64 %t21, %t22
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = add i64 %t25, %t26
  %t31 = sub i64 %t29, 1
  %t32 = load i64, ptr %l5, !tbaa !24
  %t35 = sdiv i64 %t31, %t32
  store i64 %t35, ptr %l22, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t37 = load i64, ptr %l22, !tbaa !24
  store i64 %t37, ptr %l19, !tbaa !24
  br label %bb8
bb8:
  %t38 = load i64, ptr %l19, !tbaa !24
  store i64 %t38, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t39 = load i64, ptr %l7, !tbaa !24
  %t40 = load i64, ptr %l6, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb11:
  br label %bb12
bb12:
  %t47 = load i64, ptr %l3, !tbaa !24
  %t48 = load i64, ptr %l7, !tbaa !24
  %t49 = load i64, ptr %l5, !tbaa !24
  %t52 = mul i64 %t48, %t49
  %t55 = add i64 %t47, %t52
  store i64 %t55, ptr %l8, !tbaa !24
  %t57 = load ptr, ptr %l2, !tbaa !29
  %t59 = getelementptr %"compiler/check:frame", ptr %t57, i32 0, i32 43
  store ptr %t59, ptr %l41, !tbaa !29
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t62 = getelementptr %"compiler/check:frame", ptr %t60, i32 0, i32 43
  %t64 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anarrowed_3e_2eLe_H3e76598dd6b4a90eb80e3d16fe1b70d0(ptr %v0, ptr %t62)
  store i64 %t64, ptr %l44
  br label %bb13
bb13:
  %t65 = load i64, ptr %l44, !tbaa !24
  %t66 = sub i64 %t65, 1
  %t67 = load i64, ptr %l8, !tbaa !24
  %t70 = sub i64 %t66, %t67
  %t71 = load ptr, ptr %l41, !tbaa !29
  %t73 = call %"compiler/check:narrowed" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anarrowed_3e_2eAt_H313390349c5d53629478ea446134cf40(ptr %v0, ptr %t71, i64 %t70)
  store %"compiler/check:narrowed" %t73, ptr %l48
  br label %bb14
bb14:
  %t74 = load %"compiler/check:narrowed", ptr %l48
  store %"compiler/check:narrowed" %t74, ptr %l9
  %t75 = getelementptr %"compiler/check:narrowed", ptr %l9, i32 0, i32 0
  %t76 = load i64, ptr %t75, !tbaa !24
  %t80 = icmp ne i64 %t76, %a1
  br i1 %t80, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb16:
  br label %bb17
bb17:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  store ptr %t85, ptr %l53, !tbaa !29
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr %"compiler/generic:Program", ptr %t89, i32 0, i32 2
  %t92 = getelementptr %"compiler/check:narrowed", ptr %l9, i32 0, i32 2
  %t93 = load i32, ptr %t92, !tbaa !23
  %t96 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t91, i32 %t93)
  store i32 %t96, ptr %l58
  br label %bb18
bb18:
  %t97 = load ptr, ptr %l53, !tbaa !29
  %t98 = load i32, ptr %l58, !tbaa !23
  %t99 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t97, i32 %t98)
  store ptr %t99, ptr %l59
  br label %bb19
bb19:
  %t100 = getelementptr %"compiler/check:narrowed", ptr %l9, i32 0, i32 1
  %t101 = load i64, ptr %t100, !tbaa !24
  %t102 = load ptr, ptr %l59, !tbaa !29
  %t104 = call ptr @compiler_2fcheck_2ecaseDecl(ptr %v0, ptr %t102, i64 %t101)
  store ptr %t104, ptr %l61
  br label %bb20
bb20:
  %t105 = load ptr, ptr %l61, !tbaa !29
  store ptr %t105, ptr %l10, !tbaa !29
  %t106 = load ptr, ptr %l10, !tbaa !29
  %t108 = icmp eq ptr %t106, null
  br i1 %t108, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l64, !tbaa !21
  br label %bb23
bb22:
  %t110 = load ptr, ptr %l10, !tbaa !29
  %t112 = getelementptr %"compiler/ast:CaseDecl", ptr %t110, i32 0, i32 3
  %t113 = load i1, ptr %t112, !tbaa !21
  %t115 = xor i1 %t113, true
  store i1 %t115, ptr %l64, !tbaa !21
  br label %bb23
bb23:
  %t117 = load i1, ptr %l64, !tbaa !21
  br i1 %t117, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s2)
  store i64 -1, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t119 = load ptr, ptr %l2, !tbaa !29
  %t121 = getelementptr %"compiler/check:frame", ptr %t119, i32 0, i32 44
  %t122 = getelementptr %"compiler/check:narrowed", ptr %l9, i32 0, i32 3
  %t123 = load i64, ptr %t122, !tbaa !24
  %t126 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t121, i64 %t123)
  store i64 %t126, ptr %l72
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s2)
  %t127 = load i64, ptr %l72, !tbaa !24
  store i64 %t127, ptr %rv
  br label %ret
bb28:
  %t128 = load i64, ptr %l7, !tbaa !24
  %t130 = add i64 %t128, 1
  store i64 %t130, ptr %l7, !tbaa !24
  br label %bb9
bb29:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewithin(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l9 = alloca i1
  %l11 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l21 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l32 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l43 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t7 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esamePlace(ptr %v0, ptr %v1, ptr %v2, ptr %t1, ptr %t2, ptr %t3)
  store i1 %t7, ptr %l9
  br label %bb1
bb1:
  %t8 = load i1, ptr %l9, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t11 = load ptr, ptr %l12, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l12, !tbaa !29
  %t15 = load i64, ptr %t14
  %t17 = icmp eq i64 %t15, 3
  store i1 %t17, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l13, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l3, !tbaa !29
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t31 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewithin(ptr %v0, ptr %v1, ptr %v2, ptr %t25, ptr %t26, ptr %t27)
  store i1 %t31, ptr %l21
  br label %bb10
bb10:
  %t32 = load i1, ptr %l21, !tbaa !21
  store i1 %t32, ptr %l11, !tbaa !21
  br label %bb30
bb11:
  %t33 = load ptr, ptr %l1, !tbaa !29
  store ptr %t33, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t34 = load ptr, ptr %l22, !tbaa !29
  %t35 = icmp ne ptr %t34, null
  br i1 %t35, label %bb12, label %bb13
bb12:
  %t37 = load ptr, ptr %l22, !tbaa !29
  %t38 = load i64, ptr %t37
  %t40 = icmp eq i64 %t38, 4
  store i1 %t40, ptr %l23, !tbaa !21
  br label %bb13
bb13:
  %t41 = load i1, ptr %l23, !tbaa !21
  br i1 %t41, label %bb14, label %bb15
bb14:
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = getelementptr { i64, [4 x i64] }, ptr %t42, i32 0, i32 1
  %t45 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t44, i32 0, i32 2
  %t46 = load ptr, ptr %t45
  store ptr %t46, ptr %l4, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load ptr, ptr %l4, !tbaa !29
  %t51 = getelementptr %"compiler/typed:Elem", ptr %t49, i32 0, i32 0
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t57 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewithin(ptr %v0, ptr %v1, ptr %v2, ptr %t48, ptr %t52, ptr %t53)
  store i1 %t57, ptr %l32
  br label %bb17
bb17:
  %t58 = load i1, ptr %l32, !tbaa !21
  store i1 %t58, ptr %l11, !tbaa !21
  br label %bb30
bb18:
  %t59 = load ptr, ptr %l1, !tbaa !29
  store ptr %t59, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t60 = load ptr, ptr %l33, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb19, label %bb20
bb19:
  %t63 = load ptr, ptr %l33, !tbaa !29
  %t64 = load i64, ptr %t63
  %t66 = icmp eq i64 %t64, 5
  store i1 %t66, ptr %l34, !tbaa !21
  br label %bb20
bb20:
  %t67 = load i1, ptr %l34, !tbaa !21
  br i1 %t67, label %bb21, label %bb22
bb21:
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [4 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t70, i32 0, i32 2
  %t72 = load ptr, ptr %t71
  store ptr %t72, ptr %l5, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load ptr, ptr %l5, !tbaa !29
  %t77 = getelementptr %"compiler/typed:Payload", ptr %t75, i32 0, i32 0
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t83 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewithin(ptr %v0, ptr %v1, ptr %v2, ptr %t74, ptr %t78, ptr %t79)
  store i1 %t83, ptr %l43
  br label %bb24
bb24:
  %t84 = load i1, ptr %l43, !tbaa !21
  store i1 %t84, ptr %l11, !tbaa !21
  br label %bb30
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_e1df209ea46513ba_c2fba828617e051e)
  unreachable
bb30:
  %t85 = load i1, ptr %l11, !tbaa !21
  store i1 %t85, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_2efloatLit(double %a0) #0 {
entry:
  %l2 = alloca %"compiler/check:litv"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/check:litv"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %s0, i1 true, i1 true, i1 false, i64 0, double %a0)
  store %"compiler/check:litv" %t3, ptr %l2
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t4 = load %"compiler/check:litv", ptr %l2
  store %"compiler/check:litv" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local i1 @compiler_2fcheck_2elastIsValue(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %l16 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l3, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t2, 0
  %t6 = sub i64 %t4, 1
  %t8 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr ptr, ptr %t9, i64 %t6
  %t11 = load ptr, ptr %t10, !tbaa !39
  store ptr %t11, ptr %l1, !tbaa !29
  %t13 = load ptr, ptr %l1, !tbaa !29
  store ptr %t13, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t14 = load ptr, ptr %l9, !tbaa !29
  %t15 = icmp ne ptr %t14, null
  br i1 %t15, label %bb1, label %bb2
bb1:
  %t17 = load ptr, ptr %l9, !tbaa !29
  %t18 = load i64, ptr %t17
  %t20 = icmp eq i64 %t18, 0
  store i1 %t20, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t21 = load i1, ptr %l10, !tbaa !21
  br i1 %t21, label %bb3, label %bb4
bb3:
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", ptr }, ptr %t24, i32 0, i32 1
  %t26 = load ptr, ptr %t25
  store ptr %t26, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = call i1 @compiler_2fcheck_2estmtLike(ptr %v0, ptr %t28)
  store i1 %t30, ptr %l16
  br label %bb6
bb6:
  %t31 = load i1, ptr %l16, !tbaa !21
  %t32 = xor i1 %t31, true
  store i1 %t32, ptr %l8, !tbaa !21
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_696a437f6b67e70a_247b6a7ce30931f6)
  unreachable
bb12:
  %t34 = load i1, ptr %l8, !tbaa !21
  store i1 %t34, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l16 = alloca { i64, ptr }
  %l20 = alloca i1
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Block", ptr %t6, i32 0, i32 1
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t15 = load i64, ptr %l2, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t23, ptr %l16, !tbaa !27
  %t24 = load i64, ptr %l2, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr ptr, ptr %t27, i64 %t24
  %t29 = load ptr, ptr %t28, !tbaa !39
  %t33 = call i1 @compiler_2fcheck_2eleaves(ptr %v0, ptr %t29)
  store i1 %t33, ptr %l20
  br label %bb8
bb8:
  %t34 = load i1, ptr %l20, !tbaa !21
  br i1 %t34, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  %t36 = load i64, ptr %l2, !tbaa !24
  %t38 = add i64 %t36, 1
  store i64 %t38, ptr %l2, !tbaa !24
  br label %bb4
bb13:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eleavesValue(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l7 = alloca i1
  %l17 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l21 = alloca i1
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t1)
  store i1 %t4, ptr %l7
  br label %bb1
bb1:
  %t5 = load i1, ptr %l7, !tbaa !21
  br i1 %t5, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/typed:Block", ptr %t7, i32 0, i32 1
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  store { i64, ptr } %t10, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l3, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t16 = load i64, ptr %l2, !tbaa !24
  %t17 = load i64, ptr %l3, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb7:
  br label %bb8
bb8:
  %t24 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t24, ptr %l17, !tbaa !27
  %t25 = load i64, ptr %l2, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr ptr, ptr %t28, i64 %t25
  %t30 = load ptr, ptr %t29, !tbaa !39
  store ptr %t30, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t33 = load ptr, ptr %l20, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t36 = load ptr, ptr %l20, !tbaa !29
  %t37 = load i64, ptr %t36
  %t39 = icmp eq i64 %t37, 5
  store i1 %t39, ptr %l21, !tbaa !21
  br label %bb10
bb10:
  %t40 = load i1, ptr %l21, !tbaa !21
  br i1 %t40, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  %t42 = load i64, ptr %l2, !tbaa !24
  %t44 = add i64 %t42, 1
  store i64 %t44, ptr %l2, !tbaa !24
  br label %bb5
bb17:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2eliteralOrder_2einit() #0 {
entry:
  %l0 = alloca [12 x { i64, ptr }]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 0
  store { i64, ptr } { i64 3, ptr @.d55 }, ptr %t1, !tbaa !37
  %t2 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 1
  store { i64, ptr } { i64 3, ptr @.d56 }, ptr %t2, !tbaa !37
  %t3 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 2
  store { i64, ptr } { i64 3, ptr @.d57 }, ptr %t3, !tbaa !37
  %t4 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 3
  store { i64, ptr } { i64 3, ptr @.d58 }, ptr %t4, !tbaa !37
  %t5 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 4
  store { i64, ptr } { i64 3, ptr @.d59 }, ptr %t5, !tbaa !37
  %t6 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 5
  store { i64, ptr } { i64 3, ptr @.d60 }, ptr %t6, !tbaa !37
  %t7 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 6
  store { i64, ptr } { i64 3, ptr @.d61 }, ptr %t7, !tbaa !37
  %t8 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 7
  store { i64, ptr } { i64 4, ptr @.d62 }, ptr %t8, !tbaa !37
  %t9 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 8
  store { i64, ptr } { i64 3, ptr @.d63 }, ptr %t9, !tbaa !37
  %t10 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 9
  store { i64, ptr } { i64 3, ptr @.d64 }, ptr %t10, !tbaa !37
  %t11 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 10
  store { i64, ptr } { i64 2, ptr @.d65 }, ptr %t11, !tbaa !37
  %t12 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 11
  store { i64, ptr } { i64 2, ptr @.d66 }, ptr %t12, !tbaa !37
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2fcheck_2eliteralOrder, ptr %l0, i64 192, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %v0, i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0
  %t3 = trunc i64 49 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 4, ptr @.d67 }, ptr %l1, !tbaa !27
  br label %bb59
bb4:
  %t6 = load i32, ptr %l0
  %t8 = trunc i64 50 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store { i64, ptr } { i64 5, ptr @.d68 }, ptr %l1, !tbaa !27
  br label %bb59
bb8:
  %t11 = load i32, ptr %l0
  %t13 = trunc i64 51 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 3, ptr @.d69 }, ptr %l1, !tbaa !27
  br label %bb59
bb12:
  %t16 = load i32, ptr %l0
  %t18 = trunc i64 52 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 3, ptr @.d70 }, ptr %l1, !tbaa !27
  br label %bb59
bb16:
  %t21 = load i32, ptr %l0
  %t23 = trunc i64 53 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store { i64, ptr } { i64 3, ptr @.d71 }, ptr %l1, !tbaa !27
  br label %bb59
bb20:
  %t26 = load i32, ptr %l0
  %t28 = trunc i64 54 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store { i64, ptr } { i64 6, ptr @.d72 }, ptr %l1, !tbaa !27
  br label %bb59
bb24:
  %t31 = load i32, ptr %l0
  %t33 = trunc i64 77 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb25, label %bb26
bb25:
  br label %bb33
bb26:
  %t36 = load i32, ptr %l0
  %t38 = trunc i64 79 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb27, label %bb28
bb27:
  br label %bb33
bb28:
  %t41 = load i32, ptr %l0
  %t43 = trunc i64 78 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb29, label %bb30
bb29:
  br label %bb33
bb30:
  %t46 = load i32, ptr %l0
  %t48 = trunc i64 80 to i32
  %t49 = icmp eq i32 %t46, %t48
  br i1 %t49, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  store { i64, ptr } { i64 4, ptr @.d73 }, ptr %l1, !tbaa !27
  br label %bb59
bb34:
  %t51 = load i32, ptr %l0
  %t53 = trunc i64 81 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  store { i64, ptr } { i64 6, ptr @.d74 }, ptr %l1, !tbaa !27
  br label %bb59
bb38:
  %t56 = load i32, ptr %l0
  %t58 = trunc i64 82 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  store { i64, ptr } { i64 5, ptr @.d75 }, ptr %l1, !tbaa !27
  br label %bb59
bb42:
  %t61 = load i32, ptr %l0
  %t63 = trunc i64 83 to i32
  %t64 = icmp eq i32 %t61, %t63
  br i1 %t64, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  store { i64, ptr } { i64 6, ptr @.d76 }, ptr %l1, !tbaa !27
  br label %bb59
bb46:
  %t66 = load i32, ptr %l0
  %t68 = trunc i64 86 to i32
  %t69 = icmp eq i32 %t66, %t68
  br i1 %t69, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  store { i64, ptr } { i64 9, ptr @.d77 }, ptr %l1, !tbaa !27
  br label %bb59
bb50:
  %t71 = load i32, ptr %l0
  %t73 = trunc i64 87 to i32
  %t74 = icmp eq i32 %t71, %t73
  br i1 %t74, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  store { i64, ptr } { i64 10, ptr @.d78 }, ptr %l1, !tbaa !27
  br label %bb59
bb54:
  br i1 true, label %bb55, label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb58
bb57:
  store { i64, ptr } { i64 0, ptr @.d79 }, ptr %l1, !tbaa !27
  br label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_445c35e7b454dfb2_9156676d88e8071e)
  unreachable
bb59:
  %t76 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t76, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2epatRow(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aPattern_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l2
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l2
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %t3
  store ptr %t3, ptr %l1, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aPattern_26_3e_2ePu_H50118fa117031f41a126a195286f9d97(ptr %v0, ptr %v0, ptr %t5, ptr %a0)
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aPattern_26_3e_2eTo_H10e4dc538dd932dd9b3885c00bcf8105(ptr %v0, ptr %v0, ptr %t9)
  store { i64, ptr } %t11, ptr %l7
  br label %bb3
bb3:
  %t12 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t12, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2eprimName(ptr %v0, i32 %a0) #0 {
entry:
  %l1 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = sext i32 %a0 to i64
  store i64 %t3, ptr %l1, !tbaa !24
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = icmp eq i64 %t5, 3
  br i1 %t7, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 2, ptr @.d80 }, ptr %l4, !tbaa !27
  br label %bb53
bb4:
  %t9 = load i64, ptr %l1, !tbaa !24
  %t11 = icmp eq i64 %t9, 4
  br i1 %t11, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store { i64, ptr } { i64 3, ptr @.d81 }, ptr %l4, !tbaa !27
  br label %bb53
bb8:
  %t13 = load i64, ptr %l1, !tbaa !24
  %t15 = icmp eq i64 %t13, 5
  br i1 %t15, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 3, ptr @.d82 }, ptr %l4, !tbaa !27
  br label %bb53
bb12:
  %t17 = load i64, ptr %l1, !tbaa !24
  %t19 = icmp eq i64 %t17, 6
  br i1 %t19, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 3, ptr @.d83 }, ptr %l4, !tbaa !27
  br label %bb53
bb16:
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = icmp eq i64 %t21, 7
  br i1 %t23, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store { i64, ptr } { i64 2, ptr @.d84 }, ptr %l4, !tbaa !27
  br label %bb53
bb20:
  %t25 = load i64, ptr %l1, !tbaa !24
  %t27 = icmp eq i64 %t25, 8
  br i1 %t27, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store { i64, ptr } { i64 3, ptr @.d85 }, ptr %l4, !tbaa !27
  br label %bb53
bb24:
  %t29 = load i64, ptr %l1, !tbaa !24
  %t31 = icmp eq i64 %t29, 9
  br i1 %t31, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store { i64, ptr } { i64 3, ptr @.d86 }, ptr %l4, !tbaa !27
  br label %bb53
bb28:
  %t33 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp eq i64 %t33, 10
  br i1 %t35, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store { i64, ptr } { i64 3, ptr @.d87 }, ptr %l4, !tbaa !27
  br label %bb53
bb32:
  %t37 = load i64, ptr %l1, !tbaa !24
  %t39 = icmp eq i64 %t37, 11
  br i1 %t39, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store { i64, ptr } { i64 3, ptr @.d88 }, ptr %l4, !tbaa !27
  br label %bb53
bb36:
  %t41 = load i64, ptr %l1, !tbaa !24
  %t43 = icmp eq i64 %t41, 12
  br i1 %t43, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  store { i64, ptr } { i64 4, ptr @.d89 }, ptr %l4, !tbaa !27
  br label %bb53
bb40:
  %t45 = load i64, ptr %l1, !tbaa !24
  %t47 = icmp eq i64 %t45, 13
  br i1 %t47, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  store { i64, ptr } { i64 3, ptr @.d90 }, ptr %l4, !tbaa !27
  br label %bb53
bb44:
  %t49 = load i64, ptr %l1, !tbaa !24
  %t51 = icmp eq i64 %t49, 14
  br i1 %t51, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  store { i64, ptr } { i64 3, ptr @.d91 }, ptr %l4, !tbaa !27
  br label %bb53
bb48:
  br i1 true, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  store { i64, ptr } { i64 1, ptr @.d92 }, ptr %l4, !tbaa !27
  br label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_25d55d46e6c695b2_1c5feb2a345583d6)
  unreachable
bb53:
  %t53 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t53, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcheck_2estoredExprs(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l16 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t21, ptr %l16, !tbaa !27
  %t22 = load i64, ptr %l3, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr ptr, ptr %t25, i64 %t22
  %t27 = load ptr, ptr %t26, !tbaa !39
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t27, ptr %a1)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb9
bb9:
  %t34 = load i64, ptr %l3, !tbaa !24
  %t36 = add i64 %t34, 1
  store i64 %t36, ptr %l3, !tbaa !24
  br label %bb4
bb10:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2eunpromoted(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Promote", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  store ptr %t19, ptr %rv
  br label %ret
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ewrittenMut(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 4
  store i1 %t13, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l7, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t17, i32 0, i32 2
  %t19 = load i1, ptr %t18
  store i1 %t19, ptr %l1, !tbaa !21
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t21 = load i1, ptr %l1, !tbaa !21
  store i1 %t21, ptr %l5, !tbaa !21
  br label %bb14
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_dd9051e7d89be652_5717c5df078d4726)
  unreachable
bb14:
  %t23 = load i1, ptr %l5, !tbaa !21
  store i1 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/check:Gap" @compiler_2fcheck_3aGap_2ector(ptr %v0, ptr %v1, i64 %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %rv = alloca %"compiler/check:Gap"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/check:Gap" undef, i64 %a0, 0
  %t10 = insertvalue %"compiler/check:Gap" %t8, %"compiler/source:Span" %a1, 1
  %t12 = insertvalue %"compiler/check:Gap" %t10, { i64, ptr } %a2, 2
  store %"compiler/check:Gap" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:Gap", ptr %rv
  ret %"compiler/check:Gap" %rr
}

define dso_local void @olang_2einit_2ecompiler_2fcheck() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fcheck_2eOpShapes_2einit()
  br label %bb1
bb1:
  call void @compiler_2fcheck_2eBounds_2einit()
  br label %bb2
bb2:
  call void @compiler_2fcheck_2eDivideByZero_2einit()
  br label %bb3
bb3:
  call void @compiler_2fcheck_2eOverflow_2einit()
  br label %bb4
bb4:
  call void @compiler_2fcheck_2eInvalid_2einit()
  br label %bb5
bb5:
  call void @compiler_2fcheck_2eWrongCase_2einit()
  br label %bb6
bb6:
  call void @compiler_2fcheck_2eRoStored_2einit()
  br label %bb7
bb7:
  call void @compiler_2fcheck_2eRoDecl_2einit()
  br label %bb8
bb8:
  call void @compiler_2fcheck_2eRoReturned_2einit()
  br label %bb9
bb9:
  call void @compiler_2fcheck_2eRoGlobal_2einit()
  br label %bb10
bb10:
  call void @compiler_2fcheck_2eliteralOrder_2einit()
  br label %bb11
bb11:
  br label %ret
ret:
  ret void
}

@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d0 = private constant [4 x i8] c"Plus"
@.d1 = private constant [5 x i8] c"Minus"
@.d2 = private constant [3 x i8] c"Mul"
@.d3 = private constant [3 x i8] c"Div"
@.d4 = private constant [3 x i8] c"Rem"
@.d5 = private constant [6 x i8] c"MatMul"
@.d6 = private constant [3 x i8] c"Neg"
@.d7 = private constant [4 x i8] c"Less"
@.d8 = private constant [2 x i8] c"At"
@.d9 = private constant [5 x i8] c"SetAt"
@.d10 = private constant [5 x i8] c"Slice"
@.d11 = private constant [6 x i8] c"BitAnd"
@.d12 = private constant [5 x i8] c"BitOr"
@.d13 = private constant [6 x i8] c"BitXor"
@.d14 = private constant [9 x i8] c"ShiftLeft"
@.d15 = private constant [10 x i8] c"ShiftRight"
@.d16 = private constant [6 x i8] c"BitNot"
@.d17 = private constant [3 x i8] c"Inc"
@.d18 = private constant [3 x i8] c"Dec"
@.d19 = private constant [3 x i8] c"Len"
@.d20 = private constant [2 x i8] c"Eq"
@.d21 = private constant [3 x i8] c"Str"
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d22 = private constant [1 x i8] c"("
@.d23 = private constant [1 x i8] c")"
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr)
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d24 = private constant [3 x i8] c"Str"
@.d25 = private constant [3 x i8] c"str"
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d26 = private constant [0 x i8] c""
@.d27 = private constant [26 x i8] c"a type of this kind called"
@.d28 = private constant [9 x i8] c"CheckedAt"
@.d29 = private constant [9 x i8] c"CheckedAt"
@.d30 = private constant [3 x i8] c"Len"
@.d31 = private constant [2 x i8] c"Eq"
@.d32 = private constant [2 x i8] c"eq"
@.d33 = private constant [35 x i8] c"an extern function as a value (T21)"
@.d34 = private constant [1 x i8] c"'"
@.d35 = private constant [1 x i8] c"'"
@.d36 = private constant [1 x i8] c"_"
@.d37 = private constant [0 x i8] c""
@.d38 = private constant [8 x i8] c"a lambda"
@.d39 = private constant [0 x i8] c""
@.d40 = private constant [1 x i8] c"s"
@.d41 = private constant [74 x i8] c"a lambda parameter written as a reference where a value is expected (D16a)"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d42 = private constant [11 x i8] c"this lambda"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d43 = private constant [13 x i8] c"no parameters"
@.d44 = private constant [13 x i8] c"one parameter"
declare i64 @__olang_fmt_i64(ptr, i64)
@.d45 = private constant [11 x i8] c" parameters"
@.d46 = private constant [3 x i8] c"one"
@.d47 = private constant [4 x i8] c"none"
@.d48 = private constant [9 x i8] c"at least "
@.d49 = private constant [0 x i8] c""
@.d50 = private constant [1 x i8] c"/"
@.d51 = private constant [1 x i8] c"."
@.d52 = private constant [0 x i8] c""
@.d53 = private constant [3 x i8] c"Str"
@.d54 = private constant [3 x i8] c"str"
@.d55 = private constant [3 x i8] c"F64"
@.d56 = private constant [3 x i8] c"I64"
@.d57 = private constant [3 x i8] c"U64"
@.d58 = private constant [3 x i8] c"F32"
@.d59 = private constant [3 x i8] c"I32"
@.d60 = private constant [3 x i8] c"U32"
@.d61 = private constant [3 x i8] c"F16"
@.d62 = private constant [4 x i8] c"BF16"
@.d63 = private constant [3 x i8] c"I16"
@.d64 = private constant [3 x i8] c"U16"
@.d65 = private constant [2 x i8] c"I8"
@.d66 = private constant [2 x i8] c"U8"
@.d67 = private constant [4 x i8] c"Plus"
@.d68 = private constant [5 x i8] c"Minus"
@.d69 = private constant [3 x i8] c"Mul"
@.d70 = private constant [3 x i8] c"Div"
@.d71 = private constant [3 x i8] c"Rem"
@.d72 = private constant [6 x i8] c"MatMul"
@.d73 = private constant [4 x i8] c"Less"
@.d74 = private constant [6 x i8] c"BitAnd"
@.d75 = private constant [5 x i8] c"BitOr"
@.d76 = private constant [6 x i8] c"BitXor"
@.d77 = private constant [9 x i8] c"ShiftLeft"
@.d78 = private constant [10 x i8] c"ShiftRight"
@.d79 = private constant [0 x i8] c""
@.d80 = private constant [2 x i8] c"I8"
@.d81 = private constant [3 x i8] c"I16"
@.d82 = private constant [3 x i8] c"I32"
@.d83 = private constant [3 x i8] c"I64"
@.d84 = private constant [2 x i8] c"U8"
@.d85 = private constant [3 x i8] c"U16"
@.d86 = private constant [3 x i8] c"U32"
@.d87 = private constant [3 x i8] c"U64"
@.d88 = private constant [3 x i8] c"F16"
@.d89 = private constant [4 x i8] c"BF16"
@.d90 = private constant [3 x i8] c"F32"
@.d91 = private constant [3 x i8] c"F64"
@.d92 = private constant [1 x i8] c"?"
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i1 %a2, i1 %a3)
@G_2ecompiler_2fcheck_2eOpShapes = external constant <{ [8 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [16 x i8] }>
declare i1 @compiler_2fcheck_2estmtAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_a6ae1e9a693d05c9_888d1f7981f90365 = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eExprBodyIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, i64 %a2, { i64, ptr } %a3, { i64, ptr } %a4, ptr %a5, i32 %a6)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aGlobal(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i32 %a3, i32 %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
@olang_loc_b2a10b57ca8f7dfa_ebdfac3cc9f6695e = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_Hb3133f486435530b533aaf49461c92b5(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H64d9be73b6c9bed004c541bdf7f0ca0a(ptr %v0, ptr %a0, i32 %a1, i1 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStrBody(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aFn(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_6eddca2d598ce6fb_9d8bffc2796cf667 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_f64a0f855cc2648c_4038adf1240cd248 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eReopen(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eblockOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2, %"compiler/source:Span" %a3)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_Hbcd822ae67306ca6a025f17ed2cfb61c(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %a0, i32 %a1)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare %"compiler/typed:Local" @compiler_2ftyped_3aLocal_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, i32 %a4, { i64, [2 x i64] } %a5)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddLocal(ptr %v0, ptr %a0, %"compiler/typed:Local" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_486b3db7a819736b_b4c2afa2fe5bd5af = external constant [0 x i8]
declare %"compiler/typed:Capture" @compiler_2ftyped_3aCapture_2ector(ptr %v0, ptr %v1, i32 %a0, ptr %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aCapture_26_3e_2e_He39a1cf375adb47168dea91a05758aa9(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2ePu_Hdbf2db28b3dbd7714059bb41361f5f89(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseUnknownName(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/msgs:Msg" %a2)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i1 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseIsSubject(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5, %"compiler/source:Span" %a6, %"compiler/source:Span" %a7)
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
declare %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i8 @compiler_2fcheck_2eunescape(i8 %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earithCheck(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesMet(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorVars(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etwinCall(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, { i64, ptr } %a4)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBody(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_77e9ca8727c07af9_ddc1fd4e636ee49d = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, i64 %a5, ptr %a6, { i64, ptr } %a7, { i64, ptr } %a8)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_5759851fa91ce76c_a0f65aa07f0891f0 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2easkValue(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esameRepr(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceWritable(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeMismatch(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeHasNoConstructor(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_Hb6f924c91b81223120b2cba278ece4a6(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etestBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3, i64 %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeRules(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, ptr %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaredCtor(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitSets(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
@olang_loc_9f7e5ad647601e13_a7b1cb3e26ad346f = external constant [0 x i8]
declare i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eChosen(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclsIf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, i64 %a4)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3)
@olang_loc_77184c1d82837de9_1cf0b29343463305 = external constant [0 x i8]
@G_2ecompiler_2fcheck_2eBounds = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckOp(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_f35f30377e494c1c_7f1bf7df374d1e98 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebracketIn(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTryMultiIndexNeedsTryat(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_be9b28680965c17f_ec7705667e82647b = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTryIndexNeedsLen(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_c8857a233d9e8faa_24519e517389b3e6 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einRange(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, ptr %a4)
@olang_loc_50a05787c39822f3_4820228f4f4dc477 = external constant [0 x i8]
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHolds(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKeep(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeqShaped(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorTypeAsValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLengthsNotAValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenericNotAValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebound(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnNameAt(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnTooDeep(ptr %v0, ptr %a0, i64 %a1, i32 %a2, { i64, [3 x i64] } %a3)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecurInst(ptr %v0, ptr %a0)
declare %"compiler/generic:Origin" @compiler_2fgeneric_3aOrigin_2ector(ptr %v0, i64 %a0, %"compiler/source:Span" %a1, i64 %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnBody(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyErrors(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/check:roFn" @compiler_2fcheck_3aroFn_2ector(ptr %v0, ptr %v1, i64 %a0, i64 %a1, { i64, [3 x i64] } %a2, { i64, ptr } %a3)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroFn_3e_2ePush_3ccompiler_2fcheck_3aroFn_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:roFn" %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSigNames(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithNames(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare %"compiler/check:litv" @compiler_2fcheck_2enoLit()
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseUint(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %v0, i1 %a0, i1 %a1, i1 %a2, i64 %a3, double %a4)
declare { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i32, double } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseFloat(ptr %v0, { i64, ptr } %a0)
declare { i1, i64 } @compiler_2fcheck_2emagOf(%"compiler/check:litv" %a0)
declare %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 %a0, i64 %a1)
declare %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efoldPart(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/check:litv" @compiler_2fcheck_2eaddMag(i1 %a0, i64 %a1, i1 %a2, i64 %a3)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i64 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeck(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelemPlace(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2efieldSpans(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eLen_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsInst(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3)
declare %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeHoldsItself(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_4bb92e4e6aa9fa92_ae49a41c9a1a92ee = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoreturnSpan(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoreturnHere(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaArity(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2, i64 %a3)
@olang_loc_d264b31a2a0953e1_a8a3a5518784125d = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesTypeVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_9765c214aae0d14_3e0d6126973403f8 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayParamByValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ementionsVar(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaSignature(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaParamUntyped(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_5a62442bf09cb677_66ce856a58ef9453 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eDefaultErrT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eToAr_H9d0f958437b2bc29fe1d416dfb9901d7(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_H2d42092ce658fb6cce0104fa754a4e33(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %a0)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i1 %a3)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eSetVars(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootStmts(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eletOut(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emerged(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecanonicalErrs(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMissingReturn(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aCapture_26_3e_2e_Hc9219e836d6ca52518c31537b8e6a8eb(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesIdOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2efloatOverflows(i32 %a0, double %a1)
declare i1 @compiler_2fcheck_2eintFits(ptr %v0, ptr %a0, %"compiler/check:litv" %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclareUnknown(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructOneValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructCount(ptr %v0, i64 %a0, i64 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, [2 x i64] } %a5)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eputTarget(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2, ptr %a3, i32 %a4)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAfter(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssignListCount(ptr %v0, i64 %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estoredName(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferred(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i1 %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2ector(ptr %v0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ediscardOr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2_H5eacc50cc32d6e41ff62f01e24d943f2(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2eLe_H7b92c806358c31ec0113c885295670e0(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2_H3364bcea7de64bc2b6b83bde1edd9d27(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_476fe22cd4409b92_8ac04c158b99cfe6 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2ePu_H51141c7f79c906b1679ae982392c7956(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_3f_26_3e_2_Ha849274baa3792788a1b7c8fee45d023(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_1e0e3f8e77107efc_26f178b75df49a00 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2eTr_H7b9b9c82633a95f30e02bffa16283320(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_c3a1911177000af1_d7f4a899cd404215 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenRefOrVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare %"compiler/check:narrowed" @compiler_2fcheck_3anarrowed_2ector(ptr %v0, i64 %a0, i64 %a1, i32 %a2, i64 %a3, i64 %a4)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anarrowed_3e_2ePu_H8ca7ff483075a23de06ba27b878260e2(ptr %v0, ptr %a0, %"compiler/check:narrowed" %a1)
declare { i64, ptr } @compiler_2fcheck_2elowerFirst(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotTheOperator(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDeclaredHere(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/msgs:Msg" %a3)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultMethod(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOverrideSignature(ptr %v0, ptr %v1, { i64, ptr } %a0)
@G_2ecompiler_2ftypes_2eOwning = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [2 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eParamMark(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2ePus_H9afb0399fee55ed1ef4b4d03ad72cb66(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeWrittenAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_Hc07a7e56a24d8f1225398db99ea19a4b(ptr %v0, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eRunFrom_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_d39e2cfbcd38cb5a_4efeb51c01075546 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_4138b01f2eedcaec_10fcf95e1b11f8e8 = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyOfCallee(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_64f1128892bbfadb_2fd1650a543ec847 = external constant [0 x i8]
@olang_loc_9b328daa59c12fec_530ed6f7b483a728 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroMatch(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_aa71917389f82fa1_ab8db462134cc7fd = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCallCopy(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_45c1f7cb36e76579_9732da1c199d4515 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H4c470d2e80d9fd53b2c4a8b35e81296f(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H64396385e4e6d43afa926b839ce2258a(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a2)
declare { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H6388cc594ade7977543a45717e2b755f(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLocal(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e__Hb311157f9ff5cfde66cc01a7f8069ed8(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyKey(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1d7b97a31fca2c92a4527a0b3309f2d1(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i32 %a2)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
@olang_loc_7cf0066f219391e3_f59e2f38f1229917 = external constant [0 x i8]
@olang_loc_93e3a02800d00d4_2c47855b6b12ccf8 = external constant [0 x i8]
@olang_loc_ead499c86a25c3f7_b1128c547d2ccfbb = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eStrReceiverWritable(ptr %v0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/generic:Context" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclContext(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitRef(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitExtendsNotTrait(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereachesTrait(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitExtendsItself(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsClosedTrait(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitMemberOpen(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMembers(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/generic:Unmet" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMissing(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i1 %a3, i64 %a4)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitMemberMissing(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emeets(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etyOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseValueType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eborrowedSource(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %a0)
declare { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloopCall(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3, { i64, ptr } %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexhaustedOrBreak(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
declare { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebreakUnless(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelementLocals(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, ptr %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkBody(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anarrowed_3e_2eLe_H3e76598dd6b4a90eb80e3d16fe1b70d0(ptr %v0, ptr %a0)
declare %"compiler/check:narrowed" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anarrowed_3e_2eAt_H313390349c5d53629478ea446134cf40(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecaseDecl(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_e1df209ea46513ba_c2fba828617e051e = external constant [0 x i8]
declare i1 @compiler_2fcheck_2estmtLike(ptr %v0, ptr %a0)
@olang_loc_696a437f6b67e70a_247b6a7ce30931f6 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eleaves(ptr %v0, ptr %a0)
@G_2ecompiler_2fcheck_2eliteralOrder = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
@olang_loc_445c35e7b454dfb2_9156676d88e8071e = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aPattern_26_3e_2ector(ptr %v0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aPattern_26_3e_2ePu_H50118fa117031f41a126a195286f9d97(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aPattern_26_3e_2eTo_H10e4dc538dd932dd9b3885c00bcf8105(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_25d55d46e6c695b2_1c5feb2a345583d6 = external constant [0 x i8]
declare void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_dd9051e7d89be652_5717c5df078d4726 = external constant [0 x i8]
declare void @compiler_2fcheck_2eBounds_2einit()
declare void @compiler_2fcheck_2eDivideByZero_2einit()
declare void @compiler_2fcheck_2eOverflow_2einit()
declare void @compiler_2fcheck_2eInvalid_2einit()
declare void @compiler_2fcheck_2eWrongCase_2einit()
declare void @compiler_2fcheck_2eRoStored_2einit()
declare void @compiler_2fcheck_2eRoDecl_2einit()
declare void @compiler_2fcheck_2eRoReturned_2einit()
declare void @compiler_2fcheck_2eRoGlobal_2einit()
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
