; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/ast:TopBranch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/check:roFn" = type { i64, i64, { i64, [3 x i64] }, { i64, ptr } }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, i64, i64, i64, i64, i64, i64, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i1, i1, %"std/prelude/text:StringBuilder", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr } }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] }, i1 }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/check:b5aWalk" = type { i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i32, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i32, i64, i64, i64, i1, i64, i1, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i64, i1 }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, { i64, ptr }, i1 }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/generic:Desc" = type { i64, i32, i64, i64 }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr } }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, { i64, [2 x i64] }, i32, i1, i1 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/check:ctSource" = type { ptr, ptr, { i64, ptr }, i64, { i64, ptr } }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr, { i64, ptr } }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, ptr, i1, i1 }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, { i64, ptr } }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/generic:AnySlot" = type { i32, i32, i64, i64, i1, i32 }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/check:Gap" = type { i64, %"compiler/source:Span", { i64, ptr } }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/ast:JoinS" = type { i1, { i64, ptr }, { i64, ptr } }
%"compiler/check:laneNode" = type { i64, i32, %"compiler/source:Span", %"compiler/source:Span", i64, i64, i64, ptr, i32, i64, i32 }
%"compiler/check:litv" = type { i1, i1, i1, i64, double, i1, i1, i1, i128 }
%"compiler/check:rawTable" = type { i32, i1, { i64, ptr }, { i64, ptr } }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/check:typeCase" = type { i1, i1, i32, i64, i64, i1 }
%"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" = type { ptr, i64, ptr, ptr }
%"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" = type { i32, i32 }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/check:reflList" = type { i1, i32, i64, i64 }
%"compiler/ast:Compr" = type { ptr, ptr, i32, i32, ptr, ptr, i1, i64 }
%"compiler/check:heldCand" = type { i64, i64, i64 }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/check:laneVals" = type { i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/check:atRec" = type { i64, i64, ptr, i32 }
%"compiler/ast:If" = type { ptr, ptr, ptr }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/check:reflVal" = type { i1, i64, i64, { i64, ptr }, i32 }
%"compiler/check:TopAssertAsk" = type { i64, %"compiler/source:Span", %"compiler/source:Span", i64, i64 }
define dso_local i32 @compiler_2fcheck_2ebitOp(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb5
bb4:
  store i32 31, ptr %l1
  br label %bb35
bb5:
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t6, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t8, ptr %l6
  br label %bb6
bb6:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i32 32, ptr %l1
  br label %bb35
bb10:
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t11, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i1 %t13, ptr %l9
  br label %bb11
bb11:
  %t14 = load i1, ptr %l9, !tbaa !21
  br i1 %t14, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i32 33, ptr %l1
  br label %bb35
bb15:
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t18 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t16, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i1 %t18, ptr %l12
  br label %bb16
bb16:
  %t19 = load i1, ptr %l12, !tbaa !21
  br i1 %t19, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i32 34, ptr %l1
  br label %bb35
bb20:
  %t21 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t23 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t21, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store i1 %t23, ptr %l15
  br label %bb21
bb21:
  %t24 = load i1, ptr %l15, !tbaa !21
  br i1 %t24, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  store i32 35, ptr %l1
  br label %bb35
bb25:
  %t26 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t28 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t26, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i1 %t28, ptr %l18
  br label %bb26
bb26:
  %t29 = load i1, ptr %l18, !tbaa !21
  br i1 %t29, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  store i32 36, ptr %l1
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  store i32 29, ptr %l1
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_a3fc486149a2dc5d_17491af4361141b9)
  unreachable
bb35:
  call void @__olang_scope_close(ptr %s0)
  %t32 = load i32, ptr %l1, !range !{i32 0, i32 43}
  store i32 %t32, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2echainNames(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/ast:TopIf", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  %t8 = xor i1 %t6, true
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/ast:TopIf", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = icmp eq ptr %t13, null
  br i1 %t15, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  call void @__olang_check_failed(ptr @olang_loc_2196821906d7172f_ce8d1c9901dd14c3)
  unreachable
bb4:
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/ast:TopIf", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t23 = getelementptr %"compiler/ast:TopBranch", ptr %t20, i32 0, i32 1
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t25 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2edeclNames(ptr %v0, ptr %v1, { i64, ptr } %t24, ptr %t25)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/ast:TopIf", ptr %t28, i32 0, i32 2
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = icmp eq ptr %t31, null
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb8, label %bb9
bb8:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/ast:TopIf", ptr %t37, i32 0, i32 2
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = icmp eq ptr %t40, null
  br i1 %t42, label %bb10, label %bb11
bb9:
  br label %bb14
bb10:
  call void @__olang_check_failed(ptr @olang_loc_507ed937f609d1d0_9b704622aa820f34)
  unreachable
bb11:
  br label %bb12
bb12:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/ast:TopIf", ptr %t44, i32 0, i32 2
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t48 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2echainNames(ptr %v0, ptr %v1, ptr %t47, ptr %t48)
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/ast:TopIf", ptr %t51, i32 0, i32 3
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = icmp eq ptr %t54, null
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb15, label %bb16
bb15:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/ast:TopIf", ptr %t60, i32 0, i32 3
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = icmp eq ptr %t63, null
  br i1 %t65, label %bb17, label %bb18
bb16:
  br label %bb21
bb17:
  call void @__olang_check_failed(ptr @olang_loc_27f4d264c3bf025_5d55a961c8f61129)
  unreachable
bb18:
  br label %bb19
bb19:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/ast:TopIf", ptr %t67, i32 0, i32 3
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t73 = getelementptr %"compiler/ast:TopBranch", ptr %t70, i32 0, i32 1
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !27
  %t75 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2edeclNames(ptr %v0, ptr %v1, { i64, ptr } %t74, ptr %t75)
  br label %bb20
bb20:
  br label %bb21
bb21:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2eclosedFn(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca i1
  %l2 = alloca ptr
  %l3 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 3}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_980c9dc24d8ab357_bac7a576dce6b97b)
  unreachable
bb11:
  %t10 = load i1, ptr %l1, !tbaa !21
  store i1 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eGlobalType(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l6 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t7 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalType(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
  store i32 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load i32, ptr %l6, !tbaa !23
  store i32 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTextType(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0)
  store i32 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i32, ptr %l2, !tbaa !23
  store i32 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eadapter(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l18 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i32
  %l27 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i32
  %l37 = alloca i32
  %l38 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca i32
  %l48 = alloca i32
  %l49 = alloca i64
  %l52 = alloca i1
  %l54 = alloca ptr
  %l56 = alloca i64
  %l57 = alloca i64
  %l60 = alloca ptr
  %l61 = alloca i64
  %l62 = alloca i32
  %l63 = alloca %"compiler/source:Span"
  %l66 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l69 = alloca i1
  %l73 = alloca i32
  %l77 = alloca i64
  %l81 = alloca i32
  %l84 = alloca ptr
  %l89 = alloca i32
  %l90 = alloca { i64, ptr }
  %l93 = alloca ptr
  %l98 = alloca i32
  %l99 = alloca { i64, ptr }
  %l112 = alloca i64
  %l115 = alloca i64
  %l135 = alloca ptr
  %l137 = alloca { i64, ptr }
  %l141 = alloca i32
  %l143 = alloca { i64, ptr }
  %l146 = alloca i32
  %l147 = alloca i1
  %l151 = alloca { i64, ptr }
  %l155 = alloca i1
  %l156 = alloca i1
  %l158 = alloca { i64, ptr }
  %l161 = alloca i1
  %l162 = alloca i1
  %l164 = alloca { i64, ptr }
  %l167 = alloca i1
  %l174 = alloca ptr
  %l175 = alloca ptr
  %l180 = alloca i32
  %l181 = alloca i32
  %l182 = alloca ptr
  %l187 = alloca i32
  %l188 = alloca i32
  %l189 = alloca i1
  %l194 = alloca i64
  %l197 = alloca i1
  %l198 = alloca i32
  %l201 = alloca i32
  %l206 = alloca i32
  %l207 = alloca i32
  %l212 = alloca i32
  %l214 = alloca i1
  %l219 = alloca { i64, ptr }
  %l220 = alloca ptr
  %l223 = alloca ptr
  %l228 = alloca i32
  %l229 = alloca { i64, ptr }
  %l231 = alloca i1
  %l237 = alloca { i64, ptr }
  %l240 = alloca { i64, ptr }
  %l241 = alloca ptr
  %l244 = alloca ptr
  %l249 = alloca i32
  %l254 = alloca i32
  %l255 = alloca i32
  %l260 = alloca i32
  %l261 = alloca i32
  %l262 = alloca { i64, ptr }
  %l265 = alloca ptr
  %l266 = alloca %"compiler/source:Span"
  %l269 = alloca { i64, ptr }
  %l270 = alloca { i64, ptr }
  %l273 = alloca { i64, ptr }
  %l274 = alloca { i64, ptr }
  %l275 = alloca ptr
  %l280 = alloca i32
  %l281 = alloca { i64, ptr }
  %l284 = alloca %"compiler/msgs:Msg"
  %l285 = alloca i64
  %l287 = alloca ptr
  %l288 = alloca i64
  %l291 = alloca { i64, [3 x i64] }
  %l292 = alloca ptr
  %l296 = alloca ptr
  %l299 = alloca { i64, ptr }
  %l302 = alloca %"compiler/check:roFn"
  %l305 = alloca { i64, ptr }
  %l308 = alloca ptr
  %l309 = alloca %"compiler/source:Span"
  %l310 = alloca i32
  %l313 = alloca i32
  %l314 = alloca ptr
  %l318 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca ptr
  %t668 = alloca { i64, [4 x i64] }, align 8
  %t680 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l20, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t2)
  store i32 %t5, ptr %l23
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l20, !tbaa !29
  %t7 = load i32, ptr %l23, !tbaa !23
  %t8 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t8, ptr %l24
  br label %bb2
bb2:
  %t9 = load i32, ptr %l24, !tbaa !23
  store i32 %t9, ptr %l4, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l4, !tbaa !23
  %t14 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t10, i32 %t11)
  store i1 %t14, ptr %l27
  br label %bb3
bb3:
  %t15 = load i1, ptr %l27, !tbaa !21
  %t16 = xor i1 %t15, true
  br i1 %t16, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  store ptr %t22, ptr %l31, !tbaa !29
  %t23 = load i32, ptr %l4, !tbaa !23
  store i32 %t23, ptr %l32, !tbaa !23
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/load:Loader", ptr %t30, i32 0, i32 3
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t33, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store i32 %t35, ptr %l37
  br label %bb7
bb7:
  %t36 = load ptr, ptr %l31, !tbaa !29
  %t37 = load i32, ptr %l32, !tbaa !23
  %t38 = load i32, ptr %l37, !tbaa !23
  %t39 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t36, i32 %t37, i32 %t38)
  store i64 %t39, ptr %l38
  br label %bb8
bb8:
  %t40 = load i64, ptr %l38, !tbaa !24
  store i64 %t40, ptr %l5, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t43 = icmp slt i64 %t41, 0
  br i1 %t43, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  store ptr %t48, ptr %l42, !tbaa !29
  %t49 = load i32, ptr %l4, !tbaa !23
  store i32 %t49, ptr %l43, !tbaa !23
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 0
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = getelementptr %"compiler/load:Loader", ptr %t56, i32 0, i32 3
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s2, ptr %t59, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i32 %t61, ptr %l48
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t62 = load ptr, ptr %l42, !tbaa !29
  %t63 = load i32, ptr %l43, !tbaa !23
  %t64 = load i32, ptr %l48, !tbaa !23
  %t65 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t62, i32 %t63, i32 %t64)
  store i64 %t65, ptr %l49
  br label %bb12
bb12:
  %t66 = load i64, ptr %l49, !tbaa !24
  store i64 %t66, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  %t67 = load i64, ptr %l5, !tbaa !24
  %t69 = icmp slt i64 %t67, 0
  br i1 %t69, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb18
bb15:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  store ptr %t74, ptr %l54, !tbaa !29
  %t75 = load i64, ptr %l5, !tbaa !24
  %t77 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t75)
  store i64 %t77, ptr %l56
  br label %bb16
bb16:
  %t78 = load ptr, ptr %l54, !tbaa !29
  %t79 = load i64, ptr %l56, !tbaa !24
  %t80 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t78, i64 %t79)
  store i64 %t80, ptr %l57
  br label %bb17
bb17:
  %t81 = load i64, ptr %l57, !tbaa !24
  %t82 = icmp sgt i64 %t81, 0
  store i1 %t82, ptr %l52, !tbaa !21
  br label %bb18
bb18:
  %t84 = load i1, ptr %l52, !tbaa !21
  br i1 %t84, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l60, !tbaa !29
  %t87 = load i64, ptr %l5, !tbaa !24
  store i64 %t87, ptr %l61, !tbaa !24
  %t88 = load i32, ptr %l4, !tbaa !23
  store i32 %t88, ptr %l62, !tbaa !23
  %t89 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t89, ptr %l63
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load %"compiler/source:Span", ptr %l1
  %t94 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t90, %"compiler/source:Span" %t91)
  store { i64, ptr } %t94, ptr %l66
  br label %bb22
bb22:
  %t95 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t96 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %s0, { i64, ptr } %t95)
  store { i64, ptr } %t96, ptr %l67
  br label %bb23
bb23:
  %t97 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 0
  %t99 = extractvalue { i64, ptr } %t97, 1
  %t100 = mul i64 %t98, 1
  %t101 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t100)
  call void @llvm.memcpy.p0.p0.i64(ptr %t101, ptr %t99, i64 %t100, i1 false)
  %t102 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t101, 1
  %t104 = load ptr, ptr %l60, !tbaa !29
  %t105 = load i64, ptr %l61, !tbaa !24
  %t106 = load i32, ptr %l62, !tbaa !23
  %t107 = load %"compiler/source:Span", ptr %l63
  %t109 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprivateRole(ptr %v0, ptr %s0, ptr %s0, ptr %t104, i64 %t105, i32 %t106, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d8, i32 0, i32 1) }, %"compiler/source:Span" %t107, { i64, ptr } %t103)
  store i1 %t109, ptr %l69
  br label %bb24
bb24:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/check:Checker", ptr %t110, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t114 = load i64, ptr %l5, !tbaa !24
  %t117 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t113, i64 %t114)
  store i32 %t117, ptr %l73
  br label %bb25
bb25:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/check:Checker", ptr %t118, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t122 = load i64, ptr %l5, !tbaa !24
  %t125 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %t121, i64 %t122, i32 0)
  store i64 %t125, ptr %l77
  br label %bb26
bb26:
  %t126 = load i64, ptr %l77, !tbaa !24
  store i64 %t126, ptr %l6, !tbaa !24
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/check:Checker", ptr %t127, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t131 = load i64, ptr %l6, !tbaa !24
  %t134 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %t130, i64 %t131)
  store i32 %t134, ptr %l81
  br label %bb27
bb27:
  %t135 = load i32, ptr %l81, !tbaa !23
  store i32 %t135, ptr %l7, !tbaa !23
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/check:Checker", ptr %t136, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t141 = getelementptr %"compiler/generic:Program", ptr %t139, i32 0, i32 2
  store ptr %t141, ptr %l84, !tbaa !29
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/check:Checker", ptr %t142, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !29
  %t147 = getelementptr %"compiler/generic:Program", ptr %t145, i32 0, i32 2
  %t148 = load i32, ptr %l7, !tbaa !23
  %t151 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t147, i32 %t148)
  store i32 %t151, ptr %l89
  br label %bb28
bb28:
  %t152 = load ptr, ptr %l84, !tbaa !29
  %t153 = load i32, ptr %l89, !tbaa !23
  %t154 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t152, i32 %t153)
  store { i64, ptr } %t154, ptr %l90
  br label %bb29
bb29:
  %t155 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t155, ptr %l8, !tbaa !27
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/check:Checker", ptr %t156, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t161 = getelementptr %"compiler/generic:Program", ptr %t159, i32 0, i32 2
  store ptr %t161, ptr %l93, !tbaa !29
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/check:Checker", ptr %t162, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !29
  %t167 = getelementptr %"compiler/generic:Program", ptr %t165, i32 0, i32 2
  %t168 = load i32, ptr %l3, !tbaa !23
  %t171 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t167, i32 %t168)
  store i32 %t171, ptr %l98
  br label %bb30
bb30:
  %t172 = load ptr, ptr %l93, !tbaa !29
  %t173 = load i32, ptr %l98, !tbaa !23
  %t174 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t172, i32 %t173)
  store { i64, ptr } %t174, ptr %l99
  br label %bb31
bb31:
  %t175 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t175, ptr %l9, !tbaa !27
  %t176 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t176, 0
  %t179 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t179, 0
  %t183 = add i64 %t181, 1
  %t186 = icmp ne i64 %t178, %t183
  br i1 %t186, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  store i64 0, ptr %l10, !tbaa !24
  %t189 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t189, 0
  store i64 %t191, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t193 = load i64, ptr %l11, !tbaa !24
  %t194 = load i64, ptr %l10, !tbaa !24
  %t197 = icmp sgt i64 %t193, %t194
  br i1 %t197, label %bb35, label %bb36
bb35:
  %t199 = load i64, ptr %l12, !tbaa !24
  %t201 = icmp sgt i64 %t199, 0
  br i1 %t201, label %bb37, label %bb38
bb36:
  store i64 0, ptr %l112, !tbaa !24
  br label %bb40
bb37:
  %t203 = load i64, ptr %l11, !tbaa !24
  %t204 = load i64, ptr %l10, !tbaa !24
  %t207 = sub i64 %t203, %t204
  %t208 = load i64, ptr %l12, !tbaa !24
  %t211 = add i64 %t207, %t208
  %t213 = sub i64 %t211, 1
  %t214 = load i64, ptr %l12, !tbaa !24
  %t217 = sdiv i64 %t213, %t214
  store i64 %t217, ptr %l115, !tbaa !24
  br label %bb39
bb38:
  store i64 0, ptr %l115, !tbaa !24
  br label %bb39
bb39:
  %t219 = load i64, ptr %l115, !tbaa !24
  store i64 %t219, ptr %l112, !tbaa !24
  br label %bb40
bb40:
  %t220 = load i64, ptr %l112, !tbaa !24
  store i64 %t220, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb41
bb41:
  %t221 = load i64, ptr %l14, !tbaa !24
  %t222 = load i64, ptr %l13, !tbaa !24
  %t225 = icmp slt i64 %t221, %t222
  %t227 = xor i1 %t225, true
  br i1 %t227, label %bb42, label %bb43
bb42:
  br label %bb64
bb43:
  br label %bb44
bb44:
  %t229 = load i64, ptr %l10, !tbaa !24
  %t230 = load i64, ptr %l14, !tbaa !24
  %t231 = load i64, ptr %l12, !tbaa !24
  %t234 = mul i64 %t230, %t231
  %t237 = add i64 %t229, %t234
  store i64 %t237, ptr %l15, !tbaa !24
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"compiler/check:Checker", ptr %t239, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !29
  %t244 = getelementptr %"compiler/generic:Program", ptr %t242, i32 0, i32 2
  store ptr %t244, ptr %l135, !tbaa !29
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t246, ptr %l137, !tbaa !27
  %t247 = load i64, ptr %l15, !tbaa !24
  %t249 = add i64 %t247, 1
  %t251 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t252 = load ptr, ptr %t251, !tbaa !27
  %t253 = getelementptr i32, ptr %t252, i64 %t249
  %t254 = load i32, ptr %t253, !tbaa !33
  %t257 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t245, i32 %t254)
  store i32 %t257, ptr %l141
  br label %bb45
bb45:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t259 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t259, ptr %l143, !tbaa !27
  %t260 = load i64, ptr %l15, !tbaa !24
  %t262 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t263 = load ptr, ptr %t262, !tbaa !27
  %t264 = getelementptr i32, ptr %t263, i64 %t260
  %t265 = load i32, ptr %t264, !tbaa !33
  %t268 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t258, i32 %t265)
  store i32 %t268, ptr %l146
  br label %bb46
bb46:
  %t269 = load ptr, ptr %l135, !tbaa !29
  %t270 = load i32, ptr %l141, !tbaa !23
  %t271 = load i32, ptr %l146, !tbaa !23
  %t272 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t269, i32 %t270, i32 %t271)
  store i1 %t272, ptr %l147
  br label %bb47
bb47:
  %t273 = load i1, ptr %l147, !tbaa !21
  %t274 = xor i1 %t273, true
  br i1 %t274, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb49:
  br label %bb50
bb50:
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t278 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t278, ptr %l151, !tbaa !27
  %t279 = load i64, ptr %l15, !tbaa !24
  %t281 = add i64 %t279, 1
  %t283 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !27
  %t285 = getelementptr i32, ptr %t284, i64 %t281
  %t286 = load i32, ptr %t285, !tbaa !33
  %t289 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritable(ptr %v0, ptr %t277, i32 %t286)
  store i1 %t289, ptr %l155
  br label %bb51
bb51:
  %t290 = load i1, ptr %l155, !tbaa !21
  br i1 %t290, label %bb52, label %bb53
bb52:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t292 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t292, ptr %l158, !tbaa !27
  %t293 = load i64, ptr %l15, !tbaa !24
  %t295 = getelementptr { i64, ptr }, ptr %l158, i32 0, i32 1
  %t296 = load ptr, ptr %t295, !tbaa !27
  %t297 = getelementptr i32, ptr %t296, i64 %t293
  %t298 = load i32, ptr %t297, !tbaa !33
  %t301 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t291, i32 %t298)
  store i1 %t301, ptr %l161
  br label %bb54
bb53:
  store i1 false, ptr %l156, !tbaa !21
  br label %bb55
bb54:
  %t302 = load i1, ptr %l161, !tbaa !21
  store i1 %t302, ptr %l156, !tbaa !21
  br label %bb55
bb55:
  %t303 = load i1, ptr %l156, !tbaa !21
  br i1 %t303, label %bb56, label %bb57
bb56:
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t305 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t305, ptr %l164, !tbaa !27
  %t306 = load i64, ptr %l15, !tbaa !24
  %t308 = getelementptr { i64, ptr }, ptr %l164, i32 0, i32 1
  %t309 = load ptr, ptr %t308, !tbaa !27
  %t310 = getelementptr i32, ptr %t309, i64 %t306
  %t311 = load i32, ptr %t310, !tbaa !33
  %t314 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritable(ptr %v0, ptr %t304, i32 %t311)
  store i1 %t314, ptr %l167
  br label %bb58
bb57:
  store i1 false, ptr %l162, !tbaa !21
  br label %bb59
bb58:
  %t315 = load i1, ptr %l167, !tbaa !21
  %t316 = xor i1 %t315, true
  store i1 %t316, ptr %l162, !tbaa !21
  br label %bb59
bb59:
  %t318 = load i1, ptr %l162, !tbaa !21
  br i1 %t318, label %bb60, label %bb61
bb60:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb61:
  br label %bb62
bb62:
  br label %bb63
bb63:
  %t320 = load i64, ptr %l14, !tbaa !24
  %t322 = add i64 %t320, 1
  store i64 %t322, ptr %l14, !tbaa !24
  br label %bb41
bb64:
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t326 = getelementptr %"compiler/check:Checker", ptr %t324, i32 0, i32 1
  %t327 = load ptr, ptr %t326, !tbaa !29
  %t329 = getelementptr %"compiler/generic:Program", ptr %t327, i32 0, i32 2
  store ptr %t329, ptr %l174, !tbaa !29
  %t330 = load ptr, ptr %l0, !tbaa !29
  store ptr %t330, ptr %l175, !tbaa !29
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t333 = getelementptr %"compiler/check:Checker", ptr %t331, i32 0, i32 1
  %t334 = load ptr, ptr %t333, !tbaa !29
  %t336 = getelementptr %"compiler/generic:Program", ptr %t334, i32 0, i32 2
  %t337 = load i32, ptr %l7, !tbaa !23
  %t340 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t336, i32 %t337)
  store i32 %t340, ptr %l180
  br label %bb65
bb65:
  %t341 = load ptr, ptr %l175, !tbaa !29
  %t342 = load i32, ptr %l180, !tbaa !23
  %t343 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t341, i32 %t342)
  store i32 %t343, ptr %l181
  br label %bb66
bb66:
  %t344 = load ptr, ptr %l0, !tbaa !29
  store ptr %t344, ptr %l182, !tbaa !29
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t347 = getelementptr %"compiler/check:Checker", ptr %t345, i32 0, i32 1
  %t348 = load ptr, ptr %t347, !tbaa !29
  %t350 = getelementptr %"compiler/generic:Program", ptr %t348, i32 0, i32 2
  %t351 = load i32, ptr %l3, !tbaa !23
  %t354 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t350, i32 %t351)
  store i32 %t354, ptr %l187
  br label %bb67
bb67:
  %t355 = load ptr, ptr %l182, !tbaa !29
  %t356 = load i32, ptr %l187, !tbaa !23
  %t357 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t355, i32 %t356)
  store i32 %t357, ptr %l188
  br label %bb68
bb68:
  %t358 = load ptr, ptr %l174, !tbaa !29
  %t359 = load i32, ptr %l181, !tbaa !23
  %t360 = load i32, ptr %l188, !tbaa !23
  %t361 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t358, i32 %t359, i32 %t360)
  store i1 %t361, ptr %l189
  br label %bb69
bb69:
  %t362 = load i1, ptr %l189, !tbaa !21
  %t363 = xor i1 %t362, true
  br i1 %t363, label %bb70, label %bb71
bb70:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb71:
  br label %bb72
bb72:
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t367 = load i64, ptr %l6, !tbaa !24
  %t370 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnBody(ptr %v0, ptr %t366, i64 %t367)
  store i64 %t370, ptr %l194
  br label %bb73
bb73:
  %t371 = load i64, ptr %l194, !tbaa !24
  store i64 %t371, ptr %l16, !tbaa !24
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t373 = load i32, ptr %l7, !tbaa !23
  %t376 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %t372, i32 %t373)
  store i1 %t376, ptr %l197
  br label %bb74
bb74:
  %t377 = load i1, ptr %l197, !tbaa !21
  br i1 %t377, label %bb75, label %bb76
bb75:
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t379 = load i64, ptr %l16, !tbaa !24
  %t382 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyErrors(ptr %v0, ptr %t378, i64 %t379)
  store i32 %t382, ptr %l201
  br label %bb77
bb76:
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t385 = getelementptr %"compiler/check:Checker", ptr %t383, i32 0, i32 1
  %t386 = load ptr, ptr %t385, !tbaa !29
  %t388 = getelementptr %"compiler/generic:Program", ptr %t386, i32 0, i32 2
  %t389 = load i32, ptr %l7, !tbaa !23
  %t392 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t388, i32 %t389)
  store i32 %t392, ptr %l206
  br label %bb78
bb77:
  %t393 = load i32, ptr %l201, !tbaa !23
  store i32 %t393, ptr %l198, !tbaa !23
  br label %bb79
bb78:
  %t394 = load i32, ptr %l206, !tbaa !23
  store i32 %t394, ptr %l198, !tbaa !23
  br label %bb79
bb79:
  %t395 = load i32, ptr %l198, !tbaa !23
  store i32 %t395, ptr %l17, !tbaa !23
  %t396 = load i32, ptr %l17, !tbaa !23
  store i32 %t396, ptr %l207, !tbaa !23
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t399 = getelementptr %"compiler/check:Checker", ptr %t397, i32 0, i32 1
  %t400 = load ptr, ptr %t399, !tbaa !29
  %t402 = getelementptr %"compiler/generic:Program", ptr %t400, i32 0, i32 2
  %t403 = load i32, ptr %l3, !tbaa !23
  %t406 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t402, i32 %t403)
  store i32 %t406, ptr %l212
  br label %bb80
bb80:
  %t407 = load i32, ptr %l207, !tbaa !23
  %t408 = load i32, ptr %l212, !tbaa !23
  %t409 = icmp ne i32 %t407, %t408
  br i1 %t409, label %bb81, label %bb82
bb81:
  %t411 = load ptr, ptr %l0, !tbaa !29
  %t413 = getelementptr %"compiler/check:Checker", ptr %t411, i32 0, i32 1
  %t414 = load ptr, ptr %t413, !tbaa !29
  %t416 = getelementptr %"compiler/generic:Program", ptr %t414, i32 0, i32 2
  %t417 = load i32, ptr %l17, !tbaa !23
  %t420 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t416, i32 %t417)
  store { i64, ptr } %t420, ptr %l219
  br label %bb83
bb82:
  store i1 false, ptr %l214, !tbaa !21
  br label %bb87
bb83:
  store ptr %l219, ptr %l220
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t423 = getelementptr %"compiler/check:Checker", ptr %t421, i32 0, i32 1
  %t424 = load ptr, ptr %t423, !tbaa !29
  %t426 = getelementptr %"compiler/generic:Program", ptr %t424, i32 0, i32 2
  store ptr %t426, ptr %l223, !tbaa !29
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t429 = getelementptr %"compiler/check:Checker", ptr %t427, i32 0, i32 1
  %t430 = load ptr, ptr %t429, !tbaa !29
  %t432 = getelementptr %"compiler/generic:Program", ptr %t430, i32 0, i32 2
  %t433 = load i32, ptr %l3, !tbaa !23
  %t436 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t432, i32 %t433)
  store i32 %t436, ptr %l228
  br label %bb84
bb84:
  %t437 = load ptr, ptr %l223, !tbaa !29
  %t438 = load i32, ptr %l228, !tbaa !23
  %t439 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t437, i32 %t438)
  store { i64, ptr } %t439, ptr %l229
  br label %bb85
bb85:
  %t440 = load ptr, ptr %l220
  %t442 = call i1 @olang_2eHelperKind_2eEqual_2eArray_3ccompiler_2ftypes_3aTypeId_3e_26(ptr %t440, ptr %l229)
  store i1 %t442, ptr %l231
  br label %bb86
bb86:
  %t443 = load i1, ptr %l231, !tbaa !21
  %t444 = xor i1 %t443, true
  store i1 %t444, ptr %l214, !tbaa !21
  br label %bb87
bb87:
  %t446 = load i1, ptr %l214, !tbaa !21
  br i1 %t446, label %bb88, label %bb89
bb88:
  store %olang.scope zeroinitializer, ptr %s11
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t449 = getelementptr %"compiler/check:Checker", ptr %t447, i32 0, i32 1
  %t450 = load ptr, ptr %t449, !tbaa !29
  %t452 = getelementptr %"compiler/generic:Program", ptr %t450, i32 0, i32 2
  %t453 = load i32, ptr %l17, !tbaa !23
  %t456 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t452, i32 %t453)
  store { i64, ptr } %t456, ptr %l237
  br label %bb90
bb89:
  br label %bb105
bb90:
  %t457 = load { i64, ptr }, ptr %l237, !tbaa !27
  %t458 = extractvalue { i64, ptr } %t457, 0
  %t460 = icmp sgt i64 %t458, 0
  br i1 %t460, label %bb91, label %bb92
bb91:
  %t462 = load ptr, ptr %l0, !tbaa !29
  store ptr %t462, ptr %l241, !tbaa !29
  %t463 = load ptr, ptr %l0, !tbaa !29
  %t465 = getelementptr %"compiler/check:Checker", ptr %t463, i32 0, i32 1
  %t466 = load ptr, ptr %t465, !tbaa !29
  %t468 = getelementptr %"compiler/generic:Program", ptr %t466, i32 0, i32 2
  store ptr %t468, ptr %l244, !tbaa !29
  %t469 = load ptr, ptr %l0, !tbaa !29
  %t471 = getelementptr %"compiler/check:Checker", ptr %t469, i32 0, i32 1
  %t472 = load ptr, ptr %t471, !tbaa !29
  %t474 = getelementptr %"compiler/generic:Program", ptr %t472, i32 0, i32 2
  %t475 = load i32, ptr %l3, !tbaa !23
  %t478 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t474, i32 %t475)
  store i32 %t478, ptr %l249
  br label %bb93
bb92:
  store { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l240, !tbaa !27
  br label %bb98
bb93:
  %t479 = load ptr, ptr %l0, !tbaa !29
  %t481 = getelementptr %"compiler/check:Checker", ptr %t479, i32 0, i32 1
  %t482 = load ptr, ptr %t481, !tbaa !29
  %t484 = getelementptr %"compiler/generic:Program", ptr %t482, i32 0, i32 2
  %t485 = load i32, ptr %l3, !tbaa !23
  %t488 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t484, i32 %t485)
  store i32 %t488, ptr %l254
  br label %bb94
bb94:
  %t489 = load i32, ptr %l17, !tbaa !23
  store i32 %t489, ptr %l255, !tbaa !23
  %t490 = load ptr, ptr %l0, !tbaa !29
  %t492 = getelementptr %"compiler/check:Checker", ptr %t490, i32 0, i32 1
  %t493 = load ptr, ptr %t492, !tbaa !29
  %t495 = getelementptr %"compiler/generic:Program", ptr %t493, i32 0, i32 2
  %t496 = load i32, ptr %l3, !tbaa !23
  %t499 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t495, i32 %t496)
  store i32 %t499, ptr %l260
  br label %bb95
bb95:
  %t500 = load ptr, ptr %l244, !tbaa !29
  %t501 = load i32, ptr %l249, !tbaa !23
  %t502 = load i32, ptr %l254, !tbaa !23
  %t503 = load i32, ptr %l255, !tbaa !23
  %t504 = load i32, ptr %l260, !tbaa !23
  %t505 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t500, i32 %t501, i32 %t502, i32 %t503, i32 %t504, i64 0)
  store i32 %t505, ptr %l261
  br label %bb96
bb96:
  %t506 = load ptr, ptr %l241, !tbaa !29
  %t507 = load i32, ptr %l261, !tbaa !23
  %t508 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s11, ptr %t506, i32 %t507)
  store { i64, ptr } %t508, ptr %l262
  br label %bb97
bb97:
  %t509 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t510 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t511 = load { i64, ptr }, ptr %l262, !tbaa !27
  %t512 = extractvalue { i64, ptr } %t511, 1
  %t513 = extractvalue { i64, ptr } %t511, 0
  %t514 = add i64 %t510, %t513
  %t515 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t516 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t517 = add i64 %t514, %t516
  %t518 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t517)
  call void @olang_textcopy(ptr %t518, ptr %t509, i64 %t510)
  %t519 = getelementptr i8, ptr %t518, i64 %t510
  call void @olang_textcopy(ptr %t519, ptr %t512, i64 %t513)
  %t520 = getelementptr i8, ptr %t519, i64 %t513
  call void @olang_textcopy(ptr %t520, ptr %t515, i64 %t516)
  %t521 = insertvalue { i64, ptr } undef, i64 %t517, 0
  %t522 = insertvalue { i64, ptr } %t521, ptr %t518, 1
  %t524 = extractvalue { i64, ptr } %t522, 0
  %t525 = extractvalue { i64, ptr } %t522, 1
  %t526 = mul i64 %t524, 1
  %t527 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t526)
  call void @llvm.memcpy.p0.p0.i64(ptr %t527, ptr %t525, i64 %t526, i1 false)
  %t528 = insertvalue { i64, ptr } undef, i64 %t524, 0
  %t529 = insertvalue { i64, ptr } %t528, ptr %t527, 1
  store { i64, ptr } %t529, ptr %l240, !tbaa !27
  br label %bb98
bb98:
  %t531 = load { i64, ptr }, ptr %l240, !tbaa !27
  store { i64, ptr } %t531, ptr %l18, !tbaa !27
  %t532 = load ptr, ptr %l0, !tbaa !29
  store ptr %t532, ptr %l265, !tbaa !29
  %t533 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t533, ptr %l266
  %t534 = load ptr, ptr %l0, !tbaa !29
  %t535 = load i32, ptr %l4, !tbaa !23
  %t538 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s11, ptr %t534, i32 %t535)
  store { i64, ptr } %t538, ptr %l269
  br label %bb99
bb99:
  %t539 = load { i64, ptr }, ptr %l269, !tbaa !27
  %t540 = extractvalue { i64, ptr } %t539, 0
  %t541 = extractvalue { i64, ptr } %t539, 1
  %t542 = mul i64 %t540, 1
  %t543 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t542)
  call void @llvm.memcpy.p0.p0.i64(ptr %t543, ptr %t541, i64 %t542, i1 false)
  %t544 = insertvalue { i64, ptr } undef, i64 %t540, 0
  %t545 = insertvalue { i64, ptr } %t544, ptr %t543, 1
  store { i64, ptr } %t545, ptr %l270, !tbaa !27
  %t546 = load ptr, ptr %l0, !tbaa !29
  %t547 = load i32, ptr %l17, !tbaa !23
  %t550 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrsText(ptr %v0, ptr %s11, ptr %t546, i32 %t547)
  store { i64, ptr } %t550, ptr %l273
  br label %bb100
bb100:
  %t551 = load { i64, ptr }, ptr %l273, !tbaa !27
  %t552 = extractvalue { i64, ptr } %t551, 0
  %t553 = extractvalue { i64, ptr } %t551, 1
  %t554 = mul i64 %t552, 1
  %t555 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t554)
  call void @llvm.memcpy.p0.p0.i64(ptr %t555, ptr %t553, i64 %t554, i1 false)
  %t556 = insertvalue { i64, ptr } undef, i64 %t552, 0
  %t557 = insertvalue { i64, ptr } %t556, ptr %t555, 1
  store { i64, ptr } %t557, ptr %l274, !tbaa !27
  %t558 = load ptr, ptr %l0, !tbaa !29
  store ptr %t558, ptr %l275, !tbaa !29
  %t559 = load ptr, ptr %l0, !tbaa !29
  %t561 = getelementptr %"compiler/check:Checker", ptr %t559, i32 0, i32 1
  %t562 = load ptr, ptr %t561, !tbaa !29
  %t564 = getelementptr %"compiler/generic:Program", ptr %t562, i32 0, i32 2
  %t565 = load i32, ptr %l3, !tbaa !23
  %t568 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t564, i32 %t565)
  store i32 %t568, ptr %l280
  br label %bb101
bb101:
  %t569 = load ptr, ptr %l275, !tbaa !29
  %t570 = load i32, ptr %l280, !tbaa !23
  %t571 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrsText(ptr %v0, ptr %s11, ptr %t569, i32 %t570)
  store { i64, ptr } %t571, ptr %l281
  br label %bb102
bb102:
  %t572 = load { i64, ptr }, ptr %l281, !tbaa !27
  %t573 = extractvalue { i64, ptr } %t572, 0
  %t574 = extractvalue { i64, ptr } %t572, 1
  %t575 = mul i64 %t573, 1
  %t576 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t575)
  call void @llvm.memcpy.p0.p0.i64(ptr %t576, ptr %t574, i64 %t575, i1 false)
  %t577 = insertvalue { i64, ptr } undef, i64 %t573, 0
  %t578 = insertvalue { i64, ptr } %t577, ptr %t576, 1
  %t579 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t580 = load { i64, ptr }, ptr %l270, !tbaa !27
  %t581 = load { i64, ptr }, ptr %l274, !tbaa !27
  %t584 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCallValueErrors(ptr %s11, ptr %s11, ptr %s11, ptr %s11, ptr %s11, { i64, ptr } %t580, { i64, ptr } %t581, { i64, ptr } %t578, { i64, ptr } %t579)
  store %"compiler/msgs:Msg" %t584, ptr %l284
  br label %bb103
bb103:
  %t585 = load ptr, ptr %l265, !tbaa !29
  %t586 = load %"compiler/source:Span", ptr %l266
  %t587 = load %"compiler/msgs:Msg", ptr %l284
  %t588 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s11, ptr %t585, %"compiler/source:Span" %t586, %"compiler/msgs:Msg" %t587)
  store i64 %t588, ptr %l285
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s11)
  br label %bb105
bb105:
  %t589 = load ptr, ptr %l0, !tbaa !29
  %t591 = getelementptr %"compiler/check:Checker", ptr %t589, i32 0, i32 67
  store ptr %t591, ptr %l287, !tbaa !29
  %t592 = load i64, ptr %l16, !tbaa !24
  store i64 %t592, ptr %l288, !tbaa !24
  %t593 = load ptr, ptr %l0, !tbaa !29
  %t594 = load %"compiler/source:Span", ptr %l1
  %t597 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t593, %"compiler/source:Span" %t594)
  store { i64, [3 x i64] } %t597, ptr %l291
  br label %bb106
bb106:
  %t598 = load ptr, ptr %l0, !tbaa !29
  store ptr %t598, ptr %l292, !tbaa !29
  %t599 = load ptr, ptr %l0, !tbaa !29
  %t601 = getelementptr %"compiler/check:Checker", ptr %t599, i32 0, i32 1
  %t602 = load ptr, ptr %t601, !tbaa !29
  %t603 = load i64, ptr %l5, !tbaa !24
  %t606 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t602, i64 %t603)
  store ptr %t606, ptr %l296
  br label %bb107
bb107:
  %t607 = load ptr, ptr %l296, !tbaa !29
  %t609 = getelementptr %"compiler/ast:Func", ptr %t607, i32 0, i32 2
  %t610 = load i32, ptr %t609, !tbaa !23
  %t611 = load ptr, ptr %l292, !tbaa !29
  %t613 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t611, i32 %t610)
  store { i64, ptr } %t613, ptr %l299
  br label %bb108
bb108:
  %t614 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t615 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t616 = load { i64, ptr }, ptr %l299, !tbaa !27
  %t617 = extractvalue { i64, ptr } %t616, 1
  %t618 = extractvalue { i64, ptr } %t616, 0
  %t619 = add i64 %t615, %t618
  %t620 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t621 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t622 = add i64 %t619, %t621
  %t623 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t622)
  call void @olang_textcopy(ptr %t623, ptr %t614, i64 %t615)
  %t624 = getelementptr i8, ptr %t623, i64 %t615
  call void @olang_textcopy(ptr %t624, ptr %t617, i64 %t618)
  %t625 = getelementptr i8, ptr %t624, i64 %t618
  call void @olang_textcopy(ptr %t625, ptr %t620, i64 %t621)
  %t626 = insertvalue { i64, ptr } undef, i64 %t622, 0
  %t627 = insertvalue { i64, ptr } %t626, ptr %t623, 1
  %t629 = extractvalue { i64, ptr } %t627, 0
  %t630 = extractvalue { i64, ptr } %t627, 1
  %t631 = mul i64 %t629, 1
  %t632 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t631)
  call void @llvm.memcpy.p0.p0.i64(ptr %t632, ptr %t630, i64 %t631, i1 false)
  %t633 = insertvalue { i64, ptr } undef, i64 %t629, 0
  %t634 = insertvalue { i64, ptr } %t633, ptr %t632, 1
  %t635 = load i64, ptr %l288, !tbaa !24
  %t636 = load { i64, [3 x i64] }, ptr %l291
  %t638 = call %"compiler/check:roFn" @compiler_2fcheck_3aroFn_2ector(ptr %v0, ptr %v0, i64 %t635, i64 1, { i64, [3 x i64] } %t636, { i64, ptr } %t634)
  store %"compiler/check:roFn" %t638, ptr %l302
  br label %bb109
bb109:
  %t639 = load ptr, ptr %l287, !tbaa !29
  %t640 = load %"compiler/check:roFn", ptr %l302
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroFn_3e_2ePush_3ccompiler_2fcheck_3aroFn_3e(ptr %v0, ptr %v0, ptr %t639, %"compiler/check:roFn" %t640)
  br label %bb110
bb110:
  %t641 = load ptr, ptr %l0, !tbaa !29
  %t642 = load ptr, ptr %l2, !tbaa !29
  %t643 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t643, ptr %l305, !tbaa !27
  %t644 = getelementptr { i64, ptr }, ptr %l305, i32 0, i32 1
  %t645 = load ptr, ptr %t644, !tbaa !27
  %t646 = getelementptr i32, ptr %t645, i64 0
  %t647 = load i32, ptr %t646, !tbaa !33
  %t648 = load %"compiler/source:Span", ptr %l1
  %t653 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t641, ptr %t642, i32 %t647, %"compiler/source:Span" %t648)
  store ptr %t653, ptr %l308
  br label %bb111
bb111:
  %t654 = load ptr, ptr %l308, !tbaa !29
  %t655 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t655, ptr %l309
  %t656 = load i32, ptr %l3, !tbaa !23
  store i32 %t656, ptr %l310, !tbaa !23
  %t657 = load i64, ptr %l16, !tbaa !24
  %t659 = trunc i64 %t657 to i32
  store i32 %t659, ptr %l313, !tbaa !23
  store ptr %t654, ptr %l314, !tbaa !29
  %t662 = load ptr, ptr %l0, !tbaa !29
  %t663 = load %"compiler/source:Span", ptr %l1
  %t667 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t662, i32 5, %"compiler/source:Span" %t663)
  store i32 %t667, ptr %l318
  br label %bb112
bb112:
  store { i64, [4 x i64] } zeroinitializer, ptr %t668
  %t669 = getelementptr { i64, [4 x i64] }, ptr %t668, i32 0, i32 0
  store i64 2, ptr %t669
  %t670 = load i32, ptr %l313, !tbaa !23
  %t671 = insertvalue { i32, ptr, i32 } undef, i32 %t670, 0
  %t672 = load ptr, ptr %l314, !tbaa !29
  %t673 = insertvalue { i32, ptr, i32 } %t671, ptr %t672, 1
  %t674 = load i32, ptr %l318, !tbaa !23
  %t675 = insertvalue { i32, ptr, i32 } %t673, i32 %t674, 2
  %t676 = getelementptr { i64, [4 x i64] }, ptr %t668, i32 0, i32 1
  store { i32, ptr, i32 } %t675, ptr %t676
  %t677 = load { i64, [4 x i64] }, ptr %t668
  %t679 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t677, ptr %t679
  store { i64, [5 x i64] } zeroinitializer, ptr %t680
  %t681 = getelementptr { i64, [5 x i64] }, ptr %t680, i32 0, i32 0
  store i64 15, ptr %t681
  %t682 = load %"compiler/source:Span", ptr %l309
  %t683 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t682, 0
  %t684 = load i32, ptr %l310, !tbaa !23
  %t685 = insertvalue { %"compiler/source:Span", i32, ptr } %t683, i32 %t684, 1
  %t687 = insertvalue { %"compiler/source:Span", i32, ptr } %t685, ptr %t679, 2
  %t688 = getelementptr { i64, [5 x i64] }, ptr %t680, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t687, ptr %t688
  %t689 = load { i64, [5 x i64] }, ptr %t680
  %t691 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t689, ptr %t691
  call void @__olang_scope_close(ptr %s0)
  store ptr %t691, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ealtNames(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i64 %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l5 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca i32
  %l23 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i64
  %l27 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l29 = alloca i64
  %l31 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l39 = alloca ptr
  %l42 = alloca %"compiler/typed:Local"
  %l49 = alloca i64
  %l51 = alloca i64
  %l56 = alloca i32
  %l62 = alloca i64
  %l64 = alloca i64
  %l69 = alloca ptr
  %l71 = alloca ptr
  %l74 = alloca %"compiler/typed:Local"
  %l77 = alloca i64
  %l79 = alloca i64
  %l84 = alloca i32
  %l92 = alloca ptr
  %l94 = alloca ptr
  %l97 = alloca %"compiler/typed:Local"
  %l98 = alloca %"compiler/source:Span"
  %l99 = alloca %"compiler/msgs:Msg"
  %l100 = alloca i64
  %l104 = alloca i64
  %l106 = alloca i64
  %l111 = alloca i32
  %l113 = alloca i64
  %l115 = alloca i64
  %l120 = alloca i32
  %l128 = alloca ptr
  %l130 = alloca %"compiler/source:Span"
  %l131 = alloca %"compiler/msgs:Msg"
  %l132 = alloca i64
  %s0 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s22 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l27
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l27
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l5
  %t3 = load ptr, ptr %l1, !tbaa !29
  store ptr %t3, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb2
bb2:
  %t5 = load i64, ptr %l7, !tbaa !24
  store i64 %t5, ptr %l29, !tbaa !24
  %t6 = load ptr, ptr %l6, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBind_26_3e_2eLen_3ccompiler_2ftyped_3aBind_26_3e(ptr %v1, ptr %t6)
  store i64 %t8, ptr %l31
  br label %bb3
bb3:
  %t9 = load i64, ptr %l29, !tbaa !24
  %t10 = load i64, ptr %l31, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb4, label %bb5
bb4:
  br label %bb12
bb5:
  br label %bb6
bb6:
  %t15 = load ptr, ptr %l6, !tbaa !29
  %t16 = load i64, ptr %l7, !tbaa !24
  %t19 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBind_26_3e_2eAt_3ccompiler_2ftyped_3aBind_26_3e(ptr %v1, ptr %v1, ptr %t15, i64 %t16)
  store ptr %t19, ptr %l36
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l36, !tbaa !29
  store ptr %t20, ptr %l8, !tbaa !29
  store ptr %l5, ptr %l37, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t21)
  store ptr %t23, ptr %l39
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l8, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Bind", ptr %t24, i32 0, i32 0
  %t27 = load i32, ptr %t26, !tbaa !23
  %t28 = load ptr, ptr %l39, !tbaa !29
  %t30 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t28, i32 %t27)
  store %"compiler/typed:Local" %t30, ptr %l42
  br label %bb9
bb9:
  %t31 = getelementptr %"compiler/typed:Local", ptr %l42, i32 0, i32 0
  %t32 = load i32, ptr %t31, !tbaa !23
  %t33 = load ptr, ptr %l37, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %t33, i32 %t32)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t35 = load i64, ptr %l7, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l7, !tbaa !24
  br label %bb2
bb12:
  %t41 = icmp eq i64 %a3, 0
  br i1 %t41, label %bb13, label %bb14
bb13:
  store ptr %l5, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb15
bb14:
  br label %bb24
bb15:
  %t44 = load i64, ptr %l10, !tbaa !24
  store i64 %t44, ptr %l49, !tbaa !24
  %t45 = load ptr, ptr %l9, !tbaa !29
  %t47 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %t45)
  store i64 %t47, ptr %l51
  br label %bb16
bb16:
  %t48 = load i64, ptr %l49, !tbaa !24
  %t49 = load i64, ptr %l51, !tbaa !24
  %t50 = icmp slt i64 %t48, %t49
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb17, label %bb18
bb17:
  br label %bb23
bb18:
  br label %bb19
bb19:
  %t54 = load ptr, ptr %l9, !tbaa !29
  %t55 = load i64, ptr %l10, !tbaa !24
  %t58 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %t54, i64 %t55)
  store i32 %t58, ptr %l56
  br label %bb20
bb20:
  %t59 = load i32, ptr %l56, !tbaa !23
  %t60 = load ptr, ptr %l2, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v2, ptr %t60, i32 %t59)
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t64 = load i64, ptr %l10, !tbaa !24
  %t66 = add i64 %t64, 1
  store i64 %t66, ptr %l10, !tbaa !24
  br label %bb15
bb23:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb24:
  %t68 = load ptr, ptr %l1, !tbaa !29
  store ptr %t68, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb25
bb25:
  %t70 = load i64, ptr %l13, !tbaa !24
  store i64 %t70, ptr %l62, !tbaa !24
  %t71 = load ptr, ptr %l12, !tbaa !29
  %t73 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBind_26_3e_2eLen_3ccompiler_2ftyped_3aBind_26_3e(ptr %v1, ptr %t71)
  store i64 %t73, ptr %l64
  br label %bb26
bb26:
  %t74 = load i64, ptr %l62, !tbaa !24
  %t75 = load i64, ptr %l64, !tbaa !24
  %t76 = icmp slt i64 %t74, %t75
  %t78 = xor i1 %t76, true
  br i1 %t78, label %bb27, label %bb28
bb27:
  br label %bb52
bb28:
  br label %bb29
bb29:
  %t80 = load ptr, ptr %l12, !tbaa !29
  %t81 = load i64, ptr %l13, !tbaa !24
  %t84 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBind_26_3e_2eAt_3ccompiler_2ftyped_3aBind_26_3e(ptr %v1, ptr %v1, ptr %t80, i64 %t81)
  store ptr %t84, ptr %l69
  br label %bb30
bb30:
  %t85 = load ptr, ptr %l69, !tbaa !29
  store ptr %t85, ptr %l14, !tbaa !29
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t86)
  store ptr %t88, ptr %l71
  br label %bb31
bb31:
  %t89 = load ptr, ptr %l14, !tbaa !29
  %t91 = getelementptr %"compiler/typed:Bind", ptr %t89, i32 0, i32 0
  %t92 = load i32, ptr %t91, !tbaa !23
  %t93 = load ptr, ptr %l71, !tbaa !29
  %t95 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t93, i32 %t92)
  store %"compiler/typed:Local" %t95, ptr %l74
  br label %bb32
bb32:
  %t96 = getelementptr %"compiler/typed:Local", ptr %l74, i32 0, i32 0
  %t97 = load i32, ptr %t96, !tbaa !23
  store i32 %t97, ptr %l15, !tbaa !23
  store i1 false, ptr %l16, !tbaa !21
  %t99 = load ptr, ptr %l2, !tbaa !29
  store ptr %t99, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb33
bb33:
  %t101 = load i64, ptr %l18, !tbaa !24
  store i64 %t101, ptr %l77, !tbaa !24
  %t102 = load ptr, ptr %l17, !tbaa !29
  %t104 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v2, ptr %t102)
  store i64 %t104, ptr %l79
  br label %bb34
bb34:
  %t105 = load i64, ptr %l77, !tbaa !24
  %t106 = load i64, ptr %l79, !tbaa !24
  %t107 = icmp slt i64 %t105, %t106
  %t109 = xor i1 %t107, true
  br i1 %t109, label %bb35, label %bb36
bb35:
  br label %bb43
bb36:
  br label %bb37
bb37:
  %t111 = load ptr, ptr %l17, !tbaa !29
  %t112 = load i64, ptr %l18, !tbaa !24
  %t115 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v2, ptr %t111, i64 %t112)
  store i32 %t115, ptr %l84
  br label %bb38
bb38:
  %t116 = load i32, ptr %l84, !tbaa !23
  %t118 = load i32, ptr %l15, !tbaa !23
  %t121 = icmp eq i32 %t116, %t118
  br i1 %t121, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb41
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t123 = load i64, ptr %l18, !tbaa !24
  %t125 = add i64 %t123, 1
  store i64 %t125, ptr %l18, !tbaa !24
  br label %bb33
bb43:
  %t127 = load i1, ptr %l16, !tbaa !21
  %t129 = xor i1 %t127, true
  br i1 %t129, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s14
  %t131 = load ptr, ptr %l0, !tbaa !29
  store ptr %t131, ptr %l92, !tbaa !29
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t132)
  store ptr %t134, ptr %l94
  br label %bb46
bb45:
  br label %bb50
bb46:
  %t135 = load ptr, ptr %l14, !tbaa !29
  %t137 = getelementptr %"compiler/typed:Bind", ptr %t135, i32 0, i32 0
  %t138 = load i32, ptr %t137, !tbaa !23
  %t139 = load ptr, ptr %l94, !tbaa !29
  %t141 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t139, i32 %t138)
  store %"compiler/typed:Local" %t141, ptr %l97
  br label %bb47
bb47:
  %t142 = getelementptr %"compiler/typed:Local", ptr %l97, i32 0, i32 1
  %t143 = load %"compiler/source:Span", ptr %t142
  store %"compiler/source:Span" %t143, ptr %l98
  %t144 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAltBindsOtherNames(ptr %s14)
  store %"compiler/msgs:Msg" %t144, ptr %l99
  br label %bb48
bb48:
  %t145 = load ptr, ptr %l92, !tbaa !29
  %t146 = load %"compiler/source:Span", ptr %l98
  %t147 = load %"compiler/msgs:Msg", ptr %l99
  %t148 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s14, ptr %t145, %"compiler/source:Span" %t146, %"compiler/msgs:Msg" %t147)
  store i64 %t148, ptr %l100
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb50:
  br label %bb51
bb51:
  %t149 = load i64, ptr %l13, !tbaa !24
  %t151 = add i64 %t149, 1
  store i64 %t151, ptr %l13, !tbaa !24
  br label %bb25
bb52:
  %t153 = load ptr, ptr %l2, !tbaa !29
  store ptr %t153, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb53
bb53:
  %t155 = load i64, ptr %l21, !tbaa !24
  store i64 %t155, ptr %l104, !tbaa !24
  %t156 = load ptr, ptr %l20, !tbaa !29
  %t158 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v2, ptr %t156)
  store i64 %t158, ptr %l106
  br label %bb54
bb54:
  %t159 = load i64, ptr %l104, !tbaa !24
  %t160 = load i64, ptr %l106, !tbaa !24
  %t161 = icmp slt i64 %t159, %t160
  %t163 = xor i1 %t161, true
  br i1 %t163, label %bb55, label %bb56
bb55:
  br label %bb77
bb56:
  br label %bb57
bb57:
  %t165 = load ptr, ptr %l20, !tbaa !29
  %t166 = load i64, ptr %l21, !tbaa !24
  %t169 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v2, ptr %t165, i64 %t166)
  store i32 %t169, ptr %l111
  br label %bb58
bb58:
  %t170 = load i32, ptr %l111, !tbaa !23
  store i32 %t170, ptr %l22, !tbaa !23
  store i1 false, ptr %l23, !tbaa !21
  store ptr %l5, ptr %l24, !tbaa !29
  store i64 0, ptr %l25, !tbaa !24
  br label %bb59
bb59:
  %t172 = load i64, ptr %l25, !tbaa !24
  store i64 %t172, ptr %l113, !tbaa !24
  %t173 = load ptr, ptr %l24, !tbaa !29
  %t175 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %t173)
  store i64 %t175, ptr %l115
  br label %bb60
bb60:
  %t176 = load i64, ptr %l113, !tbaa !24
  %t177 = load i64, ptr %l115, !tbaa !24
  %t178 = icmp slt i64 %t176, %t177
  %t180 = xor i1 %t178, true
  br i1 %t180, label %bb61, label %bb62
bb61:
  br label %bb69
bb62:
  br label %bb63
bb63:
  %t182 = load ptr, ptr %l24, !tbaa !29
  %t183 = load i64, ptr %l25, !tbaa !24
  %t186 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %t182, i64 %t183)
  store i32 %t186, ptr %l120
  br label %bb64
bb64:
  %t187 = load i32, ptr %l120, !tbaa !23
  %t189 = load i32, ptr %l22, !tbaa !23
  %t192 = icmp eq i32 %t187, %t189
  br i1 %t192, label %bb65, label %bb66
bb65:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb67
bb66:
  br label %bb67
bb67:
  br label %bb68
bb68:
  %t194 = load i64, ptr %l25, !tbaa !24
  %t196 = add i64 %t194, 1
  store i64 %t196, ptr %l25, !tbaa !24
  br label %bb59
bb69:
  %t198 = load i1, ptr %l23, !tbaa !21
  %t200 = xor i1 %t198, true
  br i1 %t200, label %bb70, label %bb71
bb70:
  store %olang.scope zeroinitializer, ptr %s22
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l128, !tbaa !29
  %t205 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v3, ptr %a4)
  store %"compiler/source:Span" %t205, ptr %l130
  br label %bb72
bb71:
  br label %bb75
bb72:
  %t206 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAltBindsOtherNames(ptr %s22)
  store %"compiler/msgs:Msg" %t206, ptr %l131
  br label %bb73
bb73:
  %t207 = load ptr, ptr %l128, !tbaa !29
  %t208 = load %"compiler/source:Span", ptr %l130
  %t209 = load %"compiler/msgs:Msg", ptr %l131
  %t210 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s22, ptr %t207, %"compiler/source:Span" %t208, %"compiler/msgs:Msg" %t209)
  store i64 %t210, ptr %l132
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb75:
  br label %bb76
bb76:
  %t211 = load i64, ptr %l21, !tbaa !24
  %t213 = add i64 %t211, 1
  store i64 %t213, ptr %l21, !tbaa !24
  br label %bb53
bb77:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aFn(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i1
  %l6 = alloca i1
  %l7 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i1
  %l16 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l28 = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l7, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 12
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l10
  br label %bb3
bb3:
  %t11 = load i64, ptr %l7, !tbaa !24
  %t12 = load i64, ptr %l10, !tbaa !24
  %t13 = icmp sge i64 %t11, %t12
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l6, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb8
bb6:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/check:b5aWalk", ptr %t16, i32 0, i32 1
  %t19 = load i64, ptr %l2, !tbaa !24
  %t22 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v1, ptr %t18, i64 %t19)
  store i1 %t22, ptr %l16
  br label %bb7
bb7:
  %t23 = load i1, ptr %l16, !tbaa !21
  store i1 %t23, ptr %l12, !tbaa !21
  br label %bb8
bb8:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb9, label %bb10
bb9:
  br label %ret
bb10:
  br label %bb11
bb11:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"compiler/check:b5aWalk", ptr %t25, i32 0, i32 1
  %t28 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v1, ptr %t27, i64 %t28, i1 true)
  br label %bb12
bb12:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr %"compiler/check:b5aWalk", ptr %t31, i32 0, i32 6
  %t34 = load i1, ptr %t33, !tbaa !21
  store i1 %t34, ptr %l3, !tbaa !21
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = getelementptr %"compiler/check:b5aWalk", ptr %t36, i32 0, i32 6
  store i1 false, ptr %t38, !tbaa !21
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l23, !tbaa !29
  %t40 = load ptr, ptr %l1, !tbaa !29
  store ptr %t40, ptr %l24, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 12
  %t44 = load i64, ptr %l2, !tbaa !24
  %t47 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t43, i64 %t44)
  store ptr %t47, ptr %l28
  br label %bb13
bb13:
  %t48 = load ptr, ptr %l28, !tbaa !29
  %t50 = getelementptr %"compiler/typed:Body", ptr %t48, i32 0, i32 11
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t52 = load ptr, ptr %l23, !tbaa !29
  %t53 = load ptr, ptr %l24, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aBlock(ptr %v0, ptr %v1, ptr %v0, ptr %t52, ptr %t53, ptr %t51)
  br label %bb14
bb14:
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t56 = load i1, ptr %l3, !tbaa !21
  %t59 = getelementptr %"compiler/check:b5aWalk", ptr %t55, i32 0, i32 6
  store i1 %t56, ptr %t59, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l10 = alloca ptr
  %l12 = alloca ptr
  %l15 = alloca ptr
  %l29 = alloca i1
  %l34 = alloca i1
  %l35 = alloca { i64, ptr }
  %l39 = alloca i1
  %l40 = alloca { i64, ptr }
  %l44 = alloca i1
  %l45 = alloca { i64, ptr }
  %l49 = alloca i1
  %l50 = alloca { i64, ptr }
  %l63 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 5
  store ptr %t9, ptr %l10, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t10)
  store ptr %t12, ptr %l12
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l12, !tbaa !29
  %t15 = getelementptr %"compiler/check:frame", ptr %t13, i32 0, i32 1
  %t16 = load i64, ptr %t15, !tbaa !24
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t19 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t17, i64 %t16)
  store ptr %t19, ptr %l15
  br label %bb2
bb2:
  %t20 = load ptr, ptr %l15, !tbaa !29
  %t22 = getelementptr %"compiler/load:Module", ptr %t20, i32 0, i32 6
  %t23 = load ptr, ptr %t22, !tbaa !29
  store ptr %t23, ptr %l4, !tbaa !29
  %t25 = load ptr, ptr %l4, !tbaa !29
  %t27 = icmp eq ptr %t25, null
  br i1 %t27, label %bb3, label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_37018c2ebf0da22a_371c8892c4c63a5e)
  unreachable
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l4, !tbaa !29
  %t32 = getelementptr %"compiler/source:Source", ptr %t29, i32 0, i32 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l5, !tbaa !27
  %t35 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t36 = load i32, ptr %t35, !tbaa !23
  %t38 = sext i32 %t36 to i64
  store i64 %t38, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t42 = load i32, ptr %t41, !tbaa !23
  %t44 = sext i32 %t42 to i64
  %t47 = icmp slt i64 %t40, %t44
  br i1 %t47, label %bb7, label %bb8
bb7:
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t55 = icmp slt i64 %t49, %t52
  store i1 %t55, ptr %l29, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb9
bb9:
  %t57 = load i1, ptr %l29, !tbaa !21
  br i1 %t57, label %bb10, label %bb11
bb10:
  %t58 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t58, ptr %l35, !tbaa !27
  %t59 = load i64, ptr %l6, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i8, ptr %t62, i64 %t59
  %t64 = load i8, ptr %t63, !tbaa !32
  %t66 = icmp eq i8 %t64, 32
  br i1 %t66, label %bb12, label %bb13
bb11:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb21
bb12:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb14
bb13:
  %t68 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t68, ptr %l40, !tbaa !27
  %t69 = load i64, ptr %l6, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr i8, ptr %t72, i64 %t69
  %t74 = load i8, ptr %t73, !tbaa !32
  %t76 = icmp eq i8 %t74, 10
  store i1 %t76, ptr %l39, !tbaa !21
  br label %bb14
bb14:
  %t78 = load i1, ptr %l39, !tbaa !21
  br i1 %t78, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb17
bb16:
  %t79 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t79, ptr %l45, !tbaa !27
  %t80 = load i64, ptr %l6, !tbaa !24
  %t82 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr i8, ptr %t83, i64 %t80
  %t85 = load i8, ptr %t84, !tbaa !32
  %t87 = icmp eq i8 %t85, 9
  store i1 %t87, ptr %l44, !tbaa !21
  br label %bb17
bb17:
  %t89 = load i1, ptr %l44, !tbaa !21
  br i1 %t89, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb20
bb19:
  %t90 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t90, ptr %l50, !tbaa !27
  %t91 = load i64, ptr %l6, !tbaa !24
  %t93 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr i8, ptr %t94, i64 %t91
  %t96 = load i8, ptr %t95, !tbaa !32
  %t98 = icmp eq i8 %t96, 41
  store i1 %t98, ptr %l49, !tbaa !21
  br label %bb20
bb20:
  %t100 = load i1, ptr %l49, !tbaa !21
  store i1 %t100, ptr %l34, !tbaa !21
  br label %bb21
bb21:
  %t101 = load i1, ptr %l34, !tbaa !21
  %t102 = xor i1 %t101, true
  br i1 %t102, label %bb22, label %bb23
bb22:
  br label %bb26
bb23:
  br label %bb24
bb24:
  %t104 = load i64, ptr %l6, !tbaa !24
  %t106 = add i64 %t104, 1
  store i64 %t106, ptr %l6, !tbaa !24
  br label %bb25
bb25:
  br label %bb6
bb26:
  %t108 = load i64, ptr %l6, !tbaa !24
  %t110 = trunc i64 %t108 to i32
  %t111 = load i64, ptr %l6, !tbaa !24
  %t115 = add i64 %t111, %a3
  %t117 = trunc i64 %t115 to i32
  %t120 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t110, i32 %t117)
  store %"compiler/source:Span" %t120, ptr %l63
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s0)
  %t121 = load %"compiler/source:Span", ptr %l63
  store %"compiler/source:Span" %t121, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebracketOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca %"compiler/source:Span"
  %rv = alloca %"compiler/source:Span"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  %t4 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %a1)
  store %"compiler/source:Span" %t4, ptr %l4
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load %"compiler/source:Span", ptr %l4
  %t7 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAfter(ptr %v0, ptr %t5, %"compiler/source:Span" %t6, i64 1)
  store %"compiler/source:Span" %t7, ptr %l5
  br label %bb2
bb2:
  %t8 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuildDefaulted(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l10 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca i1
  %l17 = alloca i1
  %l20 = alloca i1
  %l25 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l29 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 5
  %t13 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t9, i64 %a1)
  store ptr %t13, ptr %l10
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l10, !tbaa !29
  store ptr %t14, ptr %l4, !tbaa !29
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t17 = getelementptr %"compiler/load:Module", ptr %t15, i32 0, i32 3
  %t18 = load i1, ptr %t17, !tbaa !21
  br i1 %t18, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb5
bb3:
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t22 = getelementptr %"compiler/load:Module", ptr %t20, i32 0, i32 2
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t23, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i1 %t25, ptr %l16
  br label %bb4
bb4:
  %t26 = load i1, ptr %l16, !tbaa !21
  store i1 %t26, ptr %l13, !tbaa !21
  br label %bb5
bb5:
  %t27 = load i1, ptr %l13, !tbaa !21
  br i1 %t27, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb9
bb7:
  %t30 = getelementptr %"compiler/ast:VarDecl", ptr %a3, i32 0, i32 2
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = call i1 @compiler_2fcheck_2ewrittenMut(ptr %v1, ptr %t31)
  store i1 %t33, ptr %l20
  br label %bb8
bb8:
  %t34 = load i1, ptr %l20, !tbaa !21
  store i1 %t34, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t35 = load i1, ptr %l17, !tbaa !21
  br i1 %t35, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 0
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/load:Loader", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  store ptr %t46, ptr %l25, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t51 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t47, i32 %a2)
  store { i64, ptr } %t51, ptr %l28
  br label %bb13
bb13:
  %t52 = load ptr, ptr %l25, !tbaa !29
  %t53 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t54 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eDefined(ptr %v0, ptr %v0, ptr %t52, { i64, ptr } %t53)
  store i1 %t54, ptr %l29
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t55 = load i1, ptr %l29, !tbaa !21
  store i1 %t55, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l20 = alloca %"compiler/source:Span"
  %l23 = alloca { i64, ptr }
  %l25 = alloca %"compiler/source:Span"
  %l27 = alloca %"compiler/source:Span"
  %l28 = alloca ptr
  %l29 = alloca i1
  %l36 = alloca %"compiler/source:Span"
  %l38 = alloca %"compiler/source:Span"
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 29}
  %t8 = icmp eq i64 %t6, 12
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb19
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t17 = load ptr, ptr %l12, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 29}
  %t23 = icmp eq i64 %t21, 15
  store i1 %t23, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l13, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l3
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr { i64, [5 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t33, i32 0, i32 2
  %t35 = load i32, ptr %t34
  store i32 %t35, ptr %l4, !tbaa !23
  br label %bb10
bb9:
  br label %bb13
bb10:
  %t37 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t37, ptr %l20
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i32, ptr %l4, !tbaa !23
  %t42 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t38, i32 %t39)
  store { i64, ptr } %t42, ptr %l23
  br label %bb11
bb11:
  %t43 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t43, 0
  %t45 = load %"compiler/source:Span", ptr %l20
  %t47 = call %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %t45, i64 %t44)
  store %"compiler/source:Span" %t47, ptr %l25
  br label %bb12
bb12:
  %t48 = load %"compiler/source:Span", ptr %l25
  store %"compiler/source:Span" %t48, ptr %rv
  br label %ret
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t49 = load ptr, ptr %l2, !tbaa !29
  %t51 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t49)
  store %"compiler/source:Span" %t51, ptr %l27
  br label %bb17
bb17:
  %t52 = load %"compiler/source:Span", ptr %l27
  store %"compiler/source:Span" %t52, ptr %rv
  br label %ret
bb18:
  call void @__olang_check_failed(ptr @olang_loc_fb617c2d829b7111_714329061eadcd35)
  unreachable
bb19:
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t54 = load ptr, ptr %l28, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb20, label %bb21
bb20:
  %t57 = load ptr, ptr %l28, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 29}
  %t60 = icmp eq i64 %t58, 2
  store i1 %t60, ptr %l29, !tbaa !21
  br label %bb21
bb21:
  %t61 = load i1, ptr %l29, !tbaa !21
  br i1 %t61, label %bb22, label %bb23
bb22:
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr { i64, [5 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", ptr }, ptr %t64, i32 0, i32 1
  %t66 = load ptr, ptr %t65
  store ptr %t66, ptr %l5, !tbaa !29
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l5, !tbaa !29
  %t72 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeSpan(ptr %v0, ptr %v1, ptr %t68, ptr %t69)
  store %"compiler/source:Span" %t72, ptr %l36
  br label %bb25
bb25:
  %t73 = load %"compiler/source:Span", ptr %l36
  store %"compiler/source:Span" %t73, ptr %rv
  br label %ret
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t74)
  store %"compiler/source:Span" %t76, ptr %l38
  br label %bb30
bb30:
  %t77 = load %"compiler/source:Span", ptr %l38
  store %"compiler/source:Span" %t77, ptr %rv
  br label %ret
bb31:
  call void @__olang_check_failed(ptr @olang_loc_796a210bea009080_30d8ca3bde523e44)
  unreachable
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaptureIn(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i32
  %l25 = alloca i1
  %l35 = alloca i64
  %l40 = alloca ptr
  %l45 = alloca ptr
  %l48 = alloca ptr
  %l52 = alloca %"compiler/typed:Local"
  %l64 = alloca i1
  %l66 = alloca i1
  %l69 = alloca i32
  %l72 = alloca i1
  %l81 = alloca i32
  %l96 = alloca ptr
  %l97 = alloca ptr
  %l103 = alloca %"compiler/typed:Local"
  %l104 = alloca i32
  %l111 = alloca ptr
  %l114 = alloca i32
  %l118 = alloca %"compiler/typed:Capture"
  %l122 = alloca i1
  %l123 = alloca i1
  %l128 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i64
  %t90 = alloca { i64, [4 x i64] }, align 8
  %t147 = alloca { i64, [5 x i64] }, align 8
  %t165 = alloca { i64, [5 x i64] }, align 8
  %t193 = alloca { i64, [2 x i64] }, align 8
  %t260 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 14
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_Hc8503b2b20cde402cc7bde6f68d96fc0(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l16
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l16, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t11 = getelementptr %"compiler/check:frame", ptr %t9, i32 0, i32 8
  %t12 = load i32, ptr %l2, !tbaa !23
  %t15 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t11, i32 %t12)
  %t16 = extractvalue { i32, i64 } %t15, 1
  %t17 = extractvalue { i32, i64 } %t15, 0
  store i32 %t17, ptr %l22
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb3, label %ok.19, !prof !99
ok.19:
  store i64 %t16, ptr %l21
  br label %bb2
bb2:
  %t20 = load i64, ptr %l21, !tbaa !24
  store i64 %t20, ptr %l17, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t21 = load i64, ptr %l17, !tbaa !24
  store i64 %t21, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l5, !tbaa !24
  %t24 = icmp sge i64 %t22, 0
  br i1 %t24, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb8
bb7:
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t28 = getelementptr %"compiler/check:frame", ptr %t26, i32 0, i32 19
  %t29 = load i64, ptr %t28, !tbaa !24
  %t31 = icmp slt i64 %t29, 0
  store i1 %t31, ptr %l25, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l25, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t34 = load i64, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t34, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load ptr, ptr %l4, !tbaa !29
  %t39 = getelementptr %"compiler/check:frame", ptr %t37, i32 0, i32 19
  %t40 = load i64, ptr %t39, !tbaa !24
  %t41 = load i32, ptr %l2, !tbaa !23
  %t42 = load %"compiler/source:Span", ptr %l3
  %t47 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaptureIn(ptr %v0, ptr %t36, i64 %t40, i32 %t41, %"compiler/source:Span" %t42)
  store i64 %t47, ptr %l35
  br label %bb12
bb12:
  %t48 = load i64, ptr %l35, !tbaa !24
  store i64 %t48, ptr %l6, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t51 = icmp slt i64 %t49, 0
  br i1 %t51, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 12
  store ptr %t56, ptr %l40, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 14
  %t60 = load ptr, ptr %l4, !tbaa !29
  %t62 = getelementptr %"compiler/check:frame", ptr %t60, i32 0, i32 19
  %t63 = load i64, ptr %t62, !tbaa !24
  %t66 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_Hc8503b2b20cde402cc7bde6f68d96fc0(ptr %v0, ptr %v0, ptr %t59, i64 %t63)
  store ptr %t66, ptr %l45
  br label %bb16
bb16:
  %t67 = load ptr, ptr %l45, !tbaa !29
  %t69 = getelementptr %"compiler/check:frame", ptr %t67, i32 0, i32 0
  %t70 = load i64, ptr %t69, !tbaa !24
  %t71 = load ptr, ptr %l40, !tbaa !29
  %t73 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t71, i64 %t70)
  store ptr %t73, ptr %l48
  br label %bb17
bb17:
  %t74 = load ptr, ptr %l48, !tbaa !29
  %t76 = getelementptr %"compiler/typed:Body", ptr %t74, i32 0, i32 7
  %t77 = load i64, ptr %l6, !tbaa !24
  %t80 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t76, i64 %t77)
  store %"compiler/typed:Local" %t80, ptr %l52
  br label %bb18
bb18:
  %t81 = getelementptr %"compiler/typed:Local", ptr %l52, i32 0, i32 2
  %t82 = load i32, ptr %t81, !tbaa !23
  store i32 %t82, ptr %l7, !tbaa !23
  %t84 = load %"compiler/source:Span", ptr %l3
  %t85 = load i32, ptr %l7, !tbaa !23
  %t86 = load i64, ptr %l6, !tbaa !24
  %t88 = trunc i64 %t86 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t90
  %t91 = getelementptr { i64, [4 x i64] }, ptr %t90, i32 0, i32 0
  store i64 0, ptr %t91
  %t93 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t84, 0
  %t95 = insertvalue { %"compiler/source:Span", i32, i32 } %t93, i32 %t85, 1
  %t97 = insertvalue { %"compiler/source:Span", i32, i32 } %t95, i32 %t88, 2
  %t98 = getelementptr { i64, [4 x i64] }, ptr %t90, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t97, ptr %t98
  %t99 = load { i64, [4 x i64] }, ptr %t90
  %t101 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t99, ptr %t101
  store ptr %t101, ptr %l8, !tbaa !29
  %t103 = load i32, ptr %l7, !tbaa !23
  store i32 %t103, ptr %l9, !tbaa !23
  store ptr null, ptr %l10, !tbaa !29
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load i32, ptr %l7, !tbaa !23
  %t109 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t105, i32 %t106)
  store i1 %t109, ptr %l64
  br label %bb19
bb19:
  %t110 = load i1, ptr %l64, !tbaa !21
  %t111 = xor i1 %t110, true
  br i1 %t111, label %bb20, label %bb21
bb20:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load i32, ptr %l7, !tbaa !23
  %t117 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t113, i32 %t114)
  store i32 %t117, ptr %l69
  br label %bb22
bb21:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb23
bb22:
  %t118 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t119 = load i32, ptr %l69, !tbaa !23
  %t121 = icmp ne i32 %t119, %t118
  store i1 %t121, ptr %l66, !tbaa !21
  br label %bb23
bb23:
  %t123 = load i1, ptr %l66, !tbaa !21
  br i1 %t123, label %bb24, label %bb25
bb24:
  %t124 = load ptr, ptr %l4, !tbaa !29
  %t126 = getelementptr %"compiler/check:frame", ptr %t124, i32 0, i32 20
  %t127 = load i1, ptr %t126, !tbaa !21
  %t129 = xor i1 %t127, true
  store i1 %t129, ptr %l72, !tbaa !21
  br label %bb26
bb25:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb26
bb26:
  %t131 = load i1, ptr %l72, !tbaa !21
  br i1 %t131, label %bb27, label %bb28
bb27:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/check:Checker", ptr %t132, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t137 = getelementptr %"compiler/generic:Program", ptr %t135, i32 0, i32 2
  %t138 = load i32, ptr %l7, !tbaa !23
  %t139 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t143 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t137, i32 %t138, i64 %t139)
  store i32 %t143, ptr %l81
  br label %bb29
bb28:
  %t144 = load %"compiler/source:Span", ptr %l3
  %t145 = load i32, ptr %l7, !tbaa !23
  %t146 = load ptr, ptr %l8, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t147
  %t148 = getelementptr { i64, [5 x i64] }, ptr %t147, i32 0, i32 0
  store i64 2, ptr %t148
  %t150 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t144, 0
  %t152 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t150, i32 %t145, 1
  %t154 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t152, ptr %t146, 2
  %t155 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t154, i32 -1, 3
  %t156 = getelementptr { i64, [5 x i64] }, ptr %t147, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t155, ptr %t156
  %t157 = load { i64, [5 x i64] }, ptr %t147
  %t159 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t157, ptr %t159
  store ptr %t159, ptr %l10, !tbaa !29
  br label %bb30
bb29:
  %t161 = load i32, ptr %l81, !tbaa !23
  store i32 %t161, ptr %l9, !tbaa !23
  %t162 = load %"compiler/source:Span", ptr %l3
  %t163 = load i32, ptr %l9, !tbaa !23
  %t164 = load ptr, ptr %l8, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t165
  %t166 = getelementptr { i64, [5 x i64] }, ptr %t165, i32 0, i32 0
  store i64 3, ptr %t166
  %t168 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t162, 0
  %t170 = insertvalue { %"compiler/source:Span", i32, ptr } %t168, i32 %t163, 1
  %t172 = insertvalue { %"compiler/source:Span", i32, ptr } %t170, ptr %t164, 2
  %t173 = getelementptr { i64, [5 x i64] }, ptr %t165, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t172, ptr %t173
  %t174 = load { i64, [5 x i64] }, ptr %t165
  %t176 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t174, ptr %t176
  store ptr %t176, ptr %l10, !tbaa !29
  br label %bb30
bb30:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr %"compiler/check:Checker", ptr %t178, i32 0, i32 12
  %t181 = load ptr, ptr %l4, !tbaa !29
  %t183 = getelementptr %"compiler/check:frame", ptr %t181, i32 0, i32 0
  %t184 = load i64, ptr %t183, !tbaa !24
  %t187 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t180, i64 %t184)
  store ptr %t187, ptr %l96
  br label %bb31
bb31:
  %t188 = load ptr, ptr %l96, !tbaa !29
  store ptr %t188, ptr %l11, !tbaa !29
  %t189 = load ptr, ptr %l11, !tbaa !29
  store ptr %t189, ptr %l97, !tbaa !29
  %t190 = load i32, ptr %l2, !tbaa !23
  %t191 = load %"compiler/source:Span", ptr %l3
  %t192 = load i32, ptr %l9, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t193
  %t194 = getelementptr { i64, [2 x i64] }, ptr %t193, i32 0, i32 0
  store i64 5, ptr %t194
  %t195 = load { i64, [2 x i64] }, ptr %t193
  %t201 = call %"compiler/typed:Local" @compiler_2ftyped_3aLocal_2ector(ptr %s0, i32 %t190, %"compiler/source:Span" %t191, i32 %t192, i32 0, i32 5, { i64, [2 x i64] } %t195)
  store %"compiler/typed:Local" %t201, ptr %l103
  br label %bb32
bb32:
  %t202 = load ptr, ptr %l97, !tbaa !29
  %t203 = load %"compiler/typed:Local", ptr %l103
  %t204 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddLocal(ptr %v0, ptr %t202, %"compiler/typed:Local" %t203)
  store i32 %t204, ptr %l104
  br label %bb33
bb33:
  %t205 = load i32, ptr %l104, !tbaa !23
  %t206 = sext i32 %t205 to i64
  store i64 %t206, ptr %l12, !tbaa !24
  %t208 = load ptr, ptr %l4, !tbaa !29
  %t210 = getelementptr %"compiler/check:frame", ptr %t208, i32 0, i32 8
  %t211 = load i32, ptr %l2, !tbaa !23
  %t212 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %t210, i32 %t211, i64 %t212)
  br label %bb34
bb34:
  %t216 = load ptr, ptr %l4, !tbaa !29
  %t218 = getelementptr %"compiler/check:frame", ptr %t216, i32 0, i32 28
  store ptr %t218, ptr %l111, !tbaa !29
  %t219 = load i64, ptr %l12, !tbaa !24
  %t221 = trunc i64 %t219 to i32
  store i32 %t221, ptr %l114, !tbaa !23
  %t223 = load ptr, ptr %l10, !tbaa !29
  %t225 = icmp eq ptr %t223, null
  br i1 %t225, label %bb35, label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_486b3db7a819736b_b4c2afa2fe5bd5af)
  unreachable
bb36:
  br label %bb37
bb37:
  %t227 = load ptr, ptr %l10, !tbaa !29
  %t228 = load i32, ptr %l114, !tbaa !23
  %t230 = call %"compiler/typed:Capture" @compiler_2ftyped_3aCapture_2ector(ptr %v0, ptr %v0, i32 %t228, ptr %t227)
  store %"compiler/typed:Capture" %t230, ptr %l118
  br label %bb38
bb38:
  %t231 = load %"compiler/typed:Capture", ptr %l118
  %t232 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store %"compiler/typed:Capture" %t231, ptr %t232
  %t233 = load ptr, ptr %l111, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aCapture_26_3e_2ePus_Hdab9bd3c8945274d6e7197d4fb29356b(ptr %v0, ptr %v0, ptr %t233, ptr %t232)
  br label %bb39
bb39:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load i32, ptr %l9, !tbaa !23
  %t239 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t235, i32 %t236)
  store i1 %t239, ptr %l122
  br label %bb40
bb40:
  %t240 = load i1, ptr %l122, !tbaa !21
  br i1 %t240, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l123, !tbaa !21
  br label %bb44
bb42:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr %"compiler/check:Checker", ptr %t241, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !29
  %t246 = getelementptr %"compiler/generic:Program", ptr %t244, i32 0, i32 2
  %t247 = load i32, ptr %l9, !tbaa !23
  %t250 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t246, i32 %t247)
  store i1 %t250, ptr %l128
  br label %bb43
bb43:
  %t251 = load i1, ptr %l128, !tbaa !21
  store i1 %t251, ptr %l123, !tbaa !21
  br label %bb44
bb44:
  %t252 = load i1, ptr %l123, !tbaa !21
  br i1 %t252, label %bb45, label %bb46
bb45:
  %t253 = load ptr, ptr %l11, !tbaa !29
  %t255 = getelementptr %"compiler/typed:Body", ptr %t253, i32 0, i32 6
  %t256 = load i64, ptr %l12, !tbaa !24
  %t258 = trunc i64 %t256 to i32
  store { i64, [1 x i64] } zeroinitializer, ptr %t260
  %t261 = getelementptr { i64, [1 x i64] }, ptr %t260, i32 0, i32 0
  store i64 4, ptr %t261
  %t263 = insertvalue { i32 } undef, i32 %t258, 0
  %t264 = getelementptr { i64, [1 x i64] }, ptr %t260, i32 0, i32 1
  store { i32 } %t263, ptr %t264
  %t265 = load { i64, [1 x i64] }, ptr %t260
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2ePush_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t255, { i64, [1 x i64] } %t265)
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb48
bb48:
  %t268 = load i64, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t268, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/generic:Desc" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseDesc(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca i32
  %l11 = alloca %"compiler/generic:Desc"
  %l15 = alloca %"compiler/generic:Desc"
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/generic:Desc"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %t1, ptr %a1)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load i32, ptr %l2, !tbaa !23
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t11 = icmp sle i32 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t13 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescNone, !tbaa !24
  %t14 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t17 = call %"compiler/generic:Desc" @compiler_2fgeneric_3aDesc_2ector(ptr %s1, i64 %t13, i32 %t14, i64 0, i64 0)
  store %"compiler/generic:Desc" %t17, ptr %l11
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  %t18 = load %"compiler/generic:Desc", ptr %l11
  store %"compiler/generic:Desc" %t18, ptr %rv
  br label %ret
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t23 = load i32, ptr %l2, !tbaa !23
  %t26 = call %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %t22, i32 %t23)
  store %"compiler/generic:Desc" %t26, ptr %l15
  br label %bb6
bb6:
  %t27 = load %"compiler/generic:Desc", ptr %l15
  store %"compiler/generic:Desc" %t27, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/generic:Desc", ptr %rv
  ret %"compiler/generic:Desc" %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca i32
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca { i64, i32 }
  %l28 = alloca i64
  %l29 = alloca i32
  %l34 = alloca i1
  %l36 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l42 = alloca i1
  %l44 = alloca ptr
  %l46 = alloca ptr
  %l50 = alloca i32
  %l55 = alloca i32
  %l60 = alloca ptr
  %l65 = alloca i32
  %l66 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l80 = alloca i32
  %l87 = alloca i64
  %l91 = alloca i64
  %l94 = alloca i64
  %l113 = alloca i64
  %l117 = alloca ptr
  %l122 = alloca i32
  %l124 = alloca %"compiler/typed:Item"
  %l131 = alloca i32
  %l134 = alloca ptr
  %l136 = alloca %"compiler/typed:Item"
  %l142 = alloca i1
  %l144 = alloca ptr
  %l146 = alloca ptr
  %l150 = alloca i32
  %l157 = alloca i1
  %l159 = alloca ptr
  %l161 = alloca %"compiler/typed:Item"
  %l162 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l168 = alloca i64
  %l170 = alloca i64
  %l175 = alloca i32
  %l183 = alloca i32
  %l187 = alloca ptr
  %l189 = alloca %"compiler/typed:Item"
  %l194 = alloca i64
  %l198 = alloca i64
  %l201 = alloca i64
  %l220 = alloca i64
  %l224 = alloca ptr
  %l229 = alloca i32
  %l231 = alloca %"compiler/typed:Item"
  %l238 = alloca { i64, i32 }
  %l244 = alloca ptr
  %l246 = alloca ptr
  %l250 = alloca i1
  %l251 = alloca ptr
  %l254 = alloca %"compiler/typed:Item"
  %s0 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s22 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Path", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 1
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t10)
  store ptr %t12, ptr %l36
  br label %bb3
bb2:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb5
bb3:
  %t13 = load ptr, ptr %l36, !tbaa !29
  %t15 = getelementptr %"compiler/check:frame", ptr %t13, i32 0, i32 4
  %t16 = getelementptr %"compiler/generic:Context", ptr %t15, i32 0, i32 2
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr %"compiler/ast:Path", ptr %t17, i32 0, i32 1
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l40, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr i32, ptr %t22, i64 0
  %t24 = load i32, ptr %t23, !tbaa !33
  %t27 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_He6be2b0836caba7ddc59483ff74db438(ptr %v0, ptr %t16, i32 %t24)
  store i1 %t27, ptr %l42
  br label %bb4
bb4:
  %t28 = load i1, ptr %l42, !tbaa !21
  store i1 %t28, ptr %l34, !tbaa !21
  br label %bb5
bb5:
  %t29 = load i1, ptr %l34, !tbaa !21
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  store ptr %t33, ptr %l44, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t34)
  store ptr %t36, ptr %l46
  br label %bb8
bb7:
  br label %bb55
bb8:
  %t37 = load ptr, ptr %l46, !tbaa !29
  %t39 = getelementptr %"compiler/check:frame", ptr %t37, i32 0, i32 4
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t41 = load ptr, ptr %l44, !tbaa !29
  %t44 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorSetItem(ptr %v0, ptr %v0, ptr %v1, ptr %t41, ptr %t39, ptr %t40)
  store i32 %t44, ptr %l50
  br label %bb9
bb9:
  %t45 = load i32, ptr %l50, !tbaa !23
  store i32 %t45, ptr %l3, !tbaa !23
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 2
  %t52 = load i32, ptr %l3, !tbaa !23
  %t55 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t51, i32 %t52)
  store i32 %t55, ptr %l55
  br label %bb10
bb10:
  %t56 = load i32, ptr %l55, !range !{i32 0, i32 33}
  %t58 = trunc i64 30 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb11, label %bb12
bb11:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/check:Checker", ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = getelementptr %"compiler/generic:Program", ptr %t64, i32 0, i32 2
  store ptr %t66, ptr %l60, !tbaa !29
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Program", ptr %t70, i32 0, i32 2
  %t73 = load i32, ptr %l3, !tbaa !23
  %t76 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %t72, i32 %t73)
  store i32 %t76, ptr %l65
  br label %bb13
bb12:
  br label %bb50
bb13:
  %t77 = load ptr, ptr %l60, !tbaa !29
  %t78 = load i32, ptr %l65, !tbaa !23
  %t79 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t77, i32 %t78)
  store { i64, ptr } %t79, ptr %l66
  br label %bb14
bb14:
  %t80 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t80, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t81 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t81, 0
  store i64 %t83, ptr %l6, !tbaa !24
  br label %bb15
bb15:
  %t85 = load i64, ptr %l5, !tbaa !24
  %t86 = load i64, ptr %l6, !tbaa !24
  %t89 = icmp slt i64 %t85, %t86
  %t91 = xor i1 %t89, true
  br i1 %t91, label %bb16, label %bb17
bb16:
  br label %bb49
bb17:
  br label %bb18
bb18:
  %t93 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t93, ptr %l73, !tbaa !27
  %t94 = load i64, ptr %l5, !tbaa !24
  %t96 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr i32, ptr %t97, i64 %t94
  %t99 = load i32, ptr %t98, !tbaa !33
  store i32 %t99, ptr %l7, !tbaa !23
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/check:Checker", ptr %t101, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = getelementptr %"compiler/generic:Program", ptr %t104, i32 0, i32 2
  %t107 = load i32, ptr %l7, !tbaa !23
  %t110 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t106, i32 %t107)
  store i32 %t110, ptr %l80
  br label %bb19
bb19:
  %t111 = load i32, ptr %l80, !range !{i32 0, i32 33}
  %t113 = trunc i64 28 to i32
  %t114 = icmp eq i32 %t111, %t113
  br i1 %t114, label %bb20, label %bb21
bb20:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/check:Checker", ptr %t116, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t121 = getelementptr %"compiler/generic:Program", ptr %t119, i32 0, i32 2
  %t122 = load i32, ptr %l7, !tbaa !23
  %t125 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t121, i32 %t122)
  store i64 %t125, ptr %l87
  br label %bb22
bb21:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/check:Checker", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/generic:Program", ptr %t129, i32 0, i32 2
  %t132 = load i32, ptr %l7, !tbaa !23
  %t135 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t131, i32 %t132)
  store i32 %t135, ptr %l131
  br label %bb41
bb22:
  %t136 = load i64, ptr %l87, !tbaa !65
  store i64 %t136, ptr %l8, !tbaa !65
  store i64 0, ptr %l9, !tbaa !24
  store i64 64, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t137 = load i64, ptr %l10, !tbaa !24
  %t138 = load i64, ptr %l9, !tbaa !24
  %t141 = icmp sgt i64 %t137, %t138
  br i1 %t141, label %bb23, label %bb24
bb23:
  %t143 = load i64, ptr %l11, !tbaa !24
  %t145 = icmp sgt i64 %t143, 0
  br i1 %t145, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l91, !tbaa !24
  br label %bb28
bb25:
  %t147 = load i64, ptr %l10, !tbaa !24
  %t148 = load i64, ptr %l9, !tbaa !24
  %t151 = sub i64 %t147, %t148
  %t152 = load i64, ptr %l11, !tbaa !24
  %t155 = add i64 %t151, %t152
  %t157 = sub i64 %t155, 1
  %t158 = load i64, ptr %l11, !tbaa !24
  %t161 = sdiv i64 %t157, %t158
  store i64 %t161, ptr %l94, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l94, !tbaa !24
  br label %bb27
bb27:
  %t163 = load i64, ptr %l94, !tbaa !24
  store i64 %t163, ptr %l91, !tbaa !24
  br label %bb28
bb28:
  %t164 = load i64, ptr %l91, !tbaa !24
  store i64 %t164, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb29
bb29:
  %t165 = load i64, ptr %l13, !tbaa !24
  %t166 = load i64, ptr %l12, !tbaa !24
  %t169 = icmp slt i64 %t165, %t166
  %t171 = xor i1 %t169, true
  br i1 %t171, label %bb30, label %bb31
bb30:
  br label %bb40
bb31:
  br label %bb32
bb32:
  %t173 = load i64, ptr %l9, !tbaa !24
  %t174 = load i64, ptr %l13, !tbaa !24
  %t175 = load i64, ptr %l11, !tbaa !24
  %t178 = mul i64 %t174, %t175
  %t181 = add i64 %t173, %t178
  store i64 %t181, ptr %l14, !tbaa !24
  %t183 = load i64, ptr %l8, !tbaa !65
  %t184 = load i64, ptr %l14, !tbaa !24
  store i64 %t184, ptr %l113, !tbaa !24
  %t185 = load i64, ptr %l113, !tbaa !24
  %t186 = load i64, ptr %l113, !tbaa !24
  %t187 = shl i64 1, %t186
  %t190 = and i64 %t183, %t187
  %t192 = icmp ne i64 %t190, 0
  br i1 %t192, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s8
  %t194 = load ptr, ptr %l2, !tbaa !29
  store ptr %t194, ptr %l117, !tbaa !29
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/check:Checker", ptr %t195, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !29
  %t200 = getelementptr %"compiler/generic:Program", ptr %t198, i32 0, i32 2
  %t201 = load i32, ptr %l7, !tbaa !23
  %t204 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t200, i32 %t201)
  store i32 %t204, ptr %l122
  br label %bb35
bb34:
  br label %bb38
bb35:
  %t205 = load i64, ptr %l14, !tbaa !24
  %t206 = load i32, ptr %l122, !tbaa !23
  %t208 = call %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %s8, i32 %t206, i64 %t205)
  store %"compiler/typed:Item" %t208, ptr %l124
  br label %bb36
bb36:
  %t209 = load ptr, ptr %l117, !tbaa !29
  %t210 = load %"compiler/typed:Item", ptr %l124
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v2, ptr %t209, %"compiler/typed:Item" %t210)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s8)
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t211 = load i64, ptr %l13, !tbaa !24
  %t213 = add i64 %t211, 1
  store i64 %t213, ptr %l13, !tbaa !24
  br label %bb29
bb40:
  br label %bb47
bb41:
  %t215 = load i32, ptr %l131, !range !{i32 0, i32 33}
  %t217 = trunc i64 18 to i32
  %t218 = icmp eq i32 %t215, %t217
  br i1 %t218, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s11
  %t220 = load ptr, ptr %l2, !tbaa !29
  store ptr %t220, ptr %l134, !tbaa !29
  %t221 = load i32, ptr %l7, !tbaa !23
  %t223 = call %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %s11, i32 %t221, i64 -1)
  store %"compiler/typed:Item" %t223, ptr %l136
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t224 = load ptr, ptr %l134, !tbaa !29
  %t225 = load %"compiler/typed:Item", ptr %l136
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v2, ptr %t224, %"compiler/typed:Item" %t225)
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s11)
  br label %bb46
bb46:
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t226 = load i64, ptr %l5, !tbaa !24
  %t228 = add i64 %t226, 1
  store i64 %t228, ptr %l5, !tbaa !24
  br label %bb15
bb49:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb50:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t232 = getelementptr %"compiler/check:Checker", ptr %t230, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !29
  %t234 = load i32, ptr %l3, !tbaa !23
  %t237 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsErrVar(ptr %v0, ptr %t233, i32 %t234)
  store i1 %t237, ptr %l142
  br label %bb51
bb51:
  %t238 = load i1, ptr %l142, !tbaa !21
  br i1 %t238, label %bb52, label %bb53
bb52:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb53:
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"compiler/check:Checker", ptr %t239, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !29
  store ptr %t242, ptr %l144, !tbaa !29
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t245 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t243)
  store ptr %t245, ptr %l146
  br label %bb56
bb56:
  %t246 = load ptr, ptr %l146, !tbaa !29
  %t248 = getelementptr %"compiler/check:frame", ptr %t246, i32 0, i32 4
  %t249 = load ptr, ptr %l1, !tbaa !29
  %t250 = load ptr, ptr %l144, !tbaa !29
  %t253 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorType(ptr %v0, ptr %v0, ptr %v1, ptr %t250, ptr %t248, ptr %t249)
  store i32 %t253, ptr %l150
  br label %bb57
bb57:
  %t254 = load i32, ptr %l150, !tbaa !23
  store i32 %t254, ptr %l15, !tbaa !23
  %t255 = load i32, ptr %l15, !tbaa !23
  %t256 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t259 = icmp ne i32 %t255, %t256
  br i1 %t259, label %bb58, label %bb59
bb58:
  store %olang.scope zeroinitializer, ptr %s14
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"compiler/check:Checker", ptr %t261, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !29
  %t265 = load i32, ptr %l15, !tbaa !23
  %t268 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsErrorSet(ptr %v0, ptr %t264, i32 %t265)
  store i1 %t268, ptr %l157
  br label %bb60
bb59:
  br label %bb104
bb60:
  %t269 = load i1, ptr %l157, !tbaa !21
  %t270 = xor i1 %t269, true
  br i1 %t270, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s15
  %t272 = load ptr, ptr %l2, !tbaa !29
  store ptr %t272, ptr %l159, !tbaa !29
  %t273 = load i32, ptr %l15, !tbaa !23
  %t275 = call %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %s15, i32 %t273, i64 -1)
  store %"compiler/typed:Item" %t275, ptr %l161
  br label %bb63
bb62:
  br label %bb65
bb63:
  %t276 = load ptr, ptr %l159, !tbaa !29
  %t277 = load %"compiler/typed:Item", ptr %l161
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v2, ptr %t276, %"compiler/typed:Item" %t277)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb65:
  %t278 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s14, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t278, ptr %l162
  br label %bb66
bb66:
  %t279 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l162
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t279, ptr %l16
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = getelementptr %"compiler/check:Checker", ptr %t280, i32 0, i32 1
  %t283 = load ptr, ptr %t282, !tbaa !29
  %t284 = load i32, ptr %l15, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eEntriesOf(ptr %v0, ptr %s14, ptr %t283, i32 %t284, ptr %l16)
  br label %bb67
bb67:
  store ptr %l16, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb68
bb68:
  %t289 = load i64, ptr %l18, !tbaa !24
  store i64 %t289, ptr %l168, !tbaa !24
  %t290 = load ptr, ptr %l17, !tbaa !29
  %t292 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s14, ptr %t290)
  store i64 %t292, ptr %l170
  br label %bb69
bb69:
  %t293 = load i64, ptr %l168, !tbaa !24
  %t294 = load i64, ptr %l170, !tbaa !24
  %t295 = icmp slt i64 %t293, %t294
  %t297 = xor i1 %t295, true
  br i1 %t297, label %bb70, label %bb71
bb70:
  br label %bb103
bb71:
  br label %bb72
bb72:
  %t299 = load ptr, ptr %l17, !tbaa !29
  %t300 = load i64, ptr %l18, !tbaa !24
  %t303 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s14, ptr %t299, i64 %t300)
  store i32 %t303, ptr %l175
  br label %bb73
bb73:
  %t304 = load i32, ptr %l175, !tbaa !23
  store i32 %t304, ptr %l19, !tbaa !23
  %t305 = load i32, ptr %l19, !tbaa !23
  %t306 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t309 = icmp eq i32 %t305, %t306
  br i1 %t309, label %bb74, label %bb75
bb74:
  br label %bb102
bb75:
  br label %bb76
bb76:
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t313 = getelementptr %"compiler/check:Checker", ptr %t311, i32 0, i32 1
  %t314 = load ptr, ptr %t313, !tbaa !29
  %t316 = getelementptr %"compiler/generic:Program", ptr %t314, i32 0, i32 2
  %t317 = load i32, ptr %l19, !tbaa !23
  %t320 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t316, i32 %t317)
  store i32 %t320, ptr %l183
  br label %bb77
bb77:
  %t321 = load i32, ptr %l183, !range !{i32 0, i32 33}
  %t323 = trunc i64 28 to i32
  %t324 = icmp eq i32 %t321, %t323
  %t326 = xor i1 %t324, true
  br i1 %t326, label %bb78, label %bb79
bb78:
  store %olang.scope zeroinitializer, ptr %s19
  %t328 = load ptr, ptr %l2, !tbaa !29
  store ptr %t328, ptr %l187, !tbaa !29
  %t329 = load i32, ptr %l19, !tbaa !23
  %t331 = call %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %s19, i32 %t329, i64 -1)
  store %"compiler/typed:Item" %t331, ptr %l189
  br label %bb80
bb79:
  br label %bb82
bb80:
  %t332 = load ptr, ptr %l187, !tbaa !29
  %t333 = load %"compiler/typed:Item", ptr %l189
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v2, ptr %t332, %"compiler/typed:Item" %t333)
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s19)
  br label %bb102
bb82:
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t336 = getelementptr %"compiler/check:Checker", ptr %t334, i32 0, i32 1
  %t337 = load ptr, ptr %t336, !tbaa !29
  %t339 = getelementptr %"compiler/generic:Program", ptr %t337, i32 0, i32 2
  %t340 = load i32, ptr %l19, !tbaa !23
  %t343 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t339, i32 %t340)
  store i64 %t343, ptr %l194
  br label %bb83
bb83:
  %t344 = load i64, ptr %l194, !tbaa !65
  store i64 %t344, ptr %l20, !tbaa !65
  store i64 0, ptr %l21, !tbaa !24
  store i64 64, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t345 = load i64, ptr %l22, !tbaa !24
  %t346 = load i64, ptr %l21, !tbaa !24
  %t349 = icmp sgt i64 %t345, %t346
  br i1 %t349, label %bb84, label %bb85
bb84:
  %t351 = load i64, ptr %l23, !tbaa !24
  %t353 = icmp sgt i64 %t351, 0
  br i1 %t353, label %bb86, label %bb87
bb85:
  store i64 0, ptr %l198, !tbaa !24
  br label %bb89
bb86:
  %t355 = load i64, ptr %l22, !tbaa !24
  %t356 = load i64, ptr %l21, !tbaa !24
  %t359 = sub i64 %t355, %t356
  %t360 = load i64, ptr %l23, !tbaa !24
  %t363 = add i64 %t359, %t360
  %t365 = sub i64 %t363, 1
  %t366 = load i64, ptr %l23, !tbaa !24
  %t369 = sdiv i64 %t365, %t366
  store i64 %t369, ptr %l201, !tbaa !24
  br label %bb88
bb87:
  store i64 0, ptr %l201, !tbaa !24
  br label %bb88
bb88:
  %t371 = load i64, ptr %l201, !tbaa !24
  store i64 %t371, ptr %l198, !tbaa !24
  br label %bb89
bb89:
  %t372 = load i64, ptr %l198, !tbaa !24
  store i64 %t372, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb90
bb90:
  %t373 = load i64, ptr %l25, !tbaa !24
  %t374 = load i64, ptr %l24, !tbaa !24
  %t377 = icmp slt i64 %t373, %t374
  %t379 = xor i1 %t377, true
  br i1 %t379, label %bb91, label %bb92
bb91:
  br label %bb101
bb92:
  br label %bb93
bb93:
  %t381 = load i64, ptr %l21, !tbaa !24
  %t382 = load i64, ptr %l25, !tbaa !24
  %t383 = load i64, ptr %l23, !tbaa !24
  %t386 = mul i64 %t382, %t383
  %t389 = add i64 %t381, %t386
  store i64 %t389, ptr %l26, !tbaa !24
  %t391 = load i64, ptr %l20, !tbaa !65
  %t392 = load i64, ptr %l26, !tbaa !24
  store i64 %t392, ptr %l220, !tbaa !24
  %t393 = load i64, ptr %l220, !tbaa !24
  %t394 = load i64, ptr %l220, !tbaa !24
  %t395 = shl i64 1, %t394
  %t398 = and i64 %t391, %t395
  %t400 = icmp ne i64 %t398, 0
  br i1 %t400, label %bb94, label %bb95
bb94:
  store %olang.scope zeroinitializer, ptr %s22
  %t402 = load ptr, ptr %l2, !tbaa !29
  store ptr %t402, ptr %l224, !tbaa !29
  %t403 = load ptr, ptr %l0, !tbaa !29
  %t405 = getelementptr %"compiler/check:Checker", ptr %t403, i32 0, i32 1
  %t406 = load ptr, ptr %t405, !tbaa !29
  %t408 = getelementptr %"compiler/generic:Program", ptr %t406, i32 0, i32 2
  %t409 = load i32, ptr %l19, !tbaa !23
  %t412 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t408, i32 %t409)
  store i32 %t412, ptr %l229
  br label %bb96
bb95:
  br label %bb99
bb96:
  %t413 = load i64, ptr %l26, !tbaa !24
  %t414 = load i32, ptr %l229, !tbaa !23
  %t416 = call %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %s22, i32 %t414, i64 %t413)
  store %"compiler/typed:Item" %t416, ptr %l231
  br label %bb97
bb97:
  %t417 = load ptr, ptr %l224, !tbaa !29
  %t418 = load %"compiler/typed:Item", ptr %l231
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v2, ptr %t417, %"compiler/typed:Item" %t418)
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s22)
  br label %bb99
bb99:
  br label %bb100
bb100:
  %t419 = load i64, ptr %l25, !tbaa !24
  %t421 = add i64 %t419, 1
  store i64 %t421, ptr %l25, !tbaa !24
  br label %bb90
bb101:
  br label %bb102
bb102:
  %t423 = load i64, ptr %l18, !tbaa !24
  %t425 = add i64 %t423, 1
  store i64 %t425, ptr %l18, !tbaa !24
  br label %bb68
bb103:
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb104:
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t428 = load ptr, ptr %l1, !tbaa !29
  %t431 = call { i64, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorWord(ptr %v0, ptr %v1, ptr %t427, ptr %t428)
  store { i64, i32 } %t431, ptr %l238
  br label %bb105
bb105:
  %t432 = load { i64, i32 }, ptr %l238
  store { i64, i32 } %t432, ptr %l27
  %t433 = getelementptr { i64, i32 }, ptr %l27, i32 0, i32 0
  %t434 = load i64, ptr %t433, !tbaa !24
  store i64 %t434, ptr %l28, !tbaa !24
  %t436 = getelementptr { i64, i32 }, ptr %l27, i32 0, i32 1
  %t437 = load i32, ptr %t436, !tbaa !23
  store i32 %t437, ptr %l29, !tbaa !23
  %t439 = load i64, ptr %l28, !tbaa !24
  %t441 = icmp slt i64 %t439, 0
  br i1 %t441, label %bb106, label %bb107
bb106:
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t445 = getelementptr %"compiler/check:Checker", ptr %t443, i32 0, i32 1
  %t446 = load ptr, ptr %t445, !tbaa !29
  store ptr %t446, ptr %l244, !tbaa !29
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t449 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t447)
  store ptr %t449, ptr %l246
  br label %bb108
bb107:
  br label %bb110
bb108:
  %t450 = load ptr, ptr %l246, !tbaa !29
  %t452 = getelementptr %"compiler/check:frame", ptr %t450, i32 0, i32 4
  %t453 = load ptr, ptr %l1, !tbaa !29
  %t454 = load ptr, ptr %l244, !tbaa !29
  %t457 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorItemKnown(ptr %v0, ptr %v0, ptr %v1, ptr %t454, ptr %t452, ptr %t453)
  store i1 %t457, ptr %l250
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb110:
  %t458 = load ptr, ptr %l2, !tbaa !29
  store ptr %t458, ptr %l251, !tbaa !29
  %t459 = load i32, ptr %l29, !tbaa !23
  %t460 = load i64, ptr %l28, !tbaa !24
  %t463 = call %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %s0, i32 %t459, i64 %t460)
  store %"compiler/typed:Item" %t463, ptr %l254
  br label %bb111
bb111:
  %t464 = load ptr, ptr %l251, !tbaa !29
  %t465 = load %"compiler/typed:Item", ptr %l254
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v2, ptr %t464, %"compiler/typed:Item" %t465)
  br label %bb112
bb112:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i32, i1 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtCases(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca i1
  %l7 = alloca i32
  %l8 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca i1
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca i1
  %l28 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l29 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l35 = alloca %"compiler/source:Span"
  %l36 = alloca { i64, ptr }
  %l41 = alloca i32
  %l44 = alloca ptr
  %l45 = alloca i32
  %l48 = alloca ptr
  %l49 = alloca ptr
  %l52 = alloca i64
  %l53 = alloca i32
  %l54 = alloca i32
  %l55 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l58 = alloca i64
  %l60 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca i32
  %l66 = alloca i1
  %l70 = alloca i64
  %l74 = alloca ptr
  %l77 = alloca ptr
  %l81 = alloca i32
  %l82 = alloca i32
  %l83 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l87 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l96 = alloca i64
  %l99 = alloca i64
  %l118 = alloca { i64, ptr }
  %l122 = alloca i1
  %l126 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l128 = alloca i64
  %l130 = alloca i1
  %l132 = alloca ptr
  %l134 = alloca %"compiler/source:Span"
  %l136 = alloca %"compiler/msgs:Msg"
  %l137 = alloca i64
  %l138 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l147 = alloca { i64, ptr }
  %l150 = alloca ptr
  %l151 = alloca i1
  %l161 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l162 = alloca ptr
  %l163 = alloca i1
  %l168 = alloca ptr
  %l169 = alloca i1
  %l175 = alloca i1
  %l178 = alloca ptr
  %l180 = alloca %"compiler/source:Span"
  %l182 = alloca %"compiler/msgs:Msg"
  %l183 = alloca i64
  %l184 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l187 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l188 = alloca i32
  %l190 = alloca i1
  %l191 = alloca ptr
  %l193 = alloca %"compiler/source:Span"
  %l194 = alloca %"compiler/msgs:Msg"
  %l195 = alloca i64
  %l199 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l201 = alloca i64
  %l203 = alloca ptr
  %l205 = alloca %"compiler/source:Span"
  %l206 = alloca { i64, ptr }
  %l209 = alloca { i64, ptr }
  %l210 = alloca { i64, ptr }
  %l213 = alloca { i64, ptr }
  %l215 = alloca %"compiler/msgs:Msg"
  %l216 = alloca i64
  %l221 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l222 = alloca ptr
  %l224 = alloca %"compiler/source:Span"
  %l225 = alloca %"compiler/msgs:Msg"
  %l226 = alloca i64
  %l232 = alloca ptr
  %l234 = alloca ptr
  %l238 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l240 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l245 = alloca i1
  %l249 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l251 = alloca i64
  %l253 = alloca i1
  %l256 = alloca i1
  %l262 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l264 = alloca i64
  %l266 = alloca { i64, ptr }
  %l269 = alloca { i64, ptr }
  %l272 = alloca i64
  %l274 = alloca i1
  %l280 = alloca ptr
  %l284 = alloca %"compiler/source:Span"
  %l286 = alloca %"compiler/msgs:Msg"
  %l287 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %rv = alloca { i32, i1 }
  %t100 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l31
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l31, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l32, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"compiler/ast:Match", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t9)
  store %"compiler/source:Span" %t11, ptr %l35
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l32, !tbaa !29
  %t13 = load %"compiler/source:Span", ptr %l35
  %t14 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t12, %"compiler/source:Span" %t13)
  store { i64, ptr } %t14, ptr %l36
  br label %bb3
bb3:
  %t15 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t17 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = add i64 %t16, %t19
  %t21 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t23 = add i64 %t20, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t15, i64 %t16)
  %t25 = getelementptr i8, ptr %t24, i64 %t16
  call void @olang_textcopy(ptr %t25, ptr %t18, i64 %t19)
  %t26 = getelementptr i8, ptr %t25, i64 %t19
  call void @olang_textcopy(ptr %t26, ptr %t21, i64 %t22)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t24, 1
  store { i64, ptr } %t28, ptr %l4, !tbaa !27
  store i1 true, ptr %l6, !tbaa !21
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr %"compiler/ast:Match", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t37 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrLocalName(ptr %v0, ptr %v1, ptr %t30, ptr %t34)
  store i32 %t37, ptr %l41
  br label %bb4
bb4:
  %t38 = load i32, ptr %l41, !tbaa !23
  store i32 %t38, ptr %l7, !tbaa !23
  %t39 = load i32, ptr %l7, !tbaa !23
  %t41 = icmp ne i32 %t39, 0
  br i1 %t41, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l44, !tbaa !29
  %t44 = load i32, ptr %l7, !tbaa !23
  store i32 %t44, ptr %l45, !tbaa !23
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = getelementptr %"compiler/generic:Program", ptr %t48, i32 0, i32 2
  store ptr %t50, ptr %l48, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l49, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i32, ptr %l7, !tbaa !23
  %t56 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t52, i32 %t53)
  store i64 %t56, ptr %l52
  br label %bb7
bb6:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l74, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = getelementptr %"compiler/generic:Program", ptr %t61, i32 0, i32 2
  store ptr %t63, ptr %l77, !tbaa !29
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l3, !tbaa !29
  %t67 = getelementptr %"compiler/check:frame", ptr %t65, i32 0, i32 58
  %t68 = load i64, ptr %t67, !tbaa !24
  %t71 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t64, i64 %t68)
  store i32 %t71, ptr %l81
  br label %bb25
bb7:
  %t72 = load ptr, ptr %l49, !tbaa !29
  %t73 = load i64, ptr %l52, !tbaa !24
  %t74 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t72, i64 %t73)
  store i32 %t74, ptr %l53
  br label %bb8
bb8:
  %t75 = load ptr, ptr %l48, !tbaa !29
  %t76 = load i32, ptr %l53, !tbaa !23
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t75, i32 %t76)
  store i32 %t77, ptr %l54
  br label %bb9
bb9:
  %t78 = load ptr, ptr %l44, !tbaa !29
  %t79 = load i32, ptr %l45, !tbaa !23
  %t80 = load i32, ptr %l54, !tbaa !23
  %t81 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrNow(ptr %v0, ptr %s0, ptr %t78, i32 %t79, i32 %t80)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t81, ptr %l55
  br label %bb10
bb10:
  %t82 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l55
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t82, ptr %l5
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i32, ptr %l7, !tbaa !23
  %t87 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtNamed(ptr %v0, ptr %t83, i32 %t84)
  store i64 %t87, ptr %l58
  br label %bb11
bb11:
  %t88 = load i64, ptr %l58, !tbaa !24
  %t89 = icmp slt i64 %t88, 0
  br i1 %t89, label %bb12, label %bb13
bb12:
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l61, !tbaa !29
  %t92 = load i32, ptr %l7, !tbaa !23
  store i32 %t92, ptr %l62, !tbaa !23
  %t93 = icmp sge i64 1, 0
  br i1 %t93, label %bb14, label %bb15
bb13:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb19
bb14:
  %t95 = icmp sle i64 1, 2305843009213693951
  br i1 %t95, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_fc394d3abb705b3d_774ad654d23301b9)
  unreachable
bb16:
  %t97 = mul i64 1, 4
  %t98 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t97)
  %t99 = load i32, ptr %l62, !tbaa !23
  store i64 0, ptr %t100
  br label %fill.101
fill.101:
  %t104 = load i64, ptr %t100
  %t105 = icmp slt i64 %t104, 1
  br i1 %t105, label %fillb.102, label %filld.103
fillb.102:
  %t106 = getelementptr i32, ptr %t98, i64 %t104
  store i32 %t99, ptr %t106
  %t107 = add i64 %t104, 1
  store i64 %t107, ptr %t100
  br label %fill.101
filld.103:
  %t108 = insertvalue { i64, ptr } undef, i64 1, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t98, 1
  %t110 = load ptr, ptr %l61, !tbaa !29
  %t112 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullKnown(ptr %v0, ptr %s2, ptr %t110, { i64, ptr } %t109)
  store i1 %t112, ptr %l66
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_fc394d3abb705b3d_774ad654d23301b9)
  unreachable
bb18:
  %t113 = load i1, ptr %l66, !tbaa !21
  %t114 = xor i1 %t113, true
  store i1 %t114, ptr %l60, !tbaa !21
  br label %bb19
bb19:
  %t116 = load i1, ptr %l60, !tbaa !21
  store i1 %t116, ptr %l6, !tbaa !21
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i32, ptr %l7, !tbaa !23
  %t121 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtNamed(ptr %v0, ptr %t117, i32 %t118)
  store i64 %t121, ptr %l70
  br label %bb20
bb20:
  %t122 = load i64, ptr %l70, !tbaa !24
  %t123 = icmp sge i64 %t122, 0
  br i1 %t123, label %bb21, label %bb22
bb21:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load i32, ptr %l7, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtUsed(ptr %v0, ptr %t125, i32 %t126)
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb25:
  %t129 = load ptr, ptr %l77, !tbaa !29
  %t130 = load i32, ptr %l81, !tbaa !23
  %t131 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t129, i32 %t130)
  store i32 %t131, ptr %l82
  br label %bb26
bb26:
  %t132 = load ptr, ptr %l74, !tbaa !29
  %t133 = load i32, ptr %l82, !tbaa !23
  %t134 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetItems(ptr %v0, ptr %s0, ptr %t132, i32 %t133)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t134, ptr %l83
  br label %bb27
bb27:
  %t135 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l83
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t135, ptr %l5
  %t136 = load ptr, ptr %l3, !tbaa !29
  %t138 = getelementptr %"compiler/check:frame", ptr %t136, i32 0, i32 59
  %t139 = load i1, ptr %t138, !tbaa !21
  %t141 = xor i1 %t139, true
  store i1 %t141, ptr %l6, !tbaa !21
  br label %bb28
bb28:
  %t143 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t143, ptr %l87
  br label %bb29
bb29:
  %t144 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l87
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t144, ptr %l8
  %t145 = load i1, ptr %l6, !tbaa !21
  %t147 = xor i1 %t145, true
  store i1 %t147, ptr %l9, !tbaa !21
  store i1 true, ptr %l10, !tbaa !21
  store i1 false, ptr %l11, !tbaa !21
  store i64 0, ptr %l12, !tbaa !24
  %t149 = load ptr, ptr %l2, !tbaa !29
  %t151 = getelementptr %"compiler/ast:Match", ptr %t149, i32 0, i32 3
  %t152 = load { i64, ptr }, ptr %t151, !tbaa !27
  %t154 = extractvalue { i64, ptr } %t152, 0
  store i64 %t154, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t156 = load i64, ptr %l13, !tbaa !24
  %t157 = load i64, ptr %l12, !tbaa !24
  %t160 = icmp sgt i64 %t156, %t157
  br i1 %t160, label %bb30, label %bb31
bb30:
  %t162 = load i64, ptr %l14, !tbaa !24
  %t164 = icmp sgt i64 %t162, 0
  br i1 %t164, label %bb32, label %bb33
bb31:
  store i64 0, ptr %l96, !tbaa !24
  br label %bb35
bb32:
  %t166 = load i64, ptr %l13, !tbaa !24
  %t167 = load i64, ptr %l12, !tbaa !24
  %t170 = sub i64 %t166, %t167
  %t171 = load i64, ptr %l14, !tbaa !24
  %t174 = add i64 %t170, %t171
  %t176 = sub i64 %t174, 1
  %t177 = load i64, ptr %l14, !tbaa !24
  %t180 = sdiv i64 %t176, %t177
  store i64 %t180, ptr %l99, !tbaa !24
  br label %bb34
bb33:
  store i64 0, ptr %l99, !tbaa !24
  br label %bb34
bb34:
  %t182 = load i64, ptr %l99, !tbaa !24
  store i64 %t182, ptr %l96, !tbaa !24
  br label %bb35
bb35:
  %t183 = load i64, ptr %l96, !tbaa !24
  store i64 %t183, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb36
bb36:
  store %olang.scope zeroinitializer, ptr %s6
  %t184 = load i64, ptr %l16, !tbaa !24
  %t185 = load i64, ptr %l15, !tbaa !24
  %t188 = icmp slt i64 %t184, %t185
  %t190 = xor i1 %t188, true
  br i1 %t190, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s6)
  br label %bb125
bb38:
  br label %bb39
bb39:
  %t192 = load i64, ptr %l12, !tbaa !24
  %t193 = load i64, ptr %l16, !tbaa !24
  %t194 = load i64, ptr %l14, !tbaa !24
  %t197 = mul i64 %t193, %t194
  %t200 = add i64 %t192, %t197
  %t202 = load ptr, ptr %l2, !tbaa !29
  %t204 = getelementptr %"compiler/ast:Match", ptr %t202, i32 0, i32 3
  %t205 = load { i64, ptr }, ptr %t204, !tbaa !27
  store { i64, ptr } %t205, ptr %l118, !tbaa !27
  %t208 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr ptr, ptr %t209, i64 %t200
  %t211 = load ptr, ptr %t210, !tbaa !39
  store ptr %t211, ptr %l18, !tbaa !29
  %t213 = load i1, ptr %l11, !tbaa !21
  br i1 %t213, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l122, !tbaa !21
  br label %bb47
bb41:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t219 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetLess(ptr %v0, ptr %s0, ptr %s0, ptr %s6, ptr %t215, ptr %l5, ptr %l8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t219, ptr %l126
  br label %bb42
bb42:
  %t220 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l126
  %t221 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t220, ptr %t221
  %t223 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s6, ptr %t221)
  store i64 %t223, ptr %l128
  br label %bb43
bb43:
  %t224 = load i64, ptr %l128, !tbaa !24
  %t225 = icmp eq i64 %t224, 0
  br i1 %t225, label %bb44, label %bb45
bb44:
  %t227 = load i1, ptr %l9, !tbaa !21
  store i1 %t227, ptr %l130, !tbaa !21
  br label %bb46
bb45:
  store i1 false, ptr %l130, !tbaa !21
  br label %bb46
bb46:
  %t229 = load i1, ptr %l130, !tbaa !21
  store i1 %t229, ptr %l122, !tbaa !21
  br label %bb47
bb47:
  %t230 = load i1, ptr %l122, !tbaa !21
  br i1 %t230, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s7
  %t231 = load ptr, ptr %l0, !tbaa !29
  store ptr %t231, ptr %l132, !tbaa !29
  %t232 = load ptr, ptr %l18, !tbaa !29
  %t234 = getelementptr %"compiler/ast:Case", ptr %t232, i32 0, i32 0
  %t235 = load %"compiler/source:Span", ptr %t234
  store %"compiler/source:Span" %t235, ptr %l134
  %t236 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t238 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtCaseNever(ptr %s0, ptr %s7, { i64, ptr } %t236)
  store %"compiler/msgs:Msg" %t238, ptr %l136
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t239 = load ptr, ptr %l132, !tbaa !29
  %t240 = load %"compiler/source:Span", ptr %l134
  %t241 = load %"compiler/msgs:Msg", ptr %l136
  %t242 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t239, %"compiler/source:Span" %t240, %"compiler/msgs:Msg" %t241)
  store i64 %t242, ptr %l137
  br label %bb51
bb51:
  store i1 false, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  br label %bb124
bb52:
  %t243 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s6, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t243, ptr %l138
  br label %bb53
bb53:
  %t244 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l138
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t244, ptr %l19
  store i1 false, ptr %l20, !tbaa !21
  %t245 = load ptr, ptr %l18, !tbaa !29
  %t247 = getelementptr %"compiler/ast:Case", ptr %t245, i32 0, i32 1
  %t248 = load { i64, ptr }, ptr %t247, !tbaa !27
  store { i64, ptr } %t248, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t250 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t250, 0
  store i64 %t252, ptr %l23, !tbaa !24
  br label %bb54
bb54:
  %t254 = load i64, ptr %l22, !tbaa !24
  %t255 = load i64, ptr %l23, !tbaa !24
  %t258 = icmp slt i64 %t254, %t255
  %t260 = xor i1 %t258, true
  br i1 %t260, label %bb55, label %bb56
bb55:
  br label %bb115
bb56:
  br label %bb57
bb57:
  %t262 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t262, ptr %l147, !tbaa !27
  %t263 = load i64, ptr %l22, !tbaa !24
  %t265 = getelementptr { i64, ptr }, ptr %l147, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = getelementptr ptr, ptr %t266, i64 %t263
  %t268 = load ptr, ptr %t267, !tbaa !39
  store ptr %t268, ptr %l24, !tbaa !29
  %t270 = load ptr, ptr %l24, !tbaa !29
  store ptr %t270, ptr %l150, !tbaa !29
  store i1 false, ptr %l151, !tbaa !21
  %t271 = load ptr, ptr %l150, !tbaa !29
  %t272 = icmp ne ptr %t271, null
  br i1 %t272, label %bb58, label %bb59
bb58:
  %t274 = load ptr, ptr %l150, !tbaa !29
  %t275 = load i64, ptr %t274, !range !{i64 0, i64 6}
  %t277 = icmp eq i64 %t275, 0
  store i1 %t277, ptr %l151, !tbaa !21
  br label %bb59
bb59:
  %t278 = load i1, ptr %l151, !tbaa !21
  br i1 %t278, label %bb60, label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb67
bb62:
  %t279 = load ptr, ptr %l18, !tbaa !29
  %t281 = getelementptr %"compiler/ast:Case", ptr %t279, i32 0, i32 3
  %t282 = load ptr, ptr %t281, !tbaa !29
  %t284 = icmp eq ptr %t282, null
  br i1 %t284, label %bb63, label %bb64
bb63:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb65
bb64:
  br label %bb65
bb65:
  store i1 true, ptr %l20, !tbaa !21
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t287 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  %t289 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t287, ptr %t289
  %t293 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetUnion(ptr %v0, ptr %s6, ptr %s0, ptr %s6, ptr %t286, ptr %t289, ptr %l5)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t293, ptr %l161
  br label %bb66
bb66:
  %t294 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l161
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t294, ptr %l19
  br label %bb113
bb67:
  %t295 = load ptr, ptr %l24, !tbaa !29
  store ptr %t295, ptr %l162, !tbaa !29
  store i1 false, ptr %l163, !tbaa !21
  %t296 = load ptr, ptr %l162, !tbaa !29
  %t297 = icmp ne ptr %t296, null
  br i1 %t297, label %bb68, label %bb69
bb68:
  %t299 = load ptr, ptr %l162, !tbaa !29
  %t300 = load i64, ptr %t299, !range !{i64 0, i64 6}
  %t302 = icmp eq i64 %t300, 1
  store i1 %t302, ptr %l163, !tbaa !21
  br label %bb69
bb69:
  %t303 = load i1, ptr %l163, !tbaa !21
  br i1 %t303, label %bb70, label %bb71
bb70:
  %t304 = load ptr, ptr %l24, !tbaa !29
  %t306 = getelementptr { i64, [4 x i64] }, ptr %t304, i32 0, i32 1
  %t307 = getelementptr { %"compiler/source:Span", ptr }, ptr %t306, i32 0, i32 1
  %t308 = load ptr, ptr %t307
  store ptr %t308, ptr %l25, !tbaa !29
  br label %bb76
bb71:
  %t310 = load ptr, ptr %l24, !tbaa !29
  store ptr %t310, ptr %l168, !tbaa !29
  store i1 false, ptr %l169, !tbaa !21
  %t311 = load ptr, ptr %l168, !tbaa !29
  %t312 = icmp ne ptr %t311, null
  br i1 %t312, label %bb72, label %bb73
bb72:
  %t314 = load ptr, ptr %l168, !tbaa !29
  %t315 = load i64, ptr %t314, !range !{i64 0, i64 6}
  %t317 = icmp eq i64 %t315, 4
  store i1 %t317, ptr %l169, !tbaa !21
  br label %bb73
bb73:
  %t318 = load i1, ptr %l169, !tbaa !21
  br i1 %t318, label %bb74, label %bb75
bb74:
  %t319 = load ptr, ptr %l24, !tbaa !29
  %t321 = getelementptr { i64, [4 x i64] }, ptr %t319, i32 0, i32 1
  %t322 = getelementptr { %"compiler/source:Span", ptr }, ptr %t321, i32 0, i32 1
  %t323 = load ptr, ptr %t322
  store ptr %t323, ptr %l25, !tbaa !29
  br label %bb76
bb75:
  br label %bb105
bb76:
  store %olang.scope zeroinitializer, ptr %s12
  %t325 = load ptr, ptr %l25, !tbaa !29
  %t327 = call i1 @compiler_2fcheck_2eisNullLit(ptr %v1, ptr %t325)
  store i1 %t327, ptr %l175
  br label %bb77
bb77:
  %t328 = load i1, ptr %l175, !tbaa !21
  br i1 %t328, label %bb78, label %bb79
bb78:
  %t329 = load i1, ptr %l6, !tbaa !21
  %t331 = xor i1 %t329, true
  br i1 %t331, label %bb80, label %bb81
bb79:
  br label %bb86
bb80:
  store %olang.scope zeroinitializer, ptr %s14
  %t333 = load ptr, ptr %l0, !tbaa !29
  store ptr %t333, ptr %l178, !tbaa !29
  %t334 = load ptr, ptr %l24, !tbaa !29
  %t336 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t334)
  store %"compiler/source:Span" %t336, ptr %l180
  br label %bb82
bb81:
  br label %bb85
bb82:
  %t337 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t339 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrNeverNull(ptr %s0, ptr %s14, { i64, ptr } %t337)
  store %"compiler/msgs:Msg" %t339, ptr %l182
  br label %bb83
bb83:
  %t340 = load ptr, ptr %l178, !tbaa !29
  %t341 = load %"compiler/source:Span", ptr %l180
  %t342 = load %"compiler/msgs:Msg", ptr %l182
  %t343 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s14, ptr %t340, %"compiler/source:Span" %t341, %"compiler/msgs:Msg" %t342)
  store i64 %t343, ptr %l183
  br label %bb84
bb84:
  store i1 false, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s14)
  br label %bb85
bb85:
  store i1 true, ptr %l20, !tbaa !21
  call void @__olang_scope_close(ptr %s12)
  br label %bb114
bb86:
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t345 = load ptr, ptr %l25, !tbaa !29
  %t348 = call { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtItems(ptr %v0, ptr %v1, ptr %s12, ptr %t344, ptr %t345)
  %t349 = extractvalue { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } %t348, 1
  %t350 = extractvalue { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } %t348, 0
  store i32 %t350, ptr %l188
  %t351 = icmp ne i32 %t350, 0
  br i1 %t351, label %bb88, label %ok.352, !prof !99
ok.352:
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t349, ptr %l187
  br label %bb87
bb87:
  %t353 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l187
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t353, ptr %l184
  br label %bb93
bb88:
  %t354 = load i32, ptr %l188, !tbaa !23
  %t355 = ashr i32 %t354, 16
  %t357 = icmp eq i32 %t355, 1
  store i1 %t357, ptr %l190, !tbaa !21
  br label %bb89
bb89:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s15
  %t358 = load ptr, ptr %l0, !tbaa !29
  store ptr %t358, ptr %l191, !tbaa !29
  %t359 = load ptr, ptr %l24, !tbaa !29
  %t361 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t359)
  store %"compiler/source:Span" %t361, ptr %l193
  br label %bb90
bb90:
  %t362 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtCaseForm(ptr %s15)
  store %"compiler/msgs:Msg" %t362, ptr %l194
  br label %bb91
bb91:
  %t363 = load ptr, ptr %l191, !tbaa !29
  %t364 = load %"compiler/source:Span", ptr %l193
  %t365 = load %"compiler/msgs:Msg", ptr %l194
  %t366 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s15, ptr %t363, %"compiler/source:Span" %t364, %"compiler/msgs:Msg" %t365)
  store i64 %t366, ptr %l195
  br label %bb92
bb92:
  store i1 false, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s12)
  br label %bb114
bb93:
  %t367 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l184
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t367, ptr %l26
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t372 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetMeet(ptr %v0, ptr %s0, ptr %s12, ptr %s12, ptr %t368, ptr %l5, ptr %l26)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t372, ptr %l199
  br label %bb94
bb94:
  %t373 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l199
  %t374 = call ptr @__olang_scope_alloc_a(ptr %s12, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t373, ptr %t374
  %t376 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s12, ptr %t374)
  store i64 %t376, ptr %l201
  br label %bb95
bb95:
  %t377 = load i64, ptr %l201, !tbaa !24
  %t378 = icmp eq i64 %t377, 0
  br i1 %t378, label %bb96, label %bb97
bb96:
  store %olang.scope zeroinitializer, ptr %s16
  %t380 = load ptr, ptr %l0, !tbaa !29
  store ptr %t380, ptr %l203, !tbaa !29
  %t381 = load ptr, ptr %l24, !tbaa !29
  %t383 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t381)
  store %"compiler/source:Span" %t383, ptr %l205
  br label %bb98
bb97:
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t385 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  %t387 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t385, ptr %t387
  %t391 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetUnion(ptr %v0, ptr %s6, ptr %s12, ptr %s6, ptr %t384, ptr %t387, ptr %l26)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t391, ptr %l221
  br label %bb103
bb98:
  %t392 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t392, ptr %l206, !tbaa !27
  %t393 = load ptr, ptr %l0, !tbaa !29
  %t396 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetText(ptr %v0, ptr %s12, ptr %s16, ptr %t393, ptr %l26)
  store { i64, ptr } %t396, ptr %l209
  br label %bb99
bb99:
  %t397 = load { i64, ptr }, ptr %l209, !tbaa !27
  %t398 = extractvalue { i64, ptr } %t397, 0
  %t399 = extractvalue { i64, ptr } %t397, 1
  %t400 = mul i64 %t398, 1
  %t401 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t400)
  call void @llvm.memcpy.p0.p0.i64(ptr %t401, ptr %t399, i64 %t400, i1 false)
  %t402 = insertvalue { i64, ptr } undef, i64 %t398, 0
  %t403 = insertvalue { i64, ptr } %t402, ptr %t401, 1
  store { i64, ptr } %t403, ptr %l210, !tbaa !27
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t407 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetText(ptr %v0, ptr %s0, ptr %s16, ptr %t404, ptr %l5)
  store { i64, ptr } %t407, ptr %l213
  br label %bb100
bb100:
  %t408 = load { i64, ptr }, ptr %l213, !tbaa !27
  %t409 = extractvalue { i64, ptr } %t408, 0
  %t410 = extractvalue { i64, ptr } %t408, 1
  %t411 = mul i64 %t409, 1
  %t412 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t411)
  call void @llvm.memcpy.p0.p0.i64(ptr %t412, ptr %t410, i64 %t411, i1 false)
  %t413 = insertvalue { i64, ptr } undef, i64 %t409, 0
  %t414 = insertvalue { i64, ptr } %t413, ptr %t412, 1
  %t415 = load { i64, ptr }, ptr %l206, !tbaa !27
  %t416 = load { i64, ptr }, ptr %l210, !tbaa !27
  %t418 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtNeverIs(ptr %s0, ptr %s16, ptr %s16, ptr %s16, { i64, ptr } %t415, { i64, ptr } %t416, { i64, ptr } %t414)
  store %"compiler/msgs:Msg" %t418, ptr %l215
  br label %bb101
bb101:
  %t419 = load ptr, ptr %l203, !tbaa !29
  %t420 = load %"compiler/source:Span", ptr %l205
  %t421 = load %"compiler/msgs:Msg", ptr %l215
  %t422 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s16, ptr %t419, %"compiler/source:Span" %t420, %"compiler/msgs:Msg" %t421)
  store i64 %t422, ptr %l216
  br label %bb102
bb102:
  store i1 false, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s16)
  br label %bb104
bb103:
  %t423 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l221
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t423, ptr %l19
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s12)
  br label %bb113
bb105:
  br i1 true, label %bb106, label %bb107
bb106:
  br label %bb108
bb107:
  br label %bb112
bb108:
  store %olang.scope zeroinitializer, ptr %s18
  %t424 = load ptr, ptr %l0, !tbaa !29
  store ptr %t424, ptr %l222, !tbaa !29
  %t425 = load ptr, ptr %l24, !tbaa !29
  %t427 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t425)
  store %"compiler/source:Span" %t427, ptr %l224
  br label %bb109
bb109:
  %t428 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtCaseForm(ptr %s18)
  store %"compiler/msgs:Msg" %t428, ptr %l225
  br label %bb110
bb110:
  %t429 = load ptr, ptr %l222, !tbaa !29
  %t430 = load %"compiler/source:Span", ptr %l224
  %t431 = load %"compiler/msgs:Msg", ptr %l225
  %t432 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s18, ptr %t429, %"compiler/source:Span" %t430, %"compiler/msgs:Msg" %t431)
  store i64 %t432, ptr %l226
  br label %bb111
bb111:
  store i1 false, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s18)
  br label %bb113
bb112:
  call void @__olang_check_failed(ptr @olang_loc_259a476ccf69be4f_4dd02f382a72243)
  unreachable
bb113:
  br label %bb114
bb114:
  %t433 = load i64, ptr %l22, !tbaa !24
  %t435 = add i64 %t433, 1
  store i64 %t435, ptr %l22, !tbaa !24
  br label %bb54
bb115:
  %t437 = load ptr, ptr %l18, !tbaa !29
  %t439 = getelementptr %"compiler/ast:Case", ptr %t437, i32 0, i32 3
  %t440 = load ptr, ptr %t439, !tbaa !29
  %t442 = icmp eq ptr %t440, null
  br i1 %t442, label %bb116, label %bb117
bb116:
  %t444 = load ptr, ptr %l0, !tbaa !29
  store ptr %t444, ptr %l232, !tbaa !29
  %t445 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  %t447 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t445, ptr %t447
  store ptr %t447, ptr %l234, !tbaa !29
  %t448 = load ptr, ptr %l0, !tbaa !29
  %t452 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetMeet(ptr %v0, ptr %s6, ptr %s0, ptr %s0, ptr %t448, ptr %l19, ptr %l5)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t452, ptr %l238
  br label %bb118
bb117:
  br label %bb123
bb118:
  %t453 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l238
  %t454 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t453, ptr %t454
  %t455 = load ptr, ptr %l232, !tbaa !29
  %t456 = load ptr, ptr %l234, !tbaa !29
  %t458 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetUnion(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t455, ptr %t456, ptr %t454)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t458, ptr %l240
  br label %bb119
bb119:
  %t459 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l240
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t459, ptr %l8
  %t460 = load i1, ptr %l20, !tbaa !21
  br i1 %t460, label %bb120, label %bb121
bb120:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb122
bb121:
  br label %bb122
bb122:
  br label %bb123
bb123:
  call void @__olang_scope_close(ptr %s6)
  br label %bb124
bb124:
  %t462 = load i64, ptr %l16, !tbaa !24
  %t464 = add i64 %t462, 1
  store i64 %t464, ptr %l16, !tbaa !24
  br label %bb36
bb125:
  %t466 = load i1, ptr %l11, !tbaa !21
  br i1 %t466, label %bb126, label %bb127
bb126:
  store i1 true, ptr %l245, !tbaa !21
  br label %bb133
bb127:
  %t468 = load ptr, ptr %l0, !tbaa !29
  %t472 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetLess(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t468, ptr %l5, ptr %l8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t472, ptr %l249
  br label %bb128
bb128:
  %t473 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l249
  %t474 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t473, ptr %t474
  %t476 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t474)
  store i64 %t476, ptr %l251
  br label %bb129
bb129:
  %t477 = load i64, ptr %l251, !tbaa !24
  %t478 = icmp eq i64 %t477, 0
  br i1 %t478, label %bb130, label %bb131
bb130:
  %t480 = load i1, ptr %l9, !tbaa !21
  store i1 %t480, ptr %l253, !tbaa !21
  br label %bb132
bb131:
  store i1 false, ptr %l253, !tbaa !21
  br label %bb132
bb132:
  %t482 = load i1, ptr %l253, !tbaa !21
  store i1 %t482, ptr %l245, !tbaa !21
  br label %bb133
bb133:
  %t483 = load i1, ptr %l245, !tbaa !21
  store i1 %t483, ptr %l27, !tbaa !21
  %t484 = load i1, ptr %l10, !tbaa !21
  br i1 %t484, label %bb134, label %bb135
bb134:
  %t486 = load i1, ptr %l27, !tbaa !21
  %t488 = xor i1 %t486, true
  store i1 %t488, ptr %l256, !tbaa !21
  br label %bb136
bb135:
  store i1 false, ptr %l256, !tbaa !21
  br label %bb136
bb136:
  %t490 = load i1, ptr %l256, !tbaa !21
  br i1 %t490, label %bb137, label %bb138
bb137:
  store %olang.scope zeroinitializer, ptr %s23
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t495 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetLess(ptr %v0, ptr %s0, ptr %s0, ptr %s23, ptr %t491, ptr %l5, ptr %l8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t495, ptr %l262
  br label %bb139
bb138:
  br label %bb155
bb139:
  %t496 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l262
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t496, ptr %l28
  %t498 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s23, ptr %l28)
  store i64 %t498, ptr %l264
  br label %bb140
bb140:
  %t499 = load i64, ptr %l264, !tbaa !24
  %t500 = icmp sgt i64 %t499, 0
  br i1 %t500, label %bb141, label %bb142
bb141:
  %t502 = load ptr, ptr %l0, !tbaa !29
  %t505 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetText(ptr %v0, ptr %s23, ptr %s23, ptr %t502, ptr %l28)
  store { i64, ptr } %t505, ptr %l269
  br label %bb143
bb142:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %l266, !tbaa !27
  br label %bb144
bb143:
  %t506 = load { i64, ptr }, ptr %l269, !tbaa !27
  %t507 = extractvalue { i64, ptr } %t506, 0
  %t508 = extractvalue { i64, ptr } %t506, 1
  %t509 = mul i64 %t507, 1
  %t510 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t509)
  call void @llvm.memcpy.p0.p0.i64(ptr %t510, ptr %t508, i64 %t509, i1 false)
  %t511 = insertvalue { i64, ptr } undef, i64 %t507, 0
  %t512 = insertvalue { i64, ptr } %t511, ptr %t510, 1
  store { i64, ptr } %t512, ptr %l266, !tbaa !27
  br label %bb144
bb144:
  %t514 = load { i64, ptr }, ptr %l266, !tbaa !27
  store { i64, ptr } %t514, ptr %l29, !tbaa !27
  %t516 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s23, ptr %l28)
  store i64 %t516, ptr %l272
  br label %bb145
bb145:
  %t517 = load i64, ptr %l272, !tbaa !24
  %t518 = icmp sgt i64 %t517, 0
  br i1 %t518, label %bb146, label %bb147
bb146:
  %t520 = load i1, ptr %l9, !tbaa !21
  %t522 = xor i1 %t520, true
  store i1 %t522, ptr %l274, !tbaa !21
  br label %bb148
bb147:
  store i1 false, ptr %l274, !tbaa !21
  br label %bb148
bb148:
  %t524 = load i1, ptr %l274, !tbaa !21
  br i1 %t524, label %bb149, label %bb150
bb149:
  %t525 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t527 = extractvalue { i64, ptr } %t525, 1
  %t528 = extractvalue { i64, ptr } %t525, 0
  %t529 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t530 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t531 = add i64 %t528, %t530
  %t532 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t531)
  call void @olang_textcopy(ptr %t532, ptr %t527, i64 %t528)
  %t533 = getelementptr i8, ptr %t532, i64 %t528
  call void @olang_textcopy(ptr %t533, ptr %t529, i64 %t530)
  %t534 = insertvalue { i64, ptr } undef, i64 %t531, 0
  %t535 = insertvalue { i64, ptr } %t534, ptr %t532, 1
  %t537 = extractvalue { i64, ptr } %t535, 0
  %t538 = extractvalue { i64, ptr } %t535, 1
  %t539 = mul i64 %t537, 1
  %t540 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t539)
  call void @llvm.memcpy.p0.p0.i64(ptr %t540, ptr %t538, i64 %t539, i1 false)
  %t541 = insertvalue { i64, ptr } undef, i64 %t537, 0
  %t542 = insertvalue { i64, ptr } %t541, ptr %t540, 1
  store { i64, ptr } %t542, ptr %l29, !tbaa !27
  br label %bb151
bb150:
  br label %bb151
bb151:
  %t544 = load ptr, ptr %l0, !tbaa !29
  store ptr %t544, ptr %l280, !tbaa !29
  %t545 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t546 = load i32, ptr %t545, !tbaa !23
  %t547 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t548 = load i32, ptr %t547, !tbaa !23
  %t550 = add i32 %t548, 5
  %t553 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s23, i32 %t546, i32 %t550)
  store %"compiler/source:Span" %t553, ptr %l284
  br label %bb152
bb152:
  %t554 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t556 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtMatchMissing(ptr %s23, ptr %s23, { i64, ptr } %t554)
  store %"compiler/msgs:Msg" %t556, ptr %l286
  br label %bb153
bb153:
  %t557 = load ptr, ptr %l280, !tbaa !29
  %t558 = load %"compiler/source:Span", ptr %l284
  %t559 = load %"compiler/msgs:Msg", ptr %l286
  %t560 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s23, ptr %t557, %"compiler/source:Span" %t558, %"compiler/msgs:Msg" %t559)
  store i64 %t560, ptr %l287
  br label %bb154
bb154:
  store i1 false, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s23)
  br label %bb155
bb155:
  %t561 = load i1, ptr %l10, !tbaa !21
  %t563 = xor i1 %t561, true
  br i1 %t563, label %bb156, label %bb157
bb156:
  call void @__olang_scope_close(ptr %s0)
  %t566 = insertvalue { i32, i1 } zeroinitializer, i32 65536, 0
  store { i32, i1 } %t566, ptr %rv
  br label %ret
bb157:
  br label %bb158
bb158:
  %t567 = load i1, ptr %l27, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t569 = insertvalue { i32, i1 } zeroinitializer, i1 %t567, 1
  store { i32, i1 } %t569, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i1 }, ptr %rv
  ret { i32, i1 } %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtLast(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l41 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l62 = alloca i1
  %l69 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Match", ptr %t1, i32 0, i32 3
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  store i64 %t6, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t12 = icmp sgt i64 %t8, %t9
  br i1 %t12, label %bb1, label %bb2
bb1:
  %t14 = load i64, ptr %l5, !tbaa !24
  %t16 = icmp sgt i64 %t14, 0
  br i1 %t16, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb6
bb3:
  %t18 = load i64, ptr %l4, !tbaa !24
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = sub i64 %t18, %t19
  %t23 = load i64, ptr %l5, !tbaa !24
  %t26 = add i64 %t22, %t23
  %t28 = sub i64 %t26, 1
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = sdiv i64 %t28, %t29
  store i64 %t32, ptr %l22, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb5
bb5:
  %t34 = load i64, ptr %l22, !tbaa !24
  store i64 %t34, ptr %l19, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l19, !tbaa !24
  store i64 %t35, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l7, !tbaa !24
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb8, label %bb9
bb8:
  br label %bb25
bb9:
  br label %bb10
bb10:
  %t44 = load i64, ptr %l3, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  %t46 = load i64, ptr %l5, !tbaa !24
  %t49 = mul i64 %t45, %t46
  %t52 = add i64 %t44, %t49
  store i64 %t52, ptr %l8, !tbaa !24
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr %"compiler/ast:Match", ptr %t54, i32 0, i32 3
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  store { i64, ptr } %t57, ptr %l41, !tbaa !27
  %t58 = load i64, ptr %l8, !tbaa !24
  %t60 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr ptr, ptr %t61, i64 %t58
  %t63 = load ptr, ptr %t62, !tbaa !39
  %t65 = getelementptr %"compiler/ast:Case", ptr %t63, i32 0, i32 3
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = icmp eq ptr %t66, null
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb11, label %bb12
bb11:
  br label %bb24
bb12:
  br label %bb13
bb13:
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = getelementptr %"compiler/ast:Match", ptr %t72, i32 0, i32 3
  %t75 = load { i64, ptr }, ptr %t74, !tbaa !27
  store { i64, ptr } %t75, ptr %l48, !tbaa !27
  %t76 = load i64, ptr %l8, !tbaa !24
  %t78 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr ptr, ptr %t79, i64 %t76
  %t81 = load ptr, ptr %t80, !tbaa !39
  %t83 = getelementptr %"compiler/ast:Case", ptr %t81, i32 0, i32 1
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  store { i64, ptr } %t84, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t86 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  store i64 %t88, ptr %l11, !tbaa !24
  br label %bb14
bb14:
  %t90 = load i64, ptr %l10, !tbaa !24
  %t91 = load i64, ptr %l11, !tbaa !24
  %t94 = icmp slt i64 %t90, %t91
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb15, label %bb16
bb15:
  br label %bb23
bb16:
  br label %bb17
bb17:
  %t98 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t98, ptr %l58, !tbaa !27
  %t99 = load i64, ptr %l10, !tbaa !24
  %t101 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr ptr, ptr %t102, i64 %t99
  %t104 = load ptr, ptr %t103, !tbaa !39
  %t108 = call i1 @compiler_2fcheck_2eisWild(ptr %v1, ptr %t104)
  store i1 %t108, ptr %l62
  br label %bb18
bb18:
  %t109 = load i1, ptr %l62, !tbaa !21
  br i1 %t109, label %bb19, label %bb20
bb19:
  %t110 = load i64, ptr %l8, !tbaa !24
  store i64 %t110, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t112 = load i64, ptr %l10, !tbaa !24
  %t114 = add i64 %t112, 1
  store i64 %t114, ptr %l10, !tbaa !24
  br label %bb14
bb23:
  br label %bb24
bb24:
  %t116 = load i64, ptr %l7, !tbaa !24
  %t118 = add i64 %t116, 1
  store i64 %t118, ptr %l7, !tbaa !24
  br label %bb7
bb25:
  br i1 %a2, label %bb26, label %bb27
bb26:
  %t122 = load ptr, ptr %l1, !tbaa !29
  %t124 = getelementptr %"compiler/ast:Match", ptr %t122, i32 0, i32 3
  %t125 = load { i64, ptr }, ptr %t124, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t125, 0
  %t129 = sub i64 %t127, 1
  store i64 %t129, ptr %l69, !tbaa !24
  br label %bb28
bb27:
  store i64 -1, ptr %l69, !tbaa !24
  br label %bb28
bb28:
  %t131 = load i64, ptr %l69, !tbaa !24
  store i64 %t131, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econdOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l6 = alloca i32
  %l10 = alloca i1
  %l14 = alloca ptr
  %l16 = alloca %"compiler/source:Span"
  %l19 = alloca { i64, ptr }
  %l21 = alloca %"compiler/msgs:Msg"
  %l22 = alloca i64
  %l23 = alloca ptr
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca ptr
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1)
  store i32 %t4, ptr %l6
  br label %bb1
bb1:
  %t5 = load i32, ptr %l6, !tbaa !23
  store i32 %t5, ptr %l3, !tbaa !23
  %t6 = load i32, ptr %l3, !tbaa !23
  %t7 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t10 = icmp ne i32 %t6, %t7
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i32, ptr %l3, !tbaa !23
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t16 = icmp ne i32 %t12, %t13
  store i1 %t16, ptr %l10, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l10, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l14, !tbaa !29
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t20)
  store %"compiler/source:Span" %t22, ptr %l16
  br label %bb7
bb6:
  br label %bb13
bb7:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l3, !tbaa !23
  %t27 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t23, i32 %t24)
  store { i64, ptr } %t27, ptr %l19
  br label %bb8
bb8:
  %t28 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  %t30 = extractvalue { i64, ptr } %t28, 1
  %t31 = mul i64 %t29, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t31)
  call void @llvm.memcpy.p0.p0.i64(ptr %t32, ptr %t30, i64 %t31, i1 false)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  %t36 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondNotBoolType(ptr %s1, ptr %s1, { i64, ptr } %t34)
  store %"compiler/msgs:Msg" %t36, ptr %l21
  br label %bb9
bb9:
  %t37 = load ptr, ptr %l14, !tbaa !29
  %t38 = load %"compiler/source:Span", ptr %l16
  %t39 = load %"compiler/msgs:Msg", ptr %l21
  %t40 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t37, %"compiler/source:Span" %t38, %"compiler/msgs:Msg" %t39)
  store i64 %t40, ptr %l22
  br label %bb10
bb10:
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l23, !tbaa !29
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t42)
  store %"compiler/source:Span" %t44, ptr %l25
  br label %bb11
bb11:
  %t45 = load ptr, ptr %l23, !tbaa !29
  %t46 = load %"compiler/source:Span", ptr %l25
  %t47 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t45, %"compiler/source:Span" %t46)
  store ptr %t47, ptr %l26
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s1)
  %t48 = load ptr, ptr %l26, !tbaa !29
  store ptr %t48, ptr %rv
  br label %ret
bb13:
  %t49 = load ptr, ptr %l2, !tbaa !29
  store ptr %t49, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca i32
  %l19 = alloca ptr
  %l20 = alloca %"compiler/source:Span"
  %l21 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca %"compiler/source:Span"
  %l24 = alloca i32
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l27 = alloca ptr
  %l28 = alloca %"compiler/source:Span"
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i32
  %l32 = alloca { i64, ptr }
  %l33 = alloca %"compiler/source:Span"
  %l34 = alloca i32
  %l35 = alloca ptr
  %l36 = alloca %"compiler/source:Span"
  %l37 = alloca i32
  %l38 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca %"compiler/source:Span"
  %l41 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca %"compiler/source:Span"
  %l44 = alloca i32
  %l45 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca ptr
  %l48 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca i1
  %l80 = alloca ptr
  %l81 = alloca i1
  %l92 = alloca %"compiler/source:Span"
  %l93 = alloca i32
  %l97 = alloca ptr
  %l101 = alloca i32
  %l104 = alloca ptr
  %l105 = alloca i1
  %l114 = alloca %"compiler/source:Span"
  %l115 = alloca i32
  %l119 = alloca ptr
  %l122 = alloca ptr
  %l123 = alloca i1
  %l132 = alloca %"compiler/source:Span"
  %l133 = alloca i32
  %l138 = alloca ptr
  %l143 = alloca i32
  %l144 = alloca %"compiler/typed:Promote"
  %l148 = alloca ptr
  %l149 = alloca i1
  %l158 = alloca %"compiler/source:Span"
  %l159 = alloca i32
  %l161 = alloca ptr
  %l166 = alloca { i64, ptr }
  %l168 = alloca { i64, [2 x i64] }
  %l173 = alloca i32
  %l176 = alloca %"compiler/typed:Call"
  %l180 = alloca ptr
  %l181 = alloca i1
  %l194 = alloca { i64, ptr }
  %l199 = alloca ptr
  %l206 = alloca ptr
  %l208 = alloca %"compiler/source:Span"
  %l209 = alloca i32
  %l211 = alloca i32
  %l213 = alloca i64
  %l214 = alloca { i64, ptr }
  %l215 = alloca ptr
  %l220 = alloca i32
  %l223 = alloca %"compiler/typed:Make"
  %l227 = alloca ptr
  %l228 = alloca i1
  %l241 = alloca %"compiler/source:Span"
  %l242 = alloca i32
  %l243 = alloca i32
  %l244 = alloca i32
  %l248 = alloca { i64, ptr }
  %l251 = alloca ptr
  %l252 = alloca i1
  %l261 = alloca %"compiler/source:Span"
  %l262 = alloca i32
  %l267 = alloca ptr
  %l272 = alloca ptr
  %l277 = alloca ptr
  %l280 = alloca %"compiler/typed:Slice"
  %l284 = alloca ptr
  %l285 = alloca i1
  %l298 = alloca ptr
  %l305 = alloca ptr
  %l307 = alloca %"compiler/source:Span"
  %l308 = alloca i32
  %l313 = alloca ptr
  %l314 = alloca ptr
  %l319 = alloca ptr
  %l320 = alloca %"compiler/typed:Cond"
  %l324 = alloca ptr
  %l325 = alloca i1
  %l334 = alloca %"compiler/source:Span"
  %l335 = alloca i64
  %l339 = alloca ptr
  %l342 = alloca ptr
  %l343 = alloca i1
  %l352 = alloca ptr
  %l353 = alloca i1
  %l365 = alloca ptr
  %l367 = alloca %"compiler/source:Span"
  %l368 = alloca ptr
  %rv = alloca ptr
  %t31 = alloca { i64, [5 x i64] }, align 8
  %t81 = alloca { i64, [5 x i64] }, align 8
  %t145 = alloca { i64, [5 x i64] }, align 8
  %t196 = alloca { i64, [5 x i64] }, align 8
  %t263 = alloca { i64, [5 x i64] }, align 8
  %t345 = alloca { i64, [5 x i64] }, align 8
  %t459 = alloca { i64, [5 x i64] }, align 8
  %t522 = alloca { i64, [5 x i64] }, align 8
  %t609 = alloca { i64, [5 x i64] }, align 8
  %t706 = alloca { i64, [5 x i64] }, align 8
  %t755 = alloca { i64, [5 x i64] }, align 8
  %t813 = alloca { i64, [4 x i64] }, align 8
  %t821 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t2 = load ptr, ptr %l47, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l47, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l48, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l48, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l3
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l4, !tbaa !23
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t24, i32 0, i32 2
  %t26 = load i64, ptr %t25
  store i64 %t26, ptr %l5, !tbaa !24
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t28 = load %"compiler/source:Span", ptr %l3
  %t29 = load i32, ptr %l4, !tbaa !23
  %t30 = load i64, ptr %l5, !tbaa !24
  store { i64, [5 x i64] } zeroinitializer, ptr %t31
  %t32 = getelementptr { i64, [5 x i64] }, ptr %t31, i32 0, i32 0
  store i64 0, ptr %t32
  %t34 = insertvalue { %"compiler/source:Span", i32, i64 } undef, %"compiler/source:Span" %t28, 0
  %t36 = insertvalue { %"compiler/source:Span", i32, i64 } %t34, i32 %t29, 1
  %t38 = insertvalue { %"compiler/source:Span", i32, i64 } %t36, i64 %t30, 2
  %t39 = getelementptr { i64, [5 x i64] }, ptr %t31, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64 } %t38, ptr %t39
  %t40 = load { i64, [5 x i64] }, ptr %t31
  %t42 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t40, ptr %t42
  store ptr %t42, ptr %rv
  br label %ret
bb6:
  %t44 = load ptr, ptr %l1, !tbaa !29
  store ptr %t44, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t45 = load ptr, ptr %l62, !tbaa !29
  %t46 = icmp ne ptr %t45, null
  br i1 %t46, label %bb7, label %bb8
bb7:
  %t48 = load ptr, ptr %l62, !tbaa !29
  %t49 = load i64, ptr %t48, !range !{i64 0, i64 18}
  %t51 = icmp eq i64 %t49, 1
  store i1 %t51, ptr %l63, !tbaa !21
  br label %bb8
bb8:
  %t52 = load i1, ptr %l63, !tbaa !21
  br i1 %t52, label %bb9, label %bb10
bb9:
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr { i64, [5 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t55, i32 0, i32 0
  %t57 = load %"compiler/source:Span", ptr %t56
  store %"compiler/source:Span" %t57, ptr %l6
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr { i64, [5 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t61, i32 0, i32 1
  %t63 = load i32, ptr %t62
  store i32 %t63, ptr %l7, !tbaa !23
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr { i64, [5 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t67, i32 0, i32 2
  %t69 = load i64, ptr %t68
  store i64 %t69, ptr %l8, !tbaa !24
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr { i64, [5 x i64] }, ptr %t71, i32 0, i32 1
  %t74 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t73, i32 0, i32 3
  %t75 = load ptr, ptr %t74
  store ptr %t75, ptr %l9, !tbaa !29
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t77 = load %"compiler/source:Span", ptr %l6
  %t78 = load i32, ptr %l7, !tbaa !23
  %t79 = load i64, ptr %l8, !tbaa !24
  %t80 = load ptr, ptr %l9, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t81
  %t82 = getelementptr { i64, [5 x i64] }, ptr %t81, i32 0, i32 0
  store i64 1, ptr %t82
  %t84 = insertvalue { %"compiler/source:Span", i32, i64, ptr } undef, %"compiler/source:Span" %t77, 0
  %t86 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t84, i32 %t78, 1
  %t88 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t86, i64 %t79, 2
  %t90 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t88, ptr %t80, 3
  %t91 = getelementptr { i64, [5 x i64] }, ptr %t81, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, ptr } %t90, ptr %t91
  %t92 = load { i64, [5 x i64] }, ptr %t81
  %t94 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t92, ptr %t94
  store ptr %t94, ptr %rv
  br label %ret
bb12:
  %t96 = load ptr, ptr %l1, !tbaa !29
  store ptr %t96, ptr %l80, !tbaa !29
  store i1 false, ptr %l81, !tbaa !21
  %t97 = load ptr, ptr %l80, !tbaa !29
  %t98 = icmp ne ptr %t97, null
  br i1 %t98, label %bb13, label %bb14
bb13:
  %t100 = load ptr, ptr %l80, !tbaa !29
  %t101 = load i64, ptr %t100, !range !{i64 0, i64 18}
  %t103 = icmp eq i64 %t101, 2
  store i1 %t103, ptr %l81, !tbaa !21
  br label %bb14
bb14:
  %t104 = load i1, ptr %l81, !tbaa !21
  br i1 %t104, label %bb15, label %bb16
bb15:
  %t105 = load ptr, ptr %l1, !tbaa !29
  %t107 = getelementptr { i64, [5 x i64] }, ptr %t105, i32 0, i32 1
  %t108 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t107, i32 0, i32 0
  %t109 = load %"compiler/source:Span", ptr %t108
  store %"compiler/source:Span" %t109, ptr %l10
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = getelementptr { i64, [5 x i64] }, ptr %t111, i32 0, i32 1
  %t114 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t113, i32 0, i32 1
  %t115 = load i32, ptr %t114
  store i32 %t115, ptr %l11, !tbaa !23
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr { i64, [5 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t119, i32 0, i32 2
  %t121 = load ptr, ptr %t120
  store ptr %t121, ptr %l12, !tbaa !29
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr { i64, [5 x i64] }, ptr %t123, i32 0, i32 1
  %t126 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t125, i32 0, i32 3
  %t127 = load i32, ptr %t126
  store i32 %t127, ptr %l13, !tbaa !23
  br label %bb17
bb16:
  br label %bb20
bb17:
  %t129 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t129, ptr %l92
  %t130 = load i32, ptr %l11, !tbaa !23
  store i32 %t130, ptr %l93, !tbaa !23
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load ptr, ptr %l12, !tbaa !29
  %t133 = load i64, ptr %l2, !tbaa !24
  %t137 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyPlace(ptr %v0, ptr %v1, ptr %t131, ptr %t132, i64 %t133)
  store ptr %t137, ptr %l97
  br label %bb18
bb18:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load i32, ptr %l13, !tbaa !23
  %t140 = load i64, ptr %l2, !tbaa !24
  %t144 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereSite(ptr %v0, ptr %t138, i32 %t139, i64 %t140)
  store i32 %t144, ptr %l101
  br label %bb19
bb19:
  store { i64, [5 x i64] } zeroinitializer, ptr %t145
  %t146 = getelementptr { i64, [5 x i64] }, ptr %t145, i32 0, i32 0
  store i64 2, ptr %t146
  %t147 = load %"compiler/source:Span", ptr %l92
  %t148 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t147, 0
  %t149 = load i32, ptr %l93, !tbaa !23
  %t150 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t148, i32 %t149, 1
  %t151 = load ptr, ptr %l97, !tbaa !29
  %t152 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t150, ptr %t151, 2
  %t153 = load i32, ptr %l101, !tbaa !23
  %t154 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t152, i32 %t153, 3
  %t155 = getelementptr { i64, [5 x i64] }, ptr %t145, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t154, ptr %t155
  %t156 = load { i64, [5 x i64] }, ptr %t145
  %t158 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t156, ptr %t158
  store ptr %t158, ptr %rv
  br label %ret
bb20:
  %t160 = load ptr, ptr %l1, !tbaa !29
  store ptr %t160, ptr %l104, !tbaa !29
  store i1 false, ptr %l105, !tbaa !21
  %t161 = load ptr, ptr %l104, !tbaa !29
  %t162 = icmp ne ptr %t161, null
  br i1 %t162, label %bb21, label %bb22
bb21:
  %t164 = load ptr, ptr %l104, !tbaa !29
  %t165 = load i64, ptr %t164, !range !{i64 0, i64 18}
  %t167 = icmp eq i64 %t165, 3
  store i1 %t167, ptr %l105, !tbaa !21
  br label %bb22
bb22:
  %t168 = load i1, ptr %l105, !tbaa !21
  br i1 %t168, label %bb23, label %bb24
bb23:
  %t169 = load ptr, ptr %l1, !tbaa !29
  %t171 = getelementptr { i64, [5 x i64] }, ptr %t169, i32 0, i32 1
  %t172 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t171, i32 0, i32 0
  %t173 = load %"compiler/source:Span", ptr %t172
  store %"compiler/source:Span" %t173, ptr %l14
  %t175 = load ptr, ptr %l1, !tbaa !29
  %t177 = getelementptr { i64, [5 x i64] }, ptr %t175, i32 0, i32 1
  %t178 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t177, i32 0, i32 1
  %t179 = load i32, ptr %t178
  store i32 %t179, ptr %l15, !tbaa !23
  %t181 = load ptr, ptr %l1, !tbaa !29
  %t183 = getelementptr { i64, [5 x i64] }, ptr %t181, i32 0, i32 1
  %t184 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t183, i32 0, i32 2
  %t185 = load ptr, ptr %t184
  store ptr %t185, ptr %l16, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t187 = load %"compiler/source:Span", ptr %l14
  store %"compiler/source:Span" %t187, ptr %l114
  %t188 = load i32, ptr %l15, !tbaa !23
  store i32 %t188, ptr %l115, !tbaa !23
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load ptr, ptr %l16, !tbaa !29
  %t191 = load i64, ptr %l2, !tbaa !24
  %t195 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyPlace(ptr %v0, ptr %v1, ptr %t189, ptr %t190, i64 %t191)
  store ptr %t195, ptr %l119
  br label %bb26
bb26:
  store { i64, [5 x i64] } zeroinitializer, ptr %t196
  %t197 = getelementptr { i64, [5 x i64] }, ptr %t196, i32 0, i32 0
  store i64 3, ptr %t197
  %t198 = load %"compiler/source:Span", ptr %l114
  %t199 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t198, 0
  %t200 = load i32, ptr %l115, !tbaa !23
  %t201 = insertvalue { %"compiler/source:Span", i32, ptr } %t199, i32 %t200, 1
  %t202 = load ptr, ptr %l119, !tbaa !29
  %t203 = insertvalue { %"compiler/source:Span", i32, ptr } %t201, ptr %t202, 2
  %t204 = getelementptr { i64, [5 x i64] }, ptr %t196, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t203, ptr %t204
  %t205 = load { i64, [5 x i64] }, ptr %t196
  %t207 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t205, ptr %t207
  store ptr %t207, ptr %rv
  br label %ret
bb27:
  %t209 = load ptr, ptr %l1, !tbaa !29
  store ptr %t209, ptr %l122, !tbaa !29
  store i1 false, ptr %l123, !tbaa !21
  %t210 = load ptr, ptr %l122, !tbaa !29
  %t211 = icmp ne ptr %t210, null
  br i1 %t211, label %bb28, label %bb29
bb28:
  %t213 = load ptr, ptr %l122, !tbaa !29
  %t214 = load i64, ptr %t213, !range !{i64 0, i64 18}
  %t216 = icmp eq i64 %t214, 5
  store i1 %t216, ptr %l123, !tbaa !21
  br label %bb29
bb29:
  %t217 = load i1, ptr %l123, !tbaa !21
  br i1 %t217, label %bb30, label %bb31
bb30:
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = getelementptr { i64, [5 x i64] }, ptr %t218, i32 0, i32 1
  %t221 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t220, i32 0, i32 0
  %t222 = load %"compiler/source:Span", ptr %t221
  store %"compiler/source:Span" %t222, ptr %l17
  %t224 = load ptr, ptr %l1, !tbaa !29
  %t226 = getelementptr { i64, [5 x i64] }, ptr %t224, i32 0, i32 1
  %t227 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t226, i32 0, i32 1
  %t228 = load i32, ptr %t227
  store i32 %t228, ptr %l18, !tbaa !23
  %t230 = load ptr, ptr %l1, !tbaa !29
  %t232 = getelementptr { i64, [5 x i64] }, ptr %t230, i32 0, i32 1
  %t233 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t232, i32 0, i32 2
  %t234 = load ptr, ptr %t233
  store ptr %t234, ptr %l19, !tbaa !29
  br label %bb32
bb31:
  br label %bb36
bb32:
  %t236 = load %"compiler/source:Span", ptr %l17
  store %"compiler/source:Span" %t236, ptr %l132
  %t237 = load i32, ptr %l18, !tbaa !23
  store i32 %t237, ptr %l133, !tbaa !23
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load ptr, ptr %l19, !tbaa !29
  %t241 = getelementptr %"compiler/typed:Promote", ptr %t239, i32 0, i32 0
  %t242 = load ptr, ptr %t241, !tbaa !29
  %t243 = load i64, ptr %l2, !tbaa !24
  %t247 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %t238, ptr %t242, i64 %t243)
  store ptr %t247, ptr %l138
  br label %bb33
bb33:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load ptr, ptr %l19, !tbaa !29
  %t251 = getelementptr %"compiler/typed:Promote", ptr %t249, i32 0, i32 1
  %t252 = load i32, ptr %t251, !tbaa !23
  %t253 = load i64, ptr %l2, !tbaa !24
  %t257 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereSite(ptr %v0, ptr %t248, i32 %t252, i64 %t253)
  store i32 %t257, ptr %l143
  br label %bb34
bb34:
  %t258 = load ptr, ptr %l138, !tbaa !29
  %t259 = load i32, ptr %l143, !tbaa !23
  %t260 = call %"compiler/typed:Promote" @compiler_2ftyped_3aPromote_2ector(ptr %v0, ptr %v0, ptr %t258, i32 %t259)
  store %"compiler/typed:Promote" %t260, ptr %l144
  br label %bb35
bb35:
  %t261 = load %"compiler/typed:Promote", ptr %l144
  %t262 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store %"compiler/typed:Promote" %t261, ptr %t262
  store { i64, [5 x i64] } zeroinitializer, ptr %t263
  %t264 = getelementptr { i64, [5 x i64] }, ptr %t263, i32 0, i32 0
  store i64 5, ptr %t264
  %t265 = load %"compiler/source:Span", ptr %l132
  %t266 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t265, 0
  %t267 = load i32, ptr %l133, !tbaa !23
  %t268 = insertvalue { %"compiler/source:Span", i32, ptr } %t266, i32 %t267, 1
  %t270 = insertvalue { %"compiler/source:Span", i32, ptr } %t268, ptr %t262, 2
  %t271 = getelementptr { i64, [5 x i64] }, ptr %t263, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t270, ptr %t271
  %t272 = load { i64, [5 x i64] }, ptr %t263
  %t274 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t272, ptr %t274
  store ptr %t274, ptr %rv
  br label %ret
bb36:
  %t276 = load ptr, ptr %l1, !tbaa !29
  store ptr %t276, ptr %l148, !tbaa !29
  store i1 false, ptr %l149, !tbaa !21
  %t277 = load ptr, ptr %l148, !tbaa !29
  %t278 = icmp ne ptr %t277, null
  br i1 %t278, label %bb37, label %bb38
bb37:
  %t280 = load ptr, ptr %l148, !tbaa !29
  %t281 = load i64, ptr %t280, !range !{i64 0, i64 18}
  %t283 = icmp eq i64 %t281, 6
  store i1 %t283, ptr %l149, !tbaa !21
  br label %bb38
bb38:
  %t284 = load i1, ptr %l149, !tbaa !21
  br i1 %t284, label %bb39, label %bb40
bb39:
  %t285 = load ptr, ptr %l1, !tbaa !29
  %t287 = getelementptr { i64, [5 x i64] }, ptr %t285, i32 0, i32 1
  %t288 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t287, i32 0, i32 0
  %t289 = load %"compiler/source:Span", ptr %t288
  store %"compiler/source:Span" %t289, ptr %l20
  %t291 = load ptr, ptr %l1, !tbaa !29
  %t293 = getelementptr { i64, [5 x i64] }, ptr %t291, i32 0, i32 1
  %t294 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t293, i32 0, i32 1
  %t295 = load i32, ptr %t294
  store i32 %t295, ptr %l21, !tbaa !23
  %t297 = load ptr, ptr %l1, !tbaa !29
  %t299 = getelementptr { i64, [5 x i64] }, ptr %t297, i32 0, i32 1
  %t300 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t299, i32 0, i32 2
  %t301 = load ptr, ptr %t300
  store ptr %t301, ptr %l22, !tbaa !29
  br label %bb41
bb40:
  br label %bb45
bb41:
  %t303 = load %"compiler/source:Span", ptr %l20
  store %"compiler/source:Span" %t303, ptr %l158
  %t304 = load i32, ptr %l21, !tbaa !23
  store i32 %t304, ptr %l159, !tbaa !23
  %t305 = load ptr, ptr %l22, !tbaa !29
  %t307 = getelementptr %"compiler/typed:Call", ptr %t305, i32 0, i32 0
  %t308 = load ptr, ptr %t307, !tbaa !29
  store ptr %t308, ptr %l161, !tbaa !29
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t310 = load ptr, ptr %l22, !tbaa !29
  %t312 = getelementptr %"compiler/typed:Call", ptr %t310, i32 0, i32 1
  %t313 = load { i64, ptr }, ptr %t312, !tbaa !27
  %t314 = load i64, ptr %l2, !tbaa !24
  %t318 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyAll(ptr %v0, ptr %v1, ptr %t309, { i64, ptr } %t313, i64 %t314)
  store { i64, ptr } %t318, ptr %l166
  br label %bb42
bb42:
  %t319 = load ptr, ptr %l22, !tbaa !29
  %t321 = getelementptr %"compiler/typed:Call", ptr %t319, i32 0, i32 2
  %t322 = load { i64, [2 x i64] }, ptr %t321
  store { i64, [2 x i64] } %t322, ptr %l168
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = load ptr, ptr %l22, !tbaa !29
  %t326 = getelementptr %"compiler/typed:Call", ptr %t324, i32 0, i32 3
  %t327 = load i32, ptr %t326, !tbaa !23
  %t328 = load i64, ptr %l2, !tbaa !24
  %t332 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereSite(ptr %v0, ptr %t323, i32 %t327, i64 %t328)
  store i32 %t332, ptr %l173
  br label %bb43
bb43:
  %t333 = load ptr, ptr %l22, !tbaa !29
  %t335 = getelementptr %"compiler/typed:Call", ptr %t333, i32 0, i32 4
  %t336 = load i1, ptr %t335, !tbaa !21
  %t337 = load ptr, ptr %l161, !tbaa !29
  %t338 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t339 = load { i64, [2 x i64] }, ptr %l168
  %t340 = load i32, ptr %l173, !tbaa !23
  %t342 = call %"compiler/typed:Call" @compiler_2ftyped_3aCall_2ector(ptr %v1, ptr %v0, ptr %v0, ptr %t337, { i64, ptr } %t338, { i64, [2 x i64] } %t339, i32 %t340, i1 %t336, i1 false)
  store %"compiler/typed:Call" %t342, ptr %l176
  br label %bb44
bb44:
  %t343 = load %"compiler/typed:Call", ptr %l176
  %t344 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/typed:Call" %t343, ptr %t344
  store { i64, [5 x i64] } zeroinitializer, ptr %t345
  %t346 = getelementptr { i64, [5 x i64] }, ptr %t345, i32 0, i32 0
  store i64 6, ptr %t346
  %t347 = load %"compiler/source:Span", ptr %l158
  %t348 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t347, 0
  %t349 = load i32, ptr %l159, !tbaa !23
  %t350 = insertvalue { %"compiler/source:Span", i32, ptr } %t348, i32 %t349, 1
  %t352 = insertvalue { %"compiler/source:Span", i32, ptr } %t350, ptr %t344, 2
  %t353 = getelementptr { i64, [5 x i64] }, ptr %t345, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t352, ptr %t353
  %t354 = load { i64, [5 x i64] }, ptr %t345
  %t356 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t354, ptr %t356
  store ptr %t356, ptr %rv
  br label %ret
bb45:
  %t358 = load ptr, ptr %l1, !tbaa !29
  store ptr %t358, ptr %l180, !tbaa !29
  store i1 false, ptr %l181, !tbaa !21
  %t359 = load ptr, ptr %l180, !tbaa !29
  %t360 = icmp ne ptr %t359, null
  br i1 %t360, label %bb46, label %bb47
bb46:
  %t362 = load ptr, ptr %l180, !tbaa !29
  %t363 = load i64, ptr %t362, !range !{i64 0, i64 18}
  %t365 = icmp eq i64 %t363, 7
  store i1 %t365, ptr %l181, !tbaa !21
  br label %bb47
bb47:
  %t366 = load i1, ptr %l181, !tbaa !21
  br i1 %t366, label %bb48, label %bb49
bb48:
  %t367 = load ptr, ptr %l1, !tbaa !29
  %t369 = getelementptr { i64, [5 x i64] }, ptr %t367, i32 0, i32 1
  %t370 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t369, i32 0, i32 0
  %t371 = load %"compiler/source:Span", ptr %t370
  store %"compiler/source:Span" %t371, ptr %l23
  %t373 = load ptr, ptr %l1, !tbaa !29
  %t375 = getelementptr { i64, [5 x i64] }, ptr %t373, i32 0, i32 1
  %t376 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t375, i32 0, i32 1
  %t377 = load i32, ptr %t376
  store i32 %t377, ptr %l24, !tbaa !23
  %t379 = load ptr, ptr %l1, !tbaa !29
  %t381 = getelementptr { i64, [5 x i64] }, ptr %t379, i32 0, i32 1
  %t382 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t381, i32 0, i32 2
  %t383 = load ptr, ptr %t382
  store ptr %t383, ptr %l25, !tbaa !29
  br label %bb50
bb49:
  br label %bb61
bb50:
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t386 = load ptr, ptr %l25, !tbaa !29
  %t388 = getelementptr %"compiler/typed:Make", ptr %t386, i32 0, i32 2
  %t389 = load { i64, ptr }, ptr %t388, !tbaa !27
  %t390 = load i64, ptr %l2, !tbaa !24
  %t394 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyAll(ptr %v0, ptr %v1, ptr %t385, { i64, ptr } %t389, i64 %t390)
  store { i64, ptr } %t394, ptr %l194
  br label %bb51
bb51:
  %t395 = load { i64, ptr }, ptr %l194, !tbaa !27
  store { i64, ptr } %t395, ptr %l26, !tbaa !27
  store ptr null, ptr %l27, !tbaa !29
  %t396 = load ptr, ptr %l25, !tbaa !29
  %t398 = getelementptr %"compiler/typed:Make", ptr %t396, i32 0, i32 3
  %t399 = load ptr, ptr %t398, !tbaa !29
  %t401 = icmp eq ptr %t399, null
  %t403 = xor i1 %t401, true
  br i1 %t403, label %bb52, label %bb53
bb52:
  %t405 = load ptr, ptr %l0, !tbaa !29
  store ptr %t405, ptr %l199, !tbaa !29
  %t406 = load ptr, ptr %l25, !tbaa !29
  %t408 = getelementptr %"compiler/typed:Make", ptr %t406, i32 0, i32 3
  %t409 = load ptr, ptr %t408, !tbaa !29
  %t411 = icmp eq ptr %t409, null
  br i1 %t411, label %bb54, label %bb55
bb53:
  br label %bb58
bb54:
  call void @__olang_check_failed(ptr @olang_loc_4aef7e9433005aa6_9cd0eb13e1392442)
  unreachable
bb55:
  br label %bb56
bb56:
  %t413 = load ptr, ptr %l25, !tbaa !29
  %t415 = getelementptr %"compiler/typed:Make", ptr %t413, i32 0, i32 3
  %t416 = load ptr, ptr %t415, !tbaa !29
  %t417 = load i64, ptr %l2, !tbaa !24
  %t418 = load ptr, ptr %l199, !tbaa !29
  %t421 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %t418, ptr %t416, i64 %t417)
  store ptr %t421, ptr %l206
  br label %bb57
bb57:
  %t422 = load ptr, ptr %l206, !tbaa !29
  store ptr %t422, ptr %l27, !tbaa !29
  br label %bb58
bb58:
  %t424 = load %"compiler/source:Span", ptr %l23
  store %"compiler/source:Span" %t424, ptr %l208
  %t425 = load i32, ptr %l24, !tbaa !23
  store i32 %t425, ptr %l209, !tbaa !23
  %t426 = load ptr, ptr %l25, !tbaa !29
  %t428 = getelementptr %"compiler/typed:Make", ptr %t426, i32 0, i32 0
  %t429 = load i32, ptr %t428, !range !{i32 0, i32 4}
  store i32 %t429, ptr %l211
  %t430 = load ptr, ptr %l25, !tbaa !29
  %t432 = getelementptr %"compiler/typed:Make", ptr %t430, i32 0, i32 1
  %t433 = load i64, ptr %t432, !tbaa !24
  store i64 %t433, ptr %l213, !tbaa !24
  %t434 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t434, ptr %l214, !tbaa !27
  %t435 = load ptr, ptr %l27, !tbaa !29
  store ptr %t435, ptr %l215, !tbaa !29
  %t436 = load ptr, ptr %l0, !tbaa !29
  %t437 = load ptr, ptr %l25, !tbaa !29
  %t439 = getelementptr %"compiler/typed:Make", ptr %t437, i32 0, i32 4
  %t440 = load i32, ptr %t439, !tbaa !23
  %t441 = load i64, ptr %l2, !tbaa !24
  %t445 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereSite(ptr %v0, ptr %t436, i32 %t440, i64 %t441)
  store i32 %t445, ptr %l220
  br label %bb59
bb59:
  %t446 = load ptr, ptr %l25, !tbaa !29
  %t448 = getelementptr %"compiler/typed:Make", ptr %t446, i32 0, i32 5
  %t449 = load i32, ptr %t448, !range !{i32 0, i32 3}
  %t450 = load i32, ptr %l211, !range !{i32 0, i32 4}
  %t451 = load i64, ptr %l213, !tbaa !24
  %t452 = load { i64, ptr }, ptr %l214, !tbaa !27
  %t453 = load ptr, ptr %l215, !tbaa !29
  %t454 = load i32, ptr %l220, !tbaa !23
  %t456 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t450, i64 %t451, { i64, ptr } %t452, ptr %t453, i32 %t454, i32 %t449, i1 false)
  store %"compiler/typed:Make" %t456, ptr %l223
  br label %bb60
bb60:
  %t457 = load %"compiler/typed:Make", ptr %l223
  %t458 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/typed:Make" %t457, ptr %t458
  store { i64, [5 x i64] } zeroinitializer, ptr %t459
  %t460 = getelementptr { i64, [5 x i64] }, ptr %t459, i32 0, i32 0
  store i64 7, ptr %t460
  %t461 = load %"compiler/source:Span", ptr %l208
  %t462 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t461, 0
  %t463 = load i32, ptr %l209, !tbaa !23
  %t464 = insertvalue { %"compiler/source:Span", i32, ptr } %t462, i32 %t463, 1
  %t466 = insertvalue { %"compiler/source:Span", i32, ptr } %t464, ptr %t458, 2
  %t467 = getelementptr { i64, [5 x i64] }, ptr %t459, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t466, ptr %t467
  %t468 = load { i64, [5 x i64] }, ptr %t459
  %t470 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t468, ptr %t470
  store ptr %t470, ptr %rv
  br label %ret
bb61:
  %t472 = load ptr, ptr %l1, !tbaa !29
  store ptr %t472, ptr %l227, !tbaa !29
  store i1 false, ptr %l228, !tbaa !21
  %t473 = load ptr, ptr %l227, !tbaa !29
  %t474 = icmp ne ptr %t473, null
  br i1 %t474, label %bb62, label %bb63
bb62:
  %t476 = load ptr, ptr %l227, !tbaa !29
  %t477 = load i64, ptr %t476, !range !{i64 0, i64 18}
  %t479 = icmp eq i64 %t477, 9
  store i1 %t479, ptr %l228, !tbaa !21
  br label %bb63
bb63:
  %t480 = load i1, ptr %l228, !tbaa !21
  br i1 %t480, label %bb64, label %bb65
bb64:
  %t481 = load ptr, ptr %l1, !tbaa !29
  %t483 = getelementptr { i64, [5 x i64] }, ptr %t481, i32 0, i32 1
  %t484 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t483, i32 0, i32 0
  %t485 = load %"compiler/source:Span", ptr %t484
  store %"compiler/source:Span" %t485, ptr %l28
  %t487 = load ptr, ptr %l1, !tbaa !29
  %t489 = getelementptr { i64, [5 x i64] }, ptr %t487, i32 0, i32 1
  %t490 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t489, i32 0, i32 1
  %t491 = load i32, ptr %t490
  store i32 %t491, ptr %l29, !tbaa !23
  %t493 = load ptr, ptr %l1, !tbaa !29
  %t495 = getelementptr { i64, [5 x i64] }, ptr %t493, i32 0, i32 1
  %t496 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t495, i32 0, i32 2
  %t497 = load i32, ptr %t496, !range !{i32 0, i32 43}
  store i32 %t497, ptr %l30
  %t499 = load ptr, ptr %l1, !tbaa !29
  %t501 = getelementptr { i64, [5 x i64] }, ptr %t499, i32 0, i32 1
  %t502 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t501, i32 0, i32 3
  %t503 = load i32, ptr %t502, !range !{i32 0, i32 3}
  store i32 %t503, ptr %l31
  %t505 = load ptr, ptr %l1, !tbaa !29
  %t507 = getelementptr { i64, [5 x i64] }, ptr %t505, i32 0, i32 1
  %t508 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t507, i32 0, i32 4
  %t509 = load { i64, ptr }, ptr %t508
  store { i64, ptr } %t509, ptr %l32, !tbaa !27
  br label %bb66
bb65:
  br label %bb68
bb66:
  %t511 = load %"compiler/source:Span", ptr %l28
  store %"compiler/source:Span" %t511, ptr %l241
  %t512 = load i32, ptr %l29, !tbaa !23
  store i32 %t512, ptr %l242, !tbaa !23
  %t513 = load i32, ptr %l30, !range !{i32 0, i32 43}
  store i32 %t513, ptr %l243
  %t514 = load i32, ptr %l31, !range !{i32 0, i32 3}
  store i32 %t514, ptr %l244
  %t515 = load ptr, ptr %l0, !tbaa !29
  %t516 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t517 = load i64, ptr %l2, !tbaa !24
  %t521 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyAll(ptr %v0, ptr %v1, ptr %t515, { i64, ptr } %t516, i64 %t517)
  store { i64, ptr } %t521, ptr %l248
  br label %bb67
bb67:
  store { i64, [5 x i64] } zeroinitializer, ptr %t522
  %t523 = getelementptr { i64, [5 x i64] }, ptr %t522, i32 0, i32 0
  store i64 9, ptr %t523
  %t524 = load %"compiler/source:Span", ptr %l241
  %t525 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t524, 0
  %t526 = load i32, ptr %l242, !tbaa !23
  %t527 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t525, i32 %t526, 1
  %t528 = load i32, ptr %l243, !range !{i32 0, i32 43}
  %t529 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t527, i32 %t528, 2
  %t530 = load i32, ptr %l244, !range !{i32 0, i32 3}
  %t531 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t529, i32 %t530, 3
  %t532 = load { i64, ptr }, ptr %l248, !tbaa !27
  %t533 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t531, { i64, ptr } %t532, 4
  %t534 = getelementptr { i64, [5 x i64] }, ptr %t522, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t533, ptr %t534
  %t535 = load { i64, [5 x i64] }, ptr %t522
  %t537 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t535, ptr %t537
  store ptr %t537, ptr %rv
  br label %ret
bb68:
  %t539 = load ptr, ptr %l1, !tbaa !29
  store ptr %t539, ptr %l251, !tbaa !29
  store i1 false, ptr %l252, !tbaa !21
  %t540 = load ptr, ptr %l251, !tbaa !29
  %t541 = icmp ne ptr %t540, null
  br i1 %t541, label %bb69, label %bb70
bb69:
  %t543 = load ptr, ptr %l251, !tbaa !29
  %t544 = load i64, ptr %t543, !range !{i64 0, i64 18}
  %t546 = icmp eq i64 %t544, 10
  store i1 %t546, ptr %l252, !tbaa !21
  br label %bb70
bb70:
  %t547 = load i1, ptr %l252, !tbaa !21
  br i1 %t547, label %bb71, label %bb72
bb71:
  %t548 = load ptr, ptr %l1, !tbaa !29
  %t550 = getelementptr { i64, [5 x i64] }, ptr %t548, i32 0, i32 1
  %t551 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t550, i32 0, i32 0
  %t552 = load %"compiler/source:Span", ptr %t551
  store %"compiler/source:Span" %t552, ptr %l33
  %t554 = load ptr, ptr %l1, !tbaa !29
  %t556 = getelementptr { i64, [5 x i64] }, ptr %t554, i32 0, i32 1
  %t557 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t556, i32 0, i32 1
  %t558 = load i32, ptr %t557
  store i32 %t558, ptr %l34, !tbaa !23
  %t560 = load ptr, ptr %l1, !tbaa !29
  %t562 = getelementptr { i64, [5 x i64] }, ptr %t560, i32 0, i32 1
  %t563 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t562, i32 0, i32 2
  %t564 = load ptr, ptr %t563
  store ptr %t564, ptr %l35, !tbaa !29
  br label %bb73
bb72:
  br label %bb78
bb73:
  %t566 = load %"compiler/source:Span", ptr %l33
  store %"compiler/source:Span" %t566, ptr %l261
  %t567 = load i32, ptr %l34, !tbaa !23
  store i32 %t567, ptr %l262, !tbaa !23
  %t568 = load ptr, ptr %l0, !tbaa !29
  %t569 = load ptr, ptr %l35, !tbaa !29
  %t571 = getelementptr %"compiler/typed:Slice", ptr %t569, i32 0, i32 0
  %t572 = load ptr, ptr %t571, !tbaa !29
  %t573 = load i64, ptr %l2, !tbaa !24
  %t577 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyPlace(ptr %v0, ptr %v1, ptr %t568, ptr %t572, i64 %t573)
  store ptr %t577, ptr %l267
  br label %bb74
bb74:
  %t578 = load ptr, ptr %l0, !tbaa !29
  %t579 = load ptr, ptr %l35, !tbaa !29
  %t581 = getelementptr %"compiler/typed:Slice", ptr %t579, i32 0, i32 1
  %t582 = load ptr, ptr %t581, !tbaa !29
  %t583 = load i64, ptr %l2, !tbaa !24
  %t587 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %t578, ptr %t582, i64 %t583)
  store ptr %t587, ptr %l272
  br label %bb75
bb75:
  %t588 = load ptr, ptr %l0, !tbaa !29
  %t589 = load ptr, ptr %l35, !tbaa !29
  %t591 = getelementptr %"compiler/typed:Slice", ptr %t589, i32 0, i32 2
  %t592 = load ptr, ptr %t591, !tbaa !29
  %t593 = load i64, ptr %l2, !tbaa !24
  %t597 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %t588, ptr %t592, i64 %t593)
  store ptr %t597, ptr %l277
  br label %bb76
bb76:
  %t598 = load ptr, ptr %l35, !tbaa !29
  %t600 = getelementptr %"compiler/typed:Slice", ptr %t598, i32 0, i32 3
  %t601 = load i32, ptr %t600, !range !{i32 0, i32 3}
  %t602 = load ptr, ptr %l267, !tbaa !29
  %t603 = load ptr, ptr %l272, !tbaa !29
  %t604 = load ptr, ptr %l277, !tbaa !29
  %t606 = call %"compiler/typed:Slice" @compiler_2ftyped_3aSlice_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t602, ptr %t603, ptr %t604, i32 %t601)
  store %"compiler/typed:Slice" %t606, ptr %l280
  br label %bb77
bb77:
  %t607 = load %"compiler/typed:Slice", ptr %l280
  %t608 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/typed:Slice" %t607, ptr %t608
  store { i64, [5 x i64] } zeroinitializer, ptr %t609
  %t610 = getelementptr { i64, [5 x i64] }, ptr %t609, i32 0, i32 0
  store i64 10, ptr %t610
  %t611 = load %"compiler/source:Span", ptr %l261
  %t612 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t611, 0
  %t613 = load i32, ptr %l262, !tbaa !23
  %t614 = insertvalue { %"compiler/source:Span", i32, ptr } %t612, i32 %t613, 1
  %t616 = insertvalue { %"compiler/source:Span", i32, ptr } %t614, ptr %t608, 2
  %t617 = getelementptr { i64, [5 x i64] }, ptr %t609, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t616, ptr %t617
  %t618 = load { i64, [5 x i64] }, ptr %t609
  %t620 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t618, ptr %t620
  store ptr %t620, ptr %rv
  br label %ret
bb78:
  %t622 = load ptr, ptr %l1, !tbaa !29
  store ptr %t622, ptr %l284, !tbaa !29
  store i1 false, ptr %l285, !tbaa !21
  %t623 = load ptr, ptr %l284, !tbaa !29
  %t624 = icmp ne ptr %t623, null
  br i1 %t624, label %bb79, label %bb80
bb79:
  %t626 = load ptr, ptr %l284, !tbaa !29
  %t627 = load i64, ptr %t626, !range !{i64 0, i64 18}
  %t629 = icmp eq i64 %t627, 11
  store i1 %t629, ptr %l285, !tbaa !21
  br label %bb80
bb80:
  %t630 = load i1, ptr %l285, !tbaa !21
  br i1 %t630, label %bb81, label %bb82
bb81:
  %t631 = load ptr, ptr %l1, !tbaa !29
  %t633 = getelementptr { i64, [5 x i64] }, ptr %t631, i32 0, i32 1
  %t634 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t633, i32 0, i32 0
  %t635 = load %"compiler/source:Span", ptr %t634
  store %"compiler/source:Span" %t635, ptr %l36
  %t637 = load ptr, ptr %l1, !tbaa !29
  %t639 = getelementptr { i64, [5 x i64] }, ptr %t637, i32 0, i32 1
  %t640 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t639, i32 0, i32 1
  %t641 = load i32, ptr %t640
  store i32 %t641, ptr %l37, !tbaa !23
  %t643 = load ptr, ptr %l1, !tbaa !29
  %t645 = getelementptr { i64, [5 x i64] }, ptr %t643, i32 0, i32 1
  %t646 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t645, i32 0, i32 2
  %t647 = load ptr, ptr %t646
  store ptr %t647, ptr %l38, !tbaa !29
  br label %bb83
bb82:
  br label %bb94
bb83:
  store ptr null, ptr %l39, !tbaa !29
  %t649 = load ptr, ptr %l38, !tbaa !29
  %t651 = getelementptr %"compiler/typed:Cond", ptr %t649, i32 0, i32 1
  %t652 = load ptr, ptr %t651, !tbaa !29
  %t654 = icmp eq ptr %t652, null
  %t656 = xor i1 %t654, true
  br i1 %t656, label %bb84, label %bb85
bb84:
  %t658 = load ptr, ptr %l0, !tbaa !29
  store ptr %t658, ptr %l298, !tbaa !29
  %t659 = load ptr, ptr %l38, !tbaa !29
  %t661 = getelementptr %"compiler/typed:Cond", ptr %t659, i32 0, i32 1
  %t662 = load ptr, ptr %t661, !tbaa !29
  %t664 = icmp eq ptr %t662, null
  br i1 %t664, label %bb86, label %bb87
bb85:
  br label %bb90
bb86:
  call void @__olang_check_failed(ptr @olang_loc_89a248f11218248d_cad7b116269b1029)
  unreachable
bb87:
  br label %bb88
bb88:
  %t666 = load ptr, ptr %l38, !tbaa !29
  %t668 = getelementptr %"compiler/typed:Cond", ptr %t666, i32 0, i32 1
  %t669 = load ptr, ptr %t668, !tbaa !29
  %t670 = load i64, ptr %l2, !tbaa !24
  %t671 = load ptr, ptr %l298, !tbaa !29
  %t674 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %t671, ptr %t669, i64 %t670)
  store ptr %t674, ptr %l305
  br label %bb89
bb89:
  %t675 = load ptr, ptr %l305, !tbaa !29
  store ptr %t675, ptr %l39, !tbaa !29
  br label %bb90
bb90:
  %t677 = load %"compiler/source:Span", ptr %l36
  store %"compiler/source:Span" %t677, ptr %l307
  %t678 = load i32, ptr %l37, !tbaa !23
  store i32 %t678, ptr %l308, !tbaa !23
  %t679 = load ptr, ptr %l0, !tbaa !29
  %t680 = load ptr, ptr %l38, !tbaa !29
  %t682 = getelementptr %"compiler/typed:Cond", ptr %t680, i32 0, i32 0
  %t683 = load ptr, ptr %t682, !tbaa !29
  %t684 = load i64, ptr %l2, !tbaa !24
  %t688 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %t679, ptr %t683, i64 %t684)
  store ptr %t688, ptr %l313
  br label %bb91
bb91:
  %t689 = load ptr, ptr %l39, !tbaa !29
  store ptr %t689, ptr %l314, !tbaa !29
  %t690 = load ptr, ptr %l0, !tbaa !29
  %t691 = load ptr, ptr %l38, !tbaa !29
  %t693 = getelementptr %"compiler/typed:Cond", ptr %t691, i32 0, i32 2
  %t694 = load ptr, ptr %t693, !tbaa !29
  %t695 = load i64, ptr %l2, !tbaa !24
  %t699 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %t690, ptr %t694, i64 %t695)
  store ptr %t699, ptr %l319
  br label %bb92
bb92:
  %t700 = load ptr, ptr %l313, !tbaa !29
  %t701 = load ptr, ptr %l314, !tbaa !29
  %t702 = load ptr, ptr %l319, !tbaa !29
  %t703 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t700, ptr %t701, ptr %t702)
  store %"compiler/typed:Cond" %t703, ptr %l320
  br label %bb93
bb93:
  %t704 = load %"compiler/typed:Cond", ptr %l320
  %t705 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Cond" %t704, ptr %t705
  store { i64, [5 x i64] } zeroinitializer, ptr %t706
  %t707 = getelementptr { i64, [5 x i64] }, ptr %t706, i32 0, i32 0
  store i64 11, ptr %t707
  %t708 = load %"compiler/source:Span", ptr %l307
  %t709 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t708, 0
  %t710 = load i32, ptr %l308, !tbaa !23
  %t711 = insertvalue { %"compiler/source:Span", i32, ptr } %t709, i32 %t710, 1
  %t713 = insertvalue { %"compiler/source:Span", i32, ptr } %t711, ptr %t705, 2
  %t714 = getelementptr { i64, [5 x i64] }, ptr %t706, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t713, ptr %t714
  %t715 = load { i64, [5 x i64] }, ptr %t706
  %t717 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t715, ptr %t717
  store ptr %t717, ptr %rv
  br label %ret
bb94:
  %t719 = load ptr, ptr %l1, !tbaa !29
  store ptr %t719, ptr %l324, !tbaa !29
  store i1 false, ptr %l325, !tbaa !21
  %t720 = load ptr, ptr %l324, !tbaa !29
  %t721 = icmp ne ptr %t720, null
  br i1 %t721, label %bb95, label %bb96
bb95:
  %t723 = load ptr, ptr %l324, !tbaa !29
  %t724 = load i64, ptr %t723, !range !{i64 0, i64 18}
  %t726 = icmp eq i64 %t724, 17
  store i1 %t726, ptr %l325, !tbaa !21
  br label %bb96
bb96:
  %t727 = load i1, ptr %l325, !tbaa !21
  br i1 %t727, label %bb97, label %bb98
bb97:
  %t728 = load ptr, ptr %l1, !tbaa !29
  %t730 = getelementptr { i64, [5 x i64] }, ptr %t728, i32 0, i32 1
  %t731 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t730, i32 0, i32 0
  %t732 = load %"compiler/source:Span", ptr %t731
  store %"compiler/source:Span" %t732, ptr %l40
  %t734 = load ptr, ptr %l1, !tbaa !29
  %t736 = getelementptr { i64, [5 x i64] }, ptr %t734, i32 0, i32 1
  %t737 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t736, i32 0, i32 1
  %t738 = load i64, ptr %t737
  store i64 %t738, ptr %l41, !tbaa !24
  %t740 = load ptr, ptr %l1, !tbaa !29
  %t742 = getelementptr { i64, [5 x i64] }, ptr %t740, i32 0, i32 1
  %t743 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t742, i32 0, i32 2
  %t744 = load ptr, ptr %t743
  store ptr %t744, ptr %l42, !tbaa !29
  br label %bb99
bb98:
  br label %bb101
bb99:
  %t746 = load %"compiler/source:Span", ptr %l40
  store %"compiler/source:Span" %t746, ptr %l334
  %t747 = load i64, ptr %l41, !tbaa !24
  store i64 %t747, ptr %l335, !tbaa !24
  %t748 = load ptr, ptr %l0, !tbaa !29
  %t749 = load ptr, ptr %l42, !tbaa !29
  %t750 = load i64, ptr %l2, !tbaa !24
  %t754 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %t748, ptr %t749, i64 %t750)
  store ptr %t754, ptr %l339
  br label %bb100
bb100:
  store { i64, [5 x i64] } zeroinitializer, ptr %t755
  %t756 = getelementptr { i64, [5 x i64] }, ptr %t755, i32 0, i32 0
  store i64 17, ptr %t756
  %t757 = load %"compiler/source:Span", ptr %l334
  %t758 = insertvalue { %"compiler/source:Span", i64, ptr } undef, %"compiler/source:Span" %t757, 0
  %t759 = load i64, ptr %l335, !tbaa !24
  %t760 = insertvalue { %"compiler/source:Span", i64, ptr } %t758, i64 %t759, 1
  %t761 = load ptr, ptr %l339, !tbaa !29
  %t762 = insertvalue { %"compiler/source:Span", i64, ptr } %t760, ptr %t761, 2
  %t763 = getelementptr { i64, [5 x i64] }, ptr %t755, i32 0, i32 1
  store { %"compiler/source:Span", i64, ptr } %t762, ptr %t763
  %t764 = load { i64, [5 x i64] }, ptr %t755
  %t766 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t764, ptr %t766
  store ptr %t766, ptr %rv
  br label %ret
bb101:
  %t768 = load ptr, ptr %l1, !tbaa !29
  store ptr %t768, ptr %l342, !tbaa !29
  store i1 false, ptr %l343, !tbaa !21
  %t769 = load ptr, ptr %l342, !tbaa !29
  %t770 = icmp ne ptr %t769, null
  br i1 %t770, label %bb102, label %bb103
bb102:
  %t772 = load ptr, ptr %l342, !tbaa !29
  %t773 = load i64, ptr %t772, !range !{i64 0, i64 18}
  %t775 = icmp eq i64 %t773, 15
  store i1 %t775, ptr %l343, !tbaa !21
  br label %bb103
bb103:
  %t776 = load i1, ptr %l343, !tbaa !21
  br i1 %t776, label %bb104, label %bb105
bb104:
  %t777 = load ptr, ptr %l1, !tbaa !29
  %t779 = getelementptr { i64, [5 x i64] }, ptr %t777, i32 0, i32 1
  %t780 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t779, i32 0, i32 0
  %t781 = load %"compiler/source:Span", ptr %t780
  store %"compiler/source:Span" %t781, ptr %l43
  %t783 = load ptr, ptr %l1, !tbaa !29
  %t785 = getelementptr { i64, [5 x i64] }, ptr %t783, i32 0, i32 1
  %t786 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t785, i32 0, i32 1
  %t787 = load i32, ptr %t786
  store i32 %t787, ptr %l44, !tbaa !23
  %t789 = load ptr, ptr %l1, !tbaa !29
  %t791 = getelementptr { i64, [5 x i64] }, ptr %t789, i32 0, i32 1
  %t792 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t791, i32 0, i32 2
  %t793 = load ptr, ptr %t792
  store ptr %t793, ptr %l45, !tbaa !29
  br label %bb106
bb105:
  br label %bb118
bb106:
  %t795 = load ptr, ptr %l45, !tbaa !29
  store ptr %t795, ptr %l352, !tbaa !29
  store i1 false, ptr %l353, !tbaa !21
  %t796 = load ptr, ptr %l352, !tbaa !29
  %t797 = icmp ne ptr %t796, null
  br i1 %t797, label %bb107, label %bb108
bb107:
  %t799 = load ptr, ptr %l352, !tbaa !29
  %t800 = load i64, ptr %t799, !range !{i64 0, i64 3}
  %t802 = icmp eq i64 %t800, 0
  store i1 %t802, ptr %l353, !tbaa !21
  br label %bb108
bb108:
  %t803 = load i1, ptr %l353, !tbaa !21
  br i1 %t803, label %bb109, label %bb110
bb109:
  %t804 = load ptr, ptr %l45, !tbaa !29
  %t806 = getelementptr { i64, [4 x i64] }, ptr %t804, i32 0, i32 1
  %t807 = getelementptr { i32 }, ptr %t806, i32 0, i32 0
  %t808 = load i32, ptr %t807
  store i32 %t808, ptr %l46, !tbaa !23
  br label %bb111
bb110:
  br label %bb112
bb111:
  %t810 = load %"compiler/source:Span", ptr %l43
  %t811 = load i32, ptr %l44, !tbaa !23
  %t812 = load i32, ptr %l46, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t813
  %t814 = getelementptr { i64, [4 x i64] }, ptr %t813, i32 0, i32 0
  store i64 0, ptr %t814
  %t816 = insertvalue { i32 } undef, i32 %t812, 0
  %t817 = getelementptr { i64, [4 x i64] }, ptr %t813, i32 0, i32 1
  store { i32 } %t816, ptr %t817
  %t818 = load { i64, [4 x i64] }, ptr %t813
  %t820 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t818, ptr %t820
  store { i64, [5 x i64] } zeroinitializer, ptr %t821
  %t822 = getelementptr { i64, [5 x i64] }, ptr %t821, i32 0, i32 0
  store i64 15, ptr %t822
  %t824 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t810, 0
  %t826 = insertvalue { %"compiler/source:Span", i32, ptr } %t824, i32 %t811, 1
  %t828 = insertvalue { %"compiler/source:Span", i32, ptr } %t826, ptr %t820, 2
  %t829 = getelementptr { i64, [5 x i64] }, ptr %t821, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t828, ptr %t829
  %t830 = load { i64, [5 x i64] }, ptr %t821
  %t832 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t830, ptr %t832
  store ptr %t832, ptr %rv
  br label %ret
bb112:
  br i1 true, label %bb113, label %bb114
bb113:
  br label %bb115
bb114:
  br label %bb116
bb115:
  br label %bb117
bb116:
  call void @__olang_check_failed(ptr @olang_loc_eb46e205ba3ff6f_6cc0aaf3953c4d5b)
  unreachable
bb117:
  br label %bb123
bb118:
  br i1 true, label %bb119, label %bb120
bb119:
  br label %bb121
bb120:
  br label %bb122
bb121:
  br label %bb123
bb122:
  call void @__olang_check_failed(ptr @olang_loc_b8f4ea1c8ca382ae_7341728a048bae5a)
  unreachable
bb123:
  %t834 = load ptr, ptr %l0, !tbaa !29
  store ptr %t834, ptr %l365, !tbaa !29
  %t835 = load ptr, ptr %l1, !tbaa !29
  %t837 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t835)
  store %"compiler/source:Span" %t837, ptr %l367
  br label %bb124
bb124:
  %t838 = load ptr, ptr %l365, !tbaa !29
  %t839 = load %"compiler/source:Span", ptr %l367
  %t840 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t838, %"compiler/source:Span" %t839)
  store ptr %t840, ptr %l368
  br label %bb125
bb125:
  %t841 = load ptr, ptr %l368, !tbaa !29
  store ptr %t841, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectItems(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l6 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l13 = alloca ptr
  %t22 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 37
  store ptr %t8, ptr %l6, !tbaa !29
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v1, ptr %t9)
  store %"compiler/source:Span" %t11, ptr %l8
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l9, !tbaa !29
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v1, ptr %t13)
  store %"compiler/source:Span" %t15, ptr %l11
  br label %bb3
bb3:
  %t16 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t17 = load ptr, ptr %l9, !tbaa !29
  %t18 = load %"compiler/source:Span", ptr %l11
  %t20 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t17, %"compiler/source:Span" %t18, i32 %t16, i64 1)
  store ptr %t20, ptr %l13
  br label %bb4
bb4:
  %t21 = load ptr, ptr %l13, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t22
  %t23 = getelementptr { i64, [3 x i64] }, ptr %t22, i32 0, i32 0
  store i64 6, ptr %t23
  %t24 = load %"compiler/source:Span", ptr %l8
  %t25 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t24, 0
  %t27 = insertvalue { %"compiler/source:Span", ptr } %t25, ptr %t21, 1
  %t28 = getelementptr { i64, [3 x i64] }, ptr %t22, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t27, ptr %t28
  %t29 = load { i64, [3 x i64] }, ptr %t22
  %t31 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t29, ptr %t31
  %t32 = load ptr, ptr %l6, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t32, ptr %t31)
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectSourceOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i64
  %lp10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca ptr
  %l23 = alloca ptr
  %l32 = alloca i64
  %l36 = alloca ptr
  %l48 = alloca ptr
  %l50 = alloca ptr
  %l53 = alloca { i64, ptr }
  %l57 = alloca i64
  %l61 = alloca { i64, ptr }
  %l64 = alloca %"compiler/check:ctSource"
  %l73 = alloca i32
  %l77 = alloca ptr
  %l80 = alloca i1
  %l89 = alloca i64
  %l93 = alloca { i64, ptr }
  %l97 = alloca ptr
  %l98 = alloca i1
  %l106 = alloca i1
  %l130 = alloca %"compiler/check:ctSource"
  %l132 = alloca ptr
  %l133 = alloca i1
  %l140 = alloca i1
  %l158 = alloca %"compiler/check:ctSource"
  %l165 = alloca ptr
  %l169 = alloca { i64, ptr }
  %l170 = alloca { i64, ptr }
  %l173 = alloca ptr
  %l176 = alloca i1
  %l184 = alloca ptr
  %l188 = alloca { i64, ptr }
  %l189 = alloca { i64, ptr }
  %l192 = alloca i32
  %l198 = alloca %"compiler/source:Span"
  %l202 = alloca ptr
  %l206 = alloca %"compiler/ast:Param"
  %l214 = alloca ptr
  %l215 = alloca ptr
  %l218 = alloca { i64, ptr }
  %l223 = alloca i64
  %l226 = alloca { i64, ptr }
  %l230 = alloca { i64, ptr }
  %l233 = alloca %"compiler/check:ctSource"
  %s12 = alloca %olang.scope
  %rv = alloca ptr
  %t429 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 12
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l23
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l23, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 1
  %t11 = load { i64, [2 x i64] }, ptr %t10
  store { i64, [2 x i64] } %t11, ptr %l2
  %t13 = load { i64, [2 x i64] }, ptr %l2
  %t15 = extractvalue { i64, [2 x i64] } %t13, 0
  %t16 = icmp eq i64 %t15, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t19 = getelementptr { i64 }, ptr %t18, i32 0, i32 0
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l3, !tbaa !24
  br label %bb4
bb3:
  br label %bb16
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t25, i64 %t26)
  store i64 %t29, ptr %l32
  br label %bb5
bb5:
  %t30 = load i64, ptr %l32, !tbaa !24
  store i64 %t30, ptr %l4, !tbaa !24
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t35 = load i64, ptr %l4, !tbaa !24
  %t38 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t34, i64 %t35)
  store ptr %t38, ptr %l36
  br label %bb6
bb6:
  %t39 = load ptr, ptr %l36, !tbaa !29
  store ptr %t39, ptr %l5, !tbaa !29
  %t40 = load ptr, ptr %l5, !tbaa !29
  %t42 = getelementptr %"compiler/ast:Func", ptr %t40, i32 0, i32 3
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/ast:Sig", ptr %t43, i32 0, i32 5
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = icmp eq ptr %t46, null
  br i1 %t48, label %bb7, label %bb8
bb7:
  store ptr null, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t51 = load ptr, ptr %l5, !tbaa !29
  %t53 = getelementptr %"compiler/ast:Func", ptr %t51, i32 0, i32 3
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/ast:Sig", ptr %t54, i32 0, i32 5
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = icmp eq ptr %t57, null
  br i1 %t59, label %bb10, label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_700945490095e3ab_b793fb317cfa4b47)
  unreachable
bb11:
  br label %bb12
bb12:
  %t61 = load ptr, ptr %l5, !tbaa !29
  %t63 = getelementptr %"compiler/ast:Func", ptr %t61, i32 0, i32 3
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = getelementptr %"compiler/ast:Sig", ptr %t64, i32 0, i32 5
  %t67 = load ptr, ptr %t66, !tbaa !29
  store ptr %t67, ptr %l48, !tbaa !29
  %t68 = load ptr, ptr %l5, !tbaa !29
  %t70 = getelementptr %"compiler/ast:Func", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  store ptr %t71, ptr %l50, !tbaa !29
  %t72 = load ptr, ptr %l5, !tbaa !29
  %t74 = getelementptr %"compiler/ast:Func", ptr %t72, i32 0, i32 3
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t77 = getelementptr %"compiler/ast:Sig", ptr %t75, i32 0, i32 0
  %t78 = load { i64, ptr }, ptr %t77, !tbaa !27
  store { i64, ptr } %t78, ptr %l53, !tbaa !27
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t83 = load i64, ptr %l4, !tbaa !24
  %t86 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t82, i64 %t83)
  store i64 %t86, ptr %l57
  br label %bb13
bb13:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l5, !tbaa !29
  %t90 = getelementptr %"compiler/ast:Func", ptr %t88, i32 0, i32 2
  %t91 = load i32, ptr %t90, !tbaa !23
  %t94 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t87, i32 %t91)
  store { i64, ptr } %t94, ptr %l61
  br label %bb14
bb14:
  %t95 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t95, 1
  %t97 = extractvalue { i64, ptr } %t95, 0
  %t98 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t97)
  call void @olang_textcopy(ptr %t98, ptr %t96, i64 %t97)
  %t99 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = extractvalue { i64, ptr } %t100, 1
  %t104 = mul i64 %t102, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t104)
  call void @llvm.memcpy.p0.p0.i64(ptr %t105, ptr %t103, i64 %t104, i1 false)
  %t106 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  %t108 = load ptr, ptr %l48, !tbaa !29
  %t109 = load ptr, ptr %l50, !tbaa !29
  %t110 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t111 = load i64, ptr %l57, !tbaa !24
  %t113 = call %"compiler/check:ctSource" @compiler_2fcheck_3actSource_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t108, ptr %t109, { i64, ptr } %t110, i64 %t111, { i64, ptr } %t107)
  store %"compiler/check:ctSource" %t113, ptr %l64
  br label %bb15
bb15:
  %t114 = load %"compiler/check:ctSource", ptr %l64
  %t115 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/check:ctSource" %t114, ptr %t115
  store ptr %t115, ptr %rv
  br label %ret
bb16:
  %t117 = load { i64, [2 x i64] }, ptr %l2
  %t119 = extractvalue { i64, [2 x i64] } %t117, 0
  %t120 = icmp eq i64 %t119, 1
  br i1 %t120, label %bb17, label %bb18
bb17:
  %t122 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t123 = getelementptr { i32, i32 }, ptr %t122, i32 0, i32 0
  %t124 = load i32, ptr %t123
  store i32 %t124, ptr %l6, !tbaa !23
  br label %bb19
bb18:
  br label %bb72
bb19:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/check:Checker", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/generic:Program", ptr %t129, i32 0, i32 2
  %t132 = load i32, ptr %l6, !tbaa !23
  %t135 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t131, i32 %t132)
  store i32 %t135, ptr %l73
  br label %bb20
bb20:
  %t136 = load i32, ptr %l73, !tbaa !23
  store i32 %t136, ptr %l7, !tbaa !23
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/check:Checker", ptr %t137, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t141 = load i32, ptr %l7, !tbaa !23
  %t144 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t140, i32 %t141)
  store ptr %t144, ptr %l77
  br label %bb21
bb21:
  %t145 = load ptr, ptr %l77, !tbaa !29
  store ptr %t145, ptr %l8, !tbaa !29
  %t146 = load ptr, ptr %l8, !tbaa !29
  %t148 = icmp eq ptr %t146, null
  br i1 %t148, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l80, !tbaa !21
  br label %bb24
bb23:
  %t150 = load ptr, ptr %l8, !tbaa !29
  %t152 = getelementptr %"compiler/ast:TypeDecl", ptr %t150, i32 0, i32 3
  %t153 = load ptr, ptr %t152, !tbaa !29
  %t155 = icmp eq ptr %t153, null
  store i1 %t155, ptr %l80, !tbaa !21
  br label %bb24
bb24:
  %t157 = load i1, ptr %l80, !tbaa !21
  br i1 %t157, label %bb25, label %bb26
bb25:
  store ptr null, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/check:Checker", ptr %t159, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !29
  %t164 = getelementptr %"compiler/generic:Program", ptr %t162, i32 0, i32 2
  %t165 = load i32, ptr %l7, !tbaa !23
  %t168 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t164, i32 %t165)
  store i64 %t168, ptr %l89
  br label %bb28
bb28:
  %t169 = load i64, ptr %l89, !tbaa !24
  store i64 %t169, ptr %l9, !tbaa !24
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load ptr, ptr %l8, !tbaa !29
  %t173 = getelementptr %"compiler/ast:TypeDecl", ptr %t171, i32 0, i32 0
  %t174 = load i32, ptr %t173, !tbaa !23
  %t177 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t170, i32 %t174)
  store { i64, ptr } %t177, ptr %l93
  br label %bb29
bb29:
  %t178 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t178, 1
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t181 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t180)
  call void @olang_textcopy(ptr %t181, ptr %t179, i64 %t180)
  %t182 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t181, 1
  %t184 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t184, ptr %lp10
  %t186 = load ptr, ptr %lp10
  store { i64, ptr } %t183, ptr %t186, !tbaa !27
  %t187 = load ptr, ptr %l8, !tbaa !29
  %t189 = getelementptr %"compiler/ast:TypeDecl", ptr %t187, i32 0, i32 3
  %t190 = load ptr, ptr %t189, !tbaa !29
  store ptr %t190, ptr %l11, !tbaa !29
  %t192 = load ptr, ptr %l11, !tbaa !29
  store ptr %t192, ptr %l97, !tbaa !29
  store i1 false, ptr %l98, !tbaa !21
  %t193 = load ptr, ptr %l97, !tbaa !29
  %t194 = icmp ne ptr %t193, null
  br i1 %t194, label %bb30, label %bb31
bb30:
  %t196 = load ptr, ptr %l97, !tbaa !29
  %t197 = load i64, ptr %t196, !range !{i64 0, i64 5}
  %t199 = icmp eq i64 %t197, 0
  store i1 %t199, ptr %l98, !tbaa !21
  br label %bb31
bb31:
  %t200 = load i1, ptr %l98, !tbaa !21
  br i1 %t200, label %bb32, label %bb33
bb32:
  %t201 = load ptr, ptr %l11, !tbaa !29
  %t203 = getelementptr { i64, [6 x i64] }, ptr %t201, i32 0, i32 1
  %t204 = getelementptr { ptr }, ptr %t203, i32 0, i32 0
  %t205 = load ptr, ptr %t204
  store ptr %t205, ptr %l12, !tbaa !29
  br label %bb34
bb33:
  br label %bb51
bb34:
  %t207 = load ptr, ptr %l12, !tbaa !29
  %t209 = getelementptr %"compiler/ast:StructBody", ptr %t207, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !29
  %t212 = icmp eq ptr %t210, null
  br i1 %t212, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l106, !tbaa !21
  br label %bb40
bb36:
  %t214 = load ptr, ptr %l12, !tbaa !29
  %t216 = getelementptr %"compiler/ast:StructBody", ptr %t214, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !29
  %t219 = icmp eq ptr %t217, null
  br i1 %t219, label %bb37, label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_98b1a939df7bf83c_dad16d1edd3f2a28)
  unreachable
bb38:
  br label %bb39
bb39:
  %t221 = load ptr, ptr %l12, !tbaa !29
  %t223 = getelementptr %"compiler/ast:StructBody", ptr %t221, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !29
  %t227 = getelementptr %"compiler/ast:Sig", ptr %t224, i32 0, i32 5
  %t228 = load ptr, ptr %t227, !tbaa !29
  %t230 = icmp eq ptr %t228, null
  store i1 %t230, ptr %l106, !tbaa !21
  br label %bb40
bb40:
  %t232 = load i1, ptr %l106, !tbaa !21
  br i1 %t232, label %bb41, label %bb42
bb41:
  store ptr null, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  %t234 = load ptr, ptr %l12, !tbaa !29
  %t236 = getelementptr %"compiler/ast:StructBody", ptr %t234, i32 0, i32 1
  %t237 = load ptr, ptr %t236, !tbaa !29
  %t239 = icmp eq ptr %t237, null
  br i1 %t239, label %bb44, label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_25ec48d7738ec131_33504a893c084afd)
  unreachable
bb45:
  br label %bb46
bb46:
  %t241 = load ptr, ptr %l12, !tbaa !29
  %t243 = getelementptr %"compiler/ast:StructBody", ptr %t241, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !29
  %t247 = getelementptr %"compiler/ast:Sig", ptr %t244, i32 0, i32 5
  %t248 = load ptr, ptr %t247, !tbaa !29
  store ptr %t248, ptr %l13, !tbaa !29
  %t250 = load ptr, ptr %l13, !tbaa !29
  %t252 = icmp eq ptr %t250, null
  br i1 %t252, label %bb47, label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_25ec48d7738ec131_33504a893c084afd)
  unreachable
bb48:
  br label %bb49
bb49:
  %t254 = load ptr, ptr %l13, !tbaa !29
  %t255 = load ptr, ptr %l12, !tbaa !29
  %t257 = getelementptr %"compiler/ast:StructBody", ptr %t255, i32 0, i32 0
  %t258 = load { i64, ptr }, ptr %t257, !tbaa !27
  %t259 = load i64, ptr %l9, !tbaa !24
  %t260 = load ptr, ptr %lp10
  %t261 = load { i64, ptr }, ptr %t260, !tbaa !27
  %t266 = call %"compiler/check:ctSource" @compiler_2fcheck_3actSource_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t254, ptr null, { i64, ptr } %t258, i64 %t259, { i64, ptr } %t261)
  store %"compiler/check:ctSource" %t266, ptr %l130
  br label %bb50
bb50:
  %t267 = load %"compiler/check:ctSource", ptr %l130
  %t268 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/check:ctSource" %t267, ptr %t268
  store ptr %t268, ptr %rv
  br label %ret
bb51:
  %t270 = load ptr, ptr %l11, !tbaa !29
  store ptr %t270, ptr %l132, !tbaa !29
  store i1 false, ptr %l133, !tbaa !21
  %t271 = load ptr, ptr %l132, !tbaa !29
  %t272 = icmp ne ptr %t271, null
  br i1 %t272, label %bb52, label %bb53
bb52:
  %t274 = load ptr, ptr %l132, !tbaa !29
  %t275 = load i64, ptr %t274, !range !{i64 0, i64 5}
  %t277 = icmp eq i64 %t275, 3
  store i1 %t277, ptr %l133, !tbaa !21
  br label %bb53
bb53:
  %t278 = load i1, ptr %l133, !tbaa !21
  br i1 %t278, label %bb54, label %bb55
bb54:
  %t279 = load ptr, ptr %l11, !tbaa !29
  %t281 = getelementptr { i64, [6 x i64] }, ptr %t279, i32 0, i32 1
  %t282 = getelementptr { ptr, ptr }, ptr %t281, i32 0, i32 1
  %t283 = load ptr, ptr %t282
  store ptr %t283, ptr %l14, !tbaa !29
  br label %bb56
bb55:
  br label %bb67
bb56:
  %t285 = load ptr, ptr %l14, !tbaa !29
  %t287 = icmp eq ptr %t285, null
  br i1 %t287, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l140, !tbaa !21
  br label %bb59
bb58:
  %t289 = load ptr, ptr %l14, !tbaa !29
  %t291 = getelementptr %"compiler/ast:Func", ptr %t289, i32 0, i32 3
  %t292 = load ptr, ptr %t291, !tbaa !29
  %t294 = getelementptr %"compiler/ast:Sig", ptr %t292, i32 0, i32 5
  %t295 = load ptr, ptr %t294, !tbaa !29
  %t297 = icmp eq ptr %t295, null
  store i1 %t297, ptr %l140, !tbaa !21
  br label %bb59
bb59:
  %t299 = load i1, ptr %l140, !tbaa !21
  br i1 %t299, label %bb60, label %bb61
bb60:
  store ptr null, ptr %rv
  br label %ret
bb61:
  br label %bb62
bb62:
  %t301 = load ptr, ptr %l14, !tbaa !29
  %t303 = getelementptr %"compiler/ast:Func", ptr %t301, i32 0, i32 3
  %t304 = load ptr, ptr %t303, !tbaa !29
  %t306 = getelementptr %"compiler/ast:Sig", ptr %t304, i32 0, i32 5
  %t307 = load ptr, ptr %t306, !tbaa !29
  %t309 = icmp eq ptr %t307, null
  br i1 %t309, label %bb63, label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_1c86c4e2a1d4d52a_afb2831c22759b16)
  unreachable
bb64:
  br label %bb65
bb65:
  %t311 = load ptr, ptr %l14, !tbaa !29
  %t313 = getelementptr %"compiler/ast:Func", ptr %t311, i32 0, i32 3
  %t314 = load ptr, ptr %t313, !tbaa !29
  %t316 = getelementptr %"compiler/ast:Sig", ptr %t314, i32 0, i32 5
  %t317 = load ptr, ptr %t316, !tbaa !29
  %t318 = load ptr, ptr %l14, !tbaa !29
  %t320 = getelementptr %"compiler/ast:Func", ptr %t318, i32 0, i32 3
  %t321 = load ptr, ptr %t320, !tbaa !29
  %t323 = getelementptr %"compiler/ast:Sig", ptr %t321, i32 0, i32 0
  %t324 = load { i64, ptr }, ptr %t323, !tbaa !27
  %t325 = load i64, ptr %l9, !tbaa !24
  %t326 = load ptr, ptr %lp10
  %t327 = load { i64, ptr }, ptr %t326, !tbaa !27
  %t332 = call %"compiler/check:ctSource" @compiler_2fcheck_3actSource_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t317, ptr null, { i64, ptr } %t324, i64 %t325, { i64, ptr } %t327)
  store %"compiler/check:ctSource" %t332, ptr %l158
  br label %bb66
bb66:
  %t333 = load %"compiler/check:ctSource", ptr %l158
  %t334 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/check:ctSource" %t333, ptr %t334
  store ptr %t334, ptr %rv
  br label %ret
bb67:
  br i1 true, label %bb68, label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb71
bb70:
  store ptr null, ptr %rv
  br label %ret
bb71:
  call void @__olang_check_failed(ptr @olang_loc_34572fc3675c142e_5b9246c98f1fa642)
  unreachable
bb72:
  %t337 = load { i64, [2 x i64] }, ptr %l2
  %t339 = extractvalue { i64, [2 x i64] } %t337, 0
  %t340 = icmp eq i64 %t339, 10
  br i1 %t340, label %bb73, label %bb74
bb73:
  %t342 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t343 = getelementptr { i32, i64 }, ptr %t342, i32 0, i32 0
  %t344 = load i32, ptr %t343
  store i32 %t344, ptr %l15, !tbaa !23
  %t346 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t347 = getelementptr { i32, i64 }, ptr %t346, i32 0, i32 1
  %t348 = load i64, ptr %t347
  store i64 %t348, ptr %l16, !tbaa !24
  br label %bb75
bb74:
  br label %bb101
bb75:
  store %olang.scope zeroinitializer, ptr %s12
  %t350 = load ptr, ptr %l0, !tbaa !29
  store ptr %t350, ptr %l165, !tbaa !29
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t353 = getelementptr %"compiler/check:Checker", ptr %t351, i32 0, i32 1
  %t354 = load ptr, ptr %t353, !tbaa !29
  %t355 = load i32, ptr %l15, !tbaa !23
  %t358 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %t354, i32 %t355)
  store { i64, ptr } %t358, ptr %l169
  br label %bb76
bb76:
  %t359 = load { i64, ptr }, ptr %l169, !tbaa !27
  store { i64, ptr } %t359, ptr %l170, !tbaa !27
  %t360 = load i64, ptr %l16, !tbaa !24
  %t362 = getelementptr { i64, ptr }, ptr %l170, i32 0, i32 1
  %t363 = load ptr, ptr %t362, !tbaa !27
  %t364 = getelementptr %"compiler/generic:AnySlot", ptr %t363, i64 %t360
  %t365 = load %"compiler/generic:AnySlot", ptr %t364
  %t366 = load ptr, ptr %l165, !tbaa !29
  %t368 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitMethod(ptr %v0, ptr %t366, %"compiler/generic:AnySlot" %t365)
  store ptr %t368, ptr %l173
  br label %bb77
bb77:
  %t369 = load ptr, ptr %l173, !tbaa !29
  store ptr %t369, ptr %l17, !tbaa !29
  %t370 = load ptr, ptr %l17, !tbaa !29
  %t372 = icmp eq ptr %t370, null
  br i1 %t372, label %bb78, label %bb79
bb78:
  store i1 true, ptr %l176, !tbaa !21
  br label %bb80
bb79:
  %t374 = load ptr, ptr %l17, !tbaa !29
  %t376 = getelementptr %"compiler/ast:Func", ptr %t374, i32 0, i32 3
  %t377 = load ptr, ptr %t376, !tbaa !29
  %t379 = getelementptr %"compiler/ast:Sig", ptr %t377, i32 0, i32 5
  %t380 = load ptr, ptr %t379, !tbaa !29
  %t382 = icmp eq ptr %t380, null
  store i1 %t382, ptr %l176, !tbaa !21
  br label %bb80
bb80:
  %t384 = load i1, ptr %l176, !tbaa !21
  br i1 %t384, label %bb81, label %bb82
bb81:
  call void @__olang_scope_close(ptr %s12)
  store ptr null, ptr %rv
  br label %ret
bb82:
  br label %bb83
bb83:
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t388 = getelementptr %"compiler/check:Checker", ptr %t386, i32 0, i32 1
  %t389 = load ptr, ptr %t388, !tbaa !29
  %t391 = getelementptr %"compiler/generic:Program", ptr %t389, i32 0, i32 2
  store ptr %t391, ptr %l184, !tbaa !29
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t394 = getelementptr %"compiler/check:Checker", ptr %t392, i32 0, i32 1
  %t395 = load ptr, ptr %t394, !tbaa !29
  %t396 = load i32, ptr %l15, !tbaa !23
  %t399 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %t395, i32 %t396)
  store { i64, ptr } %t399, ptr %l188
  br label %bb84
bb84:
  %t400 = load { i64, ptr }, ptr %l188, !tbaa !27
  store { i64, ptr } %t400, ptr %l189, !tbaa !27
  %t401 = load i64, ptr %l16, !tbaa !24
  %t403 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t404 = load ptr, ptr %t403, !tbaa !27
  %t405 = getelementptr %"compiler/generic:AnySlot", ptr %t404, i64 %t401
  %t406 = getelementptr %"compiler/generic:AnySlot", ptr %t405, i32 0, i32 1
  %t407 = load i32, ptr %t406, !tbaa !23
  %t408 = load ptr, ptr %l184, !tbaa !29
  %t410 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t408, i32 %t407)
  store i32 %t410, ptr %l192
  br label %bb85
bb85:
  %t411 = load i32, ptr %l192, !tbaa !23
  store i32 %t411, ptr %l18, !tbaa !23
  %t412 = load ptr, ptr %l17, !tbaa !29
  %t414 = getelementptr %"compiler/ast:Func", ptr %t412, i32 0, i32 1
  %t415 = load ptr, ptr %t414, !tbaa !29
  store ptr %t415, ptr %l19, !tbaa !29
  %t417 = load ptr, ptr %l19, !tbaa !29
  %t419 = icmp eq ptr %t417, null
  br i1 %t419, label %bb86, label %bb87
bb86:
  %t421 = load ptr, ptr %l17, !tbaa !29
  %t423 = getelementptr %"compiler/ast:Func", ptr %t421, i32 0, i32 0
  %t424 = load %"compiler/source:Span", ptr %t423
  store %"compiler/source:Span" %t424, ptr %l198
  %t425 = load ptr, ptr %l17, !tbaa !29
  %t427 = getelementptr %"compiler/ast:Func", ptr %t425, i32 0, i32 0
  %t428 = load %"compiler/source:Span", ptr %t427
  store { i64, [5 x i64] } zeroinitializer, ptr %t429
  %t430 = getelementptr { i64, [5 x i64] }, ptr %t429, i32 0, i32 0
  store i64 4, ptr %t430
  %t432 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } undef, %"compiler/source:Span" %t428, 0
  %t433 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } %t432, ptr null, 1
  %t434 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } %t433, i1 false, 2
  %t435 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } %t434, i1 false, 3
  %t436 = getelementptr { i64, [5 x i64] }, ptr %t429, i32 0, i32 1
  store { %"compiler/source:Span", ptr, i1, i1 } %t435, ptr %t436
  %t437 = load { i64, [5 x i64] }, ptr %t429
  %t439 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t437, ptr %t439
  store ptr %t439, ptr %l202, !tbaa !29
  %t440 = icmp sge i64 0, 0
  br i1 %t440, label %bb88, label %bb89
bb87:
  br label %bb93
bb88:
  %t442 = icmp sle i64 0, 1152921504606846975
  br i1 %t442, label %bb90, label %bb91
bb89:
  call void @__olang_check_failed(ptr @olang_loc_384cb541f04295b0_3f9ee0143bd9d7ac)
  unreachable
bb90:
  %t444 = mul i64 0, 8
  %t445 = insertvalue { i64, ptr } undef, i64 0, 0
  %t446 = insertvalue { i64, ptr } %t445, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t447 = load %"compiler/source:Span", ptr %l198
  %t448 = load ptr, ptr %l202, !tbaa !29
  %t450 = call %"compiler/ast:Param" @compiler_2fast_3aParam_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t447, i32 0, ptr %t448, ptr null, { i64, ptr } %t446)
  store %"compiler/ast:Param" %t450, ptr %l206
  br label %bb92
bb91:
  call void @__olang_check_failed(ptr @olang_loc_384cb541f04295b0_3f9ee0143bd9d7ac)
  unreachable
bb92:
  %t451 = load %"compiler/ast:Param", ptr %l206
  %t452 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store %"compiler/ast:Param" %t451, ptr %t452
  store ptr %t452, ptr %l19, !tbaa !29
  br label %bb93
bb93:
  %t454 = load ptr, ptr %l17, !tbaa !29
  %t456 = getelementptr %"compiler/ast:Func", ptr %t454, i32 0, i32 3
  %t457 = load ptr, ptr %t456, !tbaa !29
  %t459 = getelementptr %"compiler/ast:Sig", ptr %t457, i32 0, i32 5
  %t460 = load ptr, ptr %t459, !tbaa !29
  %t462 = icmp eq ptr %t460, null
  br i1 %t462, label %bb94, label %bb95
bb94:
  call void @__olang_check_failed(ptr @olang_loc_a90b29f72ec4d10d_507af4b2e3250de1)
  unreachable
bb95:
  br label %bb96
bb96:
  %t464 = load ptr, ptr %l17, !tbaa !29
  %t466 = getelementptr %"compiler/ast:Func", ptr %t464, i32 0, i32 3
  %t467 = load ptr, ptr %t466, !tbaa !29
  %t469 = getelementptr %"compiler/ast:Sig", ptr %t467, i32 0, i32 5
  %t470 = load ptr, ptr %t469, !tbaa !29
  store ptr %t470, ptr %l214, !tbaa !29
  %t471 = load ptr, ptr %l19, !tbaa !29
  store ptr %t471, ptr %l215, !tbaa !29
  %t472 = load ptr, ptr %l17, !tbaa !29
  %t474 = getelementptr %"compiler/ast:Func", ptr %t472, i32 0, i32 3
  %t475 = load ptr, ptr %t474, !tbaa !29
  %t477 = getelementptr %"compiler/ast:Sig", ptr %t475, i32 0, i32 0
  %t478 = load { i64, ptr }, ptr %t477, !tbaa !27
  store { i64, ptr } %t478, ptr %l218, !tbaa !27
  %t479 = load ptr, ptr %l0, !tbaa !29
  %t481 = getelementptr %"compiler/check:Checker", ptr %t479, i32 0, i32 1
  %t482 = load ptr, ptr %t481, !tbaa !29
  %t484 = getelementptr %"compiler/generic:Program", ptr %t482, i32 0, i32 2
  %t485 = load i32, ptr %l18, !tbaa !23
  %t488 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t484, i32 %t485)
  store i64 %t488, ptr %l223
  br label %bb97
bb97:
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t490 = load i32, ptr %l15, !tbaa !23
  %t493 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s12, ptr %t489, i32 %t490)
  store { i64, ptr } %t493, ptr %l226
  br label %bb98
bb98:
  %t494 = load ptr, ptr %l0, !tbaa !29
  %t495 = load ptr, ptr %l17, !tbaa !29
  %t497 = getelementptr %"compiler/ast:Func", ptr %t495, i32 0, i32 2
  %t498 = load i32, ptr %t497, !tbaa !23
  %t501 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t494, i32 %t498)
  store { i64, ptr } %t501, ptr %l230
  br label %bb99
bb99:
  %t502 = load { i64, ptr }, ptr %l226, !tbaa !27
  %t503 = extractvalue { i64, ptr } %t502, 1
  %t504 = extractvalue { i64, ptr } %t502, 0
  %t505 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t506 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t507 = add i64 %t504, %t506
  %t508 = load { i64, ptr }, ptr %l230, !tbaa !27
  %t509 = extractvalue { i64, ptr } %t508, 1
  %t510 = extractvalue { i64, ptr } %t508, 0
  %t511 = add i64 %t507, %t510
  %t512 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t511)
  call void @olang_textcopy(ptr %t512, ptr %t503, i64 %t504)
  %t513 = getelementptr i8, ptr %t512, i64 %t504
  call void @olang_textcopy(ptr %t513, ptr %t505, i64 %t506)
  %t514 = getelementptr i8, ptr %t513, i64 %t506
  call void @olang_textcopy(ptr %t514, ptr %t509, i64 %t510)
  %t515 = insertvalue { i64, ptr } undef, i64 %t511, 0
  %t516 = insertvalue { i64, ptr } %t515, ptr %t512, 1
  %t518 = extractvalue { i64, ptr } %t516, 0
  %t519 = extractvalue { i64, ptr } %t516, 1
  %t520 = mul i64 %t518, 1
  %t521 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t520)
  call void @llvm.memcpy.p0.p0.i64(ptr %t521, ptr %t519, i64 %t520, i1 false)
  %t522 = insertvalue { i64, ptr } undef, i64 %t518, 0
  %t523 = insertvalue { i64, ptr } %t522, ptr %t521, 1
  %t524 = load ptr, ptr %l214, !tbaa !29
  %t525 = load ptr, ptr %l215, !tbaa !29
  %t526 = load { i64, ptr }, ptr %l218, !tbaa !27
  %t527 = load i64, ptr %l223, !tbaa !24
  %t529 = call %"compiler/check:ctSource" @compiler_2fcheck_3actSource_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t524, ptr %t525, { i64, ptr } %t526, i64 %t527, { i64, ptr } %t523)
  store %"compiler/check:ctSource" %t529, ptr %l233
  br label %bb100
bb100:
  %t530 = load %"compiler/check:ctSource", ptr %l233
  %t531 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/check:ctSource" %t530, ptr %t531
  call void @__olang_scope_close(ptr %s12)
  store ptr %t531, ptr %rv
  br label %ret
bb101:
  br i1 true, label %bb102, label %bb103
bb102:
  br label %bb104
bb103:
  br label %bb105
bb104:
  store ptr null, ptr %rv
  br label %ret
bb105:
  call void @__olang_check_failed(ptr @olang_loc_8dac41fcc89db5e5_6cee581458fc6b9)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBody(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etwinBody(ptr %v0, ptr %a0, i32 %a1, i32 0)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  store i64 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l7 = alloca ptr
  %l9 = alloca ptr
  %l12 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 0
  %t7 = load i64, ptr %t6, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 12
  store ptr %t13, ptr %l7, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t14)
  store ptr %t16, ptr %l9
  br label %bb4
bb3:
  %t17 = extractvalue { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t19 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t17, 1
  call void @__olang_check_failed_text(ptr @olang_loc_43d20343d6f566de_136f8b7be912828a, { i64, ptr } %t20)
  unreachable
bb4:
  %t21 = load ptr, ptr %l9, !tbaa !29
  %t23 = getelementptr %"compiler/check:frame", ptr %t21, i32 0, i32 0
  %t24 = load i64, ptr %t23, !tbaa !24
  %t25 = load ptr, ptr %l7, !tbaa !29
  %t27 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t25, i64 %t24)
  store ptr %t27, ptr %l12
  br label %bb5
bb5:
  %t28 = load ptr, ptr %l12, !tbaa !29
  store ptr %t28, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultCopiesRecv(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l8 = alloca i32
  %l11 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l25 = alloca i32
  %l30 = alloca i32
  %l36 = alloca ptr
  %l41 = alloca i32
  %l46 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t4, i64 %a1)
  store i32 %t8, ptr %l8
  br label %bb1
bb1:
  %t9 = load i32, ptr %l8, !tbaa !23
  store i32 %t9, ptr %l2, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  store ptr %t15, ptr %l11, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l16
  br label %bb2
bb2:
  %t26 = load ptr, ptr %l11, !tbaa !29
  %t27 = load i32, ptr %l16, !tbaa !23
  %t28 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t26, i32 %t27)
  store { i64, ptr } %t28, ptr %l17
  br label %bb3
bb3:
  %t29 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t29, ptr %l3, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  %t34 = icmp eq i64 %t32, 0
  br i1 %t34, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t38, ptr %l23, !tbaa !27
  %t39 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr i32, ptr %t40, i64 0
  %t42 = load i32, ptr %t41, !tbaa !33
  %t45 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t37, i32 %t42)
  store i32 %t45, ptr %l25
  br label %bb7
bb7:
  %t46 = load i32, ptr %l25, !tbaa !23
  store i32 %t46, ptr %l4, !tbaa !23
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 2
  %t53 = load i32, ptr %l4, !tbaa !23
  %t56 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t52, i32 %t53)
  store i32 %t56, ptr %l30
  br label %bb8
bb8:
  %t57 = load i32, ptr %l30, !range !{i32 0, i32 33}
  %t59 = trunc i64 25 to i32
  %t60 = icmp eq i32 %t57, %t59
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb9, label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  store ptr %t68, ptr %l36, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/generic:Program", ptr %t72, i32 0, i32 2
  %t75 = load i32, ptr %l2, !tbaa !23
  %t78 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t74, i32 %t75)
  store i32 %t78, ptr %l41
  br label %bb12
bb12:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/generic:Program", ptr %t82, i32 0, i32 2
  %t85 = load i32, ptr %l4, !tbaa !23
  %t88 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t84, i32 %t85)
  store i64 %t88, ptr %l46
  br label %bb13
bb13:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/check:Checker", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t94 = getelementptr %"compiler/generic:Program", ptr %t92, i32 0, i32 2
  %t95 = load i32, ptr %l4, !tbaa !23
  %t98 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t94, i32 %t95)
  store i64 %t98, ptr %l51
  br label %bb14
bb14:
  %t99 = load ptr, ptr %l36, !tbaa !29
  %t100 = load i32, ptr %l41, !tbaa !23
  %t101 = load i64, ptr %l46, !tbaa !24
  %t102 = load i64, ptr %l51, !tbaa !24
  %t103 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eHoldsVarByValue(ptr %v0, ptr %t99, i32 %t100, i64 %t101, i64 %t102, i64 0)
  store i1 %t103, ptr %l52
  br label %bb15
bb15:
  %t104 = load i1, ptr %l52, !tbaa !21
  store i1 %t104, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffSs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l13 = alloca { i64, ptr }
  %l18 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  %t27 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffS(ptr %v0, ptr %v1, ptr %a0, ptr %t21)
  store i1 %t27, ptr %l18
  br label %bb5
bb5:
  %t28 = load i1, ptr %l18, !tbaa !21
  br i1 %t28, label %bb6, label %bb7
bb6:
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t30 = load i64, ptr %l3, !tbaa !24
  %t32 = add i64 %t30, 1
  store i64 %t32, ptr %l3, !tbaa !24
  br label %bb1
bb10:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l42 = alloca ptr
  %l46 = alloca ptr
  %l47 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i1
  %l71 = alloca ptr
  %l72 = alloca i1
  %l79 = alloca i1
  %l80 = alloca ptr
  %l81 = alloca i1
  %l84 = alloca ptr
  %l85 = alloca i1
  %l88 = alloca ptr
  %l89 = alloca i1
  %l93 = alloca ptr
  %l94 = alloca i1
  %l103 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca i1
  %l117 = alloca ptr
  %l118 = alloca i1
  %l126 = alloca ptr
  %l130 = alloca { i64, ptr }
  %l135 = alloca i1
  %l138 = alloca ptr
  %l139 = alloca i1
  %l142 = alloca ptr
  %l143 = alloca i1
  %l147 = alloca ptr
  %l148 = alloca i1
  %l159 = alloca { i64, ptr }
  %l165 = alloca i1
  %l170 = alloca ptr
  %l171 = alloca i1
  %l180 = alloca i1
  %l184 = alloca i1
  %l188 = alloca i1
  %l198 = alloca { i64, ptr }
  %l204 = alloca i1
  %l209 = alloca ptr
  %l210 = alloca i1
  %l221 = alloca i1
  %l223 = alloca i1
  %l232 = alloca { i64, ptr }
  %l238 = alloca i1
  %l243 = alloca ptr
  %l244 = alloca i1
  %l252 = alloca i1
  %l256 = alloca i1
  %l257 = alloca i1
  %l262 = alloca i1
  %l263 = alloca i1
  %l268 = alloca i1
  %l269 = alloca ptr
  %l270 = alloca i1
  %l279 = alloca i1
  %l280 = alloca i1
  %l284 = alloca i1
  %l285 = alloca i1
  %l290 = alloca i1
  %l291 = alloca ptr
  %l292 = alloca i1
  %l300 = alloca i1
  %l301 = alloca i1
  %l305 = alloca i1
  %l306 = alloca ptr
  %l307 = alloca i1
  %l315 = alloca i1
  %l325 = alloca { i64, ptr }
  %l330 = alloca i1
  %l338 = alloca i1
  %l339 = alloca ptr
  %l345 = alloca i1
  %l346 = alloca ptr
  %l347 = alloca i1
  %l354 = alloca i1
  %l358 = alloca i1
  %l368 = alloca { i64, ptr }
  %l374 = alloca i1
  %l384 = alloca { i64, ptr }
  %l390 = alloca i1
  %l397 = alloca ptr
  %l398 = alloca i1
  %l406 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t7 = load ptr, ptr %l46, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l46, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l47, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l47, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  br label %bb16
bb7:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t16 = load ptr, ptr %l50, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb8, label %bb9
bb8:
  %t19 = load ptr, ptr %l50, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 18}
  %t22 = icmp eq i64 %t20, 1
  store i1 %t22, ptr %l51, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l51, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  br label %bb16
bb11:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l54, !tbaa !29
  store i1 false, ptr %l55, !tbaa !21
  %t25 = load ptr, ptr %l54, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb12, label %bb13
bb12:
  %t28 = load ptr, ptr %l54, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 18}
  %t31 = icmp eq i64 %t29, 15
  store i1 %t31, ptr %l55, !tbaa !21
  br label %bb13
bb13:
  %t32 = load i1, ptr %l55, !tbaa !21
  br i1 %t32, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i1 false, ptr %rv
  br label %ret
bb17:
  %t34 = load ptr, ptr %l1, !tbaa !29
  store ptr %t34, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t35 = load ptr, ptr %l59, !tbaa !29
  %t36 = icmp ne ptr %t35, null
  br i1 %t36, label %bb18, label %bb19
bb18:
  %t38 = load ptr, ptr %l59, !tbaa !29
  %t39 = load i64, ptr %t38, !range !{i64 0, i64 18}
  %t41 = icmp eq i64 %t39, 2
  store i1 %t41, ptr %l60, !tbaa !21
  br label %bb19
bb19:
  %t42 = load i1, ptr %l60, !tbaa !21
  br i1 %t42, label %bb20, label %bb21
bb20:
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr { i64, [5 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t45, i32 0, i32 2
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l2, !tbaa !29
  br label %bb30
bb21:
  %t49 = load ptr, ptr %l1, !tbaa !29
  store ptr %t49, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t50 = load ptr, ptr %l65, !tbaa !29
  %t51 = icmp ne ptr %t50, null
  br i1 %t51, label %bb22, label %bb23
bb22:
  %t53 = load ptr, ptr %l65, !tbaa !29
  %t54 = load i64, ptr %t53, !range !{i64 0, i64 18}
  %t56 = icmp eq i64 %t54, 3
  store i1 %t56, ptr %l66, !tbaa !21
  br label %bb23
bb23:
  %t57 = load i1, ptr %l66, !tbaa !21
  br i1 %t57, label %bb24, label %bb25
bb24:
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr { i64, [5 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t60, i32 0, i32 2
  %t62 = load ptr, ptr %t61
  store ptr %t62, ptr %l2, !tbaa !29
  br label %bb30
bb25:
  %t64 = load ptr, ptr %l1, !tbaa !29
  store ptr %t64, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t65 = load ptr, ptr %l71, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb26, label %bb27
bb26:
  %t68 = load ptr, ptr %l71, !tbaa !29
  %t69 = load i64, ptr %t68, !range !{i64 0, i64 18}
  %t71 = icmp eq i64 %t69, 4
  store i1 %t71, ptr %l72, !tbaa !21
  br label %bb27
bb27:
  %t72 = load i1, ptr %l72, !tbaa !21
  br i1 %t72, label %bb28, label %bb29
bb28:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [5 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t75, i32 0, i32 2
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l2, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load ptr, ptr %l2, !tbaa !29
  %t83 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffP(ptr %v0, ptr %v1, ptr %t79, ptr %t80, i1 false)
  store i1 %t83, ptr %l79
  br label %bb31
bb31:
  %t84 = load i1, ptr %l79, !tbaa !21
  store i1 %t84, ptr %rv
  br label %ret
bb32:
  %t85 = load ptr, ptr %l1, !tbaa !29
  store ptr %t85, ptr %l80, !tbaa !29
  store i1 false, ptr %l81, !tbaa !21
  %t86 = load ptr, ptr %l80, !tbaa !29
  %t87 = icmp ne ptr %t86, null
  br i1 %t87, label %bb33, label %bb34
bb33:
  %t89 = load ptr, ptr %l80, !tbaa !29
  %t90 = load i64, ptr %t89, !range !{i64 0, i64 18}
  %t92 = icmp eq i64 %t90, 5
  store i1 %t92, ptr %l81, !tbaa !21
  br label %bb34
bb34:
  %t93 = load i1, ptr %l81, !tbaa !21
  br i1 %t93, label %bb35, label %bb36
bb35:
  br label %bb45
bb36:
  %t94 = load ptr, ptr %l1, !tbaa !29
  store ptr %t94, ptr %l84, !tbaa !29
  store i1 false, ptr %l85, !tbaa !21
  %t95 = load ptr, ptr %l84, !tbaa !29
  %t96 = icmp ne ptr %t95, null
  br i1 %t96, label %bb37, label %bb38
bb37:
  %t98 = load ptr, ptr %l84, !tbaa !29
  %t99 = load i64, ptr %t98, !range !{i64 0, i64 18}
  %t101 = icmp eq i64 %t99, 16
  store i1 %t101, ptr %l85, !tbaa !21
  br label %bb38
bb38:
  %t102 = load i1, ptr %l85, !tbaa !21
  br i1 %t102, label %bb39, label %bb40
bb39:
  br label %bb45
bb40:
  %t103 = load ptr, ptr %l1, !tbaa !29
  store ptr %t103, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t104 = load ptr, ptr %l88, !tbaa !29
  %t105 = icmp ne ptr %t104, null
  br i1 %t105, label %bb41, label %bb42
bb41:
  %t107 = load ptr, ptr %l88, !tbaa !29
  %t108 = load i64, ptr %t107, !range !{i64 0, i64 18}
  %t110 = icmp eq i64 %t108, 8
  store i1 %t110, ptr %l89, !tbaa !21
  br label %bb42
bb42:
  %t111 = load i1, ptr %l89, !tbaa !21
  br i1 %t111, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  store i1 true, ptr %rv
  br label %ret
bb46:
  %t113 = load ptr, ptr %l1, !tbaa !29
  store ptr %t113, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t114 = load ptr, ptr %l93, !tbaa !29
  %t115 = icmp ne ptr %t114, null
  br i1 %t115, label %bb47, label %bb48
bb47:
  %t117 = load ptr, ptr %l93, !tbaa !29
  %t118 = load i64, ptr %t117, !range !{i64 0, i64 18}
  %t120 = icmp eq i64 %t118, 6
  store i1 %t120, ptr %l94, !tbaa !21
  br label %bb48
bb48:
  %t121 = load i1, ptr %l94, !tbaa !21
  br i1 %t121, label %bb49, label %bb50
bb49:
  %t122 = load ptr, ptr %l1, !tbaa !29
  %t124 = getelementptr { i64, [5 x i64] }, ptr %t122, i32 0, i32 1
  %t125 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t124, i32 0, i32 1
  %t126 = load i32, ptr %t125
  store i32 %t126, ptr %l3, !tbaa !23
  %t128 = load ptr, ptr %l1, !tbaa !29
  %t130 = getelementptr { i64, [5 x i64] }, ptr %t128, i32 0, i32 1
  %t131 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t130, i32 0, i32 2
  %t132 = load ptr, ptr %t131
  store ptr %t132, ptr %l4, !tbaa !29
  br label %bb51
bb50:
  br label %bb102
bb51:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load i32, ptr %l3, !tbaa !23
  %t138 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edestructs(ptr %v0, ptr %t134, i32 %t135)
  store i1 %t138, ptr %l103
  br label %bb52
bb52:
  %t139 = load i1, ptr %l103, !tbaa !21
  br i1 %t139, label %bb53, label %bb54
bb53:
  store i1 true, ptr %rv
  br label %ret
bb54:
  br label %bb55
bb55:
  %t141 = load ptr, ptr %l4, !tbaa !29
  %t143 = getelementptr %"compiler/typed:Call", ptr %t141, i32 0, i32 0
  %t144 = load ptr, ptr %t143, !tbaa !29
  store ptr %t144, ptr %l5, !tbaa !29
  %t146 = load ptr, ptr %l5, !tbaa !29
  store ptr %t146, ptr %l107, !tbaa !29
  store i1 false, ptr %l108, !tbaa !21
  %t147 = load ptr, ptr %l107, !tbaa !29
  %t148 = icmp ne ptr %t147, null
  br i1 %t148, label %bb56, label %bb57
bb56:
  %t150 = load ptr, ptr %l107, !tbaa !29
  %t151 = load i64, ptr %t150, !range !{i64 0, i64 5}
  %t153 = icmp eq i64 %t151, 0
  store i1 %t153, ptr %l108, !tbaa !21
  br label %bb57
bb57:
  %t154 = load i1, ptr %l108, !tbaa !21
  br i1 %t154, label %bb58, label %bb59
bb58:
  %t155 = load ptr, ptr %l5, !tbaa !29
  %t157 = getelementptr { i64, [3 x i64] }, ptr %t155, i32 0, i32 1
  %t158 = getelementptr { i32 }, ptr %t157, i32 0, i32 0
  %t159 = load i32, ptr %t158
  store i32 %t159, ptr %l6, !tbaa !23
  br label %bb60
bb59:
  br label %bb62
bb60:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/check:Checker", ptr %t161, i32 0, i32 89
  %t164 = load i32, ptr %l6, !tbaa !23
  %t166 = sext i32 %t164 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t163, i64 %t166)
  br label %bb61
bb61:
  br label %bb91
bb62:
  %t169 = load ptr, ptr %l5, !tbaa !29
  store ptr %t169, ptr %l117, !tbaa !29
  store i1 false, ptr %l118, !tbaa !21
  %t170 = load ptr, ptr %l117, !tbaa !29
  %t171 = icmp ne ptr %t170, null
  br i1 %t171, label %bb63, label %bb64
bb63:
  %t173 = load ptr, ptr %l117, !tbaa !29
  %t174 = load i64, ptr %t173, !range !{i64 0, i64 5}
  %t176 = icmp eq i64 %t174, 1
  store i1 %t176, ptr %l118, !tbaa !21
  br label %bb64
bb64:
  %t177 = load i1, ptr %l118, !tbaa !21
  br i1 %t177, label %bb65, label %bb66
bb65:
  %t178 = load ptr, ptr %l5, !tbaa !29
  %t180 = getelementptr { i64, [3 x i64] }, ptr %t178, i32 0, i32 1
  %t181 = getelementptr { i64 }, ptr %t180, i32 0, i32 0
  %t182 = load i64, ptr %t181
  store i64 %t182, ptr %l7, !tbaa !24
  br label %bb67
bb66:
  br label %bb74
bb67:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/check:Checker", ptr %t184, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !29
  %t188 = load i64, ptr %l7, !tbaa !24
  %t191 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t187, i64 %t188)
  store ptr %t191, ptr %l126
  br label %bb68
bb68:
  %t192 = load ptr, ptr %l126, !tbaa !29
  store ptr %t192, ptr %l8, !tbaa !29
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load ptr, ptr %l8, !tbaa !29
  %t196 = getelementptr %"compiler/ast:Func", ptr %t194, i32 0, i32 2
  %t197 = load i32, ptr %t196, !tbaa !23
  %t200 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t193, i32 %t197)
  store { i64, ptr } %t200, ptr %l130
  br label %bb69
bb69:
  %t201 = load ptr, ptr %l8, !tbaa !29
  %t203 = getelementptr %"compiler/ast:Func", ptr %t201, i32 0, i32 3
  %t204 = load ptr, ptr %t203, !tbaa !29
  %t206 = getelementptr %"compiler/ast:Sig", ptr %t204, i32 0, i32 0
  %t207 = load { i64, ptr }, ptr %t206, !tbaa !27
  %t209 = extractvalue { i64, ptr } %t207, 0
  %t210 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t212 = call i1 @compiler_2ftyped_2eMathExtern(ptr %v0, { i64, ptr } %t210, i64 %t209)
  store i1 %t212, ptr %l135
  br label %bb70
bb70:
  %t213 = load i1, ptr %l135, !tbaa !21
  %t214 = xor i1 %t213, true
  br i1 %t214, label %bb71, label %bb72
bb71:
  store i1 true, ptr %rv
  br label %ret
bb72:
  br label %bb73
bb73:
  br label %bb91
bb74:
  %t217 = load ptr, ptr %l5, !tbaa !29
  store ptr %t217, ptr %l138, !tbaa !29
  store i1 false, ptr %l139, !tbaa !21
  %t218 = load ptr, ptr %l138, !tbaa !29
  %t219 = icmp ne ptr %t218, null
  br i1 %t219, label %bb75, label %bb76
bb75:
  %t221 = load ptr, ptr %l138, !tbaa !29
  %t222 = load i64, ptr %t221, !range !{i64 0, i64 5}
  %t224 = icmp eq i64 %t222, 2
  store i1 %t224, ptr %l139, !tbaa !21
  br label %bb76
bb76:
  %t225 = load i1, ptr %l139, !tbaa !21
  br i1 %t225, label %bb77, label %bb78
bb77:
  br label %bb83
bb78:
  %t226 = load ptr, ptr %l5, !tbaa !29
  store ptr %t226, ptr %l142, !tbaa !29
  store i1 false, ptr %l143, !tbaa !21
  %t227 = load ptr, ptr %l142, !tbaa !29
  %t228 = icmp ne ptr %t227, null
  br i1 %t228, label %bb79, label %bb80
bb79:
  %t230 = load ptr, ptr %l142, !tbaa !29
  %t231 = load i64, ptr %t230, !range !{i64 0, i64 5}
  %t233 = icmp eq i64 %t231, 3
  store i1 %t233, ptr %l143, !tbaa !21
  br label %bb80
bb80:
  %t234 = load i1, ptr %l143, !tbaa !21
  br i1 %t234, label %bb81, label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb84
bb83:
  store i1 true, ptr %rv
  br label %ret
bb84:
  %t236 = load ptr, ptr %l5, !tbaa !29
  store ptr %t236, ptr %l147, !tbaa !29
  store i1 false, ptr %l148, !tbaa !21
  %t237 = load ptr, ptr %l147, !tbaa !29
  %t238 = icmp ne ptr %t237, null
  br i1 %t238, label %bb85, label %bb86
bb85:
  %t240 = load ptr, ptr %l147, !tbaa !29
  %t241 = load i64, ptr %t240, !range !{i64 0, i64 5}
  %t243 = icmp eq i64 %t241, 4
  store i1 %t243, ptr %l148, !tbaa !21
  br label %bb86
bb86:
  %t244 = load i1, ptr %l148, !tbaa !21
  br i1 %t244, label %bb87, label %bb88
bb87:
  br label %bb89
bb88:
  br label %bb90
bb89:
  br label %bb91
bb90:
  call void @__olang_check_failed(ptr @olang_loc_d97e23b04dcff800_367dc3876d150fb4)
  unreachable
bb91:
  %t245 = load ptr, ptr %l4, !tbaa !29
  %t247 = getelementptr %"compiler/typed:Call", ptr %t245, i32 0, i32 1
  %t248 = load { i64, ptr }, ptr %t247, !tbaa !27
  store { i64, ptr } %t248, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t250 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t250, 0
  store i64 %t252, ptr %l11, !tbaa !24
  br label %bb92
bb92:
  %t254 = load i64, ptr %l10, !tbaa !24
  %t255 = load i64, ptr %l11, !tbaa !24
  %t258 = icmp slt i64 %t254, %t255
  %t260 = xor i1 %t258, true
  br i1 %t260, label %bb93, label %bb94
bb93:
  br label %bb101
bb94:
  br label %bb95
bb95:
  %t262 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t262, ptr %l159, !tbaa !27
  %t263 = load i64, ptr %l10, !tbaa !24
  %t265 = getelementptr { i64, ptr }, ptr %l159, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = getelementptr ptr, ptr %t266, i64 %t263
  %t268 = load ptr, ptr %t267, !tbaa !39
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t275 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t270, ptr %t268)
  store i1 %t275, ptr %l165
  br label %bb96
bb96:
  %t276 = load i1, ptr %l165, !tbaa !21
  br i1 %t276, label %bb97, label %bb98
bb97:
  store i1 true, ptr %rv
  br label %ret
bb98:
  br label %bb99
bb99:
  br label %bb100
bb100:
  %t278 = load i64, ptr %l10, !tbaa !24
  %t280 = add i64 %t278, 1
  store i64 %t280, ptr %l10, !tbaa !24
  br label %bb92
bb101:
  store i1 false, ptr %rv
  br label %ret
bb102:
  %t283 = load ptr, ptr %l1, !tbaa !29
  store ptr %t283, ptr %l170, !tbaa !29
  store i1 false, ptr %l171, !tbaa !21
  %t284 = load ptr, ptr %l170, !tbaa !29
  %t285 = icmp ne ptr %t284, null
  br i1 %t285, label %bb103, label %bb104
bb103:
  %t287 = load ptr, ptr %l170, !tbaa !29
  %t288 = load i64, ptr %t287, !range !{i64 0, i64 18}
  %t290 = icmp eq i64 %t288, 7
  store i1 %t290, ptr %l171, !tbaa !21
  br label %bb104
bb104:
  %t291 = load i1, ptr %l171, !tbaa !21
  br i1 %t291, label %bb105, label %bb106
bb105:
  %t292 = load ptr, ptr %l1, !tbaa !29
  %t294 = getelementptr { i64, [5 x i64] }, ptr %t292, i32 0, i32 1
  %t295 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t294, i32 0, i32 2
  %t296 = load ptr, ptr %t295
  store ptr %t296, ptr %l13, !tbaa !29
  br label %bb107
bb106:
  br label %bb128
bb107:
  %t298 = load ptr, ptr %l13, !tbaa !29
  %t300 = getelementptr %"compiler/typed:Make", ptr %t298, i32 0, i32 4
  %t301 = load i32, ptr %t300, !tbaa !23
  %t303 = sext i32 %t301 to i64
  %t305 = icmp sge i64 %t303, 0
  br i1 %t305, label %bb108, label %bb109
bb108:
  store i1 true, ptr %l180, !tbaa !21
  br label %bb110
bb109:
  %t307 = load ptr, ptr %l13, !tbaa !29
  %t309 = getelementptr %"compiler/typed:Make", ptr %t307, i32 0, i32 5
  %t310 = load i32, ptr %t309, !range !{i32 0, i32 3}
  %t312 = trunc i64 1 to i32
  %t313 = icmp eq i32 %t310, %t312
  store i1 %t313, ptr %l180, !tbaa !21
  br label %bb110
bb110:
  %t315 = load i1, ptr %l180, !tbaa !21
  br i1 %t315, label %bb111, label %bb112
bb111:
  store i1 true, ptr %l184, !tbaa !21
  br label %bb114
bb112:
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t317 = load ptr, ptr %l13, !tbaa !29
  %t319 = getelementptr %"compiler/typed:Make", ptr %t317, i32 0, i32 3
  %t320 = load ptr, ptr %t319, !tbaa !29
  %t323 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t316, ptr %t320)
  store i1 %t323, ptr %l188
  br label %bb113
bb113:
  %t324 = load i1, ptr %l188, !tbaa !21
  store i1 %t324, ptr %l184, !tbaa !21
  br label %bb114
bb114:
  %t325 = load i1, ptr %l184, !tbaa !21
  br i1 %t325, label %bb115, label %bb116
bb115:
  store i1 true, ptr %rv
  br label %ret
bb116:
  br label %bb117
bb117:
  %t327 = load ptr, ptr %l13, !tbaa !29
  %t329 = getelementptr %"compiler/typed:Make", ptr %t327, i32 0, i32 2
  %t330 = load { i64, ptr }, ptr %t329, !tbaa !27
  store { i64, ptr } %t330, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t332 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t334 = extractvalue { i64, ptr } %t332, 0
  store i64 %t334, ptr %l16, !tbaa !24
  br label %bb118
bb118:
  %t336 = load i64, ptr %l15, !tbaa !24
  %t337 = load i64, ptr %l16, !tbaa !24
  %t340 = icmp slt i64 %t336, %t337
  %t342 = xor i1 %t340, true
  br i1 %t342, label %bb119, label %bb120
bb119:
  br label %bb127
bb120:
  br label %bb121
bb121:
  %t344 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t344, ptr %l198, !tbaa !27
  %t345 = load i64, ptr %l15, !tbaa !24
  %t347 = getelementptr { i64, ptr }, ptr %l198, i32 0, i32 1
  %t348 = load ptr, ptr %t347, !tbaa !27
  %t349 = getelementptr ptr, ptr %t348, i64 %t345
  %t350 = load ptr, ptr %t349, !tbaa !39
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t357 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t352, ptr %t350)
  store i1 %t357, ptr %l204
  br label %bb122
bb122:
  %t358 = load i1, ptr %l204, !tbaa !21
  br i1 %t358, label %bb123, label %bb124
bb123:
  store i1 true, ptr %rv
  br label %ret
bb124:
  br label %bb125
bb125:
  br label %bb126
bb126:
  %t360 = load i64, ptr %l15, !tbaa !24
  %t362 = add i64 %t360, 1
  store i64 %t362, ptr %l15, !tbaa !24
  br label %bb118
bb127:
  store i1 false, ptr %rv
  br label %ret
bb128:
  %t365 = load ptr, ptr %l1, !tbaa !29
  store ptr %t365, ptr %l209, !tbaa !29
  store i1 false, ptr %l210, !tbaa !21
  %t366 = load ptr, ptr %l209, !tbaa !29
  %t367 = icmp ne ptr %t366, null
  br i1 %t367, label %bb129, label %bb130
bb129:
  %t369 = load ptr, ptr %l209, !tbaa !29
  %t370 = load i64, ptr %t369, !range !{i64 0, i64 18}
  %t372 = icmp eq i64 %t370, 9
  store i1 %t372, ptr %l210, !tbaa !21
  br label %bb130
bb130:
  %t373 = load i1, ptr %l210, !tbaa !21
  br i1 %t373, label %bb131, label %bb132
bb131:
  %t374 = load ptr, ptr %l1, !tbaa !29
  %t376 = getelementptr { i64, [5 x i64] }, ptr %t374, i32 0, i32 1
  %t377 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t376, i32 0, i32 2
  %t378 = load i32, ptr %t377, !range !{i32 0, i32 43}
  store i32 %t378, ptr %l18
  %t380 = load ptr, ptr %l1, !tbaa !29
  %t382 = getelementptr { i64, [5 x i64] }, ptr %t380, i32 0, i32 1
  %t383 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t382, i32 0, i32 3
  %t384 = load i32, ptr %t383, !range !{i32 0, i32 3}
  store i32 %t384, ptr %l19
  %t386 = load ptr, ptr %l1, !tbaa !29
  %t388 = getelementptr { i64, [5 x i64] }, ptr %t386, i32 0, i32 1
  %t389 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t388, i32 0, i32 4
  %t390 = load { i64, ptr }, ptr %t389
  store { i64, ptr } %t390, ptr %l20, !tbaa !27
  br label %bb133
bb132:
  br label %bb151
bb133:
  %t392 = load i32, ptr %l19, !range !{i32 0, i32 3}
  %t394 = trunc i64 1 to i32
  %t395 = icmp eq i32 %t392, %t394
  br i1 %t395, label %bb134, label %bb135
bb134:
  store i1 true, ptr %l221, !tbaa !21
  br label %bb137
bb135:
  %t397 = load i32, ptr %l18, !range !{i32 0, i32 43}
  %t399 = call i1 @compiler_2fcheck_2eeffectOp(i32 %t397)
  store i1 %t399, ptr %l223
  br label %bb136
bb136:
  %t400 = load i1, ptr %l223, !tbaa !21
  store i1 %t400, ptr %l221, !tbaa !21
  br label %bb137
bb137:
  %t401 = load i1, ptr %l221, !tbaa !21
  br i1 %t401, label %bb138, label %bb139
bb138:
  store i1 true, ptr %rv
  br label %ret
bb139:
  br label %bb140
bb140:
  %t403 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t403, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t405 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t407 = extractvalue { i64, ptr } %t405, 0
  store i64 %t407, ptr %l23, !tbaa !24
  br label %bb141
bb141:
  %t409 = load i64, ptr %l22, !tbaa !24
  %t410 = load i64, ptr %l23, !tbaa !24
  %t413 = icmp slt i64 %t409, %t410
  %t415 = xor i1 %t413, true
  br i1 %t415, label %bb142, label %bb143
bb142:
  br label %bb150
bb143:
  br label %bb144
bb144:
  %t417 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t417, ptr %l232, !tbaa !27
  %t418 = load i64, ptr %l22, !tbaa !24
  %t420 = getelementptr { i64, ptr }, ptr %l232, i32 0, i32 1
  %t421 = load ptr, ptr %t420, !tbaa !27
  %t422 = getelementptr ptr, ptr %t421, i64 %t418
  %t423 = load ptr, ptr %t422, !tbaa !39
  %t425 = load ptr, ptr %l0, !tbaa !29
  %t430 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t425, ptr %t423)
  store i1 %t430, ptr %l238
  br label %bb145
bb145:
  %t431 = load i1, ptr %l238, !tbaa !21
  br i1 %t431, label %bb146, label %bb147
bb146:
  store i1 true, ptr %rv
  br label %ret
bb147:
  br label %bb148
bb148:
  br label %bb149
bb149:
  %t433 = load i64, ptr %l22, !tbaa !24
  %t435 = add i64 %t433, 1
  store i64 %t435, ptr %l22, !tbaa !24
  br label %bb141
bb150:
  store i1 false, ptr %rv
  br label %ret
bb151:
  %t438 = load ptr, ptr %l1, !tbaa !29
  store ptr %t438, ptr %l243, !tbaa !29
  store i1 false, ptr %l244, !tbaa !21
  %t439 = load ptr, ptr %l243, !tbaa !29
  %t440 = icmp ne ptr %t439, null
  br i1 %t440, label %bb152, label %bb153
bb152:
  %t442 = load ptr, ptr %l243, !tbaa !29
  %t443 = load i64, ptr %t442, !range !{i64 0, i64 18}
  %t445 = icmp eq i64 %t443, 10
  store i1 %t445, ptr %l244, !tbaa !21
  br label %bb153
bb153:
  %t446 = load i1, ptr %l244, !tbaa !21
  br i1 %t446, label %bb154, label %bb155
bb154:
  %t447 = load ptr, ptr %l1, !tbaa !29
  %t449 = getelementptr { i64, [5 x i64] }, ptr %t447, i32 0, i32 1
  %t450 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t449, i32 0, i32 2
  %t451 = load ptr, ptr %t450
  store ptr %t451, ptr %l25, !tbaa !29
  br label %bb156
bb155:
  br label %bb169
bb156:
  %t453 = load ptr, ptr %l25, !tbaa !29
  %t455 = getelementptr %"compiler/typed:Slice", ptr %t453, i32 0, i32 3
  %t456 = load i32, ptr %t455, !range !{i32 0, i32 3}
  %t458 = trunc i64 1 to i32
  %t459 = icmp eq i32 %t456, %t458
  br i1 %t459, label %bb157, label %bb158
bb157:
  store i1 true, ptr %l252, !tbaa !21
  br label %bb160
bb158:
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t462 = load ptr, ptr %l25, !tbaa !29
  %t464 = getelementptr %"compiler/typed:Slice", ptr %t462, i32 0, i32 0
  %t465 = load ptr, ptr %t464, !tbaa !29
  %t468 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffP(ptr %v0, ptr %v1, ptr %t461, ptr %t465, i1 false)
  store i1 %t468, ptr %l256
  br label %bb159
bb159:
  %t469 = load i1, ptr %l256, !tbaa !21
  store i1 %t469, ptr %l252, !tbaa !21
  br label %bb160
bb160:
  %t470 = load i1, ptr %l252, !tbaa !21
  br i1 %t470, label %bb161, label %bb162
bb161:
  store i1 true, ptr %l257, !tbaa !21
  br label %bb164
bb162:
  %t471 = load ptr, ptr %l0, !tbaa !29
  %t472 = load ptr, ptr %l25, !tbaa !29
  %t474 = getelementptr %"compiler/typed:Slice", ptr %t472, i32 0, i32 1
  %t475 = load ptr, ptr %t474, !tbaa !29
  %t479 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t471, ptr %t475)
  store i1 %t479, ptr %l262
  br label %bb163
bb163:
  %t480 = load i1, ptr %l262, !tbaa !21
  store i1 %t480, ptr %l257, !tbaa !21
  br label %bb164
bb164:
  %t481 = load i1, ptr %l257, !tbaa !21
  br i1 %t481, label %bb165, label %bb166
bb165:
  store i1 true, ptr %l263, !tbaa !21
  br label %bb168
bb166:
  %t482 = load ptr, ptr %l0, !tbaa !29
  %t483 = load ptr, ptr %l25, !tbaa !29
  %t485 = getelementptr %"compiler/typed:Slice", ptr %t483, i32 0, i32 2
  %t486 = load ptr, ptr %t485, !tbaa !29
  %t490 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t482, ptr %t486)
  store i1 %t490, ptr %l268
  br label %bb167
bb167:
  %t491 = load i1, ptr %l268, !tbaa !21
  store i1 %t491, ptr %l263, !tbaa !21
  br label %bb168
bb168:
  %t492 = load i1, ptr %l263, !tbaa !21
  store i1 %t492, ptr %rv
  br label %ret
bb169:
  %t493 = load ptr, ptr %l1, !tbaa !29
  store ptr %t493, ptr %l269, !tbaa !29
  store i1 false, ptr %l270, !tbaa !21
  %t494 = load ptr, ptr %l269, !tbaa !29
  %t495 = icmp ne ptr %t494, null
  br i1 %t495, label %bb170, label %bb171
bb170:
  %t497 = load ptr, ptr %l269, !tbaa !29
  %t498 = load i64, ptr %t497, !range !{i64 0, i64 18}
  %t500 = icmp eq i64 %t498, 11
  store i1 %t500, ptr %l270, !tbaa !21
  br label %bb171
bb171:
  %t501 = load i1, ptr %l270, !tbaa !21
  br i1 %t501, label %bb172, label %bb173
bb172:
  %t502 = load ptr, ptr %l1, !tbaa !29
  %t504 = getelementptr { i64, [5 x i64] }, ptr %t502, i32 0, i32 1
  %t505 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t504, i32 0, i32 2
  %t506 = load ptr, ptr %t505
  store ptr %t506, ptr %l26, !tbaa !29
  br label %bb174
bb173:
  br label %bb184
bb174:
  %t508 = load ptr, ptr %l0, !tbaa !29
  %t509 = load ptr, ptr %l26, !tbaa !29
  %t511 = getelementptr %"compiler/typed:Cond", ptr %t509, i32 0, i32 0
  %t512 = load ptr, ptr %t511, !tbaa !29
  %t516 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t508, ptr %t512)
  store i1 %t516, ptr %l279
  br label %bb175
bb175:
  %t517 = load i1, ptr %l279, !tbaa !21
  br i1 %t517, label %bb176, label %bb177
bb176:
  store i1 true, ptr %l280, !tbaa !21
  br label %bb179
bb177:
  %t518 = load ptr, ptr %l0, !tbaa !29
  %t519 = load ptr, ptr %l26, !tbaa !29
  %t521 = getelementptr %"compiler/typed:Cond", ptr %t519, i32 0, i32 1
  %t522 = load ptr, ptr %t521, !tbaa !29
  %t525 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t518, ptr %t522)
  store i1 %t525, ptr %l284
  br label %bb178
bb178:
  %t526 = load i1, ptr %l284, !tbaa !21
  store i1 %t526, ptr %l280, !tbaa !21
  br label %bb179
bb179:
  %t527 = load i1, ptr %l280, !tbaa !21
  br i1 %t527, label %bb180, label %bb181
bb180:
  store i1 true, ptr %l285, !tbaa !21
  br label %bb183
bb181:
  %t528 = load ptr, ptr %l0, !tbaa !29
  %t529 = load ptr, ptr %l26, !tbaa !29
  %t531 = getelementptr %"compiler/typed:Cond", ptr %t529, i32 0, i32 2
  %t532 = load ptr, ptr %t531, !tbaa !29
  %t536 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t528, ptr %t532)
  store i1 %t536, ptr %l290
  br label %bb182
bb182:
  %t537 = load i1, ptr %l290, !tbaa !21
  store i1 %t537, ptr %l285, !tbaa !21
  br label %bb183
bb183:
  %t538 = load i1, ptr %l285, !tbaa !21
  store i1 %t538, ptr %rv
  br label %ret
bb184:
  %t539 = load ptr, ptr %l1, !tbaa !29
  store ptr %t539, ptr %l291, !tbaa !29
  store i1 false, ptr %l292, !tbaa !21
  %t540 = load ptr, ptr %l291, !tbaa !29
  %t541 = icmp ne ptr %t540, null
  br i1 %t541, label %bb185, label %bb186
bb185:
  %t543 = load ptr, ptr %l291, !tbaa !29
  %t544 = load i64, ptr %t543, !range !{i64 0, i64 18}
  %t546 = icmp eq i64 %t544, 12
  store i1 %t546, ptr %l292, !tbaa !21
  br label %bb186
bb186:
  %t547 = load i1, ptr %l292, !tbaa !21
  br i1 %t547, label %bb187, label %bb188
bb187:
  %t548 = load ptr, ptr %l1, !tbaa !29
  %t550 = getelementptr { i64, [5 x i64] }, ptr %t548, i32 0, i32 1
  %t551 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t550, i32 0, i32 2
  %t552 = load ptr, ptr %t551
  store ptr %t552, ptr %l27, !tbaa !29
  br label %bb189
bb188:
  br label %bb195
bb189:
  %t554 = load ptr, ptr %l0, !tbaa !29
  %t555 = load ptr, ptr %l27, !tbaa !29
  %t557 = getelementptr %"compiler/typed:Seq", ptr %t555, i32 0, i32 0
  %t558 = load { i64, ptr }, ptr %t557, !tbaa !27
  %t561 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffSs(ptr %v0, ptr %v1, ptr %t554, { i64, ptr } %t558)
  store i1 %t561, ptr %l300
  br label %bb190
bb190:
  %t562 = load i1, ptr %l300, !tbaa !21
  br i1 %t562, label %bb191, label %bb192
bb191:
  store i1 true, ptr %l301, !tbaa !21
  br label %bb194
bb192:
  %t563 = load ptr, ptr %l0, !tbaa !29
  %t564 = load ptr, ptr %l27, !tbaa !29
  %t566 = getelementptr %"compiler/typed:Seq", ptr %t564, i32 0, i32 1
  %t567 = load ptr, ptr %t566, !tbaa !29
  %t570 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t563, ptr %t567)
  store i1 %t570, ptr %l305
  br label %bb193
bb193:
  %t571 = load i1, ptr %l305, !tbaa !21
  store i1 %t571, ptr %l301, !tbaa !21
  br label %bb194
bb194:
  %t572 = load i1, ptr %l301, !tbaa !21
  store i1 %t572, ptr %rv
  br label %ret
bb195:
  %t573 = load ptr, ptr %l1, !tbaa !29
  store ptr %t573, ptr %l306, !tbaa !29
  store i1 false, ptr %l307, !tbaa !21
  %t574 = load ptr, ptr %l306, !tbaa !29
  %t575 = icmp ne ptr %t574, null
  br i1 %t575, label %bb196, label %bb197
bb196:
  %t577 = load ptr, ptr %l306, !tbaa !29
  %t578 = load i64, ptr %t577, !range !{i64 0, i64 18}
  %t580 = icmp eq i64 %t578, 13
  store i1 %t580, ptr %l307, !tbaa !21
  br label %bb197
bb197:
  %t581 = load i1, ptr %l307, !tbaa !21
  br i1 %t581, label %bb198, label %bb199
bb198:
  %t582 = load ptr, ptr %l1, !tbaa !29
  %t584 = getelementptr { i64, [5 x i64] }, ptr %t582, i32 0, i32 1
  %t585 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t584, i32 0, i32 2
  %t586 = load ptr, ptr %t585
  store ptr %t586, ptr %l28, !tbaa !29
  br label %bb200
bb199:
  br label %bb222
bb200:
  %t588 = load ptr, ptr %l0, !tbaa !29
  %t589 = load ptr, ptr %l28, !tbaa !29
  %t591 = getelementptr %"compiler/typed:Match", ptr %t589, i32 0, i32 0
  %t592 = load { i64, ptr }, ptr %t591, !tbaa !27
  %t595 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffSs(ptr %v0, ptr %v1, ptr %t588, { i64, ptr } %t592)
  store i1 %t595, ptr %l315
  br label %bb201
bb201:
  %t596 = load i1, ptr %l315, !tbaa !21
  br i1 %t596, label %bb202, label %bb203
bb202:
  store i1 true, ptr %rv
  br label %ret
bb203:
  br label %bb204
bb204:
  %t598 = load ptr, ptr %l28, !tbaa !29
  %t600 = getelementptr %"compiler/typed:Match", ptr %t598, i32 0, i32 1
  %t601 = load { i64, ptr }, ptr %t600, !tbaa !27
  store { i64, ptr } %t601, ptr %l29, !tbaa !27
  store i64 0, ptr %l30, !tbaa !24
  %t603 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t605 = extractvalue { i64, ptr } %t603, 0
  store i64 %t605, ptr %l31, !tbaa !24
  br label %bb205
bb205:
  %t607 = load i64, ptr %l30, !tbaa !24
  %t608 = load i64, ptr %l31, !tbaa !24
  %t611 = icmp slt i64 %t607, %t608
  %t613 = xor i1 %t611, true
  br i1 %t613, label %bb206, label %bb207
bb206:
  br label %bb214
bb207:
  br label %bb208
bb208:
  %t615 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t615, ptr %l325, !tbaa !27
  %t616 = load i64, ptr %l30, !tbaa !24
  %t618 = getelementptr { i64, ptr }, ptr %l325, i32 0, i32 1
  %t619 = load ptr, ptr %t618, !tbaa !27
  %t620 = getelementptr ptr, ptr %t619, i64 %t616
  %t621 = load ptr, ptr %t620, !tbaa !39
  %t623 = load ptr, ptr %l0, !tbaa !29
  %t627 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffArm(ptr %v0, ptr %v1, ptr %t623, ptr %t621)
  store i1 %t627, ptr %l330
  br label %bb209
bb209:
  %t628 = load i1, ptr %l330, !tbaa !21
  br i1 %t628, label %bb210, label %bb211
bb210:
  store i1 true, ptr %rv
  br label %ret
bb211:
  br label %bb212
bb212:
  br label %bb213
bb213:
  %t630 = load i64, ptr %l30, !tbaa !24
  %t632 = add i64 %t630, 1
  store i64 %t632, ptr %l30, !tbaa !24
  br label %bb205
bb214:
  %t634 = load ptr, ptr %l28, !tbaa !29
  %t636 = getelementptr %"compiler/typed:Match", ptr %t634, i32 0, i32 2
  %t637 = load ptr, ptr %t636, !tbaa !29
  %t639 = icmp eq ptr %t637, null
  %t641 = xor i1 %t639, true
  br i1 %t641, label %bb215, label %bb216
bb215:
  %t643 = load ptr, ptr %l0, !tbaa !29
  store ptr %t643, ptr %l339, !tbaa !29
  %t644 = load ptr, ptr %l28, !tbaa !29
  %t646 = getelementptr %"compiler/typed:Match", ptr %t644, i32 0, i32 2
  %t647 = load ptr, ptr %t646, !tbaa !29
  %t649 = icmp eq ptr %t647, null
  br i1 %t649, label %bb217, label %bb218
bb216:
  store i1 false, ptr %l338, !tbaa !21
  br label %bb221
bb217:
  call void @__olang_check_failed(ptr @olang_loc_ad4dc9fe288360e2_6bae22496d237a26)
  unreachable
bb218:
  br label %bb219
bb219:
  %t651 = load ptr, ptr %l28, !tbaa !29
  %t653 = getelementptr %"compiler/typed:Match", ptr %t651, i32 0, i32 2
  %t654 = load ptr, ptr %t653, !tbaa !29
  %t655 = load ptr, ptr %l339, !tbaa !29
  %t657 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffArm(ptr %v0, ptr %v1, ptr %t655, ptr %t654)
  store i1 %t657, ptr %l345
  br label %bb220
bb220:
  %t658 = load i1, ptr %l345, !tbaa !21
  store i1 %t658, ptr %l338, !tbaa !21
  br label %bb221
bb221:
  %t659 = load i1, ptr %l338, !tbaa !21
  store i1 %t659, ptr %rv
  br label %ret
bb222:
  %t660 = load ptr, ptr %l1, !tbaa !29
  store ptr %t660, ptr %l346, !tbaa !29
  store i1 false, ptr %l347, !tbaa !21
  %t661 = load ptr, ptr %l346, !tbaa !29
  %t662 = icmp ne ptr %t661, null
  br i1 %t662, label %bb223, label %bb224
bb223:
  %t664 = load ptr, ptr %l346, !tbaa !29
  %t665 = load i64, ptr %t664, !range !{i64 0, i64 18}
  %t667 = icmp eq i64 %t665, 14
  store i1 %t667, ptr %l347, !tbaa !21
  br label %bb224
bb224:
  %t668 = load i1, ptr %l347, !tbaa !21
  br i1 %t668, label %bb225, label %bb226
bb225:
  %t669 = load ptr, ptr %l1, !tbaa !29
  %t671 = getelementptr { i64, [5 x i64] }, ptr %t669, i32 0, i32 1
  %t672 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t671, i32 0, i32 2
  %t673 = load ptr, ptr %t672
  store ptr %t673, ptr %l33, !tbaa !29
  br label %bb227
bb226:
  br label %bb255
bb227:
  %t675 = load ptr, ptr %l33, !tbaa !29
  %t677 = getelementptr %"compiler/typed:Try", ptr %t675, i32 0, i32 2
  %t678 = load i1, ptr %t677, !tbaa !21
  br i1 %t678, label %bb228, label %bb229
bb228:
  store i1 true, ptr %l354, !tbaa !21
  br label %bb231
bb229:
  %t680 = load ptr, ptr %l0, !tbaa !29
  %t681 = load ptr, ptr %l33, !tbaa !29
  %t683 = getelementptr %"compiler/typed:Try", ptr %t681, i32 0, i32 0
  %t684 = load ptr, ptr %t683, !tbaa !29
  %t687 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t680, ptr %t684)
  store i1 %t687, ptr %l358
  br label %bb230
bb230:
  %t688 = load i1, ptr %l358, !tbaa !21
  store i1 %t688, ptr %l354, !tbaa !21
  br label %bb231
bb231:
  %t689 = load i1, ptr %l354, !tbaa !21
  br i1 %t689, label %bb232, label %bb233
bb232:
  store i1 true, ptr %rv
  br label %ret
bb233:
  br label %bb234
bb234:
  %t691 = load ptr, ptr %l33, !tbaa !29
  %t693 = getelementptr %"compiler/typed:Try", ptr %t691, i32 0, i32 1
  %t694 = load { i64, ptr }, ptr %t693, !tbaa !27
  store { i64, ptr } %t694, ptr %l34, !tbaa !27
  store i64 0, ptr %l35, !tbaa !24
  %t696 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t698 = extractvalue { i64, ptr } %t696, 0
  store i64 %t698, ptr %l36, !tbaa !24
  br label %bb235
bb235:
  %t700 = load i64, ptr %l35, !tbaa !24
  %t701 = load i64, ptr %l36, !tbaa !24
  %t704 = icmp slt i64 %t700, %t701
  %t706 = xor i1 %t704, true
  br i1 %t706, label %bb236, label %bb237
bb236:
  br label %bb254
bb237:
  br label %bb238
bb238:
  %t708 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t708, ptr %l368, !tbaa !27
  %t709 = load i64, ptr %l35, !tbaa !24
  %t711 = getelementptr { i64, ptr }, ptr %l368, i32 0, i32 1
  %t712 = load ptr, ptr %t711, !tbaa !27
  %t713 = getelementptr ptr, ptr %t712, i64 %t709
  %t714 = load ptr, ptr %t713, !tbaa !39
  store ptr %t714, ptr %l37, !tbaa !29
  %t716 = load ptr, ptr %l0, !tbaa !29
  %t717 = load ptr, ptr %l37, !tbaa !29
  %t719 = getelementptr %"compiler/typed:Clause", ptr %t717, i32 0, i32 3
  %t720 = load ptr, ptr %t719, !tbaa !29
  %t723 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffB(ptr %v0, ptr %v1, ptr %t716, ptr %t720)
  store i1 %t723, ptr %l374
  br label %bb239
bb239:
  %t724 = load i1, ptr %l374, !tbaa !21
  br i1 %t724, label %bb240, label %bb241
bb240:
  store i1 true, ptr %rv
  br label %ret
bb241:
  br label %bb242
bb242:
  %t726 = load ptr, ptr %l37, !tbaa !29
  %t728 = getelementptr %"compiler/typed:Clause", ptr %t726, i32 0, i32 4
  %t729 = load { i64, ptr }, ptr %t728, !tbaa !27
  store { i64, ptr } %t729, ptr %l38, !tbaa !27
  store i64 0, ptr %l39, !tbaa !24
  %t731 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t733 = extractvalue { i64, ptr } %t731, 0
  store i64 %t733, ptr %l40, !tbaa !24
  br label %bb243
bb243:
  %t735 = load i64, ptr %l39, !tbaa !24
  %t736 = load i64, ptr %l40, !tbaa !24
  %t739 = icmp slt i64 %t735, %t736
  %t741 = xor i1 %t739, true
  br i1 %t741, label %bb244, label %bb245
bb244:
  br label %bb252
bb245:
  br label %bb246
bb246:
  %t743 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t743, ptr %l384, !tbaa !27
  %t744 = load i64, ptr %l39, !tbaa !24
  %t746 = getelementptr { i64, ptr }, ptr %l384, i32 0, i32 1
  %t747 = load ptr, ptr %t746, !tbaa !27
  %t748 = getelementptr ptr, ptr %t747, i64 %t744
  %t749 = load ptr, ptr %t748, !tbaa !39
  %t751 = load ptr, ptr %l0, !tbaa !29
  %t756 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t751, ptr %t749)
  store i1 %t756, ptr %l390
  br label %bb247
bb247:
  %t757 = load i1, ptr %l390, !tbaa !21
  br i1 %t757, label %bb248, label %bb249
bb248:
  store i1 true, ptr %rv
  br label %ret
bb249:
  br label %bb250
bb250:
  br label %bb251
bb251:
  %t759 = load i64, ptr %l39, !tbaa !24
  %t761 = add i64 %t759, 1
  store i64 %t761, ptr %l39, !tbaa !24
  br label %bb243
bb252:
  br label %bb253
bb253:
  %t763 = load i64, ptr %l35, !tbaa !24
  %t765 = add i64 %t763, 1
  store i64 %t765, ptr %l35, !tbaa !24
  br label %bb235
bb254:
  store i1 false, ptr %rv
  br label %ret
bb255:
  %t768 = load ptr, ptr %l1, !tbaa !29
  store ptr %t768, ptr %l397, !tbaa !29
  store i1 false, ptr %l398, !tbaa !21
  %t769 = load ptr, ptr %l397, !tbaa !29
  %t770 = icmp ne ptr %t769, null
  br i1 %t770, label %bb256, label %bb257
bb256:
  %t772 = load ptr, ptr %l397, !tbaa !29
  %t773 = load i64, ptr %t772, !range !{i64 0, i64 18}
  %t775 = icmp eq i64 %t773, 17
  store i1 %t775, ptr %l398, !tbaa !21
  br label %bb257
bb257:
  %t776 = load i1, ptr %l398, !tbaa !21
  br i1 %t776, label %bb258, label %bb259
bb258:
  %t777 = load ptr, ptr %l1, !tbaa !29
  %t779 = getelementptr { i64, [5 x i64] }, ptr %t777, i32 0, i32 1
  %t780 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t779, i32 0, i32 2
  %t781 = load ptr, ptr %t780
  store ptr %t781, ptr %l42, !tbaa !29
  br label %bb260
bb259:
  br label %bb262
bb260:
  %t783 = load ptr, ptr %l0, !tbaa !29
  %t784 = load ptr, ptr %l42, !tbaa !29
  %t788 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t783, ptr %t784)
  store i1 %t788, ptr %l406
  br label %bb261
bb261:
  %t789 = load i1, ptr %l406, !tbaa !21
  store i1 %t789, ptr %rv
  br label %ret
bb262:
  call void @__olang_check_failed(ptr @olang_loc_29ea0c7d0dcef6fa_322b22c08f06752e)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemptyArray(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l8 = alloca i32
  %l9 = alloca i32
  %l11 = alloca i32
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l23 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca { i64, ptr }
  %l32 = alloca i1
  %l33 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i32, ptr %l8, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load i32, ptr %l2, !tbaa !23
  store i32 %t7, ptr %l9, !tbaa !23
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t8)
  store i32 %t10, ptr %l11
  br label %bb2
bb2:
  %t11 = load i32, ptr %l9, !tbaa !23
  %t12 = load i32, ptr %l11, !tbaa !23
  %t13 = icmp eq i32 %t11, %t12
  br i1 %t13, label %bb3, label %bb4
bb3:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l13, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t15, ptr %l14, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l15, !tbaa !24
  %t18 = load i64, ptr %l15, !tbaa !24
  %t19 = mul i64 %t18, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  %t23 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = load i64, ptr %l15, !tbaa !24
  %t28 = mul i64 %t27, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t24, ptr %t26, i64 %t28, i1 false)
  %t29 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t29, ptr %l14, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t30 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t30, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 5
  %t34 = load i1, ptr %t33, !tbaa !21
  store i1 %t34, ptr %l3, !tbaa !21
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 5
  store i1 true, ptr %t38, !tbaa !21
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l20, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/check:Checker", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/generic:Program", ptr %t43, i32 0, i32 2
  store ptr %t45, ptr %l23, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i32, ptr %l2, !tbaa !23
  %t50 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t46, i32 %t47)
  store i32 %t50, ptr %l26
  br label %bb6
bb6:
  %t51 = load ptr, ptr %l23, !tbaa !29
  %t52 = load i32, ptr %l26, !tbaa !23
  %t53 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t51, i32 %t52)
  store i32 %t53, ptr %l27
  br label %bb7
bb7:
  %t54 = load ptr, ptr %l20, !tbaa !29
  %t55 = load i32, ptr %l27, !tbaa !23
  %t56 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t54, i32 %t55)
  store { i64, ptr } %t56, ptr %l28
  br label %bb8
bb8:
  %t57 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t59 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 1
  %t61 = extractvalue { i64, ptr } %t59, 0
  %t62 = add i64 %t58, %t61
  %t63 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t64 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t65 = add i64 %t62, %t64
  %t66 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t65)
  call void @olang_textcopy(ptr %t66, ptr %t57, i64 %t58)
  %t67 = getelementptr i8, ptr %t66, i64 %t58
  call void @olang_textcopy(ptr %t67, ptr %t60, i64 %t61)
  %t68 = getelementptr i8, ptr %t67, i64 %t61
  call void @olang_textcopy(ptr %t68, ptr %t63, i64 %t64)
  %t69 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t66, 1
  store { i64, ptr } %t70, ptr %l4, !tbaa !27
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i32, ptr %l2, !tbaa !23
  %t76 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t72, i32 %t73)
  store i1 %t76, ptr %l32
  br label %bb9
bb9:
  %t77 = load i1, ptr %l32, !tbaa !21
  br i1 %t77, label %bb10, label %bb11
bb10:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i32, ptr %l2, !tbaa !23
  %t82 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t78, i32 %t79)
  store { i64, ptr } %t82, ptr %l36
  br label %bb12
bb11:
  %t83 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t83, ptr %l33, !tbaa !27
  br label %bb13
bb12:
  %t85 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t86 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t90 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t91 = add i64 %t88, %t90
  %t93 = extractvalue { i64, ptr } %t85, 1
  %t94 = extractvalue { i64, ptr } %t85, 0
  %t95 = add i64 %t91, %t94
  %t96 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t97 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t98 = add i64 %t95, %t97
  %t99 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t98)
  call void @olang_textcopy(ptr %t99, ptr %t87, i64 %t88)
  %t100 = getelementptr i8, ptr %t99, i64 %t88
  call void @olang_textcopy(ptr %t100, ptr %t89, i64 %t90)
  %t101 = getelementptr i8, ptr %t100, i64 %t90
  call void @olang_textcopy(ptr %t101, ptr %t93, i64 %t94)
  %t102 = getelementptr i8, ptr %t101, i64 %t94
  call void @olang_textcopy(ptr %t102, ptr %t96, i64 %t97)
  %t103 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t99, 1
  store { i64, ptr } %t104, ptr %l33, !tbaa !27
  br label %bb13
bb13:
  %t106 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i1, ptr %l3, !tbaa !21
  %t111 = getelementptr %"compiler/check:Checker", ptr %t107, i32 0, i32 5
  store i1 %t108, ptr %t111, !tbaa !21
  store { i64, ptr } %t106, ptr %l42, !tbaa !27
  %t113 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  store i64 %t114, ptr %l43, !tbaa !24
  %t115 = load i64, ptr %l43, !tbaa !24
  %t116 = mul i64 %t115, 1
  %t117 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t116)
  %t118 = insertvalue { i64, ptr } undef, i64 %t115, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t117, 1
  store { i64, ptr } %t119, ptr %l44, !tbaa !27
  %t120 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = load i64, ptr %l43, !tbaa !24
  %t125 = mul i64 %t124, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t121, ptr %t123, i64 %t125, i1 false)
  %t126 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t126, ptr %l42, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t127 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t127, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrValues(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l9 = alloca i32
  %l12 = alloca i32
  %l15 = alloca i32
  %l19 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l34 = alloca i1
  %l35 = alloca i32
  %l38 = alloca { i64, ptr }
  %l40 = alloca %"compiler/msgs:Msg"
  %l41 = alloca i64
  %l44 = alloca ptr
  %l49 = alloca i1
  %l51 = alloca i1
  %l56 = alloca i1
  %l62 = alloca i1
  %l63 = alloca ptr
  %l66 = alloca ptr
  %l67 = alloca %"compiler/source:Span"
  %l68 = alloca ptr
  %l70 = alloca %"compiler/source:Span"
  %l71 = alloca { i64, ptr }
  %l74 = alloca %"compiler/msgs:Msg"
  %l75 = alloca i64
  %l79 = alloca ptr
  %l84 = alloca ptr
  %l85 = alloca ptr
  %l86 = alloca ptr
  %l91 = alloca i32
  %l92 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l93 = alloca ptr
  %l94 = alloca ptr
  %l99 = alloca i32
  %l100 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l102 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l104 = alloca { i64, ptr }
  %l105 = alloca i32
  %l109 = alloca ptr
  %l113 = alloca ptr
  %l114 = alloca ptr
  %l115 = alloca %"compiler/source:Span"
  %l116 = alloca i32
  %l119 = alloca i32
  %l125 = alloca ptr
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l4, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1)
  store i32 %t4, ptr %l12
  br label %bb1
bb1:
  %t5 = load i32, ptr %l12, !tbaa !23
  store i32 %t5, ptr %l6, !tbaa !23
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t9 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t6)
  store i32 %t9, ptr %l15
  br label %bb2
bb2:
  %t10 = load i32, ptr %l15, !tbaa !23
  store i32 %t10, ptr %l7, !tbaa !23
  %t11 = load i32, ptr %l3, !range !{i32 0, i32 96}
  %t13 = trunc i64 76 to i32
  %t14 = icmp eq i32 %t11, %t13
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb3, label %bb4
bb3:
  %t18 = load i32, ptr %l3, !range !{i32 0, i32 96}
  %t20 = trunc i64 77 to i32
  %t21 = icmp eq i32 %t18, %t20
  %t23 = xor i1 %t21, true
  store i1 %t23, ptr %l19, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l19, !tbaa !21
  br i1 %t25, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l23, !tbaa !29
  %t27 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t27, ptr %l24
  %t28 = load i32, ptr %l3, !range !{i32 0, i32 96}
  %t30 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s1, i32 %t28)
  store { i64, ptr } %t30, ptr %l26
  br label %bb8
bb7:
  br label %bb18
bb8:
  %t31 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t32 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s1, ptr %s1, { i64, ptr } %t31)
  store { i64, ptr } %t32, ptr %l27
  br label %bb9
bb9:
  %t33 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  %t35 = extractvalue { i64, ptr } %t33, 1
  %t36 = mul i64 %t34, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t36)
  call void @llvm.memcpy.p0.p0.i64(ptr %t37, ptr %t35, i64 %t36, i1 false)
  %t38 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l28, !tbaa !27
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l29, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 2
  %t47 = load i32, ptr %l6, !tbaa !23
  %t50 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %t46, i32 %t47)
  store i1 %t50, ptr %l34
  br label %bb10
bb10:
  %t51 = load i1, ptr %l34, !tbaa !21
  br i1 %t51, label %bb11, label %bb12
bb11:
  %t52 = load i32, ptr %l6, !tbaa !23
  store i32 %t52, ptr %l35, !tbaa !23
  br label %bb13
bb12:
  %t54 = load i32, ptr %l7, !tbaa !23
  store i32 %t54, ptr %l35, !tbaa !23
  br label %bb13
bb13:
  %t56 = load ptr, ptr %l29, !tbaa !29
  %t57 = load i32, ptr %l35, !tbaa !23
  %t58 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t56, i32 %t57)
  store { i64, ptr } %t58, ptr %l38
  br label %bb14
bb14:
  %t59 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 0
  %t61 = extractvalue { i64, ptr } %t59, 1
  %t62 = mul i64 %t60, 1
  %t63 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t62)
  call void @llvm.memcpy.p0.p0.i64(ptr %t63, ptr %t61, i64 %t62, i1 false)
  %t64 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  %t66 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t68 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrValueNoOp(ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %t66, { i64, ptr } %t65)
  store %"compiler/msgs:Msg" %t68, ptr %l40
  br label %bb15
bb15:
  %t69 = load ptr, ptr %l23, !tbaa !29
  %t70 = load %"compiler/source:Span", ptr %l24
  %t71 = load %"compiler/msgs:Msg", ptr %l40
  %t72 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t69, %"compiler/source:Span" %t70, %"compiler/msgs:Msg" %t71)
  store i64 %t72, ptr %l41
  br label %bb16
bb16:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load %"compiler/source:Span", ptr %l1
  %t77 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t73, %"compiler/source:Span" %t74)
  store ptr %t77, ptr %l44
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s1)
  %t78 = load ptr, ptr %l44, !tbaa !29
  store ptr %t78, ptr %rv
  br label %ret
bb18:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/generic:Program", ptr %t82, i32 0, i32 2
  %t85 = load i32, ptr %l6, !tbaa !23
  %t88 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %t84, i32 %t85)
  store i1 %t88, ptr %l49
  br label %bb19
bb19:
  %t89 = load i1, ptr %l49, !tbaa !21
  %t90 = xor i1 %t89, true
  br i1 %t90, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb23
bb21:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = getelementptr %"compiler/generic:Program", ptr %t95, i32 0, i32 2
  %t98 = load i32, ptr %l7, !tbaa !23
  %t101 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %t97, i32 %t98)
  store i1 %t101, ptr %l56
  br label %bb22
bb22:
  %t102 = load i1, ptr %l56, !tbaa !21
  %t103 = xor i1 %t102, true
  store i1 %t103, ptr %l51, !tbaa !21
  br label %bb23
bb23:
  %t105 = load i1, ptr %l51, !tbaa !21
  br i1 %t105, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s2
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/generic:Program", ptr %t109, i32 0, i32 2
  %t112 = load i32, ptr %l6, !tbaa !23
  %t115 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %t111, i32 %t112)
  store i1 %t115, ptr %l62
  br label %bb26
bb25:
  br label %bb35
bb26:
  %t116 = load i1, ptr %l62, !tbaa !21
  br i1 %t116, label %bb27, label %bb28
bb27:
  %t117 = load ptr, ptr %l4, !tbaa !29
  store ptr %t117, ptr %l63, !tbaa !29
  br label %bb29
bb28:
  %t119 = load ptr, ptr %l5, !tbaa !29
  store ptr %t119, ptr %l63, !tbaa !29
  br label %bb29
bb29:
  %t121 = load ptr, ptr %l63, !tbaa !29
  %t122 = load ptr, ptr %l0, !tbaa !29
  store ptr %t122, ptr %l66, !tbaa !29
  %t123 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t123, ptr %l67
  %t124 = load ptr, ptr %l0, !tbaa !29
  store ptr %t124, ptr %l68, !tbaa !29
  %t127 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t121)
  store %"compiler/source:Span" %t127, ptr %l70
  br label %bb30
bb30:
  %t128 = load ptr, ptr %l68, !tbaa !29
  %t129 = load %"compiler/source:Span", ptr %l70
  %t130 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t128, %"compiler/source:Span" %t129)
  store { i64, ptr } %t130, ptr %l71
  br label %bb31
bb31:
  %t131 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t132 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t133 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 1
  %t135 = extractvalue { i64, ptr } %t133, 0
  %t136 = add i64 %t132, %t135
  %t137 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t138 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t139 = add i64 %t136, %t138
  %t140 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t139)
  call void @olang_textcopy(ptr %t140, ptr %t131, i64 %t132)
  %t141 = getelementptr i8, ptr %t140, i64 %t132
  call void @olang_textcopy(ptr %t141, ptr %t134, i64 %t135)
  %t142 = getelementptr i8, ptr %t141, i64 %t135
  call void @olang_textcopy(ptr %t142, ptr %t137, i64 %t138)
  %t143 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t140, 1
  %t146 = extractvalue { i64, ptr } %t144, 0
  %t147 = extractvalue { i64, ptr } %t144, 1
  %t148 = mul i64 %t146, 1
  %t149 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t148)
  call void @llvm.memcpy.p0.p0.i64(ptr %t149, ptr %t147, i64 %t148, i1 false)
  %t150 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  %t153 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtCompareWhat(ptr %s2, ptr %s2, { i64, ptr } %t151)
  store %"compiler/msgs:Msg" %t153, ptr %l74
  br label %bb32
bb32:
  %t154 = load ptr, ptr %l66, !tbaa !29
  %t155 = load %"compiler/source:Span", ptr %l67
  %t156 = load %"compiler/msgs:Msg", ptr %l74
  %t157 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t154, %"compiler/source:Span" %t155, %"compiler/msgs:Msg" %t156)
  store i64 %t157, ptr %l75
  br label %bb33
bb33:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load %"compiler/source:Span", ptr %l1
  %t160 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t164 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t158, %"compiler/source:Span" %t159, i32 %t160, i64 0)
  store ptr %t164, ptr %l79
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s2)
  %t165 = load ptr, ptr %l79, !tbaa !29
  store ptr %t165, ptr %rv
  br label %ret
bb35:
  %t166 = load i32, ptr %l6, !tbaa !23
  %t167 = load i32, ptr %l7, !tbaa !23
  %t170 = icmp ne i32 %t166, %t167
  br i1 %t170, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s4
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr %"compiler/check:Checker", ptr %t172, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !29
  store ptr %t175, ptr %l84, !tbaa !29
  %t176 = load ptr, ptr %l0, !tbaa !29
  store ptr %t176, ptr %l85, !tbaa !29
  %t177 = load ptr, ptr %l0, !tbaa !29
  store ptr %t177, ptr %l86, !tbaa !29
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr %"compiler/check:Checker", ptr %t178, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !29
  %t183 = getelementptr %"compiler/generic:Program", ptr %t181, i32 0, i32 2
  %t184 = load i32, ptr %l6, !tbaa !23
  %t187 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t183, i32 %t184)
  store i32 %t187, ptr %l91
  br label %bb38
bb37:
  br label %bb47
bb38:
  %t188 = load ptr, ptr %l86, !tbaa !29
  %t189 = load i32, ptr %l91, !tbaa !23
  %t190 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetItems(ptr %v0, ptr %s4, ptr %t188, i32 %t189)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t190, ptr %l92
  br label %bb39
bb39:
  %t191 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l92
  %t192 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t191, ptr %t192
  store ptr %t192, ptr %l93, !tbaa !29
  %t193 = load ptr, ptr %l0, !tbaa !29
  store ptr %t193, ptr %l94, !tbaa !29
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/check:Checker", ptr %t194, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !29
  %t199 = getelementptr %"compiler/generic:Program", ptr %t197, i32 0, i32 2
  %t200 = load i32, ptr %l7, !tbaa !23
  %t203 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t199, i32 %t200)
  store i32 %t203, ptr %l99
  br label %bb40
bb40:
  %t204 = load ptr, ptr %l94, !tbaa !29
  %t205 = load i32, ptr %l99, !tbaa !23
  %t206 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetItems(ptr %v0, ptr %s4, ptr %t204, i32 %t205)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t206, ptr %l100
  br label %bb41
bb41:
  %t207 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l100
  %t208 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t207, ptr %t208
  %t209 = load ptr, ptr %l85, !tbaa !29
  %t210 = load ptr, ptr %l93, !tbaa !29
  %t212 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetUnion(ptr %v0, ptr %s4, ptr %s4, ptr %s4, ptr %t209, ptr %t210, ptr %t208)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t212, ptr %l102
  br label %bb42
bb42:
  %t213 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l102
  %t214 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t213, ptr %t214
  %t216 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %s4, ptr %s4, ptr %t214)
  store { i64, ptr } %t216, ptr %l104
  br label %bb43
bb43:
  %t217 = load ptr, ptr %l84, !tbaa !29
  %t218 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t219 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrValOf(ptr %v0, ptr %s4, ptr %t217, { i64, ptr } %t218)
  store i32 %t219, ptr %l105
  br label %bb44
bb44:
  %t220 = load i32, ptr %l105, !tbaa !23
  store i32 %t220, ptr %l9, !tbaa !23
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load ptr, ptr %l4, !tbaa !29
  %t223 = load i32, ptr %l9, !tbaa !23
  %t227 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrRecode(ptr %v0, ptr %t221, ptr %t222, i32 %t223)
  store ptr %t227, ptr %l109
  br label %bb45
bb45:
  %t228 = load ptr, ptr %l109, !tbaa !29
  store ptr %t228, ptr %l4, !tbaa !29
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t230 = load ptr, ptr %l5, !tbaa !29
  %t231 = load i32, ptr %l9, !tbaa !23
  %t235 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrRecode(ptr %v0, ptr %t229, ptr %t230, i32 %t231)
  store ptr %t235, ptr %l113
  br label %bb46
bb46:
  %t236 = load ptr, ptr %l113, !tbaa !29
  store ptr %t236, ptr %l5, !tbaa !29
  call void @__olang_scope_close(ptr %s4)
  br label %bb47
bb47:
  %t237 = load ptr, ptr %l0, !tbaa !29
  store ptr %t237, ptr %l114, !tbaa !29
  %t238 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t238, ptr %l115
  %t239 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t239, ptr %l116, !tbaa !23
  %t240 = load i32, ptr %l3, !range !{i32 0, i32 96}
  %t242 = trunc i64 76 to i32
  %t243 = icmp eq i32 %t240, %t242
  br i1 %t243, label %bb48, label %bb49
bb48:
  store i32 13, ptr %l119
  br label %bb50
bb49:
  store i32 14, ptr %l119
  br label %bb50
bb50:
  %t247 = load ptr, ptr %l4, !tbaa !29
  %t248 = load ptr, ptr %l5, !tbaa !29
  %t250 = load ptr, ptr %l114, !tbaa !29
  %t251 = load %"compiler/source:Span", ptr %l115
  %t252 = load i32, ptr %l116, !tbaa !23
  %t253 = load i32, ptr %l119, !range !{i32 0, i32 43}
  %t256 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t250, %"compiler/source:Span" %t251, i32 %t252, i32 %t253, ptr %t247, ptr %t248)
  store ptr %t256, ptr %l125
  br label %bb51
bb51:
  %t257 = load ptr, ptr %l125, !tbaa !29
  store ptr %t257, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexportArray(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i1
  %l9 = alloca i32
  %l14 = alloca i32
  %l17 = alloca i1
  %l18 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i1, ptr %l5, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i32, ptr %l1, !tbaa !23
  %t12 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t8, i32 %t9)
  store i32 %t12, ptr %l9
  br label %bb5
bb5:
  %t13 = load i32, ptr %l9, !tbaa !23
  store i32 %t13, ptr %l2, !tbaa !23
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 2
  %t20 = load i32, ptr %l2, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t19, i32 %t20)
  store i32 %t23, ptr %l14
  br label %bb6
bb6:
  %t24 = load i32, ptr %l14, !range !{i32 0, i32 33}
  %t26 = trunc i64 19 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l18, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/generic:Program", ptr %t33, i32 0, i32 2
  %t36 = load i32, ptr %l2, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t35, i32 %t36)
  store i32 %t39, ptr %l23
  br label %bb9
bb8:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb11
bb9:
  %t40 = load ptr, ptr %l18, !tbaa !29
  %t41 = load i32, ptr %l23, !tbaa !23
  %t42 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %t40, i32 %t41)
  store i1 %t42, ptr %l24
  br label %bb10
bb10:
  %t43 = load i1, ptr %l24, !tbaa !21
  store i1 %t43, ptr %l17, !tbaa !21
  br label %bb11
bb11:
  %t44 = load i1, ptr %l17, !tbaa !21
  store i1 %t44, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailOp(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/source:Span" %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l35 = alloca %"compiler/source:Span"
  %l37 = alloca %"compiler/msgs:Msg"
  %l38 = alloca %"compiler/msgs:Msg"
  %l39 = alloca %"compiler/msgs:Msg"
  %l40 = alloca i64
  %s5 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l10, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l4, !tbaa !29
  store ptr %t5, ptr %l11, !tbaa !29
  %t6 = load ptr, ptr %l11, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t6, i32 0, i32 16
  %t8 = load i64, ptr %t7, !tbaa !24
  %t10 = add i64 %t8, 1
  %t12 = load ptr, ptr %l11, !tbaa !29
  %t13 = getelementptr %"compiler/check:frame", ptr %t12, i32 0, i32 16
  store i64 %t10, ptr %t13, !tbaa !24
  store { i64, ptr } %a1, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  store i64 %t18, ptr %l7, !tbaa !24
  br label %bb2
bb2:
  %t20 = load i64, ptr %l6, !tbaa !24
  %t21 = load i64, ptr %l7, !tbaa !24
  %t24 = icmp slt i64 %t20, %t21
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t28 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t28, ptr %l21, !tbaa !27
  %t29 = load i64, ptr %l6, !tbaa !24
  %t31 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr i32, ptr %t32, i64 %t29
  %t34 = load i32, ptr %t33, !tbaa !33
  store i32 %t34, ptr %l8, !tbaa !23
  %t36 = load i32, ptr %l8, !tbaa !23
  %t37 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t40 = icmp ne i32 %t36, %t37
  br i1 %t40, label %bb6, label %bb7
bb6:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l8, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaks1(ptr %v0, ptr %t42, i32 %t43)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t46 = load i64, ptr %l6, !tbaa !24
  %t48 = add i64 %t46, 1
  store i64 %t48, ptr %l6, !tbaa !24
  br label %bb2
bb11:
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t52 = getelementptr %"compiler/check:frame", ptr %t50, i32 0, i32 15
  %t53 = load i64, ptr %t52, !tbaa !24
  %t55 = icmp eq i64 %t53, 0
  br i1 %t55, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s5
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l34, !tbaa !29
  store %"compiler/source:Span" %a2, ptr %l35
  br i1 %a3, label %bb14, label %bb15
bb13:
  br label %bb20
bb14:
  %t61 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAsCanFail(ptr %s5)
  store %"compiler/msgs:Msg" %t61, ptr %l38
  br label %bb16
bb15:
  %t62 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnhandledFallibleCall(ptr %s5)
  store %"compiler/msgs:Msg" %t62, ptr %l39
  br label %bb17
bb16:
  %t63 = load %"compiler/msgs:Msg", ptr %l38
  store %"compiler/msgs:Msg" %t63, ptr %l37
  br label %bb18
bb17:
  %t64 = load %"compiler/msgs:Msg", ptr %l39
  store %"compiler/msgs:Msg" %t64, ptr %l37
  br label %bb18
bb18:
  %t65 = load ptr, ptr %l34, !tbaa !29
  %t66 = load %"compiler/source:Span", ptr %l35
  %t67 = load %"compiler/msgs:Msg", ptr %l37
  %t68 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t65, %"compiler/source:Span" %t66, %"compiler/msgs:Msg" %t67)
  store i64 %t68, ptr %l40
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb20
bb20:
  store i32 2, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnBody(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l17 = alloca i64
  %l21 = alloca i32
  %l22 = alloca ptr
  %l24 = alloca { i64, [2 x i64] }
  %l25 = alloca i32
  %l29 = alloca i64
  %l33 = alloca ptr
  %l36 = alloca i64
  %l43 = alloca i1
  %rv = alloca i64
  %t40 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 18
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l10
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l9
  br label %bb1
bb1:
  %t12 = load i64, ptr %l9, !tbaa !24
  store i64 %t12, ptr %l5, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l5, !tbaa !24
  store i64 %t13, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp sge i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load i64, ptr %l2, !tbaa !24
  store i64 %t18, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t24 = load i64, ptr %l1, !tbaa !24
  %t27 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t23, i64 %t24)
  store i64 %t27, ptr %l17
  br label %bb8
bb8:
  %t28 = load i64, ptr %l17, !tbaa !24
  store i64 %t28, ptr %l3, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t33 = load i64, ptr %l1, !tbaa !24
  %t36 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %t32, i64 %t33)
  store i32 %t36, ptr %l21
  br label %bb9
bb9:
  %t37 = load i32, ptr %l21, !tbaa !23
  store i32 %t37, ptr %l4, !tbaa !23
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l22, !tbaa !29
  %t39 = load i64, ptr %l1, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t40
  %t41 = getelementptr { i64, [2 x i64] }, ptr %t40, i32 0, i32 0
  store i64 0, ptr %t41
  %t43 = insertvalue { i64 } undef, i64 %t39, 0
  %t44 = getelementptr { i64, [2 x i64] }, ptr %t40, i32 0, i32 1
  store { i64 } %t43, ptr %t44
  %t45 = load { i64, [2 x i64] }, ptr %t40
  store { i64, [2 x i64] } %t45, ptr %l24
  %t46 = load i32, ptr %l4, !tbaa !23
  store i32 %t46, ptr %l25, !tbaa !23
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t51 = load i64, ptr %l3, !tbaa !24
  %t54 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t50, i64 %t51)
  store i64 %t54, ptr %l29
  br label %bb10
bb10:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  %t62 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t58, i64 %t59)
  store ptr %t62, ptr %l33
  br label %bb11
bb11:
  %t63 = load ptr, ptr %l33, !tbaa !29
  %t65 = getelementptr %"compiler/ast:Func", ptr %t63, i32 0, i32 0
  %t66 = load %"compiler/source:Span", ptr %t65
  %t67 = load ptr, ptr %l22, !tbaa !29
  %t68 = load { i64, [2 x i64] }, ptr %l24
  %t69 = load i32, ptr %l25, !tbaa !23
  %t70 = load i64, ptr %l29, !tbaa !24
  %t72 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t67, { i64, [2 x i64] } %t68, i32 %t69, i64 %t70, %"compiler/source:Span" %t66)
  store i64 %t72, ptr %l36
  br label %bb12
bb12:
  %t73 = load i64, ptr %l36, !tbaa !24
  store i64 %t73, ptr %l2, !tbaa !24
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/check:Checker", ptr %t74, i32 0, i32 18
  %t77 = load i64, ptr %l1, !tbaa !24
  %t78 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t76, i64 %t77, i64 %t78)
  br label %bb13
bb13:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i32, ptr %l4, !tbaa !23
  %t86 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %t82, i32 %t83)
  store i1 %t86, ptr %l43
  br label %bb14
bb14:
  %t87 = load i1, ptr %l43, !tbaa !21
  br i1 %t87, label %bb15, label %bb16
bb15:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/check:Checker", ptr %t88, i32 0, i32 53
  %t91 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t90, i64 %t91, i1 true)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  %t94 = load i64, ptr %l2, !tbaa !24
  store i64 %t94, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l9 = alloca ptr
  %l13 = alloca ptr
  %l16 = alloca ptr
  %l22 = alloca %"compiler/check:Gap"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 -1, ptr %l3, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 14
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  %t7 = icmp sgt i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t9)
  store ptr %t11, ptr %l9
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t12 = load ptr, ptr %l9, !tbaa !29
  %t14 = getelementptr %"compiler/check:frame", ptr %t12, i32 0, i32 2
  %t15 = load i64, ptr %t14, !tbaa !24
  store i64 %t15, ptr %l3, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t17)
  store ptr %t19, ptr %l13
  br label %bb5
bb5:
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t22 = getelementptr %"compiler/check:frame", ptr %t20, i32 0, i32 18
  store i1 true, ptr %t22, !tbaa !21
  br label %bb6
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 13
  store ptr %t25, ptr %l16, !tbaa !29
  %t26 = load i64, ptr %l3, !tbaa !24
  %t30 = extractvalue { i64, ptr } %a2, 1
  %t31 = extractvalue { i64, ptr } %a2, 0
  %t32 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t31)
  call void @olang_textcopy(ptr %t32, ptr %t30, i64 %t31)
  %t33 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t37 = extractvalue { i64, ptr } %t34, 1
  %t38 = mul i64 %t36, 1
  %t39 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t38)
  call void @llvm.memcpy.p0.p0.i64(ptr %t39, ptr %t37, i64 %t38, i1 false)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  %t45 = call %"compiler/check:Gap" @compiler_2fcheck_3aGap_2ector(ptr %v0, ptr %v0, i64 %t26, %"compiler/source:Span" %a1, { i64, ptr } %t41)
  store %"compiler/check:Gap" %t45, ptr %l22
  br label %bb7
bb7:
  %t46 = load ptr, ptr %l16, !tbaa !29
  %t47 = load %"compiler/check:Gap", ptr %l22
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2ePush_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %v0, ptr %t46, %"compiler/check:Gap" %t47)
  br label %bb8
bb8:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalBody(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l16 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l17 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i32
  %l30 = alloca ptr
  %l31 = alloca %"compiler/source:Span"
  %l41 = alloca i64
  %l44 = alloca i64
  %l63 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l74 = alloca ptr
  %l77 = alloca { i64, [2 x i64] }
  %l82 = alloca i32
  %l85 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  %t133 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i32, ptr %l2, !tbaa !23
  %t4 = sext i32 %t2 to i64
  %t7 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t1, i64 %t4)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t7, ptr %l16
  br label %bb1
bb1:
  %t8 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l16
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t8, ptr %l3
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 27
  %t12 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l3
  %t15 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t11, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t12)
  %t16 = extractvalue { i32, i64 } %t15, 1
  %t17 = extractvalue { i32, i64 } %t15, 0
  store i32 %t17, ptr %l22
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb3, label %ok.19, !prof !99
ok.19:
  store i64 %t16, ptr %l21
  br label %bb2
bb2:
  %t20 = load i64, ptr %l21, !tbaa !24
  store i64 %t20, ptr %l17, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t21 = load i64, ptr %l17, !tbaa !24
  store i64 %t21, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = icmp sge i64 %t22, 0
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = load i64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t26, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t32 = load i64, ptr %l1, !tbaa !24
  %t33 = load i32, ptr %l2, !tbaa !23
  %t37 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %t31, i64 %t32, i32 %t33)
  store ptr %t37, ptr %l30
  br label %bb9
bb9:
  %t38 = load ptr, ptr %l30, !tbaa !29
  store ptr %t38, ptr %l5, !tbaa !29
  %t39 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t39, ptr %l31
  br label %bb10
bb10:
  %t40 = load %"compiler/source:Span", ptr %l31
  store %"compiler/source:Span" %t40, ptr %l6
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t43 = icmp eq ptr %t41, null
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb11, label %bb12
bb11:
  store i64 0, ptr %l7, !tbaa !24
  %t47 = load ptr, ptr %l5, !tbaa !29
  %t49 = getelementptr %"compiler/ast:VarDecl", ptr %t47, i32 0, i32 0
  %t50 = load { i64, ptr }, ptr %t49, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t50, 0
  store i64 %t52, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t54 = load i64, ptr %l8, !tbaa !24
  %t55 = load i64, ptr %l7, !tbaa !24
  %t58 = icmp sgt i64 %t54, %t55
  br i1 %t58, label %bb13, label %bb14
bb12:
  br label %bb28
bb13:
  %t60 = load i64, ptr %l9, !tbaa !24
  %t62 = icmp sgt i64 %t60, 0
  br i1 %t62, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb18
bb15:
  %t64 = load i64, ptr %l8, !tbaa !24
  %t65 = load i64, ptr %l7, !tbaa !24
  %t68 = sub i64 %t64, %t65
  %t69 = load i64, ptr %l9, !tbaa !24
  %t72 = add i64 %t68, %t69
  %t74 = sub i64 %t72, 1
  %t75 = load i64, ptr %l9, !tbaa !24
  %t78 = sdiv i64 %t74, %t75
  store i64 %t78, ptr %l44, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb17
bb17:
  %t80 = load i64, ptr %l44, !tbaa !24
  store i64 %t80, ptr %l41, !tbaa !24
  br label %bb18
bb18:
  %t81 = load i64, ptr %l41, !tbaa !24
  store i64 %t81, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb19
bb19:
  %t82 = load i64, ptr %l11, !tbaa !24
  %t83 = load i64, ptr %l10, !tbaa !24
  %t86 = icmp slt i64 %t82, %t83
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb20, label %bb21
bb20:
  br label %bb27
bb21:
  br label %bb22
bb22:
  %t90 = load i64, ptr %l7, !tbaa !24
  %t91 = load i64, ptr %l11, !tbaa !24
  %t92 = load i64, ptr %l9, !tbaa !24
  %t95 = mul i64 %t91, %t92
  %t98 = add i64 %t90, %t95
  store i64 %t98, ptr %l12, !tbaa !24
  %t100 = load ptr, ptr %l5, !tbaa !29
  %t102 = getelementptr %"compiler/ast:VarDecl", ptr %t100, i32 0, i32 0
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  store { i64, ptr } %t103, ptr %l63, !tbaa !27
  %t104 = load i64, ptr %l12, !tbaa !24
  %t106 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr i32, ptr %t107, i64 %t104
  %t109 = load i32, ptr %t108, !tbaa !33
  %t110 = load i32, ptr %l2, !tbaa !23
  %t113 = icmp eq i32 %t109, %t110
  br i1 %t113, label %bb23, label %bb24
bb23:
  %t115 = load ptr, ptr %l5, !tbaa !29
  %t117 = getelementptr %"compiler/ast:VarDecl", ptr %t115, i32 0, i32 1
  %t118 = load { i64, ptr }, ptr %t117, !tbaa !27
  store { i64, ptr } %t118, ptr %l69, !tbaa !27
  %t119 = load i64, ptr %l12, !tbaa !24
  %t121 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr %"compiler/source:Span", ptr %t122, i64 %t119
  %t124 = load %"compiler/source:Span", ptr %t123
  store %"compiler/source:Span" %t124, ptr %l6
  br label %bb25
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t126 = load i64, ptr %l11, !tbaa !24
  %t128 = add i64 %t126, 1
  store i64 %t128, ptr %l11, !tbaa !24
  br label %bb19
bb27:
  br label %bb28
bb28:
  %t130 = load ptr, ptr %l0, !tbaa !29
  store ptr %t130, ptr %l74, !tbaa !29
  %t131 = load i64, ptr %l1, !tbaa !24
  %t132 = load i32, ptr %l2, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t133
  %t134 = getelementptr { i64, [2 x i64] }, ptr %t133, i32 0, i32 0
  store i64 6, ptr %t134
  %t136 = insertvalue { i64, i32 } undef, i64 %t131, 0
  %t138 = insertvalue { i64, i32 } %t136, i32 %t132, 1
  %t139 = getelementptr { i64, [2 x i64] }, ptr %t133, i32 0, i32 1
  store { i64, i32 } %t138, ptr %t139
  %t140 = load { i64, [2 x i64] }, ptr %t133
  store { i64, [2 x i64] } %t140, ptr %l77
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/check:Checker", ptr %t141, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t146 = getelementptr %"compiler/generic:Program", ptr %t144, i32 0, i32 2
  %t147 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t150 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t146, i32 0, i32 %t147, i32 0, i32 0, i64 0)
  store i32 %t150, ptr %l82
  br label %bb29
bb29:
  %t151 = load i64, ptr %l1, !tbaa !24
  %t152 = load %"compiler/source:Span", ptr %l6
  %t153 = load ptr, ptr %l74, !tbaa !29
  %t154 = load { i64, [2 x i64] }, ptr %l77
  %t155 = load i32, ptr %l82, !tbaa !23
  %t158 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t153, { i64, [2 x i64] } %t154, i32 %t155, i64 %t151, %"compiler/source:Span" %t152)
  store i64 %t158, ptr %l85
  br label %bb30
bb30:
  %t159 = load i64, ptr %l85, !tbaa !24
  store i64 %t159, ptr %l4, !tbaa !24
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/check:Checker", ptr %t160, i32 0, i32 27
  %t163 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l3
  %t164 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %t162, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t163, i64 %t164)
  br label %bb31
bb31:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeck(ptr %v0, ptr %t168, i64 %t169)
  br label %bb32
bb32:
  %t172 = load i64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t172, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i64
  %l10 = alloca i64
  %l16 = alloca ptr
  %l19 = alloca i1
  %l25 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca { i64, ptr }
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l7, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 12
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l10
  br label %bb3
bb3:
  %t11 = load i64, ptr %l7, !tbaa !24
  %t12 = load i64, ptr %l10, !tbaa !24
  %t13 = icmp sge i64 %t11, %t12
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l6, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 12
  %t20 = load i64, ptr %l1, !tbaa !24
  %t23 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t19, i64 %t20)
  store ptr %t23, ptr %l16
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l16, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Body", ptr %t24, i32 0, i32 1
  %t27 = load { i64, [2 x i64] }, ptr %t26
  store { i64, [2 x i64] } %t27, ptr %l2
  %t29 = load { i64, [2 x i64] }, ptr %l2
  %t31 = extractvalue { i64, [2 x i64] } %t29, 0
  %t32 = icmp eq i64 %t31, 0
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t34 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t35 = getelementptr { i64 }, ptr %t34, i32 0, i32 0
  %t36 = load i64, ptr %t35
  store i64 %t36, ptr %l3, !tbaa !24
  br label %bb11
bb10:
  br label %bb14
bb11:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 2
  store ptr %t43, ptr %l25, !tbaa !29
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t48 = load i64, ptr %l3, !tbaa !24
  %t51 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t47, i64 %t48)
  store i32 %t51, ptr %l29
  br label %bb12
bb12:
  %t52 = load ptr, ptr %l25, !tbaa !29
  %t53 = load i32, ptr %l29, !tbaa !23
  %t54 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t52, i32 %t53)
  store { i64, ptr } %t54, ptr %l30
  br label %bb13
bb13:
  %t55 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 0
  %t58 = icmp sgt i64 %t56, 0
  store i1 %t58, ptr %l19, !tbaa !21
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_9109cadfb541186e_2a46ab96c2b41f0a)
  unreachable
bb19:
  %t60 = load i1, ptr %l19, !tbaa !21
  store i1 %t60, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l4, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t7, i32 %a1)
  store i32 %t11, ptr %l7
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l4, !tbaa !29
  %t13 = load i32, ptr %l7, !tbaa !23
  %t14 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t14, ptr %l8
  br label %bb2
bb2:
  %t15 = load i1, ptr %l8, !tbaa !21
  store i1 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ejoinStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, i64, i64 }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l25 = alloca i32
  %l26 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i64
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca ptr
  %l48 = alloca i64
  %l49 = alloca i64
  %l51 = alloca ptr
  %l59 = alloca ptr
  %l62 = alloca i64
  %l65 = alloca i64
  %l69 = alloca { i64, i64, i64 }
  %l85 = alloca { i64, ptr }
  %l98 = alloca ptr
  %l100 = alloca ptr
  %l102 = alloca ptr
  %l105 = alloca i64
  %l107 = alloca i64
  %l109 = alloca ptr
  %l112 = alloca i64
  %l114 = alloca i64
  %l115 = alloca i64
  %l118 = alloca i64
  %l119 = alloca i32
  %l120 = alloca i64
  %l123 = alloca i64
  %l124 = alloca i32
  %l127 = alloca ptr
  %l128 = alloca %"compiler/source:Span"
  %l129 = alloca %"compiler/msgs:Msg"
  %l130 = alloca i64
  %l131 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l135 = alloca i64
  %l139 = alloca i64
  %l142 = alloca i64
  %l163 = alloca i32
  %l165 = alloca i64
  %l167 = alloca i64
  %l172 = alloca i32
  %l187 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l193 = alloca i1
  %l198 = alloca i64
  %l200 = alloca ptr
  %l203 = alloca { i64, ptr }
  %l205 = alloca %"compiler/source:Span"
  %l206 = alloca %"compiler/msgs:Msg"
  %l207 = alloca i64
  %l211 = alloca i64
  %l213 = alloca i1
  %l218 = alloca ptr
  %l219 = alloca %"compiler/source:Span"
  %l220 = alloca %"compiler/msgs:Msg"
  %l221 = alloca i64
  %l224 = alloca i64
  %l226 = alloca i64
  %l228 = alloca i64
  %l233 = alloca i32
  %l241 = alloca i64
  %l254 = alloca { i64, ptr }
  %l263 = alloca { i64, ptr }
  %l266 = alloca ptr
  %l272 = alloca ptr
  %l280 = alloca i64
  %l284 = alloca i64
  %l287 = alloca i64
  %l308 = alloca ptr
  %l312 = alloca i1
  %l316 = alloca ptr
  %l322 = alloca i1
  %l324 = alloca ptr
  %l327 = alloca { i64, ptr }
  %l330 = alloca %"compiler/source:Span"
  %l331 = alloca %"compiler/msgs:Msg"
  %l332 = alloca i64
  %l339 = alloca i64
  %l340 = alloca i64
  %l343 = alloca { i64, ptr }
  %l344 = alloca i64
  %l345 = alloca i32
  %l346 = alloca ptr
  %l356 = alloca %"compiler/source:Span"
  %l360 = alloca i64
  %l362 = alloca ptr
  %l363 = alloca %"compiler/source:Span"
  %l364 = alloca ptr
  %l366 = alloca i32
  %l367 = alloca { i64, ptr }
  %l369 = alloca %"compiler/msgs:Msg"
  %l370 = alloca i64
  %l373 = alloca ptr
  %l374 = alloca %"compiler/source:Span"
  %l375 = alloca ptr
  %l377 = alloca i1
  %l379 = alloca { i64, ptr }
  %l380 = alloca %"compiler/typed:Join"
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %t674 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l51
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l51, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 31
  %t8 = load i64, ptr %t7, !tbaa !24
  store i64 %t8, ptr %l4, !tbaa !24
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t12 = getelementptr %"compiler/check:frame", ptr %t10, i32 0, i32 39
  %t13 = load i64, ptr %t12, !tbaa !24
  store i64 %t13, ptr %l5, !tbaa !24
  %t15 = load ptr, ptr %l3, !tbaa !29
  %t17 = getelementptr %"compiler/check:frame", ptr %t15, i32 0, i32 36
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t17, i64 0)
  br label %bb2
bb2:
  %t19 = load ptr, ptr %l3, !tbaa !29
  %t21 = getelementptr %"compiler/check:frame", ptr %t19, i32 0, i32 37
  store ptr %t21, ptr %l59, !tbaa !29
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t24 = getelementptr %"compiler/check:frame", ptr %t22, i32 0, i32 38
  %t26 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t24)
  store i64 %t26, ptr %l62
  br label %bb3
bb3:
  %t27 = load ptr, ptr %l59, !tbaa !29
  %t28 = load i64, ptr %l62, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t27, i64 %t28)
  br label %bb4
bb4:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 37
  %t33 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t31)
  store i64 %t33, ptr %l65
  br label %bb5
bb5:
  %t34 = load i64, ptr %l65, !tbaa !24
  store i64 %t34, ptr %l6, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load %"compiler/source:Span", ptr %l1
  %t40 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t35, i32 5, %"compiler/source:Span" %t36)
  store { i64, i64, i64 } %t40, ptr %l69
  br label %bb6
bb6:
  %t41 = load { i64, i64, i64 }, ptr %l69
  store { i64, i64, i64 } %t41, ptr %l7
  %t42 = getelementptr { i64, i64, i64 }, ptr %l7, i32 0, i32 0
  %t43 = load i64, ptr %t42, !tbaa !24
  store i64 %t43, ptr %l8, !tbaa !24
  %t45 = getelementptr { i64, i64, i64 }, ptr %l7, i32 0, i32 1
  %t46 = load i64, ptr %t45, !tbaa !24
  store i64 %t46, ptr %l9, !tbaa !24
  %t48 = getelementptr { i64, i64, i64 }, ptr %l7, i32 0, i32 2
  %t49 = load i64, ptr %t48, !tbaa !24
  store i64 %t49, ptr %l10, !tbaa !24
  %t51 = load ptr, ptr %l2, !tbaa !29
  %t53 = getelementptr %"compiler/ast:JoinS", ptr %t51, i32 0, i32 1
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t58 = icmp sgt i64 %t56, 0
  br i1 %t58, label %bb7, label %bb8
bb7:
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t62 = getelementptr %"compiler/ast:JoinS", ptr %t60, i32 0, i32 1
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  store { i64, ptr } %t63, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t65, 0
  store i64 %t67, ptr %l13, !tbaa !24
  br label %bb9
bb8:
  br label %bb16
bb9:
  %t69 = load i64, ptr %l12, !tbaa !24
  %t70 = load i64, ptr %l13, !tbaa !24
  %t73 = icmp slt i64 %t69, %t70
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb10, label %bb11
bb10:
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t77 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t77, ptr %l85, !tbaa !27
  %t78 = load i64, ptr %l12, !tbaa !24
  %t80 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr ptr, ptr %t81, i64 %t78
  %t83 = load ptr, ptr %t82, !tbaa !39
  %t85 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %t85, ptr %t83)
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t90 = load i64, ptr %l12, !tbaa !24
  %t92 = add i64 %t90, 1
  store i64 %t92, ptr %l12, !tbaa !24
  br label %bb9
bb15:
  br label %bb16
bb16:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load i64, ptr %l8, !tbaa !24
  %t96 = load i64, ptr %l9, !tbaa !24
  %t97 = load i64, ptr %l10, !tbaa !24
  %t98 = load i64, ptr %l6, !tbaa !24
  %t104 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t94, i64 %t95, i64 %t96, i64 %t97, i64 %t98)
  store ptr %t104, ptr %l98
  br label %bb17
bb17:
  %t105 = load ptr, ptr %l98, !tbaa !29
  store ptr %t105, ptr %l15, !tbaa !29
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t106)
  store ptr %t108, ptr %l100
  br label %bb18
bb18:
  %t109 = load ptr, ptr %l100, !tbaa !29
  store ptr %t109, ptr %l3, !tbaa !29
  %t110 = load ptr, ptr %l3, !tbaa !29
  %t112 = getelementptr %"compiler/check:frame", ptr %t110, i32 0, i32 36
  store ptr %t112, ptr %l102, !tbaa !29
  %t113 = load ptr, ptr %l3, !tbaa !29
  %t115 = getelementptr %"compiler/check:frame", ptr %t113, i32 0, i32 36
  %t117 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t115)
  store i64 %t117, ptr %l105
  br label %bb19
bb19:
  %t118 = load i64, ptr %l105, !tbaa !24
  %t119 = sub i64 %t118, 1
  %t120 = load ptr, ptr %l102, !tbaa !29
  %t122 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t120, i64 %t119)
  store i64 %t122, ptr %l107
  br label %bb20
bb20:
  %t123 = load i64, ptr %l107, !tbaa !24
  store i64 %t123, ptr %l16, !tbaa !24
  %t124 = load ptr, ptr %l3, !tbaa !29
  %t126 = getelementptr %"compiler/check:frame", ptr %t124, i32 0, i32 37
  store ptr %t126, ptr %l109, !tbaa !29
  %t127 = load ptr, ptr %l3, !tbaa !29
  %t129 = getelementptr %"compiler/check:frame", ptr %t127, i32 0, i32 37
  %t131 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t129)
  store i64 %t131, ptr %l112
  br label %bb21
bb21:
  %t132 = load i64, ptr %l112, !tbaa !24
  %t133 = sub i64 %t132, 1
  %t134 = load ptr, ptr %l109, !tbaa !29
  %t136 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t134, i64 %t133)
  store i64 %t136, ptr %l114
  br label %bb22
bb22:
  %t137 = load i64, ptr %l114, !tbaa !24
  store i64 %t137, ptr %l17, !tbaa !24
  %t138 = load ptr, ptr %l3, !tbaa !29
  %t140 = getelementptr %"compiler/check:frame", ptr %t138, i32 0, i32 36
  %t142 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t140)
  %t143 = extractvalue { i32, i64 } %t142, 1
  %t144 = extractvalue { i32, i64 } %t142, 0
  store i32 %t144, ptr %l119
  %t145 = icmp ne i32 %t144, 0
  br i1 %t145, label %bb24, label %ok.146, !prof !99
ok.146:
  store i64 %t143, ptr %l118
  br label %bb23
bb23:
  %t147 = load i64, ptr %l118, !tbaa !24
  store i64 %t147, ptr %l115, !tbaa !24
  br label %bb26
bb24:
  br label %bb25
bb25:
  call void @__olang_ert_req_clear()
  br label %bb26
bb26:
  %t148 = load ptr, ptr %l3, !tbaa !29
  %t150 = getelementptr %"compiler/check:frame", ptr %t148, i32 0, i32 37
  %t152 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t150)
  %t153 = extractvalue { i32, i64 } %t152, 1
  %t154 = extractvalue { i32, i64 } %t152, 0
  store i32 %t154, ptr %l124
  %t155 = icmp ne i32 %t154, 0
  br i1 %t155, label %bb28, label %ok.156, !prof !99
ok.156:
  store i64 %t153, ptr %l123
  br label %bb27
bb27:
  %t157 = load i64, ptr %l123, !tbaa !24
  store i64 %t157, ptr %l120, !tbaa !24
  br label %bb30
bb28:
  br label %bb29
bb29:
  call void @__olang_ert_req_clear()
  br label %bb30
bb30:
  %t158 = load i64, ptr %l16, !tbaa !24
  %t160 = icmp eq i64 %t158, 0
  br i1 %t160, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s7
  %t162 = load ptr, ptr %l0, !tbaa !29
  store ptr %t162, ptr %l127, !tbaa !29
  %t163 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t163, ptr %l128
  %t164 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinWithoutSpawn(ptr %s7)
  store %"compiler/msgs:Msg" %t164, ptr %l129
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t165 = load ptr, ptr %l127, !tbaa !29
  %t166 = load %"compiler/source:Span", ptr %l128
  %t167 = load %"compiler/msgs:Msg", ptr %l129
  %t168 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t165, %"compiler/source:Span" %t166, %"compiler/msgs:Msg" %t167)
  store i64 %t168, ptr %l130
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s7)
  br label %bb35
bb35:
  %t169 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t169, ptr %l131
  br label %bb36
bb36:
  %t170 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l131
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t170, ptr %l18
  %t171 = load i64, ptr %l17, !tbaa !24
  store i64 %t171, ptr %l19, !tbaa !24
  %t173 = load ptr, ptr %l3, !tbaa !29
  %t175 = getelementptr %"compiler/check:frame", ptr %t173, i32 0, i32 38
  %t177 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t175)
  store i64 %t177, ptr %l135
  br label %bb37
bb37:
  %t178 = load i64, ptr %l135, !tbaa !24
  store i64 %t178, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t179 = load i64, ptr %l20, !tbaa !24
  %t180 = load i64, ptr %l19, !tbaa !24
  %t183 = icmp sgt i64 %t179, %t180
  br i1 %t183, label %bb38, label %bb39
bb38:
  %t185 = load i64, ptr %l21, !tbaa !24
  %t187 = icmp sgt i64 %t185, 0
  br i1 %t187, label %bb40, label %bb41
bb39:
  store i64 0, ptr %l139, !tbaa !24
  br label %bb43
bb40:
  %t189 = load i64, ptr %l20, !tbaa !24
  %t190 = load i64, ptr %l19, !tbaa !24
  %t193 = sub i64 %t189, %t190
  %t194 = load i64, ptr %l21, !tbaa !24
  %t197 = add i64 %t193, %t194
  %t199 = sub i64 %t197, 1
  %t200 = load i64, ptr %l21, !tbaa !24
  %t203 = sdiv i64 %t199, %t200
  store i64 %t203, ptr %l142, !tbaa !24
  br label %bb42
bb41:
  store i64 0, ptr %l142, !tbaa !24
  br label %bb42
bb42:
  %t205 = load i64, ptr %l142, !tbaa !24
  store i64 %t205, ptr %l139, !tbaa !24
  br label %bb43
bb43:
  %t206 = load i64, ptr %l139, !tbaa !24
  store i64 %t206, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb44
bb44:
  %t207 = load i64, ptr %l23, !tbaa !24
  %t208 = load i64, ptr %l22, !tbaa !24
  %t211 = icmp slt i64 %t207, %t208
  %t213 = xor i1 %t211, true
  br i1 %t213, label %bb45, label %bb46
bb45:
  br label %bb65
bb46:
  br label %bb47
bb47:
  %t215 = load i64, ptr %l19, !tbaa !24
  %t216 = load i64, ptr %l23, !tbaa !24
  %t217 = load i64, ptr %l21, !tbaa !24
  %t220 = mul i64 %t216, %t217
  %t223 = add i64 %t215, %t220
  %t225 = load ptr, ptr %l3, !tbaa !29
  %t227 = getelementptr %"compiler/check:frame", ptr %t225, i32 0, i32 38
  %t231 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t227, i64 %t223)
  store i32 %t231, ptr %l163
  br label %bb48
bb48:
  %t232 = load i32, ptr %l163, !tbaa !23
  store i32 %t232, ptr %l25, !tbaa !23
  store i1 false, ptr %l26, !tbaa !21
  store ptr %l18, ptr %l27, !tbaa !29
  store i64 0, ptr %l28, !tbaa !24
  br label %bb49
bb49:
  %t234 = load i64, ptr %l28, !tbaa !24
  store i64 %t234, ptr %l165, !tbaa !24
  %t235 = load ptr, ptr %l27, !tbaa !29
  %t237 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t235)
  store i64 %t237, ptr %l167
  br label %bb50
bb50:
  %t238 = load i64, ptr %l165, !tbaa !24
  %t239 = load i64, ptr %l167, !tbaa !24
  %t240 = icmp slt i64 %t238, %t239
  %t242 = xor i1 %t240, true
  br i1 %t242, label %bb51, label %bb52
bb51:
  br label %bb59
bb52:
  br label %bb53
bb53:
  %t244 = load ptr, ptr %l27, !tbaa !29
  %t245 = load i64, ptr %l28, !tbaa !24
  %t248 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t244, i64 %t245)
  store i32 %t248, ptr %l172
  br label %bb54
bb54:
  %t249 = load i32, ptr %l172, !tbaa !23
  %t251 = load i32, ptr %l25, !tbaa !23
  %t254 = icmp eq i32 %t249, %t251
  br i1 %t254, label %bb55, label %bb56
bb55:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb57
bb56:
  br label %bb57
bb57:
  br label %bb58
bb58:
  %t256 = load i64, ptr %l28, !tbaa !24
  %t258 = add i64 %t256, 1
  store i64 %t258, ptr %l28, !tbaa !24
  br label %bb49
bb59:
  %t260 = load i1, ptr %l26, !tbaa !21
  %t262 = xor i1 %t260, true
  br i1 %t262, label %bb60, label %bb61
bb60:
  %t264 = load i32, ptr %l25, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l18, i32 %t264)
  br label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb63
bb63:
  br label %bb64
bb64:
  %t267 = load i64, ptr %l23, !tbaa !24
  %t269 = add i64 %t267, 1
  store i64 %t269, ptr %l23, !tbaa !24
  br label %bb44
bb65:
  %t271 = load ptr, ptr %l3, !tbaa !29
  %t273 = getelementptr %"compiler/check:frame", ptr %t271, i32 0, i32 38
  %t274 = load i64, ptr %l17, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t273, i64 %t274)
  br label %bb66
bb66:
  %t277 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t277, ptr %l187
  br label %bb67
bb67:
  %t278 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l187
  %t279 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t278, ptr %t279
  store ptr %t279, ptr %l30, !tbaa !29
  %t281 = load ptr, ptr %l2, !tbaa !29
  %t283 = getelementptr %"compiler/ast:JoinS", ptr %t281, i32 0, i32 2
  %t284 = load { i64, ptr }, ptr %t283, !tbaa !27
  %t286 = extractvalue { i64, ptr } %t284, 0
  %t288 = icmp sgt i64 %t286, 0
  br i1 %t288, label %bb68, label %bb69
bb68:
  %t290 = load ptr, ptr %l2, !tbaa !29
  %t292 = getelementptr %"compiler/ast:JoinS", ptr %t290, i32 0, i32 0
  %t293 = load i1, ptr %t292, !tbaa !21
  %t295 = xor i1 %t293, true
  store i1 %t295, ptr %l193, !tbaa !21
  br label %bb70
bb69:
  store i1 false, ptr %l193, !tbaa !21
  br label %bb70
bb70:
  %t297 = load i1, ptr %l193, !tbaa !21
  br i1 %t297, label %bb71, label %bb72
bb71:
  %t299 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l18)
  store i64 %t299, ptr %l198
  br label %bb73
bb72:
  br label %bb80
bb73:
  %t300 = load i64, ptr %l198, !tbaa !24
  %t301 = icmp eq i64 %t300, 0
  br i1 %t301, label %bb74, label %bb75
bb74:
  store %olang.scope zeroinitializer, ptr %s17
  %t303 = load ptr, ptr %l0, !tbaa !29
  store ptr %t303, ptr %l200, !tbaa !29
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t305 = load ptr, ptr %l2, !tbaa !29
  %t307 = getelementptr %"compiler/ast:JoinS", ptr %t305, i32 0, i32 2
  %t308 = load { i64, ptr }, ptr %t307, !tbaa !27
  store { i64, ptr } %t308, ptr %l203, !tbaa !27
  %t309 = getelementptr { i64, ptr }, ptr %l203, i32 0, i32 1
  %t310 = load ptr, ptr %t309, !tbaa !27
  %t311 = getelementptr ptr, ptr %t310, i64 0
  %t312 = load ptr, ptr %t311, !tbaa !39
  %t315 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %t304, ptr %t312)
  store %"compiler/source:Span" %t315, ptr %l205
  br label %bb76
bb75:
  br label %bb79
bb76:
  %t316 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinCatchNeedsTry(ptr %s17)
  store %"compiler/msgs:Msg" %t316, ptr %l206
  br label %bb77
bb77:
  %t317 = load ptr, ptr %l200, !tbaa !29
  %t318 = load %"compiler/source:Span", ptr %l205
  %t319 = load %"compiler/msgs:Msg", ptr %l206
  %t320 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s17, ptr %t317, %"compiler/source:Span" %t318, %"compiler/msgs:Msg" %t319)
  store i64 %t320, ptr %l207
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s17)
  br label %bb79
bb79:
  br label %bb80
bb80:
  %t321 = load ptr, ptr %l2, !tbaa !29
  %t323 = getelementptr %"compiler/ast:JoinS", ptr %t321, i32 0, i32 0
  %t324 = load i1, ptr %t323, !tbaa !21
  br i1 %t324, label %bb81, label %bb82
bb81:
  store %olang.scope zeroinitializer, ptr %s18
  %t327 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l18)
  store i64 %t327, ptr %l211
  br label %bb83
bb82:
  %t329 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l18)
  store i64 %t329, ptr %l360
  br label %bb155
bb83:
  %t330 = load i64, ptr %l211, !tbaa !24
  %t331 = icmp eq i64 %t330, 0
  br i1 %t331, label %bb84, label %bb85
bb84:
  %t333 = load ptr, ptr %l3, !tbaa !29
  %t335 = getelementptr %"compiler/check:frame", ptr %t333, i32 0, i32 39
  %t336 = load i64, ptr %t335, !tbaa !24
  %t337 = load i64, ptr %l5, !tbaa !24
  %t340 = icmp eq i64 %t336, %t337
  store i1 %t340, ptr %l213, !tbaa !21
  br label %bb86
bb85:
  store i1 false, ptr %l213, !tbaa !21
  br label %bb86
bb86:
  %t342 = load i1, ptr %l213, !tbaa !21
  br i1 %t342, label %bb87, label %bb88
bb87:
  store %olang.scope zeroinitializer, ptr %s19
  %t343 = load ptr, ptr %l0, !tbaa !29
  store ptr %t343, ptr %l218, !tbaa !29
  %t344 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t344, ptr %l219
  %t345 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinCannotFail(ptr %s19)
  store %"compiler/msgs:Msg" %t345, ptr %l220
  br label %bb89
bb88:
  br label %bb91
bb89:
  %t346 = load ptr, ptr %l218, !tbaa !29
  %t347 = load %"compiler/source:Span", ptr %l219
  %t348 = load %"compiler/msgs:Msg", ptr %l220
  %t349 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s19, ptr %t346, %"compiler/source:Span" %t347, %"compiler/msgs:Msg" %t348)
  store i64 %t349, ptr %l221
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s19)
  br label %bb91
bb91:
  %t350 = load ptr, ptr %l3, !tbaa !29
  %t352 = getelementptr %"compiler/check:frame", ptr %t350, i32 0, i32 26
  %t354 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t352)
  store i64 %t354, ptr %l224
  br label %bb92
bb92:
  %t355 = load i64, ptr %l224, !tbaa !24
  store i64 %t355, ptr %l31, !tbaa !24
  store ptr %l18, ptr %l32, !tbaa !29
  store i64 0, ptr %l33, !tbaa !24
  br label %bb93
bb93:
  %t357 = load i64, ptr %l33, !tbaa !24
  store i64 %t357, ptr %l226, !tbaa !24
  %t358 = load ptr, ptr %l32, !tbaa !29
  %t360 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t358)
  store i64 %t360, ptr %l228
  br label %bb94
bb94:
  %t361 = load i64, ptr %l226, !tbaa !24
  %t362 = load i64, ptr %l228, !tbaa !24
  %t363 = icmp slt i64 %t361, %t362
  %t365 = xor i1 %t363, true
  br i1 %t365, label %bb95, label %bb96
bb95:
  br label %bb101
bb96:
  br label %bb97
bb97:
  %t367 = load ptr, ptr %l32, !tbaa !29
  %t368 = load i64, ptr %l33, !tbaa !24
  %t371 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t367, i64 %t368)
  store i32 %t371, ptr %l233
  br label %bb98
bb98:
  %t372 = load i32, ptr %l233, !tbaa !23
  %t373 = load ptr, ptr %l3, !tbaa !29
  %t375 = getelementptr %"compiler/check:frame", ptr %t373, i32 0, i32 26
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t375, i32 %t372)
  br label %bb99
bb99:
  br label %bb100
bb100:
  %t379 = load i64, ptr %l33, !tbaa !24
  %t381 = add i64 %t379, 1
  store i64 %t381, ptr %l33, !tbaa !24
  br label %bb93
bb101:
  %t383 = load ptr, ptr %l3, !tbaa !29
  %t385 = getelementptr %"compiler/check:frame", ptr %t383, i32 0, i32 26
  %t387 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t385)
  store i64 %t387, ptr %l241
  br label %bb102
bb102:
  %t388 = load i64, ptr %l241, !tbaa !24
  store i64 %t388, ptr %l35, !tbaa !24
  %t389 = load ptr, ptr %l0, !tbaa !29
  %t390 = load ptr, ptr %l2, !tbaa !29
  %t392 = getelementptr %"compiler/ast:JoinS", ptr %t390, i32 0, i32 2
  %t393 = load { i64, ptr }, ptr %t392, !tbaa !27
  %t394 = load i64, ptr %l31, !tbaa !24
  %t395 = load i64, ptr %l35, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eproduced(ptr %v0, ptr %v1, ptr %t389, { i64, ptr } %t393, i64 %t394, i64 %t395)
  br label %bb103
bb103:
  %t400 = load ptr, ptr %l2, !tbaa !29
  %t402 = getelementptr %"compiler/ast:JoinS", ptr %t400, i32 0, i32 2
  %t403 = load { i64, ptr }, ptr %t402, !tbaa !27
  %t405 = extractvalue { i64, ptr } %t403, 0
  %t407 = icmp sgt i64 %t405, 0
  br i1 %t407, label %bb104, label %bb105
bb104:
  store %olang.scope zeroinitializer, ptr %s23
  %t409 = load ptr, ptr %l0, !tbaa !29
  %t410 = load i64, ptr %l31, !tbaa !24
  %t411 = load i64, ptr %l35, !tbaa !24
  %t415 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaksBetween(ptr %v0, ptr %s23, ptr %t409, i64 %t410, i64 %t411)
  store { i64, ptr } %t415, ptr %l254
  br label %bb106
bb105:
  br label %bb146
bb106:
  %t416 = load { i64, ptr }, ptr %l254, !tbaa !27
  store { i64, ptr } %t416, ptr %l36, !tbaa !27
  %t417 = load ptr, ptr %l2, !tbaa !29
  %t419 = getelementptr %"compiler/ast:JoinS", ptr %t417, i32 0, i32 2
  %t420 = load { i64, ptr }, ptr %t419, !tbaa !27
  store { i64, ptr } %t420, ptr %l37, !tbaa !27
  store i64 0, ptr %l38, !tbaa !24
  %t422 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t424 = extractvalue { i64, ptr } %t422, 0
  store i64 %t424, ptr %l39, !tbaa !24
  br label %bb107
bb107:
  %t426 = load i64, ptr %l38, !tbaa !24
  %t427 = load i64, ptr %l39, !tbaa !24
  %t430 = icmp slt i64 %t426, %t427
  %t432 = xor i1 %t430, true
  br i1 %t432, label %bb108, label %bb109
bb108:
  br label %bb114
bb109:
  br label %bb110
bb110:
  %t434 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t434, ptr %l263, !tbaa !27
  %t435 = load i64, ptr %l38, !tbaa !24
  %t437 = getelementptr { i64, ptr }, ptr %l263, i32 0, i32 1
  %t438 = load ptr, ptr %t437, !tbaa !27
  %t439 = getelementptr ptr, ptr %t438, i64 %t435
  %t440 = load ptr, ptr %t439, !tbaa !39
  %t442 = load ptr, ptr %l30, !tbaa !29
  store ptr %t442, ptr %l266, !tbaa !29
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t445 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t446 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t447 = load ptr, ptr %l30, !tbaa !29
  %t453 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclause(ptr %v0, ptr %v1, ptr %s23, ptr %v0, ptr %t443, ptr %t440, i32 %t445, i1 false, { i64, ptr } %t446, ptr %t447)
  store ptr %t453, ptr %l272
  br label %bb111
bb111:
  %t454 = load ptr, ptr %l266, !tbaa !29
  %t455 = load ptr, ptr %l272, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ePush_Hc64f4d0e64077a33423ff9c4e583894f(ptr %v0, ptr %v0, ptr %t454, ptr %t455)
  br label %bb112
bb112:
  br label %bb113
bb113:
  %t456 = load i64, ptr %l38, !tbaa !24
  %t458 = add i64 %t456, 1
  store i64 %t458, ptr %l38, !tbaa !24
  br label %bb107
bb114:
  %t460 = load ptr, ptr %l3, !tbaa !29
  %t462 = getelementptr %"compiler/check:frame", ptr %t460, i32 0, i32 31
  %t463 = load i64, ptr %t462, !tbaa !24
  %t464 = load i64, ptr %l4, !tbaa !24
  %t467 = icmp sgt i64 %t463, %t464
  br i1 %t467, label %bb115, label %bb116
bb115:
  store i64 0, ptr %l41, !tbaa !24
  %t469 = load ptr, ptr %l30, !tbaa !29
  %t471 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eLen__H4e51b5ca7b68af485b8486164a690a5f(ptr %v0, ptr %t469)
  store i64 %t471, ptr %l280
  br label %bb117
bb116:
  br label %bb145
bb117:
  %t472 = load i64, ptr %l280, !tbaa !24
  store i64 %t472, ptr %l42, !tbaa !24
  store i64 1, ptr %l43, !tbaa !24
  %t473 = load i64, ptr %l42, !tbaa !24
  %t474 = load i64, ptr %l41, !tbaa !24
  %t477 = icmp sgt i64 %t473, %t474
  br i1 %t477, label %bb118, label %bb119
bb118:
  %t479 = load i64, ptr %l43, !tbaa !24
  %t481 = icmp sgt i64 %t479, 0
  br i1 %t481, label %bb120, label %bb121
bb119:
  store i64 0, ptr %l284, !tbaa !24
  br label %bb123
bb120:
  %t483 = load i64, ptr %l42, !tbaa !24
  %t484 = load i64, ptr %l41, !tbaa !24
  %t487 = sub i64 %t483, %t484
  %t488 = load i64, ptr %l43, !tbaa !24
  %t491 = add i64 %t487, %t488
  %t493 = sub i64 %t491, 1
  %t494 = load i64, ptr %l43, !tbaa !24
  %t497 = sdiv i64 %t493, %t494
  store i64 %t497, ptr %l287, !tbaa !24
  br label %bb122
bb121:
  store i64 0, ptr %l287, !tbaa !24
  br label %bb122
bb122:
  %t499 = load i64, ptr %l287, !tbaa !24
  store i64 %t499, ptr %l284, !tbaa !24
  br label %bb123
bb123:
  %t500 = load i64, ptr %l284, !tbaa !24
  store i64 %t500, ptr %l44, !tbaa !24
  store i64 0, ptr %l45, !tbaa !24
  br label %bb124
bb124:
  %t501 = load i64, ptr %l45, !tbaa !24
  %t502 = load i64, ptr %l44, !tbaa !24
  %t505 = icmp slt i64 %t501, %t502
  %t507 = xor i1 %t505, true
  br i1 %t507, label %bb125, label %bb126
bb125:
  br label %bb144
bb126:
  br label %bb127
bb127:
  %t509 = load i64, ptr %l41, !tbaa !24
  %t510 = load i64, ptr %l45, !tbaa !24
  %t511 = load i64, ptr %l43, !tbaa !24
  %t514 = mul i64 %t510, %t511
  %t517 = add i64 %t509, %t514
  store i64 %t517, ptr %l46, !tbaa !24
  %t519 = load ptr, ptr %l30, !tbaa !29
  %t521 = load i64, ptr %l46, !tbaa !24
  %t524 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eAt_3ccompiler_2ftyped_3aClause_26_3e(ptr %v0, ptr %v0, ptr %t519, i64 %t521)
  store ptr %t524, ptr %l308
  br label %bb128
bb128:
  %t525 = load ptr, ptr %l308, !tbaa !29
  %t527 = getelementptr %"compiler/typed:Clause", ptr %t525, i32 0, i32 3
  %t528 = load ptr, ptr %t527, !tbaa !29
  %t530 = icmp eq ptr %t528, null
  br i1 %t530, label %bb129, label %bb130
bb129:
  store i1 true, ptr %l312, !tbaa !21
  br label %bb136
bb130:
  %t532 = load ptr, ptr %l30, !tbaa !29
  %t534 = load i64, ptr %l46, !tbaa !24
  %t537 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eAt_3ccompiler_2ftyped_3aClause_26_3e(ptr %v0, ptr %v0, ptr %t532, i64 %t534)
  store ptr %t537, ptr %l316
  br label %bb131
bb131:
  %t538 = load ptr, ptr %l316, !tbaa !29
  %t540 = getelementptr %"compiler/typed:Clause", ptr %t538, i32 0, i32 3
  %t541 = load ptr, ptr %t540, !tbaa !29
  store ptr %t541, ptr %l47, !tbaa !29
  %t543 = load ptr, ptr %l47, !tbaa !29
  %t545 = icmp eq ptr %t543, null
  br i1 %t545, label %bb132, label %bb133
bb132:
  call void @__olang_check_failed(ptr @olang_loc_951d796b2ec85af2_4e6ca0fa0a1175d6)
  unreachable
bb133:
  br label %bb134
bb134:
  %t547 = load ptr, ptr %l47, !tbaa !29
  %t549 = call i1 @compiler_2fcheck_2eleavesValue(ptr %v0, ptr %t547)
  store i1 %t549, ptr %l322
  br label %bb135
bb135:
  %t550 = load i1, ptr %l322, !tbaa !21
  %t551 = xor i1 %t550, true
  store i1 %t551, ptr %l312, !tbaa !21
  br label %bb136
bb136:
  %t553 = load i1, ptr %l312, !tbaa !21
  br i1 %t553, label %bb137, label %bb138
bb137:
  store %olang.scope zeroinitializer, ptr %s30
  %t554 = load ptr, ptr %l0, !tbaa !29
  store ptr %t554, ptr %l324, !tbaa !29
  %t555 = load ptr, ptr %l0, !tbaa !29
  %t556 = load ptr, ptr %l2, !tbaa !29
  %t558 = getelementptr %"compiler/ast:JoinS", ptr %t556, i32 0, i32 2
  %t559 = load { i64, ptr }, ptr %t558, !tbaa !27
  store { i64, ptr } %t559, ptr %l327, !tbaa !27
  %t560 = load i64, ptr %l46, !tbaa !24
  %t562 = getelementptr { i64, ptr }, ptr %l327, i32 0, i32 1
  %t563 = load ptr, ptr %t562, !tbaa !27
  %t564 = getelementptr ptr, ptr %t563, i64 %t560
  %t565 = load ptr, ptr %t564, !tbaa !39
  %t568 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %t555, ptr %t565)
  store %"compiler/source:Span" %t568, ptr %l330
  br label %bb139
bb138:
  br label %bb142
bb139:
  %t569 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinClauseMustLeave(ptr %s30)
  store %"compiler/msgs:Msg" %t569, ptr %l331
  br label %bb140
bb140:
  %t570 = load ptr, ptr %l324, !tbaa !29
  %t571 = load %"compiler/source:Span", ptr %l330
  %t572 = load %"compiler/msgs:Msg", ptr %l331
  %t573 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s30, ptr %t570, %"compiler/source:Span" %t571, %"compiler/msgs:Msg" %t572)
  store i64 %t573, ptr %l332
  br label %bb141
bb141:
  call void @__olang_scope_close(ptr %s30)
  br label %bb144
bb142:
  br label %bb143
bb143:
  %t574 = load i64, ptr %l45, !tbaa !24
  %t576 = add i64 %t574, 1
  store i64 %t576, ptr %l45, !tbaa !24
  br label %bb124
bb144:
  br label %bb145
bb145:
  call void @__olang_scope_close(ptr %s23)
  br label %bb146
bb146:
  %t578 = load ptr, ptr %l0, !tbaa !29
  %t579 = load i64, ptr %l31, !tbaa !24
  %t580 = load i64, ptr %l35, !tbaa !24
  %t581 = load ptr, ptr %l30, !tbaa !29
  %t586 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaught(ptr %v0, ptr %v0, ptr %t578, i64 %t579, i64 %t580, ptr %t581)
  store i64 %t586, ptr %l339
  br label %bb147
bb147:
  %t587 = load i64, ptr %l339, !tbaa !24
  store i64 %t587, ptr %l48, !tbaa !24
  %t588 = load ptr, ptr %l0, !tbaa !29
  %t589 = load %"compiler/source:Span", ptr %l1
  %t592 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t588, %"compiler/source:Span" %t589)
  store { i64, ptr } %t592, ptr %l343
  br label %bb148
bb148:
  %t593 = load { i64, ptr }, ptr %l343, !tbaa !27
  %t594 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s18, { i64, ptr } %t593, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d25, i32 0, i32 1) })
  %t595 = extractvalue { i32, i64 } %t594, 1
  %t596 = extractvalue { i32, i64 } %t594, 0
  store i32 %t596, ptr %l345
  %t597 = icmp ne i32 %t596, 0
  br i1 %t597, label %bb150, label %ok.598, !prof !99
ok.598:
  store i64 %t595, ptr %l344
  br label %bb149
bb149:
  %t599 = load i64, ptr %l344, !tbaa !24
  store i64 %t599, ptr %l340, !tbaa !24
  br label %bb152
bb150:
  br label %bb151
bb151:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l340, !tbaa !24
  br label %bb152
bb152:
  %t600 = load i64, ptr %l340, !tbaa !24
  store i64 %t600, ptr %l49, !tbaa !24
  %t601 = load ptr, ptr %l0, !tbaa !29
  store ptr %t601, ptr %l346, !tbaa !29
  %t602 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t603 = load i32, ptr %t602, !tbaa !23
  %t604 = load i64, ptr %l49, !tbaa !24
  %t606 = trunc i64 %t604 to i32
  %t609 = add i32 %t603, %t606
  %t610 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t611 = load i32, ptr %t610, !tbaa !23
  %t612 = load i64, ptr %l49, !tbaa !24
  %t614 = trunc i64 %t612 to i32
  %t617 = add i32 %t611, %t614
  %t619 = add i32 %t617, 4
  %t622 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s18, i32 %t609, i32 %t619)
  store %"compiler/source:Span" %t622, ptr %l356
  br label %bb153
bb153:
  %t623 = load i64, ptr %l31, !tbaa !24
  %t624 = load i64, ptr %l48, !tbaa !24
  %t625 = load ptr, ptr %l346, !tbaa !29
  %t626 = load %"compiler/source:Span", ptr %l356
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eescapes(ptr %v0, ptr %t625, %"compiler/source:Span" %t626, i64 %t623, i64 %t624)
  br label %bb154
bb154:
  call void @__olang_scope_close(ptr %s18)
  br label %bb163
bb155:
  %t629 = load i64, ptr %l360, !tbaa !24
  %t630 = icmp sgt i64 %t629, 0
  br i1 %t630, label %bb156, label %bb157
bb156:
  store %olang.scope zeroinitializer, ptr %s33
  %t632 = load ptr, ptr %l0, !tbaa !29
  store ptr %t632, ptr %l362, !tbaa !29
  %t633 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t633, ptr %l363
  %t634 = load ptr, ptr %l0, !tbaa !29
  store ptr %t634, ptr %l364, !tbaa !29
  %t636 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l18, i64 0)
  store i32 %t636, ptr %l366
  br label %bb158
bb157:
  br label %bb162
bb158:
  %t637 = load ptr, ptr %l364, !tbaa !29
  %t638 = load i32, ptr %l366, !tbaa !23
  %t639 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s33, ptr %t637, i32 %t638)
  store { i64, ptr } %t639, ptr %l367
  br label %bb159
bb159:
  %t640 = load { i64, ptr }, ptr %l367, !tbaa !27
  %t641 = extractvalue { i64, ptr } %t640, 0
  %t642 = extractvalue { i64, ptr } %t640, 1
  %t643 = mul i64 %t641, 1
  %t644 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t643)
  call void @llvm.memcpy.p0.p0.i64(ptr %t644, ptr %t642, i64 %t643, i1 false)
  %t645 = insertvalue { i64, ptr } undef, i64 %t641, 0
  %t646 = insertvalue { i64, ptr } %t645, ptr %t644, 1
  %t648 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinNotTried(ptr %s33, ptr %s33, { i64, ptr } %t646)
  store %"compiler/msgs:Msg" %t648, ptr %l369
  br label %bb160
bb160:
  %t649 = load ptr, ptr %l362, !tbaa !29
  %t650 = load %"compiler/source:Span", ptr %l363
  %t651 = load %"compiler/msgs:Msg", ptr %l369
  %t652 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s33, ptr %t649, %"compiler/source:Span" %t650, %"compiler/msgs:Msg" %t651)
  store i64 %t652, ptr %l370
  br label %bb161
bb161:
  call void @__olang_scope_close(ptr %s33)
  br label %bb162
bb162:
  br label %bb163
bb163:
  %t653 = load ptr, ptr %l3, !tbaa !29
  %t654 = load i64, ptr %l4, !tbaa !24
  %t657 = getelementptr %"compiler/check:frame", ptr %t653, i32 0, i32 31
  store i64 %t654, ptr %t657, !tbaa !24
  %t658 = load ptr, ptr %l0, !tbaa !29
  store ptr %t658, ptr %l373, !tbaa !29
  %t659 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t659, ptr %l374
  %t660 = load ptr, ptr %l15, !tbaa !29
  store ptr %t660, ptr %l375, !tbaa !29
  %t661 = load ptr, ptr %l2, !tbaa !29
  %t663 = getelementptr %"compiler/ast:JoinS", ptr %t661, i32 0, i32 0
  %t664 = load i1, ptr %t663, !tbaa !21
  store i1 %t664, ptr %l377, !tbaa !21
  %t665 = load ptr, ptr %l30, !tbaa !29
  %t667 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eToAr_H1af1cf80015c73411d038ac8256aec52(ptr %v0, ptr %v0, ptr %t665)
  store { i64, ptr } %t667, ptr %l379
  br label %bb164
bb164:
  %t668 = load ptr, ptr %l375, !tbaa !29
  %t669 = load i1, ptr %l377, !tbaa !21
  %t670 = load { i64, ptr }, ptr %l379, !tbaa !27
  %t671 = call %"compiler/typed:Join" @compiler_2ftyped_3aJoin_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t668, i1 %t669, { i64, ptr } %t670)
  store %"compiler/typed:Join" %t671, ptr %l380
  br label %bb165
bb165:
  %t672 = load %"compiler/typed:Join", ptr %l380
  %t673 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/typed:Join" %t672, ptr %t673
  store { i64, [3 x i64] } zeroinitializer, ptr %t674
  %t675 = getelementptr { i64, [3 x i64] }, ptr %t674, i32 0, i32 0
  store i64 13, ptr %t675
  %t676 = load %"compiler/source:Span", ptr %l374
  %t677 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t676, 0
  %t679 = insertvalue { %"compiler/source:Span", ptr } %t677, ptr %t673, 1
  %t680 = getelementptr { i64, [3 x i64] }, ptr %t674, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t679, ptr %t680
  %t681 = load { i64, [3 x i64] }, ptr %t674
  %t683 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t681, ptr %t683
  %t684 = load ptr, ptr %l373, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t684, ptr %t683)
  br label %bb166
bb166:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaves(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca %"compiler/check:laneNode"
  %l7 = alloca %"compiler/check:laneNode"
  %l11 = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 39
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store %"compiler/check:laneNode" %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load %"compiler/check:laneNode", ptr %l7
  store %"compiler/check:laneNode" %t8, ptr %l3
  %t9 = getelementptr %"compiler/check:laneNode", ptr %l3, i32 0, i32 0
  %t10 = load i64, ptr %t9, !tbaa !24
  %t11 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneArr, !tbaa !24
  %t14 = icmp eq i64 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb4
bb3:
  %t16 = getelementptr %"compiler/check:laneNode", ptr %l3, i32 0, i32 0
  %t17 = load i64, ptr %t16, !tbaa !24
  %t18 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneScalar, !tbaa !24
  %t21 = icmp eq i64 %t17, %t18
  store i1 %t21, ptr %l11, !tbaa !21
  br label %bb4
bb4:
  %t23 = load i1, ptr %l11, !tbaa !21
  br i1 %t23, label %bb5, label %bb6
bb5:
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t25 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t24, i64 %t25)
  br label %bb7
bb6:
  br label %bb8
bb7:
  br label %ret
bb8:
  %t28 = getelementptr %"compiler/check:laneNode", ptr %l3, i32 0, i32 4
  %t29 = load i64, ptr %t28, !tbaa !24
  %t31 = icmp sge i64 %t29, 0
  br i1 %t31, label %bb9, label %bb10
bb9:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:laneNode", ptr %l3, i32 0, i32 4
  %t35 = load i64, ptr %t34, !tbaa !24
  %t36 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaves(ptr %v0, ptr %v1, ptr %t33, i64 %t35, ptr %t36)
  br label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t40 = getelementptr %"compiler/check:laneNode", ptr %l3, i32 0, i32 5
  %t41 = load i64, ptr %t40, !tbaa !24
  %t43 = icmp sge i64 %t41, 0
  br i1 %t43, label %bb13, label %bb14
bb13:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:laneNode", ptr %l3, i32 0, i32 5
  %t47 = load i64, ptr %t46, !tbaa !24
  %t48 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaves(ptr %v0, ptr %v1, ptr %t45, i64 %t47, ptr %t48)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  %t52 = getelementptr %"compiler/check:laneNode", ptr %l3, i32 0, i32 6
  %t53 = load i64, ptr %t52, !tbaa !24
  %t55 = icmp sge i64 %t53, 0
  br i1 %t55, label %bb17, label %bb18
bb17:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:laneNode", ptr %l3, i32 0, i32 6
  %t59 = load i64, ptr %t58, !tbaa !24
  %t60 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaves(ptr %v0, ptr %v1, ptr %t57, i64 %t59, ptr %t60)
  br label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb20
bb20:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/check:litv" %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/check:litv"
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l6 = alloca i128
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l10 = alloca %"compiler/source:Span"
  %l13 = alloca i32
  %l18 = alloca i1
  %l20 = alloca i1
  %l22 = alloca ptr
  %l25 = alloca %"compiler/source:Span"
  %l27 = alloca %"compiler/source:Span"
  %l29 = alloca i1
  %l31 = alloca %"compiler/source:Span"
  %l34 = alloca %"compiler/source:Span"
  %l38 = alloca %"compiler/source:Span"
  %l40 = alloca %"compiler/source:Span"
  %l42 = alloca i1
  %l43 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l49 = alloca %"compiler/msgs:Msg"
  %l50 = alloca i64
  %l53 = alloca ptr
  %l58 = alloca i1
  %l61 = alloca i32
  %l65 = alloca i32
  %l67 = alloca i1
  %l70 = alloca i1
  %l71 = alloca i1
  %l74 = alloca i32
  %l78 = alloca i32
  %l80 = alloca i32
  %l85 = alloca i1
  %l88 = alloca i1
  %l91 = alloca i1
  %l94 = alloca %"compiler/source:Span"
  %l96 = alloca %"compiler/source:Span"
  %l98 = alloca i1
  %l100 = alloca ptr
  %l103 = alloca %"compiler/source:Span"
  %l104 = alloca %"compiler/msgs:Msg"
  %l105 = alloca i64
  %l106 = alloca ptr
  %l107 = alloca %"compiler/source:Span"
  %l110 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l113 = alloca %"compiler/msgs:Msg"
  %l114 = alloca i64
  %l117 = alloca ptr
  %l122 = alloca i1
  %l124 = alloca ptr
  %l125 = alloca %"compiler/source:Span"
  %l128 = alloca { i64, ptr }
  %l130 = alloca %"compiler/msgs:Msg"
  %l131 = alloca i64
  %l134 = alloca ptr
  %l137 = alloca i1
  %l138 = alloca ptr
  %l139 = alloca %"compiler/source:Span"
  %l142 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %l144 = alloca { i64, ptr }
  %l147 = alloca { i64, ptr }
  %l149 = alloca %"compiler/msgs:Msg"
  %l150 = alloca i64
  %l153 = alloca ptr
  %l154 = alloca ptr
  %l155 = alloca %"compiler/source:Span"
  %l156 = alloca i32
  %l159 = alloca i64
  %l160 = alloca ptr
  %l165 = alloca i1
  %l166 = alloca i32
  %l168 = alloca double
  %l169 = alloca i1
  %l170 = alloca ptr
  %l171 = alloca %"compiler/source:Span"
  %l174 = alloca { i64, ptr }
  %l175 = alloca { i64, ptr }
  %l176 = alloca { i64, ptr }
  %l179 = alloca { i64, ptr }
  %l181 = alloca %"compiler/msgs:Msg"
  %l182 = alloca i64
  %l185 = alloca ptr
  %l186 = alloca ptr
  %l187 = alloca %"compiler/source:Span"
  %l188 = alloca i32
  %l191 = alloca i64
  %l192 = alloca ptr
  %l198 = alloca i1
  %l202 = alloca %"compiler/source:Span"
  %l204 = alloca %"compiler/source:Span"
  %l206 = alloca i1
  %l208 = alloca ptr
  %l211 = alloca %"compiler/source:Span"
  %l214 = alloca { i64, ptr }
  %l216 = alloca %"compiler/msgs:Msg"
  %l217 = alloca i64
  %l218 = alloca ptr
  %l219 = alloca %"compiler/source:Span"
  %l222 = alloca { i64, ptr }
  %l223 = alloca { i64, ptr }
  %l224 = alloca { i64, ptr }
  %l227 = alloca { i64, ptr }
  %l229 = alloca %"compiler/msgs:Msg"
  %l230 = alloca i64
  %l233 = alloca ptr
  %l236 = alloca i128
  %l240 = alloca ptr
  %l241 = alloca %"compiler/source:Span"
  %l242 = alloca ptr
  %l243 = alloca %"compiler/source:Span"
  %l245 = alloca i32
  %l249 = alloca ptr
  %l251 = alloca ptr
  %l252 = alloca ptr
  %l253 = alloca %"compiler/source:Span"
  %l254 = alloca ptr
  %l255 = alloca %"compiler/source:Span"
  %l259 = alloca i32
  %l262 = alloca ptr
  %l264 = alloca ptr
  %l265 = alloca ptr
  %l266 = alloca %"compiler/source:Span"
  %l267 = alloca i32
  %l268 = alloca i32
  %l269 = alloca ptr
  %l270 = alloca %"compiler/source:Span"
  %l271 = alloca i32
  %l272 = alloca i32
  %l273 = alloca ptr
  %l274 = alloca ptr
  %l275 = alloca %"compiler/source:Span"
  %l277 = alloca i32
  %l278 = alloca ptr
  %l280 = alloca ptr
  %l283 = alloca ptr
  %l285 = alloca i1
  %l290 = alloca i1
  %l292 = alloca ptr
  %l293 = alloca %"compiler/source:Span"
  %l294 = alloca i32
  %l295 = alloca i32
  %l296 = alloca ptr
  %l297 = alloca %"compiler/source:Span"
  %l301 = alloca i32
  %l303 = alloca ptr
  %l304 = alloca ptr
  %l309 = alloca ptr
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/check:litv" %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t1)
  store %"compiler/source:Span" %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t4, ptr %l4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr %l3, !tbaa !23
  %t9 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t5, i32 %t6)
  store i32 %t9, ptr %l13
  br label %bb2
bb2:
  %t10 = load i32, ptr %l13, !tbaa !23
  store i32 %t10, ptr %l5, !tbaa !23
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 2
  %t17 = load i32, ptr %l5, !tbaa !23
  %t20 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t16, i32 %t17)
  store i1 %t20, ptr %l18
  br label %bb3
bb3:
  %t21 = load i1, ptr %l18, !tbaa !21
  %t22 = xor i1 %t21, true
  br i1 %t22, label %bb4, label %bb5
bb4:
  %t24 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 6
  %t25 = load i1, ptr %t24, !tbaa !21
  store i1 %t25, ptr %l20, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l20, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s1
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l22, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t33 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopOf(ptr %v0, ptr %v1, ptr %t29, ptr %t30)
  store %"compiler/source:Span" %t33, ptr %l25
  br label %bb9
bb8:
  br label %bb25
bb9:
  %t34 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t34, ptr %l27
  %t37 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %l25, ptr %l27)
  store i1 %t37, ptr %l29
  br label %bb10
bb10:
  %t38 = load i1, ptr %l29, !tbaa !21
  %t39 = xor i1 %t38, true
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t45 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopOf(ptr %v0, ptr %v1, ptr %t41, ptr %t42)
  store %"compiler/source:Span" %t45, ptr %l34
  br label %bb13
bb12:
  %t46 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t46, ptr %l31
  br label %bb14
bb13:
  %t48 = load %"compiler/source:Span", ptr %l34
  store %"compiler/source:Span" %t48, ptr %l31
  br label %bb14
bb14:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t53 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopOf(ptr %v0, ptr %v1, ptr %t49, ptr %t50)
  store %"compiler/source:Span" %t53, ptr %l38
  br label %bb15
bb15:
  %t54 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t54, ptr %l40
  %t57 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %l38, ptr %l40)
  store i1 %t57, ptr %l42
  br label %bb16
bb16:
  %t58 = load i1, ptr %l42, !tbaa !21
  br i1 %t58, label %bb17, label %bb18
bb17:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load %"compiler/source:Span", ptr %l4
  %t63 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t59, %"compiler/source:Span" %t60)
  store { i64, ptr } %t63, ptr %l46
  br label %bb19
bb18:
  store { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %l43, !tbaa !27
  br label %bb21
bb19:
  %t64 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t65 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %s1, { i64, ptr } %t64)
  store { i64, ptr } %t65, ptr %l47
  br label %bb20
bb20:
  %t66 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  %t68 = extractvalue { i64, ptr } %t66, 1
  %t69 = mul i64 %t67, 1
  %t70 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t69)
  call void @llvm.memcpy.p0.p0.i64(ptr %t70, ptr %t68, i64 %t69, i1 false)
  %t71 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  store { i64, ptr } %t72, ptr %l43, !tbaa !27
  br label %bb21
bb21:
  %t74 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t75 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLiteralNoOwnType(ptr %s1, ptr %s1, { i64, ptr } %t74)
  store %"compiler/msgs:Msg" %t75, ptr %l49
  br label %bb22
bb22:
  %t76 = load ptr, ptr %l22, !tbaa !29
  %t77 = load %"compiler/source:Span", ptr %l31
  %t78 = load %"compiler/msgs:Msg", ptr %l49
  %t79 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t76, %"compiler/source:Span" %t77, %"compiler/msgs:Msg" %t78)
  store i64 %t79, ptr %l50
  br label %bb23
bb23:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load %"compiler/source:Span", ptr %l4
  %t84 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t80, %"compiler/source:Span" %t81)
  store ptr %t84, ptr %l53
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s1)
  %t85 = load ptr, ptr %l53, !tbaa !29
  store ptr %t85, ptr %rv
  br label %ret
bb25:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr %"compiler/generic:Program", ptr %t89, i32 0, i32 2
  %t92 = load i32, ptr %l5, !tbaa !23
  %t95 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t91, i32 %t92)
  store i1 %t95, ptr %l58
  br label %bb26
bb26:
  %t96 = load i1, ptr %l58, !tbaa !21
  %t97 = xor i1 %t96, true
  br i1 %t97, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s2
  %t99 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 1
  %t100 = load i1, ptr %t99, !tbaa !21
  br i1 %t100, label %bb29, label %bb30
bb28:
  br label %bb45
bb29:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/check:Checker", ptr %t102, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = getelementptr %"compiler/generic:Program", ptr %t105, i32 0, i32 2
  %t109 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s2, ptr %t107, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d27, i32 0, i32 1) })
  store i32 %t109, ptr %l65
  br label %bb31
bb30:
  %t110 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 2
  %t111 = load i1, ptr %t110, !tbaa !21
  br i1 %t111, label %bb32, label %bb33
bb31:
  %t113 = load i32, ptr %l65, !tbaa !23
  store i32 %t113, ptr %l61, !tbaa !23
  br label %bb44
bb32:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb38
bb33:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t118 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitU64(ptr %v0, ptr %v1, ptr %t114, ptr %t115)
  store i1 %t118, ptr %l70
  br label %bb34
bb34:
  %t119 = load i1, ptr %l70, !tbaa !21
  br i1 %t119, label %bb35, label %bb36
bb35:
  %t120 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 3
  %t121 = load i64, ptr %t120, !tbaa !24
  %t123 = icmp sge i64 %t121, 0
  store i1 %t123, ptr %l71, !tbaa !21
  br label %bb37
bb36:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb37
bb37:
  %t125 = load i1, ptr %l71, !tbaa !21
  store i1 %t125, ptr %l67, !tbaa !21
  br label %bb38
bb38:
  %t126 = load i1, ptr %l67, !tbaa !21
  br i1 %t126, label %bb39, label %bb40
bb39:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/check:Checker", ptr %t127, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t132 = getelementptr %"compiler/generic:Program", ptr %t130, i32 0, i32 2
  %t134 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s2, ptr %t132, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d28, i32 0, i32 1) })
  store i32 %t134, ptr %l78
  br label %bb41
bb40:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t135)
  store i32 %t137, ptr %l80
  br label %bb42
bb41:
  %t138 = load i32, ptr %l78, !tbaa !23
  store i32 %t138, ptr %l74, !tbaa !23
  br label %bb43
bb42:
  %t139 = load i32, ptr %l80, !tbaa !23
  store i32 %t139, ptr %l74, !tbaa !23
  br label %bb43
bb43:
  %t140 = load i32, ptr %l74, !tbaa !23
  store i32 %t140, ptr %l61, !tbaa !23
  br label %bb44
bb44:
  %t141 = load i32, ptr %l61, !tbaa !23
  store i32 %t141, ptr %l3, !tbaa !23
  %t142 = load i32, ptr %l3, !tbaa !23
  store i32 %t142, ptr %l5, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  br label %bb45
bb45:
  %t144 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 1
  %t145 = load i1, ptr %t144, !tbaa !21
  br i1 %t145, label %bb46, label %bb47
bb46:
  %t147 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 4
  %t148 = load double, ptr %t147, !tbaa !26
  %t150 = fcmp ogt double %t148, 0x7fefffffffffffff
  br i1 %t150, label %bb48, label %bb49
bb47:
  br label %bb91
bb48:
  store i1 true, ptr %l85, !tbaa !21
  br label %bb50
bb49:
  %t152 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 4
  %t153 = load double, ptr %t152, !tbaa !26
  %t155 = fcmp olt double %t153, 0xffefffffffffffff
  store i1 %t155, ptr %l85, !tbaa !21
  br label %bb50
bb50:
  %t157 = load i1, ptr %l85, !tbaa !21
  br i1 %t157, label %bb51, label %bb52
bb51:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load ptr, ptr %l1, !tbaa !29
  %t162 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoverflowsF64(ptr %v0, ptr %v1, ptr %t158, ptr %t159)
  store i1 %t162, ptr %l91
  br label %bb53
bb52:
  store i1 false, ptr %l88, !tbaa !21
  br label %bb54
bb53:
  %t163 = load i1, ptr %l91, !tbaa !21
  store i1 %t163, ptr %l88, !tbaa !21
  br label %bb54
bb54:
  %t164 = load i1, ptr %l88, !tbaa !21
  br i1 %t164, label %bb55, label %bb56
bb55:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load ptr, ptr %l1, !tbaa !29
  %t169 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopOf(ptr %v0, ptr %v1, ptr %t165, ptr %t166)
  store %"compiler/source:Span" %t169, ptr %l94
  br label %bb57
bb56:
  br label %bb70
bb57:
  %t170 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t170, ptr %l96
  %t173 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %l94, ptr %l96)
  store i1 %t173, ptr %l98
  br label %bb58
bb58:
  %t174 = load i1, ptr %l98, !tbaa !21
  %t175 = xor i1 %t174, true
  br i1 %t175, label %bb59, label %bb60
bb59:
  store %olang.scope zeroinitializer, ptr %s5
  %t177 = load ptr, ptr %l0, !tbaa !29
  store ptr %t177, ptr %l100, !tbaa !29
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load ptr, ptr %l1, !tbaa !29
  %t182 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopOf(ptr %v0, ptr %v1, ptr %t178, ptr %t179)
  store %"compiler/source:Span" %t182, ptr %l103
  br label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s6
  %t183 = load ptr, ptr %l0, !tbaa !29
  store ptr %t183, ptr %l106, !tbaa !29
  %t184 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t184, ptr %l107
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load %"compiler/source:Span", ptr %l4
  %t189 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t185, %"compiler/source:Span" %t186)
  store { i64, ptr } %t189, ptr %l110
  br label %bb64
bb61:
  %t190 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLiteralExprRange(ptr %s5, ptr %s5, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t190, ptr %l104
  br label %bb62
bb62:
  %t191 = load ptr, ptr %l100, !tbaa !29
  %t192 = load %"compiler/source:Span", ptr %l103
  %t193 = load %"compiler/msgs:Msg", ptr %l104
  %t194 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t191, %"compiler/source:Span" %t192, %"compiler/msgs:Msg" %t193)
  store i64 %t194, ptr %l105
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s5)
  br label %bb68
bb64:
  %t195 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t196 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %s6, { i64, ptr } %t195)
  store { i64, ptr } %t196, ptr %l111
  br label %bb65
bb65:
  %t197 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t197, 0
  %t199 = extractvalue { i64, ptr } %t197, 1
  %t200 = mul i64 %t198, 1
  %t201 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t200)
  call void @llvm.memcpy.p0.p0.i64(ptr %t201, ptr %t199, i64 %t200, i1 false)
  %t202 = insertvalue { i64, ptr } undef, i64 %t198, 0
  %t203 = insertvalue { i64, ptr } %t202, ptr %t201, 1
  %t205 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eFloatLiteralRange(ptr %s6, ptr %s6, { i64, ptr } %t203)
  store %"compiler/msgs:Msg" %t205, ptr %l113
  br label %bb66
bb66:
  %t206 = load ptr, ptr %l106, !tbaa !29
  %t207 = load %"compiler/source:Span", ptr %l107
  %t208 = load %"compiler/msgs:Msg", ptr %l113
  %t209 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t206, %"compiler/source:Span" %t207, %"compiler/msgs:Msg" %t208)
  store i64 %t209, ptr %l114
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s6)
  br label %bb68
bb68:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t211 = load %"compiler/source:Span", ptr %l4
  %t214 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t210, %"compiler/source:Span" %t211)
  store ptr %t214, ptr %l117
  br label %bb69
bb69:
  %t215 = load ptr, ptr %l117, !tbaa !29
  store ptr %t215, ptr %rv
  br label %ret
bb70:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/check:Checker", ptr %t216, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !29
  %t221 = getelementptr %"compiler/generic:Program", ptr %t219, i32 0, i32 2
  %t222 = load i32, ptr %l5, !tbaa !23
  %t225 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t221, i32 %t222)
  store i1 %t225, ptr %l122
  br label %bb71
bb71:
  %t226 = load i1, ptr %l122, !tbaa !21
  %t227 = xor i1 %t226, true
  br i1 %t227, label %bb72, label %bb73
bb72:
  store %olang.scope zeroinitializer, ptr %s7
  %t229 = load ptr, ptr %l0, !tbaa !29
  store ptr %t229, ptr %l124, !tbaa !29
  %t230 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t230, ptr %l125
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t232 = load i32, ptr %l3, !tbaa !23
  %t235 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s7, ptr %t231, i32 %t232)
  store { i64, ptr } %t235, ptr %l128
  br label %bb74
bb73:
  br label %bb78
bb74:
  %t236 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t237 = extractvalue { i64, ptr } %t236, 0
  %t238 = extractvalue { i64, ptr } %t236, 1
  %t239 = mul i64 %t237, 1
  %t240 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t239)
  call void @llvm.memcpy.p0.p0.i64(ptr %t240, ptr %t238, i64 %t239, i1 false)
  %t241 = insertvalue { i64, ptr } undef, i64 %t237, 0
  %t242 = insertvalue { i64, ptr } %t241, ptr %t240, 1
  %t244 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeMismatch(ptr %s7, ptr %s7, ptr %s7, { i64, ptr } %t242, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t244, ptr %l130
  br label %bb75
bb75:
  %t245 = load ptr, ptr %l124, !tbaa !29
  %t246 = load %"compiler/source:Span", ptr %l125
  %t247 = load %"compiler/msgs:Msg", ptr %l130
  %t248 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t245, %"compiler/source:Span" %t246, %"compiler/msgs:Msg" %t247)
  store i64 %t248, ptr %l131
  br label %bb76
bb76:
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t250 = load %"compiler/source:Span", ptr %l4
  %t253 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t249, %"compiler/source:Span" %t250)
  store ptr %t253, ptr %l134
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s7)
  %t254 = load ptr, ptr %l134, !tbaa !29
  store ptr %t254, ptr %rv
  br label %ret
bb78:
  %t255 = load i32, ptr %l5, !tbaa !23
  %t256 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 4
  %t257 = load double, ptr %t256, !tbaa !26
  %t260 = call i1 @compiler_2fcheck_2efloatOverflows(i32 %t255, double %t257)
  store i1 %t260, ptr %l137
  br label %bb79
bb79:
  %t261 = load i1, ptr %l137, !tbaa !21
  br i1 %t261, label %bb80, label %bb81
bb80:
  store %olang.scope zeroinitializer, ptr %s8
  %t262 = load ptr, ptr %l0, !tbaa !29
  store ptr %t262, ptr %l138, !tbaa !29
  %t263 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t263, ptr %l139
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t265 = load %"compiler/source:Span", ptr %l4
  %t268 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t264, %"compiler/source:Span" %t265)
  store { i64, ptr } %t268, ptr %l142
  br label %bb82
bb81:
  br label %bb88
bb82:
  %t269 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t270 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %s8, { i64, ptr } %t269)
  store { i64, ptr } %t270, ptr %l143
  br label %bb83
bb83:
  %t271 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t272 = extractvalue { i64, ptr } %t271, 0
  %t273 = extractvalue { i64, ptr } %t271, 1
  %t274 = mul i64 %t272, 1
  %t275 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t274)
  call void @llvm.memcpy.p0.p0.i64(ptr %t275, ptr %t273, i64 %t274, i1 false)
  %t276 = insertvalue { i64, ptr } undef, i64 %t272, 0
  %t277 = insertvalue { i64, ptr } %t276, ptr %t275, 1
  store { i64, ptr } %t277, ptr %l144, !tbaa !27
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t279 = load i32, ptr %l3, !tbaa !23
  %t282 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s8, ptr %t278, i32 %t279)
  store { i64, ptr } %t282, ptr %l147
  br label %bb84
bb84:
  %t283 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t284 = extractvalue { i64, ptr } %t283, 0
  %t285 = extractvalue { i64, ptr } %t283, 1
  %t286 = mul i64 %t284, 1
  %t287 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t286)
  call void @llvm.memcpy.p0.p0.i64(ptr %t287, ptr %t285, i64 %t286, i1 false)
  %t288 = insertvalue { i64, ptr } undef, i64 %t284, 0
  %t289 = insertvalue { i64, ptr } %t288, ptr %t287, 1
  %t290 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t292 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLiteralRange(ptr %s8, ptr %s8, ptr %s8, { i64, ptr } %t290, { i64, ptr } %t289)
  store %"compiler/msgs:Msg" %t292, ptr %l149
  br label %bb85
bb85:
  %t293 = load ptr, ptr %l138, !tbaa !29
  %t294 = load %"compiler/source:Span", ptr %l139
  %t295 = load %"compiler/msgs:Msg", ptr %l149
  %t296 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t293, %"compiler/source:Span" %t294, %"compiler/msgs:Msg" %t295)
  store i64 %t296, ptr %l150
  br label %bb86
bb86:
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load %"compiler/source:Span", ptr %l4
  %t301 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t297, %"compiler/source:Span" %t298)
  store ptr %t301, ptr %l153
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s8)
  %t302 = load ptr, ptr %l153, !tbaa !29
  store ptr %t302, ptr %rv
  br label %ret
bb88:
  %t303 = load ptr, ptr %l0, !tbaa !29
  store ptr %t303, ptr %l154, !tbaa !29
  %t304 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t304, ptr %l155
  %t305 = load i32, ptr %l3, !tbaa !23
  store i32 %t305, ptr %l156, !tbaa !23
  %t306 = load i32, ptr %l5, !tbaa !23
  %t307 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 4
  %t308 = load double, ptr %t307, !tbaa !26
  %t311 = call i64 @compiler_2fcheck_2efloatBits(i32 %t306, double %t308)
  store i64 %t311, ptr %l159
  br label %bb89
bb89:
  %t312 = load ptr, ptr %l154, !tbaa !29
  %t313 = load %"compiler/source:Span", ptr %l155
  %t314 = load i32, ptr %l156, !tbaa !23
  %t315 = load i64, ptr %l159, !tbaa !24
  %t316 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t312, %"compiler/source:Span" %t313, i32 %t314, i64 %t315)
  store ptr %t316, ptr %l160
  br label %bb90
bb90:
  %t317 = load ptr, ptr %l160, !tbaa !29
  store ptr %t317, ptr %rv
  br label %ret
bb91:
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t320 = getelementptr %"compiler/check:Checker", ptr %t318, i32 0, i32 1
  %t321 = load ptr, ptr %t320, !tbaa !29
  %t323 = getelementptr %"compiler/generic:Program", ptr %t321, i32 0, i32 2
  %t324 = load i32, ptr %l5, !tbaa !23
  %t327 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t323, i32 %t324)
  store i1 %t327, ptr %l165
  br label %bb92
bb92:
  %t328 = load i1, ptr %l165, !tbaa !21
  br i1 %t328, label %bb93, label %bb94
bb93:
  %t329 = load i32, ptr %l5, !tbaa !23
  store i32 %t329, ptr %l166, !tbaa !23
  %t330 = load %"compiler/check:litv", ptr %l2
  %t332 = call double @compiler_2fcheck_2elitF64(%"compiler/check:litv" %t330)
  store double %t332, ptr %l168
  br label %bb95
bb94:
  br label %bb108
bb95:
  %t333 = load i32, ptr %l166, !tbaa !23
  %t334 = load double, ptr %l168, !tbaa !26
  %t335 = call i1 @compiler_2fcheck_2efloatOverflows(i32 %t333, double %t334)
  store i1 %t335, ptr %l169
  br label %bb96
bb96:
  %t336 = load i1, ptr %l169, !tbaa !21
  br i1 %t336, label %bb97, label %bb98
bb97:
  store %olang.scope zeroinitializer, ptr %s10
  %t337 = load ptr, ptr %l0, !tbaa !29
  store ptr %t337, ptr %l170, !tbaa !29
  %t338 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t338, ptr %l171
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t340 = load %"compiler/source:Span", ptr %l4
  %t343 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t339, %"compiler/source:Span" %t340)
  store { i64, ptr } %t343, ptr %l174
  br label %bb99
bb98:
  br label %bb105
bb99:
  %t344 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t345 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %s10, { i64, ptr } %t344)
  store { i64, ptr } %t345, ptr %l175
  br label %bb100
bb100:
  %t346 = load { i64, ptr }, ptr %l175, !tbaa !27
  %t347 = extractvalue { i64, ptr } %t346, 0
  %t348 = extractvalue { i64, ptr } %t346, 1
  %t349 = mul i64 %t347, 1
  %t350 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t349)
  call void @llvm.memcpy.p0.p0.i64(ptr %t350, ptr %t348, i64 %t349, i1 false)
  %t351 = insertvalue { i64, ptr } undef, i64 %t347, 0
  %t352 = insertvalue { i64, ptr } %t351, ptr %t350, 1
  store { i64, ptr } %t352, ptr %l176, !tbaa !27
  %t353 = load ptr, ptr %l0, !tbaa !29
  %t354 = load i32, ptr %l3, !tbaa !23
  %t357 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s10, ptr %t353, i32 %t354)
  store { i64, ptr } %t357, ptr %l179
  br label %bb101
bb101:
  %t358 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t359 = extractvalue { i64, ptr } %t358, 0
  %t360 = extractvalue { i64, ptr } %t358, 1
  %t361 = mul i64 %t359, 1
  %t362 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t361)
  call void @llvm.memcpy.p0.p0.i64(ptr %t362, ptr %t360, i64 %t361, i1 false)
  %t363 = insertvalue { i64, ptr } undef, i64 %t359, 0
  %t364 = insertvalue { i64, ptr } %t363, ptr %t362, 1
  %t365 = load { i64, ptr }, ptr %l176, !tbaa !27
  %t367 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLiteralRange(ptr %s10, ptr %s10, ptr %s10, { i64, ptr } %t365, { i64, ptr } %t364)
  store %"compiler/msgs:Msg" %t367, ptr %l181
  br label %bb102
bb102:
  %t368 = load ptr, ptr %l170, !tbaa !29
  %t369 = load %"compiler/source:Span", ptr %l171
  %t370 = load %"compiler/msgs:Msg", ptr %l181
  %t371 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s10, ptr %t368, %"compiler/source:Span" %t369, %"compiler/msgs:Msg" %t370)
  store i64 %t371, ptr %l182
  br label %bb103
bb103:
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t373 = load %"compiler/source:Span", ptr %l4
  %t376 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t372, %"compiler/source:Span" %t373)
  store ptr %t376, ptr %l185
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s10)
  %t377 = load ptr, ptr %l185, !tbaa !29
  store ptr %t377, ptr %rv
  br label %ret
bb105:
  %t378 = load ptr, ptr %l0, !tbaa !29
  store ptr %t378, ptr %l186, !tbaa !29
  %t379 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t379, ptr %l187
  %t380 = load i32, ptr %l3, !tbaa !23
  store i32 %t380, ptr %l188, !tbaa !23
  %t381 = load i32, ptr %l5, !tbaa !23
  %t382 = load %"compiler/check:litv", ptr %l2
  %t385 = call i64 @compiler_2fcheck_2eintFloatBits(i32 %t381, %"compiler/check:litv" %t382)
  store i64 %t385, ptr %l191
  br label %bb106
bb106:
  %t386 = load ptr, ptr %l186, !tbaa !29
  %t387 = load %"compiler/source:Span", ptr %l187
  %t388 = load i32, ptr %l188, !tbaa !23
  %t389 = load i64, ptr %l191, !tbaa !24
  %t390 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t386, %"compiler/source:Span" %t387, i32 %t388, i64 %t389)
  store ptr %t390, ptr %l192
  br label %bb107
bb107:
  %t391 = load ptr, ptr %l192, !tbaa !29
  store ptr %t391, ptr %rv
  br label %ret
bb108:
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t394 = getelementptr %"compiler/check:Checker", ptr %t392, i32 0, i32 1
  %t395 = load ptr, ptr %t394, !tbaa !29
  %t397 = getelementptr %"compiler/generic:Program", ptr %t395, i32 0, i32 2
  %t398 = load %"compiler/check:litv", ptr %l2
  %t399 = load i32, ptr %l5, !tbaa !23
  %t403 = call i1 @compiler_2fcheck_2eintFits(ptr %v0, ptr %t397, %"compiler/check:litv" %t398, i32 %t399)
  store i1 %t403, ptr %l198
  br label %bb109
bb109:
  %t404 = load i1, ptr %l198, !tbaa !21
  %t405 = xor i1 %t404, true
  br i1 %t405, label %bb110, label %bb111
bb110:
  %t407 = load ptr, ptr %l0, !tbaa !29
  %t408 = load ptr, ptr %l1, !tbaa !29
  %t411 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopOf(ptr %v0, ptr %v1, ptr %t407, ptr %t408)
  store %"compiler/source:Span" %t411, ptr %l202
  br label %bb112
bb111:
  br label %bb127
bb112:
  %t412 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t412, ptr %l204
  %t415 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %l202, ptr %l204)
  store i1 %t415, ptr %l206
  br label %bb113
bb113:
  %t416 = load i1, ptr %l206, !tbaa !21
  %t417 = xor i1 %t416, true
  br i1 %t417, label %bb114, label %bb115
bb114:
  store %olang.scope zeroinitializer, ptr %s12
  %t419 = load ptr, ptr %l0, !tbaa !29
  store ptr %t419, ptr %l208, !tbaa !29
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t421 = load ptr, ptr %l1, !tbaa !29
  %t424 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopOf(ptr %v0, ptr %v1, ptr %t420, ptr %t421)
  store %"compiler/source:Span" %t424, ptr %l211
  br label %bb116
bb115:
  store %olang.scope zeroinitializer, ptr %s13
  %t425 = load ptr, ptr %l0, !tbaa !29
  store ptr %t425, ptr %l218, !tbaa !29
  %t426 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t426, ptr %l219
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t428 = load %"compiler/source:Span", ptr %l4
  %t431 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t427, %"compiler/source:Span" %t428)
  store { i64, ptr } %t431, ptr %l222
  br label %bb120
bb116:
  %t432 = load ptr, ptr %l0, !tbaa !29
  %t433 = load i32, ptr %l3, !tbaa !23
  %t436 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s12, ptr %t432, i32 %t433)
  store { i64, ptr } %t436, ptr %l214
  br label %bb117
bb117:
  %t437 = load { i64, ptr }, ptr %l214, !tbaa !27
  %t438 = extractvalue { i64, ptr } %t437, 0
  %t439 = extractvalue { i64, ptr } %t437, 1
  %t440 = mul i64 %t438, 1
  %t441 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t440)
  call void @llvm.memcpy.p0.p0.i64(ptr %t441, ptr %t439, i64 %t440, i1 false)
  %t442 = insertvalue { i64, ptr } undef, i64 %t438, 0
  %t443 = insertvalue { i64, ptr } %t442, ptr %t441, 1
  %t445 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLiteralExprRange(ptr %s12, ptr %s12, { i64, ptr } %t443)
  store %"compiler/msgs:Msg" %t445, ptr %l216
  br label %bb118
bb118:
  %t446 = load ptr, ptr %l208, !tbaa !29
  %t447 = load %"compiler/source:Span", ptr %l211
  %t448 = load %"compiler/msgs:Msg", ptr %l216
  %t449 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s12, ptr %t446, %"compiler/source:Span" %t447, %"compiler/msgs:Msg" %t448)
  store i64 %t449, ptr %l217
  br label %bb119
bb119:
  call void @__olang_scope_close(ptr %s12)
  br label %bb125
bb120:
  %t450 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t451 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %s13, { i64, ptr } %t450)
  store { i64, ptr } %t451, ptr %l223
  br label %bb121
bb121:
  %t452 = load { i64, ptr }, ptr %l223, !tbaa !27
  %t453 = extractvalue { i64, ptr } %t452, 0
  %t454 = extractvalue { i64, ptr } %t452, 1
  %t455 = mul i64 %t453, 1
  %t456 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t455)
  call void @llvm.memcpy.p0.p0.i64(ptr %t456, ptr %t454, i64 %t455, i1 false)
  %t457 = insertvalue { i64, ptr } undef, i64 %t453, 0
  %t458 = insertvalue { i64, ptr } %t457, ptr %t456, 1
  store { i64, ptr } %t458, ptr %l224, !tbaa !27
  %t459 = load ptr, ptr %l0, !tbaa !29
  %t460 = load i32, ptr %l3, !tbaa !23
  %t463 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s13, ptr %t459, i32 %t460)
  store { i64, ptr } %t463, ptr %l227
  br label %bb122
bb122:
  %t464 = load { i64, ptr }, ptr %l227, !tbaa !27
  %t465 = extractvalue { i64, ptr } %t464, 0
  %t466 = extractvalue { i64, ptr } %t464, 1
  %t467 = mul i64 %t465, 1
  %t468 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t467)
  call void @llvm.memcpy.p0.p0.i64(ptr %t468, ptr %t466, i64 %t467, i1 false)
  %t469 = insertvalue { i64, ptr } undef, i64 %t465, 0
  %t470 = insertvalue { i64, ptr } %t469, ptr %t468, 1
  %t471 = load { i64, ptr }, ptr %l224, !tbaa !27
  %t473 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLiteralRange(ptr %s13, ptr %s13, ptr %s13, { i64, ptr } %t471, { i64, ptr } %t470)
  store %"compiler/msgs:Msg" %t473, ptr %l229
  br label %bb123
bb123:
  %t474 = load ptr, ptr %l218, !tbaa !29
  %t475 = load %"compiler/source:Span", ptr %l219
  %t476 = load %"compiler/msgs:Msg", ptr %l229
  %t477 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s13, ptr %t474, %"compiler/source:Span" %t475, %"compiler/msgs:Msg" %t476)
  store i64 %t477, ptr %l230
  br label %bb124
bb124:
  call void @__olang_scope_close(ptr %s13)
  br label %bb125
bb125:
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t479 = load %"compiler/source:Span", ptr %l4
  %t482 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t478, %"compiler/source:Span" %t479)
  store ptr %t482, ptr %l233
  br label %bb126
bb126:
  %t483 = load ptr, ptr %l233, !tbaa !29
  store ptr %t483, ptr %rv
  br label %ret
bb127:
  %t484 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 6
  %t485 = load i1, ptr %t484, !tbaa !21
  br i1 %t485, label %bb128, label %bb129
bb128:
  store %olang.scope zeroinitializer, ptr %s14
  %t487 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 7
  %t488 = load i1, ptr %t487, !tbaa !21
  br i1 %t488, label %bb130, label %bb131
bb129:
  br label %bb143
bb130:
  %t490 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 8
  %t491 = load i128, ptr %t490
  %t493 = sub i128 0, %t491
  store i128 %t493, ptr %l236
  br label %bb132
bb131:
  %t495 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 8
  %t496 = load i128, ptr %t495
  store i128 %t496, ptr %l236
  br label %bb132
bb132:
  %t498 = load i128, ptr %l236
  store i128 %t498, ptr %l6
  %t499 = load ptr, ptr %l0, !tbaa !29
  store ptr %t499, ptr %l240, !tbaa !29
  %t500 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t500, ptr %l241
  %t501 = load ptr, ptr %l0, !tbaa !29
  store ptr %t501, ptr %l242, !tbaa !29
  %t502 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t502, ptr %l243
  %t503 = load ptr, ptr %l0, !tbaa !29
  %t505 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t503)
  store i32 %t505, ptr %l245
  br label %bb133
bb133:
  %t506 = load i128, ptr %l6
  %t508 = lshr i128 %t506, 64
  %t510 = trunc i128 %t508 to i64
  %t511 = load ptr, ptr %l242, !tbaa !29
  %t512 = load %"compiler/source:Span", ptr %l243
  %t513 = load i32, ptr %l245, !tbaa !23
  %t515 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t511, %"compiler/source:Span" %t512, i32 %t513, i64 %t510)
  store ptr %t515, ptr %l249
  br label %bb134
bb134:
  %t516 = load i32, ptr %l3, !tbaa !23
  %t517 = load ptr, ptr %l240, !tbaa !29
  %t518 = load %"compiler/source:Span", ptr %l241
  %t519 = load ptr, ptr %l249, !tbaa !29
  %t521 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t517, %"compiler/source:Span" %t518, ptr %t519, i32 %t516)
  store ptr %t521, ptr %l251
  br label %bb135
bb135:
  %t522 = load ptr, ptr %l251, !tbaa !29
  store ptr %t522, ptr %l7, !tbaa !29
  %t523 = load ptr, ptr %l0, !tbaa !29
  store ptr %t523, ptr %l252, !tbaa !29
  %t524 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t524, ptr %l253
  %t525 = load ptr, ptr %l0, !tbaa !29
  store ptr %t525, ptr %l254, !tbaa !29
  %t526 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t526, ptr %l255
  %t527 = load ptr, ptr %l0, !tbaa !29
  %t529 = getelementptr %"compiler/check:Checker", ptr %t527, i32 0, i32 1
  %t530 = load ptr, ptr %t529, !tbaa !29
  %t532 = getelementptr %"compiler/generic:Program", ptr %t530, i32 0, i32 2
  %t534 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s14, ptr %t532, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store i32 %t534, ptr %l259
  br label %bb136
bb136:
  %t535 = load i128, ptr %l6
  %t537 = trunc i128 %t535 to i64
  %t538 = load ptr, ptr %l254, !tbaa !29
  %t539 = load %"compiler/source:Span", ptr %l255
  %t540 = load i32, ptr %l259, !tbaa !23
  %t542 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t538, %"compiler/source:Span" %t539, i32 %t540, i64 %t537)
  store ptr %t542, ptr %l262
  br label %bb137
bb137:
  %t543 = load i32, ptr %l3, !tbaa !23
  %t544 = load ptr, ptr %l252, !tbaa !29
  %t545 = load %"compiler/source:Span", ptr %l253
  %t546 = load ptr, ptr %l262, !tbaa !29
  %t548 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t544, %"compiler/source:Span" %t545, ptr %t546, i32 %t543)
  store ptr %t548, ptr %l264
  br label %bb138
bb138:
  %t549 = load ptr, ptr %l264, !tbaa !29
  store ptr %t549, ptr %l8, !tbaa !29
  %t550 = load ptr, ptr %l0, !tbaa !29
  store ptr %t550, ptr %l265, !tbaa !29
  %t551 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t551, ptr %l266
  %t552 = load i32, ptr %l3, !tbaa !23
  store i32 %t552, ptr %l267, !tbaa !23
  store i32 11, ptr %l268
  %t553 = load ptr, ptr %l0, !tbaa !29
  store ptr %t553, ptr %l269, !tbaa !29
  %t554 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t554, ptr %l270
  %t555 = load i32, ptr %l3, !tbaa !23
  store i32 %t555, ptr %l271, !tbaa !23
  store i32 8, ptr %l272
  %t556 = load ptr, ptr %l7, !tbaa !29
  store ptr %t556, ptr %l273, !tbaa !29
  %t557 = load ptr, ptr %l0, !tbaa !29
  store ptr %t557, ptr %l274, !tbaa !29
  %t558 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t558, ptr %l275
  %t559 = load ptr, ptr %l0, !tbaa !29
  %t561 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t559)
  store i32 %t561, ptr %l277
  br label %bb139
bb139:
  %t562 = load ptr, ptr %l274, !tbaa !29
  %t563 = load %"compiler/source:Span", ptr %l275
  %t564 = load i32, ptr %l277, !tbaa !23
  %t565 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t562, %"compiler/source:Span" %t563, i32 %t564, i64 64)
  store ptr %t565, ptr %l278
  br label %bb140
bb140:
  %t566 = load ptr, ptr %l278, !tbaa !29
  %t567 = load ptr, ptr %l269, !tbaa !29
  %t568 = load %"compiler/source:Span", ptr %l270
  %t569 = load i32, ptr %l271, !tbaa !23
  %t570 = load i32, ptr %l272, !range !{i32 0, i32 43}
  %t571 = load ptr, ptr %l273, !tbaa !29
  %t573 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t567, %"compiler/source:Span" %t568, i32 %t569, i32 %t570, ptr %t571, ptr %t566)
  store ptr %t573, ptr %l280
  br label %bb141
bb141:
  %t574 = load ptr, ptr %l8, !tbaa !29
  %t576 = load ptr, ptr %l265, !tbaa !29
  %t577 = load %"compiler/source:Span", ptr %l266
  %t578 = load i32, ptr %l267, !tbaa !23
  %t579 = load i32, ptr %l268, !range !{i32 0, i32 43}
  %t580 = load ptr, ptr %l280, !tbaa !29
  %t582 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t576, %"compiler/source:Span" %t577, i32 %t578, i32 %t579, ptr %t580, ptr %t574)
  store ptr %t582, ptr %l283
  br label %bb142
bb142:
  call void @__olang_scope_close(ptr %s14)
  %t583 = load ptr, ptr %l283, !tbaa !29
  store ptr %t583, ptr %rv
  br label %ret
bb143:
  %t584 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 2
  %t585 = load i1, ptr %t584, !tbaa !21
  br i1 %t585, label %bb144, label %bb145
bb144:
  %t587 = load ptr, ptr %l0, !tbaa !29
  %t589 = getelementptr %"compiler/check:Checker", ptr %t587, i32 0, i32 1
  %t590 = load ptr, ptr %t589, !tbaa !29
  %t592 = getelementptr %"compiler/generic:Program", ptr %t590, i32 0, i32 2
  %t593 = load i32, ptr %l5, !tbaa !23
  %t596 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t592, i32 %t593)
  store i1 %t596, ptr %l290
  br label %bb146
bb145:
  store i1 false, ptr %l285, !tbaa !21
  br label %bb147
bb146:
  %t597 = load i1, ptr %l290, !tbaa !21
  %t598 = xor i1 %t597, true
  store i1 %t598, ptr %l285, !tbaa !21
  br label %bb147
bb147:
  %t600 = load i1, ptr %l285, !tbaa !21
  br i1 %t600, label %bb148, label %bb149
bb148:
  store %olang.scope zeroinitializer, ptr %s15
  %t601 = load ptr, ptr %l0, !tbaa !29
  store ptr %t601, ptr %l292, !tbaa !29
  %t602 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t602, ptr %l293
  %t603 = load i32, ptr %l3, !tbaa !23
  store i32 %t603, ptr %l294, !tbaa !23
  store i32 20, ptr %l295
  %t604 = load ptr, ptr %l0, !tbaa !29
  store ptr %t604, ptr %l296, !tbaa !29
  %t605 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t605, ptr %l297
  %t606 = load ptr, ptr %l0, !tbaa !29
  %t608 = getelementptr %"compiler/check:Checker", ptr %t606, i32 0, i32 1
  %t609 = load ptr, ptr %t608, !tbaa !29
  %t611 = getelementptr %"compiler/generic:Program", ptr %t609, i32 0, i32 2
  %t613 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s15, ptr %t611, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d32, i32 0, i32 1) })
  store i32 %t613, ptr %l301
  br label %bb150
bb149:
  br label %bb153
bb150:
  %t614 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 3
  %t615 = load i64, ptr %t614, !tbaa !24
  %t616 = load ptr, ptr %l296, !tbaa !29
  %t617 = load %"compiler/source:Span", ptr %l297
  %t618 = load i32, ptr %l301, !tbaa !23
  %t620 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t616, %"compiler/source:Span" %t617, i32 %t618, i64 %t615)
  store ptr %t620, ptr %l303
  br label %bb151
bb151:
  %t621 = load ptr, ptr %l292, !tbaa !29
  %t622 = load %"compiler/source:Span", ptr %l293
  %t623 = load i32, ptr %l294, !tbaa !23
  %t624 = load i32, ptr %l295, !range !{i32 0, i32 43}
  %t625 = load ptr, ptr %l303, !tbaa !29
  %t626 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t621, %"compiler/source:Span" %t622, i32 %t623, i32 %t624, ptr %t625, ptr null)
  store ptr %t626, ptr %l304
  br label %bb152
bb152:
  call void @__olang_scope_close(ptr %s15)
  %t627 = load ptr, ptr %l304, !tbaa !29
  store ptr %t627, ptr %rv
  br label %ret
bb153:
  %t628 = load ptr, ptr %l0, !tbaa !29
  %t629 = load %"compiler/source:Span", ptr %l4
  %t630 = load i32, ptr %l3, !tbaa !23
  %t631 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 3
  %t632 = load i64, ptr %t631, !tbaa !24
  %t637 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t628, %"compiler/source:Span" %t629, i32 %t630, i64 %t632)
  store ptr %t637, ptr %l309
  br label %bb154
bb154:
  %t638 = load ptr, ptr %l309, !tbaa !29
  store ptr %t638, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitU64(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l20 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i1
  %l35 = alloca i1
  %l39 = alloca %"compiler/check:litv"
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 29}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb9
bb4:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t17 = load ptr, ptr %l12, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 29}
  %t23 = icmp eq i64 %t21, 3
  store i1 %t23, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l13, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t27, i32 0, i32 2
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l2, !tbaa !29
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t35 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitU64(ptr %v0, ptr %v1, ptr %t31, ptr %t32)
  store i1 %t35, ptr %l20
  br label %bb10
bb10:
  %t36 = load i1, ptr %l20, !tbaa !21
  store i1 %t36, ptr %l5, !tbaa !21
  br label %bb28
bb11:
  %t37 = load ptr, ptr %l1, !tbaa !29
  store ptr %t37, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t38 = load ptr, ptr %l21, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t41 = load ptr, ptr %l21, !tbaa !29
  %t42 = load i64, ptr %t41, !range !{i64 0, i64 29}
  %t44 = icmp eq i64 %t42, 5
  store i1 %t44, ptr %l22, !tbaa !21
  br label %bb13
bb13:
  %t45 = load i1, ptr %l22, !tbaa !21
  br i1 %t45, label %bb14, label %bb15
bb14:
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr { i64, [5 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t48, i32 0, i32 2
  %t50 = load ptr, ptr %t49
  store ptr %t50, ptr %l3, !tbaa !29
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr { i64, [5 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t54, i32 0, i32 3
  %t56 = load ptr, ptr %t55
  store ptr %t56, ptr %l4, !tbaa !29
  br label %bb16
bb15:
  br label %bb22
bb16:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load ptr, ptr %l3, !tbaa !29
  %t62 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitU64(ptr %v0, ptr %v1, ptr %t58, ptr %t59)
  store i1 %t62, ptr %l31
  br label %bb17
bb17:
  %t63 = load i1, ptr %l31, !tbaa !21
  br i1 %t63, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb21
bb19:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l4, !tbaa !29
  %t68 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitU64(ptr %v0, ptr %v1, ptr %t64, ptr %t65)
  store i1 %t68, ptr %l35
  br label %bb20
bb20:
  %t69 = load i1, ptr %l35, !tbaa !21
  store i1 %t69, ptr %l32, !tbaa !21
  br label %bb21
bb21:
  %t70 = load i1, ptr %l32, !tbaa !21
  store i1 %t70, ptr %l5, !tbaa !21
  br label %bb28
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t76 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t71, ptr %t72)
  store %"compiler/check:litv" %t76, ptr %l39
  br label %bb26
bb26:
  %t77 = getelementptr %"compiler/check:litv", ptr %l39, i32 0, i32 2
  %t78 = load i1, ptr %t77, !tbaa !21
  store i1 %t78, ptr %l5, !tbaa !21
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_a9a2c4034b6e08dd_84116590a5e4e601)
  unreachable
bb28:
  %t80 = load i1, ptr %l5, !tbaa !21
  store i1 %t80, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralLocalNote(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca %"compiler/typed:Local"
  %l5 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l6 = alloca %"compiler/source:Span"
  %l10 = alloca ptr
  %l14 = alloca %"compiler/typed:Local"
  %l16 = alloca ptr
  %l20 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l21 = alloca %"compiler/source:Span"
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca i32
  %l27 = alloca %"compiler/source:Span"
  %l33 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i64
  %l41 = alloca { i64, [3 x i64] }
  %l44 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l57 = alloca %"compiler/msgs:Msg"
  %l61 = alloca ptr
  %l62 = alloca i64
  %l65 = alloca { i64, [3 x i64] }
  %l68 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l84 = alloca %"compiler/msgs:Msg"
  %l88 = alloca ptr
  %l89 = alloca i64
  %l92 = alloca { i64, [3 x i64] }
  %l95 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l107 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t5)
  store ptr %t7, ptr %l10
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l10, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 7
  %t11 = load i64, ptr %l2, !tbaa !24
  %t14 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t10, i64 %t11)
  store %"compiler/typed:Local" %t14, ptr %l14
  br label %bb5
bb5:
  %t15 = load %"compiler/typed:Local", ptr %l14
  store %"compiler/typed:Local" %t15, ptr %l4
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t16)
  store ptr %t18, ptr %l16
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l16, !tbaa !29
  %t21 = getelementptr %"compiler/check:frame", ptr %t19, i32 0, i32 0
  %t22 = load i64, ptr %t21, !tbaa !24
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t22, i64 %t23)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t26, ptr %l20
  br label %bb7
bb7:
  %t27 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l20
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t27, ptr %l5
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 32
  %t31 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l5
  %t34 = call { i32, %"compiler/source:Span" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H7d5384a5030fc995e793b3fe1f57e776(ptr %v0, ptr %t30, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t31)
  %t35 = extractvalue { i32, %"compiler/source:Span" } %t34, 1
  %t36 = extractvalue { i32, %"compiler/source:Span" } %t34, 0
  store i32 %t36, ptr %l26
  %t37 = icmp ne i32 %t36, 0
  br i1 %t37, label %bb9, label %ok.38, !prof !99
ok.38:
  store %"compiler/source:Span" %t35, ptr %l25
  br label %bb8
bb8:
  %t39 = load %"compiler/source:Span", ptr %l25
  store %"compiler/source:Span" %t39, ptr %l21
  br label %bb12
bb9:
  br label %bb10
bb10:
  call void @__olang_ert_req_clear()
  %t40 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 -1, i32 -1)
  store %"compiler/source:Span" %t40, ptr %l27
  br label %bb11
bb11:
  %t41 = load %"compiler/source:Span", ptr %l27
  store %"compiler/source:Span" %t41, ptr %l21
  br label %bb12
bb12:
  %t42 = load %"compiler/source:Span", ptr %l21
  store %"compiler/source:Span" %t42, ptr %l6
  %t43 = getelementptr %"compiler/source:Span", ptr %l6, i32 0, i32 0
  %t44 = load i32, ptr %t43, !tbaa !23
  %t46 = icmp sge i32 %t44, 0
  br i1 %t46, label %bb13, label %bb14
bb13:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 33
  %t51 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l5
  %t54 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t50, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t51)
  store i1 %t54, ptr %l33
  br label %bb15
bb14:
  br label %bb34
bb15:
  %t55 = load i1, ptr %l33, !tbaa !21
  br i1 %t55, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/load:Loader", ptr %t62, i32 0, i32 4
  %t65 = load ptr, ptr %t64, !tbaa !29
  store ptr %t65, ptr %l37, !tbaa !29
  %t66 = load i64, ptr %l1, !tbaa !24
  store i64 %t66, ptr %l38, !tbaa !24
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load %"compiler/source:Span", ptr %l6
  %t71 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t67, %"compiler/source:Span" %t68)
  store { i64, [3 x i64] } %t71, ptr %l41
  br label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/check:Checker", ptr %t72, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t77 = getelementptr %"compiler/generic:Program", ptr %t75, i32 0, i32 0
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = getelementptr %"compiler/load:Loader", ptr %t78, i32 0, i32 4
  %t81 = load ptr, ptr %t80, !tbaa !29
  store ptr %t81, ptr %l61, !tbaa !29
  %t82 = load i64, ptr %l1, !tbaa !24
  store i64 %t82, ptr %l62, !tbaa !24
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load %"compiler/source:Span", ptr %l6
  %t87 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t83, %"compiler/source:Span" %t84)
  store { i64, [3 x i64] } %t87, ptr %l65
  br label %bb25
bb18:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 0
  %t90 = load i32, ptr %t89, !tbaa !23
  %t93 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t88, i32 %t90)
  store { i64, ptr } %t93, ptr %l44
  br label %bb19
bb19:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 2
  %t96 = load i32, ptr %t95, !tbaa !23
  %t99 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t94, i32 %t96)
  store { i64, ptr } %t99, ptr %l47
  br label %bb20
bb20:
  %t100 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  %t102 = extractvalue { i64, ptr } %t100, 1
  %t103 = mul i64 %t101, 1
  %t104 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t103)
  call void @llvm.memcpy.p0.p0.i64(ptr %t104, ptr %t102, i64 %t103, i1 false)
  %t105 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  store { i64, ptr } %t106, ptr %l48, !tbaa !27
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i32, ptr %l3, !tbaa !23
  %t111 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t107, i32 %t108)
  store { i64, ptr } %t111, ptr %l51
  br label %bb21
bb21:
  %t112 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t112, 0
  %t114 = extractvalue { i64, ptr } %t112, 1
  %t115 = mul i64 %t113, 1
  %t116 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t115)
  call void @llvm.memcpy.p0.p0.i64(ptr %t116, ptr %t114, i64 %t115, i1 false)
  %t117 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t116, 1
  store { i64, ptr } %t118, ptr %l52, !tbaa !27
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load i32, ptr %l3, !tbaa !23
  %t123 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t119, i32 %t120)
  store { i64, ptr } %t123, ptr %l55
  br label %bb22
bb22:
  %t124 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t124, 0
  %t126 = extractvalue { i64, ptr } %t124, 1
  %t127 = mul i64 %t125, 1
  %t128 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t127)
  call void @llvm.memcpy.p0.p0.i64(ptr %t128, ptr %t126, i64 %t127, i1 false)
  %t129 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t128, 1
  %t131 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t132 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t135 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteLiteralRangeExpr(ptr %v0, ptr %s3, ptr %s3, ptr %s3, ptr %s3, { i64, ptr } %t131, { i64, ptr } %t132, { i64, ptr } %t133, { i64, ptr } %t130)
  store %"compiler/msgs:Msg" %t135, ptr %l57
  br label %bb23
bb23:
  %t136 = load ptr, ptr %l37, !tbaa !29
  %t137 = load i64, ptr %l38, !tbaa !24
  %t138 = load { i64, [3 x i64] }, ptr %l41
  %t139 = load %"compiler/msgs:Msg", ptr %l57
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s3, ptr %t136, i64 %t137, { i64, [3 x i64] } %t138, %"compiler/msgs:Msg" %t139)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s3)
  br label %bb33
bb25:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 0
  %t142 = load i32, ptr %t141, !tbaa !23
  %t145 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t140, i32 %t142)
  store { i64, ptr } %t145, ptr %l68
  br label %bb26
bb26:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 2
  %t148 = load i32, ptr %t147, !tbaa !23
  %t151 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s4, ptr %t146, i32 %t148)
  store { i64, ptr } %t151, ptr %l71
  br label %bb27
bb27:
  %t152 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t153 = extractvalue { i64, ptr } %t152, 0
  %t154 = extractvalue { i64, ptr } %t152, 1
  %t155 = mul i64 %t153, 1
  %t156 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t155)
  call void @llvm.memcpy.p0.p0.i64(ptr %t156, ptr %t154, i64 %t155, i1 false)
  %t157 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t156, 1
  store { i64, ptr } %t158, ptr %l72, !tbaa !27
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load i32, ptr %l3, !tbaa !23
  %t163 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s4, ptr %t159, i32 %t160)
  store { i64, ptr } %t163, ptr %l75
  br label %bb28
bb28:
  %t164 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t164, 0
  %t166 = extractvalue { i64, ptr } %t164, 1
  %t167 = mul i64 %t165, 1
  %t168 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t167)
  call void @llvm.memcpy.p0.p0.i64(ptr %t168, ptr %t166, i64 %t167, i1 false)
  %t169 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t168, 1
  store { i64, ptr } %t170, ptr %l76, !tbaa !27
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load %"compiler/source:Span", ptr %l6
  %t175 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t171, %"compiler/source:Span" %t172)
  store { i64, ptr } %t175, ptr %l79
  br label %bb29
bb29:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load i32, ptr %l3, !tbaa !23
  %t180 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s4, ptr %t176, i32 %t177)
  store { i64, ptr } %t180, ptr %l82
  br label %bb30
bb30:
  %t181 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t181, 0
  %t183 = extractvalue { i64, ptr } %t181, 1
  %t184 = mul i64 %t182, 1
  %t185 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t184)
  call void @llvm.memcpy.p0.p0.i64(ptr %t185, ptr %t183, i64 %t184, i1 false)
  %t186 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t185, 1
  %t188 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t189 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t190 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t191 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t193 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteLiteralRange(ptr %v0, ptr %s4, ptr %s4, ptr %v0, ptr %s4, ptr %s4, { i64, ptr } %t188, { i64, ptr } %t189, { i64, ptr } %t190, { i64, ptr } %t191, { i64, ptr } %t187)
  store %"compiler/msgs:Msg" %t193, ptr %l84
  br label %bb31
bb31:
  %t194 = load ptr, ptr %l61, !tbaa !29
  %t195 = load i64, ptr %l62, !tbaa !24
  %t196 = load { i64, [3 x i64] }, ptr %l65
  %t197 = load %"compiler/msgs:Msg", ptr %l84
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s4, ptr %t194, i64 %t195, { i64, [3 x i64] } %t196, %"compiler/msgs:Msg" %t197)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s4)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb34:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/check:Checker", ptr %t198, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !29
  %t203 = getelementptr %"compiler/generic:Program", ptr %t201, i32 0, i32 0
  %t204 = load ptr, ptr %t203, !tbaa !29
  %t206 = getelementptr %"compiler/load:Loader", ptr %t204, i32 0, i32 4
  %t207 = load ptr, ptr %t206, !tbaa !29
  store ptr %t207, ptr %l88, !tbaa !29
  %t208 = load i64, ptr %l1, !tbaa !24
  store i64 %t208, ptr %l89, !tbaa !24
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 1
  %t211 = load %"compiler/source:Span", ptr %t210
  %t214 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t209, %"compiler/source:Span" %t211)
  store { i64, [3 x i64] } %t214, ptr %l92
  br label %bb35
bb35:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 0
  %t217 = load i32, ptr %t216, !tbaa !23
  %t220 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t215, i32 %t217)
  store { i64, ptr } %t220, ptr %l95
  br label %bb36
bb36:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 2
  %t223 = load i32, ptr %t222, !tbaa !23
  %t226 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t221, i32 %t223)
  store { i64, ptr } %t226, ptr %l98
  br label %bb37
bb37:
  %t227 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t228 = extractvalue { i64, ptr } %t227, 0
  %t229 = extractvalue { i64, ptr } %t227, 1
  %t230 = mul i64 %t228, 1
  %t231 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t230)
  call void @llvm.memcpy.p0.p0.i64(ptr %t231, ptr %t229, i64 %t230, i1 false)
  %t232 = insertvalue { i64, ptr } undef, i64 %t228, 0
  %t233 = insertvalue { i64, ptr } %t232, ptr %t231, 1
  store { i64, ptr } %t233, ptr %l99, !tbaa !27
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 0
  %t236 = load i32, ptr %t235, !tbaa !23
  %t239 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t234, i32 %t236)
  store { i64, ptr } %t239, ptr %l102
  br label %bb38
bb38:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load i32, ptr %l3, !tbaa !23
  %t244 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t240, i32 %t241)
  store { i64, ptr } %t244, ptr %l105
  br label %bb39
bb39:
  %t245 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t246 = extractvalue { i64, ptr } %t245, 0
  %t247 = extractvalue { i64, ptr } %t245, 1
  %t248 = mul i64 %t246, 1
  %t249 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t248)
  call void @llvm.memcpy.p0.p0.i64(ptr %t249, ptr %t247, i64 %t248, i1 false)
  %t250 = insertvalue { i64, ptr } undef, i64 %t246, 0
  %t251 = insertvalue { i64, ptr } %t250, ptr %t249, 1
  %t252 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t253 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t254 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t256 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteLiteralLocal(ptr %v0, ptr %s0, ptr %v0, ptr %s0, ptr %s0, { i64, ptr } %t252, { i64, ptr } %t253, { i64, ptr } %t254, { i64, ptr } %t251)
  store %"compiler/msgs:Msg" %t256, ptr %l107
  br label %bb40
bb40:
  %t257 = load ptr, ptr %l88, !tbaa !29
  %t258 = load i64, ptr %l89, !tbaa !24
  %t259 = load { i64, [3 x i64] }, ptr %l92
  %t260 = load %"compiler/msgs:Msg", ptr %l107
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s0, ptr %t257, i64 %t258, { i64, [3 x i64] } %t259, %"compiler/msgs:Msg" %t260)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/text:StringBuilder" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ememberListing(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca { i64, ptr }
  %l17 = alloca i64
  %l20 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l33 = alloca i1
  %l37 = alloca { i64, ptr }
  %l40 = alloca i1
  %l41 = alloca i1
  %l45 = alloca { i64, ptr }
  %l49 = alloca i1
  %l50 = alloca i1
  %l54 = alloca { i64, ptr }
  %l57 = alloca i1
  %l61 = alloca { i64, ptr }
  %l65 = alloca i1
  %l67 = alloca i1
  %l71 = alloca { i64, ptr }
  %l75 = alloca i64
  %l79 = alloca { i64, ptr }
  %l82 = alloca i64
  %l93 = alloca ptr
  %l95 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca %"std/prelude/text:StringBuilder"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v1)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/text:StringBuilder", ptr %l6
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/text:StringBuilder" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t12 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMembers(ptr %v0, ptr %t8, i32 %a1)
  store { i64, ptr } %t12, ptr %l10
  br label %bb2
bb2:
  %t13 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t13, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t20 = icmp slt i64 %t14, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb45
bb5:
  br label %bb6
bb6:
  %t24 = load ptr, ptr %lp2
  %t26 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v1, ptr %t24)
  store i64 %t26, ptr %l17
  br label %bb7
bb7:
  %t27 = load i64, ptr %l17, !tbaa !24
  %t28 = icmp sgt i64 %t27, 0
  br i1 %t28, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t30 = load ptr, ptr %lp2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t30, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d33, i32 0, i32 1) })
  br label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  %t32 = load ptr, ptr %lp2
  store ptr %t32, ptr %l20, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t34, ptr %l22, !tbaa !27
  %t35 = load i64, ptr %l4, !tbaa !24
  %t37 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr i32, ptr %t38, i64 %t35
  %t40 = load i32, ptr %t39, !tbaa !33
  %t43 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t33, i32 %t40)
  store { i64, ptr } %t43, ptr %l25
  br label %bb12
bb12:
  %t44 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t44, 0
  %t46 = extractvalue { i64, ptr } %t44, 1
  %t47 = mul i64 %t45, 1
  %t48 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t47)
  call void @llvm.memcpy.p0.p0.i64(ptr %t48, ptr %t46, i64 %t47, i1 false)
  %t49 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  %t51 = load ptr, ptr %l20, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s1, ptr %t51, { i64, ptr } %t50)
  br label %bb13
bb13:
  %t53 = load i64, ptr %l4, !tbaa !24
  store i64 %t53, ptr %l5, !tbaa !24
  br label %bb14
bb14:
  %t55 = load i64, ptr %l5, !tbaa !24
  %t57 = add i64 %t55, 1
  %t58 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t63 = icmp slt i64 %t57, %t60
  br i1 %t63, label %bb15, label %bb16
bb15:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = getelementptr %"compiler/generic:Program", ptr %t68, i32 0, i32 2
  %t71 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t71, ptr %l37, !tbaa !27
  %t72 = load i64, ptr %l5, !tbaa !24
  %t74 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr i32, ptr %t75, i64 %t72
  %t77 = load i32, ptr %t76, !tbaa !33
  %t80 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t70, i32 %t77)
  store i1 %t80, ptr %l40
  br label %bb17
bb16:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb18
bb17:
  %t81 = load i1, ptr %l40, !tbaa !21
  store i1 %t81, ptr %l33, !tbaa !21
  br label %bb18
bb18:
  %t82 = load i1, ptr %l33, !tbaa !21
  br i1 %t82, label %bb19, label %bb20
bb19:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  %t89 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t89, ptr %l45, !tbaa !27
  %t90 = load i64, ptr %l5, !tbaa !24
  %t92 = add i64 %t90, 1
  %t94 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr i32, ptr %t95, i64 %t92
  %t97 = load i32, ptr %t96, !tbaa !33
  %t100 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t88, i32 %t97)
  store i1 %t100, ptr %l49
  br label %bb21
bb20:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb22
bb21:
  %t101 = load i1, ptr %l49, !tbaa !21
  store i1 %t101, ptr %l41, !tbaa !21
  br label %bb22
bb22:
  %t102 = load i1, ptr %l41, !tbaa !21
  br i1 %t102, label %bb23, label %bb24
bb23:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/check:Checker", ptr %t103, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/generic:Program", ptr %t106, i32 0, i32 2
  %t109 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t109, ptr %l54, !tbaa !27
  %t110 = load i64, ptr %l5, !tbaa !24
  %t112 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr i32, ptr %t113, i64 %t110
  %t115 = load i32, ptr %t114, !tbaa !33
  %t118 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t108, i32 %t115)
  store i1 %t118, ptr %l57
  br label %bb25
bb24:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb27
bb25:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/check:Checker", ptr %t119, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !29
  %t124 = getelementptr %"compiler/generic:Program", ptr %t122, i32 0, i32 2
  %t125 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t125, ptr %l61, !tbaa !27
  %t126 = load i64, ptr %l5, !tbaa !24
  %t128 = add i64 %t126, 1
  %t130 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr i32, ptr %t131, i64 %t128
  %t133 = load i32, ptr %t132, !tbaa !33
  %t136 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t124, i32 %t133)
  store i1 %t136, ptr %l65
  br label %bb26
bb26:
  %t137 = load i1, ptr %l57, !tbaa !21
  %t138 = load i1, ptr %l65, !tbaa !21
  %t139 = icmp eq i1 %t137, %t138
  store i1 %t139, ptr %l50, !tbaa !21
  br label %bb27
bb27:
  %t141 = load i1, ptr %l50, !tbaa !21
  br i1 %t141, label %bb28, label %bb29
bb28:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/check:Checker", ptr %t142, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !29
  %t147 = getelementptr %"compiler/generic:Program", ptr %t145, i32 0, i32 2
  %t148 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t148, ptr %l71, !tbaa !27
  %t149 = load i64, ptr %l5, !tbaa !24
  %t151 = add i64 %t149, 1
  %t153 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr i32, ptr %t154, i64 %t151
  %t156 = load i32, ptr %t155, !tbaa !33
  %t159 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t147, i32 %t156)
  store i64 %t159, ptr %l75
  br label %bb30
bb29:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb32
bb30:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/check:Checker", ptr %t160, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !29
  %t165 = getelementptr %"compiler/generic:Program", ptr %t163, i32 0, i32 2
  %t166 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t166, ptr %l79, !tbaa !27
  %t167 = load i64, ptr %l5, !tbaa !24
  %t169 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !27
  %t171 = getelementptr i32, ptr %t170, i64 %t167
  %t172 = load i32, ptr %t171, !tbaa !33
  %t175 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t165, i32 %t172)
  store i64 %t175, ptr %l82
  br label %bb31
bb31:
  %t176 = load i64, ptr %l82, !tbaa !24
  %t177 = add i64 %t176, 1
  %t178 = load i64, ptr %l75, !tbaa !24
  %t180 = icmp eq i64 %t178, %t177
  store i1 %t180, ptr %l67, !tbaa !21
  br label %bb32
bb32:
  %t182 = load i1, ptr %l67, !tbaa !21
  %t183 = xor i1 %t182, true
  br i1 %t183, label %bb33, label %bb34
bb33:
  br label %bb37
bb34:
  br label %bb35
bb35:
  %t185 = load i64, ptr %l5, !tbaa !24
  %t187 = add i64 %t185, 1
  store i64 %t187, ptr %l5, !tbaa !24
  br label %bb36
bb36:
  br label %bb14
bb37:
  %t189 = load i64, ptr %l5, !tbaa !24
  %t190 = load i64, ptr %l4, !tbaa !24
  %t192 = add i64 %t190, 1
  %t195 = icmp sgt i64 %t189, %t192
  br i1 %t195, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s4
  %t197 = load ptr, ptr %lp2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s4, ptr %t197, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d34, i32 0, i32 1) })
  br label %bb40
bb39:
  br label %bb43
bb40:
  %t199 = load ptr, ptr %lp2
  store ptr %t199, ptr %l93, !tbaa !29
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t201, ptr %l95, !tbaa !27
  %t202 = load i64, ptr %l5, !tbaa !24
  %t204 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !27
  %t206 = getelementptr i32, ptr %t205, i64 %t202
  %t207 = load i32, ptr %t206, !tbaa !33
  %t210 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s4, ptr %t200, i32 %t207)
  store { i64, ptr } %t210, ptr %l98
  br label %bb41
bb41:
  %t211 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t212 = extractvalue { i64, ptr } %t211, 0
  %t213 = extractvalue { i64, ptr } %t211, 1
  %t214 = mul i64 %t212, 1
  %t215 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t214)
  call void @llvm.memcpy.p0.p0.i64(ptr %t215, ptr %t213, i64 %t214, i1 false)
  %t216 = insertvalue { i64, ptr } undef, i64 %t212, 0
  %t217 = insertvalue { i64, ptr } %t216, ptr %t215, 1
  %t218 = load ptr, ptr %l93, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s4, ptr %t218, { i64, ptr } %t217)
  br label %bb42
bb42:
  %t220 = load i64, ptr %l5, !tbaa !24
  store i64 %t220, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb43
bb43:
  %t222 = load i64, ptr %l4, !tbaa !24
  %t224 = add i64 %t222, 1
  store i64 %t224, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb44
bb44:
  br label %bb3
bb45:
  %t226 = load ptr, ptr %lp2
  %t227 = load %"std/prelude/text:StringBuilder", ptr %t226
  store %"std/prelude/text:StringBuilder" %t227, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/text:StringBuilder", ptr %rv
  ret %"std/prelude/text:StringBuilder" %rr
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emerged(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca i64
  %l21 = alloca i64
  %l26 = alloca i32
  %l30 = alloca i1
  %l38 = alloca i32
  %l40 = alloca i64
  %l44 = alloca i64
  %l47 = alloca i64
  %l67 = alloca ptr
  %l70 = alloca i32
  %l71 = alloca i32
  %l83 = alloca i32
  %l86 = alloca i1
  %l95 = alloca i64
  %l98 = alloca i64
  %l100 = alloca i64
  %l105 = alloca ptr
  %l108 = alloca i32
  %l109 = alloca i64
  %l114 = alloca i64
  %l118 = alloca ptr
  %l119 = alloca i64
  %l123 = alloca i32
  %l130 = alloca i32
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l17
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l17
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  store ptr %a1, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l4, !tbaa !24
  store i64 %t7, ptr %l19, !tbaa !24
  %t8 = load ptr, ptr %l3, !tbaa !29
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t8)
  store i64 %t10, ptr %l21
  br label %bb3
bb3:
  %t11 = load i64, ptr %l19, !tbaa !24
  %t12 = load i64, ptr %l21, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb4, label %bb5
bb4:
  br label %bb58
bb5:
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t17, i64 %t18)
  store i32 %t21, ptr %l26
  br label %bb7
bb7:
  %t22 = load i32, ptr %l26, !tbaa !23
  store i32 %t22, ptr %l5, !tbaa !23
  %t23 = load i32, ptr %l5, !tbaa !23
  %t24 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  %t27 = icmp eq i32 %t23, %t24
  br i1 %t27, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb10
bb9:
  %t29 = load i32, ptr %l5, !tbaa !23
  %t30 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t33 = icmp eq i32 %t29, %t30
  store i1 %t33, ptr %l30, !tbaa !21
  br label %bb10
bb10:
  %t35 = load i1, ptr %l30, !tbaa !21
  br i1 %t35, label %bb11, label %bb12
bb11:
  br label %bb57
bb12:
  br label %bb13
bb13:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = getelementptr %"compiler/generic:Program", ptr %t39, i32 0, i32 2
  %t42 = load i32, ptr %l5, !tbaa !23
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l38
  br label %bb14
bb14:
  %t46 = load i32, ptr %l38, !tbaa !23
  store i32 %t46, ptr %l6, !tbaa !23
  store i64 -1, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t47 = load ptr, ptr %lp2
  %t49 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t47)
  store i64 %t49, ptr %l40
  br label %bb15
bb15:
  %t50 = load i64, ptr %l40, !tbaa !24
  store i64 %t50, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t51 = load i64, ptr %l9, !tbaa !24
  %t52 = load i64, ptr %l8, !tbaa !24
  %t55 = icmp sgt i64 %t51, %t52
  br i1 %t55, label %bb16, label %bb17
bb16:
  %t57 = load i64, ptr %l10, !tbaa !24
  %t59 = icmp sgt i64 %t57, 0
  br i1 %t59, label %bb18, label %bb19
bb17:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb21
bb18:
  %t61 = load i64, ptr %l9, !tbaa !24
  %t62 = load i64, ptr %l8, !tbaa !24
  %t65 = sub i64 %t61, %t62
  %t66 = load i64, ptr %l10, !tbaa !24
  %t69 = add i64 %t65, %t66
  %t71 = sub i64 %t69, 1
  %t72 = load i64, ptr %l10, !tbaa !24
  %t75 = sdiv i64 %t71, %t72
  store i64 %t75, ptr %l47, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb20
bb20:
  %t77 = load i64, ptr %l47, !tbaa !24
  store i64 %t77, ptr %l44, !tbaa !24
  br label %bb21
bb21:
  %t78 = load i64, ptr %l44, !tbaa !24
  store i64 %t78, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb22
bb22:
  %t79 = load i64, ptr %l12, !tbaa !24
  %t80 = load i64, ptr %l11, !tbaa !24
  %t83 = icmp slt i64 %t79, %t80
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb23, label %bb24
bb23:
  br label %bb32
bb24:
  br label %bb25
bb25:
  %t87 = load i64, ptr %l8, !tbaa !24
  %t88 = load i64, ptr %l12, !tbaa !24
  %t89 = load i64, ptr %l10, !tbaa !24
  %t92 = mul i64 %t88, %t89
  %t95 = add i64 %t87, %t92
  store i64 %t95, ptr %l13, !tbaa !24
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  store ptr %t102, ptr %l67, !tbaa !29
  %t103 = load ptr, ptr %lp2
  %t104 = load i64, ptr %l13, !tbaa !24
  %t107 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t103, i64 %t104)
  store i32 %t107, ptr %l70
  br label %bb26
bb26:
  %t108 = load ptr, ptr %l67, !tbaa !29
  %t109 = load i32, ptr %l70, !tbaa !23
  %t110 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t108, i32 %t109)
  store i32 %t110, ptr %l71
  br label %bb27
bb27:
  %t111 = load i32, ptr %l6, !tbaa !23
  %t112 = load i32, ptr %l71, !tbaa !23
  %t114 = icmp eq i32 %t112, %t111
  br i1 %t114, label %bb28, label %bb29
bb28:
  %t116 = load i64, ptr %l13, !tbaa !24
  store i64 %t116, ptr %l7, !tbaa !24
  br label %bb30
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t118 = load i64, ptr %l12, !tbaa !24
  %t120 = add i64 %t118, 1
  store i64 %t120, ptr %l12, !tbaa !24
  br label %bb22
bb32:
  %t122 = load i64, ptr %l7, !tbaa !24
  %t124 = icmp slt i64 %t122, 0
  br i1 %t124, label %bb33, label %bb34
bb33:
  %t126 = load ptr, ptr %lp2
  %t127 = load i32, ptr %l5, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t126, i32 %t127)
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb57
bb36:
  %t130 = load ptr, ptr %lp2
  %t131 = load i64, ptr %l7, !tbaa !24
  %t134 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t130, i64 %t131)
  store i32 %t134, ptr %l83
  br label %bb37
bb37:
  %t135 = load i32, ptr %l6, !tbaa !23
  %t136 = load i32, ptr %l83, !tbaa !23
  %t138 = icmp eq i32 %t136, %t135
  br i1 %t138, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l86, !tbaa !21
  br label %bb40
bb39:
  %t140 = load i32, ptr %l5, !tbaa !23
  %t141 = load i32, ptr %l6, !tbaa !23
  %t144 = icmp eq i32 %t140, %t141
  store i1 %t144, ptr %l86, !tbaa !21
  br label %bb40
bb40:
  %t146 = load i1, ptr %l86, !tbaa !21
  br i1 %t146, label %bb41, label %bb42
bb41:
  %t147 = load ptr, ptr %lp2
  %t148 = load i64, ptr %l7, !tbaa !24
  %t149 = load i32, ptr %l6, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t147, i64 %t148, i32 %t149)
  br label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb57
bb44:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load i32, ptr %l6, !tbaa !23
  %t157 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordCount(ptr %v0, ptr %t153, i32 %t154)
  store i64 %t157, ptr %l95
  br label %bb45
bb45:
  %t158 = load i64, ptr %l95, !tbaa !24
  store i64 %t158, ptr %l14, !tbaa !24
  %t159 = load i64, ptr %l14, !tbaa !24
  %t161 = icmp sge i64 %t159, 64
  br i1 %t161, label %bb46, label %bb47
bb46:
  %t163 = sub i64 0, 1
  store i64 %t163, ptr %l98, !tbaa !65
  br label %bb48
bb47:
  %t165 = load i64, ptr %l14, !tbaa !24
  store i64 %t165, ptr %l100, !tbaa !24
  %t166 = load i64, ptr %l100, !tbaa !24
  %t167 = load i64, ptr %l100, !tbaa !24
  %t168 = shl i64 1, %t167
  %t170 = sub i64 %t168, 1
  store i64 %t170, ptr %l98, !tbaa !65
  br label %bb48
bb48:
  %t172 = load i64, ptr %l98, !tbaa !65
  store i64 %t172, ptr %l15, !tbaa !65
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/check:Checker", ptr %t173, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !29
  %t178 = getelementptr %"compiler/generic:Program", ptr %t176, i32 0, i32 2
  store ptr %t178, ptr %l105, !tbaa !29
  %t179 = load ptr, ptr %lp2
  %t180 = load i64, ptr %l7, !tbaa !24
  %t183 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t179, i64 %t180)
  store i32 %t183, ptr %l108
  br label %bb49
bb49:
  %t184 = load ptr, ptr %l105, !tbaa !29
  %t185 = load i32, ptr %l108, !tbaa !23
  %t186 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t184, i32 %t185)
  store i64 %t186, ptr %l109
  br label %bb50
bb50:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/check:Checker", ptr %t187, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !29
  %t192 = getelementptr %"compiler/generic:Program", ptr %t190, i32 0, i32 2
  %t193 = load i32, ptr %l5, !tbaa !23
  %t196 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t192, i32 %t193)
  store i64 %t196, ptr %l114
  br label %bb51
bb51:
  %t197 = load i64, ptr %l109, !tbaa !65
  %t198 = load i64, ptr %l114, !tbaa !65
  %t199 = or i64 %t197, %t198
  %t200 = load i64, ptr %l15, !tbaa !65
  %t203 = and i64 %t199, %t200
  store i64 %t203, ptr %l16, !tbaa !65
  %t205 = load ptr, ptr %lp2
  store ptr %t205, ptr %l118, !tbaa !29
  %t206 = load i64, ptr %l7, !tbaa !24
  store i64 %t206, ptr %l119, !tbaa !24
  %t207 = load i64, ptr %l16, !tbaa !65
  %t208 = load i64, ptr %l15, !tbaa !65
  %t211 = icmp eq i64 %t207, %t208
  br i1 %t211, label %bb52, label %bb53
bb52:
  %t213 = load i32, ptr %l6, !tbaa !23
  store i32 %t213, ptr %l123, !tbaa !23
  br label %bb55
bb53:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t217 = getelementptr %"compiler/check:Checker", ptr %t215, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !29
  %t220 = getelementptr %"compiler/generic:Program", ptr %t218, i32 0, i32 2
  %t221 = load i32, ptr %l6, !tbaa !23
  %t222 = load i64, ptr %l16, !tbaa !65
  %t226 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %t220, i32 %t221, i64 %t222)
  store i32 %t226, ptr %l130
  br label %bb54
bb54:
  %t227 = load i32, ptr %l130, !tbaa !23
  store i32 %t227, ptr %l123, !tbaa !23
  br label %bb55
bb55:
  %t228 = load ptr, ptr %l118, !tbaa !29
  %t229 = load i64, ptr %l119, !tbaa !24
  %t230 = load i32, ptr %l123, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t228, i64 %t229, i32 %t230)
  br label %bb56
bb56:
  br label %bb57
bb57:
  %t231 = load i64, ptr %l4, !tbaa !24
  %t233 = add i64 %t231, 1
  store i64 %t233, ptr %l4, !tbaa !24
  br label %bb2
bb58:
  %t235 = load ptr, ptr %lp2
  %t236 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t235
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t236, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedHolds(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l11 = alloca i64
  %l14 = alloca i64
  %l36 = alloca i32
  %l44 = alloca i32
  %l49 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  store i64 8, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t1 = load i64, ptr %l3, !tbaa !24
  %t2 = load i64, ptr %l2, !tbaa !24
  %t5 = icmp sgt i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp sgt i64 %t7, 0
  br i1 %t9, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l11, !tbaa !24
  br label %bb6
bb3:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l2, !tbaa !24
  %t15 = sub i64 %t11, %t12
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = add i64 %t15, %t16
  %t21 = sub i64 %t19, 1
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = sdiv i64 %t21, %t22
  store i64 %t25, ptr %l14, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb5
bb5:
  %t27 = load i64, ptr %l14, !tbaa !24
  store i64 %t27, ptr %l11, !tbaa !24
  br label %bb6
bb6:
  %t28 = load i64, ptr %l11, !tbaa !24
  store i64 %t28, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  %t29 = load i64, ptr %l6, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = icmp slt i64 %t29, %t30
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb8, label %bb9
bb8:
  br label %bb17
bb9:
  br label %bb10
bb10:
  %t37 = load i64, ptr %l2, !tbaa !24
  %t38 = load i64, ptr %l6, !tbaa !24
  %t39 = load i64, ptr %l4, !tbaa !24
  %t42 = mul i64 %t38, %t39
  %t45 = add i64 %t37, %t42
  store i64 %t45, ptr %l7, !tbaa !24
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 2
  %t53 = load i32, ptr %l1, !tbaa !23
  %t56 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t52, i32 %t53)
  store i32 %t56, ptr %l36
  br label %bb11
bb11:
  %t57 = load i32, ptr %l36, !range !{i32 0, i32 33}
  %t59 = trunc i64 19 to i32
  %t60 = icmp eq i32 %t57, %t59
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb12, label %bb13
bb12:
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  %t70 = load i32, ptr %l1, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l44
  br label %bb15
bb15:
  %t74 = load i32, ptr %l44, !tbaa !23
  store i32 %t74, ptr %l1, !tbaa !23
  br label %bb16
bb16:
  %t75 = load i64, ptr %l6, !tbaa !24
  %t77 = add i64 %t75, 1
  store i64 %t77, ptr %l6, !tbaa !24
  br label %bb7
bb17:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load i32, ptr %l1, !tbaa !23
  %t83 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %t79, i32 %t80)
  store i1 %t83, ptr %l49
  br label %bb18
bb18:
  %t84 = load i1, ptr %l49, !tbaa !21
  store i1 %t84, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotCapture(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emustWrite(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i1 true)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopParam(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l7 = alloca i1
  %l8 = alloca ptr
  %l11 = alloca i32
  %l13 = alloca i32
  %l15 = alloca { i64, ptr }
  %l18 = alloca i32
  %l20 = alloca i1
  %l21 = alloca i1
  %l24 = alloca i1
  %l27 = alloca ptr
  %l31 = alloca i64
  %l33 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i1, ptr %l7, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l8, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i32, ptr %l1, !tbaa !23
  %t12 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElemOf(ptr %v0, ptr %t8, i32 %t9)
  store i32 %t12, ptr %l11
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t13 = load i32, ptr %l2, !range !{i32 0, i32 96}
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t15 = load i32, ptr %l11, !tbaa !23
  %t17 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopParam(ptr %v0, ptr %t14, i32 %t15, i32 %t13)
  store i32 %t17, ptr %l13
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t18 = load i32, ptr %l13, !tbaa !23
  store i32 %t18, ptr %rv
  br label %ret
bb6:
  %t19 = load i32, ptr %l2, !range !{i32 0, i32 96}
  %t21 = call { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %s0, i32 %t19)
  store { i64, ptr } %t21, ptr %l15
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t22, ptr %l3, !tbaa !27
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l1, !tbaa !23
  %t27 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l18
  br label %bb8
bb8:
  %t28 = load i32, ptr %l18, !tbaa !23
  store i32 %t28, ptr %l4, !tbaa !23
  %t29 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t31 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t29, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d35, i32 0, i32 1) })
  store i1 %t31, ptr %l20
  br label %bb9
bb9:
  %t32 = load i1, ptr %l20, !tbaa !21
  br i1 %t32, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb13
bb11:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l4, !tbaa !23
  %t37 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t33, i32 %t34)
  store i1 %t37, ptr %l24
  br label %bb12
bb12:
  %t38 = load i1, ptr %l24, !tbaa !21
  %t39 = xor i1 %t38, true
  store i1 %t39, ptr %l21, !tbaa !21
  br label %bb13
bb13:
  %t41 = load i1, ptr %l21, !tbaa !21
  br i1 %t41, label %bb14, label %bb15
bb14:
  %t42 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t42, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l27, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i32, ptr %l4, !tbaa !23
  %t47 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t51 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t45, i32 %t46, { i64, ptr } %t47, i64 1)
  store i64 %t51, ptr %l31
  br label %bb17
bb17:
  %t52 = load i32, ptr %l1, !tbaa !23
  %t53 = load ptr, ptr %l27, !tbaa !29
  %t54 = load i64, ptr %l31, !tbaa !24
  %t56 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperandParam(ptr %v0, ptr %t53, i64 %t54, i32 %t52)
  store i32 %t56, ptr %l33
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  %t57 = load i32, ptr %l33, !tbaa !23
  store i32 %t57, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeForeign(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l7 = alloca i1
  %l14 = alloca i32
  %l19 = alloca i32
  %l20 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca { i64, ptr }
  %l28 = alloca i1
  %l29 = alloca i1
  %l33 = alloca ptr
  %l38 = alloca i64
  %l39 = alloca ptr
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforeignRef(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i1, ptr %l7, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  %t16 = load i32, ptr %l1, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t19, ptr %l14
  br label %bb5
bb5:
  %t20 = load i32, ptr %l14, !tbaa !23
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 2
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t26, i32 %t20)
  store i32 %t30, ptr %l19
  br label %bb6
bb6:
  %t31 = load i32, ptr %l19, !tbaa !23
  store i32 %t31, ptr %l4, !tbaa !23
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l20, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 2
  %t39 = load i32, ptr %l4, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l25
  br label %bb7
bb7:
  %t43 = load ptr, ptr %l20, !tbaa !29
  %t44 = load i32, ptr %l25, !tbaa !23
  %t45 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t43, i32 %t44)
  store { i64, ptr } %t45, ptr %l26
  br label %bb8
bb8:
  %t47 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t49 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t47, { i64, ptr } %a2)
  store i1 %t49, ptr %l28
  br label %bb9
bb9:
  %t50 = load i1, ptr %l28, !tbaa !21
  br i1 %t50, label %bb10, label %bb11
bb10:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/check:Checker", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/generic:Program", ptr %t54, i32 0, i32 0
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/load:Loader", ptr %t57, i32 0, i32 5
  store ptr %t59, ptr %l33, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Checker", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = getelementptr %"compiler/generic:Program", ptr %t63, i32 0, i32 2
  %t66 = load i32, ptr %l4, !tbaa !23
  %t69 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t65, i32 %t66)
  store i64 %t69, ptr %l38
  br label %bb12
bb11:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb14
bb12:
  %t70 = load ptr, ptr %l33, !tbaa !29
  %t71 = load i64, ptr %l38, !tbaa !24
  %t72 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t70, i64 %t71)
  store ptr %t72, ptr %l39
  br label %bb13
bb13:
  %t73 = load ptr, ptr %l39, !tbaa !29
  %t75 = getelementptr %"compiler/load:Module", ptr %t73, i32 0, i32 3
  %t76 = load i1, ptr %t75, !tbaa !21
  store i1 %t76, ptr %l29, !tbaa !21
  br label %bb14
bb14:
  %t78 = load i1, ptr %l29, !tbaa !21
  store i1 %t78, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawOf(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca %"compiler/source:Span"
  %l9 = alloca ptr
  %l11 = alloca i32
  %l13 = alloca i32
  %l15 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l34 = alloca ptr
  %rv = alloca ptr
  %t38 = alloca { i64, [2 x i64] }, align 8
  %t46 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/check:rawTable", ptr %t1, i32 0, i32 1
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t6, ptr %l6
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  store ptr %t12, ptr %l9, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t13)
  store i32 %t15, ptr %l11
  br label %bb3
bb2:
  br label %bb6
bb3:
  %t16 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t17 = load ptr, ptr %l9, !tbaa !29
  %t18 = load i32, ptr %l11, !tbaa !23
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t17, i32 %t18, i64 %t16)
  store i32 %t20, ptr %l13
  br label %bb4
bb4:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t21)
  store ptr %t23, ptr %l15
  br label %bb5
bb5:
  %t24 = load ptr, ptr %l15, !tbaa !29
  %t26 = getelementptr %"compiler/check:frame", ptr %t24, i32 0, i32 2
  %t27 = load i64, ptr %t26, !tbaa !24
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = getelementptr %"compiler/check:rawTable", ptr %t28, i32 0, i32 3
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  store { i64, ptr } %t31, ptr %l19, !tbaa !27
  %t32 = load i64, ptr %l3, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr { i64, ptr }, ptr %t35, i64 %t32
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !37
  store { i64, [2 x i64] } zeroinitializer, ptr %t38
  %t39 = getelementptr { i64, [2 x i64] }, ptr %t38, i32 0, i32 0
  store i64 1, ptr %t39
  %t41 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t37, 0
  %t42 = getelementptr { i64, [2 x i64] }, ptr %t38, i32 0, i32 1
  store { { i64, ptr } } %t41, ptr %t42
  %t43 = load { i64, [2 x i64] }, ptr %t38
  %t45 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store { i64, [2 x i64] } %t43, ptr %t45
  store { i64, [5 x i64] } zeroinitializer, ptr %t46
  %t47 = getelementptr { i64, [5 x i64] }, ptr %t46, i32 0, i32 0
  store i64 1, ptr %t47
  %t48 = load %"compiler/source:Span", ptr %l6
  %t49 = insertvalue { %"compiler/source:Span", i32, i64, ptr } undef, %"compiler/source:Span" %t48, 0
  %t50 = load i32, ptr %l13, !tbaa !23
  %t51 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t49, i32 %t50, 1
  %t53 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t51, i64 %t27, 2
  %t55 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t53, ptr %t45, 3
  %t56 = getelementptr { i64, [5 x i64] }, ptr %t46, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, ptr } %t55, ptr %t56
  %t57 = load { i64, [5 x i64] }, ptr %t46
  %t59 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t57, ptr %t59
  store ptr %t59, ptr %rv
  br label %ret
bb6:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load %"compiler/source:Span", ptr %l1
  %t63 = load ptr, ptr %l2, !tbaa !29
  %t65 = getelementptr %"compiler/check:rawTable", ptr %t63, i32 0, i32 0
  %t66 = load i32, ptr %t65, !tbaa !23
  %t67 = load ptr, ptr %l2, !tbaa !29
  %t69 = getelementptr %"compiler/check:rawTable", ptr %t67, i32 0, i32 2
  %t70 = load { i64, ptr }, ptr %t69, !tbaa !27
  store { i64, ptr } %t70, ptr %l31, !tbaa !27
  %t71 = load i64, ptr %l3, !tbaa !24
  %t73 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr i64, ptr %t74, i64 %t71
  %t76 = load i64, ptr %t75, !tbaa !34
  %t81 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t61, %"compiler/source:Span" %t62, i32 %t66, i64 %t76)
  store ptr %t81, ptr %l34
  br label %bb7
bb7:
  %t82 = load ptr, ptr %l34, !tbaa !29
  store ptr %t82, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCopied(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %l18 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l25 = alloca ptr
  %l31 = alloca i1
  %l32 = alloca i1
  %l36 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i1
  %l47 = alloca i1
  %l48 = alloca ptr
  %l54 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l63 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca i1
  %l74 = alloca i1
  %l75 = alloca ptr
  %l81 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i1
  %l90 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t21 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i1 %t21, ptr %l18
  br label %bb6
bb6:
  %t22 = load i1, ptr %l18, !tbaa !21
  store i1 %t22, ptr %l8, !tbaa !21
  br label %bb66
bb7:
  %t23 = load ptr, ptr %l1, !tbaa !29
  store ptr %t23, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t24 = load ptr, ptr %l19, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb8, label %bb9
bb8:
  %t27 = load ptr, ptr %l19, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 18}
  %t30 = icmp eq i64 %t28, 11
  store i1 %t30, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t31 = load i1, ptr %l20, !tbaa !21
  br i1 %t31, label %bb10, label %bb11
bb10:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr { i64, [5 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t34, i32 0, i32 2
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb21
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l25, !tbaa !29
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Cond", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = icmp eq ptr %t42, null
  br i1 %t44, label %bb13, label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_64f1128892bbfadb_2fd1650a543ec847)
  unreachable
bb14:
  br label %bb15
bb15:
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = getelementptr %"compiler/typed:Cond", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t50 = load ptr, ptr %l25, !tbaa !29
  %t52 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCopied(ptr %v0, ptr %v1, ptr %t50, ptr %t49)
  store i1 %t52, ptr %l31
  br label %bb16
bb16:
  %t53 = load i1, ptr %l31, !tbaa !21
  br i1 %t53, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb20
bb18:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Cond", ptr %t55, i32 0, i32 2
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t61 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCopied(ptr %v0, ptr %v1, ptr %t54, ptr %t58)
  store i1 %t61, ptr %l36
  br label %bb19
bb19:
  %t62 = load i1, ptr %l36, !tbaa !21
  store i1 %t62, ptr %l32, !tbaa !21
  br label %bb20
bb20:
  %t63 = load i1, ptr %l32, !tbaa !21
  store i1 %t63, ptr %l8, !tbaa !21
  br label %bb66
bb21:
  %t64 = load ptr, ptr %l1, !tbaa !29
  store ptr %t64, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t65 = load ptr, ptr %l37, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb22, label %bb23
bb22:
  %t68 = load ptr, ptr %l37, !tbaa !29
  %t69 = load i64, ptr %t68, !range !{i64 0, i64 18}
  %t71 = icmp eq i64 %t69, 12
  store i1 %t71, ptr %l38, !tbaa !21
  br label %bb23
bb23:
  %t72 = load i1, ptr %l38, !tbaa !21
  br i1 %t72, label %bb24, label %bb25
bb24:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [5 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t75, i32 0, i32 2
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l4, !tbaa !29
  br label %bb26
bb25:
  br label %bb34
bb26:
  %t79 = load ptr, ptr %l4, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Seq", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = icmp eq ptr %t82, null
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb27, label %bb28
bb27:
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l48, !tbaa !29
  %t89 = load ptr, ptr %l4, !tbaa !29
  %t91 = getelementptr %"compiler/typed:Seq", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t94 = icmp eq ptr %t92, null
  br i1 %t94, label %bb29, label %bb30
bb28:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb33
bb29:
  call void @__olang_check_failed(ptr @olang_loc_9b328daa59c12fec_530ed6f7b483a728)
  unreachable
bb30:
  br label %bb31
bb31:
  %t96 = load ptr, ptr %l4, !tbaa !29
  %t98 = getelementptr %"compiler/typed:Seq", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t100 = load ptr, ptr %l48, !tbaa !29
  %t102 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCopied(ptr %v0, ptr %v1, ptr %t100, ptr %t99)
  store i1 %t102, ptr %l54
  br label %bb32
bb32:
  %t103 = load i1, ptr %l54, !tbaa !21
  store i1 %t103, ptr %l47, !tbaa !21
  br label %bb33
bb33:
  %t104 = load i1, ptr %l47, !tbaa !21
  store i1 %t104, ptr %l8, !tbaa !21
  br label %bb66
bb34:
  %t105 = load ptr, ptr %l1, !tbaa !29
  store ptr %t105, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t106 = load ptr, ptr %l55, !tbaa !29
  %t107 = icmp ne ptr %t106, null
  br i1 %t107, label %bb35, label %bb36
bb35:
  %t109 = load ptr, ptr %l55, !tbaa !29
  %t110 = load i64, ptr %t109, !range !{i64 0, i64 18}
  %t112 = icmp eq i64 %t110, 13
  store i1 %t112, ptr %l56, !tbaa !21
  br label %bb36
bb36:
  %t113 = load i1, ptr %l56, !tbaa !21
  br i1 %t113, label %bb37, label %bb38
bb37:
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = getelementptr { i64, [5 x i64] }, ptr %t114, i32 0, i32 1
  %t117 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t116, i32 0, i32 2
  %t118 = load ptr, ptr %t117
  store ptr %t118, ptr %l5, !tbaa !29
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load ptr, ptr %l5, !tbaa !29
  %t124 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroMatch(ptr %v0, ptr %v1, ptr %t120, ptr %t121)
  store i1 %t124, ptr %l63
  br label %bb40
bb40:
  %t125 = load i1, ptr %l63, !tbaa !21
  store i1 %t125, ptr %l8, !tbaa !21
  br label %bb66
bb41:
  %t126 = load ptr, ptr %l1, !tbaa !29
  store ptr %t126, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t127 = load ptr, ptr %l64, !tbaa !29
  %t128 = icmp ne ptr %t127, null
  br i1 %t128, label %bb42, label %bb43
bb42:
  %t130 = load ptr, ptr %l64, !tbaa !29
  %t131 = load i64, ptr %t130, !range !{i64 0, i64 18}
  %t133 = icmp eq i64 %t131, 14
  store i1 %t133, ptr %l65, !tbaa !21
  br label %bb43
bb43:
  %t134 = load i1, ptr %l65, !tbaa !21
  br i1 %t134, label %bb44, label %bb45
bb44:
  %t135 = load ptr, ptr %l1, !tbaa !29
  %t137 = getelementptr { i64, [5 x i64] }, ptr %t135, i32 0, i32 1
  %t138 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t137, i32 0, i32 2
  %t139 = load ptr, ptr %t138
  store ptr %t139, ptr %l6, !tbaa !29
  br label %bb46
bb45:
  br label %bb54
bb46:
  %t141 = load ptr, ptr %l6, !tbaa !29
  %t143 = getelementptr %"compiler/typed:Try", ptr %t141, i32 0, i32 0
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t146 = icmp eq ptr %t144, null
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb47, label %bb48
bb47:
  %t150 = load ptr, ptr %l0, !tbaa !29
  store ptr %t150, ptr %l75, !tbaa !29
  %t151 = load ptr, ptr %l6, !tbaa !29
  %t153 = getelementptr %"compiler/typed:Try", ptr %t151, i32 0, i32 0
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t156 = icmp eq ptr %t154, null
  br i1 %t156, label %bb49, label %bb50
bb48:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb53
bb49:
  call void @__olang_check_failed(ptr @olang_loc_aa71917389f82fa1_ab8db462134cc7fd)
  unreachable
bb50:
  br label %bb51
bb51:
  %t158 = load ptr, ptr %l6, !tbaa !29
  %t160 = getelementptr %"compiler/typed:Try", ptr %t158, i32 0, i32 0
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t162 = load ptr, ptr %l75, !tbaa !29
  %t164 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCopied(ptr %v0, ptr %v1, ptr %t162, ptr %t161)
  store i1 %t164, ptr %l81
  br label %bb52
bb52:
  %t165 = load i1, ptr %l81, !tbaa !21
  store i1 %t165, ptr %l74, !tbaa !21
  br label %bb53
bb53:
  %t166 = load i1, ptr %l74, !tbaa !21
  store i1 %t166, ptr %l8, !tbaa !21
  br label %bb66
bb54:
  %t167 = load ptr, ptr %l1, !tbaa !29
  store ptr %t167, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t168 = load ptr, ptr %l82, !tbaa !29
  %t169 = icmp ne ptr %t168, null
  br i1 %t169, label %bb55, label %bb56
bb55:
  %t171 = load ptr, ptr %l82, !tbaa !29
  %t172 = load i64, ptr %t171, !range !{i64 0, i64 18}
  %t174 = icmp eq i64 %t172, 6
  store i1 %t174, ptr %l83, !tbaa !21
  br label %bb56
bb56:
  %t175 = load i1, ptr %l83, !tbaa !21
  br i1 %t175, label %bb57, label %bb58
bb57:
  %t176 = load ptr, ptr %l1, !tbaa !29
  %t178 = getelementptr { i64, [5 x i64] }, ptr %t176, i32 0, i32 1
  %t179 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t178, i32 0, i32 2
  %t180 = load ptr, ptr %t179
  store ptr %t180, ptr %l7, !tbaa !29
  br label %bb59
bb58:
  br label %bb61
bb59:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load ptr, ptr %l7, !tbaa !29
  %t186 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCallCopy(ptr %v0, ptr %v1, ptr %t182, ptr %t183)
  store i1 %t186, ptr %l90
  br label %bb60
bb60:
  %t187 = load i1, ptr %l90, !tbaa !21
  store i1 %t187, ptr %l8, !tbaa !21
  br label %bb66
bb61:
  br i1 true, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb65
bb64:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_45c1f7cb36e76579_9732da1c199d4515)
  unreachable
bb66:
  %t188 = load i1, ptr %l8, !tbaa !21
  store i1 %t188, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, ptr %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca %"compiler/typed:Local"
  %l8 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca ptr
  %l17 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l26 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l38 = alloca ptr
  %l40 = alloca %"compiler/typed:Local"
  %l46 = alloca ptr
  %l50 = alloca i64
  %l54 = alloca i64
  %l57 = alloca i64
  %l77 = alloca i32
  %l80 = alloca i1
  %l84 = alloca i1
  %l85 = alloca i1
  %l88 = alloca i1
  %l96 = alloca i1
  %l100 = alloca i1
  %l104 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l106 = alloca ptr
  %l110 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l111 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l112 = alloca i32
  %l114 = alloca i64
  %l116 = alloca i64
  %l121 = alloca ptr
  %l132 = alloca ptr
  %l133 = alloca i1
  %l146 = alloca ptr
  %l147 = alloca i1
  %l160 = alloca ptr
  %l161 = alloca i1
  %l175 = alloca ptr
  %l176 = alloca i1
  %l190 = alloca ptr
  %l191 = alloca i1
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l5, !tbaa !24
  %t7 = icmp sgt i64 %t5, 48
  store i1 %t7, ptr %l26, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l26, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t10 = load ptr, ptr %l2, !tbaa !29
  store ptr %t10, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t11 = load ptr, ptr %l29, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l29, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 0
  store i1 %t17, ptr %l30, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l30, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t21, i32 0, i32 2
  %t23 = load i32, ptr %t22
  store i32 %t23, ptr %l6, !tbaa !23
  br label %bb11
bb10:
  br label %bb66
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 12
  %t28 = load i64, ptr %l1, !tbaa !24
  %t31 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t27, i64 %t28)
  store ptr %t31, ptr %l38
  br label %bb12
bb12:
  %t32 = load i32, ptr %l6, !tbaa !23
  %t33 = load ptr, ptr %l38, !tbaa !29
  %t35 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t33, i32 %t32)
  store %"compiler/typed:Local" %t35, ptr %l40
  br label %bb13
bb13:
  %t36 = load %"compiler/typed:Local", ptr %l40
  store %"compiler/typed:Local" %t36, ptr %l7
  %t37 = getelementptr %"compiler/typed:Local", ptr %l7, i32 0, i32 4
  %t38 = load i32, ptr %t37, !range !{i32 0, i32 7}
  %t40 = trunc i64 0 to i32
  %t41 = icmp eq i32 %t38, %t40
  br i1 %t41, label %bb14, label %bb15
bb14:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 12
  %t46 = load i64, ptr %l1, !tbaa !24
  %t49 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t45, i64 %t46)
  store ptr %t49, ptr %l46
  br label %bb16
bb15:
  br label %bb43
bb16:
  %t50 = load ptr, ptr %l46, !tbaa !29
  %t52 = getelementptr %"compiler/typed:Body", ptr %t50, i32 0, i32 5
  %t53 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t52
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t53, ptr %l8
  store i64 0, ptr %l9, !tbaa !24
  %t56 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %l8)
  store i64 %t56, ptr %l50
  br label %bb17
bb17:
  %t57 = load i64, ptr %l50, !tbaa !24
  store i64 %t57, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t58 = load i64, ptr %l10, !tbaa !24
  %t59 = load i64, ptr %l9, !tbaa !24
  %t62 = icmp sgt i64 %t58, %t59
  br i1 %t62, label %bb18, label %bb19
bb18:
  %t64 = load i64, ptr %l11, !tbaa !24
  %t66 = icmp sgt i64 %t64, 0
  br i1 %t66, label %bb20, label %bb21
bb19:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb23
bb20:
  %t68 = load i64, ptr %l10, !tbaa !24
  %t69 = load i64, ptr %l9, !tbaa !24
  %t72 = sub i64 %t68, %t69
  %t73 = load i64, ptr %l11, !tbaa !24
  %t76 = add i64 %t72, %t73
  %t78 = sub i64 %t76, 1
  %t79 = load i64, ptr %l11, !tbaa !24
  %t82 = sdiv i64 %t78, %t79
  store i64 %t82, ptr %l57, !tbaa !24
  br label %bb22
bb21:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb22
bb22:
  %t84 = load i64, ptr %l57, !tbaa !24
  store i64 %t84, ptr %l54, !tbaa !24
  br label %bb23
bb23:
  %t85 = load i64, ptr %l54, !tbaa !24
  store i64 %t85, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb24
bb24:
  %t86 = load i64, ptr %l13, !tbaa !24
  %t87 = load i64, ptr %l12, !tbaa !24
  %t90 = icmp slt i64 %t86, %t87
  %t92 = xor i1 %t90, true
  br i1 %t92, label %bb25, label %bb26
bb25:
  br label %bb42
bb26:
  br label %bb27
bb27:
  %t94 = load i64, ptr %l9, !tbaa !24
  %t95 = load i64, ptr %l13, !tbaa !24
  %t96 = load i64, ptr %l11, !tbaa !24
  %t99 = mul i64 %t95, %t96
  %t102 = add i64 %t94, %t99
  store i64 %t102, ptr %l14, !tbaa !24
  %t104 = load i64, ptr %l14, !tbaa !24
  %t107 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %l8, i64 %t104)
  store i32 %t107, ptr %l77
  br label %bb28
bb28:
  %t108 = load i32, ptr %l6, !tbaa !23
  %t109 = load i32, ptr %l77, !tbaa !23
  %t111 = icmp eq i32 %t109, %t108
  br i1 %t111, label %bb29, label %bb30
bb29:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load i64, ptr %l1, !tbaa !24
  %t115 = load i64, ptr %l14, !tbaa !24
  %t119 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %t113, i64 %t114, i64 %t115)
  store i1 %t119, ptr %l84
  br label %bb31
bb30:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb32
bb31:
  %t120 = load i1, ptr %l84, !tbaa !21
  store i1 %t120, ptr %l80, !tbaa !21
  br label %bb32
bb32:
  %t121 = load i1, ptr %l80, !tbaa !21
  br i1 %t121, label %bb33, label %bb34
bb33:
  %t122 = load ptr, ptr %l3, !tbaa !29
  %t123 = load i64, ptr %l14, !tbaa !24
  %t126 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v2, ptr %t122, i64 %t123)
  store i1 %t126, ptr %l88
  br label %bb35
bb34:
  store i1 false, ptr %l85, !tbaa !21
  br label %bb36
bb35:
  %t127 = load i1, ptr %l88, !tbaa !21
  %t128 = xor i1 %t127, true
  store i1 %t128, ptr %l85, !tbaa !21
  br label %bb36
bb36:
  %t130 = load i1, ptr %l85, !tbaa !21
  br i1 %t130, label %bb37, label %bb38
bb37:
  %t131 = load ptr, ptr %l3, !tbaa !29
  %t132 = load i64, ptr %l14, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t131, i64 %t132)
  br label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t135 = load i64, ptr %l13, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l13, !tbaa !24
  br label %bb24
bb42:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb43:
  %t139 = getelementptr %"compiler/typed:Local", ptr %l7, i32 0, i32 4
  %t140 = load i32, ptr %t139, !range !{i32 0, i32 7}
  %t142 = trunc i64 5 to i32
  %t143 = icmp eq i32 %t140, %t142
  br i1 %t143, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l96, !tbaa !21
  br label %bb47
bb45:
  %t145 = load ptr, ptr %l4, !tbaa !29
  %t146 = load i32, ptr %l6, !tbaa !23
  %t148 = sext i32 %t146 to i64
  %t151 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v3, ptr %t145, i64 %t148)
  store i1 %t151, ptr %l100
  br label %bb46
bb46:
  %t152 = load i1, ptr %l100, !tbaa !21
  store i1 %t152, ptr %l96, !tbaa !21
  br label %bb47
bb47:
  %t153 = load i1, ptr %l96, !tbaa !21
  br i1 %t153, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb49:
  br label %bb50
bb50:
  %t154 = load ptr, ptr %l4, !tbaa !29
  %t155 = load i32, ptr %l6, !tbaa !23
  %t157 = sext i32 %t155 to i64
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v3, ptr %t154, i64 %t157, i1 true)
  br label %bb51
bb51:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/check:Checker", ptr %t160, i32 0, i32 68
  store ptr %t162, ptr %l106, !tbaa !29
  %t163 = load i64, ptr %l1, !tbaa !24
  %t164 = load i32, ptr %l6, !tbaa !23
  %t166 = sext i32 %t164 to i64
  %t169 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s2, i64 %t163, i64 %t166)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t169, ptr %l110
  br label %bb52
bb52:
  %t170 = load ptr, ptr %l106, !tbaa !29
  %t171 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l110
  %t172 = call { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hca9d4f63e6a0ec4764c25705e3ecdd1f(ptr %v0, ptr %v0, ptr %t170, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t171)
  %t173 = extractvalue { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } %t172, 1
  %t174 = extractvalue { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } %t172, 0
  store i32 %t174, ptr %l112
  %t175 = icmp ne i32 %t174, 0
  br i1 %t175, label %bb54, label %ok.176, !prof !99
ok.176:
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t173, ptr %l111
  br label %bb53
bb53:
  %t177 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l111
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t177, ptr %l104
  br label %bb56
bb54:
  br label %bb55
bb55:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb56:
  %t178 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l104
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t178, ptr %l15
  store ptr %l15, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb57
bb57:
  %t180 = load i64, ptr %l17, !tbaa !24
  store i64 %t180, ptr %l114, !tbaa !24
  %t181 = load ptr, ptr %l16, !tbaa !29
  %t183 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t181)
  store i64 %t183, ptr %l116
  br label %bb58
bb58:
  %t184 = load i64, ptr %l114, !tbaa !24
  %t185 = load i64, ptr %l116, !tbaa !24
  %t186 = icmp slt i64 %t184, %t185
  %t188 = xor i1 %t186, true
  br i1 %t188, label %bb59, label %bb60
bb59:
  br label %bb65
bb60:
  br label %bb61
bb61:
  %t190 = load ptr, ptr %l16, !tbaa !29
  %t191 = load i64, ptr %l17, !tbaa !24
  %t194 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t190, i64 %t191)
  store ptr %t194, ptr %l121
  br label %bb62
bb62:
  %t195 = load ptr, ptr %l121, !tbaa !29
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load i64, ptr %l1, !tbaa !24
  %t200 = load ptr, ptr %l3, !tbaa !29
  %t201 = load ptr, ptr %l4, !tbaa !29
  %t202 = load i64, ptr %l5, !tbaa !24
  %t204 = add i64 %t202, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepIn(ptr %v0, ptr %v0, ptr %v2, ptr %v3, ptr %t196, i64 %t197, ptr %t195, ptr %t200, ptr %t201, i64 %t204)
  br label %bb63
bb63:
  br label %bb64
bb64:
  %t211 = load i64, ptr %l17, !tbaa !24
  %t213 = add i64 %t211, 1
  store i64 %t213, ptr %l17, !tbaa !24
  br label %bb57
bb65:
  call void @__olang_scope_close(ptr %s2)
  br label %bb106
bb66:
  %t215 = load ptr, ptr %l2, !tbaa !29
  store ptr %t215, ptr %l132, !tbaa !29
  store i1 false, ptr %l133, !tbaa !21
  %t216 = load ptr, ptr %l132, !tbaa !29
  %t217 = icmp ne ptr %t216, null
  br i1 %t217, label %bb67, label %bb68
bb67:
  %t219 = load ptr, ptr %l132, !tbaa !29
  %t220 = load i64, ptr %t219, !range !{i64 0, i64 8}
  %t222 = icmp eq i64 %t220, 2
  store i1 %t222, ptr %l133, !tbaa !21
  br label %bb68
bb68:
  %t223 = load i1, ptr %l133, !tbaa !21
  br i1 %t223, label %bb69, label %bb70
bb69:
  %t224 = load ptr, ptr %l2, !tbaa !29
  %t226 = getelementptr { i64, [4 x i64] }, ptr %t224, i32 0, i32 1
  %t227 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t226, i32 0, i32 2
  %t228 = load ptr, ptr %t227
  store ptr %t228, ptr %l19, !tbaa !29
  br label %bb71
bb70:
  br label %bb73
bb71:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load i64, ptr %l1, !tbaa !24
  %t232 = load ptr, ptr %l19, !tbaa !29
  %t234 = load ptr, ptr %l3, !tbaa !29
  %t235 = load ptr, ptr %l4, !tbaa !29
  %t236 = load i64, ptr %l5, !tbaa !24
  %t238 = add i64 %t236, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t230, i64 %t231, ptr %t232, ptr %t234, ptr %t235, i64 %t238)
  br label %bb72
bb72:
  br label %bb106
bb73:
  %t245 = load ptr, ptr %l2, !tbaa !29
  store ptr %t245, ptr %l146, !tbaa !29
  store i1 false, ptr %l147, !tbaa !21
  %t246 = load ptr, ptr %l146, !tbaa !29
  %t247 = icmp ne ptr %t246, null
  br i1 %t247, label %bb74, label %bb75
bb74:
  %t249 = load ptr, ptr %l146, !tbaa !29
  %t250 = load i64, ptr %t249, !range !{i64 0, i64 8}
  %t252 = icmp eq i64 %t250, 3
  store i1 %t252, ptr %l147, !tbaa !21
  br label %bb75
bb75:
  %t253 = load i1, ptr %l147, !tbaa !21
  br i1 %t253, label %bb76, label %bb77
bb76:
  %t254 = load ptr, ptr %l2, !tbaa !29
  %t256 = getelementptr { i64, [4 x i64] }, ptr %t254, i32 0, i32 1
  %t257 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t256, i32 0, i32 2
  %t258 = load ptr, ptr %t257
  store ptr %t258, ptr %l20, !tbaa !29
  br label %bb78
bb77:
  br label %bb80
bb78:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t261 = load i64, ptr %l1, !tbaa !24
  %t262 = load ptr, ptr %l20, !tbaa !29
  %t264 = load ptr, ptr %l3, !tbaa !29
  %t265 = load ptr, ptr %l4, !tbaa !29
  %t266 = load i64, ptr %l5, !tbaa !24
  %t268 = add i64 %t266, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t260, i64 %t261, ptr %t262, ptr %t264, ptr %t265, i64 %t268)
  br label %bb79
bb79:
  br label %bb106
bb80:
  %t275 = load ptr, ptr %l2, !tbaa !29
  store ptr %t275, ptr %l160, !tbaa !29
  store i1 false, ptr %l161, !tbaa !21
  %t276 = load ptr, ptr %l160, !tbaa !29
  %t277 = icmp ne ptr %t276, null
  br i1 %t277, label %bb81, label %bb82
bb81:
  %t279 = load ptr, ptr %l160, !tbaa !29
  %t280 = load i64, ptr %t279, !range !{i64 0, i64 8}
  %t282 = icmp eq i64 %t280, 4
  store i1 %t282, ptr %l161, !tbaa !21
  br label %bb82
bb82:
  %t283 = load i1, ptr %l161, !tbaa !21
  br i1 %t283, label %bb83, label %bb84
bb83:
  %t284 = load ptr, ptr %l2, !tbaa !29
  %t286 = getelementptr { i64, [4 x i64] }, ptr %t284, i32 0, i32 1
  %t287 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t286, i32 0, i32 2
  %t288 = load ptr, ptr %t287
  store ptr %t288, ptr %l21, !tbaa !29
  br label %bb85
bb84:
  br label %bb87
bb85:
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t291 = load i64, ptr %l1, !tbaa !24
  %t292 = load ptr, ptr %l21, !tbaa !29
  %t294 = getelementptr %"compiler/typed:Elem", ptr %t292, i32 0, i32 0
  %t295 = load ptr, ptr %t294, !tbaa !29
  %t297 = load ptr, ptr %l3, !tbaa !29
  %t298 = load ptr, ptr %l4, !tbaa !29
  %t299 = load i64, ptr %l5, !tbaa !24
  %t301 = add i64 %t299, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t290, i64 %t291, ptr %t295, ptr %t297, ptr %t298, i64 %t301)
  br label %bb86
bb86:
  br label %bb106
bb87:
  %t308 = load ptr, ptr %l2, !tbaa !29
  store ptr %t308, ptr %l175, !tbaa !29
  store i1 false, ptr %l176, !tbaa !21
  %t309 = load ptr, ptr %l175, !tbaa !29
  %t310 = icmp ne ptr %t309, null
  br i1 %t310, label %bb88, label %bb89
bb88:
  %t312 = load ptr, ptr %l175, !tbaa !29
  %t313 = load i64, ptr %t312, !range !{i64 0, i64 8}
  %t315 = icmp eq i64 %t313, 5
  store i1 %t315, ptr %l176, !tbaa !21
  br label %bb89
bb89:
  %t316 = load i1, ptr %l176, !tbaa !21
  br i1 %t316, label %bb90, label %bb91
bb90:
  %t317 = load ptr, ptr %l2, !tbaa !29
  %t319 = getelementptr { i64, [4 x i64] }, ptr %t317, i32 0, i32 1
  %t320 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t319, i32 0, i32 2
  %t321 = load ptr, ptr %t320
  store ptr %t321, ptr %l22, !tbaa !29
  br label %bb92
bb91:
  br label %bb94
bb92:
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = load i64, ptr %l1, !tbaa !24
  %t325 = load ptr, ptr %l22, !tbaa !29
  %t327 = getelementptr %"compiler/typed:Payload", ptr %t325, i32 0, i32 0
  %t328 = load ptr, ptr %t327, !tbaa !29
  %t330 = load ptr, ptr %l3, !tbaa !29
  %t331 = load ptr, ptr %l4, !tbaa !29
  %t332 = load i64, ptr %l5, !tbaa !24
  %t334 = add i64 %t332, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t323, i64 %t324, ptr %t328, ptr %t330, ptr %t331, i64 %t334)
  br label %bb93
bb93:
  br label %bb106
bb94:
  %t341 = load ptr, ptr %l2, !tbaa !29
  store ptr %t341, ptr %l190, !tbaa !29
  store i1 false, ptr %l191, !tbaa !21
  %t342 = load ptr, ptr %l190, !tbaa !29
  %t343 = icmp ne ptr %t342, null
  br i1 %t343, label %bb95, label %bb96
bb95:
  %t345 = load ptr, ptr %l190, !tbaa !29
  %t346 = load i64, ptr %t345, !range !{i64 0, i64 8}
  %t348 = icmp eq i64 %t346, 6
  store i1 %t348, ptr %l191, !tbaa !21
  br label %bb96
bb96:
  %t349 = load i1, ptr %l191, !tbaa !21
  br i1 %t349, label %bb97, label %bb98
bb97:
  %t350 = load ptr, ptr %l2, !tbaa !29
  %t352 = getelementptr { i64, [4 x i64] }, ptr %t350, i32 0, i32 1
  %t353 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t352, i32 0, i32 2
  %t354 = load ptr, ptr %t353
  store ptr %t354, ptr %l23, !tbaa !29
  br label %bb99
bb98:
  br label %bb101
bb99:
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t357 = load i64, ptr %l1, !tbaa !24
  %t358 = load ptr, ptr %l23, !tbaa !29
  %t360 = load ptr, ptr %l3, !tbaa !29
  %t361 = load ptr, ptr %l4, !tbaa !29
  %t362 = load i64, ptr %l5, !tbaa !24
  %t364 = add i64 %t362, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t356, i64 %t357, ptr %t358, ptr %t360, ptr %t361, i64 %t364)
  br label %bb100
bb100:
  br label %bb106
bb101:
  br i1 true, label %bb102, label %bb103
bb102:
  br label %bb104
bb103:
  br label %bb105
bb104:
  br label %bb106
bb105:
  call void @__olang_check_failed(ptr @olang_loc_8771b1e868207559_9b4adf6aba3e467d)
  unreachable
bb106:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esameJump(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca %"compiler/types:Table"
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l14 = alloca %"compiler/types:Table"
  %l15 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca { i64, ptr }
  %l36 = alloca i64
  %l39 = alloca i64
  %l58 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l64 = alloca i1
  %l66 = alloca i1
  %l68 = alloca { i64, ptr }
  %l71 = alloca i64
  %l73 = alloca { i64, ptr }
  %l76 = alloca i64
  %l81 = alloca ptr
  %l84 = alloca i32
  %l87 = alloca i32
  %l88 = alloca i1
  %l94 = alloca i1
  %l96 = alloca i1
  %l100 = alloca i1
  %l107 = alloca { i64, ptr }
  %l108 = alloca i64
  %l113 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %l14, ptr %t6, i64 272, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %l14, i64 272, i1 false)
  store ptr %l3, ptr %l15, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %l3, i32 %t7)
  store i32 %t10, ptr %l18
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l15, !tbaa !29
  %t12 = load i32, ptr %l18, !tbaa !23
  %t13 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t11, i32 %t12)
  store { i64, ptr } %t13, ptr %l19
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t14, ptr %l4, !tbaa !27
  store ptr %l3, ptr %l20, !tbaa !29
  %t15 = load i32, ptr %l2, !tbaa !23
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %l3, i32 %t15)
  store i32 %t18, ptr %l23
  br label %bb3
bb3:
  %t19 = load ptr, ptr %l20, !tbaa !29
  %t20 = load i32, ptr %l23, !tbaa !23
  %t21 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t19, i32 %t20)
  store { i64, ptr } %t21, ptr %l24
  br label %bb4
bb4:
  %t22 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t22, ptr %l5, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t26 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  %t31 = icmp ne i64 %t25, %t28
  br i1 %t31, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  store i64 0, ptr %l6, !tbaa !24
  %t34 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t34, 0
  store i64 %t36, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t38 = load i64, ptr %l7, !tbaa !24
  %t39 = load i64, ptr %l6, !tbaa !24
  %t42 = icmp sgt i64 %t38, %t39
  br i1 %t42, label %bb8, label %bb9
bb8:
  %t44 = load i64, ptr %l8, !tbaa !24
  %t46 = icmp sgt i64 %t44, 0
  br i1 %t46, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb13
bb10:
  %t48 = load i64, ptr %l7, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = sub i64 %t48, %t49
  %t53 = load i64, ptr %l8, !tbaa !24
  %t56 = add i64 %t52, %t53
  %t58 = sub i64 %t56, 1
  %t59 = load i64, ptr %l8, !tbaa !24
  %t62 = sdiv i64 %t58, %t59
  store i64 %t62, ptr %l39, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb12
bb12:
  %t64 = load i64, ptr %l39, !tbaa !24
  store i64 %t64, ptr %l36, !tbaa !24
  br label %bb13
bb13:
  %t65 = load i64, ptr %l36, !tbaa !24
  store i64 %t65, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb14
bb14:
  %t66 = load i64, ptr %l10, !tbaa !24
  %t67 = load i64, ptr %l9, !tbaa !24
  %t70 = icmp slt i64 %t66, %t67
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb15, label %bb16
bb15:
  br label %bb28
bb16:
  br label %bb17
bb17:
  %t74 = load i64, ptr %l6, !tbaa !24
  %t75 = load i64, ptr %l10, !tbaa !24
  %t76 = load i64, ptr %l8, !tbaa !24
  %t79 = mul i64 %t75, %t76
  %t82 = add i64 %t74, %t79
  store i64 %t82, ptr %l11, !tbaa !24
  %t84 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t84, ptr %l58, !tbaa !27
  %t85 = load i64, ptr %l11, !tbaa !24
  %t87 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr i32, ptr %t88, i64 %t85
  %t90 = load i32, ptr %t89, !tbaa !33
  %t91 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t91, ptr %l61, !tbaa !27
  %t92 = load i64, ptr %l11, !tbaa !24
  %t94 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr i32, ptr %t95, i64 %t92
  %t97 = load i32, ptr %t96, !tbaa !33
  %t101 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %l3, i32 %t90, i32 %t97)
  store i1 %t101, ptr %l64
  br label %bb18
bb18:
  %t102 = load i1, ptr %l64, !tbaa !21
  %t103 = xor i1 %t102, true
  br i1 %t103, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb23
bb20:
  %t105 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t105, ptr %l68, !tbaa !27
  %t106 = load i64, ptr %l11, !tbaa !24
  %t108 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr i32, ptr %t109, i64 %t106
  %t111 = load i32, ptr %t110, !tbaa !33
  %t114 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %l3, i32 %t111)
  store i64 %t114, ptr %l71
  br label %bb21
bb21:
  %t115 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t115, ptr %l73, !tbaa !27
  %t116 = load i64, ptr %l11, !tbaa !24
  %t118 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr i32, ptr %t119, i64 %t116
  %t121 = load i32, ptr %t120, !tbaa !33
  %t124 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %l3, i32 %t121)
  store i64 %t124, ptr %l76
  br label %bb22
bb22:
  %t125 = load i64, ptr %l71, !tbaa !24
  %t126 = load i64, ptr %l76, !tbaa !24
  %t127 = icmp ne i64 %t125, %t126
  store i1 %t127, ptr %l66, !tbaa !21
  br label %bb23
bb23:
  %t129 = load i1, ptr %l66, !tbaa !21
  br i1 %t129, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t131 = load i64, ptr %l10, !tbaa !24
  %t133 = add i64 %t131, 1
  store i64 %t133, ptr %l10, !tbaa !24
  br label %bb14
bb28:
  store ptr %l3, ptr %l81, !tbaa !29
  %t135 = load i32, ptr %l1, !tbaa !23
  %t138 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %l3, i32 %t135)
  store i32 %t138, ptr %l84
  br label %bb29
bb29:
  %t139 = load i32, ptr %l2, !tbaa !23
  %t142 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %l3, i32 %t139)
  store i32 %t142, ptr %l87
  br label %bb30
bb30:
  %t143 = load ptr, ptr %l81, !tbaa !29
  %t144 = load i32, ptr %l84, !tbaa !23
  %t145 = load i32, ptr %l87, !tbaa !23
  %t146 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t143, i32 %t144, i32 %t145)
  store i1 %t146, ptr %l88
  br label %bb31
bb31:
  %t147 = load i1, ptr %l88, !tbaa !21
  %t148 = xor i1 %t147, true
  br i1 %t148, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  %t151 = load i32, ptr %l1, !tbaa !23
  %t152 = load i32, ptr %l2, !tbaa !23
  %t156 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %l3, i32 %t151, i32 %t152)
  store i1 %t156, ptr %l94
  br label %bb35
bb35:
  %t157 = load i1, ptr %l94, !tbaa !21
  %t158 = xor i1 %t157, true
  br i1 %t158, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l96, !tbaa !21
  br label %bb39
bb37:
  %t160 = load i32, ptr %l2, !tbaa !23
  %t161 = load i32, ptr %l1, !tbaa !23
  %t165 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %l3, i32 %t160, i32 %t161)
  store i1 %t165, ptr %l100
  br label %bb38
bb38:
  %t166 = load i1, ptr %l100, !tbaa !21
  %t167 = xor i1 %t166, true
  store i1 %t167, ptr %l96, !tbaa !21
  br label %bb39
bb39:
  %t169 = load i1, ptr %l96, !tbaa !21
  br i1 %t169, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/check:Checker", ptr %t171, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !29
  %t176 = getelementptr %"compiler/generic:Program", ptr %t174, i32 0, i32 2
  %t177 = load i32, ptr %l1, !tbaa !23
  %t180 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t176, i32 %t177)
  store { i64, ptr } %t180, ptr %l107
  br label %bb43
bb43:
  %t181 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t181, 0
  store i64 %t182, ptr %l108, !tbaa !24
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/check:Checker", ptr %t183, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !29
  %t188 = getelementptr %"compiler/generic:Program", ptr %t186, i32 0, i32 2
  %t189 = load i32, ptr %l2, !tbaa !23
  %t192 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t188, i32 %t189)
  store { i64, ptr } %t192, ptr %l113
  br label %bb44
bb44:
  %t193 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t194 = extractvalue { i64, ptr } %t193, 0
  %t195 = load i64, ptr %l108, !tbaa !24
  %t197 = icmp eq i64 %t195, %t194
  call void @__olang_scope_close(ptr %s0)
  store i1 %t197, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esayUncovered(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i32 %a2, ptr %a3, ptr %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l4 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l14 = alloca i32
  %l17 = alloca %"compiler/source:Span"
  %l20 = alloca i1
  %l24 = alloca i64
  %l29 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l37 = alloca i1
  %l42 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l52 = alloca %"compiler/msgs:Msg"
  %l53 = alloca i64
  %l55 = alloca i64
  %l57 = alloca i1
  %l62 = alloca i32
  %l66 = alloca ptr
  %l71 = alloca i32
  %l72 = alloca { i64, ptr }
  %l73 = alloca i64
  %l75 = alloca i64
  %l76 = alloca i32
  %l79 = alloca i1
  %l84 = alloca ptr
  %l85 = alloca %"compiler/source:Span"
  %l87 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l96 = alloca %"compiler/msgs:Msg"
  %l97 = alloca i64
  %l99 = alloca i1
  %l103 = alloca ptr
  %l109 = alloca %"compiler/source:Span"
  %l112 = alloca { i64, ptr }
  %l114 = alloca %"compiler/msgs:Msg"
  %l115 = alloca i64
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l14
  br label %bb1
bb1:
  %t6 = load i32, ptr %l14, !tbaa !23
  store i32 %t6, ptr %l6, !tbaa !23
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = getelementptr %"compiler/ast:Match", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t10)
  store %"compiler/source:Span" %t12, ptr %l17
  br label %bb2
bb2:
  %t13 = load %"compiler/source:Span", ptr %l17
  store %"compiler/source:Span" %t13, ptr %l7
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l6, !tbaa !23
  %t18 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t14, i32 %t15)
  store i1 %t18, ptr %l20
  br label %bb3
bb3:
  %t19 = load i1, ptr %l20, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l6, !tbaa !23
  %t26 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efirstUncovered(ptr %v0, ptr %v2, ptr %t20, ptr %a3, i32 %t22)
  store i64 %t26, ptr %l24
  br label %bb6
bb5:
  br label %bb21
bb6:
  %t27 = load i64, ptr %l24, !tbaa !24
  store i64 %t27, ptr %l8, !tbaa !24
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  %t34 = load i32, ptr %l6, !tbaa !23
  %t37 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %t33, i32 %t34)
  store { i64, ptr } %t37, ptr %l29
  br label %bb7
bb7:
  %t38 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t38, ptr %l9, !tbaa !27
  %t39 = load i64, ptr %l8, !tbaa !24
  %t41 = icmp sge i64 %t39, 0
  br i1 %t41, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l32, !tbaa !29
  %t44 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t44, ptr %l33
  %t45 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t49 = icmp sgt i64 %t47, 0
  br i1 %t49, label %bb10, label %bb11
bb9:
  br label %bb20
bb10:
  %t51 = load i64, ptr %l8, !tbaa !24
  %t52 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t57 = icmp slt i64 %t51, %t54
  store i1 %t57, ptr %l37, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb12
bb12:
  %t59 = load i1, ptr %l37, !tbaa !21
  br i1 %t59, label %bb13, label %bb14
bb13:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t61, ptr %l44, !tbaa !27
  %t62 = load i64, ptr %l8, !tbaa !24
  %t64 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr i32, ptr %t65, i64 %t62
  %t67 = load i32, ptr %t66, !tbaa !33
  %t70 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t60, i32 %t67)
  store { i64, ptr } %t70, ptr %l47
  br label %bb15
bb14:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, ptr %l42, !tbaa !27
  br label %bb16
bb15:
  %t71 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t71, ptr %l42, !tbaa !27
  br label %bb16
bb16:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i32, ptr %l6, !tbaa !23
  %t76 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t72, i32 %t73)
  store { i64, ptr } %t76, ptr %l50
  br label %bb17
bb17:
  %t77 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t77, 0
  %t79 = extractvalue { i64, ptr } %t77, 1
  %t80 = mul i64 %t78, 1
  %t81 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t80)
  call void @llvm.memcpy.p0.p0.i64(ptr %t81, ptr %t79, i64 %t80, i1 false)
  %t82 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t81, 1
  %t84 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t86 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatchNotExhaustive(ptr %v0, ptr %s2, ptr %s2, { i64, ptr } %t84, { i64, ptr } %t83)
  store %"compiler/msgs:Msg" %t86, ptr %l52
  br label %bb18
bb18:
  %t87 = load ptr, ptr %l32, !tbaa !29
  %t88 = load %"compiler/source:Span", ptr %l33
  %t89 = load %"compiler/msgs:Msg", ptr %l52
  %t90 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t87, %"compiler/source:Span" %t88, %"compiler/msgs:Msg" %t89)
  store i64 %t90, ptr %l53
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  br label %ret
bb21:
  %t91 = load ptr, ptr %l4, !tbaa !29
  %t93 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v3, ptr %t91)
  store i64 %t93, ptr %l55
  br label %bb22
bb22:
  %t94 = load i64, ptr %l55, !tbaa !24
  %t95 = icmp sgt i64 %t94, 0
  br i1 %t95, label %bb23, label %bb24
bb23:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  %t103 = load i32, ptr %l6, !tbaa !23
  %t106 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t102, i32 %t103)
  store i32 %t106, ptr %l62
  br label %bb25
bb24:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb26
bb25:
  %t107 = load i32, ptr %l62, !range !{i32 0, i32 33}
  %t109 = trunc i64 29 to i32
  %t110 = icmp eq i32 %t107, %t109
  store i1 %t110, ptr %l57, !tbaa !21
  br label %bb26
bb26:
  %t112 = load i1, ptr %l57, !tbaa !21
  br i1 %t112, label %bb27, label %bb28
bb27:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/check:Checker", ptr %t113, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !29
  store ptr %t116, ptr %l66, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = getelementptr %"compiler/generic:Program", ptr %t120, i32 0, i32 2
  %t123 = load i32, ptr %l6, !tbaa !23
  %t126 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t122, i32 %t123)
  store i32 %t126, ptr %l71
  br label %bb29
bb28:
  br label %bb45
bb29:
  %t127 = load ptr, ptr %l66, !tbaa !29
  %t128 = load i32, ptr %l71, !tbaa !23
  %t129 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMembers(ptr %v0, ptr %t127, i32 %t128)
  store { i64, ptr } %t129, ptr %l72
  br label %bb30
bb30:
  %t130 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t130, ptr %l10, !tbaa !27
  %t131 = load ptr, ptr %l4, !tbaa !29
  %t133 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eIndexOf_3cBool_3e(ptr %v3, ptr %t131, i1 false)
  %t134 = extractvalue { i32, i64 } %t133, 1
  %t135 = extractvalue { i32, i64 } %t133, 0
  store i32 %t135, ptr %l76
  %t136 = icmp ne i32 %t135, 0
  br i1 %t136, label %bb32, label %ok.137, !prof !99
ok.137:
  store i64 %t134, ptr %l75
  br label %bb31
bb31:
  %t138 = load i64, ptr %l75, !tbaa !24
  store i64 %t138, ptr %l73, !tbaa !24
  br label %bb34
bb32:
  br label %bb33
bb33:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l73, !tbaa !24
  br label %bb34
bb34:
  %t139 = load i64, ptr %l73, !tbaa !24
  store i64 %t139, ptr %l11, !tbaa !24
  %t140 = load i64, ptr %l11, !tbaa !24
  %t142 = icmp sge i64 %t140, 0
  br i1 %t142, label %bb35, label %bb36
bb35:
  %t144 = load i64, ptr %l11, !tbaa !24
  %t145 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t145, 0
  %t150 = icmp slt i64 %t144, %t147
  store i1 %t150, ptr %l79, !tbaa !21
  br label %bb37
bb36:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb37
bb37:
  %t152 = load i1, ptr %l79, !tbaa !21
  br i1 %t152, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s4
  %t153 = load ptr, ptr %l0, !tbaa !29
  store ptr %t153, ptr %l84, !tbaa !29
  %t154 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t154, ptr %l85
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t156, ptr %l87, !tbaa !27
  %t157 = load i64, ptr %l11, !tbaa !24
  %t159 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr i32, ptr %t160, i64 %t157
  %t162 = load i32, ptr %t161, !tbaa !33
  %t165 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s4, ptr %t155, i32 %t162)
  store { i64, ptr } %t165, ptr %l90
  br label %bb40
bb39:
  br label %bb44
bb40:
  %t166 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t167 = extractvalue { i64, ptr } %t166, 0
  %t168 = extractvalue { i64, ptr } %t166, 1
  %t169 = mul i64 %t167, 1
  %t170 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t169)
  call void @llvm.memcpy.p0.p0.i64(ptr %t170, ptr %t168, i64 %t169, i1 false)
  %t171 = insertvalue { i64, ptr } undef, i64 %t167, 0
  %t172 = insertvalue { i64, ptr } %t171, ptr %t170, 1
  store { i64, ptr } %t172, ptr %l91, !tbaa !27
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i32, ptr %l2, !tbaa !23
  %t177 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s4, ptr %t173, i32 %t174)
  store { i64, ptr } %t177, ptr %l94
  br label %bb41
bb41:
  %t178 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t178, 0
  %t180 = extractvalue { i64, ptr } %t178, 1
  %t181 = mul i64 %t179, 1
  %t182 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t181)
  call void @llvm.memcpy.p0.p0.i64(ptr %t182, ptr %t180, i64 %t181, i1 false)
  %t183 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t182, 1
  %t185 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t187 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatchNotExhaustive(ptr %s4, ptr %s4, ptr %s4, { i64, ptr } %t185, { i64, ptr } %t184)
  store %"compiler/msgs:Msg" %t187, ptr %l96
  br label %bb42
bb42:
  %t188 = load ptr, ptr %l84, !tbaa !29
  %t189 = load %"compiler/source:Span", ptr %l85
  %t190 = load %"compiler/msgs:Msg", ptr %l96
  %t191 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t188, %"compiler/source:Span" %t189, %"compiler/msgs:Msg" %t190)
  store i64 %t191, ptr %l97
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s4)
  br label %bb44
bb44:
  br label %ret
bb45:
  br i1 %a5, label %bb46, label %bb47
bb46:
  %t194 = load i32, ptr %l2, !tbaa !23
  %t195 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t198 = icmp ne i32 %t194, %t195
  store i1 %t198, ptr %l99, !tbaa !21
  br label %bb48
bb47:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb48
bb48:
  %t200 = load i1, ptr %l99, !tbaa !21
  br i1 %t200, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s5
  %t201 = load ptr, ptr %l0, !tbaa !29
  store ptr %t201, ptr %l103, !tbaa !29
  %t202 = load ptr, ptr %l1, !tbaa !29
  %t204 = getelementptr %"compiler/ast:Match", ptr %t202, i32 0, i32 0
  %t205 = getelementptr %"compiler/source:Span", ptr %t204, i32 0, i32 0
  %t206 = load i32, ptr %t205, !tbaa !23
  %t207 = load ptr, ptr %l1, !tbaa !29
  %t209 = getelementptr %"compiler/ast:Match", ptr %t207, i32 0, i32 0
  %t210 = getelementptr %"compiler/source:Span", ptr %t209, i32 0, i32 0
  %t211 = load i32, ptr %t210, !tbaa !23
  %t213 = add i32 %t211, 5
  %t216 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s5, i32 %t206, i32 %t213)
  store %"compiler/source:Span" %t216, ptr %l109
  br label %bb51
bb50:
  br label %bb55
bb51:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load i32, ptr %l2, !tbaa !23
  %t221 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t217, i32 %t218)
  store { i64, ptr } %t221, ptr %l112
  br label %bb52
bb52:
  %t222 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t223 = extractvalue { i64, ptr } %t222, 0
  %t224 = extractvalue { i64, ptr } %t222, 1
  %t225 = mul i64 %t223, 1
  %t226 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t225)
  call void @llvm.memcpy.p0.p0.i64(ptr %t226, ptr %t224, i64 %t225, i1 false)
  %t227 = insertvalue { i64, ptr } undef, i64 %t223, 0
  %t228 = insertvalue { i64, ptr } %t227, ptr %t226, 1
  %t230 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatchValueUncovered(ptr %s5, ptr %s5, { i64, ptr } %t228)
  store %"compiler/msgs:Msg" %t230, ptr %l114
  br label %bb53
bb53:
  %t231 = load ptr, ptr %l103, !tbaa !29
  %t232 = load %"compiler/source:Span", ptr %l109
  %t233 = load %"compiler/msgs:Msg", ptr %l114
  %t234 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t231, %"compiler/source:Span" %t232, %"compiler/msgs:Msg" %t233)
  store i64 %t234, ptr %l115
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s5)
  br label %bb55
bb55:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l14 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l27 = alloca i1
  %l33 = alloca %"compiler/check:litv"
  %l35 = alloca i1
  %l39 = alloca %"compiler/check:litv"
  %l44 = alloca i1
  %l45 = alloca i1
  %l49 = alloca %"compiler/check:litv"
  %l51 = alloca i1
  %l54 = alloca i1
  %l55 = alloca i1
  %l58 = alloca i1
  %l59 = alloca i1
  %l63 = alloca %"compiler/check:litv"
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 29}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i1 %t20, ptr %l14
  br label %bb6
bb6:
  %t21 = load i1, ptr %l14, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t23 = load ptr, ptr %l15, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l15, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 29}
  %t29 = icmp eq i64 %t27, 5
  store i1 %t29, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l16, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [5 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t33, i32 0, i32 1
  %t35 = load i32, ptr %t34, !range !{i32 0, i32 96}
  store i32 %t35, ptr %l3
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [5 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l4, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr { i64, [5 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t45, i32 0, i32 3
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l5, !tbaa !29
  br label %bb12
bb11:
  br label %bb41
bb12:
  %t49 = load i32, ptr %l3, !range !{i32 0, i32 96}
  %t51 = trunc i64 88 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb15
bb14:
  %t54 = load i32, ptr %l3, !range !{i32 0, i32 96}
  %t56 = trunc i64 89 to i32
  %t57 = icmp eq i32 %t54, %t56
  store i1 %t57, ptr %l27, !tbaa !21
  br label %bb15
bb15:
  %t59 = load i1, ptr %l27, !tbaa !21
  br i1 %t59, label %bb16, label %bb17
bb16:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l4, !tbaa !29
  %t65 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t60, ptr %t61)
  store %"compiler/check:litv" %t65, ptr %l33
  br label %bb18
bb17:
  br label %bb23
bb18:
  %t66 = getelementptr %"compiler/check:litv", ptr %l33, i32 0, i32 0
  %t67 = load i1, ptr %t66, !tbaa !21
  br i1 %t67, label %bb19, label %bb20
bb19:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load ptr, ptr %l5, !tbaa !29
  %t74 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t69, ptr %t70)
  store %"compiler/check:litv" %t74, ptr %l39
  br label %bb21
bb20:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb22
bb21:
  %t75 = getelementptr %"compiler/check:litv", ptr %l39, i32 0, i32 0
  %t76 = load i1, ptr %t75, !tbaa !21
  %t78 = xor i1 %t76, true
  store i1 %t78, ptr %l35, !tbaa !21
  br label %bb22
bb22:
  %t80 = load i1, ptr %l35, !tbaa !21
  store i1 %t80, ptr %rv
  br label %ret
bb23:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load ptr, ptr %l4, !tbaa !29
  %t85 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v1, ptr %t81, ptr %t82)
  store i1 %t85, ptr %l44
  br label %bb24
bb24:
  %t86 = load i1, ptr %l44, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l5, !tbaa !29
  %t92 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t87, ptr %t88)
  store %"compiler/check:litv" %t92, ptr %l49
  br label %bb27
bb26:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb32
bb27:
  %t93 = getelementptr %"compiler/check:litv", ptr %l49, i32 0, i32 0
  %t94 = load i1, ptr %t93, !tbaa !21
  br i1 %t94, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb31
bb29:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load ptr, ptr %l5, !tbaa !29
  %t100 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v1, ptr %t96, ptr %t97)
  store i1 %t100, ptr %l54
  br label %bb30
bb30:
  %t101 = load i1, ptr %l54, !tbaa !21
  store i1 %t101, ptr %l51, !tbaa !21
  br label %bb31
bb31:
  %t102 = load i1, ptr %l51, !tbaa !21
  store i1 %t102, ptr %l45, !tbaa !21
  br label %bb32
bb32:
  %t103 = load i1, ptr %l45, !tbaa !21
  br i1 %t103, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l55, !tbaa !21
  br label %bb40
bb34:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load ptr, ptr %l5, !tbaa !29
  %t108 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v1, ptr %t104, ptr %t105)
  store i1 %t108, ptr %l58
  br label %bb35
bb35:
  %t109 = load i1, ptr %l58, !tbaa !21
  br i1 %t109, label %bb36, label %bb37
bb36:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load ptr, ptr %l4, !tbaa !29
  %t115 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t110, ptr %t111)
  store %"compiler/check:litv" %t115, ptr %l63
  br label %bb38
bb37:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb39
bb38:
  %t116 = getelementptr %"compiler/check:litv", ptr %l63, i32 0, i32 0
  %t117 = load i1, ptr %t116, !tbaa !21
  store i1 %t117, ptr %l59, !tbaa !21
  br label %bb39
bb39:
  %t119 = load i1, ptr %l59, !tbaa !21
  store i1 %t119, ptr %l55, !tbaa !21
  br label %bb40
bb40:
  %t120 = load i1, ptr %l55, !tbaa !21
  store i1 %t120, ptr %rv
  br label %ret
bb41:
  br i1 true, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  store i1 false, ptr %rv
  br label %ret
bb45:
  call void @__olang_check_failed(ptr @olang_loc_5ec272a16da13ce8_6a23c064ecfaca54)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espellArgs(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l16 = alloca { i64, ptr }
  %l21 = alloca i1
  %l25 = alloca { i64, ptr }
  %l29 = alloca i32
  %l32 = alloca i1
  %l36 = alloca { i64, ptr }
  %l40 = alloca i32
  %l54 = alloca i64
  %l57 = alloca i64
  %l78 = alloca { i64, ptr }
  %l81 = alloca i32
  %l84 = alloca ptr
  %l87 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t6, i32 %a2)
  store { i64, ptr } %t10, ptr %l16
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp sgt i64 %t16, 0
  br i1 %t18, label %bb2, label %bb3
bb2:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 2
  %t26 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t26, ptr %l25, !tbaa !27
  %t27 = load i64, ptr %l4, !tbaa !24
  %t29 = sub i64 %t27, 1
  %t31 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr i32, ptr %t32, i64 %t29
  %t34 = load i32, ptr %t33, !tbaa !33
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t25, i32 %t34)
  store i32 %t37, ptr %l29
  br label %bb4
bb3:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb5
bb4:
  %t38 = load i32, ptr %l29, !range !{i32 0, i32 33}
  %t40 = trunc i64 30 to i32
  %t41 = icmp eq i32 %t38, %t40
  store i1 %t41, ptr %l21, !tbaa !21
  br label %bb5
bb5:
  %t43 = load i1, ptr %l21, !tbaa !21
  br i1 %t43, label %bb6, label %bb7
bb6:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  %t50 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t50, ptr %l36, !tbaa !27
  %t51 = load i64, ptr %l4, !tbaa !24
  %t53 = sub i64 %t51, 1
  %t55 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr i32, ptr %t56, i64 %t53
  %t58 = load i32, ptr %t57, !tbaa !33
  %t61 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %t49, i32 %t58)
  store i32 %t61, ptr %l40
  br label %bb8
bb7:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb9
bb8:
  %t62 = load i32, ptr %l40, !tbaa !23
  %t63 = icmp eq i32 %t62, 0
  store i1 %t63, ptr %l32, !tbaa !21
  br label %bb9
bb9:
  %t65 = load i1, ptr %l32, !tbaa !21
  br i1 %t65, label %bb10, label %bb11
bb10:
  %t66 = load i64, ptr %l4, !tbaa !24
  %t68 = sub i64 %t66, 1
  store i64 %t68, ptr %l4, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t70 = load i64, ptr %l4, !tbaa !24
  %t72 = icmp eq i64 %t70, 0
  br i1 %t72, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  br label %bb15
bb15:
  %t74 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t74, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) })
  br label %bb16
bb16:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 4
  %t79 = load i1, ptr %t78, !tbaa !21
  store i1 %t79, ptr %l5, !tbaa !21
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/check:Checker", ptr %t81, i32 0, i32 4
  store i1 true, ptr %t83, !tbaa !21
  store i64 0, ptr %l6, !tbaa !24
  %t84 = load i64, ptr %l4, !tbaa !24
  store i64 %t84, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t86 = load i64, ptr %l7, !tbaa !24
  %t87 = load i64, ptr %l6, !tbaa !24
  %t90 = icmp sgt i64 %t86, %t87
  br i1 %t90, label %bb17, label %bb18
bb17:
  %t92 = load i64, ptr %l8, !tbaa !24
  %t94 = icmp sgt i64 %t92, 0
  br i1 %t94, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb22
bb19:
  %t96 = load i64, ptr %l7, !tbaa !24
  %t97 = load i64, ptr %l6, !tbaa !24
  %t100 = sub i64 %t96, %t97
  %t101 = load i64, ptr %l8, !tbaa !24
  %t104 = add i64 %t100, %t101
  %t106 = sub i64 %t104, 1
  %t107 = load i64, ptr %l8, !tbaa !24
  %t110 = sdiv i64 %t106, %t107
  store i64 %t110, ptr %l57, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb21
bb21:
  %t112 = load i64, ptr %l57, !tbaa !24
  store i64 %t112, ptr %l54, !tbaa !24
  br label %bb22
bb22:
  %t113 = load i64, ptr %l54, !tbaa !24
  store i64 %t113, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  %t114 = load i64, ptr %l10, !tbaa !24
  %t115 = load i64, ptr %l9, !tbaa !24
  %t118 = icmp slt i64 %t114, %t115
  %t120 = xor i1 %t118, true
  br i1 %t120, label %bb24, label %bb25
bb24:
  br label %bb41
bb25:
  br label %bb26
bb26:
  %t122 = load i64, ptr %l6, !tbaa !24
  %t123 = load i64, ptr %l10, !tbaa !24
  %t124 = load i64, ptr %l8, !tbaa !24
  %t127 = mul i64 %t123, %t124
  %t130 = add i64 %t122, %t127
  store i64 %t130, ptr %l11, !tbaa !24
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/check:Checker", ptr %t132, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t137 = getelementptr %"compiler/generic:Program", ptr %t135, i32 0, i32 2
  %t138 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t138, ptr %l78, !tbaa !27
  %t139 = load i64, ptr %l11, !tbaa !24
  %t141 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = getelementptr i32, ptr %t142, i64 %t139
  %t144 = load i32, ptr %t143, !tbaa !33
  %t147 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t137, i32 %t144)
  store i32 %t147, ptr %l81
  br label %bb27
bb27:
  %t148 = load i32, ptr %l81, !range !{i32 0, i32 33}
  %t150 = trunc i64 30 to i32
  %t151 = icmp eq i32 %t148, %t150
  br i1 %t151, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s5
  %t153 = load ptr, ptr %l1, !tbaa !29
  store ptr %t153, ptr %l84, !tbaa !29
  %t154 = load i64, ptr %l11, !tbaa !24
  %t156 = icmp sgt i64 %t154, 0
  br i1 %t156, label %bb30, label %bb31
bb29:
  %t158 = load i64, ptr %l11, !tbaa !24
  %t160 = icmp sgt i64 %t158, 0
  br i1 %t160, label %bb34, label %bb35
bb30:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l87, !tbaa !27
  br label %bb32
bb31:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d39, i32 0, i32 1) }, ptr %l87, !tbaa !27
  br label %bb32
bb32:
  %t162 = load ptr, ptr %l84, !tbaa !29
  %t163 = load { i64, ptr }, ptr %l87, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s5, ptr %t162, { i64, ptr } %t163)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s5)
  br label %bb38
bb34:
  store %olang.scope zeroinitializer, ptr %s7
  %t164 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s7, ptr %t164, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d40, i32 0, i32 1) })
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_scope_close(ptr %s7)
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load ptr, ptr %l1, !tbaa !29
  %t168 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t168, ptr %l93, !tbaa !27
  %t169 = load i64, ptr %l11, !tbaa !24
  %t171 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !27
  %t173 = getelementptr i32, ptr %t172, i64 %t169
  %t174 = load i32, ptr %t173, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %v1, ptr %t166, ptr %t167, i32 %t174, i1 false)
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t178 = load i64, ptr %l10, !tbaa !24
  %t180 = add i64 %t178, 1
  store i64 %t180, ptr %l10, !tbaa !24
  br label %bb23
bb41:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load i1, ptr %l5, !tbaa !21
  %t186 = getelementptr %"compiler/check:Checker", ptr %t182, i32 0, i32 4
  store i1 %t183, ptr %t186, !tbaa !21
  %t187 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t187, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d41, i32 0, i32 1) })
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc2(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l2 = alloca %"compiler/source:Span"
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l11 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %rv = alloca { i64, ptr }
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 4
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t14 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTextOf(ptr %v0, ptr %t10, i64 %a1)
  store { i64, ptr } %t14, ptr %l8
  br label %bb1
bb1:
  %t15 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t15, ptr %l9, !tbaa !27
  %t16 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t17 = load i32, ptr %t16, !tbaa !23
  %t19 = sext i32 %t17 to i64
  store i64 %t19, ptr %l11, !tbaa !24
  %t20 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t21 = load i32, ptr %t20, !tbaa !23
  %t23 = sext i32 %t21 to i64
  store i64 %t23, ptr %l13, !tbaa !24
  %t24 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 0
  store i64 %t25, ptr %l14, !tbaa !24
  %t26 = load i64, ptr %l11, !tbaa !24
  %t27 = icmp sge i64 %t26, 0
  br i1 %t27, label %bb2, label %bb3
bb2:
  %t29 = load i64, ptr %l11, !tbaa !24
  %t30 = load i64, ptr %l13, !tbaa !24
  %t31 = icmp sle i64 %t29, %t30
  br i1 %t31, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_acadf2af31b93e38_18751a402ed16b84)
  unreachable
bb4:
  %t33 = load i64, ptr %l13, !tbaa !24
  %t34 = load i64, ptr %l14, !tbaa !24
  %t35 = icmp sle i64 %t33, %t34
  br i1 %t35, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_acadf2af31b93e38_18751a402ed16b84)
  unreachable
bb6:
  %t37 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = load i64, ptr %l11, !tbaa !24
  %t40 = load i64, ptr %l13, !tbaa !24
  %t41 = getelementptr i8, ptr %t38, i64 %t39
  %t42 = sub i64 %t40, %t39
  %t43 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t41, 1
  %t46 = extractvalue { i64, ptr } %t44, 1
  %t47 = extractvalue { i64, ptr } %t44, 0
  %t48 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t47)
  call void @olang_textcopy(ptr %t48, ptr %t46, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  store { i64, ptr } %t50, ptr %rv
  br label %ret
bb7:
  call void @__olang_check_failed(ptr @olang_loc_acadf2af31b93e38_18751a402ed16b84)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 50
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp slt i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s1, ptr %s1, ptr %t12, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d42, i32 0, i32 1) }, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d43, i32 0, i32 1) })
  store i32 %t14, ptr %l7
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t15 = load i32, ptr %l7, !tbaa !23
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 50
  store i32 %t15, ptr %t17, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  br label %bb4
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 50
  %t21 = load i32, ptr %t20, !tbaa !23
  store i32 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/check:typeCase" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeCaseOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca %"compiler/generic:Context"
  %l6 = alloca %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce"
  %l7 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l8 = alloca %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce"
  %l9 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i32
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca { i64, ptr }
  %l19 = alloca %"compiler/names:Ref"
  %l20 = alloca i32
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca %"compiler/check:typeCase"
  %l30 = alloca %"compiler/check:typeCase"
  %l31 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l37 = alloca i64
  %l39 = alloca %"compiler/source:Span"
  %l44 = alloca ptr
  %l49 = alloca %"compiler/generic:Context"
  %l52 = alloca %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce"
  %l53 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l55 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l56 = alloca i32
  %l58 = alloca i1
  %l64 = alloca %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce"
  %l65 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l67 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l68 = alloca i32
  %l70 = alloca i1
  %l75 = alloca i64
  %l79 = alloca i64
  %l82 = alloca i64
  %l100 = alloca ptr
  %l103 = alloca i32
  %l110 = alloca i32
  %l118 = alloca i32
  %l122 = alloca ptr
  %l123 = alloca i1
  %l132 = alloca ptr
  %l134 = alloca ptr
  %l138 = alloca %"compiler/names:Ref"
  %l142 = alloca i1
  %l145 = alloca i1
  %l152 = alloca i32
  %l157 = alloca i64
  %l160 = alloca i64
  %l168 = alloca i64
  %l171 = alloca i64
  %l189 = alloca i64
  %l192 = alloca ptr
  %l193 = alloca i64
  %l195 = alloca i64
  %l199 = alloca i32
  %l203 = alloca ptr
  %l204 = alloca i32
  %l209 = alloca i32
  %l210 = alloca i32
  %l213 = alloca i1
  %l214 = alloca i32
  %l216 = alloca i64
  %l219 = alloca %"compiler/check:typeCase"
  %l228 = alloca i32
  %l230 = alloca %"compiler/check:typeCase"
  %l233 = alloca i1
  %l234 = alloca i32
  %l236 = alloca i64
  %l237 = alloca %"compiler/check:typeCase"
  %s0 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca %"compiler/check:typeCase"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l31
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l31
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatternNames(ptr %v0, ptr %v1, ptr %s0, ptr %t3, ptr %t4, ptr %l2, i1 false)
  br label %bb2
bb2:
  %t9 = shl i64 1, 40
  %t11 = sub i64 0, %t9
  store i64 %t11, ptr %l37, !tbaa !24
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t12)
  store %"compiler/source:Span" %t14, ptr %l39
  br label %bb3
bb3:
  %t15 = getelementptr %"compiler/source:Span", ptr %l39, i32 0, i32 0
  %t16 = load i32, ptr %t15, !tbaa !23
  %t18 = sext i32 %t16 to i64
  %t19 = load i64, ptr %l37, !tbaa !24
  %t21 = sub i64 %t19, %t18
  store i64 %t21, ptr %l3, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t23)
  store ptr %t25, ptr %l44
  br label %bb4
bb4:
  %t26 = load ptr, ptr %l44, !tbaa !29
  store ptr %t26, ptr %l4, !tbaa !29
  %t27 = load ptr, ptr %l4, !tbaa !29
  %t29 = getelementptr %"compiler/check:frame", ptr %t27, i32 0, i32 4
  %t30 = getelementptr %"compiler/generic:Context", ptr %t29, i32 0, i32 0
  %t31 = load i64, ptr %t30, !tbaa !24
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = getelementptr %"compiler/check:frame", ptr %t32, i32 0, i32 4
  %t35 = getelementptr %"compiler/generic:Context", ptr %t34, i32 0, i32 1
  %t36 = load i64, ptr %t35, !tbaa !24
  %t39 = call %"compiler/generic:Context" @compiler_2fgeneric_3aContext_2ector(ptr %s0, i64 %t31, i64 %t36)
  store %"compiler/generic:Context" %t39, ptr %l49
  br label %bb5
bb5:
  %t40 = load %"compiler/generic:Context", ptr %l49
  store %"compiler/generic:Context" %t40, ptr %l5
  %t41 = load ptr, ptr %l4, !tbaa !29
  %t43 = getelementptr %"compiler/check:frame", ptr %t41, i32 0, i32 4
  %t44 = getelementptr %"compiler/generic:Context", ptr %t43, i32 0, i32 2
  %t46 = call %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Ha72624ba64524ee3315305b5d1bfb369(ptr %v0, ptr %v0, ptr %t44)
  store %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" %t46, ptr %l52
  br label %bb6
bb6:
  %t47 = load %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce", ptr %l52
  store %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" %t47, ptr %l6
  br label %bb7
bb7:
  %t49 = call { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20co_H6cf169b12565f300e9fe11f1c8d55061(ptr %v0, ptr %l6)
  %t50 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t49, 1
  %t51 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t49, 0
  store i32 %t51, ptr %l56
  %t52 = icmp ne i32 %t51, 0
  br i1 %t52, label %bb9, label %ok.53, !prof !99
ok.53:
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t50, ptr %l55
  br label %bb8
bb8:
  %t54 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l55
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t54, ptr %l53
  br label %bb11
bb9:
  %t55 = load i32, ptr %l56, !tbaa !23
  %t56 = ashr i32 %t55, 16
  %t58 = icmp eq i32 %t56, 1
  store i1 %t58, ptr %l58, !tbaa !21
  br label %bb10
bb10:
  call void @__olang_ert_req_clear()
  br label %bb14
bb11:
  %t59 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l53
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t59, ptr %l7
  %t60 = getelementptr %"compiler/generic:Context", ptr %l5, i32 0, i32 2
  %t61 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l7, i32 0, i32 0
  %t62 = load i32, ptr %t61, !tbaa !23
  %t63 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l7, i32 0, i32 1
  %t64 = load i32, ptr %t63, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %s0, ptr %t60, i32 %t62, i32 %t64)
  br label %bb12
bb12:
  br label %bb13
bb13:
  br label %bb7
bb14:
  %t68 = load ptr, ptr %l4, !tbaa !29
  %t70 = getelementptr %"compiler/check:frame", ptr %t68, i32 0, i32 4
  %t71 = getelementptr %"compiler/generic:Context", ptr %t70, i32 0, i32 3
  %t73 = call %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Ha72624ba64524ee3315305b5d1bfb369(ptr %v0, ptr %v0, ptr %t71)
  store %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" %t73, ptr %l64
  br label %bb15
bb15:
  %t74 = load %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce", ptr %l64
  store %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" %t74, ptr %l8
  br label %bb16
bb16:
  %t76 = call { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20co_H6cf169b12565f300e9fe11f1c8d55061(ptr %v0, ptr %l8)
  %t77 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t76, 1
  %t78 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t76, 0
  store i32 %t78, ptr %l68
  %t79 = icmp ne i32 %t78, 0
  br i1 %t79, label %bb18, label %ok.80, !prof !99
ok.80:
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t77, ptr %l67
  br label %bb17
bb17:
  %t81 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l67
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t81, ptr %l65
  br label %bb20
bb18:
  %t82 = load i32, ptr %l68, !tbaa !23
  %t83 = ashr i32 %t82, 16
  %t85 = icmp eq i32 %t83, 1
  store i1 %t85, ptr %l70, !tbaa !21
  br label %bb19
bb19:
  call void @__olang_ert_req_clear()
  br label %bb23
bb20:
  %t86 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l65
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t86, ptr %l9
  %t87 = getelementptr %"compiler/generic:Context", ptr %l5, i32 0, i32 3
  %t88 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l9, i32 0, i32 0
  %t89 = load i32, ptr %t88, !tbaa !23
  %t90 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l9, i32 0, i32 1
  %t91 = load i32, ptr %t90, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %s0, ptr %t87, i32 %t89, i32 %t91)
  br label %bb21
bb21:
  br label %bb22
bb22:
  br label %bb16
bb23:
  store i64 0, ptr %l10, !tbaa !24
  %t96 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l2)
  store i64 %t96, ptr %l75
  br label %bb24
bb24:
  %t97 = load i64, ptr %l75, !tbaa !24
  store i64 %t97, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t98 = load i64, ptr %l11, !tbaa !24
  %t99 = load i64, ptr %l10, !tbaa !24
  %t102 = icmp sgt i64 %t98, %t99
  br i1 %t102, label %bb25, label %bb26
bb25:
  %t104 = load i64, ptr %l12, !tbaa !24
  %t106 = icmp sgt i64 %t104, 0
  br i1 %t106, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l79, !tbaa !24
  br label %bb30
bb27:
  %t108 = load i64, ptr %l11, !tbaa !24
  %t109 = load i64, ptr %l10, !tbaa !24
  %t112 = sub i64 %t108, %t109
  %t113 = load i64, ptr %l12, !tbaa !24
  %t116 = add i64 %t112, %t113
  %t118 = sub i64 %t116, 1
  %t119 = load i64, ptr %l12, !tbaa !24
  %t122 = sdiv i64 %t118, %t119
  store i64 %t122, ptr %l82, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l82, !tbaa !24
  br label %bb29
bb29:
  %t124 = load i64, ptr %l82, !tbaa !24
  store i64 %t124, ptr %l79, !tbaa !24
  br label %bb30
bb30:
  %t125 = load i64, ptr %l79, !tbaa !24
  store i64 %t125, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb31
bb31:
  %t126 = load i64, ptr %l14, !tbaa !24
  %t127 = load i64, ptr %l13, !tbaa !24
  %t130 = icmp slt i64 %t126, %t127
  %t132 = xor i1 %t130, true
  br i1 %t132, label %bb32, label %bb33
bb32:
  br label %bb39
bb33:
  br label %bb34
bb34:
  %t134 = load i64, ptr %l10, !tbaa !24
  %t135 = load i64, ptr %l14, !tbaa !24
  %t136 = load i64, ptr %l12, !tbaa !24
  %t139 = mul i64 %t135, %t136
  %t142 = add i64 %t134, %t139
  store i64 %t142, ptr %l15, !tbaa !24
  %t144 = getelementptr %"compiler/generic:Context", ptr %l5, i32 0, i32 2
  store ptr %t144, ptr %l100, !tbaa !29
  %t145 = load i64, ptr %l15, !tbaa !24
  %t148 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l2, i64 %t145)
  store i32 %t148, ptr %l103
  br label %bb35
bb35:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/check:Checker", ptr %t149, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !29
  %t154 = getelementptr %"compiler/generic:Program", ptr %t152, i32 0, i32 2
  %t155 = load i64, ptr %l3, !tbaa !24
  %t156 = load i64, ptr %l15, !tbaa !24
  %t157 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t162 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eVar(ptr %v0, ptr %t154, i64 %t155, i64 %t156, i64 %t157)
  store i32 %t162, ptr %l110
  br label %bb36
bb36:
  %t163 = load ptr, ptr %l100, !tbaa !29
  %t164 = load i32, ptr %l103, !tbaa !23
  %t165 = load i32, ptr %l110, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %s0, ptr %t163, i32 %t164, i32 %t165)
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t166 = load i64, ptr %l14, !tbaa !24
  %t168 = add i64 %t166, 1
  store i64 %t168, ptr %l14, !tbaa !24
  br label %bb31
bb39:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/check:Checker", ptr %t170, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !29
  %t174 = load ptr, ptr %l1, !tbaa !29
  %t179 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %s0, ptr %v1, ptr %t173, ptr %l5, ptr %t174)
  store i32 %t179, ptr %l118
  br label %bb40
bb40:
  %t180 = load i32, ptr %l118, !tbaa !23
  store i32 %t180, ptr %l16, !tbaa !23
  %t181 = load i32, ptr %l16, !tbaa !23
  %t182 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t185 = icmp eq i32 %t181, %t182
  br i1 %t185, label %bb41, label %bb42
bb41:
  %t187 = load ptr, ptr %l1, !tbaa !29
  store ptr %t187, ptr %l122, !tbaa !29
  store i1 false, ptr %l123, !tbaa !21
  %t188 = load ptr, ptr %l122, !tbaa !29
  %t189 = icmp ne ptr %t188, null
  br i1 %t189, label %bb43, label %bb44
bb42:
  br label %bb93
bb43:
  %t191 = load ptr, ptr %l122, !tbaa !29
  %t192 = load i64, ptr %t191, !range !{i64 0, i64 7}
  %t194 = icmp eq i64 %t192, 0
  store i1 %t194, ptr %l123, !tbaa !21
  br label %bb44
bb44:
  %t195 = load i1, ptr %l123, !tbaa !21
  br i1 %t195, label %bb45, label %bb46
bb45:
  %t196 = load ptr, ptr %l1, !tbaa !29
  %t198 = getelementptr { i64, [5 x i64] }, ptr %t196, i32 0, i32 1
  %t199 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t198, i32 0, i32 0
  %t200 = load %"compiler/source:Span", ptr %t199
  store %"compiler/source:Span" %t200, ptr %l17
  %t202 = load ptr, ptr %l1, !tbaa !29
  %t204 = getelementptr { i64, [5 x i64] }, ptr %t202, i32 0, i32 1
  %t205 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t204, i32 0, i32 2
  %t206 = load { i64, ptr }, ptr %t205
  store { i64, ptr } %t206, ptr %l18, !tbaa !27
  br label %bb47
bb46:
  br label %bb87
bb47:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/check:Checker", ptr %t208, i32 0, i32 1
  %t211 = load ptr, ptr %t210, !tbaa !29
  %t213 = getelementptr %"compiler/generic:Program", ptr %t211, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !29
  store ptr %t214, ptr %l132, !tbaa !29
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t217 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t215)
  store ptr %t217, ptr %l134
  br label %bb48
bb48:
  %t218 = load ptr, ptr %l134, !tbaa !29
  %t220 = getelementptr %"compiler/check:frame", ptr %t218, i32 0, i32 2
  %t221 = load i64, ptr %t220, !tbaa !24
  %t222 = getelementptr %"compiler/source:Span", ptr %l17, i32 0, i32 0
  %t223 = load i32, ptr %t222, !tbaa !23
  %t224 = load ptr, ptr %l132, !tbaa !29
  %t227 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t224, i64 %t221, i32 %t223)
  store %"compiler/names:Ref" %t227, ptr %l138
  br label %bb49
bb49:
  %t228 = load %"compiler/names:Ref", ptr %l138
  store %"compiler/names:Ref" %t228, ptr %l19
  %t229 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t231 = extractvalue { i64, ptr } %t229, 0
  %t233 = icmp eq i64 %t231, 0
  br i1 %t233, label %bb50, label %bb51
bb50:
  %t235 = getelementptr %"compiler/names:Ref", ptr %l19, i32 0, i32 0
  %t236 = load i32, ptr %t235, !range !{i32 0, i32 9}
  %t238 = trunc i64 4 to i32
  %t239 = icmp eq i32 %t236, %t238
  store i1 %t239, ptr %l142, !tbaa !21
  br label %bb52
bb51:
  store i1 false, ptr %l142, !tbaa !21
  br label %bb52
bb52:
  %t241 = load i1, ptr %l142, !tbaa !21
  br i1 %t241, label %bb53, label %bb54
bb53:
  %t242 = getelementptr %"compiler/names:Ref", ptr %l19, i32 0, i32 2
  %t243 = load i64, ptr %t242, !tbaa !24
  %t245 = icmp sge i64 %t243, 0
  store i1 %t245, ptr %l145, !tbaa !21
  br label %bb55
bb54:
  store i1 false, ptr %l145, !tbaa !21
  br label %bb55
bb55:
  %t247 = load i1, ptr %l145, !tbaa !21
  br i1 %t247, label %bb56, label %bb57
bb56:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t250 = getelementptr %"compiler/check:Checker", ptr %t248, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !29
  %t252 = getelementptr %"compiler/names:Ref", ptr %l19, i32 0, i32 1
  %t253 = load i64, ptr %t252, !tbaa !24
  %t254 = getelementptr %"compiler/names:Ref", ptr %l19, i32 0, i32 2
  %t255 = load i64, ptr %t254, !tbaa !24
  %t259 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t251, i64 %t253, i64 %t255)
  store i32 %t259, ptr %l152
  br label %bb58
bb57:
  br label %bb86
bb58:
  %t260 = load i32, ptr %l152, !tbaa !23
  store i32 %t260, ptr %l20, !tbaa !23
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"compiler/check:Checker", ptr %t261, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !29
  %t266 = getelementptr %"compiler/generic:Program", ptr %t264, i32 0, i32 2
  %t267 = load i32, ptr %l20, !tbaa !23
  %t270 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %t266, i32 %t267)
  store i64 %t270, ptr %l157
  br label %bb59
bb59:
  %t271 = load i64, ptr %l157, !tbaa !24
  store i64 %t271, ptr %l21, !tbaa !24
  %t272 = load i64, ptr %l21, !tbaa !24
  %t274 = icmp sgt i64 %t272, 0
  br i1 %t274, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s11
  %t276 = load i64, ptr %l21, !tbaa !24
  store i64 %t276, ptr %l160, !tbaa !24
  %t277 = load i64, ptr %l160, !tbaa !24
  %t278 = icmp sge i64 %t277, 0
  br i1 %t278, label %bb62, label %bb63
bb61:
  br label %bb85
bb62:
  %t280 = load i64, ptr %l160, !tbaa !24
  %t281 = icmp sle i64 %t280, 2305843009213693951
  br i1 %t281, label %bb64, label %bb65
bb63:
  call void @__olang_check_failed(ptr @olang_loc_894a72349cd7ef67_30624e129d4b77a3)
  unreachable
bb64:
  %t283 = load i64, ptr %l160, !tbaa !24
  %t284 = mul i64 %t283, 4
  %t285 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t284)
  %t286 = insertvalue { i64, ptr } undef, i64 %t283, 0
  %t287 = insertvalue { i64, ptr } %t286, ptr %t285, 1
  store { i64, ptr } %t287, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t289 = load i64, ptr %l21, !tbaa !24
  store i64 %t289, ptr %l24, !tbaa !24
  store i64 1, ptr %l25, !tbaa !24
  %t291 = load i64, ptr %l24, !tbaa !24
  %t292 = load i64, ptr %l23, !tbaa !24
  %t295 = icmp sgt i64 %t291, %t292
  br i1 %t295, label %bb66, label %bb67
bb65:
  call void @__olang_check_failed(ptr @olang_loc_894a72349cd7ef67_30624e129d4b77a3)
  unreachable
bb66:
  %t297 = load i64, ptr %l25, !tbaa !24
  %t299 = icmp sgt i64 %t297, 0
  br i1 %t299, label %bb68, label %bb69
bb67:
  store i64 0, ptr %l168, !tbaa !24
  br label %bb71
bb68:
  %t301 = load i64, ptr %l24, !tbaa !24
  %t302 = load i64, ptr %l23, !tbaa !24
  %t305 = sub i64 %t301, %t302
  %t306 = load i64, ptr %l25, !tbaa !24
  %t309 = add i64 %t305, %t306
  %t311 = sub i64 %t309, 1
  %t312 = load i64, ptr %l25, !tbaa !24
  %t315 = sdiv i64 %t311, %t312
  store i64 %t315, ptr %l171, !tbaa !24
  br label %bb70
bb69:
  store i64 0, ptr %l171, !tbaa !24
  br label %bb70
bb70:
  %t317 = load i64, ptr %l171, !tbaa !24
  store i64 %t317, ptr %l168, !tbaa !24
  br label %bb71
bb71:
  %t318 = load i64, ptr %l168, !tbaa !24
  store i64 %t318, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb72
bb72:
  %t319 = load i64, ptr %l27, !tbaa !24
  %t320 = load i64, ptr %l26, !tbaa !24
  %t323 = icmp slt i64 %t319, %t320
  %t325 = xor i1 %t323, true
  br i1 %t325, label %bb73, label %bb74
bb73:
  br label %bb79
bb74:
  br label %bb75
bb75:
  %t327 = load i64, ptr %l23, !tbaa !24
  %t328 = load i64, ptr %l27, !tbaa !24
  %t329 = load i64, ptr %l25, !tbaa !24
  %t332 = mul i64 %t328, %t329
  %t335 = add i64 %t327, %t332
  store i64 %t335, ptr %l28, !tbaa !24
  %t337 = load i64, ptr %l28, !tbaa !24
  store i64 %t337, ptr %l189, !tbaa !24
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t340 = getelementptr %"compiler/check:Checker", ptr %t338, i32 0, i32 1
  %t341 = load ptr, ptr %t340, !tbaa !29
  %t343 = getelementptr %"compiler/generic:Program", ptr %t341, i32 0, i32 2
  store ptr %t343, ptr %l192, !tbaa !29
  %t344 = load i64, ptr %l3, !tbaa !24
  store i64 %t344, ptr %l193, !tbaa !24
  %t346 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l2)
  store i64 %t346, ptr %l195
  br label %bb76
bb76:
  %t347 = load i64, ptr %l28, !tbaa !24
  %t348 = load i64, ptr %l195, !tbaa !24
  %t350 = add i64 %t348, %t347
  %t351 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t352 = load ptr, ptr %l192, !tbaa !29
  %t353 = load i64, ptr %l193, !tbaa !24
  %t356 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eVar(ptr %v0, ptr %t352, i64 %t353, i64 %t350, i64 %t351)
  store i32 %t356, ptr %l199
  br label %bb77
bb77:
  %t357 = load i32, ptr %l199, !tbaa !23
  %t358 = load i64, ptr %l189, !tbaa !24
  %t359 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t360 = load ptr, ptr %t359, !tbaa !27
  %t361 = getelementptr i32, ptr %t360, i64 %t358
  store i32 %t357, ptr %t361, !tbaa !33
  br label %bb78
bb78:
  %t362 = load i64, ptr %l27, !tbaa !24
  %t364 = add i64 %t362, 1
  store i64 %t364, ptr %l27, !tbaa !24
  br label %bb72
bb79:
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t368 = getelementptr %"compiler/check:Checker", ptr %t366, i32 0, i32 1
  %t369 = load ptr, ptr %t368, !tbaa !29
  store ptr %t369, ptr %l203, !tbaa !29
  %t370 = load i32, ptr %l20, !tbaa !23
  store i32 %t370, ptr %l204, !tbaa !23
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t373 = getelementptr %"compiler/check:Checker", ptr %t371, i32 0, i32 1
  %t374 = load ptr, ptr %t373, !tbaa !29
  %t376 = getelementptr %"compiler/generic:Program", ptr %t374, i32 0, i32 2
  %t377 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t380 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s11, ptr %t376, { i64, ptr } %t377)
  store i32 %t380, ptr %l209
  br label %bb80
bb80:
  %t381 = load ptr, ptr %l203, !tbaa !29
  %t382 = load i32, ptr %l204, !tbaa !23
  %t383 = load i32, ptr %l209, !tbaa !23
  %t384 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstance(ptr %v0, ptr %t381, i32 %t382, i32 %t383)
  store i32 %t384, ptr %l210
  br label %bb81
bb81:
  %t385 = load i32, ptr %l210, !tbaa !23
  store i32 %t385, ptr %l16, !tbaa !23
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t387 = load i32, ptr %l16, !tbaa !23
  %t390 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisTrait(ptr %v0, ptr %t386, i32 %t387)
  store i1 %t390, ptr %l213
  br label %bb82
bb82:
  %t391 = load i32, ptr %l16, !tbaa !23
  store i32 %t391, ptr %l214, !tbaa !23
  %t393 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l2)
  store i64 %t393, ptr %l216
  br label %bb83
bb83:
  %t394 = load i64, ptr %l21, !tbaa !24
  %t395 = load i64, ptr %l216, !tbaa !24
  %t397 = add i64 %t395, %t394
  %t398 = load i1, ptr %l213, !tbaa !21
  %t399 = load i32, ptr %l214, !tbaa !23
  %t401 = call %"compiler/check:typeCase" @compiler_2fcheck_3atypeCase_2ector(ptr %s11, i1 false, i1 %t398, i32 %t399, i64 %t397)
  store %"compiler/check:typeCase" %t401, ptr %l219
  br label %bb84
bb84:
  %t402 = load %"compiler/check:typeCase", ptr %l219
  store %"compiler/check:typeCase" %t402, ptr %l29
  %t403 = load i64, ptr %l3, !tbaa !24
  %t405 = getelementptr %"compiler/check:typeCase", ptr %l29, i32 0, i32 4
  store i64 %t403, ptr %t405, !tbaa !24
  %t406 = getelementptr %"compiler/check:typeCase", ptr %l29, i32 0, i32 5
  store i1 true, ptr %t406, !tbaa !21
  %t407 = load %"compiler/check:typeCase", ptr %l29
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/check:typeCase" %t407, ptr %rv
  br label %ret
bb85:
  br label %bb86
bb86:
  br label %bb92
bb87:
  br i1 true, label %bb88, label %bb89
bb88:
  br label %bb90
bb89:
  br label %bb91
bb90:
  br label %bb92
bb91:
  call void @__olang_check_failed(ptr @olang_loc_e76989fdc5a7d341_eb7bf402fcfc8235)
  unreachable
bb92:
  br label %bb93
bb93:
  %t409 = load i32, ptr %l16, !tbaa !23
  %t410 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t413 = icmp eq i32 %t409, %t410
  br i1 %t413, label %bb94, label %bb95
bb94:
  store %olang.scope zeroinitializer, ptr %s16
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t416 = load ptr, ptr %l1, !tbaa !29
  %t420 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %t415, ptr %t416)
  store i32 %t420, ptr %l228
  br label %bb96
bb95:
  br label %bb98
bb96:
  %t421 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t423 = call %"compiler/check:typeCase" @compiler_2fcheck_3atypeCase_2ector(ptr %s16, i1 false, i1 false, i32 %t421, i64 0)
  store %"compiler/check:typeCase" %t423, ptr %l230
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  %t424 = load %"compiler/check:typeCase", ptr %l230
  store %"compiler/check:typeCase" %t424, ptr %rv
  br label %ret
bb98:
  %t425 = load ptr, ptr %l0, !tbaa !29
  %t426 = load i32, ptr %l16, !tbaa !23
  %t429 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisTrait(ptr %v0, ptr %t425, i32 %t426)
  store i1 %t429, ptr %l233
  br label %bb99
bb99:
  %t430 = load i32, ptr %l16, !tbaa !23
  store i32 %t430, ptr %l234, !tbaa !23
  %t432 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l2)
  store i64 %t432, ptr %l236
  br label %bb100
bb100:
  %t433 = load i1, ptr %l233, !tbaa !21
  %t434 = load i32, ptr %l234, !tbaa !23
  %t435 = load i64, ptr %l236, !tbaa !24
  %t436 = call %"compiler/check:typeCase" @compiler_2fcheck_3atypeCase_2ector(ptr %s0, i1 false, i1 %t433, i32 %t434, i64 %t435)
  store %"compiler/check:typeCase" %t436, ptr %l237
  br label %bb101
bb101:
  %t437 = load %"compiler/check:typeCase", ptr %l237
  store %"compiler/check:typeCase" %t437, ptr %l30
  %t438 = load i64, ptr %l3, !tbaa !24
  %t440 = getelementptr %"compiler/check:typeCase", ptr %l30, i32 0, i32 4
  store i64 %t438, ptr %t440, !tbaa !24
  %t441 = load %"compiler/check:typeCase", ptr %l30
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/check:typeCase" %t441, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:typeCase", ptr %rv
  ret %"compiler/check:typeCase" %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca %"compiler/names:Ref"
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca %"compiler/names:Ref"
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i32
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca i1
  %l26 = alloca ptr
  %l28 = alloca ptr
  %l32 = alloca %"compiler/names:Ref"
  %l37 = alloca i32
  %l41 = alloca i32
  %l45 = alloca i1
  %l48 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca i32
  %l57 = alloca i1
  %l60 = alloca i32
  %l62 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca i32
  %l70 = alloca i1
  %l75 = alloca i32
  %l79 = alloca i1
  %l84 = alloca i32
  %l89 = alloca ptr
  %l90 = alloca i1
  %l97 = alloca ptr
  %l99 = alloca ptr
  %l103 = alloca %"compiler/names:Ref"
  %l106 = alloca i1
  %l109 = alloca ptr
  %l114 = alloca i32
  %l115 = alloca i32
  %l116 = alloca ptr
  %l117 = alloca i1
  %l128 = alloca i32
  %l131 = alloca i1
  %l136 = alloca i32
  %l142 = alloca { i64, ptr }
  %l156 = alloca i32
  %l160 = alloca i32
  %l166 = alloca i1
  %l168 = alloca ptr
  %l172 = alloca %"compiler/source:Span"
  %l173 = alloca { i64, ptr }
  %l175 = alloca %"compiler/source:Span"
  %l178 = alloca { i64, ptr }
  %l183 = alloca { i64, ptr }
  %l187 = alloca i64
  %l189 = alloca i64
  %l190 = alloca %"compiler/msgs:Msg"
  %l191 = alloca i64
  %l194 = alloca ptr
  %l196 = alloca ptr
  %l201 = alloca i32
  %l205 = alloca i1
  %l209 = alloca i1
  %l211 = alloca i1
  %l215 = alloca i1
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca i32
  %t307 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t2 = load ptr, ptr %l16, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l16, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 29}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l17, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l17, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb45
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  store ptr %t28, ptr %l26, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t29)
  store ptr %t31, ptr %l28
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l28, !tbaa !29
  %t34 = getelementptr %"compiler/check:frame", ptr %t32, i32 0, i32 2
  %t35 = load i64, ptr %t34, !tbaa !24
  %t36 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t37 = load i32, ptr %t36, !tbaa !23
  %t38 = load ptr, ptr %l26, !tbaa !29
  %t41 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t38, i64 %t35, i32 %t37)
  store %"compiler/names:Ref" %t41, ptr %l32
  br label %bb7
bb7:
  %t42 = load %"compiler/names:Ref", ptr %l32
  store %"compiler/names:Ref" %t42, ptr %l4
  %t43 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t44 = load i32, ptr %t43, !range !{i32 0, i32 9}
  %t46 = trunc i64 7 to i32
  %t47 = icmp eq i32 %t44, %t46
  br i1 %t47, label %bb8, label %bb9
bb8:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i32, ptr %l3, !tbaa !23
  %t53 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuiltinType(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t53, ptr %l37
  br label %bb10
bb9:
  br label %bb14
bb10:
  %t54 = load i32, ptr %l37, !tbaa !23
  store i32 %t54, ptr %l5, !tbaa !23
  %t55 = load i32, ptr %l5, !tbaa !23
  %t56 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t59 = icmp ne i32 %t55, %t56
  br i1 %t59, label %bb11, label %bb12
bb11:
  %t61 = load i32, ptr %l5, !tbaa !23
  store i32 %t61, ptr %l41, !tbaa !23
  br label %bb13
bb12:
  store i32 -1, ptr %l41, !tbaa !23
  br label %bb13
bb13:
  %t63 = load i32, ptr %l41, !tbaa !23
  store i32 %t63, ptr %rv
  br label %ret
bb14:
  %t64 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t65 = load i32, ptr %t64, !range !{i32 0, i32 9}
  %t67 = trunc i64 4 to i32
  %t68 = icmp eq i32 %t65, %t67
  br i1 %t68, label %bb15, label %bb16
bb15:
  %t70 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 2
  %t71 = load i64, ptr %t70, !tbaa !24
  %t73 = icmp sge i64 %t71, 0
  store i1 %t73, ptr %l45, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb17
bb17:
  %t75 = load i1, ptr %l45, !tbaa !21
  br i1 %t75, label %bb18, label %bb19
bb18:
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l48, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t81 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 1
  %t82 = load i64, ptr %t81, !tbaa !24
  %t83 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 2
  %t84 = load i64, ptr %t83, !tbaa !24
  %t88 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t80, i64 %t82, i64 %t84)
  store i32 %t88, ptr %l53
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t89 = load ptr, ptr %l48, !tbaa !29
  %t90 = load i32, ptr %l53, !tbaa !23
  %t91 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclType(ptr %v0, ptr %t89, i32 %t90)
  store i32 %t91, ptr %l54
  br label %bb21
bb21:
  %t92 = load i32, ptr %l54, !tbaa !23
  store i32 %t92, ptr %rv
  br label %ret
bb22:
  %t93 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t94 = load i32, ptr %t93, !range !{i32 0, i32 9}
  %t96 = trunc i64 8 to i32
  %t97 = icmp eq i32 %t94, %t96
  br i1 %t97, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb25
bb24:
  %t99 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t100 = load i32, ptr %t99, !range !{i32 0, i32 9}
  %t102 = trunc i64 0 to i32
  %t103 = icmp eq i32 %t100, %t102
  store i1 %t103, ptr %l57, !tbaa !21
  br label %bb25
bb25:
  %t105 = load i1, ptr %l57, !tbaa !21
  br i1 %t105, label %bb26, label %bb27
bb26:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t106)
  store ptr %t108, ptr %l62
  br label %bb28
bb27:
  br label %bb44
bb28:
  %t109 = load ptr, ptr %l62, !tbaa !29
  %t111 = getelementptr %"compiler/check:frame", ptr %t109, i32 0, i32 4
  %t112 = getelementptr %"compiler/generic:Context", ptr %t111, i32 0, i32 2
  %t113 = load i32, ptr %l3, !tbaa !23
  %t116 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v0, ptr %t112, i32 %t113)
  %t117 = extractvalue { i32, i32 } %t116, 1
  %t118 = extractvalue { i32, i32 } %t116, 0
  store i32 %t118, ptr %l67
  %t119 = icmp ne i32 %t118, 0
  br i1 %t119, label %bb30, label %ok.120, !prof !99
ok.120:
  store i32 %t117, ptr %l66
  br label %bb29
bb29:
  %t121 = load i32, ptr %l66, !tbaa !23
  store i32 %t121, ptr %l60, !tbaa !23
  br label %bb32
bb30:
  br label %bb31
bb31:
  call void @__olang_ert_req_clear()
  store i32 -1, ptr %l60, !tbaa !23
  br label %bb32
bb32:
  %t122 = load i32, ptr %l60, !tbaa !23
  store i32 %t122, ptr %l6, !tbaa !23
  %t123 = load i32, ptr %l6, !tbaa !23
  %t125 = icmp sge i32 %t123, 0
  br i1 %t125, label %bb33, label %bb34
bb33:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/check:Checker", ptr %t127, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t132 = getelementptr %"compiler/generic:Program", ptr %t130, i32 0, i32 2
  %t133 = load i32, ptr %l6, !tbaa !23
  %t136 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t132, i32 %t133)
  store i32 %t136, ptr %l75
  br label %bb35
bb34:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb36
bb35:
  %t137 = load i32, ptr %l75, !range !{i32 0, i32 33}
  %t139 = trunc i64 26 to i32
  %t140 = icmp eq i32 %t137, %t139
  %t142 = xor i1 %t140, true
  store i1 %t142, ptr %l70, !tbaa !21
  br label %bb36
bb36:
  %t144 = load i1, ptr %l70, !tbaa !21
  br i1 %t144, label %bb37, label %bb38
bb37:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/check:Checker", ptr %t145, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !29
  %t150 = getelementptr %"compiler/generic:Program", ptr %t148, i32 0, i32 2
  %t151 = load i32, ptr %l6, !tbaa !23
  %t154 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t150, i32 %t151)
  store i32 %t154, ptr %l84
  br label %bb39
bb38:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb40
bb39:
  %t155 = load i32, ptr %l84, !range !{i32 0, i32 33}
  %t157 = trunc i64 27 to i32
  %t158 = icmp eq i32 %t155, %t157
  %t160 = xor i1 %t158, true
  store i1 %t160, ptr %l79, !tbaa !21
  br label %bb40
bb40:
  %t162 = load i1, ptr %l79, !tbaa !21
  br i1 %t162, label %bb41, label %bb42
bb41:
  %t163 = load i32, ptr %l6, !tbaa !23
  store i32 %t163, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  br label %bb44
bb44:
  br label %bb117
bb45:
  %t165 = load ptr, ptr %l1, !tbaa !29
  store ptr %t165, ptr %l89, !tbaa !29
  store i1 false, ptr %l90, !tbaa !21
  %t166 = load ptr, ptr %l89, !tbaa !29
  %t167 = icmp ne ptr %t166, null
  br i1 %t167, label %bb46, label %bb47
bb46:
  %t169 = load ptr, ptr %l89, !tbaa !29
  %t170 = load i64, ptr %t169, !range !{i64 0, i64 29}
  %t172 = icmp eq i64 %t170, 15
  store i1 %t172, ptr %l90, !tbaa !21
  br label %bb47
bb47:
  %t173 = load i1, ptr %l90, !tbaa !21
  br i1 %t173, label %bb48, label %bb49
bb48:
  %t174 = load ptr, ptr %l1, !tbaa !29
  %t176 = getelementptr { i64, [5 x i64] }, ptr %t174, i32 0, i32 1
  %t177 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t176, i32 0, i32 0
  %t178 = load %"compiler/source:Span", ptr %t177
  store %"compiler/source:Span" %t178, ptr %l7
  br label %bb50
bb49:
  br label %bb61
bb50:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/check:Checker", ptr %t180, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !29
  %t185 = getelementptr %"compiler/generic:Program", ptr %t183, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !29
  store ptr %t186, ptr %l97, !tbaa !29
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t187)
  store ptr %t189, ptr %l99
  br label %bb51
bb51:
  %t190 = load ptr, ptr %l99, !tbaa !29
  %t192 = getelementptr %"compiler/check:frame", ptr %t190, i32 0, i32 2
  %t193 = load i64, ptr %t192, !tbaa !24
  %t194 = getelementptr %"compiler/source:Span", ptr %l7, i32 0, i32 1
  %t195 = load i32, ptr %t194, !tbaa !23
  %t196 = load ptr, ptr %l97, !tbaa !29
  %t199 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %t196, i64 %t193, i32 %t195)
  store %"compiler/names:Ref" %t199, ptr %l103
  br label %bb52
bb52:
  %t200 = load %"compiler/names:Ref", ptr %l103
  store %"compiler/names:Ref" %t200, ptr %l8
  %t201 = getelementptr %"compiler/names:Ref", ptr %l8, i32 0, i32 0
  %t202 = load i32, ptr %t201, !range !{i32 0, i32 9}
  %t204 = trunc i64 4 to i32
  %t205 = icmp eq i32 %t202, %t204
  br i1 %t205, label %bb53, label %bb54
bb53:
  %t207 = getelementptr %"compiler/names:Ref", ptr %l8, i32 0, i32 2
  %t208 = load i64, ptr %t207, !tbaa !24
  %t210 = icmp sge i64 %t208, 0
  store i1 %t210, ptr %l106, !tbaa !21
  br label %bb55
bb54:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb55
bb55:
  %t212 = load i1, ptr %l106, !tbaa !21
  br i1 %t212, label %bb56, label %bb57
bb56:
  %t213 = load ptr, ptr %l0, !tbaa !29
  store ptr %t213, ptr %l109, !tbaa !29
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/check:Checker", ptr %t214, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !29
  %t218 = getelementptr %"compiler/names:Ref", ptr %l8, i32 0, i32 1
  %t219 = load i64, ptr %t218, !tbaa !24
  %t220 = getelementptr %"compiler/names:Ref", ptr %l8, i32 0, i32 2
  %t221 = load i64, ptr %t220, !tbaa !24
  %t225 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t217, i64 %t219, i64 %t221)
  store i32 %t225, ptr %l114
  br label %bb58
bb57:
  br label %bb60
bb58:
  %t226 = load ptr, ptr %l109, !tbaa !29
  %t227 = load i32, ptr %l114, !tbaa !23
  %t228 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclType(ptr %v0, ptr %t226, i32 %t227)
  store i32 %t228, ptr %l115
  br label %bb59
bb59:
  %t229 = load i32, ptr %l115, !tbaa !23
  store i32 %t229, ptr %rv
  br label %ret
bb60:
  br label %bb117
bb61:
  %t230 = load ptr, ptr %l1, !tbaa !29
  store ptr %t230, ptr %l116, !tbaa !29
  store i1 false, ptr %l117, !tbaa !21
  %t231 = load ptr, ptr %l116, !tbaa !29
  %t232 = icmp ne ptr %t231, null
  br i1 %t232, label %bb62, label %bb63
bb62:
  %t234 = load ptr, ptr %l116, !tbaa !29
  %t235 = load i64, ptr %t234, !range !{i64 0, i64 29}
  %t237 = icmp eq i64 %t235, 14
  store i1 %t237, ptr %l117, !tbaa !21
  br label %bb63
bb63:
  %t238 = load i1, ptr %l117, !tbaa !21
  br i1 %t238, label %bb64, label %bb65
bb64:
  %t239 = load ptr, ptr %l1, !tbaa !29
  %t241 = getelementptr { i64, [5 x i64] }, ptr %t239, i32 0, i32 1
  %t242 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t241, i32 0, i32 0
  %t243 = load %"compiler/source:Span", ptr %t242
  store %"compiler/source:Span" %t243, ptr %l9
  %t245 = load ptr, ptr %l1, !tbaa !29
  %t247 = getelementptr { i64, [5 x i64] }, ptr %t245, i32 0, i32 1
  %t248 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t247, i32 0, i32 1
  %t249 = load ptr, ptr %t248
  store ptr %t249, ptr %l10, !tbaa !29
  %t251 = load ptr, ptr %l1, !tbaa !29
  %t253 = getelementptr { i64, [5 x i64] }, ptr %t251, i32 0, i32 1
  %t254 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t253, i32 0, i32 2
  %t255 = load { i64, ptr }, ptr %t254
  store { i64, ptr } %t255, ptr %l11, !tbaa !27
  br label %bb66
bb65:
  br label %bb112
bb66:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load ptr, ptr %l10, !tbaa !29
  %t261 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericNamed(ptr %v0, ptr %v1, ptr %t257, ptr %t258)
  store i32 %t261, ptr %l128
  br label %bb67
bb67:
  %t262 = load i32, ptr %l128, !tbaa !23
  store i32 %t262, ptr %l12, !tbaa !23
  %t263 = load i32, ptr %l12, !tbaa !23
  %t265 = icmp slt i32 %t263, 0
  br i1 %t265, label %bb68, label %bb69
bb68:
  store i1 true, ptr %l131, !tbaa !21
  br label %bb71
bb69:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/check:Checker", ptr %t267, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !29
  %t272 = getelementptr %"compiler/generic:Program", ptr %t270, i32 0, i32 2
  %t273 = load i32, ptr %l12, !tbaa !23
  %t276 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t272, i32 %t273)
  store i32 %t276, ptr %l136
  br label %bb70
bb70:
  %t277 = load i32, ptr %l136, !range !{i32 0, i32 6}
  %t279 = trunc i64 1 to i32
  %t280 = icmp eq i32 %t277, %t279
  %t282 = xor i1 %t280, true
  store i1 %t282, ptr %l131, !tbaa !21
  br label %bb71
bb71:
  %t284 = load i1, ptr %l131, !tbaa !21
  br i1 %t284, label %bb72, label %bb73
bb72:
  store i32 -1, ptr %rv
  br label %ret
bb73:
  br label %bb74
bb74:
  %t286 = load ptr, ptr %l10, !tbaa !29
  %t288 = call { i64, ptr } @compiler_2fcheck_2etypePathOf(ptr %v1, ptr %t286)
  store { i64, ptr } %t288, ptr %l142
  br label %bb75
bb75:
  %t289 = load { i64, ptr }, ptr %l142, !tbaa !27
  store { i64, ptr } %t289, ptr %l13, !tbaa !27
  %t290 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t292 = extractvalue { i64, ptr } %t290, 0
  %t294 = icmp eq i64 %t292, 0
  br i1 %t294, label %bb76, label %bb77
bb76:
  store i32 -1, ptr %rv
  br label %ret
bb77:
  br label %bb78
bb78:
  %t297 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t299 = extractvalue { i64, ptr } %t297, 0
  %t301 = icmp eq i64 %t299, 1
  br i1 %t301, label %bb79, label %bb80
bb79:
  store %olang.scope zeroinitializer, ptr %s11
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t304 = load %"compiler/source:Span", ptr %l9
  %t305 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t306 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t307
  %t308 = getelementptr { i64, [5 x i64] }, ptr %t307, i32 0, i32 0
  store i64 0, ptr %t308
  %t310 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t304, 0
  %t312 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t310, { i64, ptr } %t305, 1
  %t314 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t312, { i64, ptr } %t306, 2
  %t315 = getelementptr { i64, [5 x i64] }, ptr %t307, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t314, ptr %t315
  %t316 = load { i64, [5 x i64] }, ptr %t307
  %t318 = call ptr @__olang_scope_alloc_a(ptr %s11, i64 48, i64 8)
  store { i64, [5 x i64] } %t316, ptr %t318
  %t321 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %s11, ptr %t303, ptr %t318)
  store i32 %t321, ptr %l156
  br label %bb81
bb80:
  br label %bb85
bb81:
  %t322 = load i32, ptr %l156, !tbaa !23
  store i32 %t322, ptr %l14, !tbaa !23
  %t323 = load i32, ptr %l14, !tbaa !23
  %t324 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t327 = icmp ne i32 %t323, %t324
  br i1 %t327, label %bb82, label %bb83
bb82:
  %t329 = load i32, ptr %l14, !tbaa !23
  store i32 %t329, ptr %l160, !tbaa !23
  br label %bb84
bb83:
  store i32 -1, ptr %l160, !tbaa !23
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s11)
  %t331 = load i32, ptr %l160, !tbaa !23
  store i32 %t331, ptr %rv
  br label %ret
bb85:
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t334 = getelementptr %"compiler/check:Checker", ptr %t332, i32 0, i32 1
  %t335 = load ptr, ptr %t334, !tbaa !29
  %t336 = load i32, ptr %l12, !tbaa !23
  %t337 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t341 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eArgsFit(ptr %v0, ptr %v1, ptr %t335, i32 %t336, { i64, ptr } %t337)
  store i1 %t341, ptr %l166
  br label %bb86
bb86:
  %t342 = load i1, ptr %l166, !tbaa !21
  %t343 = xor i1 %t342, true
  br i1 %t343, label %bb87, label %bb88
bb87:
  store %olang.scope zeroinitializer, ptr %s12
  %t345 = load ptr, ptr %l0, !tbaa !29
  store ptr %t345, ptr %l168, !tbaa !29
  %t346 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t348 = extractvalue { i64, ptr } %t346, 0
  %t350 = icmp sgt i64 %t348, 0
  br i1 %t350, label %bb89, label %bb90
bb88:
  br label %bb98
bb89:
  %t352 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t352, ptr %l173, !tbaa !27
  %t353 = getelementptr { i64, ptr }, ptr %l173, i32 0, i32 1
  %t354 = load ptr, ptr %t353, !tbaa !27
  %t355 = getelementptr ptr, ptr %t354, i64 0
  %t356 = load ptr, ptr %t355, !tbaa !39
  %t358 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t356)
  store %"compiler/source:Span" %t358, ptr %l175
  br label %bb91
bb90:
  %t359 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t359, ptr %l172
  br label %bb92
bb91:
  %t361 = load %"compiler/source:Span", ptr %l175
  store %"compiler/source:Span" %t361, ptr %l172
  br label %bb92
bb92:
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t363 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t363, ptr %l178, !tbaa !27
  %t364 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t366 = extractvalue { i64, ptr } %t364, 0
  %t368 = sub i64 %t366, 1
  %t370 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t371 = load ptr, ptr %t370, !tbaa !27
  %t372 = getelementptr i32, ptr %t371, i64 %t368
  %t373 = load i32, ptr %t372, !tbaa !33
  %t376 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t362, i32 %t373)
  store { i64, ptr } %t376, ptr %l183
  br label %bb93
bb93:
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t379 = getelementptr %"compiler/check:Checker", ptr %t377, i32 0, i32 1
  %t380 = load ptr, ptr %t379, !tbaa !29
  %t381 = load i32, ptr %l12, !tbaa !23
  %t384 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWrittenArity(ptr %v0, ptr %t380, i32 %t381)
  store i64 %t384, ptr %l187
  br label %bb94
bb94:
  %t385 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t387 = call i64 @compiler_2fgeneric_2eWrittenTypes(ptr %v1, { i64, ptr } %t385)
  store i64 %t387, ptr %l189
  br label %bb95
bb95:
  %t388 = load { i64, ptr }, ptr %l183, !tbaa !27
  %t389 = load i64, ptr %l187, !tbaa !24
  %t390 = load i64, ptr %l189, !tbaa !24
  %t391 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgCount(ptr %v0, ptr %s12, { i64, ptr } %t388, i64 %t389, i64 %t390)
  store %"compiler/msgs:Msg" %t391, ptr %l190
  br label %bb96
bb96:
  %t392 = load ptr, ptr %l168, !tbaa !29
  %t393 = load %"compiler/source:Span", ptr %l172
  %t394 = load %"compiler/msgs:Msg", ptr %l190
  %t395 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s12, ptr %t392, %"compiler/source:Span" %t393, %"compiler/msgs:Msg" %t394)
  store i64 %t395, ptr %l191
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s12)
  store i32 -1, ptr %rv
  br label %ret
bb98:
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t399 = getelementptr %"compiler/check:Checker", ptr %t397, i32 0, i32 1
  %t400 = load ptr, ptr %t399, !tbaa !29
  store ptr %t400, ptr %l194, !tbaa !29
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t403 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t401)
  store ptr %t403, ptr %l196
  br label %bb99
bb99:
  %t404 = load ptr, ptr %l196, !tbaa !29
  %t406 = getelementptr %"compiler/check:frame", ptr %t404, i32 0, i32 4
  %t407 = load i32, ptr %l12, !tbaa !23
  %t408 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t409 = load ptr, ptr %l194, !tbaa !29
  %t413 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eApply(ptr %v0, ptr %v0, ptr %v1, ptr %t409, ptr %t406, i32 %t407, { i64, ptr } %t408)
  store i32 %t413, ptr %l201
  br label %bb100
bb100:
  %t414 = load i32, ptr %l201, !tbaa !23
  store i32 %t414, ptr %l15, !tbaa !23
  %t415 = load i32, ptr %l15, !tbaa !23
  %t416 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t419 = icmp eq i32 %t415, %t416
  br i1 %t419, label %bb101, label %bb102
bb101:
  store i1 true, ptr %l205, !tbaa !21
  br label %bb104
bb102:
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t422 = load i32, ptr %l15, !tbaa !23
  %t423 = load %"compiler/source:Span", ptr %l9
  %t427 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesMet(ptr %v0, ptr %t421, i32 %t422, %"compiler/source:Span" %t423)
  store i1 %t427, ptr %l209
  br label %bb103
bb103:
  %t428 = load i1, ptr %l209, !tbaa !21
  %t429 = xor i1 %t428, true
  store i1 %t429, ptr %l205, !tbaa !21
  br label %bb104
bb104:
  %t431 = load i1, ptr %l205, !tbaa !21
  br i1 %t431, label %bb105, label %bb106
bb105:
  store i1 true, ptr %l211, !tbaa !21
  br label %bb108
bb106:
  %t432 = load ptr, ptr %l0, !tbaa !29
  %t434 = getelementptr %"compiler/check:Checker", ptr %t432, i32 0, i32 1
  %t435 = load ptr, ptr %t434, !tbaa !29
  %t436 = load i32, ptr %l15, !tbaa !23
  %t439 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t435, i32 %t436)
  store i1 %t439, ptr %l215
  br label %bb107
bb107:
  %t440 = load i1, ptr %l215, !tbaa !21
  %t441 = xor i1 %t440, true
  store i1 %t441, ptr %l211, !tbaa !21
  br label %bb108
bb108:
  %t443 = load i1, ptr %l211, !tbaa !21
  br i1 %t443, label %bb109, label %bb110
bb109:
  store i32 -1, ptr %rv
  br label %ret
bb110:
  br label %bb111
bb111:
  %t445 = load i32, ptr %l15, !tbaa !23
  store i32 %t445, ptr %rv
  br label %ret
bb112:
  br i1 true, label %bb113, label %bb114
bb113:
  br label %bb115
bb114:
  br label %bb116
bb115:
  br label %bb117
bb116:
  call void @__olang_check_failed(ptr @olang_loc_8b8738bb0f25fa76_719b7d77c23398a)
  unreachable
bb117:
  store i32 -1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunadapted(ptr %v0, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l24 = alloca ptr
  %rv = alloca ptr
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Promote", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  store ptr %t19, ptr %rv
  br label %ret
bb6:
  %t21 = load ptr, ptr %l1, !tbaa !29
  store ptr %t21, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t22 = load ptr, ptr %l13, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t26 = load i64, ptr %t25, !range !{i64 0, i64 18}
  %t28 = icmp eq i64 %t26, 3
  store i1 %t28, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t29 = load i1, ptr %l14, !tbaa !21
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = getelementptr { i64, [5 x i64] }, ptr %t30, i32 0, i32 1
  %t33 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t32, i32 0, i32 0
  %t34 = load %"compiler/source:Span", ptr %t33
  store %"compiler/source:Span" %t34, ptr %l3
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t38, i32 0, i32 2
  %t40 = load ptr, ptr %t39
  store ptr %t40, ptr %l4, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t43 = load %"compiler/source:Span", ptr %l3
  %t44 = load ptr, ptr %l4, !tbaa !29
  %t48 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %a0, %"compiler/source:Span" %t43, ptr %t44)
  store ptr %t48, ptr %l24
  br label %bb12
bb12:
  %t49 = load ptr, ptr %l24, !tbaa !29
  store ptr %t49, ptr %rv
  br label %ret
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t50 = load ptr, ptr %l1, !tbaa !29
  store ptr %t50, ptr %rv
  br label %ret
bb17:
  call void @__olang_check_failed(ptr @olang_loc_1dea4fd8b0797e99_ba26b9776858744d)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  %l36 = alloca i1
  %l43 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a1, ptr %l2, !tbaa !23
  store i64 0, ptr %l3, !tbaa !24
  store i64 32, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t3 = load i64, ptr %l4, !tbaa !24
  %t4 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l5, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l16, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l16, !tbaa !24
  store i64 %t29, ptr %l13, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l13, !tbaa !24
  store i64 %t30, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t31 = load i64, ptr %l7, !tbaa !24
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  br label %bb17
bb9:
  br label %bb10
bb10:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load i64, ptr %l7, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = mul i64 %t40, %t41
  %t47 = add i64 %t39, %t44
  store i64 %t47, ptr %l8, !tbaa !24
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i32, ptr %l2, !tbaa !23
  %t53 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisOver(ptr %v0, ptr %t49, i32 %t50)
  store i1 %t53, ptr %l36
  br label %bb11
bb11:
  %t54 = load i1, ptr %l36, !tbaa !21
  %t55 = xor i1 %t54, true
  br i1 %t55, label %bb12, label %bb13
bb12:
  %t57 = load i32, ptr %l2, !tbaa !23
  store i32 %t57, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  %t65 = load i32, ptr %l2, !tbaa !23
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t64, i32 %t65)
  store i32 %t68, ptr %l43
  br label %bb15
bb15:
  %t69 = load i32, ptr %l43, !tbaa !23
  store i32 %t69, ptr %l2, !tbaa !23
  br label %bb16
bb16:
  %t70 = load i64, ptr %l7, !tbaa !24
  %t72 = add i64 %t70, 1
  store i64 %t72, ptr %l7, !tbaa !24
  br label %bb7
bb17:
  %t74 = load i32, ptr %l2, !tbaa !23
  store i32 %t74, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunpin(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l8 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l4, !tbaa !29
  %t8 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 57
  store %"compiler/source:Span" %a1, ptr %t8
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t9)
  store ptr %t11, ptr %l8
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l8, !tbaa !29
  %t16 = getelementptr %"compiler/check:frame", ptr %t12, i32 0, i32 58
  store i64 %a2, ptr %t16, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrolledCompr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, %"compiler/check:reflList" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca %"compiler/check:reflList"
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i1
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l24 = alloca i32
  %l25 = alloca ptr
  %l28 = alloca %"compiler/source:Span"
  %l30 = alloca { i64, ptr }
  %l33 = alloca i64
  %l39 = alloca i64
  %l42 = alloca i64
  %l60 = alloca ptr
  %l62 = alloca i32
  %l67 = alloca i32
  %l68 = alloca i32
  %l69 = alloca ptr
  %l71 = alloca i32
  %l74 = alloca ptr
  %l76 = alloca i32
  %l78 = alloca i32
  %l79 = alloca i32
  %l87 = alloca i64
  %l90 = alloca ptr
  %l96 = alloca %"compiler/source:Span"
  %l97 = alloca %"compiler/msgs:Msg"
  %l98 = alloca i64
  %l106 = alloca ptr
  %l109 = alloca i1
  %l111 = alloca ptr
  %l113 = alloca ptr
  %l116 = alloca %"compiler/source:Span"
  %l118 = alloca i1
  %l137 = alloca { i64, ptr }
  %l140 = alloca ptr
  %l141 = alloca i32
  %l144 = alloca ptr
  %l146 = alloca i32
  %l148 = alloca i32
  %l149 = alloca i32
  %l150 = alloca %"compiler/source:Span"
  %l151 = alloca i32
  %l152 = alloca i32
  %l153 = alloca { i64, ptr }
  %l157 = alloca i32
  %l159 = alloca %"compiler/typed:Make"
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca ptr
  %t288 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store %"compiler/check:reflList" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t4 = getelementptr %"compiler/ast:Compr", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t8 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store i32 %t8, ptr %l24
  br label %bb1
bb1:
  %t9 = load i32, ptr %l24, !tbaa !23
  store i32 %t9, ptr %l4, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l25, !tbaa !29
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = getelementptr %"compiler/ast:Compr", ptr %t11, i32 0, i32 4
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t14)
  store %"compiler/source:Span" %t16, ptr %l28
  br label %bb2
bb2:
  %t17 = load %"compiler/check:reflList", ptr %l3
  %t18 = load ptr, ptr %l25, !tbaa !29
  %t19 = load %"compiler/source:Span", ptr %l28
  %t21 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistItems(ptr %v0, ptr %s0, ptr %t18, %"compiler/source:Span" %t19, %"compiler/check:reflList" %t17)
  store { i64, ptr } %t21, ptr %l30
  br label %bb3
bb3:
  %t22 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t22, ptr %l5, !tbaa !27
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 36
  %t27 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t25)
  store i64 %t27, ptr %l33
  br label %bb4
bb4:
  %t28 = load i64, ptr %l33, !tbaa !24
  store i64 %t28, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  store i64 %t31, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t33 = load i64, ptr %l9, !tbaa !24
  %t34 = load i64, ptr %l8, !tbaa !24
  %t37 = icmp sgt i64 %t33, %t34
  br i1 %t37, label %bb5, label %bb6
bb5:
  %t39 = load i64, ptr %l10, !tbaa !24
  %t41 = icmp sgt i64 %t39, 0
  br i1 %t41, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb10
bb7:
  %t43 = load i64, ptr %l9, !tbaa !24
  %t44 = load i64, ptr %l8, !tbaa !24
  %t47 = sub i64 %t43, %t44
  %t48 = load i64, ptr %l10, !tbaa !24
  %t51 = add i64 %t47, %t48
  %t53 = sub i64 %t51, 1
  %t54 = load i64, ptr %l10, !tbaa !24
  %t57 = sdiv i64 %t53, %t54
  store i64 %t57, ptr %l42, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb9
bb9:
  %t59 = load i64, ptr %l42, !tbaa !24
  store i64 %t59, ptr %l39, !tbaa !24
  br label %bb10
bb10:
  %t60 = load i64, ptr %l39, !tbaa !24
  store i64 %t60, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb11
bb11:
  %t61 = load i64, ptr %l12, !tbaa !24
  %t62 = load i64, ptr %l11, !tbaa !24
  %t65 = icmp slt i64 %t61, %t62
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb12, label %bb13
bb12:
  br label %bb47
bb13:
  br label %bb14
bb14:
  %t69 = load i64, ptr %l8, !tbaa !24
  %t70 = load i64, ptr %l12, !tbaa !24
  %t71 = load i64, ptr %l10, !tbaa !24
  %t74 = mul i64 %t70, %t71
  %t77 = add i64 %t69, %t74
  store i64 %t77, ptr %l13, !tbaa !24
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l60, !tbaa !29
  %t80 = load ptr, ptr %l2, !tbaa !29
  %t82 = getelementptr %"compiler/ast:Compr", ptr %t80, i32 0, i32 3
  %t83 = load i32, ptr %t82, !tbaa !23
  store i32 %t83, ptr %l62, !tbaa !23
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load %"compiler/check:reflList", ptr %l3
  %t86 = load i64, ptr %l13, !tbaa !24
  %t88 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr i64, ptr %t89, i64 %t86
  %t91 = load i64, ptr %t90, !tbaa !34
  %t95 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescriptor(ptr %v0, ptr %t84, %"compiler/check:reflList" %t85, i64 %t91)
  store i32 %t95, ptr %l67
  br label %bb15
bb15:
  %t96 = load ptr, ptr %l60, !tbaa !29
  %t97 = load i32, ptr %l62, !tbaa !23
  %t98 = load i32, ptr %l67, !tbaa !23
  %t99 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflBind(ptr %v0, ptr %t96, i32 %t97, i32 %t98)
  store i32 %t99, ptr %l68
  br label %bb16
bb16:
  %t100 = load i32, ptr %l68, !tbaa !23
  store i32 %t100, ptr %l14, !tbaa !23
  %t101 = load ptr, ptr %l0, !tbaa !29
  store ptr %t101, ptr %l69, !tbaa !29
  %t102 = load ptr, ptr %l2, !tbaa !29
  %t104 = getelementptr %"compiler/ast:Compr", ptr %t102, i32 0, i32 2
  %t105 = load i32, ptr %t104, !tbaa !23
  store i32 %t105, ptr %l71, !tbaa !23
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/generic:Program", ptr %t109, i32 0, i32 2
  store ptr %t111, ptr %l74, !tbaa !29
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t112)
  store i32 %t114, ptr %l76
  br label %bb17
bb17:
  %t115 = load i64, ptr %l13, !tbaa !24
  %t116 = load ptr, ptr %l74, !tbaa !29
  %t117 = load i32, ptr %l76, !tbaa !23
  %t119 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t116, i32 %t117, i64 %t115)
  store i32 %t119, ptr %l78
  br label %bb18
bb18:
  %t120 = load ptr, ptr %l69, !tbaa !29
  %t121 = load i32, ptr %l71, !tbaa !23
  %t122 = load i32, ptr %l78, !tbaa !23
  %t123 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflBind(ptr %v0, ptr %t120, i32 %t121, i32 %t122)
  store i32 %t123, ptr %l79
  br label %bb19
bb19:
  %t124 = load i32, ptr %l79, !tbaa !23
  store i32 %t124, ptr %l15, !tbaa !23
  store i1 true, ptr %l16, !tbaa !21
  %t125 = load ptr, ptr %l2, !tbaa !29
  %t127 = getelementptr %"compiler/ast:Compr", ptr %t125, i32 0, i32 5
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t130 = icmp eq ptr %t128, null
  %t132 = xor i1 %t130, true
  br i1 %t132, label %bb20, label %bb21
bb20:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load ptr, ptr %l2, !tbaa !29
  %t137 = getelementptr %"compiler/ast:Compr", ptr %t135, i32 0, i32 5
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t141 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDecide(ptr %v0, ptr %v1, ptr %t134, ptr %t138)
  store i64 %t141, ptr %l87
  br label %bb22
bb21:
  br label %bb32
bb22:
  %t142 = load i64, ptr %l87, !tbaa !24
  store i64 %t142, ptr %l17, !tbaa !24
  %t143 = load i64, ptr %l17, !tbaa !24
  %t145 = icmp slt i64 %t143, 0
  br i1 %t145, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  %t147 = load ptr, ptr %l0, !tbaa !29
  store ptr %t147, ptr %l90, !tbaa !29
  %t148 = load ptr, ptr %l2, !tbaa !29
  %t150 = getelementptr %"compiler/ast:Compr", ptr %t148, i32 0, i32 5
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = icmp eq ptr %t151, null
  br i1 %t153, label %bb25, label %bb26
bb24:
  %t155 = load i64, ptr %l17, !tbaa !24
  %t157 = icmp eq i64 %t155, 1
  store i1 %t157, ptr %l16, !tbaa !21
  br label %bb31
bb25:
  call void @__olang_check_failed(ptr @olang_loc_ef99e54d7427d8e6_6c42201a9dddf792)
  unreachable
bb26:
  br label %bb27
bb27:
  %t159 = load ptr, ptr %l2, !tbaa !29
  %t161 = getelementptr %"compiler/ast:Compr", ptr %t159, i32 0, i32 5
  %t162 = load ptr, ptr %t161, !tbaa !29
  %t164 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t162)
  store %"compiler/source:Span" %t164, ptr %l96
  br label %bb28
bb28:
  %t165 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflFilterUndecided(ptr %s4)
  store %"compiler/msgs:Msg" %t165, ptr %l97
  br label %bb29
bb29:
  %t166 = load ptr, ptr %l90, !tbaa !29
  %t167 = load %"compiler/source:Span", ptr %l96
  %t168 = load %"compiler/msgs:Msg", ptr %l97
  %t169 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t166, %"compiler/source:Span" %t167, %"compiler/msgs:Msg" %t168)
  store i64 %t169, ptr %l98
  br label %bb30
bb30:
  store i1 false, ptr %l16, !tbaa !21
  call void @__olang_scope_close(ptr %s4)
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t170 = load i1, ptr %l16, !tbaa !21
  br i1 %t170, label %bb33, label %bb34
bb33:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load ptr, ptr %l2, !tbaa !29
  %t175 = getelementptr %"compiler/ast:Compr", ptr %t173, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !29
  %t177 = load i32, ptr %l4, !tbaa !23
  %t181 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %t172, ptr %t176, i32 %t177)
  store ptr %t181, ptr %l106
  br label %bb35
bb34:
  br label %bb43
bb35:
  %t182 = load ptr, ptr %l106, !tbaa !29
  store ptr %t182, ptr %l18, !tbaa !29
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load i32, ptr %l4, !tbaa !23
  %t187 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t183, i32 %t184)
  store i1 %t187, ptr %l109
  br label %bb36
bb36:
  %t188 = load i1, ptr %l109, !tbaa !21
  %t189 = xor i1 %t188, true
  br i1 %t189, label %bb37, label %bb38
bb37:
  %t191 = load ptr, ptr %l0, !tbaa !29
  store ptr %t191, ptr %l111, !tbaa !29
  %t192 = load ptr, ptr %l18, !tbaa !29
  store ptr %t192, ptr %l113, !tbaa !29
  %t194 = load ptr, ptr %l2, !tbaa !29
  %t196 = getelementptr %"compiler/ast:Compr", ptr %t194, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !29
  %t199 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t197)
  store %"compiler/source:Span" %t199, ptr %l116
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t200 = load i64, ptr @G_2ecompiler_2fcheck_2eRoStored, !tbaa !24
  %t201 = load ptr, ptr %l111, !tbaa !29
  %t202 = load ptr, ptr %l113, !tbaa !29
  %t203 = load %"compiler/source:Span", ptr %l116
  %t205 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v0, ptr %t201, ptr %t202, %"compiler/source:Span" %t203, i64 %t200)
  store i1 %t205, ptr %l118
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/check:Checker", ptr %t206, i32 0, i32 36
  %t209 = load ptr, ptr %l18, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t208, ptr %t209)
  br label %bb42
bb42:
  %t212 = load i64, ptr %l7, !tbaa !24
  %t214 = add i64 %t212, 1
  store i64 %t214, ptr %l7, !tbaa !24
  br label %bb43
bb43:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = load ptr, ptr %l2, !tbaa !29
  %t219 = getelementptr %"compiler/ast:Compr", ptr %t217, i32 0, i32 2
  %t220 = load i32, ptr %t219, !tbaa !23
  %t221 = load i32, ptr %l15, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflUnbind(ptr %v0, ptr %t216, i32 %t220, i32 %t221)
  br label %bb44
bb44:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load ptr, ptr %l2, !tbaa !29
  %t228 = getelementptr %"compiler/ast:Compr", ptr %t226, i32 0, i32 3
  %t229 = load i32, ptr %t228, !tbaa !23
  %t230 = load i32, ptr %l14, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflUnbind(ptr %v0, ptr %t225, i32 %t229, i32 %t230)
  br label %bb45
bb45:
  br label %bb46
bb46:
  %t234 = load i64, ptr %l12, !tbaa !24
  %t236 = add i64 %t234, 1
  store i64 %t236, ptr %l12, !tbaa !24
  br label %bb11
bb47:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/check:Checker", ptr %t238, i32 0, i32 36
  %t241 = load i64, ptr %l6, !tbaa !24
  %t244 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t240, i64 %t241)
  store { i64, ptr } %t244, ptr %l137
  br label %bb48
bb48:
  %t245 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t245, ptr %l19, !tbaa !27
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t248 = getelementptr %"compiler/check:Checker", ptr %t246, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !29
  %t251 = getelementptr %"compiler/generic:Program", ptr %t249, i32 0, i32 2
  store ptr %t251, ptr %l140, !tbaa !29
  %t252 = load i32, ptr %l4, !tbaa !23
  store i32 %t252, ptr %l141, !tbaa !23
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/check:Checker", ptr %t253, i32 0, i32 1
  %t256 = load ptr, ptr %t255, !tbaa !29
  %t258 = getelementptr %"compiler/generic:Program", ptr %t256, i32 0, i32 2
  store ptr %t258, ptr %l144, !tbaa !29
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t261 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t259)
  store i32 %t261, ptr %l146
  br label %bb49
bb49:
  %t262 = load i64, ptr %l7, !tbaa !24
  %t263 = load ptr, ptr %l144, !tbaa !29
  %t264 = load i32, ptr %l146, !tbaa !23
  %t266 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t263, i32 %t264, i64 %t262)
  store i32 %t266, ptr %l148
  br label %bb50
bb50:
  %t267 = load ptr, ptr %l140, !tbaa !29
  %t268 = load i32, ptr %l141, !tbaa !23
  %t269 = load i32, ptr %l148, !tbaa !23
  %t270 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t267, i32 %t268, i32 %t269)
  store i32 %t270, ptr %l149
  br label %bb51
bb51:
  %t271 = load i32, ptr %l149, !tbaa !23
  %t272 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t272, ptr %l150
  store i32 %t271, ptr %l151, !tbaa !23
  store i32 2, ptr %l152
  %t274 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t274, ptr %l153, !tbaa !27
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t276 = load %"compiler/source:Span", ptr %l1
  %t280 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t275, i32 1, %"compiler/source:Span" %t276)
  store i32 %t280, ptr %l157
  br label %bb52
bb52:
  %t281 = load i32, ptr %l152, !range !{i32 0, i32 4}
  %t282 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t283 = load i32, ptr %l157, !tbaa !23
  %t285 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t281, i64 0, { i64, ptr } %t282, ptr null, i32 %t283, i32 0, i1 false)
  store %"compiler/typed:Make" %t285, ptr %l159
  br label %bb53
bb53:
  %t286 = load %"compiler/typed:Make", ptr %l159
  %t287 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/typed:Make" %t286, ptr %t287
  store { i64, [5 x i64] } zeroinitializer, ptr %t288
  %t289 = getelementptr { i64, [5 x i64] }, ptr %t288, i32 0, i32 0
  store i64 7, ptr %t289
  %t290 = load %"compiler/source:Span", ptr %l150
  %t291 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t290, 0
  %t292 = load i32, ptr %l151, !tbaa !23
  %t293 = insertvalue { %"compiler/source:Span", i32, ptr } %t291, i32 %t292, 1
  %t295 = insertvalue { %"compiler/source:Span", i32, ptr } %t293, ptr %t287, 2
  %t296 = getelementptr { i64, [5 x i64] }, ptr %t288, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t295, ptr %t296
  %t297 = load { i64, [5 x i64] }, ptr %t288
  %t299 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t297, ptr %t299
  call void @__olang_scope_close(ptr %s0)
  store ptr %t299, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarsIn(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2, { i64, ptr } %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i1
  %l28 = alloca i32
  %l35 = alloca i64
  %l38 = alloca i1
  %l43 = alloca i64
  %l47 = alloca { i64, ptr }
  %l52 = alloca i64
  %l57 = alloca ptr
  %l62 = alloca i32
  %l63 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l83 = alloca ptr
  %l88 = alloca i32
  %l97 = alloca i32
  %l99 = alloca ptr
  %l104 = alloca i32
  %l111 = alloca ptr
  %l116 = alloca i32
  %l125 = alloca ptr
  %l130 = alloca i32
  %l131 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l149 = alloca ptr
  %l154 = alloca i32
  %l165 = alloca ptr
  %l170 = alloca i32
  %l171 = alloca { i64, ptr }
  %l178 = alloca { i64, ptr }
  %l191 = alloca ptr
  %l196 = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l4, !tbaa !24
  %t3 = icmp sgt i64 %t1, 32
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t5, %t6
  store i1 %t9, ptr %l20, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l20, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %l1, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l28
  br label %bb7
bb7:
  %t22 = load i32, ptr %l28, !range !{i32 0, i32 33}
  store i32 %t22, ptr %l5
  %t23 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t25 = trunc i64 25 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb20
bb10:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  %t34 = load i32, ptr %l1, !tbaa !23
  %t37 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t33, i32 %t34)
  store i64 %t37, ptr %l35
  br label %bb11
bb11:
  %t38 = load i64, ptr %l2, !tbaa !24
  %t39 = load i64, ptr %l35, !tbaa !24
  %t41 = icmp eq i64 %t39, %t38
  br i1 %t41, label %bb12, label %bb13
bb12:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 2
  %t49 = load i32, ptr %l1, !tbaa !23
  %t52 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t48, i32 %t49)
  store i64 %t52, ptr %l43
  br label %bb14
bb13:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb15
bb14:
  %t53 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t56 = load i64, ptr %l43, !tbaa !24
  %t58 = icmp slt i64 %t56, %t55
  store i1 %t58, ptr %l38, !tbaa !21
  br label %bb15
bb15:
  %t60 = load i1, ptr %l38, !tbaa !21
  br i1 %t60, label %bb16, label %bb17
bb16:
  %t61 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t61, ptr %l47, !tbaa !27
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %l1, !tbaa !23
  %t71 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t67, i32 %t68)
  store i64 %t71, ptr %l52
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t72 = load i64, ptr %l52, !tbaa !24
  %t73 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr i1, ptr %t74, i64 %t72
  store i1 true, ptr %t75, !tbaa !31
  br label %bb19
bb19:
  br label %bb92
bb20:
  %t76 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t78 = trunc i64 18 to i32
  %t79 = icmp eq i32 %t76, %t78
  br i1 %t79, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb33
bb23:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/check:Checker", ptr %t81, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t86 = getelementptr %"compiler/generic:Program", ptr %t84, i32 0, i32 2
  store ptr %t86, ptr %l57, !tbaa !29
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/check:Checker", ptr %t87, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t92 = getelementptr %"compiler/generic:Program", ptr %t90, i32 0, i32 2
  %t93 = load i32, ptr %l1, !tbaa !23
  %t96 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t92, i32 %t93)
  store i32 %t96, ptr %l62
  br label %bb24
bb24:
  %t97 = load ptr, ptr %l57, !tbaa !29
  %t98 = load i32, ptr %l62, !tbaa !23
  %t99 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t97, i32 %t98)
  store { i64, ptr } %t99, ptr %l63
  br label %bb25
bb25:
  %t100 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t100, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t101 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t101, 0
  store i64 %t103, ptr %l8, !tbaa !24
  br label %bb26
bb26:
  %t105 = load i64, ptr %l7, !tbaa !24
  %t106 = load i64, ptr %l8, !tbaa !24
  %t109 = icmp slt i64 %t105, %t106
  %t111 = xor i1 %t109, true
  br i1 %t111, label %bb27, label %bb28
bb27:
  br label %bb32
bb28:
  br label %bb29
bb29:
  %t113 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t113, ptr %l70, !tbaa !27
  %t114 = load i64, ptr %l7, !tbaa !24
  %t116 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr i32, ptr %t117, i64 %t114
  %t119 = load i32, ptr %t118, !tbaa !33
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = load i64, ptr %l2, !tbaa !24
  %t124 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t125 = load i64, ptr %l4, !tbaa !24
  %t127 = add i64 %t125, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarsIn(ptr %v0, ptr %v1, ptr %t121, i32 %t119, i64 %t123, { i64, ptr } %t124, i64 %t127)
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t133 = load i64, ptr %l7, !tbaa !24
  %t135 = add i64 %t133, 1
  store i64 %t135, ptr %l7, !tbaa !24
  br label %bb26
bb32:
  br label %bb92
bb33:
  %t137 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t139 = trunc i64 19 to i32
  %t140 = icmp eq i32 %t137, %t139
  br i1 %t140, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb45
bb36:
  %t142 = load ptr, ptr %l0, !tbaa !29
  store ptr %t142, ptr %l83, !tbaa !29
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/check:Checker", ptr %t143, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t148 = getelementptr %"compiler/generic:Program", ptr %t146, i32 0, i32 2
  %t149 = load i32, ptr %l1, !tbaa !23
  %t152 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t148, i32 %t149)
  store i32 %t152, ptr %l88
  br label %bb37
bb37:
  %t153 = load i64, ptr %l2, !tbaa !24
  %t154 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t155 = load i64, ptr %l4, !tbaa !24
  %t157 = add i64 %t155, 1
  %t158 = load ptr, ptr %l83, !tbaa !29
  %t159 = load i32, ptr %l88, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarsIn(ptr %v0, ptr %v1, ptr %t158, i32 %t159, i64 %t153, { i64, ptr } %t154, i64 %t157)
  br label %bb38
bb38:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/check:Checker", ptr %t163, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !29
  %t168 = getelementptr %"compiler/generic:Program", ptr %t166, i32 0, i32 2
  %t169 = load i32, ptr %l1, !tbaa !23
  %t172 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t168, i32 %t169)
  store i32 %t172, ptr %l97
  br label %bb39
bb39:
  %t173 = load i32, ptr %l97, !tbaa !23
  %t174 = icmp ne i32 %t173, 0
  br i1 %t174, label %bb40, label %bb41
bb40:
  %t176 = load ptr, ptr %l0, !tbaa !29
  store ptr %t176, ptr %l99, !tbaa !29
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/check:Checker", ptr %t177, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !29
  %t182 = getelementptr %"compiler/generic:Program", ptr %t180, i32 0, i32 2
  %t183 = load i32, ptr %l1, !tbaa !23
  %t186 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t182, i32 %t183)
  store i32 %t186, ptr %l104
  br label %bb42
bb41:
  br label %bb44
bb42:
  %t187 = load i64, ptr %l2, !tbaa !24
  %t188 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t189 = load i64, ptr %l4, !tbaa !24
  %t191 = add i64 %t189, 1
  %t192 = load ptr, ptr %l99, !tbaa !29
  %t193 = load i32, ptr %l104, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarsIn(ptr %v0, ptr %v1, ptr %t192, i32 %t193, i64 %t187, { i64, ptr } %t188, i64 %t191)
  br label %bb43
bb43:
  br label %bb44
bb44:
  br label %bb92
bb45:
  %t197 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t199 = trunc i64 20 to i32
  %t200 = icmp eq i32 %t197, %t199
  br i1 %t200, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb51
bb48:
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l111, !tbaa !29
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/check:Checker", ptr %t203, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !29
  %t208 = getelementptr %"compiler/generic:Program", ptr %t206, i32 0, i32 2
  %t209 = load i32, ptr %l1, !tbaa !23
  %t212 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t208, i32 %t209)
  store i32 %t212, ptr %l116
  br label %bb49
bb49:
  %t213 = load i64, ptr %l2, !tbaa !24
  %t214 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t215 = load i64, ptr %l4, !tbaa !24
  %t217 = add i64 %t215, 1
  %t218 = load ptr, ptr %l111, !tbaa !29
  %t219 = load i32, ptr %l116, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarsIn(ptr %v0, ptr %v1, ptr %t218, i32 %t219, i64 %t213, { i64, ptr } %t214, i64 %t217)
  br label %bb50
bb50:
  br label %bb92
bb51:
  %t223 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t225 = trunc i64 21 to i32
  %t226 = icmp eq i32 %t223, %t225
  br i1 %t226, label %bb52, label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb66
bb54:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/check:Checker", ptr %t228, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !29
  %t233 = getelementptr %"compiler/generic:Program", ptr %t231, i32 0, i32 2
  store ptr %t233, ptr %l125, !tbaa !29
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"compiler/check:Checker", ptr %t234, i32 0, i32 1
  %t237 = load ptr, ptr %t236, !tbaa !29
  %t239 = getelementptr %"compiler/generic:Program", ptr %t237, i32 0, i32 2
  %t240 = load i32, ptr %l1, !tbaa !23
  %t243 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t239, i32 %t240)
  store i32 %t243, ptr %l130
  br label %bb55
bb55:
  %t244 = load ptr, ptr %l125, !tbaa !29
  %t245 = load i32, ptr %l130, !tbaa !23
  %t246 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t244, i32 %t245)
  store { i64, ptr } %t246, ptr %l131
  br label %bb56
bb56:
  %t247 = load { i64, ptr }, ptr %l131, !tbaa !27
  store { i64, ptr } %t247, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t248 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t250 = extractvalue { i64, ptr } %t248, 0
  store i64 %t250, ptr %l12, !tbaa !24
  br label %bb57
bb57:
  %t252 = load i64, ptr %l11, !tbaa !24
  %t253 = load i64, ptr %l12, !tbaa !24
  %t256 = icmp slt i64 %t252, %t253
  %t258 = xor i1 %t256, true
  br i1 %t258, label %bb58, label %bb59
bb58:
  br label %bb63
bb59:
  br label %bb60
bb60:
  %t260 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t260, ptr %l138, !tbaa !27
  %t261 = load i64, ptr %l11, !tbaa !24
  %t263 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !27
  %t265 = getelementptr i32, ptr %t264, i64 %t261
  %t266 = load i32, ptr %t265, !tbaa !33
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = load i64, ptr %l2, !tbaa !24
  %t271 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t272 = load i64, ptr %l4, !tbaa !24
  %t274 = add i64 %t272, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarsIn(ptr %v0, ptr %v1, ptr %t268, i32 %t266, i64 %t270, { i64, ptr } %t271, i64 %t274)
  br label %bb61
bb61:
  br label %bb62
bb62:
  %t280 = load i64, ptr %l11, !tbaa !24
  %t282 = add i64 %t280, 1
  store i64 %t282, ptr %l11, !tbaa !24
  br label %bb57
bb63:
  %t284 = load ptr, ptr %l0, !tbaa !29
  store ptr %t284, ptr %l149, !tbaa !29
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t287 = getelementptr %"compiler/check:Checker", ptr %t285, i32 0, i32 1
  %t288 = load ptr, ptr %t287, !tbaa !29
  %t290 = getelementptr %"compiler/generic:Program", ptr %t288, i32 0, i32 2
  %t291 = load i32, ptr %l1, !tbaa !23
  %t294 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t290, i32 %t291)
  store i32 %t294, ptr %l154
  br label %bb64
bb64:
  %t295 = load i64, ptr %l2, !tbaa !24
  %t296 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t297 = load i64, ptr %l4, !tbaa !24
  %t299 = add i64 %t297, 1
  %t300 = load ptr, ptr %l149, !tbaa !29
  %t301 = load i32, ptr %l154, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarsIn(ptr %v0, ptr %v1, ptr %t300, i32 %t301, i64 %t295, { i64, ptr } %t296, i64 %t299)
  br label %bb65
bb65:
  br label %bb92
bb66:
  %t305 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t307 = trunc i64 22 to i32
  %t308 = icmp eq i32 %t305, %t307
  br i1 %t308, label %bb67, label %bb68
bb67:
  br label %bb71
bb68:
  %t310 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t312 = trunc i64 23 to i32
  %t313 = icmp eq i32 %t310, %t312
  br i1 %t313, label %bb69, label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb81
bb71:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t317 = getelementptr %"compiler/check:Checker", ptr %t315, i32 0, i32 1
  %t318 = load ptr, ptr %t317, !tbaa !29
  %t320 = getelementptr %"compiler/generic:Program", ptr %t318, i32 0, i32 2
  store ptr %t320, ptr %l165, !tbaa !29
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t323 = getelementptr %"compiler/check:Checker", ptr %t321, i32 0, i32 1
  %t324 = load ptr, ptr %t323, !tbaa !29
  %t326 = getelementptr %"compiler/generic:Program", ptr %t324, i32 0, i32 2
  %t327 = load i32, ptr %l1, !tbaa !23
  %t330 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t326, i32 %t327)
  store i32 %t330, ptr %l170
  br label %bb72
bb72:
  %t331 = load ptr, ptr %l165, !tbaa !29
  %t332 = load i32, ptr %l170, !tbaa !23
  %t333 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t331, i32 %t332)
  store { i64, ptr } %t333, ptr %l171
  br label %bb73
bb73:
  %t334 = load { i64, ptr }, ptr %l171, !tbaa !27
  store { i64, ptr } %t334, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t335 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t337 = extractvalue { i64, ptr } %t335, 0
  store i64 %t337, ptr %l16, !tbaa !24
  br label %bb74
bb74:
  %t339 = load i64, ptr %l15, !tbaa !24
  %t340 = load i64, ptr %l16, !tbaa !24
  %t343 = icmp slt i64 %t339, %t340
  %t345 = xor i1 %t343, true
  br i1 %t345, label %bb75, label %bb76
bb75:
  br label %bb80
bb76:
  br label %bb77
bb77:
  %t347 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t347, ptr %l178, !tbaa !27
  %t348 = load i64, ptr %l15, !tbaa !24
  %t350 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t351 = load ptr, ptr %t350, !tbaa !27
  %t352 = getelementptr i32, ptr %t351, i64 %t348
  %t353 = load i32, ptr %t352, !tbaa !33
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t357 = load i64, ptr %l2, !tbaa !24
  %t358 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t359 = load i64, ptr %l4, !tbaa !24
  %t361 = add i64 %t359, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarsIn(ptr %v0, ptr %v1, ptr %t355, i32 %t353, i64 %t357, { i64, ptr } %t358, i64 %t361)
  br label %bb78
bb78:
  br label %bb79
bb79:
  %t367 = load i64, ptr %l15, !tbaa !24
  %t369 = add i64 %t367, 1
  store i64 %t369, ptr %l15, !tbaa !24
  br label %bb74
bb80:
  br label %bb92
bb81:
  %t371 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t373 = trunc i64 29 to i32
  %t374 = icmp eq i32 %t371, %t373
  br i1 %t374, label %bb82, label %bb83
bb82:
  br label %bb84
bb83:
  br label %bb87
bb84:
  %t376 = load ptr, ptr %l0, !tbaa !29
  store ptr %t376, ptr %l191, !tbaa !29
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t379 = getelementptr %"compiler/check:Checker", ptr %t377, i32 0, i32 1
  %t380 = load ptr, ptr %t379, !tbaa !29
  %t382 = getelementptr %"compiler/generic:Program", ptr %t380, i32 0, i32 2
  %t383 = load i32, ptr %l1, !tbaa !23
  %t386 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t382, i32 %t383)
  store i32 %t386, ptr %l196
  br label %bb85
bb85:
  %t387 = load i64, ptr %l2, !tbaa !24
  %t388 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t389 = load i64, ptr %l4, !tbaa !24
  %t391 = add i64 %t389, 1
  %t392 = load ptr, ptr %l191, !tbaa !29
  %t393 = load i32, ptr %l196, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarsIn(ptr %v0, ptr %v1, ptr %t392, i32 %t393, i64 %t387, { i64, ptr } %t388, i64 %t391)
  br label %bb86
bb86:
  br label %bb92
bb87:
  br i1 true, label %bb88, label %bb89
bb88:
  br label %bb90
bb89:
  br label %bb91
bb90:
  br label %bb92
bb91:
  call void @__olang_check_failed(ptr @olang_loc_cf2444207f491a80_6c107d983071089c)
  unreachable
bb92:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIter(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i64 %a4, ptr %a5, i32 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, i64, i64 }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca %"compiler/source:Span"
  %l23 = alloca i32
  %l24 = alloca i64
  %l27 = alloca i1
  %l29 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l48 = alloca ptr
  %l50 = alloca %"compiler/typed:Local"
  %l54 = alloca ptr
  %l56 = alloca ptr
  %l62 = alloca %"compiler/check:heldCand"
  %l74 = alloca ptr
  %l75 = alloca %"compiler/source:Span"
  %l77 = alloca i32
  %l78 = alloca i64
  %l79 = alloca ptr
  %l80 = alloca %"compiler/source:Span"
  %l83 = alloca i32
  %l84 = alloca ptr
  %l85 = alloca %"compiler/source:Span"
  %l87 = alloca i32
  %l88 = alloca ptr
  %l93 = alloca i64
  %l97 = alloca { i64, i64, i64 }
  %l102 = alloca ptr
  %l107 = alloca ptr
  %l111 = alloca ptr
  %l112 = alloca %"compiler/source:Span"
  %l113 = alloca i64
  %l117 = alloca ptr
  %l121 = alloca ptr
  %l126 = alloca ptr
  %l136 = alloca i64
  %l138 = alloca ptr
  %l141 = alloca i64
  %l142 = alloca i32
  %l143 = alloca i64
  %l145 = alloca ptr
  %l148 = alloca i64
  %l149 = alloca i32
  %l155 = alloca ptr
  %l156 = alloca ptr
  %l157 = alloca %"compiler/source:Span"
  %l158 = alloca ptr
  %l162 = alloca ptr
  %s4 = alloca %olang.scope
  %t100 = alloca { i64, [3 x i64] }, align 8
  %t146 = alloca { i64, [3 x i64] }, align 8
  %t300 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l19, !tbaa !29
  %t2 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t2, ptr %l20
  %t3 = load ptr, ptr %l3, !tbaa !29
  %t6 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t3)
  store i32 %t6, ptr %l23
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l19, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l20
  %t9 = load i32, ptr %l23, !tbaa !23
  %t10 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t7, %"compiler/source:Span" %t8, i32 %t9)
  store i64 %t10, ptr %l24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l24, !tbaa !24
  store i64 %t11, ptr %l7, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load ptr, ptr %l3, !tbaa !29
  %t16 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egeneratorCall(ptr %v0, ptr %t12, ptr %t13)
  store i1 %t16, ptr %l27
  br label %bb3
bb3:
  %t17 = load i1, ptr %l27, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t18)
  store ptr %t20, ptr %l29
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t21 = load ptr, ptr %l29, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Body", ptr %t21, i32 0, i32 19
  %t24 = load i64, ptr %l7, !tbaa !24
  %t26 = trunc i64 %t24 to i32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ePush_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t23, i32 %t26)
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t30 = load ptr, ptr %l3, !tbaa !29
  store ptr %t30, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t31 = load ptr, ptr %l35, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t34 = load ptr, ptr %l35, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 18}
  %t37 = icmp eq i64 %t35, 2
  store i1 %t37, ptr %l36, !tbaa !21
  br label %bb10
bb10:
  %t38 = load i1, ptr %l36, !tbaa !21
  br i1 %t38, label %bb11, label %bb12
bb11:
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr { i64, [5 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t41, i32 0, i32 2
  %t43 = load ptr, ptr %t42
  store ptr %t43, ptr %l8, !tbaa !29
  br label %bb13
bb12:
  br label %bb33
bb13:
  %t45 = load ptr, ptr %l8, !tbaa !29
  store ptr %t45, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t46 = load ptr, ptr %l41, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb14, label %bb15
bb14:
  %t49 = load ptr, ptr %l41, !tbaa !29
  %t50 = load i64, ptr %t49, !range !{i64 0, i64 8}
  %t52 = icmp eq i64 %t50, 0
  store i1 %t52, ptr %l42, !tbaa !21
  br label %bb15
bb15:
  %t53 = load i1, ptr %l42, !tbaa !21
  br i1 %t53, label %bb16, label %bb17
bb16:
  %t54 = load ptr, ptr %l8, !tbaa !29
  %t56 = getelementptr { i64, [4 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t56, i32 0, i32 2
  %t58 = load i32, ptr %t57
  store i32 %t58, ptr %l9, !tbaa !23
  br label %bb18
bb17:
  br label %bb27
bb18:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t60)
  store ptr %t62, ptr %l48
  br label %bb19
bb19:
  %t63 = load i32, ptr %l9, !tbaa !23
  %t64 = load ptr, ptr %l48, !tbaa !29
  %t66 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t64, i32 %t63)
  store %"compiler/typed:Local" %t66, ptr %l50
  br label %bb20
bb20:
  %t67 = getelementptr %"compiler/typed:Local", ptr %l50, i32 0, i32 4
  %t68 = load i32, ptr %t67, !range !{i32 0, i32 7}
  %t70 = trunc i64 1 to i32
  %t71 = icmp eq i32 %t68, %t70
  br i1 %t71, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 87
  store ptr %t75, ptr %l54, !tbaa !29
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t76)
  store ptr %t78, ptr %l56
  br label %bb23
bb22:
  br label %bb26
bb23:
  %t79 = load ptr, ptr %l56, !tbaa !29
  %t81 = getelementptr %"compiler/check:frame", ptr %t79, i32 0, i32 0
  %t82 = load i64, ptr %t81, !tbaa !24
  %t83 = load i32, ptr %l9, !tbaa !23
  %t85 = sext i32 %t83 to i64
  %t86 = load i64, ptr %l7, !tbaa !24
  %t90 = call %"compiler/check:heldCand" @compiler_2fcheck_3aheldCand_2ector(ptr %s4, i64 %t82, i64 %t85, i64 %t86)
  store %"compiler/check:heldCand" %t90, ptr %l62
  br label %bb24
bb24:
  %t91 = load ptr, ptr %l54, !tbaa !29
  %t92 = load %"compiler/check:heldCand", ptr %l62
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aheldCand_3e_2ePush_3ccompiler_2fcheck_3aheldCand_3e(ptr %v0, ptr %t91, %"compiler/check:heldCand" %t92)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s4)
  br label %bb26
bb26:
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_b35f41bb006554d6_a1d87dcad76a5f72)
  unreachable
bb32:
  br label %bb38
bb33:
  br i1 true, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_943678799cf3b8f7_240de00f13c53f3)
  unreachable
bb38:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load %"compiler/source:Span", ptr %l1
  %t95 = load i64, ptr %l7, !tbaa !24
  %t97 = trunc i64 %t95 to i32
  %t99 = load ptr, ptr %l3, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t100
  %t101 = getelementptr { i64, [3 x i64] }, ptr %t100, i32 0, i32 0
  store i64 0, ptr %t101
  %t103 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t94, 0
  %t105 = insertvalue { %"compiler/source:Span", i32, ptr } %t103, i32 %t97, 1
  %t107 = insertvalue { %"compiler/source:Span", i32, ptr } %t105, ptr %t99, 2
  %t108 = getelementptr { i64, [3 x i64] }, ptr %t100, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t107, ptr %t108
  %t109 = load { i64, [3 x i64] }, ptr %t100
  %t111 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t109, ptr %t111
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t93, ptr %t111)
  br label %bb39
bb39:
  store i64 -1, ptr %l10, !tbaa !24
  %t114 = load ptr, ptr %l2, !tbaa !29
  %t116 = getelementptr %"compiler/ast:ForIn", ptr %t114, i32 0, i32 0
  %t117 = load i32, ptr %t116, !tbaa !23
  %t119 = icmp ne i32 %t117, 0
  br i1 %t119, label %bb40, label %bb41
bb40:
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l74, !tbaa !29
  %t122 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t122, ptr %l75
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t123)
  store i32 %t125, ptr %l77
  br label %bb42
bb41:
  br label %bb47
bb42:
  %t126 = load ptr, ptr %l74, !tbaa !29
  %t127 = load %"compiler/source:Span", ptr %l75
  %t128 = load i32, ptr %l77, !tbaa !23
  %t129 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t126, %"compiler/source:Span" %t127, i32 %t128)
  store i64 %t129, ptr %l78
  br label %bb43
bb43:
  %t130 = load i64, ptr %l78, !tbaa !24
  store i64 %t130, ptr %l10, !tbaa !24
  %t131 = load ptr, ptr %l0, !tbaa !29
  store ptr %t131, ptr %l79, !tbaa !29
  %t132 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t132, ptr %l80
  %t133 = load i64, ptr %l10, !tbaa !24
  %t135 = trunc i64 %t133 to i32
  store i32 %t135, ptr %l83, !tbaa !23
  %t137 = load ptr, ptr %l0, !tbaa !29
  store ptr %t137, ptr %l84, !tbaa !29
  %t138 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t138, ptr %l85
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t139)
  store i32 %t141, ptr %l87
  br label %bb44
bb44:
  %t142 = load ptr, ptr %l84, !tbaa !29
  %t143 = load %"compiler/source:Span", ptr %l85
  %t144 = load i32, ptr %l87, !tbaa !23
  %t145 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t142, %"compiler/source:Span" %t143, i32 %t144, i64 0)
  store ptr %t145, ptr %l88
  br label %bb45
bb45:
  store { i64, [3 x i64] } zeroinitializer, ptr %t146
  %t147 = getelementptr { i64, [3 x i64] }, ptr %t146, i32 0, i32 0
  store i64 0, ptr %t147
  %t148 = load %"compiler/source:Span", ptr %l80
  %t149 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t148, 0
  %t150 = load i32, ptr %l83, !tbaa !23
  %t151 = insertvalue { %"compiler/source:Span", i32, ptr } %t149, i32 %t150, 1
  %t152 = load ptr, ptr %l88, !tbaa !29
  %t153 = insertvalue { %"compiler/source:Span", i32, ptr } %t151, ptr %t152, 2
  %t154 = getelementptr { i64, [3 x i64] }, ptr %t146, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t153, ptr %t154
  %t155 = load { i64, [3 x i64] }, ptr %t146
  %t157 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t155, ptr %t157
  %t158 = load ptr, ptr %l79, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t158, ptr %t157)
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/check:Checker", ptr %t160, i32 0, i32 37
  %t164 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t162)
  store i64 %t164, ptr %l93
  br label %bb48
bb48:
  %t165 = load i64, ptr %l93, !tbaa !24
  store i64 %t165, ptr %l11, !tbaa !24
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load %"compiler/source:Span", ptr %l1
  %t171 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t166, i32 2, %"compiler/source:Span" %t167)
  store { i64, i64, i64 } %t171, ptr %l97
  br label %bb49
bb49:
  %t172 = load { i64, i64, i64 }, ptr %l97
  store { i64, i64, i64 } %t172, ptr %l12
  %t173 = getelementptr { i64, i64, i64 }, ptr %l12, i32 0, i32 0
  %t174 = load i64, ptr %t173, !tbaa !24
  store i64 %t174, ptr %l13, !tbaa !24
  %t176 = getelementptr { i64, i64, i64 }, ptr %l12, i32 0, i32 1
  %t177 = load i64, ptr %t176, !tbaa !24
  store i64 %t177, ptr %l14, !tbaa !24
  %t179 = getelementptr { i64, i64, i64 }, ptr %l12, i32 0, i32 2
  %t180 = load i64, ptr %t179, !tbaa !24
  store i64 %t180, ptr %l15, !tbaa !24
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t182)
  store ptr %t184, ptr %l102
  br label %bb50
bb50:
  %t185 = load ptr, ptr %l102, !tbaa !29
  %t187 = getelementptr %"compiler/check:frame", ptr %t185, i32 0, i32 10
  %t188 = load i64, ptr %l13, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t187, i64 %t188)
  br label %bb51
bb51:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t191)
  store ptr %t193, ptr %l107
  br label %bb52
bb52:
  %t194 = load ptr, ptr %l107, !tbaa !29
  %t196 = getelementptr %"compiler/check:frame", ptr %t194, i32 0, i32 11
  %t197 = load i64, ptr %l13, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t196, i64 %t197)
  br label %bb53
bb53:
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l111, !tbaa !29
  %t201 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t201, ptr %l112
  store i64 %a4, ptr %l113, !tbaa !24
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load %"compiler/source:Span", ptr %l1
  %t205 = load i64, ptr %l7, !tbaa !24
  %t209 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t203, %"compiler/source:Span" %t204, i64 %t205)
  store ptr %t209, ptr %l117
  br label %bb54
bb54:
  %t210 = icmp sge i64 0, 0
  br i1 %t210, label %bb55, label %bb56
bb55:
  %t212 = icmp sle i64 0, 1152921504606846975
  br i1 %t212, label %bb57, label %bb58
bb56:
  call void @__olang_check_failed(ptr @olang_loc_dcf5b9aec39ad50b_4fa64d0de79beb7f)
  unreachable
bb57:
  %t214 = mul i64 0, 8
  %t215 = insertvalue { i64, ptr } undef, i64 0, 0
  %t216 = insertvalue { i64, ptr } %t215, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t217 = load ptr, ptr %l111, !tbaa !29
  %t218 = load %"compiler/source:Span", ptr %l112
  %t219 = load i64, ptr %l113, !tbaa !24
  %t220 = load ptr, ptr %l117, !tbaa !29
  %t222 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloopCall(ptr %v0, ptr %t217, %"compiler/source:Span" %t218, i64 %t219, ptr %t220, { i64, ptr } %t216)
  store ptr %t222, ptr %l121
  br label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_dcf5b9aec39ad50b_4fa64d0de79beb7f)
  unreachable
bb59:
  %t223 = load ptr, ptr %l121, !tbaa !29
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t225 = load %"compiler/source:Span", ptr %l1
  %t227 = load i64, ptr %l13, !tbaa !24
  %t232 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexhaustedOrBreak(ptr %v0, ptr %t224, %"compiler/source:Span" %t225, ptr %t223, i64 %t227)
  store ptr %t232, ptr %l126
  br label %bb60
bb60:
  %t233 = load ptr, ptr %l126, !tbaa !29
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load %"compiler/source:Span", ptr %l1
  %t236 = load ptr, ptr %l2, !tbaa !29
  %t237 = load i64, ptr %l10, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelementLocals(ptr %v0, ptr %v1, ptr %t234, %"compiler/source:Span" %t235, ptr %t236, i64 %t237, ptr %t233)
  br label %bb61
bb61:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t245 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkBody(ptr %v0, ptr %v1, ptr %v2, ptr %t244, ptr %t245, ptr %a5, i32 %a6)
  br label %bb62
bb62:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t252)
  store ptr %t254, ptr %l138
  br label %bb63
bb63:
  %t255 = load ptr, ptr %l138, !tbaa !29
  %t257 = getelementptr %"compiler/check:frame", ptr %t255, i32 0, i32 10
  %t259 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t257)
  %t260 = extractvalue { i32, i64 } %t259, 1
  %t261 = extractvalue { i32, i64 } %t259, 0
  store i32 %t261, ptr %l142
  %t262 = icmp ne i32 %t261, 0
  br i1 %t262, label %bb65, label %ok.263, !prof !99
ok.263:
  store i64 %t260, ptr %l141
  br label %bb64
bb64:
  %t264 = load i64, ptr %l141, !tbaa !24
  store i64 %t264, ptr %l136, !tbaa !24
  br label %bb67
bb65:
  br label %bb66
bb66:
  call void @__olang_ert_req_clear()
  br label %bb67
bb67:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t267 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t265)
  store ptr %t267, ptr %l145
  br label %bb68
bb68:
  %t268 = load ptr, ptr %l145, !tbaa !29
  %t270 = getelementptr %"compiler/check:frame", ptr %t268, i32 0, i32 11
  %t272 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t270)
  %t273 = extractvalue { i32, i64 } %t272, 1
  %t274 = extractvalue { i32, i64 } %t272, 0
  store i32 %t274, ptr %l149
  %t275 = icmp ne i32 %t274, 0
  br i1 %t275, label %bb70, label %ok.276, !prof !99
ok.276:
  store i64 %t273, ptr %l148
  br label %bb69
bb69:
  %t277 = load i64, ptr %l148, !tbaa !24
  store i64 %t277, ptr %l143, !tbaa !24
  br label %bb72
bb70:
  br label %bb71
bb71:
  call void @__olang_ert_req_clear()
  br label %bb72
bb72:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t279 = load i64, ptr %l13, !tbaa !24
  %t280 = load i64, ptr %l14, !tbaa !24
  %t281 = load i64, ptr %l15, !tbaa !24
  %t282 = load i64, ptr %l11, !tbaa !24
  %t288 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t278, i64 %t279, i64 %t280, i64 %t281, i64 %t282)
  store ptr %t288, ptr %l155
  br label %bb73
bb73:
  %t289 = load ptr, ptr %l155, !tbaa !29
  %t290 = load ptr, ptr %l0, !tbaa !29
  store ptr %t290, ptr %l156, !tbaa !29
  %t291 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t291, ptr %l157
  store ptr %t289, ptr %l158, !tbaa !29
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t294 = load %"compiler/source:Span", ptr %l1
  %t295 = load i64, ptr %l10, !tbaa !24
  %t299 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecountPost(ptr %v0, ptr %t293, %"compiler/source:Span" %t294, i64 %t295)
  store ptr %t299, ptr %l162
  br label %bb74
bb74:
  store { i64, [3 x i64] } zeroinitializer, ptr %t300
  %t301 = getelementptr { i64, [3 x i64] }, ptr %t300, i32 0, i32 0
  store i64 4, ptr %t301
  %t302 = load %"compiler/source:Span", ptr %l157
  %t303 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t302, 0
  %t304 = load ptr, ptr %l158, !tbaa !29
  %t305 = insertvalue { %"compiler/source:Span", ptr, ptr } %t303, ptr %t304, 1
  %t306 = load ptr, ptr %l162, !tbaa !29
  %t307 = insertvalue { %"compiler/source:Span", ptr, ptr } %t305, ptr %t306, 2
  %t308 = getelementptr { i64, [3 x i64] }, ptr %t300, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t307, ptr %t308
  %t309 = load { i64, [3 x i64] }, ptr %t300
  %t311 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t309, ptr %t311
  %t312 = load ptr, ptr %l156, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t312, ptr %t311)
  br label %bb75
bb75:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewriteBack(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4, %"compiler/source:Span" %a5, i64 %a6, { i64, ptr } %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i32
  %l24 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l38 = alloca i64
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca ptr
  %l48 = alloca i64
  %l49 = alloca i32
  %l50 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca ptr
  %l59 = alloca ptr
  %l60 = alloca i64
  %l61 = alloca i32
  %l62 = alloca ptr
  %l63 = alloca i64
  %l64 = alloca %"compiler/check:laneVals"
  %l65 = alloca i32
  %l66 = alloca i32
  %l67 = alloca { i64, ptr }
  %l68 = alloca i32
  %l69 = alloca i1
  %l70 = alloca i64
  %l71 = alloca { i64, ptr }
  %l72 = alloca ptr
  %l73 = alloca i64
  %l74 = alloca i64
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i64
  %l78 = alloca i64
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca i64
  %l83 = alloca i64
  %l85 = alloca i64
  %l86 = alloca ptr
  %l87 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l89 = alloca i64
  %l90 = alloca i64
  %l91 = alloca i64
  %l92 = alloca i64
  %l93 = alloca i64
  %l94 = alloca i64
  %l96 = alloca ptr
  %l97 = alloca i64
  %l98 = alloca ptr
  %l99 = alloca ptr
  %l100 = alloca { i64, ptr }
  %l101 = alloca i64
  %l102 = alloca i64
  %l103 = alloca i64
  %l104 = alloca i64
  %l105 = alloca i64
  %l106 = alloca i64
  %l107 = alloca i64
  %l108 = alloca i64
  %l109 = alloca i64
  %l110 = alloca i64
  %l111 = alloca i64
  %l112 = alloca i64
  %l113 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l115 = alloca i64
  %l116 = alloca i64
  %l117 = alloca i64
  %l118 = alloca i64
  %l119 = alloca i64
  %l120 = alloca i64
  %l121 = alloca ptr
  %l125 = alloca %"compiler/source:Span"
  %l127 = alloca %"compiler/source:Span"
  %l131 = alloca i64
  %l135 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l136 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l142 = alloca ptr
  %l145 = alloca ptr
  %l146 = alloca { i64, ptr }
  %l160 = alloca %"compiler/check:atRec"
  %l164 = alloca i64
  %l166 = alloca i64
  %l167 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l172 = alloca i64
  %l175 = alloca i64
  %l194 = alloca ptr
  %l197 = alloca i64
  %l198 = alloca %"compiler/check:atRec"
  %l202 = alloca { i64, ptr }
  %l209 = alloca i64
  %l215 = alloca i1
  %l217 = alloca ptr
  %l218 = alloca %"compiler/source:Span"
  %l221 = alloca { i64, ptr }
  %l223 = alloca %"compiler/msgs:Msg"
  %l224 = alloca i64
  %l232 = alloca ptr
  %l238 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l244 = alloca i64
  %l247 = alloca i64
  %l265 = alloca ptr
  %l275 = alloca i64
  %l278 = alloca i64
  %l302 = alloca { i64, ptr }
  %l305 = alloca i64
  %l315 = alloca i64
  %l318 = alloca i64
  %l336 = alloca { i64, ptr }
  %l340 = alloca ptr
  %l342 = alloca %"compiler/source:Span"
  %l345 = alloca i32
  %l348 = alloca i64
  %l349 = alloca ptr
  %l351 = alloca %"compiler/source:Span"
  %l358 = alloca { i64, ptr }
  %l369 = alloca i32
  %l370 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l376 = alloca { i64, ptr }
  %l382 = alloca i64
  %l385 = alloca i64
  %l403 = alloca { i64, ptr }
  %l406 = alloca ptr
  %l407 = alloca ptr
  %l409 = alloca ptr
  %l415 = alloca i32
  %l420 = alloca ptr
  %l422 = alloca %"compiler/source:Span"
  %l423 = alloca ptr
  %l424 = alloca ptr
  %l426 = alloca %"compiler/source:Span"
  %l429 = alloca i32
  %l432 = alloca i64
  %l433 = alloca ptr
  %l435 = alloca %"compiler/source:Span"
  %l449 = alloca i32
  %l455 = alloca ptr
  %l456 = alloca i64
  %l458 = alloca i32
  %l462 = alloca i32
  %l466 = alloca i1
  %l469 = alloca i1
  %l471 = alloca %"compiler/check:laneVals"
  %l474 = alloca ptr
  %l479 = alloca ptr
  %l481 = alloca i32
  %l483 = alloca i32
  %l485 = alloca i1
  %l486 = alloca ptr
  %l488 = alloca i32
  %l489 = alloca i1
  %l490 = alloca ptr
  %l491 = alloca %"compiler/source:Span"
  %l492 = alloca %"compiler/source:Span"
  %l493 = alloca i32
  %l499 = alloca ptr
  %l504 = alloca i1
  %l507 = alloca i1
  %l508 = alloca i1
  %l510 = alloca i32
  %l511 = alloca i1
  %l514 = alloca i32
  %l515 = alloca ptr
  %l519 = alloca ptr
  %l520 = alloca i64
  %l524 = alloca %"compiler/check:laneNode"
  %l526 = alloca { i64, ptr }
  %l527 = alloca { i64, ptr }
  %l528 = alloca i64
  %l529 = alloca { i64, ptr }
  %l532 = alloca i1
  %l534 = alloca i1
  %l537 = alloca i1
  %l540 = alloca i32
  %l541 = alloca { i64, ptr }
  %l542 = alloca { i64, ptr }
  %l544 = alloca i64
  %l548 = alloca { i64, ptr }
  %l550 = alloca i64
  %l553 = alloca i1
  %l555 = alloca ptr
  %l556 = alloca %"compiler/source:Span"
  %l557 = alloca ptr
  %l560 = alloca i1
  %l562 = alloca i32
  %l565 = alloca { i64, ptr }
  %l568 = alloca %"compiler/msgs:Msg"
  %l569 = alloca i64
  %l576 = alloca i1
  %l578 = alloca i1
  %l581 = alloca i1
  %l582 = alloca i1
  %l586 = alloca i1
  %l600 = alloca ptr
  %l601 = alloca %"compiler/source:Span"
  %l602 = alloca i32
  %l605 = alloca ptr
  %l608 = alloca i32
  %l609 = alloca i1
  %l610 = alloca i64
  %l613 = alloca i32
  %l614 = alloca i64
  %l615 = alloca ptr
  %l617 = alloca ptr
  %l622 = alloca ptr
  %l624 = alloca ptr
  %l627 = alloca i32
  %l630 = alloca i1
  %l631 = alloca ptr
  %l633 = alloca i32
  %l634 = alloca i1
  %l635 = alloca i1
  %l637 = alloca ptr
  %l639 = alloca i32
  %l641 = alloca i1
  %l642 = alloca ptr
  %l643 = alloca %"compiler/source:Span"
  %l648 = alloca ptr
  %l651 = alloca i32
  %l654 = alloca i1
  %l657 = alloca i1
  %l658 = alloca ptr
  %l659 = alloca i32
  %l664 = alloca i1
  %l669 = alloca i1
  %l672 = alloca i1
  %l676 = alloca i1
  %l679 = alloca ptr
  %l680 = alloca %"compiler/source:Span"
  %l682 = alloca i32
  %l685 = alloca i64
  %l686 = alloca ptr
  %l687 = alloca %"compiler/source:Span"
  %l690 = alloca i32
  %l696 = alloca i64
  %l700 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l706 = alloca i64
  %l709 = alloca i64
  %l734 = alloca i64
  %l737 = alloca i64
  %l760 = alloca ptr
  %l763 = alloca i64
  %l764 = alloca %"compiler/check:atRec"
  %l775 = alloca ptr
  %l782 = alloca { i64, ptr }
  %l784 = alloca i64
  %l787 = alloca ptr
  %l796 = alloca i64
  %l799 = alloca i64
  %l817 = alloca { i64, ptr }
  %l818 = alloca i64
  %l821 = alloca { i64, ptr }
  %l824 = alloca ptr
  %l827 = alloca ptr
  %l829 = alloca ptr
  %l832 = alloca i64
  %l833 = alloca %"compiler/check:atRec"
  %l837 = alloca i64
  %l838 = alloca ptr
  %l839 = alloca %"compiler/source:Span"
  %l840 = alloca %"compiler/source:Span"
  %l841 = alloca i64
  %l845 = alloca ptr
  %l846 = alloca ptr
  %l849 = alloca { i64, ptr }
  %l850 = alloca { i64, ptr }
  %l854 = alloca ptr
  %l855 = alloca ptr
  %l856 = alloca %"compiler/source:Span"
  %l859 = alloca i32
  %l860 = alloca i64
  %l876 = alloca ptr
  %l881 = alloca ptr
  %l886 = alloca ptr
  %l891 = alloca i64
  %l892 = alloca i64
  %l895 = alloca ptr
  %l900 = alloca i64
  %l904 = alloca i64
  %l907 = alloca i64
  %l925 = alloca { i64, ptr }
  %l926 = alloca i64
  %l927 = alloca ptr
  %l928 = alloca %"compiler/source:Span"
  %l931 = alloca i64
  %l932 = alloca ptr
  %l935 = alloca { i64, ptr }
  %l937 = alloca i64
  %l941 = alloca ptr
  %l942 = alloca %"compiler/source:Span"
  %l943 = alloca ptr
  %l944 = alloca %"compiler/source:Span"
  %l945 = alloca %"compiler/source:Span"
  %l946 = alloca i64
  %l950 = alloca ptr
  %l951 = alloca ptr
  %l954 = alloca { i64, ptr }
  %l955 = alloca { i64, ptr }
  %l959 = alloca ptr
  %l964 = alloca ptr
  %l965 = alloca %"compiler/source:Span"
  %l966 = alloca %"compiler/source:Span"
  %l968 = alloca i32
  %l969 = alloca i32
  %l973 = alloca i64
  %l979 = alloca ptr
  %l980 = alloca %"compiler/source:Span"
  %l981 = alloca i32
  %l983 = alloca i32
  %l984 = alloca i32
  %l991 = alloca ptr
  %l993 = alloca ptr
  %l995 = alloca ptr
  %l996 = alloca %"compiler/source:Span"
  %l997 = alloca ptr
  %l1007 = alloca i64
  %l1010 = alloca i64
  %l1030 = alloca { i64, ptr }
  %l1033 = alloca i64
  %l1036 = alloca ptr
  %l1045 = alloca i64
  %l1048 = alloca i64
  %l1066 = alloca { i64, ptr }
  %l1067 = alloca i64
  %l1070 = alloca { i64, ptr }
  %l1073 = alloca ptr
  %l1076 = alloca { i64, ptr }
  %l1078 = alloca i64
  %l1083 = alloca ptr
  %l1084 = alloca ptr
  %l1085 = alloca %"compiler/source:Span"
  %l1086 = alloca ptr
  %l1087 = alloca %"compiler/source:Span"
  %l1088 = alloca %"compiler/source:Span"
  %l1091 = alloca i64
  %l1092 = alloca ptr
  %l1093 = alloca %"compiler/source:Span"
  %l1096 = alloca ptr
  %l1100 = alloca ptr
  %l1101 = alloca ptr
  %l1104 = alloca { i64, ptr }
  %l1105 = alloca { i64, ptr }
  %l1109 = alloca ptr
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s44 = alloca %olang.scope
  %s50 = alloca %olang.scope
  %s59 = alloca %olang.scope
  %rv = alloca i1
  %t440 = alloca { i64, [2 x i64] }, align 8
  %t459 = alloca { i64, [3 x i64] }, align 8
  %t616 = alloca { i64, [2 x i64] }, align 8
  %t635 = alloca { i64, [3 x i64] }, align 8
  %t759 = alloca { i64, [4 x i64] }, align 8
  %t1156 = alloca { i64, [2 x i64] }, align 8
  %t1177 = alloca { i64, [3 x i64] }, align 8
  %t1201 = alloca i64
  %t1393 = alloca i64
  %t1554 = alloca { i64, [3 x i64] }, align 8
  %t1637 = alloca i64
  %t1769 = alloca { i64, [3 x i64] }, align 8
  %t1823 = alloca { i64, [4 x i64] }, align 8
  %t1855 = alloca { i64, [3 x i64] }, align 8
  %t1943 = alloca i64
  %t2100 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store %"compiler/source:Span" %a5, ptr %l5
  store i64 %a6, ptr %l6
  store { i64, ptr } %a7, ptr %l7
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  %t5 = xor i1 %t3, true
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l4, !tbaa !29
  %t9 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t7)
  store %"compiler/source:Span" %t9, ptr %l127
  br label %bb3
bb2:
  %t10 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t10, ptr %l125
  br label %bb4
bb3:
  %t12 = load %"compiler/source:Span", ptr %l127
  store %"compiler/source:Span" %t12, ptr %l125
  br label %bb4
bb4:
  %t13 = load %"compiler/source:Span", ptr %l125
  store %"compiler/source:Span" %t13, ptr %l8
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load ptr, ptr %l3, !tbaa !29
  %t18 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTemp(ptr %v0, ptr %v0, ptr %t14, ptr %t15)
  store i64 %t18, ptr %l131
  br label %bb5
bb5:
  %t19 = load i64, ptr %l131, !tbaa !24
  store i64 %t19, ptr %l9, !tbaa !24
  %t20 = load i64, ptr %l9, !tbaa !24
  %t22 = icmp slt i64 %t20, 0
  br i1 %t22, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t25 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l135
  br label %bb9
bb9:
  %t26 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l135
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t26, ptr %l10
  %t27 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2ftyped_3aExpr_26_3e_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t27, ptr %l136
  br label %bb10
bb10:
  %t28 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l136
  %t29 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, ptr %t29
  store ptr %t29, ptr %l11, !tbaa !29
  %t31 = load ptr, ptr %l3, !tbaa !29
  store ptr %t31, ptr %l12, !tbaa !29
  br label %bb11
bb11:
  %t33 = load i64, ptr %l9, !tbaa !24
  %t35 = icmp sge i64 %t33, 0
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb12, label %bb13
bb12:
  br label %bb26
bb13:
  br label %bb14
bb14:
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l142, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load ptr, ptr %l12, !tbaa !29
  %t44 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etempValue(ptr %v0, ptr %v0, ptr %t40, ptr %t41)
  store ptr %t44, ptr %l145
  br label %bb15
bb15:
  %t45 = load ptr, ptr %l142, !tbaa !29
  %t46 = load ptr, ptr %l145, !tbaa !29
  %t47 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallArgs(ptr %v0, ptr %v0, ptr %t45, ptr %t46)
  store { i64, ptr } %t47, ptr %l146
  br label %bb16
bb16:
  %t48 = load { i64, ptr }, ptr %l146, !tbaa !27
  store { i64, ptr } %t48, ptr %l13, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t53 = icmp eq i64 %t51, 0
  br i1 %t53, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s3, ptr %t55, %"compiler/source:Span" %t56, { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d44, i32 0, i32 1) })
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb20:
  %t60 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l10, i64 %t60)
  br label %bb21
bb21:
  %t63 = load ptr, ptr %l11, !tbaa !29
  %t64 = load { i64, ptr }, ptr %l13, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2ftyped_3aExpr_26_3e__H4f2a00f637999dd5fb4d6b4e8f1ae171(ptr %v0, ptr %v0, ptr %t63, { i64, ptr } %t64)
  br label %bb22
bb22:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 38
  %t70 = load i64, ptr %l9, !tbaa !24
  %t73 = call %"compiler/check:atRec" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aatRec_3e_2eAt_3ccompiler_2fcheck_3aatRec_3e(ptr %v0, ptr %v0, ptr %t69, i64 %t70)
  store %"compiler/check:atRec" %t73, ptr %l160
  br label %bb23
bb23:
  %t74 = getelementptr %"compiler/check:atRec", ptr %l160, i32 0, i32 2
  %t75 = load ptr, ptr %t74, !tbaa !29
  store ptr %t75, ptr %l12, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load ptr, ptr %l12, !tbaa !29
  %t81 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTemp(ptr %v0, ptr %v0, ptr %t77, ptr %t78)
  store i64 %t81, ptr %l164
  br label %bb24
bb24:
  %t82 = load i64, ptr %l164, !tbaa !24
  store i64 %t82, ptr %l9, !tbaa !24
  br label %bb25
bb25:
  br label %bb11
bb26:
  %t84 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l10)
  store i64 %t84, ptr %l166
  br label %bb27
bb27:
  %t85 = load i64, ptr %l166, !tbaa !24
  store i64 %t85, ptr %l14, !tbaa !24
  %t86 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t86, ptr %l167
  br label %bb28
bb28:
  %t87 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l167
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t87, ptr %l15
  store i64 0, ptr %l16, !tbaa !24
  %t88 = load i64, ptr %l14, !tbaa !24
  store i64 %t88, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t90 = load i64, ptr %l17, !tbaa !24
  %t91 = load i64, ptr %l16, !tbaa !24
  %t94 = icmp sgt i64 %t90, %t91
  br i1 %t94, label %bb29, label %bb30
bb29:
  %t96 = load i64, ptr %l18, !tbaa !24
  %t98 = icmp sgt i64 %t96, 0
  br i1 %t98, label %bb31, label %bb32
bb30:
  store i64 0, ptr %l172, !tbaa !24
  br label %bb34
bb31:
  %t100 = load i64, ptr %l17, !tbaa !24
  %t101 = load i64, ptr %l16, !tbaa !24
  %t104 = sub i64 %t100, %t101
  %t105 = load i64, ptr %l18, !tbaa !24
  %t108 = add i64 %t104, %t105
  %t110 = sub i64 %t108, 1
  %t111 = load i64, ptr %l18, !tbaa !24
  %t114 = sdiv i64 %t110, %t111
  store i64 %t114, ptr %l175, !tbaa !24
  br label %bb33
bb32:
  store i64 0, ptr %l175, !tbaa !24
  br label %bb33
bb33:
  %t116 = load i64, ptr %l175, !tbaa !24
  store i64 %t116, ptr %l172, !tbaa !24
  br label %bb34
bb34:
  %t117 = load i64, ptr %l172, !tbaa !24
  store i64 %t117, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb35
bb35:
  store %olang.scope zeroinitializer, ptr %s5
  %t118 = load i64, ptr %l20, !tbaa !24
  %t119 = load i64, ptr %l19, !tbaa !24
  %t122 = icmp slt i64 %t118, %t119
  %t124 = xor i1 %t122, true
  br i1 %t124, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s5)
  br label %bb59
bb37:
  br label %bb38
bb38:
  %t126 = load i64, ptr %l16, !tbaa !24
  %t127 = load i64, ptr %l20, !tbaa !24
  %t128 = load i64, ptr %l18, !tbaa !24
  %t131 = mul i64 %t127, %t128
  %t134 = add i64 %t126, %t131
  store i64 %t134, ptr %l21, !tbaa !24
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/check:Checker", ptr %t136, i32 0, i32 38
  store ptr %t138, ptr %l194, !tbaa !29
  %t139 = load i64, ptr %l21, !tbaa !24
  %t142 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l10, i64 %t139)
  store i64 %t142, ptr %l197
  br label %bb39
bb39:
  %t143 = load ptr, ptr %l194, !tbaa !29
  %t144 = load i64, ptr %l197, !tbaa !24
  %t145 = call %"compiler/check:atRec" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aatRec_3e_2eAt_3ccompiler_2fcheck_3aatRec_3e(ptr %v0, ptr %s5, ptr %t143, i64 %t144)
  store %"compiler/check:atRec" %t145, ptr %l198
  br label %bb40
bb40:
  %t146 = getelementptr %"compiler/check:atRec", ptr %l198, i32 0, i32 3
  %t147 = load i32, ptr %t146, !tbaa !23
  store i32 %t147, ptr %l22, !tbaa !23
  %t149 = load ptr, ptr %l11, !tbaa !29
  %t150 = load i64, ptr %l21, !tbaa !24
  %t153 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2ftyped_3aExpr_26_3e__H6fdae4ec28a8e0f494e79cb375983eb8(ptr %v0, ptr %s5, ptr %t149, i64 %t150)
  store { i64, ptr } %t153, ptr %l202
  br label %bb41
bb41:
  %t154 = load { i64, ptr }, ptr %l202, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t154, 0
  %t157 = sub i64 %t155, 1
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load i32, ptr %l22, !tbaa !23
  %t163 = add i64 %t157, 1
  %t167 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s5, ptr %t159, i32 %t160, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d45, i32 0, i32 1) }, i64 %t163)
  store i64 %t167, ptr %l209
  br label %bb42
bb42:
  %t168 = load i64, ptr %l209, !tbaa !24
  store i64 %t168, ptr %l24, !tbaa !24
  %t169 = load i64, ptr %l24, !tbaa !24
  %t171 = icmp slt i64 %t169, 0
  br i1 %t171, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s6
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i32, ptr %l22, !tbaa !23
  %t175 = load %"compiler/source:Span", ptr %l5
  %t179 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %s6, ptr %s6, ptr %t173, i32 %t174, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d46, i32 0, i32 1) }, %"compiler/source:Span" %t175, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d47, i32 0, i32 1) }, i64 2, i1 true)
  store i1 %t179, ptr %l215
  br label %bb45
bb44:
  br label %bb56
bb45:
  %t180 = load i1, ptr %l215, !tbaa !21
  %t181 = xor i1 %t180, true
  br i1 %t181, label %bb46, label %bb47
bb46:
  store %olang.scope zeroinitializer, ptr %s7
  %t183 = load ptr, ptr %l0, !tbaa !29
  store ptr %t183, ptr %l217, !tbaa !29
  %t184 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t184, ptr %l218
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load i32, ptr %l22, !tbaa !23
  %t189 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s7, ptr %t185, i32 %t186)
  store { i64, ptr } %t189, ptr %l221
  br label %bb48
bb47:
  br label %bb51
bb48:
  %t190 = load { i64, ptr }, ptr %l221, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t190, 0
  %t192 = extractvalue { i64, ptr } %t190, 1
  %t193 = mul i64 %t191, 1
  %t194 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t193)
  call void @llvm.memcpy.p0.p0.i64(ptr %t194, ptr %t192, i64 %t193, i1 false)
  %t195 = insertvalue { i64, ptr } undef, i64 %t191, 0
  %t196 = insertvalue { i64, ptr } %t195, ptr %t194, 1
  %t198 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eWriteThroughAtNoSetat(ptr %s7, ptr %s7, { i64, ptr } %t196)
  store %"compiler/msgs:Msg" %t198, ptr %l223
  br label %bb49
bb49:
  %t199 = load ptr, ptr %l217, !tbaa !29
  %t200 = load %"compiler/source:Span", ptr %l218
  %t201 = load %"compiler/msgs:Msg", ptr %l223
  %t202 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t199, %"compiler/source:Span" %t200, %"compiler/msgs:Msg" %t201)
  store i64 %t202, ptr %l224
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s7)
  br label %bb51
bb51:
  %t203 = load ptr, ptr %l4, !tbaa !29
  %t205 = icmp eq ptr %t203, null
  %t207 = xor i1 %t205, true
  br i1 %t207, label %bb52, label %bb53
bb52:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load ptr, ptr %l4, !tbaa !29
  %t212 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t216 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t209, ptr %t210, i32 %t212)
  store ptr %t216, ptr %l232
  br label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb56:
  %t218 = load i64, ptr %l24, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l15, i64 %t218)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s5)
  br label %bb58
bb58:
  %t221 = load i64, ptr %l20, !tbaa !24
  %t223 = add i64 %t221, 1
  store i64 %t223, ptr %l20, !tbaa !24
  br label %bb35
bb59:
  %t225 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t225, ptr %l238
  br label %bb60
bb60:
  %t226 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l238
  %t227 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t226, ptr %t227
  store ptr %t227, ptr %l25, !tbaa !29
  store i64 0, ptr %l26, !tbaa !24
  %t229 = load i64, ptr %l14, !tbaa !24
  store i64 %t229, ptr %l27, !tbaa !24
  store i64 1, ptr %l28, !tbaa !24
  %t231 = load i64, ptr %l27, !tbaa !24
  %t232 = load i64, ptr %l26, !tbaa !24
  %t235 = icmp sgt i64 %t231, %t232
  br i1 %t235, label %bb61, label %bb62
bb61:
  %t237 = load i64, ptr %l28, !tbaa !24
  %t239 = icmp sgt i64 %t237, 0
  br i1 %t239, label %bb63, label %bb64
bb62:
  store i64 0, ptr %l244, !tbaa !24
  br label %bb66
bb63:
  %t241 = load i64, ptr %l27, !tbaa !24
  %t242 = load i64, ptr %l26, !tbaa !24
  %t245 = sub i64 %t241, %t242
  %t246 = load i64, ptr %l28, !tbaa !24
  %t249 = add i64 %t245, %t246
  %t251 = sub i64 %t249, 1
  %t252 = load i64, ptr %l28, !tbaa !24
  %t255 = sdiv i64 %t251, %t252
  store i64 %t255, ptr %l247, !tbaa !24
  br label %bb65
bb64:
  store i64 0, ptr %l247, !tbaa !24
  br label %bb65
bb65:
  %t257 = load i64, ptr %l247, !tbaa !24
  store i64 %t257, ptr %l244, !tbaa !24
  br label %bb66
bb66:
  %t258 = load i64, ptr %l244, !tbaa !24
  store i64 %t258, ptr %l29, !tbaa !24
  store i64 0, ptr %l30, !tbaa !24
  br label %bb67
bb67:
  %t259 = load i64, ptr %l30, !tbaa !24
  %t260 = load i64, ptr %l29, !tbaa !24
  %t263 = icmp slt i64 %t259, %t260
  %t265 = xor i1 %t263, true
  br i1 %t265, label %bb68, label %bb69
bb68:
  br label %bb77
bb69:
  br label %bb70
bb70:
  %t267 = load i64, ptr %l26, !tbaa !24
  %t268 = load i64, ptr %l30, !tbaa !24
  %t269 = load i64, ptr %l28, !tbaa !24
  %t272 = mul i64 %t268, %t269
  %t275 = add i64 %t267, %t272
  store i64 %t275, ptr %l31, !tbaa !24
  %t277 = load ptr, ptr %l25, !tbaa !29
  store ptr %t277, ptr %l265, !tbaa !29
  %t278 = icmp sge i64 0, 0
  br i1 %t278, label %bb71, label %bb72
bb71:
  %t280 = icmp sle i64 0, 1152921504606846975
  br i1 %t280, label %bb73, label %bb74
bb72:
  call void @__olang_check_failed(ptr @olang_loc_f5f1ca6bc4d4202_a62b55a8c6b3a336)
  unreachable
bb73:
  %t282 = mul i64 0, 8
  %t283 = insertvalue { i64, ptr } undef, i64 0, 0
  %t284 = insertvalue { i64, ptr } %t283, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t285 = load ptr, ptr %l265, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t285, { i64, ptr } %t284)
  br label %bb75
bb74:
  call void @__olang_check_failed(ptr @olang_loc_f5f1ca6bc4d4202_a62b55a8c6b3a336)
  unreachable
bb75:
  br label %bb76
bb76:
  %t287 = load i64, ptr %l30, !tbaa !24
  %t289 = add i64 %t287, 1
  store i64 %t289, ptr %l30, !tbaa !24
  br label %bb67
bb77:
  store i64 0, ptr %l32, !tbaa !24
  %t291 = load i64, ptr %l14, !tbaa !24
  store i64 %t291, ptr %l33, !tbaa !24
  store i64 1, ptr %l34, !tbaa !24
  %t293 = load i64, ptr %l33, !tbaa !24
  %t294 = load i64, ptr %l32, !tbaa !24
  %t297 = icmp sgt i64 %t293, %t294
  br i1 %t297, label %bb78, label %bb79
bb78:
  %t299 = load i64, ptr %l34, !tbaa !24
  %t301 = icmp sgt i64 %t299, 0
  br i1 %t301, label %bb80, label %bb81
bb79:
  store i64 0, ptr %l275, !tbaa !24
  br label %bb83
bb80:
  %t303 = load i64, ptr %l33, !tbaa !24
  %t304 = load i64, ptr %l32, !tbaa !24
  %t307 = sub i64 %t303, %t304
  %t308 = load i64, ptr %l34, !tbaa !24
  %t311 = add i64 %t307, %t308
  %t313 = sub i64 %t311, 1
  %t314 = load i64, ptr %l34, !tbaa !24
  %t317 = sdiv i64 %t313, %t314
  store i64 %t317, ptr %l278, !tbaa !24
  br label %bb82
bb81:
  store i64 0, ptr %l278, !tbaa !24
  br label %bb82
bb82:
  %t319 = load i64, ptr %l278, !tbaa !24
  store i64 %t319, ptr %l275, !tbaa !24
  br label %bb83
bb83:
  %t320 = load i64, ptr %l275, !tbaa !24
  store i64 %t320, ptr %l35, !tbaa !24
  store i64 0, ptr %l36, !tbaa !24
  br label %bb84
bb84:
  %t321 = load i64, ptr %l36, !tbaa !24
  %t322 = load i64, ptr %l35, !tbaa !24
  %t325 = icmp slt i64 %t321, %t322
  %t327 = xor i1 %t325, true
  br i1 %t327, label %bb85, label %bb86
bb85:
  br label %bb112
bb86:
  br label %bb87
bb87:
  %t329 = load i64, ptr %l32, !tbaa !24
  %t330 = load i64, ptr %l36, !tbaa !24
  %t331 = load i64, ptr %l34, !tbaa !24
  %t334 = mul i64 %t330, %t331
  %t337 = add i64 %t329, %t334
  %t339 = load i64, ptr %l14, !tbaa !24
  %t341 = sub i64 %t339, 1
  %t345 = sub i64 %t341, %t337
  store i64 %t345, ptr %l38, !tbaa !24
  %t347 = load ptr, ptr %l11, !tbaa !29
  %t348 = load i64, ptr %l38, !tbaa !24
  %t351 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2ftyped_3aExpr_26_3e__H6fdae4ec28a8e0f494e79cb375983eb8(ptr %v0, ptr %v0, ptr %t347, i64 %t348)
  store { i64, ptr } %t351, ptr %l302
  br label %bb88
bb88:
  %t352 = load { i64, ptr }, ptr %l302, !tbaa !27
  store { i64, ptr } %t352, ptr %l39, !tbaa !27
  %t353 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t355 = extractvalue { i64, ptr } %t353, 0
  %t357 = sub i64 %t355, 1
  store i64 %t357, ptr %l305, !tbaa !24
  %t358 = load i64, ptr %l305, !tbaa !24
  %t359 = icmp sge i64 %t358, 0
  br i1 %t359, label %bb89, label %bb90
bb89:
  %t361 = load i64, ptr %l305, !tbaa !24
  %t362 = icmp sle i64 %t361, 1152921504606846975
  br i1 %t362, label %bb91, label %bb92
bb90:
  call void @__olang_check_failed(ptr @olang_loc_17f46f322b5d16b7_69863e823125c3cb)
  unreachable
bb91:
  %t364 = load i64, ptr %l305, !tbaa !24
  %t365 = mul i64 %t364, 8
  %t366 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t365)
  %t367 = insertvalue { i64, ptr } undef, i64 %t364, 0
  %t368 = insertvalue { i64, ptr } %t367, ptr %t366, 1
  store { i64, ptr } %t368, ptr %l40, !tbaa !27
  store i64 0, ptr %l41, !tbaa !24
  %t370 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t372 = extractvalue { i64, ptr } %t370, 0
  %t374 = sub i64 %t372, 1
  store i64 %t374, ptr %l42, !tbaa !24
  store i64 1, ptr %l43, !tbaa !24
  %t376 = load i64, ptr %l42, !tbaa !24
  %t377 = load i64, ptr %l41, !tbaa !24
  %t380 = icmp sgt i64 %t376, %t377
  br i1 %t380, label %bb93, label %bb94
bb92:
  call void @__olang_check_failed(ptr @olang_loc_17f46f322b5d16b7_69863e823125c3cb)
  unreachable
bb93:
  %t382 = load i64, ptr %l43, !tbaa !24
  %t384 = icmp sgt i64 %t382, 0
  br i1 %t384, label %bb95, label %bb96
bb94:
  store i64 0, ptr %l315, !tbaa !24
  br label %bb98
bb95:
  %t386 = load i64, ptr %l42, !tbaa !24
  %t387 = load i64, ptr %l41, !tbaa !24
  %t390 = sub i64 %t386, %t387
  %t391 = load i64, ptr %l43, !tbaa !24
  %t394 = add i64 %t390, %t391
  %t396 = sub i64 %t394, 1
  %t397 = load i64, ptr %l43, !tbaa !24
  %t400 = sdiv i64 %t396, %t397
  store i64 %t400, ptr %l318, !tbaa !24
  br label %bb97
bb96:
  store i64 0, ptr %l318, !tbaa !24
  br label %bb97
bb97:
  %t402 = load i64, ptr %l318, !tbaa !24
  store i64 %t402, ptr %l315, !tbaa !24
  br label %bb98
bb98:
  %t403 = load i64, ptr %l315, !tbaa !24
  store i64 %t403, ptr %l44, !tbaa !24
  store i64 0, ptr %l45, !tbaa !24
  br label %bb99
bb99:
  %t404 = load i64, ptr %l45, !tbaa !24
  %t405 = load i64, ptr %l44, !tbaa !24
  %t408 = icmp slt i64 %t404, %t405
  %t410 = xor i1 %t408, true
  br i1 %t410, label %bb100, label %bb101
bb100:
  br label %bb109
bb101:
  br label %bb102
bb102:
  %t412 = load i64, ptr %l41, !tbaa !24
  %t413 = load i64, ptr %l45, !tbaa !24
  %t414 = load i64, ptr %l43, !tbaa !24
  %t417 = mul i64 %t413, %t414
  %t420 = add i64 %t412, %t417
  store i64 %t420, ptr %l46, !tbaa !24
  %t422 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t422, ptr %l336, !tbaa !27
  %t423 = load i64, ptr %l46, !tbaa !24
  %t425 = add i64 %t423, 1
  %t427 = getelementptr { i64, ptr }, ptr %l336, i32 0, i32 1
  %t428 = load ptr, ptr %t427, !tbaa !27
  %t429 = getelementptr ptr, ptr %t428, i64 %t425
  %t430 = load ptr, ptr %t429, !tbaa !39
  store ptr %t430, ptr %l47, !tbaa !29
  %t432 = load ptr, ptr %l0, !tbaa !29
  store ptr %t432, ptr %l340, !tbaa !29
  %t433 = load ptr, ptr %l47, !tbaa !29
  %t435 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t433)
  store %"compiler/source:Span" %t435, ptr %l342
  br label %bb103
bb103:
  %t436 = load ptr, ptr %l47, !tbaa !29
  %t439 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t436)
  store i32 %t439, ptr %l345
  br label %bb104
bb104:
  store { i64, [2 x i64] } zeroinitializer, ptr %t440
  %t441 = getelementptr { i64, [2 x i64] }, ptr %t440, i32 0, i32 0
  store i64 0, ptr %t441
  %t442 = load { i64, [2 x i64] }, ptr %t440
  %t443 = load ptr, ptr %l340, !tbaa !29
  %t444 = load %"compiler/source:Span", ptr %l342
  %t445 = load i32, ptr %l345, !tbaa !23
  %t448 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t443, i32 0, %"compiler/source:Span" %t444, i32 %t445, i32 2, { i64, [2 x i64] } %t442)
  store i64 %t448, ptr %l348
  br label %bb105
bb105:
  %t449 = load i64, ptr %l348, !tbaa !24
  store i64 %t449, ptr %l48, !tbaa !24
  %t450 = load ptr, ptr %l0, !tbaa !29
  store ptr %t450, ptr %l349, !tbaa !29
  %t451 = load ptr, ptr %l47, !tbaa !29
  %t453 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t451)
  store %"compiler/source:Span" %t453, ptr %l351
  br label %bb106
bb106:
  %t454 = load i64, ptr %l48, !tbaa !24
  %t456 = trunc i64 %t454 to i32
  %t458 = load ptr, ptr %l47, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t459
  %t460 = getelementptr { i64, [3 x i64] }, ptr %t459, i32 0, i32 0
  store i64 0, ptr %t460
  %t461 = load %"compiler/source:Span", ptr %l351
  %t462 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t461, 0
  %t464 = insertvalue { %"compiler/source:Span", i32, ptr } %t462, i32 %t456, 1
  %t466 = insertvalue { %"compiler/source:Span", i32, ptr } %t464, ptr %t458, 2
  %t467 = getelementptr { i64, [3 x i64] }, ptr %t459, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t466, ptr %t467
  %t468 = load { i64, [3 x i64] }, ptr %t459
  %t470 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t468, ptr %t470
  %t471 = load ptr, ptr %l349, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t471, ptr %t470)
  br label %bb107
bb107:
  %t473 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t473, ptr %l358, !tbaa !27
  %t474 = load i64, ptr %l46, !tbaa !24
  %t475 = load i64, ptr %l48, !tbaa !24
  %t478 = getelementptr { i64, ptr }, ptr %l358, i32 0, i32 1
  %t479 = load ptr, ptr %t478, !tbaa !27
  %t480 = getelementptr i64, ptr %t479, i64 %t474
  store i64 %t475, ptr %t480, !tbaa !34
  br label %bb108
bb108:
  %t481 = load i64, ptr %l45, !tbaa !24
  %t483 = add i64 %t481, 1
  store i64 %t483, ptr %l45, !tbaa !24
  br label %bb99
bb109:
  %t485 = load ptr, ptr %l25, !tbaa !29
  %t486 = load i64, ptr %l38, !tbaa !24
  %t487 = load { i64, ptr }, ptr %l40, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eSetAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t485, i64 %t486, { i64, ptr } %t487)
  br label %bb110
bb110:
  br label %bb111
bb111:
  %t491 = load i64, ptr %l36, !tbaa !24
  %t493 = add i64 %t491, 1
  store i64 %t493, ptr %l36, !tbaa !24
  br label %bb84
bb112:
  %t495 = load ptr, ptr %l3, !tbaa !29
  %t497 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %t495)
  store i32 %t497, ptr %l369
  br label %bb113
bb113:
  %t498 = load i32, ptr %l369, !tbaa !23
  store i32 %t498, ptr %l49, !tbaa !23
  %t499 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t499, ptr %l370
  br label %bb114
bb114:
  %t500 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l370
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t500, ptr %l50
  %t501 = load i64, ptr %l6, !tbaa !24
  %t503 = icmp sge i64 %t501, 0
  br i1 %t503, label %bb115, label %bb116
bb115:
  store %olang.scope zeroinitializer, ptr %s19
  %t505 = load ptr, ptr %l0, !tbaa !29
  %t506 = load i64, ptr %l6, !tbaa !24
  %t507 = load i32, ptr %l49, !tbaa !23
  %t511 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamsOn(ptr %v0, ptr %s19, ptr %t505, i64 %t506, i32 %t507)
  store { i64, ptr } %t511, ptr %l376
  br label %bb117
bb116:
  br label %bb154
bb117:
  %t512 = load { i64, ptr }, ptr %l376, !tbaa !27
  store { i64, ptr } %t512, ptr %l51, !tbaa !27
  store i64 0, ptr %l52, !tbaa !24
  %t513 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t515 = extractvalue { i64, ptr } %t513, 0
  store i64 %t515, ptr %l53, !tbaa !24
  store i64 1, ptr %l54, !tbaa !24
  %t517 = load i64, ptr %l53, !tbaa !24
  %t518 = load i64, ptr %l52, !tbaa !24
  %t521 = icmp sgt i64 %t517, %t518
  br i1 %t521, label %bb118, label %bb119
bb118:
  %t523 = load i64, ptr %l54, !tbaa !24
  %t525 = icmp sgt i64 %t523, 0
  br i1 %t525, label %bb120, label %bb121
bb119:
  store i64 0, ptr %l382, !tbaa !24
  br label %bb123
bb120:
  %t527 = load i64, ptr %l53, !tbaa !24
  %t528 = load i64, ptr %l52, !tbaa !24
  %t531 = sub i64 %t527, %t528
  %t532 = load i64, ptr %l54, !tbaa !24
  %t535 = add i64 %t531, %t532
  %t537 = sub i64 %t535, 1
  %t538 = load i64, ptr %l54, !tbaa !24
  %t541 = sdiv i64 %t537, %t538
  store i64 %t541, ptr %l385, !tbaa !24
  br label %bb122
bb121:
  store i64 0, ptr %l385, !tbaa !24
  br label %bb122
bb122:
  %t543 = load i64, ptr %l385, !tbaa !24
  store i64 %t543, ptr %l382, !tbaa !24
  br label %bb123
bb123:
  %t544 = load i64, ptr %l382, !tbaa !24
  store i64 %t544, ptr %l55, !tbaa !24
  store i64 0, ptr %l56, !tbaa !24
  br label %bb124
bb124:
  %t545 = load i64, ptr %l56, !tbaa !24
  %t546 = load i64, ptr %l55, !tbaa !24
  %t549 = icmp slt i64 %t545, %t546
  %t551 = xor i1 %t549, true
  br i1 %t551, label %bb125, label %bb126
bb125:
  br label %bb141
bb126:
  br label %bb127
bb127:
  %t553 = load i64, ptr %l52, !tbaa !24
  %t554 = load i64, ptr %l56, !tbaa !24
  %t555 = load i64, ptr %l54, !tbaa !24
  %t558 = mul i64 %t554, %t555
  %t561 = add i64 %t553, %t558
  store i64 %t561, ptr %l57, !tbaa !24
  %t563 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t563, ptr %l403, !tbaa !27
  %t564 = load i64, ptr %l57, !tbaa !24
  %t566 = getelementptr { i64, ptr }, ptr %l403, i32 0, i32 1
  %t567 = load ptr, ptr %t566, !tbaa !27
  %t568 = getelementptr ptr, ptr %t567, i64 %t564
  %t569 = load ptr, ptr %t568, !tbaa !39
  store ptr %t569, ptr %l58, !tbaa !29
  %t571 = load ptr, ptr %l0, !tbaa !29
  store ptr %t571, ptr %l406, !tbaa !29
  %t572 = load ptr, ptr %l0, !tbaa !29
  store ptr %t572, ptr %l407, !tbaa !29
  %t573 = load ptr, ptr %l58, !tbaa !29
  store ptr %t573, ptr %l409, !tbaa !29
  %t575 = load i64, ptr %l57, !tbaa !24
  %t577 = add i64 1, %t575
  %t578 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t580 = extractvalue { i64, ptr } %t578, 0
  %t583 = icmp slt i64 %t577, %t580
  br i1 %t583, label %bb128, label %bb129
bb128:
  %t585 = load i64, ptr %l57, !tbaa !24
  %t587 = add i64 1, %t585
  %t589 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t590 = load ptr, ptr %t589, !tbaa !27
  %t591 = getelementptr i32, ptr %t590, i64 %t587
  %t592 = load i32, ptr %t591, !tbaa !33
  store i32 %t592, ptr %l415, !tbaa !23
  br label %bb130
bb129:
  %t594 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t594, ptr %l415, !tbaa !23
  br label %bb130
bb130:
  %t596 = load ptr, ptr %l407, !tbaa !29
  %t597 = load ptr, ptr %l409, !tbaa !29
  %t598 = load i32, ptr %l415, !tbaa !23
  %t599 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %t596, ptr %t597, i32 %t598)
  store ptr %t599, ptr %l420
  br label %bb131
bb131:
  %t600 = load ptr, ptr %l58, !tbaa !29
  %t602 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t600)
  store %"compiler/source:Span" %t602, ptr %l422
  br label %bb132
bb132:
  %t603 = load ptr, ptr %l406, !tbaa !29
  %t604 = load ptr, ptr %l420, !tbaa !29
  %t605 = load %"compiler/source:Span", ptr %l422
  %t606 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t603, ptr %t604, %"compiler/source:Span" %t605)
  store ptr %t606, ptr %l423
  br label %bb133
bb133:
  %t607 = load ptr, ptr %l423, !tbaa !29
  store ptr %t607, ptr %l59, !tbaa !29
  %t608 = load ptr, ptr %l0, !tbaa !29
  store ptr %t608, ptr %l424, !tbaa !29
  %t609 = load ptr, ptr %l58, !tbaa !29
  %t611 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t609)
  store %"compiler/source:Span" %t611, ptr %l426
  br label %bb134
bb134:
  %t612 = load ptr, ptr %l59, !tbaa !29
  %t615 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t612)
  store i32 %t615, ptr %l429
  br label %bb135
bb135:
  store { i64, [2 x i64] } zeroinitializer, ptr %t616
  %t617 = getelementptr { i64, [2 x i64] }, ptr %t616, i32 0, i32 0
  store i64 0, ptr %t617
  %t618 = load { i64, [2 x i64] }, ptr %t616
  %t619 = load ptr, ptr %l424, !tbaa !29
  %t620 = load %"compiler/source:Span", ptr %l426
  %t621 = load i32, ptr %l429, !tbaa !23
  %t624 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t619, i32 0, %"compiler/source:Span" %t620, i32 %t621, i32 2, { i64, [2 x i64] } %t618)
  store i64 %t624, ptr %l432
  br label %bb136
bb136:
  %t625 = load i64, ptr %l432, !tbaa !24
  store i64 %t625, ptr %l60, !tbaa !24
  %t626 = load ptr, ptr %l0, !tbaa !29
  store ptr %t626, ptr %l433, !tbaa !29
  %t627 = load ptr, ptr %l58, !tbaa !29
  %t629 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t627)
  store %"compiler/source:Span" %t629, ptr %l435
  br label %bb137
bb137:
  %t630 = load i64, ptr %l60, !tbaa !24
  %t632 = trunc i64 %t630 to i32
  %t634 = load ptr, ptr %l59, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t635
  %t636 = getelementptr { i64, [3 x i64] }, ptr %t635, i32 0, i32 0
  store i64 0, ptr %t636
  %t637 = load %"compiler/source:Span", ptr %l435
  %t638 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t637, 0
  %t640 = insertvalue { %"compiler/source:Span", i32, ptr } %t638, i32 %t632, 1
  %t642 = insertvalue { %"compiler/source:Span", i32, ptr } %t640, ptr %t634, 2
  %t643 = getelementptr { i64, [3 x i64] }, ptr %t635, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t642, ptr %t643
  %t644 = load { i64, [3 x i64] }, ptr %t635
  %t646 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t644, ptr %t646
  %t647 = load ptr, ptr %l433, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t647, ptr %t646)
  br label %bb138
bb138:
  %t649 = load i64, ptr %l60, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l50, i64 %t649)
  br label %bb139
bb139:
  br label %bb140
bb140:
  %t652 = load i64, ptr %l56, !tbaa !24
  %t654 = add i64 %t652, 1
  store i64 %t654, ptr %l56, !tbaa !24
  br label %bb124
bb141:
  %t656 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t658 = extractvalue { i64, ptr } %t656, 0
  %t660 = icmp sgt i64 %t658, 0
  br i1 %t660, label %bb142, label %bb143
bb142:
  %t662 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t664 = extractvalue { i64, ptr } %t662, 0
  %t666 = sub i64 %t664, 1
  %t668 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t669 = load ptr, ptr %t668, !tbaa !27
  %t670 = getelementptr i32, ptr %t669, i64 %t666
  %t671 = load i32, ptr %t670, !tbaa !33
  store i32 %t671, ptr %l449, !tbaa !23
  br label %bb144
bb143:
  %t673 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t673, ptr %l449, !tbaa !23
  br label %bb144
bb144:
  %t675 = load i32, ptr %l449, !tbaa !23
  store i32 %t675, ptr %l49, !tbaa !23
  %t676 = load ptr, ptr %l0, !tbaa !29
  store ptr %t676, ptr %l455, !tbaa !29
  %t677 = load i64, ptr %l6, !tbaa !24
  store i64 %t677, ptr %l456, !tbaa !24
  %t678 = load ptr, ptr %l3, !tbaa !29
  %t680 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %t678)
  store i32 %t680, ptr %l458
  br label %bb145
bb145:
  %t681 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t683 = extractvalue { i64, ptr } %t681, 0
  %t685 = sub i64 %t683, 1
  %t686 = load ptr, ptr %l455, !tbaa !29
  %t687 = load i64, ptr %l456, !tbaa !24
  %t688 = load i32, ptr %l458, !tbaa !23
  %t690 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamOn(ptr %v0, ptr %t686, i64 %t687, i32 %t688, i64 %t685)
  store i32 %t690, ptr %l462
  br label %bb146
bb146:
  %t691 = load i32, ptr %l462, !tbaa !23
  store i32 %t691, ptr %l61, !tbaa !23
  %t692 = load i32, ptr %l61, !tbaa !23
  %t693 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t696 = icmp ne i32 %t692, %t693
  br i1 %t696, label %bb147, label %bb148
bb147:
  %t698 = load ptr, ptr %l0, !tbaa !29
  %t699 = load i32, ptr %l61, !tbaa !23
  %t702 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t698, i32 %t699)
  store i1 %t702, ptr %l469
  br label %bb149
bb148:
  store i1 false, ptr %l466, !tbaa !21
  br label %bb150
bb149:
  %t703 = load i1, ptr %l469, !tbaa !21
  store i1 %t703, ptr %l466, !tbaa !21
  br label %bb150
bb150:
  %t704 = load i1, ptr %l466, !tbaa !21
  br i1 %t704, label %bb151, label %bb152
bb151:
  %t705 = load i32, ptr %l61, !tbaa !23
  store i32 %t705, ptr %l49, !tbaa !23
  br label %bb153
bb152:
  br label %bb153
bb153:
  call void @__olang_scope_close(ptr %s19)
  br label %bb154
bb154:
  store ptr null, ptr %l62, !tbaa !29
  store i64 -1, ptr %l63, !tbaa !24
  %t707 = call %"compiler/check:laneVals" @compiler_2fcheck_3alaneVals_2ector(ptr %s0)
  store %"compiler/check:laneVals" %t707, ptr %l471
  br label %bb155
bb155:
  %t708 = load %"compiler/check:laneVals", ptr %l471
  store %"compiler/check:laneVals" %t708, ptr %l64
  %t709 = load i32, ptr %l2, !range !{i32 0, i32 96}
  %t711 = trunc i64 61 to i32
  %t712 = icmp eq i32 %t709, %t711
  br i1 %t712, label %bb156, label %bb157
bb156:
  %t714 = load ptr, ptr %l0, !tbaa !29
  store ptr %t714, ptr %l474, !tbaa !29
  %t715 = load ptr, ptr %l4, !tbaa !29
  %t717 = icmp eq ptr %t715, null
  br i1 %t717, label %bb158, label %bb159
bb157:
  %t719 = load ptr, ptr %l4, !tbaa !29
  %t721 = icmp eq ptr %t719, null
  %t723 = xor i1 %t721, true
  br i1 %t723, label %bb175, label %bb176
bb158:
  call void @__olang_check_failed(ptr @olang_loc_8e17bc78d2dfbd4_98f8be4925a702f0)
  unreachable
bb159:
  br label %bb160
bb160:
  %t725 = load ptr, ptr %l4, !tbaa !29
  %t726 = load i32, ptr %l49, !tbaa !23
  %t727 = load ptr, ptr %l474, !tbaa !29
  %t730 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %t727, ptr %t725, i32 %t726)
  store ptr %t730, ptr %l479
  br label %bb161
bb161:
  %t731 = load ptr, ptr %l479, !tbaa !29
  store ptr %t731, ptr %l62, !tbaa !29
  %t733 = load i32, ptr %l49, !tbaa !23
  store i32 %t733, ptr %l481, !tbaa !23
  %t734 = load ptr, ptr %l0, !tbaa !29
  %t736 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t734)
  store i32 %t736, ptr %l483
  br label %bb162
bb162:
  %t737 = load i32, ptr %l481, !tbaa !23
  %t738 = load i32, ptr %l483, !tbaa !23
  %t739 = icmp eq i32 %t737, %t738
  br i1 %t739, label %bb163, label %bb164
bb163:
  %t741 = load ptr, ptr %l0, !tbaa !29
  store ptr %t741, ptr %l486, !tbaa !29
  %t742 = load ptr, ptr %l62, !tbaa !29
  %t744 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t742)
  store i32 %t744, ptr %l488
  br label %bb165
bb164:
  store i1 false, ptr %l485, !tbaa !21
  br label %bb167
bb165:
  %t745 = load ptr, ptr %l486, !tbaa !29
  %t746 = load i32, ptr %l488, !tbaa !23
  %t747 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t745, i32 %t746)
  store i1 %t747, ptr %l489
  br label %bb166
bb166:
  %t748 = load i1, ptr %l489, !tbaa !21
  store i1 %t748, ptr %l485, !tbaa !21
  br label %bb167
bb167:
  %t749 = load i1, ptr %l485, !tbaa !21
  br i1 %t749, label %bb168, label %bb169
bb168:
  %t750 = load ptr, ptr %l0, !tbaa !29
  store ptr %t750, ptr %l490, !tbaa !29
  %t751 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t751, ptr %l491
  %t752 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t752, ptr %l492
  %t753 = load i32, ptr %l49, !tbaa !23
  store i32 %t753, ptr %l493, !tbaa !23
  %t754 = load ptr, ptr %l62, !tbaa !29
  %t756 = icmp eq ptr %t754, null
  br i1 %t756, label %bb170, label %bb171
bb169:
  br label %bb174
bb170:
  call void @__olang_check_failed(ptr @olang_loc_7c9348342eb48ce3_d1653baf0fdc2fcf)
  unreachable
bb171:
  br label %bb172
bb172:
  %t758 = load ptr, ptr %l62, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t759
  %t760 = getelementptr { i64, [4 x i64] }, ptr %t759, i32 0, i32 0
  store i64 2, ptr %t760
  %t761 = load %"compiler/source:Span", ptr %l492
  %t762 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t761, 0
  %t763 = load i32, ptr %l493, !tbaa !23
  %t764 = insertvalue { %"compiler/source:Span", i32, ptr } %t762, i32 %t763, 1
  %t766 = insertvalue { %"compiler/source:Span", i32, ptr } %t764, ptr %t758, 2
  %t767 = getelementptr { i64, [4 x i64] }, ptr %t759, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t766, ptr %t767
  %t768 = load { i64, [4 x i64] }, ptr %t759
  %t770 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t768, ptr %t770
  %t771 = load ptr, ptr %l490, !tbaa !29
  %t772 = load %"compiler/source:Span", ptr %l491
  %t774 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t771, %"compiler/source:Span" %t772, ptr %t770)
  store ptr %t774, ptr %l499
  br label %bb173
bb173:
  %t775 = load ptr, ptr %l499, !tbaa !29
  store ptr %t775, ptr %l62, !tbaa !29
  br label %bb174
bb174:
  br label %bb281
bb175:
  %t777 = load ptr, ptr %l0, !tbaa !29
  %t778 = load i32, ptr %l49, !tbaa !23
  %t781 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %t777, i32 %t778)
  store i1 %t781, ptr %l507
  br label %bb177
bb176:
  store i1 false, ptr %l504, !tbaa !21
  br label %bb178
bb177:
  %t782 = load i1, ptr %l507, !tbaa !21
  store i1 %t782, ptr %l504, !tbaa !21
  br label %bb178
bb178:
  %t783 = load i1, ptr %l504, !tbaa !21
  br i1 %t783, label %bb179, label %bb180
bb179:
  %t784 = load i32, ptr %l2, !range !{i32 0, i32 96}
  %t786 = call i32 @compiler_2fcheck_2ecompoundOp(i32 %t784)
  store i32 %t786, ptr %l510
  br label %bb181
bb180:
  store i1 false, ptr %l508, !tbaa !21
  br label %bb183
bb181:
  %t787 = load i32, ptr %l510, !range !{i32 0, i32 96}
  %t788 = call i1 @compiler_2fcheck_2elaneTok(i32 %t787)
  store i1 %t788, ptr %l511
  br label %bb182
bb182:
  %t789 = load i1, ptr %l511, !tbaa !21
  store i1 %t789, ptr %l508, !tbaa !21
  br label %bb183
bb183:
  %t790 = load i1, ptr %l508, !tbaa !21
  br i1 %t790, label %bb184, label %bb185
bb184:
  store %olang.scope zeroinitializer, ptr %s27
  %t791 = load ptr, ptr %l0, !tbaa !29
  %t792 = load i32, ptr %l49, !tbaa !23
  %t795 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElemOf(ptr %v0, ptr %t791, i32 %t792)
  store i32 %t795, ptr %l514
  br label %bb186
bb185:
  %t796 = load ptr, ptr %l0, !tbaa !29
  %t797 = load i32, ptr %l49, !tbaa !23
  %t800 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t796, i32 %t797)
  store i1 %t800, ptr %l576
  br label %bb219
bb186:
  %t801 = load i32, ptr %l514, !tbaa !23
  store i32 %t801, ptr %l65, !tbaa !23
  %t802 = load ptr, ptr %l0, !tbaa !29
  store ptr %t802, ptr %l515, !tbaa !29
  %t803 = load ptr, ptr %l0, !tbaa !29
  %t804 = load ptr, ptr %l4, !tbaa !29
  %t805 = load i32, ptr %l65, !tbaa !23
  %t809 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArg(ptr %v0, ptr %v1, ptr %t803, ptr %t804, i32 %t805)
  store ptr %t809, ptr %l519
  br label %bb187
bb187:
  %t810 = load ptr, ptr %l515, !tbaa !29
  %t811 = load ptr, ptr %l519, !tbaa !29
  %t812 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaf(ptr %v0, ptr %t810, ptr %t811)
  store i64 %t812, ptr %l520
  br label %bb188
bb188:
  %t813 = load i64, ptr %l520, !tbaa !24
  store i64 %t813, ptr %l63, !tbaa !24
  %t814 = load ptr, ptr %l0, !tbaa !29
  %t816 = getelementptr %"compiler/check:Checker", ptr %t814, i32 0, i32 39
  %t817 = load i64, ptr %l63, !tbaa !24
  %t820 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s27, ptr %t816, i64 %t817)
  store %"compiler/check:laneNode" %t820, ptr %l524
  br label %bb189
bb189:
  %t821 = getelementptr %"compiler/check:laneNode", ptr %l524, i32 0, i32 8
  %t822 = load i32, ptr %t821, !tbaa !23
  store i32 %t822, ptr %l66, !tbaa !23
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %l526, !tbaa !27
  %t824 = load { i64, ptr }, ptr %l526, !tbaa !27
  store { i64, ptr } %t824, ptr %l527, !tbaa !27
  %t825 = load { i64, ptr }, ptr %l527, !tbaa !27
  %t826 = extractvalue { i64, ptr } %t825, 0
  store i64 %t826, ptr %l528, !tbaa !24
  %t827 = load i64, ptr %l528, !tbaa !24
  %t828 = mul i64 %t827, 1
  %t829 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t828)
  %t830 = insertvalue { i64, ptr } undef, i64 %t827, 0
  %t831 = insertvalue { i64, ptr } %t830, ptr %t829, 1
  store { i64, ptr } %t831, ptr %l529, !tbaa !27
  %t832 = getelementptr { i64, ptr }, ptr %l529, i32 0, i32 1
  %t833 = load ptr, ptr %t832, !tbaa !27
  %t834 = getelementptr { i64, ptr }, ptr %l527, i32 0, i32 1
  %t835 = load ptr, ptr %t834, !tbaa !27
  %t836 = load i64, ptr %l528, !tbaa !24
  %t837 = mul i64 %t836, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t833, ptr %t835, i64 %t837, i1 false)
  %t838 = load { i64, ptr }, ptr %l529, !tbaa !27
  store { i64, ptr } %t838, ptr %l67, !tbaa !27
  %t839 = load ptr, ptr %l0, !tbaa !29
  %t840 = load i32, ptr %l65, !tbaa !23
  %t843 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuiltinElem(ptr %v0, ptr %t839, i32 %t840)
  store i1 %t843, ptr %l532
  br label %bb190
bb190:
  %t844 = load i1, ptr %l532, !tbaa !21
  %t845 = xor i1 %t844, true
  br i1 %t845, label %bb191, label %bb192
bb191:
  store i1 true, ptr %l534, !tbaa !21
  br label %bb194
bb192:
  %t847 = load ptr, ptr %l0, !tbaa !29
  %t848 = load i32, ptr %l66, !tbaa !23
  %t851 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuiltinElem(ptr %v0, ptr %t847, i32 %t848)
  store i1 %t851, ptr %l537
  br label %bb193
bb193:
  %t852 = load i1, ptr %l537, !tbaa !21
  %t853 = xor i1 %t852, true
  store i1 %t853, ptr %l534, !tbaa !21
  br label %bb194
bb194:
  %t855 = load i1, ptr %l534, !tbaa !21
  br i1 %t855, label %bb195, label %bb196
bb195:
  store %olang.scope zeroinitializer, ptr %s28
  %t856 = load i32, ptr %l2, !range !{i32 0, i32 96}
  %t858 = call i32 @compiler_2fcheck_2ecompoundOp(i32 %t856)
  store i32 %t858, ptr %l540
  br label %bb197
bb196:
  %t859 = load ptr, ptr %l0, !tbaa !29
  %t860 = load i64, ptr %l63, !tbaa !24
  %t863 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneMethodCalled(ptr %v0, ptr %s27, ptr %t859, i64 %t860)
  store { i64, ptr } %t863, ptr %l548
  br label %bb202
bb197:
  %t864 = load i32, ptr %l540, !range !{i32 0, i32 96}
  %t865 = call { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %s28, i32 %t864)
  store { i64, ptr } %t865, ptr %l541
  br label %bb198
bb198:
  %t866 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t867 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t868 = load { i64, ptr }, ptr %l541, !tbaa !27
  %t869 = extractvalue { i64, ptr } %t868, 1
  %t870 = extractvalue { i64, ptr } %t868, 0
  %t871 = add i64 %t867, %t870
  %t872 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t873 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t874 = add i64 %t871, %t873
  %t875 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t874)
  call void @olang_textcopy(ptr %t875, ptr %t866, i64 %t867)
  %t876 = getelementptr i8, ptr %t875, i64 %t867
  call void @olang_textcopy(ptr %t876, ptr %t869, i64 %t870)
  %t877 = getelementptr i8, ptr %t876, i64 %t870
  call void @olang_textcopy(ptr %t877, ptr %t872, i64 %t873)
  %t878 = insertvalue { i64, ptr } undef, i64 %t874, 0
  %t879 = insertvalue { i64, ptr } %t878, ptr %t875, 1
  store { i64, ptr } %t879, ptr %l542, !tbaa !27
  %t880 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t881 = extractvalue { i64, ptr } %t880, 0
  %t882 = load { i64, ptr }, ptr %l542, !tbaa !27
  %t883 = extractvalue { i64, ptr } %t882, 0
  store i64 %t883, ptr %l544, !tbaa !24
  %t885 = load i64, ptr %l544, !tbaa !24
  %t886 = icmp eq i64 %t881, %t885
  br i1 %t886, label %bb199, label %bb200
bb199:
  %t888 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t889 = load ptr, ptr %t888, !tbaa !27
  %t890 = getelementptr { i64, ptr }, ptr %l542, i32 0, i32 1
  %t891 = load ptr, ptr %t890, !tbaa !27
  %t892 = load i64, ptr %l544, !tbaa !24
  %t893 = mul i64 %t892, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t889, ptr %t891, i64 %t893, i1 false)
  br label %bb201
bb200:
  %t894 = load { i64, ptr }, ptr %l542, !tbaa !27
  store { i64, ptr } %t894, ptr %l67, !tbaa !27
  br label %bb201
bb201:
  call void @__olang_scope_close(ptr %s28)
  br label %bb206
bb202:
  %t895 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t896 = extractvalue { i64, ptr } %t895, 0
  %t897 = load { i64, ptr }, ptr %l548, !tbaa !27
  %t898 = extractvalue { i64, ptr } %t897, 0
  store i64 %t898, ptr %l550, !tbaa !24
  %t900 = load i64, ptr %l550, !tbaa !24
  %t901 = icmp eq i64 %t896, %t900
  br i1 %t901, label %bb203, label %bb204
bb203:
  %t903 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t904 = load ptr, ptr %t903, !tbaa !27
  %t905 = getelementptr { i64, ptr }, ptr %l548, i32 0, i32 1
  %t906 = load ptr, ptr %t905, !tbaa !27
  %t907 = load i64, ptr %l550, !tbaa !24
  %t908 = mul i64 %t907, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t904, ptr %t906, i64 %t908, i1 false)
  br label %bb205
bb204:
  %t909 = load { i64, ptr }, ptr %l548, !tbaa !27
  store { i64, ptr } %t909, ptr %l67, !tbaa !27
  br label %bb205
bb205:
  br label %bb206
bb206:
  %t910 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t912 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s27, ptr %s27, { i64, ptr } %t910, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d50, i32 0, i32 1) })
  store i1 %t912, ptr %l553
  br label %bb207
bb207:
  %t913 = load i1, ptr %l553, !tbaa !21
  %t914 = xor i1 %t913, true
  br i1 %t914, label %bb208, label %bb209
bb208:
  store %olang.scope zeroinitializer, ptr %s31
  %t916 = load ptr, ptr %l0, !tbaa !29
  store ptr %t916, ptr %l555, !tbaa !29
  %t917 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t917, ptr %l556
  %t918 = load ptr, ptr %l0, !tbaa !29
  store ptr %t918, ptr %l557, !tbaa !29
  %t919 = load ptr, ptr %l0, !tbaa !29
  %t920 = load i32, ptr %l65, !tbaa !23
  %t923 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuiltinElem(ptr %v0, ptr %t919, i32 %t920)
  store i1 %t923, ptr %l560
  br label %bb210
bb209:
  br label %bb217
bb210:
  %t924 = load i1, ptr %l560, !tbaa !21
  %t925 = xor i1 %t924, true
  br i1 %t925, label %bb211, label %bb212
bb211:
  %t927 = load i32, ptr %l65, !tbaa !23
  store i32 %t927, ptr %l562, !tbaa !23
  br label %bb213
bb212:
  %t929 = load i32, ptr %l66, !tbaa !23
  store i32 %t929, ptr %l562, !tbaa !23
  br label %bb213
bb213:
  %t931 = load ptr, ptr %l557, !tbaa !29
  %t932 = load i32, ptr %l562, !tbaa !23
  %t933 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s31, ptr %t931, i32 %t932)
  store { i64, ptr } %t933, ptr %l565
  br label %bb214
bb214:
  %t934 = load { i64, ptr }, ptr %l565, !tbaa !27
  %t935 = extractvalue { i64, ptr } %t934, 0
  %t936 = extractvalue { i64, ptr } %t934, 1
  %t937 = mul i64 %t935, 1
  %t938 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t937)
  call void @llvm.memcpy.p0.p0.i64(ptr %t938, ptr %t936, i64 %t937, i1 false)
  %t939 = insertvalue { i64, ptr } undef, i64 %t935, 0
  %t940 = insertvalue { i64, ptr } %t939, ptr %t938, 1
  %t941 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t944 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eWriteThroughAtOperator(ptr %s31, ptr %s27, ptr %s31, { i64, ptr } %t940, { i64, ptr } %t941)
  store %"compiler/msgs:Msg" %t944, ptr %l568
  br label %bb215
bb215:
  %t945 = load ptr, ptr %l555, !tbaa !29
  %t946 = load %"compiler/source:Span", ptr %l556
  %t947 = load %"compiler/msgs:Msg", ptr %l568
  %t948 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s31, ptr %t945, %"compiler/source:Span" %t946, %"compiler/msgs:Msg" %t947)
  store i64 %t948, ptr %l569
  br label %bb216
bb216:
  call void @__olang_scope_close(ptr %s31)
  call void @__olang_scope_close(ptr %s27)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb217:
  %t950 = load ptr, ptr %l0, !tbaa !29
  %t951 = load i64, ptr %l63, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneHoldLeaves(ptr %v0, ptr %s0, ptr %t950, i64 %t951, ptr %l64)
  br label %bb218
bb218:
  call void @__olang_scope_close(ptr %s27)
  br label %bb280
bb219:
  %t955 = load i1, ptr %l576, !tbaa !21
  %t956 = xor i1 %t955, true
  br i1 %t956, label %bb220, label %bb221
bb220:
  store i1 true, ptr %l578, !tbaa !21
  br label %bb227
bb221:
  %t958 = load ptr, ptr %l0, !tbaa !29
  %t959 = load i32, ptr %l49, !tbaa !23
  %t962 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t958, i32 %t959)
  store i1 %t962, ptr %l581
  br label %bb222
bb222:
  %t963 = load i1, ptr %l581, !tbaa !21
  br i1 %t963, label %bb223, label %bb224
bb223:
  %t964 = load ptr, ptr %l0, !tbaa !29
  %t966 = getelementptr %"compiler/check:Checker", ptr %t964, i32 0, i32 1
  %t967 = load ptr, ptr %t966, !tbaa !29
  %t968 = load i32, ptr %l49, !tbaa !23
  %t971 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t967, i32 %t968)
  store i1 %t971, ptr %l586
  br label %bb225
bb224:
  store i1 false, ptr %l582, !tbaa !21
  br label %bb226
bb225:
  %t972 = load i1, ptr %l586, !tbaa !21
  %t973 = xor i1 %t972, true
  store i1 %t973, ptr %l582, !tbaa !21
  br label %bb226
bb226:
  %t975 = load i1, ptr %l582, !tbaa !21
  store i1 %t975, ptr %l578, !tbaa !21
  br label %bb227
bb227:
  %t976 = load i1, ptr %l578, !tbaa !21
  br i1 %t976, label %bb228, label %bb229
bb228:
  %t977 = load i32, ptr %l49, !tbaa !23
  %t978 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t981 = icmp ne i32 %t977, %t978
  br i1 %t981, label %bb230, label %bb231
bb229:
  br label %bb234
bb230:
  %t983 = load ptr, ptr %l0, !tbaa !29
  %t984 = load %"compiler/source:Span", ptr %l1
  %t985 = load i32, ptr %l2, !range !{i32 0, i32 96}
  %t986 = load i32, ptr %l49, !tbaa !23
  %t987 = load ptr, ptr %l4, !tbaa !29
  %t988 = load %"compiler/source:Span", ptr %l5
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewriteBackNoNumber(ptr %v0, ptr %v1, ptr %t983, %"compiler/source:Span" %t984, i32 %t985, i32 %t986, ptr %t987, %"compiler/source:Span" %t988)
  br label %bb232
bb231:
  br label %bb233
bb232:
  br label %bb233
bb233:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb234:
  %t996 = load ptr, ptr %l4, !tbaa !29
  %t998 = icmp eq ptr %t996, null
  br i1 %t998, label %bb235, label %bb236
bb235:
  %t1000 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1000, ptr %l600, !tbaa !29
  %t1001 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1001, ptr %l601
  %t1002 = load i32, ptr %l49, !tbaa !23
  store i32 %t1002, ptr %l602, !tbaa !23
  %t1003 = load ptr, ptr %l0, !tbaa !29
  %t1005 = getelementptr %"compiler/check:Checker", ptr %t1003, i32 0, i32 1
  %t1006 = load ptr, ptr %t1005, !tbaa !29
  %t1008 = getelementptr %"compiler/generic:Program", ptr %t1006, i32 0, i32 2
  store ptr %t1008, ptr %l605, !tbaa !29
  %t1009 = load ptr, ptr %l0, !tbaa !29
  %t1010 = load i32, ptr %l49, !tbaa !23
  %t1013 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t1009, i32 %t1010)
  store i32 %t1013, ptr %l608
  br label %bb237
bb236:
  %t1014 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1014, ptr %l617, !tbaa !29
  %t1015 = load ptr, ptr %l0, !tbaa !29
  %t1016 = load ptr, ptr %l4, !tbaa !29
  %t1018 = load i32, ptr %l49, !tbaa !23
  %t1022 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t1015, ptr %t1016, i32 %t1018)
  store ptr %t1022, ptr %l622
  br label %bb245
bb237:
  %t1023 = load ptr, ptr %l605, !tbaa !29
  %t1024 = load i32, ptr %l608, !tbaa !23
  %t1025 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t1023, i32 %t1024)
  store i1 %t1025, ptr %l609
  br label %bb238
bb238:
  %t1026 = load i1, ptr %l609, !tbaa !21
  br i1 %t1026, label %bb239, label %bb240
bb239:
  %t1027 = load ptr, ptr %l0, !tbaa !29
  %t1028 = load i32, ptr %l49, !tbaa !23
  %t1031 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t1027, i32 %t1028)
  store i32 %t1031, ptr %l613
  br label %bb241
bb240:
  store i64 1, ptr %l610, !tbaa !24
  br label %bb243
bb241:
  %t1032 = load i32, ptr %l613, !tbaa !23
  %t1033 = call i64 @compiler_2fcheck_2efloatBits(i32 %t1032, double 0x3ff0000000000000)
  store i64 %t1033, ptr %l614
  br label %bb242
bb242:
  %t1034 = load i64, ptr %l614, !tbaa !24
  store i64 %t1034, ptr %l610, !tbaa !24
  br label %bb243
bb243:
  %t1035 = load ptr, ptr %l600, !tbaa !29
  %t1036 = load %"compiler/source:Span", ptr %l601
  %t1037 = load i32, ptr %l602, !tbaa !23
  %t1038 = load i64, ptr %l610, !tbaa !24
  %t1039 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t1035, %"compiler/source:Span" %t1036, i32 %t1037, i64 %t1038)
  store ptr %t1039, ptr %l615
  br label %bb244
bb244:
  %t1040 = load ptr, ptr %l615, !tbaa !29
  store ptr %t1040, ptr %l62, !tbaa !29
  br label %bb279
bb245:
  %t1042 = load %"compiler/source:Span", ptr %l8
  %t1043 = load ptr, ptr %l617, !tbaa !29
  %t1044 = load ptr, ptr %l622, !tbaa !29
  %t1046 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t1043, ptr %t1044, %"compiler/source:Span" %t1042)
  store ptr %t1046, ptr %l624
  br label %bb246
bb246:
  %t1047 = load ptr, ptr %l624, !tbaa !29
  store ptr %t1047, ptr %l62, !tbaa !29
  %t1049 = load ptr, ptr %l62, !tbaa !29
  %t1051 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1049)
  store i32 %t1051, ptr %l627
  br label %bb247
bb247:
  %t1052 = load i32, ptr %l49, !tbaa !23
  %t1053 = load i32, ptr %l627, !tbaa !23
  %t1055 = icmp ne i32 %t1053, %t1052
  br i1 %t1055, label %bb248, label %bb249
bb248:
  %t1057 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1057, ptr %l631, !tbaa !29
  %t1058 = load ptr, ptr %l62, !tbaa !29
  %t1060 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1058)
  store i32 %t1060, ptr %l633
  br label %bb250
bb249:
  store i1 false, ptr %l630, !tbaa !21
  br label %bb252
bb250:
  %t1061 = load ptr, ptr %l631, !tbaa !29
  %t1062 = load i32, ptr %l633, !tbaa !23
  %t1063 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t1061, i32 %t1062)
  store i1 %t1063, ptr %l634
  br label %bb251
bb251:
  %t1064 = load i1, ptr %l634, !tbaa !21
  store i1 %t1064, ptr %l630, !tbaa !21
  br label %bb252
bb252:
  %t1065 = load i1, ptr %l630, !tbaa !21
  br i1 %t1065, label %bb253, label %bb254
bb253:
  %t1066 = load ptr, ptr %l0, !tbaa !29
  %t1068 = getelementptr %"compiler/check:Checker", ptr %t1066, i32 0, i32 1
  %t1069 = load ptr, ptr %t1068, !tbaa !29
  store ptr %t1069, ptr %l637, !tbaa !29
  %t1070 = load ptr, ptr %l62, !tbaa !29
  %t1072 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1070)
  store i32 %t1072, ptr %l639
  br label %bb255
bb254:
  store i1 false, ptr %l635, !tbaa !21
  br label %bb257
bb255:
  %t1073 = load i32, ptr %l49, !tbaa !23
  %t1074 = load ptr, ptr %l637, !tbaa !29
  %t1075 = load i32, ptr %l639, !tbaa !23
  %t1077 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFlows(ptr %v0, ptr %t1074, i32 %t1075, i32 %t1073)
  store i1 %t1077, ptr %l641
  br label %bb256
bb256:
  %t1078 = load i1, ptr %l641, !tbaa !21
  store i1 %t1078, ptr %l635, !tbaa !21
  br label %bb257
bb257:
  %t1079 = load i1, ptr %l635, !tbaa !21
  br i1 %t1079, label %bb258, label %bb259
bb258:
  %t1080 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1080, ptr %l642, !tbaa !29
  %t1081 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t1081, ptr %l643
  %t1082 = load ptr, ptr %l62, !tbaa !29
  %t1084 = icmp eq ptr %t1082, null
  br i1 %t1084, label %bb260, label %bb261
bb259:
  br label %bb264
bb260:
  call void @__olang_check_failed(ptr @olang_loc_161638cb42cb28fe_744a250164fb3182)
  unreachable
bb261:
  br label %bb262
bb262:
  %t1086 = load ptr, ptr %l62, !tbaa !29
  %t1087 = load i32, ptr %l49, !tbaa !23
  %t1088 = load ptr, ptr %l642, !tbaa !29
  %t1089 = load %"compiler/source:Span", ptr %l643
  %t1092 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t1088, %"compiler/source:Span" %t1089, ptr %t1086, i32 %t1087)
  store ptr %t1092, ptr %l648
  br label %bb263
bb263:
  %t1093 = load ptr, ptr %l648, !tbaa !29
  store ptr %t1093, ptr %l62, !tbaa !29
  br label %bb264
bb264:
  %t1095 = load i32, ptr %l2, !range !{i32 0, i32 96}
  %t1097 = call i32 @compiler_2fcheck_2ecompoundOp(i32 %t1095)
  store i32 %t1097, ptr %l651
  br label %bb265
bb265:
  %t1098 = load i32, ptr %l651, !range !{i32 0, i32 96}
  store i32 %t1098, ptr %l68
  %t1099 = load i32, ptr %l68, !range !{i32 0, i32 96}
  %t1101 = trunc i64 88 to i32
  %t1102 = icmp eq i32 %t1099, %t1101
  br i1 %t1102, label %bb266, label %bb267
bb266:
  store i1 true, ptr %l654, !tbaa !21
  br label %bb268
bb267:
  %t1104 = load i32, ptr %l68, !range !{i32 0, i32 96}
  %t1106 = trunc i64 89 to i32
  %t1107 = icmp eq i32 %t1104, %t1106
  store i1 %t1107, ptr %l654, !tbaa !21
  br label %bb268
bb268:
  %t1109 = load i1, ptr %l654, !tbaa !21
  br i1 %t1109, label %bb269, label %bb270
bb269:
  %t1110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1110, ptr %l658, !tbaa !29
  %t1111 = load i32, ptr %l49, !tbaa !23
  store i32 %t1111, ptr %l659, !tbaa !23
  %t1112 = load ptr, ptr %l62, !tbaa !29
  %t1114 = icmp eq ptr %t1112, null
  br i1 %t1114, label %bb271, label %bb272
bb270:
  store i1 false, ptr %l657, !tbaa !21
  br label %bb275
bb271:
  call void @__olang_check_failed(ptr @olang_loc_d3f4fca21c1b05a5_cc4b7e60173cb869)
  unreachable
bb272:
  br label %bb273
bb273:
  %t1116 = load ptr, ptr %l62, !tbaa !29
  %t1117 = load %"compiler/source:Span", ptr %l8
  %t1118 = load ptr, ptr %l658, !tbaa !29
  %t1119 = load i32, ptr %l659, !tbaa !23
  %t1122 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftInRange(ptr %v0, ptr %v0, ptr %t1118, i32 %t1119, ptr %t1116, %"compiler/source:Span" %t1117)
  store i1 %t1122, ptr %l664
  br label %bb274
bb274:
  %t1123 = load i1, ptr %l664, !tbaa !21
  %t1124 = xor i1 %t1123, true
  store i1 %t1124, ptr %l657, !tbaa !21
  br label %bb275
bb275:
  %t1126 = load i1, ptr %l657, !tbaa !21
  br i1 %t1126, label %bb276, label %bb277
bb276:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb277:
  br label %bb278
bb278:
  br label %bb279
bb279:
  br label %bb280
bb280:
  br label %bb281
bb281:
  %t1128 = load i64, ptr %l63, !tbaa !24
  %t1130 = icmp sge i64 %t1128, 0
  br i1 %t1130, label %bb282, label %bb283
bb282:
  store i1 true, ptr %l669, !tbaa !21
  br label %bb291
bb283:
  %t1132 = load i32, ptr %l2, !range !{i32 0, i32 96}
  %t1134 = trunc i64 61 to i32
  %t1135 = icmp eq i32 %t1132, %t1134
  br i1 %t1135, label %bb284, label %bb285
bb284:
  %t1137 = load ptr, ptr %l62, !tbaa !29
  %t1139 = icmp eq ptr %t1137, null
  br i1 %t1139, label %bb286, label %bb287
bb285:
  store i1 false, ptr %l672, !tbaa !21
  br label %bb290
bb286:
  call void @__olang_check_failed(ptr @olang_loc_21f488b3c5e8e750_2d22ad345f3d4574)
  unreachable
bb287:
  br label %bb288
bb288:
  %t1141 = load ptr, ptr %l62, !tbaa !29
  %t1143 = call i1 @compiler_2fcheck_2elocalRead(ptr %v0, ptr %t1141)
  store i1 %t1143, ptr %l676
  br label %bb289
bb289:
  %t1144 = load i1, ptr %l676, !tbaa !21
  store i1 %t1144, ptr %l672, !tbaa !21
  br label %bb290
bb290:
  %t1145 = load i1, ptr %l672, !tbaa !21
  store i1 %t1145, ptr %l669, !tbaa !21
  br label %bb291
bb291:
  %t1146 = load i1, ptr %l669, !tbaa !21
  store i1 %t1146, ptr %l69, !tbaa !21
  store i64 -1, ptr %l70, !tbaa !24
  %t1147 = load i1, ptr %l69, !tbaa !21
  %t1149 = xor i1 %t1147, true
  br i1 %t1149, label %bb292, label %bb293
bb292:
  %t1151 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1151, ptr %l679, !tbaa !29
  %t1152 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t1152, ptr %l680
  %t1153 = load ptr, ptr %l62, !tbaa !29
  %t1155 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1153)
  store i32 %t1155, ptr %l682
  br label %bb294
bb293:
  br label %bb300
bb294:
  store { i64, [2 x i64] } zeroinitializer, ptr %t1156
  %t1157 = getelementptr { i64, [2 x i64] }, ptr %t1156, i32 0, i32 0
  store i64 0, ptr %t1157
  %t1158 = load { i64, [2 x i64] }, ptr %t1156
  %t1159 = load ptr, ptr %l679, !tbaa !29
  %t1160 = load %"compiler/source:Span", ptr %l680
  %t1161 = load i32, ptr %l682, !tbaa !23
  %t1164 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t1159, i32 0, %"compiler/source:Span" %t1160, i32 %t1161, i32 2, { i64, [2 x i64] } %t1158)
  store i64 %t1164, ptr %l685
  br label %bb295
bb295:
  %t1165 = load i64, ptr %l685, !tbaa !24
  store i64 %t1165, ptr %l70, !tbaa !24
  %t1166 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1166, ptr %l686, !tbaa !29
  %t1167 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t1167, ptr %l687
  %t1168 = load i64, ptr %l70, !tbaa !24
  %t1170 = trunc i64 %t1168 to i32
  store i32 %t1170, ptr %l690, !tbaa !23
  %t1172 = load ptr, ptr %l62, !tbaa !29
  %t1174 = icmp eq ptr %t1172, null
  br i1 %t1174, label %bb296, label %bb297
bb296:
  call void @__olang_check_failed(ptr @olang_loc_f30c3194d6b62caf_3ce94d7e88579503)
  unreachable
bb297:
  br label %bb298
bb298:
  %t1176 = load ptr, ptr %l62, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t1177
  %t1178 = getelementptr { i64, [3 x i64] }, ptr %t1177, i32 0, i32 0
  store i64 0, ptr %t1178
  %t1179 = load %"compiler/source:Span", ptr %l687
  %t1180 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1179, 0
  %t1181 = load i32, ptr %l690, !tbaa !23
  %t1182 = insertvalue { %"compiler/source:Span", i32, ptr } %t1180, i32 %t1181, 1
  %t1184 = insertvalue { %"compiler/source:Span", i32, ptr } %t1182, ptr %t1176, 2
  %t1185 = getelementptr { i64, [3 x i64] }, ptr %t1177, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1184, ptr %t1185
  %t1186 = load { i64, [3 x i64] }, ptr %t1177
  %t1188 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t1186, ptr %t1188
  %t1189 = load ptr, ptr %l686, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t1189, ptr %t1188)
  br label %bb299
bb299:
  br label %bb300
bb300:
  %t1191 = load i64, ptr %l14, !tbaa !24
  store i64 %t1191, ptr %l696, !tbaa !24
  %t1192 = load i64, ptr %l696, !tbaa !24
  %t1193 = icmp sge i64 %t1192, 0
  br i1 %t1193, label %bb301, label %bb302
bb301:
  %t1195 = load i64, ptr %l696, !tbaa !24
  %t1196 = icmp sle i64 %t1195, 1152921504606846975
  br i1 %t1196, label %bb303, label %bb304
bb302:
  call void @__olang_check_failed(ptr @olang_loc_cb5bd539a2ebdd1a_6c90c646f95f810e)
  unreachable
bb303:
  %t1198 = load i64, ptr %l696, !tbaa !24
  %t1199 = mul i64 %t1198, 8
  %t1200 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1199)
  store i64 0, ptr %t1201
  br label %fill.1202
fill.1202:
  %t1205 = load i64, ptr %t1201
  %t1206 = icmp slt i64 %t1205, %t1198
  br i1 %t1206, label %fillb.1203, label %filld.1204
fillb.1203:
  %t1207 = getelementptr i64, ptr %t1200, i64 %t1205
  store i64 -1, ptr %t1207
  %t1208 = add i64 %t1205, 1
  store i64 %t1208, ptr %t1201
  br label %fill.1202
filld.1204:
  %t1209 = insertvalue { i64, ptr } undef, i64 %t1198, 0
  %t1210 = insertvalue { i64, ptr } %t1209, ptr %t1200, 1
  store { i64, ptr } %t1210, ptr %l71, !tbaa !27
  %t1212 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1212, ptr %l700
  br label %bb305
bb304:
  call void @__olang_check_failed(ptr @olang_loc_cb5bd539a2ebdd1a_6c90c646f95f810e)
  unreachable
bb305:
  %t1213 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l700
  %t1214 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1213, ptr %t1214
  store ptr %t1214, ptr %l72, !tbaa !29
  store i64 0, ptr %l73, !tbaa !24
  %t1216 = load i64, ptr %l14, !tbaa !24
  store i64 %t1216, ptr %l74, !tbaa !24
  store i64 1, ptr %l75, !tbaa !24
  %t1218 = load i64, ptr %l74, !tbaa !24
  %t1219 = load i64, ptr %l73, !tbaa !24
  %t1222 = icmp sgt i64 %t1218, %t1219
  br i1 %t1222, label %bb306, label %bb307
bb306:
  %t1224 = load i64, ptr %l75, !tbaa !24
  %t1226 = icmp sgt i64 %t1224, 0
  br i1 %t1226, label %bb308, label %bb309
bb307:
  store i64 0, ptr %l706, !tbaa !24
  br label %bb311
bb308:
  %t1228 = load i64, ptr %l74, !tbaa !24
  %t1229 = load i64, ptr %l73, !tbaa !24
  %t1232 = sub i64 %t1228, %t1229
  %t1233 = load i64, ptr %l75, !tbaa !24
  %t1236 = add i64 %t1232, %t1233
  %t1238 = sub i64 %t1236, 1
  %t1239 = load i64, ptr %l75, !tbaa !24
  %t1242 = sdiv i64 %t1238, %t1239
  store i64 %t1242, ptr %l709, !tbaa !24
  br label %bb310
bb309:
  store i64 0, ptr %l709, !tbaa !24
  br label %bb310
bb310:
  %t1244 = load i64, ptr %l709, !tbaa !24
  store i64 %t1244, ptr %l706, !tbaa !24
  br label %bb311
bb311:
  %t1245 = load i64, ptr %l706, !tbaa !24
  store i64 %t1245, ptr %l76, !tbaa !24
  store i64 0, ptr %l77, !tbaa !24
  br label %bb312
bb312:
  %t1246 = load i64, ptr %l77, !tbaa !24
  %t1247 = load i64, ptr %l76, !tbaa !24
  %t1250 = icmp slt i64 %t1246, %t1247
  %t1252 = xor i1 %t1250, true
  br i1 %t1252, label %bb313, label %bb314
bb313:
  br label %bb318
bb314:
  br label %bb315
bb315:
  %t1254 = load i64, ptr %l73, !tbaa !24
  %t1255 = load i64, ptr %l77, !tbaa !24
  %t1256 = load i64, ptr %l75, !tbaa !24
  %t1259 = mul i64 %t1255, %t1256
  %t1262 = add i64 %t1254, %t1259
  store i64 %t1262, ptr %l78, !tbaa !24
  %t1264 = load ptr, ptr %l72, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eP_Ha5c233616e2ae02d7fe37742cfaef2c2(ptr %v0, ptr %v0, ptr %t1264, ptr null)
  br label %bb316
bb316:
  br label %bb317
bb317:
  %t1266 = load i64, ptr %l77, !tbaa !24
  %t1268 = add i64 %t1266, 1
  store i64 %t1268, ptr %l77, !tbaa !24
  br label %bb312
bb318:
  store i64 0, ptr %l79, !tbaa !24
  %t1270 = load i64, ptr %l14, !tbaa !24
  store i64 %t1270, ptr %l80, !tbaa !24
  store i64 1, ptr %l81, !tbaa !24
  %t1272 = load i64, ptr %l80, !tbaa !24
  %t1273 = load i64, ptr %l79, !tbaa !24
  %t1276 = icmp sgt i64 %t1272, %t1273
  br i1 %t1276, label %bb319, label %bb320
bb319:
  %t1278 = load i64, ptr %l81, !tbaa !24
  %t1280 = icmp sgt i64 %t1278, 0
  br i1 %t1280, label %bb321, label %bb322
bb320:
  store i64 0, ptr %l734, !tbaa !24
  br label %bb324
bb321:
  %t1282 = load i64, ptr %l80, !tbaa !24
  %t1283 = load i64, ptr %l79, !tbaa !24
  %t1286 = sub i64 %t1282, %t1283
  %t1287 = load i64, ptr %l81, !tbaa !24
  %t1290 = add i64 %t1286, %t1287
  %t1292 = sub i64 %t1290, 1
  %t1293 = load i64, ptr %l81, !tbaa !24
  %t1296 = sdiv i64 %t1292, %t1293
  store i64 %t1296, ptr %l737, !tbaa !24
  br label %bb323
bb322:
  store i64 0, ptr %l737, !tbaa !24
  br label %bb323
bb323:
  %t1298 = load i64, ptr %l737, !tbaa !24
  store i64 %t1298, ptr %l734, !tbaa !24
  br label %bb324
bb324:
  %t1299 = load i64, ptr %l734, !tbaa !24
  store i64 %t1299, ptr %l82, !tbaa !24
  store i64 0, ptr %l83, !tbaa !24
  br label %bb325
bb325:
  store %olang.scope zeroinitializer, ptr %s44
  %t1300 = load i64, ptr %l83, !tbaa !24
  %t1301 = load i64, ptr %l82, !tbaa !24
  %t1304 = icmp slt i64 %t1300, %t1301
  %t1306 = xor i1 %t1304, true
  br i1 %t1306, label %bb326, label %bb327
bb326:
  call void @__olang_scope_close(ptr %s44)
  br label %bb372
bb327:
  br label %bb328
bb328:
  %t1308 = load i64, ptr %l79, !tbaa !24
  %t1309 = load i64, ptr %l83, !tbaa !24
  %t1310 = load i64, ptr %l81, !tbaa !24
  %t1313 = mul i64 %t1309, %t1310
  %t1316 = add i64 %t1308, %t1313
  %t1318 = load i64, ptr %l14, !tbaa !24
  %t1320 = sub i64 %t1318, 1
  %t1324 = sub i64 %t1320, %t1316
  store i64 %t1324, ptr %l85, !tbaa !24
  %t1326 = load ptr, ptr %l0, !tbaa !29
  %t1328 = getelementptr %"compiler/check:Checker", ptr %t1326, i32 0, i32 38
  store ptr %t1328, ptr %l760, !tbaa !29
  %t1329 = load i64, ptr %l85, !tbaa !24
  %t1332 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l10, i64 %t1329)
  store i64 %t1332, ptr %l763
  br label %bb329
bb329:
  %t1333 = load ptr, ptr %l760, !tbaa !29
  %t1334 = load i64, ptr %l763, !tbaa !24
  %t1335 = call %"compiler/check:atRec" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aatRec_3e_2eAt_3ccompiler_2fcheck_3aatRec_3e(ptr %v0, ptr %v0, ptr %t1333, i64 %t1334)
  store %"compiler/check:atRec" %t1335, ptr %l764
  br label %bb330
bb330:
  %t1336 = getelementptr %"compiler/check:atRec", ptr %l764, i32 0, i32 2
  %t1337 = load ptr, ptr %t1336, !tbaa !29
  store ptr %t1337, ptr %l86, !tbaa !29
  %t1339 = load i64, ptr %l85, !tbaa !24
  %t1341 = add i64 %t1339, 1
  %t1342 = load i64, ptr %l14, !tbaa !24
  %t1345 = icmp slt i64 %t1341, %t1342
  br i1 %t1345, label %bb331, label %bb332
bb331:
  %t1347 = load ptr, ptr %l0, !tbaa !29
  %t1348 = load ptr, ptr %l86, !tbaa !29
  %t1349 = load i64, ptr %l85, !tbaa !24
  %t1351 = add i64 %t1349, 1
  %t1353 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t1354 = load ptr, ptr %t1353, !tbaa !27
  %t1355 = getelementptr i64, ptr %t1354, i64 %t1351
  %t1356 = load i64, ptr %t1355, !tbaa !34
  %t1360 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereplaceTemp(ptr %v0, ptr %t1347, ptr %t1348, i64 %t1356)
  store ptr %t1360, ptr %l775
  br label %bb333
bb332:
  br label %bb334
bb333:
  %t1361 = load ptr, ptr %l775, !tbaa !29
  store ptr %t1361, ptr %l86, !tbaa !29
  br label %bb334
bb334:
  %t1362 = load ptr, ptr %l72, !tbaa !29
  %t1363 = load i64, ptr %l85, !tbaa !24
  %t1364 = load ptr, ptr %l86, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eS_H34f0b8d4004ea3d8dbd5c02acd682062(ptr %v0, ptr %v0, ptr %t1362, i64 %t1363, ptr %t1364)
  br label %bb335
bb335:
  %t1369 = load ptr, ptr %l25, !tbaa !29
  %t1370 = load i64, ptr %l85, !tbaa !24
  %t1373 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t1369, i64 %t1370)
  store { i64, ptr } %t1373, ptr %l782
  br label %bb336
bb336:
  %t1374 = load { i64, ptr }, ptr %l782, !tbaa !27
  store { i64, ptr } %t1374, ptr %l87, !tbaa !27
  %t1375 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t1377 = extractvalue { i64, ptr } %t1375, 0
  store i64 %t1377, ptr %l784, !tbaa !24
  %t1378 = load ptr, ptr %l0, !tbaa !29
  %t1379 = load %"compiler/source:Span", ptr %l1
  %t1382 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehole(ptr %v0, ptr %t1378, %"compiler/source:Span" %t1379)
  store ptr %t1382, ptr %l787
  br label %bb337
bb337:
  %t1383 = load i64, ptr %l784, !tbaa !24
  %t1384 = icmp sge i64 %t1383, 0
  br i1 %t1384, label %bb338, label %bb339
bb338:
  %t1386 = load i64, ptr %l784, !tbaa !24
  %t1387 = icmp sle i64 %t1386, 1152921504606846975
  br i1 %t1387, label %bb340, label %bb341
bb339:
  call void @__olang_check_failed(ptr @olang_loc_ec12a5e6811badef_17bc7d420925a003)
  unreachable
bb340:
  %t1389 = load i64, ptr %l784, !tbaa !24
  %t1390 = mul i64 %t1389, 8
  %t1391 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t1390)
  %t1392 = load ptr, ptr %l787, !tbaa !29
  store i64 0, ptr %t1393
  br label %fill.1394
fill.1394:
  %t1397 = load i64, ptr %t1393
  %t1398 = icmp slt i64 %t1397, %t1389
  br i1 %t1398, label %fillb.1395, label %filld.1396
fillb.1395:
  %t1399 = getelementptr ptr, ptr %t1391, i64 %t1397
  store ptr %t1392, ptr %t1399
  %t1400 = add i64 %t1397, 1
  store i64 %t1400, ptr %t1393
  br label %fill.1394
filld.1396:
  %t1401 = insertvalue { i64, ptr } undef, i64 %t1389, 0
  %t1402 = insertvalue { i64, ptr } %t1401, ptr %t1391, 1
  store { i64, ptr } %t1402, ptr %l88, !tbaa !27
  store i64 0, ptr %l89, !tbaa !24
  %t1404 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t1406 = extractvalue { i64, ptr } %t1404, 0
  store i64 %t1406, ptr %l90, !tbaa !24
  store i64 1, ptr %l91, !tbaa !24
  %t1408 = load i64, ptr %l90, !tbaa !24
  %t1409 = load i64, ptr %l89, !tbaa !24
  %t1412 = icmp sgt i64 %t1408, %t1409
  br i1 %t1412, label %bb342, label %bb343
bb341:
  call void @__olang_check_failed(ptr @olang_loc_ec12a5e6811badef_17bc7d420925a003)
  unreachable
bb342:
  %t1414 = load i64, ptr %l91, !tbaa !24
  %t1416 = icmp sgt i64 %t1414, 0
  br i1 %t1416, label %bb344, label %bb345
bb343:
  store i64 0, ptr %l796, !tbaa !24
  br label %bb347
bb344:
  %t1418 = load i64, ptr %l90, !tbaa !24
  %t1419 = load i64, ptr %l89, !tbaa !24
  %t1422 = sub i64 %t1418, %t1419
  %t1423 = load i64, ptr %l91, !tbaa !24
  %t1426 = add i64 %t1422, %t1423
  %t1428 = sub i64 %t1426, 1
  %t1429 = load i64, ptr %l91, !tbaa !24
  %t1432 = sdiv i64 %t1428, %t1429
  store i64 %t1432, ptr %l799, !tbaa !24
  br label %bb346
bb345:
  store i64 0, ptr %l799, !tbaa !24
  br label %bb346
bb346:
  %t1434 = load i64, ptr %l799, !tbaa !24
  store i64 %t1434, ptr %l796, !tbaa !24
  br label %bb347
bb347:
  %t1435 = load i64, ptr %l796, !tbaa !24
  store i64 %t1435, ptr %l92, !tbaa !24
  store i64 0, ptr %l93, !tbaa !24
  br label %bb348
bb348:
  %t1436 = load i64, ptr %l93, !tbaa !24
  %t1437 = load i64, ptr %l92, !tbaa !24
  %t1440 = icmp slt i64 %t1436, %t1437
  %t1442 = xor i1 %t1440, true
  br i1 %t1442, label %bb349, label %bb350
bb349:
  br label %bb354
bb350:
  br label %bb351
bb351:
  %t1444 = load i64, ptr %l89, !tbaa !24
  %t1445 = load i64, ptr %l93, !tbaa !24
  %t1446 = load i64, ptr %l91, !tbaa !24
  %t1449 = mul i64 %t1445, %t1446
  %t1452 = add i64 %t1444, %t1449
  store i64 %t1452, ptr %l94, !tbaa !24
  %t1454 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t1454, ptr %l817, !tbaa !27
  %t1455 = load i64, ptr %l94, !tbaa !24
  store i64 %t1455, ptr %l818, !tbaa !24
  %t1456 = load ptr, ptr %l0, !tbaa !29
  %t1457 = load %"compiler/source:Span", ptr %l1
  %t1458 = load { i64, ptr }, ptr %l87, !tbaa !27
  store { i64, ptr } %t1458, ptr %l821, !tbaa !27
  %t1459 = load i64, ptr %l94, !tbaa !24
  %t1461 = getelementptr { i64, ptr }, ptr %l821, i32 0, i32 1
  %t1462 = load ptr, ptr %t1461, !tbaa !27
  %t1463 = getelementptr i64, ptr %t1462, i64 %t1459
  %t1464 = load i64, ptr %t1463, !tbaa !34
  %t1468 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t1456, %"compiler/source:Span" %t1457, i64 %t1464)
  store ptr %t1468, ptr %l824
  br label %bb352
bb352:
  %t1469 = load ptr, ptr %l824, !tbaa !29
  %t1470 = load i64, ptr %l818, !tbaa !24
  %t1471 = getelementptr { i64, ptr }, ptr %l817, i32 0, i32 1
  %t1472 = load ptr, ptr %t1471, !tbaa !27
  %t1473 = getelementptr ptr, ptr %t1472, i64 %t1470
  store ptr %t1469, ptr %t1473, !tbaa !39
  br label %bb353
bb353:
  %t1474 = load i64, ptr %l93, !tbaa !24
  %t1476 = add i64 %t1474, 1
  store i64 %t1476, ptr %l93, !tbaa !24
  br label %bb348
bb354:
  %t1478 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1478, ptr %l827, !tbaa !29
  %t1479 = load ptr, ptr %l0, !tbaa !29
  %t1481 = getelementptr %"compiler/check:Checker", ptr %t1479, i32 0, i32 38
  store ptr %t1481, ptr %l829, !tbaa !29
  %t1482 = load i64, ptr %l85, !tbaa !24
  %t1485 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l10, i64 %t1482)
  store i64 %t1485, ptr %l832
  br label %bb355
bb355:
  %t1486 = load ptr, ptr %l829, !tbaa !29
  %t1487 = load i64, ptr %l832, !tbaa !24
  %t1488 = call %"compiler/check:atRec" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aatRec_3e_2eAt_3ccompiler_2fcheck_3aatRec_3e(ptr %v0, ptr %s44, ptr %t1486, i64 %t1487)
  store %"compiler/check:atRec" %t1488, ptr %l833
  br label %bb356
bb356:
  %t1489 = getelementptr %"compiler/check:atRec", ptr %l833, i32 0, i32 3
  %t1490 = load i32, ptr %t1489, !tbaa !23
  %t1491 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t1493 = extractvalue { i64, ptr } %t1491, 0
  %t1494 = load ptr, ptr %l827, !tbaa !29
  %t1497 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s44, ptr %t1494, i32 %t1490, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d51, i32 0, i32 1) }, i64 %t1493)
  store i64 %t1497, ptr %l837
  br label %bb357
bb357:
  %t1498 = load i64, ptr %l837, !tbaa !24
  %t1499 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1499, ptr %l838, !tbaa !29
  %t1500 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1500, ptr %l839
  %t1501 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1501, ptr %l840
  store i64 %t1498, ptr %l841, !tbaa !24
  %t1503 = load ptr, ptr %l0, !tbaa !29
  %t1504 = load %"compiler/source:Span", ptr %l1
  %t1505 = load ptr, ptr %l86, !tbaa !29
  %t1509 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t1503, %"compiler/source:Span" %t1504, ptr %t1505)
  store ptr %t1509, ptr %l845
  br label %bb358
bb358:
  %t1510 = load ptr, ptr %l845, !tbaa !29
  store ptr %t1510, ptr %l846, !tbaa !29
  %t1511 = icmp sge i64 0, 0
  br i1 %t1511, label %bb359, label %bb360
bb359:
  %t1513 = icmp sle i64 0, 1152921504606846975
  br i1 %t1513, label %bb361, label %bb362
bb360:
  call void @__olang_check_failed(ptr @olang_loc_da0d16ec43a70817_ac9d3ce40fb81973)
  unreachable
bb361:
  %t1515 = mul i64 0, 8
  %t1516 = insertvalue { i64, ptr } undef, i64 0, 0
  %t1517 = insertvalue { i64, ptr } %t1516, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t1517, ptr %l849, !tbaa !27
  %t1518 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t1518, ptr %l850, !tbaa !27
  %t1519 = icmp sge i64 0, 0
  br i1 %t1519, label %bb363, label %bb364
bb362:
  call void @__olang_check_failed(ptr @olang_loc_da0d16ec43a70817_ac9d3ce40fb81973)
  unreachable
bb363:
  %t1521 = icmp sle i64 0, 2305843009213693951
  br i1 %t1521, label %bb365, label %bb366
bb364:
  call void @__olang_check_failed(ptr @olang_loc_1e80b96f97cf3962_d4e3965ce5124a3e)
  unreachable
bb365:
  %t1523 = mul i64 0, 4
  %t1524 = insertvalue { i64, ptr } undef, i64 0, 0
  %t1525 = insertvalue { i64, ptr } %t1524, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t1526 = load ptr, ptr %l838, !tbaa !29
  %t1527 = load %"compiler/source:Span", ptr %l839
  %t1528 = load %"compiler/source:Span", ptr %l840
  %t1529 = load i64, ptr %l841, !tbaa !24
  %t1530 = load ptr, ptr %l846, !tbaa !29
  %t1531 = load { i64, ptr }, ptr %l849, !tbaa !27
  %t1532 = load { i64, ptr }, ptr %l850, !tbaa !27
  %t1534 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %s44, ptr %t1526, %"compiler/source:Span" %t1527, %"compiler/source:Span" %t1528, i64 %t1529, ptr %t1530, { i64, ptr } %t1531, { i64, ptr } %t1532, { i64, ptr } %t1525)
  store ptr %t1534, ptr %l854
  br label %bb367
bb366:
  call void @__olang_check_failed(ptr @olang_loc_1e80b96f97cf3962_d4e3965ce5124a3e)
  unreachable
bb367:
  %t1535 = load ptr, ptr %l854, !tbaa !29
  store ptr %t1535, ptr %l96, !tbaa !29
  %t1536 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1536, ptr %l855, !tbaa !29
  %t1537 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1537, ptr %l856
  %t1538 = load ptr, ptr %l96, !tbaa !29
  %t1541 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1538)
  store i32 %t1541, ptr %l859
  br label %bb368
bb368:
  %t1542 = load ptr, ptr %l855, !tbaa !29
  %t1543 = load %"compiler/source:Span", ptr %l856
  %t1544 = load i32, ptr %l859, !tbaa !23
  %t1545 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t1542, %"compiler/source:Span" %t1543, i32 %t1544)
  store i64 %t1545, ptr %l860
  br label %bb369
bb369:
  %t1546 = load i64, ptr %l860, !tbaa !24
  store i64 %t1546, ptr %l97, !tbaa !24
  %t1547 = load ptr, ptr %l0, !tbaa !29
  %t1548 = load %"compiler/source:Span", ptr %l1
  %t1549 = load i64, ptr %l97, !tbaa !24
  %t1551 = trunc i64 %t1549 to i32
  %t1553 = load ptr, ptr %l96, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t1554
  %t1555 = getelementptr { i64, [3 x i64] }, ptr %t1554, i32 0, i32 0
  store i64 0, ptr %t1555
  %t1557 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1548, 0
  %t1559 = insertvalue { %"compiler/source:Span", i32, ptr } %t1557, i32 %t1551, 1
  %t1561 = insertvalue { %"compiler/source:Span", i32, ptr } %t1559, ptr %t1553, 2
  %t1562 = getelementptr { i64, [3 x i64] }, ptr %t1554, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1561, ptr %t1562
  %t1563 = load { i64, [3 x i64] }, ptr %t1554
  %t1565 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t1563, ptr %t1565
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t1547, ptr %t1565)
  br label %bb370
bb370:
  %t1568 = load i64, ptr %l85, !tbaa !24
  %t1569 = load i64, ptr %l97, !tbaa !24
  %t1572 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t1573 = load ptr, ptr %t1572, !tbaa !27
  %t1574 = getelementptr i64, ptr %t1573, i64 %t1568
  store i64 %t1569, ptr %t1574, !tbaa !34
  call void @__olang_scope_close(ptr %s44)
  br label %bb371
bb371:
  %t1575 = load i64, ptr %l83, !tbaa !24
  %t1577 = add i64 %t1575, 1
  store i64 %t1577, ptr %l83, !tbaa !24
  br label %bb325
bb372:
  %t1579 = load ptr, ptr %l0, !tbaa !29
  %t1580 = load ptr, ptr %l3, !tbaa !29
  %t1581 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t1582 = load ptr, ptr %t1581, !tbaa !27
  %t1583 = getelementptr i64, ptr %t1582, i64 0
  %t1584 = load i64, ptr %t1583, !tbaa !34
  %t1588 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereplaceTemp(ptr %v0, ptr %t1579, ptr %t1580, i64 %t1584)
  store ptr %t1588, ptr %l876
  br label %bb373
bb373:
  %t1589 = load ptr, ptr %l876, !tbaa !29
  store ptr %t1589, ptr %l98, !tbaa !29
  %t1590 = load ptr, ptr %l0, !tbaa !29
  %t1591 = load ptr, ptr %l98, !tbaa !29
  %t1592 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotCapture(ptr %v0, ptr %v0, ptr %t1590, ptr %t1591, %"compiler/source:Span" %t1592)
  br label %bb374
bb374:
  %t1596 = load i1, ptr %l69, !tbaa !21
  br i1 %t1596, label %bb375, label %bb376
bb375:
  %t1598 = load ptr, ptr %l62, !tbaa !29
  store ptr %t1598, ptr %l881, !tbaa !29
  br label %bb378
bb376:
  %t1600 = load ptr, ptr %l0, !tbaa !29
  %t1601 = load %"compiler/source:Span", ptr %l1
  %t1602 = load i64, ptr %l70, !tbaa !24
  %t1606 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t1600, %"compiler/source:Span" %t1601, i64 %t1602)
  store ptr %t1606, ptr %l886
  br label %bb377
bb377:
  %t1607 = load ptr, ptr %l886, !tbaa !29
  store ptr %t1607, ptr %l881, !tbaa !29
  br label %bb378
bb378:
  %t1609 = load ptr, ptr %l881, !tbaa !29
  store ptr %t1609, ptr %l99, !tbaa !29
  %t1610 = load i64, ptr %l6, !tbaa !24
  %t1612 = icmp sge i64 %t1610, 0
  br i1 %t1612, label %bb379, label %bb380
bb379:
  store %olang.scope zeroinitializer, ptr %s50
  %t1615 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l50)
  store i64 %t1615, ptr %l891
  br label %bb381
bb380:
  %t1616 = load i64, ptr %l63, !tbaa !24
  %t1618 = icmp sge i64 %t1616, 0
  br i1 %t1618, label %bb417, label %bb418
bb381:
  %t1620 = load i64, ptr %l891, !tbaa !24
  %t1621 = add i64 %t1620, 1
  store i64 %t1621, ptr %l892, !tbaa !24
  %t1622 = load ptr, ptr %l0, !tbaa !29
  %t1623 = load %"compiler/source:Span", ptr %l1
  %t1626 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehole(ptr %v0, ptr %t1622, %"compiler/source:Span" %t1623)
  store ptr %t1626, ptr %l895
  br label %bb382
bb382:
  %t1627 = load i64, ptr %l892, !tbaa !24
  %t1628 = icmp sge i64 %t1627, 0
  br i1 %t1628, label %bb383, label %bb384
bb383:
  %t1630 = load i64, ptr %l892, !tbaa !24
  %t1631 = icmp sle i64 %t1630, 1152921504606846975
  br i1 %t1631, label %bb385, label %bb386
bb384:
  call void @__olang_check_failed(ptr @olang_loc_f5f2ded9311e9d81_bb624a8d0118ae7d)
  unreachable
bb385:
  %t1633 = load i64, ptr %l892, !tbaa !24
  %t1634 = mul i64 %t1633, 8
  %t1635 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t1634)
  %t1636 = load ptr, ptr %l895, !tbaa !29
  store i64 0, ptr %t1637
  br label %fill.1638
fill.1638:
  %t1641 = load i64, ptr %t1637
  %t1642 = icmp slt i64 %t1641, %t1633
  br i1 %t1642, label %fillb.1639, label %filld.1640
fillb.1639:
  %t1643 = getelementptr ptr, ptr %t1635, i64 %t1641
  store ptr %t1636, ptr %t1643
  %t1644 = add i64 %t1641, 1
  store i64 %t1644, ptr %t1637
  br label %fill.1638
filld.1640:
  %t1645 = insertvalue { i64, ptr } undef, i64 %t1633, 0
  %t1646 = insertvalue { i64, ptr } %t1645, ptr %t1635, 1
  store { i64, ptr } %t1646, ptr %l100, !tbaa !27
  store i64 0, ptr %l101, !tbaa !24
  %t1649 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l50)
  store i64 %t1649, ptr %l900
  br label %bb387
bb386:
  call void @__olang_check_failed(ptr @olang_loc_f5f2ded9311e9d81_bb624a8d0118ae7d)
  unreachable
bb387:
  %t1650 = load i64, ptr %l900, !tbaa !24
  store i64 %t1650, ptr %l102, !tbaa !24
  store i64 1, ptr %l103, !tbaa !24
  %t1651 = load i64, ptr %l102, !tbaa !24
  %t1652 = load i64, ptr %l101, !tbaa !24
  %t1655 = icmp sgt i64 %t1651, %t1652
  br i1 %t1655, label %bb388, label %bb389
bb388:
  %t1657 = load i64, ptr %l103, !tbaa !24
  %t1659 = icmp sgt i64 %t1657, 0
  br i1 %t1659, label %bb390, label %bb391
bb389:
  store i64 0, ptr %l904, !tbaa !24
  br label %bb393
bb390:
  %t1661 = load i64, ptr %l102, !tbaa !24
  %t1662 = load i64, ptr %l101, !tbaa !24
  %t1665 = sub i64 %t1661, %t1662
  %t1666 = load i64, ptr %l103, !tbaa !24
  %t1669 = add i64 %t1665, %t1666
  %t1671 = sub i64 %t1669, 1
  %t1672 = load i64, ptr %l103, !tbaa !24
  %t1675 = sdiv i64 %t1671, %t1672
  store i64 %t1675, ptr %l907, !tbaa !24
  br label %bb392
bb391:
  store i64 0, ptr %l907, !tbaa !24
  br label %bb392
bb392:
  %t1677 = load i64, ptr %l907, !tbaa !24
  store i64 %t1677, ptr %l904, !tbaa !24
  br label %bb393
bb393:
  %t1678 = load i64, ptr %l904, !tbaa !24
  store i64 %t1678, ptr %l104, !tbaa !24
  store i64 0, ptr %l105, !tbaa !24
  br label %bb394
bb394:
  %t1679 = load i64, ptr %l105, !tbaa !24
  %t1680 = load i64, ptr %l104, !tbaa !24
  %t1683 = icmp slt i64 %t1679, %t1680
  %t1685 = xor i1 %t1683, true
  br i1 %t1685, label %bb395, label %bb396
bb395:
  br label %bb401
bb396:
  br label %bb397
bb397:
  %t1687 = load i64, ptr %l101, !tbaa !24
  %t1688 = load i64, ptr %l105, !tbaa !24
  %t1689 = load i64, ptr %l103, !tbaa !24
  %t1692 = mul i64 %t1688, %t1689
  %t1695 = add i64 %t1687, %t1692
  store i64 %t1695, ptr %l106, !tbaa !24
  %t1697 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t1697, ptr %l925, !tbaa !27
  %t1698 = load i64, ptr %l106, !tbaa !24
  store i64 %t1698, ptr %l926, !tbaa !24
  %t1699 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1699, ptr %l927, !tbaa !29
  %t1700 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1700, ptr %l928
  %t1701 = load i64, ptr %l106, !tbaa !24
  %t1704 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l50, i64 %t1701)
  store i64 %t1704, ptr %l931
  br label %bb398
bb398:
  %t1705 = load ptr, ptr %l927, !tbaa !29
  %t1706 = load %"compiler/source:Span", ptr %l928
  %t1707 = load i64, ptr %l931, !tbaa !24
  %t1708 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t1705, %"compiler/source:Span" %t1706, i64 %t1707)
  store ptr %t1708, ptr %l932
  br label %bb399
bb399:
  %t1709 = load ptr, ptr %l932, !tbaa !29
  %t1710 = load i64, ptr %l926, !tbaa !24
  %t1711 = getelementptr { i64, ptr }, ptr %l925, i32 0, i32 1
  %t1712 = load ptr, ptr %t1711, !tbaa !27
  %t1713 = getelementptr ptr, ptr %t1712, i64 %t1710
  store ptr %t1709, ptr %t1713, !tbaa !39
  br label %bb400
bb400:
  %t1714 = load i64, ptr %l105, !tbaa !24
  %t1716 = add i64 %t1714, 1
  store i64 %t1716, ptr %l105, !tbaa !24
  br label %bb394
bb401:
  %t1718 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t1718, ptr %l935, !tbaa !27
  %t1720 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l50)
  store i64 %t1720, ptr %l937
  br label %bb402
bb402:
  %t1721 = load ptr, ptr %l99, !tbaa !29
  %t1723 = icmp eq ptr %t1721, null
  br i1 %t1723, label %bb403, label %bb404
bb403:
  call void @__olang_check_failed(ptr @olang_loc_472402eb7644e34_5f66aff84e38a918)
  unreachable
bb404:
  br label %bb405
bb405:
  %t1725 = load ptr, ptr %l99, !tbaa !29
  %t1727 = load i64, ptr %l937, !tbaa !24
  %t1728 = getelementptr { i64, ptr }, ptr %l935, i32 0, i32 1
  %t1729 = load ptr, ptr %t1728, !tbaa !27
  %t1730 = getelementptr ptr, ptr %t1729, i64 %t1727
  store ptr %t1725, ptr %t1730, !tbaa !39
  %t1731 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1731, ptr %l941, !tbaa !29
  %t1732 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1732, ptr %l942
  %t1733 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1733, ptr %l943, !tbaa !29
  %t1734 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1734, ptr %l944
  %t1735 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1735, ptr %l945
  %t1736 = load i64, ptr %l6, !tbaa !24
  store i64 %t1736, ptr %l946, !tbaa !24
  %t1737 = load ptr, ptr %l0, !tbaa !29
  %t1738 = load %"compiler/source:Span", ptr %l1
  %t1739 = load ptr, ptr %l98, !tbaa !29
  %t1743 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t1737, %"compiler/source:Span" %t1738, ptr %t1739)
  store ptr %t1743, ptr %l950
  br label %bb406
bb406:
  %t1744 = load ptr, ptr %l950, !tbaa !29
  store ptr %t1744, ptr %l951, !tbaa !29
  %t1745 = icmp sge i64 0, 0
  br i1 %t1745, label %bb407, label %bb408
bb407:
  %t1747 = icmp sle i64 0, 1152921504606846975
  br i1 %t1747, label %bb409, label %bb410
bb408:
  call void @__olang_check_failed(ptr @olang_loc_d99d0717bbb0270b_5e4dc4d9370c1e7f)
  unreachable
bb409:
  %t1749 = mul i64 0, 8
  %t1750 = insertvalue { i64, ptr } undef, i64 0, 0
  %t1751 = insertvalue { i64, ptr } %t1750, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t1751, ptr %l954, !tbaa !27
  %t1752 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t1752, ptr %l955, !tbaa !27
  %t1753 = icmp sge i64 0, 0
  br i1 %t1753, label %bb411, label %bb412
bb410:
  call void @__olang_check_failed(ptr @olang_loc_d99d0717bbb0270b_5e4dc4d9370c1e7f)
  unreachable
bb411:
  %t1755 = icmp sle i64 0, 2305843009213693951
  br i1 %t1755, label %bb413, label %bb414
bb412:
  call void @__olang_check_failed(ptr @olang_loc_1e80b96f97cf3962_d4e3965ce5124a3e)
  unreachable
bb413:
  %t1757 = mul i64 0, 4
  %t1758 = insertvalue { i64, ptr } undef, i64 0, 0
  %t1759 = insertvalue { i64, ptr } %t1758, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t1760 = load ptr, ptr %l943, !tbaa !29
  %t1761 = load %"compiler/source:Span", ptr %l944
  %t1762 = load %"compiler/source:Span", ptr %l945
  %t1763 = load i64, ptr %l946, !tbaa !24
  %t1764 = load ptr, ptr %l951, !tbaa !29
  %t1765 = load { i64, ptr }, ptr %l954, !tbaa !27
  %t1766 = load { i64, ptr }, ptr %l955, !tbaa !27
  %t1768 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %s50, ptr %t1760, %"compiler/source:Span" %t1761, %"compiler/source:Span" %t1762, i64 %t1763, ptr %t1764, { i64, ptr } %t1765, { i64, ptr } %t1766, { i64, ptr } %t1759)
  store ptr %t1768, ptr %l959
  br label %bb415
bb414:
  call void @__olang_check_failed(ptr @olang_loc_1e80b96f97cf3962_d4e3965ce5124a3e)
  unreachable
bb415:
  store { i64, [3 x i64] } zeroinitializer, ptr %t1769
  %t1770 = getelementptr { i64, [3 x i64] }, ptr %t1769, i32 0, i32 0
  store i64 2, ptr %t1770
  %t1771 = load %"compiler/source:Span", ptr %l942
  %t1772 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t1771, 0
  %t1773 = load ptr, ptr %l959, !tbaa !29
  %t1774 = insertvalue { %"compiler/source:Span", ptr } %t1772, ptr %t1773, 1
  %t1775 = getelementptr { i64, [3 x i64] }, ptr %t1769, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t1774, ptr %t1775
  %t1776 = load { i64, [3 x i64] }, ptr %t1769
  %t1778 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t1776, ptr %t1778
  %t1779 = load ptr, ptr %l941, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t1779, ptr %t1778)
  br label %bb416
bb416:
  call void @__olang_scope_close(ptr %s50)
  br label %bb434
bb417:
  %t1781 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1781, ptr %l964, !tbaa !29
  %t1782 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1782, ptr %l965
  %t1783 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t1783, ptr %l966
  %t1784 = load i32, ptr %l2, !range !{i32 0, i32 96}
  %t1786 = call i32 @compiler_2fcheck_2ecompoundOp(i32 %t1784)
  store i32 %t1786, ptr %l968
  br label %bb419
bb418:
  %t1787 = load i32, ptr %l2, !range !{i32 0, i32 96}
  %t1789 = trunc i64 61 to i32
  %t1790 = icmp eq i32 %t1787, %t1789
  %t1792 = xor i1 %t1790, true
  br i1 %t1792, label %bb422, label %bb423
bb419:
  %t1794 = load i32, ptr %l49, !tbaa !23
  store i32 %t1794, ptr %l969, !tbaa !23
  %t1795 = load ptr, ptr %l0, !tbaa !29
  %t1796 = load %"compiler/source:Span", ptr %l1
  %t1797 = load ptr, ptr %l98, !tbaa !29
  %t1801 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneTarget(ptr %v0, ptr %t1795, %"compiler/source:Span" %t1796, ptr %t1797)
  store i64 %t1801, ptr %l973
  br label %bb420
bb420:
  %t1802 = load i64, ptr %l63, !tbaa !24
  %t1803 = load ptr, ptr %l964, !tbaa !29
  %t1804 = load %"compiler/source:Span", ptr %l965
  %t1805 = load %"compiler/source:Span", ptr %l966
  %t1806 = load i32, ptr %l968, !range !{i32 0, i32 96}
  %t1807 = load i32, ptr %l969, !tbaa !23
  %t1808 = load i64, ptr %l973, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneStore(ptr %v0, ptr %s0, ptr %t1803, %"compiler/source:Span" %t1804, %"compiler/source:Span" %t1805, i32 %t1806, i32 %t1807, i64 %t1808, i64 %t1802, ptr %l64)
  br label %bb421
bb421:
  br label %bb433
bb422:
  %t1811 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1811, ptr %l979, !tbaa !29
  %t1812 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1812, ptr %l980
  %t1813 = load i32, ptr %l49, !tbaa !23
  store i32 %t1813, ptr %l981, !tbaa !23
  %t1814 = load i32, ptr %l2, !range !{i32 0, i32 96}
  %t1816 = call i32 @compiler_2fcheck_2ecompoundOp(i32 %t1814)
  store i32 %t1816, ptr %l983
  br label %bb424
bb423:
  br label %bb428
bb424:
  %t1817 = load i32, ptr %l983, !range !{i32 0, i32 96}
  %t1818 = call i32 @compiler_2fcheck_2ebinaryOp(i32 %t1817)
  store i32 %t1818, ptr %l984
  br label %bb425
bb425:
  %t1819 = load ptr, ptr %l0, !tbaa !29
  %t1820 = load %"compiler/source:Span", ptr %l1
  %t1821 = load %"compiler/source:Span", ptr %l1
  %t1822 = load i32, ptr %l49, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t1823
  %t1824 = getelementptr { i64, [4 x i64] }, ptr %t1823, i32 0, i32 0
  store i64 7, ptr %t1824
  %t1826 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t1821, 0
  %t1828 = insertvalue { %"compiler/source:Span", i32 } %t1826, i32 %t1822, 1
  %t1829 = getelementptr { i64, [4 x i64] }, ptr %t1823, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t1828, ptr %t1829
  %t1830 = load { i64, [4 x i64] }, ptr %t1823
  %t1832 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t1830, ptr %t1832
  %t1836 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t1819, %"compiler/source:Span" %t1820, ptr %t1832)
  store ptr %t1836, ptr %l991
  br label %bb426
bb426:
  %t1837 = load ptr, ptr %l99, !tbaa !29
  %t1838 = load ptr, ptr %l979, !tbaa !29
  %t1839 = load %"compiler/source:Span", ptr %l980
  %t1840 = load i32, ptr %l981, !tbaa !23
  %t1841 = load i32, ptr %l984, !range !{i32 0, i32 43}
  %t1842 = load ptr, ptr %l991, !tbaa !29
  %t1844 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t1838, %"compiler/source:Span" %t1839, i32 %t1840, i32 %t1841, ptr %t1842, ptr %t1837)
  store ptr %t1844, ptr %l993
  br label %bb427
bb427:
  %t1845 = load ptr, ptr %l993, !tbaa !29
  store ptr %t1845, ptr %l99, !tbaa !29
  br label %bb428
bb428:
  %t1847 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1847, ptr %l995, !tbaa !29
  %t1848 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1848, ptr %l996
  %t1849 = load ptr, ptr %l98, !tbaa !29
  store ptr %t1849, ptr %l997, !tbaa !29
  %t1850 = load ptr, ptr %l99, !tbaa !29
  %t1852 = icmp eq ptr %t1850, null
  br i1 %t1852, label %bb429, label %bb430
bb429:
  call void @__olang_check_failed(ptr @olang_loc_d11b8aacafb7785e_f77cfc6c7f6ded4a)
  unreachable
bb430:
  br label %bb431
bb431:
  %t1854 = load ptr, ptr %l99, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t1855
  %t1856 = getelementptr { i64, [3 x i64] }, ptr %t1855, i32 0, i32 0
  store i64 1, ptr %t1856
  %t1857 = load %"compiler/source:Span", ptr %l996
  %t1858 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t1857, 0
  %t1859 = load ptr, ptr %l997, !tbaa !29
  %t1860 = insertvalue { %"compiler/source:Span", ptr, ptr } %t1858, ptr %t1859, 1
  %t1862 = insertvalue { %"compiler/source:Span", ptr, ptr } %t1860, ptr %t1854, 2
  %t1863 = getelementptr { i64, [3 x i64] }, ptr %t1855, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t1862, ptr %t1863
  %t1864 = load { i64, [3 x i64] }, ptr %t1855
  %t1866 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t1864, ptr %t1866
  %t1867 = load ptr, ptr %l995, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t1867, ptr %t1866)
  br label %bb432
bb432:
  br label %bb433
bb433:
  br label %bb434
bb434:
  store i64 0, ptr %l107, !tbaa !24
  %t1869 = load i64, ptr %l14, !tbaa !24
  store i64 %t1869, ptr %l108, !tbaa !24
  store i64 1, ptr %l109, !tbaa !24
  %t1871 = load i64, ptr %l108, !tbaa !24
  %t1872 = load i64, ptr %l107, !tbaa !24
  %t1875 = icmp sgt i64 %t1871, %t1872
  br i1 %t1875, label %bb435, label %bb436
bb435:
  %t1877 = load i64, ptr %l109, !tbaa !24
  %t1879 = icmp sgt i64 %t1877, 0
  br i1 %t1879, label %bb437, label %bb438
bb436:
  store i64 0, ptr %l1007, !tbaa !24
  br label %bb440
bb437:
  %t1881 = load i64, ptr %l108, !tbaa !24
  %t1882 = load i64, ptr %l107, !tbaa !24
  %t1885 = sub i64 %t1881, %t1882
  %t1886 = load i64, ptr %l109, !tbaa !24
  %t1889 = add i64 %t1885, %t1886
  %t1891 = sub i64 %t1889, 1
  %t1892 = load i64, ptr %l109, !tbaa !24
  %t1895 = sdiv i64 %t1891, %t1892
  store i64 %t1895, ptr %l1010, !tbaa !24
  br label %bb439
bb438:
  store i64 0, ptr %l1010, !tbaa !24
  br label %bb439
bb439:
  %t1897 = load i64, ptr %l1010, !tbaa !24
  store i64 %t1897, ptr %l1007, !tbaa !24
  br label %bb440
bb440:
  %t1898 = load i64, ptr %l1007, !tbaa !24
  store i64 %t1898, ptr %l110, !tbaa !24
  store i64 0, ptr %l111, !tbaa !24
  br label %bb441
bb441:
  store %olang.scope zeroinitializer, ptr %s59
  %t1899 = load i64, ptr %l111, !tbaa !24
  %t1900 = load i64, ptr %l110, !tbaa !24
  %t1903 = icmp slt i64 %t1899, %t1900
  %t1905 = xor i1 %t1903, true
  br i1 %t1905, label %bb442, label %bb443
bb442:
  call void @__olang_scope_close(ptr %s59)
  br label %bb482
bb443:
  br label %bb444
bb444:
  %t1907 = load i64, ptr %l107, !tbaa !24
  %t1908 = load i64, ptr %l111, !tbaa !24
  %t1909 = load i64, ptr %l109, !tbaa !24
  %t1912 = mul i64 %t1908, %t1909
  %t1915 = add i64 %t1907, %t1912
  store i64 %t1915, ptr %l112, !tbaa !24
  %t1917 = load ptr, ptr %l25, !tbaa !29
  %t1918 = load i64, ptr %l112, !tbaa !24
  %t1921 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t1917, i64 %t1918)
  store { i64, ptr } %t1921, ptr %l1030
  br label %bb445
bb445:
  %t1922 = load { i64, ptr }, ptr %l1030, !tbaa !27
  store { i64, ptr } %t1922, ptr %l113, !tbaa !27
  %t1923 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t1925 = extractvalue { i64, ptr } %t1923, 0
  %t1927 = add i64 %t1925, 1
  store i64 %t1927, ptr %l1033, !tbaa !24
  %t1928 = load ptr, ptr %l0, !tbaa !29
  %t1929 = load %"compiler/source:Span", ptr %l1
  %t1932 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehole(ptr %v0, ptr %t1928, %"compiler/source:Span" %t1929)
  store ptr %t1932, ptr %l1036
  br label %bb446
bb446:
  %t1933 = load i64, ptr %l1033, !tbaa !24
  %t1934 = icmp sge i64 %t1933, 0
  br i1 %t1934, label %bb447, label %bb448
bb447:
  %t1936 = load i64, ptr %l1033, !tbaa !24
  %t1937 = icmp sle i64 %t1936, 1152921504606846975
  br i1 %t1937, label %bb449, label %bb450
bb448:
  call void @__olang_check_failed(ptr @olang_loc_fb4c1a49ef697595_16cae88eb029dae9)
  unreachable
bb449:
  %t1939 = load i64, ptr %l1033, !tbaa !24
  %t1940 = mul i64 %t1939, 8
  %t1941 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t1940)
  %t1942 = load ptr, ptr %l1036, !tbaa !29
  store i64 0, ptr %t1943
  br label %fill.1944
fill.1944:
  %t1947 = load i64, ptr %t1943
  %t1948 = icmp slt i64 %t1947, %t1939
  br i1 %t1948, label %fillb.1945, label %filld.1946
fillb.1945:
  %t1949 = getelementptr ptr, ptr %t1941, i64 %t1947
  store ptr %t1942, ptr %t1949
  %t1950 = add i64 %t1947, 1
  store i64 %t1950, ptr %t1943
  br label %fill.1944
filld.1946:
  %t1951 = insertvalue { i64, ptr } undef, i64 %t1939, 0
  %t1952 = insertvalue { i64, ptr } %t1951, ptr %t1941, 1
  store { i64, ptr } %t1952, ptr %l114, !tbaa !27
  store i64 0, ptr %l115, !tbaa !24
  %t1954 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t1956 = extractvalue { i64, ptr } %t1954, 0
  store i64 %t1956, ptr %l116, !tbaa !24
  store i64 1, ptr %l117, !tbaa !24
  %t1958 = load i64, ptr %l116, !tbaa !24
  %t1959 = load i64, ptr %l115, !tbaa !24
  %t1962 = icmp sgt i64 %t1958, %t1959
  br i1 %t1962, label %bb451, label %bb452
bb450:
  call void @__olang_check_failed(ptr @olang_loc_fb4c1a49ef697595_16cae88eb029dae9)
  unreachable
bb451:
  %t1964 = load i64, ptr %l117, !tbaa !24
  %t1966 = icmp sgt i64 %t1964, 0
  br i1 %t1966, label %bb453, label %bb454
bb452:
  store i64 0, ptr %l1045, !tbaa !24
  br label %bb456
bb453:
  %t1968 = load i64, ptr %l116, !tbaa !24
  %t1969 = load i64, ptr %l115, !tbaa !24
  %t1972 = sub i64 %t1968, %t1969
  %t1973 = load i64, ptr %l117, !tbaa !24
  %t1976 = add i64 %t1972, %t1973
  %t1978 = sub i64 %t1976, 1
  %t1979 = load i64, ptr %l117, !tbaa !24
  %t1982 = sdiv i64 %t1978, %t1979
  store i64 %t1982, ptr %l1048, !tbaa !24
  br label %bb455
bb454:
  store i64 0, ptr %l1048, !tbaa !24
  br label %bb455
bb455:
  %t1984 = load i64, ptr %l1048, !tbaa !24
  store i64 %t1984, ptr %l1045, !tbaa !24
  br label %bb456
bb456:
  %t1985 = load i64, ptr %l1045, !tbaa !24
  store i64 %t1985, ptr %l118, !tbaa !24
  store i64 0, ptr %l119, !tbaa !24
  br label %bb457
bb457:
  %t1986 = load i64, ptr %l119, !tbaa !24
  %t1987 = load i64, ptr %l118, !tbaa !24
  %t1990 = icmp slt i64 %t1986, %t1987
  %t1992 = xor i1 %t1990, true
  br i1 %t1992, label %bb458, label %bb459
bb458:
  br label %bb463
bb459:
  br label %bb460
bb460:
  %t1994 = load i64, ptr %l115, !tbaa !24
  %t1995 = load i64, ptr %l119, !tbaa !24
  %t1996 = load i64, ptr %l117, !tbaa !24
  %t1999 = mul i64 %t1995, %t1996
  %t2002 = add i64 %t1994, %t1999
  store i64 %t2002, ptr %l120, !tbaa !24
  %t2004 = load { i64, ptr }, ptr %l114, !tbaa !27
  store { i64, ptr } %t2004, ptr %l1066, !tbaa !27
  %t2005 = load i64, ptr %l120, !tbaa !24
  store i64 %t2005, ptr %l1067, !tbaa !24
  %t2006 = load ptr, ptr %l0, !tbaa !29
  %t2007 = load %"compiler/source:Span", ptr %l1
  %t2008 = load { i64, ptr }, ptr %l113, !tbaa !27
  store { i64, ptr } %t2008, ptr %l1070, !tbaa !27
  %t2009 = load i64, ptr %l120, !tbaa !24
  %t2011 = getelementptr { i64, ptr }, ptr %l1070, i32 0, i32 1
  %t2012 = load ptr, ptr %t2011, !tbaa !27
  %t2013 = getelementptr i64, ptr %t2012, i64 %t2009
  %t2014 = load i64, ptr %t2013, !tbaa !34
  %t2018 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t2006, %"compiler/source:Span" %t2007, i64 %t2014)
  store ptr %t2018, ptr %l1073
  br label %bb461
bb461:
  %t2019 = load ptr, ptr %l1073, !tbaa !29
  %t2020 = load i64, ptr %l1067, !tbaa !24
  %t2021 = getelementptr { i64, ptr }, ptr %l1066, i32 0, i32 1
  %t2022 = load ptr, ptr %t2021, !tbaa !27
  %t2023 = getelementptr ptr, ptr %t2022, i64 %t2020
  store ptr %t2019, ptr %t2023, !tbaa !39
  br label %bb462
bb462:
  %t2024 = load i64, ptr %l119, !tbaa !24
  %t2026 = add i64 %t2024, 1
  store i64 %t2026, ptr %l119, !tbaa !24
  br label %bb457
bb463:
  %t2028 = load { i64, ptr }, ptr %l114, !tbaa !27
  store { i64, ptr } %t2028, ptr %l1076, !tbaa !27
  %t2029 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t2031 = extractvalue { i64, ptr } %t2029, 0
  store i64 %t2031, ptr %l1078, !tbaa !24
  %t2032 = load ptr, ptr %l0, !tbaa !29
  %t2033 = load %"compiler/source:Span", ptr %l1
  %t2034 = load i64, ptr %l112, !tbaa !24
  %t2036 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t2037 = load ptr, ptr %t2036, !tbaa !27
  %t2038 = getelementptr i64, ptr %t2037, i64 %t2034
  %t2039 = load i64, ptr %t2038, !tbaa !34
  %t2043 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t2032, %"compiler/source:Span" %t2033, i64 %t2039)
  store ptr %t2043, ptr %l1083
  br label %bb464
bb464:
  %t2044 = load ptr, ptr %l1083, !tbaa !29
  %t2045 = load i64, ptr %l1078, !tbaa !24
  %t2046 = getelementptr { i64, ptr }, ptr %l1076, i32 0, i32 1
  %t2047 = load ptr, ptr %t2046, !tbaa !27
  %t2048 = getelementptr ptr, ptr %t2047, i64 %t2045
  store ptr %t2044, ptr %t2048, !tbaa !39
  %t2049 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2049, ptr %l1084, !tbaa !29
  %t2050 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t2050, ptr %l1085
  %t2051 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2051, ptr %l1086, !tbaa !29
  %t2052 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t2052, ptr %l1087
  %t2053 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t2053, ptr %l1088
  %t2054 = load i64, ptr %l112, !tbaa !24
  %t2057 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l15, i64 %t2054)
  store i64 %t2057, ptr %l1091
  br label %bb465
bb465:
  %t2058 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2058, ptr %l1092, !tbaa !29
  %t2059 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t2059, ptr %l1093
  %t2060 = load ptr, ptr %l72, !tbaa !29
  %t2061 = load i64, ptr %l112, !tbaa !24
  %t2064 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eA_Hf8c35f4f5353320ac1e6ff0719acdfb7(ptr %v0, ptr %v0, ptr %t2060, i64 %t2061)
  store ptr %t2064, ptr %l1096
  br label %bb466
bb466:
  %t2065 = load ptr, ptr %l1096, !tbaa !29
  store ptr %t2065, ptr %l121, !tbaa !29
  %t2066 = load ptr, ptr %l121, !tbaa !29
  %t2068 = icmp eq ptr %t2066, null
  br i1 %t2068, label %bb467, label %bb468
bb467:
  call void @__olang_check_failed(ptr @olang_loc_eccd8b6a5c2fa6b0_78891c232bd2a45c)
  unreachable
bb468:
  br label %bb469
bb469:
  %t2070 = load ptr, ptr %l121, !tbaa !29
  %t2071 = load ptr, ptr %l1092, !tbaa !29
  %t2072 = load %"compiler/source:Span", ptr %l1093
  %t2074 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t2071, %"compiler/source:Span" %t2072, ptr %t2070)
  store ptr %t2074, ptr %l1100
  br label %bb470
bb470:
  %t2075 = load ptr, ptr %l1100, !tbaa !29
  store ptr %t2075, ptr %l1101, !tbaa !29
  %t2076 = icmp sge i64 0, 0
  br i1 %t2076, label %bb471, label %bb472
bb471:
  %t2078 = icmp sle i64 0, 1152921504606846975
  br i1 %t2078, label %bb473, label %bb474
bb472:
  call void @__olang_check_failed(ptr @olang_loc_f0e5921914b2a2cf_65ed047d8124f4fb)
  unreachable
bb473:
  %t2080 = mul i64 0, 8
  %t2081 = insertvalue { i64, ptr } undef, i64 0, 0
  %t2082 = insertvalue { i64, ptr } %t2081, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t2082, ptr %l1104, !tbaa !27
  %t2083 = load { i64, ptr }, ptr %l114, !tbaa !27
  store { i64, ptr } %t2083, ptr %l1105, !tbaa !27
  %t2084 = icmp sge i64 0, 0
  br i1 %t2084, label %bb475, label %bb476
bb474:
  call void @__olang_check_failed(ptr @olang_loc_f0e5921914b2a2cf_65ed047d8124f4fb)
  unreachable
bb475:
  %t2086 = icmp sle i64 0, 2305843009213693951
  br i1 %t2086, label %bb477, label %bb478
bb476:
  call void @__olang_check_failed(ptr @olang_loc_1e80b96f97cf3962_d4e3965ce5124a3e)
  unreachable
bb477:
  %t2088 = mul i64 0, 4
  %t2089 = insertvalue { i64, ptr } undef, i64 0, 0
  %t2090 = insertvalue { i64, ptr } %t2089, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t2091 = load ptr, ptr %l1086, !tbaa !29
  %t2092 = load %"compiler/source:Span", ptr %l1087
  %t2093 = load %"compiler/source:Span", ptr %l1088
  %t2094 = load i64, ptr %l1091, !tbaa !24
  %t2095 = load ptr, ptr %l1101, !tbaa !29
  %t2096 = load { i64, ptr }, ptr %l1104, !tbaa !27
  %t2097 = load { i64, ptr }, ptr %l1105, !tbaa !27
  %t2099 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %s59, ptr %t2091, %"compiler/source:Span" %t2092, %"compiler/source:Span" %t2093, i64 %t2094, ptr %t2095, { i64, ptr } %t2096, { i64, ptr } %t2097, { i64, ptr } %t2090)
  store ptr %t2099, ptr %l1109
  br label %bb479
bb478:
  call void @__olang_check_failed(ptr @olang_loc_1e80b96f97cf3962_d4e3965ce5124a3e)
  unreachable
bb479:
  store { i64, [3 x i64] } zeroinitializer, ptr %t2100
  %t2101 = getelementptr { i64, [3 x i64] }, ptr %t2100, i32 0, i32 0
  store i64 2, ptr %t2101
  %t2102 = load %"compiler/source:Span", ptr %l1085
  %t2103 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t2102, 0
  %t2104 = load ptr, ptr %l1109, !tbaa !29
  %t2105 = insertvalue { %"compiler/source:Span", ptr } %t2103, ptr %t2104, 1
  %t2106 = getelementptr { i64, [3 x i64] }, ptr %t2100, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t2105, ptr %t2106
  %t2107 = load { i64, [3 x i64] }, ptr %t2100
  %t2109 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t2107, ptr %t2109
  %t2110 = load ptr, ptr %l1084, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t2110, ptr %t2109)
  br label %bb480
bb480:
  call void @__olang_scope_close(ptr %s59)
  br label %bb481
bb481:
  %t2112 = load i64, ptr %l111, !tbaa !24
  %t2114 = add i64 %t2112, 1
  store i64 %t2114, ptr %l111, !tbaa !24
  br label %bb441
bb482:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenRefOrVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i1
  %l16 = alloca i32
  %l19 = alloca i1
  %l20 = alloca i1
  %l25 = alloca i32
  %l28 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 7}
  %t8 = icmp eq i64 %t6, 4
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb18
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = icmp eq ptr %t16, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t26 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %t21, ptr %t22)
  store i32 %t26, ptr %l16
  br label %bb9
bb9:
  %t27 = load i32, ptr %l16, !tbaa !23
  store i32 %t27, ptr %l3, !tbaa !23
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l3, !tbaa !23
  %t32 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t28, i32 %t29)
  store i1 %t32, ptr %l19
  br label %bb10
bb10:
  %t33 = load i1, ptr %l19, !tbaa !21
  br i1 %t33, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb14
bb12:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  %t40 = load i32, ptr %l3, !tbaa !23
  %t43 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t43, ptr %l25
  br label %bb13
bb13:
  %t44 = load i32, ptr %l25, !range !{i32 0, i32 33}
  %t46 = trunc i64 25 to i32
  %t47 = icmp eq i32 %t44, %t46
  store i1 %t47, ptr %l20, !tbaa !21
  br label %bb14
bb14:
  %t49 = load i1, ptr %l20, !tbaa !21
  br i1 %t49, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb17
bb16:
  %t50 = load i32, ptr %l3, !tbaa !23
  %t51 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t54 = icmp eq i32 %t50, %t51
  store i1 %t54, ptr %l28, !tbaa !21
  br label %bb17
bb17:
  %t56 = load i1, ptr %l28, !tbaa !21
  store i1 %t56, ptr %rv
  br label %ret
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store i1 false, ptr %rv
  br label %ret
bb22:
  call void @__olang_check_failed(ptr @olang_loc_712f9e4ca30bc6cb_a93275977373a857)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2efieldSpans(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l25 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l29 = alloca i1
  %l44 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/ast:StructBody", ptr %t5, i32 0, i32 2
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t12 = icmp eq i64 %t10, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = load ptr, ptr %lp1
  %t15 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t14
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/ast:StructBody", ptr %t17, i32 0, i32 2
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  store i64 %t24, ptr %l4, !tbaa !24
  br label %bb5
bb5:
  %t26 = load i64, ptr %l3, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = icmp slt i64 %t26, %t27
  %t32 = xor i1 %t30, true
  br i1 %t32, label %bb6, label %bb7
bb6:
  br label %bb31
bb7:
  br label %bb8
bb8:
  %t34 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t34, ptr %l25, !tbaa !27
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr ptr, ptr %t38, i64 %t35
  %t40 = load ptr, ptr %t39, !tbaa !39
  store ptr %t40, ptr %l5, !tbaa !29
  %t42 = load ptr, ptr %l5, !tbaa !29
  store ptr %t42, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t43 = load ptr, ptr %l28, !tbaa !29
  %t44 = icmp ne ptr %t43, null
  br i1 %t44, label %bb9, label %bb10
bb9:
  %t46 = load ptr, ptr %l28, !tbaa !29
  %t47 = load i64, ptr %t46, !range !{i64 0, i64 22}
  %t49 = icmp eq i64 %t47, 1
  store i1 %t49, ptr %l29, !tbaa !21
  br label %bb10
bb10:
  %t50 = load i1, ptr %l29, !tbaa !21
  br i1 %t50, label %bb11, label %bb12
bb11:
  %t51 = load ptr, ptr %l5, !tbaa !29
  %t53 = getelementptr { i64, [4 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", ptr }, ptr %t53, i32 0, i32 1
  %t55 = load ptr, ptr %t54
  store ptr %t55, ptr %l6, !tbaa !29
  br label %bb13
bb12:
  br label %bb24
bb13:
  %t57 = load ptr, ptr %l6, !tbaa !29
  %t59 = getelementptr %"compiler/ast:VarDecl", ptr %t57, i32 0, i32 5
  %t60 = load i1, ptr %t59, !tbaa !21
  br i1 %t60, label %bb14, label %bb15
bb14:
  %t62 = load ptr, ptr %l6, !tbaa !29
  %t64 = getelementptr %"compiler/ast:VarDecl", ptr %t62, i32 0, i32 1
  %t65 = load { i64, ptr }, ptr %t64, !tbaa !27
  store { i64, ptr } %t65, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t67 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 0
  store i64 %t69, ptr %l9, !tbaa !24
  br label %bb16
bb15:
  br label %bb23
bb16:
  %t71 = load i64, ptr %l8, !tbaa !24
  %t72 = load i64, ptr %l9, !tbaa !24
  %t75 = icmp slt i64 %t71, %t72
  %t77 = xor i1 %t75, true
  br i1 %t77, label %bb17, label %bb18
bb17:
  br label %bb22
bb18:
  br label %bb19
bb19:
  %t79 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t79, ptr %l44, !tbaa !27
  %t80 = load i64, ptr %l8, !tbaa !24
  %t82 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr %"compiler/source:Span", ptr %t83, i64 %t80
  %t85 = load %"compiler/source:Span", ptr %t84
  %t87 = load ptr, ptr %lp1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v1, ptr %t87, %"compiler/source:Span" %t85)
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t91 = load i64, ptr %l8, !tbaa !24
  %t93 = add i64 %t91, 1
  store i64 %t93, ptr %l8, !tbaa !24
  br label %bb16
bb22:
  br label %bb23
bb23:
  br label %bb29
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_fdb64edea8b6d798_567edb713353da64)
  unreachable
bb29:
  br label %bb30
bb30:
  %t95 = load i64, ptr %l3, !tbaa !24
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l3, !tbaa !24
  br label %bb5
bb31:
  %t99 = load ptr, ptr %lp1
  %t100 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t99
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t100, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i1 @compiler_2fcheck_2eifAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l5 = alloca i1
  %l11 = alloca i1
  %l20 = alloca i1
  %l25 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/ast:If", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t8 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t4, { i64, ptr } %t5)
  store i1 %t8, ptr %l5
  br label %bb1
bb1:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/ast:If", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = icmp eq ptr %t14, null
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/ast:If", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  br i1 %t25, label %bb7, label %bb8
bb6:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb11
bb7:
  call void @__olang_check_failed(ptr @olang_loc_cc3b6ed7ca85eab5_875d9ef7a16c4e59)
  unreachable
bb8:
  br label %bb9
bb9:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/ast:If", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t33 = getelementptr %"compiler/ast:Branch", ptr %t30, i32 0, i32 1
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t38 = call i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %t34, { i64, ptr } %t35)
  store i1 %t38, ptr %l20
  br label %bb10
bb10:
  %t39 = load i1, ptr %l20, !tbaa !21
  store i1 %t39, ptr %l11, !tbaa !21
  br label %bb11
bb11:
  %t40 = load i1, ptr %l11, !tbaa !21
  br i1 %t40, label %bb12, label %bb13
bb12:
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/ast:If", ptr %t42, i32 0, i32 2
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t46 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t49 = call i1 @compiler_2fcheck_2estmtAssigns(ptr %v0, ptr %v1, ptr %t45, { i64, ptr } %t46)
  store i1 %t49, ptr %l25
  br label %bb15
bb15:
  %t50 = load i1, ptr %l25, !tbaa !21
  store i1 %t50, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2elocalRead(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t17 = load ptr, ptr %l8, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l8, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l9, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l9, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_51cc068c3aeae8b4_3b6d62df8d15b2a8)
  unreachable
bb16:
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_a6ce77febe1defe5_34385e948c177179)
  unreachable
bb22:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2enumberLitsOnly(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l11 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l20 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i1
  %l31 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l42 = alloca i1
  %l45 = alloca i1
  %l48 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i1
  %l61 = alloca i1
  %l64 = alloca i1
  %l67 = alloca i1
  %l70 = alloca i1
  %l73 = alloca i1
  %l76 = alloca i1
  %l79 = alloca i1
  %l82 = alloca i1
  %l85 = alloca i1
  %l88 = alloca i1
  %l91 = alloca i1
  %l92 = alloca i1
  %l95 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t7 = load ptr, ptr %l12, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l12, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 29}
  %t13 = icmp eq i64 %t11, 1
  store i1 %t13, ptr %l13, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l13, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32 }, ptr %t17, i32 0, i32 1
  %t19 = load i32, ptr %t18, !range !{i32 0, i32 96}
  store i32 %t19, ptr %l1
  br label %bb8
bb7:
  br label %bb12
bb8:
  %t21 = load i32, ptr %l1, !range !{i32 0, i32 96}
  %t23 = trunc i64 2 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb11
bb10:
  %t26 = load i32, ptr %l1, !range !{i32 0, i32 96}
  %t28 = trunc i64 3 to i32
  %t29 = icmp eq i32 %t26, %t28
  store i1 %t29, ptr %l20, !tbaa !21
  br label %bb11
bb11:
  %t31 = load i1, ptr %l20, !tbaa !21
  store i1 %t31, ptr %l11, !tbaa !21
  br label %bb78
bb12:
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t33 = load ptr, ptr %l23, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb13, label %bb14
bb13:
  %t36 = load ptr, ptr %l23, !tbaa !29
  %t37 = load i64, ptr %t36, !range !{i64 0, i64 29}
  %t39 = icmp eq i64 %t37, 2
  store i1 %t39, ptr %l24, !tbaa !21
  br label %bb14
bb14:
  %t40 = load i1, ptr %l24, !tbaa !21
  br i1 %t40, label %bb15, label %bb16
bb15:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr { i64, [5 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", ptr }, ptr %t43, i32 0, i32 1
  %t45 = load ptr, ptr %t44
  store ptr %t45, ptr %l2, !tbaa !29
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t47 = load ptr, ptr %l2, !tbaa !29
  %t50 = call i1 @compiler_2fcheck_2enumberLitsOnly(ptr %v0, ptr %t47)
  store i1 %t50, ptr %l31
  br label %bb18
bb18:
  %t51 = load i1, ptr %l31, !tbaa !21
  store i1 %t51, ptr %l11, !tbaa !21
  br label %bb78
bb19:
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t53 = load ptr, ptr %l32, !tbaa !29
  %t54 = icmp ne ptr %t53, null
  br i1 %t54, label %bb20, label %bb21
bb20:
  %t56 = load ptr, ptr %l32, !tbaa !29
  %t57 = load i64, ptr %t56, !range !{i64 0, i64 29}
  %t59 = icmp eq i64 %t57, 3
  store i1 %t59, ptr %l33, !tbaa !21
  br label %bb21
bb21:
  %t60 = load i1, ptr %l33, !tbaa !21
  br i1 %t60, label %bb22, label %bb23
bb22:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr { i64, [5 x i64] }, ptr %t61, i32 0, i32 1
  %t64 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t63, i32 0, i32 1
  %t65 = load i32, ptr %t64, !range !{i32 0, i32 96}
  store i32 %t65, ptr %l3
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr { i64, [5 x i64] }, ptr %t67, i32 0, i32 1
  %t70 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t69, i32 0, i32 2
  %t71 = load ptr, ptr %t70
  store ptr %t71, ptr %l4, !tbaa !29
  br label %bb24
bb23:
  br label %bb32
bb24:
  %t73 = load i32, ptr %l3, !range !{i32 0, i32 96}
  %t75 = trunc i64 53 to i32
  %t76 = icmp eq i32 %t73, %t75
  br i1 %t76, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb27
bb26:
  %t78 = load i32, ptr %l3, !range !{i32 0, i32 96}
  %t80 = trunc i64 86 to i32
  %t81 = icmp eq i32 %t78, %t80
  store i1 %t81, ptr %l42, !tbaa !21
  br label %bb27
bb27:
  %t83 = load i1, ptr %l42, !tbaa !21
  br i1 %t83, label %bb28, label %bb29
bb28:
  %t84 = load ptr, ptr %l4, !tbaa !29
  %t87 = call i1 @compiler_2fcheck_2enumberLitsOnly(ptr %v0, ptr %t84)
  store i1 %t87, ptr %l48
  br label %bb30
bb29:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb31
bb30:
  %t88 = load i1, ptr %l48, !tbaa !21
  store i1 %t88, ptr %l45, !tbaa !21
  br label %bb31
bb31:
  %t89 = load i1, ptr %l45, !tbaa !21
  store i1 %t89, ptr %l11, !tbaa !21
  br label %bb78
bb32:
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t91 = load ptr, ptr %l49, !tbaa !29
  %t92 = icmp ne ptr %t91, null
  br i1 %t92, label %bb33, label %bb34
bb33:
  %t94 = load ptr, ptr %l49, !tbaa !29
  %t95 = load i64, ptr %t94, !range !{i64 0, i64 29}
  %t97 = icmp eq i64 %t95, 5
  store i1 %t97, ptr %l50, !tbaa !21
  br label %bb34
bb34:
  %t98 = load i1, ptr %l50, !tbaa !21
  br i1 %t98, label %bb35, label %bb36
bb35:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr { i64, [5 x i64] }, ptr %t99, i32 0, i32 1
  %t102 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t101, i32 0, i32 1
  %t103 = load i32, ptr %t102, !range !{i32 0, i32 96}
  store i32 %t103, ptr %l5
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr { i64, [5 x i64] }, ptr %t105, i32 0, i32 1
  %t108 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t107, i32 0, i32 2
  %t109 = load ptr, ptr %t108
  store ptr %t109, ptr %l6, !tbaa !29
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr { i64, [5 x i64] }, ptr %t111, i32 0, i32 1
  %t114 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t113, i32 0, i32 3
  %t115 = load ptr, ptr %t114
  store ptr %t115, ptr %l7, !tbaa !29
  br label %bb37
bb36:
  br label %bb73
bb37:
  %t117 = load i32, ptr %l5, !range !{i32 0, i32 96}
  %t119 = trunc i64 52 to i32
  %t120 = icmp eq i32 %t117, %t119
  br i1 %t120, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l61, !tbaa !21
  br label %bb40
bb39:
  %t122 = load i32, ptr %l5, !range !{i32 0, i32 96}
  %t124 = trunc i64 53 to i32
  %t125 = icmp eq i32 %t122, %t124
  store i1 %t125, ptr %l61, !tbaa !21
  br label %bb40
bb40:
  %t127 = load i1, ptr %l61, !tbaa !21
  br i1 %t127, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l64, !tbaa !21
  br label %bb43
bb42:
  %t128 = load i32, ptr %l5, !range !{i32 0, i32 96}
  %t130 = trunc i64 54 to i32
  %t131 = icmp eq i32 %t128, %t130
  store i1 %t131, ptr %l64, !tbaa !21
  br label %bb43
bb43:
  %t133 = load i1, ptr %l64, !tbaa !21
  br i1 %t133, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb46
bb45:
  %t134 = load i32, ptr %l5, !range !{i32 0, i32 96}
  %t136 = trunc i64 55 to i32
  %t137 = icmp eq i32 %t134, %t136
  store i1 %t137, ptr %l67, !tbaa !21
  br label %bb46
bb46:
  %t139 = load i1, ptr %l67, !tbaa !21
  br i1 %t139, label %bb47, label %bb48
bb47:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb49
bb48:
  %t140 = load i32, ptr %l5, !range !{i32 0, i32 96}
  %t142 = trunc i64 56 to i32
  %t143 = icmp eq i32 %t140, %t142
  store i1 %t143, ptr %l70, !tbaa !21
  br label %bb49
bb49:
  %t145 = load i1, ptr %l70, !tbaa !21
  br i1 %t145, label %bb50, label %bb51
bb50:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb52
bb51:
  %t146 = load i32, ptr %l5, !range !{i32 0, i32 96}
  %t148 = trunc i64 83 to i32
  %t149 = icmp eq i32 %t146, %t148
  store i1 %t149, ptr %l73, !tbaa !21
  br label %bb52
bb52:
  %t151 = load i1, ptr %l73, !tbaa !21
  br i1 %t151, label %bb53, label %bb54
bb53:
  store i1 true, ptr %l76, !tbaa !21
  br label %bb55
bb54:
  %t152 = load i32, ptr %l5, !range !{i32 0, i32 96}
  %t154 = trunc i64 84 to i32
  %t155 = icmp eq i32 %t152, %t154
  store i1 %t155, ptr %l76, !tbaa !21
  br label %bb55
bb55:
  %t157 = load i1, ptr %l76, !tbaa !21
  br i1 %t157, label %bb56, label %bb57
bb56:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb58
bb57:
  %t158 = load i32, ptr %l5, !range !{i32 0, i32 96}
  %t160 = trunc i64 85 to i32
  %t161 = icmp eq i32 %t158, %t160
  store i1 %t161, ptr %l79, !tbaa !21
  br label %bb58
bb58:
  %t163 = load i1, ptr %l79, !tbaa !21
  br i1 %t163, label %bb59, label %bb60
bb59:
  store i1 true, ptr %l82, !tbaa !21
  br label %bb61
bb60:
  %t164 = load i32, ptr %l5, !range !{i32 0, i32 96}
  %t166 = trunc i64 88 to i32
  %t167 = icmp eq i32 %t164, %t166
  store i1 %t167, ptr %l82, !tbaa !21
  br label %bb61
bb61:
  %t169 = load i1, ptr %l82, !tbaa !21
  br i1 %t169, label %bb62, label %bb63
bb62:
  store i1 true, ptr %l85, !tbaa !21
  br label %bb64
bb63:
  %t170 = load i32, ptr %l5, !range !{i32 0, i32 96}
  %t172 = trunc i64 89 to i32
  %t173 = icmp eq i32 %t170, %t172
  store i1 %t173, ptr %l85, !tbaa !21
  br label %bb64
bb64:
  %t175 = load i1, ptr %l85, !tbaa !21
  br i1 %t175, label %bb65, label %bb66
bb65:
  %t176 = load ptr, ptr %l6, !tbaa !29
  %t179 = call i1 @compiler_2fcheck_2enumberLitsOnly(ptr %v0, ptr %t176)
  store i1 %t179, ptr %l91
  br label %bb67
bb66:
  store i1 false, ptr %l88, !tbaa !21
  br label %bb68
bb67:
  %t180 = load i1, ptr %l91, !tbaa !21
  store i1 %t180, ptr %l88, !tbaa !21
  br label %bb68
bb68:
  %t181 = load i1, ptr %l88, !tbaa !21
  br i1 %t181, label %bb69, label %bb70
bb69:
  %t182 = load ptr, ptr %l7, !tbaa !29
  %t185 = call i1 @compiler_2fcheck_2enumberLitsOnly(ptr %v0, ptr %t182)
  store i1 %t185, ptr %l95
  br label %bb71
bb70:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb72
bb71:
  %t186 = load i1, ptr %l95, !tbaa !21
  store i1 %t186, ptr %l92, !tbaa !21
  br label %bb72
bb72:
  %t187 = load i1, ptr %l92, !tbaa !21
  store i1 %t187, ptr %l11, !tbaa !21
  br label %bb78
bb73:
  br i1 true, label %bb74, label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb77
bb76:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb78
bb77:
  call void @__olang_check_failed(ptr @olang_loc_a2bfaee8e4bbf2f0_c4354a8bc250ee0c)
  unreachable
bb78:
  %t188 = load i1, ptr %l11, !tbaa !21
  store i1 %t188, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/check:reflVal" @compiler_2fcheck_2ervBool(ptr %v0, i1 %a0) #0 {
entry:
  %l1 = alloca i64
  %l3 = alloca i64
  %l5 = alloca %"compiler/check:reflVal"
  %rv = alloca %"compiler/check:reflVal"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr @G_2ecompiler_2fcheck_2eRvBool, !tbaa !24
  store i64 %t1, ptr %l1, !tbaa !24
  br i1 %a0, label %bb1, label %bb2
bb1:
  store i64 1, ptr %l3, !tbaa !24
  br label %bb3
bb2:
  store i64 0, ptr %l3, !tbaa !24
  br label %bb3
bb3:
  %t4 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = load i64, ptr %l1, !tbaa !24
  %t6 = load i64, ptr %l3, !tbaa !24
  %t8 = call %"compiler/check:reflVal" @compiler_2fcheck_3areflVal_2ector(ptr %v0, ptr %v0, i1 true, i64 %t5, i64 %t6, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d52, i32 0, i32 1) }, i32 %t4)
  store %"compiler/check:reflVal" %t8, ptr %l5
  br label %bb4
bb4:
  %t9 = load %"compiler/check:reflVal", ptr %l5
  store %"compiler/check:reflVal" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:reflVal", ptr %rv
  ret %"compiler/check:reflVal" %rr
}

define dso_local void @compiler_2fcheck_2estoredExprs(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l16 = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb5, label %bb6
bb5:
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t21, ptr %l16, !tbaa !27
  %t22 = load i64, ptr %l3, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr ptr, ptr %t25, i64 %t22
  %t27 = load ptr, ptr %t26, !tbaa !39
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t27, ptr %a1)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t34 = load i64, ptr %l3, !tbaa !24
  %t36 = add i64 %t34, 1
  store i64 %t36, ptr %l3, !tbaa !24
  br label %bb4
bb10:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t5, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %t7)
  store i32 %t9, ptr %l5
  br label %bb4
bb4:
  %t10 = load i32, ptr %l5, !tbaa !23
  store i32 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/check:TopAssertAsk" @compiler_2fcheck_3aTopAssertAsk_2ector(ptr %v0, i64 %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, i64 %a4) #0 {
entry:
  %rv = alloca %"compiler/check:TopAssertAsk"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/check:TopAssertAsk" undef, i64 %a0, 0
  %t14 = insertvalue %"compiler/check:TopAssertAsk" %t12, %"compiler/source:Span" %a1, 1
  %t16 = insertvalue %"compiler/check:TopAssertAsk" %t14, %"compiler/source:Span" %a2, 2
  %t18 = insertvalue %"compiler/check:TopAssertAsk" %t16, i64 %a3, 3
  %t20 = insertvalue %"compiler/check:TopAssertAsk" %t18, i64 %a4, 4
  store %"compiler/check:TopAssertAsk" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:TopAssertAsk", ptr %rv
  ret %"compiler/check:TopAssertAsk" %rr
}

@.d0 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"LeadingZeros" }>, align 8
@.d1 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"TrailingZeros" }>, align 8
@.d2 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"PopCount" }>, align 8
@.d3 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"RotateLeft" }>, align 8
@.d4 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"RotateRight" }>, align 8
@.d5 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"ByteSwap" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d6 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Call" }>, align 8
@.d7 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"call" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d8 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Call" }>, align 8
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2eArray_3ccompiler_2ftypes_3aTypeId_3e_26(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %l8 = alloca i1
  %l11 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %a0, !tbaa !27
  store { i64, ptr } %t2, ptr %l2, !tbaa !27
  %t4 = load { i64, ptr }, ptr %a1, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  store i1 false, ptr %l4, !tbaa !21
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  %t7 = extractvalue { i64, ptr } zeroinitializer, 0
  %t8 = icmp eq i64 %t6, %t7
  %t9 = extractvalue { i64, ptr } %t5, 1
  %t10 = extractvalue { i64, ptr } zeroinitializer, 1
  %t11 = icmp eq ptr %t9, %t10
  %t12 = and i1 %t8, %t11
  store i1 %t12, ptr %l5, !tbaa !21
  %t13 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } zeroinitializer, 0
  %t16 = icmp eq i64 %t14, %t15
  %t17 = extractvalue { i64, ptr } %t13, 1
  %t18 = extractvalue { i64, ptr } zeroinitializer, 1
  %t19 = icmp eq ptr %t17, %t18
  %t20 = and i1 %t16, %t19
  store i1 %t20, ptr %l6, !tbaa !21
  %t21 = load i1, ptr %l5, !tbaa !21
  %t22 = load i1, ptr %l6, !tbaa !21
  %t23 = and i1 %t21, %t22
  %t24 = load i1, ptr %l5, !tbaa !21
  %t25 = load i1, ptr %l6, !tbaa !21
  %t26 = or i1 %t24, %t25
  store i1 %t26, ptr %l8, !tbaa !21
  br i1 %t23, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb4
bb2:
  %t28 = load i1, ptr %l8, !tbaa !21
  br i1 %t28, label %bb4, label %bb3
bb3:
  %t29 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t33 = call i1 @olang_2eHelperKind_2eEqual_2eArray_3ccompiler_2ftypes_3aTypeId_3e({ i64, ptr } %t29, { i64, ptr } %t30)
  store i1 %t33, ptr %l11
  br label %bb5
bb4:
  %t34 = load i1, ptr %l4, !tbaa !21
  store i1 %t34, ptr %rv
  br label %ret
bb5:
  %t35 = load i1, ptr %l11, !tbaa !21
  store i1 %t35, ptr %l4, !tbaa !21
  br label %bb4
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d9 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"pass a lambda calling it" }>, align 8
@.d10 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"write the function type '" }>, align 8
@.d11 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"', or pass a lambda handling them" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d12 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d13 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
declare void @__olang_ert_req_clear()
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d15 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d16 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" and null" }>, align 8
@__olang_empty_array = external constant [16 x i64]
@.d17 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d18 = private constant <{ i64, [58 x i8] }> <{ i64 0, [58 x i8] c"the checker asked for the body of a frame that checks none" }>, align 8
declare void @__olang_check_failed_text(ptr, { i64, ptr }) cold noreturn
@.d19 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\22\22" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d20 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Array<" }>, align 8
@.d21 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c">(0)" }>, align 8
@.d22 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d23 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d24 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d25 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"join" }>, align 8
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/source:Span", ptr %t1, i32 0, i32 0
  %t3 = load i32, ptr %t2, !tbaa !23
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/source:Span", ptr %t4, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  %t9 = icmp eq i32 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb4
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/source:Span", ptr %t11, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/source:Span", ptr %t14, i32 0, i32 1
  %t16 = load i32, ptr %t15, !tbaa !23
  %t19 = icmp eq i32 %t13, %t16
  br i1 %t19, label %bb3, label %bb1
bb3:
  br label %bb4
bb4:
  %t21 = load i1, ptr %l2, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d26 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"this literal expression's value" }>, align 8
@.d27 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
@.d28 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d29 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
@.d30 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
@.d31 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d32 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d33 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d34 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" to " }>, align 8
@.d35 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d36 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"?" }>, align 8
@.d37 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d38 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" ? " }>, align 8
@.d39 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"? " }>, align 8
@.d40 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d41 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d42 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"std/prelude/text" }>, align 8
@.d43 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"String" }>, align 8
@.d44 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c"a store through an element read of this kind (E31b)" }>, align 8
@.d45 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"SetAt" }>, align 8
@.d46 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"SetAt" }>, align 8
@.d47 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"'x[i] = v'" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d48 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d49 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d50 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d51 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"At" }>, align 8
@.d52 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2eArray_3ccompiler_2ftypes_3aTypeId_3e({ i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i64
  %l6 = alloca i64
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t3, 0
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb7
bb2:
  store i64 0, ptr %l6, !tbaa !24
  br label %bb3
bb3:
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i32, ptr %t15, i64 %t13
  %t17 = load i32, ptr %t16, !tbaa !33
  %t18 = load i64, ptr %l6, !tbaa !24
  %t19 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr i32, ptr %t20, i64 %t18
  %t22 = load i32, ptr %t21, !tbaa !33
  %t25 = icmp eq i32 %t17, %t22
  br i1 %t25, label %bb6, label %bb1
bb5:
  br label %bb7
bb6:
  %t27 = load i64, ptr %l6, !tbaa !24
  %t28 = add i64 %t27, 1
  store i64 %t28, ptr %l6, !tbaa !24
  br label %bb3
bb7:
  %t29 = load i1, ptr %l2, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_a3fc486149a2dc5d_17491af4361141b9 = external constant [0 x i8]
@olang_loc_2196821906d7172f_ce8d1c9901dd14c3 = external constant [0 x i8]
declare void @compiler_2fcheck_2edeclNames(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
@olang_loc_507ed937f609d1d0_9b704622aa820f34 = external constant [0 x i8]
@olang_loc_27f4d264c3bf025_5d55a961c8f61129 = external constant [0 x i8]
@olang_loc_980c9dc24d8ab357_bac7a576dce6b97b = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalType(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprivateRole(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i32 %a2, { i64, ptr } %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritable(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyErrors(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrsText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCallValueErrors(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/msgs:Msg" %a2)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/check:roFn" @compiler_2fcheck_3aroFn_2ector(ptr %v0, ptr %v1, i64 %a0, i64 %a1, { i64, [3 x i64] } %a2, { i64, ptr } %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroFn_3e_2ePush_3ccompiler_2fcheck_3aroFn_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:roFn" %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBind_26_3e_2eLen_3ccompiler_2ftyped_3aBind_26_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBind_26_3e_2eAt_3ccompiler_2ftyped_3aBind_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAltBindsOtherNames(ptr %v0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aBlock(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_37018c2ebf0da22a_371c8892c4c63a5e = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAfter(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ewrittenMut(ptr %v0, ptr %a0)
declare i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eDefined(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %a0, i64 %a1)
@olang_loc_fb617c2d829b7111_714329061eadcd35 = external constant [0 x i8]
@olang_loc_796a210bea009080_30d8ca3bde523e44 = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_Hc8503b2b20cde402cc7bde6f68d96fc0(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare %"compiler/typed:Local" @compiler_2ftyped_3aLocal_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, i32 %a4, { i64, [2 x i64] } %a5)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddLocal(ptr %v0, ptr %a0, %"compiler/typed:Local" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_486b3db7a819736b_b4c2afa2fe5bd5af = external constant [0 x i8]
declare %"compiler/typed:Capture" @compiler_2ftyped_3aCapture_2ector(ptr %v0, ptr %v1, i32 %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aCapture_26_3e_2ePus_Hdab9bd3c8945274d6e7197d4fb29356b(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2ePush_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2fgeneric_2eDescNone = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/generic:Desc" @compiler_2fgeneric_3aDesc_2ector(ptr %v0, i64 %a0, i32 %a1, i64 %a2, i64 %a3)
declare %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_He6be2b0836caba7ddc59483ff74db438(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorSetItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %v0, i32 %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ePush_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %a0, %"compiler/typed:Item" %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsErrVar(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsErrorSet(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eEntriesOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorWord(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorItemKnown(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrLocalName(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrNow(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtNamed(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_fc394d3abb705b3d_774ad654d23301b9 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullKnown(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtUsed(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetLess(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtCaseNever(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetUnion(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare i1 @compiler_2fcheck_2eisNullLit(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrNeverNull(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtItems(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtCaseForm(ptr %v0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetMeet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtNeverIs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@olang_loc_259a476ccf69be4f_4dd02f382a72243 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtMatchMissing(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2eisWild(ptr %v0, ptr %a0)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondNotBoolType(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereSite(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare %"compiler/typed:Promote" @compiler_2ftyped_3aPromote_2ector(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyAll(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare %"compiler/typed:Call" @compiler_2ftyped_3aCall_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, [2 x i64] } %a2, i32 %a3, i1 %a4, i1 %a5)
@olang_loc_4aef7e9433005aa6_9cd0eb13e1392442 = external constant [0 x i8]
declare %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, i64 %a1, { i64, ptr } %a2, ptr %a3, i32 %a4, i32 %a5, i1 %a6)
declare %"compiler/typed:Slice" @compiler_2ftyped_3aSlice_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
@olang_loc_89a248f11218248d_cad7b116269b1029 = external constant [0 x i8]
declare %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
@olang_loc_eb46e205ba3ff6f_6cc0aaf3953c4d5b = external constant [0 x i8]
@olang_loc_b8f4ea1c8ca382ae_7341728a048bae5a = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_700945490095e3ab_b793fb317cfa4b47 = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/check:ctSource" @compiler_2fcheck_3actSource_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3, { i64, ptr } %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_98b1a939df7bf83c_dad16d1edd3f2a28 = external constant [0 x i8]
@olang_loc_25ec48d7738ec131_33504a893c084afd = external constant [0 x i8]
@olang_loc_1c86c4e2a1d4d52a_afb2831c22759b16 = external constant [0 x i8]
@olang_loc_34572fc3675c142e_5b9246c98f1fa642 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitMethod(ptr %v0, ptr %a0, %"compiler/generic:AnySlot" %a1)
@olang_loc_384cb541f04295b0_3f9ee0143bd9d7ac = external constant [0 x i8]
declare %"compiler/ast:Param" @compiler_2fast_3aParam_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, %"compiler/source:Span" %a0, i32 %a1, ptr %a2, ptr %a3, { i64, ptr } %a4)
@olang_loc_a90b29f72ec4d10d_507af4b2e3250de1 = external constant [0 x i8]
@olang_loc_8dac41fcc89db5e5_6cee581458fc6b9 = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etwinBody(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_43d20343d6f566de_136f8b7be912828a = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eHoldsVarByValue(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i64 %a3, i64 %a4)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffS(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffP(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edestructs(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftyped_2eMathExtern(ptr %v0, { i64, ptr } %a0, i64 %a1)
@olang_loc_d97e23b04dcff800_367dc3876d150fb4 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eeffectOp(i32 %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffArm(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_ad4dc9fe288360e2_6bae22496d237a26 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffB(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_29ea0c7d0dcef6fa_322b22c08f06752e = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrValueNoOp(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtCompareWhat(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrValOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrRecode(ptr %v0, ptr %a0, ptr %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaks1(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAsCanFail(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnhandledFallibleCall(ptr %v0)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %a0)
declare %"compiler/check:Gap" @compiler_2fcheck_3aGap_2ector(ptr %v0, ptr %v1, i64 %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2ePush_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:Gap" %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i64 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeck(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_9109cadfb541186e_2a46ab96c2b41f0a = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinWithoutSpawn(ptr %v0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ector(ptr %v0, i64 %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinCatchNeedsTry(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinCannotFail(ptr %v0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eproduced(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2, i64 %a3)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaksBetween(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclause(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i32 %a2, i1 %a3, { i64, ptr } %a4, ptr %a5)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ePush_Hc64f4d0e64077a33423ff9c4e583894f(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eLen__H4e51b5ca7b68af485b8486164a690a5f(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eAt_3ccompiler_2ftyped_3aClause_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_951d796b2ec85af2_4e6ca0fa0a1175d6 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eleavesValue(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinClauseMustLeave(ptr %v0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaught(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eescapes(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinNotTried(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eToAr_H1af1cf80015c73411d038ac8256aec52(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/typed:Join" @compiler_2ftyped_3aJoin_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i1 %a1, { i64, ptr } %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %a0, ptr %a1)
declare %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@G_2ecompiler_2fcheck_2eLaneArr = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eLaneScalar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLiteralNoOwnType(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoverflowsF64(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLiteralExprRange(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eFloatLiteralRange(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeMismatch(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2efloatOverflows(i32 %a0, double %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLiteralRange(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2efloatBits(i32 %a0, double %a1)
declare double @compiler_2fcheck_2elitF64(%"compiler/check:litv" %a0)
declare i64 @compiler_2fcheck_2eintFloatBits(i32 %a0, %"compiler/check:litv" %a1)
declare i1 @compiler_2fcheck_2eintFits(ptr %v0, ptr %a0, %"compiler/check:litv" %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_a9a2c4034b6e08dd_84116590a5e4e601 = external constant [0 x i8]
declare { i32, %"compiler/source:Span" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H7d5384a5030fc995e793b3fe1f57e776(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteLiteralRangeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/msgs:Msg" %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteLiteralRange(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteLiteralLocal(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMembers(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eDefaultErrT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eSetAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordCount(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emustWrite(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i1 %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElemOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %v0, i32 %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperandParam(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforeignRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_64f1128892bbfadb_2fd1650a543ec847 = external constant [0 x i8]
@olang_loc_9b328daa59c12fec_530ed6f7b483a728 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroMatch(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_aa71917389f82fa1_ab8db462134cc7fd = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCallCopy(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_45c1f7cb36e76579_9732da1c199d4515 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hca9d4f63e6a0ec4764c25705e3ecdd1f(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, ptr %a4, i64 %a5)
@olang_loc_8771b1e868207559_9b4adf6aba3e467d = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efirstUncovered(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatchNotExhaustive(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eIndexOf_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMatchValueUncovered(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_5ec272a16da13ce8_6a23c064ecfaca54 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i1 %a3)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTextOf(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_acadf2af31b93e38_18751a402ed16b84 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatternNames(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i1 %a3)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/generic:Context" @compiler_2fgeneric_3aContext_2ector(ptr %v0, i64 %a0, i64 %a1)
declare %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Ha72624ba64524ee3315305b5d1bfb369(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20co_H6cf169b12565f300e9fe11f1c8d55061(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eVar(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_894a72349cd7ef67_30624e129d4b77a3 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstance(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisTrait(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/check:typeCase" @compiler_2fcheck_3atypeCase_2ector(ptr %v0, i1 %a0, i1 %a1, i32 %a2, i64 %a3)
@olang_loc_e76989fdc5a7d341_eb7bf402fcfc8235 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuiltinType(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclType(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2etypePathOf(ptr %v0, ptr %a0)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eArgsFit(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWrittenArity(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2eWrittenTypes(ptr %v0, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgCount(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eApply(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, { i64, ptr } %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesMet(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_8b8738bb0f25fa76_719b7d77c23398a = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
@olang_loc_1dea4fd8b0797e99_ba26b9776858744d = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisOver(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistItems(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/check:reflList" %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescriptor(ptr %v0, ptr %a0, %"compiler/check:reflList" %a1, i64 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflBind(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDecide(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_ef99e54d7427d8e6_6c42201a9dddf792 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflFilterUndecided(ptr %v0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
@G_2ecompiler_2fcheck_2eRoStored = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i64 %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflUnbind(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_cf2444207f491a80_6c107d983071089c = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egeneratorCall(ptr %v0, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ePush_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/check:heldCand" @compiler_2fcheck_3aheldCand_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aheldCand_3e_2ePush_3ccompiler_2fcheck_3aheldCand_3e(ptr %v0, ptr %a0, %"compiler/check:heldCand" %a1)
@olang_loc_b35f41bb006554d6_a1d87dcad76a5f72 = external constant [0 x i8]
@olang_loc_943678799cf3b8f7_240de00f13c53f3 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
@olang_loc_dcf5b9aec39ad50b_4fa64d0de79beb7f = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloopCall(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3, { i64, ptr } %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexhaustedOrBreak(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelementLocals(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, ptr %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkBody(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecountPost(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTemp(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2ftyped_3aExpr_26_3e_26_3e_2ector(ptr %v0, i64 %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etempValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallArgs(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2ftyped_3aExpr_26_3e__H4f2a00f637999dd5fb4d6b4e8f1ae171(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/check:atRec" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aatRec_3e_2eAt_3ccompiler_2fcheck_3aatRec_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2ftyped_3aExpr_26_3e__H6fdae4ec28a8e0f494e79cb375983eb8(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4, i64 %a5, i1 %a6)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eWriteThroughAtNoSetat(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_f5f1ca6bc4d4202_a62b55a8c6b3a336 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_17f46f322b5d16b7_69863e823125c3cb = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, [2 x i64] } %a5)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eSetAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamsOn(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamOn(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i64 %a3)
declare %"compiler/check:laneVals" @compiler_2fcheck_3alaneVals_2ector(ptr %v0)
@olang_loc_8e17bc78d2dfbd4_98f8be4925a702f0 = external constant [0 x i8]
@olang_loc_7c9348342eb48ce3_d1653baf0fdc2fcf = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompoundOp(i32 %a0)
declare i1 @compiler_2fcheck_2elaneTok(i32 %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArg(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaf(ptr %v0, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuiltinElem(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneMethodCalled(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eWriteThroughAtOperator(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneHoldLeaves(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewriteBackNoNumber(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, %"compiler/source:Span" %a5)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFlows(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_161638cb42cb28fe_744a250164fb3182 = external constant [0 x i8]
@olang_loc_d3f4fca21c1b05a5_cc4b7e60173cb869 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftInRange(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, %"compiler/source:Span" %a3)
@olang_loc_21f488b3c5e8e750_2d22ad345f3d4574 = external constant [0 x i8]
@olang_loc_f30c3194d6b62caf_3ce94d7e88579503 = external constant [0 x i8]
@olang_loc_cb5bd539a2ebdd1a_6c90c646f95f810e = external constant [0 x i8]
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eP_Ha5c233616e2ae02d7fe37742cfaef2c2(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereplaceTemp(ptr %v0, ptr %a0, ptr %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eS_H34f0b8d4004ea3d8dbd5c02acd682062(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehole(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
@olang_loc_ec12a5e6811badef_17bc7d420925a003 = external constant [0 x i8]
@olang_loc_da0d16ec43a70817_ac9d3ce40fb81973 = external constant [0 x i8]
@olang_loc_1e80b96f97cf3962_d4e3965ce5124a3e = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, ptr } %a7)
@olang_loc_f5f2ded9311e9d81_bb624a8d0118ae7d = external constant [0 x i8]
@olang_loc_472402eb7644e34_5f66aff84e38a918 = external constant [0 x i8]
@olang_loc_d99d0717bbb0270b_5e4dc4d9370c1e7f = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneTarget(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneStore(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, i64 %a5, i64 %a6, ptr %a7)
declare i32 @compiler_2fcheck_2ebinaryOp(i32 %a0)
@olang_loc_d11b8aacafb7785e_f77cfc6c7f6ded4a = external constant [0 x i8]
@olang_loc_fb4c1a49ef697595_16cae88eb029dae9 = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eA_Hf8c35f4f5353320ac1e6ff0719acdfb7(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_eccd8b6a5c2fa6b0_78891c232bd2a45c = external constant [0 x i8]
@olang_loc_f0e5921914b2a2cf_65ed047d8124f4fb = external constant [0 x i8]
@olang_loc_712f9e4ca30bc6cb_a93275977373a857 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
@olang_loc_fdb64edea8b6d798_567edb713353da64 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_cc3b6ed7ca85eab5_875d9ef7a16c4e59 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2estmtAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_51cc068c3aeae8b4_3b6d62df8d15b2a8 = external constant [0 x i8]
@olang_loc_a6ce77febe1defe5_34385e948c177179 = external constant [0 x i8]
@olang_loc_a2bfaee8e4bbf2f0_c4354a8bc250ee0c = external constant [0 x i8]
@G_2ecompiler_2fcheck_2eRvBool = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/check:reflVal" @compiler_2fcheck_3areflVal_2ector(ptr %v0, ptr %v1, i1 %a0, i64 %a1, i64 %a2, { i64, ptr } %a3, i32 %a4)
declare void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
