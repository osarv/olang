; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i64, i1, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/text:StringBuilder", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/source:Span" = type { i32, i32 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr }, ptr, i32 }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, ptr, i1, i1 }
%"compiler/generic:AnySlot" = type { i32, i32, i64, i64, i1, i32 }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr, { i64, ptr } }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i32, i64, i64, i64, i1, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", i64, i1 }
%"compiler/generic:Binding" = type { i64, i64, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/check:litv" = type { i1, i1, i1, i64, double, i1, i1, i1, i128 }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
%"compiler/ast:If" = type { ptr, ptr, ptr }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/check:errNarrow" = type { i32, i32, i64, i1 }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/check:b5aWalk" = type { i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1 }
%"compiler/check:inPlaceRead" = type { { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"compiler/source:Span" }
%"compiler/check:Gap" = type { i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/check:laneVals" = type { i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/check:laneNode" = type { i64, i32, %"compiler/source:Span", %"compiler/source:Span", i64, i64, i64, ptr, i32, i64, i32 }
%"compiler/ast:Multi" = type { { i64, ptr }, i1, { i64, ptr } }
%"compiler/check:setAt" = type { ptr, i64, { i64, ptr }, { i64, ptr }, %"compiler/source:Span", i32 }
%"compiler/check:reflList" = type { i1, i32, i64, i64 }
%"compiler/generic:Desc" = type { i64, i32, i64, i64 }
%"compiler/check:reflVal" = type { i1, i64, i64, { i64, ptr }, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/check:idleCall" = type { i64, i64, %"compiler/source:Span", { i64, ptr }, ptr }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/typed:TaskClause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i32, %"compiler/source:Span" }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/check:TopAssertAsk" = type { i64, %"compiler/source:Span", %"compiler/source:Span", i64, i64 }
%"compiler/generic:Unmet" = type { i64, i32, i32, i1, i1, i1 }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, { i64, ptr }, i32, i1 }
%"compiler/ast:Compr" = type { ptr, ptr, i32, i32, ptr, ptr, i1, i64 }
%"compiler/typed:DropHolding" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/check:signMag" = type { i1, i128 }
%"compiler/check:fieldSet" = type { { i64, ptr }, i32, { i64, ptr }, { i64, ptr } }
%"compiler/check:narrowed" = type { i64, i64, i32, i64, i64, i1 }
define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCheckMain(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i32
  %l15 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i64
  %l25 = alloca i32
  %l26 = alloca i64
  %l35 = alloca i1
  %l40 = alloca ptr
  %l42 = alloca { i64, [3 x i64] }
  %l43 = alloca %"compiler/diagmsg:Msg"
  %l44 = alloca i64
  %l48 = alloca ptr
  %l52 = alloca i32
  %l57 = alloca i1
  %l63 = alloca i1
  %l69 = alloca i1
  %l73 = alloca i1
  %l78 = alloca i32
  %l84 = alloca ptr
  %l86 = alloca { i64, [3 x i64] }
  %l87 = alloca %"compiler/diagmsg:Msg"
  %l88 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %t87 = alloca { i64, [3 x i64] }, align 8
  %t187 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 12
  %t10 = load i64, ptr %t9, !tbaa !24
  store i64 %t10, ptr %l1, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 0
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/load:Loader", ptr %t18, i32 0, i32 10
  %t21 = load i64, ptr %l1, !tbaa !24
  %t24 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t20, i64 %t21)
  store ptr %t24, ptr %l15
  br label %bb1
bb1:
  %t25 = load ptr, ptr %l15, !tbaa !29
  %t27 = getelementptr %"compiler/load:Module", ptr %t25, i32 0, i32 4
  %t28 = load i64, ptr %t27, !tbaa !24
  store i64 %t28, ptr %l2, !tbaa !24
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  store ptr %t33, ptr %l19, !tbaa !29
  %t34 = load i64, ptr %l1, !tbaa !24
  store i64 %t34, ptr %l20, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"compiler/generic:Program", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/load:Loader", ptr %t41, i32 0, i32 3
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t44, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i32 %t46, ptr %l25
  br label %bb2
bb2:
  %t47 = load ptr, ptr %l19, !tbaa !29
  %t48 = load i64, ptr %l20, !tbaa !24
  %t49 = load i32, ptr %l25, !tbaa !23
  %t50 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %t47, i64 %t48, i32 %t49)
  store i64 %t50, ptr %l26
  br label %bb3
bb3:
  %t51 = load i64, ptr %l26, !tbaa !24
  store i64 %t51, ptr %l3, !tbaa !24
  %t52 = load i64, ptr %l3, !tbaa !24
  %t54 = icmp slt i64 %t52, 0
  br i1 %t54, label %bb4, label %bb5
bb4:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/load:Loader", ptr %t62, i32 0, i32 4
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t66, i32 0, i32 94
  %t69 = load i64, ptr %t68, !tbaa !24
  %t72 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorBefore(ptr %v0, ptr %t65, i64 %t69)
  store i1 %t72, ptr %l35
  br label %bb6
bb5:
  br label %bb12
bb6:
  %t73 = load i1, ptr %l35, !tbaa !21
  %t74 = xor i1 %t73, true
  br i1 %t74, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/generic:Program", ptr %t79, i32 0, i32 0
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/load:Loader", ptr %t82, i32 0, i32 4
  %t85 = load ptr, ptr %t84, !tbaa !29
  store ptr %t85, ptr %l40, !tbaa !29
  %t86 = load i64, ptr %l2, !tbaa !24
  store { i64, [3 x i64] } zeroinitializer, ptr %t87
  %t88 = getelementptr { i64, [3 x i64] }, ptr %t87, i32 0, i32 0
  store i64 1, ptr %t88
  %t90 = insertvalue { i64 } undef, i64 %t86, 0
  %t91 = getelementptr { i64, [3 x i64] }, ptr %t87, i32 0, i32 1
  store { i64 } %t90, ptr %t91
  %t92 = load { i64, [3 x i64] }, ptr %t87
  store { i64, [3 x i64] } %t92, ptr %l42
  %t93 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoMain(ptr %s2)
  store %"compiler/diagmsg:Msg" %t93, ptr %l43
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t94 = load ptr, ptr %l40, !tbaa !29
  %t95 = load { i64, [3 x i64] }, ptr %l42
  %t96 = load %"compiler/diagmsg:Msg", ptr %l43
  %t97 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s2, ptr %t94, { i64, [3 x i64] } %t95, %"compiler/diagmsg:Msg" %t96)
  store i64 %t97, ptr %l44
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb12:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/check:Checker", ptr %t98, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t102 = load i64, ptr %l3, !tbaa !24
  %t105 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t101, i64 %t102)
  store ptr %t105, ptr %l48
  br label %bb13
bb13:
  %t106 = load ptr, ptr %l48, !tbaa !29
  store ptr %t106, ptr %l4, !tbaa !29
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/check:Checker", ptr %t107, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t111 = load i64, ptr %l3, !tbaa !24
  %t114 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t110, i64 %t111)
  store i32 %t114, ptr %l52
  br label %bb14
bb14:
  %t115 = load i32, ptr %l52, !tbaa !23
  store i32 %t115, ptr %l5, !tbaa !23
  %t116 = load ptr, ptr %l4, !tbaa !29
  %t118 = getelementptr %"compiler/ast:Func", ptr %t116, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t121 = icmp eq ptr %t119, null
  %t123 = xor i1 %t121, true
  br i1 %t123, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb17
bb16:
  %t125 = load ptr, ptr %l4, !tbaa !29
  %t127 = getelementptr %"compiler/ast:Func", ptr %t125, i32 0, i32 3
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t130 = getelementptr %"compiler/ast:Sig", ptr %t128, i32 0, i32 0
  %t131 = load { i64, ptr }, ptr %t130, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t131, 0
  %t135 = icmp sgt i64 %t133, 0
  store i1 %t135, ptr %l57, !tbaa !21
  br label %bb17
bb17:
  %t137 = load i1, ptr %l57, !tbaa !21
  br i1 %t137, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l63, !tbaa !21
  br label %bb20
bb19:
  %t138 = load ptr, ptr %l4, !tbaa !29
  %t140 = getelementptr %"compiler/ast:Func", ptr %t138, i32 0, i32 3
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t143 = getelementptr %"compiler/ast:Sig", ptr %t141, i32 0, i32 1
  %t144 = load { i64, ptr }, ptr %t143, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t144, 0
  %t148 = icmp sgt i64 %t146, 0
  store i1 %t148, ptr %l63, !tbaa !21
  br label %bb20
bb20:
  %t150 = load i1, ptr %l63, !tbaa !21
  br i1 %t150, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l69, !tbaa !21
  br label %bb23
bb22:
  %t151 = load ptr, ptr %l4, !tbaa !29
  %t153 = getelementptr %"compiler/ast:Func", ptr %t151, i32 0, i32 3
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t156 = getelementptr %"compiler/ast:Sig", ptr %t154, i32 0, i32 4
  %t157 = load i1, ptr %t156, !tbaa !21
  store i1 %t157, ptr %l69, !tbaa !21
  br label %bb23
bb23:
  %t159 = load i1, ptr %l69, !tbaa !21
  br i1 %t159, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb27
bb25:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/check:Checker", ptr %t160, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !29
  %t165 = getelementptr %"compiler/generic:Program", ptr %t163, i32 0, i32 2
  %t166 = load i32, ptr %l5, !tbaa !23
  %t169 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t165, i32 %t166)
  store i32 %t169, ptr %l78
  br label %bb26
bb26:
  %t170 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t171 = load i32, ptr %l78, !tbaa !23
  %t173 = icmp ne i32 %t171, %t170
  store i1 %t173, ptr %l73, !tbaa !21
  br label %bb27
bb27:
  %t175 = load i1, ptr %l73, !tbaa !21
  br i1 %t175, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s3
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/check:Checker", ptr %t176, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !29
  %t181 = getelementptr %"compiler/generic:Program", ptr %t179, i32 0, i32 0
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t184 = getelementptr %"compiler/load:Loader", ptr %t182, i32 0, i32 4
  %t185 = load ptr, ptr %t184, !tbaa !29
  store ptr %t185, ptr %l84, !tbaa !29
  %t186 = load i64, ptr %l2, !tbaa !24
  store { i64, [3 x i64] } zeroinitializer, ptr %t187
  %t188 = getelementptr { i64, [3 x i64] }, ptr %t187, i32 0, i32 0
  store i64 1, ptr %t188
  %t190 = insertvalue { i64 } undef, i64 %t186, 0
  %t191 = getelementptr { i64, [3 x i64] }, ptr %t187, i32 0, i32 1
  store { i64 } %t190, ptr %t191
  %t192 = load { i64, [3 x i64] }, ptr %t187
  store { i64, [3 x i64] } %t192, ptr %l86
  %t193 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMainSignature(ptr %s3)
  store %"compiler/diagmsg:Msg" %t193, ptr %l87
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t194 = load ptr, ptr %l84, !tbaa !29
  %t195 = load { i64, [3 x i64] }, ptr %l86
  %t196 = load %"compiler/diagmsg:Msg", ptr %l87
  %t197 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s3, ptr %t194, { i64, [3 x i64] } %t195, %"compiler/diagmsg:Msg" %t196)
  store i64 %t197, ptr %l88
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s3)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eExprBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l4 = alloca ptr
  %l5 = alloca i64
  %l8 = alloca { i64, ptr }
  %l14 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store ptr %a0, ptr %l4, !tbaa !29
  store i64 %a1, ptr %l5, !tbaa !24
  %t3 = icmp sge i64 0, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = icmp sle i64 0, 2305843009213693951
  br i1 %t5, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_a6ae1e9a693d05c9_888d1f7981f90365)
  unreachable
bb3:
  %t7 = mul i64 0, 4
  %t8 = insertvalue { i64, ptr } undef, i64 0, 0
  %t9 = insertvalue { i64, ptr } %t8, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t9, ptr %l8, !tbaa !27
  %t10 = icmp sge i64 0, 0
  br i1 %t10, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_a6ae1e9a693d05c9_888d1f7981f90365)
  unreachable
bb5:
  %t12 = icmp sle i64 0, 2305843009213693951
  br i1 %t12, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_a6ae1e9a693d05c9_888d1f7981f90365)
  unreachable
bb7:
  %t14 = mul i64 0, 4
  %t15 = insertvalue { i64, ptr } undef, i64 0, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t19 = load ptr, ptr %l4, !tbaa !29
  %t20 = load i64, ptr %l5, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t25 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eExprBodyIn(ptr %v0, ptr %s0, ptr %s0, ptr %v1, ptr %t19, i64 %t20, i64 -1, { i64, ptr } %t21, { i64, ptr } %t16, ptr %a2, i32 %a3)
  store i64 %t25, ptr %l14
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_a6ae1e9a693d05c9_888d1f7981f90365)
  unreachable
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t26 = load i64, ptr %l14, !tbaa !24
  store i64 %t26, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargDefault(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, i64 %a4, i1 %a5, i32 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l4 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"compiler/generic:AnySlot"
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i1
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l47 = alloca ptr
  %l50 = alloca ptr
  %l55 = alloca i1
  %l58 = alloca i1
  %l65 = alloca i1
  %l68 = alloca { i64, ptr }
  %l76 = alloca i64
  %l81 = alloca ptr
  %l82 = alloca %"compiler/source:Span"
  %l83 = alloca i64
  %l86 = alloca { i64, ptr }
  %l88 = alloca %"compiler/diagmsg:Msg"
  %l89 = alloca i64
  %l92 = alloca ptr
  %l97 = alloca i32
  %l102 = alloca i64
  %l104 = alloca ptr
  %l108 = alloca ptr
  %l114 = alloca ptr
  %l115 = alloca ptr
  %l119 = alloca %"compiler/generic:Context"
  %l123 = alloca ptr
  %l126 = alloca { i64, ptr }
  %l134 = alloca ptr
  %l139 = alloca ptr
  %l152 = alloca ptr
  %l153 = alloca %"compiler/source:Span"
  %l154 = alloca i64
  %l155 = alloca i64
  %l156 = alloca i1
  %l157 = alloca i32
  %l160 = alloca i32
  %l161 = alloca ptr
  %s3 = alloca %olang.scope
  %rv = alloca ptr
  %t211 = alloca %"compiler/generic:Context", align 8
  %t277 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a4, ptr %l4
  store i32 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t2 = load ptr, ptr %l22, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l22, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 5}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l23, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l23, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i32, i64, i32 }, ptr %t12, i32 0, i32 0
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l7, !tbaa !23
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { i32, i64, i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l8, !tbaa !24
  br label %bb5
bb4:
  br label %bb49
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t26 = load i32, ptr %l7, !tbaa !23
  %t29 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v0, ptr %t25, i32 %t26)
  store { i64, ptr } %t29, ptr %l33
  br label %bb6
bb6:
  %t30 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t30, ptr %l9, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t31, ptr %l34, !tbaa !27
  %t32 = load i64, ptr %l8, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t38 = srem i64 %t32, %t35
  %t40 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr %"compiler/generic:AnySlot", ptr %t41, i64 %t38
  %t43 = load %"compiler/generic:AnySlot", ptr %t42
  store %"compiler/generic:AnySlot" %t43, ptr %l10
  %t45 = getelementptr %"compiler/generic:AnySlot", ptr %l10, i32 0, i32 2
  %t46 = load i64, ptr %t45, !tbaa !24
  %t48 = icmp slt i64 %t46, 0
  br i1 %t48, label %bb7, label %bb8
bb7:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load %"compiler/source:Span", ptr %l1
  %t52 = getelementptr %"compiler/generic:AnySlot", ptr %l10, i32 0, i32 3
  %t53 = load i64, ptr %t52, !tbaa !24
  %t54 = load i64, ptr %l4, !tbaa !24
  %t55 = load i32, ptr %l6, !tbaa !23
  %t61 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultArg(ptr %v0, ptr %v2, ptr %t50, %"compiler/source:Span" %t51, i64 %t53, i64 %t54, i1 true, i32 %t55, i32 0)
  store ptr %t61, ptr %l47
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t62 = load ptr, ptr %l47, !tbaa !29
  store ptr %t62, ptr %rv
  br label %ret
bb10:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load %"compiler/generic:AnySlot", ptr %l10
  %t67 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitMethod(ptr %v0, ptr %v2, ptr %t63, %"compiler/generic:AnySlot" %t64)
  store ptr %t67, ptr %l50
  br label %bb11
bb11:
  %t68 = load ptr, ptr %l50, !tbaa !29
  store ptr %t68, ptr %l11, !tbaa !29
  %t69 = load i64, ptr %l4, !tbaa !24
  %t71 = sub i64 %t69, 1
  store i64 %t71, ptr %l12, !tbaa !24
  %t73 = load ptr, ptr %l11, !tbaa !29
  %t75 = icmp eq ptr %t73, null
  br i1 %t75, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l55, !tbaa !21
  br label %bb14
bb13:
  %t77 = load i64, ptr %l12, !tbaa !24
  %t79 = icmp slt i64 %t77, 0
  store i1 %t79, ptr %l55, !tbaa !21
  br label %bb14
bb14:
  %t81 = load i1, ptr %l55, !tbaa !21
  br i1 %t81, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l58, !tbaa !21
  br label %bb17
bb16:
  %t82 = load i64, ptr %l12, !tbaa !24
  %t83 = load ptr, ptr %l11, !tbaa !29
  %t85 = getelementptr %"compiler/ast:Func", ptr %t83, i32 0, i32 3
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/ast:Sig", ptr %t86, i32 0, i32 0
  %t89 = load { i64, ptr }, ptr %t88, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t94 = icmp sge i64 %t82, %t91
  store i1 %t94, ptr %l58, !tbaa !21
  br label %bb17
bb17:
  %t96 = load i1, ptr %l58, !tbaa !21
  br i1 %t96, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb20
bb19:
  %t97 = load ptr, ptr %l11, !tbaa !29
  %t99 = getelementptr %"compiler/ast:Func", ptr %t97, i32 0, i32 3
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/ast:Sig", ptr %t100, i32 0, i32 0
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  store { i64, ptr } %t103, ptr %l68, !tbaa !27
  %t104 = load i64, ptr %l12, !tbaa !24
  %t106 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr ptr, ptr %t107, i64 %t104
  %t109 = load ptr, ptr %t108, !tbaa !39
  %t111 = getelementptr %"compiler/ast:Param", ptr %t109, i32 0, i32 3
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = icmp eq ptr %t112, null
  store i1 %t114, ptr %l65, !tbaa !21
  br label %bb20
bb20:
  %t116 = load i1, ptr %l65, !tbaa !21
  br i1 %t116, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  %t117 = load ptr, ptr %l11, !tbaa !29
  %t119 = icmp eq ptr %t117, null
  %t121 = xor i1 %t119, true
  br i1 %t121, label %bb23, label %bb24
bb22:
  br label %bb32
bb23:
  %t123 = load ptr, ptr %l11, !tbaa !29
  %t125 = getelementptr %"compiler/ast:Func", ptr %t123, i32 0, i32 3
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t128 = getelementptr %"compiler/ast:Sig", ptr %t126, i32 0, i32 0
  %t129 = load { i64, ptr }, ptr %t128, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t129, 0
  store i64 %t131, ptr %l76, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l76, !tbaa !24
  br label %bb25
bb25:
  %t133 = load i64, ptr %l76, !tbaa !24
  store i64 %t133, ptr %l13, !tbaa !24
  %t134 = load ptr, ptr %l0, !tbaa !29
  store ptr %t134, ptr %l81, !tbaa !29
  %t135 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t135, ptr %l82
  %t136 = load i64, ptr %l13, !tbaa !24
  store i64 %t136, ptr %l83, !tbaa !24
  %t137 = load i64, ptr %l13, !tbaa !24
  %t139 = icmp eq i64 %t137, 1
  br i1 %t139, label %bb26, label %bb27
bb26:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l86, !tbaa !27
  br label %bb28
bb27:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %l86, !tbaa !27
  br label %bb28
bb28:
  %t141 = load i64, ptr %l12, !tbaa !24
  %t142 = load i64, ptr %l83, !tbaa !24
  %t143 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t145 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArgCount(ptr %s3, ptr %s3, i64 %t142, { i64, ptr } %t143, i64 %t141)
  store %"compiler/diagmsg:Msg" %t145, ptr %l88
  br label %bb29
bb29:
  %t146 = load ptr, ptr %l81, !tbaa !29
  %t147 = load %"compiler/source:Span", ptr %l82
  %t148 = load %"compiler/diagmsg:Msg", ptr %l88
  %t149 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t146, %"compiler/source:Span" %t147, %"compiler/diagmsg:Msg" %t148)
  store i64 %t149, ptr %l89
  br label %bb30
bb30:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load %"compiler/source:Span", ptr %l1
  %t154 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t150, %"compiler/source:Span" %t151)
  store ptr %t154, ptr %l92
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s3)
  %t155 = load ptr, ptr %l92, !tbaa !29
  store ptr %t155, ptr %rv
  br label %ret
bb32:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/check:Checker", ptr %t156, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t161 = getelementptr %"compiler/generic:Program", ptr %t159, i32 0, i32 2
  %t162 = getelementptr %"compiler/generic:AnySlot", ptr %l10, i32 0, i32 1
  %t163 = load i32, ptr %t162, !tbaa !23
  %t166 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t161, i32 %t163)
  store i32 %t166, ptr %l97
  br label %bb33
bb33:
  %t167 = load i32, ptr %l97, !tbaa !23
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/check:Checker", ptr %t168, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !29
  %t173 = getelementptr %"compiler/generic:Program", ptr %t171, i32 0, i32 2
  %t177 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t173, i32 %t167)
  store i64 %t177, ptr %l102
  br label %bb34
bb34:
  %t178 = load i64, ptr %l102, !tbaa !24
  store i64 %t178, ptr %l15, !tbaa !24
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t179)
  store ptr %t181, ptr %l104
  br label %bb35
bb35:
  %t182 = load ptr, ptr %l104, !tbaa !29
  %t184 = getelementptr %"compiler/check:frame", ptr %t182, i32 0, i32 2
  %t185 = load i64, ptr %t184, !tbaa !24
  store i64 %t185, ptr %l16, !tbaa !24
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t187)
  store ptr %t189, ptr %l108
  br label %bb36
bb36:
  %t190 = load ptr, ptr %l108, !tbaa !29
  store ptr %t190, ptr %l17, !tbaa !29
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t192 = load ptr, ptr %l17, !tbaa !29
  %t194 = getelementptr %"compiler/check:frame", ptr %t192, i32 0, i32 0
  %t195 = load i64, ptr %t194, !tbaa !24
  %t196 = load i64, ptr %l15, !tbaa !24
  %t197 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t202 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t191, i64 %t195, i64 %t196, i32 %t197, i32 0)
  store ptr %t202, ptr %l114
  br label %bb37
bb37:
  %t203 = load ptr, ptr %l114, !tbaa !29
  store ptr %t203, ptr %l18, !tbaa !29
  %t204 = load ptr, ptr %l18, !tbaa !29
  store ptr %t204, ptr %l115, !tbaa !29
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/check:Checker", ptr %t205, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !29
  %t209 = getelementptr %"compiler/generic:AnySlot", ptr %l10, i32 0, i32 1
  %t210 = load i32, ptr %t209, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceContext(ptr %t211, ptr %v0, ptr %v0, ptr %t208, i32 %t210)
  call void @llvm.memmove.p0.p0.i64(ptr %l119, ptr %t211, i64 160, i1 false)
  br label %bb38
bb38:
  %t214 = load ptr, ptr %l115, !tbaa !29
  %t215 = getelementptr %"compiler/check:frame", ptr %t214, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %t215, ptr %l119, i64 160, i1 false)
  %t216 = load ptr, ptr %l18, !tbaa !29
  %t217 = load ptr, ptr %l17, !tbaa !29
  %t219 = getelementptr %"compiler/check:frame", ptr %t217, i32 0, i32 7
  %t220 = load i64, ptr %t219, !tbaa !24
  %t223 = getelementptr %"compiler/check:frame", ptr %t216, i32 0, i32 7
  store i64 %t220, ptr %t223, !tbaa !24
  %t224 = load ptr, ptr %l0, !tbaa !29
  store ptr %t224, ptr %l123, !tbaa !29
  %t225 = load ptr, ptr %l11, !tbaa !29
  %t227 = getelementptr %"compiler/ast:Func", ptr %t225, i32 0, i32 3
  %t228 = load ptr, ptr %t227, !tbaa !29
  %t230 = getelementptr %"compiler/ast:Sig", ptr %t228, i32 0, i32 0
  %t231 = load { i64, ptr }, ptr %t230, !tbaa !27
  store { i64, ptr } %t231, ptr %l126, !tbaa !27
  %t232 = load i64, ptr %l12, !tbaa !24
  %t234 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = getelementptr ptr, ptr %t235, i64 %t232
  %t237 = load ptr, ptr %t236, !tbaa !39
  %t239 = getelementptr %"compiler/ast:Param", ptr %t237, i32 0, i32 3
  %t240 = load ptr, ptr %t239, !tbaa !29
  store ptr %t240, ptr %l19, !tbaa !29
  %t242 = load ptr, ptr %l19, !tbaa !29
  %t244 = icmp eq ptr %t242, null
  br i1 %t244, label %bb39, label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_87950e0971945cd5_bece9ab6826c95c9)
  unreachable
bb40:
  br label %bb41
bb41:
  %t246 = load ptr, ptr %l19, !tbaa !29
  %t247 = load i32, ptr %l6, !tbaa !23
  %t248 = load ptr, ptr %l123, !tbaa !29
  %t251 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v2, ptr %v2, ptr %t248, ptr %t246, i32 %t247)
  store ptr %t251, ptr %l134
  br label %bb42
bb42:
  %t252 = load ptr, ptr %l134, !tbaa !29
  store ptr %t252, ptr %l20, !tbaa !29
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t254 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultReads(ptr %v0, ptr %v2, ptr %t253, ptr %t254)
  br label %bb43
bb43:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t260 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t258)
  store ptr %t260, ptr %l139
  br label %bb44
bb44:
  %t261 = load ptr, ptr %l139, !tbaa !29
  %t263 = getelementptr %"compiler/check:frame", ptr %t261, i32 0, i32 2
  %t264 = load i64, ptr %t263, !tbaa !24
  store i64 %t264, ptr %l21, !tbaa !24
  %t266 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t266)
  br label %bb45
bb45:
  %t268 = load i64, ptr %l21, !tbaa !24
  %t269 = load i64, ptr %l16, !tbaa !24
  %t272 = icmp ne i64 %t268, %t269
  br i1 %t272, label %bb46, label %bb47
bb46:
  %t274 = load %"compiler/source:Span", ptr %l1
  %t275 = load i64, ptr %l21, !tbaa !24
  %t276 = load ptr, ptr %l20, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t277
  %t278 = getelementptr { i64, [5 x i64] }, ptr %t277, i32 0, i32 0
  store i64 17, ptr %t278
  %t280 = insertvalue { %"compiler/source:Span", i64, ptr } undef, %"compiler/source:Span" %t274, 0
  %t282 = insertvalue { %"compiler/source:Span", i64, ptr } %t280, i64 %t275, 1
  %t284 = insertvalue { %"compiler/source:Span", i64, ptr } %t282, ptr %t276, 2
  %t285 = getelementptr { i64, [5 x i64] }, ptr %t277, i32 0, i32 1
  store { %"compiler/source:Span", i64, ptr } %t284, ptr %t285
  %t286 = load { i64, [5 x i64] }, ptr %t277
  %t288 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t286, ptr %t288
  store ptr %t288, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  %t290 = load ptr, ptr %l20, !tbaa !29
  store ptr %t290, ptr %rv
  br label %ret
bb49:
  br i1 true, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb55
bb52:
  %t292 = load ptr, ptr %l0, !tbaa !29
  store ptr %t292, ptr %l152, !tbaa !29
  %t293 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t293, ptr %l153
  store i64 %a3, ptr %l154, !tbaa !24
  %t295 = load i64, ptr %l4, !tbaa !24
  store i64 %t295, ptr %l155, !tbaa !24
  store i1 %a5, ptr %l156, !tbaa !21
  %t297 = load i32, ptr %l6, !tbaa !23
  store i32 %t297, ptr %l157, !tbaa !23
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t299 = load ptr, ptr %l2, !tbaa !29
  %t302 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeArgs(ptr %v0, ptr %v1, ptr %t298, ptr %t299)
  store i32 %t302, ptr %l160
  br label %bb53
bb53:
  %t303 = load ptr, ptr %l152, !tbaa !29
  %t304 = load %"compiler/source:Span", ptr %l153
  %t305 = load i64, ptr %l154, !tbaa !24
  %t306 = load i64, ptr %l155, !tbaa !24
  %t307 = load i1, ptr %l156, !tbaa !21
  %t308 = load i32, ptr %l157, !tbaa !23
  %t309 = load i32, ptr %l160, !tbaa !23
  %t310 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultArg(ptr %v0, ptr %v2, ptr %t303, %"compiler/source:Span" %t304, i64 %t305, i64 %t306, i1 %t307, i32 %t308, i32 %t309)
  store ptr %t310, ptr %l161
  br label %bb54
bb54:
  %t311 = load ptr, ptr %l161, !tbaa !29
  store ptr %t311, ptr %rv
  br label %ret
bb55:
  call void @__olang_check_failed(ptr @olang_loc_f8c90d07629b23d_673d56dd932bf211)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrTypeOk(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l6 = alloca i1
  %l13 = alloca i32
  %l17 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca ptr
  %l26 = alloca i1
  %l32 = alloca i32
  %l35 = alloca i1
  %l41 = alloca i1
  %l44 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i1, ptr %l6, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  %t16 = load i32, ptr %l1, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t19, ptr %l13
  br label %bb5
bb5:
  %t20 = load i32, ptr %l13, !tbaa !23
  store i32 %t20, ptr %l2, !tbaa !23
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 0
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/load:Loader", ptr %t27, i32 0, i32 10
  store ptr %t29, ptr %l17, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/generic:Program", ptr %t33, i32 0, i32 2
  %t36 = load i32, ptr %l2, !tbaa !23
  %t39 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t35, i32 %t36)
  store i64 %t39, ptr %l22
  br label %bb6
bb6:
  %t40 = load ptr, ptr %l17, !tbaa !29
  %t41 = load i64, ptr %l22, !tbaa !24
  %t42 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t40, i64 %t41)
  store ptr %t42, ptr %l23
  br label %bb7
bb7:
  %t43 = load ptr, ptr %l23, !tbaa !29
  %t45 = getelementptr %"compiler/load:Module", ptr %t43, i32 0, i32 2
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  %t48 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t46, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i1 %t48, ptr %l26
  br label %bb8
bb8:
  %t49 = load i1, ptr %l26, !tbaa !21
  br i1 %t49, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/check:Checker", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/generic:Program", ptr %t54, i32 0, i32 2
  %t57 = load i32, ptr %l2, !tbaa !23
  %t60 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t56, i32 %t57)
  store i32 %t60, ptr %l32
  br label %bb12
bb12:
  %t61 = load i32, ptr %l32, !range !{i32 0, i32 6}
  store i32 %t61, ptr %l3
  %t62 = load i32, ptr %l3, !range !{i32 0, i32 6}
  %t64 = trunc i64 0 to i32
  %t65 = icmp eq i32 %t62, %t64
  br i1 %t65, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb15
bb14:
  %t67 = load i32, ptr %l3, !range !{i32 0, i32 6}
  %t69 = trunc i64 1 to i32
  %t70 = icmp eq i32 %t67, %t69
  store i1 %t70, ptr %l35, !tbaa !21
  br label %bb15
bb15:
  %t72 = load i1, ptr %l35, !tbaa !21
  br i1 %t72, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t74 = load i32, ptr %l3, !range !{i32 0, i32 6}
  %t76 = trunc i64 4 to i32
  %t77 = icmp eq i32 %t74, %t76
  br i1 %t77, label %bb19, label %bb20
bb19:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load i32, ptr %l1, !tbaa !23
  %t83 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t79, i32 %t80)
  store i1 %t83, ptr %l44
  br label %bb21
bb20:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb22
bb21:
  %t84 = load i1, ptr %l44, !tbaa !21
  store i1 %t84, ptr %l41, !tbaa !21
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t85 = load i1, ptr %l41, !tbaa !21
  store i1 %t85, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStrBody(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"compiler/generic:Binding"
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l14 = alloca i1
  %l17 = alloca i64
  %l21 = alloca i64
  %l24 = alloca i64
  %l26 = alloca ptr
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i32
  %l35 = alloca ptr
  %l38 = alloca ptr
  %l42 = alloca i32
  %l43 = alloca i32
  %l44 = alloca { i64, ptr }
  %l51 = alloca %"compiler/generic:Binding"
  %l53 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l76 = alloca i64
  %l78 = alloca ptr
  %l80 = alloca ptr
  %l81 = alloca i64
  %l86 = alloca i32
  %l87 = alloca i64
  %l88 = alloca i64
  %l89 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %t4, i64 %t5)
  store i1 %t8, ptr %l14
  br label %bb1
bb1:
  %t9 = load i1, ptr %l14, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load i64, ptr %l1, !tbaa !24
  %t13 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t11)
  store i64 %t13, ptr %l17
  br label %bb5
bb5:
  %t14 = load i64, ptr %l17, !tbaa !24
  store i64 %t14, ptr %l3, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t18, i64 %t19)
  store i64 %t22, ptr %l21
  br label %bb6
bb6:
  %t23 = load i64, ptr %l21, !tbaa !24
  store i64 %t23, ptr %l4, !tbaa !24
  %t24 = load i64, ptr %l4, !tbaa !24
  %t26 = icmp eq i64 %t24, 0
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 20
  store ptr %t30, ptr %l26, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t35 = load i64, ptr %l1, !tbaa !24
  %t38 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %t34, i64 %t35, i32 0)
  store i64 %t38, ptr %l30
  br label %bb9
bb8:
  br label %bb14
bb9:
  %t39 = load ptr, ptr %l26, !tbaa !29
  %t40 = load i64, ptr %l30, !tbaa !24
  %t41 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t39, i64 %t40)
  %t42 = extractvalue { i32, i64 } %t41, 1
  %t43 = extractvalue { i32, i64 } %t41, 0
  store i32 %t43, ptr %l32
  %t44 = icmp ne i32 %t43, 0
  br i1 %t44, label %bb11, label %ok.45, !prof !99
ok.45:
  store i64 %t42, ptr %l31
  br label %bb10
bb10:
  %t46 = load i64, ptr %l31, !tbaa !24
  store i64 %t46, ptr %l24, !tbaa !24
  br label %bb13
bb11:
  br label %bb12
bb12:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l24, !tbaa !24
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t47 = load i64, ptr %l24, !tbaa !24
  store i64 %t47, ptr %rv
  br label %ret
bb14:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = getelementptr %"compiler/generic:Program", ptr %t51, i32 0, i32 2
  store ptr %t53, ptr %l35, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/generic:Program", ptr %t57, i32 0, i32 2
  store ptr %t59, ptr %l38, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Checker", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t64 = load i64, ptr %l1, !tbaa !24
  %t67 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t63, i64 %t64)
  store i32 %t67, ptr %l42
  br label %bb15
bb15:
  %t68 = load ptr, ptr %l38, !tbaa !29
  %t69 = load i32, ptr %l42, !tbaa !23
  %t70 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t68, i32 %t69)
  store i32 %t70, ptr %l43
  br label %bb16
bb16:
  %t71 = load ptr, ptr %l35, !tbaa !29
  %t72 = load i32, ptr %l43, !tbaa !23
  %t73 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t71, i32 %t72)
  store { i64, ptr } %t73, ptr %l44
  br label %bb17
bb17:
  %t74 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t74, ptr %l5, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t75, 0
  %t79 = icmp eq i64 %t77, 0
  br i1 %t79, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t82 = load i64, ptr %l3, !tbaa !24
  %t83 = load i64, ptr %l4, !tbaa !24
  %t86 = call %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %s0, i64 %t82, i64 %t83)
  store %"compiler/generic:Binding" %t86, ptr %l51
  br label %bb21
bb21:
  %t87 = load %"compiler/generic:Binding", ptr %l51
  store %"compiler/generic:Binding" %t87, ptr %l6
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t89, ptr %l53, !tbaa !27
  %t90 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr i32, ptr %t91, i64 0
  %t93 = load i32, ptr %t92, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %s0, ptr %t88, i32 %t93, i32 %a2, ptr %l6, i1 false, i1 true)
  br label %bb22
bb22:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInferThroughBounds(ptr %v0, ptr %s0, ptr %t102, ptr %l6)
  br label %bb23
bb23:
  %t105 = getelementptr %"compiler/generic:Binding", ptr %l6, i32 0, i32 2
  %t106 = load { i64, ptr }, ptr %t105, !tbaa !27
  store { i64, ptr } %t106, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t108 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t108, 0
  store i64 %t110, ptr %l9, !tbaa !24
  br label %bb24
bb24:
  %t112 = load i64, ptr %l8, !tbaa !24
  %t113 = load i64, ptr %l9, !tbaa !24
  %t116 = icmp slt i64 %t112, %t113
  %t118 = xor i1 %t116, true
  br i1 %t118, label %bb25, label %bb26
bb25:
  br label %bb32
bb26:
  br label %bb27
bb27:
  %t120 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t120, ptr %l67, !tbaa !27
  %t121 = load i64, ptr %l8, !tbaa !24
  %t123 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = getelementptr i32, ptr %t124, i64 %t121
  %t126 = load i32, ptr %t125, !tbaa !33
  %t129 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t132 = icmp eq i32 %t126, %t129
  br i1 %t132, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t135 = load i64, ptr %l8, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l8, !tbaa !24
  br label %bb24
bb32:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/check:Checker", ptr %t139, i32 0, i32 20
  store ptr %t141, ptr %l78, !tbaa !29
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/check:Checker", ptr %t142, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !29
  store ptr %t145, ptr %l80, !tbaa !29
  %t146 = load i64, ptr %l1, !tbaa !24
  store i64 %t146, ptr %l81, !tbaa !24
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/check:Checker", ptr %t147, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t152 = getelementptr %"compiler/generic:Program", ptr %t150, i32 0, i32 2
  %t153 = getelementptr %"compiler/generic:Binding", ptr %l6, i32 0, i32 2
  %t154 = load { i64, ptr }, ptr %t153, !tbaa !27
  %t157 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t152, { i64, ptr } %t154)
  store i32 %t157, ptr %l86
  br label %bb33
bb33:
  %t158 = load ptr, ptr %l80, !tbaa !29
  %t159 = load i64, ptr %l81, !tbaa !24
  %t160 = load i32, ptr %l86, !tbaa !23
  %t161 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %t158, i64 %t159, i32 %t160)
  store i64 %t161, ptr %l87
  br label %bb34
bb34:
  %t162 = load ptr, ptr %l78, !tbaa !29
  %t163 = load i64, ptr %l87, !tbaa !24
  %t164 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t162, i64 %t163)
  %t165 = extractvalue { i32, i64 } %t164, 1
  %t166 = extractvalue { i32, i64 } %t164, 0
  store i32 %t166, ptr %l89
  %t167 = icmp ne i32 %t166, 0
  br i1 %t167, label %bb36, label %ok.168, !prof !99
ok.168:
  store i64 %t165, ptr %l88
  br label %bb35
bb35:
  %t169 = load i64, ptr %l88, !tbaa !24
  store i64 %t169, ptr %l76, !tbaa !24
  br label %bb38
bb36:
  br label %bb37
bb37:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l76, !tbaa !24
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s0)
  %t170 = load i64, ptr %l76, !tbaa !24
  store i64 %t170, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyOfCallee(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 5}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i32 }, ptr %t12, i32 0, i32 0
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l2, !tbaa !23
  %t18 = sext i32 %t16 to i64
  store i64 %t18, ptr %l3, !tbaa !24
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_5f37bbd32b93a1e_9b7778ec6ef06ea)
  unreachable
bb11:
  %t20 = load i64, ptr %l3, !tbaa !24
  store i64 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebreakUnless(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l4 = alloca i64
  %lp5 = alloca ptr
  %l8 = alloca i64
  %l19 = alloca ptr
  %l23 = alloca i32
  %l27 = alloca { i64, ptr }
  %l28 = alloca %"compiler/typed:Block"
  %l29 = alloca %"compiler/source:Span"
  %l33 = alloca ptr
  %l35 = alloca %"compiler/typed:If"
  %rv = alloca ptr
  %t15 = alloca { i64, [3 x i64] }, align 8
  %t66 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 37
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 37
  %t10 = load %"compiler/source:Span", ptr %l1
  %t13 = trunc i64 %a3 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t15
  %t16 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 0
  store i64 5, ptr %t16
  %t18 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t10, 0
  %t20 = insertvalue { %"compiler/source:Span", i32, i32 } %t18, i32 0, 1
  %t22 = insertvalue { %"compiler/source:Span", i32, i32 } %t20, i32 %t13, 2
  %t23 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t22, ptr %t23
  %t24 = load { i64, [3 x i64] }, ptr %t15
  %t26 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t24, ptr %t26
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t9, ptr %t26)
  br label %bb2
bb2:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t29)
  store ptr %t31, ptr %l19
  br label %bb3
bb3:
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t34 = getelementptr %"compiler/check:frame", ptr %t32, i32 0, i32 7
  %t35 = load i64, ptr %t34, !tbaa !24
  %t37 = trunc i64 %t35 to i32
  store i32 %t37, ptr %l23, !tbaa !23
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 37
  %t42 = load i64, ptr %l4, !tbaa !24
  %t45 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t41, i64 %t42)
  store { i64, ptr } %t45, ptr %l27
  br label %bb4
bb4:
  %t46 = load i32, ptr %l23, !tbaa !23
  %t47 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t48 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v2, i32 %t46, { i64, ptr } %t47)
  store %"compiler/typed:Block" %t48, ptr %l28
  br label %bb5
bb5:
  %t49 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store ptr %t49, ptr %lp5
  %t50 = load %"compiler/typed:Block", ptr %l28
  %t51 = load ptr, ptr %lp5
  store %"compiler/typed:Block" %t50, ptr %t51
  %t52 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t52, ptr %l29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load %"compiler/source:Span", ptr %l1
  %t59 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v1, ptr %v0, ptr %t53, %"compiler/source:Span" %t54, ptr %a2)
  store ptr %t59, ptr %l33
  br label %bb6
bb6:
  %t60 = load ptr, ptr %lp5
  %t61 = load ptr, ptr %l33, !tbaa !29
  %t63 = call %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v0, ptr %v2, ptr %v2, ptr %v2, ptr %t61, ptr %t60, ptr null)
  store %"compiler/typed:If" %t63, ptr %l35
  br label %bb7
bb7:
  %t64 = load %"compiler/typed:If", ptr %l35
  %t65 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store %"compiler/typed:If" %t64, ptr %t65
  store { i64, [3 x i64] } zeroinitializer, ptr %t66
  %t67 = getelementptr { i64, [3 x i64] }, ptr %t66, i32 0, i32 0
  store i64 3, ptr %t67
  %t68 = load %"compiler/source:Span", ptr %l29
  %t69 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t68, 0
  %t71 = insertvalue { %"compiler/source:Span", ptr } %t69, ptr %t65, 1
  %t72 = getelementptr { i64, [3 x i64] }, ptr %t66, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t71, ptr %t72
  %t73 = load { i64, [3 x i64] }, ptr %t66
  %t75 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store { i64, [3 x i64] } %t73, ptr %t75
  store ptr %t75, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuiltinType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l7 = alloca i1
  %l10 = alloca i1
  %l16 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t1, i32 %a1)
  store { i64, ptr } %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t7, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store i1 %t9, ptr %l7
  br label %bb2
bb2:
  %t10 = load i1, ptr %l7, !tbaa !21
  br i1 %t10, label %bb3, label %bb4
bb3:
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t11, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t15 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t13, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i1 %t15, ptr %l10
  br label %bb6
bb6:
  %t16 = load i1, ptr %l10, !tbaa !21
  br i1 %t16, label %bb7, label %bb8
bb7:
  %t17 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t17, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 2
  %t25 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v0, ptr %t24, { i64, ptr } %t25)
  store i32 %t28, ptr %l16
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load i32, ptr %l16, !tbaa !23
  store i32 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallOfBody(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3, { i64, ptr } %a4, i1 %a5) #0 {
entry:
  %l1 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l17 = alloca i32
  %l19 = alloca %"compiler/typed:Call"
  %rv = alloca ptr
  %t7 = alloca { i64, [3 x i64] }, align 8
  %t30 = alloca { i64, [5 x i64] }, align 8
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1, ptr %l6
  store i32 %a2, ptr %l7, !tbaa !23
  %t5 = trunc i64 %a3 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t7
  %t8 = getelementptr { i64, [3 x i64] }, ptr %t7, i32 0, i32 0
  store i64 0, ptr %t8
  %t10 = insertvalue { i32 } undef, i32 %t5, 0
  %t11 = getelementptr { i64, [3 x i64] }, ptr %t7, i32 0, i32 1
  store { i32 } %t10, ptr %t11
  %t12 = load { i64, [3 x i64] }, ptr %t7
  %t14 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store { i64, [3 x i64] } %t12, ptr %t14
  store ptr %t14, ptr %l12, !tbaa !29
  store { i64, ptr } %a4, ptr %l13, !tbaa !27
  %t17 = load %"compiler/source:Span", ptr %l1
  %t21 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 0, %"compiler/source:Span" %t17)
  store i32 %t21, ptr %l17
  br label %bb1
bb1:
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t25 = load i32, ptr %l17, !tbaa !23
  %t27 = call %"compiler/typed:Call" @compiler_2ftyped_3aCall_2ector(ptr %v2, ptr %v1, ptr %v2, ptr %t23, { i64, ptr } %t24, i32 %t25, i1 %a5, i1 false)
  store %"compiler/typed:Call" %t27, ptr %l19
  br label %bb2
bb2:
  %t28 = load %"compiler/typed:Call", ptr %l19
  %t29 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"compiler/typed:Call" %t28, ptr %t29
  store { i64, [5 x i64] } zeroinitializer, ptr %t30
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t30, i32 0, i32 0
  store i64 6, ptr %t31
  %t32 = load %"compiler/source:Span", ptr %l6
  %t33 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t32, 0
  %t34 = load i32, ptr %l7, !tbaa !23
  %t35 = insertvalue { %"compiler/source:Span", i32, ptr } %t33, i32 %t34, 1
  %t37 = insertvalue { %"compiler/source:Span", i32, ptr } %t35, ptr %t29, 2
  %t38 = getelementptr { i64, [5 x i64] }, ptr %t30, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t37, ptr %t38
  %t39 = load { i64, [5 x i64] }, ptr %t30
  %t41 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t39, ptr %t41
  store ptr %t41, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallbackType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i32
  %l11 = alloca i32
  %l15 = alloca i1
  %l18 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l48 = alloca i1
  %l49 = alloca i1
  %l52 = alloca i1
  %l53 = alloca i1
  %l54 = alloca ptr
  %l59 = alloca i32
  %l60 = alloca i1
  %l69 = alloca i32
  %l73 = alloca i1
  %l76 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l11
  br label %bb1
bb1:
  %t11 = load i32, ptr %l11, !range !{i32 0, i32 33}
  %t13 = trunc i64 21 to i32
  %t14 = icmp eq i32 %t11, %t13
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb6
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 2
  store ptr %t23, ptr %l18, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t30 = load i32, ptr %l1, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l23
  br label %bb4
bb4:
  %t34 = load ptr, ptr %l18, !tbaa !29
  %t35 = load i32, ptr %l23, !tbaa !23
  %t36 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t34, i32 %t35)
  store { i64, ptr } %t36, ptr %l24
  br label %bb5
bb5:
  %t37 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  %t40 = icmp sgt i64 %t38, 0
  store i1 %t40, ptr %l15, !tbaa !21
  br label %bb6
bb6:
  %t42 = load i1, ptr %l15, !tbaa !21
  br i1 %t42, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  store ptr %t49, ptr %l30, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %l1, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t59, ptr %l35
  br label %bb10
bb10:
  %t60 = load ptr, ptr %l30, !tbaa !29
  %t61 = load i32, ptr %l35, !tbaa !23
  %t62 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t60, i32 %t61)
  store { i64, ptr } %t62, ptr %l36
  br label %bb11
bb11:
  %t63 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t63, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t64, 0
  store i64 %t66, ptr %l4, !tbaa !24
  br label %bb12
bb12:
  %t68 = load i64, ptr %l3, !tbaa !24
  %t69 = load i64, ptr %l4, !tbaa !24
  %t72 = icmp slt i64 %t68, %t69
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb13, label %bb14
bb13:
  br label %bb30
bb14:
  br label %bb15
bb15:
  %t76 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t76, ptr %l43, !tbaa !27
  %t77 = load i64, ptr %l3, !tbaa !24
  %t79 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr i32, ptr %t80, i64 %t77
  %t82 = load i32, ptr %t81, !tbaa !33
  store i32 %t82, ptr %l5, !tbaa !23
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i32, ptr %l5, !tbaa !23
  %t88 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %t84, i32 %t85)
  store i1 %t88, ptr %l48
  br label %bb16
bb16:
  %t89 = load i1, ptr %l48, !tbaa !21
  br i1 %t89, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb25
bb18:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i32, ptr %l5, !tbaa !23
  %t94 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t90, i32 %t91)
  store i1 %t94, ptr %l52
  br label %bb19
bb19:
  %t95 = load i1, ptr %l52, !tbaa !21
  br i1 %t95, label %bb20, label %bb21
bb20:
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l54, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  %t103 = load i32, ptr %l5, !tbaa !23
  %t106 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t102, i32 %t103)
  store i32 %t106, ptr %l59
  br label %bb22
bb21:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb24
bb22:
  %t107 = load ptr, ptr %l54, !tbaa !29
  %t108 = load i32, ptr %l59, !tbaa !23
  %t109 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainStruct(ptr %v0, ptr %t107, i32 %t108, i64 0)
  store i1 %t109, ptr %l60
  br label %bb23
bb23:
  %t110 = load i1, ptr %l60, !tbaa !21
  store i1 %t110, ptr %l53, !tbaa !21
  br label %bb24
bb24:
  %t111 = load i1, ptr %l53, !tbaa !21
  store i1 %t111, ptr %l49, !tbaa !21
  br label %bb25
bb25:
  %t112 = load i1, ptr %l49, !tbaa !21
  %t113 = xor i1 %t112, true
  br i1 %t113, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t116 = load i64, ptr %l3, !tbaa !24
  %t118 = add i64 %t116, 1
  store i64 %t118, ptr %l3, !tbaa !24
  br label %bb12
bb30:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/check:Checker", ptr %t120, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = getelementptr %"compiler/generic:Program", ptr %t123, i32 0, i32 2
  %t126 = load i32, ptr %l1, !tbaa !23
  %t129 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t125, i32 %t126)
  store i32 %t129, ptr %l69
  br label %bb31
bb31:
  %t130 = load i32, ptr %l69, !tbaa !23
  store i32 %t130, ptr %l6, !tbaa !23
  %t131 = load i32, ptr %l6, !tbaa !23
  %t132 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t135 = icmp eq i32 %t131, %t132
  br i1 %t135, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb35
bb33:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load i32, ptr %l6, !tbaa !23
  %t141 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %t137, i32 %t138)
  store i1 %t141, ptr %l76
  br label %bb34
bb34:
  %t142 = load i1, ptr %l76, !tbaa !21
  store i1 %t142, ptr %l73, !tbaa !21
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s0)
  %t143 = load i1, ptr %l73, !tbaa !21
  store i1 %t143, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecasePublic(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l9 = alloca i1
  %l10 = alloca i1
  %l13 = alloca i64
  %l15 = alloca i1
  %l18 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i64
  %l26 = alloca ptr
  %l33 = alloca ptr
  %l36 = alloca { i64, [3 x i64] }
  %l39 = alloca { i64, ptr }
  %l41 = alloca %"compiler/diagmsg:Msg"
  %l42 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s0, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t6, ptr %l7, !tbaa !27
  %t7 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr i8, ptr %t8, i64 0
  %t10 = load i8, ptr %t9, !tbaa !32
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t10)
  store i1 %t12, ptr %l9
  br label %bb2
bb2:
  %t13 = load i1, ptr %l9, !tbaa !21
  br i1 %t13, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb6
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 16
  %t18 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l13
  br label %bb5
bb5:
  %t19 = load i64, ptr %l13, !tbaa !24
  %t20 = icmp eq i64 %t19, 0
  store i1 %t20, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t22 = load i1, ptr %l10, !tbaa !21
  br i1 %t22, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb12
bb8:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  store ptr %t28, ptr %l18, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t34, i32 %a1)
  store i32 %t38, ptr %l23
  br label %bb9
bb9:
  %t39 = load ptr, ptr %l18, !tbaa !29
  %t40 = load i32, ptr %l23, !tbaa !23
  %t41 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t39, i32 %t40)
  store i64 %t41, ptr %l24
  br label %bb10
bb10:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t42)
  store ptr %t44, ptr %l26
  br label %bb11
bb11:
  %t45 = load ptr, ptr %l26, !tbaa !29
  %t47 = getelementptr %"compiler/check:frame", ptr %t45, i32 0, i32 1
  %t48 = load i64, ptr %t47, !tbaa !24
  %t49 = load i64, ptr %l24, !tbaa !24
  %t51 = icmp eq i64 %t49, %t48
  store i1 %t51, ptr %l15, !tbaa !21
  br label %bb12
bb12:
  %t53 = load i1, ptr %l15, !tbaa !21
  br i1 %t53, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  br label %bb15
bb15:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/generic:Program", ptr %t57, i32 0, i32 0
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/load:Loader", ptr %t60, i32 0, i32 4
  %t63 = load ptr, ptr %t62, !tbaa !29
  store ptr %t63, ptr %l33, !tbaa !29
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t68 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t64, %"compiler/source:Span" %a3)
  store { i64, [3 x i64] } %t68, ptr %l36
  br label %bb16
bb16:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i32, ptr %l2, !tbaa !23
  %t73 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s0, ptr %t69, i32 %t70)
  store { i64, ptr } %t73, ptr %l39
  br label %bb17
bb17:
  %t74 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t74, 0
  %t76 = extractvalue { i64, ptr } %t74, 1
  %t77 = mul i64 %t75, 1
  %t78 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t77)
  call void @llvm.memcpy.p0.p0.i64(ptr %t78, ptr %t76, i64 %t77, i1 false)
  %t79 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t78, 1
  %t82 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaseIsPrivate(ptr %s0, ptr %s0, { i64, ptr } %t80)
  store %"compiler/diagmsg:Msg" %t82, ptr %l41
  br label %bb18
bb18:
  %t83 = load ptr, ptr %l33, !tbaa !29
  %t84 = load { i64, [3 x i64] }, ptr %l36
  %t85 = load %"compiler/diagmsg:Msg", ptr %l41
  %t86 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %s0, ptr %t83, { i64, [3 x i64] } %t84, %"compiler/diagmsg:Msg" %t85)
  store i64 %t86, ptr %l42
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l9 = alloca i1
  %l14 = alloca i32
  %l17 = alloca i1
  %l20 = alloca i1
  %l24 = alloca i32
  %l27 = alloca i1
  %l30 = alloca i1
  %l36 = alloca i1
  %l43 = alloca i32
  %l46 = alloca i32
  %l50 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !range !{i32 0, i32 98}
  %t3 = trunc i64 78 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l1, !range !{i32 0, i32 98}
  %t8 = trunc i64 79 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l9, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t16 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrLocalName(ptr %v0, ptr %v1, ptr %t12, ptr %t13)
  store i32 %t16, ptr %l14
  br label %bb6
bb5:
  br label %bb22
bb6:
  %t17 = load i32, ptr %l14, !tbaa !23
  store i32 %t17, ptr %l4, !tbaa !23
  %t18 = load i32, ptr %l4, !tbaa !23
  %t20 = icmp ne i32 %t18, 0
  br i1 %t20, label %bb7, label %bb8
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t26 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrItemPath(ptr %v0, ptr %v2, ptr %t22, ptr %t23)
  store i1 %t26, ptr %l20
  br label %bb9
bb8:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb10
bb9:
  %t27 = load i1, ptr %l20, !tbaa !21
  store i1 %t27, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t28 = load i1, ptr %l17, !tbaa !21
  br i1 %t28, label %bb11, label %bb12
bb11:
  %t29 = load i32, ptr %l4, !tbaa !23
  store i32 %t29, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l3, !tbaa !29
  %t35 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrLocalName(ptr %v0, ptr %v2, ptr %t31, ptr %t32)
  store i32 %t35, ptr %l24
  br label %bb14
bb14:
  %t36 = load i32, ptr %l24, !tbaa !23
  store i32 %t36, ptr %l5, !tbaa !23
  %t37 = load i32, ptr %l5, !tbaa !23
  %t39 = icmp ne i32 %t37, 0
  br i1 %t39, label %bb15, label %bb16
bb15:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load ptr, ptr %l2, !tbaa !29
  %t45 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrItemPath(ptr %v0, ptr %v1, ptr %t41, ptr %t42)
  store i1 %t45, ptr %l30
  br label %bb17
bb16:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb18
bb17:
  %t46 = load i1, ptr %l30, !tbaa !21
  store i1 %t46, ptr %l27, !tbaa !21
  br label %bb18
bb18:
  %t47 = load i1, ptr %l27, !tbaa !21
  br i1 %t47, label %bb19, label %bb20
bb19:
  %t48 = load i32, ptr %l5, !tbaa !23
  store i32 %t48, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  store i32 0, ptr %rv
  br label %ret
bb22:
  %t51 = load i32, ptr %l1, !range !{i32 0, i32 98}
  %t53 = trunc i64 45 to i32
  %t54 = icmp eq i32 %t51, %t53
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb23, label %bb24
bb23:
  %t58 = load i32, ptr %l1, !range !{i32 0, i32 98}
  %t60 = trunc i64 46 to i32
  %t61 = icmp eq i32 %t58, %t60
  %t63 = xor i1 %t61, true
  store i1 %t63, ptr %l36, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb25
bb25:
  %t65 = load i1, ptr %l36, !tbaa !21
  br i1 %t65, label %bb26, label %bb27
bb26:
  store i32 0, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l2, !tbaa !29
  %t71 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtIn(ptr %v0, ptr %v1, ptr %t67, ptr %t68)
  store i32 %t71, ptr %l43
  br label %bb29
bb29:
  %t72 = load i32, ptr %l43, !tbaa !23
  store i32 %t72, ptr %l6, !tbaa !23
  %t73 = load i32, ptr %l6, !tbaa !23
  %t75 = icmp ne i32 %t73, 0
  br i1 %t75, label %bb30, label %bb31
bb30:
  %t77 = load i32, ptr %l6, !tbaa !23
  store i32 %t77, ptr %l46, !tbaa !23
  br label %bb33
bb31:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load ptr, ptr %l3, !tbaa !29
  %t83 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtIn(ptr %v0, ptr %v2, ptr %t79, ptr %t80)
  store i32 %t83, ptr %l50
  br label %bb32
bb32:
  %t84 = load i32, ptr %l50, !tbaa !23
  store i32 %t84, ptr %l46, !tbaa !23
  br label %bb33
bb33:
  %t85 = load i32, ptr %l46, !tbaa !23
  store i32 %t85, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echain(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %lp5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i32
  %l34 = alloca i32
  %l35 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i64
  %l38 = alloca ptr
  %l41 = alloca i64
  %l45 = alloca i64
  %l52 = alloca i64
  %l55 = alloca i64
  %l73 = alloca i64
  %l76 = alloca { i64, ptr }
  %l80 = alloca %"compiler/check:litv"
  %l84 = alloca i64
  %l91 = alloca i64
  %l94 = alloca i64
  %l112 = alloca i64
  %l115 = alloca { i64, ptr }
  %l118 = alloca i1
  %l122 = alloca ptr
  %l125 = alloca ptr
  %l127 = alloca ptr
  %l128 = alloca ptr
  %l131 = alloca { i64, ptr }
  %l136 = alloca ptr
  %l138 = alloca { i64, ptr }
  %l141 = alloca %"compiler/source:Span"
  %l142 = alloca ptr
  %l149 = alloca i64
  %l152 = alloca i64
  %l173 = alloca i1
  %l180 = alloca i64
  %l183 = alloca i64
  %l205 = alloca i1
  %l219 = alloca i1
  %l231 = alloca { i64, ptr }
  %l237 = alloca ptr
  %l240 = alloca i64
  %l241 = alloca ptr
  %l246 = alloca ptr
  %l248 = alloca %"compiler/source:Span"
  %l249 = alloca ptr
  %l255 = alloca ptr
  %l257 = alloca i32
  %l260 = alloca i1
  %l261 = alloca i32
  %l264 = alloca i32
  %l269 = alloca i1
  %l270 = alloca ptr
  %l271 = alloca ptr
  %l273 = alloca ptr
  %l275 = alloca i32
  %l278 = alloca ptr
  %l280 = alloca %"compiler/source:Span"
  %l281 = alloca ptr
  %l285 = alloca i64
  %l290 = alloca ptr
  %l291 = alloca ptr
  %l293 = alloca { i64, ptr }
  %l296 = alloca %"compiler/source:Span"
  %l298 = alloca { i64, ptr }
  %l302 = alloca %"compiler/source:Span"
  %l304 = alloca { i64, ptr }
  %l307 = alloca { i64, ptr }
  %l309 = alloca %"compiler/source:Span"
  %l310 = alloca i32
  %l313 = alloca i32
  %l314 = alloca i1
  %l323 = alloca ptr
  %l324 = alloca %"compiler/source:Span"
  %l325 = alloca ptr
  %l326 = alloca i64
  %l327 = alloca { i64, ptr }
  %l329 = alloca ptr
  %l333 = alloca ptr
  %l335 = alloca ptr
  %s0 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 36
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l41
  br label %bb1
bb1:
  %t6 = load i64, ptr %l41, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"compiler/ast:Chain", ptr %t7, i32 0, i32 1
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  store i64 %t14, ptr %l45, !tbaa !24
  %t15 = load i64, ptr %l45, !tbaa !24
  %t16 = icmp sge i64 %t15, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load i64, ptr %l45, !tbaa !24
  %t19 = mul i64 %t18, 1
  %t20 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t23 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t23, ptr %lp5
  %t25 = load ptr, ptr %lp5
  store { i64, ptr } %t22, ptr %t25, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  store i64 %t26, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t28 = load i64, ptr %l7, !tbaa !24
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = icmp sgt i64 %t28, %t29
  br i1 %t32, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_514ceade83978a4d_1843f44cd2570191)
  unreachable
bb4:
  %t34 = load i64, ptr %l8, !tbaa !24
  %t36 = icmp sgt i64 %t34, 0
  br i1 %t36, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb9
bb6:
  %t38 = load i64, ptr %l7, !tbaa !24
  %t39 = load i64, ptr %l6, !tbaa !24
  %t42 = sub i64 %t38, %t39
  %t43 = load i64, ptr %l8, !tbaa !24
  %t46 = add i64 %t42, %t43
  %t48 = sub i64 %t46, 1
  %t49 = load i64, ptr %l8, !tbaa !24
  %t52 = sdiv i64 %t48, %t49
  store i64 %t52, ptr %l55, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb8
bb8:
  %t54 = load i64, ptr %l55, !tbaa !24
  store i64 %t54, ptr %l52, !tbaa !24
  br label %bb9
bb9:
  %t55 = load i64, ptr %l52, !tbaa !24
  store i64 %t55, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb10
bb10:
  %t56 = load i64, ptr %l10, !tbaa !24
  %t57 = load i64, ptr %l9, !tbaa !24
  %t60 = icmp slt i64 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb11, label %bb12
bb11:
  br label %bb16
bb12:
  br label %bb13
bb13:
  %t64 = load i64, ptr %l6, !tbaa !24
  %t65 = load i64, ptr %l10, !tbaa !24
  %t66 = load i64, ptr %l8, !tbaa !24
  %t69 = mul i64 %t65, %t66
  %t72 = add i64 %t64, %t69
  store i64 %t72, ptr %l11, !tbaa !24
  %t74 = load i64, ptr %l11, !tbaa !24
  store i64 %t74, ptr %l73, !tbaa !24
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load ptr, ptr %l2, !tbaa !29
  %t78 = getelementptr %"compiler/ast:Chain", ptr %t76, i32 0, i32 1
  %t79 = load { i64, ptr }, ptr %t78, !tbaa !27
  store { i64, ptr } %t79, ptr %l76, !tbaa !27
  %t80 = load i64, ptr %l11, !tbaa !24
  %t82 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr ptr, ptr %t83, i64 %t80
  %t85 = load ptr, ptr %t84, !tbaa !39
  %t89 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t75, ptr %t85)
  store %"compiler/check:litv" %t89, ptr %l80
  br label %bb14
bb14:
  %t90 = getelementptr %"compiler/check:litv", ptr %l80, i32 0, i32 0
  %t91 = load i1, ptr %t90, !tbaa !21
  %t93 = load ptr, ptr %lp5
  %t94 = load i64, ptr %l73, !tbaa !24
  %t95 = getelementptr { i64, ptr }, ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr i1, ptr %t96, i64 %t94
  store i1 %t91, ptr %t97, !tbaa !31
  br label %bb15
bb15:
  %t98 = load i64, ptr %l10, !tbaa !24
  %t100 = add i64 %t98, 1
  store i64 %t100, ptr %l10, !tbaa !24
  br label %bb10
bb16:
  %t102 = load i64, ptr %l4, !tbaa !24
  store i64 %t102, ptr %l84, !tbaa !24
  %t103 = load i64, ptr %l84, !tbaa !24
  %t104 = icmp sge i64 %t103, 0
  br i1 %t104, label %bb17, label %bb18
bb17:
  %t106 = load i64, ptr %l84, !tbaa !24
  %t107 = mul i64 %t106, 1
  %t108 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t107)
  %t109 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  store { i64, ptr } %t110, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t112 = load i64, ptr %l4, !tbaa !24
  store i64 %t112, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t114 = load i64, ptr %l14, !tbaa !24
  %t115 = load i64, ptr %l13, !tbaa !24
  %t118 = icmp sgt i64 %t114, %t115
  br i1 %t118, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_8bbd92ac148fb220_5a9ba8c1b178084)
  unreachable
bb19:
  %t120 = load i64, ptr %l15, !tbaa !24
  %t122 = icmp sgt i64 %t120, 0
  br i1 %t122, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l91, !tbaa !24
  br label %bb24
bb21:
  %t124 = load i64, ptr %l14, !tbaa !24
  %t125 = load i64, ptr %l13, !tbaa !24
  %t128 = sub i64 %t124, %t125
  %t129 = load i64, ptr %l15, !tbaa !24
  %t132 = add i64 %t128, %t129
  %t134 = sub i64 %t132, 1
  %t135 = load i64, ptr %l15, !tbaa !24
  %t138 = sdiv i64 %t134, %t135
  store i64 %t138, ptr %l94, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l94, !tbaa !24
  br label %bb23
bb23:
  %t140 = load i64, ptr %l94, !tbaa !24
  store i64 %t140, ptr %l91, !tbaa !24
  br label %bb24
bb24:
  %t141 = load i64, ptr %l91, !tbaa !24
  store i64 %t141, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb25
bb25:
  %t142 = load i64, ptr %l17, !tbaa !24
  %t143 = load i64, ptr %l16, !tbaa !24
  %t146 = icmp slt i64 %t142, %t143
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb26, label %bb27
bb26:
  br label %bb40
bb27:
  br label %bb28
bb28:
  %t150 = load i64, ptr %l13, !tbaa !24
  %t151 = load i64, ptr %l17, !tbaa !24
  %t152 = load i64, ptr %l15, !tbaa !24
  %t155 = mul i64 %t151, %t152
  %t158 = add i64 %t150, %t155
  store i64 %t158, ptr %l18, !tbaa !24
  %t160 = load i64, ptr %l18, !tbaa !24
  store i64 %t160, ptr %l112, !tbaa !24
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load ptr, ptr %l2, !tbaa !29
  %t164 = getelementptr %"compiler/ast:Chain", ptr %t162, i32 0, i32 1
  %t165 = load { i64, ptr }, ptr %t164, !tbaa !27
  store { i64, ptr } %t165, ptr %l115, !tbaa !27
  %t166 = load i64, ptr %l18, !tbaa !24
  %t168 = getelementptr { i64, ptr }, ptr %l115, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = getelementptr ptr, ptr %t169, i64 %t166
  %t171 = load ptr, ptr %t170, !tbaa !39
  %t174 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t161, ptr %t171)
  store i1 %t174, ptr %l118
  br label %bb29
bb29:
  %t175 = load i1, ptr %l118, !tbaa !21
  %t176 = load i64, ptr %l112, !tbaa !24
  %t177 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = getelementptr i1, ptr %t178, i64 %t176
  store i1 %t175, ptr %t179, !tbaa !31
  %t180 = load i64, ptr %l18, !tbaa !24
  %t182 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !27
  %t184 = getelementptr i1, ptr %t183, i64 %t180
  %t185 = load i1, ptr %t184, !tbaa !31
  br i1 %t185, label %bb30, label %bb31
bb30:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/check:Checker", ptr %t187, i32 0, i32 36
  store ptr %t189, ptr %l122, !tbaa !29
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load %"compiler/source:Span", ptr %l1
  %t194 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehole(ptr %v0, ptr %v0, ptr %t190, %"compiler/source:Span" %t191)
  store ptr %t194, ptr %l125
  br label %bb32
bb31:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/check:Checker", ptr %t195, i32 0, i32 36
  store ptr %t197, ptr %l127, !tbaa !29
  %t198 = load ptr, ptr %l0, !tbaa !29
  store ptr %t198, ptr %l128, !tbaa !29
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load ptr, ptr %l2, !tbaa !29
  %t202 = getelementptr %"compiler/ast:Chain", ptr %t200, i32 0, i32 1
  %t203 = load { i64, ptr }, ptr %t202, !tbaa !27
  store { i64, ptr } %t203, ptr %l131, !tbaa !27
  %t204 = load i64, ptr %l18, !tbaa !24
  %t206 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !27
  %t208 = getelementptr ptr, ptr %t207, i64 %t204
  %t209 = load ptr, ptr %t208, !tbaa !39
  %t211 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t215 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t199, ptr %t209, i32 %t211)
  store ptr %t215, ptr %l136
  br label %bb34
bb32:
  %t216 = load ptr, ptr %l122, !tbaa !29
  %t217 = load ptr, ptr %l125, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t216, ptr %t217)
  br label %bb33
bb33:
  br label %bb38
bb34:
  %t218 = load ptr, ptr %l2, !tbaa !29
  %t220 = getelementptr %"compiler/ast:Chain", ptr %t218, i32 0, i32 1
  %t221 = load { i64, ptr }, ptr %t220, !tbaa !27
  store { i64, ptr } %t221, ptr %l138, !tbaa !27
  %t222 = load i64, ptr %l18, !tbaa !24
  %t224 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !27
  %t226 = getelementptr ptr, ptr %t225, i64 %t222
  %t227 = load ptr, ptr %t226, !tbaa !39
  %t229 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t227)
  store %"compiler/source:Span" %t229, ptr %l141
  br label %bb35
bb35:
  %t230 = load ptr, ptr %l128, !tbaa !29
  %t231 = load ptr, ptr %l136, !tbaa !29
  %t232 = load %"compiler/source:Span", ptr %l141
  %t233 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v0, ptr %t230, ptr %t231, %"compiler/source:Span" %t232)
  store ptr %t233, ptr %l142
  br label %bb36
bb36:
  %t234 = load ptr, ptr %l127, !tbaa !29
  %t235 = load ptr, ptr %l142, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t234, ptr %t235)
  br label %bb37
bb37:
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t236 = load i64, ptr %l17, !tbaa !24
  %t238 = add i64 %t236, 1
  store i64 %t238, ptr %l17, !tbaa !24
  br label %bb25
bb40:
  store i64 0, ptr %l19, !tbaa !24
  %t240 = load i64, ptr %l4, !tbaa !24
  store i64 %t240, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t242 = load i64, ptr %l20, !tbaa !24
  %t243 = load i64, ptr %l19, !tbaa !24
  %t246 = icmp sgt i64 %t242, %t243
  br i1 %t246, label %bb41, label %bb42
bb41:
  %t248 = load i64, ptr %l21, !tbaa !24
  %t250 = icmp sgt i64 %t248, 0
  br i1 %t250, label %bb43, label %bb44
bb42:
  store i64 0, ptr %l149, !tbaa !24
  br label %bb46
bb43:
  %t252 = load i64, ptr %l20, !tbaa !24
  %t253 = load i64, ptr %l19, !tbaa !24
  %t256 = sub i64 %t252, %t253
  %t257 = load i64, ptr %l21, !tbaa !24
  %t260 = add i64 %t256, %t257
  %t262 = sub i64 %t260, 1
  %t263 = load i64, ptr %l21, !tbaa !24
  %t266 = sdiv i64 %t262, %t263
  store i64 %t266, ptr %l152, !tbaa !24
  br label %bb45
bb44:
  store i64 0, ptr %l152, !tbaa !24
  br label %bb45
bb45:
  %t268 = load i64, ptr %l152, !tbaa !24
  store i64 %t268, ptr %l149, !tbaa !24
  br label %bb46
bb46:
  %t269 = load i64, ptr %l149, !tbaa !24
  store i64 %t269, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb47
bb47:
  store %olang.scope zeroinitializer, ptr %s10
  %t270 = load i64, ptr %l23, !tbaa !24
  %t271 = load i64, ptr %l22, !tbaa !24
  %t274 = icmp slt i64 %t270, %t271
  %t276 = xor i1 %t274, true
  br i1 %t276, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s10)
  br label %bb116
bb49:
  br label %bb50
bb50:
  %t278 = load i64, ptr %l19, !tbaa !24
  %t279 = load i64, ptr %l23, !tbaa !24
  %t280 = load i64, ptr %l21, !tbaa !24
  %t283 = mul i64 %t279, %t280
  %t286 = add i64 %t278, %t283
  store i64 %t286, ptr %l24, !tbaa !24
  %t288 = load i64, ptr %l24, !tbaa !24
  %t290 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t291 = load ptr, ptr %t290, !tbaa !27
  %t292 = getelementptr i1, ptr %t291, i64 %t288
  %t293 = load i1, ptr %t292, !tbaa !31
  %t295 = xor i1 %t293, true
  br i1 %t295, label %bb51, label %bb52
bb51:
  store i1 true, ptr %l173, !tbaa !21
  br label %bb53
bb52:
  %t297 = load i64, ptr %l24, !tbaa !24
  %t298 = load ptr, ptr %lp5
  %t300 = getelementptr { i64, ptr }, ptr %t298, i32 0, i32 1
  %t301 = load ptr, ptr %t300, !tbaa !27
  %t302 = getelementptr i1, ptr %t301, i64 %t297
  %t303 = load i1, ptr %t302, !tbaa !31
  store i1 %t303, ptr %l173, !tbaa !21
  br label %bb53
bb53:
  %t305 = load i1, ptr %l173, !tbaa !21
  br i1 %t305, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s10)
  br label %bb115
bb55:
  br label %bb56
bb56:
  store i64 -1, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t306 = load i64, ptr %l4, !tbaa !24
  store i64 %t306, ptr %l27, !tbaa !24
  store i64 1, ptr %l28, !tbaa !24
  %t308 = load i64, ptr %l27, !tbaa !24
  %t309 = load i64, ptr %l26, !tbaa !24
  %t312 = icmp sgt i64 %t308, %t309
  br i1 %t312, label %bb57, label %bb58
bb57:
  %t314 = load i64, ptr %l28, !tbaa !24
  %t316 = icmp sgt i64 %t314, 0
  br i1 %t316, label %bb59, label %bb60
bb58:
  store i64 0, ptr %l180, !tbaa !24
  br label %bb62
bb59:
  %t318 = load i64, ptr %l27, !tbaa !24
  %t319 = load i64, ptr %l26, !tbaa !24
  %t322 = sub i64 %t318, %t319
  %t323 = load i64, ptr %l28, !tbaa !24
  %t326 = add i64 %t322, %t323
  %t328 = sub i64 %t326, 1
  %t329 = load i64, ptr %l28, !tbaa !24
  %t332 = sdiv i64 %t328, %t329
  store i64 %t332, ptr %l183, !tbaa !24
  br label %bb61
bb60:
  store i64 0, ptr %l183, !tbaa !24
  br label %bb61
bb61:
  %t334 = load i64, ptr %l183, !tbaa !24
  store i64 %t334, ptr %l180, !tbaa !24
  br label %bb62
bb62:
  %t335 = load i64, ptr %l180, !tbaa !24
  store i64 %t335, ptr %l29, !tbaa !24
  store i64 0, ptr %l30, !tbaa !24
  br label %bb63
bb63:
  %t336 = load i64, ptr %l30, !tbaa !24
  %t337 = load i64, ptr %l29, !tbaa !24
  %t340 = icmp slt i64 %t336, %t337
  %t342 = xor i1 %t340, true
  br i1 %t342, label %bb64, label %bb65
bb64:
  br label %bb80
bb65:
  br label %bb66
bb66:
  %t344 = load i64, ptr %l26, !tbaa !24
  %t345 = load i64, ptr %l30, !tbaa !24
  %t346 = load i64, ptr %l28, !tbaa !24
  %t349 = mul i64 %t345, %t346
  %t352 = add i64 %t344, %t349
  store i64 %t352, ptr %l31, !tbaa !24
  %t354 = load i64, ptr %l24, !tbaa !24
  %t355 = load i64, ptr %l31, !tbaa !24
  %t358 = sub i64 %t354, %t355
  %t360 = icmp sge i64 %t358, 0
  br i1 %t360, label %bb67, label %bb68
bb67:
  %t362 = load i64, ptr %l24, !tbaa !24
  %t363 = load i64, ptr %l31, !tbaa !24
  %t366 = sub i64 %t362, %t363
  %t368 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t369 = load ptr, ptr %t368, !tbaa !27
  %t370 = getelementptr i1, ptr %t369, i64 %t366
  %t371 = load i1, ptr %t370, !tbaa !31
  %t373 = xor i1 %t371, true
  store i1 %t373, ptr %l205, !tbaa !21
  br label %bb69
bb68:
  store i1 false, ptr %l205, !tbaa !21
  br label %bb69
bb69:
  %t375 = load i1, ptr %l205, !tbaa !21
  br i1 %t375, label %bb70, label %bb71
bb70:
  %t376 = load i64, ptr %l24, !tbaa !24
  %t377 = load i64, ptr %l31, !tbaa !24
  %t380 = sub i64 %t376, %t377
  store i64 %t380, ptr %l25, !tbaa !24
  br label %bb80
bb71:
  br label %bb72
bb72:
  %t382 = load i64, ptr %l24, !tbaa !24
  %t383 = load i64, ptr %l31, !tbaa !24
  %t386 = add i64 %t382, %t383
  %t387 = load i64, ptr %l4, !tbaa !24
  %t390 = icmp slt i64 %t386, %t387
  br i1 %t390, label %bb73, label %bb74
bb73:
  %t392 = load i64, ptr %l24, !tbaa !24
  %t393 = load i64, ptr %l31, !tbaa !24
  %t396 = add i64 %t392, %t393
  %t398 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t399 = load ptr, ptr %t398, !tbaa !27
  %t400 = getelementptr i1, ptr %t399, i64 %t396
  %t401 = load i1, ptr %t400, !tbaa !31
  %t403 = xor i1 %t401, true
  store i1 %t403, ptr %l219, !tbaa !21
  br label %bb75
bb74:
  store i1 false, ptr %l219, !tbaa !21
  br label %bb75
bb75:
  %t405 = load i1, ptr %l219, !tbaa !21
  br i1 %t405, label %bb76, label %bb77
bb76:
  %t406 = load i64, ptr %l24, !tbaa !24
  %t407 = load i64, ptr %l31, !tbaa !24
  %t410 = add i64 %t406, %t407
  store i64 %t410, ptr %l25, !tbaa !24
  br label %bb80
bb77:
  br label %bb78
bb78:
  br label %bb79
bb79:
  %t412 = load i64, ptr %l30, !tbaa !24
  %t414 = add i64 %t412, 1
  store i64 %t414, ptr %l30, !tbaa !24
  br label %bb63
bb80:
  %t416 = load ptr, ptr %l2, !tbaa !29
  %t418 = getelementptr %"compiler/ast:Chain", ptr %t416, i32 0, i32 1
  %t419 = load { i64, ptr }, ptr %t418, !tbaa !27
  store { i64, ptr } %t419, ptr %l231, !tbaa !27
  %t420 = load i64, ptr %l24, !tbaa !24
  %t422 = getelementptr { i64, ptr }, ptr %l231, i32 0, i32 1
  %t423 = load ptr, ptr %t422, !tbaa !27
  %t424 = getelementptr ptr, ptr %t423, i64 %t420
  %t425 = load ptr, ptr %t424, !tbaa !39
  store ptr %t425, ptr %l32, !tbaa !29
  %t427 = load i64, ptr %l25, !tbaa !24
  %t429 = icmp slt i64 %t427, 0
  br i1 %t429, label %bb81, label %bb82
bb81:
  %t431 = load ptr, ptr %l0, !tbaa !29
  %t433 = getelementptr %"compiler/check:Checker", ptr %t431, i32 0, i32 36
  store ptr %t433, ptr %l237, !tbaa !29
  %t434 = load i64, ptr %l3, !tbaa !24
  %t435 = load i64, ptr %l24, !tbaa !24
  %t438 = add i64 %t434, %t435
  store i64 %t438, ptr %l240, !tbaa !24
  %t439 = load ptr, ptr %l0, !tbaa !29
  store ptr %t439, ptr %l241, !tbaa !29
  %t440 = load ptr, ptr %l0, !tbaa !29
  %t441 = load ptr, ptr %l32, !tbaa !29
  %t443 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t447 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t440, ptr %t441, i32 %t443)
  store ptr %t447, ptr %l246
  br label %bb83
bb82:
  br label %bb87
bb83:
  %t448 = load ptr, ptr %l32, !tbaa !29
  %t450 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t448)
  store %"compiler/source:Span" %t450, ptr %l248
  br label %bb84
bb84:
  %t451 = load ptr, ptr %l241, !tbaa !29
  %t452 = load ptr, ptr %l246, !tbaa !29
  %t453 = load %"compiler/source:Span", ptr %l248
  %t454 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v0, ptr %t451, ptr %t452, %"compiler/source:Span" %t453)
  store ptr %t454, ptr %l249
  br label %bb85
bb85:
  %t455 = load ptr, ptr %l237, !tbaa !29
  %t456 = load i64, ptr %l240, !tbaa !24
  %t457 = load ptr, ptr %l249, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eSetAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t455, i64 %t456, ptr %t457)
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s10)
  br label %bb115
bb87:
  %t458 = load ptr, ptr %l0, !tbaa !29
  %t460 = getelementptr %"compiler/check:Checker", ptr %t458, i32 0, i32 36
  %t461 = load i64, ptr %l3, !tbaa !24
  %t462 = load i64, ptr %l25, !tbaa !24
  %t465 = add i64 %t461, %t462
  %t468 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %s10, ptr %t460, i64 %t465)
  store ptr %t468, ptr %l255
  br label %bb88
bb88:
  %t469 = load ptr, ptr %l255, !tbaa !29
  %t471 = call i32 @compiler_2fcheck_2etypeOf(ptr %s10, ptr %t469)
  store i32 %t471, ptr %l257
  br label %bb89
bb89:
  %t472 = load i32, ptr %l257, !tbaa !23
  store i32 %t472, ptr %l33, !tbaa !23
  %t473 = load ptr, ptr %l0, !tbaa !29
  %t474 = load i32, ptr %l33, !tbaa !23
  %t477 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t473, i32 %t474)
  store i1 %t477, ptr %l260
  br label %bb90
bb90:
  %t478 = load i1, ptr %l260, !tbaa !21
  br i1 %t478, label %bb91, label %bb92
bb91:
  %t479 = load ptr, ptr %l0, !tbaa !29
  %t480 = load i32, ptr %l33, !tbaa !23
  %t483 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %t479, i32 %t480)
  store i32 %t483, ptr %l264
  br label %bb93
bb92:
  %t484 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t484, ptr %l261, !tbaa !23
  br label %bb94
bb93:
  %t486 = load i32, ptr %l264, !tbaa !23
  store i32 %t486, ptr %l261, !tbaa !23
  br label %bb94
bb94:
  %t487 = load i32, ptr %l261, !tbaa !23
  store i32 %t487, ptr %l34, !tbaa !23
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t489 = load ptr, ptr %l32, !tbaa !29
  %t490 = load i32, ptr %l34, !tbaa !23
  %t494 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLikeFits(ptr %v0, ptr %v1, ptr %t488, ptr %t489, i32 %t490)
  store i1 %t494, ptr %l269
  br label %bb95
bb95:
  %t495 = load i1, ptr %l269, !tbaa !21
  store i1 %t495, ptr %l35, !tbaa !21
  %t496 = load ptr, ptr %l0, !tbaa !29
  store ptr %t496, ptr %l270, !tbaa !29
  %t497 = load ptr, ptr %l0, !tbaa !29
  store ptr %t497, ptr %l271, !tbaa !29
  %t498 = load ptr, ptr %l32, !tbaa !29
  store ptr %t498, ptr %l273, !tbaa !29
  %t500 = load i1, ptr %l35, !tbaa !21
  br i1 %t500, label %bb96, label %bb97
bb96:
  %t502 = load i32, ptr %l34, !tbaa !23
  store i32 %t502, ptr %l275, !tbaa !23
  br label %bb98
bb97:
  %t504 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t504, ptr %l275, !tbaa !23
  br label %bb98
bb98:
  %t506 = load ptr, ptr %l271, !tbaa !29
  %t507 = load ptr, ptr %l273, !tbaa !29
  %t508 = load i32, ptr %l275, !tbaa !23
  %t509 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t506, ptr %t507, i32 %t508)
  store ptr %t509, ptr %l278
  br label %bb99
bb99:
  %t510 = load ptr, ptr %l32, !tbaa !29
  %t512 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t510)
  store %"compiler/source:Span" %t512, ptr %l280
  br label %bb100
bb100:
  %t513 = load ptr, ptr %l270, !tbaa !29
  %t514 = load ptr, ptr %l278, !tbaa !29
  %t515 = load %"compiler/source:Span", ptr %l280
  %t516 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v0, ptr %t513, ptr %t514, %"compiler/source:Span" %t515)
  store ptr %t516, ptr %l281
  br label %bb101
bb101:
  %t517 = load ptr, ptr %l281, !tbaa !29
  store ptr %t517, ptr %l36, !tbaa !29
  %t518 = load i64, ptr %l24, !tbaa !24
  %t519 = load i64, ptr %l25, !tbaa !24
  %t522 = icmp slt i64 %t518, %t519
  br i1 %t522, label %bb102, label %bb103
bb102:
  %t524 = load i64, ptr %l24, !tbaa !24
  store i64 %t524, ptr %l285, !tbaa !24
  br label %bb104
bb103:
  %t526 = load i64, ptr %l25, !tbaa !24
  store i64 %t526, ptr %l285, !tbaa !24
  br label %bb104
bb104:
  %t528 = load i64, ptr %l285, !tbaa !24
  store i64 %t528, ptr %l37, !tbaa !24
  %t529 = load i1, ptr %l35, !tbaa !21
  %t531 = xor i1 %t529, true
  br i1 %t531, label %bb105, label %bb106
bb105:
  store %olang.scope zeroinitializer, ptr %s18
  %t533 = load ptr, ptr %l0, !tbaa !29
  store ptr %t533, ptr %l290, !tbaa !29
  %t534 = load ptr, ptr %l0, !tbaa !29
  store ptr %t534, ptr %l291, !tbaa !29
  %t535 = load ptr, ptr %l2, !tbaa !29
  %t537 = getelementptr %"compiler/ast:Chain", ptr %t535, i32 0, i32 1
  %t538 = load { i64, ptr }, ptr %t537, !tbaa !27
  store { i64, ptr } %t538, ptr %l293, !tbaa !27
  %t539 = load i64, ptr %l37, !tbaa !24
  %t541 = getelementptr { i64, ptr }, ptr %l293, i32 0, i32 1
  %t542 = load ptr, ptr %t541, !tbaa !27
  %t543 = getelementptr ptr, ptr %t542, i64 %t539
  %t544 = load ptr, ptr %t543, !tbaa !39
  %t546 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t544)
  store %"compiler/source:Span" %t546, ptr %l296
  br label %bb107
bb106:
  br label %bb113
bb107:
  %t547 = load ptr, ptr %l2, !tbaa !29
  %t549 = getelementptr %"compiler/ast:Chain", ptr %t547, i32 0, i32 1
  %t550 = load { i64, ptr }, ptr %t549, !tbaa !27
  store { i64, ptr } %t550, ptr %l298, !tbaa !27
  %t551 = load i64, ptr %l37, !tbaa !24
  %t553 = add i64 %t551, 1
  %t555 = getelementptr { i64, ptr }, ptr %l298, i32 0, i32 1
  %t556 = load ptr, ptr %t555, !tbaa !27
  %t557 = getelementptr ptr, ptr %t556, i64 %t553
  %t558 = load ptr, ptr %t557, !tbaa !39
  %t560 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t558)
  store %"compiler/source:Span" %t560, ptr %l302
  br label %bb108
bb108:
  %t561 = load ptr, ptr %l2, !tbaa !29
  %t563 = getelementptr %"compiler/ast:Chain", ptr %t561, i32 0, i32 0
  %t564 = load { i64, ptr }, ptr %t563, !tbaa !27
  store { i64, ptr } %t564, ptr %l304, !tbaa !27
  %t565 = load i64, ptr %l37, !tbaa !24
  %t567 = getelementptr { i64, ptr }, ptr %l304, i32 0, i32 1
  %t568 = load ptr, ptr %t567, !tbaa !27
  %t569 = getelementptr i32, ptr %t568, i64 %t565
  %t570 = load i32, ptr %t569, !range !{i32 0, i32 98}
  %t572 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s18, i32 %t570)
  store { i64, ptr } %t572, ptr %l307
  br label %bb109
bb109:
  %t573 = load { i64, ptr }, ptr %l307, !tbaa !27
  %t574 = extractvalue { i64, ptr } %t573, 0
  %t575 = load ptr, ptr %l291, !tbaa !29
  %t576 = load %"compiler/source:Span", ptr %l296
  %t577 = load %"compiler/source:Span", ptr %l302
  %t579 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t575, %"compiler/source:Span" %t576, %"compiler/source:Span" %t577, i64 %t574)
  store %"compiler/source:Span" %t579, ptr %l309
  br label %bb110
bb110:
  %t580 = load i32, ptr %l33, !tbaa !23
  store i32 %t580, ptr %l310, !tbaa !23
  %t581 = load ptr, ptr %l36, !tbaa !29
  %t584 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t581)
  store i32 %t584, ptr %l313
  br label %bb111
bb111:
  %t585 = load ptr, ptr %l290, !tbaa !29
  %t586 = load %"compiler/source:Span", ptr %l309
  %t587 = load i32, ptr %l310, !tbaa !23
  %t588 = load i32, ptr %l313, !tbaa !23
  %t589 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoMeet(ptr %v0, ptr %t585, %"compiler/source:Span" %t586, i32 %t587, i32 %t588)
  store i1 %t589, ptr %l314
  br label %bb112
bb112:
  call void @__olang_scope_close(ptr %s18)
  br label %bb113
bb113:
  %t590 = load ptr, ptr %l0, !tbaa !29
  %t592 = getelementptr %"compiler/check:Checker", ptr %t590, i32 0, i32 36
  %t593 = load i64, ptr %l3, !tbaa !24
  %t594 = load i64, ptr %l24, !tbaa !24
  %t597 = add i64 %t593, %t594
  %t598 = load ptr, ptr %l36, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eSetAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t592, i64 %t597, ptr %t598)
  br label %bb114
bb114:
  call void @__olang_scope_close(ptr %s10)
  br label %bb115
bb115:
  %t602 = load i64, ptr %l23, !tbaa !24
  %t604 = add i64 %t602, 1
  store i64 %t604, ptr %l23, !tbaa !24
  br label %bb47
bb116:
  %t606 = load ptr, ptr %l0, !tbaa !29
  store ptr %t606, ptr %l323, !tbaa !29
  %t607 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t607, ptr %l324
  %t608 = load ptr, ptr %l2, !tbaa !29
  store ptr %t608, ptr %l325, !tbaa !29
  %t609 = load i64, ptr %l3, !tbaa !24
  store i64 %t609, ptr %l326, !tbaa !24
  %t610 = load ptr, ptr %lp5
  %t611 = load { i64, ptr }, ptr %t610, !tbaa !27
  store { i64, ptr } %t611, ptr %l327, !tbaa !27
  %t612 = load ptr, ptr %lp5
  %t613 = getelementptr { i64, ptr }, ptr %t612, i32 0, i32 1
  %t614 = load ptr, ptr %t613, !tbaa !27
  %t615 = getelementptr i1, ptr %t614, i64 0
  %t616 = load i1, ptr %t615, !tbaa !31
  br i1 %t616, label %bb117, label %bb118
bb117:
  store ptr null, ptr %l329, !tbaa !29
  br label %bb120
bb118:
  %t618 = load ptr, ptr %l0, !tbaa !29
  %t620 = getelementptr %"compiler/check:Checker", ptr %t618, i32 0, i32 36
  %t621 = load i64, ptr %l3, !tbaa !24
  %t624 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t620, i64 %t621)
  store ptr %t624, ptr %l333
  br label %bb119
bb119:
  %t625 = load ptr, ptr %l333, !tbaa !29
  store ptr %t625, ptr %l329, !tbaa !29
  br label %bb120
bb120:
  %t627 = load ptr, ptr %l323, !tbaa !29
  %t628 = load %"compiler/source:Span", ptr %l324
  %t629 = load ptr, ptr %l325, !tbaa !29
  %t630 = load i64, ptr %l326, !tbaa !24
  %t631 = load { i64, ptr }, ptr %l327, !tbaa !27
  %t632 = load ptr, ptr %l329, !tbaa !29
  %t633 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainFrom(ptr %v0, ptr %v1, ptr %v2, ptr %v0, ptr %v2, ptr %t627, %"compiler/source:Span" %t628, ptr %t629, i64 %t630, { i64, ptr } %t631, i64 0, ptr %t632)
  store ptr %t633, ptr %l335
  br label %bb121
bb121:
  %t634 = load ptr, ptr %l335, !tbaa !29
  store ptr %t634, ptr %l38, !tbaa !29
  %t635 = load ptr, ptr %l0, !tbaa !29
  %t637 = getelementptr %"compiler/check:Checker", ptr %t635, i32 0, i32 36
  %t638 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eTrunca_Hdac151ce4e73ec212dc55b02b0b7e7d0(ptr %v0, ptr %t637, i64 %t638)
  br label %bb122
bb122:
  %t641 = load ptr, ptr %l38, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t641, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainCmp(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l27 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l39 = alloca %"compiler/source:Span"
  %l41 = alloca %"compiler/source:Span"
  %l43 = alloca { i64, ptr }
  %l45 = alloca %"compiler/source:Span"
  %l48 = alloca ptr
  %l49 = alloca ptr
  %l53 = alloca %"compiler/check:litv"
  %l59 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca ptr
  %l66 = alloca %"compiler/source:Span"
  %l67 = alloca %"compiler/source:Span"
  %l68 = alloca i32
  %l69 = alloca ptr
  %l72 = alloca ptr
  %l74 = alloca %"compiler/source:Span"
  %l76 = alloca %"compiler/source:Span"
  %l77 = alloca ptr
  %l80 = alloca ptr
  %l81 = alloca ptr
  %l85 = alloca %"compiler/check:litv"
  %l89 = alloca ptr
  %l94 = alloca ptr
  %l95 = alloca ptr
  %l96 = alloca %"compiler/source:Span"
  %l97 = alloca %"compiler/source:Span"
  %l98 = alloca i32
  %l99 = alloca ptr
  %l100 = alloca ptr
  %l102 = alloca %"compiler/source:Span"
  %l104 = alloca %"compiler/source:Span"
  %l105 = alloca ptr
  %l106 = alloca ptr
  %l107 = alloca %"compiler/source:Span"
  %l108 = alloca %"compiler/source:Span"
  %l109 = alloca i32
  %l110 = alloca ptr
  %l111 = alloca ptr
  %l113 = alloca %"compiler/source:Span"
  %l115 = alloca %"compiler/source:Span"
  %l116 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Chain", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l13, !tbaa !27
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr ptr, ptr %t8, i64 %t5
  %t10 = load ptr, ptr %t9, !tbaa !39
  store ptr %t10, ptr %l6, !tbaa !29
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t14 = getelementptr %"compiler/ast:Chain", ptr %t12, i32 0, i32 1
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l17, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = add i64 %t16, 1
  %t20 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr ptr, ptr %t21, i64 %t18
  %t23 = load ptr, ptr %t22, !tbaa !39
  store ptr %t23, ptr %l7, !tbaa !29
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr %"compiler/ast:Chain", ptr %t25, i32 0, i32 0
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l22, !tbaa !27
  %t29 = load i64, ptr %l3, !tbaa !24
  %t31 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr i32, ptr %t32, i64 %t29
  %t34 = load i32, ptr %t33, !range !{i32 0, i32 98}
  store i32 %t34, ptr %l8
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t38 = icmp eq ptr %t36, null
  br i1 %t38, label %bb1, label %bb2
bb1:
  %t40 = load ptr, ptr %l5, !tbaa !29
  %t42 = icmp eq ptr %t40, null
  store i1 %t42, ptr %l27, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb3
bb3:
  %t44 = load i1, ptr %l27, !tbaa !21
  br i1 %t44, label %bb4, label %bb5
bb4:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load %"compiler/source:Span", ptr %l1
  %t47 = load i32, ptr %l8, !range !{i32 0, i32 98}
  %t48 = load ptr, ptr %l6, !tbaa !29
  %t49 = load ptr, ptr %l7, !tbaa !29
  %t50 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t57 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebinary(ptr %v0, ptr %v1, ptr %v1, ptr %v4, ptr %t45, %"compiler/source:Span" %t46, i32 %t47, ptr %t48, ptr %t49, i32 %t50)
  store ptr %t57, ptr %l36
  br label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t58 = load ptr, ptr %l36, !tbaa !29
  store ptr %t58, ptr %rv
  br label %ret
bb7:
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l37, !tbaa !29
  %t60 = load ptr, ptr %l6, !tbaa !29
  %t62 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t60)
  store %"compiler/source:Span" %t62, ptr %l39
  br label %bb8
bb8:
  %t63 = load ptr, ptr %l7, !tbaa !29
  %t65 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t63)
  store %"compiler/source:Span" %t65, ptr %l41
  br label %bb9
bb9:
  %t66 = load i32, ptr %l8, !range !{i32 0, i32 98}
  %t68 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s0, i32 %t66)
  store { i64, ptr } %t68, ptr %l43
  br label %bb10
bb10:
  %t69 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  %t71 = load ptr, ptr %l37, !tbaa !29
  %t72 = load %"compiler/source:Span", ptr %l39
  %t73 = load %"compiler/source:Span", ptr %l41
  %t75 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t71, %"compiler/source:Span" %t72, %"compiler/source:Span" %t73, i64 %t70)
  store %"compiler/source:Span" %t75, ptr %l45
  br label %bb11
bb11:
  %t76 = load %"compiler/source:Span", ptr %l45
  store %"compiler/source:Span" %t76, ptr %l9
  %t77 = load ptr, ptr %l4, !tbaa !29
  %t79 = icmp eq ptr %t77, null
  br i1 %t79, label %bb12, label %bb13
bb12:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l48, !tbaa !29
  %t82 = load ptr, ptr %l6, !tbaa !29
  store ptr %t82, ptr %l49, !tbaa !29
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l6, !tbaa !29
  %t88 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t83, ptr %t84)
  store %"compiler/check:litv" %t88, ptr %l53
  br label %bb14
bb13:
  br label %bb29
bb14:
  %t89 = load ptr, ptr %l5, !tbaa !29
  %t91 = icmp eq ptr %t89, null
  br i1 %t91, label %bb15, label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_854899d5724a103b_e7dfb19072d83fa7)
  unreachable
bb16:
  br label %bb17
bb17:
  %t93 = load ptr, ptr %l5, !tbaa !29
  %t94 = load i32, ptr %l8, !range !{i32 0, i32 98}
  %t95 = load %"compiler/source:Span", ptr %l9
  %t96 = load ptr, ptr %l48, !tbaa !29
  %t97 = load ptr, ptr %l49, !tbaa !29
  %t98 = load %"compiler/check:litv", ptr %l53
  %t102 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitBeside(ptr %v0, ptr %v1, ptr %v3, ptr %v4, ptr %t96, ptr %t97, %"compiler/check:litv" %t98, ptr %t93, i32 %t94, %"compiler/source:Span" %t95, i1 false)
  store ptr %t102, ptr %l59
  br label %bb18
bb18:
  %t103 = load ptr, ptr %l59, !tbaa !29
  store ptr %t103, ptr %l10, !tbaa !29
  %t104 = load ptr, ptr %l10, !tbaa !29
  %t106 = icmp eq ptr %t104, null
  br i1 %t106, label %bb19, label %bb20
bb19:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load %"compiler/source:Span", ptr %l1
  %t112 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t108, %"compiler/source:Span" %t109)
  store ptr %t112, ptr %l64
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  %t113 = load ptr, ptr %l64, !tbaa !29
  store ptr %t113, ptr %rv
  br label %ret
bb22:
  %t114 = load ptr, ptr %l0, !tbaa !29
  store ptr %t114, ptr %l65, !tbaa !29
  %t115 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t115, ptr %l66
  %t116 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t116, ptr %l67
  %t117 = load i32, ptr %l8, !range !{i32 0, i32 98}
  store i32 %t117, ptr %l68
  %t118 = load ptr, ptr %l10, !tbaa !29
  store ptr %t118, ptr %l69, !tbaa !29
  %t119 = load ptr, ptr %l5, !tbaa !29
  %t121 = icmp eq ptr %t119, null
  br i1 %t121, label %bb23, label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_852b58c2eb82b3cc_e47a0c64d3951188)
  unreachable
bb24:
  br label %bb25
bb25:
  %t123 = load ptr, ptr %l5, !tbaa !29
  store ptr %t123, ptr %l72, !tbaa !29
  %t124 = load ptr, ptr %l6, !tbaa !29
  %t126 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t124)
  store %"compiler/source:Span" %t126, ptr %l74
  br label %bb26
bb26:
  %t127 = load ptr, ptr %l7, !tbaa !29
  %t129 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t127)
  store %"compiler/source:Span" %t129, ptr %l76
  br label %bb27
bb27:
  %t130 = load ptr, ptr %l65, !tbaa !29
  %t131 = load %"compiler/source:Span", ptr %l66
  %t132 = load %"compiler/source:Span", ptr %l67
  %t133 = load i32, ptr %l68, !range !{i32 0, i32 98}
  %t134 = load ptr, ptr %l69, !tbaa !29
  %t135 = load ptr, ptr %l72, !tbaa !29
  %t136 = load %"compiler/source:Span", ptr %l74
  %t137 = load %"compiler/source:Span", ptr %l76
  %t138 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %v4, ptr %v3, ptr %v4, ptr %t130, %"compiler/source:Span" %t131, %"compiler/source:Span" %t132, i32 %t133, ptr %t134, ptr %t135, %"compiler/source:Span" %t136, %"compiler/source:Span" %t137)
  store ptr %t138, ptr %l77
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s0)
  %t139 = load ptr, ptr %l77, !tbaa !29
  store ptr %t139, ptr %rv
  br label %ret
bb29:
  %t140 = load ptr, ptr %l5, !tbaa !29
  %t142 = icmp eq ptr %t140, null
  br i1 %t142, label %bb30, label %bb31
bb30:
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l80, !tbaa !29
  %t145 = load ptr, ptr %l7, !tbaa !29
  store ptr %t145, ptr %l81, !tbaa !29
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load ptr, ptr %l7, !tbaa !29
  %t151 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t146, ptr %t147)
  store %"compiler/check:litv" %t151, ptr %l85
  br label %bb32
bb31:
  br label %bb41
bb32:
  %t152 = load ptr, ptr %l4, !tbaa !29
  %t153 = load i32, ptr %l8, !range !{i32 0, i32 98}
  %t154 = load %"compiler/source:Span", ptr %l9
  %t155 = load ptr, ptr %l80, !tbaa !29
  %t156 = load ptr, ptr %l81, !tbaa !29
  %t157 = load %"compiler/check:litv", ptr %l85
  %t161 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitBeside(ptr %v0, ptr %v1, ptr %v2, ptr %v4, ptr %t155, ptr %t156, %"compiler/check:litv" %t157, ptr %t152, i32 %t153, %"compiler/source:Span" %t154, i1 true)
  store ptr %t161, ptr %l89
  br label %bb33
bb33:
  %t162 = load ptr, ptr %l89, !tbaa !29
  store ptr %t162, ptr %l11, !tbaa !29
  %t163 = load ptr, ptr %l11, !tbaa !29
  %t165 = icmp eq ptr %t163, null
  br i1 %t165, label %bb34, label %bb35
bb34:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load %"compiler/source:Span", ptr %l1
  %t171 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t167, %"compiler/source:Span" %t168)
  store ptr %t171, ptr %l94
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_scope_close(ptr %s0)
  %t172 = load ptr, ptr %l94, !tbaa !29
  store ptr %t172, ptr %rv
  br label %ret
bb37:
  %t173 = load ptr, ptr %l0, !tbaa !29
  store ptr %t173, ptr %l95, !tbaa !29
  %t174 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t174, ptr %l96
  %t175 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t175, ptr %l97
  %t176 = load i32, ptr %l8, !range !{i32 0, i32 98}
  store i32 %t176, ptr %l98
  %t177 = load ptr, ptr %l4, !tbaa !29
  store ptr %t177, ptr %l99, !tbaa !29
  %t178 = load ptr, ptr %l11, !tbaa !29
  store ptr %t178, ptr %l100, !tbaa !29
  %t179 = load ptr, ptr %l6, !tbaa !29
  %t181 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t179)
  store %"compiler/source:Span" %t181, ptr %l102
  br label %bb38
bb38:
  %t182 = load ptr, ptr %l7, !tbaa !29
  %t184 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t182)
  store %"compiler/source:Span" %t184, ptr %l104
  br label %bb39
bb39:
  %t185 = load ptr, ptr %l95, !tbaa !29
  %t186 = load %"compiler/source:Span", ptr %l96
  %t187 = load %"compiler/source:Span", ptr %l97
  %t188 = load i32, ptr %l98, !range !{i32 0, i32 98}
  %t189 = load ptr, ptr %l99, !tbaa !29
  %t190 = load ptr, ptr %l100, !tbaa !29
  %t191 = load %"compiler/source:Span", ptr %l102
  %t192 = load %"compiler/source:Span", ptr %l104
  %t193 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %v2, ptr %v4, ptr %v4, ptr %t185, %"compiler/source:Span" %t186, %"compiler/source:Span" %t187, i32 %t188, ptr %t189, ptr %t190, %"compiler/source:Span" %t191, %"compiler/source:Span" %t192)
  store ptr %t193, ptr %l105
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s0)
  %t194 = load ptr, ptr %l105, !tbaa !29
  store ptr %t194, ptr %rv
  br label %ret
bb41:
  %t195 = load ptr, ptr %l0, !tbaa !29
  store ptr %t195, ptr %l106, !tbaa !29
  %t196 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t196, ptr %l107
  %t197 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t197, ptr %l108
  %t198 = load i32, ptr %l8, !range !{i32 0, i32 98}
  store i32 %t198, ptr %l109
  %t199 = load ptr, ptr %l4, !tbaa !29
  store ptr %t199, ptr %l110, !tbaa !29
  %t200 = load ptr, ptr %l5, !tbaa !29
  store ptr %t200, ptr %l111, !tbaa !29
  %t201 = load ptr, ptr %l6, !tbaa !29
  %t203 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t201)
  store %"compiler/source:Span" %t203, ptr %l113
  br label %bb42
bb42:
  %t204 = load ptr, ptr %l7, !tbaa !29
  %t206 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t204)
  store %"compiler/source:Span" %t206, ptr %l115
  br label %bb43
bb43:
  %t207 = load ptr, ptr %l106, !tbaa !29
  %t208 = load %"compiler/source:Span", ptr %l107
  %t209 = load %"compiler/source:Span", ptr %l108
  %t210 = load i32, ptr %l109, !range !{i32 0, i32 98}
  %t211 = load ptr, ptr %l110, !tbaa !29
  %t212 = load ptr, ptr %l111, !tbaa !29
  %t213 = load %"compiler/source:Span", ptr %l113
  %t214 = load %"compiler/source:Span", ptr %l115
  %t215 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %v2, ptr %v3, ptr %v4, ptr %t207, %"compiler/source:Span" %t208, %"compiler/source:Span" %t209, i32 %t210, ptr %t211, ptr %t212, %"compiler/source:Span" %t213, %"compiler/source:Span" %t214)
  store ptr %t215, ptr %l116
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s0)
  %t216 = load ptr, ptr %l116, !tbaa !29
  store ptr %t216, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecommutesRule(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l5 = alloca %"compiler/source:Span"
  %l7 = alloca { i64, ptr }
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i64
  %l17 = alloca i64
  %l21 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l28 = alloca i32
  %l31 = alloca ptr
  %l36 = alloca i32
  %l37 = alloca { i64, ptr }
  %l39 = alloca i1
  %l40 = alloca i1
  %l42 = alloca i1
  %l43 = alloca i1
  %l45 = alloca i1
  %l46 = alloca i1
  %l48 = alloca i1
  %l49 = alloca i1
  %l51 = alloca i1
  %l54 = alloca i1
  %l58 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca %"compiler/source:Span"
  %l67 = alloca { i64, ptr }
  %l69 = alloca %"compiler/diagmsg:Msg"
  %l70 = alloca i64
  %l74 = alloca ptr
  %l76 = alloca { i64, ptr }
  %l78 = alloca i32
  %l79 = alloca i32
  %l82 = alloca ptr
  %l84 = alloca { i64, ptr }
  %l86 = alloca i32
  %l87 = alloca i32
  %l93 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca %"compiler/source:Span"
  %l99 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l105 = alloca %"compiler/diagmsg:Msg"
  %l106 = alloca i64
  %l110 = alloca i1
  %l116 = alloca i64
  %l119 = alloca i1
  %l126 = alloca ptr
  %l129 = alloca ptr
  %l133 = alloca i32
  %l134 = alloca i32
  %l135 = alloca { i64, ptr }
  %l138 = alloca ptr
  %l141 = alloca ptr
  %l143 = alloca { i64, ptr }
  %l145 = alloca i32
  %l146 = alloca i32
  %l148 = alloca i1
  %l154 = alloca ptr
  %l158 = alloca i1
  %l164 = alloca i1
  %l165 = alloca { i64, ptr }
  %l167 = alloca i1
  %l168 = alloca { i64, ptr }
  %l170 = alloca i1
  %l171 = alloca { i64, ptr }
  %l173 = alloca i1
  %l174 = alloca { i64, ptr }
  %l175 = alloca ptr
  %l176 = alloca %"compiler/source:Span"
  %l177 = alloca { i64, ptr }
  %l180 = alloca { i64, ptr }
  %l181 = alloca { i64, ptr }
  %l184 = alloca { i64, ptr }
  %l185 = alloca { i64, ptr }
  %l188 = alloca { i64, ptr }
  %l189 = alloca ptr
  %l193 = alloca ptr
  %l196 = alloca { i64, ptr }
  %l199 = alloca %"compiler/diagmsg:Msg"
  %l200 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t4, i64 %t5)
  store i64 %t8, ptr %l17
  br label %bb1
bb1:
  %t9 = load i64, ptr %l17, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t16 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t10, i64 -1, i64 %t9, i32 %t12, i32 0)
  store ptr %t16, ptr %l21
  br label %bb2
bb2:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t21 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v1, ptr %t17, ptr %t18)
  store %"compiler/source:Span" %t21, ptr %l24
  br label %bb3
bb3:
  %t22 = load %"compiler/source:Span", ptr %l24
  store %"compiler/source:Span" %t22, ptr %l5
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t27 = load i64, ptr %l1, !tbaa !24
  %t30 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t26, i64 %t27)
  store i32 %t30, ptr %l28
  br label %bb4
bb4:
  %t31 = load i32, ptr %l28, !tbaa !23
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  store ptr %t37, ptr %l31, !tbaa !29
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 2
  %t47 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t43, i32 %t31)
  store i32 %t47, ptr %l36
  br label %bb5
bb5:
  %t48 = load ptr, ptr %l31, !tbaa !29
  %t49 = load i32, ptr %l36, !tbaa !23
  %t50 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t48, i32 %t49)
  store { i64, ptr } %t50, ptr %l37
  br label %bb6
bb6:
  %t51 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t51, ptr %l7, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t54 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t52, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store i1 %t54, ptr %l39
  br label %bb7
bb7:
  %t55 = load i1, ptr %l39, !tbaa !21
  br i1 %t55, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb11
bb9:
  %t56 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t58 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t56, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i1 %t58, ptr %l42
  br label %bb10
bb10:
  %t59 = load i1, ptr %l42, !tbaa !21
  store i1 %t59, ptr %l40, !tbaa !21
  br label %bb11
bb11:
  %t60 = load i1, ptr %l40, !tbaa !21
  br i1 %t60, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb15
bb13:
  %t61 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t63 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t61, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i1 %t63, ptr %l45
  br label %bb14
bb14:
  %t64 = load i1, ptr %l45, !tbaa !21
  store i1 %t64, ptr %l43, !tbaa !21
  br label %bb15
bb15:
  %t65 = load i1, ptr %l43, !tbaa !21
  br i1 %t65, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb19
bb17:
  %t66 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t68 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t66, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d9, i32 0, i32 1) })
  store i1 %t68, ptr %l48
  br label %bb18
bb18:
  %t69 = load i1, ptr %l48, !tbaa !21
  store i1 %t69, ptr %l46, !tbaa !21
  br label %bb19
bb19:
  %t70 = load i1, ptr %l46, !tbaa !21
  br i1 %t70, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb23
bb21:
  %t71 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t73 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t71, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i1 %t73, ptr %l51
  br label %bb22
bb22:
  %t74 = load i1, ptr %l51, !tbaa !21
  store i1 %t74, ptr %l49, !tbaa !21
  br label %bb23
bb23:
  %t75 = load i1, ptr %l49, !tbaa !21
  %t78 = xor i1 %t75, true
  br i1 %t78, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb26
bb25:
  %t80 = load ptr, ptr %l2, !tbaa !29
  %t82 = getelementptr %"compiler/ast:Func", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = icmp eq ptr %t83, null
  store i1 %t85, ptr %l54, !tbaa !21
  br label %bb26
bb26:
  %t87 = load i1, ptr %l54, !tbaa !21
  br i1 %t87, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l58, !tbaa !21
  br label %bb29
bb28:
  %t88 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t88, 0
  %t92 = icmp ne i64 %t90, 2
  store i1 %t92, ptr %l58, !tbaa !21
  br label %bb29
bb29:
  %t94 = load i1, ptr %l58, !tbaa !21
  br i1 %t94, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s1
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l62, !tbaa !29
  %t96 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t96, ptr %l63
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %l2, !tbaa !29
  %t100 = getelementptr %"compiler/ast:Func", ptr %t98, i32 0, i32 2
  %t101 = load i32, ptr %t100, !tbaa !23
  %t104 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s1, ptr %t97, i32 %t101)
  store { i64, ptr } %t104, ptr %l67
  br label %bb32
bb31:
  br label %bb36
bb32:
  %t105 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t105, 0
  %t107 = extractvalue { i64, ptr } %t105, 1
  %t108 = mul i64 %t106, 1
  %t109 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t108)
  call void @llvm.memcpy.p0.p0.i64(ptr %t109, ptr %t107, i64 %t108, i1 false)
  %t110 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  %t113 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCommutesNotHere(ptr %s1, ptr %s1, { i64, ptr } %t111)
  store %"compiler/diagmsg:Msg" %t113, ptr %l69
  br label %bb33
bb33:
  %t114 = load ptr, ptr %l62, !tbaa !29
  %t115 = load %"compiler/source:Span", ptr %l63
  %t116 = load %"compiler/diagmsg:Msg", ptr %l69
  %t117 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t114, %"compiler/source:Span" %t115, %"compiler/diagmsg:Msg" %t116)
  store i64 %t117, ptr %l70
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s1)
  %t118 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t118)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb36:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/check:Checker", ptr %t120, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = getelementptr %"compiler/generic:Program", ptr %t123, i32 0, i32 2
  store ptr %t125, ptr %l74, !tbaa !29
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t127, ptr %l76, !tbaa !27
  %t128 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr i32, ptr %t129, i64 0
  %t131 = load i32, ptr %t130, !tbaa !33
  %t134 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t126, i32 %t131)
  store i32 %t134, ptr %l78
  br label %bb37
bb37:
  %t135 = load ptr, ptr %l74, !tbaa !29
  %t136 = load i32, ptr %l78, !tbaa !23
  %t137 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t135, i32 %t136)
  store i32 %t137, ptr %l79
  br label %bb38
bb38:
  %t138 = load i32, ptr %l79, !tbaa !23
  store i32 %t138, ptr %l9, !tbaa !23
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/check:Checker", ptr %t139, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t144 = getelementptr %"compiler/generic:Program", ptr %t142, i32 0, i32 2
  store ptr %t144, ptr %l82, !tbaa !29
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t146, ptr %l84, !tbaa !27
  %t147 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = getelementptr i32, ptr %t148, i64 1
  %t150 = load i32, ptr %t149, !tbaa !33
  %t153 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t145, i32 %t150)
  store i32 %t153, ptr %l86
  br label %bb39
bb39:
  %t154 = load ptr, ptr %l82, !tbaa !29
  %t155 = load i32, ptr %l86, !tbaa !23
  %t156 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t154, i32 %t155)
  store i32 %t156, ptr %l87
  br label %bb40
bb40:
  %t157 = load i32, ptr %l87, !tbaa !23
  store i32 %t157, ptr %l10, !tbaa !23
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/check:Checker", ptr %t158, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = getelementptr %"compiler/generic:Program", ptr %t161, i32 0, i32 2
  %t164 = load i32, ptr %l9, !tbaa !23
  %t165 = load i32, ptr %l10, !tbaa !23
  %t169 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t163, i32 %t164, i32 %t165)
  store i1 %t169, ptr %l93
  br label %bb41
bb41:
  %t170 = load i1, ptr %l93, !tbaa !21
  br i1 %t170, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s3
  %t171 = load ptr, ptr %l0, !tbaa !29
  store ptr %t171, ptr %l94, !tbaa !29
  %t172 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t172, ptr %l95
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load ptr, ptr %l2, !tbaa !29
  %t176 = getelementptr %"compiler/ast:Func", ptr %t174, i32 0, i32 2
  %t177 = load i32, ptr %t176, !tbaa !23
  %t180 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s3, ptr %t173, i32 %t177)
  store { i64, ptr } %t180, ptr %l99
  br label %bb44
bb43:
  br label %bb49
bb44:
  %t181 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t181, 0
  %t183 = extractvalue { i64, ptr } %t181, 1
  %t184 = mul i64 %t182, 1
  %t185 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t184)
  call void @llvm.memcpy.p0.p0.i64(ptr %t185, ptr %t183, i64 %t184, i1 false)
  %t186 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t185, 1
  store { i64, ptr } %t187, ptr %l100, !tbaa !27
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load i32, ptr %l10, !tbaa !23
  %t192 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t188, i32 %t189)
  store { i64, ptr } %t192, ptr %l103
  br label %bb45
bb45:
  %t193 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t194 = extractvalue { i64, ptr } %t193, 0
  %t195 = extractvalue { i64, ptr } %t193, 1
  %t196 = mul i64 %t194, 1
  %t197 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t196)
  call void @llvm.memcpy.p0.p0.i64(ptr %t197, ptr %t195, i64 %t196, i1 false)
  %t198 = insertvalue { i64, ptr } undef, i64 %t194, 0
  %t199 = insertvalue { i64, ptr } %t198, ptr %t197, 1
  %t200 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t202 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCommutesSameType(ptr %s3, ptr %s3, ptr %s3, { i64, ptr } %t200, { i64, ptr } %t199)
  store %"compiler/diagmsg:Msg" %t202, ptr %l105
  br label %bb46
bb46:
  %t203 = load ptr, ptr %l94, !tbaa !29
  %t204 = load %"compiler/source:Span", ptr %l95
  %t205 = load %"compiler/diagmsg:Msg", ptr %l105
  %t206 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t203, %"compiler/source:Span" %t204, %"compiler/diagmsg:Msg" %t205)
  store i64 %t206, ptr %l106
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s3)
  %t207 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t207)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb49:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load i32, ptr %l10, !tbaa !23
  %t213 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t209, i32 %t210)
  store i1 %t213, ptr %l110
  br label %bb50
bb50:
  %t214 = load i1, ptr %l110, !tbaa !21
  %t215 = xor i1 %t214, true
  br i1 %t215, label %bb51, label %bb52
bb51:
  %t217 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t217)
  br label %bb53
bb52:
  br label %bb54
bb53:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb54:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load i32, ptr %l10, !tbaa !23
  %t221 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t225 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %v2, ptr %t219, i32 %t220, { i64, ptr } %t221, i64 1)
  store i64 %t225, ptr %l116
  br label %bb55
bb55:
  %t226 = load i64, ptr %l116, !tbaa !24
  store i64 %t226, ptr %l11, !tbaa !24
  %t227 = load i64, ptr %l11, !tbaa !24
  %t229 = icmp slt i64 %t227, 0
  br i1 %t229, label %bb56, label %bb57
bb56:
  store i1 true, ptr %l119, !tbaa !21
  br label %bb58
bb57:
  %t231 = load i64, ptr %l11, !tbaa !24
  %t232 = load i64, ptr %l1, !tbaa !24
  %t235 = icmp eq i64 %t231, %t232
  store i1 %t235, ptr %l119, !tbaa !21
  br label %bb58
bb58:
  %t237 = load i1, ptr %l119, !tbaa !21
  br i1 %t237, label %bb59, label %bb60
bb59:
  %t238 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t238)
  br label %bb61
bb60:
  br label %bb62
bb61:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb62:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = getelementptr %"compiler/check:Checker", ptr %t240, i32 0, i32 1
  %t243 = load ptr, ptr %t242, !tbaa !29
  %t245 = getelementptr %"compiler/generic:Program", ptr %t243, i32 0, i32 2
  store ptr %t245, ptr %l126, !tbaa !29
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t248 = getelementptr %"compiler/check:Checker", ptr %t246, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !29
  %t251 = getelementptr %"compiler/generic:Program", ptr %t249, i32 0, i32 2
  store ptr %t251, ptr %l129, !tbaa !29
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr %"compiler/check:Checker", ptr %t252, i32 0, i32 1
  %t255 = load ptr, ptr %t254, !tbaa !29
  %t256 = load i64, ptr %l11, !tbaa !24
  %t259 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t255, i64 %t256)
  store i32 %t259, ptr %l133
  br label %bb63
bb63:
  %t260 = load ptr, ptr %l129, !tbaa !29
  %t261 = load i32, ptr %l133, !tbaa !23
  %t262 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t260, i32 %t261)
  store i32 %t262, ptr %l134
  br label %bb64
bb64:
  %t263 = load ptr, ptr %l126, !tbaa !29
  %t264 = load i32, ptr %l134, !tbaa !23
  %t265 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t263, i32 %t264)
  store { i64, ptr } %t265, ptr %l135
  br label %bb65
bb65:
  %t266 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/check:Checker", ptr %t267, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !29
  %t272 = getelementptr %"compiler/generic:Program", ptr %t270, i32 0, i32 2
  store ptr %t272, ptr %l138, !tbaa !29
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/check:Checker", ptr %t273, i32 0, i32 1
  %t276 = load ptr, ptr %t275, !tbaa !29
  %t278 = getelementptr %"compiler/generic:Program", ptr %t276, i32 0, i32 2
  store ptr %t278, ptr %l141, !tbaa !29
  %t279 = load ptr, ptr %l0, !tbaa !29
  store { i64, ptr } %t266, ptr %l143, !tbaa !27
  %t281 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !27
  %t283 = getelementptr i32, ptr %t282, i64 1
  %t284 = load i32, ptr %t283, !tbaa !33
  %t287 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t279, i32 %t284)
  store i32 %t287, ptr %l145
  br label %bb66
bb66:
  %t288 = load ptr, ptr %l141, !tbaa !29
  %t289 = load i32, ptr %l145, !tbaa !23
  %t290 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t288, i32 %t289)
  store i32 %t290, ptr %l146
  br label %bb67
bb67:
  %t291 = load i32, ptr %l9, !tbaa !23
  %t292 = load ptr, ptr %l138, !tbaa !29
  %t293 = load i32, ptr %l146, !tbaa !23
  %t295 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t292, i32 %t293, i32 %t291)
  store i1 %t295, ptr %l148
  br label %bb68
bb68:
  %t296 = load i1, ptr %l148, !tbaa !21
  %t297 = xor i1 %t296, true
  br i1 %t297, label %bb69, label %bb70
bb69:
  %t299 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t299)
  br label %bb71
bb70:
  br label %bb72
bb71:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb72:
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t303 = getelementptr %"compiler/check:Checker", ptr %t301, i32 0, i32 1
  %t304 = load ptr, ptr %t303, !tbaa !29
  %t305 = load i64, ptr %l11, !tbaa !24
  %t308 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s0, ptr %t304, i64 %t305)
  store ptr %t308, ptr %l154
  br label %bb73
bb73:
  %t309 = load ptr, ptr %l154, !tbaa !29
  %t311 = getelementptr %"compiler/ast:Func", ptr %t309, i32 0, i32 3
  %t312 = load ptr, ptr %t311, !tbaa !29
  %t314 = getelementptr %"compiler/ast:Sig", ptr %t312, i32 0, i32 6
  %t315 = load i1, ptr %t314, !tbaa !21
  br i1 %t315, label %bb74, label %bb75
bb74:
  %t317 = load i64, ptr %l11, !tbaa !24
  %t318 = load i64, ptr %l1, !tbaa !24
  %t321 = icmp sgt i64 %t317, %t318
  store i1 %t321, ptr %l158, !tbaa !21
  br label %bb76
bb75:
  store i1 false, ptr %l158, !tbaa !21
  br label %bb76
bb76:
  %t323 = load i1, ptr %l158, !tbaa !21
  br i1 %t323, label %bb77, label %bb78
bb77:
  %t324 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t324)
  br label %bb79
bb78:
  br label %bb80
bb79:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb80:
  %t326 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t328 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t326, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i1 %t328, ptr %l164
  br label %bb81
bb81:
  %t329 = load i1, ptr %l164, !tbaa !21
  br i1 %t329, label %bb82, label %bb83
bb82:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d12, i32 0, i32 1) }, ptr %l165, !tbaa !27
  br label %bb96
bb83:
  %t330 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t332 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t330, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i1 %t332, ptr %l167
  br label %bb84
bb84:
  %t333 = load i1, ptr %l167, !tbaa !21
  br i1 %t333, label %bb85, label %bb86
bb85:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d14, i32 0, i32 1) }, ptr %l168, !tbaa !27
  br label %bb95
bb86:
  %t334 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t336 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t334, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t336, ptr %l170
  br label %bb87
bb87:
  %t337 = load i1, ptr %l170, !tbaa !21
  br i1 %t337, label %bb88, label %bb89
bb88:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l171, !tbaa !27
  br label %bb94
bb89:
  %t338 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t340 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t338, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store i1 %t340, ptr %l173
  br label %bb90
bb90:
  %t341 = load i1, ptr %l173, !tbaa !21
  br i1 %t341, label %bb91, label %bb92
bb91:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l174, !tbaa !27
  br label %bb93
bb92:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l174, !tbaa !27
  br label %bb93
bb93:
  %t342 = load { i64, ptr }, ptr %l174, !tbaa !27
  store { i64, ptr } %t342, ptr %l171, !tbaa !27
  br label %bb94
bb94:
  %t343 = load { i64, ptr }, ptr %l171, !tbaa !27
  store { i64, ptr } %t343, ptr %l168, !tbaa !27
  br label %bb95
bb95:
  %t344 = load { i64, ptr }, ptr %l168, !tbaa !27
  store { i64, ptr } %t344, ptr %l165, !tbaa !27
  br label %bb96
bb96:
  %t345 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t346 = load ptr, ptr %l0, !tbaa !29
  store ptr %t346, ptr %l175, !tbaa !29
  %t347 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t347, ptr %l176
  store { i64, ptr } %t345, ptr %l177, !tbaa !27
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t350 = load i32, ptr %l9, !tbaa !23
  %t353 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t349, i32 %t350)
  store { i64, ptr } %t353, ptr %l180
  br label %bb97
bb97:
  %t354 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t355 = extractvalue { i64, ptr } %t354, 0
  %t356 = extractvalue { i64, ptr } %t354, 1
  %t357 = mul i64 %t355, 1
  %t358 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t357)
  call void @llvm.memcpy.p0.p0.i64(ptr %t358, ptr %t356, i64 %t357, i1 false)
  %t359 = insertvalue { i64, ptr } undef, i64 %t355, 0
  %t360 = insertvalue { i64, ptr } %t359, ptr %t358, 1
  store { i64, ptr } %t360, ptr %l181, !tbaa !27
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t362 = load i32, ptr %l10, !tbaa !23
  %t365 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t361, i32 %t362)
  store { i64, ptr } %t365, ptr %l184
  br label %bb98
bb98:
  %t366 = load { i64, ptr }, ptr %l184, !tbaa !27
  %t367 = extractvalue { i64, ptr } %t366, 0
  %t368 = extractvalue { i64, ptr } %t366, 1
  %t369 = mul i64 %t367, 1
  %t370 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t369)
  call void @llvm.memcpy.p0.p0.i64(ptr %t370, ptr %t368, i64 %t369, i1 false)
  %t371 = insertvalue { i64, ptr } undef, i64 %t367, 0
  %t372 = insertvalue { i64, ptr } %t371, ptr %t370, 1
  store { i64, ptr } %t372, ptr %l185, !tbaa !27
  %t373 = load ptr, ptr %l0, !tbaa !29
  %t374 = load i32, ptr %l10, !tbaa !23
  %t377 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t373, i32 %t374)
  store { i64, ptr } %t377, ptr %l188
  br label %bb99
bb99:
  %t378 = load ptr, ptr %l0, !tbaa !29
  store ptr %t378, ptr %l189, !tbaa !29
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t381 = getelementptr %"compiler/check:Checker", ptr %t379, i32 0, i32 1
  %t382 = load ptr, ptr %t381, !tbaa !29
  %t383 = load i64, ptr %l11, !tbaa !24
  %t386 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s0, ptr %t382, i64 %t383)
  store ptr %t386, ptr %l193
  br label %bb100
bb100:
  %t387 = load ptr, ptr %l193, !tbaa !29
  %t389 = getelementptr %"compiler/ast:Func", ptr %t387, i32 0, i32 2
  %t390 = load i32, ptr %t389, !tbaa !23
  %t391 = load ptr, ptr %l189, !tbaa !29
  %t393 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s0, ptr %t391, i32 %t390)
  store { i64, ptr } %t393, ptr %l196
  br label %bb101
bb101:
  %t394 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t395 = extractvalue { i64, ptr } %t394, 1
  %t396 = extractvalue { i64, ptr } %t394, 0
  %t397 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t398 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t399 = add i64 %t396, %t398
  %t400 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t401 = extractvalue { i64, ptr } %t400, 1
  %t402 = extractvalue { i64, ptr } %t400, 0
  %t403 = add i64 %t399, %t402
  %t404 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t403)
  call void @olang_textcopy(ptr %t404, ptr %t395, i64 %t396)
  %t405 = getelementptr i8, ptr %t404, i64 %t396
  call void @olang_textcopy(ptr %t405, ptr %t397, i64 %t398)
  %t406 = getelementptr i8, ptr %t405, i64 %t398
  call void @olang_textcopy(ptr %t406, ptr %t401, i64 %t402)
  %t407 = insertvalue { i64, ptr } undef, i64 %t403, 0
  %t408 = insertvalue { i64, ptr } %t407, ptr %t404, 1
  %t410 = extractvalue { i64, ptr } %t408, 0
  %t411 = extractvalue { i64, ptr } %t408, 1
  %t412 = mul i64 %t410, 1
  %t413 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t412)
  call void @llvm.memcpy.p0.p0.i64(ptr %t413, ptr %t411, i64 %t412, i1 false)
  %t414 = insertvalue { i64, ptr } undef, i64 %t410, 0
  %t415 = insertvalue { i64, ptr } %t414, ptr %t413, 1
  %t416 = load ptr, ptr @__olang_prog_scope
  %t417 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t418 = load { i64, ptr }, ptr %l181, !tbaa !27
  %t419 = load { i64, ptr }, ptr %l185, !tbaa !27
  %t421 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCommutesClash(ptr %t416, ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t417, { i64, ptr } %t418, { i64, ptr } %t419, { i64, ptr } %t415)
  store %"compiler/diagmsg:Msg" %t421, ptr %l199
  br label %bb102
bb102:
  %t422 = load ptr, ptr %l175, !tbaa !29
  %t423 = load %"compiler/source:Span", ptr %l176
  %t424 = load %"compiler/diagmsg:Msg", ptr %l199
  %t425 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t422, %"compiler/source:Span" %t423, %"compiler/diagmsg:Msg" %t424)
  store i64 %t425, ptr %l200
  br label %bb103
bb103:
  %t426 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t426)
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecommuting(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i64
  %l5 = alloca i1
  %l7 = alloca i1
  %l10 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l20 = alloca i1
  %l24 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t3 = call i1 @compiler_2fcheck_2ecommutative(i32 %t1)
  store i1 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i1, ptr %l5, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb5
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t7, i32 %t8)
  store i1 %t11, ptr %l10
  br label %bb4
bb4:
  %t12 = load i1, ptr %l10, !tbaa !21
  %t13 = xor i1 %t12, true
  store i1 %t13, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t15 = load i1, ptr %l7, !tbaa !21
  br i1 %t15, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l13, !tbaa !29
  %t18 = load i32, ptr %l1, !tbaa !23
  store i32 %t18, ptr %l14, !tbaa !23
  %t19 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t21 = call { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %s0, i32 %t19)
  store { i64, ptr } %t21, ptr %l16
  br label %bb9
bb9:
  %t22 = load ptr, ptr %l13, !tbaa !29
  %t23 = load i32, ptr %l14, !tbaa !23
  %t24 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t25 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t22, i32 %t23, { i64, ptr } %t24, i64 1)
  store i64 %t25, ptr %l17
  br label %bb10
bb10:
  %t26 = load i64, ptr %l17, !tbaa !24
  store i64 %t26, ptr %l3, !tbaa !24
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = icmp slt i64 %t27, 0
  br i1 %t29, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb14
bb12:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t35 = load i64, ptr %l3, !tbaa !24
  %t38 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s0, ptr %t34, i64 %t35)
  store ptr %t38, ptr %l24
  br label %bb13
bb13:
  %t39 = load ptr, ptr %l24, !tbaa !29
  %t41 = getelementptr %"compiler/ast:Func", ptr %t39, i32 0, i32 3
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/ast:Sig", ptr %t42, i32 0, i32 6
  %t45 = load i1, ptr %t44, !tbaa !21
  %t47 = xor i1 %t45, true
  store i1 %t47, ptr %l20, !tbaa !21
  br label %bb14
bb14:
  %t49 = load i1, ptr %l20, !tbaa !21
  br i1 %t49, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t51 = load i64, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t51, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econdOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l6 = alloca i32
  %l10 = alloca i1
  %l14 = alloca ptr
  %l16 = alloca %"compiler/source:Span"
  %l19 = alloca { i64, ptr }
  %l21 = alloca %"compiler/diagmsg:Msg"
  %l22 = alloca i64
  %l23 = alloca ptr
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca ptr
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t1)
  store i32 %t4, ptr %l6
  br label %bb1
bb1:
  %t5 = load i32, ptr %l6, !tbaa !23
  store i32 %t5, ptr %l3, !tbaa !23
  %t6 = load i32, ptr %l3, !tbaa !23
  %t7 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t10 = icmp ne i32 %t6, %t7
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i32, ptr %l3, !tbaa !23
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t16 = icmp ne i32 %t12, %t13
  store i1 %t16, ptr %l10, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l10, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l14, !tbaa !29
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t20)
  store %"compiler/source:Span" %t22, ptr %l16
  br label %bb7
bb6:
  br label %bb13
bb7:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l3, !tbaa !23
  %t27 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t23, i32 %t24)
  store { i64, ptr } %t27, ptr %l19
  br label %bb8
bb8:
  %t28 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  %t30 = extractvalue { i64, ptr } %t28, 1
  %t31 = mul i64 %t29, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t31)
  call void @llvm.memcpy.p0.p0.i64(ptr %t32, ptr %t30, i64 %t31, i1 false)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  %t36 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCondNotBoolType(ptr %s1, ptr %s1, { i64, ptr } %t34)
  store %"compiler/diagmsg:Msg" %t36, ptr %l21
  br label %bb9
bb9:
  %t37 = load ptr, ptr %l14, !tbaa !29
  %t38 = load %"compiler/source:Span", ptr %l16
  %t39 = load %"compiler/diagmsg:Msg", ptr %l21
  %t40 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t37, %"compiler/source:Span" %t38, %"compiler/diagmsg:Msg" %t39)
  store i64 %t40, ptr %l22
  br label %bb10
bb10:
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l23, !tbaa !29
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t42)
  store %"compiler/source:Span" %t44, ptr %l25
  br label %bb11
bb11:
  %t45 = load ptr, ptr %l23, !tbaa !29
  %t46 = load %"compiler/source:Span", ptr %l25
  %t47 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t45, %"compiler/source:Span" %t46)
  store ptr %t47, ptr %l26
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s1)
  %t48 = load ptr, ptr %l26, !tbaa !29
  store ptr %t48, ptr %rv
  br label %ret
bb13:
  %t49 = load ptr, ptr %l2, !tbaa !29
  store ptr %t49, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecountPost(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, i64, i64 }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l13 = alloca i64
  %l17 = alloca { i64, i64, i64 }
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca %"compiler/source:Span"
  %l24 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca %"compiler/source:Span"
  %l28 = alloca i32
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l36 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store ptr null, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 37
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l13
  br label %bb4
bb4:
  %t11 = load i64, ptr %l13, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load %"compiler/source:Span", ptr %l1
  %t17 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t12, i32 3, %"compiler/source:Span" %t13)
  store { i64, i64, i64 } %t17, ptr %l17
  br label %bb5
bb5:
  %t18 = load { i64, i64, i64 }, ptr %l17
  store { i64, i64, i64 } %t18, ptr %l4
  %t19 = getelementptr { i64, i64, i64 }, ptr %l4, i32 0, i32 0
  %t20 = load i64, ptr %t19, !tbaa !24
  store i64 %t20, ptr %l5, !tbaa !24
  %t22 = getelementptr { i64, i64, i64 }, ptr %l4, i32 0, i32 1
  %t23 = load i64, ptr %t22, !tbaa !24
  store i64 %t23, ptr %l6, !tbaa !24
  %t25 = getelementptr { i64, i64, i64 }, ptr %l4, i32 0, i32 2
  %t26 = load i64, ptr %t25, !tbaa !24
  store i64 %t26, ptr %l7, !tbaa !24
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l21, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l22, !tbaa !29
  %t30 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t30, ptr %l23
  %t31 = load i64, ptr %l2, !tbaa !24
  store i64 %t31, ptr %l24, !tbaa !24
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l25, !tbaa !29
  %t33 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t33, ptr %l26
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t34)
  store i32 %t36, ptr %l28
  br label %bb6
bb6:
  %t37 = load ptr, ptr %l25, !tbaa !29
  %t38 = load %"compiler/source:Span", ptr %l26
  %t39 = load i32, ptr %l28, !tbaa !23
  %t40 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t37, %"compiler/source:Span" %t38, i32 %t39, i64 1)
  store ptr %t40, ptr %l29
  br label %bb7
bb7:
  %t41 = load ptr, ptr %l22, !tbaa !29
  %t42 = load %"compiler/source:Span", ptr %l23
  %t43 = load i64, ptr %l24, !tbaa !24
  %t44 = load ptr, ptr %l29, !tbaa !29
  %t45 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eaddTo(ptr %v0, ptr %v0, ptr %v0, ptr %t41, %"compiler/source:Span" %t42, i64 %t43, ptr %t44)
  store ptr %t45, ptr %l30
  br label %bb8
bb8:
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t47 = load ptr, ptr %l30, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t46, ptr %t47)
  br label %bb9
bb9:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load i64, ptr %l5, !tbaa !24
  %t50 = load i64, ptr %l6, !tbaa !24
  %t51 = load i64, ptr %l7, !tbaa !24
  %t52 = load i64, ptr %l3, !tbaa !24
  %t58 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v1, ptr %t48, i64 %t49, i64 %t50, i64 %t51, i64 %t52)
  store ptr %t58, ptr %l36
  br label %bb10
bb10:
  %t59 = load ptr, ptr %l36, !tbaa !29
  store ptr %t59, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edestructs(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i32
  %l12 = alloca i1
  %l13 = alloca i1
  %l18 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l5, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t7, i32 %a1)
  store i32 %t11, ptr %l8
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l5, !tbaa !29
  %t13 = load i32, ptr %l8, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t14, ptr %l9
  br label %bb2
bb2:
  %t15 = load i32, ptr %l9, !tbaa !23
  store i32 %t15, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t16, i32 %t17)
  store i1 %t20, ptr %l12
  br label %bb3
bb3:
  %t21 = load i1, ptr %l12, !tbaa !21
  br i1 %t21, label %bb4, label %bb5
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l2, !tbaa !23
  %t31 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t27, i32 %t28)
  store i1 %t31, ptr %l18
  br label %bb6
bb5:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb7
bb6:
  %t32 = load i1, ptr %l18, !tbaa !21
  store i1 %t32, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t33 = load i1, ptr %l13, !tbaa !21
  store i1 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelseDropped(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l17 = alloca i1
  %l18 = alloca ptr
  %l26 = alloca i1
  %l27 = alloca ptr
  %l35 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 22}
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t18 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 0
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/load:Loader", ptr %t22, i32 0, i32 4
  %t25 = load ptr, ptr %t24, !tbaa !29
  store ptr %t25, ptr %l3, !tbaa !29
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t29 = getelementptr %"compiler/ast:If", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = icmp eq ptr %t30, null
  br i1 %t32, label %bb6, label %bb7
bb6:
  %t34 = load ptr, ptr %l3, !tbaa !29
  store ptr %t34, ptr %l18, !tbaa !29
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"compiler/ast:If", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = icmp eq ptr %t38, null
  br i1 %t40, label %bb8, label %bb9
bb7:
  %t42 = load ptr, ptr %l3, !tbaa !29
  store ptr %t42, ptr %l27, !tbaa !29
  %t43 = load ptr, ptr %l2, !tbaa !29
  %t45 = getelementptr %"compiler/ast:If", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = icmp eq ptr %t46, null
  br i1 %t48, label %bb12, label %bb13
bb8:
  call void @__olang_check_failed(ptr @olang_loc_9f409528a62be557_96e98ebb70e4ac13)
  unreachable
bb9:
  br label %bb10
bb10:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = getelementptr %"compiler/ast:If", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t56 = getelementptr %"compiler/ast:Branch", ptr %t53, i32 0, i32 2
  %t57 = load i64, ptr %t56, !tbaa !24
  %t58 = load ptr, ptr %l18, !tbaa !29
  %t60 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eIsDropped(ptr %v0, ptr %t58, i64 %t57)
  store i1 %t60, ptr %l26
  br label %bb11
bb11:
  %t61 = load i1, ptr %l26, !tbaa !21
  store i1 %t61, ptr %l17, !tbaa !21
  br label %bb16
bb12:
  call void @__olang_check_failed(ptr @olang_loc_9f409528a62be557_96e98ebb70e4ac13)
  unreachable
bb13:
  br label %bb14
bb14:
  %t62 = load ptr, ptr %l2, !tbaa !29
  %t64 = getelementptr %"compiler/ast:If", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t68 = getelementptr %"compiler/ast:Branch", ptr %t65, i32 0, i32 2
  %t69 = load i64, ptr %t68, !tbaa !24
  %t70 = load ptr, ptr %l27, !tbaa !29
  %t72 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eIsCut(ptr %v0, ptr %t70, i64 %t69)
  store i1 %t72, ptr %l35
  br label %bb15
bb15:
  %t73 = load i1, ptr %l35, !tbaa !21
  store i1 %t73, ptr %l17, !tbaa !21
  br label %bb16
bb16:
  %t74 = load i1, ptr %l17, !tbaa !21
  store i1 %t74, ptr %rv
  br label %ret
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i1 false, ptr %rv
  br label %ret
bb21:
  call void @__olang_check_failed(ptr @olang_loc_1bc36e5fea83eb2f_c65858cd7310966b)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeqMethod(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i64
  %l17 = alloca i1
  %l18 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca i32
  %l27 = alloca i32
  %l28 = alloca i64
  %l31 = alloca i1
  %l34 = alloca ptr
  %l37 = alloca ptr
  %l41 = alloca i32
  %l42 = alloca i32
  %l43 = alloca { i64, ptr }
  %l50 = alloca i64
  %l52 = alloca ptr
  %l56 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  store i32 %t5, ptr %l5, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/load:Loader", ptr %t12, i32 0, i32 3
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t15, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d21, i32 0, i32 1) })
  store i32 %t17, ptr %l10
  br label %bb1
bb1:
  %t18 = load ptr, ptr %l4, !tbaa !29
  %t19 = load i32, ptr %l5, !tbaa !23
  %t20 = load i32, ptr %l10, !tbaa !23
  %t21 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t18, i32 %t19, i32 %t20)
  store i64 %t21, ptr %l11
  br label %bb2
bb2:
  %t22 = load i64, ptr %l11, !tbaa !24
  store i64 %t22, ptr %l2, !tbaa !24
  %t23 = load i64, ptr %l2, !tbaa !24
  %t25 = icmp sge i64 %t23, 0
  br i1 %t25, label %bb3, label %bb4
bb3:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l1, !tbaa !23
  %t29 = load i64, ptr %l2, !tbaa !24
  %t33 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeqShaped(ptr %v0, ptr %t27, i32 %t28, i64 %t29)
  store i1 %t33, ptr %l17
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t34 = load i1, ptr %l17, !tbaa !21
  br i1 %t34, label %bb6, label %bb7
bb6:
  %t35 = load i64, ptr %l2, !tbaa !24
  store i64 %t35, ptr %l18, !tbaa !24
  br label %bb8
bb7:
  store i64 -1, ptr %l18, !tbaa !24
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t37 = load i64, ptr %l18, !tbaa !24
  store i64 %t37, ptr %rv
  br label %ret
bb9:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  store ptr %t41, ptr %l21, !tbaa !29
  %t42 = load i32, ptr %l1, !tbaa !23
  store i32 %t42, ptr %l22, !tbaa !23
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 0
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/load:Loader", ptr %t49, i32 0, i32 3
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t52, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store i32 %t54, ptr %l27
  br label %bb10
bb10:
  %t55 = load ptr, ptr %l21, !tbaa !29
  %t56 = load i32, ptr %l22, !tbaa !23
  %t57 = load i32, ptr %l27, !tbaa !23
  %t58 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t55, i32 %t56, i32 %t57)
  store i64 %t58, ptr %l28
  br label %bb11
bb11:
  %t59 = load i64, ptr %l28, !tbaa !24
  store i64 %t59, ptr %l2, !tbaa !24
  %t60 = load i64, ptr %l2, !tbaa !24
  %t62 = icmp slt i64 %t60, 0
  br i1 %t62, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb17
bb13:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  store ptr %t69, ptr %l34, !tbaa !29
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/check:Checker", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/generic:Program", ptr %t73, i32 0, i32 2
  store ptr %t75, ptr %l37, !tbaa !29
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t80 = load i64, ptr %l2, !tbaa !24
  %t83 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t79, i64 %t80)
  store i32 %t83, ptr %l41
  br label %bb14
bb14:
  %t84 = load ptr, ptr %l37, !tbaa !29
  %t85 = load i32, ptr %l41, !tbaa !23
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t84, i32 %t85)
  store i32 %t86, ptr %l42
  br label %bb15
bb15:
  %t87 = load ptr, ptr %l34, !tbaa !29
  %t88 = load i32, ptr %l42, !tbaa !23
  %t89 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t87, i32 %t88)
  store { i64, ptr } %t89, ptr %l43
  br label %bb16
bb16:
  %t90 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  %t93 = icmp ne i64 %t91, 2
  store i1 %t93, ptr %l31, !tbaa !21
  br label %bb17
bb17:
  %t95 = load i1, ptr %l31, !tbaa !21
  br i1 %t95, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t101 = load i64, ptr %l2, !tbaa !24
  %t104 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t100, i64 %t101)
  store i64 %t104, ptr %l50
  br label %bb21
bb21:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t105)
  store ptr %t107, ptr %l52
  br label %bb22
bb22:
  %t108 = load ptr, ptr %l52, !tbaa !29
  %t110 = getelementptr %"compiler/check:frame", ptr %t108, i32 0, i32 1
  %t111 = load i64, ptr %t110, !tbaa !24
  %t112 = load i64, ptr %l50, !tbaa !24
  %t114 = icmp eq i64 %t112, %t111
  br i1 %t114, label %bb23, label %bb24
bb23:
  %t116 = load i64, ptr %l2, !tbaa !24
  store i64 %t116, ptr %l56, !tbaa !24
  br label %bb25
bb24:
  store i64 -2, ptr %l56, !tbaa !24
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t118 = load i64, ptr %l56, !tbaa !24
  store i64 %t118, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrNarrowed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca i32
  %l8 = alloca i32
  %l13 = alloca i1
  %l15 = alloca i1
  %l17 = alloca ptr
  %l20 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i32
  %l29 = alloca i32
  %l30 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l32 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l35 = alloca i32
  %l40 = alloca ptr
  %l42 = alloca %"compiler/source:Span"
  %l46 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t1)
  store i32 %t4, ptr %l8
  br label %bb1
bb1:
  %t5 = load i32, ptr %l8, !tbaa !23
  store i32 %t5, ptr %l3, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 2
  %t12 = load i32, ptr %l3, !tbaa !23
  %t15 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %t11, i32 %t12)
  store i1 %t15, ptr %l13
  br label %bb2
bb2:
  %t16 = load i1, ptr %l13, !tbaa !21
  %t17 = xor i1 %t16, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb7
bb4:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t19)
  store ptr %t21, ptr %l17
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l17, !tbaa !29
  %t24 = getelementptr %"compiler/check:frame", ptr %t22, i32 0, i32 59
  %t26 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eLen__H3cdfcddd9c493bd8bcefc7b766e0438b(ptr %v0, ptr %t24)
  store i64 %t26, ptr %l20
  br label %bb6
bb6:
  %t27 = load i64, ptr %l20, !tbaa !24
  %t28 = icmp eq i64 %t27, 0
  store i1 %t28, ptr %l15, !tbaa !21
  br label %bb7
bb7:
  %t30 = load i1, ptr %l15, !tbaa !21
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t31 = load ptr, ptr %l1, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t31, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l23, !tbaa !29
  store i32 %a2, ptr %l24, !tbaa !23
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"compiler/generic:Program", ptr %t38, i32 0, i32 2
  %t41 = load i32, ptr %l3, !tbaa !23
  %t44 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t40, i32 %t41)
  store i32 %t44, ptr %l29
  br label %bb11
bb11:
  %t45 = load ptr, ptr %l23, !tbaa !29
  %t46 = load i32, ptr %l24, !tbaa !23
  %t47 = load i32, ptr %l29, !tbaa !23
  %t48 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrNow(ptr %v0, ptr %s0, ptr %t45, i32 %t46, i32 %t47)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t48, ptr %l30
  br label %bb12
bb12:
  %t49 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l30
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %l4
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  store ptr %t53, ptr %l32, !tbaa !29
  %t55 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %s0, ptr %l4)
  store { i64, ptr } %t55, ptr %l34
  br label %bb13
bb13:
  %t56 = load ptr, ptr %l32, !tbaa !29
  %t57 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t58 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrValOf(ptr %v0, ptr %s0, ptr %t56, { i64, ptr } %t57)
  store i32 %t58, ptr %l35
  br label %bb14
bb14:
  %t59 = load i32, ptr %l35, !tbaa !23
  store i32 %t59, ptr %l5, !tbaa !23
  %t60 = load i32, ptr %l5, !tbaa !23
  %t61 = load i32, ptr %l3, !tbaa !23
  %t64 = icmp eq i32 %t60, %t61
  br i1 %t64, label %bb15, label %bb16
bb15:
  %t66 = load ptr, ptr %l1, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t66, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t68 = load ptr, ptr %l0, !tbaa !29
  store ptr %t68, ptr %l40, !tbaa !29
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t71 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t69)
  store %"compiler/source:Span" %t71, ptr %l42
  br label %bb18
bb18:
  %t72 = load i32, ptr %l5, !tbaa !23
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t74 = load ptr, ptr %l40, !tbaa !29
  %t75 = load %"compiler/source:Span", ptr %l42
  %t79 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v1, ptr %v0, ptr %v2, ptr %t74, %"compiler/source:Span" %t75, i32 %t72, i32 20, ptr %t73, ptr null)
  store ptr %t79, ptr %l46
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  %t80 = load ptr, ptr %l46, !tbaa !29
  store ptr %t80, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrNow(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l6 = alloca ptr
  %l9 = alloca i64
  %l17 = alloca %"compiler/check:errNarrow"
  %l21 = alloca i1
  %l25 = alloca %"compiler/check:errNarrow"
  %l28 = alloca ptr
  %l32 = alloca %"compiler/check:errNarrow"
  %l34 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l39 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l6, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 59
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eLen__H3cdfcddd9c493bd8bcefc7b766e0438b(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l9
  br label %bb2
bb2:
  %t10 = load i64, ptr %l9, !tbaa !24
  %t11 = sub i64 %t10, 1
  store i64 %t11, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp sge i64 %t13, 0
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb4, label %bb5
bb4:
  br label %bb18
bb5:
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l3, !tbaa !29
  %t21 = getelementptr %"compiler/check:frame", ptr %t19, i32 0, i32 59
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = call %"compiler/check:errNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eAt_3ccompiler_2fcheck_3aerrNarrow_3e(ptr %v0, ptr %t21, i64 %t22)
  store %"compiler/check:errNarrow" %t25, ptr %l17
  br label %bb7
bb7:
  %t26 = getelementptr %"compiler/check:errNarrow", ptr %l17, i32 0, i32 0
  %t27 = load i32, ptr %t26, !tbaa !23
  %t31 = icmp eq i32 %t27, %a1
  br i1 %t31, label %bb8, label %bb9
bb8:
  %t33 = load ptr, ptr %l3, !tbaa !29
  %t35 = getelementptr %"compiler/check:frame", ptr %t33, i32 0, i32 59
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = call %"compiler/check:errNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eAt_3ccompiler_2fcheck_3aerrNarrow_3e(ptr %v0, ptr %t35, i64 %t36)
  store %"compiler/check:errNarrow" %t39, ptr %l25
  br label %bb10
bb9:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb11
bb10:
  %t40 = getelementptr %"compiler/check:errNarrow", ptr %l25, i32 0, i32 3
  %t41 = load i1, ptr %t40, !tbaa !21
  %t43 = xor i1 %t41, true
  store i1 %t43, ptr %l21, !tbaa !21
  br label %bb11
bb11:
  %t45 = load i1, ptr %l21, !tbaa !21
  br i1 %t45, label %bb12, label %bb13
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l28, !tbaa !29
  %t47 = load ptr, ptr %l3, !tbaa !29
  %t49 = getelementptr %"compiler/check:frame", ptr %t47, i32 0, i32 59
  %t50 = load i64, ptr %l4, !tbaa !24
  %t53 = call %"compiler/check:errNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eAt_3ccompiler_2fcheck_3aerrNarrow_3e(ptr %v0, ptr %t49, i64 %t50)
  store %"compiler/check:errNarrow" %t53, ptr %l32
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t54 = getelementptr %"compiler/check:errNarrow", ptr %l32, i32 0, i32 1
  %t55 = load i32, ptr %t54, !tbaa !23
  %t56 = load ptr, ptr %l28, !tbaa !29
  %t58 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetItems(ptr %v0, ptr %v1, ptr %t56, i32 %t55)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t58, ptr %l34
  br label %bb15
bb15:
  %t59 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t59, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t60 = load i64, ptr %l4, !tbaa !24
  %t62 = sub i64 %t60, 1
  store i64 %t62, ptr %l4, !tbaa !24
  br label %bb3
bb18:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t68 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetItems(ptr %v0, ptr %v1, ptr %t64, i32 %a2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t68, ptr %l39
  br label %bb19
bb19:
  %t69 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l39
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t69, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrRecode(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca i32
  %l9 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l15 = alloca ptr
  %rv = alloca ptr
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t1)
  store i32 %t4, ptr %l5
  br label %bb1
bb1:
  %t5 = load i32, ptr %l2, !tbaa !23
  %t6 = load i32, ptr %l5, !tbaa !23
  %t8 = icmp eq i32 %t6, %t5
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store ptr %a0, ptr %l9, !tbaa !29
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t13)
  store %"compiler/source:Span" %t15, ptr %l11
  br label %bb5
bb5:
  %t16 = load i32, ptr %l2, !tbaa !23
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t18 = load ptr, ptr %l9, !tbaa !29
  %t19 = load %"compiler/source:Span", ptr %l11
  %t23 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v1, ptr %v0, ptr %v2, ptr %t18, %"compiler/source:Span" %t19, i32 %t16, i32 20, ptr %t17, ptr null)
  store ptr %t23, ptr %l15
  br label %bb6
bb6:
  %t24 = load ptr, ptr %l15, !tbaa !29
  store ptr %t24, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrTest(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca ptr
  %l31 = alloca ptr
  %l34 = alloca ptr
  %l37 = alloca i32
  %l38 = alloca i32
  %l39 = alloca { i64, ptr }
  %l43 = alloca i32
  %l45 = alloca i64
  %l47 = alloca i64
  %l52 = alloca i32
  %l57 = alloca i32
  %l63 = alloca i64
  %l66 = alloca i64
  %l87 = alloca { i64, ptr }
  %l90 = alloca i32
  %l101 = alloca { i64, ptr }
  %l104 = alloca i64
  %l107 = alloca i64
  %l113 = alloca i64
  %l118 = alloca ptr
  %l119 = alloca %"compiler/source:Span"
  %l120 = alloca i32
  %l121 = alloca i32
  %l122 = alloca ptr
  %l126 = alloca ptr
  %l128 = alloca ptr
  %l129 = alloca ptr
  %l130 = alloca %"compiler/source:Span"
  %l131 = alloca i32
  %l132 = alloca i32
  %l133 = alloca ptr
  %l139 = alloca ptr
  %l141 = alloca ptr
  %l147 = alloca i64
  %l153 = alloca i64
  %l156 = alloca i64
  %l175 = alloca i64
  %l179 = alloca ptr
  %l180 = alloca %"compiler/source:Span"
  %l181 = alloca i32
  %l182 = alloca i32
  %l183 = alloca ptr
  %l184 = alloca ptr
  %l185 = alloca %"compiler/source:Span"
  %l188 = alloca i32
  %l194 = alloca ptr
  %l196 = alloca ptr
  %l199 = alloca ptr
  %l209 = alloca ptr
  %l217 = alloca ptr
  %l227 = alloca ptr
  %l236 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l31, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  store ptr %t12, ptr %l34, !tbaa !29
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t16 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t13)
  store i32 %t16, ptr %l37
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l34, !tbaa !29
  %t18 = load i32, ptr %l37, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t19, ptr %l38
  br label %bb2
bb2:
  %t20 = load ptr, ptr %l31, !tbaa !29
  %t21 = load i32, ptr %l38, !tbaa !23
  %t22 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t20, i32 %t21)
  store { i64, ptr } %t22, ptr %l39
  br label %bb3
bb3:
  %t23 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t23, ptr %l4, !tbaa !27
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t29, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d23, i32 0, i32 1) })
  store i32 %t31, ptr %l43
  br label %bb4
bb4:
  %t32 = load i32, ptr %l43, !tbaa !23
  store i32 %t32, ptr %l5, !tbaa !23
  store ptr null, ptr %l6, !tbaa !29
  store ptr %a3, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb5
bb5:
  %t35 = load i64, ptr %l8, !tbaa !24
  store i64 %t35, ptr %l45, !tbaa !24
  %t36 = load ptr, ptr %l7, !tbaa !29
  %t38 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t36)
  store i64 %t38, ptr %l47
  br label %bb6
bb6:
  %t39 = load i64, ptr %l45, !tbaa !24
  %t40 = load i64, ptr %l47, !tbaa !24
  %t41 = icmp slt i64 %t39, %t40
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb7, label %bb8
bb7:
  br label %bb72
bb8:
  br label %bb9
bb9:
  %t45 = load ptr, ptr %l7, !tbaa !29
  %t46 = load i64, ptr %l8, !tbaa !24
  %t49 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t45, i64 %t46)
  store i32 %t49, ptr %l52
  br label %bb10
bb10:
  %t50 = load i32, ptr %l52, !tbaa !23
  store i32 %t50, ptr %l9, !tbaa !23
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/check:Checker", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/generic:Program", ptr %t54, i32 0, i32 2
  %t57 = load i32, ptr %l9, !tbaa !23
  %t60 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t56, i32 %t57)
  store i32 %t60, ptr %l57
  br label %bb11
bb11:
  %t61 = load i32, ptr %l57, !tbaa !23
  store i32 %t61, ptr %l10, !tbaa !23
  store i64 -1, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  %t62 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t62, 0
  store i64 %t64, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t66 = load i64, ptr %l13, !tbaa !24
  %t67 = load i64, ptr %l12, !tbaa !24
  %t70 = icmp sgt i64 %t66, %t67
  br i1 %t70, label %bb12, label %bb13
bb12:
  %t72 = load i64, ptr %l14, !tbaa !24
  %t74 = icmp sgt i64 %t72, 0
  br i1 %t74, label %bb14, label %bb15
bb13:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb17
bb14:
  %t76 = load i64, ptr %l13, !tbaa !24
  %t77 = load i64, ptr %l12, !tbaa !24
  %t80 = sub i64 %t76, %t77
  %t81 = load i64, ptr %l14, !tbaa !24
  %t84 = add i64 %t80, %t81
  %t86 = sub i64 %t84, 1
  %t87 = load i64, ptr %l14, !tbaa !24
  %t90 = sdiv i64 %t86, %t87
  store i64 %t90, ptr %l66, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb16
bb16:
  %t92 = load i64, ptr %l66, !tbaa !24
  store i64 %t92, ptr %l63, !tbaa !24
  br label %bb17
bb17:
  %t93 = load i64, ptr %l63, !tbaa !24
  store i64 %t93, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb18
bb18:
  %t94 = load i64, ptr %l16, !tbaa !24
  %t95 = load i64, ptr %l15, !tbaa !24
  %t98 = icmp slt i64 %t94, %t95
  %t100 = xor i1 %t98, true
  br i1 %t100, label %bb19, label %bb20
bb19:
  br label %bb27
bb20:
  br label %bb21
bb21:
  %t102 = load i64, ptr %l12, !tbaa !24
  %t103 = load i64, ptr %l16, !tbaa !24
  %t104 = load i64, ptr %l14, !tbaa !24
  %t107 = mul i64 %t103, %t104
  %t110 = add i64 %t102, %t107
  store i64 %t110, ptr %l17, !tbaa !24
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/check:Checker", ptr %t112, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !29
  %t117 = getelementptr %"compiler/generic:Program", ptr %t115, i32 0, i32 2
  %t118 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t118, ptr %l87, !tbaa !27
  %t119 = load i64, ptr %l17, !tbaa !24
  %t121 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr i32, ptr %t122, i64 %t119
  %t124 = load i32, ptr %t123, !tbaa !33
  %t127 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t117, i32 %t124)
  store i32 %t127, ptr %l90
  br label %bb22
bb22:
  %t128 = load i32, ptr %l10, !tbaa !23
  %t129 = load i32, ptr %l90, !tbaa !23
  %t131 = icmp eq i32 %t129, %t128
  br i1 %t131, label %bb23, label %bb24
bb23:
  %t133 = load i64, ptr %l17, !tbaa !24
  store i64 %t133, ptr %l11, !tbaa !24
  br label %bb25
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t135 = load i64, ptr %l16, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l16, !tbaa !24
  br label %bb18
bb27:
  %t139 = load i64, ptr %l11, !tbaa !24
  %t141 = icmp slt i64 %t139, 0
  br i1 %t141, label %bb28, label %bb29
bb28:
  br label %bb71
bb29:
  br label %bb30
bb30:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/check:Checker", ptr %t143, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t148 = getelementptr %"compiler/generic:Program", ptr %t146, i32 0, i32 2
  %t149 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t149, ptr %l101, !tbaa !27
  %t150 = load i64, ptr %l11, !tbaa !24
  %t152 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = getelementptr i32, ptr %t153, i64 %t150
  %t155 = load i32, ptr %t154, !tbaa !33
  %t158 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t148, i32 %t155)
  store i64 %t158, ptr %l104
  br label %bb31
bb31:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load i32, ptr %l10, !tbaa !23
  %t163 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eallWords(ptr %v0, ptr %t159, i32 %t160)
  store i64 %t163, ptr %l107
  br label %bb32
bb32:
  %t164 = load i64, ptr %l104, !tbaa !65
  %t165 = load i64, ptr %l107, !tbaa !65
  %t166 = and i64 %t164, %t165
  store i64 %t166, ptr %l18, !tbaa !65
  store ptr null, ptr %l19, !tbaa !29
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/check:Checker", ptr %t168, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !29
  %t173 = getelementptr %"compiler/generic:Program", ptr %t171, i32 0, i32 2
  %t174 = load i32, ptr %l9, !tbaa !23
  %t177 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t173, i32 %t174)
  store i64 %t177, ptr %l113
  br label %bb33
bb33:
  %t178 = load i64, ptr %l18, !tbaa !65
  %t179 = load i64, ptr %l113, !tbaa !65
  %t181 = and i64 %t179, %t178
  %t182 = load i64, ptr %l18, !tbaa !65
  %t185 = icmp eq i64 %t181, %t182
  br i1 %t185, label %bb34, label %bb35
bb34:
  %t187 = load ptr, ptr %l0, !tbaa !29
  store ptr %t187, ptr %l118, !tbaa !29
  %t188 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t188, ptr %l119
  %t189 = load i32, ptr %l5, !tbaa !23
  store i32 %t189, ptr %l120, !tbaa !23
  store i32 9, ptr %l121
  %t190 = load ptr, ptr %l2, !tbaa !29
  store ptr %t190, ptr %l122, !tbaa !29
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t192 = load %"compiler/source:Span", ptr %l1
  %t193 = load i32, ptr %l5, !tbaa !23
  %t197 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t191, %"compiler/source:Span" %t192, i32 %t193, i64 16)
  store ptr %t197, ptr %l126
  br label %bb36
bb35:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/check:Checker", ptr %t198, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !29
  %t203 = getelementptr %"compiler/generic:Program", ptr %t201, i32 0, i32 2
  %t204 = load i32, ptr %l9, !tbaa !23
  %t207 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t203, i32 %t204)
  store i64 %t207, ptr %l147
  br label %bb40
bb36:
  %t208 = load ptr, ptr %l126, !tbaa !29
  %t209 = load ptr, ptr %l118, !tbaa !29
  %t210 = load %"compiler/source:Span", ptr %l119
  %t211 = load i32, ptr %l120, !tbaa !23
  %t212 = load i32, ptr %l121, !range !{i32 0, i32 46}
  %t213 = load ptr, ptr %l122, !tbaa !29
  %t215 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v1, ptr %v0, ptr %v3, ptr %t209, %"compiler/source:Span" %t210, i32 %t211, i32 %t212, ptr %t213, ptr %t208)
  store ptr %t215, ptr %l128
  br label %bb37
bb37:
  %t216 = load ptr, ptr %l128, !tbaa !29
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l129, !tbaa !29
  %t218 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t218, ptr %l130
  %t219 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t219, ptr %l131, !tbaa !23
  store i32 13, ptr %l132
  store ptr %t216, ptr %l133, !tbaa !29
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load %"compiler/source:Span", ptr %l1
  %t223 = load i32, ptr %l5, !tbaa !23
  %t224 = load i64, ptr %l11, !tbaa !24
  %t226 = add i64 %t224, 1
  %t231 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t221, %"compiler/source:Span" %t222, i32 %t223, i64 %t226)
  store ptr %t231, ptr %l139
  br label %bb38
bb38:
  %t232 = load ptr, ptr %l139, !tbaa !29
  %t233 = load ptr, ptr %l129, !tbaa !29
  %t234 = load %"compiler/source:Span", ptr %l130
  %t235 = load i32, ptr %l131, !tbaa !23
  %t236 = load i32, ptr %l132, !range !{i32 0, i32 46}
  %t237 = load ptr, ptr %l133, !tbaa !29
  %t239 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v3, ptr %v0, ptr %v3, ptr %t233, %"compiler/source:Span" %t234, i32 %t235, i32 %t236, ptr %t237, ptr %t232)
  store ptr %t239, ptr %l141
  br label %bb39
bb39:
  %t240 = load ptr, ptr %l141, !tbaa !29
  store ptr %t240, ptr %l19, !tbaa !29
  br label %bb63
bb40:
  %t242 = load i64, ptr %l18, !tbaa !65
  %t243 = load i64, ptr %l147, !tbaa !65
  %t245 = and i64 %t243, %t242
  store i64 %t245, ptr %l21, !tbaa !65
  store i64 0, ptr %l22, !tbaa !24
  store i64 64, ptr %l23, !tbaa !24
  store i64 1, ptr %l24, !tbaa !24
  %t247 = load i64, ptr %l23, !tbaa !24
  %t248 = load i64, ptr %l22, !tbaa !24
  %t251 = icmp sgt i64 %t247, %t248
  br i1 %t251, label %bb41, label %bb42
bb41:
  %t253 = load i64, ptr %l24, !tbaa !24
  %t255 = icmp sgt i64 %t253, 0
  br i1 %t255, label %bb43, label %bb44
bb42:
  store i64 0, ptr %l153, !tbaa !24
  br label %bb46
bb43:
  %t257 = load i64, ptr %l23, !tbaa !24
  %t258 = load i64, ptr %l22, !tbaa !24
  %t261 = sub i64 %t257, %t258
  %t262 = load i64, ptr %l24, !tbaa !24
  %t265 = add i64 %t261, %t262
  %t267 = sub i64 %t265, 1
  %t268 = load i64, ptr %l24, !tbaa !24
  %t271 = sdiv i64 %t267, %t268
  store i64 %t271, ptr %l156, !tbaa !24
  br label %bb45
bb44:
  store i64 0, ptr %l156, !tbaa !24
  br label %bb45
bb45:
  %t273 = load i64, ptr %l156, !tbaa !24
  store i64 %t273, ptr %l153, !tbaa !24
  br label %bb46
bb46:
  %t274 = load i64, ptr %l153, !tbaa !24
  store i64 %t274, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  br label %bb47
bb47:
  %t275 = load i64, ptr %l26, !tbaa !24
  %t276 = load i64, ptr %l25, !tbaa !24
  %t279 = icmp slt i64 %t275, %t276
  %t281 = xor i1 %t279, true
  br i1 %t281, label %bb48, label %bb49
bb48:
  br label %bb62
bb49:
  br label %bb50
bb50:
  %t283 = load i64, ptr %l22, !tbaa !24
  %t284 = load i64, ptr %l26, !tbaa !24
  %t285 = load i64, ptr %l24, !tbaa !24
  %t288 = mul i64 %t284, %t285
  %t291 = add i64 %t283, %t288
  store i64 %t291, ptr %l27, !tbaa !24
  %t293 = load i64, ptr %l21, !tbaa !65
  %t294 = load i64, ptr %l27, !tbaa !24
  store i64 %t294, ptr %l175, !tbaa !24
  %t295 = load i64, ptr %l175, !tbaa !24
  %t296 = load i64, ptr %l175, !tbaa !24
  %t297 = shl i64 1, %t296
  %t300 = and i64 %t293, %t297
  %t302 = icmp eq i64 %t300, 0
  br i1 %t302, label %bb51, label %bb52
bb51:
  br label %bb61
bb52:
  br label %bb53
bb53:
  %t304 = load ptr, ptr %l0, !tbaa !29
  store ptr %t304, ptr %l179, !tbaa !29
  %t305 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t305, ptr %l180
  %t306 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t306, ptr %l181, !tbaa !23
  store i32 13, ptr %l182
  %t307 = load ptr, ptr %l2, !tbaa !29
  store ptr %t307, ptr %l183, !tbaa !29
  %t308 = load ptr, ptr %l0, !tbaa !29
  store ptr %t308, ptr %l184, !tbaa !29
  %t309 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t309, ptr %l185
  %t310 = load ptr, ptr %l2, !tbaa !29
  %t313 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t310)
  store i32 %t313, ptr %l188
  br label %bb54
bb54:
  %t314 = load i64, ptr %l11, !tbaa !24
  %t316 = add i64 %t314, 1
  %t318 = shl i64 %t316, 16
  %t319 = load i64, ptr %l27, !tbaa !24
  %t322 = or i64 %t318, %t319
  %t323 = load ptr, ptr %l184, !tbaa !29
  %t324 = load %"compiler/source:Span", ptr %l185
  %t325 = load i32, ptr %l188, !tbaa !23
  %t327 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t323, %"compiler/source:Span" %t324, i32 %t325, i64 %t322)
  store ptr %t327, ptr %l194
  br label %bb55
bb55:
  %t328 = load ptr, ptr %l194, !tbaa !29
  %t329 = load ptr, ptr %l179, !tbaa !29
  %t330 = load %"compiler/source:Span", ptr %l180
  %t331 = load i32, ptr %l181, !tbaa !23
  %t332 = load i32, ptr %l182, !range !{i32 0, i32 46}
  %t333 = load ptr, ptr %l183, !tbaa !29
  %t335 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v1, ptr %v0, ptr %v3, ptr %t329, %"compiler/source:Span" %t330, i32 %t331, i32 %t332, ptr %t333, ptr %t328)
  store ptr %t335, ptr %l196
  br label %bb56
bb56:
  %t336 = load ptr, ptr %l196, !tbaa !29
  store ptr %t336, ptr %l28, !tbaa !29
  %t337 = load ptr, ptr %l19, !tbaa !29
  %t339 = icmp eq ptr %t337, null
  br i1 %t339, label %bb57, label %bb58
bb57:
  %t341 = load ptr, ptr %l28, !tbaa !29
  store ptr %t341, ptr %l199, !tbaa !29
  br label %bb60
bb58:
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t345 = load %"compiler/source:Span", ptr %l1
  %t346 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t347 = load ptr, ptr %l19, !tbaa !29
  %t348 = load ptr, ptr %l28, !tbaa !29
  %t356 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v3, ptr %v3, ptr %v3, ptr %t344, %"compiler/source:Span" %t345, i32 %t346, i32 11, ptr %t347, ptr %t348)
  store ptr %t356, ptr %l209
  br label %bb59
bb59:
  %t357 = load ptr, ptr %l209, !tbaa !29
  store ptr %t357, ptr %l199, !tbaa !29
  br label %bb60
bb60:
  %t359 = load ptr, ptr %l199, !tbaa !29
  store ptr %t359, ptr %l19, !tbaa !29
  br label %bb61
bb61:
  %t360 = load i64, ptr %l26, !tbaa !24
  %t362 = add i64 %t360, 1
  store i64 %t362, ptr %l26, !tbaa !24
  br label %bb47
bb62:
  br label %bb63
bb63:
  %t364 = load ptr, ptr %l19, !tbaa !29
  %t366 = icmp eq ptr %t364, null
  br i1 %t366, label %bb64, label %bb65
bb64:
  br label %bb71
bb65:
  br label %bb66
bb66:
  %t368 = load ptr, ptr %l6, !tbaa !29
  %t370 = icmp eq ptr %t368, null
  br i1 %t370, label %bb67, label %bb68
bb67:
  %t372 = load ptr, ptr %l19, !tbaa !29
  store ptr %t372, ptr %l217, !tbaa !29
  br label %bb70
bb68:
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t376 = load %"compiler/source:Span", ptr %l1
  %t377 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t378 = load ptr, ptr %l6, !tbaa !29
  %t379 = load ptr, ptr %l19, !tbaa !29
  %t387 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v3, ptr %v3, ptr %v3, ptr %t375, %"compiler/source:Span" %t376, i32 %t377, i32 11, ptr %t378, ptr %t379)
  store ptr %t387, ptr %l227
  br label %bb69
bb69:
  %t388 = load ptr, ptr %l227, !tbaa !29
  store ptr %t388, ptr %l217, !tbaa !29
  br label %bb70
bb70:
  %t390 = load ptr, ptr %l217, !tbaa !29
  store ptr %t390, ptr %l6, !tbaa !29
  br label %bb71
bb71:
  %t391 = load i64, ptr %l8, !tbaa !24
  %t393 = add i64 %t391, 1
  store i64 %t393, ptr %l8, !tbaa !24
  br label %bb5
bb72:
  %t395 = load ptr, ptr %l6, !tbaa !29
  %t397 = icmp eq ptr %t395, null
  br i1 %t397, label %bb73, label %bb74
bb73:
  %t399 = load ptr, ptr %l0, !tbaa !29
  %t400 = load %"compiler/source:Span", ptr %l1
  %t401 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t405 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t399, %"compiler/source:Span" %t400, i32 %t401, i64 0)
  store ptr %t405, ptr %l236
  br label %bb75
bb74:
  br label %bb76
bb75:
  call void @__olang_scope_close(ptr %s0)
  %t406 = load ptr, ptr %l236, !tbaa !29
  store ptr %t406, ptr %rv
  br label %ret
bb76:
  %t407 = load ptr, ptr %l6, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t407, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexplicitArgs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i32
  %l30 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l38 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l40 = alloca i64
  %l42 = alloca i64
  %l46 = alloca i64
  %l51 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l58 = alloca %"compiler/source:Span"
  %l60 = alloca %"compiler/diagmsg:Msg"
  %l61 = alloca i64
  %l67 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca { i64, ptr }
  %l73 = alloca %"compiler/source:Span"
  %l75 = alloca %"compiler/diagmsg:Msg"
  %l76 = alloca i64
  %l83 = alloca ptr
  %l84 = alloca { i64, ptr }
  %l86 = alloca %"compiler/source:Span"
  %l90 = alloca %"compiler/diagmsg:Msg"
  %l91 = alloca i64
  %l98 = alloca i64
  %l100 = alloca i64
  %l105 = alloca i64
  %l114 = alloca i64
  %l115 = alloca i32
  %l123 = alloca i64
  %l126 = alloca i64
  %l145 = alloca { i64, ptr }
  %l149 = alloca i32
  %l156 = alloca { i64, ptr }
  %l159 = alloca i64
  %l167 = alloca { i64, ptr }
  %l168 = alloca i64
  %l170 = alloca ptr
  %l172 = alloca ptr
  %l175 = alloca { i64, ptr }
  %l178 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t208 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = icmp sge i64 0, 0
  br i1 %t5, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t7 = icmp sle i64 0, 2305843009213693951
  br i1 %t7, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_92689d3fb9399c33_8949aa7cd18a1ac7)
  unreachable
bb5:
  %t9 = mul i64 0, 4
  %t10 = insertvalue { i64, ptr } undef, i64 0, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t11, ptr %rv
  br label %ret
bb6:
  call void @__olang_check_failed(ptr @olang_loc_92689d3fb9399c33_8949aa7cd18a1ac7)
  unreachable
bb7:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t16, i64 %t17)
  store ptr %t20, ptr %l30
  br label %bb8
bb8:
  %t21 = load ptr, ptr %l30, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/ast:Func", ptr %t21, i32 0, i32 2
  %t26 = load i32, ptr %t25, !tbaa !23
  %t29 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t22, i32 %t26)
  store { i64, ptr } %t29, ptr %l34
  br label %bb9
bb9:
  %t30 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t30, ptr %l5, !tbaa !27
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t35 = load i64, ptr %l1, !tbaa !24
  %t38 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eOwnVarIndexes(ptr %v0, ptr %s0, ptr %t34, i64 %t35)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t38, ptr %l38
  br label %bb10
bb10:
  %t39 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l38
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %l6
  %t41 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l6)
  store i64 %t41, ptr %l40
  br label %bb11
bb11:
  %t42 = load i64, ptr %l40, !tbaa !24
  store i64 %t42, ptr %l7, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t45 = call i64 @compiler_2fgeneric_2eWrittenTypes(ptr %v1, { i64, ptr } %t43)
  store i64 %t45, ptr %l42
  br label %bb12
bb12:
  %t46 = load i64, ptr %l42, !tbaa !24
  store i64 %t46, ptr %l8, !tbaa !24
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t51 = load i64, ptr %l1, !tbaa !24
  %t54 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrVarIndex(ptr %v0, ptr %t50, i64 %t51)
  store i64 %t54, ptr %l46
  br label %bb13
bb13:
  %t55 = load i64, ptr %l46, !tbaa !24
  store i64 %t55, ptr %l9, !tbaa !24
  %t56 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t56, 0
  %t59 = load i64, ptr %l8, !tbaa !24
  %t62 = icmp sgt i64 %t58, %t59
  br i1 %t62, label %bb14, label %bb15
bb14:
  %t64 = load i64, ptr %l9, !tbaa !24
  %t66 = icmp slt i64 %t64, 0
  store i1 %t66, ptr %l51, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb16
bb16:
  %t68 = load i1, ptr %l51, !tbaa !21
  br i1 %t68, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s2
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l54, !tbaa !29
  %t70 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t70, ptr %l55, !tbaa !27
  %t71 = load i64, ptr %l8, !tbaa !24
  %t73 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr ptr, ptr %t74, i64 %t71
  %t76 = load ptr, ptr %t75, !tbaa !39
  %t78 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t76)
  store %"compiler/source:Span" %t78, ptr %l58
  br label %bb19
bb18:
  br label %bb26
bb19:
  %t79 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t81 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrSetArgUnwanted(ptr %v0, ptr %s2, { i64, ptr } %t79)
  store %"compiler/diagmsg:Msg" %t81, ptr %l60
  br label %bb20
bb20:
  %t82 = load ptr, ptr %l54, !tbaa !29
  %t83 = load %"compiler/source:Span", ptr %l58
  %t84 = load %"compiler/diagmsg:Msg", ptr %l60
  %t85 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t82, %"compiler/source:Span" %t83, %"compiler/diagmsg:Msg" %t84)
  store i64 %t85, ptr %l61
  br label %bb21
bb21:
  %t86 = icmp sge i64 0, 0
  br i1 %t86, label %bb22, label %bb23
bb22:
  %t88 = icmp sle i64 0, 2305843009213693951
  br i1 %t88, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_3150b71fd0fb46fe_3d08923418e7b7d2)
  unreachable
bb24:
  %t90 = mul i64 0, 4
  %t91 = insertvalue { i64, ptr } undef, i64 0, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t92, ptr %rv
  br label %ret
bb25:
  call void @__olang_check_failed(ptr @olang_loc_3150b71fd0fb46fe_3d08923418e7b7d2)
  unreachable
bb26:
  %t94 = load i64, ptr %l7, !tbaa !24
  %t96 = icmp eq i64 %t94, 0
  br i1 %t96, label %bb27, label %bb28
bb27:
  %t98 = load i64, ptr %l8, !tbaa !24
  %t100 = icmp sgt i64 %t98, 0
  store i1 %t100, ptr %l67, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb29
bb29:
  %t102 = load i1, ptr %l67, !tbaa !21
  br i1 %t102, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s3
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l70, !tbaa !29
  %t104 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t104, ptr %l71, !tbaa !27
  %t105 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr ptr, ptr %t106, i64 0
  %t108 = load ptr, ptr %t107, !tbaa !39
  %t110 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t108)
  store %"compiler/source:Span" %t110, ptr %l73
  br label %bb32
bb31:
  br label %bb39
bb32:
  %t111 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t113 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeArgsOnNonGeneric(ptr %v0, ptr %s3, { i64, ptr } %t111)
  store %"compiler/diagmsg:Msg" %t113, ptr %l75
  br label %bb33
bb33:
  %t114 = load ptr, ptr %l70, !tbaa !29
  %t115 = load %"compiler/source:Span", ptr %l73
  %t116 = load %"compiler/diagmsg:Msg", ptr %l75
  %t117 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t114, %"compiler/source:Span" %t115, %"compiler/diagmsg:Msg" %t116)
  store i64 %t117, ptr %l76
  br label %bb34
bb34:
  %t118 = icmp sge i64 0, 0
  br i1 %t118, label %bb35, label %bb36
bb35:
  %t120 = icmp sle i64 0, 2305843009213693951
  br i1 %t120, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_d7e03fe7b4bf2c3d_64b0c57621292c71)
  unreachable
bb37:
  %t122 = mul i64 0, 4
  %t123 = insertvalue { i64, ptr } undef, i64 0, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t124, ptr %rv
  br label %ret
bb38:
  call void @__olang_check_failed(ptr @olang_loc_d7e03fe7b4bf2c3d_64b0c57621292c71)
  unreachable
bb39:
  %t126 = load i64, ptr %l7, !tbaa !24
  %t127 = load i64, ptr %l8, !tbaa !24
  %t130 = icmp ne i64 %t126, %t127
  br i1 %t130, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s4
  %t132 = load ptr, ptr %l0, !tbaa !29
  store ptr %t132, ptr %l83, !tbaa !29
  %t133 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t133, ptr %l84, !tbaa !27
  %t134 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = getelementptr ptr, ptr %t135, i64 0
  %t137 = load ptr, ptr %t136, !tbaa !39
  %t139 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t137)
  store %"compiler/source:Span" %t139, ptr %l86
  br label %bb42
bb41:
  br label %bb49
bb42:
  %t140 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t141 = load i64, ptr %l7, !tbaa !24
  %t142 = load i64, ptr %l8, !tbaa !24
  %t146 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeArgCount(ptr %v0, ptr %s4, { i64, ptr } %t140, i64 %t141, i64 %t142)
  store %"compiler/diagmsg:Msg" %t146, ptr %l90
  br label %bb43
bb43:
  %t147 = load ptr, ptr %l83, !tbaa !29
  %t148 = load %"compiler/source:Span", ptr %l86
  %t149 = load %"compiler/diagmsg:Msg", ptr %l90
  %t150 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t147, %"compiler/source:Span" %t148, %"compiler/diagmsg:Msg" %t149)
  store i64 %t150, ptr %l91
  br label %bb44
bb44:
  %t151 = icmp sge i64 0, 0
  br i1 %t151, label %bb45, label %bb46
bb45:
  %t153 = icmp sle i64 0, 2305843009213693951
  br i1 %t153, label %bb47, label %bb48
bb46:
  call void @__olang_check_failed(ptr @olang_loc_c902484ee6860410_648a649019eab164)
  unreachable
bb47:
  %t155 = mul i64 0, 4
  %t156 = insertvalue { i64, ptr } undef, i64 0, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t157, ptr %rv
  br label %ret
bb48:
  call void @__olang_check_failed(ptr @olang_loc_c902484ee6860410_648a649019eab164)
  unreachable
bb49:
  %t159 = load i64, ptr %l9, !tbaa !24
  %t161 = add i64 %t159, 1
  store i64 %t161, ptr %l10, !tbaa !24
  store ptr %l6, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb50
bb50:
  %t164 = load i64, ptr %l12, !tbaa !24
  store i64 %t164, ptr %l98, !tbaa !24
  %t165 = load ptr, ptr %l11, !tbaa !29
  %t167 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t165)
  store i64 %t167, ptr %l100
  br label %bb51
bb51:
  %t168 = load i64, ptr %l98, !tbaa !24
  %t169 = load i64, ptr %l100, !tbaa !24
  %t170 = icmp slt i64 %t168, %t169
  %t172 = xor i1 %t170, true
  br i1 %t172, label %bb52, label %bb53
bb52:
  br label %bb60
bb53:
  br label %bb54
bb54:
  %t174 = load ptr, ptr %l11, !tbaa !29
  %t175 = load i64, ptr %l12, !tbaa !24
  %t178 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t174, i64 %t175)
  store i64 %t178, ptr %l105
  br label %bb55
bb55:
  %t179 = load i64, ptr %l105, !tbaa !24
  store i64 %t179, ptr %l13, !tbaa !24
  %t180 = load i64, ptr %l13, !tbaa !24
  %t182 = add i64 %t180, 1
  %t183 = load i64, ptr %l10, !tbaa !24
  %t186 = icmp sgt i64 %t182, %t183
  br i1 %t186, label %bb56, label %bb57
bb56:
  %t188 = load i64, ptr %l13, !tbaa !24
  %t190 = add i64 %t188, 1
  store i64 %t190, ptr %l10, !tbaa !24
  br label %bb58
bb57:
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t192 = load i64, ptr %l12, !tbaa !24
  %t194 = add i64 %t192, 1
  store i64 %t194, ptr %l12, !tbaa !24
  br label %bb50
bb60:
  %t196 = load i64, ptr %l10, !tbaa !24
  store i64 %t196, ptr %l114, !tbaa !24
  %t197 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t197, ptr %l115, !tbaa !23
  %t198 = load i64, ptr %l114, !tbaa !24
  %t199 = icmp sge i64 %t198, 0
  br i1 %t199, label %bb61, label %bb62
bb61:
  %t201 = load i64, ptr %l114, !tbaa !24
  %t202 = icmp sle i64 %t201, 2305843009213693951
  br i1 %t202, label %bb63, label %bb64
bb62:
  call void @__olang_check_failed(ptr @olang_loc_e4324c4b30f6563f_ec149b7f01d5683b)
  unreachable
bb63:
  %t204 = load i64, ptr %l114, !tbaa !24
  %t205 = mul i64 %t204, 4
  %t206 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t205)
  %t207 = load i32, ptr %l115, !tbaa !23
  store i64 0, ptr %t208
  br label %fill.209
fill.209:
  %t212 = load i64, ptr %t208
  %t213 = icmp slt i64 %t212, %t204
  br i1 %t213, label %fillb.210, label %filld.211
fillb.210:
  %t214 = getelementptr i32, ptr %t206, i64 %t212
  store i32 %t207, ptr %t214
  %t215 = add i64 %t212, 1
  store i64 %t215, ptr %t208
  br label %fill.209
filld.211:
  %t216 = insertvalue { i64, ptr } undef, i64 %t204, 0
  %t217 = insertvalue { i64, ptr } %t216, ptr %t206, 1
  store { i64, ptr } %t217, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t219 = load i64, ptr %l7, !tbaa !24
  store i64 %t219, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t221 = load i64, ptr %l16, !tbaa !24
  %t222 = load i64, ptr %l15, !tbaa !24
  %t225 = icmp sgt i64 %t221, %t222
  br i1 %t225, label %bb65, label %bb66
bb64:
  call void @__olang_check_failed(ptr @olang_loc_e4324c4b30f6563f_ec149b7f01d5683b)
  unreachable
bb65:
  %t227 = load i64, ptr %l17, !tbaa !24
  %t229 = icmp sgt i64 %t227, 0
  br i1 %t229, label %bb67, label %bb68
bb66:
  store i64 0, ptr %l123, !tbaa !24
  br label %bb70
bb67:
  %t231 = load i64, ptr %l16, !tbaa !24
  %t232 = load i64, ptr %l15, !tbaa !24
  %t235 = sub i64 %t231, %t232
  %t236 = load i64, ptr %l17, !tbaa !24
  %t239 = add i64 %t235, %t236
  %t241 = sub i64 %t239, 1
  %t242 = load i64, ptr %l17, !tbaa !24
  %t245 = sdiv i64 %t241, %t242
  store i64 %t245, ptr %l126, !tbaa !24
  br label %bb69
bb68:
  store i64 0, ptr %l126, !tbaa !24
  br label %bb69
bb69:
  %t247 = load i64, ptr %l126, !tbaa !24
  store i64 %t247, ptr %l123, !tbaa !24
  br label %bb70
bb70:
  %t248 = load i64, ptr %l123, !tbaa !24
  store i64 %t248, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb71
bb71:
  %t249 = load i64, ptr %l19, !tbaa !24
  %t250 = load i64, ptr %l18, !tbaa !24
  %t253 = icmp slt i64 %t249, %t250
  %t255 = xor i1 %t253, true
  br i1 %t255, label %bb72, label %bb73
bb72:
  br label %bb85
bb73:
  br label %bb74
bb74:
  %t257 = load i64, ptr %l15, !tbaa !24
  %t258 = load i64, ptr %l19, !tbaa !24
  %t259 = load i64, ptr %l17, !tbaa !24
  %t262 = mul i64 %t258, %t259
  %t265 = add i64 %t257, %t262
  store i64 %t265, ptr %l20, !tbaa !24
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t268 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t268, ptr %l145, !tbaa !27
  %t269 = load i64, ptr %l20, !tbaa !24
  %t271 = getelementptr { i64, ptr }, ptr %l145, i32 0, i32 1
  %t272 = load ptr, ptr %t271, !tbaa !27
  %t273 = getelementptr ptr, ptr %t272, i64 %t269
  %t274 = load ptr, ptr %t273, !tbaa !39
  %t278 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %t267, ptr %t274)
  store i32 %t278, ptr %l149
  br label %bb75
bb75:
  %t279 = load i32, ptr %l149, !tbaa !23
  store i32 %t279, ptr %l21, !tbaa !23
  %t280 = load i32, ptr %l21, !tbaa !23
  %t281 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t284 = icmp eq i32 %t280, %t281
  br i1 %t284, label %bb76, label %bb77
bb76:
  %t286 = icmp sge i64 0, 0
  br i1 %t286, label %bb78, label %bb79
bb77:
  br label %bb82
bb78:
  %t288 = icmp sle i64 0, 2305843009213693951
  br i1 %t288, label %bb80, label %bb81
bb79:
  call void @__olang_check_failed(ptr @olang_loc_2e16a6af4c93cb6a_eec2ff8433b844a6)
  unreachable
bb80:
  %t290 = mul i64 0, 4
  %t291 = insertvalue { i64, ptr } undef, i64 0, 0
  %t292 = insertvalue { i64, ptr } %t291, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t292, ptr %rv
  br label %ret
bb81:
  call void @__olang_check_failed(ptr @olang_loc_2e16a6af4c93cb6a_eec2ff8433b844a6)
  unreachable
bb82:
  %t294 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t294, ptr %l156, !tbaa !27
  %t295 = load i64, ptr %l20, !tbaa !24
  %t298 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l6, i64 %t295)
  store i64 %t298, ptr %l159
  br label %bb83
bb83:
  %t299 = load i32, ptr %l21, !tbaa !23
  %t301 = load i64, ptr %l159, !tbaa !24
  %t302 = getelementptr { i64, ptr }, ptr %l156, i32 0, i32 1
  %t303 = load ptr, ptr %t302, !tbaa !27
  %t304 = getelementptr i32, ptr %t303, i64 %t301
  store i32 %t299, ptr %t304, !tbaa !33
  br label %bb84
bb84:
  %t305 = load i64, ptr %l19, !tbaa !24
  %t307 = add i64 %t305, 1
  store i64 %t307, ptr %l19, !tbaa !24
  br label %bb71
bb85:
  %t309 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t311 = extractvalue { i64, ptr } %t309, 0
  %t312 = load i64, ptr %l8, !tbaa !24
  %t315 = icmp sgt i64 %t311, %t312
  br i1 %t315, label %bb86, label %bb87
bb86:
  %t317 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t317, ptr %l167, !tbaa !27
  %t318 = load i64, ptr %l9, !tbaa !24
  store i64 %t318, ptr %l168, !tbaa !24
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t321 = getelementptr %"compiler/check:Checker", ptr %t319, i32 0, i32 1
  %t322 = load ptr, ptr %t321, !tbaa !29
  store ptr %t322, ptr %l170, !tbaa !29
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t325 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t323)
  store ptr %t325, ptr %l172
  br label %bb88
bb87:
  br label %bb90
bb88:
  %t326 = load ptr, ptr %l172, !tbaa !29
  %t328 = getelementptr %"compiler/check:frame", ptr %t326, i32 0, i32 4
  %t329 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t329, ptr %l175, !tbaa !27
  %t330 = load i64, ptr %l8, !tbaa !24
  %t332 = getelementptr { i64, ptr }, ptr %l175, i32 0, i32 1
  %t333 = load ptr, ptr %t332, !tbaa !27
  %t334 = getelementptr ptr, ptr %t333, i64 %t330
  %t335 = load ptr, ptr %t334, !tbaa !39
  %t336 = load ptr, ptr %l170, !tbaa !29
  %t339 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrsArgOf(ptr %v0, ptr %v0, ptr %v1, ptr %t336, ptr %t328, ptr %t335)
  store i32 %t339, ptr %l178
  br label %bb89
bb89:
  %t340 = load i32, ptr %l178, !tbaa !23
  %t341 = load i64, ptr %l168, !tbaa !24
  %t342 = getelementptr { i64, ptr }, ptr %l167, i32 0, i32 1
  %t343 = load ptr, ptr %t342, !tbaa !27
  %t344 = getelementptr i32, ptr %t343, i64 %t341
  store i32 %t340, ptr %t344, !tbaa !33
  br label %bb90
bb90:
  %t345 = load { i64, ptr }, ptr %l14, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t345, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprPattern(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i32 %a3, ptr %a4, i64 %a5, i1 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l7 = alloca i32
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca i32
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca i32
  %l19 = alloca i32
  %l21 = alloca %"compiler/source:Span"
  %l22 = alloca ptr
  %l23 = alloca i1
  %l34 = alloca { i64, ptr }
  %l35 = alloca i1
  %l39 = alloca ptr
  %l49 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca i1
  %l57 = alloca i64
  %l64 = alloca ptr
  %l65 = alloca ptr
  %l66 = alloca i1
  %l76 = alloca i64
  %l79 = alloca ptr
  %l80 = alloca %"compiler/source:Span"
  %l81 = alloca ptr
  %l82 = alloca i64
  %l85 = alloca { i64, ptr }
  %l90 = alloca ptr
  %l93 = alloca i32
  %l96 = alloca ptr
  %l97 = alloca %"compiler/source:Span"
  %l98 = alloca ptr
  %l99 = alloca i32
  %l102 = alloca { i64, ptr }
  %l107 = alloca ptr
  %l110 = alloca i1
  %l113 = alloca i32
  %l116 = alloca ptr
  %l118 = alloca %"compiler/source:Span"
  %l119 = alloca ptr
  %l122 = alloca i32
  %l123 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l127 = alloca { i64, ptr }
  %l129 = alloca %"compiler/diagmsg:Msg"
  %l130 = alloca i64
  %l134 = alloca ptr
  %l140 = alloca ptr
  %s2 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca ptr
  %t55 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l3, !tbaa !23
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l19
  br label %bb1
bb1:
  %t6 = load i32, ptr %l19, !tbaa !23
  store i32 %t6, ptr %l7, !tbaa !23
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t7)
  store %"compiler/source:Span" %t9, ptr %l21
  br label %bb2
bb2:
  %t10 = load %"compiler/source:Span", ptr %l21
  store %"compiler/source:Span" %t10, ptr %l8
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t12 = load ptr, ptr %l22, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l22, !tbaa !29
  %t16 = load i64, ptr %t15, !range !{i64 0, i64 30}
  %t18 = icmp eq i64 %t16, 0
  store i1 %t18, ptr %l23, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l23, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32 }, ptr %t22, i32 0, i32 0
  %t24 = load %"compiler/source:Span", ptr %t23
  store %"compiler/source:Span" %t24, ptr %l9
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr { i64, [4 x i64] }, ptr %t26, i32 0, i32 1
  %t29 = getelementptr { %"compiler/source:Span", i32 }, ptr %t28, i32 0, i32 1
  %t30 = load i32, ptr %t29
  store i32 %t30, ptr %l10, !tbaa !23
  br label %bb7
bb6:
  br label %bb18
bb7:
  %t34 = xor i1 %a6, true
  br i1 %t34, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l10, !tbaa !23
  %t40 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t36, i32 %t37)
  store { i64, ptr } %t40, ptr %l34
  br label %bb10
bb9:
  br label %bb17
bb10:
  %t41 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t42 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t41, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) })
  store i1 %t42, ptr %l35
  br label %bb11
bb11:
  %t43 = load i1, ptr %l35, !tbaa !21
  br i1 %t43, label %bb12, label %bb13
bb12:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load %"compiler/source:Span", ptr %l9
  %t46 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t50 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v4, ptr %t44, %"compiler/source:Span" %t45, i32 %t46, i64 1)
  store ptr %t50, ptr %l39
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  %t51 = load ptr, ptr %l39, !tbaa !29
  store ptr %t51, ptr %rv
  br label %ret
bb15:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load %"compiler/source:Span", ptr %l9
  %t54 = load i32, ptr %l10, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t55
  %t56 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 0
  store i64 3, ptr %t56
  %t58 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t53, 0
  %t60 = insertvalue { %"compiler/source:Span", i32 } %t58, i32 %t54, 1
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t60, ptr %t61
  %t62 = load { i64, [4 x i64] }, ptr %t55
  %t64 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 40, i64 8)
  store { i64, [4 x i64] } %t62, ptr %t64
  %t65 = load ptr, ptr %l2, !tbaa !29
  %t66 = load i32, ptr %l3, !tbaa !23
  %t67 = load ptr, ptr %l4, !tbaa !29
  %t68 = load i64, ptr %l5, !tbaa !24
  %t75 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epattern(ptr %v0, ptr %v4, ptr %v2, ptr %v3, ptr %v4, ptr %t52, ptr %t64, ptr %t65, i32 %t66, ptr %t67, i64 %t68)
  store ptr %t75, ptr %l49
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  %t76 = load ptr, ptr %l49, !tbaa !29
  store ptr %t76, ptr %rv
  br label %ret
bb17:
  br label %bb67
bb18:
  %t77 = load ptr, ptr %l1, !tbaa !29
  store ptr %t77, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t78 = load ptr, ptr %l50, !tbaa !29
  %t79 = icmp ne ptr %t78, null
  br i1 %t79, label %bb19, label %bb20
bb19:
  %t81 = load ptr, ptr %l50, !tbaa !29
  %t82 = load i64, ptr %t81, !range !{i64 0, i64 30}
  %t84 = icmp eq i64 %t82, 14
  store i1 %t84, ptr %l51, !tbaa !21
  br label %bb20
bb20:
  %t85 = load i1, ptr %l51, !tbaa !21
  br i1 %t85, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb29
bb23:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t88 = load i32, ptr %l7, !tbaa !23
  %t92 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %t86, ptr %t87, i32 %t88)
  store i64 %t92, ptr %l57
  br label %bb24
bb24:
  %t93 = load i64, ptr %l57, !tbaa !24
  store i64 %t93, ptr %l11, !tbaa !24
  %t94 = load i64, ptr %l11, !tbaa !24
  %t96 = icmp sge i64 %t94, 0
  br i1 %t96, label %bb25, label %bb26
bb25:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load %"compiler/source:Span", ptr %l8
  %t100 = load ptr, ptr %l2, !tbaa !29
  %t101 = load i64, ptr %l11, !tbaa !24
  %t106 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCase(ptr %v0, ptr %v2, ptr %v4, ptr %t98, %"compiler/source:Span" %t99, ptr %t100, i64 %t101)
  store ptr %t106, ptr %l64
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t107 = load ptr, ptr %l64, !tbaa !29
  store ptr %t107, ptr %rv
  br label %ret
bb28:
  br label %bb67
bb29:
  %t108 = load ptr, ptr %l1, !tbaa !29
  store ptr %t108, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t109 = load ptr, ptr %l65, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb30, label %bb31
bb30:
  %t112 = load ptr, ptr %l65, !tbaa !29
  %t113 = load i64, ptr %t112, !range !{i64 0, i64 30}
  %t115 = icmp eq i64 %t113, 12
  store i1 %t115, ptr %l66, !tbaa !21
  br label %bb31
bb31:
  %t116 = load i1, ptr %l66, !tbaa !21
  br i1 %t116, label %bb32, label %bb33
bb32:
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr { i64, [4 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t119, i32 0, i32 1
  %t121 = load ptr, ptr %t120
  store ptr %t121, ptr %l12, !tbaa !29
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr { i64, [4 x i64] }, ptr %t123, i32 0, i32 1
  %t126 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t125, i32 0, i32 2
  %t127 = load { i64, ptr }, ptr %t126
  store { i64, ptr } %t127, ptr %l13, !tbaa !27
  br label %bb34
bb33:
  br label %bb62
bb34:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load ptr, ptr %l12, !tbaa !29
  %t131 = load i32, ptr %l7, !tbaa !23
  %t135 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %t129, ptr %t130, i32 %t131)
  store i64 %t135, ptr %l76
  br label %bb35
bb35:
  %t136 = load i64, ptr %l76, !tbaa !24
  store i64 %t136, ptr %l14, !tbaa !24
  %t137 = load i64, ptr %l14, !tbaa !24
  %t139 = icmp sge i64 %t137, 0
  br i1 %t139, label %bb36, label %bb37
bb36:
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l79, !tbaa !29
  %t142 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t142, ptr %l80
  %t143 = load ptr, ptr %l12, !tbaa !29
  store ptr %t143, ptr %l81, !tbaa !29
  %t144 = load i64, ptr %l14, !tbaa !24
  store i64 %t144, ptr %l82, !tbaa !24
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t149 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargPatterns(ptr %v0, ptr %v1, ptr %v1, ptr %t145, { i64, ptr } %t146)
  store { i64, ptr } %t149, ptr %l85
  br label %bb38
bb37:
  br label %bb40
bb38:
  %t150 = load ptr, ptr %l2, !tbaa !29
  %t151 = load i32, ptr %l3, !tbaa !23
  %t152 = load ptr, ptr %l4, !tbaa !29
  %t153 = load i64, ptr %l5, !tbaa !24
  %t154 = load ptr, ptr %l79, !tbaa !29
  %t155 = load %"compiler/source:Span", ptr %l80
  %t156 = load ptr, ptr %l81, !tbaa !29
  %t157 = load i64, ptr %l82, !tbaa !24
  %t158 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t163 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epayloadPattern(ptr %v0, ptr %v1, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t154, %"compiler/source:Span" %t155, ptr %t156, i64 %t157, { i64, ptr } %t158, ptr %t150, i32 %t151, ptr %t152, i64 %t153)
  store ptr %t163, ptr %l90
  br label %bb39
bb39:
  %t164 = load ptr, ptr %l90, !tbaa !29
  store ptr %t164, ptr %rv
  br label %ret
bb40:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load ptr, ptr %l12, !tbaa !29
  %t169 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estructDecl(ptr %v0, ptr %v1, ptr %t165, ptr %t166)
  store i32 %t169, ptr %l93
  br label %bb41
bb41:
  %t170 = load i32, ptr %l93, !tbaa !23
  store i32 %t170, ptr %l15, !tbaa !23
  %t171 = load i32, ptr %l15, !tbaa !23
  %t173 = icmp sge i32 %t171, 0
  br i1 %t173, label %bb42, label %bb43
bb42:
  %t175 = load ptr, ptr %l0, !tbaa !29
  store ptr %t175, ptr %l96, !tbaa !29
  %t176 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t176, ptr %l97
  %t177 = load ptr, ptr %l12, !tbaa !29
  store ptr %t177, ptr %l98, !tbaa !29
  %t178 = load i32, ptr %l15, !tbaa !23
  store i32 %t178, ptr %l99, !tbaa !23
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t183 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargPatterns(ptr %v0, ptr %v1, ptr %v1, ptr %t179, { i64, ptr } %t180)
  store { i64, ptr } %t183, ptr %l102
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t184 = load ptr, ptr %l2, !tbaa !29
  %t185 = load i32, ptr %l3, !tbaa !23
  %t186 = load ptr, ptr %l4, !tbaa !29
  %t187 = load i64, ptr %l5, !tbaa !24
  %t188 = load ptr, ptr %l96, !tbaa !29
  %t189 = load %"compiler/source:Span", ptr %l97
  %t190 = load ptr, ptr %l98, !tbaa !29
  %t191 = load i32, ptr %l99, !tbaa !23
  %t192 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t197 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estructPattern(ptr %v0, ptr %v1, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t188, %"compiler/source:Span" %t189, ptr %t190, i32 %t191, { i64, ptr } %t192, ptr %t184, i32 %t185, ptr %t186, i64 %t187)
  store ptr %t197, ptr %l107
  br label %bb45
bb45:
  %t198 = load ptr, ptr %l107, !tbaa !29
  store ptr %t198, ptr %rv
  br label %ret
bb46:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load ptr, ptr %l12, !tbaa !29
  %t203 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseWritten(ptr %v0, ptr %v1, ptr %t199, ptr %t200)
  store i1 %t203, ptr %l110
  br label %bb47
bb47:
  %t204 = load i1, ptr %l110, !tbaa !21
  br i1 %t204, label %bb48, label %bb49
bb48:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load ptr, ptr %l12, !tbaa !29
  %t209 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenEnum(ptr %v0, ptr %v1, ptr %t205, ptr %t206)
  store i32 %t209, ptr %l113
  br label %bb50
bb49:
  br label %bb61
bb50:
  %t210 = load i32, ptr %l113, !tbaa !23
  store i32 %t210, ptr %l16, !tbaa !23
  %t211 = load i32, ptr %l16, !tbaa !23
  %t213 = icmp sge i32 %t211, 0
  br i1 %t213, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s10
  %t215 = load ptr, ptr %l0, !tbaa !29
  store ptr %t215, ptr %l116, !tbaa !29
  %t216 = load ptr, ptr %l1, !tbaa !29
  %t218 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t216)
  store %"compiler/source:Span" %t218, ptr %l118
  br label %bb53
bb52:
  br label %bb60
bb53:
  %t219 = load ptr, ptr %l0, !tbaa !29
  store ptr %t219, ptr %l119, !tbaa !29
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load i32, ptr %l3, !tbaa !23
  %t224 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t220, i32 %t221)
  store i32 %t224, ptr %l122
  br label %bb54
bb54:
  %t225 = load ptr, ptr %l119, !tbaa !29
  %t226 = load i32, ptr %l122, !tbaa !23
  %t227 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s10, ptr %t225, i32 %t226)
  store { i64, ptr } %t227, ptr %l123
  br label %bb55
bb55:
  %t228 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t229 = extractvalue { i64, ptr } %t228, 0
  %t230 = extractvalue { i64, ptr } %t228, 1
  %t231 = mul i64 %t229, 1
  %t232 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t231)
  call void @llvm.memcpy.p0.p0.i64(ptr %t232, ptr %t230, i64 %t231, i1 false)
  %t233 = insertvalue { i64, ptr } undef, i64 %t229, 0
  %t234 = insertvalue { i64, ptr } %t233, ptr %t232, 1
  store { i64, ptr } %t234, ptr %l124, !tbaa !27
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load i32, ptr %l16, !tbaa !23
  %t239 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s10, ptr %t235, i32 %t236)
  store { i64, ptr } %t239, ptr %l127
  br label %bb56
bb56:
  %t240 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t241 = extractvalue { i64, ptr } %t240, 0
  %t242 = extractvalue { i64, ptr } %t240, 1
  %t243 = mul i64 %t241, 1
  %t244 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t243)
  call void @llvm.memcpy.p0.p0.i64(ptr %t244, ptr %t242, i64 %t243, i1 false)
  %t245 = insertvalue { i64, ptr } undef, i64 %t241, 0
  %t246 = insertvalue { i64, ptr } %t245, ptr %t244, 1
  %t247 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t249 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaseValueType(ptr %s10, ptr %s10, ptr %s10, { i64, ptr } %t247, { i64, ptr } %t246)
  store %"compiler/diagmsg:Msg" %t249, ptr %l129
  br label %bb57
bb57:
  %t250 = load ptr, ptr %l116, !tbaa !29
  %t251 = load %"compiler/source:Span", ptr %l118
  %t252 = load %"compiler/diagmsg:Msg", ptr %l129
  %t253 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s10, ptr %t250, %"compiler/source:Span" %t251, %"compiler/diagmsg:Msg" %t252)
  store i64 %t253, ptr %l130
  br label %bb58
bb58:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = load %"compiler/source:Span", ptr %l8
  %t256 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t260 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v4, ptr %t254, %"compiler/source:Span" %t255, i32 %t256, i64 0)
  store ptr %t260, ptr %l134
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s10)
  %t261 = load ptr, ptr %l134, !tbaa !29
  store ptr %t261, ptr %rv
  br label %ret
bb60:
  br label %bb61
bb61:
  br label %bb67
bb62:
  br i1 true, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb67
bb66:
  call void @__olang_check_failed(ptr @olang_loc_d21fae414ff68ab0_be44aac3c4a6c53c)
  unreachable
bb67:
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t263 = load %"compiler/source:Span", ptr %l8
  %t264 = load ptr, ptr %l2, !tbaa !29
  %t265 = load ptr, ptr %l1, !tbaa !29
  %t266 = load i32, ptr %l3, !tbaa !23
  %t272 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTest(ptr %v0, ptr %v2, ptr %v1, ptr %v4, ptr %t262, %"compiler/source:Span" %t263, ptr %t264, ptr %t265, i32 %t266)
  store ptr %t272, ptr %l140
  br label %bb68
bb68:
  %t273 = load ptr, ptr %l140, !tbaa !29
  store ptr %t273, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldTypes(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i1
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l15 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca i64
  %l31 = alloca i64
  %l34 = alloca i64
  %l43 = alloca i64
  %l46 = alloca i64
  %l65 = alloca { i64, ptr }
  %l69 = alloca ptr
  %l71 = alloca ptr
  %l74 = alloca i32
  %l76 = alloca %"compiler/typed:Local"
  %l78 = alloca { i64, ptr }
  %l83 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca i32
  %l100 = alloca i32
  %l105 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l15, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l20
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l15, !tbaa !29
  %t18 = load i32, ptr %l20, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t17, i32 %t18)
  store { i64, ptr } %t19, ptr %l21
  br label %bb2
bb2:
  %t20 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t20, ptr %l2, !tbaa !27
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t21)
  store ptr %t23, ptr %l23
  br label %bb3
bb3:
  %t24 = load ptr, ptr %l23, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Body", ptr %t24, i32 0, i32 10
  %t27 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t26
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t27, ptr %l25
  %t29 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l25)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %l27
  br label %bb4
bb4:
  %t30 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %l3
  %t31 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  store i64 %t33, ptr %l29, !tbaa !24
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l3)
  store i64 %t35, ptr %l31
  br label %bb5
bb5:
  %t36 = load i64, ptr %l29, !tbaa !24
  %t37 = load i64, ptr %l31, !tbaa !24
  %t38 = icmp ne i64 %t36, %t37
  br i1 %t38, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  br label %bb8
bb8:
  %t40 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t40, 0
  store i64 %t42, ptr %l34, !tbaa !24
  %t43 = load i64, ptr %l34, !tbaa !24
  %t44 = icmp sge i64 %t43, 0
  br i1 %t44, label %bb9, label %bb10
bb9:
  %t46 = load i64, ptr %l34, !tbaa !24
  %t47 = icmp sle i64 %t46, 2305843009213693951
  br i1 %t47, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_ad8923f011cb5acf_6f8a151e60866063)
  unreachable
bb11:
  %t49 = load i64, ptr %l34, !tbaa !24
  %t50 = mul i64 %t49, 4
  %t51 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t50)
  %t52 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t51, 1
  store { i64, ptr } %t53, ptr %l4, !tbaa !27
  store i1 false, ptr %l5, !tbaa !21
  store i64 0, ptr %l6, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 0
  store i64 %t57, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t59 = load i64, ptr %l7, !tbaa !24
  %t60 = load i64, ptr %l6, !tbaa !24
  %t63 = icmp sgt i64 %t59, %t60
  br i1 %t63, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_ad8923f011cb5acf_6f8a151e60866063)
  unreachable
bb13:
  %t65 = load i64, ptr %l8, !tbaa !24
  %t67 = icmp sgt i64 %t65, 0
  br i1 %t67, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb18
bb15:
  %t69 = load i64, ptr %l7, !tbaa !24
  %t70 = load i64, ptr %l6, !tbaa !24
  %t73 = sub i64 %t69, %t70
  %t74 = load i64, ptr %l8, !tbaa !24
  %t77 = add i64 %t73, %t74
  %t79 = sub i64 %t77, 1
  %t80 = load i64, ptr %l8, !tbaa !24
  %t83 = sdiv i64 %t79, %t80
  store i64 %t83, ptr %l46, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb17
bb17:
  %t85 = load i64, ptr %l46, !tbaa !24
  store i64 %t85, ptr %l43, !tbaa !24
  br label %bb18
bb18:
  %t86 = load i64, ptr %l43, !tbaa !24
  store i64 %t86, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb19
bb19:
  %t87 = load i64, ptr %l10, !tbaa !24
  %t88 = load i64, ptr %l9, !tbaa !24
  %t91 = icmp slt i64 %t87, %t88
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb20, label %bb21
bb20:
  br label %bb33
bb21:
  br label %bb22
bb22:
  %t95 = load i64, ptr %l6, !tbaa !24
  %t96 = load i64, ptr %l10, !tbaa !24
  %t97 = load i64, ptr %l8, !tbaa !24
  %t100 = mul i64 %t96, %t97
  %t103 = add i64 %t95, %t100
  store i64 %t103, ptr %l11, !tbaa !24
  %t105 = load i64, ptr %l11, !tbaa !24
  %t106 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t106, ptr %l65, !tbaa !27
  %t107 = load i64, ptr %l11, !tbaa !24
  %t109 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr i32, ptr %t110, i64 %t107
  %t112 = load i32, ptr %t111, !tbaa !33
  %t115 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr i32, ptr %t116, i64 %t105
  store i32 %t112, ptr %t117, !tbaa !33
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t118)
  store ptr %t120, ptr %l69
  br label %bb23
bb23:
  %t121 = load ptr, ptr %l69, !tbaa !29
  %t123 = getelementptr %"compiler/typed:Body", ptr %t121, i32 0, i32 7
  store ptr %t123, ptr %l71, !tbaa !29
  %t124 = load i64, ptr %l11, !tbaa !24
  %t127 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l3, i64 %t124)
  store i32 %t127, ptr %l74
  br label %bb24
bb24:
  %t128 = load i32, ptr %l74, !tbaa !23
  %t129 = sext i32 %t128 to i64
  %t130 = load ptr, ptr %l71, !tbaa !29
  %t132 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t130, i64 %t129)
  store %"compiler/typed:Local" %t132, ptr %l76
  br label %bb25
bb25:
  %t133 = getelementptr %"compiler/typed:Local", ptr %l76, i32 0, i32 2
  %t134 = load i32, ptr %t133, !tbaa !23
  store i32 %t134, ptr %l12, !tbaa !23
  %t136 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t136, ptr %l78, !tbaa !27
  %t137 = load i64, ptr %l11, !tbaa !24
  %t139 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !27
  %t141 = getelementptr i32, ptr %t140, i64 %t137
  %t142 = load i32, ptr %t141, !tbaa !33
  %t143 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t146 = icmp eq i32 %t142, %t143
  br i1 %t146, label %bb26, label %bb27
bb26:
  %t148 = load i32, ptr %l12, !tbaa !23
  %t149 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t152 = icmp ne i32 %t148, %t149
  store i1 %t152, ptr %l83, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l83, !tbaa !21
  br label %bb28
bb28:
  %t154 = load i1, ptr %l83, !tbaa !21
  br i1 %t154, label %bb29, label %bb30
bb29:
  %t155 = load i64, ptr %l11, !tbaa !24
  %t156 = load i32, ptr %l12, !tbaa !23
  %t159 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr i32, ptr %t160, i64 %t155
  store i32 %t156, ptr %t161, !tbaa !33
  store i1 true, ptr %l5, !tbaa !21
  br label %bb31
bb30:
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t162 = load i64, ptr %l10, !tbaa !24
  %t164 = add i64 %t162, 1
  store i64 %t164, ptr %l10, !tbaa !24
  br label %bb19
bb33:
  %t166 = load i1, ptr %l5, !tbaa !21
  br i1 %t166, label %bb34, label %bb35
bb34:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/check:Checker", ptr %t168, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !29
  %t173 = getelementptr %"compiler/generic:Program", ptr %t171, i32 0, i32 2
  store ptr %t173, ptr %l94, !tbaa !29
  %t174 = load i32, ptr %l1, !tbaa !23
  store i32 %t174, ptr %l95, !tbaa !23
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/check:Checker", ptr %t175, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !29
  %t180 = getelementptr %"compiler/generic:Program", ptr %t178, i32 0, i32 2
  %t181 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t184 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t180, { i64, ptr } %t181)
  store i32 %t184, ptr %l100
  br label %bb36
bb35:
  br label %bb39
bb36:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/check:Checker", ptr %t185, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !29
  %t190 = getelementptr %"compiler/generic:Program", ptr %t188, i32 0, i32 2
  %t191 = load i32, ptr %l1, !tbaa !23
  %t194 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDtorWritten(ptr %v0, ptr %t190, i32 %t191)
  store i1 %t194, ptr %l105
  br label %bb37
bb37:
  %t195 = load ptr, ptr %l94, !tbaa !29
  %t196 = load i32, ptr %l95, !tbaa !23
  %t197 = load i32, ptr %l100, !tbaa !23
  %t198 = load i1, ptr %l105, !tbaa !21
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetStructBody(ptr %v0, ptr %t195, i32 %t196, i32 %t197, i1 %t198)
  br label %bb38
bb38:
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l8 = alloca i1
  %l12 = alloca i1
  %l13 = alloca i1
  %l14 = alloca ptr
  %l19 = alloca i32
  %l21 = alloca i1
  %l27 = alloca i32
  %l30 = alloca i1
  %l35 = alloca i32
  %l42 = alloca i32
  %l44 = alloca i1
  %l48 = alloca i1
  %l53 = alloca ptr
  %l58 = alloca i32
  %l63 = alloca i32
  %l64 = alloca i1
  %l65 = alloca i1
  %l66 = alloca ptr
  %l71 = alloca i32
  %l76 = alloca i32
  %l77 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t8 = load i32, ptr %l2, !tbaa !23
  %t12 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t6, i32 %t7, i32 %t8)
  store i1 %t12, ptr %l8
  br label %bb1
bb1:
  %t13 = load i1, ptr %l8, !tbaa !21
  br i1 %t13, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l1, !tbaa !23
  %t19 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisOver(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l12
  br label %bb5
bb5:
  %t20 = load i1, ptr %l12, !tbaa !21
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l14, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l1, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l19
  br label %bb8
bb7:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb10
bb8:
  %t32 = load i32, ptr %l2, !tbaa !23
  %t33 = load ptr, ptr %l14, !tbaa !29
  %t34 = load i32, ptr %l19, !tbaa !23
  %t36 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %t33, i32 %t34, i32 %t32)
  store i1 %t36, ptr %l21
  br label %bb9
bb9:
  %t37 = load i1, ptr %l21, !tbaa !21
  store i1 %t37, ptr %l13, !tbaa !21
  br label %bb10
bb10:
  %t38 = load i1, ptr %l13, !tbaa !21
  br i1 %t38, label %bb11, label %bb12
bb11:
  store i1 true, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/check:Checker", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/generic:Program", ptr %t43, i32 0, i32 2
  %t46 = load i32, ptr %l1, !tbaa !23
  %t49 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t45, i32 %t46)
  store i32 %t49, ptr %l27
  br label %bb14
bb14:
  %t50 = load i32, ptr %l27, !range !{i32 0, i32 33}
  %t52 = trunc i64 19 to i32
  %t53 = icmp eq i32 %t50, %t52
  br i1 %t53, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = getelementptr %"compiler/generic:Program", ptr %t58, i32 0, i32 2
  %t61 = load i32, ptr %l2, !tbaa !23
  %t64 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t60, i32 %t61)
  store i32 %t64, ptr %l35
  br label %bb17
bb16:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb18
bb17:
  %t65 = load i32, ptr %l35, !range !{i32 0, i32 33}
  %t67 = trunc i64 19 to i32
  %t68 = icmp eq i32 %t65, %t67
  store i1 %t68, ptr %l30, !tbaa !21
  br label %bb18
bb18:
  %t70 = load i1, ptr %l30, !tbaa !21
  br i1 %t70, label %bb19, label %bb20
bb19:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 2
  %t77 = load i32, ptr %l2, !tbaa !23
  %t80 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t76, i32 %t77)
  store i32 %t80, ptr %l42
  br label %bb21
bb20:
  br label %bb38
bb21:
  %t81 = load i32, ptr %l42, !tbaa !23
  %t82 = icmp ne i32 %t81, 0
  br i1 %t82, label %bb22, label %bb23
bb22:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i32, ptr %l1, !tbaa !23
  %t86 = load i32, ptr %l2, !tbaa !23
  %t90 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elengthsMeet(ptr %v0, ptr %t84, i32 %t85, i32 %t86)
  store i1 %t90, ptr %l48
  br label %bb24
bb23:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb25
bb24:
  %t91 = load i1, ptr %l48, !tbaa !21
  %t92 = xor i1 %t91, true
  store i1 %t92, ptr %l44, !tbaa !21
  br label %bb25
bb25:
  %t94 = load i1, ptr %l44, !tbaa !21
  br i1 %t94, label %bb26, label %bb27
bb26:
  store i1 false, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/check:Checker", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/generic:Program", ptr %t99, i32 0, i32 2
  store ptr %t101, ptr %l53, !tbaa !29
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/check:Checker", ptr %t102, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = getelementptr %"compiler/generic:Program", ptr %t105, i32 0, i32 2
  %t108 = load i32, ptr %l1, !tbaa !23
  %t111 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t107, i32 %t108)
  store i32 %t111, ptr %l58
  br label %bb29
bb29:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/check:Checker", ptr %t112, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !29
  %t117 = getelementptr %"compiler/generic:Program", ptr %t115, i32 0, i32 2
  %t118 = load i32, ptr %l2, !tbaa !23
  %t121 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t117, i32 %t118)
  store i32 %t121, ptr %l63
  br label %bb30
bb30:
  %t122 = load ptr, ptr %l53, !tbaa !29
  %t123 = load i32, ptr %l58, !tbaa !23
  %t124 = load i32, ptr %l63, !tbaa !23
  %t125 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t122, i32 %t123, i32 %t124)
  store i1 %t125, ptr %l64
  br label %bb31
bb31:
  %t126 = load i1, ptr %l64, !tbaa !21
  br i1 %t126, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb37
bb33:
  %t127 = load ptr, ptr %l0, !tbaa !29
  store ptr %t127, ptr %l66, !tbaa !29
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/check:Checker", ptr %t128, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !29
  %t133 = getelementptr %"compiler/generic:Program", ptr %t131, i32 0, i32 2
  %t134 = load i32, ptr %l1, !tbaa !23
  %t137 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t133, i32 %t134)
  store i32 %t137, ptr %l71
  br label %bb34
bb34:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/check:Checker", ptr %t138, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t143 = getelementptr %"compiler/generic:Program", ptr %t141, i32 0, i32 2
  %t144 = load i32, ptr %l2, !tbaa !23
  %t147 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t143, i32 %t144)
  store i32 %t147, ptr %l76
  br label %bb35
bb35:
  %t148 = load ptr, ptr %l66, !tbaa !29
  %t149 = load i32, ptr %l71, !tbaa !23
  %t150 = load i32, ptr %l76, !tbaa !23
  %t151 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %t148, i32 %t149, i32 %t150)
  store i1 %t151, ptr %l77
  br label %bb36
bb36:
  %t152 = load i1, ptr %l77, !tbaa !21
  store i1 %t152, ptr %l65, !tbaa !21
  br label %bb37
bb37:
  %t153 = load i1, ptr %l65, !tbaa !21
  store i1 %t153, ptr %rv
  br label %ret
bb38:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenEnd(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l2 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t8 = alloca { i64, [3 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %"compiler/source:Span" %a1, ptr %l2
  %t4 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t7 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s0, ptr %s0, ptr %t5, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d25, i32 0, i32 1) }, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d26, i32 0, i32 1) })
  store i32 %t7, ptr %l5
  br label %bb1
bb1:
  store { i64, [3 x i64] } zeroinitializer, ptr %t8
  %t9 = getelementptr { i64, [3 x i64] }, ptr %t8, i32 0, i32 0
  store i64 7, ptr %t9
  %t10 = load %"compiler/source:Span", ptr %l2
  %t11 = insertvalue { %"compiler/source:Span", i32, i64 } undef, %"compiler/source:Span" %t10, 0
  %t12 = load i32, ptr %l5, !tbaa !23
  %t13 = insertvalue { %"compiler/source:Span", i32, i64 } %t11, i32 %t12, 1
  %t14 = insertvalue { %"compiler/source:Span", i32, i64 } %t13, i64 0, 2
  %t15 = getelementptr { i64, [3 x i64] }, ptr %t8, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64 } %t14, ptr %t15
  %t16 = load { i64, [3 x i64] }, ptr %t8
  %t18 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store { i64, [3 x i64] } %t16, ptr %t18
  call void @__olang_scope_close(ptr %s0)
  store ptr %t18, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egeneratorCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i64
  %l16 = alloca i1
  %l18 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i64 @compiler_2ftyped_2eCalledBody(ptr %v1, ptr %a1)
  store i64 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i64, ptr %l5, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp slt i64 %t5, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 14
  %t13 = load i64, ptr %l2, !tbaa !24
  %t16 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t12, i64 %t13)
  store ptr %t16, ptr %l12
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l12, !tbaa !29
  %t18 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eInst(ptr %v0, ptr %t17)
  store i64 %t18, ptr %l13
  br label %bb6
bb6:
  %t19 = load i64, ptr %l13, !tbaa !24
  store i64 %t19, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = icmp sge i64 %t20, 0
  br i1 %t22, label %bb7, label %bb8
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  store ptr %t27, ptr %l18, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t32 = load i64, ptr %l3, !tbaa !24
  %t35 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t31, i64 %t32)
  store i64 %t35, ptr %l22
  br label %bb9
bb8:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb11
bb9:
  %t36 = load ptr, ptr %l18, !tbaa !29
  %t37 = load i64, ptr %l22, !tbaa !24
  %t38 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsGenerator(ptr %v0, ptr %t36, i64 %t37)
  store i1 %t38, ptr %l23
  br label %bb10
bb10:
  %t39 = load i1, ptr %l23, !tbaa !21
  store i1 %t39, ptr %l16, !tbaa !21
  br label %bb11
bb11:
  %t40 = load i1, ptr %l16, !tbaa !21
  store i1 %t40, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalDeps(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l6 = alloca %"compiler/check:b5aWalk"
  %l11 = alloca i1
  %l12 = alloca i64
  %l14 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l21 = alloca i64
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %t2 = alloca %"compiler/check:b5aWalk", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fcheck_3ab5aWalk_2ector(ptr %t2, ptr %v1, i64 %a1)
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %t2, i64 296, i1 false)
  br label %bb1
bb1:
  %t4 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 296, i64 8)
  store ptr %t4, ptr %lp3
  %t5 = load ptr, ptr %lp3
  call void @llvm.memmove.p0.p0.i64(ptr %t5, ptr %l6, i64 296, i1 false)
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load ptr, ptr %lp3
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aInit(ptr %v0, ptr %v1, ptr %t6, ptr %t7, i64 %a2)
  br label %bb2
bb2:
  store i64 0, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  %t12 = load ptr, ptr %lp3
  %t13 = getelementptr %"compiler/check:b5aWalk", ptr %t12, i32 0, i32 7
  %t14 = load i1, ptr %t13, !tbaa !21
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t16 = load i64, ptr %l4, !tbaa !24
  store i64 %t16, ptr %l12, !tbaa !24
  %t17 = load ptr, ptr %lp3
  %t18 = getelementptr %"compiler/check:b5aWalk", ptr %t17, i32 0, i32 2
  %t20 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t18)
  store i64 %t20, ptr %l14
  br label %bb6
bb5:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb7
bb6:
  %t21 = load i64, ptr %l12, !tbaa !24
  %t22 = load i64, ptr %l14, !tbaa !24
  %t23 = icmp slt i64 %t21, %t22
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb7
bb7:
  %t25 = load i1, ptr %l11, !tbaa !21
  %t26 = xor i1 %t25, true
  br i1 %t26, label %bb8, label %bb9
bb8:
  br label %bb14
bb9:
  br label %bb10
bb10:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l17, !tbaa !29
  %t29 = load ptr, ptr %lp3
  store ptr %t29, ptr %l18, !tbaa !29
  %t30 = load ptr, ptr %lp3
  %t31 = getelementptr %"compiler/check:b5aWalk", ptr %t30, i32 0, i32 2
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t31, i64 %t32)
  store i64 %t35, ptr %l21
  br label %bb11
bb11:
  %t36 = load ptr, ptr %l17, !tbaa !29
  %t37 = load ptr, ptr %l18, !tbaa !29
  %t38 = load i64, ptr %l21, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aFn(ptr %v0, ptr %v1, ptr %t36, ptr %t37, i64 %t38)
  br label %bb12
bb12:
  %t39 = load i64, ptr %l4, !tbaa !24
  %t41 = add i64 %t39, 1
  store i64 %t41, ptr %l4, !tbaa !24
  br label %bb13
bb13:
  br label %bb3
bb14:
  %t43 = load ptr, ptr %lp3
  %t44 = getelementptr %"compiler/check:b5aWalk", ptr %t43, i32 0, i32 3
  %t45 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t44
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t45, ptr %l24
  %t47 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v1, ptr %l24)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t47, ptr %l26
  br label %bb15
bb15:
  %t48 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t48, ptr %l24
  %t49 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldArg(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l8 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l15 = alloca %"compiler/source:Span"
  %l18 = alloca i64
  %l19 = alloca ptr
  %rv = alloca ptr
  store { i64, ptr } %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t2 = load i64, ptr %l3, !tbaa !24
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t1, i64 %t2)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  %t7 = icmp slt i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t9, ptr %l8, !tbaa !27
  %t10 = load i64, ptr %l3, !tbaa !24
  %t12 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr ptr, ptr %t13, i64 %t10
  %t15 = load ptr, ptr %t14, !tbaa !39
  store ptr %t15, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store ptr %a0, ptr %l11, !tbaa !29
  %t18 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t18, ptr %l12, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  %t26 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t24)
  store %"compiler/source:Span" %t26, ptr %l15
  br label %bb5
bb5:
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t27, i64 %t28)
  store i64 %t31, ptr %l18
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l11, !tbaa !29
  %t33 = load %"compiler/source:Span", ptr %l15
  %t34 = load i64, ptr %l18, !tbaa !24
  %t35 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v3, ptr %t32, %"compiler/source:Span" %t33, i64 %t34)
  store ptr %t35, ptr %l19
  br label %bb7
bb7:
  %t36 = load ptr, ptr %l19, !tbaa !29
  store ptr %t36, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einPlaceUndecided(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/check:inPlaceRead"
  %l6 = alloca i64
  %l8 = alloca i64
  %l13 = alloca %"compiler/check:inPlaceRead"
  %l15 = alloca %"compiler/check:inPlaceRead"
  %l19 = alloca i1
  %l21 = alloca ptr
  %l24 = alloca %"compiler/check:Gap"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 62
  store ptr %t3, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l6, !tbaa !24
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3ainPlaceRead_3e_2eLe_Hf613227d99bb55cc0c1d4d516f382642(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l8
  br label %bb2
bb2:
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l8, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb15
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = call %"compiler/check:inPlaceRead" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3ainPlaceRead_3e_2eAt_Hf62b397eb49933d0308b5b903703d314(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store %"compiler/check:inPlaceRead" %t19, ptr %l13
  br label %bb6
bb6:
  %t21 = call %"compiler/check:inPlaceRead" @olang_2eHelperKind_2eCopy_2ecompiler_2fcheck_3ainPlaceRead(ptr %v0, ptr %l13)
  store %"compiler/check:inPlaceRead" %t21, ptr %l15
  br label %bb7
bb7:
  %t22 = load %"compiler/check:inPlaceRead", ptr %l15
  store %"compiler/check:inPlaceRead" %t22, ptr %l3
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 68
  %t26 = getelementptr %"compiler/check:inPlaceRead", ptr %l3, i32 0, i32 0
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  %t30 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v0, ptr %t25, { i64, ptr } %t27)
  store i1 %t30, ptr %l19
  br label %bb8
bb8:
  %t31 = load i1, ptr %l19, !tbaa !21
  br i1 %t31, label %bb9, label %bb10
bb9:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 15
  store ptr %t34, ptr %l21, !tbaa !29
  %t35 = getelementptr %"compiler/check:inPlaceRead", ptr %l3, i32 0, i32 2
  %t36 = load i64, ptr %t35, !tbaa !24
  %t37 = getelementptr %"compiler/check:inPlaceRead", ptr %l3, i32 0, i32 3
  %t38 = load %"compiler/source:Span", ptr %t37
  %t41 = call %"compiler/check:Gap" @compiler_2fcheck_3aGap_2ector(ptr %v0, ptr %v0, i64 %t36, %"compiler/source:Span" %t38, { i64, ptr } { i64 79, ptr getelementptr inbounds (<{ i64, [79 x i8] }>, ptr @.d27, i32 0, i32 1) })
  store %"compiler/check:Gap" %t41, ptr %l24
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t42 = load ptr, ptr %l21, !tbaa !29
  %t43 = load %"compiler/check:Gap", ptr %l24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2ePush_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %v0, ptr %t42, %"compiler/check:Gap" %t43)
  br label %bb12
bb12:
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t44 = load i64, ptr %l2, !tbaa !24
  %t46 = add i64 %t44, 1
  store i64 %t46, ptr %l2, !tbaa !24
  br label %bb1
bb15:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstImmutUnique(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/generic:Origin"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l10 = alloca i1
  %l12 = alloca i1
  %l16 = alloca i1
  %l21 = alloca %"compiler/generic:Origin"
  %l26 = alloca ptr
  %l31 = alloca i32
  %l32 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l44 = alloca i1
  %l45 = alloca i1
  %l49 = alloca i1
  %l54 = alloca ptr
  %l60 = alloca { i64, [3 x i64] }
  %l63 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l69 = alloca %"compiler/diagmsg:Msg"
  %l70 = alloca i64
  %s4 = alloca %olang.scope
  %t118 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  %t8 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eImmut(ptr %v0, ptr %t4, i32 %t5)
  store i1 %t8, ptr %l10
  br label %bb1
bb1:
  %t9 = load i1, ptr %l10, !tbaa !21
  %t10 = xor i1 %t9, true
  br i1 %t10, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb5
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t16 = load i32, ptr %l1, !tbaa !23
  %t19 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l16
  br label %bb4
bb4:
  %t20 = load i1, ptr %l16, !tbaa !21
  %t21 = xor i1 %t20, true
  store i1 %t21, ptr %l12, !tbaa !21
  br label %bb5
bb5:
  %t23 = load i1, ptr %l12, !tbaa !21
  br i1 %t23, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t28 = load i32, ptr %l1, !tbaa !23
  %t31 = call %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeOrigin(ptr %v0, ptr %t27, i32 %t28)
  store %"compiler/generic:Origin" %t31, ptr %l21
  br label %bb9
bb9:
  %t32 = load %"compiler/generic:Origin", ptr %l21
  store %"compiler/generic:Origin" %t32, ptr %l2
  %t33 = getelementptr %"compiler/generic:Origin", ptr %l2, i32 0, i32 0
  %t34 = load i64, ptr %t33, !tbaa !24
  %t36 = icmp slt i64 %t34, 0
  br i1 %t36, label %bb10, label %bb11
bb10:
  br label %ret
bb11:
  br label %bb12
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 2
  store ptr %t43, ptr %l26, !tbaa !29
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  %t50 = load i32, ptr %l1, !tbaa !23
  %t53 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t53, ptr %l31
  br label %bb13
bb13:
  %t54 = load ptr, ptr %l26, !tbaa !29
  %t55 = load i32, ptr %l31, !tbaa !23
  %t56 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t54, i32 %t55)
  store { i64, ptr } %t56, ptr %l32
  br label %bb14
bb14:
  %t57 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t57, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t58, 0
  store i64 %t60, ptr %l5, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t62 = load i64, ptr %l4, !tbaa !24
  %t63 = load i64, ptr %l5, !tbaa !24
  %t66 = icmp slt i64 %t62, %t63
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s4)
  br label %bb32
bb17:
  br label %bb18
bb18:
  %t70 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t70, ptr %l39, !tbaa !27
  %t71 = load i64, ptr %l4, !tbaa !24
  %t73 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr i32, ptr %t74, i64 %t71
  %t76 = load i32, ptr %t75, !tbaa !33
  store i32 %t76, ptr %l6, !tbaa !23
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i32, ptr %l6, !tbaa !23
  %t82 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t78, i32 %t79)
  store i1 %t82, ptr %l44
  br label %bb19
bb19:
  %t83 = load i1, ptr %l44, !tbaa !21
  br i1 %t83, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb23
bb21:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/check:Checker", ptr %t84, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t88 = load i32, ptr %l6, !tbaa !23
  %t91 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnique(ptr %v0, ptr %t87, i32 %t88)
  store i1 %t91, ptr %l49
  br label %bb22
bb22:
  %t92 = load i1, ptr %l49, !tbaa !21
  %t93 = xor i1 %t92, true
  store i1 %t93, ptr %l45, !tbaa !21
  br label %bb23
bb23:
  %t95 = load i1, ptr %l45, !tbaa !21
  br i1 %t95, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s4)
  br label %bb31
bb25:
  br label %bb26
bb26:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/check:Checker", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/generic:Program", ptr %t99, i32 0, i32 0
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = getelementptr %"compiler/load:Loader", ptr %t102, i32 0, i32 4
  %t105 = load ptr, ptr %t104, !tbaa !29
  store ptr %t105, ptr %l54, !tbaa !29
  %t106 = getelementptr %"compiler/generic:Origin", ptr %l2, i32 0, i32 0
  %t107 = load i64, ptr %t106, !tbaa !24
  %t108 = getelementptr %"compiler/generic:Origin", ptr %l2, i32 0, i32 1
  %t109 = getelementptr %"compiler/source:Span", ptr %t108, i32 0, i32 0
  %t110 = load i32, ptr %t109, !tbaa !23
  %t112 = sext i32 %t110 to i64
  %t113 = getelementptr %"compiler/generic:Origin", ptr %l2, i32 0, i32 1
  %t114 = getelementptr %"compiler/source:Span", ptr %t113, i32 0, i32 1
  %t115 = load i32, ptr %t114, !tbaa !23
  %t117 = sext i32 %t115 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t118
  %t119 = getelementptr { i64, [3 x i64] }, ptr %t118, i32 0, i32 0
  store i64 3, ptr %t119
  %t121 = insertvalue { i64, i64, i64 } undef, i64 %t107, 0
  %t123 = insertvalue { i64, i64, i64 } %t121, i64 %t112, 1
  %t125 = insertvalue { i64, i64, i64 } %t123, i64 %t117, 2
  %t126 = getelementptr { i64, [3 x i64] }, ptr %t118, i32 0, i32 1
  store { i64, i64, i64 } %t125, ptr %t126
  %t127 = load { i64, [3 x i64] }, ptr %t118
  store { i64, [3 x i64] } %t127, ptr %l60
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load i32, ptr %l1, !tbaa !23
  %t132 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s4, ptr %t128, i32 %t129)
  store { i64, ptr } %t132, ptr %l63
  br label %bb27
bb27:
  %t133 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 0
  %t135 = extractvalue { i64, ptr } %t133, 1
  %t136 = mul i64 %t134, 1
  %t137 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t136)
  call void @llvm.memcpy.p0.p0.i64(ptr %t137, ptr %t135, i64 %t136, i1 false)
  %t138 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t137, 1
  store { i64, ptr } %t139, ptr %l64, !tbaa !27
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i32, ptr %l6, !tbaa !23
  %t144 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s4, ptr %t140, i32 %t141)
  store { i64, ptr } %t144, ptr %l67
  br label %bb28
bb28:
  %t145 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t145, 0
  %t147 = extractvalue { i64, ptr } %t145, 1
  %t148 = mul i64 %t146, 1
  %t149 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t148)
  call void @llvm.memcpy.p0.p0.i64(ptr %t149, ptr %t147, i64 %t148, i1 false)
  %t150 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  %t152 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t154 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUniqueImmutPart(ptr %s4, ptr %s4, ptr %s4, { i64, ptr } %t152, { i64, ptr } %t151)
  store %"compiler/diagmsg:Msg" %t154, ptr %l69
  br label %bb29
bb29:
  %t155 = load ptr, ptr %l54, !tbaa !29
  %t156 = load { i64, [3 x i64] }, ptr %l60
  %t157 = load %"compiler/diagmsg:Msg", ptr %l69
  %t158 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorBare(ptr %v0, ptr %s4, ptr %t155, { i64, [3 x i64] } %t156, %"compiler/diagmsg:Msg" %t157)
  store i64 %t158, ptr %l70
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s4)
  br label %ret
bb31:
  %t159 = load i64, ptr %l4, !tbaa !24
  %t161 = add i64 %t159, 1
  store i64 %t161, ptr %l4, !tbaa !24
  br label %bb15
bb32:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisArrayCtor(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l25 = alloca { i64, ptr }
  %l26 = alloca i1
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 13
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t18, i32 0, i32 2
  %t20 = load { i64, ptr }, ptr %t19
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  br label %bb21
bb5:
  %t22 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t26 = icmp ne i64 %t24, 1
  br i1 %t26, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t29 = load ptr, ptr %l2, !tbaa !29
  store ptr %t29, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t30 = load ptr, ptr %l17, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb9, label %bb10
bb9:
  %t33 = load ptr, ptr %l17, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 30}
  %t36 = icmp eq i64 %t34, 0
  store i1 %t36, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t37 = load i1, ptr %l18, !tbaa !21
  br i1 %t37, label %bb11, label %bb12
bb11:
  %t38 = load ptr, ptr %l2, !tbaa !29
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32 }, ptr %t40, i32 0, i32 1
  %t42 = load i32, ptr %t41
  store i32 %t42, ptr %l4, !tbaa !23
  br label %bb13
bb12:
  br label %bb16
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t45 = load i32, ptr %l4, !tbaa !23
  %t48 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %a0, i32 %t45)
  store { i64, ptr } %t48, ptr %l25
  br label %bb14
bb14:
  %t49 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t50 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t49, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d28, i32 0, i32 1) })
  store i1 %t50, ptr %l26
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  %t51 = load i1, ptr %l26, !tbaa !21
  store i1 %t51, ptr %rv
  br label %ret
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i1 false, ptr %rv
  br label %ret
bb20:
  call void @__olang_check_failed(ptr @olang_loc_aec4d07a8c55eb24_c1f86bfc15f940a8)
  unreachable
bb21:
  br i1 true, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  store i1 false, ptr %rv
  br label %ret
bb25:
  call void @__olang_check_failed(ptr @olang_loc_f7ce27c314005a15_bac367b114faff79)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCStrRef(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeForeign(ptr %v0, ptr %s0, ptr %a0, i32 %a1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t6 = load i1, ptr %l4, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eiterShaped(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l12 = alloca i32
  %l15 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca { i64, ptr }
  %l25 = alloca i1
  %l27 = alloca { i64, ptr }
  %l29 = alloca i1
  %l36 = alloca i32
  %l40 = alloca i1
  %l44 = alloca i1
  %l49 = alloca i32
  %l55 = alloca ptr
  %l60 = alloca i32
  %l61 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l73 = alloca ptr
  %l78 = alloca i32
  %l79 = alloca i32
  %l83 = alloca ptr
  %l86 = alloca ptr
  %l89 = alloca ptr
  %l94 = alloca i32
  %l95 = alloca i32
  %l96 = alloca i32
  %l97 = alloca { i64, ptr }
  %l98 = alloca i1
  %l104 = alloca i1
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t4, i64 %a1)
  store i32 %t8, ptr %l12
  br label %bb1
bb1:
  %t9 = load i32, ptr %l12, !tbaa !23
  store i32 %t9, ptr %l2, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  store ptr %t15, ptr %l15, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l20
  br label %bb2
bb2:
  %t26 = load ptr, ptr %l15, !tbaa !29
  %t27 = load i32, ptr %l20, !tbaa !23
  %t28 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t26, i32 %t27)
  store { i64, ptr } %t28, ptr %l21
  br label %bb3
bb3:
  %t29 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t29, ptr %l3, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  %t34 = icmp ne i64 %t32, 1
  br i1 %t34, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb7
bb5:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t37, ptr %l27, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr i32, ptr %t39, i64 0
  %t41 = load i32, ptr %t40, !tbaa !33
  %t44 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritable(ptr %v0, ptr %t36, i32 %t41)
  store i1 %t44, ptr %l29
  br label %bb6
bb6:
  %t45 = load i1, ptr %l29, !tbaa !21
  %t46 = xor i1 %t45, true
  store i1 %t46, ptr %l25, !tbaa !21
  br label %bb7
bb7:
  %t48 = load i1, ptr %l25, !tbaa !21
  br i1 %t48, label %bb8, label %bb9
bb8:
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %l2, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t59, ptr %l36
  br label %bb11
bb11:
  %t60 = load i32, ptr %l36, !tbaa !23
  store i32 %t60, ptr %l4, !tbaa !23
  %t61 = load i32, ptr %l4, !tbaa !23
  %t62 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t65 = icmp eq i32 %t61, %t62
  br i1 %t65, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb14
bb13:
  %t67 = load i32, ptr %l4, !tbaa !23
  %t68 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t71 = icmp eq i32 %t67, %t68
  store i1 %t71, ptr %l40, !tbaa !21
  br label %bb14
bb14:
  %t73 = load i1, ptr %l40, !tbaa !21
  br i1 %t73, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb18
bb16:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/check:Checker", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/generic:Program", ptr %t77, i32 0, i32 2
  %t80 = load i32, ptr %l4, !tbaa !23
  %t83 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t79, i32 %t80)
  store i32 %t83, ptr %l49
  br label %bb17
bb17:
  %t84 = load i32, ptr %l49, !range !{i32 0, i32 33}
  %t86 = trunc i64 22 to i32
  %t87 = icmp eq i32 %t84, %t86
  store i1 %t87, ptr %l44, !tbaa !21
  br label %bb18
bb18:
  %t89 = load i1, ptr %l44, !tbaa !21
  br i1 %t89, label %bb19, label %bb20
bb19:
  store i1 false, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/check:Checker", ptr %t91, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = getelementptr %"compiler/generic:Program", ptr %t94, i32 0, i32 2
  store ptr %t96, ptr %l55, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  %t103 = load i32, ptr %l2, !tbaa !23
  %t106 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t102, i32 %t103)
  store i32 %t106, ptr %l60
  br label %bb22
bb22:
  %t107 = load ptr, ptr %l55, !tbaa !29
  %t108 = load i32, ptr %l60, !tbaa !23
  %t109 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t107, i32 %t108)
  store { i64, ptr } %t109, ptr %l61
  br label %bb23
bb23:
  %t110 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t110, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t111 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t111, 0
  store i64 %t113, ptr %l7, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s4
  %t115 = load i64, ptr %l6, !tbaa !24
  %t116 = load i64, ptr %l7, !tbaa !24
  %t119 = icmp slt i64 %t115, %t116
  %t121 = xor i1 %t119, true
  br i1 %t121, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s4)
  br label %bb42
bb26:
  br label %bb27
bb27:
  %t123 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t123, ptr %l68, !tbaa !27
  %t124 = load i64, ptr %l6, !tbaa !24
  %t126 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr i32, ptr %t127, i64 %t124
  %t129 = load i32, ptr %t128, !tbaa !33
  store i32 %t129, ptr %l8, !tbaa !23
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/check:Checker", ptr %t131, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !29
  %t136 = getelementptr %"compiler/generic:Program", ptr %t134, i32 0, i32 2
  store ptr %t136, ptr %l73, !tbaa !29
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/check:Checker", ptr %t137, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t142 = getelementptr %"compiler/generic:Program", ptr %t140, i32 0, i32 2
  %t143 = load i32, ptr %l8, !tbaa !23
  %t146 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t142, i32 %t143)
  store i32 %t146, ptr %l78
  br label %bb28
bb28:
  %t147 = load ptr, ptr %l73, !tbaa !29
  %t148 = load i32, ptr %l78, !tbaa !23
  %t149 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t147, i32 %t148)
  store i32 %t149, ptr %l79
  br label %bb29
bb29:
  %t150 = load i32, ptr %l79, !range !{i32 0, i32 33}
  %t152 = trunc i64 18 to i32
  %t153 = icmp eq i32 %t150, %t152
  %t155 = xor i1 %t153, true
  br i1 %t155, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s4)
  br label %bb41
bb31:
  br label %bb32
bb32:
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l83, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/check:Checker", ptr %t158, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = getelementptr %"compiler/generic:Program", ptr %t161, i32 0, i32 2
  store ptr %t163, ptr %l86, !tbaa !29
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/check:Checker", ptr %t164, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t169 = getelementptr %"compiler/generic:Program", ptr %t167, i32 0, i32 2
  store ptr %t169, ptr %l89, !tbaa !29
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/check:Checker", ptr %t170, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !29
  %t175 = getelementptr %"compiler/generic:Program", ptr %t173, i32 0, i32 2
  %t176 = load i32, ptr %l8, !tbaa !23
  %t179 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t175, i32 %t176)
  store i32 %t179, ptr %l94
  br label %bb33
bb33:
  %t180 = load ptr, ptr %l89, !tbaa !29
  %t181 = load i32, ptr %l94, !tbaa !23
  %t182 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t180, i32 %t181)
  store i32 %t182, ptr %l95
  br label %bb34
bb34:
  %t183 = load ptr, ptr %l86, !tbaa !29
  %t184 = load i32, ptr %l95, !tbaa !23
  %t185 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t183, i32 %t184)
  store i32 %t185, ptr %l96
  br label %bb35
bb35:
  %t186 = load ptr, ptr %l83, !tbaa !29
  %t187 = load i32, ptr %l96, !tbaa !23
  %t188 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t186, i32 %t187)
  store { i64, ptr } %t188, ptr %l97
  br label %bb36
bb36:
  %t189 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t190 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t189, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store i1 %t190, ptr %l98
  br label %bb37
bb37:
  %t191 = load i1, ptr %l98, !tbaa !21
  br i1 %t191, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s4)
  store i1 true, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s4)
  br label %bb41
bb41:
  %t193 = load i64, ptr %l6, !tbaa !24
  %t195 = add i64 %t193, 1
  store i64 %t195, ptr %l6, !tbaa !24
  br label %bb24
bb42:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load i32, ptr %l2, !tbaa !23
  %t201 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %t197, i32 %t198)
  store i1 %t201, ptr %l104
  br label %bb43
bb43:
  %t202 = load i1, ptr %l104, !tbaa !21
  store i1 %t202, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elambdaErrs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l32 = alloca i32
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l45 = alloca ptr
  %l51 = alloca i32
  %l57 = alloca i32
  %l58 = alloca i32
  %l64 = alloca i32
  %l65 = alloca i32
  %l68 = alloca ptr
  %l73 = alloca i32
  %l78 = alloca i32
  %l79 = alloca i32
  %l84 = alloca i32
  %l89 = alloca i64
  %l90 = alloca i32
  %rv = alloca ptr
  %t191 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l1, !tbaa !29
  store ptr %t7, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t8 = load ptr, ptr %l12, !tbaa !29
  %t9 = icmp ne ptr %t8, null
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t11 = load ptr, ptr %l12, !tbaa !29
  %t12 = load i64, ptr %t11, !range !{i64 0, i64 18}
  %t14 = icmp eq i64 %t12, 15
  store i1 %t14, ptr %l13, !tbaa !21
  br label %bb5
bb5:
  %t15 = load i1, ptr %l13, !tbaa !21
  br i1 %t15, label %bb6, label %bb7
bb6:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 0
  %t20 = load %"compiler/source:Span", ptr %t19
  store %"compiler/source:Span" %t20, ptr %l3
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t24, i32 0, i32 1
  %t26 = load i32, ptr %t25
  store i32 %t26, ptr %l4, !tbaa !23
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l5, !tbaa !29
  br label %bb8
bb7:
  br label %bb33
bb8:
  %t34 = load ptr, ptr %l5, !tbaa !29
  store ptr %t34, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t35 = load ptr, ptr %l22, !tbaa !29
  %t36 = icmp ne ptr %t35, null
  br i1 %t36, label %bb9, label %bb10
bb9:
  %t38 = load ptr, ptr %l22, !tbaa !29
  %t39 = load i64, ptr %t38, !range !{i64 0, i64 3}
  %t41 = icmp eq i64 %t39, 1
  store i1 %t41, ptr %l23, !tbaa !21
  br label %bb10
bb10:
  %t42 = load i1, ptr %l23, !tbaa !21
  br i1 %t42, label %bb11, label %bb12
bb11:
  %t43 = load ptr, ptr %l5, !tbaa !29
  %t45 = getelementptr { i64, [4 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t45, i32 0, i32 0
  %t47 = load i32, ptr %t46
  store i32 %t47, ptr %l6, !tbaa !23
  br label %bb13
bb12:
  br label %bb28
bb13:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/generic:Program", ptr %t52, i32 0, i32 2
  %t55 = load i32, ptr %l4, !tbaa !23
  %t58 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t54, i32 %t55)
  store i32 %t58, ptr %l32
  br label %bb14
bb14:
  %t59 = load i32, ptr %l2, !tbaa !23
  %t60 = load i32, ptr %l32, !tbaa !23
  %t62 = icmp eq i32 %t60, %t59
  br i1 %t62, label %bb15, label %bb16
bb15:
  %t64 = load ptr, ptr %l1, !tbaa !29
  store ptr %t64, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 14
  %t70 = load i32, ptr %l6, !tbaa !23
  %t72 = sext i32 %t70 to i64
  %t75 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t69, i64 %t72)
  store ptr %t75, ptr %l41
  br label %bb18
bb18:
  %t76 = load ptr, ptr %l41, !tbaa !29
  store ptr %t76, ptr %l7, !tbaa !29
  %t77 = load ptr, ptr %l7, !tbaa !29
  store ptr %t77, ptr %l42, !tbaa !29
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/check:Checker", ptr %t78, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t83 = getelementptr %"compiler/generic:Program", ptr %t81, i32 0, i32 2
  store ptr %t83, ptr %l45, !tbaa !29
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/check:Checker", ptr %t84, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t89 = getelementptr %"compiler/generic:Program", ptr %t87, i32 0, i32 2
  %t90 = load ptr, ptr %l7, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Body", ptr %t90, i32 0, i32 2
  %t93 = load i32, ptr %t92, !tbaa !23
  %t96 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t89, i32 %t93)
  store i32 %t96, ptr %l51
  br label %bb19
bb19:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  %t103 = load ptr, ptr %l7, !tbaa !29
  %t105 = getelementptr %"compiler/typed:Body", ptr %t103, i32 0, i32 2
  %t106 = load i32, ptr %t105, !tbaa !23
  %t109 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t102, i32 %t106)
  store i32 %t109, ptr %l57
  br label %bb20
bb20:
  %t110 = load i32, ptr %l2, !tbaa !23
  store i32 %t110, ptr %l58, !tbaa !23
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/check:Checker", ptr %t111, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = getelementptr %"compiler/generic:Program", ptr %t114, i32 0, i32 2
  %t117 = load ptr, ptr %l7, !tbaa !29
  %t119 = getelementptr %"compiler/typed:Body", ptr %t117, i32 0, i32 2
  %t120 = load i32, ptr %t119, !tbaa !23
  %t123 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t116, i32 %t120)
  store i32 %t123, ptr %l64
  br label %bb21
bb21:
  %t124 = load ptr, ptr %l45, !tbaa !29
  %t125 = load i32, ptr %l51, !tbaa !23
  %t126 = load i32, ptr %l57, !tbaa !23
  %t127 = load i32, ptr %l58, !tbaa !23
  %t128 = load i32, ptr %l64, !tbaa !23
  %t129 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t124, i32 %t125, i32 %t126, i32 %t127, i32 %t128, i64 0, i1 false, i32 0)
  store i32 %t129, ptr %l65
  br label %bb22
bb22:
  %t130 = load i32, ptr %l65, !tbaa !23
  %t131 = load ptr, ptr %l42, !tbaa !29
  %t132 = getelementptr %"compiler/typed:Body", ptr %t131, i32 0, i32 2
  store i32 %t130, ptr %t132, !tbaa !23
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/check:Checker", ptr %t133, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t138 = getelementptr %"compiler/generic:Program", ptr %t136, i32 0, i32 2
  store ptr %t138, ptr %l68, !tbaa !29
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/check:Checker", ptr %t139, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t144 = getelementptr %"compiler/generic:Program", ptr %t142, i32 0, i32 2
  %t145 = load i32, ptr %l4, !tbaa !23
  %t148 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t144, i32 %t145)
  store i32 %t148, ptr %l73
  br label %bb23
bb23:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/check:Checker", ptr %t149, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !29
  %t154 = getelementptr %"compiler/generic:Program", ptr %t152, i32 0, i32 2
  %t155 = load i32, ptr %l4, !tbaa !23
  %t158 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t154, i32 %t155)
  store i32 %t158, ptr %l78
  br label %bb24
bb24:
  %t159 = load i32, ptr %l2, !tbaa !23
  store i32 %t159, ptr %l79, !tbaa !23
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/check:Checker", ptr %t160, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !29
  %t165 = getelementptr %"compiler/generic:Program", ptr %t163, i32 0, i32 2
  %t166 = load i32, ptr %l4, !tbaa !23
  %t169 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t165, i32 %t166)
  store i32 %t169, ptr %l84
  br label %bb25
bb25:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/check:Checker", ptr %t170, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !29
  %t175 = getelementptr %"compiler/generic:Program", ptr %t173, i32 0, i32 2
  %t176 = load i32, ptr %l4, !tbaa !23
  %t179 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesIdOf(ptr %v0, ptr %t175, i32 %t176)
  store i64 %t179, ptr %l89
  br label %bb26
bb26:
  %t180 = load ptr, ptr %l68, !tbaa !29
  %t181 = load i32, ptr %l73, !tbaa !23
  %t182 = load i32, ptr %l78, !tbaa !23
  %t183 = load i32, ptr %l79, !tbaa !23
  %t184 = load i32, ptr %l84, !tbaa !23
  %t185 = load i64, ptr %l89, !tbaa !24
  %t186 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t180, i32 %t181, i32 %t182, i32 %t183, i32 %t184, i64 %t185, i1 false, i32 0)
  store i32 %t186, ptr %l90
  br label %bb27
bb27:
  %t187 = load i32, ptr %l90, !tbaa !23
  %t188 = load %"compiler/source:Span", ptr %l3
  %t190 = load ptr, ptr %l5, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t191
  %t192 = getelementptr { i64, [5 x i64] }, ptr %t191, i32 0, i32 0
  store i64 15, ptr %t192
  %t194 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t188, 0
  %t196 = insertvalue { %"compiler/source:Span", i32, ptr } %t194, i32 %t187, 1
  %t198 = insertvalue { %"compiler/source:Span", i32, ptr } %t196, ptr %t190, 2
  %t199 = getelementptr { i64, [5 x i64] }, ptr %t191, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t198, ptr %t199
  %t200 = load { i64, [5 x i64] }, ptr %t191
  %t202 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t200, ptr %t202
  store ptr %t202, ptr %rv
  br label %ret
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  %t204 = load ptr, ptr %l1, !tbaa !29
  store ptr %t204, ptr %rv
  br label %ret
bb32:
  call void @__olang_check_failed(ptr @olang_loc_24473ecab934ff5a_e5063e673d38f936)
  unreachable
bb33:
  br i1 true, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  %t207 = load ptr, ptr %l1, !tbaa !29
  store ptr %t207, ptr %rv
  br label %ret
bb37:
  call void @__olang_check_failed(ptr @olang_loc_1dc6773449e59e5b_c7fcef2f52138cd7)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneAssign(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca %"compiler/check:laneVals"
  %l11 = alloca i32
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca ptr
  %l22 = alloca %"compiler/check:laneVals"
  %l23 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca i64
  %l31 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l4, !tbaa !29
  %t3 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t1)
  store i32 %t3, ptr %l11
  br label %bb1
bb1:
  %t4 = load i32, ptr %l11, !tbaa !23
  store i32 %t4, ptr %l6, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load %"compiler/source:Span", ptr %l1
  %t7 = load ptr, ptr %l4, !tbaa !29
  %t11 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneTarget(ptr %v0, ptr %v1, ptr %t5, %"compiler/source:Span" %t6, ptr %t7)
  store i64 %t11, ptr %l15
  br label %bb2
bb2:
  %t12 = load i64, ptr %l15, !tbaa !24
  store i64 %t12, ptr %l7, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l16, !tbaa !29
  store ptr %a5, ptr %l17, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l6, !tbaa !23
  %t19 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElemOf(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t19, ptr %l20
  br label %bb3
bb3:
  %t20 = load ptr, ptr %l16, !tbaa !29
  %t21 = load ptr, ptr %l17, !tbaa !29
  %t22 = load i32, ptr %l20, !tbaa !23
  %t23 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArg(ptr %v0, ptr %v2, ptr %v0, ptr %t20, ptr %t21, i32 %t22)
  store ptr %t23, ptr %l21
  br label %bb4
bb4:
  %t24 = load ptr, ptr %l21, !tbaa !29
  store ptr %t24, ptr %l8, !tbaa !29
  %t25 = call %"compiler/check:laneVals" @compiler_2fcheck_3alaneVals_2ector(ptr %s0)
  store %"compiler/check:laneVals" %t25, ptr %l22
  br label %bb5
bb5:
  %t26 = load %"compiler/check:laneVals", ptr %l22
  store %"compiler/check:laneVals" %t26, ptr %l9
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l23, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t28, ptr %l24
  store %"compiler/source:Span" %a2, ptr %l25
  store i32 %a3, ptr %l26
  %t31 = load i32, ptr %l6, !tbaa !23
  store i32 %t31, ptr %l27, !tbaa !23
  %t32 = load i64, ptr %l7, !tbaa !24
  store i64 %t32, ptr %l28, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load ptr, ptr %l8, !tbaa !29
  %t37 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaf(ptr %v0, ptr %v0, ptr %t33, ptr %t34)
  store i64 %t37, ptr %l31
  br label %bb6
bb6:
  %t38 = load ptr, ptr %l23, !tbaa !29
  %t39 = load %"compiler/source:Span", ptr %l24
  %t40 = load %"compiler/source:Span", ptr %l25
  %t41 = load i32, ptr %l26, !range !{i32 0, i32 98}
  %t42 = load i32, ptr %l27, !tbaa !23
  %t43 = load i64, ptr %l28, !tbaa !24
  %t44 = load i64, ptr %l31, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneStore(ptr %v0, ptr %s0, ptr %t38, %"compiler/source:Span" %t39, %"compiler/source:Span" %t40, i32 %t41, i32 %t42, i64 %t43, i64 %t44, ptr %l9)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneCount(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l7 = alloca %"compiler/check:laneNode"
  %l10 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l13 = alloca i32
  %l17 = alloca %"compiler/check:laneNode"
  %l19 = alloca ptr
  %l24 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 39
  %t4 = load i64, ptr %l2, !tbaa !24
  %t7 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s0, ptr %t3, i64 %t4)
  store %"compiler/check:laneNode" %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = getelementptr %"compiler/check:laneNode", ptr %l7, i32 0, i32 9
  %t9 = load i64, ptr %t8, !tbaa !24
  %t11 = icmp sge i64 %t9, 0
  br i1 %t11, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l10, !tbaa !29
  %t14 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t14, ptr %l11
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t15)
  store i32 %t17, ptr %l13
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 39
  %t21 = load i64, ptr %l2, !tbaa !24
  %t24 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s1, ptr %t20, i64 %t21)
  store %"compiler/check:laneNode" %t24, ptr %l17
  br label %bb5
bb5:
  %t25 = getelementptr %"compiler/check:laneNode", ptr %l17, i32 0, i32 9
  %t26 = load i64, ptr %t25, !tbaa !24
  %t27 = load ptr, ptr %l10, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l11
  %t29 = load i32, ptr %l13, !tbaa !23
  %t31 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v2, ptr %t27, %"compiler/source:Span" %t28, i32 %t29, i64 %t26)
  store ptr %t31, ptr %l19
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t32 = load ptr, ptr %l19, !tbaa !29
  store ptr %t32, ptr %rv
  br label %ret
bb7:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load %"compiler/source:Span", ptr %l1
  %t37 = getelementptr %"compiler/check:laneVals", ptr %a3, i32 0, i32 0
  %t38 = load i64, ptr %t37, !tbaa !24
  %t42 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v2, ptr %t33, %"compiler/source:Span" %t34, i64 %t38)
  store ptr %t42, ptr %l24
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t43 = load ptr, ptr %l24, !tbaa !29
  store ptr %t43, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneHold(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %rv = alloca ptr
  %t12 = alloca { i64, [5 x i64] }, align 8
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %"compiler/source:Span" %a1, ptr %l3
  %t3 = load i64, ptr %l2, !tbaa !24
  %t6 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneType(ptr %v0, ptr %a0, i64 %t3)
  store i32 %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneMagic, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = add i64 %t7, %t8
  store { i64, [5 x i64] } zeroinitializer, ptr %t12
  %t13 = getelementptr { i64, [5 x i64] }, ptr %t12, i32 0, i32 0
  store i64 0, ptr %t13
  %t14 = load %"compiler/source:Span", ptr %l3
  %t15 = insertvalue { %"compiler/source:Span", i32, i64 } undef, %"compiler/source:Span" %t14, 0
  %t16 = load i32, ptr %l6, !tbaa !23
  %t17 = insertvalue { %"compiler/source:Span", i32, i64 } %t15, i32 %t16, 1
  %t19 = insertvalue { %"compiler/source:Span", i32, i64 } %t17, i64 %t11, 2
  %t20 = getelementptr { i64, [5 x i64] }, ptr %t12, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64 } %t19, ptr %t20
  %t21 = load { i64, [5 x i64] }, ptr %t12
  %t23 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t21, ptr %t23
  store ptr %t23, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLen(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l16 = alloca { i64, ptr }
  %l22 = alloca %"compiler/check:laneNode"
  %l28 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l36 = alloca %"compiler/diagmsg:Msg"
  %l37 = alloca i64
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 -1, ptr %l3, !tbaa !24
  store { i64, ptr } %a1, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l6, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l6, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t15, ptr %l16, !tbaa !27
  %t16 = load i64, ptr %l5, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i64, ptr %t19, i64 %t16
  %t21 = load i64, ptr %t20, !tbaa !34
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 39
  %t29 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s2, ptr %t25, i64 %t21)
  store %"compiler/check:laneNode" %t29, ptr %l22
  br label %bb5
bb5:
  %t30 = getelementptr %"compiler/check:laneNode", ptr %l22, i32 0, i32 9
  %t31 = load i64, ptr %t30, !tbaa !24
  store i64 %t31, ptr %l8, !tbaa !24
  %t33 = load i64, ptr %l8, !tbaa !24
  %t35 = icmp slt i64 %t33, 0
  br i1 %t35, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb7:
  br label %bb8
bb8:
  %t37 = load i64, ptr %l3, !tbaa !24
  %t39 = icmp sge i64 %t37, 0
  br i1 %t39, label %bb9, label %bb10
bb9:
  %t41 = load i64, ptr %l8, !tbaa !24
  %t42 = load i64, ptr %l3, !tbaa !24
  %t45 = icmp ne i64 %t41, %t42
  store i1 %t45, ptr %l28, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb11
bb11:
  %t47 = load i1, ptr %l28, !tbaa !21
  br i1 %t47, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l32, !tbaa !29
  store %"compiler/source:Span" %a2, ptr %l33
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i64, ptr %l8, !tbaa !24
  %t54 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLaneLengths(ptr %s4, i64 %t50, i64 %t51)
  store %"compiler/diagmsg:Msg" %t54, ptr %l36
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t55 = load ptr, ptr %l32, !tbaa !29
  %t56 = load %"compiler/source:Span", ptr %l33
  %t57 = load %"compiler/diagmsg:Msg", ptr %l36
  %t58 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t55, %"compiler/source:Span" %t56, %"compiler/diagmsg:Msg" %t57)
  store i64 %t58, ptr %l37
  br label %bb15
bb15:
  %t59 = load i64, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  store i64 %t59, ptr %rv
  br label %ret
bb16:
  %t61 = load i64, ptr %l8, !tbaa !24
  store i64 %t61, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  %t63 = load i64, ptr %l5, !tbaa !24
  %t65 = add i64 %t63, 1
  store i64 %t65, ptr %l5, !tbaa !24
  br label %bb1
bb18:
  %t67 = load i64, ptr %l3, !tbaa !24
  store i64 %t67, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaks1(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l3 = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 28
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t6, i32 %a1)
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emulti(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca %"compiler/source:Span"
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca %"compiler/source:Span"
  %l41 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca ptr
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca ptr
  %l59 = alloca i64
  %l60 = alloca ptr
  %l61 = alloca i64
  %l62 = alloca ptr
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca ptr
  %l70 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca ptr
  %l74 = alloca i64
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i64
  %l78 = alloca i64
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca ptr
  %lp82 = alloca ptr
  %l83 = alloca { i64, ptr }
  %l84 = alloca i64
  %l85 = alloca i64
  %l86 = alloca i64
  %l87 = alloca ptr
  %l88 = alloca ptr
  %l89 = alloca i64
  %l90 = alloca ptr
  %l98 = alloca i1
  %l103 = alloca { i64, ptr }
  %l107 = alloca ptr
  %l110 = alloca i32
  %l122 = alloca { i64, ptr }
  %l135 = alloca i32
  %l139 = alloca ptr
  %l141 = alloca { i64, ptr }
  %l143 = alloca %"compiler/source:Span"
  %l146 = alloca { i64, ptr }
  %l148 = alloca %"compiler/diagmsg:Msg"
  %l149 = alloca i64
  %l158 = alloca { i64, ptr }
  %l169 = alloca ptr
  %l174 = alloca i32
  %l175 = alloca { i64, ptr }
  %l180 = alloca ptr
  %l181 = alloca %"compiler/source:Span"
  %l185 = alloca %"compiler/diagmsg:Msg"
  %l186 = alloca i64
  %l195 = alloca { i64, ptr }
  %l209 = alloca i64
  %l222 = alloca i64
  %l225 = alloca i64
  %l244 = alloca { i64, ptr }
  %l247 = alloca %"compiler/source:Span"
  %l251 = alloca { i64, ptr }
  %l264 = alloca ptr
  %l267 = alloca { i64, ptr }
  %l273 = alloca { i64, ptr }
  %l283 = alloca ptr
  %l284 = alloca ptr
  %l286 = alloca { i64, ptr }
  %l290 = alloca %"compiler/source:Span"
  %l293 = alloca i64
  %l294 = alloca %"compiler/source:Span"
  %l299 = alloca %"compiler/diagmsg:Msg"
  %l300 = alloca i64
  %l309 = alloca { i64, ptr }
  %l316 = alloca ptr
  %l325 = alloca i64
  %l328 = alloca i64
  %l348 = alloca { i64, ptr }
  %l353 = alloca ptr
  %l354 = alloca ptr
  %l356 = alloca { i64, ptr }
  %l358 = alloca ptr
  %l359 = alloca ptr
  %l362 = alloca { i64, ptr }
  %l365 = alloca i1
  %l367 = alloca i32
  %l369 = alloca { i64, ptr }
  %l372 = alloca %"compiler/source:Span"
  %l373 = alloca i32
  %l375 = alloca i32
  %l377 = alloca i1
  %l378 = alloca ptr
  %l381 = alloca i32
  %l382 = alloca i1
  %l390 = alloca ptr
  %l393 = alloca i1
  %l395 = alloca i1
  %l398 = alloca i1
  %l402 = alloca ptr
  %l405 = alloca i32
  %l408 = alloca i1
  %l410 = alloca i1
  %l415 = alloca i1
  %l418 = alloca ptr
  %l421 = alloca { i64, ptr }
  %l428 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l429 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l431 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l437 = alloca i64
  %l440 = alloca i64
  %l460 = alloca { i64, ptr }
  %l463 = alloca ptr
  %l468 = alloca ptr
  %l471 = alloca { i64, ptr }
  %l474 = alloca ptr
  %l483 = alloca i64
  %l486 = alloca i64
  %l506 = alloca ptr
  %l510 = alloca i1
  %l513 = alloca i1
  %l514 = alloca ptr
  %l517 = alloca { i64, ptr }
  %l520 = alloca %"compiler/source:Span"
  %l521 = alloca %"compiler/diagmsg:Msg"
  %l522 = alloca i64
  %l527 = alloca i64
  %l529 = alloca i64
  %l531 = alloca i64
  %l536 = alloca ptr
  %l540 = alloca i1
  %l541 = alloca ptr
  %l543 = alloca i32
  %l544 = alloca i1
  %l546 = alloca i1
  %l549 = alloca ptr
  %l551 = alloca i32
  %l552 = alloca i1
  %l562 = alloca i64
  %l565 = alloca i64
  %l585 = alloca ptr
  %l589 = alloca i32
  %l594 = alloca ptr
  %l597 = alloca i32
  %l600 = alloca ptr
  %l604 = alloca i32
  %l608 = alloca { i64, ptr }
  %l612 = alloca ptr
  %l615 = alloca ptr
  %l618 = alloca ptr
  %l621 = alloca ptr
  %l626 = alloca ptr
  %l627 = alloca ptr
  %l629 = alloca { i64, ptr }
  %l632 = alloca %"compiler/source:Span"
  %l635 = alloca i32
  %l638 = alloca i64
  %l639 = alloca ptr
  %l641 = alloca { i64, ptr }
  %l644 = alloca %"compiler/source:Span"
  %l662 = alloca i64
  %l665 = alloca i64
  %l685 = alloca ptr
  %l689 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l699 = alloca { i64, ptr }
  %l702 = alloca ptr
  %l703 = alloca ptr
  %l710 = alloca i32
  %l716 = alloca ptr
  %l717 = alloca ptr
  %l719 = alloca %"compiler/source:Span"
  %l722 = alloca i32
  %l725 = alloca i64
  %l726 = alloca ptr
  %l728 = alloca %"compiler/source:Span"
  %l735 = alloca ptr
  %l739 = alloca ptr
  %l742 = alloca ptr
  %l743 = alloca ptr
  %l744 = alloca %"compiler/source:Span"
  %l747 = alloca i64
  %l748 = alloca ptr
  %l749 = alloca ptr
  %l750 = alloca %"compiler/source:Span"
  %l751 = alloca ptr
  %l752 = alloca %"compiler/source:Span"
  %l754 = alloca %"compiler/source:Span"
  %l756 = alloca i64
  %l762 = alloca ptr
  %l763 = alloca ptr
  %l766 = alloca { i64, ptr }
  %l768 = alloca { i64, ptr }
  %l772 = alloca ptr
  %l777 = alloca ptr
  %l780 = alloca ptr
  %l781 = alloca %"compiler/source:Span"
  %l784 = alloca ptr
  %l787 = alloca ptr
  %l788 = alloca ptr
  %l789 = alloca %"compiler/source:Span"
  %l792 = alloca i64
  %l793 = alloca ptr
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s49 = alloca %olang.scope
  %t253 = alloca { i64, [1 x i64] }, align 8
  %t270 = alloca { i64, [3 x i64] }, align 8
  %t361 = alloca { i64, [4 x i64] }, align 8
  %t374 = alloca { i64, [4 x i64] }, align 8
  %t653 = alloca { i64, [4 x i64] }, align 8
  %t1161 = alloca { i64, [1 x i64] }, align 8
  %t1189 = alloca { i64, [3 x i64] }, align 8
  %t1354 = alloca { i64, [1 x i64] }, align 8
  %t1373 = alloca { i64, [3 x i64] }, align 8
  %t1466 = alloca { i64, [3 x i64] }, align 8
  %t1506 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Multi", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t10 = getelementptr %"compiler/ast:Multi", ptr %t8, i32 0, i32 2
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t15 = icmp eq i64 %t13, 1
  br i1 %t15, label %bb1, label %bb2
bb1:
  %t17 = load i64, ptr %l3, !tbaa !24
  %t19 = icmp sgt i64 %t17, 1
  store i1 %t19, ptr %l98, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l98, !tbaa !21
  br label %bb3
bb3:
  %t21 = load i1, ptr %l98, !tbaa !21
  br i1 %t21, label %bb4, label %bb5
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t25 = getelementptr %"compiler/ast:Multi", ptr %t23, i32 0, i32 2
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  store { i64, ptr } %t26, ptr %l103, !tbaa !27
  %t27 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr ptr, ptr %t28, i64 0
  %t30 = load ptr, ptr %t29, !tbaa !39
  %t32 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t36 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t22, ptr %t30, i32 %t32)
  store ptr %t36, ptr %l107
  br label %bb6
bb5:
  br label %bb64
bb6:
  %t37 = load ptr, ptr %l107, !tbaa !29
  store ptr %t37, ptr %l4, !tbaa !29
  %t38 = load ptr, ptr %l4, !tbaa !29
  %t41 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t38)
  store i32 %t41, ptr %l110
  br label %bb7
bb7:
  %t42 = load i32, ptr %l110, !tbaa !23
  store i32 %t42, ptr %l5, !tbaa !23
  %t43 = load i32, ptr %l5, !tbaa !23
  %t44 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t47 = icmp eq i32 %t43, %t44
  br i1 %t47, label %bb8, label %bb9
bb8:
  %t49 = load ptr, ptr %l2, !tbaa !29
  %t51 = getelementptr %"compiler/ast:Multi", ptr %t49, i32 0, i32 0
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  store { i64, ptr } %t52, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t54 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t54, 0
  store i64 %t56, ptr %l8, !tbaa !24
  br label %bb10
bb9:
  br label %bb17
bb10:
  %t58 = load i64, ptr %l7, !tbaa !24
  %t59 = load i64, ptr %l8, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb11, label %bb12
bb11:
  br label %bb16
bb12:
  br label %bb13
bb13:
  %t66 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t66, ptr %l122, !tbaa !27
  %t67 = load i64, ptr %l7, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr ptr, ptr %t70, i64 %t67
  %t72 = load ptr, ptr %t71, !tbaa !39
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = load ptr, ptr %l2, !tbaa !29
  %t78 = getelementptr %"compiler/ast:Multi", ptr %t76, i32 0, i32 1
  %t79 = load i1, ptr %t78, !tbaa !21
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclareUnknown(ptr %v0, ptr %v1, ptr %t74, ptr %t72, i1 %t79)
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t83 = load i64, ptr %l7, !tbaa !24
  %t85 = add i64 %t83, 1
  store i64 %t85, ptr %l7, !tbaa !24
  br label %bb10
bb16:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb17:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/check:Checker", ptr %t87, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t92 = getelementptr %"compiler/generic:Program", ptr %t90, i32 0, i32 2
  %t93 = load i32, ptr %l5, !tbaa !23
  %t96 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t92, i32 %t93)
  store i32 %t96, ptr %l135
  br label %bb18
bb18:
  %t97 = load i32, ptr %l135, !range !{i32 0, i32 33}
  %t99 = trunc i64 22 to i32
  %t100 = icmp eq i32 %t97, %t99
  %t102 = xor i1 %t100, true
  br i1 %t102, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s6
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l139, !tbaa !29
  %t105 = load ptr, ptr %l2, !tbaa !29
  %t107 = getelementptr %"compiler/ast:Multi", ptr %t105, i32 0, i32 2
  %t108 = load { i64, ptr }, ptr %t107, !tbaa !27
  store { i64, ptr } %t108, ptr %l141, !tbaa !27
  %t109 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr ptr, ptr %t110, i64 0
  %t112 = load ptr, ptr %t111, !tbaa !39
  %t114 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t112)
  store %"compiler/source:Span" %t114, ptr %l143
  br label %bb21
bb20:
  br label %bb32
bb21:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load i32, ptr %l5, !tbaa !23
  %t119 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s6, ptr %t115, i32 %t116)
  store { i64, ptr } %t119, ptr %l146
  br label %bb22
bb22:
  %t120 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t120, 0
  %t122 = extractvalue { i64, ptr } %t120, 1
  %t123 = mul i64 %t121, 1
  %t124 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t123)
  call void @llvm.memcpy.p0.p0.i64(ptr %t124, ptr %t122, i64 %t123, i1 false)
  %t125 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t124, 1
  %t128 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDestructOneValue(ptr %s6, ptr %s6, { i64, ptr } %t126)
  store %"compiler/diagmsg:Msg" %t128, ptr %l148
  br label %bb23
bb23:
  %t129 = load ptr, ptr %l139, !tbaa !29
  %t130 = load %"compiler/source:Span", ptr %l143
  %t131 = load %"compiler/diagmsg:Msg", ptr %l148
  %t132 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t129, %"compiler/source:Span" %t130, %"compiler/diagmsg:Msg" %t131)
  store i64 %t132, ptr %l149
  br label %bb24
bb24:
  %t133 = load ptr, ptr %l2, !tbaa !29
  %t135 = getelementptr %"compiler/ast:Multi", ptr %t133, i32 0, i32 0
  %t136 = load { i64, ptr }, ptr %t135, !tbaa !27
  store { i64, ptr } %t136, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t138 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t138, 0
  store i64 %t140, ptr %l12, !tbaa !24
  br label %bb25
bb25:
  %t142 = load i64, ptr %l11, !tbaa !24
  %t143 = load i64, ptr %l12, !tbaa !24
  %t146 = icmp slt i64 %t142, %t143
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb26, label %bb27
bb26:
  br label %bb31
bb27:
  br label %bb28
bb28:
  %t150 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t150, ptr %l158, !tbaa !27
  %t151 = load i64, ptr %l11, !tbaa !24
  %t153 = getelementptr { i64, ptr }, ptr %l158, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr ptr, ptr %t154, i64 %t151
  %t156 = load ptr, ptr %t155, !tbaa !39
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = load ptr, ptr %l2, !tbaa !29
  %t162 = getelementptr %"compiler/ast:Multi", ptr %t160, i32 0, i32 1
  %t163 = load i1, ptr %t162, !tbaa !21
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclareUnknown(ptr %v0, ptr %v1, ptr %t158, ptr %t156, i1 %t163)
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t167 = load i64, ptr %l11, !tbaa !24
  %t169 = add i64 %t167, 1
  store i64 %t169, ptr %l11, !tbaa !24
  br label %bb25
bb31:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb32:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/check:Checker", ptr %t171, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !29
  %t176 = getelementptr %"compiler/generic:Program", ptr %t174, i32 0, i32 2
  store ptr %t176, ptr %l169, !tbaa !29
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/check:Checker", ptr %t177, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !29
  %t182 = getelementptr %"compiler/generic:Program", ptr %t180, i32 0, i32 2
  %t183 = load i32, ptr %l5, !tbaa !23
  %t186 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t182, i32 %t183)
  store i32 %t186, ptr %l174
  br label %bb33
bb33:
  %t187 = load ptr, ptr %l169, !tbaa !29
  %t188 = load i32, ptr %l174, !tbaa !23
  %t189 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t187, i32 %t188)
  store { i64, ptr } %t189, ptr %l175
  br label %bb34
bb34:
  %t190 = load { i64, ptr }, ptr %l175, !tbaa !27
  store { i64, ptr } %t190, ptr %l14, !tbaa !27
  %t191 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t191, 0
  %t194 = load i64, ptr %l3, !tbaa !24
  %t197 = icmp ne i64 %t193, %t194
  br i1 %t197, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s10
  %t199 = load ptr, ptr %l0, !tbaa !29
  store ptr %t199, ptr %l180, !tbaa !29
  %t200 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t200, ptr %l181
  %t201 = load i64, ptr %l3, !tbaa !24
  %t202 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t202, 0
  %t207 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDestructCount(ptr %s10, i64 %t201, i64 %t204)
  store %"compiler/diagmsg:Msg" %t207, ptr %l185
  br label %bb37
bb36:
  br label %bb46
bb37:
  %t208 = load ptr, ptr %l180, !tbaa !29
  %t209 = load %"compiler/source:Span", ptr %l181
  %t210 = load %"compiler/diagmsg:Msg", ptr %l185
  %t211 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s10, ptr %t208, %"compiler/source:Span" %t209, %"compiler/diagmsg:Msg" %t210)
  store i64 %t211, ptr %l186
  br label %bb38
bb38:
  %t212 = load ptr, ptr %l2, !tbaa !29
  %t214 = getelementptr %"compiler/ast:Multi", ptr %t212, i32 0, i32 0
  %t215 = load { i64, ptr }, ptr %t214, !tbaa !27
  store { i64, ptr } %t215, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t217 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t219 = extractvalue { i64, ptr } %t217, 0
  store i64 %t219, ptr %l17, !tbaa !24
  br label %bb39
bb39:
  %t221 = load i64, ptr %l16, !tbaa !24
  %t222 = load i64, ptr %l17, !tbaa !24
  %t225 = icmp slt i64 %t221, %t222
  %t227 = xor i1 %t225, true
  br i1 %t227, label %bb40, label %bb41
bb40:
  br label %bb45
bb41:
  br label %bb42
bb42:
  %t229 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t229, ptr %l195, !tbaa !27
  %t230 = load i64, ptr %l16, !tbaa !24
  %t232 = getelementptr { i64, ptr }, ptr %l195, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !27
  %t234 = getelementptr ptr, ptr %t233, i64 %t230
  %t235 = load ptr, ptr %t234, !tbaa !39
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = load ptr, ptr %l2, !tbaa !29
  %t241 = getelementptr %"compiler/ast:Multi", ptr %t239, i32 0, i32 1
  %t242 = load i1, ptr %t241, !tbaa !21
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclareUnknown(ptr %v0, ptr %v1, ptr %t237, ptr %t235, i1 %t242)
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t246 = load i64, ptr %l16, !tbaa !24
  %t248 = add i64 %t246, 1
  store i64 %t248, ptr %l16, !tbaa !24
  br label %bb39
bb45:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb46:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load %"compiler/source:Span", ptr %l1
  %t252 = load i32, ptr %l5, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t253
  %t254 = getelementptr { i64, [1 x i64] }, ptr %t253, i32 0, i32 0
  store i64 0, ptr %t254
  %t255 = load { i64, [1 x i64] }, ptr %t253
  %t261 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t250, i32 0, %"compiler/source:Span" %t251, i32 %t252, i32 2, { i64, [1 x i64] } %t255)
  store i64 %t261, ptr %l209
  br label %bb47
bb47:
  %t262 = load i64, ptr %l209, !tbaa !24
  store i64 %t262, ptr %l19, !tbaa !24
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t264 = load %"compiler/source:Span", ptr %l1
  %t265 = load i64, ptr %l19, !tbaa !24
  %t267 = trunc i64 %t265 to i32
  %t269 = load ptr, ptr %l4, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t270
  %t271 = getelementptr { i64, [3 x i64] }, ptr %t270, i32 0, i32 0
  store i64 0, ptr %t271
  %t273 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t264, 0
  %t275 = insertvalue { %"compiler/source:Span", i32, ptr } %t273, i32 %t267, 1
  %t277 = insertvalue { %"compiler/source:Span", i32, ptr } %t275, ptr %t269, 2
  %t278 = getelementptr { i64, [3 x i64] }, ptr %t270, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t277, ptr %t278
  %t279 = load { i64, [3 x i64] }, ptr %t270
  %t281 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t279, ptr %t281
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t263, ptr %t281)
  br label %bb48
bb48:
  store i64 0, ptr %l20, !tbaa !24
  %t284 = load i64, ptr %l3, !tbaa !24
  store i64 %t284, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t286 = load i64, ptr %l21, !tbaa !24
  %t287 = load i64, ptr %l20, !tbaa !24
  %t290 = icmp sgt i64 %t286, %t287
  br i1 %t290, label %bb49, label %bb50
bb49:
  %t292 = load i64, ptr %l22, !tbaa !24
  %t294 = icmp sgt i64 %t292, 0
  br i1 %t294, label %bb51, label %bb52
bb50:
  store i64 0, ptr %l222, !tbaa !24
  br label %bb54
bb51:
  %t296 = load i64, ptr %l21, !tbaa !24
  %t297 = load i64, ptr %l20, !tbaa !24
  %t300 = sub i64 %t296, %t297
  %t301 = load i64, ptr %l22, !tbaa !24
  %t304 = add i64 %t300, %t301
  %t306 = sub i64 %t304, 1
  %t307 = load i64, ptr %l22, !tbaa !24
  %t310 = sdiv i64 %t306, %t307
  store i64 %t310, ptr %l225, !tbaa !24
  br label %bb53
bb52:
  store i64 0, ptr %l225, !tbaa !24
  br label %bb53
bb53:
  %t312 = load i64, ptr %l225, !tbaa !24
  store i64 %t312, ptr %l222, !tbaa !24
  br label %bb54
bb54:
  %t313 = load i64, ptr %l222, !tbaa !24
  store i64 %t313, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb55
bb55:
  %t314 = load i64, ptr %l24, !tbaa !24
  %t315 = load i64, ptr %l23, !tbaa !24
  %t318 = icmp slt i64 %t314, %t315
  %t320 = xor i1 %t318, true
  br i1 %t320, label %bb56, label %bb57
bb56:
  br label %bb63
bb57:
  br label %bb58
bb58:
  %t322 = load i64, ptr %l20, !tbaa !24
  %t323 = load i64, ptr %l24, !tbaa !24
  %t324 = load i64, ptr %l22, !tbaa !24
  %t327 = mul i64 %t323, %t324
  %t330 = add i64 %t322, %t327
  store i64 %t330, ptr %l25, !tbaa !24
  %t332 = load ptr, ptr %l2, !tbaa !29
  %t334 = getelementptr %"compiler/ast:Multi", ptr %t332, i32 0, i32 0
  %t335 = load { i64, ptr }, ptr %t334, !tbaa !27
  store { i64, ptr } %t335, ptr %l244, !tbaa !27
  %t336 = load i64, ptr %l25, !tbaa !24
  %t338 = getelementptr { i64, ptr }, ptr %l244, i32 0, i32 1
  %t339 = load ptr, ptr %t338, !tbaa !27
  %t340 = getelementptr ptr, ptr %t339, i64 %t336
  %t341 = load ptr, ptr %t340, !tbaa !39
  %t343 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t341)
  store %"compiler/source:Span" %t343, ptr %l247
  br label %bb59
bb59:
  %t344 = load %"compiler/source:Span", ptr %l247
  store %"compiler/source:Span" %t344, ptr %l26
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t346 = load %"compiler/source:Span", ptr %l26
  %t347 = load %"compiler/source:Span", ptr %l26
  %t348 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t348, ptr %l251, !tbaa !27
  %t349 = load i64, ptr %l25, !tbaa !24
  %t351 = getelementptr { i64, ptr }, ptr %l251, i32 0, i32 1
  %t352 = load ptr, ptr %t351, !tbaa !27
  %t353 = getelementptr i32, ptr %t352, i64 %t349
  %t354 = load i32, ptr %t353, !tbaa !33
  %t355 = load %"compiler/source:Span", ptr %l26
  %t356 = load i32, ptr %l5, !tbaa !23
  %t357 = load i64, ptr %l19, !tbaa !24
  %t359 = trunc i64 %t357 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t361
  %t362 = getelementptr { i64, [4 x i64] }, ptr %t361, i32 0, i32 0
  store i64 0, ptr %t362
  %t364 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t355, 0
  %t366 = insertvalue { %"compiler/source:Span", i32, i32 } %t364, i32 %t356, 1
  %t368 = insertvalue { %"compiler/source:Span", i32, i32 } %t366, i32 %t359, 2
  %t369 = getelementptr { i64, [4 x i64] }, ptr %t361, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t368, ptr %t369
  %t370 = load { i64, [4 x i64] }, ptr %t361
  %t372 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t370, ptr %t372
  %t373 = load i64, ptr %l25, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t374
  %t375 = getelementptr { i64, [4 x i64] }, ptr %t374, i32 0, i32 0
  store i64 3, ptr %t375
  %t377 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t347, 0
  %t379 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t377, i32 %t354, 1
  %t381 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t379, ptr %t372, 2
  %t383 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t381, i64 %t373, 3
  %t384 = getelementptr { i64, [4 x i64] }, ptr %t374, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t383, ptr %t384
  %t385 = load { i64, [4 x i64] }, ptr %t374
  %t387 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t385, ptr %t387
  %t391 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t345, %"compiler/source:Span" %t346, ptr %t387)
  store ptr %t391, ptr %l264
  br label %bb60
bb60:
  %t392 = load ptr, ptr %l264, !tbaa !29
  %t393 = load ptr, ptr %l0, !tbaa !29
  %t394 = load ptr, ptr %l2, !tbaa !29
  %t396 = getelementptr %"compiler/ast:Multi", ptr %t394, i32 0, i32 0
  %t397 = load { i64, ptr }, ptr %t396, !tbaa !27
  store { i64, ptr } %t397, ptr %l267, !tbaa !27
  %t398 = load i64, ptr %l25, !tbaa !24
  %t400 = getelementptr { i64, ptr }, ptr %l267, i32 0, i32 1
  %t401 = load ptr, ptr %t400, !tbaa !27
  %t402 = getelementptr ptr, ptr %t401, i64 %t398
  %t403 = load ptr, ptr %t402, !tbaa !39
  %t404 = load ptr, ptr %l2, !tbaa !29
  %t406 = getelementptr %"compiler/ast:Multi", ptr %t404, i32 0, i32 1
  %t407 = load i1, ptr %t406, !tbaa !21
  %t409 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t409, ptr %l273, !tbaa !27
  %t410 = load i64, ptr %l25, !tbaa !24
  %t412 = getelementptr { i64, ptr }, ptr %l273, i32 0, i32 1
  %t413 = load ptr, ptr %t412, !tbaa !27
  %t414 = getelementptr i32, ptr %t413, i64 %t410
  %t415 = load i32, ptr %t414, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eputTarget(ptr %v0, ptr %v1, ptr %v0, ptr %t393, ptr %t403, i1 %t407, ptr %t392, i32 %t415)
  br label %bb61
bb61:
  br label %bb62
bb62:
  %t421 = load i64, ptr %l24, !tbaa !24
  %t423 = add i64 %t421, 1
  store i64 %t423, ptr %l24, !tbaa !24
  br label %bb55
bb63:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb64:
  %t425 = load ptr, ptr %l2, !tbaa !29
  %t427 = getelementptr %"compiler/ast:Multi", ptr %t425, i32 0, i32 2
  %t428 = load { i64, ptr }, ptr %t427, !tbaa !27
  %t430 = extractvalue { i64, ptr } %t428, 0
  %t431 = load i64, ptr %l3, !tbaa !24
  %t434 = icmp ne i64 %t430, %t431
  br i1 %t434, label %bb65, label %bb66
bb65:
  store %olang.scope zeroinitializer, ptr %s17
  %t436 = load ptr, ptr %l0, !tbaa !29
  store ptr %t436, ptr %l283, !tbaa !29
  %t437 = load ptr, ptr %l0, !tbaa !29
  store ptr %t437, ptr %l284, !tbaa !29
  %t438 = load ptr, ptr %l2, !tbaa !29
  %t440 = getelementptr %"compiler/ast:Multi", ptr %t438, i32 0, i32 0
  %t441 = load { i64, ptr }, ptr %t440, !tbaa !27
  store { i64, ptr } %t441, ptr %l286, !tbaa !27
  %t442 = load i64, ptr %l3, !tbaa !24
  %t444 = sub i64 %t442, 1
  %t446 = getelementptr { i64, ptr }, ptr %l286, i32 0, i32 1
  %t447 = load ptr, ptr %t446, !tbaa !27
  %t448 = getelementptr ptr, ptr %t447, i64 %t444
  %t449 = load ptr, ptr %t448, !tbaa !39
  %t451 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t449)
  store %"compiler/source:Span" %t451, ptr %l290
  br label %bb67
bb66:
  br label %bb81
bb67:
  %t452 = load ptr, ptr %l2, !tbaa !29
  %t454 = getelementptr %"compiler/ast:Multi", ptr %t452, i32 0, i32 1
  %t455 = load i1, ptr %t454, !tbaa !21
  br i1 %t455, label %bb68, label %bb69
bb68:
  store i64 2, ptr %l293, !tbaa !24
  br label %bb70
bb69:
  store i64 1, ptr %l293, !tbaa !24
  br label %bb70
bb70:
  %t457 = load ptr, ptr %l284, !tbaa !29
  %t458 = load %"compiler/source:Span", ptr %l290
  %t459 = load i64, ptr %l293, !tbaa !24
  %t460 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAfter(ptr %v0, ptr %t457, %"compiler/source:Span" %t458, i64 %t459)
  store %"compiler/source:Span" %t460, ptr %l294
  br label %bb71
bb71:
  %t461 = load i64, ptr %l3, !tbaa !24
  %t462 = load ptr, ptr %l2, !tbaa !29
  %t464 = getelementptr %"compiler/ast:Multi", ptr %t462, i32 0, i32 2
  %t465 = load { i64, ptr }, ptr %t464, !tbaa !27
  %t467 = extractvalue { i64, ptr } %t465, 0
  %t470 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAssignListCount(ptr %s17, i64 %t461, i64 %t467)
  store %"compiler/diagmsg:Msg" %t470, ptr %l299
  br label %bb72
bb72:
  %t471 = load ptr, ptr %l283, !tbaa !29
  %t472 = load %"compiler/source:Span", ptr %l294
  %t473 = load %"compiler/diagmsg:Msg", ptr %l299
  %t474 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s17, ptr %t471, %"compiler/source:Span" %t472, %"compiler/diagmsg:Msg" %t473)
  store i64 %t474, ptr %l300
  br label %bb73
bb73:
  %t475 = load ptr, ptr %l2, !tbaa !29
  %t477 = getelementptr %"compiler/ast:Multi", ptr %t475, i32 0, i32 2
  %t478 = load { i64, ptr }, ptr %t477, !tbaa !27
  store { i64, ptr } %t478, ptr %l28, !tbaa !27
  store i64 0, ptr %l29, !tbaa !24
  %t480 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t482 = extractvalue { i64, ptr } %t480, 0
  store i64 %t482, ptr %l30, !tbaa !24
  br label %bb74
bb74:
  %t484 = load i64, ptr %l29, !tbaa !24
  %t485 = load i64, ptr %l30, !tbaa !24
  %t488 = icmp slt i64 %t484, %t485
  %t490 = xor i1 %t488, true
  br i1 %t490, label %bb75, label %bb76
bb75:
  br label %bb80
bb76:
  br label %bb77
bb77:
  %t492 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t492, ptr %l309, !tbaa !27
  %t493 = load i64, ptr %l29, !tbaa !24
  %t495 = getelementptr { i64, ptr }, ptr %l309, i32 0, i32 1
  %t496 = load ptr, ptr %t495, !tbaa !27
  %t497 = getelementptr ptr, ptr %t496, i64 %t493
  %t498 = load ptr, ptr %t497, !tbaa !39
  %t500 = load ptr, ptr %l0, !tbaa !29
  %t503 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t507 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t500, ptr %t498, i32 %t503)
  store ptr %t507, ptr %l316
  br label %bb78
bb78:
  br label %bb79
bb79:
  %t508 = load i64, ptr %l29, !tbaa !24
  %t510 = add i64 %t508, 1
  store i64 %t510, ptr %l29, !tbaa !24
  br label %bb74
bb80:
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb81:
  %t512 = load ptr, ptr %l2, !tbaa !29
  %t514 = getelementptr %"compiler/ast:Multi", ptr %t512, i32 0, i32 1
  %t515 = load i1, ptr %t514, !tbaa !21
  br i1 %t515, label %bb82, label %bb83
bb82:
  store i64 0, ptr %l32, !tbaa !24
  %t517 = load i64, ptr %l3, !tbaa !24
  store i64 %t517, ptr %l33, !tbaa !24
  store i64 1, ptr %l34, !tbaa !24
  %t519 = load i64, ptr %l33, !tbaa !24
  %t520 = load i64, ptr %l32, !tbaa !24
  %t523 = icmp sgt i64 %t519, %t520
  br i1 %t523, label %bb84, label %bb85
bb83:
  br label %bb130
bb84:
  %t525 = load i64, ptr %l34, !tbaa !24
  %t527 = icmp sgt i64 %t525, 0
  br i1 %t527, label %bb86, label %bb87
bb85:
  store i64 0, ptr %l325, !tbaa !24
  br label %bb89
bb86:
  %t529 = load i64, ptr %l33, !tbaa !24
  %t530 = load i64, ptr %l32, !tbaa !24
  %t533 = sub i64 %t529, %t530
  %t534 = load i64, ptr %l34, !tbaa !24
  %t537 = add i64 %t533, %t534
  %t539 = sub i64 %t537, 1
  %t540 = load i64, ptr %l34, !tbaa !24
  %t543 = sdiv i64 %t539, %t540
  store i64 %t543, ptr %l328, !tbaa !24
  br label %bb88
bb87:
  store i64 0, ptr %l328, !tbaa !24
  br label %bb88
bb88:
  %t545 = load i64, ptr %l328, !tbaa !24
  store i64 %t545, ptr %l325, !tbaa !24
  br label %bb89
bb89:
  %t546 = load i64, ptr %l325, !tbaa !24
  store i64 %t546, ptr %l35, !tbaa !24
  store i64 0, ptr %l36, !tbaa !24
  br label %bb90
bb90:
  %t547 = load i64, ptr %l36, !tbaa !24
  %t548 = load i64, ptr %l35, !tbaa !24
  %t551 = icmp slt i64 %t547, %t548
  %t553 = xor i1 %t551, true
  br i1 %t553, label %bb91, label %bb92
bb91:
  br label %bb129
bb92:
  br label %bb93
bb93:
  %t555 = load i64, ptr %l32, !tbaa !24
  %t556 = load i64, ptr %l36, !tbaa !24
  %t557 = load i64, ptr %l34, !tbaa !24
  %t560 = mul i64 %t556, %t557
  %t563 = add i64 %t555, %t560
  store i64 %t563, ptr %l37, !tbaa !24
  %t565 = load ptr, ptr %l0, !tbaa !29
  %t566 = load ptr, ptr %l2, !tbaa !29
  %t568 = getelementptr %"compiler/ast:Multi", ptr %t566, i32 0, i32 2
  %t569 = load { i64, ptr }, ptr %t568, !tbaa !27
  store { i64, ptr } %t569, ptr %l348, !tbaa !27
  %t570 = load i64, ptr %l37, !tbaa !24
  %t572 = getelementptr { i64, ptr }, ptr %l348, i32 0, i32 1
  %t573 = load ptr, ptr %t572, !tbaa !27
  %t574 = getelementptr ptr, ptr %t573, i64 %t570
  %t575 = load ptr, ptr %t574, !tbaa !39
  %t577 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t581 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t565, ptr %t575, i32 %t577)
  store ptr %t581, ptr %l353
  br label %bb94
bb94:
  %t582 = load ptr, ptr %l353, !tbaa !29
  store ptr %t582, ptr %l38, !tbaa !29
  %t583 = load ptr, ptr %l0, !tbaa !29
  store ptr %t583, ptr %l354, !tbaa !29
  %t584 = load ptr, ptr %l2, !tbaa !29
  %t586 = getelementptr %"compiler/ast:Multi", ptr %t584, i32 0, i32 2
  %t587 = load { i64, ptr }, ptr %t586, !tbaa !27
  store { i64, ptr } %t587, ptr %l356, !tbaa !27
  %t588 = load i64, ptr %l37, !tbaa !24
  %t590 = getelementptr { i64, ptr }, ptr %l356, i32 0, i32 1
  %t591 = load ptr, ptr %t590, !tbaa !27
  %t592 = getelementptr ptr, ptr %t591, i64 %t588
  %t593 = load ptr, ptr %t592, !tbaa !39
  store ptr %t593, ptr %l358, !tbaa !29
  %t594 = load ptr, ptr %l38, !tbaa !29
  store ptr %t594, ptr %l359, !tbaa !29
  %t595 = load ptr, ptr %l0, !tbaa !29
  %t596 = load ptr, ptr %l2, !tbaa !29
  %t598 = getelementptr %"compiler/ast:Multi", ptr %t596, i32 0, i32 0
  %t599 = load { i64, ptr }, ptr %t598, !tbaa !27
  store { i64, ptr } %t599, ptr %l362, !tbaa !27
  %t600 = load i64, ptr %l37, !tbaa !24
  %t602 = getelementptr { i64, ptr }, ptr %l362, i32 0, i32 1
  %t603 = load ptr, ptr %t602, !tbaa !27
  %t604 = getelementptr ptr, ptr %t603, i64 %t600
  %t605 = load ptr, ptr %t604, !tbaa !39
  %t608 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estoredName(ptr %v0, ptr %v1, ptr %t595, ptr %t605)
  store i1 %t608, ptr %l365
  br label %bb95
bb95:
  %t609 = load i1, ptr %l365, !tbaa !21
  %t610 = xor i1 %t609, true
  %t611 = load ptr, ptr %l354, !tbaa !29
  %t612 = load ptr, ptr %l358, !tbaa !29
  %t613 = load ptr, ptr %l359, !tbaa !29
  %t615 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferred(ptr %v0, ptr %v1, ptr %v0, ptr %t611, ptr %t612, ptr %t613, i1 %t610)
  store i32 %t615, ptr %l367
  br label %bb96
bb96:
  %t616 = load i32, ptr %l367, !tbaa !23
  store i32 %t616, ptr %l39, !tbaa !23
  %t617 = load ptr, ptr %l2, !tbaa !29
  %t619 = getelementptr %"compiler/ast:Multi", ptr %t617, i32 0, i32 2
  %t620 = load { i64, ptr }, ptr %t619, !tbaa !27
  store { i64, ptr } %t620, ptr %l369, !tbaa !27
  %t621 = load i64, ptr %l37, !tbaa !24
  %t623 = getelementptr { i64, ptr }, ptr %l369, i32 0, i32 1
  %t624 = load ptr, ptr %t623, !tbaa !27
  %t625 = getelementptr ptr, ptr %t624, i64 %t621
  %t626 = load ptr, ptr %t625, !tbaa !39
  %t628 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t626)
  store %"compiler/source:Span" %t628, ptr %l372
  br label %bb97
bb97:
  %t629 = load %"compiler/source:Span", ptr %l372
  store %"compiler/source:Span" %t629, ptr %l40
  %t630 = load i32, ptr %l39, !tbaa !23
  store i32 %t630, ptr %l373, !tbaa !23
  %t631 = load ptr, ptr %l0, !tbaa !29
  %t633 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t631)
  store i32 %t633, ptr %l375
  br label %bb98
bb98:
  %t634 = load i32, ptr %l373, !tbaa !23
  %t635 = load i32, ptr %l375, !tbaa !23
  %t636 = icmp eq i32 %t634, %t635
  br i1 %t636, label %bb99, label %bb100
bb99:
  %t638 = load ptr, ptr %l0, !tbaa !29
  store ptr %t638, ptr %l378, !tbaa !29
  %t639 = load ptr, ptr %l38, !tbaa !29
  %t642 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t639)
  store i32 %t642, ptr %l381
  br label %bb101
bb100:
  store i1 false, ptr %l377, !tbaa !21
  br label %bb103
bb101:
  %t643 = load ptr, ptr %l378, !tbaa !29
  %t644 = load i32, ptr %l381, !tbaa !23
  %t645 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t643, i32 %t644)
  store i1 %t645, ptr %l382
  br label %bb102
bb102:
  %t646 = load i1, ptr %l382, !tbaa !21
  store i1 %t646, ptr %l377, !tbaa !21
  br label %bb103
bb103:
  %t647 = load i1, ptr %l377, !tbaa !21
  br i1 %t647, label %bb104, label %bb105
bb104:
  %t648 = load ptr, ptr %l0, !tbaa !29
  %t649 = load %"compiler/source:Span", ptr %l40
  %t650 = load %"compiler/source:Span", ptr %l40
  %t651 = load i32, ptr %l39, !tbaa !23
  %t652 = load ptr, ptr %l38, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t653
  %t654 = getelementptr { i64, [4 x i64] }, ptr %t653, i32 0, i32 0
  store i64 2, ptr %t654
  %t656 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t650, 0
  %t658 = insertvalue { %"compiler/source:Span", i32, ptr } %t656, i32 %t651, 1
  %t660 = insertvalue { %"compiler/source:Span", i32, ptr } %t658, ptr %t652, 2
  %t661 = getelementptr { i64, [4 x i64] }, ptr %t653, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t660, ptr %t661
  %t662 = load { i64, [4 x i64] }, ptr %t653
  %t664 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t662, ptr %t664
  %t668 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t648, %"compiler/source:Span" %t649, ptr %t664)
  store ptr %t668, ptr %l390
  br label %bb106
bb105:
  br label %bb107
bb106:
  %t669 = load ptr, ptr %l390, !tbaa !29
  store ptr %t669, ptr %l38, !tbaa !29
  br label %bb107
bb107:
  %t670 = load ptr, ptr %l0, !tbaa !29
  %t671 = load i32, ptr %l39, !tbaa !23
  %t674 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t670, i32 %t671)
  store i1 %t674, ptr %l393
  br label %bb108
bb108:
  %t675 = load i1, ptr %l393, !tbaa !21
  %t676 = xor i1 %t675, true
  br i1 %t676, label %bb109, label %bb110
bb109:
  %t678 = load ptr, ptr %l0, !tbaa !29
  %t679 = load ptr, ptr %l38, !tbaa !29
  %t682 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueExisting(ptr %v0, ptr %v0, ptr %t678, ptr %t679)
  store i1 %t682, ptr %l398
  br label %bb111
bb110:
  store i1 false, ptr %l395, !tbaa !21
  br label %bb112
bb111:
  %t683 = load i1, ptr %l398, !tbaa !21
  store i1 %t683, ptr %l395, !tbaa !21
  br label %bb112
bb112:
  %t684 = load i1, ptr %l395, !tbaa !21
  br i1 %t684, label %bb113, label %bb114
bb113:
  %t685 = load ptr, ptr %l0, !tbaa !29
  %t686 = load ptr, ptr %l38, !tbaa !29
  %t687 = load %"compiler/source:Span", ptr %l40
  %t691 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueRef(ptr %v0, ptr %v0, ptr %v0, ptr %t685, ptr %t686, %"compiler/source:Span" %t687, i1 true)
  store ptr %t691, ptr %l402
  br label %bb115
bb114:
  br label %bb117
bb115:
  %t692 = load ptr, ptr %l402, !tbaa !29
  store ptr %t692, ptr %l38, !tbaa !29
  %t693 = load ptr, ptr %l38, !tbaa !29
  %t696 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t693)
  store i32 %t696, ptr %l405
  br label %bb116
bb116:
  %t697 = load i32, ptr %l405, !tbaa !23
  store i32 %t697, ptr %l39, !tbaa !23
  br label %bb117
bb117:
  %t698 = load ptr, ptr %l0, !tbaa !29
  %t699 = load i32, ptr %l39, !tbaa !23
  %t702 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t698, i32 %t699)
  store i1 %t702, ptr %l408
  br label %bb118
bb118:
  %t703 = load i1, ptr %l408, !tbaa !21
  %t704 = xor i1 %t703, true
  br i1 %t704, label %bb119, label %bb120
bb119:
  %t706 = load ptr, ptr %l0, !tbaa !29
  %t708 = getelementptr %"compiler/check:Checker", ptr %t706, i32 0, i32 1
  %t709 = load ptr, ptr %t708, !tbaa !29
  %t711 = getelementptr %"compiler/generic:Program", ptr %t709, i32 0, i32 2
  %t712 = load i32, ptr %l39, !tbaa !23
  %t715 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %t711, i32 %t712)
  store i1 %t715, ptr %l415
  br label %bb121
bb120:
  store i1 false, ptr %l410, !tbaa !21
  br label %bb122
bb121:
  %t716 = load i1, ptr %l415, !tbaa !21
  store i1 %t716, ptr %l410, !tbaa !21
  br label %bb122
bb122:
  %t717 = load i1, ptr %l410, !tbaa !21
  br i1 %t717, label %bb123, label %bb124
bb123:
  %t718 = load ptr, ptr %l0, !tbaa !29
  %t719 = load ptr, ptr %l38, !tbaa !29
  %t722 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownCopy(ptr %v0, ptr %v0, ptr %v0, ptr %t718, ptr %t719)
  store ptr %t722, ptr %l418
  br label %bb125
bb124:
  br label %bb126
bb125:
  %t723 = load ptr, ptr %l418, !tbaa !29
  store ptr %t723, ptr %l38, !tbaa !29
  br label %bb126
bb126:
  %t724 = load ptr, ptr %l0, !tbaa !29
  %t725 = load ptr, ptr %l2, !tbaa !29
  %t727 = getelementptr %"compiler/ast:Multi", ptr %t725, i32 0, i32 0
  %t728 = load { i64, ptr }, ptr %t727, !tbaa !27
  store { i64, ptr } %t728, ptr %l421, !tbaa !27
  %t729 = load i64, ptr %l37, !tbaa !24
  %t731 = getelementptr { i64, ptr }, ptr %l421, i32 0, i32 1
  %t732 = load ptr, ptr %t731, !tbaa !27
  %t733 = getelementptr ptr, ptr %t732, i64 %t729
  %t734 = load ptr, ptr %t733, !tbaa !39
  %t735 = load ptr, ptr %l38, !tbaa !29
  %t736 = load i32, ptr %l39, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eputTarget(ptr %v0, ptr %v1, ptr %v0, ptr %t724, ptr %t734, i1 true, ptr %t735, i32 %t736)
  br label %bb127
bb127:
  br label %bb128
bb128:
  %t741 = load i64, ptr %l36, !tbaa !24
  %t743 = add i64 %t741, 1
  store i64 %t743, ptr %l36, !tbaa !24
  br label %bb90
bb129:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb130:
  %t745 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t745, ptr %l428
  br label %bb131
bb131:
  %t746 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l428
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t746, ptr %l41
  %t747 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t747, ptr %l429
  br label %bb132
bb132:
  %t748 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l429
  %t749 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t748, ptr %t749
  store ptr %t749, ptr %l42, !tbaa !29
  %t751 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3asetAt_3f_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t751, ptr %l431
  br label %bb133
bb133:
  %t752 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l431
  %t753 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t752, ptr %t753
  store ptr %t753, ptr %l43, !tbaa !29
  store i64 0, ptr %l44, !tbaa !24
  %t755 = load i64, ptr %l3, !tbaa !24
  store i64 %t755, ptr %l45, !tbaa !24
  store i64 1, ptr %l46, !tbaa !24
  %t757 = load i64, ptr %l45, !tbaa !24
  %t758 = load i64, ptr %l44, !tbaa !24
  %t761 = icmp sgt i64 %t757, %t758
  br i1 %t761, label %bb134, label %bb135
bb134:
  %t763 = load i64, ptr %l46, !tbaa !24
  %t765 = icmp sgt i64 %t763, 0
  br i1 %t765, label %bb136, label %bb137
bb135:
  store i64 0, ptr %l437, !tbaa !24
  br label %bb139
bb136:
  %t767 = load i64, ptr %l45, !tbaa !24
  %t768 = load i64, ptr %l44, !tbaa !24
  %t771 = sub i64 %t767, %t768
  %t772 = load i64, ptr %l46, !tbaa !24
  %t775 = add i64 %t771, %t772
  %t777 = sub i64 %t775, 1
  %t778 = load i64, ptr %l46, !tbaa !24
  %t781 = sdiv i64 %t777, %t778
  store i64 %t781, ptr %l440, !tbaa !24
  br label %bb138
bb137:
  store i64 0, ptr %l440, !tbaa !24
  br label %bb138
bb138:
  %t783 = load i64, ptr %l440, !tbaa !24
  store i64 %t783, ptr %l437, !tbaa !24
  br label %bb139
bb139:
  %t784 = load i64, ptr %l437, !tbaa !24
  store i64 %t784, ptr %l47, !tbaa !24
  store i64 0, ptr %l48, !tbaa !24
  br label %bb140
bb140:
  %t785 = load i64, ptr %l48, !tbaa !24
  %t786 = load i64, ptr %l47, !tbaa !24
  %t789 = icmp slt i64 %t785, %t786
  %t791 = xor i1 %t789, true
  br i1 %t791, label %bb141, label %bb142
bb141:
  br label %bb152
bb142:
  br label %bb143
bb143:
  %t793 = load i64, ptr %l44, !tbaa !24
  %t794 = load i64, ptr %l48, !tbaa !24
  %t795 = load i64, ptr %l46, !tbaa !24
  %t798 = mul i64 %t794, %t795
  %t801 = add i64 %t793, %t798
  store i64 %t801, ptr %l49, !tbaa !24
  %t803 = load ptr, ptr %l0, !tbaa !29
  %t804 = load ptr, ptr %l2, !tbaa !29
  %t806 = getelementptr %"compiler/ast:Multi", ptr %t804, i32 0, i32 0
  %t807 = load { i64, ptr }, ptr %t806, !tbaa !27
  store { i64, ptr } %t807, ptr %l460, !tbaa !27
  %t808 = load i64, ptr %l49, !tbaa !24
  %t810 = getelementptr { i64, ptr }, ptr %l460, i32 0, i32 1
  %t811 = load ptr, ptr %t810, !tbaa !27
  %t812 = getelementptr ptr, ptr %t811, i64 %t808
  %t813 = load ptr, ptr %t812, !tbaa !39
  %t816 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetAtTarget(ptr %v0, ptr %v1, ptr %v0, ptr %t803, ptr %t813)
  store ptr %t816, ptr %l463
  br label %bb144
bb144:
  %t817 = load ptr, ptr %l463, !tbaa !29
  store ptr %t817, ptr %l50, !tbaa !29
  %t818 = load ptr, ptr %l43, !tbaa !29
  %t819 = load ptr, ptr %l50, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3asetAt_3f_26_3e_2ePu_H987461f55898bae561e1d5349703380d(ptr %v0, ptr %v0, ptr %t818, ptr %t819)
  br label %bb145
bb145:
  %t822 = load ptr, ptr %l50, !tbaa !29
  %t824 = icmp eq ptr %t822, null
  br i1 %t824, label %bb146, label %bb147
bb146:
  %t826 = load ptr, ptr %l0, !tbaa !29
  %t827 = load ptr, ptr %l2, !tbaa !29
  %t829 = getelementptr %"compiler/ast:Multi", ptr %t827, i32 0, i32 0
  %t830 = load { i64, ptr }, ptr %t829, !tbaa !27
  store { i64, ptr } %t830, ptr %l471, !tbaa !27
  %t831 = load i64, ptr %l49, !tbaa !24
  %t833 = getelementptr { i64, ptr }, ptr %l471, i32 0, i32 1
  %t834 = load ptr, ptr %t833, !tbaa !27
  %t835 = getelementptr ptr, ptr %t834, i64 %t831
  %t836 = load ptr, ptr %t835, !tbaa !39
  %t839 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ediscardOr(ptr %v0, ptr %v1, ptr %v0, ptr %t826, ptr %t836)
  store ptr %t839, ptr %l474
  br label %bb148
bb147:
  store ptr null, ptr %l468, !tbaa !29
  br label %bb149
bb148:
  %t840 = load ptr, ptr %l474, !tbaa !29
  store ptr %t840, ptr %l468, !tbaa !29
  br label %bb149
bb149:
  %t841 = load ptr, ptr %l468, !tbaa !29
  %t842 = load ptr, ptr %l42, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eP_Ha5c233616e2ae02d7fe37742cfaef2c2(ptr %v0, ptr %v0, ptr %t842, ptr %t841)
  br label %bb150
bb150:
  br label %bb151
bb151:
  %t846 = load i64, ptr %l48, !tbaa !24
  %t848 = add i64 %t846, 1
  store i64 %t848, ptr %l48, !tbaa !24
  br label %bb140
bb152:
  store i64 0, ptr %l52, !tbaa !24
  %t850 = load i64, ptr %l3, !tbaa !24
  store i64 %t850, ptr %l53, !tbaa !24
  store i64 1, ptr %l54, !tbaa !24
  %t852 = load i64, ptr %l53, !tbaa !24
  %t853 = load i64, ptr %l52, !tbaa !24
  %t856 = icmp sgt i64 %t852, %t853
  br i1 %t856, label %bb153, label %bb154
bb153:
  %t858 = load i64, ptr %l54, !tbaa !24
  %t860 = icmp sgt i64 %t858, 0
  br i1 %t860, label %bb155, label %bb156
bb154:
  store i64 0, ptr %l483, !tbaa !24
  br label %bb158
bb155:
  %t862 = load i64, ptr %l53, !tbaa !24
  %t863 = load i64, ptr %l52, !tbaa !24
  %t866 = sub i64 %t862, %t863
  %t867 = load i64, ptr %l54, !tbaa !24
  %t870 = add i64 %t866, %t867
  %t872 = sub i64 %t870, 1
  %t873 = load i64, ptr %l54, !tbaa !24
  %t876 = sdiv i64 %t872, %t873
  store i64 %t876, ptr %l486, !tbaa !24
  br label %bb157
bb156:
  store i64 0, ptr %l486, !tbaa !24
  br label %bb157
bb157:
  %t878 = load i64, ptr %l486, !tbaa !24
  store i64 %t878, ptr %l483, !tbaa !24
  br label %bb158
bb158:
  %t879 = load i64, ptr %l483, !tbaa !24
  store i64 %t879, ptr %l55, !tbaa !24
  store i64 0, ptr %l56, !tbaa !24
  br label %bb159
bb159:
  %t880 = load i64, ptr %l56, !tbaa !24
  %t881 = load i64, ptr %l55, !tbaa !24
  %t884 = icmp slt i64 %t880, %t881
  %t886 = xor i1 %t884, true
  br i1 %t886, label %bb160, label %bb161
bb160:
  br label %bb175
bb161:
  br label %bb162
bb162:
  %t888 = load i64, ptr %l52, !tbaa !24
  %t889 = load i64, ptr %l56, !tbaa !24
  %t890 = load i64, ptr %l54, !tbaa !24
  %t893 = mul i64 %t889, %t890
  %t896 = add i64 %t888, %t893
  store i64 %t896, ptr %l57, !tbaa !24
  %t898 = load ptr, ptr %l42, !tbaa !29
  %t899 = load i64, ptr %l57, !tbaa !24
  %t902 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eA_Hf8c35f4f5353320ac1e6ff0719acdfb7(ptr %v0, ptr %v0, ptr %t898, i64 %t899)
  store ptr %t902, ptr %l506
  br label %bb163
bb163:
  %t903 = load ptr, ptr %l506, !tbaa !29
  store ptr %t903, ptr %l58, !tbaa !29
  %t904 = load ptr, ptr %l58, !tbaa !29
  %t906 = icmp eq ptr %t904, null
  %t908 = xor i1 %t906, true
  br i1 %t908, label %bb164, label %bb165
bb164:
  %t910 = load ptr, ptr %l0, !tbaa !29
  %t911 = load ptr, ptr %l58, !tbaa !29
  %t914 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewholeColumn(ptr %v0, ptr %v0, ptr %t910, ptr %t911)
  store i1 %t914, ptr %l513
  br label %bb166
bb165:
  store i1 false, ptr %l510, !tbaa !21
  br label %bb167
bb166:
  %t915 = load i1, ptr %l513, !tbaa !21
  store i1 %t915, ptr %l510, !tbaa !21
  br label %bb167
bb167:
  %t916 = load i1, ptr %l510, !tbaa !21
  br i1 %t916, label %bb168, label %bb169
bb168:
  store %olang.scope zeroinitializer, ptr %s33
  %t917 = load ptr, ptr %l0, !tbaa !29
  store ptr %t917, ptr %l514, !tbaa !29
  %t918 = load ptr, ptr %l0, !tbaa !29
  %t919 = load ptr, ptr %l2, !tbaa !29
  %t921 = getelementptr %"compiler/ast:Multi", ptr %t919, i32 0, i32 0
  %t922 = load { i64, ptr }, ptr %t921, !tbaa !27
  store { i64, ptr } %t922, ptr %l517, !tbaa !27
  %t923 = load i64, ptr %l57, !tbaa !24
  %t925 = getelementptr { i64, ptr }, ptr %l517, i32 0, i32 1
  %t926 = load ptr, ptr %t925, !tbaa !27
  %t927 = getelementptr ptr, ptr %t926, i64 %t923
  %t928 = load ptr, ptr %t927, !tbaa !39
  %t931 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %t918, ptr %t928)
  store %"compiler/source:Span" %t931, ptr %l520
  br label %bb170
bb169:
  br label %bb173
bb170:
  %t932 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eColumnAssigned(ptr %s33)
  store %"compiler/diagmsg:Msg" %t932, ptr %l521
  br label %bb171
bb171:
  %t933 = load ptr, ptr %l514, !tbaa !29
  %t934 = load %"compiler/source:Span", ptr %l520
  %t935 = load %"compiler/diagmsg:Msg", ptr %l521
  %t936 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s33, ptr %t933, %"compiler/source:Span" %t934, %"compiler/diagmsg:Msg" %t935)
  store i64 %t936, ptr %l522
  br label %bb172
bb172:
  call void @__olang_scope_close(ptr %s33)
  br label %bb173
bb173:
  br label %bb174
bb174:
  %t937 = load i64, ptr %l56, !tbaa !24
  %t939 = add i64 %t937, 1
  store i64 %t939, ptr %l56, !tbaa !24
  br label %bb159
bb175:
  %t941 = load ptr, ptr %l0, !tbaa !29
  %t943 = getelementptr %"compiler/check:Checker", ptr %t941, i32 0, i32 10
  %t945 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eLen__H22c160154c8542d83ffe3c77c98973d0(ptr %v0, ptr %t943)
  store i64 %t945, ptr %l527
  br label %bb176
bb176:
  %t946 = load i64, ptr %l527, !tbaa !24
  store i64 %t946, ptr %l59, !tbaa !24
  %t947 = load ptr, ptr %l42, !tbaa !29
  store ptr %t947, ptr %l60, !tbaa !29
  store i64 0, ptr %l61, !tbaa !24
  br label %bb177
bb177:
  %t949 = load i64, ptr %l61, !tbaa !24
  store i64 %t949, ptr %l529, !tbaa !24
  %t950 = load ptr, ptr %l60, !tbaa !29
  %t952 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eL_H6a486a18542e18ee3475c3237c5a5335(ptr %v0, ptr %t950)
  store i64 %t952, ptr %l531
  br label %bb178
bb178:
  %t953 = load i64, ptr %l529, !tbaa !24
  %t954 = load i64, ptr %l531, !tbaa !24
  %t955 = icmp slt i64 %t953, %t954
  %t957 = xor i1 %t955, true
  br i1 %t957, label %bb179, label %bb180
bb179:
  br label %bb198
bb180:
  br label %bb181
bb181:
  %t959 = load ptr, ptr %l60, !tbaa !29
  %t960 = load i64, ptr %l61, !tbaa !24
  %t963 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eA_Hf8c35f4f5353320ac1e6ff0719acdfb7(ptr %v0, ptr %v0, ptr %t959, i64 %t960)
  store ptr %t963, ptr %l536
  br label %bb182
bb182:
  %t964 = load ptr, ptr %l536, !tbaa !29
  store ptr %t964, ptr %l62, !tbaa !29
  %t965 = load ptr, ptr %l62, !tbaa !29
  %t967 = icmp eq ptr %t965, null
  %t969 = xor i1 %t967, true
  br i1 %t969, label %bb183, label %bb184
bb183:
  %t971 = load ptr, ptr %l0, !tbaa !29
  store ptr %t971, ptr %l541, !tbaa !29
  %t972 = load ptr, ptr %l62, !tbaa !29
  %t974 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %t972)
  store i32 %t974, ptr %l543
  br label %bb185
bb184:
  store i1 false, ptr %l540, !tbaa !21
  br label %bb187
bb185:
  %t975 = load ptr, ptr %l541, !tbaa !29
  %t976 = load i32, ptr %l543, !tbaa !23
  %t977 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t975, i32 %t976)
  store i1 %t977, ptr %l544
  br label %bb186
bb186:
  %t978 = load i1, ptr %l544, !tbaa !21
  %t979 = xor i1 %t978, true
  store i1 %t979, ptr %l540, !tbaa !21
  br label %bb187
bb187:
  %t981 = load i1, ptr %l540, !tbaa !21
  br i1 %t981, label %bb188, label %bb189
bb188:
  %t982 = load ptr, ptr %l0, !tbaa !29
  %t984 = getelementptr %"compiler/check:Checker", ptr %t982, i32 0, i32 1
  %t985 = load ptr, ptr %t984, !tbaa !29
  %t987 = getelementptr %"compiler/generic:Program", ptr %t985, i32 0, i32 2
  store ptr %t987, ptr %l549, !tbaa !29
  %t988 = load ptr, ptr %l62, !tbaa !29
  %t990 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %t988)
  store i32 %t990, ptr %l551
  br label %bb190
bb189:
  store i1 false, ptr %l546, !tbaa !21
  br label %bb192
bb190:
  %t991 = load ptr, ptr %l549, !tbaa !29
  %t992 = load i32, ptr %l551, !tbaa !23
  %t993 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t991, i32 %t992)
  store i1 %t993, ptr %l552
  br label %bb191
bb191:
  %t994 = load i1, ptr %l552, !tbaa !21
  store i1 %t994, ptr %l546, !tbaa !21
  br label %bb192
bb192:
  %t995 = load i1, ptr %l546, !tbaa !21
  br i1 %t995, label %bb193, label %bb194
bb193:
  %t996 = load ptr, ptr %l0, !tbaa !29
  %t998 = getelementptr %"compiler/check:Checker", ptr %t996, i32 0, i32 10
  %t999 = load ptr, ptr %l62, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2ePush_H521773322b2b1b179ce4cc03a1674857(ptr %v0, ptr %v0, ptr %t998, ptr %t999)
  br label %bb195
bb194:
  br label %bb196
bb195:
  br label %bb196
bb196:
  br label %bb197
bb197:
  %t1002 = load i64, ptr %l61, !tbaa !24
  %t1004 = add i64 %t1002, 1
  store i64 %t1004, ptr %l61, !tbaa !24
  br label %bb177
bb198:
  store i64 0, ptr %l63, !tbaa !24
  %t1006 = load i64, ptr %l3, !tbaa !24
  store i64 %t1006, ptr %l64, !tbaa !24
  store i64 1, ptr %l65, !tbaa !24
  %t1008 = load i64, ptr %l64, !tbaa !24
  %t1009 = load i64, ptr %l63, !tbaa !24
  %t1012 = icmp sgt i64 %t1008, %t1009
  br i1 %t1012, label %bb199, label %bb200
bb199:
  %t1014 = load i64, ptr %l65, !tbaa !24
  %t1016 = icmp sgt i64 %t1014, 0
  br i1 %t1016, label %bb201, label %bb202
bb200:
  store i64 0, ptr %l562, !tbaa !24
  br label %bb204
bb201:
  %t1018 = load i64, ptr %l64, !tbaa !24
  %t1019 = load i64, ptr %l63, !tbaa !24
  %t1022 = sub i64 %t1018, %t1019
  %t1023 = load i64, ptr %l65, !tbaa !24
  %t1026 = add i64 %t1022, %t1023
  %t1028 = sub i64 %t1026, 1
  %t1029 = load i64, ptr %l65, !tbaa !24
  %t1032 = sdiv i64 %t1028, %t1029
  store i64 %t1032, ptr %l565, !tbaa !24
  br label %bb203
bb202:
  store i64 0, ptr %l565, !tbaa !24
  br label %bb203
bb203:
  %t1034 = load i64, ptr %l565, !tbaa !24
  store i64 %t1034, ptr %l562, !tbaa !24
  br label %bb204
bb204:
  %t1035 = load i64, ptr %l562, !tbaa !24
  store i64 %t1035, ptr %l66, !tbaa !24
  store i64 0, ptr %l67, !tbaa !24
  br label %bb205
bb205:
  store %olang.scope zeroinitializer, ptr %s40
  %t1036 = load i64, ptr %l67, !tbaa !24
  %t1037 = load i64, ptr %l66, !tbaa !24
  %t1040 = icmp slt i64 %t1036, %t1037
  %t1042 = xor i1 %t1040, true
  br i1 %t1042, label %bb206, label %bb207
bb206:
  call void @__olang_scope_close(ptr %s40)
  br label %bb239
bb207:
  br label %bb208
bb208:
  %t1044 = load i64, ptr %l63, !tbaa !24
  %t1045 = load i64, ptr %l67, !tbaa !24
  %t1046 = load i64, ptr %l65, !tbaa !24
  %t1049 = mul i64 %t1045, %t1046
  %t1052 = add i64 %t1044, %t1049
  store i64 %t1052, ptr %l68, !tbaa !24
  %t1054 = load ptr, ptr %l43, !tbaa !29
  %t1055 = load i64, ptr %l68, !tbaa !24
  %t1058 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3asetAt_3f_26_3e_2eAt_H6c7d5ab01c425e68e8a93a567ecc740a(ptr %v0, ptr %v0, ptr %t1054, i64 %t1055)
  store ptr %t1058, ptr %l585
  br label %bb209
bb209:
  %t1059 = load ptr, ptr %l585, !tbaa !29
  store ptr %t1059, ptr %l69, !tbaa !29
  %t1060 = load ptr, ptr %l69, !tbaa !29
  %t1062 = icmp eq ptr %t1060, null
  %t1064 = xor i1 %t1062, true
  br i1 %t1064, label %bb210, label %bb211
bb210:
  %t1066 = load ptr, ptr %l69, !tbaa !29
  %t1068 = getelementptr %"compiler/check:setAt", ptr %t1066, i32 0, i32 5
  %t1069 = load i32, ptr %t1068, !tbaa !23
  store i32 %t1069, ptr %l589, !tbaa !23
  br label %bb221
bb211:
  %t1071 = load ptr, ptr %l42, !tbaa !29
  %t1072 = load i64, ptr %l68, !tbaa !24
  %t1075 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eA_Hf8c35f4f5353320ac1e6ff0719acdfb7(ptr %v0, ptr %s40, ptr %t1071, i64 %t1072)
  store ptr %t1075, ptr %l594
  br label %bb212
bb212:
  %t1076 = load ptr, ptr %l594, !tbaa !29
  %t1077 = icmp eq ptr %t1076, null
  %t1079 = xor i1 %t1077, true
  br i1 %t1079, label %bb213, label %bb214
bb213:
  %t1081 = load ptr, ptr %l42, !tbaa !29
  %t1082 = load i64, ptr %l68, !tbaa !24
  %t1085 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eA_Hf8c35f4f5353320ac1e6ff0719acdfb7(ptr %v0, ptr %v0, ptr %t1081, i64 %t1082)
  store ptr %t1085, ptr %l600
  br label %bb215
bb214:
  %t1086 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t1086, ptr %l597, !tbaa !23
  br label %bb220
bb215:
  %t1088 = load ptr, ptr %l600, !tbaa !29
  store ptr %t1088, ptr %l70, !tbaa !29
  %t1089 = load ptr, ptr %l70, !tbaa !29
  %t1091 = icmp eq ptr %t1089, null
  br i1 %t1091, label %bb216, label %bb217
bb216:
  call void @__olang_check_failed(ptr @olang_loc_96ad6a547cbfae6b_c8fd4ea10ff1b69f)
  unreachable
bb217:
  br label %bb218
bb218:
  %t1093 = load ptr, ptr %l70, !tbaa !29
  %t1095 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %t1093)
  store i32 %t1095, ptr %l604
  br label %bb219
bb219:
  %t1096 = load i32, ptr %l604, !tbaa !23
  store i32 %t1096, ptr %l597, !tbaa !23
  br label %bb220
bb220:
  %t1097 = load i32, ptr %l597, !tbaa !23
  store i32 %t1097, ptr %l589, !tbaa !23
  br label %bb221
bb221:
  %t1098 = load i32, ptr %l589, !tbaa !23
  %t1099 = load ptr, ptr %l0, !tbaa !29
  %t1100 = load ptr, ptr %l2, !tbaa !29
  %t1102 = getelementptr %"compiler/ast:Multi", ptr %t1100, i32 0, i32 2
  %t1103 = load { i64, ptr }, ptr %t1102, !tbaa !27
  store { i64, ptr } %t1103, ptr %l608, !tbaa !27
  %t1104 = load i64, ptr %l68, !tbaa !24
  %t1106 = getelementptr { i64, ptr }, ptr %l608, i32 0, i32 1
  %t1107 = load ptr, ptr %t1106, !tbaa !27
  %t1108 = getelementptr ptr, ptr %t1107, i64 %t1104
  %t1109 = load ptr, ptr %t1108, !tbaa !39
  %t1114 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %v0, ptr %t1099, ptr %t1109, i32 %t1098)
  store ptr %t1114, ptr %l612
  br label %bb222
bb222:
  %t1115 = load ptr, ptr %l612, !tbaa !29
  store ptr %t1115, ptr %l72, !tbaa !29
  %t1116 = load ptr, ptr %l42, !tbaa !29
  %t1117 = load i64, ptr %l68, !tbaa !24
  %t1120 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eA_Hf8c35f4f5353320ac1e6ff0719acdfb7(ptr %v0, ptr %s40, ptr %t1116, i64 %t1117)
  store ptr %t1120, ptr %l615
  br label %bb223
bb223:
  %t1121 = load ptr, ptr %l615, !tbaa !29
  %t1122 = icmp eq ptr %t1121, null
  %t1124 = xor i1 %t1122, true
  br i1 %t1124, label %bb224, label %bb225
bb224:
  %t1126 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1126, ptr %l618, !tbaa !29
  %t1127 = load ptr, ptr %l42, !tbaa !29
  %t1128 = load i64, ptr %l68, !tbaa !24
  %t1131 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eA_Hf8c35f4f5353320ac1e6ff0719acdfb7(ptr %v0, ptr %v0, ptr %t1127, i64 %t1128)
  store ptr %t1131, ptr %l621
  br label %bb226
bb225:
  br label %bb231
bb226:
  %t1132 = load ptr, ptr %l621, !tbaa !29
  store ptr %t1132, ptr %l73, !tbaa !29
  %t1133 = load ptr, ptr %l73, !tbaa !29
  %t1135 = icmp eq ptr %t1133, null
  br i1 %t1135, label %bb227, label %bb228
bb227:
  call void @__olang_check_failed(ptr @olang_loc_1e0e3f8e77107efc_26f178b75df49a00)
  unreachable
bb228:
  br label %bb229
bb229:
  %t1137 = load ptr, ptr %l73, !tbaa !29
  %t1138 = load ptr, ptr %l72, !tbaa !29
  %t1139 = load ptr, ptr %l618, !tbaa !29
  %t1142 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estoreCopy(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t1139, ptr %t1137, ptr %t1138)
  store ptr %t1142, ptr %l626
  br label %bb230
bb230:
  %t1143 = load ptr, ptr %l626, !tbaa !29
  store ptr %t1143, ptr %l72, !tbaa !29
  br label %bb231
bb231:
  %t1144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1144, ptr %l627, !tbaa !29
  %t1145 = load ptr, ptr %l2, !tbaa !29
  %t1147 = getelementptr %"compiler/ast:Multi", ptr %t1145, i32 0, i32 2
  %t1148 = load { i64, ptr }, ptr %t1147, !tbaa !27
  store { i64, ptr } %t1148, ptr %l629, !tbaa !27
  %t1149 = load i64, ptr %l68, !tbaa !24
  %t1151 = getelementptr { i64, ptr }, ptr %l629, i32 0, i32 1
  %t1152 = load ptr, ptr %t1151, !tbaa !27
  %t1153 = getelementptr ptr, ptr %t1152, i64 %t1149
  %t1154 = load ptr, ptr %t1153, !tbaa !39
  %t1156 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t1154)
  store %"compiler/source:Span" %t1156, ptr %l632
  br label %bb232
bb232:
  %t1157 = load ptr, ptr %l72, !tbaa !29
  %t1160 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1157)
  store i32 %t1160, ptr %l635
  br label %bb233
bb233:
  store { i64, [1 x i64] } zeroinitializer, ptr %t1161
  %t1162 = getelementptr { i64, [1 x i64] }, ptr %t1161, i32 0, i32 0
  store i64 0, ptr %t1162
  %t1163 = load { i64, [1 x i64] }, ptr %t1161
  %t1164 = load ptr, ptr %l627, !tbaa !29
  %t1165 = load %"compiler/source:Span", ptr %l632
  %t1166 = load i32, ptr %l635, !tbaa !23
  %t1169 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t1164, i32 0, %"compiler/source:Span" %t1165, i32 %t1166, i32 2, { i64, [1 x i64] } %t1163)
  store i64 %t1169, ptr %l638
  br label %bb234
bb234:
  %t1170 = load i64, ptr %l638, !tbaa !24
  store i64 %t1170, ptr %l74, !tbaa !24
  %t1171 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1171, ptr %l639, !tbaa !29
  %t1172 = load ptr, ptr %l2, !tbaa !29
  %t1174 = getelementptr %"compiler/ast:Multi", ptr %t1172, i32 0, i32 2
  %t1175 = load { i64, ptr }, ptr %t1174, !tbaa !27
  store { i64, ptr } %t1175, ptr %l641, !tbaa !27
  %t1176 = load i64, ptr %l68, !tbaa !24
  %t1178 = getelementptr { i64, ptr }, ptr %l641, i32 0, i32 1
  %t1179 = load ptr, ptr %t1178, !tbaa !27
  %t1180 = getelementptr ptr, ptr %t1179, i64 %t1176
  %t1181 = load ptr, ptr %t1180, !tbaa !39
  %t1183 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t1181)
  store %"compiler/source:Span" %t1183, ptr %l644
  br label %bb235
bb235:
  %t1184 = load i64, ptr %l74, !tbaa !24
  %t1186 = trunc i64 %t1184 to i32
  %t1188 = load ptr, ptr %l72, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t1189
  %t1190 = getelementptr { i64, [3 x i64] }, ptr %t1189, i32 0, i32 0
  store i64 0, ptr %t1190
  %t1191 = load %"compiler/source:Span", ptr %l644
  %t1192 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1191, 0
  %t1194 = insertvalue { %"compiler/source:Span", i32, ptr } %t1192, i32 %t1186, 1
  %t1196 = insertvalue { %"compiler/source:Span", i32, ptr } %t1194, ptr %t1188, 2
  %t1197 = getelementptr { i64, [3 x i64] }, ptr %t1189, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1196, ptr %t1197
  %t1198 = load { i64, [3 x i64] }, ptr %t1189
  %t1200 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t1198, ptr %t1200
  %t1201 = load ptr, ptr %l639, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t1201, ptr %t1200)
  br label %bb236
bb236:
  %t1203 = load i64, ptr %l74, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l41, i64 %t1203)
  br label %bb237
bb237:
  call void @__olang_scope_close(ptr %s40)
  br label %bb238
bb238:
  %t1206 = load i64, ptr %l67, !tbaa !24
  %t1208 = add i64 %t1206, 1
  store i64 %t1208, ptr %l67, !tbaa !24
  br label %bb205
bb239:
  %t1210 = load ptr, ptr %l0, !tbaa !29
  %t1212 = getelementptr %"compiler/check:Checker", ptr %t1210, i32 0, i32 10
  %t1213 = load i64, ptr %l59, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eTrun_Haa7c8ccc08c8123d0b87c9688e5d351e(ptr %v0, ptr %t1212, i64 %t1213)
  br label %bb240
bb240:
  store i64 0, ptr %l75, !tbaa !24
  %t1216 = load i64, ptr %l3, !tbaa !24
  store i64 %t1216, ptr %l76, !tbaa !24
  store i64 1, ptr %l77, !tbaa !24
  %t1218 = load i64, ptr %l76, !tbaa !24
  %t1219 = load i64, ptr %l75, !tbaa !24
  %t1222 = icmp sgt i64 %t1218, %t1219
  br i1 %t1222, label %bb241, label %bb242
bb241:
  %t1224 = load i64, ptr %l77, !tbaa !24
  %t1226 = icmp sgt i64 %t1224, 0
  br i1 %t1226, label %bb243, label %bb244
bb242:
  store i64 0, ptr %l662, !tbaa !24
  br label %bb246
bb243:
  %t1228 = load i64, ptr %l76, !tbaa !24
  %t1229 = load i64, ptr %l75, !tbaa !24
  %t1232 = sub i64 %t1228, %t1229
  %t1233 = load i64, ptr %l77, !tbaa !24
  %t1236 = add i64 %t1232, %t1233
  %t1238 = sub i64 %t1236, 1
  %t1239 = load i64, ptr %l77, !tbaa !24
  %t1242 = sdiv i64 %t1238, %t1239
  store i64 %t1242, ptr %l665, !tbaa !24
  br label %bb245
bb244:
  store i64 0, ptr %l665, !tbaa !24
  br label %bb245
bb245:
  %t1244 = load i64, ptr %l665, !tbaa !24
  store i64 %t1244, ptr %l662, !tbaa !24
  br label %bb246
bb246:
  %t1245 = load i64, ptr %l662, !tbaa !24
  store i64 %t1245, ptr %l78, !tbaa !24
  store i64 0, ptr %l79, !tbaa !24
  br label %bb247
bb247:
  %t1246 = load i64, ptr %l79, !tbaa !24
  %t1247 = load i64, ptr %l78, !tbaa !24
  %t1250 = icmp slt i64 %t1246, %t1247
  %t1252 = xor i1 %t1250, true
  br i1 %t1252, label %bb248, label %bb249
bb248:
  br label %bb300
bb249:
  br label %bb250
bb250:
  %t1254 = load i64, ptr %l75, !tbaa !24
  %t1255 = load i64, ptr %l79, !tbaa !24
  %t1256 = load i64, ptr %l77, !tbaa !24
  %t1259 = mul i64 %t1255, %t1256
  %t1262 = add i64 %t1254, %t1259
  store i64 %t1262, ptr %l80, !tbaa !24
  %t1264 = load ptr, ptr %l43, !tbaa !29
  %t1265 = load i64, ptr %l80, !tbaa !24
  %t1268 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3asetAt_3f_26_3e_2eAt_H6c7d5ab01c425e68e8a93a567ecc740a(ptr %v0, ptr %v0, ptr %t1264, i64 %t1265)
  store ptr %t1268, ptr %l685
  br label %bb251
bb251:
  %t1269 = load ptr, ptr %l685, !tbaa !29
  store ptr %t1269, ptr %l81, !tbaa !29
  %t1270 = load ptr, ptr %l81, !tbaa !29
  %t1272 = icmp eq ptr %t1270, null
  %t1274 = xor i1 %t1272, true
  br i1 %t1274, label %bb252, label %bb253
bb252:
  %t1276 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1276, ptr %l689
  br label %bb254
bb253:
  store %olang.scope zeroinitializer, ptr %s49
  %t1277 = load ptr, ptr %l42, !tbaa !29
  %t1278 = load i64, ptr %l80, !tbaa !24
  %t1281 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eA_Hf8c35f4f5353320ac1e6ff0719acdfb7(ptr %v0, ptr %s49, ptr %t1277, i64 %t1278)
  store ptr %t1281, ptr %l777
  br label %bb287
bb254:
  %t1282 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store ptr %t1282, ptr %lp82
  %t1283 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l689
  %t1284 = load ptr, ptr %lp82
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1283, ptr %t1284
  %t1285 = load ptr, ptr %l81, !tbaa !29
  %t1287 = getelementptr %"compiler/check:setAt", ptr %t1285, i32 0, i32 2
  %t1288 = load { i64, ptr }, ptr %t1287, !tbaa !27
  store { i64, ptr } %t1288, ptr %l83, !tbaa !27
  store i64 0, ptr %l84, !tbaa !24
  %t1290 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t1292 = extractvalue { i64, ptr } %t1290, 0
  store i64 %t1292, ptr %l85, !tbaa !24
  br label %bb255
bb255:
  %t1294 = load i64, ptr %l84, !tbaa !24
  %t1295 = load i64, ptr %l85, !tbaa !24
  %t1298 = icmp slt i64 %t1294, %t1295
  %t1300 = xor i1 %t1298, true
  br i1 %t1300, label %bb256, label %bb257
bb256:
  br label %bb271
bb257:
  br label %bb258
bb258:
  %t1302 = load i64, ptr %l84, !tbaa !24
  store i64 %t1302, ptr %l86, !tbaa !24
  %t1304 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t1304, ptr %l699, !tbaa !27
  %t1305 = load i64, ptr %l84, !tbaa !24
  %t1307 = getelementptr { i64, ptr }, ptr %l699, i32 0, i32 1
  %t1308 = load ptr, ptr %t1307, !tbaa !27
  %t1309 = getelementptr ptr, ptr %t1308, i64 %t1305
  %t1310 = load ptr, ptr %t1309, !tbaa !39
  store ptr %t1310, ptr %l87, !tbaa !29
  %t1312 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1312, ptr %l702, !tbaa !29
  %t1313 = load ptr, ptr %l87, !tbaa !29
  store ptr %t1313, ptr %l703, !tbaa !29
  %t1314 = load i64, ptr %l86, !tbaa !24
  %t1316 = add i64 %t1314, 1
  %t1317 = load ptr, ptr %l81, !tbaa !29
  %t1319 = getelementptr %"compiler/check:setAt", ptr %t1317, i32 0, i32 3
  %t1320 = load { i64, ptr }, ptr %t1319, !tbaa !27
  %t1322 = extractvalue { i64, ptr } %t1320, 0
  %t1325 = icmp slt i64 %t1316, %t1322
  br i1 %t1325, label %bb259, label %bb260
bb259:
  %t1327 = load ptr, ptr %l81, !tbaa !29
  %t1328 = load i64, ptr %l86, !tbaa !24
  %t1330 = add i64 %t1328, 1
  %t1332 = getelementptr %"compiler/check:setAt", ptr %t1327, i32 0, i32 3
  %t1334 = getelementptr { i64, ptr }, ptr %t1332, i32 0, i32 1
  %t1335 = load ptr, ptr %t1334, !tbaa !27
  %t1336 = getelementptr i32, ptr %t1335, i64 %t1330
  %t1337 = load i32, ptr %t1336, !tbaa !33
  store i32 %t1337, ptr %l710, !tbaa !23
  br label %bb261
bb260:
  %t1339 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t1339, ptr %l710, !tbaa !23
  br label %bb261
bb261:
  %t1341 = load ptr, ptr %l702, !tbaa !29
  %t1342 = load ptr, ptr %l703, !tbaa !29
  %t1343 = load i32, ptr %l710, !tbaa !23
  %t1344 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v0, ptr %v0, ptr %t1341, ptr %t1342, i32 %t1343)
  store ptr %t1344, ptr %l716
  br label %bb262
bb262:
  %t1345 = load ptr, ptr %l716, !tbaa !29
  store ptr %t1345, ptr %l88, !tbaa !29
  %t1346 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1346, ptr %l717, !tbaa !29
  %t1347 = load ptr, ptr %l87, !tbaa !29
  %t1349 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t1347)
  store %"compiler/source:Span" %t1349, ptr %l719
  br label %bb263
bb263:
  %t1350 = load ptr, ptr %l88, !tbaa !29
  %t1353 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1350)
  store i32 %t1353, ptr %l722
  br label %bb264
bb264:
  store { i64, [1 x i64] } zeroinitializer, ptr %t1354
  %t1355 = getelementptr { i64, [1 x i64] }, ptr %t1354, i32 0, i32 0
  store i64 0, ptr %t1355
  %t1356 = load { i64, [1 x i64] }, ptr %t1354
  %t1357 = load ptr, ptr %l717, !tbaa !29
  %t1358 = load %"compiler/source:Span", ptr %l719
  %t1359 = load i32, ptr %l722, !tbaa !23
  %t1362 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t1357, i32 0, %"compiler/source:Span" %t1358, i32 %t1359, i32 2, { i64, [1 x i64] } %t1356)
  store i64 %t1362, ptr %l725
  br label %bb265
bb265:
  %t1363 = load i64, ptr %l725, !tbaa !24
  store i64 %t1363, ptr %l89, !tbaa !24
  %t1364 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1364, ptr %l726, !tbaa !29
  %t1365 = load ptr, ptr %l87, !tbaa !29
  %t1367 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t1365)
  store %"compiler/source:Span" %t1367, ptr %l728
  br label %bb266
bb266:
  %t1368 = load i64, ptr %l89, !tbaa !24
  %t1370 = trunc i64 %t1368 to i32
  %t1372 = load ptr, ptr %l88, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t1373
  %t1374 = getelementptr { i64, [3 x i64] }, ptr %t1373, i32 0, i32 0
  store i64 0, ptr %t1374
  %t1375 = load %"compiler/source:Span", ptr %l728
  %t1376 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1375, 0
  %t1378 = insertvalue { %"compiler/source:Span", i32, ptr } %t1376, i32 %t1370, 1
  %t1380 = insertvalue { %"compiler/source:Span", i32, ptr } %t1378, ptr %t1372, 2
  %t1381 = getelementptr { i64, [3 x i64] }, ptr %t1373, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1380, ptr %t1381
  %t1382 = load { i64, [3 x i64] }, ptr %t1373
  %t1384 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t1382, ptr %t1384
  %t1385 = load ptr, ptr %l726, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t1385, ptr %t1384)
  br label %bb267
bb267:
  %t1387 = load ptr, ptr %lp82
  store ptr %t1387, ptr %l735, !tbaa !29
  %t1388 = load ptr, ptr %l0, !tbaa !29
  %t1389 = load %"compiler/source:Span", ptr %l1
  %t1390 = load i64, ptr %l89, !tbaa !24
  %t1394 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t1388, %"compiler/source:Span" %t1389, i64 %t1390)
  store ptr %t1394, ptr %l739
  br label %bb268
bb268:
  %t1395 = load ptr, ptr %l735, !tbaa !29
  %t1396 = load ptr, ptr %l739, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t1395, ptr %t1396)
  br label %bb269
bb269:
  br label %bb270
bb270:
  %t1397 = load i64, ptr %l84, !tbaa !24
  %t1399 = add i64 %t1397, 1
  store i64 %t1399, ptr %l84, !tbaa !24
  br label %bb255
bb271:
  %t1401 = load ptr, ptr %lp82
  store ptr %t1401, ptr %l742, !tbaa !29
  %t1402 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1402, ptr %l743, !tbaa !29
  %t1403 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1403, ptr %l744
  %t1404 = load i64, ptr %l80, !tbaa !24
  %t1407 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l41, i64 %t1404)
  store i64 %t1407, ptr %l747
  br label %bb272
bb272:
  %t1408 = load ptr, ptr %l743, !tbaa !29
  %t1409 = load %"compiler/source:Span", ptr %l744
  %t1410 = load i64, ptr %l747, !tbaa !24
  %t1411 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t1408, %"compiler/source:Span" %t1409, i64 %t1410)
  store ptr %t1411, ptr %l748
  br label %bb273
bb273:
  %t1412 = load ptr, ptr %l742, !tbaa !29
  %t1413 = load ptr, ptr %l748, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t1412, ptr %t1413)
  br label %bb274
bb274:
  %t1414 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1414, ptr %l749, !tbaa !29
  %t1415 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1415, ptr %l750
  %t1416 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1416, ptr %l751, !tbaa !29
  %t1417 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1417, ptr %l752
  %t1418 = load ptr, ptr %l81, !tbaa !29
  %t1420 = getelementptr %"compiler/check:setAt", ptr %t1418, i32 0, i32 4
  %t1421 = load %"compiler/source:Span", ptr %t1420
  store %"compiler/source:Span" %t1421, ptr %l754
  %t1422 = load ptr, ptr %l81, !tbaa !29
  %t1424 = getelementptr %"compiler/check:setAt", ptr %t1422, i32 0, i32 1
  %t1425 = load i64, ptr %t1424, !tbaa !24
  store i64 %t1425, ptr %l756, !tbaa !24
  %t1426 = load ptr, ptr %l0, !tbaa !29
  %t1427 = load ptr, ptr %l81, !tbaa !29
  %t1429 = getelementptr %"compiler/check:setAt", ptr %t1427, i32 0, i32 4
  %t1430 = load %"compiler/source:Span", ptr %t1429
  %t1431 = load ptr, ptr %l81, !tbaa !29
  %t1433 = getelementptr %"compiler/check:setAt", ptr %t1431, i32 0, i32 0
  %t1434 = load ptr, ptr %t1433, !tbaa !29
  %t1438 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t1426, %"compiler/source:Span" %t1430, ptr %t1434)
  store ptr %t1438, ptr %l762
  br label %bb275
bb275:
  %t1439 = load ptr, ptr %l762, !tbaa !29
  store ptr %t1439, ptr %l763, !tbaa !29
  %t1440 = icmp sge i64 0, 0
  br i1 %t1440, label %bb276, label %bb277
bb276:
  %t1442 = icmp sle i64 0, 1152921504606846975
  br i1 %t1442, label %bb278, label %bb279
bb277:
  call void @__olang_check_failed(ptr @olang_loc_89675b40bb29f91f_f23262abf4982edb)
  unreachable
bb278:
  %t1444 = mul i64 0, 8
  %t1445 = insertvalue { i64, ptr } undef, i64 0, 0
  %t1446 = insertvalue { i64, ptr } %t1445, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t1446, ptr %l766, !tbaa !27
  %t1447 = load ptr, ptr %lp82
  %t1449 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eToArra_H50cbff9caa8a2389caf3e92da7e24507(ptr %v0, ptr %v0, ptr %t1447)
  store { i64, ptr } %t1449, ptr %l768
  br label %bb280
bb279:
  call void @__olang_check_failed(ptr @olang_loc_89675b40bb29f91f_f23262abf4982edb)
  unreachable
bb280:
  %t1450 = icmp sge i64 0, 0
  br i1 %t1450, label %bb281, label %bb282
bb281:
  %t1452 = icmp sle i64 0, 2305843009213693951
  br i1 %t1452, label %bb283, label %bb284
bb282:
  call void @__olang_check_failed(ptr @olang_loc_7114c498979ee84a_e24a16e9735bab46)
  unreachable
bb283:
  %t1454 = mul i64 0, 4
  %t1455 = insertvalue { i64, ptr } undef, i64 0, 0
  %t1456 = insertvalue { i64, ptr } %t1455, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t1457 = load ptr, ptr %l751, !tbaa !29
  %t1458 = load %"compiler/source:Span", ptr %l752
  %t1459 = load %"compiler/source:Span", ptr %l754
  %t1460 = load i64, ptr %l756, !tbaa !24
  %t1461 = load ptr, ptr %l763, !tbaa !29
  %t1462 = load { i64, ptr }, ptr %l766, !tbaa !27
  %t1463 = load { i64, ptr }, ptr %l768, !tbaa !27
  %t1465 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t1457, %"compiler/source:Span" %t1458, %"compiler/source:Span" %t1459, i64 %t1460, ptr %t1461, { i64, ptr } %t1462, { i64, ptr } %t1463, { i64, ptr } %t1456)
  store ptr %t1465, ptr %l772
  br label %bb285
bb284:
  call void @__olang_check_failed(ptr @olang_loc_7114c498979ee84a_e24a16e9735bab46)
  unreachable
bb285:
  store { i64, [3 x i64] } zeroinitializer, ptr %t1466
  %t1467 = getelementptr { i64, [3 x i64] }, ptr %t1466, i32 0, i32 0
  store i64 2, ptr %t1467
  %t1468 = load %"compiler/source:Span", ptr %l750
  %t1469 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t1468, 0
  %t1470 = load ptr, ptr %l772, !tbaa !29
  %t1471 = insertvalue { %"compiler/source:Span", ptr } %t1469, ptr %t1470, 1
  %t1472 = getelementptr { i64, [3 x i64] }, ptr %t1466, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t1471, ptr %t1472
  %t1473 = load { i64, [3 x i64] }, ptr %t1466
  %t1475 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t1473, ptr %t1475
  %t1476 = load ptr, ptr %l749, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t1476, ptr %t1475)
  br label %bb286
bb286:
  br label %bb298
bb287:
  %t1478 = load ptr, ptr %l777, !tbaa !29
  %t1479 = icmp eq ptr %t1478, null
  %t1481 = xor i1 %t1479, true
  br i1 %t1481, label %bb288, label %bb289
bb288:
  %t1483 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1483, ptr %l780, !tbaa !29
  %t1484 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1484, ptr %l781
  %t1485 = load ptr, ptr %l42, !tbaa !29
  %t1486 = load i64, ptr %l80, !tbaa !24
  %t1489 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eA_Hf8c35f4f5353320ac1e6ff0719acdfb7(ptr %v0, ptr %v0, ptr %t1485, i64 %t1486)
  store ptr %t1489, ptr %l784
  br label %bb290
bb289:
  br label %bb297
bb290:
  %t1490 = load ptr, ptr %l784, !tbaa !29
  store ptr %t1490, ptr %l90, !tbaa !29
  %t1491 = load ptr, ptr %l90, !tbaa !29
  %t1493 = icmp eq ptr %t1491, null
  br i1 %t1493, label %bb291, label %bb292
bb291:
  call void @__olang_check_failed(ptr @olang_loc_c7908973d247e2d7_c6acba74781c2b93)
  unreachable
bb292:
  br label %bb293
bb293:
  %t1495 = load ptr, ptr %l90, !tbaa !29
  store ptr %t1495, ptr %l787, !tbaa !29
  %t1496 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1496, ptr %l788, !tbaa !29
  %t1497 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1497, ptr %l789
  %t1498 = load i64, ptr %l80, !tbaa !24
  %t1501 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l41, i64 %t1498)
  store i64 %t1501, ptr %l792
  br label %bb294
bb294:
  %t1502 = load ptr, ptr %l788, !tbaa !29
  %t1503 = load %"compiler/source:Span", ptr %l789
  %t1504 = load i64, ptr %l792, !tbaa !24
  %t1505 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t1502, %"compiler/source:Span" %t1503, i64 %t1504)
  store ptr %t1505, ptr %l793
  br label %bb295
bb295:
  store { i64, [3 x i64] } zeroinitializer, ptr %t1506
  %t1507 = getelementptr { i64, [3 x i64] }, ptr %t1506, i32 0, i32 0
  store i64 1, ptr %t1507
  %t1508 = load %"compiler/source:Span", ptr %l781
  %t1509 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t1508, 0
  %t1510 = load ptr, ptr %l787, !tbaa !29
  %t1511 = insertvalue { %"compiler/source:Span", ptr, ptr } %t1509, ptr %t1510, 1
  %t1512 = load ptr, ptr %l793, !tbaa !29
  %t1513 = insertvalue { %"compiler/source:Span", ptr, ptr } %t1511, ptr %t1512, 2
  %t1514 = getelementptr { i64, [3 x i64] }, ptr %t1506, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t1513, ptr %t1514
  %t1515 = load { i64, [3 x i64] }, ptr %t1506
  %t1517 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t1515, ptr %t1517
  %t1518 = load ptr, ptr %l780, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t1518, ptr %t1517)
  br label %bb296
bb296:
  br label %bb297
bb297:
  call void @__olang_scope_close(ptr %s49)
  br label %bb298
bb298:
  br label %bb299
bb299:
  %t1520 = load i64, ptr %l79, !tbaa !24
  %t1522 = add i64 %t1520, 1
  store i64 %t1522, ptr %l79, !tbaa !24
  br label %bb247
bb300:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedHolds(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l11 = alloca i64
  %l14 = alloca i64
  %l36 = alloca i32
  %l44 = alloca i32
  %l49 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  store i64 8, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t1 = load i64, ptr %l3, !tbaa !24
  %t2 = load i64, ptr %l2, !tbaa !24
  %t5 = icmp sgt i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp sgt i64 %t7, 0
  br i1 %t9, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l11, !tbaa !24
  br label %bb6
bb3:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l2, !tbaa !24
  %t15 = sub i64 %t11, %t12
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = add i64 %t15, %t16
  %t21 = sub i64 %t19, 1
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = sdiv i64 %t21, %t22
  store i64 %t25, ptr %l14, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb5
bb5:
  %t27 = load i64, ptr %l14, !tbaa !24
  store i64 %t27, ptr %l11, !tbaa !24
  br label %bb6
bb6:
  %t28 = load i64, ptr %l11, !tbaa !24
  store i64 %t28, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  %t29 = load i64, ptr %l6, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = icmp slt i64 %t29, %t30
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb8, label %bb9
bb8:
  br label %bb17
bb9:
  br label %bb10
bb10:
  %t37 = load i64, ptr %l2, !tbaa !24
  %t38 = load i64, ptr %l6, !tbaa !24
  %t39 = load i64, ptr %l4, !tbaa !24
  %t42 = mul i64 %t38, %t39
  %t45 = add i64 %t37, %t42
  store i64 %t45, ptr %l7, !tbaa !24
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 2
  %t53 = load i32, ptr %l1, !tbaa !23
  %t56 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t52, i32 %t53)
  store i32 %t56, ptr %l36
  br label %bb11
bb11:
  %t57 = load i32, ptr %l36, !range !{i32 0, i32 33}
  %t59 = trunc i64 19 to i32
  %t60 = icmp eq i32 %t57, %t59
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb12, label %bb13
bb12:
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  %t70 = load i32, ptr %l1, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l44
  br label %bb15
bb15:
  %t74 = load i32, ptr %l44, !tbaa !23
  store i32 %t74, ptr %l1, !tbaa !23
  br label %bb16
bb16:
  %t75 = load i64, ptr %l6, !tbaa !24
  %t77 = add i64 %t75, 1
  store i64 %t77, ptr %l6, !tbaa !24
  br label %bb7
bb17:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load i32, ptr %l1, !tbaa !23
  %t83 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %t79, i32 %t80)
  store i1 %t83, ptr %l49
  br label %bb18
bb18:
  %t84 = load i1, ptr %l49, !tbaa !21
  store i1 %t84, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedPackedWhat(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l11 = alloca i1
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d31, i32 0, i32 1) }, ptr %l5, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t7, ptr %l6, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l7, !tbaa !24
  %t10 = load i64, ptr %l7, !tbaa !24
  %t11 = mul i64 %t10, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l8, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l7, !tbaa !24
  %t20 = mul i64 %t19, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %t18, i64 %t20, i1 false)
  %t21 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t21, ptr %l6, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t22, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l1, !tbaa !23
  %t27 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t23, i32 %t24)
  store i1 %t27, ptr %l11
  br label %bb5
bb5:
  %t28 = load i1, ptr %l11, !tbaa !21
  %t29 = xor i1 %t28, true
  br i1 %t29, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d32, i32 0, i32 1) }, ptr %l13, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t31, ptr %l14, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 0
  store i64 %t33, ptr %l15, !tbaa !24
  %t34 = load i64, ptr %l15, !tbaa !24
  %t35 = mul i64 %t34, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t35)
  %t37 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  store { i64, ptr } %t38, ptr %l16, !tbaa !27
  %t39 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = load i64, ptr %l15, !tbaa !24
  %t44 = mul i64 %t43, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t40, ptr %t42, i64 %t44, i1 false)
  %t45 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t45, ptr %l14, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t46, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  store { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d33, i32 0, i32 1) }, ptr %l17, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t47, ptr %l18, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 0
  store i64 %t49, ptr %l19, !tbaa !24
  %t50 = load i64, ptr %l19, !tbaa !24
  %t51 = mul i64 %t50, 1
  %t52 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t51)
  %t53 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  store { i64, ptr } %t54, ptr %l20, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = load i64, ptr %l19, !tbaa !24
  %t60 = mul i64 %t59, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t56, ptr %t58, i64 %t60, i1 false)
  %t61 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t61, ptr %l18, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t62, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, { i64, ptr } %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l11 = alloca i64
  %l15 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca %"compiler/source:Span"
  %l26 = alloca %"compiler/diagmsg:Msg"
  %l27 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca %"compiler/source:Span"
  %l30 = alloca %"compiler/diagmsg:Msg"
  %l31 = alloca i64
  %l36 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l41 = alloca i32
  %l45 = alloca ptr
  %l48 = alloca i32
  %l52 = alloca i1
  %l58 = alloca ptr
  %l61 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca { i64, ptr }
  %l66 = alloca %"compiler/source:Span"
  %l69 = alloca { i64, ptr }
  %l71 = alloca %"compiler/diagmsg:Msg"
  %l72 = alloca i64
  %l75 = alloca ptr
  %l79 = alloca { i64, ptr }
  %l84 = alloca i32
  %l85 = alloca { i64, ptr }
  %l89 = alloca i32
  %l92 = alloca i64
  %l96 = alloca %"compiler/source:Span"
  %l97 = alloca i32
  %l98 = alloca i32
  %l99 = alloca i32
  %l103 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca ptr
  %t187 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store { i64, ptr } %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp ne i64 %t3, 1
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb3
bb2:
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = icmp ne i64 %t9, 0
  store i1 %t11, ptr %l15, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l15, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t14 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t18 = icmp ne i64 %t16, 1
  br i1 %t18, label %bb6, label %bb7
bb5:
  br label %bb15
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l22, !tbaa !29
  %t21 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t21, ptr %l23
  %t22 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t26 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeArgCount(ptr %s2, ptr %s2, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d34, i32 0, i32 1) }, i64 1, i64 %t24)
  store %"compiler/diagmsg:Msg" %t26, ptr %l26
  br label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l28, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t28, ptr %l29
  %t29 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTakesNoArgs(ptr %s3, ptr %s3, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d35, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t29, ptr %l30
  br label %bb10
bb8:
  %t30 = load ptr, ptr %l22, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l23
  %t32 = load %"compiler/diagmsg:Msg", ptr %l26
  %t33 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t30, %"compiler/source:Span" %t31, %"compiler/diagmsg:Msg" %t32)
  store i64 %t33, ptr %l27
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb10:
  %t34 = load ptr, ptr %l28, !tbaa !29
  %t35 = load %"compiler/source:Span", ptr %l29
  %t36 = load %"compiler/diagmsg:Msg", ptr %l30
  %t37 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t34, %"compiler/source:Span" %t35, %"compiler/diagmsg:Msg" %t36)
  store i64 %t37, ptr %l31
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v3, ptr %t38, { i64, ptr } %t39)
  br label %bb13
bb13:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load %"compiler/source:Span", ptr %l1
  %t46 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t42, %"compiler/source:Span" %t43)
  store ptr %t46, ptr %l36
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t47 = load ptr, ptr %l36, !tbaa !29
  store ptr %t47, ptr %rv
  br label %ret
bb15:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t49, ptr %l38, !tbaa !27
  %t50 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr ptr, ptr %t51, i64 0
  %t53 = load ptr, ptr %t52, !tbaa !39
  %t57 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v2, ptr %t48, ptr %t53)
  store i32 %t57, ptr %l41
  br label %bb16
bb16:
  %t58 = load i32, ptr %l41, !tbaa !23
  store i32 %t58, ptr %l6, !tbaa !23
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = load %"compiler/source:Span", ptr %l1
  %t65 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v1, ptr %v4, ptr %t59, ptr %a3, %"compiler/source:Span" %t61)
  store ptr %t65, ptr %l45
  br label %bb17
bb17:
  %t66 = load ptr, ptr %l45, !tbaa !29
  store ptr %t66, ptr %l7, !tbaa !29
  %t67 = load ptr, ptr %l7, !tbaa !29
  %t70 = call i32 @compiler_2fcheck_2etypeOf(ptr %v4, ptr %t67)
  store i32 %t70, ptr %l48
  br label %bb18
bb18:
  %t71 = load i32, ptr %l48, !tbaa !23
  store i32 %t71, ptr %l8, !tbaa !23
  %t72 = load i32, ptr %l6, !tbaa !23
  %t73 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t76 = icmp eq i32 %t72, %t73
  br i1 %t76, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb21
bb20:
  %t78 = load i32, ptr %l8, !tbaa !23
  %t79 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t82 = icmp eq i32 %t78, %t79
  store i1 %t82, ptr %l52, !tbaa !21
  br label %bb21
bb21:
  %t84 = load i1, ptr %l52, !tbaa !21
  br i1 %t84, label %bb22, label %bb23
bb22:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load %"compiler/source:Span", ptr %l1
  %t89 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t85, %"compiler/source:Span" %t86)
  store ptr %t89, ptr %l58
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_scope_close(ptr %s0)
  %t90 = load ptr, ptr %l58, !tbaa !29
  store ptr %t90, ptr %rv
  br label %ret
bb25:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load i32, ptr %l6, !tbaa !23
  %t95 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t91, i32 %t92)
  store i1 %t95, ptr %l61
  br label %bb26
bb26:
  %t96 = load i1, ptr %l61, !tbaa !21
  %t97 = xor i1 %t96, true
  br i1 %t97, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s5
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l63, !tbaa !29
  %t100 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t100, ptr %l64, !tbaa !27
  %t101 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr ptr, ptr %t102, i64 0
  %t104 = load ptr, ptr %t103, !tbaa !39
  %t106 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %t104)
  store %"compiler/source:Span" %t106, ptr %l66
  br label %bb29
bb28:
  br label %bb34
bb29:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i32, ptr %l6, !tbaa !23
  %t111 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t107, i32 %t108)
  store { i64, ptr } %t111, ptr %l69
  br label %bb30
bb30:
  %t112 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t112, 0
  %t114 = extractvalue { i64, ptr } %t112, 1
  %t115 = mul i64 %t113, 1
  %t116 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t115)
  call void @llvm.memcpy.p0.p0.i64(ptr %t116, ptr %t114, i64 %t115, i1 false)
  %t117 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t116, 1
  %t120 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNarrowNotNumber(ptr %s5, ptr %s5, { i64, ptr } %t118)
  store %"compiler/diagmsg:Msg" %t120, ptr %l71
  br label %bb31
bb31:
  %t121 = load ptr, ptr %l63, !tbaa !29
  %t122 = load %"compiler/source:Span", ptr %l66
  %t123 = load %"compiler/diagmsg:Msg", ptr %l71
  %t124 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t121, %"compiler/source:Span" %t122, %"compiler/diagmsg:Msg" %t123)
  store i64 %t124, ptr %l72
  br label %bb32
bb32:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load %"compiler/source:Span", ptr %l1
  %t129 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t125, %"compiler/source:Span" %t126)
  store ptr %t129, ptr %l75
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t130 = load ptr, ptr %l75, !tbaa !29
  store ptr %t130, ptr %rv
  br label %ret
bb34:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i32, ptr %l8, !tbaa !23
  %t133 = load i32, ptr %l6, !tbaa !23
  %t137 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvWords(ptr %v0, ptr %s0, ptr %t131, i32 %t132, i32 %t133)
  store { i64, ptr } %t137, ptr %l79
  br label %bb35
bb35:
  %t138 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t138, ptr %l9, !tbaa !27
  %t139 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t139, 0
  %t143 = icmp eq i64 %t141, 0
  br i1 %t143, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s6
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %s6, ptr %s6, ptr %s6, ptr %t145, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d36, i32 0, i32 1) }, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d37, i32 0, i32 1) }, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d38, i32 0, i32 1) })
  store i32 %t147, ptr %l84
  br label %bb38
bb37:
  br label %bb39
bb38:
  %t148 = mul i64 1, 4
  %t149 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t148)
  %t150 = insertvalue { i64, ptr } undef, i64 1, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  store { i64, ptr } %t151, ptr %l85, !tbaa !27
  %t152 = load i32, ptr %l84, !tbaa !23
  %t153 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr i32, ptr %t154, i64 0
  store i32 %t152, ptr %t155, !tbaa !33
  %t156 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t156, ptr %l9, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb39
bb39:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t159 = load %"compiler/source:Span", ptr %l2
  %t163 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailOp(ptr %v0, ptr %s0, ptr %t157, { i64, ptr } %t158, %"compiler/source:Span" %t159, i1 false)
  store i32 %t163, ptr %l89
  br label %bb40
bb40:
  %t164 = load i32, ptr %l89, !range !{i32 0, i32 3}
  store i32 %t164, ptr %l10
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/check:Checker", ptr %t165, i32 0, i32 36
  %t169 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t167)
  store i64 %t169, ptr %l92
  br label %bb41
bb41:
  %t170 = load i64, ptr %l92, !tbaa !24
  store i64 %t170, ptr %l11, !tbaa !24
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/check:Checker", ptr %t171, i32 0, i32 36
  %t174 = load ptr, ptr %l7, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v4, ptr %t173, ptr %t174)
  br label %bb42
bb42:
  %t177 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t177, ptr %l96
  %t178 = load i32, ptr %l6, !tbaa !23
  store i32 %t178, ptr %l97, !tbaa !23
  store i32 20, ptr %l98
  %t179 = load i32, ptr %l10, !range !{i32 0, i32 3}
  store i32 %t179, ptr %l99
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/check:Checker", ptr %t180, i32 0, i32 36
  %t183 = load i64, ptr %l11, !tbaa !24
  %t186 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v4, ptr %t182, i64 %t183)
  store { i64, ptr } %t186, ptr %l103
  br label %bb43
bb43:
  store { i64, [5 x i64] } zeroinitializer, ptr %t187
  %t188 = getelementptr { i64, [5 x i64] }, ptr %t187, i32 0, i32 0
  store i64 9, ptr %t188
  %t189 = load %"compiler/source:Span", ptr %l96
  %t190 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t189, 0
  %t191 = load i32, ptr %l97, !tbaa !23
  %t192 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t190, i32 %t191, 1
  %t193 = load i32, ptr %l98, !range !{i32 0, i32 46}
  %t194 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t192, i32 %t193, 2
  %t195 = load i32, ptr %l99, !range !{i32 0, i32 3}
  %t196 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t194, i32 %t195, 3
  %t197 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t198 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t196, { i64, ptr } %t197, 4
  %t199 = getelementptr { i64, [5 x i64] }, ptr %t187, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t198, ptr %t199
  %t200 = load { i64, [5 x i64] }, ptr %t187
  %t202 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 48, i64 8)
  store { i64, [5 x i64] } %t200, ptr %t202
  call void @__olang_scope_close(ptr %s0)
  store ptr %t202, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoIndex(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l8 = alloca %"compiler/source:Span"
  %l12 = alloca i1
  %l17 = alloca i64
  %l19 = alloca ptr
  %l23 = alloca %"compiler/source:Span"
  %l29 = alloca { i64, ptr }
  %l31 = alloca %"compiler/diagmsg:Msg"
  %l32 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca %"compiler/source:Span"
  %l35 = alloca i32
  %l38 = alloca { i64, ptr }
  %l40 = alloca %"compiler/diagmsg:Msg"
  %l41 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebracketIn(ptr %v0, ptr %t1, %"compiler/source:Span" %a1)
  store %"compiler/source:Span" %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t6, ptr %l5
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  %t9 = load %"compiler/source:Span", ptr %l5
  %t13 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %s0, ptr %s0, ptr %t7, i32 %t8, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d39, i32 0, i32 1) }, %"compiler/source:Span" %t9, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d40, i32 0, i32 1) }, i64 1, i1 true)
  store i1 %t13, ptr %l12
  br label %bb2
bb2:
  %t14 = load i1, ptr %l12, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l2, !tbaa !23
  %t19 = add i64 %a4, 1
  %t23 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t15, i32 %t16, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d41, i32 0, i32 1) }, i64 %t19)
  store i64 %t23, ptr %l17
  br label %bb6
bb6:
  %t24 = load i64, ptr %l17, !tbaa !24
  %t25 = icmp sge i64 %t24, 0
  br i1 %t25, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l19, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 48
  %t31 = getelementptr %"compiler/source:Span", ptr %t30, i32 0, i32 0
  %t32 = load i32, ptr %t31, !tbaa !23
  %t34 = icmp sge i32 %t32, 0
  br i1 %t34, label %bb9, label %bb10
bb8:
  br label %bb15
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 48
  %t39 = load %"compiler/source:Span", ptr %t38
  store %"compiler/source:Span" %t39, ptr %l23
  br label %bb11
bb10:
  %t41 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t41, ptr %l23
  br label %bb11
bb11:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t47 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t43, i32 %a3)
  store { i64, ptr } %t47, ptr %l29
  br label %bb12
bb12:
  %t48 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 0
  %t50 = extractvalue { i64, ptr } %t48, 1
  %t51 = mul i64 %t49, 1
  %t52 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t51)
  call void @llvm.memcpy.p0.p0.i64(ptr %t52, ptr %t50, i64 %t51, i1 false)
  %t53 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  %t56 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAtUndeclared(ptr %s2, ptr %s2, { i64, ptr } %t54)
  store %"compiler/diagmsg:Msg" %t56, ptr %l31
  br label %bb13
bb13:
  %t57 = load ptr, ptr %l19, !tbaa !29
  %t58 = load %"compiler/source:Span", ptr %l23
  %t59 = load %"compiler/diagmsg:Msg", ptr %l31
  %t60 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t57, %"compiler/source:Span" %t58, %"compiler/diagmsg:Msg" %t59)
  store i64 %t60, ptr %l32
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb15:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l33, !tbaa !29
  %t62 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t62, ptr %l34
  %t63 = load i32, ptr %l2, !tbaa !23
  store i32 %t63, ptr %l35, !tbaa !23
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load i32, ptr %l2, !tbaa !23
  %t68 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t64, i32 %t65)
  store { i64, ptr } %t68, ptr %l38
  br label %bb16
bb16:
  %t69 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  %t71 = extractvalue { i64, ptr } %t69, 1
  %t72 = mul i64 %t70, 1
  %t73 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t72)
  call void @llvm.memcpy.p0.p0.i64(ptr %t73, ptr %t71, i64 %t72, i1 false)
  %t74 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  %t77 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNotIndexable(ptr %s0, ptr %s0, { i64, ptr } %t75)
  store %"compiler/diagmsg:Msg" %t77, ptr %l40
  br label %bb17
bb17:
  %t78 = load ptr, ptr %l33, !tbaa !29
  %t79 = load %"compiler/source:Span", ptr %l34
  %t80 = load i32, ptr %l35, !tbaa !23
  %t81 = load %"compiler/diagmsg:Msg", ptr %l40
  %t82 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedErr(ptr %v0, ptr %s0, ptr %s0, ptr %t78, %"compiler/source:Span" %t79, i32 %t80, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d42, i32 0, i32 1) }, %"compiler/diagmsg:Msg" %t81)
  store i64 %t82, ptr %l41
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopnd(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l6 = alloca i1
  %l11 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t4 = call i1 @compiler_2fcheck_2elaneTok(i32 %a1)
  store i1 %t4, ptr %l6
  br label %bb1
bb1:
  %t5 = load i1, ptr %l6, !tbaa !21
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 40
  store i1 %t5, ptr %t7, !tbaa !21
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t15 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t8, ptr %a2, i32 %a3)
  store ptr %t15, ptr %l11
  br label %bb2
bb2:
  %t16 = load ptr, ptr %l11, !tbaa !29
  store ptr %t16, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoverrideClash(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca i1
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i32
  %l20 = alloca i32
  %l23 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l36 = alloca i32
  %l39 = alloca i1
  %l41 = alloca i1
  %l46 = alloca i1
  %l51 = alloca ptr
  %l57 = alloca i64
  %l60 = alloca i1
  %l67 = alloca i32
  %l70 = alloca ptr
  %l75 = alloca i32
  %l76 = alloca { i64, ptr }
  %l87 = alloca i64
  %l90 = alloca i64
  %l113 = alloca { i64, ptr }
  %l116 = alloca i1
  %l117 = alloca i1
  %l121 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l127 = alloca i1
  %l135 = alloca i32
  %l137 = alloca i1
  %l142 = alloca i1
  %l143 = alloca i1
  %l146 = alloca ptr
  %l147 = alloca i32
  %l152 = alloca i32
  %l153 = alloca i1
  %l156 = alloca ptr
  %l160 = alloca i64
  %l162 = alloca ptr
  %l163 = alloca ptr
  %l166 = alloca %"compiler/source:Span"
  %l170 = alloca { i64, ptr }
  %l171 = alloca %"compiler/diagmsg:Msg"
  %l172 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t4, i64 %t5)
  store i32 %t8, ptr %l20
  br label %bb1
bb1:
  %t9 = load i32, ptr %l20, !tbaa !23
  store i32 %t9, ptr %l2, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  store ptr %t15, ptr %l23, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l28
  br label %bb2
bb2:
  %t26 = load ptr, ptr %l23, !tbaa !29
  %t27 = load i32, ptr %l28, !tbaa !23
  %t28 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t26, i32 %t27)
  store { i64, ptr } %t28, ptr %l29
  br label %bb3
bb3:
  %t29 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t29, ptr %l3, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  %t34 = icmp eq i64 %t32, 0
  br i1 %t34, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  br label %bb6
bb6:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t37, ptr %l34, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr i32, ptr %t39, i64 0
  %t41 = load i32, ptr %t40, !tbaa !33
  %t44 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t36, i32 %t41)
  store i32 %t44, ptr %l36
  br label %bb7
bb7:
  %t45 = load i32, ptr %l36, !tbaa !23
  store i32 %t45, ptr %l4, !tbaa !23
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i32, ptr %l4, !tbaa !23
  %t50 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t46, i32 %t47)
  store i1 %t50, ptr %l39
  br label %bb8
bb8:
  %t51 = load i1, ptr %l39, !tbaa !21
  %t52 = xor i1 %t51, true
  br i1 %t52, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb12
bb10:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/generic:Program", ptr %t57, i32 0, i32 2
  %t60 = load i32, ptr %l4, !tbaa !23
  %t63 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t59, i32 %t60)
  store i1 %t63, ptr %l46
  br label %bb11
bb11:
  %t64 = load i1, ptr %l46, !tbaa !21
  %t65 = xor i1 %t64, true
  store i1 %t65, ptr %l41, !tbaa !21
  br label %bb12
bb12:
  %t67 = load i1, ptr %l41, !tbaa !21
  br i1 %t67, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  br label %bb15
bb15:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/check:Checker", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t72 = load i64, ptr %l1, !tbaa !24
  %t75 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t71, i64 %t72)
  store ptr %t75, ptr %l51
  br label %bb16
bb16:
  %t76 = load ptr, ptr %l51, !tbaa !29
  store ptr %t76, ptr %l5, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t81 = load i32, ptr %l4, !tbaa !23
  %t82 = load ptr, ptr %l5, !tbaa !29
  %t84 = getelementptr %"compiler/ast:Func", ptr %t82, i32 0, i32 2
  %t85 = load i32, ptr %t84, !tbaa !23
  %t89 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultMethod(ptr %v0, ptr %t80, i32 %t81, i32 %t85)
  store i64 %t89, ptr %l57
  br label %bb17
bb17:
  %t90 = load i64, ptr %l57, !tbaa !24
  store i64 %t90, ptr %l6, !tbaa !24
  %t91 = load i64, ptr %l6, !tbaa !24
  %t93 = icmp slt i64 %t91, 0
  br i1 %t93, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb20
bb19:
  %t95 = load i64, ptr %l6, !tbaa !24
  %t96 = load i64, ptr %l1, !tbaa !24
  %t99 = icmp eq i64 %t95, %t96
  store i1 %t99, ptr %l60, !tbaa !21
  br label %bb20
bb20:
  %t101 = load i1, ptr %l60, !tbaa !21
  br i1 %t101, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb22:
  br label %bb23
bb23:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/check:Checker", ptr %t102, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t106 = load i64, ptr %l6, !tbaa !24
  %t109 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t105, i64 %t106)
  store i32 %t109, ptr %l67
  br label %bb24
bb24:
  %t110 = load i32, ptr %l67, !tbaa !23
  store i32 %t110, ptr %l7, !tbaa !23
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/check:Checker", ptr %t111, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = getelementptr %"compiler/generic:Program", ptr %t114, i32 0, i32 2
  store ptr %t116, ptr %l70, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = getelementptr %"compiler/generic:Program", ptr %t120, i32 0, i32 2
  %t123 = load i32, ptr %l7, !tbaa !23
  %t126 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t122, i32 %t123)
  store i32 %t126, ptr %l75
  br label %bb25
bb25:
  %t127 = load ptr, ptr %l70, !tbaa !29
  %t128 = load i32, ptr %l75, !tbaa !23
  %t129 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t127, i32 %t128)
  store { i64, ptr } %t129, ptr %l76
  br label %bb26
bb26:
  %t130 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t130, ptr %l8, !tbaa !27
  %t131 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t131, 0
  %t134 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t134, 0
  %t139 = icmp eq i64 %t133, %t136
  store i1 %t139, ptr %l9, !tbaa !21
  store i64 1, ptr %l10, !tbaa !24
  %t141 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t141, 0
  store i64 %t143, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t145 = load i64, ptr %l11, !tbaa !24
  %t146 = load i64, ptr %l10, !tbaa !24
  %t149 = icmp sgt i64 %t145, %t146
  br i1 %t149, label %bb27, label %bb28
bb27:
  %t151 = load i64, ptr %l12, !tbaa !24
  %t153 = icmp sgt i64 %t151, 0
  br i1 %t153, label %bb29, label %bb30
bb28:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb32
bb29:
  %t155 = load i64, ptr %l11, !tbaa !24
  %t156 = load i64, ptr %l10, !tbaa !24
  %t159 = sub i64 %t155, %t156
  %t160 = load i64, ptr %l12, !tbaa !24
  %t163 = add i64 %t159, %t160
  %t165 = sub i64 %t163, 1
  %t166 = load i64, ptr %l12, !tbaa !24
  %t169 = sdiv i64 %t165, %t166
  store i64 %t169, ptr %l90, !tbaa !24
  br label %bb31
bb30:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb31
bb31:
  %t171 = load i64, ptr %l90, !tbaa !24
  store i64 %t171, ptr %l87, !tbaa !24
  br label %bb32
bb32:
  %t172 = load i64, ptr %l87, !tbaa !24
  store i64 %t172, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb33
bb33:
  %t173 = load i64, ptr %l14, !tbaa !24
  %t174 = load i64, ptr %l13, !tbaa !24
  %t177 = icmp slt i64 %t173, %t174
  %t179 = xor i1 %t177, true
  br i1 %t179, label %bb34, label %bb35
bb34:
  br label %bb49
bb35:
  br label %bb36
bb36:
  %t181 = load i64, ptr %l10, !tbaa !24
  %t182 = load i64, ptr %l14, !tbaa !24
  %t183 = load i64, ptr %l12, !tbaa !24
  %t186 = mul i64 %t182, %t183
  %t189 = add i64 %t181, %t186
  store i64 %t189, ptr %l15, !tbaa !24
  %t191 = load i1, ptr %l9, !tbaa !21
  %t193 = xor i1 %t191, true
  br i1 %t193, label %bb37, label %bb38
bb37:
  br label %bb49
bb38:
  br label %bb39
bb39:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/check:Checker", ptr %t195, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !29
  %t200 = getelementptr %"compiler/generic:Program", ptr %t198, i32 0, i32 2
  %t201 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t201, ptr %l113, !tbaa !27
  %t202 = load i64, ptr %l15, !tbaa !24
  %t204 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !27
  %t206 = getelementptr i32, ptr %t205, i64 %t202
  %t207 = load i32, ptr %t206, !tbaa !33
  %t210 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t200, i32 %t207)
  store i1 %t210, ptr %l116
  br label %bb40
bb40:
  %t211 = load i1, ptr %l116, !tbaa !21
  br i1 %t211, label %bb41, label %bb42
bb41:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/check:Checker", ptr %t212, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !29
  %t217 = getelementptr %"compiler/generic:Program", ptr %t215, i32 0, i32 2
  %t218 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t218, ptr %l121, !tbaa !27
  %t219 = load i64, ptr %l15, !tbaa !24
  %t221 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t222 = load ptr, ptr %t221, !tbaa !27
  %t223 = getelementptr i32, ptr %t222, i64 %t219
  %t224 = load i32, ptr %t223, !tbaa !33
  %t225 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t225, ptr %l124, !tbaa !27
  %t226 = load i64, ptr %l15, !tbaa !24
  %t228 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t229 = load ptr, ptr %t228, !tbaa !27
  %t230 = getelementptr i32, ptr %t229, i64 %t226
  %t231 = load i32, ptr %t230, !tbaa !33
  %t235 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t217, i32 %t224, i32 %t231)
  store i1 %t235, ptr %l127
  br label %bb43
bb42:
  store i1 false, ptr %l117, !tbaa !21
  br label %bb44
bb43:
  %t236 = load i1, ptr %l127, !tbaa !21
  %t237 = xor i1 %t236, true
  store i1 %t237, ptr %l117, !tbaa !21
  br label %bb44
bb44:
  %t239 = load i1, ptr %l117, !tbaa !21
  br i1 %t239, label %bb45, label %bb46
bb45:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb47
bb46:
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t240 = load i64, ptr %l14, !tbaa !24
  %t242 = add i64 %t240, 1
  store i64 %t242, ptr %l14, !tbaa !24
  br label %bb33
bb49:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr %"compiler/check:Checker", ptr %t244, i32 0, i32 1
  %t247 = load ptr, ptr %t246, !tbaa !29
  %t249 = getelementptr %"compiler/generic:Program", ptr %t247, i32 0, i32 2
  %t250 = load i32, ptr %l7, !tbaa !23
  %t253 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t249, i32 %t250)
  store i32 %t253, ptr %l135
  br label %bb50
bb50:
  %t254 = load i32, ptr %l135, !tbaa !23
  store i32 %t254, ptr %l16, !tbaa !23
  %t255 = load i1, ptr %l9, !tbaa !21
  br i1 %t255, label %bb51, label %bb52
bb51:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/check:Checker", ptr %t257, i32 0, i32 1
  %t260 = load ptr, ptr %t259, !tbaa !29
  %t262 = getelementptr %"compiler/generic:Program", ptr %t260, i32 0, i32 2
  %t263 = load i32, ptr %l16, !tbaa !23
  %t266 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t262, i32 %t263)
  store i1 %t266, ptr %l142
  br label %bb53
bb52:
  store i1 false, ptr %l137, !tbaa !21
  br label %bb54
bb53:
  %t267 = load i1, ptr %l142, !tbaa !21
  store i1 %t267, ptr %l137, !tbaa !21
  br label %bb54
bb54:
  %t268 = load i1, ptr %l137, !tbaa !21
  br i1 %t268, label %bb55, label %bb56
bb55:
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"compiler/check:Checker", ptr %t269, i32 0, i32 1
  %t272 = load ptr, ptr %t271, !tbaa !29
  %t274 = getelementptr %"compiler/generic:Program", ptr %t272, i32 0, i32 2
  store ptr %t274, ptr %l146, !tbaa !29
  %t275 = load i32, ptr %l16, !tbaa !23
  store i32 %t275, ptr %l147, !tbaa !23
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t278 = getelementptr %"compiler/check:Checker", ptr %t276, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !29
  %t281 = getelementptr %"compiler/generic:Program", ptr %t279, i32 0, i32 2
  %t282 = load i32, ptr %l2, !tbaa !23
  %t285 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t281, i32 %t282)
  store i32 %t285, ptr %l152
  br label %bb57
bb56:
  store i1 false, ptr %l143, !tbaa !21
  br label %bb59
bb57:
  %t286 = load ptr, ptr %l146, !tbaa !29
  %t287 = load i32, ptr %l147, !tbaa !23
  %t288 = load i32, ptr %l152, !tbaa !23
  %t289 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t286, i32 %t287, i32 %t288)
  store i1 %t289, ptr %l153
  br label %bb58
bb58:
  %t290 = load i1, ptr %l153, !tbaa !21
  %t291 = xor i1 %t290, true
  store i1 %t291, ptr %l143, !tbaa !21
  br label %bb59
bb59:
  %t293 = load i1, ptr %l143, !tbaa !21
  br i1 %t293, label %bb60, label %bb61
bb60:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb62
bb61:
  br label %bb62
bb62:
  %t294 = load i1, ptr %l9, !tbaa !21
  br i1 %t294, label %bb63, label %bb64
bb63:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb64:
  br label %bb65
bb65:
  %t296 = load ptr, ptr %l0, !tbaa !29
  store ptr %t296, ptr %l156, !tbaa !29
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t299 = getelementptr %"compiler/check:Checker", ptr %t297, i32 0, i32 1
  %t300 = load ptr, ptr %t299, !tbaa !29
  %t301 = load i64, ptr %l1, !tbaa !24
  %t304 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t300, i64 %t301)
  store i64 %t304, ptr %l160
  br label %bb66
bb66:
  %t305 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t306 = load ptr, ptr %l156, !tbaa !29
  %t307 = load i64, ptr %l160, !tbaa !24
  %t309 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t306, i64 -1, i64 %t307, i32 %t305, i32 0)
  store ptr %t309, ptr %l162
  br label %bb67
bb67:
  %t310 = load ptr, ptr %l0, !tbaa !29
  store ptr %t310, ptr %l163, !tbaa !29
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t312 = load ptr, ptr %l5, !tbaa !29
  %t315 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v0, ptr %t311, ptr %t312)
  store %"compiler/source:Span" %t315, ptr %l166
  br label %bb68
bb68:
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t317 = load ptr, ptr %l5, !tbaa !29
  %t319 = getelementptr %"compiler/ast:Func", ptr %t317, i32 0, i32 2
  %t320 = load i32, ptr %t319, !tbaa !23
  %t323 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t316, i32 %t320)
  store { i64, ptr } %t323, ptr %l170
  br label %bb69
bb69:
  %t324 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t325 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOverrideSignature(ptr %v0, ptr %s0, { i64, ptr } %t324)
  store %"compiler/diagmsg:Msg" %t325, ptr %l171
  br label %bb70
bb70:
  %t326 = load ptr, ptr %l163, !tbaa !29
  %t327 = load %"compiler/source:Span", ptr %l166
  %t328 = load %"compiler/diagmsg:Msg", ptr %l171
  %t329 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t326, %"compiler/source:Span" %t327, %"compiler/diagmsg:Msg" %t328)
  store i64 %t329, ptr %l172
  br label %bb71
bb71:
  %t330 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t330)
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowExponent(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca i64
  %l13 = alloca i32
  %l14 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i32, ptr %l1, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t7, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l6, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l7, !tbaa !29
  %t11 = load i32, ptr %l1, !tbaa !23
  store i32 %t11, ptr %l8, !tbaa !23
  %t12 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 -1, i32 -1)
  store %"compiler/source:Span" %t12, ptr %l9
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l7, !tbaa !29
  %t14 = load i32, ptr %l8, !tbaa !23
  %t15 = load %"compiler/source:Span", ptr %l9
  %t16 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowMethod(ptr %v0, ptr %t13, i32 %t14, %"compiler/source:Span" %t15)
  store i64 %t16, ptr %l10
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i32, ptr %l1, !tbaa !23
  %t21 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l13
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l6, !tbaa !29
  %t23 = load i64, ptr %l10, !tbaa !24
  %t24 = load i32, ptr %l13, !tbaa !23
  %t25 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperandParam(ptr %v0, ptr %t22, i64 %t23, i32 %t24)
  store i32 %t25, ptr %l14
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t26 = load i32, ptr %l14, !tbaa !23
  store i32 %t26, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushFacts(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = load i1, ptr %l2, !tbaa !21
  %t4 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushNulls(ptr %v0, ptr %v1, ptr %t1, ptr %t2, i1 %t3, i64 %t4)
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t11 = load i1, ptr %l2, !tbaa !21
  %t12 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushErrNarrow(ptr %v0, ptr %v1, ptr %t9, ptr %t10, i1 %t11, i64 %t12)
  br label %bb2
bb2:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t19 = load i1, ptr %l2, !tbaa !21
  %t20 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushCases(ptr %v0, ptr %v1, ptr %t17, ptr %t18, i1 %t19, i64 %t20)
  br label %bb3
bb3:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflMember(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"compiler/check:reflList"
  %l7 = alloca i32
  %lp8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca %"compiler/generic:Desc"
  %lp11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l18 = alloca { i64, ptr }
  %l25 = alloca %"compiler/check:reflList"
  %l27 = alloca ptr
  %l28 = alloca %"compiler/source:Span"
  %l31 = alloca { i64, ptr }
  %l34 = alloca %"compiler/diagmsg:Msg"
  %l35 = alloca i64
  %l38 = alloca ptr
  %l42 = alloca i32
  %l50 = alloca ptr
  %l54 = alloca i1
  %l55 = alloca i1
  %l58 = alloca i1
  %l60 = alloca i1
  %l64 = alloca i1
  %l67 = alloca i1
  %l68 = alloca ptr
  %l69 = alloca %"compiler/source:Span"
  %l72 = alloca { i64, ptr }
  %l75 = alloca %"compiler/diagmsg:Msg"
  %l76 = alloca i64
  %l79 = alloca ptr
  %l82 = alloca i1
  %l83 = alloca i1
  %l85 = alloca i1
  %l86 = alloca i1
  %l88 = alloca i1
  %l89 = alloca i1
  %l91 = alloca i1
  %l92 = alloca i1
  %l94 = alloca i1
  %l98 = alloca %"compiler/check:reflVal"
  %l103 = alloca ptr
  %l106 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca %"compiler/source:Span"
  %l111 = alloca { i64, ptr }
  %l113 = alloca %"compiler/diagmsg:Msg"
  %l114 = alloca i64
  %l116 = alloca i1
  %l117 = alloca ptr
  %l118 = alloca %"compiler/source:Span"
  %l121 = alloca { i64, ptr }
  %l123 = alloca %"compiler/diagmsg:Msg"
  %l124 = alloca i64
  %l126 = alloca i1
  %l127 = alloca i1
  %l129 = alloca i1
  %l130 = alloca ptr
  %l131 = alloca %"compiler/source:Span"
  %l134 = alloca { i64, ptr }
  %l137 = alloca %"compiler/diagmsg:Msg"
  %l138 = alloca i64
  %l141 = alloca ptr
  %l145 = alloca i1
  %l146 = alloca i1
  %l148 = alloca i1
  %l152 = alloca i1
  %l156 = alloca i1
  %l157 = alloca i1
  %l160 = alloca i32
  %l164 = alloca ptr
  %l165 = alloca %"compiler/source:Span"
  %l168 = alloca { i64, ptr }
  %l171 = alloca %"compiler/diagmsg:Msg"
  %l172 = alloca i64
  %l175 = alloca ptr
  %l179 = alloca i32
  %l188 = alloca ptr
  %l193 = alloca %"compiler/generic:Desc"
  %l195 = alloca i1
  %l196 = alloca i1
  %l200 = alloca ptr
  %l201 = alloca %"compiler/source:Span"
  %l204 = alloca { i64, ptr }
  %l207 = alloca %"compiler/diagmsg:Msg"
  %l208 = alloca i64
  %l211 = alloca ptr
  %l214 = alloca i1
  %l215 = alloca i1
  %l222 = alloca ptr
  %l227 = alloca %"compiler/check:reflVal"
  %l232 = alloca ptr
  %l235 = alloca { i64, ptr }
  %l249 = alloca { i64, ptr }
  %l262 = alloca ptr
  %l263 = alloca %"compiler/source:Span"
  %l267 = alloca %"compiler/diagmsg:Msg"
  %l268 = alloca i64
  %l271 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca ptr
  %t11 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l4, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l18
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t6, ptr %l5, !tbaa !27
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t10 = load i32, ptr %l4, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t11
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t11, i32 0, i32 0
  store i64 14, ptr %t12
  %t14 = insertvalue { %"compiler/source:Span", ptr, i32 } undef, %"compiler/source:Span" %t8, 0
  %t16 = insertvalue { %"compiler/source:Span", ptr, i32 } %t14, ptr %t9, 1
  %t18 = insertvalue { %"compiler/source:Span", ptr, i32 } %t16, i32 %t10, 2
  %t19 = getelementptr { i64, [4 x i64] }, ptr %t11, i32 0, i32 1
  store { %"compiler/source:Span", ptr, i32 } %t18, ptr %t19
  %t20 = load { i64, [4 x i64] }, ptr %t11
  %t22 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 40, i64 8)
  store { i64, [4 x i64] } %t20, ptr %t22
  %t25 = call %"compiler/check:reflList" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistOf(ptr %v0, ptr %s0, ptr %t7, ptr %t22)
  store %"compiler/check:reflList" %t25, ptr %l25
  br label %bb2
bb2:
  %t26 = load %"compiler/check:reflList", ptr %l25
  store %"compiler/check:reflList" %t26, ptr %l6
  %t27 = getelementptr %"compiler/check:reflList", ptr %l6, i32 0, i32 0
  %t28 = load i1, ptr %t27, !tbaa !21
  br i1 %t28, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l27, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t31, ptr %l28
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load %"compiler/source:Span", ptr %l1
  %t36 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %s1, ptr %t32, %"compiler/source:Span" %t33)
  store { i64, ptr } %t36, ptr %l31
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t37 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 1
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t40 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t39)
  call void @olang_textcopy(ptr %t40, ptr %t38, i64 %t39)
  %t41 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t45 = extractvalue { i64, ptr } %t42, 1
  %t46 = mul i64 %t44, 1
  %t47 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t46)
  call void @llvm.memcpy.p0.p0.i64(ptr %t47, ptr %t45, i64 %t46, i1 false)
  %t48 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  %t51 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflListValue(ptr %s1, ptr %s1, { i64, ptr } %t49)
  store %"compiler/diagmsg:Msg" %t51, ptr %l34
  br label %bb6
bb6:
  %t52 = load ptr, ptr %l27, !tbaa !29
  %t53 = load %"compiler/source:Span", ptr %l28
  %t54 = load %"compiler/diagmsg:Msg", ptr %l34
  %t55 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t52, %"compiler/source:Span" %t53, %"compiler/diagmsg:Msg" %t54)
  store i64 %t55, ptr %l35
  br label %bb7
bb7:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load %"compiler/source:Span", ptr %l1
  %t60 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t56, %"compiler/source:Span" %t57)
  store ptr %t60, ptr %l38
  br label %bb8
bb8:
  %t61 = load ptr, ptr %l38, !tbaa !29
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t61, ptr %rv
  br label %ret
bb9:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load ptr, ptr %l3, !tbaa !29
  %t67 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflType(ptr %v0, ptr %v1, ptr %t63, ptr %t64)
  store i32 %t67, ptr %l42
  br label %bb10
bb10:
  %t68 = load i32, ptr %l42, !tbaa !23
  store i32 %t68, ptr %l7, !tbaa !23
  %t69 = load i32, ptr %l7, !tbaa !23
  %t71 = icmp sge i32 %t69, 0
  br i1 %t71, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t73 = load i32, ptr %l7, !tbaa !23
  %t74 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t77 = icmp eq i32 %t73, %t74
  br i1 %t77, label %bb13, label %bb14
bb12:
  br label %bb112
bb13:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load %"compiler/source:Span", ptr %l1
  %t83 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t79, %"compiler/source:Span" %t80)
  store ptr %t83, ptr %l50
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t84 = load ptr, ptr %l50, !tbaa !29
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t84, ptr %rv
  br label %ret
bb16:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load i32, ptr %l7, !tbaa !23
  %t90 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t86, i32 %t87)
  store i1 %t90, ptr %l54
  br label %bb17
bb17:
  %t91 = load i1, ptr %l54, !tbaa !21
  br i1 %t91, label %bb18, label %bb19
bb18:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %l3, !tbaa !29
  %t96 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eviaTypeVar(ptr %v0, ptr %v1, ptr %t92, ptr %t93)
  store i1 %t96, ptr %l58
  br label %bb20
bb19:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb21
bb20:
  %t97 = load i1, ptr %l58, !tbaa !21
  %t98 = xor i1 %t97, true
  store i1 %t98, ptr %l55, !tbaa !21
  br label %bb21
bb21:
  %t100 = load i1, ptr %l55, !tbaa !21
  br i1 %t100, label %bb22, label %bb23
bb22:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load i32, ptr %l7, !tbaa !23
  %t103 = load i32, ptr %l4, !tbaa !23
  %t107 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasCase(ptr %v0, ptr %t101, i32 %t102, i32 %t103)
  store i1 %t107, ptr %l64
  br label %bb24
bb23:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb25
bb24:
  %t108 = load i1, ptr %l64, !tbaa !21
  store i1 %t108, ptr %l60, !tbaa !21
  br label %bb25
bb25:
  %t109 = load i1, ptr %l60, !tbaa !21
  br i1 %t109, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t111 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t113 = call i1 @compiler_2fgeneric_2eProjectsType(ptr %v0, { i64, ptr } %t111)
  store i1 %t113, ptr %l67
  br label %bb29
bb29:
  %t114 = load i1, ptr %l67, !tbaa !21
  br i1 %t114, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s6
  %t115 = load ptr, ptr %l0, !tbaa !29
  store ptr %t115, ptr %l68, !tbaa !29
  %t116 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t116, ptr %l69
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load %"compiler/source:Span", ptr %l1
  %t121 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %s6, ptr %t117, %"compiler/source:Span" %t118)
  store { i64, ptr } %t121, ptr %l72
  br label %bb32
bb31:
  br label %bb36
bb32:
  %t122 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t122, 1
  %t124 = extractvalue { i64, ptr } %t122, 0
  %t125 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t124)
  call void @olang_textcopy(ptr %t125, ptr %t123, i64 %t124)
  %t126 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t125, 1
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t130 = extractvalue { i64, ptr } %t127, 1
  %t131 = mul i64 %t129, 1
  %t132 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t131)
  call void @llvm.memcpy.p0.p0.i64(ptr %t132, ptr %t130, i64 %t131, i1 false)
  %t133 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t134 = insertvalue { i64, ptr } %t133, ptr %t132, 1
  %t136 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflTypeNotValue(ptr %s6, ptr %s6, { i64, ptr } %t134)
  store %"compiler/diagmsg:Msg" %t136, ptr %l75
  br label %bb33
bb33:
  %t137 = load ptr, ptr %l68, !tbaa !29
  %t138 = load %"compiler/source:Span", ptr %l69
  %t139 = load %"compiler/diagmsg:Msg", ptr %l75
  %t140 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t137, %"compiler/source:Span" %t138, %"compiler/diagmsg:Msg" %t139)
  store i64 %t140, ptr %l76
  br label %bb34
bb34:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load %"compiler/source:Span", ptr %l1
  %t145 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t141, %"compiler/source:Span" %t142)
  store ptr %t145, ptr %l79
  br label %bb35
bb35:
  %t146 = load ptr, ptr %l79, !tbaa !29
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t146, ptr %rv
  br label %ret
bb36:
  %t148 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t150 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t148, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d43, i32 0, i32 1) })
  store i1 %t150, ptr %l82
  br label %bb37
bb37:
  %t151 = load i1, ptr %l82, !tbaa !21
  br i1 %t151, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l83, !tbaa !21
  br label %bb41
bb39:
  %t152 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t154 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t152, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d44, i32 0, i32 1) })
  store i1 %t154, ptr %l85
  br label %bb40
bb40:
  %t155 = load i1, ptr %l85, !tbaa !21
  store i1 %t155, ptr %l83, !tbaa !21
  br label %bb41
bb41:
  %t156 = load i1, ptr %l83, !tbaa !21
  br i1 %t156, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l86, !tbaa !21
  br label %bb45
bb43:
  %t157 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t159 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t157, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d45, i32 0, i32 1) })
  store i1 %t159, ptr %l88
  br label %bb44
bb44:
  %t160 = load i1, ptr %l88, !tbaa !21
  store i1 %t160, ptr %l86, !tbaa !21
  br label %bb45
bb45:
  %t161 = load i1, ptr %l86, !tbaa !21
  br i1 %t161, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l89, !tbaa !21
  br label %bb49
bb47:
  %t162 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t164 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t162, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d46, i32 0, i32 1) })
  store i1 %t164, ptr %l91
  br label %bb48
bb48:
  %t165 = load i1, ptr %l91, !tbaa !21
  store i1 %t165, ptr %l89, !tbaa !21
  br label %bb49
bb49:
  %t166 = load i1, ptr %l89, !tbaa !21
  br i1 %t166, label %bb50, label %bb51
bb50:
  store i1 true, ptr %l92, !tbaa !21
  br label %bb53
bb51:
  %t167 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t169 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t167, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d47, i32 0, i32 1) })
  store i1 %t169, ptr %l94
  br label %bb52
bb52:
  %t170 = load i1, ptr %l94, !tbaa !21
  store i1 %t170, ptr %l92, !tbaa !21
  br label %bb53
bb53:
  %t171 = load i1, ptr %l92, !tbaa !21
  br i1 %t171, label %bb54, label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s8
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load ptr, ptr %l3, !tbaa !29
  %t174 = load i32, ptr %l4, !tbaa !23
  %t178 = call %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflConst(ptr %v0, ptr %v1, ptr %v2, ptr %t172, ptr %t173, i32 %t174)
  store %"compiler/check:reflVal" %t178, ptr %l98
  br label %bb56
bb55:
  br label %bb87
bb56:
  %t179 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t179, ptr %lp8
  %t180 = load %"compiler/check:reflVal", ptr %l98
  %t181 = load ptr, ptr %lp8
  store %"compiler/check:reflVal" %t180, ptr %t181
  %t182 = load ptr, ptr %lp8
  %t183 = getelementptr %"compiler/check:reflVal", ptr %t182, i32 0, i32 0
  %t184 = load i1, ptr %t183, !tbaa !21
  br i1 %t184, label %bb57, label %bb58
bb57:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load %"compiler/source:Span", ptr %l1
  %t188 = load ptr, ptr %lp8
  %t189 = load %"compiler/check:reflVal", ptr %t188
  %t193 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflExpr(ptr %v0, ptr %v2, ptr %v2, ptr %t186, %"compiler/source:Span" %t187, %"compiler/check:reflVal" %t189)
  store ptr %t193, ptr %l103
  br label %bb59
bb58:
  br label %bb60
bb59:
  %t194 = load ptr, ptr %l103, !tbaa !29
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t194, ptr %rv
  br label %ret
bb60:
  %t196 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t198 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s8, { i64, ptr } %t196, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d48, i32 0, i32 1) })
  store i1 %t198, ptr %l106
  br label %bb61
bb61:
  %t199 = load i1, ptr %l106, !tbaa !21
  br i1 %t199, label %bb62, label %bb63
bb62:
  store %olang.scope zeroinitializer, ptr %s10
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l107, !tbaa !29
  %t201 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t201, ptr %l108
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load i32, ptr %l7, !tbaa !23
  %t206 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s10, ptr %t202, i32 %t203)
  store { i64, ptr } %t206, ptr %l111
  br label %bb64
bb63:
  br label %bb67
bb64:
  %t207 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t207, 0
  %t209 = extractvalue { i64, ptr } %t207, 1
  %t210 = mul i64 %t208, 1
  %t211 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t210)
  call void @llvm.memcpy.p0.p0.i64(ptr %t211, ptr %t209, i64 %t210, i1 false)
  %t212 = insertvalue { i64, ptr } undef, i64 %t208, 0
  %t213 = insertvalue { i64, ptr } %t212, ptr %t211, 1
  %t215 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflNoKind(ptr %s10, ptr %s10, { i64, ptr } %t213)
  store %"compiler/diagmsg:Msg" %t215, ptr %l113
  br label %bb65
bb65:
  %t216 = load ptr, ptr %l107, !tbaa !29
  %t217 = load %"compiler/source:Span", ptr %l108
  %t218 = load %"compiler/diagmsg:Msg", ptr %l113
  %t219 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s10, ptr %t216, %"compiler/source:Span" %t217, %"compiler/diagmsg:Msg" %t218)
  store i64 %t219, ptr %l114
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s10)
  br label %bb67
bb67:
  %t220 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t222 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s8, { i64, ptr } %t220, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d49, i32 0, i32 1) })
  store i1 %t222, ptr %l116
  br label %bb68
bb68:
  %t223 = load i1, ptr %l116, !tbaa !21
  br i1 %t223, label %bb69, label %bb70
bb69:
  store %olang.scope zeroinitializer, ptr %s11
  %t224 = load ptr, ptr %l0, !tbaa !29
  store ptr %t224, ptr %l117, !tbaa !29
  %t225 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t225, ptr %l118
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t227 = load i32, ptr %l7, !tbaa !23
  %t230 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s11, ptr %t226, i32 %t227)
  store { i64, ptr } %t230, ptr %l121
  br label %bb71
bb70:
  br label %bb74
bb71:
  %t231 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t231, 0
  %t233 = extractvalue { i64, ptr } %t231, 1
  %t234 = mul i64 %t232, 1
  %t235 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t234)
  call void @llvm.memcpy.p0.p0.i64(ptr %t235, ptr %t233, i64 %t234, i1 false)
  %t236 = insertvalue { i64, ptr } undef, i64 %t232, 0
  %t237 = insertvalue { i64, ptr } %t236, ptr %t235, 1
  %t239 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflNoLength(ptr %s11, ptr %s11, { i64, ptr } %t237)
  store %"compiler/diagmsg:Msg" %t239, ptr %l123
  br label %bb72
bb72:
  %t240 = load ptr, ptr %l117, !tbaa !29
  %t241 = load %"compiler/source:Span", ptr %l118
  %t242 = load %"compiler/diagmsg:Msg", ptr %l123
  %t243 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s11, ptr %t240, %"compiler/source:Span" %t241, %"compiler/diagmsg:Msg" %t242)
  store i64 %t243, ptr %l124
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s11)
  br label %bb74
bb74:
  %t244 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t246 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s8, { i64, ptr } %t244, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d50, i32 0, i32 1) })
  store i1 %t246, ptr %l126
  br label %bb75
bb75:
  %t247 = load i1, ptr %l126, !tbaa !21
  br i1 %t247, label %bb76, label %bb77
bb76:
  store i1 true, ptr %l127, !tbaa !21
  br label %bb79
bb77:
  %t248 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t250 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s8, { i64, ptr } %t248, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d51, i32 0, i32 1) })
  store i1 %t250, ptr %l129
  br label %bb78
bb78:
  %t251 = load i1, ptr %l129, !tbaa !21
  store i1 %t251, ptr %l127, !tbaa !21
  br label %bb79
bb79:
  %t252 = load i1, ptr %l127, !tbaa !21
  br i1 %t252, label %bb80, label %bb81
bb80:
  store %olang.scope zeroinitializer, ptr %s12
  %t253 = load ptr, ptr %l0, !tbaa !29
  store ptr %t253, ptr %l130, !tbaa !29
  %t254 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t254, ptr %l131
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t256 = load i32, ptr %l7, !tbaa !23
  %t259 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s12, ptr %t255, i32 %t256)
  store { i64, ptr } %t259, ptr %l134
  br label %bb82
bb81:
  br label %bb85
bb82:
  %t260 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t261 = extractvalue { i64, ptr } %t260, 0
  %t262 = extractvalue { i64, ptr } %t260, 1
  %t263 = mul i64 %t261, 1
  %t264 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t263)
  call void @llvm.memcpy.p0.p0.i64(ptr %t264, ptr %t262, i64 %t263, i1 false)
  %t265 = insertvalue { i64, ptr } undef, i64 %t261, 0
  %t266 = insertvalue { i64, ptr } %t265, ptr %t264, 1
  %t267 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t270 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflNoLayout(ptr %s12, ptr %v0, ptr %s12, { i64, ptr } %t266, { i64, ptr } %t267)
  store %"compiler/diagmsg:Msg" %t270, ptr %l137
  br label %bb83
bb83:
  %t271 = load ptr, ptr %l130, !tbaa !29
  %t272 = load %"compiler/source:Span", ptr %l131
  %t273 = load %"compiler/diagmsg:Msg", ptr %l137
  %t274 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s12, ptr %t271, %"compiler/source:Span" %t272, %"compiler/diagmsg:Msg" %t273)
  store i64 %t274, ptr %l138
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s12)
  br label %bb85
bb85:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t276 = load %"compiler/source:Span", ptr %l1
  %t279 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t275, %"compiler/source:Span" %t276)
  store ptr %t279, ptr %l141
  br label %bb86
bb86:
  %t280 = load ptr, ptr %l141, !tbaa !29
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t280, ptr %rv
  br label %ret
bb87:
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t283 = load i32, ptr %l7, !tbaa !23
  %t286 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t282, i32 %t283)
  store i1 %t286, ptr %l145
  br label %bb88
bb88:
  %t287 = load i1, ptr %l145, !tbaa !21
  br i1 %t287, label %bb89, label %bb90
bb89:
  store i1 true, ptr %l146, !tbaa !21
  br label %bb92
bb90:
  %t288 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t290 = call i1 @compiler_2fcheck_2eisLimitName(ptr %v0, { i64, ptr } %t288)
  store i1 %t290, ptr %l148
  br label %bb91
bb91:
  %t291 = load i1, ptr %l148, !tbaa !21
  store i1 %t291, ptr %l146, !tbaa !21
  br label %bb92
bb92:
  %t292 = load i1, ptr %l146, !tbaa !21
  br i1 %t292, label %bb93, label %bb94
bb93:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb94:
  br label %bb95
bb95:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = load i32, ptr %l7, !tbaa !23
  %t298 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t294, i32 %t295)
  store i1 %t298, ptr %l152
  br label %bb96
bb96:
  %t299 = load i1, ptr %l152, !tbaa !21
  br i1 %t299, label %bb97, label %bb98
bb97:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb98:
  br label %bb99
bb99:
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t302 = load i32, ptr %l7, !tbaa !23
  %t305 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t301, i32 %t302)
  store i1 %t305, ptr %l156
  br label %bb100
bb100:
  %t306 = load i1, ptr %l156, !tbaa !21
  br i1 %t306, label %bb101, label %bb102
bb101:
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t308 = load i32, ptr %l7, !tbaa !23
  %t311 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t307, i32 %t308)
  store i32 %t311, ptr %l160
  br label %bb103
bb102:
  store i1 false, ptr %l157, !tbaa !21
  br label %bb104
bb103:
  %t312 = load i32, ptr %l160, !range !{i32 0, i32 6}
  %t314 = trunc i64 2 to i32
  %t315 = icmp eq i32 %t312, %t314
  store i1 %t315, ptr %l157, !tbaa !21
  br label %bb104
bb104:
  %t317 = load i1, ptr %l157, !tbaa !21
  br i1 %t317, label %bb105, label %bb106
bb105:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb106:
  br label %bb107
bb107:
  %t319 = load ptr, ptr %l0, !tbaa !29
  store ptr %t319, ptr %l164, !tbaa !29
  %t320 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t320, ptr %l165
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t322 = load i32, ptr %l7, !tbaa !23
  %t325 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t321, i32 %t322)
  store { i64, ptr } %t325, ptr %l168
  br label %bb108
bb108:
  %t326 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t327 = extractvalue { i64, ptr } %t326, 0
  %t328 = extractvalue { i64, ptr } %t326, 1
  %t329 = mul i64 %t327, 1
  %t330 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t329)
  call void @llvm.memcpy.p0.p0.i64(ptr %t330, ptr %t328, i64 %t329, i1 false)
  %t331 = insertvalue { i64, ptr } undef, i64 %t327, 0
  %t332 = insertvalue { i64, ptr } %t331, ptr %t330, 1
  %t333 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t336 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflNoMember(ptr %s3, ptr %v0, ptr %s3, { i64, ptr } %t332, { i64, ptr } %t333)
  store %"compiler/diagmsg:Msg" %t336, ptr %l171
  br label %bb109
bb109:
  %t337 = load ptr, ptr %l164, !tbaa !29
  %t338 = load %"compiler/source:Span", ptr %l165
  %t339 = load %"compiler/diagmsg:Msg", ptr %l171
  %t340 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t337, %"compiler/source:Span" %t338, %"compiler/diagmsg:Msg" %t339)
  store i64 %t340, ptr %l172
  br label %bb110
bb110:
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t342 = load %"compiler/source:Span", ptr %l1
  %t345 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t341, %"compiler/source:Span" %t342)
  store ptr %t345, ptr %l175
  br label %bb111
bb111:
  %t346 = load ptr, ptr %l175, !tbaa !29
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t346, ptr %rv
  br label %ret
bb112:
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t349 = load ptr, ptr %l3, !tbaa !29
  %t352 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %t348, ptr %t349)
  store i32 %t352, ptr %l179
  br label %bb113
bb113:
  %t353 = load i32, ptr %l179, !tbaa !23
  store i32 %t353, ptr %l9, !tbaa !23
  %t354 = load i32, ptr %l9, !tbaa !23
  %t356 = icmp slt i32 %t354, 0
  br i1 %t356, label %bb114, label %bb115
bb114:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb115:
  br label %bb116
bb116:
  %t359 = load i32, ptr %l9, !tbaa !23
  %t360 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t363 = icmp eq i32 %t359, %t360
  br i1 %t363, label %bb117, label %bb118
bb117:
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t366 = load %"compiler/source:Span", ptr %l1
  %t369 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t365, %"compiler/source:Span" %t366)
  store ptr %t369, ptr %l188
  br label %bb119
bb118:
  br label %bb120
bb119:
  %t370 = load ptr, ptr %l188, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t370, ptr %rv
  br label %ret
bb120:
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t374 = getelementptr %"compiler/check:Checker", ptr %t372, i32 0, i32 1
  %t375 = load ptr, ptr %t374, !tbaa !29
  %t376 = load i32, ptr %l9, !tbaa !23
  %t379 = call %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %t375, i32 %t376)
  store %"compiler/generic:Desc" %t379, ptr %l193
  br label %bb121
bb121:
  %t380 = load %"compiler/generic:Desc", ptr %l193
  store %"compiler/generic:Desc" %t380, ptr %l10
  %t381 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t383 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t381, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d52, i32 0, i32 1) })
  store i1 %t383, ptr %l195
  br label %bb122
bb122:
  %t384 = load i1, ptr %l195, !tbaa !21
  br i1 %t384, label %bb123, label %bb124
bb123:
  %t385 = getelementptr %"compiler/generic:Desc", ptr %l10, i32 0, i32 0
  %t386 = load i64, ptr %t385, !tbaa !24
  %t387 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescCase, !tbaa !24
  %t390 = icmp ne i64 %t386, %t387
  store i1 %t390, ptr %l196, !tbaa !21
  br label %bb125
bb124:
  store i1 false, ptr %l196, !tbaa !21
  br label %bb125
bb125:
  %t392 = load i1, ptr %l196, !tbaa !21
  br i1 %t392, label %bb126, label %bb127
bb126:
  store %olang.scope zeroinitializer, ptr %s18
  %t393 = load ptr, ptr %l0, !tbaa !29
  store ptr %t393, ptr %l200, !tbaa !29
  %t394 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t394, ptr %l201
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t396 = load %"compiler/source:Span", ptr %l1
  %t399 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %s18, ptr %t395, %"compiler/source:Span" %t396)
  store { i64, ptr } %t399, ptr %l204
  br label %bb128
bb127:
  br label %bb132
bb128:
  %t400 = load { i64, ptr }, ptr %l204, !tbaa !27
  %t401 = extractvalue { i64, ptr } %t400, 1
  %t402 = extractvalue { i64, ptr } %t400, 0
  %t403 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t402)
  call void @olang_textcopy(ptr %t403, ptr %t401, i64 %t402)
  %t404 = insertvalue { i64, ptr } undef, i64 %t402, 0
  %t405 = insertvalue { i64, ptr } %t404, ptr %t403, 1
  %t407 = extractvalue { i64, ptr } %t405, 0
  %t408 = extractvalue { i64, ptr } %t405, 1
  %t409 = mul i64 %t407, 1
  %t410 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t409)
  call void @llvm.memcpy.p0.p0.i64(ptr %t410, ptr %t408, i64 %t409, i1 false)
  %t411 = insertvalue { i64, ptr } undef, i64 %t407, 0
  %t412 = insertvalue { i64, ptr } %t411, ptr %t410, 1
  %t414 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflTypeNotValue(ptr %s18, ptr %s18, { i64, ptr } %t412)
  store %"compiler/diagmsg:Msg" %t414, ptr %l207
  br label %bb129
bb129:
  %t415 = load ptr, ptr %l200, !tbaa !29
  %t416 = load %"compiler/source:Span", ptr %l201
  %t417 = load %"compiler/diagmsg:Msg", ptr %l207
  %t418 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s18, ptr %t415, %"compiler/source:Span" %t416, %"compiler/diagmsg:Msg" %t417)
  store i64 %t418, ptr %l208
  br label %bb130
bb130:
  %t419 = load ptr, ptr %l0, !tbaa !29
  %t420 = load %"compiler/source:Span", ptr %l1
  %t423 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t419, %"compiler/source:Span" %t420)
  store ptr %t423, ptr %l211
  br label %bb131
bb131:
  %t424 = load ptr, ptr %l211, !tbaa !29
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t424, ptr %rv
  br label %ret
bb132:
  %t426 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t428 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t426, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d53, i32 0, i32 1) })
  store i1 %t428, ptr %l214
  br label %bb133
bb133:
  %t429 = load i1, ptr %l214, !tbaa !21
  br i1 %t429, label %bb134, label %bb135
bb134:
  %t430 = getelementptr %"compiler/generic:Desc", ptr %l10, i32 0, i32 0
  %t431 = load i64, ptr %t430, !tbaa !24
  %t432 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescParam, !tbaa !24
  %t435 = icmp eq i64 %t431, %t432
  store i1 %t435, ptr %l215, !tbaa !21
  br label %bb136
bb135:
  store i1 false, ptr %l215, !tbaa !21
  br label %bb136
bb136:
  %t437 = load i1, ptr %l215, !tbaa !21
  br i1 %t437, label %bb137, label %bb138
bb137:
  %t438 = load ptr, ptr %l0, !tbaa !29
  %t439 = load %"compiler/source:Span", ptr %l1
  %t440 = load %"compiler/generic:Desc", ptr %l10
  %t444 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDefault(ptr %v0, ptr %v2, ptr %t438, %"compiler/source:Span" %t439, %"compiler/generic:Desc" %t440)
  store ptr %t444, ptr %l222
  br label %bb139
bb138:
  br label %bb140
bb139:
  %t445 = load ptr, ptr %l222, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t445, ptr %rv
  br label %ret
bb140:
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t448 = load ptr, ptr %l3, !tbaa !29
  %t449 = load i32, ptr %l4, !tbaa !23
  %t453 = call %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflConst(ptr %v0, ptr %v1, ptr %v2, ptr %t447, ptr %t448, i32 %t449)
  store %"compiler/check:reflVal" %t453, ptr %l227
  br label %bb141
bb141:
  %t454 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t454, ptr %lp11
  %t455 = load %"compiler/check:reflVal", ptr %l227
  %t456 = load ptr, ptr %lp11
  store %"compiler/check:reflVal" %t455, ptr %t456
  %t457 = load ptr, ptr %lp11
  %t458 = getelementptr %"compiler/check:reflVal", ptr %t457, i32 0, i32 0
  %t459 = load i1, ptr %t458, !tbaa !21
  br i1 %t459, label %bb142, label %bb143
bb142:
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t462 = load %"compiler/source:Span", ptr %l1
  %t463 = load ptr, ptr %lp11
  %t464 = load %"compiler/check:reflVal", ptr %t463
  %t468 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflExpr(ptr %v0, ptr %v2, ptr %v2, ptr %t461, %"compiler/source:Span" %t462, %"compiler/check:reflVal" %t464)
  store ptr %t468, ptr %l232
  br label %bb144
bb143:
  br label %bb145
bb144:
  %t469 = load ptr, ptr %l232, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t469, ptr %rv
  br label %ret
bb145:
  %t471 = getelementptr %"compiler/generic:Desc", ptr %l10, i32 0, i32 0
  %t472 = load i64, ptr %t471, !tbaa !24
  store i64 %t472, ptr %l12, !tbaa !24
  %t474 = load i64, ptr %l12, !tbaa !24
  %t475 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescField, !tbaa !24
  %t478 = icmp eq i64 %t474, %t475
  br i1 %t478, label %bb146, label %bb147
bb146:
  br label %bb148
bb147:
  br label %bb149
bb148:
  store { i64, ptr } { i64 57, ptr getelementptr inbounds (<{ i64, [57 x i8] }>, ptr @.d54, i32 0, i32 1) }, ptr %l235, !tbaa !27
  br label %bb166
bb149:
  %t480 = load i64, ptr %l12, !tbaa !24
  %t481 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescCase, !tbaa !24
  %t484 = icmp eq i64 %t480, %t481
  br i1 %t484, label %bb150, label %bb151
bb150:
  br label %bb152
bb151:
  br label %bb153
bb152:
  store { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d55, i32 0, i32 1) }, ptr %l235, !tbaa !27
  br label %bb166
bb153:
  %t486 = load i64, ptr %l12, !tbaa !24
  %t487 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescParam, !tbaa !24
  %t490 = icmp eq i64 %t486, %t487
  br i1 %t490, label %bb154, label %bb155
bb154:
  br label %bb156
bb155:
  br label %bb157
bb156:
  store { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d56, i32 0, i32 1) }, ptr %l235, !tbaa !27
  br label %bb166
bb157:
  %t492 = load i64, ptr %l12, !tbaa !24
  %t493 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescFunc, !tbaa !24
  %t496 = icmp eq i64 %t492, %t493
  br i1 %t496, label %bb158, label %bb159
bb158:
  br label %bb160
bb159:
  br label %bb161
bb160:
  store { i64, ptr } { i64 123, ptr getelementptr inbounds (<{ i64, [123 x i8] }>, ptr @.d57, i32 0, i32 1) }, ptr %l235, !tbaa !27
  br label %bb166
bb161:
  br i1 true, label %bb162, label %bb163
bb162:
  br label %bb164
bb163:
  br label %bb165
bb164:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d58, i32 0, i32 1) }, ptr %l235, !tbaa !27
  br label %bb166
bb165:
  call void @__olang_check_failed(ptr @olang_loc_6fa12bf18c08968_7f63ef0109416d3c)
  unreachable
bb166:
  %t498 = load { i64, ptr }, ptr %l235, !tbaa !27
  store { i64, ptr } %t498, ptr %l13, !tbaa !27
  %t499 = getelementptr %"compiler/generic:Desc", ptr %l10, i32 0, i32 0
  %t500 = load i64, ptr %t499, !tbaa !24
  store i64 %t500, ptr %l14, !tbaa !24
  %t502 = load i64, ptr %l14, !tbaa !24
  %t503 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescField, !tbaa !24
  %t506 = icmp eq i64 %t502, %t503
  br i1 %t506, label %bb167, label %bb168
bb167:
  br label %bb169
bb168:
  br label %bb170
bb169:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d59, i32 0, i32 1) }, ptr %l249, !tbaa !27
  br label %bb187
bb170:
  %t508 = load i64, ptr %l14, !tbaa !24
  %t509 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescCase, !tbaa !24
  %t512 = icmp eq i64 %t508, %t509
  br i1 %t512, label %bb171, label %bb172
bb171:
  br label %bb173
bb172:
  br label %bb174
bb173:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d60, i32 0, i32 1) }, ptr %l249, !tbaa !27
  br label %bb187
bb174:
  %t514 = load i64, ptr %l14, !tbaa !24
  %t515 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescParam, !tbaa !24
  %t518 = icmp eq i64 %t514, %t515
  br i1 %t518, label %bb175, label %bb176
bb175:
  br label %bb177
bb176:
  br label %bb178
bb177:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d61, i32 0, i32 1) }, ptr %l249, !tbaa !27
  br label %bb187
bb178:
  %t520 = load i64, ptr %l14, !tbaa !24
  %t521 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescFunc, !tbaa !24
  %t524 = icmp eq i64 %t520, %t521
  br i1 %t524, label %bb179, label %bb180
bb179:
  br label %bb181
bb180:
  br label %bb182
bb181:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d62, i32 0, i32 1) }, ptr %l249, !tbaa !27
  br label %bb187
bb182:
  br i1 true, label %bb183, label %bb184
bb183:
  br label %bb185
bb184:
  br label %bb186
bb185:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d63, i32 0, i32 1) }, ptr %l249, !tbaa !27
  br label %bb187
bb186:
  call void @__olang_check_failed(ptr @olang_loc_366830190f407939_a82d5f1c611378ed)
  unreachable
bb187:
  %t526 = load { i64, ptr }, ptr %l249, !tbaa !27
  %t527 = load ptr, ptr %l0, !tbaa !29
  store ptr %t527, ptr %l262, !tbaa !29
  %t528 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t528, ptr %l263
  %t530 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t531 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t532 = load ptr, ptr @__olang_prog_scope
  %t533 = load ptr, ptr @__olang_prog_scope
  %t537 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflDescNoMember(ptr %t532, ptr %v0, ptr %t533, ptr %s0, { i64, ptr } %t526, { i64, ptr } %t530, { i64, ptr } %t531)
  store %"compiler/diagmsg:Msg" %t537, ptr %l267
  br label %bb188
bb188:
  %t538 = load ptr, ptr %l262, !tbaa !29
  %t539 = load %"compiler/source:Span", ptr %l263
  %t540 = load %"compiler/diagmsg:Msg", ptr %l267
  %t541 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t538, %"compiler/source:Span" %t539, %"compiler/diagmsg:Msg" %t540)
  store i64 %t541, ptr %l268
  br label %bb189
bb189:
  %t542 = load ptr, ptr %l0, !tbaa !29
  %t543 = load %"compiler/source:Span", ptr %l1
  %t546 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t542, %"compiler/source:Span" %t543)
  store ptr %t546, ptr %l271
  br label %bb190
bb190:
  %t547 = load ptr, ptr %l271, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t547, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCopied(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %l18 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l25 = alloca ptr
  %l31 = alloca i1
  %l32 = alloca i1
  %l36 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i1
  %l47 = alloca i1
  %l48 = alloca ptr
  %l54 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l63 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca i1
  %l74 = alloca i1
  %l75 = alloca ptr
  %l81 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i1
  %l90 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t21 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i1 %t21, ptr %l18
  br label %bb6
bb6:
  %t22 = load i1, ptr %l18, !tbaa !21
  store i1 %t22, ptr %l8, !tbaa !21
  br label %bb66
bb7:
  %t23 = load ptr, ptr %l1, !tbaa !29
  store ptr %t23, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t24 = load ptr, ptr %l19, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb8, label %bb9
bb8:
  %t27 = load ptr, ptr %l19, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 18}
  %t30 = icmp eq i64 %t28, 11
  store i1 %t30, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t31 = load i1, ptr %l20, !tbaa !21
  br i1 %t31, label %bb10, label %bb11
bb10:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr { i64, [5 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t34, i32 0, i32 2
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb21
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l25, !tbaa !29
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Cond", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = icmp eq ptr %t42, null
  br i1 %t44, label %bb13, label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_64f1128892bbfadb_2fd1650a543ec847)
  unreachable
bb14:
  br label %bb15
bb15:
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = getelementptr %"compiler/typed:Cond", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t50 = load ptr, ptr %l25, !tbaa !29
  %t52 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCopied(ptr %v0, ptr %v1, ptr %t50, ptr %t49)
  store i1 %t52, ptr %l31
  br label %bb16
bb16:
  %t53 = load i1, ptr %l31, !tbaa !21
  br i1 %t53, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb20
bb18:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Cond", ptr %t55, i32 0, i32 2
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t61 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCopied(ptr %v0, ptr %v1, ptr %t54, ptr %t58)
  store i1 %t61, ptr %l36
  br label %bb19
bb19:
  %t62 = load i1, ptr %l36, !tbaa !21
  store i1 %t62, ptr %l32, !tbaa !21
  br label %bb20
bb20:
  %t63 = load i1, ptr %l32, !tbaa !21
  store i1 %t63, ptr %l8, !tbaa !21
  br label %bb66
bb21:
  %t64 = load ptr, ptr %l1, !tbaa !29
  store ptr %t64, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t65 = load ptr, ptr %l37, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb22, label %bb23
bb22:
  %t68 = load ptr, ptr %l37, !tbaa !29
  %t69 = load i64, ptr %t68, !range !{i64 0, i64 18}
  %t71 = icmp eq i64 %t69, 12
  store i1 %t71, ptr %l38, !tbaa !21
  br label %bb23
bb23:
  %t72 = load i1, ptr %l38, !tbaa !21
  br i1 %t72, label %bb24, label %bb25
bb24:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [5 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t75, i32 0, i32 2
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l4, !tbaa !29
  br label %bb26
bb25:
  br label %bb34
bb26:
  %t79 = load ptr, ptr %l4, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Seq", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = icmp eq ptr %t82, null
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb27, label %bb28
bb27:
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l48, !tbaa !29
  %t89 = load ptr, ptr %l4, !tbaa !29
  %t91 = getelementptr %"compiler/typed:Seq", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t94 = icmp eq ptr %t92, null
  br i1 %t94, label %bb29, label %bb30
bb28:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb33
bb29:
  call void @__olang_check_failed(ptr @olang_loc_9b328daa59c12fec_530ed6f7b483a728)
  unreachable
bb30:
  br label %bb31
bb31:
  %t96 = load ptr, ptr %l4, !tbaa !29
  %t98 = getelementptr %"compiler/typed:Seq", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t100 = load ptr, ptr %l48, !tbaa !29
  %t102 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCopied(ptr %v0, ptr %v1, ptr %t100, ptr %t99)
  store i1 %t102, ptr %l54
  br label %bb32
bb32:
  %t103 = load i1, ptr %l54, !tbaa !21
  store i1 %t103, ptr %l47, !tbaa !21
  br label %bb33
bb33:
  %t104 = load i1, ptr %l47, !tbaa !21
  store i1 %t104, ptr %l8, !tbaa !21
  br label %bb66
bb34:
  %t105 = load ptr, ptr %l1, !tbaa !29
  store ptr %t105, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t106 = load ptr, ptr %l55, !tbaa !29
  %t107 = icmp ne ptr %t106, null
  br i1 %t107, label %bb35, label %bb36
bb35:
  %t109 = load ptr, ptr %l55, !tbaa !29
  %t110 = load i64, ptr %t109, !range !{i64 0, i64 18}
  %t112 = icmp eq i64 %t110, 13
  store i1 %t112, ptr %l56, !tbaa !21
  br label %bb36
bb36:
  %t113 = load i1, ptr %l56, !tbaa !21
  br i1 %t113, label %bb37, label %bb38
bb37:
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = getelementptr { i64, [5 x i64] }, ptr %t114, i32 0, i32 1
  %t117 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t116, i32 0, i32 2
  %t118 = load ptr, ptr %t117
  store ptr %t118, ptr %l5, !tbaa !29
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load ptr, ptr %l5, !tbaa !29
  %t124 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroMatch(ptr %v0, ptr %v1, ptr %t120, ptr %t121)
  store i1 %t124, ptr %l63
  br label %bb40
bb40:
  %t125 = load i1, ptr %l63, !tbaa !21
  store i1 %t125, ptr %l8, !tbaa !21
  br label %bb66
bb41:
  %t126 = load ptr, ptr %l1, !tbaa !29
  store ptr %t126, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t127 = load ptr, ptr %l64, !tbaa !29
  %t128 = icmp ne ptr %t127, null
  br i1 %t128, label %bb42, label %bb43
bb42:
  %t130 = load ptr, ptr %l64, !tbaa !29
  %t131 = load i64, ptr %t130, !range !{i64 0, i64 18}
  %t133 = icmp eq i64 %t131, 14
  store i1 %t133, ptr %l65, !tbaa !21
  br label %bb43
bb43:
  %t134 = load i1, ptr %l65, !tbaa !21
  br i1 %t134, label %bb44, label %bb45
bb44:
  %t135 = load ptr, ptr %l1, !tbaa !29
  %t137 = getelementptr { i64, [5 x i64] }, ptr %t135, i32 0, i32 1
  %t138 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t137, i32 0, i32 2
  %t139 = load ptr, ptr %t138
  store ptr %t139, ptr %l6, !tbaa !29
  br label %bb46
bb45:
  br label %bb54
bb46:
  %t141 = load ptr, ptr %l6, !tbaa !29
  %t143 = getelementptr %"compiler/typed:Try", ptr %t141, i32 0, i32 0
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t146 = icmp eq ptr %t144, null
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb47, label %bb48
bb47:
  %t150 = load ptr, ptr %l0, !tbaa !29
  store ptr %t150, ptr %l75, !tbaa !29
  %t151 = load ptr, ptr %l6, !tbaa !29
  %t153 = getelementptr %"compiler/typed:Try", ptr %t151, i32 0, i32 0
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t156 = icmp eq ptr %t154, null
  br i1 %t156, label %bb49, label %bb50
bb48:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb53
bb49:
  call void @__olang_check_failed(ptr @olang_loc_aa71917389f82fa1_ab8db462134cc7fd)
  unreachable
bb50:
  br label %bb51
bb51:
  %t158 = load ptr, ptr %l6, !tbaa !29
  %t160 = getelementptr %"compiler/typed:Try", ptr %t158, i32 0, i32 0
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t162 = load ptr, ptr %l75, !tbaa !29
  %t164 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCopied(ptr %v0, ptr %v1, ptr %t162, ptr %t161)
  store i1 %t164, ptr %l81
  br label %bb52
bb52:
  %t165 = load i1, ptr %l81, !tbaa !21
  store i1 %t165, ptr %l74, !tbaa !21
  br label %bb53
bb53:
  %t166 = load i1, ptr %l74, !tbaa !21
  store i1 %t166, ptr %l8, !tbaa !21
  br label %bb66
bb54:
  %t167 = load ptr, ptr %l1, !tbaa !29
  store ptr %t167, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t168 = load ptr, ptr %l82, !tbaa !29
  %t169 = icmp ne ptr %t168, null
  br i1 %t169, label %bb55, label %bb56
bb55:
  %t171 = load ptr, ptr %l82, !tbaa !29
  %t172 = load i64, ptr %t171, !range !{i64 0, i64 18}
  %t174 = icmp eq i64 %t172, 6
  store i1 %t174, ptr %l83, !tbaa !21
  br label %bb56
bb56:
  %t175 = load i1, ptr %l83, !tbaa !21
  br i1 %t175, label %bb57, label %bb58
bb57:
  %t176 = load ptr, ptr %l1, !tbaa !29
  %t178 = getelementptr { i64, [5 x i64] }, ptr %t176, i32 0, i32 1
  %t179 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t178, i32 0, i32 2
  %t180 = load ptr, ptr %t179
  store ptr %t180, ptr %l7, !tbaa !29
  br label %bb59
bb58:
  br label %bb61
bb59:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load ptr, ptr %l7, !tbaa !29
  %t186 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCallCopy(ptr %v0, ptr %v1, ptr %t182, ptr %t183)
  store i1 %t186, ptr %l90
  br label %bb60
bb60:
  %t187 = load i1, ptr %l90, !tbaa !21
  store i1 %t187, ptr %l8, !tbaa !21
  br label %bb66
bb61:
  br i1 true, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb65
bb64:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_45c1f7cb36e76579_9732da1c199d4515)
  unreachable
bb66:
  %t188 = load i1, ptr %l8, !tbaa !21
  store i1 %t188, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeep(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l4 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l5 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l5
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l4
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepIn(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %a0, i64 %a1, ptr %a2, ptr %a3, ptr %l4, i64 0)
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleIdle(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca %"compiler/check:idleCall"
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca %"compiler/check:idleCall"
  %l27 = alloca i1
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l36 = alloca i64
  %l38 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l39 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l40 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l42 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l43 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l47 = alloca i64
  %l49 = alloca i64
  %l54 = alloca %"compiler/check:idleCall"
  %l55 = alloca ptr
  %l57 = alloca i64
  %l60 = alloca ptr
  %l64 = alloca i1
  %l67 = alloca i64
  %l69 = alloca i64
  %l74 = alloca i64
  %l79 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca i64
  %l84 = alloca i64
  %l92 = alloca ptr
  %l94 = alloca i64
  %l95 = alloca i64
  %l97 = alloca i64
  %l102 = alloca i64
  %l105 = alloca i1
  %l106 = alloca i64
  %l109 = alloca i64
  %l111 = alloca i1
  %l115 = alloca ptr
  %l123 = alloca ptr
  %l127 = alloca ptr
  %l130 = alloca i1
  %l135 = alloca i64
  %l137 = alloca i64
  %l142 = alloca i64
  %l143 = alloca ptr
  %l146 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l149 = alloca i1
  %l151 = alloca ptr
  %l152 = alloca i64
  %l154 = alloca i64
  %l165 = alloca i64
  %l167 = alloca i64
  %l172 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l175 = alloca i1
  %l176 = alloca ptr
  %l177 = alloca i64
  %l180 = alloca i64
  %l181 = alloca i32
  %l182 = alloca i1
  %l189 = alloca i64
  %l191 = alloca i64
  %l197 = alloca %"compiler/check:idleCall"
  %l200 = alloca i1
  %l201 = alloca i1
  %l204 = alloca i1
  %l205 = alloca i64
  %l208 = alloca i64
  %l212 = alloca i64
  %l216 = alloca i64
  %l220 = alloca i64
  %l223 = alloca i64
  %l241 = alloca ptr
  %l242 = alloca i64
  %l243 = alloca ptr
  %l246 = alloca i64
  %l247 = alloca i64
  %l248 = alloca i32
  %l249 = alloca i1
  %l257 = alloca ptr
  %l263 = alloca { i64, [3 x i64] }
  %l265 = alloca %"compiler/diagmsg:Msg"
  %l266 = alloca i64
  %s0 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %t432 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 104
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aidleCall_3e_2eLen_3ccompiler_2fcheck_3aidleCall_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l36
  br label %bb1
bb1:
  %t6 = load i64, ptr %l36, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t9, ptr %l38
  br label %bb5
bb5:
  %t10 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l38
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t10, ptr %l1
  %t11 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l39
  br label %bb6
bb6:
  %t12 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l39
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %l2
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l40
  br label %bb7
bb7:
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l40
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l3
  %t15 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l41
  br label %bb8
bb8:
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l41
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %l4
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l42
  br label %bb9
bb9:
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l42
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l5
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l43
  br label %bb10
bb10:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %l6
  %t21 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l44
  br label %bb11
bb11:
  %t22 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l44
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l7
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 104
  store ptr %t25, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb12
bb12:
  %t27 = load i64, ptr %l9, !tbaa !24
  store i64 %t27, ptr %l47, !tbaa !24
  %t28 = load ptr, ptr %l8, !tbaa !29
  %t30 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aidleCall_3e_2eLen_3ccompiler_2fcheck_3aidleCall_3e(ptr %v0, ptr %t28)
  store i64 %t30, ptr %l49
  br label %bb13
bb13:
  %t31 = load i64, ptr %l47, !tbaa !24
  %t32 = load i64, ptr %l49, !tbaa !24
  %t33 = icmp slt i64 %t31, %t32
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb14, label %bb15
bb14:
  br label %bb41
bb15:
  br label %bb16
bb16:
  %t37 = load ptr, ptr %l8, !tbaa !29
  %t38 = load i64, ptr %l9, !tbaa !24
  %t41 = call %"compiler/check:idleCall" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aidleCall_3e_2eAt_3ccompiler_2fcheck_3aidleCall_3e(ptr %v0, ptr %v0, ptr %t37, i64 %t38)
  store %"compiler/check:idleCall" %t41, ptr %l54
  br label %bb17
bb17:
  %t42 = load %"compiler/check:idleCall", ptr %l54
  store %"compiler/check:idleCall" %t42, ptr %l10
  store ptr %l6, ptr %l55, !tbaa !29
  %t44 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l7)
  store i64 %t44, ptr %l57
  br label %bb18
bb18:
  %t45 = load ptr, ptr %l55, !tbaa !29
  %t46 = load i64, ptr %l57, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t45, i64 %t46)
  br label %bb19
bb19:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 105
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t49)
  br label %bb20
bb20:
  store ptr %l5, ptr %l60, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:idleCall", ptr %l10, i32 0, i32 4
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t57 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v0, ptr %t51, ptr %t53)
  store i1 %t57, ptr %l64
  br label %bb21
bb21:
  %t58 = load ptr, ptr %l60, !tbaa !29
  %t59 = load i1, ptr %l64, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %s0, ptr %t58, i1 %t59)
  br label %bb22
bb22:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Checker", ptr %t60, i32 0, i32 105
  store ptr %t62, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb23
bb23:
  %t64 = load i64, ptr %l12, !tbaa !24
  store i64 %t64, ptr %l67, !tbaa !24
  %t65 = load ptr, ptr %l11, !tbaa !29
  %t67 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t65)
  store i64 %t67, ptr %l69
  br label %bb24
bb24:
  %t68 = load i64, ptr %l67, !tbaa !24
  %t69 = load i64, ptr %l69, !tbaa !24
  %t70 = icmp slt i64 %t68, %t69
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb25, label %bb26
bb25:
  br label %bb39
bb26:
  br label %bb27
bb27:
  %t74 = load ptr, ptr %l11, !tbaa !29
  %t75 = load i64, ptr %l12, !tbaa !24
  %t78 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t74, i64 %t75)
  store i64 %t78, ptr %l74
  br label %bb28
bb28:
  %t79 = load i64, ptr %l74, !tbaa !24
  store i64 %t79, ptr %l13, !tbaa !24
  %t80 = load i64, ptr %l13, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l7, i64 %t80)
  br label %bb29
bb29:
  %t83 = load i64, ptr %l13, !tbaa !24
  %t86 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %s0, ptr %l1, i64 %t83)
  store i1 %t86, ptr %l79
  br label %bb30
bb30:
  %t87 = load i1, ptr %l79, !tbaa !21
  %t88 = xor i1 %t87, true
  br i1 %t88, label %bb31, label %bb32
bb31:
  store ptr %l1, ptr %l81, !tbaa !29
  %t90 = load i64, ptr %l13, !tbaa !24
  store i64 %t90, ptr %l82, !tbaa !24
  %t92 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l2)
  store i64 %t92, ptr %l84
  br label %bb33
bb32:
  br label %bb37
bb33:
  %t93 = load ptr, ptr %l81, !tbaa !29
  %t94 = load i64, ptr %l82, !tbaa !24
  %t95 = load i64, ptr %l84, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %s0, ptr %t93, i64 %t94, i64 %t95)
  br label %bb34
bb34:
  %t96 = load i64, ptr %l13, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l2, i64 %t96)
  br label %bb35
bb35:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %s0, ptr %l3, i1 false)
  br label %bb36
bb36:
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t100 = load i64, ptr %l12, !tbaa !24
  %t102 = add i64 %t100, 1
  store i64 %t102, ptr %l12, !tbaa !24
  br label %bb23
bb39:
  br label %bb40
bb40:
  %t104 = load i64, ptr %l9, !tbaa !24
  %t106 = add i64 %t104, 1
  store i64 %t106, ptr %l9, !tbaa !24
  br label %bb12
bb41:
  store ptr %l6, ptr %l92, !tbaa !29
  %t109 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l7)
  store i64 %t109, ptr %l94
  br label %bb42
bb42:
  %t110 = load ptr, ptr %l92, !tbaa !29
  %t111 = load i64, ptr %l94, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t110, i64 %t111)
  br label %bb43
bb43:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb44
bb44:
  %t112 = load i64, ptr %l14, !tbaa !24
  store i64 %t112, ptr %l95, !tbaa !24
  %t114 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l2)
  store i64 %t114, ptr %l97
  br label %bb45
bb45:
  %t115 = load i64, ptr %l95, !tbaa !24
  %t116 = load i64, ptr %l97, !tbaa !24
  %t117 = icmp slt i64 %t115, %t116
  %t119 = xor i1 %t117, true
  br i1 %t119, label %bb46, label %bb47
bb46:
  br label %bb88
bb47:
  br label %bb48
bb48:
  %t121 = load i64, ptr %l14, !tbaa !24
  %t124 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l2, i64 %t121)
  store i64 %t124, ptr %l102
  br label %bb49
bb49:
  %t125 = load i64, ptr %l102, !tbaa !24
  store i64 %t125, ptr %l15, !tbaa !24
  %t126 = load i64, ptr %l15, !tbaa !24
  %t128 = icmp slt i64 %t126, 0
  br i1 %t128, label %bb50, label %bb51
bb50:
  store i1 true, ptr %l105, !tbaa !21
  br label %bb53
bb51:
  %t130 = load i64, ptr %l15, !tbaa !24
  store i64 %t130, ptr %l106, !tbaa !24
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/check:Checker", ptr %t131, i32 0, i32 14
  %t135 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t133)
  store i64 %t135, ptr %l109
  br label %bb52
bb52:
  %t136 = load i64, ptr %l106, !tbaa !24
  %t137 = load i64, ptr %l109, !tbaa !24
  %t138 = icmp sge i64 %t136, %t137
  store i1 %t138, ptr %l105, !tbaa !21
  br label %bb53
bb53:
  %t140 = load i1, ptr %l105, !tbaa !21
  br i1 %t140, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l111, !tbaa !21
  br label %bb57
bb55:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/check:Checker", ptr %t141, i32 0, i32 14
  %t144 = load i64, ptr %l15, !tbaa !24
  %t147 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t143, i64 %t144)
  store ptr %t147, ptr %l115
  br label %bb56
bb56:
  %t148 = load ptr, ptr %l115, !tbaa !29
  %t150 = getelementptr %"compiler/typed:Body", ptr %t148, i32 0, i32 11
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = icmp eq ptr %t151, null
  store i1 %t153, ptr %l111, !tbaa !21
  br label %bb57
bb57:
  %t155 = load i1, ptr %l111, !tbaa !21
  br i1 %t155, label %bb58, label %bb59
bb58:
  %t156 = load i64, ptr %l14, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %s0, ptr %l3, i64 %t156, i1 true)
  br label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb87
bb61:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/check:Checker", ptr %t159, i32 0, i32 105
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t161)
  br label %bb62
bb62:
  %t163 = load ptr, ptr %l0, !tbaa !29
  store ptr %t163, ptr %l123, !tbaa !29
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/check:Checker", ptr %t164, i32 0, i32 14
  %t167 = load i64, ptr %l15, !tbaa !24
  %t170 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t166, i64 %t167)
  store ptr %t170, ptr %l127
  br label %bb63
bb63:
  %t171 = load ptr, ptr %l127, !tbaa !29
  %t173 = getelementptr %"compiler/typed:Body", ptr %t171, i32 0, i32 11
  %t174 = load ptr, ptr %t173, !tbaa !29
  %t175 = load ptr, ptr %l123, !tbaa !29
  %t177 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffB(ptr %v0, ptr %v0, ptr %t175, ptr %t174)
  store i1 %t177, ptr %l130
  br label %bb64
bb64:
  %t178 = load i1, ptr %l130, !tbaa !21
  br i1 %t178, label %bb65, label %bb66
bb65:
  %t179 = load i64, ptr %l14, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %s0, ptr %l3, i64 %t179, i1 true)
  br label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb87
bb68:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/check:Checker", ptr %t182, i32 0, i32 105
  store ptr %t184, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb69
bb69:
  store %olang.scope zeroinitializer, ptr %s14
  %t186 = load i64, ptr %l17, !tbaa !24
  store i64 %t186, ptr %l135, !tbaa !24
  %t187 = load ptr, ptr %l16, !tbaa !29
  %t189 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t187)
  store i64 %t189, ptr %l137
  br label %bb70
bb70:
  %t190 = load i64, ptr %l135, !tbaa !24
  %t191 = load i64, ptr %l137, !tbaa !24
  %t192 = icmp slt i64 %t190, %t191
  %t194 = xor i1 %t192, true
  br i1 %t194, label %bb71, label %bb72
bb71:
  call void @__olang_scope_close(ptr %s14)
  br label %bb86
bb72:
  br label %bb73
bb73:
  %t196 = load ptr, ptr %l16, !tbaa !29
  %t197 = load i64, ptr %l17, !tbaa !24
  %t200 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t196, i64 %t197)
  store i64 %t200, ptr %l142
  br label %bb74
bb74:
  %t201 = load i64, ptr %l142, !tbaa !24
  store i64 %t201, ptr %l18, !tbaa !24
  store ptr %l4, ptr %l143, !tbaa !29
  %t202 = load i64, ptr %l14, !tbaa !24
  %t203 = load i64, ptr %l18, !tbaa !24
  %t206 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s14, i64 %t202, i64 %t203)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t206, ptr %l146
  br label %bb75
bb75:
  %t207 = load ptr, ptr %l143, !tbaa !29
  %t208 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l146
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H2474e1fc3c93452d7765e4ed18f29a03(ptr %s0, ptr %t207, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t208)
  br label %bb76
bb76:
  %t209 = load i64, ptr %l18, !tbaa !24
  %t212 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %s0, ptr %l1, i64 %t209)
  store i1 %t212, ptr %l149
  br label %bb77
bb77:
  %t213 = load i1, ptr %l149, !tbaa !21
  %t214 = xor i1 %t213, true
  br i1 %t214, label %bb78, label %bb79
bb78:
  store ptr %l1, ptr %l151, !tbaa !29
  %t216 = load i64, ptr %l18, !tbaa !24
  store i64 %t216, ptr %l152, !tbaa !24
  %t218 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l2)
  store i64 %t218, ptr %l154
  br label %bb80
bb79:
  br label %bb84
bb80:
  %t219 = load ptr, ptr %l151, !tbaa !29
  %t220 = load i64, ptr %l152, !tbaa !24
  %t221 = load i64, ptr %l154, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %s0, ptr %t219, i64 %t220, i64 %t221)
  br label %bb81
bb81:
  %t222 = load i64, ptr %l18, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l2, i64 %t222)
  br label %bb82
bb82:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %s0, ptr %l3, i1 false)
  br label %bb83
bb83:
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s14)
  br label %bb85
bb85:
  %t226 = load i64, ptr %l17, !tbaa !24
  %t228 = add i64 %t226, 1
  store i64 %t228, ptr %l17, !tbaa !24
  br label %bb69
bb86:
  br label %bb87
bb87:
  %t230 = load i64, ptr %l14, !tbaa !24
  %t232 = add i64 %t230, 1
  store i64 %t232, ptr %l14, !tbaa !24
  br label %bb44
bb88:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb89
bb89:
  %t234 = load i1, ptr %l19, !tbaa !21
  %t236 = xor i1 %t234, true
  br i1 %t236, label %bb90, label %bb91
bb90:
  br label %bb115
bb91:
  br label %bb92
bb92:
  store i1 false, ptr %l19, !tbaa !21
  store ptr %l4, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb93
bb93:
  %t239 = load i64, ptr %l21, !tbaa !24
  store i64 %t239, ptr %l165, !tbaa !24
  %t240 = load ptr, ptr %l20, !tbaa !29
  %t242 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_Hda4ef06466535e66801340e999dad217(ptr %s0, ptr %t240)
  store i64 %t242, ptr %l167
  br label %bb94
bb94:
  %t243 = load i64, ptr %l165, !tbaa !24
  %t244 = load i64, ptr %l167, !tbaa !24
  %t245 = icmp slt i64 %t243, %t244
  %t247 = xor i1 %t245, true
  br i1 %t247, label %bb95, label %bb96
bb95:
  br label %bb113
bb96:
  br label %bb97
bb97:
  %t249 = load ptr, ptr %l20, !tbaa !29
  %t250 = load i64, ptr %l21, !tbaa !24
  %t253 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H87a29777ccf22aa2985fa9d3c61f9cd3(ptr %s0, ptr %t249, i64 %t250)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t253, ptr %l172
  br label %bb98
bb98:
  %t254 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l172
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t254, ptr %l22
  %t255 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l22, i32 0, i32 0
  %t256 = load i64, ptr %t255, !tbaa !24
  %t259 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %s0, ptr %l3, i64 %t256)
  store i1 %t259, ptr %l175
  br label %bb99
bb99:
  %t260 = load i1, ptr %l175, !tbaa !21
  br i1 %t260, label %bb100, label %bb101
bb100:
  br label %bb112
bb101:
  br label %bb102
bb102:
  store ptr %l3, ptr %l176, !tbaa !29
  %t261 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l22, i32 0, i32 1
  %t262 = load i64, ptr %t261, !tbaa !24
  %t265 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %s0, ptr %l1, i64 %t262)
  %t266 = extractvalue { i32, i64 } %t265, 1
  %t267 = extractvalue { i32, i64 } %t265, 0
  store i32 %t267, ptr %l181
  %t268 = icmp ne i32 %t267, 0
  br i1 %t268, label %bb104, label %ok.269, !prof !99
ok.269:
  store i64 %t266, ptr %l180
  br label %bb103
bb103:
  %t270 = load i64, ptr %l180, !tbaa !24
  store i64 %t270, ptr %l177, !tbaa !24
  br label %bb106
bb104:
  br label %bb105
bb105:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l177, !tbaa !24
  br label %bb106
bb106:
  %t271 = load ptr, ptr %l176, !tbaa !29
  %t272 = load i64, ptr %l177, !tbaa !24
  %t273 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %s0, ptr %t271, i64 %t272)
  store i1 %t273, ptr %l182
  br label %bb107
bb107:
  %t274 = load i1, ptr %l182, !tbaa !21
  br i1 %t274, label %bb108, label %bb109
bb108:
  %t275 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l22, i32 0, i32 0
  %t276 = load i64, ptr %t275, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %s0, ptr %l3, i64 %t276, i1 true)
  br label %bb110
bb109:
  br label %bb111
bb110:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb111
bb111:
  br label %bb112
bb112:
  %t279 = load i64, ptr %l21, !tbaa !24
  %t281 = add i64 %t279, 1
  store i64 %t281, ptr %l21, !tbaa !24
  br label %bb93
bb113:
  br label %bb114
bb114:
  br label %bb89
bb115:
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t285 = getelementptr %"compiler/check:Checker", ptr %t283, i32 0, i32 104
  store ptr %t285, ptr %l23, !tbaa !29
  store i64 0, ptr %l24, !tbaa !24
  br label %bb116
bb116:
  store %olang.scope zeroinitializer, ptr %s25
  %t287 = load i64, ptr %l24, !tbaa !24
  store i64 %t287, ptr %l189, !tbaa !24
  %t288 = load ptr, ptr %l23, !tbaa !29
  %t290 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aidleCall_3e_2eLen_3ccompiler_2fcheck_3aidleCall_3e(ptr %v0, ptr %t288)
  store i64 %t290, ptr %l191
  br label %bb117
bb117:
  %t291 = load i64, ptr %l189, !tbaa !24
  %t292 = load i64, ptr %l191, !tbaa !24
  %t293 = icmp slt i64 %t291, %t292
  %t295 = xor i1 %t293, true
  br i1 %t295, label %bb118, label %bb119
bb118:
  call void @__olang_scope_close(ptr %s25)
  br label %bb162
bb119:
  br label %bb120
bb120:
  %t297 = load i64, ptr %l24, !tbaa !24
  store i64 %t297, ptr %l25, !tbaa !24
  %t299 = load ptr, ptr %l23, !tbaa !29
  %t300 = load i64, ptr %l24, !tbaa !24
  %t303 = call %"compiler/check:idleCall" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aidleCall_3e_2eAt_3ccompiler_2fcheck_3aidleCall_3e(ptr %v0, ptr %v0, ptr %t299, i64 %t300)
  store %"compiler/check:idleCall" %t303, ptr %l197
  br label %bb121
bb121:
  %t304 = load %"compiler/check:idleCall", ptr %l197
  store %"compiler/check:idleCall" %t304, ptr %l26
  %t305 = load i64, ptr %l25, !tbaa !24
  %t308 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %s0, ptr %l5, i64 %t305)
  store i1 %t308, ptr %l200
  br label %bb122
bb122:
  %t309 = load i1, ptr %l200, !tbaa !21
  br i1 %t309, label %bb123, label %bb124
bb123:
  store i1 true, ptr %l201, !tbaa !21
  br label %bb125
bb124:
  %t310 = getelementptr %"compiler/check:idleCall", ptr %l26, i32 0, i32 0
  %t311 = load i64, ptr %t310, !tbaa !24
  %t313 = icmp slt i64 %t311, 0
  store i1 %t313, ptr %l201, !tbaa !21
  br label %bb125
bb125:
  %t315 = load i1, ptr %l201, !tbaa !21
  br i1 %t315, label %bb126, label %bb127
bb126:
  store i1 true, ptr %l204, !tbaa !21
  br label %bb129
bb127:
  %t316 = getelementptr %"compiler/check:idleCall", ptr %l26, i32 0, i32 0
  %t317 = load i64, ptr %t316, !tbaa !24
  store i64 %t317, ptr %l205, !tbaa !24
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t320 = getelementptr %"compiler/check:Checker", ptr %t318, i32 0, i32 14
  %t322 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t320)
  store i64 %t322, ptr %l208
  br label %bb128
bb128:
  %t323 = load i64, ptr %l205, !tbaa !24
  %t324 = load i64, ptr %l208, !tbaa !24
  %t325 = icmp sge i64 %t323, %t324
  store i1 %t325, ptr %l204, !tbaa !21
  br label %bb129
bb129:
  %t327 = load i1, ptr %l204, !tbaa !21
  br i1 %t327, label %bb130, label %bb131
bb130:
  call void @__olang_scope_close(ptr %s25)
  br label %bb161
bb131:
  br label %bb132
bb132:
  store i1 true, ptr %l27, !tbaa !21
  %t328 = load i64, ptr %l25, !tbaa !24
  %t331 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l6, i64 %t328)
  store i64 %t331, ptr %l212
  br label %bb133
bb133:
  %t332 = load i64, ptr %l212, !tbaa !24
  store i64 %t332, ptr %l28, !tbaa !24
  %t333 = load i64, ptr %l25, !tbaa !24
  %t335 = add i64 %t333, 1
  %t338 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l6, i64 %t335)
  store i64 %t338, ptr %l216
  br label %bb134
bb134:
  %t339 = load i64, ptr %l216, !tbaa !24
  store i64 %t339, ptr %l29, !tbaa !24
  store i64 1, ptr %l30, !tbaa !24
  %t340 = load i64, ptr %l29, !tbaa !24
  %t341 = load i64, ptr %l28, !tbaa !24
  %t344 = icmp sgt i64 %t340, %t341
  br i1 %t344, label %bb135, label %bb136
bb135:
  %t346 = load i64, ptr %l30, !tbaa !24
  %t348 = icmp sgt i64 %t346, 0
  br i1 %t348, label %bb137, label %bb138
bb136:
  store i64 0, ptr %l220, !tbaa !24
  br label %bb140
bb137:
  %t350 = load i64, ptr %l29, !tbaa !24
  %t351 = load i64, ptr %l28, !tbaa !24
  %t354 = sub i64 %t350, %t351
  %t355 = load i64, ptr %l30, !tbaa !24
  %t358 = add i64 %t354, %t355
  %t360 = sub i64 %t358, 1
  %t361 = load i64, ptr %l30, !tbaa !24
  %t364 = sdiv i64 %t360, %t361
  store i64 %t364, ptr %l223, !tbaa !24
  br label %bb139
bb138:
  store i64 0, ptr %l223, !tbaa !24
  br label %bb139
bb139:
  %t366 = load i64, ptr %l223, !tbaa !24
  store i64 %t366, ptr %l220, !tbaa !24
  br label %bb140
bb140:
  %t367 = load i64, ptr %l220, !tbaa !24
  store i64 %t367, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  br label %bb141
bb141:
  %t368 = load i64, ptr %l32, !tbaa !24
  %t369 = load i64, ptr %l31, !tbaa !24
  %t372 = icmp slt i64 %t368, %t369
  %t374 = xor i1 %t372, true
  br i1 %t374, label %bb142, label %bb143
bb142:
  br label %bb155
bb143:
  br label %bb144
bb144:
  %t376 = load i64, ptr %l28, !tbaa !24
  %t377 = load i64, ptr %l32, !tbaa !24
  %t378 = load i64, ptr %l30, !tbaa !24
  %t381 = mul i64 %t377, %t378
  %t384 = add i64 %t376, %t381
  store ptr %l3, ptr %l241, !tbaa !29
  store ptr %l1, ptr %l243, !tbaa !29
  %t389 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l7, i64 %t384)
  store i64 %t389, ptr %l246
  br label %bb145
bb145:
  %t390 = load ptr, ptr %l243, !tbaa !29
  %t391 = load i64, ptr %l246, !tbaa !24
  %t392 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %s0, ptr %t390, i64 %t391)
  %t393 = extractvalue { i32, i64 } %t392, 1
  %t394 = extractvalue { i32, i64 } %t392, 0
  store i32 %t394, ptr %l248
  %t395 = icmp ne i32 %t394, 0
  br i1 %t395, label %bb147, label %ok.396, !prof !99
ok.396:
  store i64 %t393, ptr %l247
  br label %bb146
bb146:
  %t397 = load i64, ptr %l247, !tbaa !24
  store i64 %t397, ptr %l242, !tbaa !24
  br label %bb149
bb147:
  br label %bb148
bb148:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l242, !tbaa !24
  br label %bb149
bb149:
  %t398 = load ptr, ptr %l241, !tbaa !29
  %t399 = load i64, ptr %l242, !tbaa !24
  %t400 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %s0, ptr %t398, i64 %t399)
  store i1 %t400, ptr %l249
  br label %bb150
bb150:
  %t401 = load i1, ptr %l249, !tbaa !21
  br i1 %t401, label %bb151, label %bb152
bb151:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb153
bb152:
  br label %bb153
bb153:
  br label %bb154
bb154:
  %t402 = load i64, ptr %l32, !tbaa !24
  %t404 = add i64 %t402, 1
  store i64 %t404, ptr %l32, !tbaa !24
  br label %bb141
bb155:
  %t406 = load i1, ptr %l27, !tbaa !21
  %t408 = xor i1 %t406, true
  br i1 %t408, label %bb156, label %bb157
bb156:
  call void @__olang_scope_close(ptr %s25)
  br label %bb161
bb157:
  br label %bb158
bb158:
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t412 = getelementptr %"compiler/check:Checker", ptr %t410, i32 0, i32 1
  %t413 = load ptr, ptr %t412, !tbaa !29
  %t415 = getelementptr %"compiler/generic:Program", ptr %t413, i32 0, i32 0
  %t416 = load ptr, ptr %t415, !tbaa !29
  %t418 = getelementptr %"compiler/load:Loader", ptr %t416, i32 0, i32 4
  %t419 = load ptr, ptr %t418, !tbaa !29
  store ptr %t419, ptr %l257, !tbaa !29
  %t420 = getelementptr %"compiler/check:idleCall", ptr %l26, i32 0, i32 1
  %t421 = load i64, ptr %t420, !tbaa !24
  %t422 = getelementptr %"compiler/check:idleCall", ptr %l26, i32 0, i32 2
  %t423 = getelementptr %"compiler/source:Span", ptr %t422, i32 0, i32 0
  %t424 = load i32, ptr %t423, !tbaa !23
  %t426 = sext i32 %t424 to i64
  %t427 = getelementptr %"compiler/check:idleCall", ptr %l26, i32 0, i32 2
  %t428 = getelementptr %"compiler/source:Span", ptr %t427, i32 0, i32 1
  %t429 = load i32, ptr %t428, !tbaa !23
  %t431 = sext i32 %t429 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t432
  %t433 = getelementptr { i64, [3 x i64] }, ptr %t432, i32 0, i32 0
  store i64 3, ptr %t433
  %t435 = insertvalue { i64, i64, i64 } undef, i64 %t421, 0
  %t437 = insertvalue { i64, i64, i64 } %t435, i64 %t426, 1
  %t439 = insertvalue { i64, i64, i64 } %t437, i64 %t431, 2
  %t440 = getelementptr { i64, [3 x i64] }, ptr %t432, i32 0, i32 1
  store { i64, i64, i64 } %t439, ptr %t440
  %t441 = load { i64, [3 x i64] }, ptr %t432
  store { i64, [3 x i64] } %t441, ptr %l263
  %t442 = getelementptr %"compiler/check:idleCall", ptr %l26, i32 0, i32 3
  %t443 = load { i64, ptr }, ptr %t442, !tbaa !27
  %t445 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCallDoesNothing(ptr %v0, ptr %s25, { i64, ptr } %t443)
  store %"compiler/diagmsg:Msg" %t445, ptr %l265
  br label %bb159
bb159:
  %t446 = load ptr, ptr %l257, !tbaa !29
  %t447 = load { i64, [3 x i64] }, ptr %l263
  %t448 = load %"compiler/diagmsg:Msg", ptr %l265
  %t449 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s25, ptr %t446, { i64, [3 x i64] } %t447, %"compiler/diagmsg:Msg" %t448)
  store i64 %t449, ptr %l266
  br label %bb160
bb160:
  call void @__olang_scope_close(ptr %s25)
  br label %bb161
bb161:
  %t450 = load i64, ptr %l24, !tbaa !24
  %t452 = add i64 %t450, 1
  store i64 %t452, ptr %l24, !tbaa !24
  br label %bb116
bb162:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esliceOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, ptr %a4, i32 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l27 = alloca i1
  %l30 = alloca ptr
  %l33 = alloca i32
  %l36 = alloca i1
  %l37 = alloca i64
  %l43 = alloca i64
  %l46 = alloca i64
  %l66 = alloca i1
  %l74 = alloca i64
  %l77 = alloca %"compiler/source:Span"
  %l82 = alloca i32
  %l86 = alloca ptr
  %l93 = alloca i32
  %l98 = alloca i32
  %l107 = alloca ptr
  %l110 = alloca i1
  %l112 = alloca ptr
  %l113 = alloca %"compiler/source:Span"
  %l116 = alloca { i64, ptr }
  %l118 = alloca %"compiler/diagmsg:Msg"
  %l119 = alloca i64
  %l122 = alloca ptr
  %l125 = alloca i64
  %l131 = alloca i1
  %l133 = alloca ptr
  %l134 = alloca %"compiler/source:Span"
  %l135 = alloca i32
  %l138 = alloca { i64, ptr }
  %l140 = alloca %"compiler/diagmsg:Msg"
  %l141 = alloca i64
  %l144 = alloca ptr
  %l147 = alloca i64
  %l150 = alloca i1
  %l157 = alloca ptr
  %l160 = alloca ptr
  %l161 = alloca ptr
  %l162 = alloca %"compiler/source:Span"
  %l164 = alloca i32
  %l165 = alloca ptr
  %l166 = alloca ptr
  %l167 = alloca ptr
  %l168 = alloca ptr
  %l170 = alloca i32
  %l171 = alloca ptr
  %l173 = alloca %"compiler/source:Span"
  %l174 = alloca ptr
  %l177 = alloca ptr
  %l178 = alloca %"compiler/source:Span"
  %l179 = alloca %"compiler/source:Span"
  %l180 = alloca i64
  %l184 = alloca ptr
  %l185 = alloca ptr
  %l188 = alloca { i64, ptr }
  %l191 = alloca { i64, ptr }
  %l195 = alloca ptr
  %l197 = alloca ptr
  %l198 = alloca ptr
  %l199 = alloca ptr
  %l201 = alloca i32
  %l202 = alloca ptr
  %l204 = alloca %"compiler/source:Span"
  %l205 = alloca ptr
  %l209 = alloca i64
  %l214 = alloca ptr
  %l218 = alloca ptr
  %l219 = alloca %"compiler/source:Span"
  %l220 = alloca %"compiler/source:Span"
  %l221 = alloca i64
  %l225 = alloca ptr
  %l226 = alloca ptr
  %l229 = alloca { i64, ptr }
  %l233 = alloca { i64, ptr }
  %l237 = alloca ptr
  %l240 = alloca ptr
  %l241 = alloca %"compiler/source:Span"
  %l243 = alloca i32
  %l244 = alloca ptr
  %l246 = alloca ptr
  %l247 = alloca ptr
  %l249 = alloca i32
  %l250 = alloca ptr
  %l254 = alloca ptr
  %l255 = alloca %"compiler/source:Span"
  %l257 = alloca i32
  %l258 = alloca i32
  %l259 = alloca %"compiler/source:Span"
  %l265 = alloca i32
  %l269 = alloca ptr
  %l271 = alloca ptr
  %l272 = alloca ptr
  %l274 = alloca i32
  %l275 = alloca ptr
  %l279 = alloca i1
  %l280 = alloca i32
  %l284 = alloca ptr
  %l289 = alloca i32
  %l292 = alloca i32
  %l297 = alloca i32
  %l298 = alloca i32
  %l299 = alloca %"compiler/source:Span"
  %l305 = alloca i32
  %l306 = alloca ptr
  %l309 = alloca ptr
  %l314 = alloca %"compiler/typed:Slice"
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca ptr
  %t123 = alloca { i64, [4 x i64] }, align 8
  %t501 = alloca { i64, [5 x i64] }, align 8
  %t604 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store i32 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = load %"compiler/source:Span", ptr %l1
  %t7 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elendsPacked(ptr %v0, ptr %v1, ptr %t1, ptr %t2, %"compiler/source:Span" %t3)
  store i1 %t7, ptr %l27
  br label %bb1
bb1:
  %t8 = load i1, ptr %l27, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l1
  %t13 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t9, %"compiler/source:Span" %t10)
  store ptr %t13, ptr %l30
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t14 = load ptr, ptr %l30, !tbaa !29
  store ptr %t14, ptr %rv
  br label %ret
bb5:
  %t15 = load ptr, ptr %l2, !tbaa !29
  store ptr %t15, ptr %l6, !tbaa !29
  %t17 = load ptr, ptr %l6, !tbaa !29
  %t19 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t17)
  store i32 %t19, ptr %l33
  br label %bb6
bb6:
  %t20 = load i32, ptr %l33, !tbaa !23
  store i32 %t20, ptr %l7, !tbaa !23
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t25 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eslicedWritable(ptr %v0, ptr %v1, ptr %t21, ptr %t22)
  store i1 %t25, ptr %l36
  br label %bb7
bb7:
  %t26 = load i1, ptr %l36, !tbaa !21
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t27 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  store i64 %t27, ptr %l37, !tbaa !24
  br label %bb10
bb9:
  %t29 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  store i64 %t29, ptr %l37, !tbaa !24
  br label %bb10
bb10:
  %t31 = load i64, ptr %l37, !tbaa !24
  store i64 %t31, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  store i64 4, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t32 = load i64, ptr %l10, !tbaa !24
  %t33 = load i64, ptr %l9, !tbaa !24
  %t36 = icmp sgt i64 %t32, %t33
  br i1 %t36, label %bb11, label %bb12
bb11:
  %t38 = load i64, ptr %l11, !tbaa !24
  %t40 = icmp sgt i64 %t38, 0
  br i1 %t40, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb16
bb13:
  %t42 = load i64, ptr %l10, !tbaa !24
  %t43 = load i64, ptr %l9, !tbaa !24
  %t46 = sub i64 %t42, %t43
  %t47 = load i64, ptr %l11, !tbaa !24
  %t50 = add i64 %t46, %t47
  %t52 = sub i64 %t50, 1
  %t53 = load i64, ptr %l11, !tbaa !24
  %t56 = sdiv i64 %t52, %t53
  store i64 %t56, ptr %l46, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb15
bb15:
  %t58 = load i64, ptr %l46, !tbaa !24
  store i64 %t58, ptr %l43, !tbaa !24
  br label %bb16
bb16:
  %t59 = load i64, ptr %l43, !tbaa !24
  store i64 %t59, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb17
bb17:
  %t60 = load i64, ptr %l13, !tbaa !24
  %t61 = load i64, ptr %l12, !tbaa !24
  %t64 = icmp slt i64 %t60, %t61
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb18, label %bb19
bb18:
  br label %bb31
bb19:
  br label %bb20
bb20:
  %t68 = load i64, ptr %l9, !tbaa !24
  %t69 = load i64, ptr %l13, !tbaa !24
  %t70 = load i64, ptr %l11, !tbaa !24
  %t73 = mul i64 %t69, %t70
  %t76 = add i64 %t68, %t73
  store i64 %t76, ptr %l14, !tbaa !24
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i32, ptr %l7, !tbaa !23
  %t82 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t78, i32 %t79)
  store i1 %t82, ptr %l66
  br label %bb21
bb21:
  %t83 = load i1, ptr %l66, !tbaa !21
  %t84 = xor i1 %t83, true
  br i1 %t84, label %bb22, label %bb23
bb22:
  br label %bb31
bb23:
  br label %bb24
bb24:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullRead(ptr %v0, ptr %v1, ptr %t86, ptr %t87)
  br label %bb25
bb25:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/check:Checker", ptr %t90, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = getelementptr %"compiler/generic:Program", ptr %t93, i32 0, i32 2
  %t96 = load i32, ptr %l7, !tbaa !23
  %t99 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t95, i32 %t96)
  store i64 %t99, ptr %l74
  br label %bb26
bb26:
  %t100 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t101 = load i64, ptr %l74, !tbaa !24
  %t103 = and i64 %t101, %t100
  store i64 %t103, ptr %l8, !tbaa !24
  %t105 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t105, ptr %l77
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/generic:Program", ptr %t109, i32 0, i32 2
  %t112 = load i32, ptr %l7, !tbaa !23
  %t115 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t111, i32 %t112)
  store i32 %t115, ptr %l82
  br label %bb27
bb27:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load %"compiler/source:Span", ptr %l1
  %t118 = load ptr, ptr %l6, !tbaa !29
  %t122 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v1, ptr %t116, %"compiler/source:Span" %t117, ptr %t118)
  store ptr %t122, ptr %l86
  br label %bb28
bb28:
  store { i64, [4 x i64] } zeroinitializer, ptr %t123
  %t124 = getelementptr { i64, [4 x i64] }, ptr %t123, i32 0, i32 0
  store i64 2, ptr %t124
  %t125 = load %"compiler/source:Span", ptr %l77
  %t126 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t125, 0
  %t127 = load i32, ptr %l82, !tbaa !23
  %t128 = insertvalue { %"compiler/source:Span", i32, ptr } %t126, i32 %t127, 1
  %t129 = load ptr, ptr %l86, !tbaa !29
  %t130 = insertvalue { %"compiler/source:Span", i32, ptr } %t128, ptr %t129, 2
  %t131 = getelementptr { i64, [4 x i64] }, ptr %t123, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t130, ptr %t131
  %t132 = load { i64, [4 x i64] }, ptr %t123
  %t134 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t132, ptr %t134
  store ptr %t134, ptr %l6, !tbaa !29
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/check:Checker", ptr %t136, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t141 = getelementptr %"compiler/generic:Program", ptr %t139, i32 0, i32 2
  %t142 = load i32, ptr %l7, !tbaa !23
  %t145 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t141, i32 %t142)
  store i32 %t145, ptr %l93
  br label %bb29
bb29:
  %t146 = load i32, ptr %l93, !tbaa !23
  store i32 %t146, ptr %l7, !tbaa !23
  br label %bb30
bb30:
  %t147 = load i64, ptr %l13, !tbaa !24
  %t149 = add i64 %t147, 1
  store i64 %t149, ptr %l13, !tbaa !24
  br label %bb17
bb31:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load i32, ptr %l7, !tbaa !23
  %t155 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t151, i32 %t152)
  store i32 %t155, ptr %l98
  br label %bb32
bb32:
  %t156 = load i32, ptr %l98, !tbaa !23
  store i32 %t156, ptr %l15, !tbaa !23
  %t157 = load i32, ptr %l15, !tbaa !23
  %t158 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t161 = icmp eq i32 %t157, %t158
  br i1 %t161, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s6
  %t163 = load i32, ptr %l7, !tbaa !23
  %t164 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t167 = icmp eq i32 %t163, %t164
  br i1 %t167, label %bb35, label %bb36
bb34:
  br label %bb115
bb35:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load %"compiler/source:Span", ptr %l1
  %t173 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t169, %"compiler/source:Span" %t170)
  store ptr %t173, ptr %l107
  br label %bb37
bb36:
  br label %bb38
bb37:
  call void @__olang_scope_close(ptr %s6)
  %t174 = load ptr, ptr %l107, !tbaa !29
  store ptr %t174, ptr %rv
  br label %ret
bb38:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load i32, ptr %l7, !tbaa !23
  %t179 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t175, i32 %t176)
  store i1 %t179, ptr %l110
  br label %bb39
bb39:
  %t180 = load i1, ptr %l110, !tbaa !21
  %t181 = xor i1 %t180, true
  br i1 %t181, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s8
  %t183 = load ptr, ptr %l0, !tbaa !29
  store ptr %t183, ptr %l112, !tbaa !29
  %t184 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t184, ptr %l113
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load i32, ptr %l7, !tbaa !23
  %t189 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s8, ptr %t185, i32 %t186)
  store { i64, ptr } %t189, ptr %l116
  br label %bb42
bb41:
  br label %bb46
bb42:
  %t190 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t190, 0
  %t192 = extractvalue { i64, ptr } %t190, 1
  %t193 = mul i64 %t191, 1
  %t194 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t193)
  call void @llvm.memcpy.p0.p0.i64(ptr %t194, ptr %t192, i64 %t193, i1 false)
  %t195 = insertvalue { i64, ptr } undef, i64 %t191, 0
  %t196 = insertvalue { i64, ptr } %t195, ptr %t194, 1
  %t198 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNotIndexable(ptr %s8, ptr %s8, { i64, ptr } %t196)
  store %"compiler/diagmsg:Msg" %t198, ptr %l118
  br label %bb43
bb43:
  %t199 = load ptr, ptr %l112, !tbaa !29
  %t200 = load %"compiler/source:Span", ptr %l113
  %t201 = load %"compiler/diagmsg:Msg", ptr %l118
  %t202 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t199, %"compiler/source:Span" %t200, %"compiler/diagmsg:Msg" %t201)
  store i64 %t202, ptr %l119
  br label %bb44
bb44:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load %"compiler/source:Span", ptr %l1
  %t207 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t203, %"compiler/source:Span" %t204)
  store ptr %t207, ptr %l122
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s6)
  %t208 = load ptr, ptr %l122, !tbaa !29
  store ptr %t208, ptr %rv
  br label %ret
bb46:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load i32, ptr %l7, !tbaa !23
  %t213 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s6, ptr %t209, i32 %t210, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d64, i32 0, i32 1) }, i64 2)
  store i64 %t213, ptr %l125
  br label %bb47
bb47:
  %t214 = load i64, ptr %l125, !tbaa !24
  store i64 %t214, ptr %l16, !tbaa !24
  %t215 = load i64, ptr %l16, !tbaa !24
  %t217 = icmp slt i64 %t215, 0
  br i1 %t217, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s9
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load i32, ptr %l7, !tbaa !23
  %t221 = load %"compiler/source:Span", ptr %l1
  %t225 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %s9, ptr %s9, ptr %t219, i32 %t220, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d65, i32 0, i32 1) }, %"compiler/source:Span" %t221, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d66, i32 0, i32 1) }, i64 2, i1 false)
  store i1 %t225, ptr %l131
  br label %bb50
bb49:
  br label %bb58
bb50:
  %t226 = load i1, ptr %l131, !tbaa !21
  %t227 = xor i1 %t226, true
  br i1 %t227, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s10
  %t229 = load ptr, ptr %l0, !tbaa !29
  store ptr %t229, ptr %l133, !tbaa !29
  %t230 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t230, ptr %l134
  %t231 = load i32, ptr %l7, !tbaa !23
  store i32 %t231, ptr %l135, !tbaa !23
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load i32, ptr %l7, !tbaa !23
  %t236 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s10, ptr %t232, i32 %t233)
  store { i64, ptr } %t236, ptr %l138
  br label %bb53
bb52:
  br label %bb56
bb53:
  %t237 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t238 = extractvalue { i64, ptr } %t237, 0
  %t239 = extractvalue { i64, ptr } %t237, 1
  %t240 = mul i64 %t238, 1
  %t241 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t240)
  call void @llvm.memcpy.p0.p0.i64(ptr %t241, ptr %t239, i64 %t240, i1 false)
  %t242 = insertvalue { i64, ptr } undef, i64 %t238, 0
  %t243 = insertvalue { i64, ptr } %t242, ptr %t241, 1
  %t245 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNotIndexable(ptr %s10, ptr %s10, { i64, ptr } %t243)
  store %"compiler/diagmsg:Msg" %t245, ptr %l140
  br label %bb54
bb54:
  %t246 = load ptr, ptr %l133, !tbaa !29
  %t247 = load %"compiler/source:Span", ptr %l134
  %t248 = load i32, ptr %l135, !tbaa !23
  %t249 = load %"compiler/diagmsg:Msg", ptr %l140
  %t250 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedErr(ptr %v0, ptr %s10, ptr %s10, ptr %t246, %"compiler/source:Span" %t247, i32 %t248, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d67, i32 0, i32 1) }, %"compiler/diagmsg:Msg" %t249)
  store i64 %t250, ptr %l141
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s10)
  br label %bb56
bb56:
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t252 = load %"compiler/source:Span", ptr %l1
  %t255 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t251, %"compiler/source:Span" %t252)
  store ptr %t255, ptr %l144
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s6)
  %t256 = load ptr, ptr %l144, !tbaa !29
  store ptr %t256, ptr %rv
  br label %ret
bb58:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load i32, ptr %l7, !tbaa !23
  %t261 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s6, ptr %t257, i32 %t258, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d68, i32 0, i32 1) }, i64 0)
  store i64 %t261, ptr %l147
  br label %bb59
bb59:
  %t262 = load i64, ptr %l147, !tbaa !24
  store i64 %t262, ptr %l17, !tbaa !24
  %t263 = load ptr, ptr %l4, !tbaa !29
  %t265 = icmp eq ptr %t263, null
  br i1 %t265, label %bb60, label %bb61
bb60:
  %t267 = load i64, ptr %l17, !tbaa !24
  %t269 = icmp slt i64 %t267, 0
  store i1 %t269, ptr %l150, !tbaa !21
  br label %bb62
bb61:
  store i1 false, ptr %l150, !tbaa !21
  br label %bb62
bb62:
  %t271 = load i1, ptr %l150, !tbaa !21
  br i1 %t271, label %bb63, label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s11
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t273 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s11, ptr %t272, %"compiler/source:Span" %t273, { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d69, i32 0, i32 1) })
  br label %bb65
bb64:
  br label %bb67
bb65:
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t277 = load %"compiler/source:Span", ptr %l1
  %t280 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t276, %"compiler/source:Span" %t277)
  store ptr %t280, ptr %l157
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s6)
  %t281 = load ptr, ptr %l157, !tbaa !29
  store ptr %t281, ptr %rv
  br label %ret
bb67:
  %t282 = load ptr, ptr %l3, !tbaa !29
  %t284 = icmp eq ptr %t282, null
  br i1 %t284, label %bb68, label %bb69
bb68:
  %t286 = load ptr, ptr %l0, !tbaa !29
  store ptr %t286, ptr %l161, !tbaa !29
  %t287 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t287, ptr %l162
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t290 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t288)
  store i32 %t290, ptr %l164
  br label %bb70
bb69:
  %t291 = load ptr, ptr %l0, !tbaa !29
  store ptr %t291, ptr %l166, !tbaa !29
  %t292 = load ptr, ptr %l0, !tbaa !29
  store ptr %t292, ptr %l167, !tbaa !29
  %t293 = load ptr, ptr %l3, !tbaa !29
  store ptr %t293, ptr %l168, !tbaa !29
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t296 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t294)
  store i32 %t296, ptr %l170
  br label %bb72
bb70:
  %t297 = load ptr, ptr %l161, !tbaa !29
  %t298 = load %"compiler/source:Span", ptr %l162
  %t299 = load i32, ptr %l164, !tbaa !23
  %t300 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v4, ptr %t297, %"compiler/source:Span" %t298, i32 %t299, i64 0)
  store ptr %t300, ptr %l165
  br label %bb71
bb71:
  %t301 = load ptr, ptr %l165, !tbaa !29
  store ptr %t301, ptr %l160, !tbaa !29
  br label %bb76
bb72:
  %t302 = load ptr, ptr %l167, !tbaa !29
  %t303 = load ptr, ptr %l168, !tbaa !29
  %t304 = load i32, ptr %l170, !tbaa !23
  %t305 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v2, ptr %v0, ptr %t302, ptr %t303, i32 %t304)
  store ptr %t305, ptr %l171
  br label %bb73
bb73:
  %t306 = load ptr, ptr %l3, !tbaa !29
  %t308 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t306)
  store %"compiler/source:Span" %t308, ptr %l173
  br label %bb74
bb74:
  %t309 = load ptr, ptr %l166, !tbaa !29
  %t310 = load ptr, ptr %l171, !tbaa !29
  %t311 = load %"compiler/source:Span", ptr %l173
  %t312 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v4, ptr %t309, ptr %t310, %"compiler/source:Span" %t311)
  store ptr %t312, ptr %l174
  br label %bb75
bb75:
  %t313 = load ptr, ptr %l174, !tbaa !29
  store ptr %t313, ptr %l160, !tbaa !29
  br label %bb76
bb76:
  %t314 = load ptr, ptr %l160, !tbaa !29
  store ptr %t314, ptr %l18, !tbaa !29
  store ptr null, ptr %l19, !tbaa !29
  %t315 = load ptr, ptr %l4, !tbaa !29
  %t317 = icmp eq ptr %t315, null
  br i1 %t317, label %bb77, label %bb78
bb77:
  %t319 = load ptr, ptr %l0, !tbaa !29
  store ptr %t319, ptr %l177, !tbaa !29
  %t320 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t320, ptr %l178
  %t321 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t321, ptr %l179
  %t322 = load i64, ptr %l17, !tbaa !24
  store i64 %t322, ptr %l180, !tbaa !24
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = load %"compiler/source:Span", ptr %l1
  %t325 = load ptr, ptr %l6, !tbaa !29
  %t329 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v0, ptr %t323, %"compiler/source:Span" %t324, ptr %t325)
  store ptr %t329, ptr %l184
  br label %bb79
bb78:
  %t330 = load ptr, ptr %l0, !tbaa !29
  store ptr %t330, ptr %l197, !tbaa !29
  %t331 = load ptr, ptr %l0, !tbaa !29
  store ptr %t331, ptr %l198, !tbaa !29
  %t332 = load ptr, ptr %l4, !tbaa !29
  store ptr %t332, ptr %l199, !tbaa !29
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t335 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t333)
  store i32 %t335, ptr %l201
  br label %bb93
bb79:
  %t336 = load ptr, ptr %l184, !tbaa !29
  store ptr %t336, ptr %l185, !tbaa !29
  %t337 = icmp sge i64 0, 0
  br i1 %t337, label %bb80, label %bb81
bb80:
  %t339 = icmp sle i64 0, 1152921504606846975
  br i1 %t339, label %bb82, label %bb83
bb81:
  call void @__olang_check_failed(ptr @olang_loc_5aa0e1f55b10e6f_53045464d54dc2fb)
  unreachable
bb82:
  %t341 = mul i64 0, 8
  %t342 = insertvalue { i64, ptr } undef, i64 0, 0
  %t343 = insertvalue { i64, ptr } %t342, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t343, ptr %l188, !tbaa !27
  %t344 = icmp sge i64 0, 0
  br i1 %t344, label %bb84, label %bb85
bb83:
  call void @__olang_check_failed(ptr @olang_loc_5aa0e1f55b10e6f_53045464d54dc2fb)
  unreachable
bb84:
  %t346 = icmp sle i64 0, 1152921504606846975
  br i1 %t346, label %bb86, label %bb87
bb85:
  call void @__olang_check_failed(ptr @olang_loc_5aa0e1f55b10e6f_53045464d54dc2fb)
  unreachable
bb86:
  %t348 = mul i64 0, 8
  %t349 = insertvalue { i64, ptr } undef, i64 0, 0
  %t350 = insertvalue { i64, ptr } %t349, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t350, ptr %l191, !tbaa !27
  %t351 = icmp sge i64 0, 0
  br i1 %t351, label %bb88, label %bb89
bb87:
  call void @__olang_check_failed(ptr @olang_loc_5aa0e1f55b10e6f_53045464d54dc2fb)
  unreachable
bb88:
  %t353 = icmp sle i64 0, 2305843009213693951
  br i1 %t353, label %bb90, label %bb91
bb89:
  call void @__olang_check_failed(ptr @olang_loc_e4f33d7277813d9a_8adeed4fca551266)
  unreachable
bb90:
  %t355 = mul i64 0, 4
  %t356 = insertvalue { i64, ptr } undef, i64 0, 0
  %t357 = insertvalue { i64, ptr } %t356, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t358 = load ptr, ptr %l177, !tbaa !29
  %t359 = load %"compiler/source:Span", ptr %l178
  %t360 = load %"compiler/source:Span", ptr %l179
  %t361 = load i64, ptr %l180, !tbaa !24
  %t362 = load ptr, ptr %l185, !tbaa !29
  %t363 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t364 = load { i64, ptr }, ptr %l191, !tbaa !27
  %t366 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v4, ptr %v4, ptr %t358, %"compiler/source:Span" %t359, %"compiler/source:Span" %t360, i64 %t361, ptr %t362, { i64, ptr } %t363, { i64, ptr } %t364, { i64, ptr } %t357)
  store ptr %t366, ptr %l195
  br label %bb92
bb91:
  call void @__olang_check_failed(ptr @olang_loc_e4f33d7277813d9a_8adeed4fca551266)
  unreachable
bb92:
  %t367 = load ptr, ptr %l195, !tbaa !29
  store ptr %t367, ptr %l19, !tbaa !29
  br label %bb97
bb93:
  %t369 = load ptr, ptr %l198, !tbaa !29
  %t370 = load ptr, ptr %l199, !tbaa !29
  %t371 = load i32, ptr %l201, !tbaa !23
  %t372 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v3, ptr %v0, ptr %t369, ptr %t370, i32 %t371)
  store ptr %t372, ptr %l202
  br label %bb94
bb94:
  %t373 = load ptr, ptr %l4, !tbaa !29
  %t375 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v3, ptr %t373)
  store %"compiler/source:Span" %t375, ptr %l204
  br label %bb95
bb95:
  %t376 = load ptr, ptr %l197, !tbaa !29
  %t377 = load ptr, ptr %l202, !tbaa !29
  %t378 = load %"compiler/source:Span", ptr %l204
  %t379 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v4, ptr %t376, ptr %t377, %"compiler/source:Span" %t378)
  store ptr %t379, ptr %l205
  br label %bb96
bb96:
  %t380 = load ptr, ptr %l205, !tbaa !29
  store ptr %t380, ptr %l19, !tbaa !29
  br label %bb97
bb97:
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t384 = getelementptr %"compiler/check:Checker", ptr %t382, i32 0, i32 36
  %t386 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t384)
  store i64 %t386, ptr %l209
  br label %bb98
bb98:
  %t387 = load i64, ptr %l209, !tbaa !24
  store i64 %t387, ptr %l20, !tbaa !24
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t390 = getelementptr %"compiler/check:Checker", ptr %t388, i32 0, i32 36
  %t391 = load ptr, ptr %l18, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v4, ptr %t390, ptr %t391)
  br label %bb99
bb99:
  %t394 = load ptr, ptr %l0, !tbaa !29
  %t396 = getelementptr %"compiler/check:Checker", ptr %t394, i32 0, i32 36
  store ptr %t396, ptr %l214, !tbaa !29
  %t397 = load ptr, ptr %l19, !tbaa !29
  %t399 = icmp eq ptr %t397, null
  br i1 %t399, label %bb100, label %bb101
bb100:
  call void @__olang_check_failed(ptr @olang_loc_b203c9fbf4c249fb_735051f472c86bf)
  unreachable
bb101:
  br label %bb102
bb102:
  %t401 = load ptr, ptr %l19, !tbaa !29
  %t402 = load ptr, ptr %l214, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v4, ptr %t402, ptr %t401)
  br label %bb103
bb103:
  %t404 = load ptr, ptr %l0, !tbaa !29
  store ptr %t404, ptr %l218, !tbaa !29
  %t405 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t405, ptr %l219
  %t406 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t406, ptr %l220
  %t407 = load i64, ptr %l16, !tbaa !24
  store i64 %t407, ptr %l221, !tbaa !24
  %t408 = load ptr, ptr %l0, !tbaa !29
  %t409 = load %"compiler/source:Span", ptr %l1
  %t410 = load ptr, ptr %l6, !tbaa !29
  %t414 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v0, ptr %t408, %"compiler/source:Span" %t409, ptr %t410)
  store ptr %t414, ptr %l225
  br label %bb104
bb104:
  %t415 = load ptr, ptr %l225, !tbaa !29
  store ptr %t415, ptr %l226, !tbaa !29
  %t416 = icmp sge i64 0, 0
  br i1 %t416, label %bb105, label %bb106
bb105:
  %t418 = icmp sle i64 0, 1152921504606846975
  br i1 %t418, label %bb107, label %bb108
bb106:
  call void @__olang_check_failed(ptr @olang_loc_85a2f2931038d80c_e5a946dd8e187d18)
  unreachable
bb107:
  %t420 = mul i64 0, 8
  %t421 = insertvalue { i64, ptr } undef, i64 0, 0
  %t422 = insertvalue { i64, ptr } %t421, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t422, ptr %l229, !tbaa !27
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t425 = getelementptr %"compiler/check:Checker", ptr %t423, i32 0, i32 36
  %t426 = load i64, ptr %l20, !tbaa !24
  %t429 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t425, i64 %t426)
  store { i64, ptr } %t429, ptr %l233
  br label %bb109
bb108:
  call void @__olang_check_failed(ptr @olang_loc_85a2f2931038d80c_e5a946dd8e187d18)
  unreachable
bb109:
  %t430 = icmp sge i64 0, 0
  br i1 %t430, label %bb110, label %bb111
bb110:
  %t432 = icmp sle i64 0, 2305843009213693951
  br i1 %t432, label %bb112, label %bb113
bb111:
  call void @__olang_check_failed(ptr @olang_loc_e4f33d7277813d9a_8adeed4fca551266)
  unreachable
bb112:
  %t434 = mul i64 0, 4
  %t435 = insertvalue { i64, ptr } undef, i64 0, 0
  %t436 = insertvalue { i64, ptr } %t435, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t437 = load ptr, ptr %l218, !tbaa !29
  %t438 = load %"compiler/source:Span", ptr %l219
  %t439 = load %"compiler/source:Span", ptr %l220
  %t440 = load i64, ptr %l221, !tbaa !24
  %t441 = load ptr, ptr %l226, !tbaa !29
  %t442 = load { i64, ptr }, ptr %l229, !tbaa !27
  %t443 = load { i64, ptr }, ptr %l233, !tbaa !27
  %t445 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v4, ptr %v4, ptr %t437, %"compiler/source:Span" %t438, %"compiler/source:Span" %t439, i64 %t440, ptr %t441, { i64, ptr } %t442, { i64, ptr } %t443, { i64, ptr } %t436)
  store ptr %t445, ptr %l237
  br label %bb114
bb113:
  call void @__olang_check_failed(ptr @olang_loc_e4f33d7277813d9a_8adeed4fca551266)
  unreachable
bb114:
  call void @__olang_scope_close(ptr %s6)
  %t446 = load ptr, ptr %l237, !tbaa !29
  store ptr %t446, ptr %rv
  br label %ret
bb115:
  store ptr null, ptr %l21, !tbaa !29
  %t447 = load ptr, ptr %l3, !tbaa !29
  %t449 = icmp eq ptr %t447, null
  br i1 %t449, label %bb116, label %bb117
bb116:
  %t451 = load ptr, ptr %l0, !tbaa !29
  store ptr %t451, ptr %l240, !tbaa !29
  %t452 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t452, ptr %l241
  %t453 = load ptr, ptr %l0, !tbaa !29
  %t455 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t453)
  store i32 %t455, ptr %l243
  br label %bb118
bb117:
  %t456 = load ptr, ptr %l0, !tbaa !29
  store ptr %t456, ptr %l246, !tbaa !29
  %t457 = load ptr, ptr %l3, !tbaa !29
  store ptr %t457, ptr %l247, !tbaa !29
  %t458 = load ptr, ptr %l0, !tbaa !29
  %t460 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t458)
  store i32 %t460, ptr %l249
  br label %bb120
bb118:
  %t461 = load ptr, ptr %l240, !tbaa !29
  %t462 = load %"compiler/source:Span", ptr %l241
  %t463 = load i32, ptr %l243, !tbaa !23
  %t464 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v4, ptr %t461, %"compiler/source:Span" %t462, i32 %t463, i64 0)
  store ptr %t464, ptr %l244
  br label %bb119
bb119:
  %t465 = load ptr, ptr %l244, !tbaa !29
  store ptr %t465, ptr %l21, !tbaa !29
  br label %bb122
bb120:
  %t467 = load ptr, ptr %l246, !tbaa !29
  %t468 = load ptr, ptr %l247, !tbaa !29
  %t469 = load i32, ptr %l249, !tbaa !23
  %t470 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v2, ptr %v4, ptr %t467, ptr %t468, i32 %t469)
  store ptr %t470, ptr %l250
  br label %bb121
bb121:
  %t471 = load ptr, ptr %l250, !tbaa !29
  store ptr %t471, ptr %l21, !tbaa !29
  br label %bb122
bb122:
  store ptr null, ptr %l22, !tbaa !29
  %t473 = load ptr, ptr %l4, !tbaa !29
  %t475 = icmp eq ptr %t473, null
  br i1 %t475, label %bb123, label %bb124
bb123:
  %t477 = load ptr, ptr %l0, !tbaa !29
  store ptr %t477, ptr %l254, !tbaa !29
  %t478 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t478, ptr %l255
  %t479 = load ptr, ptr %l0, !tbaa !29
  %t481 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t479)
  store i32 %t481, ptr %l257
  br label %bb125
bb124:
  %t482 = load ptr, ptr %l0, !tbaa !29
  store ptr %t482, ptr %l271, !tbaa !29
  %t483 = load ptr, ptr %l4, !tbaa !29
  store ptr %t483, ptr %l272, !tbaa !29
  %t484 = load ptr, ptr %l0, !tbaa !29
  %t486 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t484)
  store i32 %t486, ptr %l274
  br label %bb128
bb125:
  store i32 22, ptr %l258
  %t487 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t487, ptr %l259
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t490 = getelementptr %"compiler/check:Checker", ptr %t488, i32 0, i32 1
  %t491 = load ptr, ptr %t490, !tbaa !29
  %t493 = getelementptr %"compiler/generic:Program", ptr %t491, i32 0, i32 2
  %t494 = load i32, ptr %l7, !tbaa !23
  %t495 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t499 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t493, i32 %t494, i64 %t495)
  store i32 %t499, ptr %l265
  br label %bb126
bb126:
  %t500 = load ptr, ptr %l6, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t501
  %t502 = getelementptr { i64, [5 x i64] }, ptr %t501, i32 0, i32 0
  store i64 3, ptr %t502
  %t503 = load %"compiler/source:Span", ptr %l259
  %t504 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t503, 0
  %t505 = load i32, ptr %l265, !tbaa !23
  %t506 = insertvalue { %"compiler/source:Span", i32, ptr } %t504, i32 %t505, 1
  %t508 = insertvalue { %"compiler/source:Span", i32, ptr } %t506, ptr %t500, 2
  %t509 = getelementptr { i64, [5 x i64] }, ptr %t501, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t508, ptr %t509
  %t510 = load { i64, [5 x i64] }, ptr %t501
  %t512 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t510, ptr %t512
  %t513 = load ptr, ptr %l254, !tbaa !29
  %t514 = load %"compiler/source:Span", ptr %l255
  %t515 = load i32, ptr %l257, !tbaa !23
  %t516 = load i32, ptr %l258, !range !{i32 0, i32 46}
  %t518 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v4, ptr %t513, %"compiler/source:Span" %t514, i32 %t515, i32 %t516, ptr %t512, ptr null)
  store ptr %t518, ptr %l269
  br label %bb127
bb127:
  %t519 = load ptr, ptr %l269, !tbaa !29
  store ptr %t519, ptr %l22, !tbaa !29
  br label %bb130
bb128:
  %t521 = load ptr, ptr %l271, !tbaa !29
  %t522 = load ptr, ptr %l272, !tbaa !29
  %t523 = load i32, ptr %l274, !tbaa !23
  %t524 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v3, ptr %v4, ptr %t521, ptr %t522, i32 %t523)
  store ptr %t524, ptr %l275
  br label %bb129
bb129:
  %t525 = load ptr, ptr %l275, !tbaa !29
  store ptr %t525, ptr %l22, !tbaa !29
  br label %bb130
bb130:
  %t527 = load ptr, ptr %l0, !tbaa !29
  %t528 = load i32, ptr %l7, !tbaa !23
  %t531 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t527, i32 %t528)
  store i1 %t531, ptr %l279
  br label %bb131
bb131:
  %t532 = load i1, ptr %l279, !tbaa !21
  br i1 %t532, label %bb132, label %bb133
bb132:
  %t533 = load i32, ptr %l7, !tbaa !23
  store i32 %t533, ptr %l280, !tbaa !23
  br label %bb140
bb133:
  %t535 = load ptr, ptr %l0, !tbaa !29
  %t537 = getelementptr %"compiler/check:Checker", ptr %t535, i32 0, i32 1
  %t538 = load ptr, ptr %t537, !tbaa !29
  %t540 = getelementptr %"compiler/generic:Program", ptr %t538, i32 0, i32 2
  store ptr %t540, ptr %l284, !tbaa !29
  %t541 = load ptr, ptr %l0, !tbaa !29
  %t543 = getelementptr %"compiler/check:Checker", ptr %t541, i32 0, i32 1
  %t544 = load ptr, ptr %t543, !tbaa !29
  %t546 = getelementptr %"compiler/generic:Program", ptr %t544, i32 0, i32 2
  %t547 = load i32, ptr %l15, !tbaa !23
  %t550 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t546, i32 %t547)
  store i32 %t550, ptr %l289
  br label %bb134
bb134:
  %t551 = load i32, ptr %l5, !range !{i32 0, i32 3}
  %t553 = trunc i64 1 to i32
  %t554 = icmp eq i32 %t551, %t553
  br i1 %t554, label %bb135, label %bb136
bb135:
  %t556 = load ptr, ptr %l0, !tbaa !29
  %t557 = load i32, ptr %l15, !tbaa !23
  %t558 = load ptr, ptr %l3, !tbaa !29
  %t559 = load ptr, ptr %l4, !tbaa !29
  %t564 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esliceLength(ptr %v0, ptr %v2, ptr %v3, ptr %t556, i32 %t557, ptr %t558, ptr %t559)
  store i32 %t564, ptr %l297
  br label %bb137
bb136:
  store i32 0, ptr %l292, !tbaa !23
  br label %bb138
bb137:
  %t565 = load i32, ptr %l297, !tbaa !23
  store i32 %t565, ptr %l292, !tbaa !23
  br label %bb138
bb138:
  %t566 = load ptr, ptr %l284, !tbaa !29
  %t567 = load i32, ptr %l289, !tbaa !23
  %t568 = load i32, ptr %l292, !tbaa !23
  %t569 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t566, i32 %t567, i32 %t568)
  store i32 %t569, ptr %l298
  br label %bb139
bb139:
  %t570 = load i32, ptr %l298, !tbaa !23
  store i32 %t570, ptr %l280, !tbaa !23
  br label %bb140
bb140:
  %t571 = load i32, ptr %l280, !tbaa !23
  %t572 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t572, ptr %l299
  %t573 = load ptr, ptr %l0, !tbaa !29
  %t575 = getelementptr %"compiler/check:Checker", ptr %t573, i32 0, i32 1
  %t576 = load ptr, ptr %t575, !tbaa !29
  %t578 = getelementptr %"compiler/generic:Program", ptr %t576, i32 0, i32 2
  %t580 = load i64, ptr %l8, !tbaa !24
  %t584 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t578, i32 %t571, i64 %t580)
  store i32 %t584, ptr %l305
  br label %bb141
bb141:
  %t585 = load ptr, ptr %l6, !tbaa !29
  store ptr %t585, ptr %l306, !tbaa !29
  %t586 = load ptr, ptr %l21, !tbaa !29
  %t588 = icmp eq ptr %t586, null
  br i1 %t588, label %bb142, label %bb143
bb142:
  call void @__olang_check_failed(ptr @olang_loc_2f1aad6b95023edd_c82f5ce971f0d619)
  unreachable
bb143:
  br label %bb144
bb144:
  %t590 = load ptr, ptr %l21, !tbaa !29
  store ptr %t590, ptr %l309, !tbaa !29
  %t591 = load ptr, ptr %l22, !tbaa !29
  %t593 = icmp eq ptr %t591, null
  br i1 %t593, label %bb145, label %bb146
bb145:
  call void @__olang_check_failed(ptr @olang_loc_2f1aad6b95023edd_c82f5ce971f0d619)
  unreachable
bb146:
  br label %bb147
bb147:
  %t595 = load ptr, ptr %l22, !tbaa !29
  %t596 = load i32, ptr %l5, !range !{i32 0, i32 3}
  %t597 = load ptr, ptr %l306, !tbaa !29
  %t598 = load ptr, ptr %l309, !tbaa !29
  %t601 = call %"compiler/typed:Slice" @compiler_2ftyped_3aSlice_2ector(ptr %v1, ptr %v4, ptr %v4, ptr %v4, ptr %t597, ptr %t598, ptr %t595, i32 %t596)
  store %"compiler/typed:Slice" %t601, ptr %l314
  br label %bb148
bb148:
  %t602 = load %"compiler/typed:Slice", ptr %l314
  %t603 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 32, i64 8)
  store %"compiler/typed:Slice" %t602, ptr %t603
  store { i64, [5 x i64] } zeroinitializer, ptr %t604
  %t605 = getelementptr { i64, [5 x i64] }, ptr %t604, i32 0, i32 0
  store i64 10, ptr %t605
  %t606 = load %"compiler/source:Span", ptr %l299
  %t607 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t606, 0
  %t608 = load i32, ptr %l305, !tbaa !23
  %t609 = insertvalue { %"compiler/source:Span", i32, ptr } %t607, i32 %t608, 1
  %t611 = insertvalue { %"compiler/source:Span", i32, ptr } %t609, ptr %t603, 2
  %t612 = getelementptr { i64, [5 x i64] }, ptr %t604, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t611, ptr %t612
  %t613 = load { i64, [5 x i64] }, ptr %t604
  %t615 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 48, i64 8)
  store { i64, [5 x i64] } %t613, ptr %t615
  store ptr %t615, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espawnStmt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i1
  %l18 = alloca %"compiler/source:Span"
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca i32
  %l27 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca i1
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l39 = alloca i1
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i64
  %l45 = alloca ptr
  %l49 = alloca ptr
  %l53 = alloca i1
  %l56 = alloca i64
  %l60 = alloca ptr
  %l61 = alloca %"compiler/source:Span"
  %l62 = alloca %"compiler/diagmsg:Msg"
  %l63 = alloca i64
  %l64 = alloca ptr
  %l69 = alloca i64
  %l71 = alloca ptr
  %l72 = alloca %"compiler/source:Span"
  %l73 = alloca %"compiler/diagmsg:Msg"
  %l74 = alloca i64
  %l75 = alloca ptr
  %l79 = alloca ptr
  %l82 = alloca i64
  %l83 = alloca i64
  %l85 = alloca ptr
  %l88 = alloca i64
  %l90 = alloca i64
  %l92 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l101 = alloca { i64, ptr }
  %l104 = alloca ptr
  %l107 = alloca ptr
  %l114 = alloca ptr
  %l115 = alloca i1
  %l126 = alloca i64
  %l128 = alloca ptr
  %l131 = alloca ptr
  %l132 = alloca i1
  %l144 = alloca ptr
  %l145 = alloca %"compiler/source:Span"
  %l146 = alloca %"compiler/diagmsg:Msg"
  %l147 = alloca i64
  %l152 = alloca ptr
  %l155 = alloca i32
  %l158 = alloca ptr
  %l159 = alloca %"compiler/source:Span"
  %l160 = alloca %"compiler/source:Span"
  %l163 = alloca i32
  %l166 = alloca ptr
  %l169 = alloca { i64, ptr }
  %l173 = alloca ptr
  %l175 = alloca ptr
  %l176 = alloca i1
  %l183 = alloca ptr
  %l185 = alloca ptr
  %l186 = alloca i1
  %l195 = alloca i1
  %l197 = alloca i1
  %l202 = alloca ptr
  %l204 = alloca ptr
  %l206 = alloca %"compiler/source:Span"
  %l207 = alloca %"compiler/diagmsg:Msg"
  %l208 = alloca i64
  %l213 = alloca ptr
  %l215 = alloca ptr
  %l216 = alloca ptr
  %l220 = alloca i1
  %l224 = alloca ptr
  %l225 = alloca { i64, ptr }
  %l226 = alloca i64
  %l229 = alloca i64
  %l235 = alloca ptr
  %l239 = alloca i1
  %l240 = alloca ptr
  %l241 = alloca { i64, ptr }
  %l242 = alloca ptr
  %l243 = alloca ptr
  %l246 = alloca i32
  %l247 = alloca ptr
  %l255 = alloca { i64, ptr }
  %l263 = alloca i1
  %l266 = alloca ptr
  %l268 = alloca %"compiler/source:Span"
  %l269 = alloca %"compiler/diagmsg:Msg"
  %l270 = alloca i64
  %l271 = alloca ptr
  %l277 = alloca i1
  %l279 = alloca ptr
  %l281 = alloca %"compiler/source:Span"
  %l282 = alloca %"compiler/diagmsg:Msg"
  %l283 = alloca i64
  %l284 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l286 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l292 = alloca i32
  %l294 = alloca i64
  %l296 = alloca i1
  %l298 = alloca ptr
  %l302 = alloca ptr
  %l306 = alloca i32
  %l309 = alloca i1
  %l310 = alloca i1
  %l313 = alloca i1
  %l314 = alloca i1
  %l319 = alloca i1
  %l320 = alloca i1
  %l325 = alloca i32
  %l330 = alloca i32
  %l336 = alloca i32
  %l344 = alloca { i64, ptr }
  %l347 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l350 = alloca i1
  %l355 = alloca i1
  %l366 = alloca { i64, ptr }
  %l377 = alloca i1
  %l379 = alloca ptr
  %l381 = alloca %"compiler/source:Span"
  %l383 = alloca { i64, ptr }
  %l388 = alloca ptr
  %l390 = alloca i32
  %l392 = alloca { i64, ptr }
  %l394 = alloca { i64, ptr }
  %l398 = alloca { i64, ptr }
  %l400 = alloca %"compiler/diagmsg:Msg"
  %l401 = alloca i64
  %l406 = alloca i1
  %l408 = alloca ptr
  %l410 = alloca %"compiler/source:Span"
  %l412 = alloca { i64, ptr }
  %l413 = alloca i1
  %l414 = alloca ptr
  %l415 = alloca ptr
  %l416 = alloca i32
  %l418 = alloca i64
  %l419 = alloca ptr
  %l420 = alloca %"compiler/typed:TaskClause"
  %l422 = alloca ptr
  %l424 = alloca %"compiler/source:Span"
  %l426 = alloca { i64, ptr }
  %l427 = alloca i1
  %l431 = alloca %"compiler/typed:Clause"
  %l437 = alloca i64
  %l446 = alloca { i64, ptr }
  %l460 = alloca i64
  %l462 = alloca i1
  %l465 = alloca i64
  %l468 = alloca ptr
  %l472 = alloca i64
  %l474 = alloca ptr
  %l475 = alloca %"compiler/source:Span"
  %l476 = alloca ptr
  %l477 = alloca { i64, ptr }
  %l478 = alloca ptr
  %l481 = alloca i32
  %l482 = alloca ptr
  %l483 = alloca %"compiler/source:Span"
  %l485 = alloca { i64, ptr }
  %l486 = alloca ptr
  %l488 = alloca { i64, ptr }
  %l492 = alloca i32
  %l493 = alloca %"compiler/typed:Spawn"
  %l497 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %t261 = alloca { i64, [3 x i64] }, align 8
  %t958 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l45, !tbaa !29
  %t2 = load ptr, ptr %l45, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t2, i32 0, i32 41
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = add i64 %t4, 1
  %t8 = load ptr, ptr %l45, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t8, i32 0, i32 41
  store i64 %t6, ptr %t9, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t10)
  store ptr %t12, ptr %l49
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l49, !tbaa !29
  store ptr %t13, ptr %l4, !tbaa !29
  %t14 = load ptr, ptr %l4, !tbaa !29
  %t16 = getelementptr %"compiler/check:frame", ptr %t14, i32 0, i32 34
  %t17 = load i64, ptr %t16, !tbaa !24
  %t19 = icmp sge i64 %t17, 0
  br i1 %t19, label %bb2, label %bb3
bb2:
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t23 = getelementptr %"compiler/check:frame", ptr %t21, i32 0, i32 38
  %t25 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t23)
  store i64 %t25, ptr %l56
  br label %bb4
bb3:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb5
bb4:
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t28 = getelementptr %"compiler/check:frame", ptr %t26, i32 0, i32 37
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = load i64, ptr %l56, !tbaa !24
  %t32 = icmp sle i64 %t30, %t29
  store i1 %t32, ptr %l53, !tbaa !21
  br label %bb5
bb5:
  %t34 = load i1, ptr %l53, !tbaa !21
  br i1 %t34, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l60, !tbaa !29
  %t36 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t36, ptr %l61
  %t37 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpawnInDefer(ptr %s1)
  store %"compiler/diagmsg:Msg" %t37, ptr %l62
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t38 = load ptr, ptr %l60, !tbaa !29
  %t39 = load %"compiler/source:Span", ptr %l61
  %t40 = load %"compiler/diagmsg:Msg", ptr %l62
  %t41 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t38, %"compiler/source:Span" %t39, %"compiler/diagmsg:Msg" %t40)
  store i64 %t41, ptr %l63
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l64, !tbaa !29
  %t43 = load ptr, ptr %l64, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 41
  %t45 = load i64, ptr %t44, !tbaa !24
  %t47 = sub i64 %t45, 1
  %t49 = load ptr, ptr %l64, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 41
  store i64 %t47, ptr %t50, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb10:
  %t51 = load ptr, ptr %l4, !tbaa !29
  %t53 = getelementptr %"compiler/check:frame", ptr %t51, i32 0, i32 38
  %t55 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t53)
  store i64 %t55, ptr %l69
  br label %bb11
bb11:
  %t56 = load i64, ptr %l69, !tbaa !24
  %t57 = icmp eq i64 %t56, 0
  br i1 %t57, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l71, !tbaa !29
  %t60 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t60, ptr %l72
  %t61 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpawnOutsideJoin(ptr %s3)
  store %"compiler/diagmsg:Msg" %t61, ptr %l73
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t62 = load ptr, ptr %l71, !tbaa !29
  %t63 = load %"compiler/source:Span", ptr %l72
  %t64 = load %"compiler/diagmsg:Msg", ptr %l73
  %t65 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t62, %"compiler/source:Span" %t63, %"compiler/diagmsg:Msg" %t64)
  store i64 %t65, ptr %l74
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  %t66 = load ptr, ptr %l0, !tbaa !29
  store ptr %t66, ptr %l75, !tbaa !29
  %t67 = load ptr, ptr %l75, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 41
  %t69 = load i64, ptr %t68, !tbaa !24
  %t71 = sub i64 %t69, 1
  %t73 = load ptr, ptr %l75, !tbaa !29
  %t74 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 41
  store i64 %t71, ptr %t74, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb16:
  %t75 = load ptr, ptr %l4, !tbaa !29
  %t77 = getelementptr %"compiler/check:frame", ptr %t75, i32 0, i32 38
  store ptr %t77, ptr %l79, !tbaa !29
  %t78 = load ptr, ptr %l4, !tbaa !29
  %t80 = getelementptr %"compiler/check:frame", ptr %t78, i32 0, i32 38
  %t82 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t80)
  store i64 %t82, ptr %l82
  br label %bb17
bb17:
  %t83 = load i64, ptr %l82, !tbaa !24
  %t84 = sub i64 %t83, 1
  store i64 %t84, ptr %l83, !tbaa !24
  %t85 = load ptr, ptr %l4, !tbaa !29
  %t87 = getelementptr %"compiler/check:frame", ptr %t85, i32 0, i32 38
  store ptr %t87, ptr %l85, !tbaa !29
  %t88 = load ptr, ptr %l4, !tbaa !29
  %t90 = getelementptr %"compiler/check:frame", ptr %t88, i32 0, i32 38
  %t92 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t90)
  store i64 %t92, ptr %l88
  br label %bb18
bb18:
  %t93 = load i64, ptr %l88, !tbaa !24
  %t94 = sub i64 %t93, 1
  %t95 = load ptr, ptr %l85, !tbaa !29
  %t97 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t95, i64 %t94)
  store i64 %t97, ptr %l90
  br label %bb19
bb19:
  %t98 = load i64, ptr %l90, !tbaa !24
  %t99 = add i64 %t98, 1
  %t100 = load ptr, ptr %l79, !tbaa !29
  %t101 = load i64, ptr %l83, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t100, i64 %t101, i64 %t99)
  br label %bb20
bb20:
  %t103 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t103, ptr %l92
  br label %bb21
bb21:
  %t104 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l92
  %t105 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t104, ptr %t105
  store ptr %t105, ptr %l5, !tbaa !29
  %t107 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t107, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t109 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t109, 0
  store i64 %t111, ptr %l8, !tbaa !24
  br label %bb22
bb22:
  %t113 = load i64, ptr %l7, !tbaa !24
  %t114 = load i64, ptr %l8, !tbaa !24
  %t117 = icmp slt i64 %t113, %t114
  %t119 = xor i1 %t117, true
  br i1 %t119, label %bb23, label %bb24
bb23:
  br label %bb29
bb24:
  br label %bb25
bb25:
  %t121 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t121, ptr %l101, !tbaa !27
  %t122 = load i64, ptr %l7, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr ptr, ptr %t125, i64 %t122
  %t127 = load ptr, ptr %t126, !tbaa !39
  %t129 = load ptr, ptr %l5, !tbaa !29
  store ptr %t129, ptr %l104, !tbaa !29
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t134 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ediscardOr(ptr %v0, ptr %v1, ptr %v0, ptr %t130, ptr %t127)
  store ptr %t134, ptr %l107
  br label %bb26
bb26:
  %t135 = load ptr, ptr %l104, !tbaa !29
  %t136 = load ptr, ptr %l107, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eP_Ha5c233616e2ae02d7fe37742cfaef2c2(ptr %v0, ptr %v0, ptr %t135, ptr %t136)
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t137 = load i64, ptr %l7, !tbaa !24
  %t139 = add i64 %t137, 1
  store i64 %t139, ptr %l7, !tbaa !24
  br label %bb22
bb29:
  store i1 false, ptr %l10, !tbaa !21
  %t141 = load ptr, ptr %l3, !tbaa !29
  store ptr %t141, ptr %l11, !tbaa !29
  %t143 = icmp sge i64 0, 0
  br i1 %t143, label %bb30, label %bb31
bb30:
  %t145 = icmp sle i64 0, 1152921504606846975
  br i1 %t145, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_e10ca684bef0956d_f742028d37a3af11)
  unreachable
bb32:
  %t147 = mul i64 0, 8
  %t148 = insertvalue { i64, ptr } undef, i64 0, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t149, ptr %l12, !tbaa !27
  %t151 = load ptr, ptr %l3, !tbaa !29
  store ptr %t151, ptr %l114, !tbaa !29
  store i1 false, ptr %l115, !tbaa !21
  %t152 = load ptr, ptr %l114, !tbaa !29
  %t153 = icmp ne ptr %t152, null
  br i1 %t153, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_e10ca684bef0956d_f742028d37a3af11)
  unreachable
bb34:
  %t155 = load ptr, ptr %l114, !tbaa !29
  %t156 = load i64, ptr %t155, !range !{i64 0, i64 30}
  %t158 = icmp eq i64 %t156, 21
  store i1 %t158, ptr %l115, !tbaa !21
  br label %bb35
bb35:
  %t159 = load i1, ptr %l115, !tbaa !21
  br i1 %t159, label %bb36, label %bb37
bb36:
  %t160 = load ptr, ptr %l3, !tbaa !29
  %t162 = getelementptr { i64, [4 x i64] }, ptr %t160, i32 0, i32 1
  %t163 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t162, i32 0, i32 1
  %t164 = load ptr, ptr %t163
  store ptr %t164, ptr %l13, !tbaa !29
  %t166 = load ptr, ptr %l3, !tbaa !29
  %t168 = getelementptr { i64, [4 x i64] }, ptr %t166, i32 0, i32 1
  %t169 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t168, i32 0, i32 2
  %t170 = load { i64, ptr }, ptr %t169
  store { i64, ptr } %t170, ptr %l14, !tbaa !27
  br label %bb38
bb37:
  br label %bb39
bb38:
  store i1 true, ptr %l10, !tbaa !21
  %t172 = load ptr, ptr %l13, !tbaa !29
  store ptr %t172, ptr %l11, !tbaa !29
  %t174 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t174, ptr %l12, !tbaa !27
  br label %bb44
bb39:
  br i1 true, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_c3afd3921db70d3f_27f9f6390ccac16b)
  unreachable
bb44:
  %t176 = load ptr, ptr %l4, !tbaa !29
  %t178 = getelementptr %"compiler/check:frame", ptr %t176, i32 0, i32 28
  %t180 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t178)
  store i64 %t180, ptr %l126
  br label %bb45
bb45:
  %t181 = load i64, ptr %l126, !tbaa !24
  store i64 %t181, ptr %l15, !tbaa !24
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/check:Checker", ptr %t182, i32 0, i32 42
  store i32 0, ptr %t184, !tbaa !23
  %t185 = load ptr, ptr %l4, !tbaa !29
  store ptr %t185, ptr %l128, !tbaa !29
  %t186 = load ptr, ptr %l128, !tbaa !29
  %t187 = getelementptr %"compiler/check:frame", ptr %t186, i32 0, i32 15
  %t188 = load i64, ptr %t187, !tbaa !24
  %t190 = add i64 %t188, 1
  %t192 = load ptr, ptr %l128, !tbaa !29
  %t193 = getelementptr %"compiler/check:frame", ptr %t192, i32 0, i32 15
  store i64 %t190, ptr %t193, !tbaa !24
  store ptr null, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t194 = load ptr, ptr %l11, !tbaa !29
  store ptr %t194, ptr %l131, !tbaa !29
  store i1 false, ptr %l132, !tbaa !21
  %t195 = load ptr, ptr %l131, !tbaa !29
  %t196 = icmp ne ptr %t195, null
  br i1 %t196, label %bb46, label %bb47
bb46:
  %t198 = load ptr, ptr %l131, !tbaa !29
  %t199 = load i64, ptr %t198, !range !{i64 0, i64 30}
  %t201 = icmp eq i64 %t199, 22
  store i1 %t201, ptr %l132, !tbaa !21
  br label %bb47
bb47:
  %t202 = load i1, ptr %l132, !tbaa !21
  br i1 %t202, label %bb48, label %bb49
bb48:
  %t203 = load ptr, ptr %l11, !tbaa !29
  %t205 = getelementptr { i64, [4 x i64] }, ptr %t203, i32 0, i32 1
  %t206 = getelementptr { %"compiler/source:Span", ptr }, ptr %t205, i32 0, i32 0
  %t207 = load %"compiler/source:Span", ptr %t206
  store %"compiler/source:Span" %t207, ptr %l18
  %t209 = load ptr, ptr %l11, !tbaa !29
  %t211 = getelementptr { i64, [4 x i64] }, ptr %t209, i32 0, i32 1
  %t212 = getelementptr { %"compiler/source:Span", ptr }, ptr %t211, i32 0, i32 1
  %t213 = load ptr, ptr %t212
  store ptr %t213, ptr %l19, !tbaa !29
  br label %bb50
bb49:
  br label %bb71
bb50:
  %t215 = load ptr, ptr %l19, !tbaa !29
  %t217 = getelementptr %"compiler/ast:Func", ptr %t215, i32 0, i32 3
  %t218 = load ptr, ptr %t217, !tbaa !29
  %t220 = getelementptr %"compiler/ast:Sig", ptr %t218, i32 0, i32 0
  %t221 = load { i64, ptr }, ptr %t220, !tbaa !27
  %t223 = extractvalue { i64, ptr } %t221, 0
  %t225 = icmp sgt i64 %t223, 0
  br i1 %t225, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s11
  %t227 = load ptr, ptr %l0, !tbaa !29
  store ptr %t227, ptr %l144, !tbaa !29
  %t228 = load %"compiler/source:Span", ptr %l18
  store %"compiler/source:Span" %t228, ptr %l145
  %t229 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpawnLambdaParams(ptr %s11)
  store %"compiler/diagmsg:Msg" %t229, ptr %l146
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t230 = load ptr, ptr %l144, !tbaa !29
  %t231 = load %"compiler/source:Span", ptr %l145
  %t232 = load %"compiler/diagmsg:Msg", ptr %l146
  %t233 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s11, ptr %t230, %"compiler/source:Span" %t231, %"compiler/diagmsg:Msg" %t232)
  store i64 %t233, ptr %l147
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s11)
  br label %bb55
bb55:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load %"compiler/source:Span", ptr %l18
  %t236 = load ptr, ptr %l19, !tbaa !29
  %t237 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t242 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elambda(ptr %v0, ptr %v2, ptr %v0, ptr %t234, %"compiler/source:Span" %t235, ptr %t236, i32 %t237)
  store ptr %t242, ptr %l152
  br label %bb56
bb56:
  %t243 = load ptr, ptr %l152, !tbaa !29
  store ptr %t243, ptr %l20, !tbaa !29
  %t244 = load ptr, ptr %l20, !tbaa !29
  %t247 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t244)
  store i32 %t247, ptr %l155
  br label %bb57
bb57:
  %t248 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t249 = load i32, ptr %l155, !tbaa !23
  %t251 = icmp ne i32 %t249, %t248
  br i1 %t251, label %bb58, label %bb59
bb58:
  %t253 = load ptr, ptr %l0, !tbaa !29
  store ptr %t253, ptr %l158, !tbaa !29
  %t254 = load %"compiler/source:Span", ptr %l18
  store %"compiler/source:Span" %t254, ptr %l159
  %t255 = load %"compiler/source:Span", ptr %l18
  store %"compiler/source:Span" %t255, ptr %l160
  %t256 = load ptr, ptr %l20, !tbaa !29
  %t259 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t256)
  store i32 %t259, ptr %l163
  br label %bb60
bb59:
  br label %bb70
bb60:
  %t260 = load ptr, ptr %l20, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t261
  %t262 = getelementptr { i64, [3 x i64] }, ptr %t261, i32 0, i32 0
  store i64 2, ptr %t262
  %t264 = insertvalue { ptr } undef, ptr %t260, 0
  %t265 = getelementptr { i64, [3 x i64] }, ptr %t261, i32 0, i32 1
  store { ptr } %t264, ptr %t265
  %t266 = load { i64, [3 x i64] }, ptr %t261
  %t268 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t266, ptr %t268
  store ptr %t268, ptr %l166, !tbaa !29
  %t269 = icmp sge i64 0, 0
  br i1 %t269, label %bb61, label %bb62
bb61:
  %t271 = icmp sle i64 0, 1152921504606846975
  br i1 %t271, label %bb63, label %bb64
bb62:
  call void @__olang_check_failed(ptr @olang_loc_da760de622febe3_df78aa298e2a00e7)
  unreachable
bb63:
  %t273 = mul i64 0, 8
  %t274 = insertvalue { i64, ptr } undef, i64 0, 0
  %t275 = insertvalue { i64, ptr } %t274, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t275, ptr %l169, !tbaa !27
  %t276 = icmp sge i64 0, 0
  br i1 %t276, label %bb65, label %bb66
bb64:
  call void @__olang_check_failed(ptr @olang_loc_da760de622febe3_df78aa298e2a00e7)
  unreachable
bb65:
  %t278 = icmp sle i64 0, 1152921504606846975
  br i1 %t278, label %bb67, label %bb68
bb66:
  call void @__olang_check_failed(ptr @olang_loc_da760de622febe3_df78aa298e2a00e7)
  unreachable
bb67:
  %t280 = mul i64 0, 8
  %t281 = insertvalue { i64, ptr } undef, i64 0, 0
  %t282 = insertvalue { i64, ptr } %t281, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t283 = load ptr, ptr %l158, !tbaa !29
  %t284 = load %"compiler/source:Span", ptr %l159
  %t285 = load %"compiler/source:Span", ptr %l160
  %t286 = load i32, ptr %l163, !tbaa !23
  %t287 = load ptr, ptr %l166, !tbaa !29
  %t288 = load { i64, ptr }, ptr %l169, !tbaa !27
  %t290 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t283, %"compiler/source:Span" %t284, %"compiler/source:Span" %t285, i32 %t286, ptr %t287, i64 -1, ptr null, { i64, ptr } %t288, { i64, ptr } %t282)
  store ptr %t290, ptr %l173
  br label %bb69
bb68:
  call void @__olang_check_failed(ptr @olang_loc_da760de622febe3_df78aa298e2a00e7)
  unreachable
bb69:
  %t291 = load ptr, ptr %l173, !tbaa !29
  store ptr %t291, ptr %l16, !tbaa !29
  br label %bb70
bb70:
  br label %bb100
bb71:
  %t293 = load ptr, ptr %l11, !tbaa !29
  store ptr %t293, ptr %l175, !tbaa !29
  store i1 false, ptr %l176, !tbaa !21
  %t294 = load ptr, ptr %l175, !tbaa !29
  %t295 = icmp ne ptr %t294, null
  br i1 %t295, label %bb72, label %bb73
bb72:
  %t297 = load ptr, ptr %l175, !tbaa !29
  %t298 = load i64, ptr %t297, !range !{i64 0, i64 30}
  %t300 = icmp eq i64 %t298, 12
  store i1 %t300, ptr %l176, !tbaa !21
  br label %bb73
bb73:
  %t301 = load i1, ptr %l176, !tbaa !21
  br i1 %t301, label %bb74, label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb78
bb76:
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t303 = load ptr, ptr %l11, !tbaa !29
  %t305 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t309 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %v0, ptr %t302, ptr %t303, i32 %t305)
  store ptr %t309, ptr %l183
  br label %bb77
bb77:
  %t310 = load ptr, ptr %l183, !tbaa !29
  store ptr %t310, ptr %l16, !tbaa !29
  br label %bb100
bb78:
  %t312 = load ptr, ptr %l11, !tbaa !29
  store ptr %t312, ptr %l185, !tbaa !29
  store i1 false, ptr %l186, !tbaa !21
  %t313 = load ptr, ptr %l185, !tbaa !29
  %t314 = icmp ne ptr %t313, null
  br i1 %t314, label %bb79, label %bb80
bb79:
  %t316 = load ptr, ptr %l185, !tbaa !29
  %t317 = load i64, ptr %t316, !range !{i64 0, i64 30}
  %t319 = icmp eq i64 %t317, 4
  store i1 %t319, ptr %l186, !tbaa !21
  br label %bb80
bb80:
  %t320 = load i1, ptr %l186, !tbaa !21
  br i1 %t320, label %bb81, label %bb82
bb81:
  %t321 = load ptr, ptr %l11, !tbaa !29
  %t323 = getelementptr { i64, [4 x i64] }, ptr %t321, i32 0, i32 1
  %t324 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t323, i32 0, i32 1
  %t325 = load i32, ptr %t324, !range !{i32 0, i32 98}
  store i32 %t325, ptr %l21
  %t327 = load ptr, ptr %l11, !tbaa !29
  %t329 = getelementptr { i64, [4 x i64] }, ptr %t327, i32 0, i32 1
  %t330 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t329, i32 0, i32 2
  %t331 = load ptr, ptr %t330
  store ptr %t331, ptr %l22, !tbaa !29
  br label %bb83
bb82:
  br label %bb91
bb83:
  %t333 = load i32, ptr %l21, !range !{i32 0, i32 98}
  %t335 = trunc i64 80 to i32
  %t336 = icmp eq i32 %t333, %t335
  br i1 %t336, label %bb84, label %bb85
bb84:
  %t338 = load ptr, ptr %l22, !tbaa !29
  %t340 = call i1 @compiler_2fcheck_2ecallLike(ptr %v2, ptr %t338)
  store i1 %t340, ptr %l197
  br label %bb86
bb85:
  store i1 false, ptr %l195, !tbaa !21
  br label %bb87
bb86:
  %t341 = load i1, ptr %l197, !tbaa !21
  store i1 %t341, ptr %l195, !tbaa !21
  br label %bb87
bb87:
  %t342 = load i1, ptr %l195, !tbaa !21
  br i1 %t342, label %bb88, label %bb89
bb88:
  store i1 true, ptr %l17, !tbaa !21
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t344 = load ptr, ptr %l11, !tbaa !29
  %t346 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t350 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %v0, ptr %t343, ptr %t344, i32 %t346)
  store ptr %t350, ptr %l202
  br label %bb90
bb89:
  br label %bb91
bb90:
  %t351 = load ptr, ptr %l202, !tbaa !29
  store ptr %t351, ptr %l16, !tbaa !29
  br label %bb100
bb91:
  br i1 true, label %bb92, label %bb93
bb92:
  br label %bb94
bb93:
  br label %bb99
bb94:
  store %olang.scope zeroinitializer, ptr %s15
  %t353 = load ptr, ptr %l0, !tbaa !29
  store ptr %t353, ptr %l204, !tbaa !29
  %t354 = load ptr, ptr %l11, !tbaa !29
  %t356 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t354)
  store %"compiler/source:Span" %t356, ptr %l206
  br label %bb95
bb95:
  %t357 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpawnNotCall(ptr %s15)
  store %"compiler/diagmsg:Msg" %t357, ptr %l207
  br label %bb96
bb96:
  %t358 = load ptr, ptr %l204, !tbaa !29
  %t359 = load %"compiler/source:Span", ptr %l206
  %t360 = load %"compiler/diagmsg:Msg", ptr %l207
  %t361 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s15, ptr %t358, %"compiler/source:Span" %t359, %"compiler/diagmsg:Msg" %t360)
  store i64 %t361, ptr %l208
  br label %bb97
bb97:
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t363 = load ptr, ptr %l11, !tbaa !29
  %t365 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t369 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %v0, ptr %t362, ptr %t363, i32 %t365)
  store ptr %t369, ptr %l213
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s15)
  br label %bb100
bb99:
  call void @__olang_check_failed(ptr @olang_loc_5ca7d448b00003f5_5d17299a767670c1)
  unreachable
bb100:
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t372 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t370)
  store ptr %t372, ptr %l215
  br label %bb101
bb101:
  %t373 = load ptr, ptr %l215, !tbaa !29
  store ptr %t373, ptr %l4, !tbaa !29
  %t374 = load ptr, ptr %l4, !tbaa !29
  store ptr %t374, ptr %l216, !tbaa !29
  %t375 = load ptr, ptr %l216, !tbaa !29
  %t376 = getelementptr %"compiler/check:frame", ptr %t375, i32 0, i32 15
  %t377 = load i64, ptr %t376, !tbaa !24
  %t379 = sub i64 %t377, 1
  %t381 = load ptr, ptr %l216, !tbaa !29
  %t382 = getelementptr %"compiler/check:frame", ptr %t381, i32 0, i32 15
  store i64 %t379, ptr %t382, !tbaa !24
  %t383 = load i1, ptr %l10, !tbaa !21
  br i1 %t383, label %bb102, label %bb103
bb102:
  %t385 = load ptr, ptr %l16, !tbaa !29
  %t387 = icmp eq ptr %t385, null
  %t389 = xor i1 %t387, true
  store i1 %t389, ptr %l220, !tbaa !21
  br label %bb104
bb103:
  store i1 false, ptr %l220, !tbaa !21
  br label %bb104
bb104:
  %t391 = load i1, ptr %l220, !tbaa !21
  br i1 %t391, label %bb105, label %bb106
bb105:
  %t392 = load ptr, ptr %l0, !tbaa !29
  store ptr %t392, ptr %l224, !tbaa !29
  %t393 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t393, ptr %l225, !tbaa !27
  %t394 = load i64, ptr %l15, !tbaa !24
  store i64 %t394, ptr %l226, !tbaa !24
  %t395 = load ptr, ptr %l4, !tbaa !29
  %t397 = getelementptr %"compiler/check:frame", ptr %t395, i32 0, i32 28
  %t399 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t397)
  store i64 %t399, ptr %l229
  br label %bb107
bb106:
  br label %bb109
bb107:
  %t400 = load ptr, ptr %l224, !tbaa !29
  %t401 = load { i64, ptr }, ptr %l225, !tbaa !27
  %t402 = load i64, ptr %l226, !tbaa !24
  %t403 = load i64, ptr %l229, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eproduced(ptr %v0, ptr %v2, ptr %t400, { i64, ptr } %t401, i64 %t402, i64 %t403)
  br label %bb108
bb108:
  br label %bb109
bb109:
  %t404 = load ptr, ptr %l4, !tbaa !29
  %t406 = getelementptr %"compiler/check:frame", ptr %t404, i32 0, i32 28
  %t407 = load i64, ptr %l15, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t406, i64 %t407)
  br label %bb110
bb110:
  %t410 = load ptr, ptr %l16, !tbaa !29
  %t412 = icmp eq ptr %t410, null
  br i1 %t412, label %bb111, label %bb112
bb111:
  %t414 = load ptr, ptr %l0, !tbaa !29
  store ptr %t414, ptr %l235, !tbaa !29
  %t415 = load ptr, ptr %l235, !tbaa !29
  %t416 = getelementptr %"compiler/check:Checker", ptr %t415, i32 0, i32 41
  %t417 = load i64, ptr %t416, !tbaa !24
  %t419 = sub i64 %t417, 1
  %t421 = load ptr, ptr %l235, !tbaa !29
  %t422 = getelementptr %"compiler/check:Checker", ptr %t421, i32 0, i32 41
  store i64 %t419, ptr %t422, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb112:
  br label %bb113
bb113:
  %t423 = load ptr, ptr %l16, !tbaa !29
  %t425 = call i1 @compiler_2fcheck_2edispatched(ptr %v0, ptr %t423)
  store i1 %t425, ptr %l239
  br label %bb114
bb114:
  %t426 = load i1, ptr %l239, !tbaa !21
  br i1 %t426, label %bb115, label %bb116
bb115:
  %t427 = load ptr, ptr %l0, !tbaa !29
  store ptr %t427, ptr %l240, !tbaa !29
  %t428 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t428, ptr %l241, !tbaa !27
  %t429 = load ptr, ptr %l3, !tbaa !29
  store ptr %t429, ptr %l242, !tbaa !29
  %t430 = load ptr, ptr %l11, !tbaa !29
  store ptr %t430, ptr %l243, !tbaa !29
  %t431 = load ptr, ptr %l16, !tbaa !29
  %t434 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t431)
  store i32 %t434, ptr %l246
  br label %bb117
bb116:
  br label %bb119
bb117:
  %t435 = load ptr, ptr %l240, !tbaa !29
  %t436 = load { i64, ptr }, ptr %l241, !tbaa !27
  %t437 = load ptr, ptr %l242, !tbaa !29
  %t438 = load ptr, ptr %l243, !tbaa !29
  %t439 = load i32, ptr %l246, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanySpawned(ptr %v0, ptr %v1, ptr %v2, ptr %v2, ptr %t435, { i64, ptr } %t436, ptr %t437, ptr %t438, i32 %t439)
  br label %bb118
bb118:
  %t440 = load ptr, ptr %l0, !tbaa !29
  store ptr %t440, ptr %l247, !tbaa !29
  %t441 = load ptr, ptr %l247, !tbaa !29
  %t442 = getelementptr %"compiler/check:Checker", ptr %t441, i32 0, i32 41
  %t443 = load i64, ptr %t442, !tbaa !24
  %t445 = sub i64 %t443, 1
  %t447 = load ptr, ptr %l247, !tbaa !29
  %t448 = getelementptr %"compiler/check:Checker", ptr %t447, i32 0, i32 41
  store i64 %t445, ptr %t448, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb119:
  %t449 = load ptr, ptr %l0, !tbaa !29
  %t451 = getelementptr %"compiler/check:Checker", ptr %t449, i32 0, i32 1
  %t452 = load ptr, ptr %t451, !tbaa !29
  %t454 = getelementptr %"compiler/generic:Program", ptr %t452, i32 0, i32 2
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t457 = getelementptr %"compiler/check:Checker", ptr %t455, i32 0, i32 42
  %t458 = load i32, ptr %t457, !tbaa !23
  %t461 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t454, i32 %t458)
  store { i64, ptr } %t461, ptr %l255
  br label %bb120
bb120:
  %t462 = load { i64, ptr }, ptr %l255, !tbaa !27
  store { i64, ptr } %t462, ptr %l23, !tbaa !27
  %t463 = load i1, ptr %l17, !tbaa !21
  br i1 %t463, label %bb121, label %bb122
bb121:
  %t465 = icmp sge i64 0, 0
  br i1 %t465, label %bb123, label %bb124
bb122:
  br label %bb127
bb123:
  %t467 = icmp sle i64 0, 2305843009213693951
  br i1 %t467, label %bb125, label %bb126
bb124:
  call void @__olang_check_failed(ptr @olang_loc_a0a2b29f181c5519_be518ce768fc1fe5)
  unreachable
bb125:
  %t469 = mul i64 0, 4
  %t470 = insertvalue { i64, ptr } undef, i64 0, 0
  %t471 = insertvalue { i64, ptr } %t470, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t471, ptr %l23, !tbaa !27
  br label %bb127
bb126:
  call void @__olang_check_failed(ptr @olang_loc_a0a2b29f181c5519_be518ce768fc1fe5)
  unreachable
bb127:
  %t473 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t475 = extractvalue { i64, ptr } %t473, 0
  %t477 = icmp sgt i64 %t475, 0
  br i1 %t477, label %bb128, label %bb129
bb128:
  %t479 = load i1, ptr %l10, !tbaa !21
  %t481 = xor i1 %t479, true
  store i1 %t481, ptr %l263, !tbaa !21
  br label %bb130
bb129:
  store i1 false, ptr %l263, !tbaa !21
  br label %bb130
bb130:
  %t483 = load i1, ptr %l263, !tbaa !21
  br i1 %t483, label %bb131, label %bb132
bb131:
  store %olang.scope zeroinitializer, ptr %s22
  %t484 = load ptr, ptr %l0, !tbaa !29
  store ptr %t484, ptr %l266, !tbaa !29
  %t485 = load ptr, ptr %l11, !tbaa !29
  %t487 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t485)
  store %"compiler/source:Span" %t487, ptr %l268
  br label %bb133
bb132:
  br label %bb136
bb133:
  %t488 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpawnFallible(ptr %s22)
  store %"compiler/diagmsg:Msg" %t488, ptr %l269
  br label %bb134
bb134:
  %t489 = load ptr, ptr %l266, !tbaa !29
  %t490 = load %"compiler/source:Span", ptr %l268
  %t491 = load %"compiler/diagmsg:Msg", ptr %l269
  %t492 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s22, ptr %t489, %"compiler/source:Span" %t490, %"compiler/diagmsg:Msg" %t491)
  store i64 %t492, ptr %l270
  br label %bb135
bb135:
  %t493 = load ptr, ptr %l4, !tbaa !29
  store ptr %t493, ptr %l271, !tbaa !29
  %t494 = load ptr, ptr %l271, !tbaa !29
  %t495 = getelementptr %"compiler/check:frame", ptr %t494, i32 0, i32 41
  %t496 = load i64, ptr %t495, !tbaa !24
  %t498 = add i64 %t496, 1
  %t500 = load ptr, ptr %l271, !tbaa !29
  %t501 = getelementptr %"compiler/check:frame", ptr %t500, i32 0, i32 41
  store i64 %t498, ptr %t501, !tbaa !24
  call void @__olang_scope_close(ptr %s22)
  br label %bb136
bb136:
  %t502 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t504 = extractvalue { i64, ptr } %t502, 0
  %t506 = icmp eq i64 %t504, 0
  br i1 %t506, label %bb137, label %bb138
bb137:
  %t508 = load i1, ptr %l10, !tbaa !21
  store i1 %t508, ptr %l277, !tbaa !21
  br label %bb139
bb138:
  store i1 false, ptr %l277, !tbaa !21
  br label %bb139
bb139:
  %t510 = load i1, ptr %l277, !tbaa !21
  br i1 %t510, label %bb140, label %bb141
bb140:
  store %olang.scope zeroinitializer, ptr %s23
  %t511 = load ptr, ptr %l0, !tbaa !29
  store ptr %t511, ptr %l279, !tbaa !29
  %t512 = load ptr, ptr %l3, !tbaa !29
  %t514 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t512)
  store %"compiler/source:Span" %t514, ptr %l281
  br label %bb142
bb141:
  br label %bb145
bb142:
  %t515 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpawnTryInfallible(ptr %s23)
  store %"compiler/diagmsg:Msg" %t515, ptr %l282
  br label %bb143
bb143:
  %t516 = load ptr, ptr %l279, !tbaa !29
  %t517 = load %"compiler/source:Span", ptr %l281
  %t518 = load %"compiler/diagmsg:Msg", ptr %l282
  %t519 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s23, ptr %t516, %"compiler/source:Span" %t517, %"compiler/diagmsg:Msg" %t518)
  store i64 %t519, ptr %l283
  br label %bb144
bb144:
  call void @__olang_scope_close(ptr %s23)
  br label %bb145
bb145:
  %t520 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aTaskClause_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t520, ptr %l284
  br label %bb146
bb146:
  %t521 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l284
  %t522 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t521, ptr %t522
  store ptr %t522, ptr %l24, !tbaa !29
  %t524 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t524, ptr %l286
  br label %bb147
bb147:
  %t525 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l286
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t525, ptr %l25
  %t526 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t528 = extractvalue { i64, ptr } %t526, 0
  %t530 = icmp sgt i64 %t528, 0
  br i1 %t530, label %bb148, label %bb149
bb148:
  store %olang.scope zeroinitializer, ptr %s24
  %t532 = load ptr, ptr %l16, !tbaa !29
  %t535 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t532)
  store i32 %t535, ptr %l292
  br label %bb150
bb149:
  br label %bb233
bb150:
  %t536 = load i32, ptr %l292, !tbaa !23
  store i32 %t536, ptr %l26, !tbaa !23
  %t537 = load ptr, ptr %l5, !tbaa !29
  %t539 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eL_H6a486a18542e18ee3475c3237c5a5335(ptr %v0, ptr %t537)
  store i64 %t539, ptr %l294
  br label %bb151
bb151:
  %t540 = load i64, ptr %l294, !tbaa !24
  %t541 = icmp eq i64 %t540, 1
  br i1 %t541, label %bb152, label %bb153
bb152:
  %t543 = load ptr, ptr %l5, !tbaa !29
  %t545 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eA_Hf8c35f4f5353320ac1e6ff0719acdfb7(ptr %v0, ptr %s24, ptr %t543, i64 0)
  store ptr %t545, ptr %l298
  br label %bb154
bb153:
  store i1 false, ptr %l296, !tbaa !21
  br label %bb155
bb154:
  %t546 = load ptr, ptr %l298, !tbaa !29
  %t547 = icmp eq ptr %t546, null
  %t549 = xor i1 %t547, true
  store i1 %t549, ptr %l296, !tbaa !21
  br label %bb155
bb155:
  %t551 = load i1, ptr %l296, !tbaa !21
  br i1 %t551, label %bb156, label %bb157
bb156:
  %t552 = load ptr, ptr %l5, !tbaa !29
  %t554 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eA_Hf8c35f4f5353320ac1e6ff0719acdfb7(ptr %v0, ptr %v0, ptr %t552, i64 0)
  store ptr %t554, ptr %l302
  br label %bb158
bb157:
  br label %bb181
bb158:
  %t555 = load ptr, ptr %l302, !tbaa !29
  store ptr %t555, ptr %l27, !tbaa !29
  %t556 = load ptr, ptr %l27, !tbaa !29
  %t558 = icmp eq ptr %t556, null
  br i1 %t558, label %bb159, label %bb160
bb159:
  call void @__olang_check_failed(ptr @olang_loc_ebab815881a318c_398bac8a238c0b80)
  unreachable
bb160:
  br label %bb161
bb161:
  %t560 = load ptr, ptr %l27, !tbaa !29
  %t562 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %t560)
  store i32 %t562, ptr %l306
  br label %bb162
bb162:
  %t563 = load i32, ptr %l306, !tbaa !23
  store i32 %t563, ptr %l28, !tbaa !23
  %t564 = load ptr, ptr %l0, !tbaa !29
  %t565 = load i32, ptr %l26, !tbaa !23
  %t568 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t564, i32 %t565)
  store i1 %t568, ptr %l309
  br label %bb163
bb163:
  %t569 = load i1, ptr %l309, !tbaa !21
  br i1 %t569, label %bb164, label %bb165
bb164:
  %t570 = load ptr, ptr %l0, !tbaa !29
  %t571 = load i32, ptr %l28, !tbaa !23
  %t574 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t570, i32 %t571)
  store i1 %t574, ptr %l313
  br label %bb166
bb165:
  store i1 false, ptr %l310, !tbaa !21
  br label %bb167
bb166:
  %t575 = load i1, ptr %l313, !tbaa !21
  store i1 %t575, ptr %l310, !tbaa !21
  br label %bb167
bb167:
  %t576 = load i1, ptr %l310, !tbaa !21
  br i1 %t576, label %bb168, label %bb169
bb168:
  %t577 = load ptr, ptr %l0, !tbaa !29
  %t579 = getelementptr %"compiler/check:Checker", ptr %t577, i32 0, i32 1
  %t580 = load ptr, ptr %t579, !tbaa !29
  %t582 = getelementptr %"compiler/generic:Program", ptr %t580, i32 0, i32 2
  %t583 = load i32, ptr %l28, !tbaa !23
  %t586 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t582, i32 %t583)
  store i1 %t586, ptr %l319
  br label %bb170
bb169:
  store i1 false, ptr %l314, !tbaa !21
  br label %bb171
bb170:
  %t587 = load i1, ptr %l319, !tbaa !21
  store i1 %t587, ptr %l314, !tbaa !21
  br label %bb171
bb171:
  %t588 = load i1, ptr %l314, !tbaa !21
  br i1 %t588, label %bb172, label %bb173
bb172:
  %t589 = load ptr, ptr %l0, !tbaa !29
  %t591 = getelementptr %"compiler/check:Checker", ptr %t589, i32 0, i32 1
  %t592 = load ptr, ptr %t591, !tbaa !29
  %t594 = getelementptr %"compiler/generic:Program", ptr %t592, i32 0, i32 2
  %t595 = load i32, ptr %l28, !tbaa !23
  %t598 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t594, i32 %t595)
  store i32 %t598, ptr %l325
  br label %bb174
bb173:
  store i1 false, ptr %l320, !tbaa !21
  br label %bb176
bb174:
  %t599 = load ptr, ptr %l0, !tbaa !29
  %t601 = getelementptr %"compiler/check:Checker", ptr %t599, i32 0, i32 1
  %t602 = load ptr, ptr %t601, !tbaa !29
  %t604 = getelementptr %"compiler/generic:Program", ptr %t602, i32 0, i32 2
  %t605 = load i32, ptr %l26, !tbaa !23
  %t608 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t604, i32 %t605)
  store i32 %t608, ptr %l330
  br label %bb175
bb175:
  %t609 = load i32, ptr %l325, !tbaa !23
  %t610 = load i32, ptr %l330, !tbaa !23
  %t611 = icmp eq i32 %t609, %t610
  store i1 %t611, ptr %l320, !tbaa !21
  br label %bb176
bb176:
  %t613 = load i1, ptr %l320, !tbaa !21
  br i1 %t613, label %bb177, label %bb178
bb177:
  %t614 = load ptr, ptr %l0, !tbaa !29
  %t616 = getelementptr %"compiler/check:Checker", ptr %t614, i32 0, i32 1
  %t617 = load ptr, ptr %t616, !tbaa !29
  %t619 = getelementptr %"compiler/generic:Program", ptr %t617, i32 0, i32 2
  %t620 = load i32, ptr %l26, !tbaa !23
  %t623 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t619, i32 %t620)
  store i32 %t623, ptr %l336
  br label %bb179
bb178:
  br label %bb180
bb179:
  %t624 = load i32, ptr %l336, !tbaa !23
  store i32 %t624, ptr %l26, !tbaa !23
  br label %bb180
bb180:
  br label %bb181
bb181:
  %t625 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t625, ptr %l29, !tbaa !27
  store i64 0, ptr %l30, !tbaa !24
  %t627 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t629 = extractvalue { i64, ptr } %t627, 0
  store i64 %t629, ptr %l31, !tbaa !24
  br label %bb182
bb182:
  store %olang.scope zeroinitializer, ptr %s28
  %t631 = load i64, ptr %l30, !tbaa !24
  %t632 = load i64, ptr %l31, !tbaa !24
  %t635 = icmp slt i64 %t631, %t632
  %t637 = xor i1 %t635, true
  br i1 %t637, label %bb183, label %bb184
bb183:
  call void @__olang_scope_close(ptr %s28)
  br label %bb232
bb184:
  br label %bb185
bb185:
  %t639 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t639, ptr %l344, !tbaa !27
  %t640 = load i64, ptr %l30, !tbaa !24
  %t642 = getelementptr { i64, ptr }, ptr %l344, i32 0, i32 1
  %t643 = load ptr, ptr %t642, !tbaa !27
  %t644 = getelementptr ptr, ptr %t643, i64 %t640
  %t645 = load ptr, ptr %t644, !tbaa !39
  store ptr %t645, ptr %l32, !tbaa !29
  %t647 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ector(ptr %s28, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t647, ptr %l347
  br label %bb186
bb186:
  %t648 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l347
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t648, ptr %l33
  %t649 = load ptr, ptr %l0, !tbaa !29
  %t650 = load ptr, ptr %l32, !tbaa !29
  %t653 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloneBinding(ptr %v0, ptr %v2, ptr %t649, ptr %t650)
  store i1 %t653, ptr %l350
  br label %bb187
bb187:
  %t654 = load i1, ptr %l350, !tbaa !21
  store i1 %t654, ptr %l34, !tbaa !21
  %t655 = load ptr, ptr %l32, !tbaa !29
  %t657 = getelementptr %"compiler/ast:Catch", ptr %t655, i32 0, i32 1
  %t658 = load { i64, ptr }, ptr %t657, !tbaa !27
  %t660 = extractvalue { i64, ptr } %t658, 0
  %t662 = icmp sgt i64 %t660, 0
  br i1 %t662, label %bb188, label %bb189
bb188:
  %t664 = load i1, ptr %l34, !tbaa !21
  %t666 = xor i1 %t664, true
  store i1 %t666, ptr %l355, !tbaa !21
  br label %bb190
bb189:
  store i1 false, ptr %l355, !tbaa !21
  br label %bb190
bb190:
  %t668 = load i1, ptr %l355, !tbaa !21
  br i1 %t668, label %bb191, label %bb192
bb191:
  %t669 = load ptr, ptr %l32, !tbaa !29
  %t671 = getelementptr %"compiler/ast:Catch", ptr %t669, i32 0, i32 1
  %t672 = load { i64, ptr }, ptr %t671, !tbaa !27
  store { i64, ptr } %t672, ptr %l35, !tbaa !27
  store i64 0, ptr %l36, !tbaa !24
  %t674 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t676 = extractvalue { i64, ptr } %t674, 0
  store i64 %t676, ptr %l37, !tbaa !24
  br label %bb193
bb192:
  br label %bb200
bb193:
  %t678 = load i64, ptr %l36, !tbaa !24
  %t679 = load i64, ptr %l37, !tbaa !24
  %t682 = icmp slt i64 %t678, %t679
  %t684 = xor i1 %t682, true
  br i1 %t684, label %bb194, label %bb195
bb194:
  br label %bb199
bb195:
  br label %bb196
bb196:
  %t686 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t686, ptr %l366, !tbaa !27
  %t687 = load i64, ptr %l36, !tbaa !24
  %t689 = getelementptr { i64, ptr }, ptr %l366, i32 0, i32 1
  %t690 = load ptr, ptr %t689, !tbaa !27
  %t691 = getelementptr ptr, ptr %t690, i64 %t687
  %t692 = load ptr, ptr %t691, !tbaa !39
  %t694 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchItem(ptr %v0, ptr %v2, ptr %s28, ptr %t694, ptr %t692, ptr %l33)
  br label %bb197
bb197:
  br label %bb198
bb198:
  %t699 = load i64, ptr %l36, !tbaa !24
  %t701 = add i64 %t699, 1
  store i64 %t701, ptr %l36, !tbaa !24
  br label %bb193
bb199:
  br label %bb200
bb200:
  %t703 = load ptr, ptr %l32, !tbaa !29
  %t705 = getelementptr %"compiler/ast:Catch", ptr %t703, i32 0, i32 5
  %t706 = load i32, ptr %t705, !tbaa !23
  %t708 = icmp ne i32 %t706, 0
  br i1 %t708, label %bb201, label %bb202
bb201:
  store i1 true, ptr %l377, !tbaa !21
  br label %bb203
bb202:
  %t710 = load i1, ptr %l34, !tbaa !21
  store i1 %t710, ptr %l377, !tbaa !21
  br label %bb203
bb203:
  %t712 = load i1, ptr %l377, !tbaa !21
  br i1 %t712, label %bb204, label %bb205
bb204:
  store %olang.scope zeroinitializer, ptr %s33
  %t713 = load ptr, ptr %l0, !tbaa !29
  store ptr %t713, ptr %l379, !tbaa !29
  %t714 = load i1, ptr %l34, !tbaa !21
  br i1 %t714, label %bb206, label %bb207
bb205:
  br label %bb215
bb206:
  %t716 = load ptr, ptr %l32, !tbaa !29
  %t718 = getelementptr %"compiler/ast:Catch", ptr %t716, i32 0, i32 1
  %t719 = load { i64, ptr }, ptr %t718, !tbaa !27
  store { i64, ptr } %t719, ptr %l383, !tbaa !27
  %t720 = getelementptr { i64, ptr }, ptr %l383, i32 0, i32 1
  %t721 = load ptr, ptr %t720, !tbaa !27
  %t722 = getelementptr ptr, ptr %t721, i64 0
  %t723 = load ptr, ptr %t722, !tbaa !39
  %t725 = getelementptr %"compiler/ast:Path", ptr %t723, i32 0, i32 0
  %t726 = load %"compiler/source:Span", ptr %t725
  store %"compiler/source:Span" %t726, ptr %l381
  br label %bb208
bb207:
  %t728 = load ptr, ptr %l32, !tbaa !29
  %t730 = getelementptr %"compiler/ast:Catch", ptr %t728, i32 0, i32 6
  %t731 = load %"compiler/source:Span", ptr %t730
  store %"compiler/source:Span" %t731, ptr %l381
  br label %bb208
bb208:
  %t733 = load ptr, ptr %l0, !tbaa !29
  store ptr %t733, ptr %l388, !tbaa !29
  %t734 = load i1, ptr %l34, !tbaa !21
  br i1 %t734, label %bb209, label %bb210
bb209:
  %t736 = load ptr, ptr %l32, !tbaa !29
  %t738 = getelementptr %"compiler/ast:Catch", ptr %t736, i32 0, i32 1
  %t739 = load { i64, ptr }, ptr %t738, !tbaa !27
  store { i64, ptr } %t739, ptr %l392, !tbaa !27
  %t740 = getelementptr { i64, ptr }, ptr %l392, i32 0, i32 1
  %t741 = load ptr, ptr %t740, !tbaa !27
  %t742 = getelementptr ptr, ptr %t741, i64 0
  %t743 = load ptr, ptr %t742, !tbaa !39
  %t745 = getelementptr %"compiler/ast:Path", ptr %t743, i32 0, i32 1
  %t746 = load { i64, ptr }, ptr %t745, !tbaa !27
  store { i64, ptr } %t746, ptr %l394, !tbaa !27
  %t747 = getelementptr { i64, ptr }, ptr %l394, i32 0, i32 1
  %t748 = load ptr, ptr %t747, !tbaa !27
  %t749 = getelementptr i32, ptr %t748, i64 0
  %t750 = load i32, ptr %t749, !tbaa !33
  store i32 %t750, ptr %l390, !tbaa !23
  br label %bb211
bb210:
  %t752 = load ptr, ptr %l32, !tbaa !29
  %t754 = getelementptr %"compiler/ast:Catch", ptr %t752, i32 0, i32 5
  %t755 = load i32, ptr %t754, !tbaa !23
  store i32 %t755, ptr %l390, !tbaa !23
  br label %bb211
bb211:
  %t757 = load ptr, ptr %l388, !tbaa !29
  %t758 = load i32, ptr %l390, !tbaa !23
  %t759 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s33, ptr %t757, i32 %t758)
  store { i64, ptr } %t759, ptr %l398
  br label %bb212
bb212:
  %t760 = load { i64, ptr }, ptr %l398, !tbaa !27
  %t761 = extractvalue { i64, ptr } %t760, 0
  %t762 = extractvalue { i64, ptr } %t760, 1
  %t763 = mul i64 %t761, 1
  %t764 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t763)
  call void @llvm.memcpy.p0.p0.i64(ptr %t764, ptr %t762, i64 %t763, i1 false)
  %t765 = insertvalue { i64, ptr } undef, i64 %t761, 0
  %t766 = insertvalue { i64, ptr } %t765, ptr %t764, 1
  %t768 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCatchNameInTask(ptr %s33, ptr %s33, { i64, ptr } %t766)
  store %"compiler/diagmsg:Msg" %t768, ptr %l400
  br label %bb213
bb213:
  %t769 = load ptr, ptr %l379, !tbaa !29
  %t770 = load %"compiler/source:Span", ptr %l381
  %t771 = load %"compiler/diagmsg:Msg", ptr %l400
  %t772 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s33, ptr %t769, %"compiler/source:Span" %t770, %"compiler/diagmsg:Msg" %t771)
  store i64 %t772, ptr %l401
  br label %bb214
bb214:
  call void @__olang_scope_close(ptr %s33)
  br label %bb215
bb215:
  %t773 = load ptr, ptr %l32, !tbaa !29
  %t775 = getelementptr %"compiler/ast:Catch", ptr %t773, i32 0, i32 1
  %t776 = load { i64, ptr }, ptr %t775, !tbaa !27
  %t778 = extractvalue { i64, ptr } %t776, 0
  %t780 = icmp eq i64 %t778, 0
  br i1 %t780, label %bb216, label %bb217
bb216:
  store i1 true, ptr %l406, !tbaa !21
  br label %bb218
bb217:
  %t782 = load i1, ptr %l34, !tbaa !21
  store i1 %t782, ptr %l406, !tbaa !21
  br label %bb218
bb218:
  %t784 = load i1, ptr %l406, !tbaa !21
  store i1 %t784, ptr %l39, !tbaa !21
  %t785 = load ptr, ptr %l24, !tbaa !29
  store ptr %t785, ptr %l408, !tbaa !29
  %t786 = load ptr, ptr %l32, !tbaa !29
  %t788 = getelementptr %"compiler/ast:Catch", ptr %t786, i32 0, i32 0
  %t789 = load %"compiler/source:Span", ptr %t788
  store %"compiler/source:Span" %t789, ptr %l410
  %t791 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2eToArray_3ccompiler_2ftyped_3aItem_3e(ptr %s28, ptr %v0, ptr %l33)
  store { i64, ptr } %t791, ptr %l412
  br label %bb219
bb219:
  %t792 = load i1, ptr %l39, !tbaa !21
  store i1 %t792, ptr %l413, !tbaa !21
  %t793 = load ptr, ptr %l0, !tbaa !29
  store ptr %t793, ptr %l414, !tbaa !29
  %t794 = load ptr, ptr %l32, !tbaa !29
  store ptr %t794, ptr %l415, !tbaa !29
  %t795 = load i32, ptr %l26, !tbaa !23
  store i32 %t795, ptr %l416, !tbaa !23
  %t796 = load ptr, ptr %l5, !tbaa !29
  %t798 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eL_H6a486a18542e18ee3475c3237c5a5335(ptr %v0, ptr %t796)
  store i64 %t798, ptr %l418
  br label %bb220
bb220:
  %t799 = load ptr, ptr %l414, !tbaa !29
  %t800 = load ptr, ptr %l415, !tbaa !29
  %t801 = load i32, ptr %l416, !tbaa !23
  %t802 = load i64, ptr %l418, !tbaa !24
  %t803 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclauseHandler(ptr %v0, ptr %v2, ptr %v0, ptr %t799, ptr %t800, i32 %t801, i64 %t802)
  store ptr %t803, ptr %l419
  br label %bb221
bb221:
  %t804 = load %"compiler/source:Span", ptr %l410
  %t805 = load { i64, ptr }, ptr %l412, !tbaa !27
  %t806 = load i1, ptr %l413, !tbaa !21
  %t807 = load ptr, ptr %l419, !tbaa !29
  %t808 = call %"compiler/typed:TaskClause" @compiler_2ftyped_3aTaskClause_2ector(ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t804, { i64, ptr } %t805, i1 %t806, ptr %t807)
  store %"compiler/typed:TaskClause" %t808, ptr %l420
  br label %bb222
bb222:
  %t809 = load %"compiler/typed:TaskClause", ptr %l420
  %t810 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store %"compiler/typed:TaskClause" %t809, ptr %t810
  %t811 = load ptr, ptr %l408, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aTaskClause_26_3e_2e_H70975c58788d810dba7712b4ee87a08c(ptr %v0, ptr %v0, ptr %t811, ptr %t810)
  br label %bb223
bb223:
  store ptr %l25, ptr %l422, !tbaa !29
  %t813 = load ptr, ptr %l32, !tbaa !29
  %t815 = getelementptr %"compiler/ast:Catch", ptr %t813, i32 0, i32 0
  %t816 = load %"compiler/source:Span", ptr %t815
  store %"compiler/source:Span" %t816, ptr %l424
  %t818 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2eToArray_3ccompiler_2ftyped_3aItem_3e(ptr %s28, ptr %s0, ptr %l33)
  store { i64, ptr } %t818, ptr %l426
  br label %bb224
bb224:
  %t819 = load i1, ptr %l39, !tbaa !21
  store i1 %t819, ptr %l427, !tbaa !21
  %t820 = icmp sge i64 0, 0
  br i1 %t820, label %bb225, label %bb226
bb225:
  %t822 = icmp sle i64 0, 1152921504606846975
  br i1 %t822, label %bb227, label %bb228
bb226:
  call void @__olang_check_failed(ptr @olang_loc_e78286934eafcc6f_802ae2752731a35b)
  unreachable
bb227:
  %t824 = mul i64 0, 8
  %t825 = insertvalue { i64, ptr } undef, i64 0, 0
  %t826 = insertvalue { i64, ptr } %t825, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t827 = load %"compiler/source:Span", ptr %l424
  %t828 = load { i64, ptr }, ptr %l426, !tbaa !27
  %t829 = load i1, ptr %l427, !tbaa !21
  %t831 = call %"compiler/typed:Clause" @compiler_2ftyped_3aClause_2ector(ptr %s0, ptr %s0, ptr %s0, ptr %s0, %"compiler/source:Span" %t827, { i64, ptr } %t828, i1 %t829, ptr null, { i64, ptr } %t826, i64 -1, i32 0)
  store %"compiler/typed:Clause" %t831, ptr %l431
  br label %bb229
bb228:
  call void @__olang_check_failed(ptr @olang_loc_e78286934eafcc6f_802ae2752731a35b)
  unreachable
bb229:
  %t832 = load %"compiler/typed:Clause", ptr %l431
  %t833 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 72, i64 8)
  store %"compiler/typed:Clause" %t832, ptr %t833
  %t834 = load ptr, ptr %l422, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ePush_Hc64f4d0e64077a33423ff9c4e583894f(ptr %s0, ptr %s0, ptr %t834, ptr %t833)
  br label %bb230
bb230:
  call void @__olang_scope_close(ptr %s28)
  br label %bb231
bb231:
  %t836 = load i64, ptr %l30, !tbaa !24
  %t838 = add i64 %t836, 1
  store i64 %t838, ptr %l30, !tbaa !24
  br label %bb182
bb232:
  call void @__olang_scope_close(ptr %s24)
  br label %bb233
bb233:
  %t840 = load ptr, ptr %l4, !tbaa !29
  %t842 = getelementptr %"compiler/check:frame", ptr %t840, i32 0, i32 40
  %t844 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t842)
  store i64 %t844, ptr %l437
  br label %bb234
bb234:
  %t845 = load i64, ptr %l437, !tbaa !24
  store i64 %t845, ptr %l40, !tbaa !24
  %t846 = load i1, ptr %l10, !tbaa !21
  br i1 %t846, label %bb235, label %bb236
bb235:
  %t848 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t848, ptr %l41, !tbaa !27
  store i64 0, ptr %l42, !tbaa !24
  %t850 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t852 = extractvalue { i64, ptr } %t850, 0
  store i64 %t852, ptr %l43, !tbaa !24
  br label %bb237
bb236:
  br label %bb244
bb237:
  %t854 = load i64, ptr %l42, !tbaa !24
  %t855 = load i64, ptr %l43, !tbaa !24
  %t858 = icmp slt i64 %t854, %t855
  %t860 = xor i1 %t858, true
  br i1 %t860, label %bb238, label %bb239
bb238:
  br label %bb243
bb239:
  br label %bb240
bb240:
  %t862 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t862, ptr %l446, !tbaa !27
  %t863 = load i64, ptr %l42, !tbaa !24
  %t865 = getelementptr { i64, ptr }, ptr %l446, i32 0, i32 1
  %t866 = load ptr, ptr %t865, !tbaa !27
  %t867 = getelementptr i32, ptr %t866, i64 %t863
  %t868 = load i32, ptr %t867, !tbaa !33
  %t870 = load ptr, ptr %l4, !tbaa !29
  %t872 = getelementptr %"compiler/check:frame", ptr %t870, i32 0, i32 40
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t872, i32 %t868)
  br label %bb241
bb241:
  br label %bb242
bb242:
  %t876 = load i64, ptr %l42, !tbaa !24
  %t878 = add i64 %t876, 1
  store i64 %t878, ptr %l42, !tbaa !24
  br label %bb237
bb243:
  br label %bb244
bb244:
  %t880 = load ptr, ptr %l0, !tbaa !29
  %t881 = load ptr, ptr %l4, !tbaa !29
  %t883 = getelementptr %"compiler/check:frame", ptr %t881, i32 0, i32 40
  %t884 = load i64, ptr %l40, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropTaken(ptr %v0, ptr %v0, ptr %s0, ptr %t880, ptr %t883, i64 %t884, ptr %l25)
  br label %bb245
bb245:
  %t889 = load ptr, ptr %l5, !tbaa !29
  %t891 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eL_H6a486a18542e18ee3475c3237c5a5335(ptr %v0, ptr %t889)
  store i64 %t891, ptr %l460
  br label %bb246
bb246:
  %t892 = load i64, ptr %l460, !tbaa !24
  %t893 = icmp sgt i64 %t892, 0
  br i1 %t893, label %bb247, label %bb248
bb247:
  %t895 = load ptr, ptr %l4, !tbaa !29
  %t897 = getelementptr %"compiler/check:frame", ptr %t895, i32 0, i32 40
  %t899 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t897)
  store i64 %t899, ptr %l465
  br label %bb249
bb248:
  store i1 false, ptr %l462, !tbaa !21
  br label %bb250
bb249:
  %t900 = load i64, ptr %l40, !tbaa !24
  %t901 = load i64, ptr %l465, !tbaa !24
  %t903 = icmp sgt i64 %t901, %t900
  store i1 %t903, ptr %l462, !tbaa !21
  br label %bb250
bb250:
  %t905 = load i1, ptr %l462, !tbaa !21
  br i1 %t905, label %bb251, label %bb252
bb251:
  %t906 = load ptr, ptr %l4, !tbaa !29
  store ptr %t906, ptr %l468, !tbaa !29
  %t907 = load ptr, ptr %l468, !tbaa !29
  %t908 = getelementptr %"compiler/check:frame", ptr %t907, i32 0, i32 33
  %t909 = load i64, ptr %t908, !tbaa !24
  %t911 = add i64 %t909, 1
  %t913 = load ptr, ptr %l468, !tbaa !29
  %t914 = getelementptr %"compiler/check:frame", ptr %t913, i32 0, i32 33
  store i64 %t911, ptr %t914, !tbaa !24
  br label %bb253
bb252:
  br label %bb253
bb253:
  %t915 = load ptr, ptr %l5, !tbaa !29
  %t917 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eL_H6a486a18542e18ee3475c3237c5a5335(ptr %v0, ptr %t915)
  store i64 %t917, ptr %l472
  br label %bb254
bb254:
  %t918 = load i64, ptr %l472, !tbaa !24
  %t919 = icmp sgt i64 %t918, 0
  br i1 %t919, label %bb255, label %bb256
bb255:
  %t921 = load ptr, ptr %l0, !tbaa !29
  store ptr %t921, ptr %l474, !tbaa !29
  %t922 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t922, ptr %l475
  %t923 = load ptr, ptr %l3, !tbaa !29
  store ptr %t923, ptr %l476, !tbaa !29
  %t924 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t924, ptr %l477, !tbaa !27
  %t925 = load ptr, ptr %l5, !tbaa !29
  store ptr %t925, ptr %l478, !tbaa !29
  %t926 = load ptr, ptr %l16, !tbaa !29
  %t929 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t926)
  store i32 %t929, ptr %l481
  br label %bb257
bb256:
  br label %bb259
bb257:
  %t930 = load ptr, ptr %l474, !tbaa !29
  %t931 = load %"compiler/source:Span", ptr %l475
  %t932 = load ptr, ptr %l476, !tbaa !29
  %t933 = load { i64, ptr }, ptr %l477, !tbaa !27
  %t934 = load ptr, ptr %l478, !tbaa !29
  %t935 = load i32, ptr %l481, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espawnTargets(ptr %v0, ptr %v2, ptr %v1, ptr %v0, ptr %t930, %"compiler/source:Span" %t931, ptr %t932, { i64, ptr } %t933, ptr %t934, i32 %t935)
  br label %bb258
bb258:
  br label %bb259
bb259:
  %t936 = load ptr, ptr %l0, !tbaa !29
  store ptr %t936, ptr %l482, !tbaa !29
  %t937 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t937, ptr %l483
  %t938 = load ptr, ptr %l5, !tbaa !29
  %t940 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eT_Hc52cb714df9676093c851daa15f6f747(ptr %v0, ptr %v0, ptr %t938)
  store { i64, ptr } %t940, ptr %l485
  br label %bb260
bb260:
  %t941 = load ptr, ptr %l16, !tbaa !29
  store ptr %t941, ptr %l486, !tbaa !29
  %t942 = load ptr, ptr %l24, !tbaa !29
  %t944 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aTaskClause_26_3e_2e_H788addc5d4e2ce71c84413f6a2c1cfed(ptr %v0, ptr %v0, ptr %t942)
  store { i64, ptr } %t944, ptr %l488
  br label %bb261
bb261:
  %t945 = load ptr, ptr %l0, !tbaa !29
  %t946 = load %"compiler/source:Span", ptr %l1
  %t950 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t945, i32 6, %"compiler/source:Span" %t946)
  store i32 %t950, ptr %l492
  br label %bb262
bb262:
  %t951 = load { i64, ptr }, ptr %l485, !tbaa !27
  %t952 = load ptr, ptr %l486, !tbaa !29
  %t953 = load { i64, ptr }, ptr %l488, !tbaa !27
  %t954 = load i32, ptr %l492, !tbaa !23
  %t955 = call %"compiler/typed:Spawn" @compiler_2ftyped_3aSpawn_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t951, ptr %t952, { i64, ptr } %t953, i32 %t954)
  store %"compiler/typed:Spawn" %t955, ptr %l493
  br label %bb263
bb263:
  %t956 = load %"compiler/typed:Spawn", ptr %l493
  %t957 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store %"compiler/typed:Spawn" %t956, ptr %t957
  store { i64, [3 x i64] } zeroinitializer, ptr %t958
  %t959 = getelementptr { i64, [3 x i64] }, ptr %t958, i32 0, i32 0
  store i64 14, ptr %t959
  %t960 = load %"compiler/source:Span", ptr %l483
  %t961 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t960, 0
  %t963 = insertvalue { %"compiler/source:Span", ptr } %t961, ptr %t957, 1
  %t964 = getelementptr { i64, [3 x i64] }, ptr %t958, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t963, ptr %t964
  %t965 = load { i64, [3 x i64] }, ptr %t958
  %t967 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t965, ptr %t967
  %t968 = load ptr, ptr %l482, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t968, ptr %t967)
  br label %bb264
bb264:
  %t970 = load ptr, ptr %l0, !tbaa !29
  store ptr %t970, ptr %l497, !tbaa !29
  %t971 = load ptr, ptr %l497, !tbaa !29
  %t972 = getelementptr %"compiler/check:Checker", ptr %t971, i32 0, i32 41
  %t973 = load i64, ptr %t972, !tbaa !24
  %t975 = sub i64 %t973, 1
  %t977 = load ptr, ptr %l497, !tbaa !29
  %t978 = getelementptr %"compiler/check:Checker", ptr %t977, i32 0, i32 41
  store i64 %t975, ptr %t978, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etakenSet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %a2, i1 %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca %"compiler/typed:Item"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca { i64, ptr }
  %l29 = alloca i1
  %l36 = alloca i32
  %l47 = alloca i32
  %l49 = alloca i64
  %l51 = alloca i64
  %l56 = alloca %"compiler/typed:Item"
  %l66 = alloca i1
  %l71 = alloca i64
  %l72 = alloca i64
  %l76 = alloca ptr
  %l81 = alloca i64
  %l83 = alloca i32
  %l88 = alloca ptr
  %l89 = alloca ptr
  %l92 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l94 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l96 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l15
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l5
  store { i64, ptr } %a1, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l8, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l7, !tbaa !24
  %t10 = load i64, ptr %l8, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb46
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t17, ptr %l23, !tbaa !27
  %t18 = load i64, ptr %l7, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i32, ptr %t21, i64 %t18
  %t23 = load i32, ptr %t22, !tbaa !33
  store i32 %t23, ptr %l9, !tbaa !23
  %t25 = load i32, ptr %l9, !tbaa !23
  %t26 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  %t29 = icmp eq i32 %t25, %t26
  br i1 %t29, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb8
bb7:
  %t31 = load i32, ptr %l9, !tbaa !23
  %t32 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t35 = icmp eq i32 %t31, %t32
  store i1 %t35, ptr %l29, !tbaa !21
  br label %bb8
bb8:
  %t37 = load i1, ptr %l29, !tbaa !21
  br i1 %t37, label %bb9, label %bb10
bb9:
  br label %bb45
bb10:
  br label %bb11
bb11:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i32, ptr %l9, !tbaa !23
  %t44 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleft(ptr %v0, ptr %v3, ptr %t38, i32 %t39, ptr %a4)
  store i32 %t44, ptr %l36
  br label %bb12
bb12:
  %t45 = load i32, ptr %l36, !tbaa !23
  store i32 %t45, ptr %l10, !tbaa !23
  %t46 = load i32, ptr %l10, !tbaa !23
  %t47 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t50 = icmp eq i32 %t46, %t47
  br i1 %t50, label %bb13, label %bb14
bb13:
  br label %bb45
bb14:
  br label %bb15
bb15:
  br i1 %a3, label %bb16, label %bb17
bb16:
  %t54 = load i32, ptr %l10, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l5, i32 %t54)
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb45
bb19:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 2
  %t63 = load i32, ptr %l10, !tbaa !23
  %t66 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t62, i32 %t63)
  store i32 %t66, ptr %l47
  br label %bb20
bb20:
  %t67 = load i32, ptr %l47, !tbaa !23
  store i32 %t67, ptr %l11, !tbaa !23
  store ptr %a2, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb21
bb21:
  %t70 = load i64, ptr %l13, !tbaa !24
  store i64 %t70, ptr %l49, !tbaa !24
  %t71 = load ptr, ptr %l12, !tbaa !29
  %t73 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2eLen_3ccompiler_2ftyped_3aItem_3e(ptr %v2, ptr %t71)
  store i64 %t73, ptr %l51
  br label %bb22
bb22:
  %t74 = load i64, ptr %l49, !tbaa !24
  %t75 = load i64, ptr %l51, !tbaa !24
  %t76 = icmp slt i64 %t74, %t75
  %t78 = xor i1 %t76, true
  br i1 %t78, label %bb23, label %bb24
bb23:
  br label %bb44
bb24:
  br label %bb25
bb25:
  %t80 = load ptr, ptr %l12, !tbaa !29
  %t81 = load i64, ptr %l13, !tbaa !24
  %t84 = call %"compiler/typed:Item" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2eAt_3ccompiler_2ftyped_3aItem_3e(ptr %v2, ptr %t80, i64 %t81)
  store %"compiler/typed:Item" %t84, ptr %l56
  br label %bb26
bb26:
  %t85 = load %"compiler/typed:Item", ptr %l56
  store %"compiler/typed:Item" %t85, ptr %l14
  %t86 = getelementptr %"compiler/typed:Item", ptr %l14, i32 0, i32 0
  %t87 = load i32, ptr %t86, !tbaa !23
  %t88 = load i32, ptr %l11, !tbaa !23
  %t91 = icmp ne i32 %t87, %t88
  br i1 %t91, label %bb27, label %bb28
bb27:
  br label %bb43
bb28:
  br label %bb29
bb29:
  %t93 = getelementptr %"compiler/typed:Item", ptr %l14, i32 0, i32 1
  %t94 = load i64, ptr %t93, !tbaa !24
  %t96 = icmp slt i64 %t94, 0
  br i1 %t96, label %bb30, label %bb31
bb30:
  %t98 = load i32, ptr %l10, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l5, i32 %t98)
  br label %bb32
bb31:
  %t101 = getelementptr %"compiler/typed:Item", ptr %l14, i32 0, i32 1
  %t102 = load i64, ptr %t101, !tbaa !24
  %t104 = icmp slt i64 %t102, 64
  br i1 %t104, label %bb33, label %bb34
bb32:
  br label %bb42
bb33:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/generic:Program", ptr %t109, i32 0, i32 2
  %t112 = load i32, ptr %l10, !tbaa !23
  %t115 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t111, i32 %t112)
  store i64 %t115, ptr %l71
  br label %bb35
bb34:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb36
bb35:
  %t116 = getelementptr %"compiler/typed:Item", ptr %l14, i32 0, i32 1
  %t117 = load i64, ptr %t116, !tbaa !24
  store i64 %t117, ptr %l72, !tbaa !24
  %t118 = load i64, ptr %l72, !tbaa !24
  %t119 = load i64, ptr %l72, !tbaa !24
  %t120 = shl i64 1, %t119
  %t121 = load i64, ptr %l71, !tbaa !65
  %t123 = and i64 %t121, %t120
  %t125 = icmp ne i64 %t123, 0
  store i1 %t125, ptr %l66, !tbaa !21
  br label %bb36
bb36:
  %t127 = load i1, ptr %l66, !tbaa !21
  br i1 %t127, label %bb37, label %bb38
bb37:
  store ptr %l5, ptr %l76, !tbaa !29
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/check:Checker", ptr %t128, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !29
  %t133 = getelementptr %"compiler/generic:Program", ptr %t131, i32 0, i32 2
  %t134 = load i32, ptr %l11, !tbaa !23
  %t135 = getelementptr %"compiler/typed:Item", ptr %l14, i32 0, i32 1
  %t136 = load i64, ptr %t135, !tbaa !24
  store i64 %t136, ptr %l81, !tbaa !24
  %t137 = load i64, ptr %l81, !tbaa !24
  %t138 = load i64, ptr %l81, !tbaa !24
  %t139 = shl i64 1, %t138
  %t143 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %t133, i32 %t134, i64 %t139)
  store i32 %t143, ptr %l83
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t144 = load ptr, ptr %l76, !tbaa !29
  %t145 = load i32, ptr %l83, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t144, i32 %t145)
  br label %bb40
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t146 = load i64, ptr %l13, !tbaa !24
  %t148 = add i64 %t146, 1
  store i64 %t148, ptr %l13, !tbaa !24
  br label %bb21
bb44:
  br label %bb45
bb45:
  %t150 = load i64, ptr %l7, !tbaa !24
  %t152 = add i64 %t150, 1
  store i64 %t152, ptr %l7, !tbaa !24
  br label %bb2
bb46:
  %t154 = load ptr, ptr %l0, !tbaa !29
  store ptr %t154, ptr %l88, !tbaa !29
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l89, !tbaa !29
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t159 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emerged(ptr %v0, ptr %s0, ptr %s0, ptr %t156, ptr %l5)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t159, ptr %l92
  br label %bb47
bb47:
  %t160 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l92
  %t161 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t160, ptr %t161
  %t162 = load ptr, ptr %l89, !tbaa !29
  %t164 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enormalSet(ptr %v0, ptr %s0, ptr %s0, ptr %t162, ptr %t161)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t164, ptr %l94
  br label %bb48
bb48:
  %t165 = load ptr, ptr %l88, !tbaa !29
  %t167 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecanonicalErrs(ptr %v0, ptr %s0, ptr %t165, ptr %l94)
  store i32 %t167, ptr %l96
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s0)
  %t168 = load i32, ptr %l96, !tbaa !23
  store i32 %t168, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 51
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp slt i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s1, ptr %s1, ptr %t12, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d70, i32 0, i32 1) }, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d71, i32 0, i32 1) })
  store i32 %t14, ptr %l7
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t15 = load i32, ptr %l7, !tbaa !23
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 51
  store i32 %t15, ptr %t17, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  br label %bb4
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 51
  %t21 = load i32, ptr %t20, !tbaa !23
  store i32 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopAssert(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l11 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca ptr
  %l20 = alloca ptr
  %l22 = alloca i32
  %l24 = alloca i32
  %l25 = alloca i64
  %l28 = alloca i1
  %l32 = alloca i1
  %l36 = alloca ptr
  %l42 = alloca ptr
  %l44 = alloca i64
  %l45 = alloca %"compiler/source:Span"
  %l48 = alloca %"compiler/source:Span"
  %l51 = alloca %"compiler/check:TopAssertAsk"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t3 = load ptr, ptr %l3, !tbaa !29
  %t4 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t9 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopBody(ptr %v0, ptr %v1, ptr %t1, i64 %t2, ptr %t3, i32 %t4)
  store i64 %t9, ptr %l11
  br label %bb1
bb1:
  %t10 = load i64, ptr %l11, !tbaa !24
  store i64 %t10, ptr %l5, !tbaa !24
  store i64 -1, ptr %l6, !tbaa !24
  %t11 = load ptr, ptr %l4, !tbaa !29
  %t13 = icmp eq ptr %t11, null
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l15, !tbaa !29
  %t18 = load i64, ptr %l1, !tbaa !24
  store i64 %t18, ptr %l16, !tbaa !24
  %t19 = load ptr, ptr %l4, !tbaa !29
  store ptr %t19, ptr %l17, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 2
  store ptr %t25, ptr %l20, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t26)
  store i32 %t28, ptr %l22
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t29 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t30 = load ptr, ptr %l20, !tbaa !29
  %t31 = load i32, ptr %l22, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t30, i32 %t31, i64 %t29)
  store i32 %t33, ptr %l24
  br label %bb5
bb5:
  %t34 = load ptr, ptr %l15, !tbaa !29
  %t35 = load i64, ptr %l16, !tbaa !24
  %t36 = load ptr, ptr %l17, !tbaa !29
  %t37 = load i32, ptr %l24, !tbaa !23
  %t38 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopBody(ptr %v0, ptr %v2, ptr %t34, i64 %t35, ptr %t36, i32 %t37)
  store i64 %t38, ptr %l25
  br label %bb6
bb6:
  %t39 = load i64, ptr %l25, !tbaa !24
  store i64 %t39, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  %t40 = load i64, ptr %l5, !tbaa !24
  %t42 = icmp slt i64 %t40, 0
  br i1 %t42, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb13
bb9:
  %t44 = load ptr, ptr %l4, !tbaa !29
  %t46 = icmp eq ptr %t44, null
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb10, label %bb11
bb10:
  %t50 = load i64, ptr %l6, !tbaa !24
  %t52 = icmp slt i64 %t50, 0
  store i1 %t52, ptr %l32, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb12
bb12:
  %t54 = load i1, ptr %l32, !tbaa !21
  store i1 %t54, ptr %l28, !tbaa !21
  br label %bb13
bb13:
  %t55 = load i1, ptr %l28, !tbaa !21
  br i1 %t55, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb15:
  br label %bb16
bb16:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 99
  store ptr %t58, ptr %l36, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/load:Loader", ptr %t65, i32 0, i32 10
  %t68 = load i64, ptr %l1, !tbaa !24
  %t71 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t67, i64 %t68)
  store ptr %t71, ptr %l42
  br label %bb17
bb17:
  %t72 = load ptr, ptr %l42, !tbaa !29
  %t74 = getelementptr %"compiler/load:Module", ptr %t72, i32 0, i32 4
  %t75 = load i64, ptr %t74, !tbaa !24
  store i64 %t75, ptr %l44, !tbaa !24
  store %"compiler/source:Span" %a2, ptr %l45
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load ptr, ptr %l3, !tbaa !29
  %t81 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorOf(ptr %v0, ptr %v1, ptr %t77, ptr %t78)
  store %"compiler/source:Span" %t81, ptr %l48
  br label %bb18
bb18:
  %t82 = load i64, ptr %l5, !tbaa !24
  %t83 = load i64, ptr %l6, !tbaa !24
  %t84 = load i64, ptr %l44, !tbaa !24
  %t85 = load %"compiler/source:Span", ptr %l45
  %t86 = load %"compiler/source:Span", ptr %l48
  %t89 = call %"compiler/check:TopAssertAsk" @compiler_2fcheck_3aTopAssertAsk_2ector(ptr %s0, i64 %t84, %"compiler/source:Span" %t85, %"compiler/source:Span" %t86, i64 %t82, i64 %t83)
  store %"compiler/check:TopAssertAsk" %t89, ptr %l51
  br label %bb19
bb19:
  %t90 = load ptr, ptr %l36, !tbaa !29
  %t91 = load %"compiler/check:TopAssertAsk", ptr %l51
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aTopAssertAsk_3e_2eP_H67072fc16e996275e069a499f28fddf9(ptr %v0, ptr %t90, %"compiler/check:TopAssertAsk" %t91)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitHeader(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca i1
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i32
  %l27 = alloca %"compiler/generic:Unmet"
  %l30 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i1
  %l47 = alloca i1
  %l56 = alloca i64
  %l63 = alloca i32
  %l67 = alloca ptr
  %l68 = alloca ptr
  %l72 = alloca %"compiler/generic:Context"
  %l76 = alloca i32
  %l84 = alloca { i64, ptr }
  %l90 = alloca i1
  %l92 = alloca ptr
  %l94 = alloca %"compiler/source:Span"
  %l95 = alloca ptr
  %l97 = alloca %"compiler/source:Span"
  %l98 = alloca { i64, ptr }
  %l99 = alloca %"compiler/diagmsg:Msg"
  %l100 = alloca i64
  %l105 = alloca i1
  %l109 = alloca i1
  %l113 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca { i64, ptr }
  %l117 = alloca %"compiler/source:Span"
  %l121 = alloca { i64, ptr }
  %l123 = alloca %"compiler/diagmsg:Msg"
  %l124 = alloca i64
  %l127 = alloca i1
  %l139 = alloca { i64, ptr }
  %l145 = alloca i1
  %l148 = alloca i1
  %l151 = alloca i1
  %l154 = alloca i32
  %l156 = alloca ptr
  %l158 = alloca ptr
  %l163 = alloca i32
  %l167 = alloca i32
  %l172 = alloca [1 x i32]
  %l173 = alloca { i64, ptr }
  %l175 = alloca i1
  %l179 = alloca i1
  %l181 = alloca ptr
  %l183 = alloca %"compiler/source:Span"
  %l184 = alloca ptr
  %l186 = alloca %"compiler/source:Span"
  %l187 = alloca { i64, ptr }
  %l188 = alloca %"compiler/diagmsg:Msg"
  %l189 = alloca i64
  %l194 = alloca { i64, ptr }
  %l195 = alloca { i64, ptr }
  %l197 = alloca i64
  %l199 = alloca i64
  %l200 = alloca { i64, ptr }
  %l210 = alloca { i64, ptr }
  %l217 = alloca %"compiler/generic:Unmet"
  %l220 = alloca i1
  %l222 = alloca ptr
  %l224 = alloca %"compiler/source:Span"
  %l227 = alloca { i64, ptr }
  %l228 = alloca { i64, ptr }
  %l232 = alloca { i64, ptr }
  %l233 = alloca { i64, ptr }
  %l236 = alloca { i64, ptr }
  %l238 = alloca %"compiler/diagmsg:Msg"
  %l239 = alloca i64
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %t95 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/ast:TypeDecl", ptr %t5, i32 0, i32 3
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = icmp eq ptr %t8, null
  store i1 %t10, ptr %l30, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l30, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t15 = getelementptr %"compiler/ast:TypeDecl", ptr %t13, i32 0, i32 3
  %t16 = load ptr, ptr %t15, !tbaa !29
  store ptr %t16, ptr %l3, !tbaa !29
  %t18 = load ptr, ptr %l3, !tbaa !29
  store ptr %t18, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t19 = load ptr, ptr %l36, !tbaa !29
  %t20 = icmp ne ptr %t19, null
  br i1 %t20, label %bb7, label %bb8
bb7:
  %t22 = load ptr, ptr %l36, !tbaa !29
  %t23 = load i64, ptr %t22, !range !{i64 0, i64 5}
  %t25 = icmp eq i64 %t23, 2
  store i1 %t25, ptr %l37, !tbaa !21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l37, !tbaa !21
  br i1 %t26, label %bb9, label %bb10
bb9:
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t29 = getelementptr { i64, [6 x i64] }, ptr %t27, i32 0, i32 1
  %t30 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t29, i32 0, i32 1
  %t31 = load { i64, ptr }, ptr %t30
  store { i64, ptr } %t31, ptr %l4, !tbaa !27
  %t33 = load ptr, ptr %l3, !tbaa !29
  %t35 = getelementptr { i64, [6 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t35, i32 0, i32 2
  %t37 = load { i64, ptr }, ptr %t36
  store { i64, ptr } %t37, ptr %l5, !tbaa !27
  br label %bb11
bb10:
  br label %bb123
bb11:
  %t39 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t43 = icmp eq i64 %t41, 0
  br i1 %t43, label %bb12, label %bb13
bb12:
  %t45 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t49 = icmp eq i64 %t47, 0
  store i1 %t49, ptr %l47, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb14
bb14:
  %t51 = load i1, ptr %l47, !tbaa !21
  br i1 %t51, label %bb15, label %bb16
bb15:
  br label %ret
bb16:
  br label %bb17
bb17:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t56 = load i64, ptr %l1, !tbaa !24
  %t57 = load ptr, ptr %l2, !tbaa !29
  %t59 = getelementptr %"compiler/ast:TypeDecl", ptr %t57, i32 0, i32 0
  %t60 = load i32, ptr %t59, !tbaa !23
  %t64 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %t55, i64 %t56, i32 %t60)
  store i64 %t64, ptr %l56
  br label %bb18
bb18:
  %t65 = load i64, ptr %l56, !tbaa !24
  store i64 %t65, ptr %l6, !tbaa !24
  %t66 = load i64, ptr %l6, !tbaa !24
  %t68 = icmp slt i64 %t66, 0
  br i1 %t68, label %bb19, label %bb20
bb19:
  br label %ret
bb20:
  br label %bb21
bb21:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/check:Checker", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t74 = load i64, ptr %l1, !tbaa !24
  %t75 = load i64, ptr %l6, !tbaa !24
  %t79 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t73, i64 %t74, i64 %t75)
  store i32 %t79, ptr %l63
  br label %bb22
bb22:
  %t80 = load i32, ptr %l63, !tbaa !23
  store i32 %t80, ptr %l7, !tbaa !23
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load i64, ptr %l1, !tbaa !24
  %t83 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t87 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t81, i64 -1, i64 %t82, i32 %t83, i32 0)
  store ptr %t87, ptr %l67
  br label %bb23
bb23:
  %t88 = load ptr, ptr %l67, !tbaa !29
  store ptr %t88, ptr %l68, !tbaa !29
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/check:Checker", ptr %t90, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t94 = load i32, ptr %l7, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclContext(ptr %t95, ptr %v0, ptr %v0, ptr %t93, i32 %t94)
  call void @llvm.memmove.p0.p0.i64(ptr %l72, ptr %t95, i64 160, i1 false)
  br label %bb24
bb24:
  %t98 = load ptr, ptr %l68, !tbaa !29
  %t99 = getelementptr %"compiler/check:frame", ptr %t98, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %t99, ptr %l72, i64 160, i1 false)
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/check:Checker", ptr %t100, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t104 = load i32, ptr %l7, !tbaa !23
  %t107 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t103, i32 %t104)
  store i32 %t107, ptr %l76
  br label %bb25
bb25:
  %t108 = load i32, ptr %l76, !tbaa !23
  store i32 %t108, ptr %l9, !tbaa !23
  store i1 false, ptr %l10, !tbaa !21
  %t109 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t109, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t111 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t111, 0
  store i64 %t113, ptr %l13, !tbaa !24
  br label %bb26
bb26:
  %t115 = load i64, ptr %l12, !tbaa !24
  %t116 = load i64, ptr %l13, !tbaa !24
  %t119 = icmp slt i64 %t115, %t116
  %t121 = xor i1 %t119, true
  br i1 %t121, label %bb27, label %bb28
bb27:
  br label %bb40
bb28:
  br label %bb29
bb29:
  %t123 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t123, ptr %l84, !tbaa !27
  %t124 = load i64, ptr %l12, !tbaa !24
  %t126 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr ptr, ptr %t127, i64 %t124
  %t129 = load ptr, ptr %t128, !tbaa !39
  store ptr %t129, ptr %l14, !tbaa !29
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i64, ptr %l1, !tbaa !24
  %t133 = load ptr, ptr %l14, !tbaa !29
  %t137 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitRef(ptr %v0, ptr %v1, ptr %t131, i64 %t132, ptr %t133)
  store i1 %t137, ptr %l90
  br label %bb30
bb30:
  %t138 = load i1, ptr %l90, !tbaa !21
  %t139 = xor i1 %t138, true
  br i1 %t139, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s7
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l92, !tbaa !29
  %t142 = load ptr, ptr %l14, !tbaa !29
  %t144 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t142)
  store %"compiler/source:Span" %t144, ptr %l94
  br label %bb33
bb32:
  br label %bb38
bb33:
  %t145 = load ptr, ptr %l0, !tbaa !29
  store ptr %t145, ptr %l95, !tbaa !29
  %t146 = load ptr, ptr %l14, !tbaa !29
  %t148 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t146)
  store %"compiler/source:Span" %t148, ptr %l97
  br label %bb34
bb34:
  %t149 = load ptr, ptr %l95, !tbaa !29
  %t150 = load %"compiler/source:Span", ptr %l97
  %t151 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t149, %"compiler/source:Span" %t150)
  store { i64, ptr } %t151, ptr %l98
  br label %bb35
bb35:
  %t152 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t153 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTraitExtendsNotTrait(ptr %v0, ptr %s7, { i64, ptr } %t152)
  store %"compiler/diagmsg:Msg" %t153, ptr %l99
  br label %bb36
bb36:
  %t154 = load ptr, ptr %l92, !tbaa !29
  %t155 = load %"compiler/source:Span", ptr %l94
  %t156 = load %"compiler/diagmsg:Msg", ptr %l99
  %t157 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t154, %"compiler/source:Span" %t155, %"compiler/diagmsg:Msg" %t156)
  store i64 %t157, ptr %l100
  br label %bb37
bb37:
  store i1 true, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s7)
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t158 = load i64, ptr %l12, !tbaa !24
  %t160 = add i64 %t158, 1
  store i64 %t160, ptr %l12, !tbaa !24
  br label %bb26
bb40:
  %t162 = load i1, ptr %l10, !tbaa !21
  %t164 = xor i1 %t162, true
  br i1 %t164, label %bb41, label %bb42
bb41:
  %t166 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t166, 0
  %t170 = icmp sgt i64 %t168, 0
  store i1 %t170, ptr %l105, !tbaa !21
  br label %bb43
bb42:
  store i1 false, ptr %l105, !tbaa !21
  br label %bb43
bb43:
  %t172 = load i1, ptr %l105, !tbaa !21
  br i1 %t172, label %bb44, label %bb45
bb44:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i32, ptr %l7, !tbaa !23
  %t175 = load i32, ptr %l9, !tbaa !23
  %t179 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereachesTrait(ptr %v0, ptr %t173, i32 %t174, i32 %t175, i64 0)
  store i1 %t179, ptr %l113
  br label %bb46
bb45:
  store i1 false, ptr %l109, !tbaa !21
  br label %bb47
bb46:
  %t180 = load i1, ptr %l113, !tbaa !21
  store i1 %t180, ptr %l109, !tbaa !21
  br label %bb47
bb47:
  %t181 = load i1, ptr %l109, !tbaa !21
  br i1 %t181, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s9
  %t182 = load ptr, ptr %l0, !tbaa !29
  store ptr %t182, ptr %l114, !tbaa !29
  %t183 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t183, ptr %l115, !tbaa !27
  %t184 = getelementptr { i64, ptr }, ptr %l115, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = getelementptr ptr, ptr %t185, i64 0
  %t187 = load ptr, ptr %t186, !tbaa !39
  %t189 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t187)
  store %"compiler/source:Span" %t189, ptr %l117
  br label %bb50
bb49:
  br label %bb54
bb50:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load ptr, ptr %l2, !tbaa !29
  %t193 = getelementptr %"compiler/ast:TypeDecl", ptr %t191, i32 0, i32 0
  %t194 = load i32, ptr %t193, !tbaa !23
  %t197 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s9, ptr %t190, i32 %t194)
  store { i64, ptr } %t197, ptr %l121
  br label %bb51
bb51:
  %t198 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t198, 0
  %t200 = extractvalue { i64, ptr } %t198, 1
  %t201 = mul i64 %t199, 1
  %t202 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t201)
  call void @llvm.memcpy.p0.p0.i64(ptr %t202, ptr %t200, i64 %t201, i1 false)
  %t203 = insertvalue { i64, ptr } undef, i64 %t199, 0
  %t204 = insertvalue { i64, ptr } %t203, ptr %t202, 1
  %t206 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTraitExtendsItself(ptr %s9, ptr %s9, { i64, ptr } %t204)
  store %"compiler/diagmsg:Msg" %t206, ptr %l123
  br label %bb52
bb52:
  %t207 = load ptr, ptr %l114, !tbaa !29
  %t208 = load %"compiler/source:Span", ptr %l117
  %t209 = load %"compiler/diagmsg:Msg", ptr %l123
  %t210 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s9, ptr %t207, %"compiler/source:Span" %t208, %"compiler/diagmsg:Msg" %t209)
  store i64 %t210, ptr %l124
  br label %bb53
bb53:
  store i1 true, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s9)
  br label %bb54
bb54:
  %t211 = load i1, ptr %l10, !tbaa !21
  %t213 = xor i1 %t211, true
  br i1 %t213, label %bb55, label %bb56
bb55:
  %t215 = load ptr, ptr %l2, !tbaa !29
  %t217 = getelementptr %"compiler/ast:TypeDecl", ptr %t215, i32 0, i32 1
  %t218 = load { i64, ptr }, ptr %t217, !tbaa !27
  %t220 = extractvalue { i64, ptr } %t218, 0
  %t222 = icmp eq i64 %t220, 0
  store i1 %t222, ptr %l127, !tbaa !21
  br label %bb57
bb56:
  store i1 false, ptr %l127, !tbaa !21
  br label %bb57
bb57:
  %t224 = load i1, ptr %l127, !tbaa !21
  store i1 %t224, ptr %l15, !tbaa !21
  %t225 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t225, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t227 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t229 = extractvalue { i64, ptr } %t227, 0
  store i64 %t229, ptr %l18, !tbaa !24
  br label %bb58
bb58:
  store %olang.scope zeroinitializer, ptr %s11
  %t231 = load i64, ptr %l17, !tbaa !24
  %t232 = load i64, ptr %l18, !tbaa !24
  %t235 = icmp slt i64 %t231, %t232
  %t237 = xor i1 %t235, true
  br i1 %t237, label %bb59, label %bb60
bb59:
  call void @__olang_scope_close(ptr %s11)
  br label %bb121
bb60:
  br label %bb61
bb61:
  %t239 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t239, ptr %l139, !tbaa !27
  %t240 = load i64, ptr %l17, !tbaa !24
  %t242 = getelementptr { i64, ptr }, ptr %l139, i32 0, i32 1
  %t243 = load ptr, ptr %t242, !tbaa !27
  %t244 = getelementptr ptr, ptr %t243, i64 %t240
  %t245 = load ptr, ptr %t244, !tbaa !39
  store ptr %t245, ptr %l19, !tbaa !29
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load i64, ptr %l1, !tbaa !24
  %t249 = load ptr, ptr %l19, !tbaa !29
  %t253 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitRef(ptr %v0, ptr %v1, ptr %t247, i64 %t248, ptr %t249)
  store i1 %t253, ptr %l145
  br label %bb62
bb62:
  %t254 = load i1, ptr %l145, !tbaa !21
  store i1 %t254, ptr %l20, !tbaa !21
  %t255 = load i1, ptr %l20, !tbaa !21
  %t257 = xor i1 %t255, true
  br i1 %t257, label %bb63, label %bb64
bb63:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load ptr, ptr %l19, !tbaa !29
  %t263 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTypeWritten(ptr %v0, ptr %v1, ptr %t259, ptr %t260, i1 true)
  store i1 %t263, ptr %l151
  br label %bb65
bb64:
  store i1 false, ptr %l148, !tbaa !21
  br label %bb66
bb65:
  %t264 = load i1, ptr %l151, !tbaa !21
  %t265 = xor i1 %t264, true
  store i1 %t265, ptr %l148, !tbaa !21
  br label %bb66
bb66:
  %t267 = load i1, ptr %l148, !tbaa !21
  br i1 %t267, label %bb67, label %bb68
bb67:
  call void @__olang_scope_close(ptr %s11)
  br label %bb120
bb68:
  br label %bb69
bb69:
  %t268 = load i1, ptr %l20, !tbaa !21
  br i1 %t268, label %bb70, label %bb71
bb70:
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t272 = getelementptr %"compiler/check:Checker", ptr %t270, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !29
  store ptr %t273, ptr %l156, !tbaa !29
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t274)
  store ptr %t276, ptr %l158
  br label %bb72
bb71:
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t278 = load ptr, ptr %l19, !tbaa !29
  %t282 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %t277, ptr %t278)
  store i32 %t282, ptr %l167
  br label %bb74
bb72:
  %t283 = load ptr, ptr %l158, !tbaa !29
  %t285 = getelementptr %"compiler/check:frame", ptr %t283, i32 0, i32 4
  %t286 = load ptr, ptr %l19, !tbaa !29
  %t288 = load ptr, ptr %l156, !tbaa !29
  %t291 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v0, ptr %v1, ptr %t288, ptr %t285, ptr %t286)
  store i32 %t291, ptr %l163
  br label %bb73
bb73:
  %t292 = load i32, ptr %l163, !tbaa !23
  store i32 %t292, ptr %l154, !tbaa !23
  br label %bb75
bb74:
  %t293 = load i32, ptr %l167, !tbaa !23
  store i32 %t293, ptr %l154, !tbaa !23
  br label %bb75
bb75:
  %t294 = load i32, ptr %l154, !tbaa !23
  store i32 %t294, ptr %l21, !tbaa !23
  %t295 = load i32, ptr %l21, !tbaa !23
  %t296 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t299 = icmp eq i32 %t295, %t296
  br i1 %t299, label %bb76, label %bb77
bb76:
  call void @__olang_scope_close(ptr %s11)
  br label %bb120
bb77:
  br label %bb78
bb78:
  %t301 = load i32, ptr %l21, !tbaa !23
  %t303 = insertvalue [1 x i32] undef, i32 %t301, 0
  store [1 x i32] %t303, ptr %l172
  %t304 = mul i64 1, 4
  %t305 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t304)
  %t306 = insertvalue { i64, ptr } undef, i64 1, 0
  %t307 = insertvalue { i64, ptr } %t306, ptr %t305, 1
  store { i64, ptr } %t307, ptr %l173, !tbaa !27
  %t308 = getelementptr { i64, ptr }, ptr %l173, i32 0, i32 1
  %t309 = load ptr, ptr %t308, !tbaa !27
  %t310 = mul i64 1, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t309, ptr %l172, i64 %t310, i1 false)
  %t311 = load { i64, ptr }, ptr %l173, !tbaa !27
  store { i64, ptr } %t311, ptr %l22, !tbaa !27
  %t312 = load i1, ptr %l20, !tbaa !21
  br i1 %t312, label %bb79, label %bb80
bb79:
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t316 = getelementptr %"compiler/check:Checker", ptr %t314, i32 0, i32 1
  %t317 = load ptr, ptr %t316, !tbaa !29
  %t318 = load i32, ptr %l21, !tbaa !23
  %t321 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsClosedTrait(ptr %v0, ptr %t317, i32 %t318)
  store i1 %t321, ptr %l179
  br label %bb81
bb80:
  store i1 false, ptr %l175, !tbaa !21
  br label %bb82
bb81:
  %t322 = load i1, ptr %l179, !tbaa !21
  %t323 = xor i1 %t322, true
  store i1 %t323, ptr %l175, !tbaa !21
  br label %bb82
bb82:
  %t325 = load i1, ptr %l175, !tbaa !21
  br i1 %t325, label %bb83, label %bb84
bb83:
  store %olang.scope zeroinitializer, ptr %s14
  %t326 = load ptr, ptr %l0, !tbaa !29
  store ptr %t326, ptr %l181, !tbaa !29
  %t327 = load ptr, ptr %l19, !tbaa !29
  %t329 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t327)
  store %"compiler/source:Span" %t329, ptr %l183
  br label %bb85
bb84:
  br label %bb90
bb85:
  %t330 = load ptr, ptr %l0, !tbaa !29
  store ptr %t330, ptr %l184, !tbaa !29
  %t331 = load ptr, ptr %l19, !tbaa !29
  %t333 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t331)
  store %"compiler/source:Span" %t333, ptr %l186
  br label %bb86
bb86:
  %t334 = load ptr, ptr %l184, !tbaa !29
  %t335 = load %"compiler/source:Span", ptr %l186
  %t336 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t334, %"compiler/source:Span" %t335)
  store { i64, ptr } %t336, ptr %l187
  br label %bb87
bb87:
  %t337 = load { i64, ptr }, ptr %l187, !tbaa !27
  %t338 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTraitMemberOpen(ptr %v0, ptr %s14, { i64, ptr } %t337)
  store %"compiler/diagmsg:Msg" %t338, ptr %l188
  br label %bb88
bb88:
  %t339 = load ptr, ptr %l181, !tbaa !29
  %t340 = load %"compiler/source:Span", ptr %l183
  %t341 = load %"compiler/diagmsg:Msg", ptr %l188
  %t342 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s14, ptr %t339, %"compiler/source:Span" %t340, %"compiler/diagmsg:Msg" %t341)
  store i64 %t342, ptr %l189
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s11)
  br label %bb120
bb90:
  %t343 = load i1, ptr %l20, !tbaa !21
  br i1 %t343, label %bb91, label %bb92
bb91:
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t347 = getelementptr %"compiler/check:Checker", ptr %t345, i32 0, i32 1
  %t348 = load ptr, ptr %t347, !tbaa !29
  %t349 = load i32, ptr %l21, !tbaa !23
  %t352 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMembers(ptr %v0, ptr %v0, ptr %t348, i32 %t349)
  store { i64, ptr } %t352, ptr %l194
  br label %bb93
bb92:
  br label %bb97
bb93:
  %t353 = load { i64, ptr }, ptr %l194, !tbaa !27
  store { i64, ptr } %t353, ptr %l195, !tbaa !27
  %t354 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t355 = extractvalue { i64, ptr } %t354, 0
  %t356 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t357 = extractvalue { i64, ptr } %t356, 0
  store i64 %t357, ptr %l197, !tbaa !24
  %t359 = load i64, ptr %l197, !tbaa !24
  %t360 = icmp eq i64 %t355, %t359
  br i1 %t360, label %bb94, label %bb95
bb94:
  %t362 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t363 = load ptr, ptr %t362, !tbaa !27
  %t364 = getelementptr { i64, ptr }, ptr %l195, i32 0, i32 1
  %t365 = load ptr, ptr %t364, !tbaa !27
  %t366 = load i64, ptr %l197, !tbaa !24
  %t367 = mul i64 %t366, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t363, ptr %t365, i64 %t367, i1 false)
  br label %bb96
bb95:
  %t368 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t369 = extractvalue { i64, ptr } %t368, 0
  store i64 %t369, ptr %l199, !tbaa !24
  %t370 = load i64, ptr %l199, !tbaa !24
  %t371 = mul i64 %t370, 4
  %t372 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t371)
  %t373 = insertvalue { i64, ptr } undef, i64 %t370, 0
  %t374 = insertvalue { i64, ptr } %t373, ptr %t372, 1
  store { i64, ptr } %t374, ptr %l200, !tbaa !27
  %t375 = getelementptr { i64, ptr }, ptr %l200, i32 0, i32 1
  %t376 = load ptr, ptr %t375, !tbaa !27
  %t377 = getelementptr { i64, ptr }, ptr %l195, i32 0, i32 1
  %t378 = load ptr, ptr %t377, !tbaa !27
  %t379 = load i64, ptr %l199, !tbaa !24
  %t380 = mul i64 %t379, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t376, ptr %t378, i64 %t380, i1 false)
  %t381 = load { i64, ptr }, ptr %l200, !tbaa !27
  store { i64, ptr } %t381, ptr %l22, !tbaa !27
  br label %bb96
bb96:
  br label %bb97
bb97:
  %t382 = load i1, ptr %l15, !tbaa !21
  %t384 = xor i1 %t382, true
  br i1 %t384, label %bb98, label %bb99
bb98:
  call void @__olang_scope_close(ptr %s11)
  br label %bb120
bb99:
  br label %bb100
bb100:
  %t386 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t386, ptr %l23, !tbaa !27
  store i64 0, ptr %l24, !tbaa !24
  %t388 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t390 = extractvalue { i64, ptr } %t388, 0
  store i64 %t390, ptr %l25, !tbaa !24
  br label %bb101
bb101:
  %t392 = load i64, ptr %l24, !tbaa !24
  %t393 = load i64, ptr %l25, !tbaa !24
  %t396 = icmp slt i64 %t392, %t393
  %t398 = xor i1 %t396, true
  br i1 %t398, label %bb102, label %bb103
bb102:
  br label %bb119
bb103:
  br label %bb104
bb104:
  %t400 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t400, ptr %l210, !tbaa !27
  %t401 = load i64, ptr %l24, !tbaa !24
  %t403 = getelementptr { i64, ptr }, ptr %l210, i32 0, i32 1
  %t404 = load ptr, ptr %t403, !tbaa !27
  %t405 = getelementptr i32, ptr %t404, i64 %t401
  %t406 = load i32, ptr %t405, !tbaa !33
  store i32 %t406, ptr %l26, !tbaa !23
  %t408 = load ptr, ptr %l0, !tbaa !29
  %t410 = getelementptr %"compiler/check:Checker", ptr %t408, i32 0, i32 1
  %t411 = load ptr, ptr %t410, !tbaa !29
  %t412 = load i32, ptr %l26, !tbaa !23
  %t413 = load i32, ptr %l9, !tbaa !23
  %t417 = call %"compiler/generic:Unmet" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMissing(ptr %v0, ptr %t411, i32 %t412, i32 %t413, i1 false, i64 0)
  store %"compiler/generic:Unmet" %t417, ptr %l217
  br label %bb105
bb105:
  %t418 = load %"compiler/generic:Unmet", ptr %l217
  store %"compiler/generic:Unmet" %t418, ptr %l27
  %t419 = getelementptr %"compiler/generic:Unmet", ptr %l27, i32 0, i32 0
  %t420 = load i64, ptr %t419, !tbaa !24
  %t422 = icmp sge i64 %t420, 0
  br i1 %t422, label %bb106, label %bb107
bb106:
  %t424 = getelementptr %"compiler/generic:Unmet", ptr %l27, i32 0, i32 3
  %t425 = load i1, ptr %t424, !tbaa !21
  store i1 %t425, ptr %l220, !tbaa !21
  br label %bb108
bb107:
  store i1 false, ptr %l220, !tbaa !21
  br label %bb108
bb108:
  %t427 = load i1, ptr %l220, !tbaa !21
  br i1 %t427, label %bb109, label %bb110
bb109:
  store %olang.scope zeroinitializer, ptr %s19
  %t428 = load ptr, ptr %l0, !tbaa !29
  store ptr %t428, ptr %l222, !tbaa !29
  %t429 = load ptr, ptr %l19, !tbaa !29
  %t431 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t429)
  store %"compiler/source:Span" %t431, ptr %l224
  br label %bb111
bb110:
  br label %bb117
bb111:
  %t432 = load ptr, ptr %l0, !tbaa !29
  %t433 = load i32, ptr %l26, !tbaa !23
  %t436 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s19, ptr %t432, i32 %t433)
  store { i64, ptr } %t436, ptr %l227
  br label %bb112
bb112:
  %t437 = load { i64, ptr }, ptr %l227, !tbaa !27
  %t438 = extractvalue { i64, ptr } %t437, 0
  %t439 = extractvalue { i64, ptr } %t437, 1
  %t440 = mul i64 %t438, 1
  %t441 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t440)
  call void @llvm.memcpy.p0.p0.i64(ptr %t441, ptr %t439, i64 %t440, i1 false)
  %t442 = insertvalue { i64, ptr } undef, i64 %t438, 0
  %t443 = insertvalue { i64, ptr } %t442, ptr %t441, 1
  store { i64, ptr } %t443, ptr %l228, !tbaa !27
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t445 = load ptr, ptr %l2, !tbaa !29
  %t447 = getelementptr %"compiler/ast:TypeDecl", ptr %t445, i32 0, i32 0
  %t448 = load i32, ptr %t447, !tbaa !23
  %t451 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s19, ptr %t444, i32 %t448)
  store { i64, ptr } %t451, ptr %l232
  br label %bb113
bb113:
  %t452 = load { i64, ptr }, ptr %l232, !tbaa !27
  %t453 = extractvalue { i64, ptr } %t452, 0
  %t454 = extractvalue { i64, ptr } %t452, 1
  %t455 = mul i64 %t453, 1
  %t456 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t455)
  call void @llvm.memcpy.p0.p0.i64(ptr %t456, ptr %t454, i64 %t455, i1 false)
  %t457 = insertvalue { i64, ptr } undef, i64 %t453, 0
  %t458 = insertvalue { i64, ptr } %t457, ptr %t456, 1
  store { i64, ptr } %t458, ptr %l233, !tbaa !27
  %t459 = load ptr, ptr %l0, !tbaa !29
  %t460 = getelementptr %"compiler/generic:Unmet", ptr %l27, i32 0, i32 2
  %t461 = load i32, ptr %t460, !tbaa !23
  %t464 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s19, ptr %t459, i32 %t461)
  store { i64, ptr } %t464, ptr %l236
  br label %bb114
bb114:
  %t465 = load { i64, ptr }, ptr %l236, !tbaa !27
  %t466 = extractvalue { i64, ptr } %t465, 0
  %t467 = extractvalue { i64, ptr } %t465, 1
  %t468 = mul i64 %t466, 1
  %t469 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t468)
  call void @llvm.memcpy.p0.p0.i64(ptr %t469, ptr %t467, i64 %t468, i1 false)
  %t470 = insertvalue { i64, ptr } undef, i64 %t466, 0
  %t471 = insertvalue { i64, ptr } %t470, ptr %t469, 1
  %t472 = load { i64, ptr }, ptr %l228, !tbaa !27
  %t473 = load { i64, ptr }, ptr %l233, !tbaa !27
  %t475 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTraitMemberMissing(ptr %s19, ptr %s19, ptr %s19, ptr %s19, { i64, ptr } %t472, { i64, ptr } %t473, { i64, ptr } %t471)
  store %"compiler/diagmsg:Msg" %t475, ptr %l238
  br label %bb115
bb115:
  %t476 = load ptr, ptr %l222, !tbaa !29
  %t477 = load %"compiler/source:Span", ptr %l224
  %t478 = load %"compiler/diagmsg:Msg", ptr %l238
  %t479 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s19, ptr %t476, %"compiler/source:Span" %t477, %"compiler/diagmsg:Msg" %t478)
  store i64 %t479, ptr %l239
  br label %bb116
bb116:
  call void @__olang_scope_close(ptr %s19)
  br label %bb117
bb117:
  br label %bb118
bb118:
  %t480 = load i64, ptr %l24, !tbaa !24
  %t482 = add i64 %t480, 1
  store i64 %t482, ptr %l24, !tbaa !24
  br label %bb101
bb119:
  call void @__olang_scope_close(ptr %s11)
  br label %bb120
bb120:
  %t484 = load i64, ptr %l17, !tbaa !24
  %t486 = add i64 %t484, 1
  store i64 %t486, ptr %l17, !tbaa !24
  br label %bb58
bb121:
  %t488 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t488)
  br label %bb122
bb122:
  br label %bb128
bb123:
  br i1 true, label %bb124, label %bb125
bb124:
  br label %bb126
bb125:
  br label %bb127
bb126:
  br label %bb128
bb127:
  call void @__olang_check_failed(ptr @olang_loc_21d2c8212e1ec20a_d97fbaae9e5bc606)
  unreachable
bb128:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantStr(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l25 = alloca i1
  %l29 = alloca i1
  %l32 = alloca i1
  %l35 = alloca i1
  %l42 = alloca i32
  %l45 = alloca ptr
  %l50 = alloca i32
  %l68 = alloca ptr
  %l69 = alloca i32
  %l74 = alloca i32
  %l75 = alloca i64
  %l86 = alloca i1
  %l95 = alloca i1
  %l99 = alloca i32
  %l104 = alloca ptr
  %l109 = alloca i32
  %l110 = alloca { i64, ptr }
  %l117 = alloca { i64, ptr }
  %l131 = alloca ptr
  %l136 = alloca i32
  %l137 = alloca { i64, ptr }
  %l144 = alloca { i64, ptr }
  %l156 = alloca ptr
  %l161 = alloca i32
  %l167 = alloca ptr
  %l172 = alloca i32
  %l182 = alloca ptr
  %l187 = alloca i32
  %l188 = alloca { i64, ptr }
  %l195 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t5, %t6
  store i1 %t9, ptr %l25, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l25, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i32, ptr %l1, !tbaa !23
  %t14 = icmp eq i32 %t12, 0
  store i1 %t14, ptr %l29, !tbaa !21
  br label %bb6
bb6:
  %t16 = load i1, ptr %l29, !tbaa !21
  br i1 %t16, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb10
bb8:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t18 = load i32, ptr %l1, !tbaa !23
  %t21 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_Hb3133f486435530b533aaf49461c92b5(ptr %v1, ptr %t17, i32 %t18)
  store i1 %t21, ptr %l35
  br label %bb9
bb9:
  %t22 = load i1, ptr %l35, !tbaa !21
  store i1 %t22, ptr %l32, !tbaa !21
  br label %bb10
bb10:
  %t23 = load i1, ptr %l32, !tbaa !21
  br i1 %t23, label %bb11, label %bb12
bb11:
  br label %ret
bb12:
  br label %bb13
bb13:
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t25 = load i32, ptr %l1, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H64d9be73b6c9bed004c541bdf7f0ca0a(ptr %v1, ptr %t24, i32 %t25, i1 true)
  br label %bb14
bb14:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  %t34 = load i32, ptr %l1, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l42
  br label %bb15
bb15:
  %t38 = load i32, ptr %l42, !range !{i32 0, i32 33}
  store i32 %t38, ptr %l4
  %t39 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t41 = trunc i64 20 to i32
  %t42 = icmp eq i32 %t39, %t41
  br i1 %t42, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb21
bb18:
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l45, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = getelementptr %"compiler/generic:Program", ptr %t48, i32 0, i32 2
  %t51 = load i32, ptr %l1, !tbaa !23
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t50, i32 %t51)
  store i32 %t54, ptr %l50
  br label %bb19
bb19:
  %t55 = load ptr, ptr %l2, !tbaa !29
  %t56 = load i64, ptr %l3, !tbaa !24
  %t58 = add i64 %t56, 1
  %t59 = load ptr, ptr %l45, !tbaa !29
  %t60 = load i32, ptr %l50, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantStr(ptr %v0, ptr %v1, ptr %t59, i32 %t60, ptr %t55, i64 %t58)
  br label %bb20
bb20:
  br label %bb101
bb21:
  %t63 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t65 = trunc i64 18 to i32
  %t66 = icmp eq i32 %t63, %t65
  br i1 %t66, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb75
bb24:
  store %olang.scope zeroinitializer, ptr %s4
  %t68 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  %t69 = insertvalue [2 x { i64, ptr }] %t68, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t71 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 32, i64 8)
  store [2 x { i64, ptr }] %t69, ptr %t71
  store ptr %t71, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  %t73 = load ptr, ptr %l5
  store i64 2, ptr %l7, !tbaa !24
  br label %bb25
bb25:
  %t76 = load i64, ptr %l6, !tbaa !24
  %t77 = load i64, ptr %l7, !tbaa !24
  %t80 = icmp slt i64 %t76, %t77
  %t82 = xor i1 %t80, true
  br i1 %t82, label %bb26, label %bb27
bb26:
  br label %bb40
bb27:
  br label %bb28
bb28:
  %t84 = load ptr, ptr %l5
  %t85 = load i64, ptr %l6, !tbaa !24
  %t88 = getelementptr [2 x { i64, ptr }], ptr %t84, i64 0, i64 %t85
  %t89 = load { i64, ptr }, ptr %t88, !tbaa !37
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/check:Checker", ptr %t91, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !29
  store ptr %t94, ptr %l68, !tbaa !29
  %t95 = load i32, ptr %l1, !tbaa !23
  store i32 %t95, ptr %l69, !tbaa !23
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/check:Checker", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/generic:Program", ptr %t99, i32 0, i32 2
  %t102 = getelementptr %"compiler/types:Table", ptr %t101, i32 0, i32 0
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = load ptr, ptr @__olang_prog_scope
  %t106 = load ptr, ptr @__olang_prog_scope
  %t109 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %t105, ptr %t106, ptr %t103, { i64, ptr } %t89)
  store i32 %t109, ptr %l74
  br label %bb29
bb29:
  %t110 = load ptr, ptr %l68, !tbaa !29
  %t111 = load i32, ptr %l69, !tbaa !23
  %t112 = load i32, ptr %l74, !tbaa !23
  %t113 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t110, i32 %t111, i32 %t112)
  store i64 %t113, ptr %l75
  br label %bb30
bb30:
  %t114 = load i64, ptr %l75, !tbaa !24
  store i64 %t114, ptr %l9, !tbaa !24
  %t115 = load i64, ptr %l9, !tbaa !24
  %t117 = icmp sge i64 %t115, 0
  br i1 %t117, label %bb31, label %bb32
bb31:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/check:Checker", ptr %t119, i32 0, i32 46
  %t122 = getelementptr %"compiler/source:Span", ptr %t121, i32 0, i32 0
  %t123 = load i32, ptr %t122, !tbaa !23
  %t125 = icmp sge i32 %t123, 0
  br i1 %t125, label %bb33, label %bb34
bb32:
  br label %bb38
bb33:
  store %olang.scope zeroinitializer, ptr %s7
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load i64, ptr %l9, !tbaa !24
  %t129 = load i32, ptr %l1, !tbaa !23
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/check:Checker", ptr %t130, i32 0, i32 46
  %t133 = load %"compiler/source:Span", ptr %t132
  %t138 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprivateRole(ptr %v0, ptr %s7, ptr %s7, ptr %t127, i64 %t128, i32 %t129, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d74, i32 0, i32 1) }, %"compiler/source:Span" %t133, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d75, i32 0, i32 1) })
  store i1 %t138, ptr %l86
  br label %bb35
bb34:
  br label %bb36
bb35:
  call void @__olang_scope_close(ptr %s7)
  br label %bb36
bb36:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load i64, ptr %l9, !tbaa !24
  %t141 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estrInstance(ptr %v0, ptr %t139, i64 %t140, i32 %t141)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s4)
  br label %ret
bb38:
  br label %bb39
bb39:
  %t145 = load i64, ptr %l6, !tbaa !24
  %t147 = add i64 %t145, 1
  store i64 %t147, ptr %l6, !tbaa !24
  br label %bb25
bb40:
  call void @__olang_scope_close(ptr %s4)
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/check:Checker", ptr %t149, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !29
  %t153 = load i32, ptr %l1, !tbaa !23
  %t156 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t152, i32 %t153)
  store i1 %t156, ptr %l95
  br label %bb41
bb41:
  %t157 = load i1, ptr %l95, !tbaa !21
  %t158 = xor i1 %t157, true
  br i1 %t158, label %bb42, label %bb43
bb42:
  br label %ret
bb43:
  br label %bb44
bb44:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load i32, ptr %l1, !tbaa !23
  %t164 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t160, i32 %t161)
  store i32 %t164, ptr %l99
  br label %bb45
bb45:
  %t165 = load i32, ptr %l99, !range !{i32 0, i32 6}
  store i32 %t165, ptr %l10
  %t166 = load i32, ptr %l10, !range !{i32 0, i32 6}
  %t168 = trunc i64 0 to i32
  %t169 = icmp eq i32 %t166, %t168
  br i1 %t169, label %bb46, label %bb47
bb46:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/check:Checker", ptr %t171, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !29
  %t176 = getelementptr %"compiler/generic:Program", ptr %t174, i32 0, i32 2
  store ptr %t176, ptr %l104, !tbaa !29
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/check:Checker", ptr %t177, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !29
  %t182 = getelementptr %"compiler/generic:Program", ptr %t180, i32 0, i32 2
  %t183 = load i32, ptr %l1, !tbaa !23
  %t186 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t182, i32 %t183)
  store i32 %t186, ptr %l109
  br label %bb48
bb47:
  %t187 = load i32, ptr %l10, !range !{i32 0, i32 6}
  %t189 = trunc i64 1 to i32
  %t190 = icmp eq i32 %t187, %t189
  br i1 %t190, label %bb57, label %bb58
bb48:
  %t192 = load ptr, ptr %l104, !tbaa !29
  %t193 = load i32, ptr %l109, !tbaa !23
  %t194 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t192, i32 %t193)
  store { i64, ptr } %t194, ptr %l110
  br label %bb49
bb49:
  %t195 = load { i64, ptr }, ptr %l110, !tbaa !27
  store { i64, ptr } %t195, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t196 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t196, 0
  store i64 %t198, ptr %l13, !tbaa !24
  br label %bb50
bb50:
  %t200 = load i64, ptr %l12, !tbaa !24
  %t201 = load i64, ptr %l13, !tbaa !24
  %t204 = icmp slt i64 %t200, %t201
  %t206 = xor i1 %t204, true
  br i1 %t206, label %bb51, label %bb52
bb51:
  br label %bb56
bb52:
  br label %bb53
bb53:
  %t208 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t208, ptr %l117, !tbaa !27
  %t209 = load i64, ptr %l12, !tbaa !24
  %t211 = getelementptr { i64, ptr }, ptr %l117, i32 0, i32 1
  %t212 = load ptr, ptr %t211, !tbaa !27
  %t213 = getelementptr i32, ptr %t212, i64 %t209
  %t214 = load i32, ptr %t213, !tbaa !33
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = load ptr, ptr %l2, !tbaa !29
  %t219 = load i64, ptr %l3, !tbaa !24
  %t221 = add i64 %t219, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantStr(ptr %v0, ptr %v1, ptr %t216, i32 %t214, ptr %t218, i64 %t221)
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t226 = load i64, ptr %l12, !tbaa !24
  %t228 = add i64 %t226, 1
  store i64 %t228, ptr %l12, !tbaa !24
  br label %bb50
bb56:
  br label %bb74
bb57:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t232 = getelementptr %"compiler/check:Checker", ptr %t230, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !29
  %t235 = getelementptr %"compiler/generic:Program", ptr %t233, i32 0, i32 2
  store ptr %t235, ptr %l131, !tbaa !29
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t238 = getelementptr %"compiler/check:Checker", ptr %t236, i32 0, i32 1
  %t239 = load ptr, ptr %t238, !tbaa !29
  %t241 = getelementptr %"compiler/generic:Program", ptr %t239, i32 0, i32 2
  %t242 = load i32, ptr %l1, !tbaa !23
  %t245 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t241, i32 %t242)
  store i32 %t245, ptr %l136
  br label %bb59
bb58:
  %t246 = load i32, ptr %l10, !range !{i32 0, i32 6}
  %t248 = trunc i64 4 to i32
  %t249 = icmp eq i32 %t246, %t248
  br i1 %t249, label %bb68, label %bb69
bb59:
  %t251 = load ptr, ptr %l131, !tbaa !29
  %t252 = load i32, ptr %l136, !tbaa !23
  %t253 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t251, i32 %t252)
  store { i64, ptr } %t253, ptr %l137
  br label %bb60
bb60:
  %t254 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t254, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t255 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t257 = extractvalue { i64, ptr } %t255, 0
  store i64 %t257, ptr %l17, !tbaa !24
  br label %bb61
bb61:
  %t259 = load i64, ptr %l16, !tbaa !24
  %t260 = load i64, ptr %l17, !tbaa !24
  %t263 = icmp slt i64 %t259, %t260
  %t265 = xor i1 %t263, true
  br i1 %t265, label %bb62, label %bb63
bb62:
  br label %bb67
bb63:
  br label %bb64
bb64:
  %t267 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t267, ptr %l144, !tbaa !27
  %t268 = load i64, ptr %l16, !tbaa !24
  %t270 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t271 = load ptr, ptr %t270, !tbaa !27
  %t272 = getelementptr i32, ptr %t271, i64 %t268
  %t273 = load i32, ptr %t272, !tbaa !33
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t277 = load ptr, ptr %l2, !tbaa !29
  %t278 = load i64, ptr %l3, !tbaa !24
  %t280 = add i64 %t278, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantStr(ptr %v0, ptr %v1, ptr %t275, i32 %t273, ptr %t277, i64 %t280)
  br label %bb65
bb65:
  br label %bb66
bb66:
  %t285 = load i64, ptr %l16, !tbaa !24
  %t287 = add i64 %t285, 1
  store i64 %t287, ptr %l16, !tbaa !24
  br label %bb61
bb67:
  br label %bb73
bb68:
  %t289 = load ptr, ptr %l0, !tbaa !29
  store ptr %t289, ptr %l156, !tbaa !29
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t292 = getelementptr %"compiler/check:Checker", ptr %t290, i32 0, i32 1
  %t293 = load ptr, ptr %t292, !tbaa !29
  %t295 = getelementptr %"compiler/generic:Program", ptr %t293, i32 0, i32 2
  %t296 = load i32, ptr %l1, !tbaa !23
  %t299 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t295, i32 %t296)
  store i32 %t299, ptr %l161
  br label %bb70
bb69:
  br label %bb72
bb70:
  %t300 = load ptr, ptr %l2, !tbaa !29
  %t301 = load i64, ptr %l3, !tbaa !24
  %t303 = add i64 %t301, 1
  %t304 = load ptr, ptr %l156, !tbaa !29
  %t305 = load i32, ptr %l161, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantStr(ptr %v0, ptr %v1, ptr %t304, i32 %t305, ptr %t300, i64 %t303)
  br label %bb71
bb71:
  br label %bb72
bb72:
  br label %bb73
bb73:
  br label %bb74
bb74:
  br label %bb101
bb75:
  %t308 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t310 = trunc i64 19 to i32
  %t311 = icmp eq i32 %t308, %t310
  br i1 %t311, label %bb76, label %bb77
bb76:
  br label %bb78
bb77:
  br label %bb81
bb78:
  %t313 = load ptr, ptr %l0, !tbaa !29
  store ptr %t313, ptr %l167, !tbaa !29
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t316 = getelementptr %"compiler/check:Checker", ptr %t314, i32 0, i32 1
  %t317 = load ptr, ptr %t316, !tbaa !29
  %t319 = getelementptr %"compiler/generic:Program", ptr %t317, i32 0, i32 2
  %t320 = load i32, ptr %l1, !tbaa !23
  %t323 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t319, i32 %t320)
  store i32 %t323, ptr %l172
  br label %bb79
bb79:
  %t324 = load ptr, ptr %l2, !tbaa !29
  %t325 = load i64, ptr %l3, !tbaa !24
  %t327 = add i64 %t325, 1
  %t328 = load ptr, ptr %l167, !tbaa !29
  %t329 = load i32, ptr %l172, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantStr(ptr %v0, ptr %v1, ptr %t328, i32 %t329, ptr %t324, i64 %t327)
  br label %bb80
bb80:
  br label %bb101
bb81:
  %t332 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t334 = trunc i64 22 to i32
  %t335 = icmp eq i32 %t332, %t334
  br i1 %t335, label %bb82, label %bb83
bb82:
  br label %bb86
bb83:
  %t337 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t339 = trunc i64 23 to i32
  %t340 = icmp eq i32 %t337, %t339
  br i1 %t340, label %bb84, label %bb85
bb84:
  br label %bb86
bb85:
  br label %bb96
bb86:
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t344 = getelementptr %"compiler/check:Checker", ptr %t342, i32 0, i32 1
  %t345 = load ptr, ptr %t344, !tbaa !29
  %t347 = getelementptr %"compiler/generic:Program", ptr %t345, i32 0, i32 2
  store ptr %t347, ptr %l182, !tbaa !29
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t350 = getelementptr %"compiler/check:Checker", ptr %t348, i32 0, i32 1
  %t351 = load ptr, ptr %t350, !tbaa !29
  %t353 = getelementptr %"compiler/generic:Program", ptr %t351, i32 0, i32 2
  %t354 = load i32, ptr %l1, !tbaa !23
  %t357 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t353, i32 %t354)
  store i32 %t357, ptr %l187
  br label %bb87
bb87:
  %t358 = load ptr, ptr %l182, !tbaa !29
  %t359 = load i32, ptr %l187, !tbaa !23
  %t360 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t358, i32 %t359)
  store { i64, ptr } %t360, ptr %l188
  br label %bb88
bb88:
  %t361 = load { i64, ptr }, ptr %l188, !tbaa !27
  store { i64, ptr } %t361, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t362 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t364 = extractvalue { i64, ptr } %t362, 0
  store i64 %t364, ptr %l21, !tbaa !24
  br label %bb89
bb89:
  %t366 = load i64, ptr %l20, !tbaa !24
  %t367 = load i64, ptr %l21, !tbaa !24
  %t370 = icmp slt i64 %t366, %t367
  %t372 = xor i1 %t370, true
  br i1 %t372, label %bb90, label %bb91
bb90:
  br label %bb95
bb91:
  br label %bb92
bb92:
  %t374 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t374, ptr %l195, !tbaa !27
  %t375 = load i64, ptr %l20, !tbaa !24
  %t377 = getelementptr { i64, ptr }, ptr %l195, i32 0, i32 1
  %t378 = load ptr, ptr %t377, !tbaa !27
  %t379 = getelementptr i32, ptr %t378, i64 %t375
  %t380 = load i32, ptr %t379, !tbaa !33
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t384 = load ptr, ptr %l2, !tbaa !29
  %t385 = load i64, ptr %l3, !tbaa !24
  %t387 = add i64 %t385, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantStr(ptr %v0, ptr %v1, ptr %t382, i32 %t380, ptr %t384, i64 %t387)
  br label %bb93
bb93:
  br label %bb94
bb94:
  %t392 = load i64, ptr %l20, !tbaa !24
  %t394 = add i64 %t392, 1
  store i64 %t394, ptr %l20, !tbaa !24
  br label %bb89
bb95:
  br label %bb101
bb96:
  br i1 true, label %bb97, label %bb98
bb97:
  br label %bb99
bb98:
  br label %bb100
bb99:
  br label %bb101
bb100:
  call void @__olang_check_failed(ptr @olang_loc_8830d773c2e320be_c40e682cdd96e1f2)
  unreachable
bb101:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewholeColumn(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l10 = alloca ptr
  %l12 = alloca ptr
  %l15 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca ptr
  %l56 = alloca i32
  %l57 = alloca i32
  %l58 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 10
  store ptr %t9, ptr %l10, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t10)
  store ptr %t12, ptr %l12
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l12, !tbaa !29
  %t15 = getelementptr %"compiler/check:frame", ptr %t13, i32 0, i32 1
  %t16 = load i64, ptr %t15, !tbaa !24
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t19 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t17, i64 %t16)
  store ptr %t19, ptr %l15
  br label %bb2
bb2:
  %t20 = load ptr, ptr %l15, !tbaa !29
  %t22 = getelementptr %"compiler/load:Module", ptr %t20, i32 0, i32 3
  %t23 = load i1, ptr %t22, !tbaa !21
  br i1 %t23, label %bb3, label %bb4
bb3:
  store i1 false, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t26 = load ptr, ptr %l1, !tbaa !29
  store ptr %t26, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t27 = load ptr, ptr %l19, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb6, label %bb7
bb6:
  %t30 = load ptr, ptr %l19, !tbaa !29
  %t31 = load i64, ptr %t30, !range !{i64 0, i64 8}
  %t33 = icmp eq i64 %t31, 3
  store i1 %t33, ptr %l20, !tbaa !21
  br label %bb7
bb7:
  %t34 = load i1, ptr %l20, !tbaa !21
  br i1 %t34, label %bb8, label %bb9
bb8:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr { i64, [4 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t37, i32 0, i32 2
  %t39 = load ptr, ptr %t38
  store ptr %t39, ptr %l2, !tbaa !29
  br label %bb10
bb9:
  br label %bb14
bb10:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  store ptr %t44, ptr %l26, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l27, !tbaa !29
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t48 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t46)
  store i32 %t48, ptr %l29
  br label %bb11
bb11:
  %t49 = load ptr, ptr %l27, !tbaa !29
  %t50 = load i32, ptr %l29, !tbaa !23
  %t51 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t51, ptr %l30
  br label %bb12
bb12:
  %t52 = load ptr, ptr %l26, !tbaa !29
  %t53 = load i32, ptr %l30, !tbaa !23
  %t54 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsColumns(ptr %v0, ptr %t52, i32 %t53)
  store i1 %t54, ptr %l31
  br label %bb13
bb13:
  %t55 = load i1, ptr %l31, !tbaa !21
  store i1 %t55, ptr %rv
  br label %ret
bb14:
  %t56 = load ptr, ptr %l1, !tbaa !29
  store ptr %t56, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t57 = load ptr, ptr %l32, !tbaa !29
  %t58 = icmp ne ptr %t57, null
  br i1 %t58, label %bb15, label %bb16
bb15:
  %t60 = load ptr, ptr %l32, !tbaa !29
  %t61 = load i64, ptr %t60, !range !{i64 0, i64 8}
  %t63 = icmp eq i64 %t61, 6
  store i1 %t63, ptr %l33, !tbaa !21
  br label %bb16
bb16:
  %t64 = load i1, ptr %l33, !tbaa !21
  br i1 %t64, label %bb17, label %bb18
bb17:
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr { i64, [4 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t67, i32 0, i32 2
  %t69 = load ptr, ptr %t68
  store ptr %t69, ptr %l3, !tbaa !29
  br label %bb19
bb18:
  br label %bb43
bb19:
  %t71 = load ptr, ptr %l3, !tbaa !29
  store ptr %t71, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t72 = load ptr, ptr %l38, !tbaa !29
  %t73 = icmp ne ptr %t72, null
  br i1 %t73, label %bb20, label %bb21
bb20:
  %t75 = load ptr, ptr %l38, !tbaa !29
  %t76 = load i64, ptr %t75, !range !{i64 0, i64 18}
  %t78 = icmp eq i64 %t76, 10
  store i1 %t78, ptr %l39, !tbaa !21
  br label %bb21
bb21:
  %t79 = load i1, ptr %l39, !tbaa !21
  br i1 %t79, label %bb22, label %bb23
bb22:
  %t80 = load ptr, ptr %l3, !tbaa !29
  %t82 = getelementptr { i64, [5 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t82, i32 0, i32 2
  %t84 = load ptr, ptr %t83
  store ptr %t84, ptr %l4, !tbaa !29
  br label %bb24
bb23:
  br label %bb38
bb24:
  %t86 = load ptr, ptr %l4, !tbaa !29
  %t88 = getelementptr %"compiler/typed:Slice", ptr %t86, i32 0, i32 0
  %t89 = load ptr, ptr %t88, !tbaa !29
  store ptr %t89, ptr %l5, !tbaa !29
  %t91 = load ptr, ptr %l5, !tbaa !29
  store ptr %t91, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t92 = load ptr, ptr %l46, !tbaa !29
  %t93 = icmp ne ptr %t92, null
  br i1 %t93, label %bb25, label %bb26
bb25:
  %t95 = load ptr, ptr %l46, !tbaa !29
  %t96 = load i64, ptr %t95, !range !{i64 0, i64 8}
  %t98 = icmp eq i64 %t96, 3
  store i1 %t98, ptr %l47, !tbaa !21
  br label %bb26
bb26:
  %t99 = load i1, ptr %l47, !tbaa !21
  br i1 %t99, label %bb27, label %bb28
bb27:
  %t100 = load ptr, ptr %l5, !tbaa !29
  %t102 = getelementptr { i64, [4 x i64] }, ptr %t100, i32 0, i32 1
  %t103 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t102, i32 0, i32 2
  %t104 = load ptr, ptr %t103
  store ptr %t104, ptr %l6, !tbaa !29
  br label %bb29
bb28:
  br label %bb33
bb29:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  store ptr %t109, ptr %l53, !tbaa !29
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l54, !tbaa !29
  %t111 = load ptr, ptr %l6, !tbaa !29
  %t113 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t111)
  store i32 %t113, ptr %l56
  br label %bb30
bb30:
  %t114 = load ptr, ptr %l54, !tbaa !29
  %t115 = load i32, ptr %l56, !tbaa !23
  %t116 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t114, i32 %t115)
  store i32 %t116, ptr %l57
  br label %bb31
bb31:
  %t117 = load ptr, ptr %l53, !tbaa !29
  %t118 = load i32, ptr %l57, !tbaa !23
  %t119 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsColumns(ptr %v0, ptr %t117, i32 %t118)
  store i1 %t119, ptr %l58
  br label %bb32
bb32:
  %t120 = load i1, ptr %l58, !tbaa !21
  store i1 %t120, ptr %rv
  br label %ret
bb33:
  br i1 true, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  store i1 false, ptr %rv
  br label %ret
bb37:
  call void @__olang_check_failed(ptr @olang_loc_b2735ee686977dce_6cfd672f66c8ceea)
  unreachable
bb38:
  br i1 true, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  store i1 false, ptr %rv
  br label %ret
bb42:
  call void @__olang_check_failed(ptr @olang_loc_ea26c0eb0666620f_15a39c1642164bab)
  unreachable
bb43:
  br i1 true, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb47
bb46:
  store i1 false, ptr %rv
  br label %ret
bb47:
  call void @__olang_check_failed(ptr @olang_loc_4f5af4be817f3cd4_b4ce7fc5c27c5770)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l62 = alloca i1
  %l65 = alloca i1
  %l68 = alloca i1
  %l73 = alloca i1
  %l74 = alloca ptr
  %l75 = alloca i1
  %l80 = alloca ptr
  %l81 = alloca i1
  %l86 = alloca ptr
  %l87 = alloca i1
  %l92 = alloca ptr
  %l93 = alloca i1
  %l98 = alloca ptr
  %l99 = alloca i1
  %l107 = alloca i1
  %l108 = alloca ptr
  %l109 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca i1
  %l123 = alloca i1
  %l124 = alloca ptr
  %l125 = alloca i1
  %l132 = alloca ptr
  %l133 = alloca i1
  %l140 = alloca ptr
  %l141 = alloca i1
  %l151 = alloca i1
  %l152 = alloca i1
  %l156 = alloca i1
  %l157 = alloca ptr
  %l158 = alloca i1
  %l166 = alloca i1
  %l167 = alloca ptr
  %l168 = alloca i1
  %l180 = alloca i1
  %l181 = alloca i1
  %l185 = alloca i1
  %l186 = alloca i1
  %l190 = alloca i1
  %l191 = alloca ptr
  %l192 = alloca i1
  %l199 = alloca ptr
  %l200 = alloca i1
  %l210 = alloca i1
  %l211 = alloca i1
  %l214 = alloca i1
  %l215 = alloca ptr
  %l216 = alloca i1
  %l228 = alloca i1
  %l229 = alloca i1
  %l232 = alloca i1
  %l233 = alloca i1
  %l236 = alloca i1
  %l237 = alloca ptr
  %l238 = alloca i1
  %l243 = alloca ptr
  %l244 = alloca i1
  %l249 = alloca ptr
  %l250 = alloca i1
  %l255 = alloca ptr
  %l256 = alloca i1
  %l261 = alloca ptr
  %l262 = alloca i1
  %l269 = alloca i1
  %l270 = alloca ptr
  %l271 = alloca i1
  %l280 = alloca i1
  %l281 = alloca i1
  %l286 = alloca i1
  %l287 = alloca i1
  %l291 = alloca i1
  %l292 = alloca ptr
  %l293 = alloca i1
  %l303 = alloca i1
  %l304 = alloca i1
  %l307 = alloca i1
  %l308 = alloca ptr
  %l309 = alloca i1
  %l316 = alloca i1
  %l317 = alloca ptr
  %l318 = alloca i1
  %l325 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t7 = load ptr, ptr %l26, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l26, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 30}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l27, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l27, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  br label %bb16
bb7:
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t16 = load ptr, ptr %l30, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb8, label %bb9
bb8:
  %t19 = load ptr, ptr %l30, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 30}
  %t22 = icmp eq i64 %t20, 1
  store i1 %t22, ptr %l31, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l31, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  br label %bb16
bb11:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t25 = load ptr, ptr %l34, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb12, label %bb13
bb12:
  %t28 = load ptr, ptr %l34, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 30}
  %t31 = icmp eq i64 %t29, 25
  store i1 %t31, ptr %l35, !tbaa !21
  br label %bb13
bb13:
  %t32 = load i1, ptr %l35, !tbaa !21
  br i1 %t32, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i1 false, ptr %rv
  br label %ret
bb17:
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t35 = load ptr, ptr %l39, !tbaa !29
  %t36 = icmp ne ptr %t35, null
  br i1 %t36, label %bb18, label %bb19
bb18:
  %t38 = load ptr, ptr %l39, !tbaa !29
  %t39 = load i64, ptr %t38, !range !{i64 0, i64 30}
  %t41 = icmp eq i64 %t39, 22
  store i1 %t41, ptr %l40, !tbaa !21
  br label %bb19
bb19:
  %t42 = load i1, ptr %l40, !tbaa !21
  br i1 %t42, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  store i1 false, ptr %rv
  br label %ret
bb23:
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t45 = load ptr, ptr %l44, !tbaa !29
  %t46 = icmp ne ptr %t45, null
  br i1 %t46, label %bb24, label %bb25
bb24:
  %t48 = load ptr, ptr %l44, !tbaa !29
  %t49 = load i64, ptr %t48, !range !{i64 0, i64 30}
  %t51 = icmp eq i64 %t49, 3
  store i1 %t51, ptr %l45, !tbaa !21
  br label %bb25
bb25:
  %t52 = load i1, ptr %l45, !tbaa !21
  br i1 %t52, label %bb26, label %bb27
bb26:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr { i64, [4 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t55, i32 0, i32 1
  %t57 = load i32, ptr %t56, !range !{i32 0, i32 98}
  store i32 %t57, ptr %l2
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t61, i32 0, i32 2
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l3, !tbaa !29
  br label %bb32
bb27:
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t66 = load ptr, ptr %l52, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb28, label %bb29
bb28:
  %t69 = load ptr, ptr %l52, !tbaa !29
  %t70 = load i64, ptr %t69, !range !{i64 0, i64 30}
  %t72 = icmp eq i64 %t70, 4
  store i1 %t72, ptr %l53, !tbaa !21
  br label %bb29
bb29:
  %t73 = load i1, ptr %l53, !tbaa !21
  br i1 %t73, label %bb30, label %bb31
bb30:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t76, i32 0, i32 1
  %t78 = load i32, ptr %t77, !range !{i32 0, i32 98}
  store i32 %t78, ptr %l2
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr { i64, [4 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t82, i32 0, i32 2
  %t84 = load ptr, ptr %t83
  store ptr %t84, ptr %l3, !tbaa !29
  br label %bb32
bb31:
  br label %bb44
bb32:
  %t86 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t88 = trunc i64 76 to i32
  %t89 = icmp eq i32 %t86, %t88
  br i1 %t89, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb35
bb34:
  %t91 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t93 = trunc i64 77 to i32
  %t94 = icmp eq i32 %t91, %t93
  store i1 %t94, ptr %l62, !tbaa !21
  br label %bb35
bb35:
  %t96 = load i1, ptr %l62, !tbaa !21
  br i1 %t96, label %bb36, label %bb37
bb36:
  %t97 = load ptr, ptr %l3, !tbaa !29
  %t98 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t101 = call i1 @compiler_2fcheck_2ehitsPath(ptr %v0, ptr %v1, ptr %t97, { i64, ptr } %t98)
  store i1 %t101, ptr %l68
  br label %bb38
bb37:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb39
bb38:
  %t102 = load i1, ptr %l68, !tbaa !21
  store i1 %t102, ptr %l65, !tbaa !21
  br label %bb39
bb39:
  %t103 = load i1, ptr %l65, !tbaa !21
  br i1 %t103, label %bb40, label %bb41
bb40:
  store i1 true, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  %t105 = load ptr, ptr %l3, !tbaa !29
  %t107 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t110 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t105, { i64, ptr } %t107)
  store i1 %t110, ptr %l73
  br label %bb43
bb43:
  %t111 = load i1, ptr %l73, !tbaa !21
  store i1 %t111, ptr %rv
  br label %ret
bb44:
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l74, !tbaa !29
  store i1 false, ptr %l75, !tbaa !21
  %t113 = load ptr, ptr %l74, !tbaa !29
  %t114 = icmp ne ptr %t113, null
  br i1 %t114, label %bb45, label %bb46
bb45:
  %t116 = load ptr, ptr %l74, !tbaa !29
  %t117 = load i64, ptr %t116, !range !{i64 0, i64 30}
  %t119 = icmp eq i64 %t117, 2
  store i1 %t119, ptr %l75, !tbaa !21
  br label %bb46
bb46:
  %t120 = load i1, ptr %l75, !tbaa !21
  br i1 %t120, label %bb47, label %bb48
bb47:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr { i64, [4 x i64] }, ptr %t121, i32 0, i32 1
  %t124 = getelementptr { %"compiler/source:Span", ptr }, ptr %t123, i32 0, i32 1
  %t125 = load ptr, ptr %t124
  store ptr %t125, ptr %l4, !tbaa !29
  br label %bb65
bb48:
  %t127 = load ptr, ptr %l0, !tbaa !29
  store ptr %t127, ptr %l80, !tbaa !29
  store i1 false, ptr %l81, !tbaa !21
  %t128 = load ptr, ptr %l80, !tbaa !29
  %t129 = icmp ne ptr %t128, null
  br i1 %t129, label %bb49, label %bb50
bb49:
  %t131 = load ptr, ptr %l80, !tbaa !29
  %t132 = load i64, ptr %t131, !range !{i64 0, i64 30}
  %t134 = icmp eq i64 %t132, 26
  store i1 %t134, ptr %l81, !tbaa !21
  br label %bb50
bb50:
  %t135 = load i1, ptr %l81, !tbaa !21
  br i1 %t135, label %bb51, label %bb52
bb51:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr { i64, [4 x i64] }, ptr %t136, i32 0, i32 1
  %t139 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t138, i32 0, i32 2
  %t140 = load ptr, ptr %t139
  store ptr %t140, ptr %l4, !tbaa !29
  br label %bb65
bb52:
  %t142 = load ptr, ptr %l0, !tbaa !29
  store ptr %t142, ptr %l86, !tbaa !29
  store i1 false, ptr %l87, !tbaa !21
  %t143 = load ptr, ptr %l86, !tbaa !29
  %t144 = icmp ne ptr %t143, null
  br i1 %t144, label %bb53, label %bb54
bb53:
  %t146 = load ptr, ptr %l86, !tbaa !29
  %t147 = load i64, ptr %t146, !range !{i64 0, i64 30}
  %t149 = icmp eq i64 %t147, 28
  store i1 %t149, ptr %l87, !tbaa !21
  br label %bb54
bb54:
  %t150 = load i1, ptr %l87, !tbaa !21
  br i1 %t150, label %bb55, label %bb56
bb55:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr { i64, [4 x i64] }, ptr %t151, i32 0, i32 1
  %t154 = getelementptr { %"compiler/source:Span", ptr }, ptr %t153, i32 0, i32 1
  %t155 = load ptr, ptr %t154
  store ptr %t155, ptr %l4, !tbaa !29
  br label %bb65
bb56:
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l92, !tbaa !29
  store i1 false, ptr %l93, !tbaa !21
  %t158 = load ptr, ptr %l92, !tbaa !29
  %t159 = icmp ne ptr %t158, null
  br i1 %t159, label %bb57, label %bb58
bb57:
  %t161 = load ptr, ptr %l92, !tbaa !29
  %t162 = load i64, ptr %t161, !range !{i64 0, i64 30}
  %t164 = icmp eq i64 %t162, 14
  store i1 %t164, ptr %l93, !tbaa !21
  br label %bb58
bb58:
  %t165 = load i1, ptr %l93, !tbaa !21
  br i1 %t165, label %bb59, label %bb60
bb59:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr { i64, [4 x i64] }, ptr %t166, i32 0, i32 1
  %t169 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t168, i32 0, i32 1
  %t170 = load ptr, ptr %t169
  store ptr %t170, ptr %l4, !tbaa !29
  br label %bb65
bb60:
  %t172 = load ptr, ptr %l0, !tbaa !29
  store ptr %t172, ptr %l98, !tbaa !29
  store i1 false, ptr %l99, !tbaa !21
  %t173 = load ptr, ptr %l98, !tbaa !29
  %t174 = icmp ne ptr %t173, null
  br i1 %t174, label %bb61, label %bb62
bb61:
  %t176 = load ptr, ptr %l98, !tbaa !29
  %t177 = load i64, ptr %t176, !range !{i64 0, i64 30}
  %t179 = icmp eq i64 %t177, 13
  store i1 %t179, ptr %l99, !tbaa !21
  br label %bb62
bb62:
  %t180 = load i1, ptr %l99, !tbaa !21
  br i1 %t180, label %bb63, label %bb64
bb63:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr { i64, [4 x i64] }, ptr %t181, i32 0, i32 1
  %t184 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t183, i32 0, i32 1
  %t185 = load ptr, ptr %t184
  store ptr %t185, ptr %l4, !tbaa !29
  br label %bb65
bb64:
  br label %bb67
bb65:
  %t187 = load ptr, ptr %l4, !tbaa !29
  %t189 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t192 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t187, { i64, ptr } %t189)
  store i1 %t192, ptr %l107
  br label %bb66
bb66:
  %t193 = load i1, ptr %l107, !tbaa !21
  store i1 %t193, ptr %rv
  br label %ret
bb67:
  %t194 = load ptr, ptr %l0, !tbaa !29
  store ptr %t194, ptr %l108, !tbaa !29
  store i1 false, ptr %l109, !tbaa !21
  %t195 = load ptr, ptr %l108, !tbaa !29
  %t196 = icmp ne ptr %t195, null
  br i1 %t196, label %bb68, label %bb69
bb68:
  %t198 = load ptr, ptr %l108, !tbaa !29
  %t199 = load i64, ptr %t198, !range !{i64 0, i64 30}
  %t201 = icmp eq i64 %t199, 9
  store i1 %t201, ptr %l109, !tbaa !21
  br label %bb69
bb69:
  %t202 = load i1, ptr %l109, !tbaa !21
  br i1 %t202, label %bb70, label %bb71
bb70:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr { i64, [4 x i64] }, ptr %t203, i32 0, i32 1
  %t206 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t205, i32 0, i32 1
  %t207 = load ptr, ptr %t206
  store ptr %t207, ptr %l5, !tbaa !29
  br label %bb76
bb71:
  %t209 = load ptr, ptr %l0, !tbaa !29
  store ptr %t209, ptr %l114, !tbaa !29
  store i1 false, ptr %l115, !tbaa !21
  %t210 = load ptr, ptr %l114, !tbaa !29
  %t211 = icmp ne ptr %t210, null
  br i1 %t211, label %bb72, label %bb73
bb72:
  %t213 = load ptr, ptr %l114, !tbaa !29
  %t214 = load i64, ptr %t213, !range !{i64 0, i64 30}
  %t216 = icmp eq i64 %t214, 11
  store i1 %t216, ptr %l115, !tbaa !21
  br label %bb73
bb73:
  %t217 = load i1, ptr %l115, !tbaa !21
  br i1 %t217, label %bb74, label %bb75
bb74:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t220 = getelementptr { i64, [4 x i64] }, ptr %t218, i32 0, i32 1
  %t221 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t220, i32 0, i32 1
  %t222 = load ptr, ptr %t221
  store ptr %t222, ptr %l5, !tbaa !29
  br label %bb76
bb75:
  br label %bb78
bb76:
  %t224 = load ptr, ptr %l5, !tbaa !29
  %t226 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t229 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t224, { i64, ptr } %t226)
  store i1 %t229, ptr %l123
  br label %bb77
bb77:
  %t230 = load i1, ptr %l123, !tbaa !21
  store i1 %t230, ptr %rv
  br label %ret
bb78:
  %t231 = load ptr, ptr %l0, !tbaa !29
  store ptr %t231, ptr %l124, !tbaa !29
  store i1 false, ptr %l125, !tbaa !21
  %t232 = load ptr, ptr %l124, !tbaa !29
  %t233 = icmp ne ptr %t232, null
  br i1 %t233, label %bb79, label %bb80
bb79:
  %t235 = load ptr, ptr %l124, !tbaa !29
  %t236 = load i64, ptr %t235, !range !{i64 0, i64 30}
  %t238 = icmp eq i64 %t236, 5
  store i1 %t238, ptr %l125, !tbaa !21
  br label %bb80
bb80:
  %t239 = load i1, ptr %l125, !tbaa !21
  br i1 %t239, label %bb81, label %bb82
bb81:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = getelementptr { i64, [4 x i64] }, ptr %t240, i32 0, i32 1
  %t243 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t242, i32 0, i32 2
  %t244 = load ptr, ptr %t243
  store ptr %t244, ptr %l6, !tbaa !29
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t248 = getelementptr { i64, [4 x i64] }, ptr %t246, i32 0, i32 1
  %t249 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t248, i32 0, i32 3
  %t250 = load ptr, ptr %t249
  store ptr %t250, ptr %l7, !tbaa !29
  br label %bb91
bb82:
  %t252 = load ptr, ptr %l0, !tbaa !29
  store ptr %t252, ptr %l132, !tbaa !29
  store i1 false, ptr %l133, !tbaa !21
  %t253 = load ptr, ptr %l132, !tbaa !29
  %t254 = icmp ne ptr %t253, null
  br i1 %t254, label %bb83, label %bb84
bb83:
  %t256 = load ptr, ptr %l132, !tbaa !29
  %t257 = load i64, ptr %t256, !range !{i64 0, i64 30}
  %t259 = icmp eq i64 %t257, 6
  store i1 %t259, ptr %l133, !tbaa !21
  br label %bb84
bb84:
  %t260 = load i1, ptr %l133, !tbaa !21
  br i1 %t260, label %bb85, label %bb86
bb85:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr { i64, [4 x i64] }, ptr %t261, i32 0, i32 1
  %t264 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t263, i32 0, i32 1
  %t265 = load ptr, ptr %t264
  store ptr %t265, ptr %l6, !tbaa !29
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr { i64, [4 x i64] }, ptr %t267, i32 0, i32 1
  %t270 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t269, i32 0, i32 2
  %t271 = load ptr, ptr %t270
  store ptr %t271, ptr %l7, !tbaa !29
  br label %bb91
bb86:
  %t273 = load ptr, ptr %l0, !tbaa !29
  store ptr %t273, ptr %l140, !tbaa !29
  store i1 false, ptr %l141, !tbaa !21
  %t274 = load ptr, ptr %l140, !tbaa !29
  %t275 = icmp ne ptr %t274, null
  br i1 %t275, label %bb87, label %bb88
bb87:
  %t277 = load ptr, ptr %l140, !tbaa !29
  %t278 = load i64, ptr %t277, !range !{i64 0, i64 30}
  %t280 = icmp eq i64 %t278, 10
  store i1 %t280, ptr %l141, !tbaa !21
  br label %bb88
bb88:
  %t281 = load i1, ptr %l141, !tbaa !21
  br i1 %t281, label %bb89, label %bb90
bb89:
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t284 = getelementptr { i64, [4 x i64] }, ptr %t282, i32 0, i32 1
  %t285 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t284, i32 0, i32 1
  %t286 = load ptr, ptr %t285
  store ptr %t286, ptr %l6, !tbaa !29
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t290 = getelementptr { i64, [4 x i64] }, ptr %t288, i32 0, i32 1
  %t291 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t290, i32 0, i32 2
  %t292 = load ptr, ptr %t291
  store ptr %t292, ptr %l7, !tbaa !29
  br label %bb91
bb90:
  br label %bb97
bb91:
  %t294 = load ptr, ptr %l6, !tbaa !29
  %t296 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t299 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t294, { i64, ptr } %t296)
  store i1 %t299, ptr %l151
  br label %bb92
bb92:
  %t300 = load i1, ptr %l151, !tbaa !21
  br i1 %t300, label %bb93, label %bb94
bb93:
  store i1 true, ptr %l152, !tbaa !21
  br label %bb96
bb94:
  %t301 = load ptr, ptr %l7, !tbaa !29
  %t303 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t306 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t301, { i64, ptr } %t303)
  store i1 %t306, ptr %l156
  br label %bb95
bb95:
  %t307 = load i1, ptr %l156, !tbaa !21
  store i1 %t307, ptr %l152, !tbaa !21
  br label %bb96
bb96:
  %t308 = load i1, ptr %l152, !tbaa !21
  store i1 %t308, ptr %rv
  br label %ret
bb97:
  %t309 = load ptr, ptr %l0, !tbaa !29
  store ptr %t309, ptr %l157, !tbaa !29
  store i1 false, ptr %l158, !tbaa !21
  %t310 = load ptr, ptr %l157, !tbaa !29
  %t311 = icmp ne ptr %t310, null
  br i1 %t311, label %bb98, label %bb99
bb98:
  %t313 = load ptr, ptr %l157, !tbaa !29
  %t314 = load i64, ptr %t313, !range !{i64 0, i64 30}
  %t316 = icmp eq i64 %t314, 7
  store i1 %t316, ptr %l158, !tbaa !21
  br label %bb99
bb99:
  %t317 = load i1, ptr %l158, !tbaa !21
  br i1 %t317, label %bb100, label %bb101
bb100:
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t320 = getelementptr { i64, [4 x i64] }, ptr %t318, i32 0, i32 1
  %t321 = getelementptr { %"compiler/source:Span", ptr }, ptr %t320, i32 0, i32 1
  %t322 = load ptr, ptr %t321
  store ptr %t322, ptr %l8, !tbaa !29
  br label %bb102
bb101:
  br label %bb104
bb102:
  %t324 = load ptr, ptr %l8, !tbaa !29
  %t326 = getelementptr %"compiler/ast:Chain", ptr %t324, i32 0, i32 1
  %t327 = load { i64, ptr }, ptr %t326, !tbaa !27
  %t328 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t331 = call i1 @compiler_2fcheck_2eexprsAssign(ptr %v0, ptr %v1, { i64, ptr } %t327, { i64, ptr } %t328)
  store i1 %t331, ptr %l166
  br label %bb103
bb103:
  %t332 = load i1, ptr %l166, !tbaa !21
  store i1 %t332, ptr %rv
  br label %ret
bb104:
  %t333 = load ptr, ptr %l0, !tbaa !29
  store ptr %t333, ptr %l167, !tbaa !29
  store i1 false, ptr %l168, !tbaa !21
  %t334 = load ptr, ptr %l167, !tbaa !29
  %t335 = icmp ne ptr %t334, null
  br i1 %t335, label %bb105, label %bb106
bb105:
  %t337 = load ptr, ptr %l167, !tbaa !29
  %t338 = load i64, ptr %t337, !range !{i64 0, i64 30}
  %t340 = icmp eq i64 %t338, 8
  store i1 %t340, ptr %l168, !tbaa !21
  br label %bb106
bb106:
  %t341 = load i1, ptr %l168, !tbaa !21
  br i1 %t341, label %bb107, label %bb108
bb107:
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t344 = getelementptr { i64, [4 x i64] }, ptr %t342, i32 0, i32 1
  %t345 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t344, i32 0, i32 1
  %t346 = load ptr, ptr %t345
  store ptr %t346, ptr %l9, !tbaa !29
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t350 = getelementptr { i64, [4 x i64] }, ptr %t348, i32 0, i32 1
  %t351 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t350, i32 0, i32 2
  %t352 = load ptr, ptr %t351
  store ptr %t352, ptr %l10, !tbaa !29
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t356 = getelementptr { i64, [4 x i64] }, ptr %t354, i32 0, i32 1
  %t357 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t356, i32 0, i32 3
  %t358 = load ptr, ptr %t357
  store ptr %t358, ptr %l11, !tbaa !29
  br label %bb109
bb108:
  br label %bb119
bb109:
  %t360 = load ptr, ptr %l9, !tbaa !29
  %t362 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t365 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t360, { i64, ptr } %t362)
  store i1 %t365, ptr %l180
  br label %bb110
bb110:
  %t366 = load i1, ptr %l180, !tbaa !21
  br i1 %t366, label %bb111, label %bb112
bb111:
  store i1 true, ptr %l181, !tbaa !21
  br label %bb114
bb112:
  %t367 = load ptr, ptr %l10, !tbaa !29
  %t369 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t372 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t367, { i64, ptr } %t369)
  store i1 %t372, ptr %l185
  br label %bb113
bb113:
  %t373 = load i1, ptr %l185, !tbaa !21
  store i1 %t373, ptr %l181, !tbaa !21
  br label %bb114
bb114:
  %t374 = load i1, ptr %l181, !tbaa !21
  br i1 %t374, label %bb115, label %bb116
bb115:
  store i1 true, ptr %l186, !tbaa !21
  br label %bb118
bb116:
  %t375 = load ptr, ptr %l11, !tbaa !29
  %t377 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t380 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t375, { i64, ptr } %t377)
  store i1 %t380, ptr %l190
  br label %bb117
bb117:
  %t381 = load i1, ptr %l190, !tbaa !21
  store i1 %t381, ptr %l186, !tbaa !21
  br label %bb118
bb118:
  %t382 = load i1, ptr %l186, !tbaa !21
  store i1 %t382, ptr %rv
  br label %ret
bb119:
  %t383 = load ptr, ptr %l0, !tbaa !29
  store ptr %t383, ptr %l191, !tbaa !29
  store i1 false, ptr %l192, !tbaa !21
  %t384 = load ptr, ptr %l191, !tbaa !29
  %t385 = icmp ne ptr %t384, null
  br i1 %t385, label %bb120, label %bb121
bb120:
  %t387 = load ptr, ptr %l191, !tbaa !29
  %t388 = load i64, ptr %t387, !range !{i64 0, i64 30}
  %t390 = icmp eq i64 %t388, 12
  store i1 %t390, ptr %l192, !tbaa !21
  br label %bb121
bb121:
  %t391 = load i1, ptr %l192, !tbaa !21
  br i1 %t391, label %bb122, label %bb123
bb122:
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t394 = getelementptr { i64, [4 x i64] }, ptr %t392, i32 0, i32 1
  %t395 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t394, i32 0, i32 1
  %t396 = load ptr, ptr %t395
  store ptr %t396, ptr %l12, !tbaa !29
  %t398 = load ptr, ptr %l0, !tbaa !29
  %t400 = getelementptr { i64, [4 x i64] }, ptr %t398, i32 0, i32 1
  %t401 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t400, i32 0, i32 2
  %t402 = load { i64, ptr }, ptr %t401
  store { i64, ptr } %t402, ptr %l13, !tbaa !27
  br label %bb128
bb123:
  %t404 = load ptr, ptr %l0, !tbaa !29
  store ptr %t404, ptr %l199, !tbaa !29
  store i1 false, ptr %l200, !tbaa !21
  %t405 = load ptr, ptr %l199, !tbaa !29
  %t406 = icmp ne ptr %t405, null
  br i1 %t406, label %bb124, label %bb125
bb124:
  %t408 = load ptr, ptr %l199, !tbaa !29
  %t409 = load i64, ptr %t408, !range !{i64 0, i64 30}
  %t411 = icmp eq i64 %t409, 15
  store i1 %t411, ptr %l200, !tbaa !21
  br label %bb125
bb125:
  %t412 = load i1, ptr %l200, !tbaa !21
  br i1 %t412, label %bb126, label %bb127
bb126:
  %t413 = load ptr, ptr %l0, !tbaa !29
  %t415 = getelementptr { i64, [4 x i64] }, ptr %t413, i32 0, i32 1
  %t416 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t415, i32 0, i32 1
  %t417 = load ptr, ptr %t416
  store ptr %t417, ptr %l12, !tbaa !29
  %t419 = load ptr, ptr %l0, !tbaa !29
  %t421 = getelementptr { i64, [4 x i64] }, ptr %t419, i32 0, i32 1
  %t422 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t421, i32 0, i32 2
  %t423 = load { i64, ptr }, ptr %t422
  store { i64, ptr } %t423, ptr %l13, !tbaa !27
  br label %bb128
bb127:
  br label %bb134
bb128:
  %t425 = load ptr, ptr %l12, !tbaa !29
  %t427 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t430 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t425, { i64, ptr } %t427)
  store i1 %t430, ptr %l210
  br label %bb129
bb129:
  %t431 = load i1, ptr %l210, !tbaa !21
  br i1 %t431, label %bb130, label %bb131
bb130:
  store i1 true, ptr %l211, !tbaa !21
  br label %bb133
bb131:
  %t432 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t433 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t436 = call i1 @compiler_2fcheck_2eexprsAssign(ptr %v0, ptr %v1, { i64, ptr } %t432, { i64, ptr } %t433)
  store i1 %t436, ptr %l214
  br label %bb132
bb132:
  %t437 = load i1, ptr %l214, !tbaa !21
  store i1 %t437, ptr %l211, !tbaa !21
  br label %bb133
bb133:
  %t438 = load i1, ptr %l211, !tbaa !21
  store i1 %t438, ptr %rv
  br label %ret
bb134:
  %t439 = load ptr, ptr %l0, !tbaa !29
  store ptr %t439, ptr %l215, !tbaa !29
  store i1 false, ptr %l216, !tbaa !21
  %t440 = load ptr, ptr %l215, !tbaa !29
  %t441 = icmp ne ptr %t440, null
  br i1 %t441, label %bb135, label %bb136
bb135:
  %t443 = load ptr, ptr %l215, !tbaa !29
  %t444 = load i64, ptr %t443, !range !{i64 0, i64 30}
  %t446 = icmp eq i64 %t444, 16
  store i1 %t446, ptr %l216, !tbaa !21
  br label %bb136
bb136:
  %t447 = load i1, ptr %l216, !tbaa !21
  br i1 %t447, label %bb137, label %bb138
bb137:
  %t448 = load ptr, ptr %l0, !tbaa !29
  %t450 = getelementptr { i64, [4 x i64] }, ptr %t448, i32 0, i32 1
  %t451 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t450, i32 0, i32 1
  %t452 = load ptr, ptr %t451
  store ptr %t452, ptr %l14, !tbaa !29
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t456 = getelementptr { i64, [4 x i64] }, ptr %t454, i32 0, i32 1
  %t457 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t456, i32 0, i32 2
  %t458 = load ptr, ptr %t457
  store ptr %t458, ptr %l15, !tbaa !29
  %t460 = load ptr, ptr %l0, !tbaa !29
  %t462 = getelementptr { i64, [4 x i64] }, ptr %t460, i32 0, i32 1
  %t463 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t462, i32 0, i32 3
  %t464 = load ptr, ptr %t463
  store ptr %t464, ptr %l16, !tbaa !29
  br label %bb139
bb138:
  br label %bb149
bb139:
  %t466 = load ptr, ptr %l14, !tbaa !29
  %t468 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t471 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t466, { i64, ptr } %t468)
  store i1 %t471, ptr %l228
  br label %bb140
bb140:
  %t472 = load i1, ptr %l228, !tbaa !21
  br i1 %t472, label %bb141, label %bb142
bb141:
  store i1 true, ptr %l229, !tbaa !21
  br label %bb144
bb142:
  %t473 = load ptr, ptr %l15, !tbaa !29
  %t474 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t477 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t473, { i64, ptr } %t474)
  store i1 %t477, ptr %l232
  br label %bb143
bb143:
  %t478 = load i1, ptr %l232, !tbaa !21
  store i1 %t478, ptr %l229, !tbaa !21
  br label %bb144
bb144:
  %t479 = load i1, ptr %l229, !tbaa !21
  br i1 %t479, label %bb145, label %bb146
bb145:
  store i1 true, ptr %l233, !tbaa !21
  br label %bb148
bb146:
  %t480 = load ptr, ptr %l16, !tbaa !29
  %t481 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t484 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t480, { i64, ptr } %t481)
  store i1 %t484, ptr %l236
  br label %bb147
bb147:
  %t485 = load i1, ptr %l236, !tbaa !21
  store i1 %t485, ptr %l233, !tbaa !21
  br label %bb148
bb148:
  %t486 = load i1, ptr %l233, !tbaa !21
  store i1 %t486, ptr %rv
  br label %ret
bb149:
  %t487 = load ptr, ptr %l0, !tbaa !29
  store ptr %t487, ptr %l237, !tbaa !29
  store i1 false, ptr %l238, !tbaa !21
  %t488 = load ptr, ptr %l237, !tbaa !29
  %t489 = icmp ne ptr %t488, null
  br i1 %t489, label %bb150, label %bb151
bb150:
  %t491 = load ptr, ptr %l237, !tbaa !29
  %t492 = load i64, ptr %t491, !range !{i64 0, i64 30}
  %t494 = icmp eq i64 %t492, 17
  store i1 %t494, ptr %l238, !tbaa !21
  br label %bb151
bb151:
  %t495 = load i1, ptr %l238, !tbaa !21
  br i1 %t495, label %bb152, label %bb153
bb152:
  %t496 = load ptr, ptr %l0, !tbaa !29
  %t498 = getelementptr { i64, [4 x i64] }, ptr %t496, i32 0, i32 1
  %t499 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t498, i32 0, i32 2
  %t500 = load { i64, ptr }, ptr %t499
  store { i64, ptr } %t500, ptr %l17, !tbaa !27
  br label %bb170
bb153:
  %t502 = load ptr, ptr %l0, !tbaa !29
  store ptr %t502, ptr %l243, !tbaa !29
  store i1 false, ptr %l244, !tbaa !21
  %t503 = load ptr, ptr %l243, !tbaa !29
  %t504 = icmp ne ptr %t503, null
  br i1 %t504, label %bb154, label %bb155
bb154:
  %t506 = load ptr, ptr %l243, !tbaa !29
  %t507 = load i64, ptr %t506, !range !{i64 0, i64 30}
  %t509 = icmp eq i64 %t507, 18
  store i1 %t509, ptr %l244, !tbaa !21
  br label %bb155
bb155:
  %t510 = load i1, ptr %l244, !tbaa !21
  br i1 %t510, label %bb156, label %bb157
bb156:
  %t511 = load ptr, ptr %l0, !tbaa !29
  %t513 = getelementptr { i64, [4 x i64] }, ptr %t511, i32 0, i32 1
  %t514 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t513, i32 0, i32 1
  %t515 = load { i64, ptr }, ptr %t514
  store { i64, ptr } %t515, ptr %l17, !tbaa !27
  br label %bb170
bb157:
  %t517 = load ptr, ptr %l0, !tbaa !29
  store ptr %t517, ptr %l249, !tbaa !29
  store i1 false, ptr %l250, !tbaa !21
  %t518 = load ptr, ptr %l249, !tbaa !29
  %t519 = icmp ne ptr %t518, null
  br i1 %t519, label %bb158, label %bb159
bb158:
  %t521 = load ptr, ptr %l249, !tbaa !29
  %t522 = load i64, ptr %t521, !range !{i64 0, i64 30}
  %t524 = icmp eq i64 %t522, 29
  store i1 %t524, ptr %l250, !tbaa !21
  br label %bb159
bb159:
  %t525 = load i1, ptr %l250, !tbaa !21
  br i1 %t525, label %bb160, label %bb161
bb160:
  %t526 = load ptr, ptr %l0, !tbaa !29
  %t528 = getelementptr { i64, [4 x i64] }, ptr %t526, i32 0, i32 1
  %t529 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t528, i32 0, i32 1
  %t530 = load { i64, ptr }, ptr %t529
  store { i64, ptr } %t530, ptr %l17, !tbaa !27
  br label %bb170
bb161:
  %t532 = load ptr, ptr %l0, !tbaa !29
  store ptr %t532, ptr %l255, !tbaa !29
  store i1 false, ptr %l256, !tbaa !21
  %t533 = load ptr, ptr %l255, !tbaa !29
  %t534 = icmp ne ptr %t533, null
  br i1 %t534, label %bb162, label %bb163
bb162:
  %t536 = load ptr, ptr %l255, !tbaa !29
  %t537 = load i64, ptr %t536, !range !{i64 0, i64 30}
  %t539 = icmp eq i64 %t537, 20
  store i1 %t539, ptr %l256, !tbaa !21
  br label %bb163
bb163:
  %t540 = load i1, ptr %l256, !tbaa !21
  br i1 %t540, label %bb164, label %bb165
bb164:
  %t541 = load ptr, ptr %l0, !tbaa !29
  %t543 = getelementptr { i64, [4 x i64] }, ptr %t541, i32 0, i32 1
  %t544 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t543, i32 0, i32 1
  %t545 = load { i64, ptr }, ptr %t544
  store { i64, ptr } %t545, ptr %l17, !tbaa !27
  br label %bb170
bb165:
  %t547 = load ptr, ptr %l0, !tbaa !29
  store ptr %t547, ptr %l261, !tbaa !29
  store i1 false, ptr %l262, !tbaa !21
  %t548 = load ptr, ptr %l261, !tbaa !29
  %t549 = icmp ne ptr %t548, null
  br i1 %t549, label %bb166, label %bb167
bb166:
  %t551 = load ptr, ptr %l261, !tbaa !29
  %t552 = load i64, ptr %t551, !range !{i64 0, i64 30}
  %t554 = icmp eq i64 %t552, 24
  store i1 %t554, ptr %l262, !tbaa !21
  br label %bb167
bb167:
  %t555 = load i1, ptr %l262, !tbaa !21
  br i1 %t555, label %bb168, label %bb169
bb168:
  %t556 = load ptr, ptr %l0, !tbaa !29
  %t558 = getelementptr { i64, [4 x i64] }, ptr %t556, i32 0, i32 1
  %t559 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t558, i32 0, i32 1
  %t560 = load { i64, ptr }, ptr %t559
  store { i64, ptr } %t560, ptr %l17, !tbaa !27
  br label %bb170
bb169:
  br label %bb172
bb170:
  %t562 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t563 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t566 = call i1 @compiler_2fcheck_2eexprsAssign(ptr %v0, ptr %v1, { i64, ptr } %t562, { i64, ptr } %t563)
  store i1 %t566, ptr %l269
  br label %bb171
bb171:
  %t567 = load i1, ptr %l269, !tbaa !21
  store i1 %t567, ptr %rv
  br label %ret
bb172:
  %t568 = load ptr, ptr %l0, !tbaa !29
  store ptr %t568, ptr %l270, !tbaa !29
  store i1 false, ptr %l271, !tbaa !21
  %t569 = load ptr, ptr %l270, !tbaa !29
  %t570 = icmp ne ptr %t569, null
  br i1 %t570, label %bb173, label %bb174
bb173:
  %t572 = load ptr, ptr %l270, !tbaa !29
  %t573 = load i64, ptr %t572, !range !{i64 0, i64 30}
  %t575 = icmp eq i64 %t573, 19
  store i1 %t575, ptr %l271, !tbaa !21
  br label %bb174
bb174:
  %t576 = load i1, ptr %l271, !tbaa !21
  br i1 %t576, label %bb175, label %bb176
bb175:
  %t577 = load ptr, ptr %l0, !tbaa !29
  %t579 = getelementptr { i64, [4 x i64] }, ptr %t577, i32 0, i32 1
  %t580 = getelementptr { %"compiler/source:Span", ptr }, ptr %t579, i32 0, i32 1
  %t581 = load ptr, ptr %t580
  store ptr %t581, ptr %l18, !tbaa !29
  br label %bb177
bb176:
  br label %bb187
bb177:
  %t583 = load ptr, ptr %l18, !tbaa !29
  %t585 = getelementptr %"compiler/ast:Compr", ptr %t583, i32 0, i32 1
  %t586 = load ptr, ptr %t585, !tbaa !29
  %t588 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t591 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t586, { i64, ptr } %t588)
  store i1 %t591, ptr %l280
  br label %bb178
bb178:
  %t592 = load i1, ptr %l280, !tbaa !21
  br i1 %t592, label %bb179, label %bb180
bb179:
  store i1 true, ptr %l281, !tbaa !21
  br label %bb182
bb180:
  %t593 = load ptr, ptr %l18, !tbaa !29
  %t595 = getelementptr %"compiler/ast:Compr", ptr %t593, i32 0, i32 4
  %t596 = load ptr, ptr %t595, !tbaa !29
  %t598 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t601 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t596, { i64, ptr } %t598)
  store i1 %t601, ptr %l286
  br label %bb181
bb181:
  %t602 = load i1, ptr %l286, !tbaa !21
  store i1 %t602, ptr %l281, !tbaa !21
  br label %bb182
bb182:
  %t603 = load i1, ptr %l281, !tbaa !21
  br i1 %t603, label %bb183, label %bb184
bb183:
  store i1 true, ptr %l287, !tbaa !21
  br label %bb186
bb184:
  %t604 = load ptr, ptr %l18, !tbaa !29
  %t606 = getelementptr %"compiler/ast:Compr", ptr %t604, i32 0, i32 5
  %t607 = load ptr, ptr %t606, !tbaa !29
  %t608 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t611 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t607, { i64, ptr } %t608)
  store i1 %t611, ptr %l291
  br label %bb185
bb185:
  %t612 = load i1, ptr %l291, !tbaa !21
  store i1 %t612, ptr %l287, !tbaa !21
  br label %bb186
bb186:
  %t613 = load i1, ptr %l287, !tbaa !21
  store i1 %t613, ptr %rv
  br label %ret
bb187:
  %t614 = load ptr, ptr %l0, !tbaa !29
  store ptr %t614, ptr %l292, !tbaa !29
  store i1 false, ptr %l293, !tbaa !21
  %t615 = load ptr, ptr %l292, !tbaa !29
  %t616 = icmp ne ptr %t615, null
  br i1 %t616, label %bb188, label %bb189
bb188:
  %t618 = load ptr, ptr %l292, !tbaa !29
  %t619 = load i64, ptr %t618, !range !{i64 0, i64 30}
  %t621 = icmp eq i64 %t619, 21
  store i1 %t621, ptr %l293, !tbaa !21
  br label %bb189
bb189:
  %t622 = load i1, ptr %l293, !tbaa !21
  br i1 %t622, label %bb190, label %bb191
bb190:
  %t623 = load ptr, ptr %l0, !tbaa !29
  %t625 = getelementptr { i64, [4 x i64] }, ptr %t623, i32 0, i32 1
  %t626 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t625, i32 0, i32 1
  %t627 = load ptr, ptr %t626
  store ptr %t627, ptr %l19, !tbaa !29
  %t629 = load ptr, ptr %l0, !tbaa !29
  %t631 = getelementptr { i64, [4 x i64] }, ptr %t629, i32 0, i32 1
  %t632 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t631, i32 0, i32 2
  %t633 = load { i64, ptr }, ptr %t632
  store { i64, ptr } %t633, ptr %l20, !tbaa !27
  br label %bb192
bb191:
  br label %bb198
bb192:
  %t635 = load ptr, ptr %l19, !tbaa !29
  %t637 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t640 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t635, { i64, ptr } %t637)
  store i1 %t640, ptr %l303
  br label %bb193
bb193:
  %t641 = load i1, ptr %l303, !tbaa !21
  br i1 %t641, label %bb194, label %bb195
bb194:
  store i1 true, ptr %l304, !tbaa !21
  br label %bb197
bb195:
  %t642 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t643 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t646 = call i1 @compiler_2fcheck_2eclausesAssign(ptr %v0, ptr %v1, { i64, ptr } %t642, { i64, ptr } %t643)
  store i1 %t646, ptr %l307
  br label %bb196
bb196:
  %t647 = load i1, ptr %l307, !tbaa !21
  store i1 %t647, ptr %l304, !tbaa !21
  br label %bb197
bb197:
  %t648 = load i1, ptr %l304, !tbaa !21
  store i1 %t648, ptr %rv
  br label %ret
bb198:
  %t649 = load ptr, ptr %l0, !tbaa !29
  store ptr %t649, ptr %l308, !tbaa !29
  store i1 false, ptr %l309, !tbaa !21
  %t650 = load ptr, ptr %l308, !tbaa !29
  %t651 = icmp ne ptr %t650, null
  br i1 %t651, label %bb199, label %bb200
bb199:
  %t653 = load ptr, ptr %l308, !tbaa !29
  %t654 = load i64, ptr %t653, !range !{i64 0, i64 30}
  %t656 = icmp eq i64 %t654, 23
  store i1 %t656, ptr %l309, !tbaa !21
  br label %bb200
bb200:
  %t657 = load i1, ptr %l309, !tbaa !21
  br i1 %t657, label %bb201, label %bb202
bb201:
  %t658 = load ptr, ptr %l0, !tbaa !29
  %t660 = getelementptr { i64, [4 x i64] }, ptr %t658, i32 0, i32 1
  %t661 = getelementptr { %"compiler/source:Span", ptr }, ptr %t660, i32 0, i32 1
  %t662 = load ptr, ptr %t661
  store ptr %t662, ptr %l21, !tbaa !29
  br label %bb203
bb202:
  br label %bb205
bb203:
  %t664 = load ptr, ptr %l21, !tbaa !29
  %t665 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t668 = call i1 @compiler_2fcheck_2ematchAssigns(ptr %v0, ptr %v1, ptr %t664, { i64, ptr } %t665)
  store i1 %t668, ptr %l316
  br label %bb204
bb204:
  %t669 = load i1, ptr %l316, !tbaa !21
  store i1 %t669, ptr %rv
  br label %ret
bb205:
  %t670 = load ptr, ptr %l0, !tbaa !29
  store ptr %t670, ptr %l317, !tbaa !29
  store i1 false, ptr %l318, !tbaa !21
  %t671 = load ptr, ptr %l317, !tbaa !29
  %t672 = icmp ne ptr %t671, null
  br i1 %t672, label %bb206, label %bb207
bb206:
  %t674 = load ptr, ptr %l317, !tbaa !29
  %t675 = load i64, ptr %t674, !range !{i64 0, i64 30}
  %t677 = icmp eq i64 %t675, 27
  store i1 %t677, ptr %l318, !tbaa !21
  br label %bb207
bb207:
  %t678 = load i1, ptr %l318, !tbaa !21
  br i1 %t678, label %bb208, label %bb209
bb208:
  %t679 = load ptr, ptr %l0, !tbaa !29
  %t681 = getelementptr { i64, [4 x i64] }, ptr %t679, i32 0, i32 1
  %t682 = getelementptr { %"compiler/source:Span", ptr }, ptr %t681, i32 0, i32 1
  %t683 = load ptr, ptr %t682
  store ptr %t683, ptr %l22, !tbaa !29
  br label %bb210
bb209:
  br label %bb212
bb210:
  %t685 = load ptr, ptr %l22, !tbaa !29
  %t686 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t689 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t685, { i64, ptr } %t686)
  store i1 %t689, ptr %l325
  br label %bb211
bb211:
  %t690 = load i1, ptr %l325, !tbaa !21
  store i1 %t690, ptr %rv
  br label %ret
bb212:
  call void @__olang_check_failed(ptr @olang_loc_cbdda74bd058a0f4_fe1f71fe107242f8)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eisLit(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  store i1 false, ptr %l2, !tbaa !21
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l2, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l2, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_5b2b374f73dad39a_b03018bc2543a136)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2elimitBits(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %l7 = alloca i64
  %l10 = alloca i1
  %l13 = alloca i1
  %l17 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l25 = alloca i64
  %l29 = alloca i64
  %l31 = alloca i64
  %l36 = alloca [6 x i64]
  %l41 = alloca [6 x i64]
  %l46 = alloca [6 x i64]
  %l49 = alloca [6 x i64]
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i64, ptr %l7, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t7, i32 %t8)
  store i1 %t11, ptr %l10
  br label %bb2
bb2:
  %t12 = load i1, ptr %l10, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t13, i32 %t14)
  store i1 %t17, ptr %l13
  br label %bb5
bb4:
  br label %bb18
bb5:
  %t18 = load i1, ptr %l13, !tbaa !21
  store i1 %t18, ptr %l4, !tbaa !21
  %t19 = load i64, ptr %l2, !tbaa !24
  %t21 = icmp eq i64 %t19, 0
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t23 = load i1, ptr %l4, !tbaa !21
  br i1 %t23, label %bb8, label %bb9
bb7:
  br label %bb14
bb8:
  %t25 = load i64, ptr %l3, !tbaa !24
  %t27 = icmp eq i64 %t25, 64
  br i1 %t27, label %bb10, label %bb11
bb9:
  %t29 = load i64, ptr %l3, !tbaa !24
  %t31 = sub i64 %t29, 1
  store i64 %t31, ptr %l25, !tbaa !24
  %t32 = load i64, ptr %l25, !tbaa !24
  %t33 = load i64, ptr %l25, !tbaa !24
  %t34 = shl i64 1, %t33
  %t36 = sub i64 %t34, 1
  store i64 %t36, ptr %l17, !tbaa !24
  br label %bb13
bb10:
  store i64 -1, ptr %l20, !tbaa !24
  br label %bb12
bb11:
  %t38 = load i64, ptr %l3, !tbaa !24
  store i64 %t38, ptr %l21, !tbaa !24
  %t39 = load i64, ptr %l21, !tbaa !24
  %t40 = load i64, ptr %l21, !tbaa !24
  %t41 = shl i64 1, %t40
  %t43 = sub i64 %t41, 1
  store i64 %t43, ptr %l20, !tbaa !24
  br label %bb12
bb12:
  %t45 = load i64, ptr %l20, !tbaa !24
  store i64 %t45, ptr %l17, !tbaa !24
  br label %bb13
bb13:
  %t46 = load i64, ptr %l17, !tbaa !24
  store i64 %t46, ptr %rv
  br label %ret
bb14:
  %t47 = load i1, ptr %l4, !tbaa !21
  br i1 %t47, label %bb15, label %bb16
bb15:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb17
bb16:
  %t49 = load i64, ptr %l3, !tbaa !24
  %t51 = sub i64 %t49, 1
  store i64 %t51, ptr %l31, !tbaa !24
  %t52 = load i64, ptr %l31, !tbaa !24
  %t53 = load i64, ptr %l31, !tbaa !24
  %t54 = shl i64 1, %t53
  %t56 = sub i64 0, %t54
  store i64 %t56, ptr %l29, !tbaa !24
  br label %bb17
bb17:
  %t58 = load i64, ptr %l29, !tbaa !24
  store i64 %t58, ptr %rv
  br label %ret
bb18:
  %t59 = load i32, ptr %l1, !tbaa !23
  %t61 = icmp eq i32 %t59, 13
  br i1 %t61, label %bb19, label %bb20
bb19:
  %t63 = insertvalue [6 x i64] undef, i64 2139095039, 0
  %t64 = insertvalue [6 x i64] %t63, i64 4286578687, 1
  %t65 = insertvalue [6 x i64] %t64, i64 2139095040, 2
  %t66 = insertvalue [6 x i64] %t65, i64 2143289344, 3
  %t67 = insertvalue [6 x i64] %t66, i64 872415232, 4
  %t68 = insertvalue [6 x i64] %t67, i64 8388608, 5
  store [6 x i64] %t68, ptr %l36
  %t69 = load i64, ptr %l2, !tbaa !24
  %t71 = getelementptr [6 x i64], ptr %l36, i64 0, i64 %t69
  %t72 = load i64, ptr %t71, !tbaa !34
  store i64 %t72, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t74 = load i32, ptr %l1, !tbaa !23
  %t76 = icmp eq i32 %t74, 11
  br i1 %t76, label %bb22, label %bb23
bb22:
  %t78 = insertvalue [6 x i64] undef, i64 31743, 0
  %t79 = insertvalue [6 x i64] %t78, i64 64511, 1
  %t80 = insertvalue [6 x i64] %t79, i64 31744, 2
  %t81 = insertvalue [6 x i64] %t80, i64 32256, 3
  %t82 = insertvalue [6 x i64] %t81, i64 5120, 4
  %t83 = insertvalue [6 x i64] %t82, i64 1024, 5
  store [6 x i64] %t83, ptr %l41
  %t84 = load i64, ptr %l2, !tbaa !24
  %t86 = getelementptr [6 x i64], ptr %l41, i64 0, i64 %t84
  %t87 = load i64, ptr %t86, !tbaa !34
  store i64 %t87, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t89 = load i32, ptr %l1, !tbaa !23
  %t91 = icmp eq i32 %t89, 12
  br i1 %t91, label %bb25, label %bb26
bb25:
  %t93 = insertvalue [6 x i64] undef, i64 32639, 0
  %t94 = insertvalue [6 x i64] %t93, i64 65407, 1
  %t95 = insertvalue [6 x i64] %t94, i64 32640, 2
  %t96 = insertvalue [6 x i64] %t95, i64 32704, 3
  %t97 = insertvalue [6 x i64] %t96, i64 15360, 4
  %t98 = insertvalue [6 x i64] %t97, i64 128, 5
  store [6 x i64] %t98, ptr %l46
  %t99 = load i64, ptr %l2, !tbaa !24
  %t101 = getelementptr [6 x i64], ptr %l46, i64 0, i64 %t99
  %t102 = load i64, ptr %t101, !tbaa !34
  store i64 %t102, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t104 = insertvalue [6 x i64] undef, i64 9218868437227405311, 0
  %t105 = insertvalue [6 x i64] %t104, i64 -4503599627370497, 1
  %t106 = insertvalue [6 x i64] %t105, i64 9218868437227405312, 2
  %t107 = insertvalue [6 x i64] %t106, i64 9221120237041090560, 3
  %t108 = insertvalue [6 x i64] %t107, i64 4372995238176751616, 4
  %t109 = insertvalue [6 x i64] %t108, i64 4503599627370496, 5
  store [6 x i64] %t109, ptr %l49
  %t110 = load i64, ptr %l2, !tbaa !24
  %t112 = getelementptr [6 x i64], ptr %l49, i64 0, i64 %t110
  %t113 = load i64, ptr %t112, !tbaa !34
  store i64 %t113, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local double @compiler_2fcheck_2elitF64(%"compiler/check:litv" %a0) #0 {
entry:
  %l0 = alloca %"compiler/check:litv"
  %l3 = alloca double
  %l10 = alloca double
  %rv = alloca double
  store %"compiler/check:litv" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 6
  %t2 = load i1, ptr %t1, !tbaa !21
  br i1 %t2, label %bb1, label %bb2
bb1:
  %t4 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 7
  %t5 = load i1, ptr %t4, !tbaa !21
  br i1 %t5, label %bb3, label %bb4
bb2:
  br label %bb6
bb3:
  %t7 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 8
  %t8 = load i128, ptr %t7
  %t10 = uitofp i128 %t8 to double
  %t12 = fneg double %t10
  store double %t12, ptr %l3, !tbaa !26
  br label %bb5
bb4:
  %t14 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 8
  %t15 = load i128, ptr %t14
  %t17 = uitofp i128 %t15 to double
  store double %t17, ptr %l3, !tbaa !26
  br label %bb5
bb5:
  %t19 = load double, ptr %l3, !tbaa !26
  store double %t19, ptr %rv
  br label %ret
bb6:
  %t20 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 2
  %t21 = load i1, ptr %t20, !tbaa !21
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 3
  %t24 = load i64, ptr %t23, !tbaa !24
  %t27 = uitofp i64 %t24 to double
  store double %t27, ptr %l10, !tbaa !26
  br label %bb9
bb8:
  %t29 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  %t32 = sitofp i64 %t30 to double
  store double %t32, ptr %l10, !tbaa !26
  br label %bb9
bb9:
  %t34 = load double, ptr %l10, !tbaa !26
  store double %t34, ptr %rv
  br label %ret
ret:
  %rr = load double, ptr %rv
  ret double %rr
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_2elitv_2ewideLit(i1 %a0, i128 %a1) #0 {
entry:
  %l1 = alloca i128
  %l2 = alloca %"compiler/check:litv"
  %l9 = alloca %"compiler/check:litv"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/check:litv"
  store i128 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i128, ptr %l1
  %t2 = sub i64 0, 1
  %t4 = zext i64 %t2 to i128
  %t7 = and i128 %t1, %t4
  %t9 = trunc i128 %t7 to i64
  %t12 = call %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %s0, i1 true, i1 false, i1 true, i64 %t9, double 0x0000000000000000)
  store %"compiler/check:litv" %t12, ptr %l9
  br label %bb1
bb1:
  %t13 = load %"compiler/check:litv", ptr %l9
  store %"compiler/check:litv" %t13, ptr %l2
  %t14 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 6
  store i1 true, ptr %t14, !tbaa !21
  %t17 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 7
  store i1 %a0, ptr %t17, !tbaa !21
  %t18 = load i128, ptr %l1
  %t20 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 8
  store i128 %t18, ptr %t20
  %t21 = load %"compiler/check:litv", ptr %l2
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/check:litv" %t21, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2eprimName(ptr %v0, i32 %a0) #0 {
entry:
  %l1 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = sext i32 %a0 to i64
  store i64 %t3, ptr %l1, !tbaa !24
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = icmp eq i64 %t5, 3
  br i1 %t7, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d76, i32 0, i32 1) }, ptr %l4, !tbaa !27
  br label %bb53
bb4:
  %t9 = load i64, ptr %l1, !tbaa !24
  %t11 = icmp eq i64 %t9, 4
  br i1 %t11, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d77, i32 0, i32 1) }, ptr %l4, !tbaa !27
  br label %bb53
bb8:
  %t13 = load i64, ptr %l1, !tbaa !24
  %t15 = icmp eq i64 %t13, 5
  br i1 %t15, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d78, i32 0, i32 1) }, ptr %l4, !tbaa !27
  br label %bb53
bb12:
  %t17 = load i64, ptr %l1, !tbaa !24
  %t19 = icmp eq i64 %t17, 6
  br i1 %t19, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d79, i32 0, i32 1) }, ptr %l4, !tbaa !27
  br label %bb53
bb16:
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = icmp eq i64 %t21, 7
  br i1 %t23, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d80, i32 0, i32 1) }, ptr %l4, !tbaa !27
  br label %bb53
bb20:
  %t25 = load i64, ptr %l1, !tbaa !24
  %t27 = icmp eq i64 %t25, 8
  br i1 %t27, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d81, i32 0, i32 1) }, ptr %l4, !tbaa !27
  br label %bb53
bb24:
  %t29 = load i64, ptr %l1, !tbaa !24
  %t31 = icmp eq i64 %t29, 9
  br i1 %t31, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d82, i32 0, i32 1) }, ptr %l4, !tbaa !27
  br label %bb53
bb28:
  %t33 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp eq i64 %t33, 10
  br i1 %t35, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d83, i32 0, i32 1) }, ptr %l4, !tbaa !27
  br label %bb53
bb32:
  %t37 = load i64, ptr %l1, !tbaa !24
  %t39 = icmp eq i64 %t37, 11
  br i1 %t39, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d84, i32 0, i32 1) }, ptr %l4, !tbaa !27
  br label %bb53
bb36:
  %t41 = load i64, ptr %l1, !tbaa !24
  %t43 = icmp eq i64 %t41, 12
  br i1 %t43, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d85, i32 0, i32 1) }, ptr %l4, !tbaa !27
  br label %bb53
bb40:
  %t45 = load i64, ptr %l1, !tbaa !24
  %t47 = icmp eq i64 %t45, 13
  br i1 %t47, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d86, i32 0, i32 1) }, ptr %l4, !tbaa !27
  br label %bb53
bb44:
  %t49 = load i64, ptr %l1, !tbaa !24
  %t51 = icmp eq i64 %t49, 14
  br i1 %t51, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d87, i32 0, i32 1) }, ptr %l4, !tbaa !27
  br label %bb53
bb48:
  br i1 true, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d88, i32 0, i32 1) }, ptr %l4, !tbaa !27
  br label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_25d55d46e6c695b2_1c5feb2a345583d6)
  unreachable
bb53:
  %t53 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t53, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2ervInt(ptr %v0, i64 %a0) #0 {
entry:
  %l4 = alloca %"compiler/check:reflVal"
  %rv = alloca %"compiler/check:reflVal"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr @G_2ecompiler_2fcheck_2eRvInt, !tbaa !24
  %t3 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t7 = call %"compiler/check:reflVal" @compiler_2fcheck_3areflVal_2ector(ptr %v0, ptr %v0, i1 true, i64 %t1, i64 %a0, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d89, i32 0, i32 1) }, i32 %t3)
  store %"compiler/check:reflVal" %t7, ptr %l4
  br label %bb1
bb1:
  %t8 = load %"compiler/check:reflVal", ptr %l4
  store %"compiler/check:reflVal" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:reflVal", ptr %rv
  ret %"compiler/check:reflVal" %rr
}

define dso_local i1 @compiler_2fcheck_2eregisteredBefore(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i64
  %l15 = alloca i64
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:DropHolding", ptr %a0, i32 0, i32 0
  store ptr %t3, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l4, !tbaa !24
  store i64 %t5, ptr %l8, !tbaa !24
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l10
  br label %bb2
bb2:
  %t9 = load i64, ptr %l8, !tbaa !24
  %t10 = load i64, ptr %l10, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l3, !tbaa !29
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t15, i64 %t16)
  store i64 %t19, ptr %l15
  br label %bb6
bb6:
  %t20 = load i64, ptr %l15, !tbaa !24
  store i64 %t20, ptr %l5, !tbaa !24
  %t21 = load i64, ptr %l5, !tbaa !24
  %t25 = icmp eq i64 %t21, %a1
  br i1 %t25, label %bb7, label %bb8
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t28 = load i64, ptr %l5, !tbaa !24
  %t32 = icmp eq i64 %t28, %a2
  br i1 %t32, label %bb10, label %bb11
bb10:
  store i1 false, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t35 = load i64, ptr %l4, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l4, !tbaa !24
  br label %bb1
bb14:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ewholeTemp(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l2, !tbaa !29
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store ptr null, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_fcf37abe830e2966_4b106c75c56f483a)
  unreachable
bb11:
  %t19 = load ptr, ptr %l2, !tbaa !29
  store ptr %t19, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_2ewideBits(i32 %a0, %"compiler/check:litv" %a1, %"compiler/check:litv" %a2) #0 {
entry:
  %l0 = alloca i32
  %l3 = alloca %"compiler/check:signMag"
  %l4 = alloca i1
  %l5 = alloca i128
  %l6 = alloca %"compiler/check:signMag"
  %l7 = alloca i1
  %l8 = alloca i128
  %l9 = alloca i1
  %l10 = alloca i128
  %l12 = alloca %"compiler/check:signMag"
  %l16 = alloca %"compiler/check:signMag"
  %l21 = alloca i1
  %l23 = alloca i1
  %l27 = alloca i1
  %l29 = alloca i1
  %l36 = alloca i128
  %l42 = alloca i128
  %l52 = alloca %"compiler/check:litv"
  %l55 = alloca %"compiler/check:litv"
  %l58 = alloca %"compiler/check:litv"
  %rv = alloca %"compiler/check:litv"
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call %"compiler/check:signMag" @compiler_2fcheck_2esignMag_2etwos(%"compiler/check:litv" %a1)
  store %"compiler/check:signMag" %t3, ptr %l12
  br label %bb1
bb1:
  %t4 = load %"compiler/check:signMag", ptr %l12
  store %"compiler/check:signMag" %t4, ptr %l3
  %t5 = getelementptr %"compiler/check:signMag", ptr %l3, i32 0, i32 0
  %t6 = load i1, ptr %t5, !tbaa !21
  store i1 %t6, ptr %l4, !tbaa !21
  %t8 = getelementptr %"compiler/check:signMag", ptr %l3, i32 0, i32 1
  %t9 = load i128, ptr %t8
  store i128 %t9, ptr %l5
  %t13 = call %"compiler/check:signMag" @compiler_2fcheck_2esignMag_2etwos(%"compiler/check:litv" %a2)
  store %"compiler/check:signMag" %t13, ptr %l16
  br label %bb2
bb2:
  %t14 = load %"compiler/check:signMag", ptr %l16
  store %"compiler/check:signMag" %t14, ptr %l6
  %t15 = getelementptr %"compiler/check:signMag", ptr %l6, i32 0, i32 0
  %t16 = load i1, ptr %t15, !tbaa !21
  store i1 %t16, ptr %l7, !tbaa !21
  %t18 = getelementptr %"compiler/check:signMag", ptr %l6, i32 0, i32 1
  %t19 = load i128, ptr %t18
  store i128 %t19, ptr %l8
  %t21 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t23 = trunc i64 85 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb3, label %bb4
bb3:
  %t26 = load i1, ptr %l4, !tbaa !21
  br i1 %t26, label %bb5, label %bb6
bb4:
  %t28 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t30 = trunc i64 86 to i32
  %t31 = icmp eq i32 %t28, %t30
  br i1 %t31, label %bb8, label %bb9
bb5:
  %t33 = load i1, ptr %l7, !tbaa !21
  store i1 %t33, ptr %l23, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb7
bb7:
  %t35 = load i1, ptr %l23, !tbaa !21
  store i1 %t35, ptr %l21, !tbaa !21
  br label %bb14
bb8:
  %t36 = load i1, ptr %l4, !tbaa !21
  br i1 %t36, label %bb10, label %bb11
bb9:
  %t38 = load i1, ptr %l4, !tbaa !21
  %t39 = load i1, ptr %l7, !tbaa !21
  %t42 = icmp ne i1 %t38, %t39
  store i1 %t42, ptr %l27, !tbaa !21
  br label %bb13
bb10:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb12
bb11:
  %t44 = load i1, ptr %l7, !tbaa !21
  store i1 %t44, ptr %l29, !tbaa !21
  br label %bb12
bb12:
  %t46 = load i1, ptr %l29, !tbaa !21
  store i1 %t46, ptr %l27, !tbaa !21
  br label %bb13
bb13:
  %t47 = load i1, ptr %l27, !tbaa !21
  store i1 %t47, ptr %l21, !tbaa !21
  br label %bb14
bb14:
  %t48 = load i1, ptr %l21, !tbaa !21
  store i1 %t48, ptr %l9, !tbaa !21
  %t49 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t51 = trunc i64 85 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb15, label %bb16
bb15:
  %t54 = load i128, ptr %l5
  %t55 = load i128, ptr %l8
  %t58 = and i128 %t54, %t55
  store i128 %t58, ptr %l36
  br label %bb20
bb16:
  %t60 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t62 = trunc i64 86 to i32
  %t63 = icmp eq i32 %t60, %t62
  br i1 %t63, label %bb17, label %bb18
bb17:
  %t65 = load i128, ptr %l5
  %t66 = load i128, ptr %l8
  %t69 = or i128 %t65, %t66
  store i128 %t69, ptr %l42
  br label %bb19
bb18:
  %t71 = load i128, ptr %l5
  %t72 = load i128, ptr %l8
  %t75 = xor i128 %t71, %t72
  store i128 %t75, ptr %l42
  br label %bb19
bb19:
  %t77 = load i128, ptr %l42
  store i128 %t77, ptr %l36
  br label %bb20
bb20:
  %t78 = load i128, ptr %l36
  store i128 %t78, ptr %l10
  %t79 = load i1, ptr %l9, !tbaa !21
  %t81 = xor i1 %t79, true
  br i1 %t81, label %bb21, label %bb22
bb21:
  %t83 = load i128, ptr %l10
  %t85 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2eofMag(i1 false, i128 %t83)
  store %"compiler/check:litv" %t85, ptr %l52
  br label %bb23
bb22:
  br label %bb24
bb23:
  %t86 = load %"compiler/check:litv", ptr %l52
  store %"compiler/check:litv" %t86, ptr %rv
  br label %ret
bb24:
  %t87 = load i128, ptr %l10
  %t89 = icmp eq i128 %t87, 0
  br i1 %t89, label %bb25, label %bb26
bb25:
  %t91 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2enoLit()
  store %"compiler/check:litv" %t91, ptr %l55
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t92 = load %"compiler/check:litv", ptr %l55
  store %"compiler/check:litv" %t92, ptr %rv
  br label %ret
bb28:
  %t93 = load i128, ptr %l10
  %t95 = sub i128 0, %t93
  %t97 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2eofMag(i1 true, i128 %t95)
  store %"compiler/check:litv" %t97, ptr %l58
  br label %bb29
bb29:
  %t98 = load %"compiler/check:litv", ptr %l58
  store %"compiler/check:litv" %t98, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local i64 @compiler_2fcheck_2ewordCount(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca i1
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l27 = alloca i1
  %l30 = alloca i1
  %l31 = alloca { i64, ptr }
  %l35 = alloca i1
  %l36 = alloca i1
  %l37 = alloca { i64, ptr }
  %l41 = alloca i1
  %l42 = alloca i1
  %l43 = alloca { i64, ptr }
  %l57 = alloca i1
  %l58 = alloca { i64, ptr }
  %l61 = alloca i1
  %l62 = alloca i1
  %l63 = alloca { i64, ptr }
  %l66 = alloca i1
  %l67 = alloca i1
  %l68 = alloca { i64, ptr }
  %l74 = alloca i1
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t2, 0
  %t7 = add i64 %t1, %t4
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t13 = icmp sle i64 %t7, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb2, label %bb3
bb2:
  br label %bb44
bb3:
  br label %bb4
bb4:
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t17, ptr %l15, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  store i64 %t18, ptr %l16, !tbaa !24
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t25 = add i64 %t19, %t22
  store i64 %t25, ptr %l20, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t26, 0
  store i64 %t27, ptr %l21, !tbaa !24
  %t28 = load i64, ptr %l16, !tbaa !24
  %t29 = icmp sge i64 %t28, 0
  br i1 %t29, label %bb5, label %bb6
bb5:
  %t31 = load i64, ptr %l16, !tbaa !24
  %t32 = load i64, ptr %l20, !tbaa !24
  %t33 = icmp sle i64 %t31, %t32
  br i1 %t33, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_a18b02733ea53beb_f9e22fb852fb348f)
  unreachable
bb7:
  %t35 = load i64, ptr %l20, !tbaa !24
  %t36 = load i64, ptr %l21, !tbaa !24
  %t37 = icmp sle i64 %t35, %t36
  br i1 %t37, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_a18b02733ea53beb_f9e22fb852fb348f)
  unreachable
bb9:
  %t39 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = load i64, ptr %l16, !tbaa !24
  %t42 = load i64, ptr %l20, !tbaa !24
  %t43 = getelementptr i8, ptr %t40, i64 %t41
  %t44 = sub i64 %t42, %t41
  %t45 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t43, 1
  %t47 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t50 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t46, { i64, ptr } %t47)
  store i1 %t50, ptr %l27
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_a18b02733ea53beb_f9e22fb852fb348f)
  unreachable
bb11:
  %t51 = load i1, ptr %l27, !tbaa !21
  br i1 %t51, label %bb12, label %bb13
bb12:
  %t52 = load i64, ptr %l3, !tbaa !24
  %t54 = icmp eq i64 %t52, 0
  br i1 %t54, label %bb14, label %bb15
bb13:
  br label %bb42
bb14:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb24
bb15:
  %t56 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t56, ptr %l31, !tbaa !27
  %t57 = load i64, ptr %l3, !tbaa !24
  %t59 = sub i64 %t57, 1
  %t61 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i8, ptr %t62, i64 %t59
  %t64 = load i8, ptr %t63, !tbaa !32
  %t66 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t64)
  store i1 %t66, ptr %l35
  br label %bb16
bb16:
  %t67 = load i1, ptr %l35, !tbaa !21
  br i1 %t67, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb20
bb18:
  %t68 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t68, ptr %l37, !tbaa !27
  %t69 = load i64, ptr %l3, !tbaa !24
  %t71 = sub i64 %t69, 1
  %t73 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr i8, ptr %t74, i64 %t71
  %t76 = load i8, ptr %t75, !tbaa !32
  %t78 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t76)
  store i1 %t78, ptr %l41
  br label %bb19
bb19:
  %t79 = load i1, ptr %l41, !tbaa !21
  store i1 %t79, ptr %l36, !tbaa !21
  br label %bb20
bb20:
  %t80 = load i1, ptr %l36, !tbaa !21
  br i1 %t80, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb23
bb22:
  %t81 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t81, ptr %l43, !tbaa !27
  %t82 = load i64, ptr %l3, !tbaa !24
  %t84 = sub i64 %t82, 1
  %t86 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr i8, ptr %t87, i64 %t84
  %t89 = load i8, ptr %t88, !tbaa !32
  %t91 = icmp eq i8 %t89, 95
  store i1 %t91, ptr %l42, !tbaa !21
  br label %bb23
bb23:
  %t93 = load i1, ptr %l42, !tbaa !21
  %t94 = xor i1 %t93, true
  store i1 %t94, ptr %l30, !tbaa !21
  br label %bb24
bb24:
  %t96 = load i1, ptr %l30, !tbaa !21
  store i1 %t96, ptr %l4, !tbaa !21
  %t97 = load i64, ptr %l3, !tbaa !24
  %t98 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t98, 0
  %t103 = add i64 %t97, %t100
  store i64 %t103, ptr %l5, !tbaa !24
  %t105 = load i64, ptr %l5, !tbaa !24
  %t106 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t106, 0
  %t111 = icmp sge i64 %t105, %t108
  br i1 %t111, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb35
bb26:
  %t113 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t113, ptr %l58, !tbaa !27
  %t114 = load i64, ptr %l5, !tbaa !24
  %t116 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr i8, ptr %t117, i64 %t114
  %t119 = load i8, ptr %t118, !tbaa !32
  %t121 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t119)
  store i1 %t121, ptr %l61
  br label %bb27
bb27:
  %t122 = load i1, ptr %l61, !tbaa !21
  br i1 %t122, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb31
bb29:
  %t123 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t123, ptr %l63, !tbaa !27
  %t124 = load i64, ptr %l5, !tbaa !24
  %t126 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr i8, ptr %t127, i64 %t124
  %t129 = load i8, ptr %t128, !tbaa !32
  %t131 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t129)
  store i1 %t131, ptr %l66
  br label %bb30
bb30:
  %t132 = load i1, ptr %l66, !tbaa !21
  store i1 %t132, ptr %l62, !tbaa !21
  br label %bb31
bb31:
  %t133 = load i1, ptr %l62, !tbaa !21
  br i1 %t133, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb34
bb33:
  %t134 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t134, ptr %l68, !tbaa !27
  %t135 = load i64, ptr %l5, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr i8, ptr %t138, i64 %t135
  %t140 = load i8, ptr %t139, !tbaa !32
  %t142 = icmp eq i8 %t140, 95
  store i1 %t142, ptr %l67, !tbaa !21
  br label %bb34
bb34:
  %t144 = load i1, ptr %l67, !tbaa !21
  %t145 = xor i1 %t144, true
  store i1 %t145, ptr %l57, !tbaa !21
  br label %bb35
bb35:
  %t147 = load i1, ptr %l57, !tbaa !21
  store i1 %t147, ptr %l6, !tbaa !21
  %t148 = load i1, ptr %l4, !tbaa !21
  br i1 %t148, label %bb36, label %bb37
bb36:
  %t150 = load i1, ptr %l6, !tbaa !21
  store i1 %t150, ptr %l74, !tbaa !21
  br label %bb38
bb37:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb38
bb38:
  %t152 = load i1, ptr %l74, !tbaa !21
  br i1 %t152, label %bb39, label %bb40
bb39:
  %t153 = load i64, ptr %l2, !tbaa !24
  %t155 = add i64 %t153, 1
  store i64 %t155, ptr %l2, !tbaa !24
  br label %bb41
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t157 = load i64, ptr %l3, !tbaa !24
  %t159 = add i64 %t157, 1
  store i64 %t159, ptr %l3, !tbaa !24
  br label %bb43
bb43:
  br label %bb1
bb44:
  %t161 = load i64, ptr %l2, !tbaa !24
  store i64 %t161, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/check:TopAssertAsk" @compiler_2fcheck_3aTopAssertAsk_2ector(ptr %v0, i64 %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, i64 %a4) #0 {
entry:
  %rv = alloca %"compiler/check:TopAssertAsk"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/check:TopAssertAsk" undef, i64 %a0, 0
  %t14 = insertvalue %"compiler/check:TopAssertAsk" %t12, %"compiler/source:Span" %a1, 1
  %t16 = insertvalue %"compiler/check:TopAssertAsk" %t14, %"compiler/source:Span" %a2, 2
  %t18 = insertvalue %"compiler/check:TopAssertAsk" %t16, i64 %a3, 3
  %t20 = insertvalue %"compiler/check:TopAssertAsk" %t18, i64 %a4, 4
  store %"compiler/check:TopAssertAsk" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:TopAssertAsk", ptr %rv
  ret %"compiler/check:TopAssertAsk" %rr
}

define dso_local %"compiler/check:fieldSet" @compiler_2fcheck_3afieldSet_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, i32 %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %rv = alloca %"compiler/check:fieldSet"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/check:fieldSet" undef, { i64, ptr } %a0, 0
  %t12 = insertvalue %"compiler/check:fieldSet" %t10, i32 %a1, 1
  %t14 = insertvalue %"compiler/check:fieldSet" %t12, { i64, ptr } %a2, 2
  %t16 = insertvalue %"compiler/check:fieldSet" %t14, { i64, ptr } %a3, 3
  store %"compiler/check:fieldSet" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:fieldSet", ptr %rv
  ret %"compiler/check:fieldSet" %rr
}

define dso_local %"compiler/check:narrowed" @compiler_2fcheck_3anarrowed_2ector(ptr %v0, i64 %a0, i64 %a1, i32 %a2, i64 %a3, i64 %a4, i1 %a5) #0 {
entry:
  %rv = alloca %"compiler/check:narrowed"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/check:narrowed" undef, i64 %a0, 0
  %t16 = insertvalue %"compiler/check:narrowed" %t14, i64 %a1, 1
  %t18 = insertvalue %"compiler/check:narrowed" %t16, i32 %a2, 2
  %t20 = insertvalue %"compiler/check:narrowed" %t18, i64 %a3, 3
  %t22 = insertvalue %"compiler/check:narrowed" %t20, i64 %a4, 4
  %t24 = insertvalue %"compiler/check:narrowed" %t22, i1 %a5, 5
  store %"compiler/check:narrowed" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:narrowed", ptr %rv
  ret %"compiler/check:narrowed" %rr
}

@.d0 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"main" }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr) cold noreturn
@__olang_empty_array = external constant [16 x i64]
@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d3 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"std/prelude" }>, align 8
declare void @__olang_ert_req_clear()
@.d4 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d5 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Array" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d6 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Plus" }>, align 8
@.d7 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Mul" }>, align 8
@.d8 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"BitAnd" }>, align 8
@.d9 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"BitOr" }>, align 8
@.d10 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"BitXor" }>, align 8
@.d11 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Plus" }>, align 8
@.d12 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"'+'" }>, align 8
@.d13 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Mul" }>, align 8
@.d14 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"'*'" }>, align 8
@.d15 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"BitAnd" }>, align 8
@.d16 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"'&'" }>, align 8
@.d17 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"BitOr" }>, align 8
@.d18 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"'|'" }>, align 8
@.d19 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"'^'" }>, align 8
@.d20 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d21 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"Eq" }>, align 8
@.d22 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"eq" }>, align 8
@.d23 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d24 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 4
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d25 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"std/prelude/iterator" }>, align 8
@.d26 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Exhausted" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"compiler/check:inPlaceRead" @olang_2eHelperKind_2eCopy_2ecompiler_2fcheck_3ainPlaceRead(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/check:inPlaceRead"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/check:inPlaceRead"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/check:inPlaceRead", ptr %a0
  store %"compiler/check:inPlaceRead" %t2, ptr %l1
  %t3 = getelementptr %"compiler/check:inPlaceRead", ptr %l1, i32 0, i32 1
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/check:inPlaceRead", ptr %l1, i32 0, i32 1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"compiler/check:inPlaceRead", ptr %l1
  store %"compiler/check:inPlaceRead" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:inPlaceRead", ptr %rv
  ret %"compiler/check:inPlaceRead" %rr
}

@.d27 = private constant <{ i64, [79 x i8] }> <{ i64 0, [79 x i8] c"a call through x[i] made in place whose callee may change the collection (E31b)" }>, align 8
@.d28 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Array" }>, align 8
@.d29 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"CStr" }>, align 8
@.d30 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Exhausted" }>, align 8
@.d31 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"a struct that is not packed" }>, align 8
@.d32 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"it has no width in bits" }>, align 8
@.d33 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"an enum carrying a payload" }>, align 8
@.d34 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"'Narrow'" }>, align 8
@.d35 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"'Narrow'" }>, align 8
@.d36 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"std/prelude/number" }>, align 8
@.d37 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"NumberError" }>, align 8
@.d38 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"Overflow" }>, align 8
@.d39 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"At" }>, align 8
@.d40 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"'x[i]'" }>, align 8
@.d41 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"SetAt" }>, align 8
@.d42 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"At ('x[i]')" }>, align 8
@.d43 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Name" }>, align 8
@.d44 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Kind" }>, align 8
@.d45 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Size" }>, align 8
@.d46 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Align" }>, align 8
@.d47 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Length" }>, align 8
@.d48 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Kind" }>, align 8
@.d49 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Length" }>, align 8
@.d50 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Size" }>, align 8
@.d51 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Align" }>, align 8
@.d52 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Type" }>, align 8
@.d53 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"Default" }>, align 8
@.d54 = private constant <{ i64, [57 x i8] }> <{ i64 0, [57 x i8] c"Name, Type, Offset, BitOffset, Bits, Of, Attr and HasAttr" }>, align 8
@.d55 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"Name, Fields, Attr and HasAttr" }>, align 8
@.d56 = private constant <{ i64, [49 x i8] }> <{ i64 0, [49 x i8] c"Name, Type, HasDefault, Default, Attr and HasAttr" }>, align 8
@.d57 = private constant <{ i64, [123 x i8] }> <{ i64 0, [123 x i8] c"Name, Type, Params, Results, Errors, Attr, HasAttr, NoReturn, Exported, Extern, Commutes and G42's facts - and it is called" }>, align 8
@.d58 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Type" }>, align 8
@.d59 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"field" }>, align 8
@.d60 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"case" }>, align 8
@.d61 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"parameter" }>, align 8
@.d62 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"function" }>, align 8
@.d63 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"result" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d64 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Slice" }>, align 8
@.d65 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Slice" }>, align 8
@.d66 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"'x[lo:hi]'" }>, align 8
@.d67 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"Slice ('x[lo:hi]')" }>, align 8
@.d68 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Len" }>, align 8
@.d69 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c"a slice with no end of a type with no Len (E31)" }>, align 8
@.d70 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"std/prelude/text" }>, align 8
@.d71 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"String" }>, align 8
@.d72 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Str" }>, align 8
@.d73 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"str" }>, align 8
@.d74 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Str" }>, align 8
@.d75 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"'$'" }>, align 8
@.d76 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"I8" }>, align 8
@.d77 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I16" }>, align 8
@.d78 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d79 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d80 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d81 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U16" }>, align 8
@.d82 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U32" }>, align 8
@.d83 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d84 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F16" }>, align 8
@.d85 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"BF16" }>, align 8
@.d86 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F32" }>, align 8
@.d87 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
@.d88 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"?" }>, align 8
@.d89 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorBefore(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoMain(ptr %v0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMainSignature(ptr %v0)
@olang_loc_a6ae1e9a693d05c9_888d1f7981f90365 = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eExprBodyIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, i64 %a2, { i64, ptr } %a3, { i64, ptr } %a4, ptr %a5, i32 %a6)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultArg(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3, i1 %a4, i32 %a5, i32 %a6)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitMethod(ptr %v0, ptr %v1, ptr %a0, %"compiler/generic:AnySlot" %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArgCount(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1, i64 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/diagmsg:Msg" %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v1, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceContext(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_87950e0971945cd5_bece9ab6826c95c9 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultReads(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeArgs(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_f8c90d07629b23d_673d56dd932bf211 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %v0, i64 %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i1 %a4, i1 %a5)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInferThroughBounds(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_5f37bbd32b93a1e_9b7778ec6ef06ea = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare %"compiler/typed:Call" @compiler_2ftyped_3aCall_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, i1 %a3, i1 %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainStruct(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %a0)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaseIsPrivate(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrLocalName(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrItemPath(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtIn(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
@olang_loc_514ceade83978a4d_1843f44cd2570191 = external constant [0 x i8]
declare %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_8bbd92ac148fb220_5a9ba8c1b178084 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehole(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eSetAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLikeFits(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoMeet(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainFrom(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, { i64, ptr } %a4, i64 %a5, ptr %a6)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eTrunca_Hdac151ce4e73ec212dc55b02b0b7e7d0(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebinary(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4, i32 %a5)
@olang_loc_854899d5724a103b_e7dfb19072d83fa7 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitBeside(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, %"compiler/check:litv" %a2, ptr %a3, i32 %a4, %"compiler/source:Span" %a5, i1 %a6)
@olang_loc_852b58c2eb82b3cc_e47a0c64d3951188 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5, %"compiler/source:Span" %a6, %"compiler/source:Span" %a7)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCommutesNotHere(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCommutesSameType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCommutesClash(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i1 @compiler_2fcheck_2ecommutative(i32 %a0)
declare { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %v0, i32 %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCondNotBoolType(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eaddTo(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_9f409528a62be557_96e98ebb70e4ac13 = external constant [0 x i8]
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eIsDropped(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eIsCut(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_1bc36e5fea83eb2f_c65858cd7310966b = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeqShaped(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eLen__H3cdfcddd9c493bd8bcefc7b766e0438b(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrValOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
declare %"compiler/check:errNarrow" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eAt_3ccompiler_2fcheck_3aerrNarrow_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eallWords(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_92689d3fb9399c33_8949aa7cd18a1ac7 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eOwnVarIndexes(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2eWrittenTypes(ptr %v0, { i64, ptr } %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrVarIndex(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrSetArgUnwanted(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_3150b71fd0fb46fe_3d08923418e7b7d2 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeArgsOnNonGeneric(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_d7e03fe7b4bf2c3d_64b0c57621292c71 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeArgCount(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2)
@olang_loc_c902484ee6860410_648a649019eab164 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_e4324c4b30f6563f_ec149b7f01d5683b = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_2e16a6af4c93cb6a_eec2ff8433b844a6 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrsArgOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epattern(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i32 %a3, ptr %a4, i64 %a5)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCase(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargPatterns(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epayloadPattern(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, { i64, ptr } %a4, ptr %a5, i32 %a6, ptr %a7, i64 %a8)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estructDecl(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estructPattern(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, { i64, ptr } %a4, ptr %a5, i32 %a6, ptr %a7, i64 %a8)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenEnum(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaseValueType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_d21fae414ff68ab0_be44aac3c4a6c53c = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTest(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
@olang_loc_ad8923f011cb5acf_6f8a151e60866063 = external constant [0 x i8]
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDtorWritten(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetStructBody(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i1 %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisOver(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elengthsMeet(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @compiler_2ftyped_2eCalledBody(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eInst(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsGenerator(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_3ab5aWalk_2ector(ptr %out, ptr %v0, i64 %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aInit(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aFn(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3ainPlaceRead_3e_2eLe_Hf613227d99bb55cc0c1d4d516f382642(ptr %v0, ptr %a0)
declare %"compiler/check:inPlaceRead" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3ainPlaceRead_3e_2eAt_Hf62b397eb49933d0308b5b903703d314(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/check:Gap" @compiler_2fcheck_3aGap_2ector(ptr %v0, ptr %v1, i64 %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2ePush_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:Gap" %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eImmut(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeOrigin(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnique(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUniqueImmutPart(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorBare(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2)
@olang_loc_aec4d07a8c55eb24_c1f86bfc15f940a8 = external constant [0 x i8]
@olang_loc_f7ce27c314005a15_bac367b114faff79 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeForeign(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritable(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5, i1 %a6, i32 %a7)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesIdOf(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_24473ecab934ff5a_e5063e673d38f936 = external constant [0 x i8]
@olang_loc_1dc6773449e59e5b_c7fcef2f52138cd7 = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneTarget(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElemOf(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArg(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare %"compiler/check:laneVals" @compiler_2fcheck_3alaneVals_2ector(ptr %v0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneStore(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, i64 %a5, i64 %a6, ptr %a7)
declare %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneType(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2fcheck_2eLaneMagic = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\01\00\00" }>, align 8
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLaneLengths(ptr %v0, i64 %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclareUnknown(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDestructOneValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDestructCount(ptr %v0, i64 %a0, i64 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, [1 x i64] } %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eputTarget(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i1 %a2, ptr %a3, i32 %a4)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAfter(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAssignListCount(ptr %v0, i64 %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estoredName(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferred(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i1 %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueExisting(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueRef(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i1 %a3)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownCopy(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3asetAt_3f_26_3e_2ector(ptr %v0, i64 %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetAtTarget(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3asetAt_3f_26_3e_2ePu_H987461f55898bae561e1d5349703380d(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ediscardOr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eP_Ha5c233616e2ae02d7fe37742cfaef2c2(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eA_Hf8c35f4f5353320ac1e6ff0719acdfb7(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eColumnAssigned(ptr %v0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eLen__H22c160154c8542d83ffe3c77c98973d0(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eL_H6a486a18542e18ee3475c3237c5a5335(ptr %v0, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2ePush_H521773322b2b1b179ce4cc03a1674857(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3asetAt_3f_26_3e_2eAt_H6c7d5ab01c425e68e8a93a567ecc740a(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_96ad6a547cbfae6b_c8fd4ea10ff1b69f = external constant [0 x i8]
@olang_loc_1e0e3f8e77107efc_26f178b75df49a00 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estoreCopy(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eTrun_Haa7c8ccc08c8123d0b87c9688e5d351e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_89675b40bb29f91f_f23262abf4982edb = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eToArra_H50cbff9caa8a2389caf3e92da7e24507(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_7114c498979ee84a_e24a16e9735bab46 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, ptr } %a7)
@olang_loc_c7908973d247e2d7_c6acba74781c2b93 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTakesNoArgs(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNarrowNotNumber(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvWords(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailOp(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/source:Span" %a2, i1 %a3)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebracketIn(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4, i64 %a5, i1 %a6)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAtUndeclared(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNotIndexable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedErr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3, %"compiler/diagmsg:Msg" %a4)
declare i1 @compiler_2fcheck_2elaneTok(i32 %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultMethod(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOverrideSignature(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowMethod(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperandParam(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushNulls(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2, i64 %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushErrNarrow(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2, i64 %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushCases(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2, i64 %a3)
declare %"compiler/check:reflList" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflListValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eviaTypeVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasCase(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fgeneric_2eProjectsType(ptr %v0, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflTypeNotValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflConst(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/check:reflVal" %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflNoKind(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflNoLength(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflNoLayout(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2eisLimitName(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflNoMember(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fgeneric_2eDescCase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eDescParam = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDefault(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/generic:Desc" %a2)
@G_2ecompiler_2fgeneric_2eDescField = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eDescFunc = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@olang_loc_6fa12bf18c08968_7f63ef0109416d3c = external constant [0 x i8]
@olang_loc_366830190f407939_a82d5f1c611378ed = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflDescNoMember(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_64f1128892bbfadb_2fd1650a543ec847 = external constant [0 x i8]
@olang_loc_9b328daa59c12fec_530ed6f7b483a728 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroMatch(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_aa71917389f82fa1_ab8db462134cc7fd = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCallCopy(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_45c1f7cb36e76579_9732da1c199d4515 = external constant [0 x i8]
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, ptr %a4, i64 %a5)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aidleCall_3e_2eLen_3ccompiler_2fcheck_3aidleCall_3e(ptr %v0, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_2ector(ptr %v0, i64 %a0)
declare %"compiler/check:idleCall" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aidleCall_3e_2eAt_3ccompiler_2fcheck_3aidleCall_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffB(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H2474e1fc3c93452d7765e4ed18f29a03(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_Hda4ef06466535e66801340e999dad217(ptr %v0, ptr %a0)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H87a29777ccf22aa2985fa9d3c61f9cd3(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCallDoesNothing(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elendsPacked(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eslicedWritable(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullRead(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
@olang_loc_5aa0e1f55b10e6f_53045464d54dc2fb = external constant [0 x i8]
@olang_loc_e4f33d7277813d9a_8adeed4fca551266 = external constant [0 x i8]
@olang_loc_b203c9fbf4c249fb_735051f472c86bf = external constant [0 x i8]
@olang_loc_85a2f2931038d80c_e5a946dd8e187d18 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esliceLength(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, ptr %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_2f1aad6b95023edd_c82f5ce971f0d619 = external constant [0 x i8]
declare %"compiler/typed:Slice" @compiler_2ftyped_3aSlice_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpawnInDefer(ptr %v0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpawnOutsideJoin(ptr %v0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_e10ca684bef0956d_f742028d37a3af11 = external constant [0 x i8]
@olang_loc_c3afd3921db70d3f_27f9f6390ccac16b = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpawnLambdaParams(ptr %v0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elambda(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
@olang_loc_da760de622febe3_df78aa298e2a00e7 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, i64 %a5, ptr %a6, { i64, ptr } %a7, { i64, ptr } %a8)
declare i1 @compiler_2fcheck_2ecallLike(ptr %v0, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpawnNotCall(ptr %v0)
@olang_loc_5ca7d448b00003f5_5d17299a767670c1 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eproduced(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2, i64 %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2edispatched(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanySpawned(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %a2, ptr %a3, i32 %a4)
@olang_loc_a0a2b29f181c5519_be518ce768fc1fe5 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpawnFallible(ptr %v0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpawnTryInfallible(ptr %v0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aTaskClause_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_ebab815881a318c_398bac8a238c0b80 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ector(ptr %v0, i64 %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloneBinding(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCatchNameInTask(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2eToArray_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %v1, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclauseHandler(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, i64 %a3)
declare %"compiler/typed:TaskClause" @compiler_2ftyped_3aTaskClause_2ector(ptr %v0, ptr %v1, ptr %v2, %"compiler/source:Span" %a0, { i64, ptr } %a1, i1 %a2, ptr %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aTaskClause_26_3e_2e_H70975c58788d810dba7712b4ee87a08c(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_e78286934eafcc6f_802ae2752731a35b = external constant [0 x i8]
declare %"compiler/typed:Clause" @compiler_2ftyped_3aClause_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, %"compiler/source:Span" %a0, { i64, ptr } %a1, i1 %a2, ptr %a3, { i64, ptr } %a4, i64 %a5, i32 %a6)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ePush_Hc64f4d0e64077a33423ff9c4e583894f(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropTaken(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, ptr %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espawnTargets(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3, ptr %a4, i32 %a5)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eT_Hc52cb714df9676093c851daa15f6f747(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aTaskClause_26_3e_2e_H788addc5d4e2ce71c84413f6a2c1cfed(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/typed:Spawn" @compiler_2ftyped_3aSpawn_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, { i64, ptr } %a2, i32 %a3)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
@G_2ecompiler_2ftypes_2eDefaultErrT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleft(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2eLen_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %a0)
declare %"compiler/typed:Item" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2eAt_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emerged(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enormalSet(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecanonicalErrs(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i32 %a3)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aTopAssertAsk_3e_2eP_H67072fc16e996275e069a499f28fddf9(ptr %v0, ptr %a0, %"compiler/check:TopAssertAsk" %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclContext(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitRef(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTraitExtendsNotTrait(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereachesTrait(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTraitExtendsItself(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTypeWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsClosedTrait(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTraitMemberOpen(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMembers(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/generic:Unmet" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMissing(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i1 %a3, i64 %a4)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTraitMemberMissing(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@olang_loc_21d2c8212e1ec20a_d97fbaae9e5bc606 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_Hb3133f486435530b533aaf49461c92b5(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H64d9be73b6c9bed004c541bdf7f0ca0a(ptr %v0, ptr %a0, i32 %a1, i1 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprivateRole(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i32 %a2, { i64, ptr } %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estrInstance(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_8830d773c2e320be_c40e682cdd96e1f2 = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsColumns(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_b2735ee686977dce_6cfd672f66c8ceea = external constant [0 x i8]
@olang_loc_ea26c0eb0666620f_15a39c1642164bab = external constant [0 x i8]
@olang_loc_4f5af4be817f3cd4_b4ce7fc5c27c5770 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ehitsPath(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2eexprsAssign(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2eclausesAssign(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ematchAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_cbdda74bd058a0f4_fe1f71fe107242f8 = external constant [0 x i8]
@olang_loc_5b2b374f73dad39a_b03018bc2543a136 = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %v0, i1 %a0, i1 %a1, i1 %a2, i64 %a3, double %a4)
@olang_loc_25d55d46e6c695b2_1c5feb2a345583d6 = external constant [0 x i8]
@G_2ecompiler_2fcheck_2eRvInt = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/check:reflVal" @compiler_2fcheck_3areflVal_2ector(ptr %v0, ptr %v1, i1 %a0, i64 %a1, i64 %a2, { i64, ptr } %a3, i32 %a4)
@olang_loc_fcf37abe830e2966_4b106c75c56f483a = external constant [0 x i8]
declare %"compiler/check:signMag" @compiler_2fcheck_2esignMag_2etwos(%"compiler/check:litv" %a0)
declare %"compiler/check:litv" @compiler_2fcheck_2elitv_2eofMag(i1 %a0, i128 %a1)
declare %"compiler/check:litv" @compiler_2fcheck_2elitv_2enoLit()
@olang_loc_a18b02733ea53beb_f9e22fb852fb348f = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
