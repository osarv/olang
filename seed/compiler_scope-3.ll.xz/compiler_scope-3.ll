; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/scope:Scoper" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { ptr, ptr }, { ptr, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, i64, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/typed:Plan", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, [2 x i64] }, i1, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, [2 x i64] }, i1, %"compiler/source:Span", { i64, [2 x i64] }, i1, { i64, [2 x i64] }, i1, i1, i1, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, [2 x i64] }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, { i64, [2 x i64] }, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i64, i1, i32, i1, i1, i1, i1, i64, %"compiler/source:Span", i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i1, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, { i64, [2 x i64] }, i32, i1, i1 }
%"compiler/scope:Val" = type { i32, { i64, [2 x i64] } }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] }, i1 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/scope:summary" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Capture" = type { i32, ptr }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/scope:compRun" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/diag:Taken", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/diag:Taken" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr } }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/scope:rel" = type { { i64, [2 x i64] }, { i64, [2 x i64] }, i1, %"compiler/source:Span", i64, i1 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/scope:fnUse" = type { i64, %"compiler/source:Span", i64, i64, i32 }
%"compiler/scope:Gap" = type { i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32, i1 }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"compiler/typed:TaskClause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr }
%"compiler/scope:placeSlot" = type { { i64, [2 x i64] }, i1, i64 }
%"compiler/scope:sumRead" = type { i64, ptr }
define dso_local i1 @compiler_2fscope_2eanyArrayBox(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i1
  %l12 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 7
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Make", ptr %t16, i32 0, i32 0
  %t19 = load i32, ptr %t18, !range !{i32 0, i32 5}
  %t21 = trunc i64 0 to i32
  %t22 = icmp eq i32 %t19, %t21
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Make", ptr %t24, i32 0, i32 2
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t31 = icmp eq i64 %t29, 1
  store i1 %t31, ptr %l12, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l12, !tbaa !21
  store i1 %t33, ptr %l2, !tbaa !21
  br label %bb14
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_815ce866d8282155_e428af91c79b2b69)
  unreachable
bb14:
  %t34 = load i1, ptr %l2, !tbaa !21
  store i1 %t34, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ecollectArm(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l20 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Arm", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb17
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l20, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l5, !tbaa !29
  %t30 = load ptr, ptr %l5, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Alt", ptr %t30, i32 0, i32 0
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t33, ptr %t35)
  br label %bb8
bb8:
  %t38 = load ptr, ptr %l5, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Alt", ptr %t38, i32 0, i32 1
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  store i64 %t45, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  %t47 = load i64, ptr %l7, !tbaa !24
  %t48 = load i64, ptr %l8, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb10, label %bb11
bb10:
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t55 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t55, ptr %l35, !tbaa !27
  %t56 = load i64, ptr %l7, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr ptr, ptr %t59, i64 %t56
  %t61 = load ptr, ptr %t60, !tbaa !39
  %t65 = getelementptr %"compiler/typed:Bind", ptr %t61, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t66, ptr %t68)
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t71 = load i64, ptr %l7, !tbaa !24
  %t73 = add i64 %t71, 1
  store i64 %t73, ptr %l7, !tbaa !24
  br label %bb9
bb15:
  br label %bb16
bb16:
  %t75 = load i64, ptr %l3, !tbaa !24
  %t77 = add i64 %t75, 1
  store i64 %t77, ptr %l3, !tbaa !24
  br label %bb4
bb17:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Arm", ptr %t79, i32 0, i32 2
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t83 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t82, ptr %t83)
  br label %bb18
bb18:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/typed:Arm", ptr %t86, i32 0, i32 3
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t90 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %v1, ptr %t89, ptr %t90)
  br label %bb19
bb19:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Arm", ptr %t93, i32 0, i32 4
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t97 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t96, ptr %t97)
  br label %bb20
bb20:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eInferStats(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l9 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l25 = alloca i64
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 125
  %t5 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H135723289cd67fccd962ee530d90cf81(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/scope:Scoper", ptr %t6, i32 0, i32 129
  %t10 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hda9b67cfa9ae8a2a4969568452cdfd9b(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l6
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 127
  %t15 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hda9b67cfa9ae8a2a4969568452cdfd9b(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l9
  br label %bb3
bb3:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/scope:Scoper", ptr %t16, i32 0, i32 126
  %t20 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H135723289cd67fccd962ee530d90cf81(ptr %v0, ptr %t18)
  store i64 %t20, ptr %l12
  br label %bb4
bb4:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/scope:Scoper", ptr %t21, i32 0, i32 128
  %t25 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hda9b67cfa9ae8a2a4969568452cdfd9b(ptr %v0, ptr %t23)
  store i64 %t25, ptr %l15
  br label %bb5
bb5:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/scope:Scoper", ptr %t26, i32 0, i32 143
  %t30 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hb48ebc0aec2f1394686d895000e23a7c(ptr %v0, ptr %t28)
  store i64 %t30, ptr %l18
  br label %bb6
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/scope:Scoper", ptr %t31, i32 0, i32 144
  %t35 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hda9b67cfa9ae8a2a4969568452cdfd9b(ptr %v0, ptr %t33)
  store i64 %t35, ptr %l21
  br label %bb7
bb7:
  %t36 = load i64, ptr %l18, !tbaa !24
  %t37 = load i64, ptr %l21, !tbaa !24
  %t38 = sub i64 %t36, %t37
  store i64 %t38, ptr %l22, !tbaa !24
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/scope:Scoper", ptr %t39, i32 0, i32 144
  %t43 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hda9b67cfa9ae8a2a4969568452cdfd9b(ptr %v0, ptr %t41)
  store i64 %t43, ptr %l25
  br label %bb8
bb8:
  %t44 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t46 = load i64, ptr %l3, !tbaa !24
  %t47 = call i64 @__olang_fmt_i64(ptr null, i64 %t46)
  %t48 = add i64 %t45, %t47
  %t49 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t51 = add i64 %t48, %t50
  %t52 = load i64, ptr %l6, !tbaa !24
  %t53 = call i64 @__olang_fmt_i64(ptr null, i64 %t52)
  %t54 = add i64 %t51, %t53
  %t55 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t57 = add i64 %t54, %t56
  %t58 = load i64, ptr %l9, !tbaa !24
  %t59 = call i64 @__olang_fmt_i64(ptr null, i64 %t58)
  %t60 = add i64 %t57, %t59
  %t61 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t62 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t63 = add i64 %t60, %t62
  %t64 = load i64, ptr %l12, !tbaa !24
  %t65 = call i64 @__olang_fmt_i64(ptr null, i64 %t64)
  %t66 = add i64 %t63, %t65
  %t67 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t68 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t69 = add i64 %t66, %t68
  %t70 = load i64, ptr %l15, !tbaa !24
  %t71 = call i64 @__olang_fmt_i64(ptr null, i64 %t70)
  %t72 = add i64 %t69, %t71
  %t73 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t74 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t75 = add i64 %t72, %t74
  %t76 = load i64, ptr %l22, !tbaa !24
  %t77 = call i64 @__olang_fmt_i64(ptr null, i64 %t76)
  %t78 = add i64 %t75, %t77
  %t79 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t81 = add i64 %t78, %t80
  %t82 = load i64, ptr %l25, !tbaa !24
  %t83 = call i64 @__olang_fmt_i64(ptr null, i64 %t82)
  %t84 = add i64 %t81, %t83
  %t85 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t86 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t87 = add i64 %t84, %t86
  %t88 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t87)
  call void @olang_textcopy(ptr %t88, ptr %t44, i64 %t45)
  %t89 = getelementptr i8, ptr %t88, i64 %t45
  %t90 = call i64 @__olang_fmt_i64(ptr %t89, i64 %t46)
  %t91 = getelementptr i8, ptr %t89, i64 %t47
  call void @olang_textcopy(ptr %t91, ptr %t49, i64 %t50)
  %t92 = getelementptr i8, ptr %t91, i64 %t50
  %t93 = call i64 @__olang_fmt_i64(ptr %t92, i64 %t52)
  %t94 = getelementptr i8, ptr %t92, i64 %t53
  call void @olang_textcopy(ptr %t94, ptr %t55, i64 %t56)
  %t95 = getelementptr i8, ptr %t94, i64 %t56
  %t96 = call i64 @__olang_fmt_i64(ptr %t95, i64 %t58)
  %t97 = getelementptr i8, ptr %t95, i64 %t59
  call void @olang_textcopy(ptr %t97, ptr %t61, i64 %t62)
  %t98 = getelementptr i8, ptr %t97, i64 %t62
  %t99 = call i64 @__olang_fmt_i64(ptr %t98, i64 %t64)
  %t100 = getelementptr i8, ptr %t98, i64 %t65
  call void @olang_textcopy(ptr %t100, ptr %t67, i64 %t68)
  %t101 = getelementptr i8, ptr %t100, i64 %t68
  %t102 = call i64 @__olang_fmt_i64(ptr %t101, i64 %t70)
  %t103 = getelementptr i8, ptr %t101, i64 %t71
  call void @olang_textcopy(ptr %t103, ptr %t73, i64 %t74)
  %t104 = getelementptr i8, ptr %t103, i64 %t74
  %t105 = call i64 @__olang_fmt_i64(ptr %t104, i64 %t76)
  %t106 = getelementptr i8, ptr %t104, i64 %t77
  call void @olang_textcopy(ptr %t106, ptr %t79, i64 %t80)
  %t107 = getelementptr i8, ptr %t106, i64 %t80
  %t108 = call i64 @__olang_fmt_i64(ptr %t107, i64 %t82)
  %t109 = getelementptr i8, ptr %t107, i64 %t83
  call void @olang_textcopy(ptr %t109, ptr %t85, i64 %t86)
  %t110 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t88, 1
  store { i64, ptr } %t111, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eaddToSet(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i64
  %l47 = alloca ptr
  %l48 = alloca ptr
  %l52 = alloca { i64, [2 x i64] }
  %l56 = alloca i64
  %l58 = alloca i64
  %l63 = alloca { i64, [2 x i64] }
  %l64 = alloca { i64, [2 x i64] }
  %l66 = alloca { i64, [2 x i64] }
  %l68 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, [2 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l2
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 5
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t7 = getelementptr { i64 }, ptr %t6, i32 0, i32 0
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l3, !tbaa !24
  br label %bb3
bb2:
  br label %bb20
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/scope:Scoper", ptr %t10, i32 0, i32 36
  %t13 = load i64, ptr %l3, !tbaa !24
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t12, i64 %t13)
  store i64 %t16, ptr %l19
  br label %bb4
bb4:
  %t17 = load i64, ptr %l19, !tbaa !24
  store i64 %t17, ptr %l4, !tbaa !24
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esetEnd(ptr %v0, ptr %t18, i64 %t19)
  store i64 %t22, ptr %l22
  br label %bb5
bb5:
  %t23 = load i64, ptr %l22, !tbaa !24
  store i64 %t23, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l5, !tbaa !24
  %t25 = load i64, ptr %l4, !tbaa !24
  %t28 = icmp sgt i64 %t24, %t25
  br i1 %t28, label %bb6, label %bb7
bb6:
  %t30 = load i64, ptr %l6, !tbaa !24
  %t32 = icmp sgt i64 %t30, 0
  br i1 %t32, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb11
bb8:
  %t34 = load i64, ptr %l5, !tbaa !24
  %t35 = load i64, ptr %l4, !tbaa !24
  %t38 = sub i64 %t34, %t35
  %t39 = load i64, ptr %l6, !tbaa !24
  %t42 = add i64 %t38, %t39
  %t44 = sub i64 %t42, 1
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = sdiv i64 %t44, %t45
  store i64 %t48, ptr %l29, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb10
bb10:
  %t50 = load i64, ptr %l29, !tbaa !24
  store i64 %t50, ptr %l26, !tbaa !24
  br label %bb11
bb11:
  %t51 = load i64, ptr %l26, !tbaa !24
  store i64 %t51, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb12
bb12:
  %t52 = load i64, ptr %l8, !tbaa !24
  %t53 = load i64, ptr %l7, !tbaa !24
  %t56 = icmp slt i64 %t52, %t53
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb13, label %bb14
bb13:
  br label %bb19
bb14:
  br label %bb15
bb15:
  %t60 = load i64, ptr %l4, !tbaa !24
  %t61 = load i64, ptr %l8, !tbaa !24
  %t62 = load i64, ptr %l6, !tbaa !24
  %t65 = mul i64 %t61, %t62
  %t68 = add i64 %t60, %t65
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l47, !tbaa !29
  %t71 = load ptr, ptr %l1, !tbaa !29
  store ptr %t71, ptr %l48, !tbaa !29
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/scope:Scoper", ptr %t72, i32 0, i32 37
  %t78 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t74, i64 %t68)
  store { i64, [2 x i64] } %t78, ptr %l52
  br label %bb16
bb16:
  %t79 = load ptr, ptr %l47, !tbaa !29
  %t80 = load ptr, ptr %l48, !tbaa !29
  %t81 = load { i64, [2 x i64] }, ptr %l52
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eaddToSet(ptr %v0, ptr %v1, ptr %t79, ptr %t80, { i64, [2 x i64] } %t81)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t82 = load i64, ptr %l8, !tbaa !24
  %t84 = add i64 %t82, 1
  store i64 %t84, ptr %l8, !tbaa !24
  br label %bb12
bb19:
  br label %ret
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_ade2525ec560ecac_5eadaea182574e0)
  unreachable
bb25:
  %t86 = load ptr, ptr %l1, !tbaa !29
  store ptr %t86, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb26
bb26:
  %t88 = load i64, ptr %l11, !tbaa !24
  store i64 %t88, ptr %l56, !tbaa !24
  %t89 = load ptr, ptr %l10, !tbaa !29
  %t91 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %v1, ptr %t89)
  store i64 %t91, ptr %l58
  br label %bb27
bb27:
  %t92 = load i64, ptr %l56, !tbaa !24
  %t93 = load i64, ptr %l58, !tbaa !24
  %t94 = icmp slt i64 %t92, %t93
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb28, label %bb29
bb28:
  br label %bb37
bb29:
  br label %bb30
bb30:
  %t98 = load ptr, ptr %l10, !tbaa !29
  %t99 = load i64, ptr %l11, !tbaa !24
  %t102 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v1, ptr %t98, i64 %t99)
  store { i64, [2 x i64] } %t102, ptr %l63
  br label %bb31
bb31:
  %t103 = load { i64, [2 x i64] }, ptr %l63
  store { i64, [2 x i64] } %t103, ptr %l64
  %t105 = load { i64, [2 x i64] }, ptr %l2
  store { i64, [2 x i64] } %t105, ptr %l66
  %t108 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l64, ptr %l66)
  store i1 %t108, ptr %l68
  br label %bb32
bb32:
  %t109 = load i1, ptr %l68, !tbaa !21
  br i1 %t109, label %bb33, label %bb34
bb33:
  br label %ret
bb34:
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t110 = load i64, ptr %l11, !tbaa !24
  %t112 = add i64 %t110, 1
  store i64 %t112, ptr %l11, !tbaa !24
  br label %bb26
bb37:
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t115 = load { i64, [2 x i64] }, ptr %l2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ePush_3ccompiler_2fscope_3aTerm_3e(ptr %v1, ptr %t114, { i64, [2 x i64] } %t115)
  br label %bb38
bb38:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eadmitsAt(ptr %v0, ptr %a0, i32 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i1
  %l3 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca i32
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l15 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l19 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i32
  %l36 = alloca i32
  %l46 = alloca i1
  %l47 = alloca i1
  %l50 = alloca ptr
  %l55 = alloca i32
  %l56 = alloca i32
  %l61 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l63 = alloca i64
  %l65 = alloca i64
  %l70 = alloca i32
  %l74 = alloca i1
  %l87 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l89 = alloca i64
  %l91 = alloca i64
  %l96 = alloca i32
  %l100 = alloca i1
  %l104 = alloca ptr
  %l105 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l107 = alloca i64
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = sext i32 %t1 to i64
  store i64 %t3, ptr %l15, !tbaa !24
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i64 1, ptr %l17, !tbaa !24
  br label %bb3
bb2:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb3
bb3:
  %t6 = load i64, ptr %l15, !tbaa !24
  %t7 = load i64, ptr %l17, !tbaa !24
  %t8 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t6, i64 %t7)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t8, ptr %l18
  br label %bb4
bb4:
  %t9 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l18
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t9, ptr %l3
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/scope:Scoper", ptr %t10, i32 0, i32 9
  %t13 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l3
  %t16 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t12, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t13)
  %t17 = extractvalue { i32, i64 } %t16, 1
  %t18 = extractvalue { i32, i64 } %t16, 0
  store i32 %t18, ptr %l24
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb6, label %ok.20, !prof !99
ok.20:
  store i64 %t17, ptr %l23
  br label %bb5
bb5:
  %t21 = load i64, ptr %l23, !tbaa !24
  store i64 %t21, ptr %l19, !tbaa !24
  br label %bb8
bb6:
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l19, !tbaa !24
  br label %bb8
bb8:
  %t22 = load i64, ptr %l19, !tbaa !24
  store i64 %t22, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = icmp ne i64 %t23, 0
  br i1 %t25, label %bb9, label %bb10
bb9:
  %t27 = load i64, ptr %l4, !tbaa !24
  %t29 = icmp eq i64 %t27, 3
  call void @__olang_scope_close(ptr %s0)
  store i1 %t29, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/scope:Scoper", ptr %t31, i32 0, i32 9
  %t34 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l3
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %t33, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t34, i64 1)
  br label %bb12
bb12:
  store i1 false, ptr %l5, !tbaa !21
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/scope:Scoper", ptr %t37, i32 0, i32 0
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 2
  %t43 = load i32, ptr %l1, !tbaa !23
  %t46 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t42, i32 %t43)
  store i32 %t46, ptr %l36
  br label %bb13
bb13:
  %t47 = load i32, ptr %l36, !range !{i32 0, i32 33}
  store i32 %t47, ptr %l6
  %t48 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t50 = trunc i64 25 to i32
  %t51 = icmp eq i32 %t48, %t50
  br i1 %t51, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb71
bb17:
  %t53 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t55 = trunc i64 18 to i32
  %t56 = icmp eq i32 %t53, %t55
  br i1 %t56, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb43
bb20:
  %t58 = load i1, ptr %l2, !tbaa !21
  store i1 %t58, ptr %l7, !tbaa !21
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/scope:Scoper", ptr %t60, i32 0, i32 0
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = getelementptr %"compiler/generic:Program", ptr %t63, i32 0, i32 2
  %t66 = load i32, ptr %l1, !tbaa !23
  %t69 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t65, i32 %t66)
  store i1 %t69, ptr %l46
  br label %bb21
bb21:
  %t70 = load i1, ptr %l46, !tbaa !21
  br i1 %t70, label %bb22, label %bb23
bb22:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/scope:Scoper", ptr %t71, i32 0, i32 0
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 2
  store ptr %t76, ptr %l50, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/scope:Scoper", ptr %t77, i32 0, i32 0
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/generic:Program", ptr %t80, i32 0, i32 2
  %t83 = load i32, ptr %l1, !tbaa !23
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t82, i32 %t83)
  store i32 %t86, ptr %l55
  br label %bb24
bb23:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb26
bb24:
  %t87 = load ptr, ptr %l50, !tbaa !29
  %t88 = load i32, ptr %l55, !tbaa !23
  %t89 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t87, i32 %t88)
  store i32 %t89, ptr %l56
  br label %bb25
bb25:
  %t90 = load i32, ptr %l56, !range !{i32 0, i32 6}
  %t92 = trunc i64 1 to i32
  %t93 = icmp eq i32 %t90, %t92
  store i1 %t93, ptr %l47, !tbaa !21
  br label %bb26
bb26:
  %t95 = load i1, ptr %l47, !tbaa !21
  br i1 %t95, label %bb27, label %bb28
bb27:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb29
bb28:
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s5
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load i32, ptr %l1, !tbaa !23
  %t100 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparts(ptr %v0, ptr %s5, ptr %t96, i32 %t97)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t100, ptr %l61
  br label %bb30
bb30:
  %t101 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l61
  %t102 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t101, ptr %t102
  store ptr %t102, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb31
bb31:
  %t104 = load i64, ptr %l9, !tbaa !24
  store i64 %t104, ptr %l63, !tbaa !24
  %t105 = load ptr, ptr %l8, !tbaa !29
  %t107 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s5, ptr %t105)
  store i64 %t107, ptr %l65
  br label %bb32
bb32:
  %t108 = load i64, ptr %l63, !tbaa !24
  %t109 = load i64, ptr %l65, !tbaa !24
  %t110 = icmp slt i64 %t108, %t109
  %t112 = xor i1 %t110, true
  br i1 %t112, label %bb33, label %bb34
bb33:
  br label %bb42
bb34:
  br label %bb35
bb35:
  %t114 = load ptr, ptr %l8, !tbaa !29
  %t115 = load i64, ptr %l9, !tbaa !24
  %t118 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s5, ptr %t114, i64 %t115)
  store i32 %t118, ptr %l70
  br label %bb36
bb36:
  %t119 = load i32, ptr %l70, !tbaa !23
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = load i1, ptr %l7, !tbaa !21
  %t126 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartAdmits(ptr %v0, ptr %t120, i32 %t119, i1 %t122)
  store i1 %t126, ptr %l74
  br label %bb37
bb37:
  %t127 = load i1, ptr %l74, !tbaa !21
  br i1 %t127, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb40
bb39:
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t128 = load i64, ptr %l9, !tbaa !24
  %t130 = add i64 %t128, 1
  store i64 %t130, ptr %l9, !tbaa !24
  br label %bb31
bb42:
  call void @__olang_scope_close(ptr %s5)
  br label %bb71
bb43:
  %t132 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t134 = trunc i64 19 to i32
  %t135 = icmp eq i32 %t132, %t134
  br i1 %t135, label %bb44, label %bb45
bb44:
  br label %bb52
bb45:
  %t137 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t139 = trunc i64 22 to i32
  %t140 = icmp eq i32 %t137, %t139
  br i1 %t140, label %bb46, label %bb47
bb46:
  br label %bb52
bb47:
  %t142 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t144 = trunc i64 23 to i32
  %t145 = icmp eq i32 %t142, %t144
  br i1 %t145, label %bb48, label %bb49
bb48:
  br label %bb52
bb49:
  %t147 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t149 = trunc i64 24 to i32
  %t150 = icmp eq i32 %t147, %t149
  br i1 %t150, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb66
bb52:
  store %olang.scope zeroinitializer, ptr %s10
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load i32, ptr %l1, !tbaa !23
  %t156 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparts(ptr %v0, ptr %s10, ptr %t152, i32 %t153)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t156, ptr %l87
  br label %bb53
bb53:
  %t157 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l87
  %t158 = call ptr @__olang_scope_alloc_a(ptr %s10, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t157, ptr %t158
  store ptr %t158, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb54
bb54:
  %t160 = load i64, ptr %l12, !tbaa !24
  store i64 %t160, ptr %l89, !tbaa !24
  %t161 = load ptr, ptr %l11, !tbaa !29
  %t163 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s10, ptr %t161)
  store i64 %t163, ptr %l91
  br label %bb55
bb55:
  %t164 = load i64, ptr %l89, !tbaa !24
  %t165 = load i64, ptr %l91, !tbaa !24
  %t166 = icmp slt i64 %t164, %t165
  %t168 = xor i1 %t166, true
  br i1 %t168, label %bb56, label %bb57
bb56:
  br label %bb65
bb57:
  br label %bb58
bb58:
  %t170 = load ptr, ptr %l11, !tbaa !29
  %t171 = load i64, ptr %l12, !tbaa !24
  %t174 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s10, ptr %t170, i64 %t171)
  store i32 %t174, ptr %l96
  br label %bb59
bb59:
  %t175 = load i32, ptr %l96, !tbaa !23
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = load i1, ptr %l2, !tbaa !21
  %t182 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartAdmits(ptr %v0, ptr %t176, i32 %t175, i1 %t178)
  store i1 %t182, ptr %l100
  br label %bb60
bb60:
  %t183 = load i1, ptr %l100, !tbaa !21
  br i1 %t183, label %bb61, label %bb62
bb61:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb63
bb62:
  br label %bb63
bb63:
  br label %bb64
bb64:
  %t184 = load i64, ptr %l12, !tbaa !24
  %t186 = add i64 %t184, 1
  store i64 %t186, ptr %l12, !tbaa !24
  br label %bb54
bb65:
  call void @__olang_scope_close(ptr %s10)
  br label %bb71
bb66:
  br i1 true, label %bb67, label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb71
bb70:
  call void @__olang_check_failed(ptr @olang_loc_7ac300513ffc0d8b_1ff73281fb7180bf)
  unreachable
bb71:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/scope:Scoper", ptr %t188, i32 0, i32 9
  store ptr %t190, ptr %l104, !tbaa !29
  %t191 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l3
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t191, ptr %l105
  %t192 = load i1, ptr %l5, !tbaa !21
  br i1 %t192, label %bb72, label %bb73
bb72:
  store i64 3, ptr %l107, !tbaa !24
  br label %bb74
bb73:
  store i64 2, ptr %l107, !tbaa !24
  br label %bb74
bb74:
  %t194 = load ptr, ptr %l104, !tbaa !29
  %t195 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l105
  %t196 = load i64, ptr %l107, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %t194, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t195, i64 %t196)
  br label %bb75
bb75:
  %t197 = load i1, ptr %l5, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  store i1 %t197, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eadmitsStores(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l8 = alloca i1
  %l9 = alloca ptr
  %l14 = alloca i32
  %l19 = alloca i64
  %l23 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i32, ptr %l1, !tbaa !23
  %t13 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t9, i32 %t10)
  store i1 %t13, ptr %l8
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t14 = load i1, ptr %l8, !tbaa !21
  store i1 %t14, ptr %rv
  br label %ret
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l9, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/scope:Scoper", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l1, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l14
  br label %bb6
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/scope:Scoper", ptr %t26, i32 0, i32 0
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/generic:Program", ptr %t29, i32 0, i32 2
  %t32 = load i32, ptr %l1, !tbaa !23
  %t35 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t31, i32 %t32)
  store i64 %t35, ptr %l19
  br label %bb7
bb7:
  %t36 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t37 = load i64, ptr %l19, !tbaa !24
  %t39 = and i64 %t37, %t36
  %t41 = icmp ne i64 %t39, 0
  %t42 = load ptr, ptr %l9, !tbaa !29
  %t43 = load i32, ptr %l14, !tbaa !23
  %t45 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eadmitsAt(ptr %v0, ptr %t42, i32 %t43, i1 %t41)
  store i1 %t45, ptr %l23
  br label %bb8
bb8:
  %t46 = load i1, ptr %l23, !tbaa !21
  store i1 %t46, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargPartCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l19 = alloca i1
  %l22 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t6 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s0, ptr %t1, ptr %a1)
  store ptr %t6, ptr %l8
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l8, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  %t8 = load ptr, ptr %l2, !tbaa !29
  store ptr %t8, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t9 = load ptr, ptr %l9, !tbaa !29
  %t10 = icmp ne ptr %t9, null
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l9, !tbaa !29
  %t13 = load i64, ptr %t12, !range !{i64 0, i64 18}
  %t15 = icmp eq i64 %t13, 2
  store i1 %t15, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l10, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr { i64, [5 x i64] }, ptr %t17, i32 0, i32 1
  %t20 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t19, i32 0, i32 1
  %t21 = load i32, ptr %t20
  store i32 %t21, ptr %l3, !tbaa !23
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t25 = getelementptr { i64, [5 x i64] }, ptr %t23, i32 0, i32 1
  %t26 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t25, i32 0, i32 2
  %t27 = load ptr, ptr %t26
  store ptr %t27, ptr %l4, !tbaa !29
  br label %bb6
bb5:
  br label %bb12
bb6:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l3, !tbaa !23
  %t33 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t29, i32 %t30)
  store i1 %t33, ptr %l19
  br label %bb7
bb7:
  %t34 = load i1, ptr %l19, !tbaa !21
  br i1 %t34, label %bb8, label %bb9
bb8:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t39 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartCall(ptr %v0, ptr %s0, ptr %t35, ptr %t36)
  store i64 %t39, ptr %l22
  br label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t40 = load i64, ptr %l22, !tbaa !24
  store i64 %t40, ptr %rv
  br label %ret
bb11:
  br label %bb17
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_bd8a316f234c31bd_e8aabd6e86499e79)
  unreachable
bb17:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargPartOK(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l6 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i1
  %l22 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, [2 x i64] }, ptr %l2
  %t3 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t1)
  store i1 %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load i1, ptr %l6, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t13 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s0, ptr %t8, ptr %a1)
  store ptr %t13, ptr %l12
  br label %bb5
bb5:
  %t14 = load ptr, ptr %l12, !tbaa !29
  store ptr %t14, ptr %l3, !tbaa !29
  %t15 = load ptr, ptr %l3, !tbaa !29
  store ptr %t15, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t16 = load ptr, ptr %l13, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t19 = load ptr, ptr %l13, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 18}
  %t22 = icmp eq i64 %t20, 2
  store i1 %t22, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t23 = load i1, ptr %l14, !tbaa !21
  br i1 %t23, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t26 = getelementptr { i64, [5 x i64] }, ptr %t24, i32 0, i32 1
  %t27 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t26, i32 0, i32 2
  %t28 = load ptr, ptr %t27
  store ptr %t28, ptr %l4, !tbaa !29
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l4, !tbaa !29
  %t32 = load { i64, [2 x i64] }, ptr %l2
  %t36 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartOK(ptr %v0, ptr %s0, ptr %t30, ptr %t31, { i64, [2 x i64] } %t32)
  store i1 %t36, ptr %l22
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t37 = load i1, ptr %l22, !tbaa !21
  store i1 %t37, ptr %rv
  br label %ret
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb16:
  call void @__olang_check_failed(ptr @olang_loc_5ad8ce5e83291793_3404c81b33ceede7)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargRec(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l14 = alloca ptr
  %l18 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l26 = alloca ptr
  %l27 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l40 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t7 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s0, ptr %t2, ptr %a1)
  store ptr %t7, ptr %l9
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l5, !tbaa !29
  %t9 = load ptr, ptr %l9, !tbaa !29
  %t10 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunPromoted(ptr %v0, ptr %s0, ptr %s0, ptr %t8, ptr %t9)
  store ptr %t10, ptr %l10
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l10, !tbaa !29
  store ptr %t11, ptr %l2, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t17 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallOf(ptr %v0, ptr %s0, ptr %s0, ptr %t12, ptr %t13)
  store ptr %t17, ptr %l14
  br label %bb3
bb3:
  %t18 = load ptr, ptr %l14, !tbaa !29
  store ptr %t18, ptr %l3, !tbaa !29
  %t19 = load ptr, ptr %l3, !tbaa !29
  %t21 = icmp eq ptr %t19, null
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb4, label %bb5
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/scope:Scoper", ptr %t25, i32 0, i32 46
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Call", ptr %t28, i32 0, i32 3
  %t31 = load i32, ptr %t30, !tbaa !23
  %t33 = sext i32 %t31 to i64
  %t36 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t27, i64 %t33)
  %t37 = extractvalue { i32, i64 } %t36, 1
  %t38 = extractvalue { i32, i64 } %t36, 0
  store i32 %t38, ptr %l25
  %t39 = icmp ne i32 %t38, 0
  br i1 %t39, label %bb7, label %ok.40, !prof !99
ok.40:
  store i64 %t37, ptr %l24
  br label %bb6
bb5:
  br label %bb10
bb6:
  %t41 = load i64, ptr %l24, !tbaa !24
  store i64 %t41, ptr %l18, !tbaa !24
  br label %bb9
bb7:
  br label %bb8
bb8:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l18, !tbaa !24
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t42 = load i64, ptr %l18, !tbaa !24
  store i64 %t42, ptr %rv
  br label %ret
bb10:
  %t43 = load ptr, ptr %l2, !tbaa !29
  store ptr %t43, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t44 = load ptr, ptr %l26, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb11, label %bb12
bb11:
  %t47 = load ptr, ptr %l26, !tbaa !29
  %t48 = load i64, ptr %t47, !range !{i64 0, i64 18}
  %t50 = icmp eq i64 %t48, 2
  store i1 %t50, ptr %l27, !tbaa !21
  br label %bb12
bb12:
  %t51 = load i1, ptr %l27, !tbaa !21
  br i1 %t51, label %bb13, label %bb14
bb13:
  %t52 = load ptr, ptr %l2, !tbaa !29
  %t54 = getelementptr { i64, [5 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t54, i32 0, i32 2
  %t56 = load ptr, ptr %t55
  store ptr %t56, ptr %l4, !tbaa !29
  br label %bb19
bb14:
  %t58 = load ptr, ptr %l2, !tbaa !29
  store ptr %t58, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t59 = load ptr, ptr %l32, !tbaa !29
  %t60 = icmp ne ptr %t59, null
  br i1 %t60, label %bb15, label %bb16
bb15:
  %t62 = load ptr, ptr %l32, !tbaa !29
  %t63 = load i64, ptr %t62, !range !{i64 0, i64 18}
  %t65 = icmp eq i64 %t63, 3
  store i1 %t65, ptr %l33, !tbaa !21
  br label %bb16
bb16:
  %t66 = load i1, ptr %l33, !tbaa !21
  br i1 %t66, label %bb17, label %bb18
bb17:
  %t67 = load ptr, ptr %l2, !tbaa !29
  %t69 = getelementptr { i64, [5 x i64] }, ptr %t67, i32 0, i32 1
  %t70 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t69, i32 0, i32 2
  %t71 = load ptr, ptr %t70
  store ptr %t71, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load ptr, ptr %l4, !tbaa !29
  %t77 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erecOf(ptr %v0, ptr %s0, ptr %t73, ptr %t74)
  store i64 %t77, ptr %l40
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t78 = load i64, ptr %l40, !tbaa !24
  store i64 %t78, ptr %rv
  br label %ret
bb21:
  br i1 true, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb25:
  call void @__olang_check_failed(ptr @olang_loc_2489ab739aea8b00_863e154a28bdb8e4)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2earm(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca %"compiler/scope:Val"
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca %"compiler/scope:Val"
  %l18 = alloca %"compiler/scope:Val"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca { i64, ptr }
  %l36 = alloca %"compiler/scope:Val"
  %l45 = alloca { i64, ptr }
  %l53 = alloca %"compiler/scope:Val"
  %l58 = alloca ptr
  %l59 = alloca i64
  %l60 = alloca ptr
  %l69 = alloca %"compiler/typed:Local"
  %l71 = alloca { i64, [2 x i64] }
  %l74 = alloca i1
  %l75 = alloca i1
  %l79 = alloca { i64, [2 x i64] }
  %l81 = alloca { i64, [2 x i64] }
  %l83 = alloca i1
  %l85 = alloca i1
  %l89 = alloca { i64, [2 x i64] }
  %l93 = alloca i1
  %l98 = alloca ptr
  %l99 = alloca i64
  %l100 = alloca ptr
  %l104 = alloca { i64, [2 x i64] }
  %l106 = alloca { i64, [2 x i64] }
  %l107 = alloca i64
  %l110 = alloca i64
  %l117 = alloca i1
  %l128 = alloca i64
  %l129 = alloca i64
  %l132 = alloca i64
  %l135 = alloca ptr
  %l136 = alloca i64
  %l139 = alloca i1
  %l143 = alloca i1
  %l146 = alloca i1
  %l147 = alloca i1
  %l150 = alloca i64
  %l152 = alloca i64
  %l162 = alloca %"compiler/scope:Val"
  %l163 = alloca %"compiler/scope:Val"
  %l169 = alloca ptr
  %l177 = alloca ptr
  %l189 = alloca %"compiler/scope:Val"
  %l190 = alloca i32
  %l193 = alloca i32
  %l194 = alloca i32
  %l199 = alloca %"compiler/scope:Val"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/scope:Val"
  %t40 = alloca { i64, [2 x i64] }, align 8
  %t78 = alloca { i64, [2 x i64] }, align 8
  %t293 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, [2 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call %"compiler/scope:Val" @compiler_2fscope_2eplain()
  store %"compiler/scope:Val" %t5, ptr %l18
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t6 = load %"compiler/scope:Val", ptr %l18
  store %"compiler/scope:Val" %t6, ptr %rv
  br label %ret
bb4:
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l19
  br label %bb5
bb5:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l3
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Arm", ptr %t9, i32 0, i32 1
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  store { i64, ptr } %t12, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  store i64 %t16, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  %t18 = load i64, ptr %l5, !tbaa !24
  %t19 = load i64, ptr %l6, !tbaa !24
  %t22 = icmp slt i64 %t18, %t19
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb7, label %bb8
bb7:
  br label %bb75
bb8:
  br label %bb9
bb9:
  %t26 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t26, ptr %l28, !tbaa !27
  %t27 = load i64, ptr %l5, !tbaa !24
  %t29 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr ptr, ptr %t30, i64 %t27
  %t32 = load ptr, ptr %t31, !tbaa !39
  store ptr %t32, ptr %l7, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load ptr, ptr %l7, !tbaa !29
  %t37 = getelementptr %"compiler/typed:Alt", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t40
  %t41 = getelementptr { i64, [2 x i64] }, ptr %t40, i32 0, i32 0
  store i64 0, ptr %t41
  %t42 = load { i64, [2 x i64] }, ptr %t40
  %t46 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t34, ptr %t38, { i64, [2 x i64] } %t42)
  store %"compiler/scope:Val" %t46, ptr %l36
  br label %bb10
bb10:
  %t47 = load ptr, ptr %l7, !tbaa !29
  %t49 = getelementptr %"compiler/typed:Alt", ptr %t47, i32 0, i32 1
  %t50 = load { i64, ptr }, ptr %t49, !tbaa !27
  store { i64, ptr } %t50, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t52 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t52, 0
  store i64 %t54, ptr %l10, !tbaa !24
  br label %bb11
bb11:
  %t56 = load i64, ptr %l9, !tbaa !24
  %t57 = load i64, ptr %l10, !tbaa !24
  %t60 = icmp slt i64 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb12, label %bb13
bb12:
  br label %bb73
bb13:
  br label %bb14
bb14:
  %t64 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t64, ptr %l45, !tbaa !27
  %t65 = load i64, ptr %l9, !tbaa !24
  %t67 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr ptr, ptr %t68, i64 %t65
  %t70 = load ptr, ptr %t69, !tbaa !39
  store ptr %t70, ptr %l11, !tbaa !29
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load ptr, ptr %l11, !tbaa !29
  %t75 = getelementptr %"compiler/typed:Bind", ptr %t73, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t78
  %t79 = getelementptr { i64, [2 x i64] }, ptr %t78, i32 0, i32 0
  store i64 0, ptr %t79
  %t80 = load { i64, [2 x i64] }, ptr %t78
  %t84 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t72, ptr %t76, { i64, [2 x i64] } %t80)
  store %"compiler/scope:Val" %t84, ptr %l53
  br label %bb15
bb15:
  %t85 = load %"compiler/scope:Val", ptr %l53
  store %"compiler/scope:Val" %t85, ptr %l12
  %t86 = load ptr, ptr %l11, !tbaa !29
  %t88 = getelementptr %"compiler/typed:Bind", ptr %t86, i32 0, i32 0
  %t89 = load i32, ptr %t88, !tbaa !23
  %t91 = sext i32 %t89 to i64
  store i64 %t91, ptr %l13, !tbaa !24
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/scope:Scoper", ptr %t93, i32 0, i32 32
  store ptr %t95, ptr %l58, !tbaa !29
  %t96 = load i64, ptr %l13, !tbaa !24
  store i64 %t96, ptr %l59, !tbaa !24
  %t97 = load ptr, ptr %l0, !tbaa !29
  store ptr %t97, ptr %l60, !tbaa !29
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/scope:Scoper", ptr %t98, i32 0, i32 25
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t103 = icmp eq ptr %t101, null
  br i1 %t103, label %bb16, label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_76dd643541c5999_442dc791771fad)
  unreachable
bb17:
  br label %bb18
bb18:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/scope:Scoper", ptr %t105, i32 0, i32 25
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t111 = getelementptr %"compiler/typed:Body", ptr %t108, i32 0, i32 7
  %t112 = load i64, ptr %l13, !tbaa !24
  %t115 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t111, i64 %t112)
  store %"compiler/typed:Local" %t115, ptr %l69
  br label %bb19
bb19:
  %t116 = getelementptr %"compiler/typed:Local", ptr %l69, i32 0, i32 3
  %t117 = load i32, ptr %t116, !tbaa !23
  %t118 = load ptr, ptr %l60, !tbaa !29
  %t120 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblockTerm(ptr %v0, ptr %t118, i32 %t117)
  store { i64, [2 x i64] } %t120, ptr %l71
  br label %bb20
bb20:
  %t121 = load ptr, ptr %l58, !tbaa !29
  %t122 = load i64, ptr %l59, !tbaa !24
  %t123 = load { i64, [2 x i64] }, ptr %l71
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t121, i64 %t122, { i64, [2 x i64] } %t123)
  br label %bb21
bb21:
  %t124 = load i64, ptr %l13, !tbaa !24
  %t127 = call i1 @compiler_2fscope_2eflHas(ptr %s0, ptr %l3, i64 %t124)
  store i1 %t127, ptr %l74
  br label %bb22
bb22:
  %t128 = load i1, ptr %l74, !tbaa !21
  br i1 %t128, label %bb23, label %bb24
bb23:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/scope:Scoper", ptr %t129, i32 0, i32 31
  %t132 = load i64, ptr %l13, !tbaa !24
  %t135 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t131, i64 %t132)
  store { i64, [2 x i64] } %t135, ptr %l79
  br label %bb25
bb24:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb27
bb25:
  %t136 = getelementptr %"compiler/scope:Val", ptr %l12, i32 0, i32 1
  %t137 = load { i64, [2 x i64] }, ptr %t136
  store { i64, [2 x i64] } %t137, ptr %l81
  %t140 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l79, ptr %l81)
  store i1 %t140, ptr %l83
  br label %bb26
bb26:
  %t141 = load i1, ptr %l83, !tbaa !21
  %t142 = xor i1 %t141, true
  store i1 %t142, ptr %l75, !tbaa !21
  br label %bb27
bb27:
  %t144 = load i1, ptr %l75, !tbaa !21
  br i1 %t144, label %bb28, label %bb29
bb28:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/scope:Scoper", ptr %t145, i32 0, i32 31
  %t148 = load i64, ptr %l13, !tbaa !24
  %t151 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t147, i64 %t148)
  store { i64, [2 x i64] } %t151, ptr %l89
  br label %bb30
bb29:
  store i1 false, ptr %l85, !tbaa !21
  br label %bb31
bb30:
  %t152 = load { i64, [2 x i64] }, ptr %l89
  %t154 = extractvalue { i64, [2 x i64] } %t152, 0
  %t155 = icmp eq i64 %t154, 0
  %t157 = xor i1 %t155, true
  store i1 %t157, ptr %l85, !tbaa !21
  br label %bb31
bb31:
  %t159 = load i1, ptr %l85, !tbaa !21
  br i1 %t159, label %bb32, label %bb33
bb32:
  %t160 = getelementptr %"compiler/scope:Val", ptr %l12, i32 0, i32 1
  %t161 = load { i64, [2 x i64] }, ptr %t160
  %t163 = extractvalue { i64, [2 x i64] } %t161, 0
  %t164 = icmp eq i64 %t163, 0
  %t166 = xor i1 %t164, true
  store i1 %t166, ptr %l93, !tbaa !21
  br label %bb34
bb33:
  store i1 false, ptr %l93, !tbaa !21
  br label %bb34
bb34:
  %t168 = load i1, ptr %l93, !tbaa !21
  br i1 %t168, label %bb35, label %bb36
bb35:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/scope:Scoper", ptr %t169, i32 0, i32 31
  store ptr %t171, ptr %l98, !tbaa !29
  %t172 = load i64, ptr %l13, !tbaa !24
  store i64 %t172, ptr %l99, !tbaa !24
  %t173 = load ptr, ptr %l0, !tbaa !29
  store ptr %t173, ptr %l100, !tbaa !29
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/scope:Scoper", ptr %t174, i32 0, i32 31
  %t177 = load i64, ptr %l13, !tbaa !24
  %t180 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t176, i64 %t177)
  store { i64, [2 x i64] } %t180, ptr %l104
  br label %bb37
bb36:
  %t181 = load i64, ptr %l13, !tbaa !24
  %t184 = call i1 @compiler_2fscope_2eflHas(ptr %s0, ptr %l3, i64 %t181)
  store i1 %t184, ptr %l117
  br label %bb45
bb37:
  %t185 = getelementptr %"compiler/scope:Val", ptr %l12, i32 0, i32 1
  %t186 = load { i64, [2 x i64] }, ptr %t185
  %t187 = load ptr, ptr %l100, !tbaa !29
  %t188 = load { i64, [2 x i64] }, ptr %l104
  %t190 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esetOf(ptr %v0, ptr %t187, { i64, [2 x i64] } %t188, { i64, [2 x i64] } %t186)
  store { i64, [2 x i64] } %t190, ptr %l106
  br label %bb38
bb38:
  %t191 = load ptr, ptr %l98, !tbaa !29
  %t192 = load i64, ptr %l99, !tbaa !24
  %t193 = load { i64, [2 x i64] }, ptr %l106
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t191, i64 %t192, { i64, [2 x i64] } %t193)
  br label %bb39
bb39:
  %t194 = load i64, ptr %l13, !tbaa !24
  store i64 %t194, ptr %l107, !tbaa !24
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/scope:Scoper", ptr %t195, i32 0, i32 132
  %t199 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t197)
  store i64 %t199, ptr %l110
  br label %bb40
bb40:
  %t200 = load i64, ptr %l107, !tbaa !24
  %t201 = load i64, ptr %l110, !tbaa !24
  %t202 = icmp slt i64 %t200, %t201
  br i1 %t202, label %bb41, label %bb42
bb41:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/scope:Scoper", ptr %t204, i32 0, i32 132
  %t207 = load i64, ptr %l13, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t206, i64 %t207, i64 -2)
  br label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb44
bb44:
  br label %bb71
bb45:
  %t210 = load i1, ptr %l117, !tbaa !21
  %t211 = xor i1 %t210, true
  br i1 %t211, label %bb46, label %bb47
bb46:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/scope:Scoper", ptr %t213, i32 0, i32 31
  %t216 = load i64, ptr %l13, !tbaa !24
  %t217 = getelementptr %"compiler/scope:Val", ptr %l12, i32 0, i32 1
  %t218 = load { i64, [2 x i64] }, ptr %t217
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t215, i64 %t216, { i64, [2 x i64] } %t218)
  br label %bb48
bb47:
  br label %bb70
bb48:
  %t222 = load i64, ptr %l13, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t222)
  br label %bb49
bb49:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load ptr, ptr %l11, !tbaa !29
  %t228 = getelementptr %"compiler/typed:Bind", ptr %t226, i32 0, i32 1
  %t229 = load ptr, ptr %t228, !tbaa !29
  %t232 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eclaimRoot(ptr %v0, ptr %v1, ptr %t225, ptr %t229)
  store i64 %t232, ptr %l128
  br label %bb50
bb50:
  %t233 = load i64, ptr %l128, !tbaa !24
  store i64 %t233, ptr %l14, !tbaa !24
  %t234 = load i64, ptr %l13, !tbaa !24
  store i64 %t234, ptr %l129, !tbaa !24
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/scope:Scoper", ptr %t235, i32 0, i32 132
  %t239 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t237)
  store i64 %t239, ptr %l132
  br label %bb51
bb51:
  %t240 = load i64, ptr %l129, !tbaa !24
  %t241 = load i64, ptr %l132, !tbaa !24
  %t242 = icmp slt i64 %t240, %t241
  br i1 %t242, label %bb52, label %bb53
bb52:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr %"compiler/scope:Scoper", ptr %t244, i32 0, i32 132
  store ptr %t246, ptr %l135, !tbaa !29
  %t247 = load i64, ptr %l13, !tbaa !24
  store i64 %t247, ptr %l136, !tbaa !24
  %t248 = load i64, ptr %l14, !tbaa !24
  %t250 = icmp sge i64 %t248, 0
  br i1 %t250, label %bb54, label %bb55
bb53:
  br label %bb69
bb54:
  %t252 = load i64, ptr %l14, !tbaa !24
  %t253 = load i64, ptr %l13, !tbaa !24
  %t256 = icmp ne i64 %t252, %t253
  store i1 %t256, ptr %l139, !tbaa !21
  br label %bb56
bb55:
  store i1 false, ptr %l139, !tbaa !21
  br label %bb56
bb56:
  %t258 = load i1, ptr %l139, !tbaa !21
  br i1 %t258, label %bb57, label %bb58
bb57:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load i64, ptr %l14, !tbaa !24
  %t263 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eliftable(ptr %v0, ptr %t259, i64 %t260)
  store i1 %t263, ptr %l146
  br label %bb59
bb58:
  store i1 false, ptr %l143, !tbaa !21
  br label %bb64
bb59:
  %t264 = load i1, ptr %l146, !tbaa !21
  br i1 %t264, label %bb60, label %bb61
bb60:
  store i1 true, ptr %l147, !tbaa !21
  br label %bb63
bb61:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t266 = load i64, ptr %l14, !tbaa !24
  %t269 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eheldCall(ptr %v0, ptr %t265, i64 %t266)
  store i64 %t269, ptr %l150
  br label %bb62
bb62:
  %t270 = load i64, ptr %l150, !tbaa !24
  %t271 = icmp sge i64 %t270, 0
  store i1 %t271, ptr %l147, !tbaa !21
  br label %bb63
bb63:
  %t273 = load i1, ptr %l147, !tbaa !21
  store i1 %t273, ptr %l143, !tbaa !21
  br label %bb64
bb64:
  %t274 = load i1, ptr %l143, !tbaa !21
  br i1 %t274, label %bb65, label %bb66
bb65:
  %t275 = load i64, ptr %l14, !tbaa !24
  store i64 %t275, ptr %l152, !tbaa !24
  br label %bb67
bb66:
  store i64 -2, ptr %l152, !tbaa !24
  br label %bb67
bb67:
  %t277 = load ptr, ptr %l135, !tbaa !29
  %t278 = load i64, ptr %l136, !tbaa !24
  %t279 = load i64, ptr %l152, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t277, i64 %t278, i64 %t279)
  br label %bb68
bb68:
  br label %bb69
bb69:
  br label %bb70
bb70:
  br label %bb71
bb71:
  br label %bb72
bb72:
  %t280 = load i64, ptr %l9, !tbaa !24
  %t282 = add i64 %t280, 1
  store i64 %t282, ptr %l9, !tbaa !24
  br label %bb11
bb73:
  br label %bb74
bb74:
  %t284 = load i64, ptr %l5, !tbaa !24
  %t286 = add i64 %t284, 1
  store i64 %t286, ptr %l5, !tbaa !24
  br label %bb6
bb75:
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t289 = load ptr, ptr %l1, !tbaa !29
  %t291 = getelementptr %"compiler/typed:Arm", ptr %t289, i32 0, i32 2
  %t292 = load ptr, ptr %t291, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t293
  %t294 = getelementptr { i64, [2 x i64] }, ptr %t293, i32 0, i32 0
  store i64 0, ptr %t294
  %t295 = load { i64, [2 x i64] }, ptr %t293
  %t299 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t288, ptr %t292, { i64, [2 x i64] } %t295)
  store %"compiler/scope:Val" %t299, ptr %l162
  br label %bb76
bb76:
  %t300 = call %"compiler/scope:Val" @compiler_2fscope_2eplain()
  store %"compiler/scope:Val" %t300, ptr %l163
  br label %bb77
bb77:
  %t301 = load %"compiler/scope:Val", ptr %l163
  store %"compiler/scope:Val" %t301, ptr %l15
  %t302 = load ptr, ptr %l1, !tbaa !29
  %t304 = getelementptr %"compiler/typed:Arm", ptr %t302, i32 0, i32 3
  %t305 = load ptr, ptr %t304, !tbaa !29
  %t307 = icmp eq ptr %t305, null
  %t309 = xor i1 %t307, true
  br i1 %t309, label %bb78, label %bb79
bb78:
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t313 = getelementptr %"compiler/scope:Scoper", ptr %t311, i32 0, i32 34
  store ptr %t313, ptr %l169, !tbaa !29
  %t314 = load ptr, ptr %l1, !tbaa !29
  %t316 = getelementptr %"compiler/typed:Arm", ptr %t314, i32 0, i32 3
  %t317 = load ptr, ptr %t316, !tbaa !29
  %t319 = icmp eq ptr %t317, null
  br i1 %t319, label %bb80, label %bb81
bb79:
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t322 = load ptr, ptr %l1, !tbaa !29
  %t324 = getelementptr %"compiler/typed:Arm", ptr %t322, i32 0, i32 4
  %t325 = load ptr, ptr %t324, !tbaa !29
  %t326 = load { i64, [2 x i64] }, ptr %l2
  %t330 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t321, ptr %t325, { i64, [2 x i64] } %t326)
  store %"compiler/scope:Val" %t330, ptr %l199
  br label %bb93
bb80:
  call void @__olang_check_failed(ptr @olang_loc_a61f6227542ac272_aba93d64b04206c6)
  unreachable
bb81:
  br label %bb82
bb82:
  %t331 = load ptr, ptr %l1, !tbaa !29
  %t333 = getelementptr %"compiler/typed:Arm", ptr %t331, i32 0, i32 3
  %t334 = load ptr, ptr %t333, !tbaa !29
  %t337 = getelementptr %"compiler/typed:Block", ptr %t334, i32 0, i32 0
  %t338 = load i32, ptr %t337, !tbaa !23
  %t339 = load ptr, ptr %l169, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t339, i32 %t338)
  br label %bb83
bb83:
  %t341 = load ptr, ptr %l0, !tbaa !29
  store ptr %t341, ptr %l177, !tbaa !29
  %t342 = load ptr, ptr %l1, !tbaa !29
  %t344 = getelementptr %"compiler/typed:Arm", ptr %t342, i32 0, i32 3
  %t345 = load ptr, ptr %t344, !tbaa !29
  %t347 = icmp eq ptr %t345, null
  br i1 %t347, label %bb84, label %bb85
bb84:
  call void @__olang_check_failed(ptr @olang_loc_f34ecaa27a4fd2b3_7961e1dcca83cdb7)
  unreachable
bb85:
  br label %bb86
bb86:
  %t349 = load ptr, ptr %l1, !tbaa !29
  %t351 = getelementptr %"compiler/typed:Arm", ptr %t349, i32 0, i32 3
  %t352 = load ptr, ptr %t351, !tbaa !29
  %t355 = getelementptr %"compiler/typed:Block", ptr %t352, i32 0, i32 1
  %t356 = load { i64, ptr }, ptr %t355, !tbaa !27
  %t357 = load ptr, ptr %l177, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estmts(ptr %v0, ptr %v1, ptr %t357, { i64, ptr } %t356)
  br label %bb87
bb87:
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t360 = load ptr, ptr %l1, !tbaa !29
  %t362 = getelementptr %"compiler/typed:Arm", ptr %t360, i32 0, i32 4
  %t363 = load ptr, ptr %t362, !tbaa !29
  %t364 = load { i64, [2 x i64] }, ptr %l2
  %t368 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t359, ptr %t363, { i64, [2 x i64] } %t364)
  store %"compiler/scope:Val" %t368, ptr %l189
  br label %bb88
bb88:
  %t369 = load %"compiler/scope:Val", ptr %l189
  store %"compiler/scope:Val" %t369, ptr %l15
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t372 = getelementptr %"compiler/scope:Scoper", ptr %t370, i32 0, i32 34
  %t374 = call { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePop_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t372)
  %t375 = extractvalue { i32, i32 } %t374, 1
  %t376 = extractvalue { i32, i32 } %t374, 0
  store i32 %t376, ptr %l194
  %t377 = icmp ne i32 %t376, 0
  br i1 %t377, label %bb90, label %ok.378, !prof !99
ok.378:
  store i32 %t375, ptr %l193
  br label %bb89
bb89:
  %t379 = load i32, ptr %l193, !tbaa !23
  store i32 %t379, ptr %l190, !tbaa !23
  br label %bb92
bb90:
  br label %bb91
bb91:
  call void @__olang_ert_req_clear()
  br label %bb92
bb92:
  br label %bb94
bb93:
  %t380 = load %"compiler/scope:Val", ptr %l199
  store %"compiler/scope:Val" %t380, ptr %l15
  br label %bb94
bb94:
  %t381 = load %"compiler/scope:Val", ptr %l15
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/scope:Val" %t381, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scope:Val", ptr %rv
  ret %"compiler/scope:Val" %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebindLocal(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l8 = alloca ptr
  %l18 = alloca %"compiler/typed:Local"
  %l23 = alloca i1
  %l27 = alloca i1
  %l34 = alloca i1
  %l47 = alloca i1
  %l53 = alloca i1
  %l58 = alloca i1
  %l59 = alloca i1
  %l64 = alloca i1
  %l66 = alloca ptr
  %l71 = alloca ptr
  %l72 = alloca i32
  %l74 = alloca ptr
  %l76 = alloca i64
  %l79 = alloca i64
  %l81 = alloca i64
  %l83 = alloca i64
  %l88 = alloca { i64, [2 x i64] }
  %l96 = alloca ptr
  %l99 = alloca ptr
  %l101 = alloca ptr
  %l104 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 25
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_b442aabc3e151319_4a7d8af854ba830d)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 25
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 7
  %t15 = load i32, ptr %l1, !tbaa !23
  %t17 = sext i32 %t15 to i64
  %t20 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t14, i64 %t17)
  store %"compiler/typed:Local" %t20, ptr %l18
  br label %bb4
bb4:
  %t21 = getelementptr %"compiler/typed:Local", ptr %l18, i32 0, i32 4
  %t22 = load i32, ptr %t21, !range !{i32 0, i32 7}
  store i32 %t22, ptr %l3
  %t24 = load i32, ptr %l3, !range !{i32 0, i32 7}
  %t26 = trunc i64 1 to i32
  %t27 = icmp eq i32 %t24, %t26
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb5, label %bb6
bb5:
  %t31 = load i32, ptr %l3, !range !{i32 0, i32 7}
  %t33 = trunc i64 3 to i32
  %t34 = icmp eq i32 %t31, %t33
  %t36 = xor i1 %t34, true
  store i1 %t36, ptr %l23, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb7
bb7:
  %t38 = load i1, ptr %l23, !tbaa !21
  br i1 %t38, label %bb8, label %bb9
bb8:
  %t39 = load i32, ptr %l3, !range !{i32 0, i32 7}
  %t41 = trunc i64 6 to i32
  %t42 = icmp eq i32 %t39, %t41
  %t44 = xor i1 %t42, true
  store i1 %t44, ptr %l27, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb10
bb10:
  %t46 = load i1, ptr %l27, !tbaa !21
  br i1 %t46, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb12:
  br label %bb13
bb13:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i32, ptr %l1, !tbaa !23
  %t50 = sext i32 %t48 to i64
  %t53 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ereassigned(ptr %v0, ptr %t47, i64 %t50)
  store i1 %t53, ptr %l34
  br label %bb14
bb14:
  %t54 = load i1, ptr %l34, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i32, ptr %l1, !tbaa !23
  %t58 = sext i32 %t56 to i64
  %t59 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteLate(ptr %v0, ptr %v1, ptr %t55, i64 %t58, ptr %t59)
  br label %bb17
bb16:
  br label %bb52
bb17:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/scope:Scoper", ptr %t63, i32 0, i32 49
  %t66 = load i1, ptr %t65, !tbaa !21
  br i1 %t66, label %bb18, label %bb19
bb18:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/scope:Scoper", ptr %t68, i32 0, i32 52
  %t71 = load i32, ptr %l1, !tbaa !23
  %t73 = sext i32 %t71 to i64
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t70, i64 %t73, i1 true)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/scope:Scoper", ptr %t76, i32 0, i32 49
  %t79 = load i1, ptr %t78, !tbaa !21
  br i1 %t79, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l47, !tbaa !21
  br label %bb24
bb23:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/scope:Scoper", ptr %t81, i32 0, i32 48
  %t84 = load i64, ptr %t83, !tbaa !24
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/scope:Scoper", ptr %t85, i32 0, i32 26
  %t88 = load i64, ptr %t87, !tbaa !24
  %t91 = icmp ne i64 %t84, %t88
  store i1 %t91, ptr %l47, !tbaa !21
  br label %bb24
bb24:
  %t93 = load i1, ptr %l47, !tbaa !21
  br i1 %t93, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb28
bb26:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/scope:Scoper", ptr %t94, i32 0, i32 51
  %t97 = load i32, ptr %l1, !tbaa !23
  %t99 = sext i32 %t97 to i64
  %t102 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t96, i64 %t99)
  store i1 %t102, ptr %l58
  br label %bb27
bb27:
  %t103 = load i1, ptr %l58, !tbaa !21
  store i1 %t103, ptr %l53, !tbaa !21
  br label %bb28
bb28:
  %t104 = load i1, ptr %l53, !tbaa !21
  br i1 %t104, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l59, !tbaa !21
  br label %bb32
bb30:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/scope:Scoper", ptr %t105, i32 0, i32 52
  %t108 = load i32, ptr %l1, !tbaa !23
  %t110 = sext i32 %t108 to i64
  %t113 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t107, i64 %t110)
  store i1 %t113, ptr %l64
  br label %bb31
bb31:
  %t114 = load i1, ptr %l64, !tbaa !21
  %t115 = xor i1 %t114, true
  store i1 %t115, ptr %l59, !tbaa !21
  br label %bb32
bb32:
  %t117 = load i1, ptr %l59, !tbaa !21
  br i1 %t117, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb34:
  br label %bb35
bb35:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/scope:Scoper", ptr %t118, i32 0, i32 50
  %t121 = load i32, ptr %l1, !tbaa !23
  %t123 = sext i32 %t121 to i64
  %t126 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H1c7d675bdd0f9eae97711af4b62e7c17(ptr %v0, ptr %v0, ptr %t120, i64 %t123)
  %t127 = extractvalue { i32, ptr } %t126, 1
  %t128 = extractvalue { i32, ptr } %t126, 0
  store i32 %t128, ptr %l72
  %t129 = icmp ne i32 %t128, 0
  br i1 %t129, label %bb37, label %ok.130, !prof !99
ok.130:
  store ptr %t127, ptr %l71
  br label %bb36
bb36:
  %t131 = load ptr, ptr %l71, !tbaa !29
  store ptr %t131, ptr %l66, !tbaa !29
  br label %bb39
bb37:
  br label %bb38
bb38:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb39:
  %t132 = load ptr, ptr %l66, !tbaa !29
  store ptr %t132, ptr %l4, !tbaa !29
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/scope:Scoper", ptr %t133, i32 0, i32 43
  store ptr %t135, ptr %l74, !tbaa !29
  %t136 = load i32, ptr %l1, !tbaa !23
  %t138 = sext i32 %t136 to i64
  store i64 %t138, ptr %l76, !tbaa !24
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/scope:Scoper", ptr %t139, i32 0, i32 44
  %t143 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t141)
  store i64 %t143, ptr %l79
  br label %bb40
bb40:
  %t144 = load ptr, ptr %l74, !tbaa !29
  %t145 = load i64, ptr %l76, !tbaa !24
  %t146 = load i64, ptr %l79, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t144, i64 %t145, i64 %t146)
  br label %bb41
bb41:
  %t147 = load ptr, ptr %l4, !tbaa !29
  store ptr %t147, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb42
bb42:
  %t149 = load i64, ptr %l6, !tbaa !24
  store i64 %t149, ptr %l81, !tbaa !24
  %t150 = load ptr, ptr %l5, !tbaa !29
  %t152 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t150)
  store i64 %t152, ptr %l83
  br label %bb43
bb43:
  %t153 = load i64, ptr %l81, !tbaa !24
  %t154 = load i64, ptr %l83, !tbaa !24
  %t155 = icmp slt i64 %t153, %t154
  %t157 = xor i1 %t155, true
  br i1 %t157, label %bb44, label %bb45
bb44:
  br label %bb51
bb45:
  br label %bb46
bb46:
  %t159 = load ptr, ptr %l5, !tbaa !29
  %t160 = load i64, ptr %l6, !tbaa !24
  %t163 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t159, i64 %t160)
  store { i64, [2 x i64] } %t163, ptr %l88
  br label %bb47
bb47:
  %t164 = load { i64, [2 x i64] }, ptr %l88
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/scope:Scoper", ptr %t165, i32 0, i32 44
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ePush_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t167, { i64, [2 x i64] } %t164)
  br label %bb48
bb48:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/scope:Scoper", ptr %t171, i32 0, i32 45
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t173, i64 -1)
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t175 = load i64, ptr %l6, !tbaa !24
  %t177 = add i64 %t175, 1
  store i64 %t177, ptr %l6, !tbaa !24
  br label %bb42
bb51:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb52:
  %t179 = load ptr, ptr %l0, !tbaa !29
  store ptr %t179, ptr %l96, !tbaa !29
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load ptr, ptr %l2, !tbaa !29
  %t184 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunPromoted(ptr %v0, ptr %v1, ptr %s0, ptr %t180, ptr %t181)
  store ptr %t184, ptr %l99
  br label %bb53
bb53:
  %t185 = load ptr, ptr %l99, !tbaa !29
  %t186 = load ptr, ptr %l96, !tbaa !29
  %t188 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallOf(ptr %v0, ptr %s0, ptr %s0, ptr %t186, ptr %t185)
  store ptr %t188, ptr %l101
  br label %bb54
bb54:
  %t189 = load ptr, ptr %l101, !tbaa !29
  store ptr %t189, ptr %l8, !tbaa !29
  %t190 = load ptr, ptr %l8, !tbaa !29
  %t192 = icmp eq ptr %t190, null
  br i1 %t192, label %bb55, label %bb56
bb55:
  store i1 true, ptr %l104, !tbaa !21
  br label %bb57
bb56:
  %t194 = load ptr, ptr %l8, !tbaa !29
  %t196 = getelementptr %"compiler/typed:Call", ptr %t194, i32 0, i32 3
  %t197 = load i32, ptr %t196, !tbaa !23
  %t199 = sext i32 %t197 to i64
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/scope:Scoper", ptr %t200, i32 0, i32 53
  %t203 = load i64, ptr %t202, !tbaa !24
  %t206 = icmp ne i64 %t199, %t203
  store i1 %t206, ptr %l104, !tbaa !21
  br label %bb57
bb57:
  %t208 = load i1, ptr %l104, !tbaa !21
  br i1 %t208, label %bb58, label %bb59
bb58:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb59:
  br label %bb60
bb60:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/scope:Scoper", ptr %t209, i32 0, i32 43
  %t212 = load i32, ptr %l1, !tbaa !23
  %t214 = sext i32 %t212 to i64
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t217 = getelementptr %"compiler/scope:Scoper", ptr %t215, i32 0, i32 54
  %t218 = load i64, ptr %t217, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t211, i64 %t214, i64 %t218)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebindingParam(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i32
  %l31 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l35 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca ptr
  %l52 = alloca i64
  %l55 = alloca i1
  %l59 = alloca %"compiler/typed:Local"
  %l62 = alloca i1
  %l63 = alloca ptr
  %l67 = alloca %"compiler/typed:Local"
  %l69 = alloca i1
  %l75 = alloca i64
  %l77 = alloca i64
  %l82 = alloca i32
  %l83 = alloca ptr
  %l88 = alloca %"compiler/typed:Local"
  %l90 = alloca i1
  %s4 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Body", ptr %t1, i32 0, i32 11
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  %t8 = xor i1 %t6, true
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Body", ptr %t10, i32 0, i32 11
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = icmp eq ptr %t13, null
  br i1 %t15, label %bb3, label %bb4
bb2:
  br label %bb41
bb3:
  call void @__olang_check_failed(ptr @olang_loc_c5883e2e797033d1_fc44041a166d1b4d)
  unreachable
bb4:
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Body", ptr %t17, i32 0, i32 11
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Block", ptr %t20, i32 0, i32 1
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  store { i64, ptr } %t24, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l5, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l4, !tbaa !24
  %t31 = load i64, ptr %l5, !tbaa !24
  %t34 = icmp slt i64 %t30, %t31
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb7, label %bb8
bb7:
  br label %bb40
bb8:
  br label %bb9
bb9:
  %t38 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t38, ptr %l31, !tbaa !27
  %t39 = load i64, ptr %l4, !tbaa !24
  %t41 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr ptr, ptr %t42, i64 %t39
  %t44 = load ptr, ptr %t43, !tbaa !39
  store ptr %t44, ptr %l6, !tbaa !29
  %t46 = load ptr, ptr %l6, !tbaa !29
  store ptr %t46, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t47 = load ptr, ptr %l34, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb10, label %bb11
bb10:
  %t50 = load ptr, ptr %l34, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 17}
  %t53 = icmp eq i64 %t51, 0
  store i1 %t53, ptr %l35, !tbaa !21
  br label %bb11
bb11:
  %t54 = load i1, ptr %l35, !tbaa !21
  br i1 %t54, label %bb12, label %bb13
bb12:
  %t55 = load ptr, ptr %l6, !tbaa !29
  %t57 = getelementptr { i64, [3 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t57, i32 0, i32 1
  %t59 = load i32, ptr %t58
  store i32 %t59, ptr %l7, !tbaa !23
  %t61 = load ptr, ptr %l6, !tbaa !29
  %t63 = getelementptr { i64, [3 x i64] }, ptr %t61, i32 0, i32 1
  %t64 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t63, i32 0, i32 2
  %t65 = load ptr, ptr %t64
  store ptr %t65, ptr %l8, !tbaa !29
  br label %bb14
bb13:
  br label %bb33
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t67 = load i32, ptr %l7, !tbaa !23
  %t69 = sext i32 %t67 to i64
  %t73 = icmp ne i64 %t69, %a2
  br i1 %t73, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s4)
  br label %bb39
bb16:
  br label %bb17
bb17:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load ptr, ptr %l8, !tbaa !29
  %t80 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s4, ptr %t75, ptr %t76)
  store ptr %t80, ptr %l49
  br label %bb18
bb18:
  %t81 = load ptr, ptr %l49, !tbaa !29
  %t82 = call ptr @compiler_2fscope_2eunPassed(ptr %s4, ptr %s4, ptr %t81)
  store ptr %t82, ptr %l50
  br label %bb19
bb19:
  %t83 = load ptr, ptr %l50, !tbaa !29
  %t85 = call i64 @compiler_2fscope_2eflRootExpr(ptr %s4, ptr %t83)
  store i64 %t85, ptr %l52
  br label %bb20
bb20:
  %t86 = load i64, ptr %l52, !tbaa !24
  store i64 %t86, ptr %l9, !tbaa !24
  %t87 = load i64, ptr %l9, !tbaa !24
  %t89 = icmp sge i64 %t87, 0
  br i1 %t89, label %bb21, label %bb22
bb21:
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t93 = getelementptr %"compiler/typed:Body", ptr %t91, i32 0, i32 7
  %t94 = load i64, ptr %l9, !tbaa !24
  %t97 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v1, ptr %t93, i64 %t94)
  store %"compiler/typed:Local" %t97, ptr %l59
  br label %bb23
bb22:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb24
bb23:
  %t98 = getelementptr %"compiler/typed:Local", ptr %l59, i32 0, i32 4
  %t99 = load i32, ptr %t98, !range !{i32 0, i32 7}
  %t101 = trunc i64 0 to i32
  %t102 = icmp eq i32 %t99, %t101
  store i1 %t102, ptr %l55, !tbaa !21
  br label %bb24
bb24:
  %t104 = load i1, ptr %l55, !tbaa !21
  br i1 %t104, label %bb25, label %bb26
bb25:
  %t105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t105, ptr %l63, !tbaa !29
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr %"compiler/typed:Body", ptr %t106, i32 0, i32 7
  %t109 = load i64, ptr %l9, !tbaa !24
  %t112 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v1, ptr %t108, i64 %t109)
  store %"compiler/typed:Local" %t112, ptr %l67
  br label %bb27
bb26:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb29
bb27:
  %t113 = getelementptr %"compiler/typed:Local", ptr %l67, i32 0, i32 2
  %t114 = load i32, ptr %t113, !tbaa !23
  %t115 = load ptr, ptr %l63, !tbaa !29
  %t117 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t115, i32 %t114)
  store i1 %t117, ptr %l69
  br label %bb28
bb28:
  %t118 = load i1, ptr %l69, !tbaa !21
  store i1 %t118, ptr %l62, !tbaa !21
  br label %bb29
bb29:
  %t119 = load i1, ptr %l62, !tbaa !21
  br i1 %t119, label %bb30, label %bb31
bb30:
  %t120 = load i64, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  store i64 %t120, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s4)
  br label %bb38
bb33:
  br i1 true, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_ea6e06a9360e3f29_549c073cdead9825)
  unreachable
bb38:
  br label %bb39
bb39:
  %t122 = load i64, ptr %l4, !tbaa !24
  %t124 = add i64 %t122, 1
  store i64 %t124, ptr %l4, !tbaa !24
  br label %bb6
bb40:
  br label %bb41
bb41:
  store i64 -1, ptr %l10, !tbaa !24
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t128 = getelementptr %"compiler/typed:Body", ptr %t126, i32 0, i32 5
  store ptr %t128, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb42
bb42:
  %t130 = load i64, ptr %l12, !tbaa !24
  store i64 %t130, ptr %l75, !tbaa !24
  %t131 = load ptr, ptr %l11, !tbaa !29
  %t133 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v1, ptr %t131)
  store i64 %t133, ptr %l77
  br label %bb43
bb43:
  %t134 = load i64, ptr %l75, !tbaa !24
  %t135 = load i64, ptr %l77, !tbaa !24
  %t136 = icmp slt i64 %t134, %t135
  %t138 = xor i1 %t136, true
  br i1 %t138, label %bb44, label %bb45
bb44:
  br label %bb57
bb45:
  br label %bb46
bb46:
  %t140 = load ptr, ptr %l11, !tbaa !29
  %t141 = load i64, ptr %l12, !tbaa !24
  %t144 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v1, ptr %t140, i64 %t141)
  store i32 %t144, ptr %l82
  br label %bb47
bb47:
  %t145 = load i32, ptr %l82, !tbaa !23
  store i32 %t145, ptr %l13, !tbaa !23
  %t146 = load ptr, ptr %l0, !tbaa !29
  store ptr %t146, ptr %l83, !tbaa !29
  %t147 = load ptr, ptr %l1, !tbaa !29
  %t149 = getelementptr %"compiler/typed:Body", ptr %t147, i32 0, i32 7
  %t150 = load i32, ptr %l13, !tbaa !23
  %t152 = sext i32 %t150 to i64
  %t155 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v1, ptr %t149, i64 %t152)
  store %"compiler/typed:Local" %t155, ptr %l88
  br label %bb48
bb48:
  %t156 = getelementptr %"compiler/typed:Local", ptr %l88, i32 0, i32 2
  %t157 = load i32, ptr %t156, !tbaa !23
  %t158 = load ptr, ptr %l83, !tbaa !29
  %t160 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t158, i32 %t157)
  store i1 %t160, ptr %l90
  br label %bb49
bb49:
  %t161 = load i1, ptr %l90, !tbaa !21
  %t162 = xor i1 %t161, true
  br i1 %t162, label %bb50, label %bb51
bb50:
  br label %bb56
bb51:
  br label %bb52
bb52:
  %t164 = load i64, ptr %l10, !tbaa !24
  %t166 = icmp sge i64 %t164, 0
  br i1 %t166, label %bb53, label %bb54
bb53:
  store i64 -1, ptr %rv
  br label %ret
bb54:
  br label %bb55
bb55:
  %t169 = load i32, ptr %l13, !tbaa !23
  %t171 = sext i32 %t169 to i64
  store i64 %t171, ptr %l10, !tbaa !24
  br label %bb56
bb56:
  %t173 = load i64, ptr %l12, !tbaa !24
  %t175 = add i64 %t173, 1
  store i64 %t175, ptr %l12, !tbaa !24
  br label %bb42
bb57:
  %t177 = load i64, ptr %l10, !tbaa !24
  store i64 %t177, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebodyOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 5}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i32 }, ptr %t12, i32 0, i32 0
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l2, !tbaa !23
  %t18 = sext i32 %t16 to i64
  store i64 %t18, ptr %l3, !tbaa !24
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_1cbcbb68212d18c9_a0b41c71999484fd)
  unreachable
bb11:
  %t20 = load i64, ptr %l3, !tbaa !24
  store i64 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eborrowRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l21 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l2, !tbaa !23
  %t18 = sext i32 %t16 to i64
  store i64 %t18, ptr %l4, !tbaa !24
  br label %bb18
bb6:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t21 = load ptr, ptr %l13, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb7, label %bb8
bb7:
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 8}
  %t27 = icmp eq i64 %t25, 2
  store i1 %t27, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t28 = load i1, ptr %l14, !tbaa !21
  br i1 %t28, label %bb9, label %bb10
bb9:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l3, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t35 = load ptr, ptr %l3, !tbaa !29
  %t38 = call i64 @compiler_2fscope_2eflRootExpr(ptr %v1, ptr %t35)
  store i64 %t38, ptr %l21
  br label %bb12
bb12:
  %t39 = load i64, ptr %l21, !tbaa !24
  store i64 %t39, ptr %l4, !tbaa !24
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i64 -1, ptr %l4, !tbaa !24
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_43bfbe21df81ba11_dcc42dbc8d435385)
  unreachable
bb18:
  %t40 = load i64, ptr %l4, !tbaa !24
  store i64 %t40, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildsIntoSet(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i32 %a3, i64 %a4, { i64, [2 x i64] } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l11 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i1
  %l25 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l35 = alloca i64
  %l37 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, [2 x i64] } %a5, 0
  %t4 = icmp eq i64 %t3, 5
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb9
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 false, ptr %rv
  br label %ret
bb8:
  call void @__olang_check_failed(ptr @olang_loc_ae19eb3dd0d17d29_4ac15fb0aa0c6205)
  unreachable
bb9:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l3, !tbaa !23
  %t11 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t7, i32 %t8)
  store i1 %t11, ptr %l11
  br label %bb10
bb10:
  %t12 = load i1, ptr %l11, !tbaa !21
  %t13 = xor i1 %t12, true
  br i1 %t13, label %bb11, label %bb12
bb11:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l3, !tbaa !23
  %t19 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evalueAdmits(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l15
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t20 = load i1, ptr %l15, !tbaa !21
  store i1 %t20, ptr %rv
  br label %ret
bb14:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l3, !tbaa !23
  %t25 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eadmitsStores(ptr %v0, ptr %t21, i32 %t22)
  store i1 %t25, ptr %l18
  br label %bb15
bb15:
  %t26 = load i1, ptr %l18, !tbaa !21
  %t27 = xor i1 %t26, true
  br i1 %t27, label %bb16, label %bb17
bb16:
  store i1 false, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/scope:Scoper", ptr %t30, i32 0, i32 0
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/generic:Program", ptr %t33, i32 0, i32 2
  %t36 = load i32, ptr %l3, !tbaa !23
  %t39 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t35, i32 %t36)
  store i64 %t39, ptr %l25
  br label %bb19
bb19:
  %t40 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t41 = load i64, ptr %l25, !tbaa !24
  %t43 = and i64 %t41, %t40
  %t45 = icmp ne i64 %t43, 0
  br i1 %t45, label %bb20, label %bb21
bb20:
  store i1 true, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l30, !tbaa !29
  %t49 = load ptr, ptr %l1, !tbaa !29
  store ptr %t49, ptr %l31, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr %"compiler/typed:Call", ptr %t51, i32 0, i32 0
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t57 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebodyOf(ptr %v0, ptr %v1, ptr %t50, ptr %t54)
  store i64 %t57, ptr %l35
  br label %bb23
bb23:
  %t59 = load ptr, ptr %l30, !tbaa !29
  %t60 = load ptr, ptr %l31, !tbaa !29
  %t61 = load i64, ptr %l35, !tbaa !24
  %t63 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeBuilds(ptr %v0, ptr %v1, ptr %t59, ptr %t60, i64 %t61, i64 %a4)
  store i1 %t63, ptr %l37
  br label %bb24
bb24:
  %t64 = load i1, ptr %l37, !tbaa !21
  store i1 %t64, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeStoresArg(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i1
  %l19 = alloca ptr
  %l22 = alloca i64
  %l26 = alloca ptr
  %l29 = alloca i64
  %l31 = alloca i1
  %l35 = alloca ptr
  %l39 = alloca i1
  %l43 = alloca ptr
  %l47 = alloca i1
  %l48 = alloca i64
  %l52 = alloca ptr
  %l55 = alloca i64
  %l61 = alloca ptr
  %l65 = alloca i1
  %l66 = alloca ptr
  %l67 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Call", ptr %a1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  store ptr %t6, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t7 = load ptr, ptr %l8, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l8, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l9, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l3, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { i32 }, ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l4, !tbaa !23
  br label %bb5
bb4:
  br label %bb28
bb5:
  %t21 = load i32, ptr %l4, !tbaa !23
  %t23 = sext i32 %t21 to i64
  store i64 %t23, ptr %l5, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/scope:Scoper", ptr %t25, i32 0, i32 6
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t27, i64 %t28)
  store ptr %t31, ptr %l19
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t34 = getelementptr %"compiler/scope:summary", ptr %t32, i32 0, i32 16
  %t35 = load i1, ptr %t34, !tbaa !21
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l2, !tbaa !24
  store i64 %t37, ptr %l22, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/scope:Scoper", ptr %t38, i32 0, i32 6
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t40, i64 %t41)
  store ptr %t44, ptr %l26
  br label %bb9
bb8:
  br label %bb16
bb9:
  %t45 = load ptr, ptr %l26, !tbaa !29
  %t47 = getelementptr %"compiler/scope:summary", ptr %t45, i32 0, i32 6
  %t49 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t47)
  store i64 %t49, ptr %l29
  br label %bb10
bb10:
  %t50 = load i64, ptr %l22, !tbaa !24
  %t51 = load i64, ptr %l29, !tbaa !24
  %t52 = icmp slt i64 %t50, %t51
  br i1 %t52, label %bb11, label %bb12
bb11:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/scope:Scoper", ptr %t54, i32 0, i32 6
  %t57 = load i64, ptr %l5, !tbaa !24
  %t60 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t56, i64 %t57)
  store ptr %t60, ptr %l35
  br label %bb13
bb12:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb15
bb13:
  %t61 = load ptr, ptr %l35, !tbaa !29
  %t63 = getelementptr %"compiler/scope:summary", ptr %t61, i32 0, i32 6
  %t64 = load i64, ptr %l2, !tbaa !24
  %t67 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t63, i64 %t64)
  store i1 %t67, ptr %l39
  br label %bb14
bb14:
  %t68 = load i1, ptr %l39, !tbaa !21
  store i1 %t68, ptr %l31, !tbaa !21
  br label %bb15
bb15:
  %t69 = load i1, ptr %l31, !tbaa !21
  store i1 %t69, ptr %rv
  br label %ret
bb16:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/scope:Scoper", ptr %t70, i32 0, i32 6
  %t73 = load i64, ptr %l5, !tbaa !24
  %t76 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t72, i64 %t73)
  store ptr %t76, ptr %l43
  br label %bb17
bb17:
  %t77 = load ptr, ptr %l43, !tbaa !29
  %t79 = getelementptr %"compiler/scope:summary", ptr %t77, i32 0, i32 15
  %t80 = load i1, ptr %t79, !tbaa !21
  %t82 = xor i1 %t80, true
  br i1 %t82, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l47, !tbaa !21
  br label %bb22
bb19:
  %t84 = load i64, ptr %l2, !tbaa !24
  store i64 %t84, ptr %l48, !tbaa !24
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/scope:Scoper", ptr %t85, i32 0, i32 6
  %t88 = load i64, ptr %l5, !tbaa !24
  %t91 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t87, i64 %t88)
  store ptr %t91, ptr %l52
  br label %bb20
bb20:
  %t92 = load ptr, ptr %l52, !tbaa !29
  %t94 = getelementptr %"compiler/scope:summary", ptr %t92, i32 0, i32 6
  %t96 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t94)
  store i64 %t96, ptr %l55
  br label %bb21
bb21:
  %t97 = load i64, ptr %l48, !tbaa !24
  %t98 = load i64, ptr %l55, !tbaa !24
  %t99 = icmp sge i64 %t97, %t98
  store i1 %t99, ptr %l47, !tbaa !21
  br label %bb22
bb22:
  %t101 = load i1, ptr %l47, !tbaa !21
  br i1 %t101, label %bb23, label %bb24
bb23:
  store i1 true, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/scope:Scoper", ptr %t103, i32 0, i32 6
  %t106 = load i64, ptr %l5, !tbaa !24
  %t109 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t105, i64 %t106)
  store ptr %t109, ptr %l61
  br label %bb26
bb26:
  %t110 = load ptr, ptr %l61, !tbaa !29
  %t112 = getelementptr %"compiler/scope:summary", ptr %t110, i32 0, i32 6
  %t113 = load i64, ptr %l2, !tbaa !24
  %t116 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t112, i64 %t113)
  store i1 %t116, ptr %l65
  br label %bb27
bb27:
  %t117 = load i1, ptr %l65, !tbaa !21
  store i1 %t117, ptr %rv
  br label %ret
bb28:
  %t118 = load ptr, ptr %l3, !tbaa !29
  store ptr %t118, ptr %l66, !tbaa !29
  store i1 false, ptr %l67, !tbaa !21
  %t119 = load ptr, ptr %l66, !tbaa !29
  %t120 = icmp ne ptr %t119, null
  br i1 %t120, label %bb29, label %bb30
bb29:
  %t122 = load ptr, ptr %l66, !tbaa !29
  %t123 = load i64, ptr %t122, !range !{i64 0, i64 5}
  %t125 = icmp eq i64 %t123, 1
  store i1 %t125, ptr %l67, !tbaa !21
  br label %bb30
bb30:
  %t126 = load i1, ptr %l67, !tbaa !21
  br i1 %t126, label %bb31, label %bb32
bb31:
  br label %bb37
bb32:
  %t127 = load ptr, ptr %l3, !tbaa !29
  store ptr %t127, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t128 = load ptr, ptr %l70, !tbaa !29
  %t129 = icmp ne ptr %t128, null
  br i1 %t129, label %bb33, label %bb34
bb33:
  %t131 = load ptr, ptr %l70, !tbaa !29
  %t132 = load i64, ptr %t131, !range !{i64 0, i64 5}
  %t134 = icmp eq i64 %t132, 4
  store i1 %t134, ptr %l71, !tbaa !21
  br label %bb34
bb34:
  %t135 = load i1, ptr %l71, !tbaa !21
  br i1 %t135, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  store i1 false, ptr %rv
  br label %ret
bb38:
  br i1 true, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  store i1 true, ptr %rv
  br label %ret
bb42:
  call void @__olang_check_failed(ptr @olang_loc_190434ab470c43aa_3a8ff8b5c92040d6)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecaptureVar(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, [1 x i64] }
  %l11 = alloca i32
  %l15 = alloca ptr
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i64
  %l48 = alloca { i64, [1 x i64] }
  %s0 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %a0, i32 0, i32 1
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l15
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l15, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 6
  %t11 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l17
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e(ptr %s0, ptr %l17)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l19
  br label %bb2
bb2:
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %s0, ptr %l3)
  store i64 %t16, ptr %l21
  br label %bb3
bb3:
  %t17 = load i64, ptr %l21, !tbaa !24
  store i64 %t17, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t18 = load i64, ptr %l5, !tbaa !24
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = icmp sgt i64 %t18, %t19
  br i1 %t22, label %bb4, label %bb5
bb4:
  %t24 = load i64, ptr %l6, !tbaa !24
  %t26 = icmp sgt i64 %t24, 0
  br i1 %t26, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb9
bb6:
  %t28 = load i64, ptr %l5, !tbaa !24
  %t29 = load i64, ptr %l4, !tbaa !24
  %t32 = sub i64 %t28, %t29
  %t33 = load i64, ptr %l6, !tbaa !24
  %t36 = add i64 %t32, %t33
  %t38 = sub i64 %t36, 1
  %t39 = load i64, ptr %l6, !tbaa !24
  %t42 = sdiv i64 %t38, %t39
  store i64 %t42, ptr %l28, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb8
bb8:
  %t44 = load i64, ptr %l28, !tbaa !24
  store i64 %t44, ptr %l25, !tbaa !24
  br label %bb9
bb9:
  %t45 = load i64, ptr %l25, !tbaa !24
  store i64 %t45, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb10
bb10:
  %t46 = load i64, ptr %l8, !tbaa !24
  %t47 = load i64, ptr %l7, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb11, label %bb12
bb11:
  br label %bb28
bb12:
  br label %bb13
bb13:
  %t54 = load i64, ptr %l4, !tbaa !24
  %t55 = load i64, ptr %l8, !tbaa !24
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = mul i64 %t55, %t56
  %t62 = add i64 %t54, %t59
  store i64 %t62, ptr %l9, !tbaa !24
  %t64 = load i64, ptr %l9, !tbaa !24
  %t67 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %s0, ptr %l3, i64 %t64)
  store { i64, [1 x i64] } %t67, ptr %l48
  br label %bb14
bb14:
  %t68 = load { i64, [1 x i64] }, ptr %l48
  store { i64, [1 x i64] } %t68, ptr %l10
  %t69 = load { i64, [1 x i64] }, ptr %l10
  %t71 = extractvalue { i64, [1 x i64] } %t69, 0
  %t72 = icmp eq i64 %t71, 4
  br i1 %t72, label %bb15, label %bb16
bb15:
  %t74 = getelementptr { i64, [1 x i64] }, ptr %l10, i32 0, i32 1
  %t75 = getelementptr { i32 }, ptr %t74, i32 0, i32 0
  %t76 = load i32, ptr %t75
  store i32 %t76, ptr %l11, !tbaa !23
  br label %bb17
bb16:
  br label %bb21
bb17:
  %t78 = load i32, ptr %l11, !tbaa !23
  %t82 = icmp eq i32 %t78, %a2
  br i1 %t82, label %bb18, label %bb19
bb18:
  %t84 = load i64, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t84, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  br label %bb26
bb21:
  br i1 true, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_5cb72587228936ff_1a6837af5c2cdca3)
  unreachable
bb26:
  br label %bb27
bb27:
  %t86 = load i64, ptr %l8, !tbaa !24
  %t88 = add i64 %t86, 1
  store i64 %t88, ptr %l8, !tbaa !24
  br label %bb10
bb28:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca i64
  %l47 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca i1
  %l68 = alloca i1
  %l72 = alloca ptr
  %l73 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca i1
  %l91 = alloca ptr
  %l92 = alloca i1
  %l102 = alloca ptr
  %l103 = alloca i1
  %l112 = alloca i1
  %l120 = alloca i64
  %l123 = alloca i64
  %l144 = alloca i1
  %l147 = alloca { i64, ptr }
  %l154 = alloca ptr
  %l155 = alloca i1
  %l168 = alloca { i64, ptr }
  %l177 = alloca ptr
  %l178 = alloca i1
  %l188 = alloca i1
  %l189 = alloca i1
  %l193 = alloca i1
  %l196 = alloca i1
  %l198 = alloca { i64, ptr }
  %l202 = alloca ptr
  %l203 = alloca i1
  %l217 = alloca ptr
  %l218 = alloca i1
  %l227 = alloca ptr
  %l228 = alloca i1
  %l241 = alloca { i64, ptr }
  %l254 = alloca ptr
  %l263 = alloca ptr
  %l264 = alloca i1
  %l281 = alloca { i64, ptr }
  %l292 = alloca { i64, ptr }
  %l303 = alloca ptr
  %l304 = alloca i1
  %l313 = alloca ptr
  %l314 = alloca i1
  %l319 = alloca ptr
  %l320 = alloca i1
  %l335 = alloca { i64, ptr }
  %l345 = alloca ptr
  %l346 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t6 = load ptr, ptr %l50, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l50, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 18}
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l51, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l51, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t16, i32 0, i32 1
  %t18 = load i32, ptr %t17
  store i32 %t18, ptr %l3, !tbaa !23
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [5 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t22, i32 0, i32 2
  %t24 = load ptr, ptr %t23
  store ptr %t24, ptr %l4, !tbaa !29
  br label %bb12
bb7:
  %t26 = load ptr, ptr %l1, !tbaa !29
  store ptr %t26, ptr %l58, !tbaa !29
  store i1 false, ptr %l59, !tbaa !21
  %t27 = load ptr, ptr %l58, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb8, label %bb9
bb8:
  %t30 = load ptr, ptr %l58, !tbaa !29
  %t31 = load i64, ptr %t30, !range !{i64 0, i64 18}
  %t33 = icmp eq i64 %t31, 4
  store i1 %t33, ptr %l59, !tbaa !21
  br label %bb9
bb9:
  %t34 = load i1, ptr %l59, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb10:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr { i64, [5 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t37, i32 0, i32 1
  %t39 = load i32, ptr %t38
  store i32 %t39, ptr %l3, !tbaa !23
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr { i64, [5 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t43, i32 0, i32 2
  %t45 = load ptr, ptr %t44
  store ptr %t45, ptr %l4, !tbaa !29
  br label %bb12
bb11:
  br label %bb18
bb12:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i32, ptr %l3, !tbaa !23
  %t51 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t47, i32 %t48)
  store i1 %t51, ptr %l68
  br label %bb13
bb13:
  %t52 = load i1, ptr %l68, !tbaa !21
  br i1 %t52, label %bb14, label %bb15
bb14:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load ptr, ptr %l4, !tbaa !29
  %t55 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarriedPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t53, ptr %t54, ptr %t55)
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  br label %bb198
bb18:
  %t59 = load ptr, ptr %l1, !tbaa !29
  store ptr %t59, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t60 = load ptr, ptr %l72, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb19, label %bb20
bb19:
  %t63 = load ptr, ptr %l72, !tbaa !29
  %t64 = load i64, ptr %t63, !range !{i64 0, i64 18}
  %t66 = icmp eq i64 %t64, 3
  store i1 %t66, ptr %l73, !tbaa !21
  br label %bb20
bb20:
  %t67 = load i1, ptr %l73, !tbaa !21
  br i1 %t67, label %bb21, label %bb22
bb21:
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [5 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t70, i32 0, i32 2
  %t72 = load ptr, ptr %t71
  store ptr %t72, ptr %l5, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load ptr, ptr %l5, !tbaa !29
  %t76 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarriedPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t74, ptr %t75, ptr %t76)
  br label %bb24
bb24:
  br label %bb198
bb25:
  %t80 = load ptr, ptr %l1, !tbaa !29
  store ptr %t80, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t81 = load ptr, ptr %l81, !tbaa !29
  %t82 = icmp ne ptr %t81, null
  br i1 %t82, label %bb26, label %bb27
bb26:
  %t84 = load ptr, ptr %l81, !tbaa !29
  %t85 = load i64, ptr %t84, !range !{i64 0, i64 18}
  %t87 = icmp eq i64 %t85, 10
  store i1 %t87, ptr %l82, !tbaa !21
  br label %bb27
bb27:
  %t88 = load i1, ptr %l82, !tbaa !21
  br i1 %t88, label %bb28, label %bb29
bb28:
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t91 = getelementptr { i64, [5 x i64] }, ptr %t89, i32 0, i32 1
  %t92 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t91, i32 0, i32 2
  %t93 = load ptr, ptr %t92
  store ptr %t93, ptr %l6, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load ptr, ptr %l6, !tbaa !29
  %t98 = getelementptr %"compiler/typed:Slice", ptr %t96, i32 0, i32 0
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t100 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarriedPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t95, ptr %t99, ptr %t100)
  br label %bb31
bb31:
  br label %bb198
bb32:
  %t104 = load ptr, ptr %l1, !tbaa !29
  store ptr %t104, ptr %l91, !tbaa !29
  store i1 false, ptr %l92, !tbaa !21
  %t105 = load ptr, ptr %l91, !tbaa !29
  %t106 = icmp ne ptr %t105, null
  br i1 %t106, label %bb33, label %bb34
bb33:
  %t108 = load ptr, ptr %l91, !tbaa !29
  %t109 = load i64, ptr %t108, !range !{i64 0, i64 18}
  %t111 = icmp eq i64 %t109, 5
  store i1 %t111, ptr %l92, !tbaa !21
  br label %bb34
bb34:
  %t112 = load i1, ptr %l92, !tbaa !21
  br i1 %t112, label %bb35, label %bb36
bb35:
  %t113 = load ptr, ptr %l1, !tbaa !29
  %t115 = getelementptr { i64, [5 x i64] }, ptr %t113, i32 0, i32 1
  %t116 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t115, i32 0, i32 2
  %t117 = load ptr, ptr %t116
  store ptr %t117, ptr %l7, !tbaa !29
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load ptr, ptr %l7, !tbaa !29
  %t122 = getelementptr %"compiler/typed:Promote", ptr %t120, i32 0, i32 0
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t119, ptr %t123, ptr %t125)
  br label %bb38
bb38:
  br label %bb198
bb39:
  %t129 = load ptr, ptr %l1, !tbaa !29
  store ptr %t129, ptr %l102, !tbaa !29
  store i1 false, ptr %l103, !tbaa !21
  %t130 = load ptr, ptr %l102, !tbaa !29
  %t131 = icmp ne ptr %t130, null
  br i1 %t131, label %bb40, label %bb41
bb40:
  %t133 = load ptr, ptr %l102, !tbaa !29
  %t134 = load i64, ptr %t133, !range !{i64 0, i64 18}
  %t136 = icmp eq i64 %t134, 6
  store i1 %t136, ptr %l103, !tbaa !21
  br label %bb41
bb41:
  %t137 = load i1, ptr %l103, !tbaa !21
  br i1 %t137, label %bb42, label %bb43
bb42:
  %t138 = load ptr, ptr %l1, !tbaa !29
  %t140 = getelementptr { i64, [5 x i64] }, ptr %t138, i32 0, i32 1
  %t141 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t140, i32 0, i32 1
  %t142 = load i32, ptr %t141
  store i32 %t142, ptr %l8, !tbaa !23
  %t144 = load ptr, ptr %l1, !tbaa !29
  %t146 = getelementptr { i64, [5 x i64] }, ptr %t144, i32 0, i32 1
  %t147 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t146, i32 0, i32 2
  %t148 = load ptr, ptr %t147
  store ptr %t148, ptr %l9, !tbaa !29
  br label %bb44
bb43:
  br label %bb66
bb44:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load i32, ptr %l8, !tbaa !23
  %t154 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t150, i32 %t151)
  store i1 %t154, ptr %l112
  br label %bb45
bb45:
  %t155 = load i1, ptr %l112, !tbaa !21
  %t156 = xor i1 %t155, true
  br i1 %t156, label %bb46, label %bb47
bb46:
  br label %ret
bb47:
  br label %bb48
bb48:
  store i64 0, ptr %l10, !tbaa !24
  %t158 = load ptr, ptr %l9, !tbaa !29
  %t160 = getelementptr %"compiler/typed:Call", ptr %t158, i32 0, i32 1
  %t161 = load { i64, ptr }, ptr %t160, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t161, 0
  store i64 %t163, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t165 = load i64, ptr %l11, !tbaa !24
  %t166 = load i64, ptr %l10, !tbaa !24
  %t169 = icmp sgt i64 %t165, %t166
  br i1 %t169, label %bb49, label %bb50
bb49:
  %t171 = load i64, ptr %l12, !tbaa !24
  %t173 = icmp sgt i64 %t171, 0
  br i1 %t173, label %bb51, label %bb52
bb50:
  store i64 0, ptr %l120, !tbaa !24
  br label %bb54
bb51:
  %t175 = load i64, ptr %l11, !tbaa !24
  %t176 = load i64, ptr %l10, !tbaa !24
  %t179 = sub i64 %t175, %t176
  %t180 = load i64, ptr %l12, !tbaa !24
  %t183 = add i64 %t179, %t180
  %t185 = sub i64 %t183, 1
  %t186 = load i64, ptr %l12, !tbaa !24
  %t189 = sdiv i64 %t185, %t186
  store i64 %t189, ptr %l123, !tbaa !24
  br label %bb53
bb52:
  store i64 0, ptr %l123, !tbaa !24
  br label %bb53
bb53:
  %t191 = load i64, ptr %l123, !tbaa !24
  store i64 %t191, ptr %l120, !tbaa !24
  br label %bb54
bb54:
  %t192 = load i64, ptr %l120, !tbaa !24
  store i64 %t192, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb55
bb55:
  %t193 = load i64, ptr %l14, !tbaa !24
  %t194 = load i64, ptr %l13, !tbaa !24
  %t197 = icmp slt i64 %t193, %t194
  %t199 = xor i1 %t197, true
  br i1 %t199, label %bb56, label %bb57
bb56:
  br label %bb65
bb57:
  br label %bb58
bb58:
  %t201 = load i64, ptr %l10, !tbaa !24
  %t202 = load i64, ptr %l14, !tbaa !24
  %t203 = load i64, ptr %l12, !tbaa !24
  %t206 = mul i64 %t202, %t203
  %t209 = add i64 %t201, %t206
  store i64 %t209, ptr %l15, !tbaa !24
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t212 = load ptr, ptr %l9, !tbaa !29
  %t213 = load i64, ptr %l15, !tbaa !24
  %t217 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecanKeep(ptr %v0, ptr %v1, ptr %t211, ptr %t212, i64 %t213)
  store i1 %t217, ptr %l144
  br label %bb59
bb59:
  %t218 = load i1, ptr %l144, !tbaa !21
  br i1 %t218, label %bb60, label %bb61
bb60:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load ptr, ptr %l9, !tbaa !29
  %t222 = getelementptr %"compiler/typed:Call", ptr %t220, i32 0, i32 1
  %t223 = load { i64, ptr }, ptr %t222, !tbaa !27
  store { i64, ptr } %t223, ptr %l147, !tbaa !27
  %t224 = load i64, ptr %l15, !tbaa !24
  %t226 = getelementptr { i64, ptr }, ptr %l147, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !27
  %t228 = getelementptr ptr, ptr %t227, i64 %t224
  %t229 = load ptr, ptr %t228, !tbaa !39
  %t231 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t219, ptr %t229, ptr %t231)
  br label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb63
bb63:
  br label %bb64
bb64:
  %t235 = load i64, ptr %l14, !tbaa !24
  %t237 = add i64 %t235, 1
  store i64 %t237, ptr %l14, !tbaa !24
  br label %bb55
bb65:
  br label %bb198
bb66:
  %t239 = load ptr, ptr %l1, !tbaa !29
  store ptr %t239, ptr %l154, !tbaa !29
  store i1 false, ptr %l155, !tbaa !21
  %t240 = load ptr, ptr %l154, !tbaa !29
  %t241 = icmp ne ptr %t240, null
  br i1 %t241, label %bb67, label %bb68
bb67:
  %t243 = load ptr, ptr %l154, !tbaa !29
  %t244 = load i64, ptr %t243, !range !{i64 0, i64 18}
  %t246 = icmp eq i64 %t244, 7
  store i1 %t246, ptr %l155, !tbaa !21
  br label %bb68
bb68:
  %t247 = load i1, ptr %l155, !tbaa !21
  br i1 %t247, label %bb69, label %bb70
bb69:
  %t248 = load ptr, ptr %l1, !tbaa !29
  %t250 = getelementptr { i64, [5 x i64] }, ptr %t248, i32 0, i32 1
  %t251 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t250, i32 0, i32 2
  %t252 = load ptr, ptr %t251
  store ptr %t252, ptr %l16, !tbaa !29
  br label %bb71
bb70:
  br label %bb79
bb71:
  %t254 = load ptr, ptr %l16, !tbaa !29
  %t256 = getelementptr %"compiler/typed:Make", ptr %t254, i32 0, i32 2
  %t257 = load { i64, ptr }, ptr %t256, !tbaa !27
  store { i64, ptr } %t257, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t259 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t261 = extractvalue { i64, ptr } %t259, 0
  store i64 %t261, ptr %l19, !tbaa !24
  br label %bb72
bb72:
  %t263 = load i64, ptr %l18, !tbaa !24
  %t264 = load i64, ptr %l19, !tbaa !24
  %t267 = icmp slt i64 %t263, %t264
  %t269 = xor i1 %t267, true
  br i1 %t269, label %bb73, label %bb74
bb73:
  br label %bb78
bb74:
  br label %bb75
bb75:
  %t271 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t271, ptr %l168, !tbaa !27
  %t272 = load i64, ptr %l18, !tbaa !24
  %t274 = getelementptr { i64, ptr }, ptr %l168, i32 0, i32 1
  %t275 = load ptr, ptr %t274, !tbaa !27
  %t276 = getelementptr ptr, ptr %t275, i64 %t272
  %t277 = load ptr, ptr %t276, !tbaa !39
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t282 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t279, ptr %t277, ptr %t282)
  br label %bb76
bb76:
  br label %bb77
bb77:
  %t286 = load i64, ptr %l18, !tbaa !24
  %t288 = add i64 %t286, 1
  store i64 %t288, ptr %l18, !tbaa !24
  br label %bb72
bb78:
  br label %bb198
bb79:
  %t290 = load ptr, ptr %l1, !tbaa !29
  store ptr %t290, ptr %l177, !tbaa !29
  store i1 false, ptr %l178, !tbaa !21
  %t291 = load ptr, ptr %l177, !tbaa !29
  %t292 = icmp ne ptr %t291, null
  br i1 %t292, label %bb80, label %bb81
bb80:
  %t294 = load ptr, ptr %l177, !tbaa !29
  %t295 = load i64, ptr %t294, !range !{i64 0, i64 18}
  %t297 = icmp eq i64 %t295, 9
  store i1 %t297, ptr %l178, !tbaa !21
  br label %bb81
bb81:
  %t298 = load i1, ptr %l178, !tbaa !21
  br i1 %t298, label %bb82, label %bb83
bb82:
  %t299 = load ptr, ptr %l1, !tbaa !29
  %t301 = getelementptr { i64, [5 x i64] }, ptr %t299, i32 0, i32 1
  %t302 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t301, i32 0, i32 1
  %t303 = load i32, ptr %t302
  store i32 %t303, ptr %l21, !tbaa !23
  %t305 = load ptr, ptr %l1, !tbaa !29
  %t307 = getelementptr { i64, [5 x i64] }, ptr %t305, i32 0, i32 1
  %t308 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t307, i32 0, i32 2
  %t309 = load i32, ptr %t308, !range !{i32 0, i32 43}
  store i32 %t309, ptr %l22
  %t311 = load ptr, ptr %l1, !tbaa !29
  %t313 = getelementptr { i64, [5 x i64] }, ptr %t311, i32 0, i32 1
  %t314 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t313, i32 0, i32 4
  %t315 = load { i64, ptr }, ptr %t314
  store { i64, ptr } %t315, ptr %l23, !tbaa !27
  br label %bb84
bb83:
  br label %bb97
bb84:
  %t317 = load i32, ptr %l22, !range !{i32 0, i32 43}
  %t319 = call i1 @compiler_2ftyped_2ePassesRefs(i32 %t317)
  store i1 %t319, ptr %l188
  br label %bb85
bb85:
  %t320 = load i1, ptr %l188, !tbaa !21
  br i1 %t320, label %bb86, label %bb87
bb86:
  %t321 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t323 = extractvalue { i64, ptr } %t321, 0
  %t325 = icmp sgt i64 %t323, 0
  store i1 %t325, ptr %l189, !tbaa !21
  br label %bb88
bb87:
  store i1 false, ptr %l189, !tbaa !21
  br label %bb88
bb88:
  %t327 = load i1, ptr %l189, !tbaa !21
  br i1 %t327, label %bb89, label %bb90
bb89:
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t329 = load i32, ptr %l21, !tbaa !23
  %t332 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t328, i32 %t329)
  store i1 %t332, ptr %l196
  br label %bb91
bb90:
  store i1 false, ptr %l193, !tbaa !21
  br label %bb92
bb91:
  %t333 = load i1, ptr %l196, !tbaa !21
  store i1 %t333, ptr %l193, !tbaa !21
  br label %bb92
bb92:
  %t334 = load i1, ptr %l193, !tbaa !21
  br i1 %t334, label %bb93, label %bb94
bb93:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t336 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t336, ptr %l198, !tbaa !27
  %t337 = getelementptr { i64, ptr }, ptr %l198, i32 0, i32 1
  %t338 = load ptr, ptr %t337, !tbaa !27
  %t339 = getelementptr ptr, ptr %t338, i64 0
  %t340 = load ptr, ptr %t339, !tbaa !39
  %t342 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t335, ptr %t340, ptr %t342)
  br label %bb95
bb94:
  br label %bb96
bb95:
  br label %bb96
bb96:
  br label %bb198
bb97:
  %t346 = load ptr, ptr %l1, !tbaa !29
  store ptr %t346, ptr %l202, !tbaa !29
  store i1 false, ptr %l203, !tbaa !21
  %t347 = load ptr, ptr %l202, !tbaa !29
  %t348 = icmp ne ptr %t347, null
  br i1 %t348, label %bb98, label %bb99
bb98:
  %t350 = load ptr, ptr %l202, !tbaa !29
  %t351 = load i64, ptr %t350, !range !{i64 0, i64 18}
  %t353 = icmp eq i64 %t351, 11
  store i1 %t353, ptr %l203, !tbaa !21
  br label %bb99
bb99:
  %t354 = load i1, ptr %l203, !tbaa !21
  br i1 %t354, label %bb100, label %bb101
bb100:
  %t355 = load ptr, ptr %l1, !tbaa !29
  %t357 = getelementptr { i64, [5 x i64] }, ptr %t355, i32 0, i32 1
  %t358 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t357, i32 0, i32 2
  %t359 = load ptr, ptr %t358
  store ptr %t359, ptr %l24, !tbaa !29
  br label %bb102
bb101:
  br label %bb105
bb102:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t362 = load ptr, ptr %l24, !tbaa !29
  %t364 = getelementptr %"compiler/typed:Cond", ptr %t362, i32 0, i32 1
  %t365 = load ptr, ptr %t364, !tbaa !29
  %t366 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t361, ptr %t365, ptr %t366)
  br label %bb103
bb103:
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t371 = load ptr, ptr %l24, !tbaa !29
  %t373 = getelementptr %"compiler/typed:Cond", ptr %t371, i32 0, i32 2
  %t374 = load ptr, ptr %t373, !tbaa !29
  %t376 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t370, ptr %t374, ptr %t376)
  br label %bb104
bb104:
  br label %bb198
bb105:
  %t380 = load ptr, ptr %l1, !tbaa !29
  store ptr %t380, ptr %l217, !tbaa !29
  store i1 false, ptr %l218, !tbaa !21
  %t381 = load ptr, ptr %l217, !tbaa !29
  %t382 = icmp ne ptr %t381, null
  br i1 %t382, label %bb106, label %bb107
bb106:
  %t384 = load ptr, ptr %l217, !tbaa !29
  %t385 = load i64, ptr %t384, !range !{i64 0, i64 18}
  %t387 = icmp eq i64 %t385, 12
  store i1 %t387, ptr %l218, !tbaa !21
  br label %bb107
bb107:
  %t388 = load i1, ptr %l218, !tbaa !21
  br i1 %t388, label %bb108, label %bb109
bb108:
  %t389 = load ptr, ptr %l1, !tbaa !29
  %t391 = getelementptr { i64, [5 x i64] }, ptr %t389, i32 0, i32 1
  %t392 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t391, i32 0, i32 2
  %t393 = load ptr, ptr %t392
  store ptr %t393, ptr %l25, !tbaa !29
  br label %bb110
bb109:
  br label %bb112
bb110:
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t396 = load ptr, ptr %l25, !tbaa !29
  %t398 = getelementptr %"compiler/typed:Seq", ptr %t396, i32 0, i32 1
  %t399 = load ptr, ptr %t398, !tbaa !29
  %t400 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t395, ptr %t399, ptr %t400)
  br label %bb111
bb111:
  br label %bb198
bb112:
  %t404 = load ptr, ptr %l1, !tbaa !29
  store ptr %t404, ptr %l227, !tbaa !29
  store i1 false, ptr %l228, !tbaa !21
  %t405 = load ptr, ptr %l227, !tbaa !29
  %t406 = icmp ne ptr %t405, null
  br i1 %t406, label %bb113, label %bb114
bb113:
  %t408 = load ptr, ptr %l227, !tbaa !29
  %t409 = load i64, ptr %t408, !range !{i64 0, i64 18}
  %t411 = icmp eq i64 %t409, 13
  store i1 %t411, ptr %l228, !tbaa !21
  br label %bb114
bb114:
  %t412 = load i1, ptr %l228, !tbaa !21
  br i1 %t412, label %bb115, label %bb116
bb115:
  %t413 = load ptr, ptr %l1, !tbaa !29
  %t415 = getelementptr { i64, [5 x i64] }, ptr %t413, i32 0, i32 1
  %t416 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t415, i32 0, i32 2
  %t417 = load ptr, ptr %t416
  store ptr %t417, ptr %l26, !tbaa !29
  br label %bb117
bb116:
  br label %bb132
bb117:
  %t419 = load ptr, ptr %l26, !tbaa !29
  %t421 = getelementptr %"compiler/typed:Match", ptr %t419, i32 0, i32 1
  %t422 = load { i64, ptr }, ptr %t421, !tbaa !27
  store { i64, ptr } %t422, ptr %l27, !tbaa !27
  store i64 0, ptr %l28, !tbaa !24
  %t424 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t426 = extractvalue { i64, ptr } %t424, 0
  store i64 %t426, ptr %l29, !tbaa !24
  br label %bb118
bb118:
  %t428 = load i64, ptr %l28, !tbaa !24
  %t429 = load i64, ptr %l29, !tbaa !24
  %t432 = icmp slt i64 %t428, %t429
  %t434 = xor i1 %t432, true
  br i1 %t434, label %bb119, label %bb120
bb119:
  br label %bb124
bb120:
  br label %bb121
bb121:
  %t436 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t436, ptr %l241, !tbaa !27
  %t437 = load i64, ptr %l28, !tbaa !24
  %t439 = getelementptr { i64, ptr }, ptr %l241, i32 0, i32 1
  %t440 = load ptr, ptr %t439, !tbaa !27
  %t441 = getelementptr ptr, ptr %t440, i64 %t437
  %t442 = load ptr, ptr %t441, !tbaa !39
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t447 = getelementptr %"compiler/typed:Arm", ptr %t442, i32 0, i32 4
  %t448 = load ptr, ptr %t447, !tbaa !29
  %t449 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t444, ptr %t448, ptr %t449)
  br label %bb122
bb122:
  br label %bb123
bb123:
  %t453 = load i64, ptr %l28, !tbaa !24
  %t455 = add i64 %t453, 1
  store i64 %t455, ptr %l28, !tbaa !24
  br label %bb118
bb124:
  %t457 = load ptr, ptr %l26, !tbaa !29
  %t459 = getelementptr %"compiler/typed:Match", ptr %t457, i32 0, i32 2
  %t460 = load ptr, ptr %t459, !tbaa !29
  %t462 = icmp eq ptr %t460, null
  %t464 = xor i1 %t462, true
  br i1 %t464, label %bb125, label %bb126
bb125:
  %t466 = load ptr, ptr %l0, !tbaa !29
  store ptr %t466, ptr %l254, !tbaa !29
  %t467 = load ptr, ptr %l26, !tbaa !29
  %t469 = getelementptr %"compiler/typed:Match", ptr %t467, i32 0, i32 2
  %t470 = load ptr, ptr %t469, !tbaa !29
  %t472 = icmp eq ptr %t470, null
  br i1 %t472, label %bb127, label %bb128
bb126:
  br label %bb131
bb127:
  call void @__olang_check_failed(ptr @olang_loc_9675e93c9f07526d_8a86ee267fb7b3d9)
  unreachable
bb128:
  br label %bb129
bb129:
  %t474 = load ptr, ptr %l26, !tbaa !29
  %t476 = getelementptr %"compiler/typed:Match", ptr %t474, i32 0, i32 2
  %t477 = load ptr, ptr %t476, !tbaa !29
  %t480 = getelementptr %"compiler/typed:Arm", ptr %t477, i32 0, i32 4
  %t481 = load ptr, ptr %t480, !tbaa !29
  %t482 = load ptr, ptr %l2, !tbaa !29
  %t483 = load ptr, ptr %l254, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t483, ptr %t481, ptr %t482)
  br label %bb130
bb130:
  br label %bb131
bb131:
  br label %bb198
bb132:
  %t486 = load ptr, ptr %l1, !tbaa !29
  store ptr %t486, ptr %l263, !tbaa !29
  store i1 false, ptr %l264, !tbaa !21
  %t487 = load ptr, ptr %l263, !tbaa !29
  %t488 = icmp ne ptr %t487, null
  br i1 %t488, label %bb133, label %bb134
bb133:
  %t490 = load ptr, ptr %l263, !tbaa !29
  %t491 = load i64, ptr %t490, !range !{i64 0, i64 18}
  %t493 = icmp eq i64 %t491, 14
  store i1 %t493, ptr %l264, !tbaa !21
  br label %bb134
bb134:
  %t494 = load i1, ptr %l264, !tbaa !21
  br i1 %t494, label %bb135, label %bb136
bb135:
  %t495 = load ptr, ptr %l1, !tbaa !29
  %t497 = getelementptr { i64, [5 x i64] }, ptr %t495, i32 0, i32 1
  %t498 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t497, i32 0, i32 2
  %t499 = load ptr, ptr %t498
  store ptr %t499, ptr %l31, !tbaa !29
  br label %bb137
bb136:
  br label %bb152
bb137:
  %t501 = load ptr, ptr %l0, !tbaa !29
  %t502 = load ptr, ptr %l31, !tbaa !29
  %t504 = getelementptr %"compiler/typed:Try", ptr %t502, i32 0, i32 0
  %t505 = load ptr, ptr %t504, !tbaa !29
  %t506 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t501, ptr %t505, ptr %t506)
  br label %bb138
bb138:
  %t510 = load ptr, ptr %l31, !tbaa !29
  %t512 = getelementptr %"compiler/typed:Try", ptr %t510, i32 0, i32 1
  %t513 = load { i64, ptr }, ptr %t512, !tbaa !27
  store { i64, ptr } %t513, ptr %l32, !tbaa !27
  store i64 0, ptr %l33, !tbaa !24
  %t515 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t517 = extractvalue { i64, ptr } %t515, 0
  store i64 %t517, ptr %l34, !tbaa !24
  br label %bb139
bb139:
  %t519 = load i64, ptr %l33, !tbaa !24
  %t520 = load i64, ptr %l34, !tbaa !24
  %t523 = icmp slt i64 %t519, %t520
  %t525 = xor i1 %t523, true
  br i1 %t525, label %bb140, label %bb141
bb140:
  br label %bb151
bb141:
  br label %bb142
bb142:
  %t527 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t527, ptr %l281, !tbaa !27
  %t528 = load i64, ptr %l33, !tbaa !24
  %t530 = getelementptr { i64, ptr }, ptr %l281, i32 0, i32 1
  %t531 = load ptr, ptr %t530, !tbaa !27
  %t532 = getelementptr ptr, ptr %t531, i64 %t528
  %t533 = load ptr, ptr %t532, !tbaa !39
  %t537 = getelementptr %"compiler/typed:Clause", ptr %t533, i32 0, i32 4
  %t538 = load { i64, ptr }, ptr %t537, !tbaa !27
  store { i64, ptr } %t538, ptr %l36, !tbaa !27
  store i64 0, ptr %l37, !tbaa !24
  %t540 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t542 = extractvalue { i64, ptr } %t540, 0
  store i64 %t542, ptr %l38, !tbaa !24
  br label %bb143
bb143:
  %t544 = load i64, ptr %l37, !tbaa !24
  %t545 = load i64, ptr %l38, !tbaa !24
  %t548 = icmp slt i64 %t544, %t545
  %t550 = xor i1 %t548, true
  br i1 %t550, label %bb144, label %bb145
bb144:
  br label %bb149
bb145:
  br label %bb146
bb146:
  %t552 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t552, ptr %l292, !tbaa !27
  %t553 = load i64, ptr %l37, !tbaa !24
  %t555 = getelementptr { i64, ptr }, ptr %l292, i32 0, i32 1
  %t556 = load ptr, ptr %t555, !tbaa !27
  %t557 = getelementptr ptr, ptr %t556, i64 %t553
  %t558 = load ptr, ptr %t557, !tbaa !39
  %t560 = load ptr, ptr %l0, !tbaa !29
  %t563 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t560, ptr %t558, ptr %t563)
  br label %bb147
bb147:
  br label %bb148
bb148:
  %t567 = load i64, ptr %l37, !tbaa !24
  %t569 = add i64 %t567, 1
  store i64 %t569, ptr %l37, !tbaa !24
  br label %bb143
bb149:
  br label %bb150
bb150:
  %t571 = load i64, ptr %l33, !tbaa !24
  %t573 = add i64 %t571, 1
  store i64 %t573, ptr %l33, !tbaa !24
  br label %bb139
bb151:
  br label %bb198
bb152:
  %t575 = load ptr, ptr %l1, !tbaa !29
  store ptr %t575, ptr %l303, !tbaa !29
  store i1 false, ptr %l304, !tbaa !21
  %t576 = load ptr, ptr %l303, !tbaa !29
  %t577 = icmp ne ptr %t576, null
  br i1 %t577, label %bb153, label %bb154
bb153:
  %t579 = load ptr, ptr %l303, !tbaa !29
  %t580 = load i64, ptr %t579, !range !{i64 0, i64 18}
  %t582 = icmp eq i64 %t580, 17
  store i1 %t582, ptr %l304, !tbaa !21
  br label %bb154
bb154:
  %t583 = load i1, ptr %l304, !tbaa !21
  br i1 %t583, label %bb155, label %bb156
bb155:
  %t584 = load ptr, ptr %l1, !tbaa !29
  %t586 = getelementptr { i64, [5 x i64] }, ptr %t584, i32 0, i32 1
  %t587 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t586, i32 0, i32 2
  %t588 = load ptr, ptr %t587
  store ptr %t588, ptr %l40, !tbaa !29
  br label %bb157
bb156:
  br label %bb159
bb157:
  %t590 = load ptr, ptr %l0, !tbaa !29
  %t591 = load ptr, ptr %l40, !tbaa !29
  %t593 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t590, ptr %t591, ptr %t593)
  br label %bb158
bb158:
  br label %bb198
bb159:
  %t597 = load ptr, ptr %l1, !tbaa !29
  store ptr %t597, ptr %l313, !tbaa !29
  store i1 false, ptr %l314, !tbaa !21
  %t598 = load ptr, ptr %l313, !tbaa !29
  %t599 = icmp ne ptr %t598, null
  br i1 %t599, label %bb160, label %bb161
bb160:
  %t601 = load ptr, ptr %l313, !tbaa !29
  %t602 = load i64, ptr %t601, !range !{i64 0, i64 18}
  %t604 = icmp eq i64 %t602, 15
  store i1 %t604, ptr %l314, !tbaa !21
  br label %bb161
bb161:
  %t605 = load i1, ptr %l314, !tbaa !21
  br i1 %t605, label %bb162, label %bb163
bb162:
  %t606 = load ptr, ptr %l1, !tbaa !29
  %t608 = getelementptr { i64, [5 x i64] }, ptr %t606, i32 0, i32 1
  %t609 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t608, i32 0, i32 2
  %t610 = load ptr, ptr %t609
  store ptr %t610, ptr %l41, !tbaa !29
  br label %bb164
bb163:
  br label %bb193
bb164:
  %t612 = load ptr, ptr %l41, !tbaa !29
  store ptr %t612, ptr %l319, !tbaa !29
  store i1 false, ptr %l320, !tbaa !21
  %t613 = load ptr, ptr %l319, !tbaa !29
  %t614 = icmp ne ptr %t613, null
  br i1 %t614, label %bb165, label %bb166
bb165:
  %t616 = load ptr, ptr %l319, !tbaa !29
  %t617 = load i64, ptr %t616, !range !{i64 0, i64 3}
  %t619 = icmp eq i64 %t617, 1
  store i1 %t619, ptr %l320, !tbaa !21
  br label %bb166
bb166:
  %t620 = load i1, ptr %l320, !tbaa !21
  br i1 %t620, label %bb167, label %bb168
bb167:
  %t621 = load ptr, ptr %l41, !tbaa !29
  %t623 = getelementptr { i64, [4 x i64] }, ptr %t621, i32 0, i32 1
  %t624 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t623, i32 0, i32 1
  %t625 = load { i64, ptr }, ptr %t624
  store { i64, ptr } %t625, ptr %l42, !tbaa !27
  br label %bb169
bb168:
  br label %bb180
bb169:
  %t627 = load ptr, ptr %l0, !tbaa !29
  %t629 = getelementptr %"compiler/scope:Scoper", ptr %t627, i32 0, i32 118
  %t630 = load i1, ptr %t629, !tbaa !21
  %t632 = xor i1 %t630, true
  br i1 %t632, label %bb170, label %bb171
bb170:
  br label %ret
bb171:
  br label %bb172
bb172:
  %t634 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t634, ptr %l43, !tbaa !27
  store i64 0, ptr %l44, !tbaa !24
  %t636 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t638 = extractvalue { i64, ptr } %t636, 0
  store i64 %t638, ptr %l45, !tbaa !24
  br label %bb173
bb173:
  %t640 = load i64, ptr %l44, !tbaa !24
  %t641 = load i64, ptr %l45, !tbaa !24
  %t644 = icmp slt i64 %t640, %t641
  %t646 = xor i1 %t644, true
  br i1 %t646, label %bb174, label %bb175
bb174:
  br label %bb179
bb175:
  br label %bb176
bb176:
  %t648 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t648, ptr %l335, !tbaa !27
  %t649 = load i64, ptr %l44, !tbaa !24
  %t651 = getelementptr { i64, ptr }, ptr %l335, i32 0, i32 1
  %t652 = load ptr, ptr %t651, !tbaa !27
  %t653 = getelementptr ptr, ptr %t652, i64 %t649
  %t654 = load ptr, ptr %t653, !tbaa !39
  %t656 = load ptr, ptr %l0, !tbaa !29
  %t659 = getelementptr %"compiler/typed:Capture", ptr %t654, i32 0, i32 1
  %t660 = load ptr, ptr %t659, !tbaa !29
  %t662 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t656, ptr %t660, ptr %t662)
  br label %bb177
bb177:
  br label %bb178
bb178:
  %t666 = load i64, ptr %l44, !tbaa !24
  %t668 = add i64 %t666, 1
  store i64 %t668, ptr %l44, !tbaa !24
  br label %bb173
bb179:
  br label %bb192
bb180:
  %t670 = load ptr, ptr %l41, !tbaa !29
  store ptr %t670, ptr %l345, !tbaa !29
  store i1 false, ptr %l346, !tbaa !21
  %t671 = load ptr, ptr %l345, !tbaa !29
  %t672 = icmp ne ptr %t671, null
  br i1 %t672, label %bb181, label %bb182
bb181:
  %t674 = load ptr, ptr %l345, !tbaa !29
  %t675 = load i64, ptr %t674, !range !{i64 0, i64 3}
  %t677 = icmp eq i64 %t675, 2
  store i1 %t677, ptr %l346, !tbaa !21
  br label %bb182
bb182:
  %t678 = load i1, ptr %l346, !tbaa !21
  br i1 %t678, label %bb183, label %bb184
bb183:
  %t679 = load ptr, ptr %l41, !tbaa !29
  %t681 = getelementptr { i64, [4 x i64] }, ptr %t679, i32 0, i32 1
  %t682 = getelementptr { i32, ptr, i32 }, ptr %t681, i32 0, i32 1
  %t683 = load ptr, ptr %t682
  store ptr %t683, ptr %l47, !tbaa !29
  br label %bb185
bb184:
  br label %bb187
bb185:
  %t685 = load ptr, ptr %l0, !tbaa !29
  %t686 = load ptr, ptr %l47, !tbaa !29
  %t688 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %t685, ptr %t686, ptr %t688)
  br label %bb186
bb186:
  br label %bb192
bb187:
  br i1 true, label %bb188, label %bb189
bb188:
  br label %bb190
bb189:
  br label %bb191
bb190:
  br label %bb192
bb191:
  call void @__olang_check_failed(ptr @olang_loc_768f72a2579754c5_d91cee094dc07e21)
  unreachable
bb192:
  br label %bb198
bb193:
  br i1 true, label %bb194, label %bb195
bb194:
  br label %bb196
bb195:
  br label %bb197
bb196:
  br label %bb198
bb197:
  call void @__olang_check_failed(ptr @olang_loc_15f791c29ca5960e_c2f6ea53b6b5628a)
  unreachable
bb198:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2echeckReuse(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, { i64, ptr } %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/typed:Plan"
  %l13 = alloca %"compiler/typed:Plan"
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"std/prelude/text:StringBuilder"
  %l23 = alloca i1
  %l34 = alloca i64
  %l37 = alloca i64
  %l45 = alloca i64
  %l48 = alloca i64
  %l69 = alloca ptr
  %l73 = alloca ptr
  %l74 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca { i64, ptr }
  %l79 = alloca i64
  %l83 = alloca ptr
  %l87 = alloca ptr
  %l88 = alloca { i64, ptr }
  %l94 = alloca %"compiler/typed:Plan"
  %l96 = alloca %"compiler/typed:Plan"
  %l100 = alloca %"compiler/typed:Plan"
  %l102 = alloca %"compiler/typed:Plan"
  %l103 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l107 = alloca i1
  %l108 = alloca i1
  %l109 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l113 = alloca i1
  %l114 = alloca i1
  %l115 = alloca { i64, ptr }
  %l117 = alloca { i64, ptr }
  %l119 = alloca i1
  %l120 = alloca i1
  %l121 = alloca { i64, ptr }
  %l123 = alloca { i64, ptr }
  %l125 = alloca i1
  %l126 = alloca i1
  %l127 = alloca { i64, ptr }
  %l129 = alloca { i64, ptr }
  %l131 = alloca i1
  %l132 = alloca i1
  %l133 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l137 = alloca i1
  %l138 = alloca i1
  %l139 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l143 = alloca i1
  %l144 = alloca i1
  %l145 = alloca { i64, ptr }
  %l147 = alloca { i64, ptr }
  %l149 = alloca i1
  %l150 = alloca i1
  %l151 = alloca { i64, ptr }
  %l153 = alloca { i64, ptr }
  %l155 = alloca i1
  %l156 = alloca i1
  %l159 = alloca i1
  %l162 = alloca { i64, ptr }
  %l170 = alloca i64
  %l175 = alloca ptr
  %l180 = alloca i64
  %l183 = alloca i64
  %l186 = alloca ptr
  %l189 = alloca i64
  %l192 = alloca i64
  %l195 = alloca ptr
  %l198 = alloca i64
  %l201 = alloca i64
  %l203 = alloca ptr
  %l215 = alloca { i64, ptr }
  %l218 = alloca ptr
  %l219 = alloca i64
  %l223 = alloca ptr
  %l225 = alloca i64
  %l229 = alloca ptr
  %l231 = alloca i32
  %l235 = alloca ptr
  %l237 = alloca { i64, [2 x i64] }
  %l239 = alloca { i64, ptr }
  %l243 = alloca i64
  %l245 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.builder
  %s14room = alloca [64 x i8], align 8
  %t170 = alloca %"compiler/typed:Plan", align 8
  %t173 = alloca %"compiler/typed:Plan", align 8
  %t179 = alloca %"compiler/typed:Plan", align 8
  %t182 = alloca %"compiler/typed:Plan", align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l18
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l18
  store %"std/prelude/text:StringBuilder" %t2, ptr %l5
  %t3 = load ptr, ptr %l4, !tbaa !29
  %t5 = getelementptr %"compiler/scope:compRun", ptr %t3, i32 0, i32 3
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t8 = getelementptr %"compiler/scope:compRun", ptr %t6, i32 0, i32 3
  %t11 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aTaken_2eSame(ptr %v3, ptr %v2, ptr %t5, ptr %t8)
  store i1 %t11, ptr %l23
  br label %bb2
bb2:
  %t12 = load i1, ptr %l23, !tbaa !21
  %t13 = xor i1 %t12, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %l5, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d8, i32 0, i32 1) })
  br label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb6
bb6:
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t18 = getelementptr %"compiler/scope:compRun", ptr %t16, i32 0, i32 8
  %t19 = load i64, ptr %t18, !tbaa !24
  %t20 = load ptr, ptr %l3, !tbaa !29
  %t22 = getelementptr %"compiler/scope:compRun", ptr %t20, i32 0, i32 8
  %t23 = load i64, ptr %t22, !tbaa !24
  %t26 = icmp ne i64 %t19, %t23
  br i1 %t26, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l5, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d9, i32 0, i32 1) })
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t29 = load ptr, ptr %l4, !tbaa !29
  %t31 = getelementptr %"compiler/scope:compRun", ptr %t29, i32 0, i32 4
  %t33 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnUse_3e_2eLen_3ccompiler_2fscope_3afnUse_3e(ptr %v3, ptr %t31)
  store i64 %t33, ptr %l34
  br label %bb11
bb11:
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t36 = getelementptr %"compiler/scope:compRun", ptr %t34, i32 0, i32 4
  %t38 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnUse_3e_2eLen_3ccompiler_2fscope_3afnUse_3e(ptr %v2, ptr %t36)
  store i64 %t38, ptr %l37
  br label %bb12
bb12:
  %t39 = load i64, ptr %l34, !tbaa !24
  %t40 = load i64, ptr %l37, !tbaa !24
  %t41 = icmp ne i64 %t39, %t40
  br i1 %t41, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l5, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d10, i32 0, i32 1) })
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  store i64 0, ptr %l6, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  store i64 %t46, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t48 = load i64, ptr %l7, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = icmp sgt i64 %t48, %t49
  br i1 %t52, label %bb17, label %bb18
bb17:
  %t54 = load i64, ptr %l8, !tbaa !24
  %t56 = icmp sgt i64 %t54, 0
  br i1 %t56, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb22
bb19:
  %t58 = load i64, ptr %l7, !tbaa !24
  %t59 = load i64, ptr %l6, !tbaa !24
  %t62 = sub i64 %t58, %t59
  %t63 = load i64, ptr %l8, !tbaa !24
  %t66 = add i64 %t62, %t63
  %t68 = sub i64 %t66, 1
  %t69 = load i64, ptr %l8, !tbaa !24
  %t72 = sdiv i64 %t68, %t69
  store i64 %t72, ptr %l48, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l48, !tbaa !24
  br label %bb21
bb21:
  %t74 = load i64, ptr %l48, !tbaa !24
  store i64 %t74, ptr %l45, !tbaa !24
  br label %bb22
bb22:
  %t75 = load i64, ptr %l45, !tbaa !24
  store i64 %t75, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  %t76 = load i64, ptr %l10, !tbaa !24
  %t77 = load i64, ptr %l9, !tbaa !24
  %t80 = icmp slt i64 %t76, %t77
  %t82 = xor i1 %t80, true
  br i1 %t82, label %bb24, label %bb25
bb24:
  br label %bb83
bb25:
  br label %bb26
bb26:
  %t84 = load i64, ptr %l6, !tbaa !24
  %t85 = load i64, ptr %l10, !tbaa !24
  %t86 = load i64, ptr %l8, !tbaa !24
  %t89 = mul i64 %t85, %t86
  %t92 = add i64 %t84, %t89
  store i64 %t92, ptr %l11, !tbaa !24
  %t94 = load ptr, ptr %l4, !tbaa !29
  %t96 = getelementptr %"compiler/scope:compRun", ptr %t94, i32 0, i32 1
  %t97 = load i64, ptr %l11, !tbaa !24
  %t100 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v3, ptr %v3, ptr %t96, i64 %t97)
  store ptr %t100, ptr %l69
  br label %bb27
bb27:
  %t101 = load ptr, ptr %l3, !tbaa !29
  %t103 = getelementptr %"compiler/scope:compRun", ptr %t101, i32 0, i32 1
  %t104 = load i64, ptr %l11, !tbaa !24
  %t107 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v2, ptr %v2, ptr %t103, i64 %t104)
  store ptr %t107, ptr %l73
  br label %bb28
bb28:
  %t108 = load ptr, ptr %l69, !tbaa !29
  %t109 = load ptr, ptr %l73, !tbaa !29
  %t110 = call i1 @compiler_2fscope_2esameSummary(ptr %v3, ptr %v2, ptr %t108, ptr %t109)
  store i1 %t110, ptr %l74
  br label %bb29
bb29:
  %t111 = load i1, ptr %l74, !tbaa !21
  %t112 = xor i1 %t111, true
  br i1 %t112, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s6
  store ptr %l5, ptr %l76, !tbaa !29
  %t114 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t114, ptr %l77, !tbaa !27
  %t115 = load i64, ptr %l11, !tbaa !24
  %t117 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = getelementptr i64, ptr %t118, i64 %t115
  %t120 = load i64, ptr %t119, !tbaa !34
  store i64 %t120, ptr %l79, !tbaa !24
  %t121 = load ptr, ptr %l4, !tbaa !29
  %t123 = getelementptr %"compiler/scope:compRun", ptr %t121, i32 0, i32 1
  %t124 = load i64, ptr %l11, !tbaa !24
  %t127 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v3, ptr %v3, ptr %t123, i64 %t124)
  store ptr %t127, ptr %l83
  br label %bb32
bb31:
  br label %bb36
bb32:
  %t128 = load ptr, ptr %l3, !tbaa !29
  %t130 = getelementptr %"compiler/scope:compRun", ptr %t128, i32 0, i32 1
  %t131 = load i64, ptr %l11, !tbaa !24
  %t134 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v2, ptr %v2, ptr %t130, i64 %t131)
  store ptr %t134, ptr %l87
  br label %bb33
bb33:
  %t135 = load ptr, ptr %l83, !tbaa !29
  %t136 = load ptr, ptr %l87, !tbaa !29
  %t137 = call { i64, ptr } @compiler_2fscope_2esummaryDiff(ptr %v3, ptr %v2, ptr %s6, ptr %t135, ptr %t136)
  store { i64, ptr } %t137, ptr %l88
  br label %bb34
bb34:
  %t138 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t139 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t140 = load i64, ptr %l79, !tbaa !24
  %t141 = call i64 @__olang_fmt_i64(ptr null, i64 %t140)
  %t142 = add i64 %t139, %t141
  %t143 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t144 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t145 = add i64 %t142, %t144
  %t146 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t146, 1
  %t148 = extractvalue { i64, ptr } %t146, 0
  %t149 = add i64 %t145, %t148
  %t150 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t149)
  call void @olang_textcopy(ptr %t150, ptr %t138, i64 %t139)
  %t151 = getelementptr i8, ptr %t150, i64 %t139
  %t152 = call i64 @__olang_fmt_i64(ptr %t151, i64 %t140)
  %t153 = getelementptr i8, ptr %t151, i64 %t141
  call void @olang_textcopy(ptr %t153, ptr %t143, i64 %t144)
  %t154 = getelementptr i8, ptr %t153, i64 %t144
  call void @olang_textcopy(ptr %t154, ptr %t147, i64 %t148)
  %t155 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t150, 1
  %t158 = extractvalue { i64, ptr } %t156, 0
  %t159 = extractvalue { i64, ptr } %t156, 1
  %t160 = mul i64 %t158, 1
  %t161 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t160)
  call void @llvm.memcpy.p0.p0.i64(ptr %t161, ptr %t159, i64 %t160, i1 false)
  %t162 = insertvalue { i64, ptr } undef, i64 %t158, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t161, 1
  %t164 = load ptr, ptr %l76, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %t164, { i64, ptr } %t163)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s6)
  br label %bb36
bb36:
  %t166 = load ptr, ptr %l4, !tbaa !29
  %t168 = getelementptr %"compiler/scope:compRun", ptr %t166, i32 0, i32 0
  %t169 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %t170, ptr %v3, ptr %v3, ptr %t168, i64 %t169)
  call void @llvm.memmove.p0.p0.i64(ptr %l94, ptr %t170, i64 176, i1 false)
  br label %bb37
bb37:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aPlan(ptr %t173, ptr %v3, ptr %l94)
  call void @llvm.memmove.p0.p0.i64(ptr %l96, ptr %t173, i64 176, i1 false)
  br label %bb38
bb38:
  call void @llvm.memmove.p0.p0.i64(ptr %l12, ptr %l96, i64 176, i1 false)
  %t175 = load ptr, ptr %l3, !tbaa !29
  %t177 = getelementptr %"compiler/scope:compRun", ptr %t175, i32 0, i32 0
  %t178 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %t179, ptr %v2, ptr %v2, ptr %t177, i64 %t178)
  call void @llvm.memmove.p0.p0.i64(ptr %l100, ptr %t179, i64 176, i1 false)
  br label %bb39
bb39:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aPlan(ptr %t182, ptr %v2, ptr %l100)
  call void @llvm.memmove.p0.p0.i64(ptr %l102, ptr %t182, i64 176, i1 false)
  br label %bb40
bb40:
  call void @llvm.memmove.p0.p0.i64(ptr %l13, ptr %l102, i64 176, i1 false)
  %t184 = getelementptr %"compiler/typed:Plan", ptr %l12, i32 0, i32 0
  %t185 = load { i64, ptr }, ptr %t184, !tbaa !27
  store { i64, ptr } %t185, ptr %l103, !tbaa !27
  %t186 = getelementptr %"compiler/typed:Plan", ptr %l13, i32 0, i32 0
  %t187 = load { i64, ptr }, ptr %t186, !tbaa !27
  store { i64, ptr } %t187, ptr %l105, !tbaa !27
  %t190 = call i1 @olang_2eHelperKind_2eEqual_2eArray_3ccompiler_2ftyped_3aScope_3e_26(ptr %l103, ptr %l105)
  store i1 %t190, ptr %l107
  br label %bb41
bb41:
  %t191 = load i1, ptr %l107, !tbaa !21
  br i1 %t191, label %bb42, label %bb43
bb42:
  %t192 = getelementptr %"compiler/typed:Plan", ptr %l12, i32 0, i32 1
  %t193 = load { i64, ptr }, ptr %t192, !tbaa !27
  store { i64, ptr } %t193, ptr %l109, !tbaa !27
  %t194 = getelementptr %"compiler/typed:Plan", ptr %l13, i32 0, i32 1
  %t195 = load { i64, ptr }, ptr %t194, !tbaa !27
  store { i64, ptr } %t195, ptr %l111, !tbaa !27
  %t198 = call i1 @olang_2eHelperKind_2eEqual_2eArray_3ccompiler_2ftyped_3aScope_3e_26(ptr %l109, ptr %l111)
  store i1 %t198, ptr %l113
  br label %bb44
bb43:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb45
bb44:
  %t199 = load i1, ptr %l113, !tbaa !21
  store i1 %t199, ptr %l108, !tbaa !21
  br label %bb45
bb45:
  %t200 = load i1, ptr %l108, !tbaa !21
  br i1 %t200, label %bb46, label %bb47
bb46:
  %t201 = getelementptr %"compiler/typed:Plan", ptr %l12, i32 0, i32 2
  %t202 = load { i64, ptr }, ptr %t201, !tbaa !27
  store { i64, ptr } %t202, ptr %l115, !tbaa !27
  %t203 = getelementptr %"compiler/typed:Plan", ptr %l13, i32 0, i32 2
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  store { i64, ptr } %t204, ptr %l117, !tbaa !27
  %t207 = call i1 @olang_2eHelperKind_2eEqual_2eArray_3cBool_3e_26(ptr %l115, ptr %l117)
  store i1 %t207, ptr %l119
  br label %bb48
bb47:
  store i1 false, ptr %l114, !tbaa !21
  br label %bb49
bb48:
  %t208 = load i1, ptr %l119, !tbaa !21
  store i1 %t208, ptr %l114, !tbaa !21
  br label %bb49
bb49:
  %t209 = load i1, ptr %l114, !tbaa !21
  br i1 %t209, label %bb50, label %bb51
bb50:
  %t210 = getelementptr %"compiler/typed:Plan", ptr %l12, i32 0, i32 3
  %t211 = load { i64, ptr }, ptr %t210, !tbaa !27
  store { i64, ptr } %t211, ptr %l121, !tbaa !27
  %t212 = getelementptr %"compiler/typed:Plan", ptr %l13, i32 0, i32 3
  %t213 = load { i64, ptr }, ptr %t212, !tbaa !27
  store { i64, ptr } %t213, ptr %l123, !tbaa !27
  %t216 = call i1 @olang_2eHelperKind_2eEqual_2eArray_3cBool_3e_26(ptr %l121, ptr %l123)
  store i1 %t216, ptr %l125
  br label %bb52
bb51:
  store i1 false, ptr %l120, !tbaa !21
  br label %bb53
bb52:
  %t217 = load i1, ptr %l125, !tbaa !21
  store i1 %t217, ptr %l120, !tbaa !21
  br label %bb53
bb53:
  %t218 = load i1, ptr %l120, !tbaa !21
  br i1 %t218, label %bb54, label %bb55
bb54:
  %t219 = getelementptr %"compiler/typed:Plan", ptr %l12, i32 0, i32 4
  %t220 = load { i64, ptr }, ptr %t219, !tbaa !27
  store { i64, ptr } %t220, ptr %l127, !tbaa !27
  %t221 = getelementptr %"compiler/typed:Plan", ptr %l13, i32 0, i32 4
  %t222 = load { i64, ptr }, ptr %t221, !tbaa !27
  store { i64, ptr } %t222, ptr %l129, !tbaa !27
  %t225 = call i1 @olang_2eHelperKind_2eEqual_2eArray_3cI64_3e_26(ptr %l127, ptr %l129)
  store i1 %t225, ptr %l131
  br label %bb56
bb55:
  store i1 false, ptr %l126, !tbaa !21
  br label %bb57
bb56:
  %t226 = load i1, ptr %l131, !tbaa !21
  store i1 %t226, ptr %l126, !tbaa !21
  br label %bb57
bb57:
  %t227 = load i1, ptr %l126, !tbaa !21
  br i1 %t227, label %bb58, label %bb59
bb58:
  %t228 = getelementptr %"compiler/typed:Plan", ptr %l12, i32 0, i32 5
  %t229 = load { i64, ptr }, ptr %t228, !tbaa !27
  store { i64, ptr } %t229, ptr %l133, !tbaa !27
  %t230 = getelementptr %"compiler/typed:Plan", ptr %l13, i32 0, i32 5
  %t231 = load { i64, ptr }, ptr %t230, !tbaa !27
  store { i64, ptr } %t231, ptr %l135, !tbaa !27
  %t234 = call i1 @olang_2eHelperKind_2eEqual_2eArray_3ccompiler_2ftyped_3aScope_3e_26(ptr %l133, ptr %l135)
  store i1 %t234, ptr %l137
  br label %bb60
bb59:
  store i1 false, ptr %l132, !tbaa !21
  br label %bb61
bb60:
  %t235 = load i1, ptr %l137, !tbaa !21
  store i1 %t235, ptr %l132, !tbaa !21
  br label %bb61
bb61:
  %t236 = load i1, ptr %l132, !tbaa !21
  br i1 %t236, label %bb62, label %bb63
bb62:
  %t237 = getelementptr %"compiler/typed:Plan", ptr %l12, i32 0, i32 6
  %t238 = load { i64, ptr }, ptr %t237, !tbaa !27
  store { i64, ptr } %t238, ptr %l139, !tbaa !27
  %t239 = getelementptr %"compiler/typed:Plan", ptr %l13, i32 0, i32 6
  %t240 = load { i64, ptr }, ptr %t239, !tbaa !27
  store { i64, ptr } %t240, ptr %l141, !tbaa !27
  %t243 = call i1 @olang_2eHelperKind_2eEqual_2eArray_3ccompiler_2ftyped_3aExpr_3f_26_3e_26(ptr %l139, ptr %l141)
  store i1 %t243, ptr %l143
  br label %bb64
bb63:
  store i1 false, ptr %l138, !tbaa !21
  br label %bb65
bb64:
  %t244 = load i1, ptr %l143, !tbaa !21
  store i1 %t244, ptr %l138, !tbaa !21
  br label %bb65
bb65:
  %t245 = load i1, ptr %l138, !tbaa !21
  br i1 %t245, label %bb66, label %bb67
bb66:
  %t246 = getelementptr %"compiler/typed:Plan", ptr %l12, i32 0, i32 7
  %t247 = load { i64, ptr }, ptr %t246, !tbaa !27
  store { i64, ptr } %t247, ptr %l145, !tbaa !27
  %t248 = getelementptr %"compiler/typed:Plan", ptr %l13, i32 0, i32 7
  %t249 = load { i64, ptr }, ptr %t248, !tbaa !27
  store { i64, ptr } %t249, ptr %l147, !tbaa !27
  %t252 = call i1 @olang_2eHelperKind_2eEqual_2eArray_3cI64_3e_26(ptr %l145, ptr %l147)
  store i1 %t252, ptr %l149
  br label %bb68
bb67:
  store i1 false, ptr %l144, !tbaa !21
  br label %bb69
bb68:
  %t253 = load i1, ptr %l149, !tbaa !21
  store i1 %t253, ptr %l144, !tbaa !21
  br label %bb69
bb69:
  %t254 = load i1, ptr %l144, !tbaa !21
  br i1 %t254, label %bb70, label %bb71
bb70:
  %t255 = getelementptr %"compiler/typed:Plan", ptr %l12, i32 0, i32 8
  %t256 = load { i64, ptr }, ptr %t255, !tbaa !27
  store { i64, ptr } %t256, ptr %l151, !tbaa !27
  %t257 = getelementptr %"compiler/typed:Plan", ptr %l13, i32 0, i32 8
  %t258 = load { i64, ptr }, ptr %t257, !tbaa !27
  store { i64, ptr } %t258, ptr %l153, !tbaa !27
  %t261 = call i1 @olang_2eHelperKind_2eEqual_2eArray_3cI64_3e_26(ptr %l151, ptr %l153)
  store i1 %t261, ptr %l155
  br label %bb72
bb71:
  store i1 false, ptr %l150, !tbaa !21
  br label %bb73
bb72:
  %t262 = load i1, ptr %l155, !tbaa !21
  store i1 %t262, ptr %l150, !tbaa !21
  br label %bb73
bb73:
  %t263 = load i1, ptr %l150, !tbaa !21
  br i1 %t263, label %bb74, label %bb75
bb74:
  %t264 = getelementptr %"compiler/typed:Plan", ptr %l12, i32 0, i32 9
  %t265 = getelementptr %"compiler/typed:Plan", ptr %l13, i32 0, i32 9
  %t268 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2eEq_3ccompiler_2ftyped_3aScope_3e(ptr %v3, ptr %v2, ptr %t264, ptr %t265)
  store i1 %t268, ptr %l159
  br label %bb76
bb75:
  store i1 false, ptr %l156, !tbaa !21
  br label %bb77
bb76:
  %t269 = load i1, ptr %l159, !tbaa !21
  store i1 %t269, ptr %l156, !tbaa !21
  br label %bb77
bb77:
  %t270 = load i1, ptr %l156, !tbaa !21
  %t271 = xor i1 %t270, true
  br i1 %t271, label %bb78, label %bb79
bb78:
  store %olang.scope zeroinitializer, ptr %s8
  %t273 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t273, ptr %l162, !tbaa !27
  %t274 = load i64, ptr %l11, !tbaa !24
  %t276 = getelementptr { i64, ptr }, ptr %l162, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !27
  %t278 = getelementptr i64, ptr %t277, i64 %t274
  %t279 = load i64, ptr %t278, !tbaa !34
  %t280 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t281 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t283 = call i64 @__olang_fmt_i64(ptr null, i64 %t279)
  %t284 = add i64 %t281, %t283
  %t285 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t284)
  call void @olang_textcopy(ptr %t285, ptr %t280, i64 %t281)
  %t286 = getelementptr i8, ptr %t285, i64 %t281
  %t287 = call i64 @__olang_fmt_i64(ptr %t286, i64 %t279)
  %t288 = insertvalue { i64, ptr } undef, i64 %t284, 0
  %t289 = insertvalue { i64, ptr } %t288, ptr %t285, 1
  %t291 = extractvalue { i64, ptr } %t289, 0
  %t292 = extractvalue { i64, ptr } %t289, 1
  %t293 = mul i64 %t291, 1
  %t294 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t293)
  call void @llvm.memcpy.p0.p0.i64(ptr %t294, ptr %t292, i64 %t293, i1 false)
  %t295 = insertvalue { i64, ptr } undef, i64 %t291, 0
  %t296 = insertvalue { i64, ptr } %t295, ptr %t294, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s8, ptr %l5, { i64, ptr } %t296)
  br label %bb80
bb79:
  br label %bb81
bb80:
  call void @__olang_scope_close(ptr %s8)
  br label %bb81
bb81:
  br label %bb82
bb82:
  %t299 = load i64, ptr %l10, !tbaa !24
  %t301 = add i64 %t299, 1
  store i64 %t301, ptr %l10, !tbaa !24
  br label %bb23
bb83:
  %t304 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l5)
  store i64 %t304, ptr %l170
  br label %bb84
bb84:
  %t305 = load i64, ptr %l170, !tbaa !24
  %t306 = icmp eq i64 %t305, 0
  br i1 %t306, label %bb85, label %bb86
bb85:
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t310 = getelementptr %"compiler/scope:Scoper", ptr %t308, i32 0, i32 0
  %t311 = load ptr, ptr %t310, !tbaa !29
  %t313 = getelementptr %"compiler/generic:Program", ptr %t311, i32 0, i32 0
  %t314 = load ptr, ptr %t313, !tbaa !29
  %t316 = getelementptr %"compiler/load:Loader", ptr %t314, i32 0, i32 4
  %t317 = load ptr, ptr %t316, !tbaa !29
  store ptr %t317, ptr %l175, !tbaa !29
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t320 = getelementptr %"compiler/scope:Scoper", ptr %t318, i32 0, i32 0
  %t321 = load ptr, ptr %t320, !tbaa !29
  %t323 = getelementptr %"compiler/generic:Program", ptr %t321, i32 0, i32 0
  %t324 = load ptr, ptr %t323, !tbaa !29
  %t326 = getelementptr %"compiler/load:Loader", ptr %t324, i32 0, i32 4
  %t327 = load ptr, ptr %t326, !tbaa !29
  %t329 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t327)
  store i64 %t329, ptr %l180
  br label %bb87
bb86:
  br label %bb96
bb87:
  %t330 = load ptr, ptr %l4, !tbaa !29
  %t332 = getelementptr %"compiler/scope:compRun", ptr %t330, i32 0, i32 3
  %t334 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aTaken_2eCount(ptr %v3, ptr %t332)
  store i64 %t334, ptr %l183
  br label %bb88
bb88:
  %t335 = load i64, ptr %l180, !tbaa !24
  %t336 = load i64, ptr %l183, !tbaa !24
  %t337 = sub i64 %t335, %t336
  %t338 = load ptr, ptr %l175, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eForget(ptr %v0, ptr %t338, i64 %t337)
  br label %bb89
bb89:
  %t340 = load ptr, ptr %l0, !tbaa !29
  %t342 = getelementptr %"compiler/scope:Scoper", ptr %t340, i32 0, i32 83
  store ptr %t342, ptr %l186, !tbaa !29
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t345 = getelementptr %"compiler/scope:Scoper", ptr %t343, i32 0, i32 83
  %t347 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnUse_3e_2eLen_3ccompiler_2fscope_3afnUse_3e(ptr %v0, ptr %t345)
  store i64 %t347, ptr %l189
  br label %bb90
bb90:
  %t348 = load ptr, ptr %l4, !tbaa !29
  %t350 = getelementptr %"compiler/scope:compRun", ptr %t348, i32 0, i32 4
  %t352 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnUse_3e_2eLen_3ccompiler_2fscope_3afnUse_3e(ptr %v3, ptr %t350)
  store i64 %t352, ptr %l192
  br label %bb91
bb91:
  %t353 = load i64, ptr %l189, !tbaa !24
  %t354 = load i64, ptr %l192, !tbaa !24
  %t355 = sub i64 %t353, %t354
  %t356 = load ptr, ptr %l186, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnUse_3e_2eTruncate_3ccompiler_2fscope_3afnUse_3e(ptr %v0, ptr %t356, i64 %t355)
  br label %bb92
bb92:
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t360 = getelementptr %"compiler/scope:Scoper", ptr %t358, i32 0, i32 3
  store ptr %t360, ptr %l195, !tbaa !29
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t363 = getelementptr %"compiler/scope:Scoper", ptr %t361, i32 0, i32 3
  %t365 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aGap_3e_2eLen_3ccompiler_2fscope_3aGap_3e(ptr %v0, ptr %t363)
  store i64 %t365, ptr %l198
  br label %bb93
bb93:
  %t366 = load ptr, ptr %l4, !tbaa !29
  %t368 = getelementptr %"compiler/scope:compRun", ptr %t366, i32 0, i32 5
  %t370 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aGap_3e_2eLen_3ccompiler_2fscope_3aGap_3e(ptr %v3, ptr %t368)
  store i64 %t370, ptr %l201
  br label %bb94
bb94:
  %t371 = load i64, ptr %l198, !tbaa !24
  %t372 = load i64, ptr %l201, !tbaa !24
  %t373 = sub i64 %t371, %t372
  %t374 = load ptr, ptr %l195, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aGap_3e_2eTruncate_3ccompiler_2fscope_3aGap_3e(ptr %v0, ptr %t374, i64 %t373)
  br label %bb95
bb95:
  %t376 = load ptr, ptr %l0, !tbaa !29
  store ptr %t376, ptr %l203, !tbaa !29
  %t377 = load ptr, ptr %l203, !tbaa !29
  %t378 = getelementptr %"compiler/scope:Scoper", ptr %t377, i32 0, i32 138
  %t379 = load i64, ptr %t378, !tbaa !24
  %t380 = load ptr, ptr %l4, !tbaa !29
  %t382 = getelementptr %"compiler/scope:compRun", ptr %t380, i32 0, i32 8
  %t383 = load i64, ptr %t382, !tbaa !24
  %t386 = sub i64 %t379, %t383
  %t388 = load ptr, ptr %l203, !tbaa !29
  %t389 = getelementptr %"compiler/scope:Scoper", ptr %t388, i32 0, i32 138
  store i64 %t386, ptr %t389, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb96:
  %t390 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t390, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t392 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t394 = extractvalue { i64, ptr } %t392, 0
  store i64 %t394, ptr %l16, !tbaa !24
  br label %bb97
bb97:
  store %olang.scope zeroinitializer, ptr %s13
  %t396 = load i64, ptr %l15, !tbaa !24
  %t397 = load i64, ptr %l16, !tbaa !24
  %t400 = icmp slt i64 %t396, %t397
  %t402 = xor i1 %t400, true
  br i1 %t402, label %bb98, label %bb99
bb98:
  call void @__olang_scope_close(ptr %s13)
  br label %bb107
bb99:
  br label %bb100
bb100:
  %t404 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t404, ptr %l215, !tbaa !27
  %t405 = load i64, ptr %l15, !tbaa !24
  %t407 = getelementptr { i64, ptr }, ptr %l215, i32 0, i32 1
  %t408 = load ptr, ptr %t407, !tbaa !27
  %t409 = getelementptr i64, ptr %t408, i64 %t405
  %t410 = load i64, ptr %t409, !tbaa !34
  store i64 %t410, ptr %l17, !tbaa !24
  store ptr %l5, ptr %l218, !tbaa !29
  %t412 = load i64, ptr %l17, !tbaa !24
  store i64 %t412, ptr %l219, !tbaa !24
  %t413 = load ptr, ptr %l0, !tbaa !29
  %t415 = getelementptr %"compiler/scope:Scoper", ptr %t413, i32 0, i32 1
  %t416 = load i64, ptr %l17, !tbaa !24
  %t419 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t415, i64 %t416)
  store ptr %t419, ptr %l223
  br label %bb101
bb101:
  %t420 = load ptr, ptr %l223, !tbaa !29
  %t422 = getelementptr %"compiler/typed:Body", ptr %t420, i32 0, i32 3
  %t423 = load i64, ptr %t422, !tbaa !24
  store i64 %t423, ptr %l225, !tbaa !24
  %t424 = load ptr, ptr %l0, !tbaa !29
  %t426 = getelementptr %"compiler/scope:Scoper", ptr %t424, i32 0, i32 1
  %t427 = load i64, ptr %l17, !tbaa !24
  %t430 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t426, i64 %t427)
  store ptr %t430, ptr %l229
  br label %bb102
bb102:
  %t431 = load ptr, ptr %l229, !tbaa !29
  %t433 = getelementptr %"compiler/typed:Body", ptr %t431, i32 0, i32 4
  %t434 = getelementptr %"compiler/source:Span", ptr %t433, i32 0, i32 0
  %t435 = load i32, ptr %t434, !tbaa !23
  store i32 %t435, ptr %l231, !tbaa !23
  %t436 = load ptr, ptr %l0, !tbaa !29
  %t438 = getelementptr %"compiler/scope:Scoper", ptr %t436, i32 0, i32 1
  %t439 = load i64, ptr %l17, !tbaa !24
  %t442 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t438, i64 %t439)
  store ptr %t442, ptr %l235
  br label %bb103
bb103:
  %t443 = load ptr, ptr %l235, !tbaa !29
  %t445 = getelementptr %"compiler/typed:Body", ptr %t443, i32 0, i32 1
  %t446 = load { i64, [2 x i64] }, ptr %t445
  store { i64, [2 x i64] } %t446, ptr %l237
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s14
  store ptr %s14room, ptr %s14
  %t447 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t448 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s14, ptr %t447, i64 %t448)
  %t449 = load i64, ptr %l219, !tbaa !24
  %t450 = call ptr @__olang_sb_room(ptr %s14, i64 24)
  %t451 = call i64 @__olang_fmt_i64(ptr %t450, i64 %t449)
  call void @__olang_sb_add(ptr %s14, i64 %t451)
  %t452 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t453 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s14, ptr %t452, i64 %t453)
  %t454 = load i64, ptr %l225, !tbaa !24
  %t455 = call ptr @__olang_sb_room(ptr %s14, i64 24)
  %t456 = call i64 @__olang_fmt_i64(ptr %t455, i64 %t454)
  call void @__olang_sb_add(ptr %s14, i64 %t456)
  %t457 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t458 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s14, ptr %t457, i64 %t458)
  %t459 = load i32, ptr %l231, !tbaa !23
  %t460 = sext i32 %t459 to i64
  %t461 = call ptr @__olang_sb_room(ptr %s14, i64 24)
  %t462 = call i64 @__olang_fmt_i64(ptr %t461, i64 %t460)
  call void @__olang_sb_add(ptr %s14, i64 %t462)
  %t463 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t464 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s14, ptr %t463, i64 %t464)
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aBodyOf(ptr %s14, ptr %l237, i64 0)
  br label %bb104
bb104:
  %t466 = load ptr, ptr %s14
  %t467 = getelementptr %olang.builder, ptr %s14, i32 0, i32 1
  %t468 = load i64, ptr %t467
  %t469 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t468)
  call void @olang_textcopy(ptr %t469, ptr %t466, i64 %t468)
  %t470 = insertvalue { i64, ptr } undef, i64 %t468, 0
  %t471 = insertvalue { i64, ptr } %t470, ptr %t469, 1
  store { i64, ptr } %t471, ptr %l239, !tbaa !27
  %t472 = getelementptr %olang.builder, ptr %s14, i32 0, i32 3
  %t473 = load ptr, ptr %t472
  %t474 = icmp ne ptr %t473, null
  br i1 %t474, label %sbgrew.475, label %sbdone.476
sbgrew.475:
  call void @__olang_sb_done(ptr %s14)
  br label %sbdone.476
sbdone.476:
  %t477 = load { i64, ptr }, ptr %l239, !tbaa !27
  %t478 = extractvalue { i64, ptr } %t477, 0
  %t479 = extractvalue { i64, ptr } %t477, 1
  %t480 = mul i64 %t478, 1
  %t481 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t480)
  call void @llvm.memcpy.p0.p0.i64(ptr %t481, ptr %t479, i64 %t480, i1 false)
  %t482 = insertvalue { i64, ptr } undef, i64 %t478, 0
  %t483 = insertvalue { i64, ptr } %t482, ptr %t481, 1
  %t484 = load ptr, ptr %l218, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s13, ptr %t484, { i64, ptr } %t483)
  br label %bb105
bb105:
  call void @__olang_scope_close(ptr %s13)
  br label %bb106
bb106:
  %t486 = load i64, ptr %l15, !tbaa !24
  %t488 = add i64 %t486, 1
  store i64 %t488, ptr %l15, !tbaa !24
  br label %bb97
bb107:
  br i1 false, label %bb108, label %bb109
bb108:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb109:
  store i64 %a1, ptr %l243, !tbaa !24
  %t492 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l5)
  store { i64, ptr } %t492, ptr %l245
  br label %bb110
bb110:
  %t493 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t494 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t495 = load i64, ptr %l243, !tbaa !24
  %t496 = call i64 @__olang_fmt_i64(ptr null, i64 %t495)
  %t497 = add i64 %t494, %t496
  %t498 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t499 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t500 = add i64 %t497, %t499
  %t501 = load { i64, ptr }, ptr %l245, !tbaa !27
  %t502 = extractvalue { i64, ptr } %t501, 1
  %t503 = extractvalue { i64, ptr } %t501, 0
  %t504 = add i64 %t500, %t503
  %t505 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t504)
  call void @olang_textcopy(ptr %t505, ptr %t493, i64 %t494)
  %t506 = getelementptr i8, ptr %t505, i64 %t494
  %t507 = call i64 @__olang_fmt_i64(ptr %t506, i64 %t495)
  %t508 = getelementptr i8, ptr %t506, i64 %t496
  call void @olang_textcopy(ptr %t508, ptr %t498, i64 %t499)
  %t509 = getelementptr i8, ptr %t508, i64 %t499
  call void @olang_textcopy(ptr %t509, ptr %t502, i64 %t503)
  %t510 = insertvalue { i64, ptr } undef, i64 %t504, 0
  %t511 = insertvalue { i64, ptr } %t510, ptr %t505, 1
  %t513 = extractvalue { i64, ptr } %t511, 0
  %t514 = extractvalue { i64, ptr } %t511, 1
  %t515 = mul i64 %t513, 1
  %t516 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t515)
  call void @llvm.memcpy.p0.p0.i64(ptr %t516, ptr %t514, i64 %t515, i1 false)
  %t517 = insertvalue { i64, ptr } undef, i64 %t513, 0
  %t518 = insertvalue { i64, ptr } %t517, ptr %t516, 1
  %t520 = extractvalue { i64, ptr } %t518, 1
  %t521 = extractvalue { i64, ptr } %t518, 0
  %t522 = insertvalue { i64, ptr } undef, i64 %t521, 0
  %t523 = insertvalue { i64, ptr } %t522, ptr %t520, 1
  call void @__olang_check_failed_text(ptr @olang_loc_6a87b3eb83e8e753_81a9677ce8feda27, { i64, ptr } %t523)
  unreachable
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2echoiceOfRefs(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l27 = alloca i1
  %l28 = alloca ptr
  %l34 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t6 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s0, ptr %t1, ptr %a1)
  store ptr %t6, ptr %l7
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l7, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  %t8 = load ptr, ptr %l2, !tbaa !29
  store ptr %t8, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t9 = load ptr, ptr %l9, !tbaa !29
  %t10 = icmp ne ptr %t9, null
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l9, !tbaa !29
  %t13 = load i64, ptr %t12, !range !{i64 0, i64 18}
  %t15 = icmp eq i64 %t13, 11
  store i1 %t15, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l10, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  br label %bb10
bb5:
  %t17 = load ptr, ptr %l2, !tbaa !29
  store ptr %t17, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t18 = load ptr, ptr %l13, !tbaa !29
  %t19 = icmp ne ptr %t18, null
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %l13, !tbaa !29
  %t22 = load i64, ptr %t21, !range !{i64 0, i64 18}
  %t24 = icmp eq i64 %t22, 13
  store i1 %t24, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t25 = load i1, ptr %l14, !tbaa !21
  br i1 %t25, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb29
bb11:
  %t26 = load ptr, ptr %l2, !tbaa !29
  store ptr %t26, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t27 = load ptr, ptr %l17, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb12, label %bb13
bb12:
  %t30 = load ptr, ptr %l17, !tbaa !29
  %t31 = load i64, ptr %t30, !range !{i64 0, i64 18}
  %t33 = icmp eq i64 %t31, 12
  store i1 %t33, ptr %l18, !tbaa !21
  br label %bb13
bb13:
  %t34 = load i1, ptr %l18, !tbaa !21
  br i1 %t34, label %bb14, label %bb15
bb14:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr { i64, [5 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t37, i32 0, i32 2
  %t39 = load ptr, ptr %t38
  store ptr %t39, ptr %l3, !tbaa !29
  br label %bb16
bb15:
  br label %bb24
bb16:
  %t41 = load ptr, ptr %l3, !tbaa !29
  %t43 = getelementptr %"compiler/typed:Seq", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = icmp eq ptr %t44, null
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb17, label %bb18
bb17:
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l28, !tbaa !29
  %t51 = load ptr, ptr %l3, !tbaa !29
  %t53 = getelementptr %"compiler/typed:Seq", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = icmp eq ptr %t54, null
  br i1 %t56, label %bb19, label %bb20
bb18:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb23
bb19:
  call void @__olang_check_failed(ptr @olang_loc_13a66e5900397517_aa9470c685b363ab)
  unreachable
bb20:
  br label %bb21
bb21:
  %t58 = load ptr, ptr %l3, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Seq", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t62 = load ptr, ptr %l28, !tbaa !29
  %t64 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2echoiceOfRefs(ptr %v0, ptr %s0, ptr %t62, ptr %t61)
  store i1 %t64, ptr %l34
  br label %bb22
bb22:
  %t65 = load i1, ptr %l34, !tbaa !21
  store i1 %t65, ptr %l27, !tbaa !21
  br label %bb23
bb23:
  %t66 = load i1, ptr %l27, !tbaa !21
  store i1 %t66, ptr %l8, !tbaa !21
  br label %bb29
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_5a6ddbb4ef42a8ef_2ba82a28086a35d3)
  unreachable
bb29:
  call void @__olang_scope_close(ptr %s0)
  %t67 = load i1, ptr %l8, !tbaa !21
  store i1 %t67, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2echoiceRefs(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca { i64, [2 x i64] }
  %l12 = alloca ptr
  %l13 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca { i64, [2 x i64] }
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i1
  %l29 = alloca ptr
  %l38 = alloca ptr
  %l39 = alloca i1
  %l56 = alloca { i64, ptr }
  %l63 = alloca ptr
  %l75 = alloca i1
  %l85 = alloca ptr
  %l99 = alloca i64
  %l101 = alloca i64
  %l106 = alloca ptr
  %l110 = alloca ptr
  %l111 = alloca ptr
  %l112 = alloca i1
  %l117 = alloca ptr
  %l119 = alloca i32
  %l120 = alloca i1
  %l122 = alloca i1
  %l124 = alloca i1
  %l128 = alloca { i64, [2 x i64] }
  %l134 = alloca { i64, [2 x i64] }
  %l139 = alloca { i64, [2 x i64] }
  %s0 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca { i64, [2 x i64] }
  %t66 = alloca { i64, [2 x i64] }, align 8
  %t174 = alloca { i64, [2 x i64] }, align 8
  %t178 = alloca { i64, [2 x i64] }, align 8
  %t236 = alloca { i64, [2 x i64] }, align 8
  %t251 = alloca { i64, [2 x i64] }, align 8
  %t271 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l18
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s0, ptr %t3, ptr %a1)
  store ptr %t8, ptr %l22
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l22, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t10 = load ptr, ptr %l3, !tbaa !29
  store ptr %t10, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t11 = load ptr, ptr %l23, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load ptr, ptr %l23, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 18}
  %t17 = icmp eq i64 %t15, 11
  store i1 %t17, ptr %l24, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l24, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t19 = load ptr, ptr %l3, !tbaa !29
  %t21 = getelementptr { i64, [5 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l4, !tbaa !29
  br label %bb7
bb6:
  br label %bb13
bb7:
  store ptr %l2, ptr %l29, !tbaa !29
  %t25 = load ptr, ptr %l4, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Cond", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = icmp eq ptr %t28, null
  br i1 %t30, label %bb8, label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_c315d8e1b666b9f2_cb49359568748e36)
  unreachable
bb9:
  br label %bb10
bb10:
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = getelementptr %"compiler/typed:Cond", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t36 = load ptr, ptr %l29, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %s0, ptr %s0, ptr %t36, ptr %t35)
  br label %bb11
bb11:
  %t38 = load ptr, ptr %l4, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Cond", ptr %t38, i32 0, i32 2
  %t41 = load ptr, ptr %t40, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %s0, ptr %s0, ptr %l2, ptr %t41)
  br label %bb12
bb12:
  br label %bb56
bb13:
  %t44 = load ptr, ptr %l3, !tbaa !29
  store ptr %t44, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t45 = load ptr, ptr %l38, !tbaa !29
  %t46 = icmp ne ptr %t45, null
  br i1 %t46, label %bb14, label %bb15
bb14:
  %t48 = load ptr, ptr %l38, !tbaa !29
  %t49 = load i64, ptr %t48, !range !{i64 0, i64 18}
  %t51 = icmp eq i64 %t49, 13
  store i1 %t51, ptr %l39, !tbaa !21
  br label %bb15
bb15:
  %t52 = load i1, ptr %l39, !tbaa !21
  br i1 %t52, label %bb16, label %bb17
bb16:
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t55 = getelementptr { i64, [5 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t55, i32 0, i32 2
  %t57 = load ptr, ptr %t56
  store ptr %t57, ptr %l5, !tbaa !29
  br label %bb18
bb17:
  br label %bb51
bb18:
  %t59 = load ptr, ptr %l5, !tbaa !29
  %t61 = getelementptr %"compiler/typed:Match", ptr %t59, i32 0, i32 3
  %t62 = load i1, ptr %t61, !tbaa !21
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb19, label %bb20
bb19:
  store { i64, [2 x i64] } zeroinitializer, ptr %t66
  %t67 = getelementptr { i64, [2 x i64] }, ptr %t66, i32 0, i32 0
  store i64 0, ptr %t67
  %t68 = load { i64, [2 x i64] }, ptr %t66
  call void @__olang_scope_close(ptr %s0)
  store { i64, [2 x i64] } %t68, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t70 = load ptr, ptr %l5, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Match", ptr %t70, i32 0, i32 1
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  store { i64, ptr } %t73, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t75 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t75, 0
  store i64 %t77, ptr %l8, !tbaa !24
  br label %bb22
bb22:
  %t79 = load i64, ptr %l7, !tbaa !24
  %t80 = load i64, ptr %l8, !tbaa !24
  %t83 = icmp slt i64 %t79, %t80
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb23, label %bb24
bb23:
  br label %bb34
bb24:
  br label %bb25
bb25:
  %t87 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t87, ptr %l56, !tbaa !27
  %t88 = load i64, ptr %l7, !tbaa !24
  %t90 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr ptr, ptr %t91, i64 %t88
  %t93 = load ptr, ptr %t92, !tbaa !39
  store ptr %t93, ptr %l9, !tbaa !29
  %t95 = load ptr, ptr %l9, !tbaa !29
  %t97 = getelementptr %"compiler/typed:Arm", ptr %t95, i32 0, i32 4
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t100 = icmp eq ptr %t98, null
  %t102 = xor i1 %t100, true
  br i1 %t102, label %bb26, label %bb27
bb26:
  store ptr %l2, ptr %l63, !tbaa !29
  %t104 = load ptr, ptr %l9, !tbaa !29
  %t106 = getelementptr %"compiler/typed:Arm", ptr %t104, i32 0, i32 4
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t109 = icmp eq ptr %t107, null
  br i1 %t109, label %bb28, label %bb29
bb27:
  br label %bb32
bb28:
  call void @__olang_check_failed(ptr @olang_loc_24644cfdb6585119_908704f065623d9d)
  unreachable
bb29:
  br label %bb30
bb30:
  %t111 = load ptr, ptr %l9, !tbaa !29
  %t113 = getelementptr %"compiler/typed:Arm", ptr %t111, i32 0, i32 4
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t115 = load ptr, ptr %l63, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %s0, ptr %s0, ptr %t115, ptr %t114)
  br label %bb31
bb31:
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t117 = load i64, ptr %l7, !tbaa !24
  %t119 = add i64 %t117, 1
  store i64 %t119, ptr %l7, !tbaa !24
  br label %bb22
bb34:
  %t121 = load ptr, ptr %l5, !tbaa !29
  %t123 = getelementptr %"compiler/typed:Match", ptr %t121, i32 0, i32 2
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t126 = icmp eq ptr %t124, null
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb35, label %bb36
bb35:
  %t130 = load ptr, ptr %l5, !tbaa !29
  %t132 = getelementptr %"compiler/typed:Match", ptr %t130, i32 0, i32 2
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t135 = icmp eq ptr %t133, null
  br i1 %t135, label %bb37, label %bb38
bb36:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb40
bb37:
  call void @__olang_check_failed(ptr @olang_loc_68a62456ab789a64_c90c032bbba18c8)
  unreachable
bb38:
  br label %bb39
bb39:
  %t137 = load ptr, ptr %l5, !tbaa !29
  %t139 = getelementptr %"compiler/typed:Match", ptr %t137, i32 0, i32 2
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t143 = getelementptr %"compiler/typed:Arm", ptr %t140, i32 0, i32 4
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t146 = icmp eq ptr %t144, null
  %t148 = xor i1 %t146, true
  store i1 %t148, ptr %l75, !tbaa !21
  br label %bb40
bb40:
  %t150 = load i1, ptr %l75, !tbaa !21
  br i1 %t150, label %bb41, label %bb42
bb41:
  store ptr %l2, ptr %l85, !tbaa !29
  %t151 = load ptr, ptr %l5, !tbaa !29
  %t153 = getelementptr %"compiler/typed:Match", ptr %t151, i32 0, i32 2
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t156 = icmp eq ptr %t154, null
  br i1 %t156, label %bb43, label %bb44
bb42:
  br label %bb50
bb43:
  call void @__olang_check_failed(ptr @olang_loc_68a62456ab789a64_c90c032bbba18c8)
  unreachable
bb44:
  br label %bb45
bb45:
  %t158 = load ptr, ptr %l5, !tbaa !29
  %t160 = getelementptr %"compiler/typed:Match", ptr %t158, i32 0, i32 2
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t164 = getelementptr %"compiler/typed:Arm", ptr %t161, i32 0, i32 4
  %t165 = load ptr, ptr %t164, !tbaa !29
  store ptr %t165, ptr %l10, !tbaa !29
  %t167 = load ptr, ptr %l10, !tbaa !29
  %t169 = icmp eq ptr %t167, null
  br i1 %t169, label %bb46, label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_68a62456ab789a64_c90c032bbba18c8)
  unreachable
bb47:
  br label %bb48
bb48:
  %t171 = load ptr, ptr %l10, !tbaa !29
  %t172 = load ptr, ptr %l85, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %s0, ptr %s0, ptr %t172, ptr %t171)
  br label %bb49
bb49:
  br label %bb50
bb50:
  br label %bb56
bb51:
  br i1 true, label %bb52, label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb55
bb54:
  store { i64, [2 x i64] } zeroinitializer, ptr %t174
  %t175 = getelementptr { i64, [2 x i64] }, ptr %t174, i32 0, i32 0
  store i64 0, ptr %t175
  %t176 = load { i64, [2 x i64] }, ptr %t174
  call void @__olang_scope_close(ptr %s0)
  store { i64, [2 x i64] } %t176, ptr %rv
  br label %ret
bb55:
  call void @__olang_check_failed(ptr @olang_loc_95e0a8f1123dd6ca_6df17d64d17059fe)
  unreachable
bb56:
  store { i64, [2 x i64] } zeroinitializer, ptr %t178
  %t179 = getelementptr { i64, [2 x i64] }, ptr %t178, i32 0, i32 0
  store i64 0, ptr %t179
  %t180 = load { i64, [2 x i64] }, ptr %t178
  store { i64, [2 x i64] } %t180, ptr %l11
  store ptr %l2, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb57
bb57:
  store %olang.scope zeroinitializer, ptr %s11
  %t183 = load i64, ptr %l13, !tbaa !24
  store i64 %t183, ptr %l99, !tbaa !24
  %t184 = load ptr, ptr %l12, !tbaa !29
  %t186 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %s0, ptr %t184)
  store i64 %t186, ptr %l101
  br label %bb58
bb58:
  %t187 = load i64, ptr %l99, !tbaa !24
  %t188 = load i64, ptr %l101, !tbaa !24
  %t189 = icmp slt i64 %t187, %t188
  %t191 = xor i1 %t189, true
  br i1 %t191, label %bb59, label %bb60
bb59:
  call void @__olang_scope_close(ptr %s11)
  br label %bb93
bb60:
  br label %bb61
bb61:
  %t193 = load ptr, ptr %l12, !tbaa !29
  %t194 = load i64, ptr %l13, !tbaa !24
  %t197 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %s0, ptr %s0, ptr %t193, i64 %t194)
  store ptr %t197, ptr %l106
  br label %bb62
bb62:
  %t198 = load ptr, ptr %l106, !tbaa !29
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t204 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %s0, ptr %s11, ptr %t199, ptr %t198)
  store ptr %t204, ptr %l110
  br label %bb63
bb63:
  %t205 = load ptr, ptr %l110, !tbaa !29
  store ptr %t205, ptr %l15, !tbaa !29
  %t206 = load ptr, ptr %l15, !tbaa !29
  store ptr %t206, ptr %l111, !tbaa !29
  store i1 false, ptr %l112, !tbaa !21
  %t207 = load ptr, ptr %l111, !tbaa !29
  %t208 = icmp ne ptr %t207, null
  br i1 %t208, label %bb64, label %bb65
bb64:
  %t210 = load ptr, ptr %l111, !tbaa !29
  %t211 = load i64, ptr %t210, !range !{i64 0, i64 18}
  %t213 = icmp eq i64 %t211, 3
  store i1 %t213, ptr %l112, !tbaa !21
  br label %bb65
bb65:
  %t214 = load i1, ptr %l112, !tbaa !21
  br i1 %t214, label %bb66, label %bb67
bb66:
  %t215 = load ptr, ptr %l15, !tbaa !29
  %t217 = getelementptr { i64, [5 x i64] }, ptr %t215, i32 0, i32 1
  %t218 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t217, i32 0, i32 2
  %t219 = load ptr, ptr %t218
  store ptr %t219, ptr %l16, !tbaa !29
  br label %bb68
bb67:
  br label %bb86
bb68:
  %t221 = load ptr, ptr %l0, !tbaa !29
  store ptr %t221, ptr %l117, !tbaa !29
  %t222 = load ptr, ptr %l16, !tbaa !29
  %t224 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %s11, ptr %t222)
  store i32 %t224, ptr %l119
  br label %bb69
bb69:
  %t225 = load ptr, ptr %l117, !tbaa !29
  %t226 = load i32, ptr %l119, !tbaa !23
  %t227 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t225, i32 %t226)
  store i1 %t227, ptr %l120
  br label %bb70
bb70:
  %t228 = load i1, ptr %l120, !tbaa !21
  %t229 = xor i1 %t228, true
  br i1 %t229, label %bb71, label %bb72
bb71:
  store i1 true, ptr %l122, !tbaa !21
  br label %bb74
bb72:
  %t231 = load ptr, ptr %l16, !tbaa !29
  %t233 = call i1 @compiler_2fscope_2eflThroughRef(ptr %s11, ptr %t231)
  store i1 %t233, ptr %l124
  br label %bb73
bb73:
  %t234 = load i1, ptr %l124, !tbaa !21
  store i1 %t234, ptr %l122, !tbaa !21
  br label %bb74
bb74:
  %t235 = load i1, ptr %l122, !tbaa !21
  br i1 %t235, label %bb75, label %bb76
bb75:
  store { i64, [2 x i64] } zeroinitializer, ptr %t236
  %t237 = getelementptr { i64, [2 x i64] }, ptr %t236, i32 0, i32 0
  store i64 0, ptr %t237
  %t238 = load { i64, [2 x i64] }, ptr %t236
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  store { i64, [2 x i64] } %t238, ptr %rv
  br label %ret
bb76:
  br label %bb77
bb77:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load ptr, ptr %l16, !tbaa !29
  %t244 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekPlace(ptr %v0, ptr %s11, ptr %t240, ptr %t241, i1 true)
  store { i64, [2 x i64] } %t244, ptr %l128
  br label %bb78
bb78:
  %t245 = load { i64, [2 x i64] }, ptr %l128
  store { i64, [2 x i64] } %t245, ptr %l17
  %t246 = load { i64, [2 x i64] }, ptr %l17
  %t248 = extractvalue { i64, [2 x i64] } %t246, 0
  %t249 = icmp eq i64 %t248, 0
  br i1 %t249, label %bb79, label %bb80
bb79:
  store { i64, [2 x i64] } zeroinitializer, ptr %t251
  %t252 = getelementptr { i64, [2 x i64] }, ptr %t251, i32 0, i32 0
  store i64 0, ptr %t252
  %t253 = load { i64, [2 x i64] }, ptr %t251
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  store { i64, [2 x i64] } %t253, ptr %rv
  br label %ret
bb80:
  br label %bb81
bb81:
  %t255 = load { i64, [2 x i64] }, ptr %l11
  %t257 = extractvalue { i64, [2 x i64] } %t255, 0
  %t258 = icmp eq i64 %t257, 0
  br i1 %t258, label %bb82, label %bb83
bb82:
  %t260 = load { i64, [2 x i64] }, ptr %l17
  store { i64, [2 x i64] } %t260, ptr %l134
  br label %bb85
bb83:
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t263 = load { i64, [2 x i64] }, ptr %l11
  %t264 = load { i64, [2 x i64] }, ptr %l17
  %t268 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esetOf(ptr %v0, ptr %t262, { i64, [2 x i64] } %t263, { i64, [2 x i64] } %t264)
  store { i64, [2 x i64] } %t268, ptr %l139
  br label %bb84
bb84:
  %t269 = load { i64, [2 x i64] }, ptr %l139
  store { i64, [2 x i64] } %t269, ptr %l134
  br label %bb85
bb85:
  %t270 = load { i64, [2 x i64] }, ptr %l134
  store { i64, [2 x i64] } %t270, ptr %l11
  br label %bb91
bb86:
  br i1 true, label %bb87, label %bb88
bb87:
  br label %bb89
bb88:
  br label %bb90
bb89:
  store { i64, [2 x i64] } zeroinitializer, ptr %t271
  %t272 = getelementptr { i64, [2 x i64] }, ptr %t271, i32 0, i32 0
  store i64 0, ptr %t272
  %t273 = load { i64, [2 x i64] }, ptr %t271
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  store { i64, [2 x i64] } %t273, ptr %rv
  br label %ret
bb90:
  call void @__olang_check_failed(ptr @olang_loc_5b1407f703b7271d_53185d392c7421d9)
  unreachable
bb91:
  call void @__olang_scope_close(ptr %s11)
  br label %bb92
bb92:
  %t275 = load i64, ptr %l13, !tbaa !24
  %t277 = add i64 %t275, 1
  store i64 %t277, ptr %l13, !tbaa !24
  br label %bb57
bb93:
  %t279 = load { i64, [2 x i64] }, ptr %l11
  call void @__olang_scope_close(ptr %s0)
  store { i64, [2 x i64] } %t279, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ectorParams(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l8 = alloca i32
  %l11 = alloca i1
  %l14 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i32
  %l29 = alloca i64
  %l33 = alloca ptr
  %l36 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i32, ptr %l8, !tbaa !23
  store i32 %t11, ptr %l2, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l2, !tbaa !23
  %t16 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t16, ptr %l11
  br label %bb2
bb2:
  %t17 = load i1, ptr %l11, !tbaa !21
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/scope:Scoper", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 2
  store ptr %t23, ptr %l14, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/scope:Scoper", ptr %t24, i32 0, i32 0
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t30 = load i32, ptr %l2, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l19
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t34 = load ptr, ptr %l14, !tbaa !29
  %t35 = load i32, ptr %l19, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t36, ptr %l20
  br label %bb6
bb6:
  %t37 = load i32, ptr %l20, !tbaa !23
  store i32 %t37, ptr %l2, !tbaa !23
  br label %bb7
bb7:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/scope:Scoper", ptr %t38, i32 0, i32 7
  %t41 = load i32, ptr %l2, !tbaa !23
  %t44 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %t40, i32 %t41)
  %t45 = extractvalue { i32, i64 } %t44, 1
  %t46 = extractvalue { i32, i64 } %t44, 0
  store i32 %t46, ptr %l26
  %t47 = icmp ne i32 %t46, 0
  br i1 %t47, label %bb9, label %ok.48, !prof !99
ok.48:
  store i64 %t45, ptr %l25
  br label %bb8
bb8:
  %t49 = load i64, ptr %l25, !tbaa !24
  store i64 %t49, ptr %l21, !tbaa !24
  br label %bb11
bb9:
  br label %bb10
bb10:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l21, !tbaa !24
  br label %bb11
bb11:
  %t50 = load i64, ptr %l21, !tbaa !24
  store i64 %t50, ptr %l3, !tbaa !24
  %t51 = load i64, ptr %l3, !tbaa !24
  %t53 = icmp sge i64 %t51, 0
  br i1 %t53, label %bb12, label %bb13
bb12:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/scope:Scoper", ptr %t55, i32 0, i32 1
  %t58 = load i64, ptr %l3, !tbaa !24
  %t61 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t57, i64 %t58)
  store ptr %t61, ptr %l33
  br label %bb14
bb13:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb16
bb14:
  %t62 = load ptr, ptr %l33, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Body", ptr %t62, i32 0, i32 5
  %t66 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t64)
  store i64 %t66, ptr %l36
  br label %bb15
bb15:
  %t67 = load i64, ptr %l36, !tbaa !24
  store i64 %t67, ptr %l29, !tbaa !24
  br label %bb16
bb16:
  %t68 = load i64, ptr %l29, !tbaa !24
  store i64 %t68, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edeclOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l7 = alloca i32
  %l10 = alloca i1
  %l13 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca i32
  %l23 = alloca i1
  %l25 = alloca i1
  %l30 = alloca i32
  %l39 = alloca i32
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load i32, ptr %l7, !tbaa !23
  store i32 %t11, ptr %l2, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l2, !tbaa !23
  %t16 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t16, ptr %l10
  br label %bb2
bb2:
  %t17 = load i1, ptr %l10, !tbaa !21
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/scope:Scoper", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 2
  store ptr %t23, ptr %l13, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/scope:Scoper", ptr %t24, i32 0, i32 0
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t30 = load i32, ptr %l2, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l18
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t34 = load ptr, ptr %l13, !tbaa !29
  %t35 = load i32, ptr %l18, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t36, ptr %l19
  br label %bb6
bb6:
  %t37 = load i32, ptr %l19, !tbaa !23
  store i32 %t37, ptr %l2, !tbaa !23
  br label %bb7
bb7:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/scope:Scoper", ptr %t38, i32 0, i32 7
  %t41 = load i32, ptr %l2, !tbaa !23
  %t44 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H58d460568d59c9f3a36f8d9425118a1c(ptr %v0, ptr %t40, i32 %t41)
  store i1 %t44, ptr %l23
  br label %bb8
bb8:
  %t45 = load i1, ptr %l23, !tbaa !21
  %t46 = xor i1 %t45, true
  br i1 %t46, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb12
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/scope:Scoper", ptr %t48, i32 0, i32 0
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = getelementptr %"compiler/generic:Program", ptr %t51, i32 0, i32 2
  %t54 = load i32, ptr %l2, !tbaa !23
  %t57 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t53, i32 %t54)
  store i32 %t57, ptr %l30
  br label %bb11
bb11:
  %t58 = load i32, ptr %l30, !range !{i32 0, i32 33}
  %t60 = trunc i64 18 to i32
  %t61 = icmp eq i32 %t58, %t60
  %t63 = xor i1 %t61, true
  store i1 %t63, ptr %l25, !tbaa !21
  br label %bb12
bb12:
  %t65 = load i1, ptr %l25, !tbaa !21
  br i1 %t65, label %bb13, label %bb14
bb13:
  store i64 -1, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/scope:Scoper", ptr %t67, i32 0, i32 0
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Program", ptr %t70, i32 0, i32 2
  %t73 = load i32, ptr %l2, !tbaa !23
  %t76 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t72, i32 %t73)
  store i32 %t76, ptr %l39
  br label %bb16
bb16:
  %t77 = load i32, ptr %l39, !tbaa !23
  %t78 = sext i32 %t77 to i64
  store i64 %t78, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ederivedAt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i64 %a2, ptr %a3, i1 %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, [2 x i64] }
  %l12 = alloca i1
  %l20 = alloca { i64, ptr }
  %l24 = alloca i64
  %l27 = alloca i1
  %l36 = alloca %"compiler/typed:Local"
  %l39 = alloca i1
  %l40 = alloca ptr
  %l49 = alloca %"compiler/typed:Local"
  %l51 = alloca i1
  %l54 = alloca i64
  %l59 = alloca i64
  %l63 = alloca { i64, [2 x i64] }
  %l70 = alloca { i64, [2 x i64] }
  %l78 = alloca { i64, [2 x i64] }
  %l82 = alloca { i64, [2 x i64] }
  %rv = alloca { i64, [2 x i64] }
  %t17 = alloca { i64, [2 x i64] }, align 8
  %t97 = alloca { i64, [2 x i64] }, align 8
  %t138 = alloca { i64, [2 x i64] }, align 8
  %t161 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Call", ptr %t6, i32 0, i32 1
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  %t14 = icmp sge i64 %t5, %t11
  store i1 %t14, ptr %l12, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l12, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  store { i64, [2 x i64] } zeroinitializer, ptr %t17
  %t18 = getelementptr { i64, [2 x i64] }, ptr %t17, i32 0, i32 0
  store i64 6, ptr %t18
  %t19 = load { i64, [2 x i64] }, ptr %t17
  store { i64, [2 x i64] } %t19, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Call", ptr %t21, i32 0, i32 1
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  store { i64, ptr } %t24, ptr %l20, !tbaa !27
  %t25 = load i64, ptr %l1, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr ptr, ptr %t28, i64 %t25
  %t30 = load ptr, ptr %t29, !tbaa !39
  store ptr %t30, ptr %l6, !tbaa !29
  %t32 = load ptr, ptr %l6, !tbaa !29
  %t34 = call i64 @compiler_2fscope_2eregionLocal(ptr %v1, ptr %t32)
  store i64 %t34, ptr %l24
  br label %bb7
bb7:
  %t35 = load i64, ptr %l24, !tbaa !24
  store i64 %t35, ptr %l7, !tbaa !24
  %t36 = load i64, ptr %l7, !tbaa !24
  %t38 = icmp sge i64 %t36, 0
  br i1 %t38, label %bb8, label %bb9
bb8:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/scope:Scoper", ptr %t40, i32 0, i32 25
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = icmp eq ptr %t43, null
  br i1 %t45, label %bb10, label %bb11
bb9:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb14
bb10:
  call void @__olang_check_failed(ptr @olang_loc_9797cac8d61c1573_9128cc3b478a4c7f)
  unreachable
bb11:
  br label %bb12
bb12:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/scope:Scoper", ptr %t47, i32 0, i32 25
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t53 = getelementptr %"compiler/typed:Body", ptr %t50, i32 0, i32 7
  %t54 = load i64, ptr %l7, !tbaa !24
  %t57 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t53, i64 %t54)
  store %"compiler/typed:Local" %t57, ptr %l36
  br label %bb13
bb13:
  %t58 = getelementptr %"compiler/typed:Local", ptr %l36, i32 0, i32 4
  %t59 = load i32, ptr %t58, !range !{i32 0, i32 7}
  %t61 = trunc i64 0 to i32
  %t62 = icmp eq i32 %t59, %t61
  store i1 %t62, ptr %l27, !tbaa !21
  br label %bb14
bb14:
  %t64 = load i1, ptr %l27, !tbaa !21
  br i1 %t64, label %bb15, label %bb16
bb15:
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l40, !tbaa !29
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/scope:Scoper", ptr %t66, i32 0, i32 25
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = icmp eq ptr %t69, null
  br i1 %t71, label %bb17, label %bb18
bb16:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb22
bb17:
  call void @__olang_check_failed(ptr @olang_loc_9797cac8d61c1573_9128cc3b478a4c7f)
  unreachable
bb18:
  br label %bb19
bb19:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/scope:Scoper", ptr %t73, i32 0, i32 25
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t79 = getelementptr %"compiler/typed:Body", ptr %t76, i32 0, i32 7
  %t80 = load i64, ptr %l7, !tbaa !24
  %t83 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t79, i64 %t80)
  store %"compiler/typed:Local" %t83, ptr %l49
  br label %bb20
bb20:
  %t84 = getelementptr %"compiler/typed:Local", ptr %l49, i32 0, i32 2
  %t85 = load i32, ptr %t84, !tbaa !23
  %t86 = load ptr, ptr %l40, !tbaa !29
  %t88 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t86, i32 %t85)
  store i1 %t88, ptr %l51
  br label %bb21
bb21:
  %t89 = load i1, ptr %l51, !tbaa !21
  store i1 %t89, ptr %l39, !tbaa !21
  br label %bb22
bb22:
  %t90 = load i1, ptr %l39, !tbaa !21
  br i1 %t90, label %bb23, label %bb24
bb23:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load i64, ptr %l7, !tbaa !24
  %t95 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparamIndex(ptr %v0, ptr %t91, i64 %t92)
  store i64 %t95, ptr %l54
  br label %bb25
bb24:
  br label %bb26
bb25:
  %t96 = load i64, ptr %l2, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t97
  %t98 = getelementptr { i64, [2 x i64] }, ptr %t97, i32 0, i32 0
  store i64 4, ptr %t98
  %t99 = load i64, ptr %l54, !tbaa !24
  %t100 = insertvalue { i64, i64 } undef, i64 %t99, 0
  %t102 = insertvalue { i64, i64 } %t100, i64 %t96, 1
  %t103 = getelementptr { i64, [2 x i64] }, ptr %t97, i32 0, i32 1
  store { i64, i64 } %t102, ptr %t103
  %t104 = load { i64, [2 x i64] }, ptr %t97
  store { i64, [2 x i64] } %t104, ptr %rv
  br label %ret
bb26:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load ptr, ptr %l6, !tbaa !29
  %t110 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargRec(ptr %v0, ptr %v1, ptr %t106, ptr %t107)
  store i64 %t110, ptr %l59
  br label %bb27
bb27:
  %t111 = load i64, ptr %l59, !tbaa !24
  store i64 %t111, ptr %l8, !tbaa !24
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load i64, ptr %l8, !tbaa !24
  %t114 = load i64, ptr %l2, !tbaa !24
  %t118 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erecAt(ptr %v0, ptr %t112, i64 %t113, i64 %t114)
  store { i64, [2 x i64] } %t118, ptr %l63
  br label %bb28
bb28:
  %t119 = load { i64, [2 x i64] }, ptr %l63
  %t121 = extractvalue { i64, [2 x i64] } %t119, 0
  %t122 = icmp eq i64 %t121, 0
  %t124 = xor i1 %t122, true
  br i1 %t124, label %bb29, label %bb30
bb29:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load i64, ptr %l8, !tbaa !24
  %t128 = load i64, ptr %l2, !tbaa !24
  %t132 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erecAt(ptr %v0, ptr %t126, i64 %t127, i64 %t128)
  store { i64, [2 x i64] } %t132, ptr %l70
  br label %bb31
bb30:
  br label %bb32
bb31:
  %t133 = load { i64, [2 x i64] }, ptr %l70
  store { i64, [2 x i64] } %t133, ptr %rv
  br label %ret
bb32:
  %t136 = xor i1 %a4, true
  br i1 %t136, label %bb33, label %bb34
bb33:
  store { i64, [2 x i64] } zeroinitializer, ptr %t138
  %t139 = getelementptr { i64, [2 x i64] }, ptr %t138, i32 0, i32 0
  store i64 6, ptr %t139
  %t140 = load { i64, [2 x i64] }, ptr %t138
  store { i64, [2 x i64] } %t140, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load ptr, ptr %l3, !tbaa !29
  %t144 = load i64, ptr %l1, !tbaa !24
  %t150 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparamBinding(ptr %v0, ptr %v1, ptr %v2, ptr %t142, ptr %t143, i64 %t144, { i64, ptr } %a5)
  store { i64, [2 x i64] } %t150, ptr %l78
  br label %bb36
bb36:
  %t151 = load { i64, [2 x i64] }, ptr %l78
  store { i64, [2 x i64] } %t151, ptr %l9
  %t152 = load { i64, [2 x i64] }, ptr %l9
  %t154 = extractvalue { i64, [2 x i64] } %t152, 0
  %t155 = icmp eq i64 %t154, 0
  %t157 = xor i1 %t155, true
  br i1 %t157, label %bb37, label %bb38
bb37:
  %t159 = load { i64, [2 x i64] }, ptr %l9
  store { i64, [2 x i64] } %t159, ptr %l82
  br label %bb39
bb38:
  store { i64, [2 x i64] } zeroinitializer, ptr %t161
  %t162 = getelementptr { i64, [2 x i64] }, ptr %t161, i32 0, i32 0
  store i64 6, ptr %t162
  %t163 = load { i64, [2 x i64] }, ptr %t161
  store { i64, [2 x i64] } %t163, ptr %l82
  br label %bb39
bb39:
  %t165 = load { i64, [2 x i64] }, ptr %l82
  store { i64, [2 x i64] } %t165, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ederivedBuilds(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca { i64, ptr }
  %l34 = alloca i1
  %l41 = alloca { i64, ptr }
  %l44 = alloca i1
  %l50 = alloca { i64, ptr }
  %l55 = alloca i64
  %l58 = alloca i64
  %l81 = alloca i64
  %s5 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a4, ptr %l14, !tbaa !27
  %t2 = load i64, ptr %l3, !tbaa !24
  %t4 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !27
  %t6 = getelementptr { i64, [2 x i64] }, ptr %t5, i64 %t2
  %t7 = load { i64, [2 x i64] }, ptr %t6
  %t11 = extractvalue { i64, [2 x i64] } %t7, 0
  %t12 = icmp eq i64 %t11, 4
  br i1 %t12, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb9
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  call void @__olang_check_failed(ptr @olang_loc_5143053d218562e2_13c44612613aa94e)
  unreachable
bb9:
  store { i64, ptr } %a2, ptr %l20, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i64, ptr %t19, i64 %t16
  %t21 = load i64, ptr %t20, !tbaa !34
  store i64 %t21, ptr %l6, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/scope:Scoper", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  store ptr %t28, ptr %l25, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/scope:Scoper", ptr %t29, i32 0, i32 0
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t35 = load i32, ptr %l1, !tbaa !23
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t38, ptr %l30
  br label %bb10
bb10:
  %t39 = load ptr, ptr %l25, !tbaa !29
  %t40 = load i32, ptr %l30, !tbaa !23
  %t41 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t39, i32 %t40)
  store { i64, ptr } %t41, ptr %l31
  br label %bb11
bb11:
  %t42 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t42, ptr %l7, !tbaa !27
  %t43 = load i64, ptr %l6, !tbaa !24
  %t45 = icmp slt i64 %t43, 0
  br i1 %t45, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb14
bb13:
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t48, 0
  %t53 = icmp sge i64 %t47, %t50
  store i1 %t53, ptr %l34, !tbaa !21
  br label %bb14
bb14:
  %t55 = load i1, ptr %l34, !tbaa !21
  br i1 %t55, label %bb15, label %bb16
bb15:
  store i1 true, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t58, ptr %l41, !tbaa !27
  %t59 = load i64, ptr %l6, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i32, ptr %t62, i64 %t59
  %t64 = load i32, ptr %t63, !tbaa !33
  %t67 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eadmitsStores(ptr %v0, ptr %t57, i32 %t64)
  store i1 %t67, ptr %l44
  br label %bb18
bb18:
  %t68 = load i1, ptr %l44, !tbaa !21
  br i1 %t68, label %bb19, label %bb20
bb19:
  store i1 true, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s5
  store i64 0, ptr %l8, !tbaa !24
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/scope:Scoper", ptr %t70, i32 0, i32 0
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/generic:Program", ptr %t73, i32 0, i32 2
  %t76 = load i32, ptr %l1, !tbaa !23
  %t79 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s5, ptr %t75, i32 %t76)
  store { i64, ptr } %t79, ptr %l50
  br label %bb22
bb22:
  %t80 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 0
  store i64 %t81, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t83 = load i64, ptr %l9, !tbaa !24
  %t84 = load i64, ptr %l8, !tbaa !24
  %t87 = icmp sgt i64 %t83, %t84
  br i1 %t87, label %bb23, label %bb24
bb23:
  %t89 = load i64, ptr %l10, !tbaa !24
  %t91 = icmp sgt i64 %t89, 0
  br i1 %t91, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb28
bb25:
  %t93 = load i64, ptr %l9, !tbaa !24
  %t94 = load i64, ptr %l8, !tbaa !24
  %t97 = sub i64 %t93, %t94
  %t98 = load i64, ptr %l10, !tbaa !24
  %t101 = add i64 %t97, %t98
  %t103 = sub i64 %t101, 1
  %t104 = load i64, ptr %l10, !tbaa !24
  %t107 = sdiv i64 %t103, %t104
  store i64 %t107, ptr %l58, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb27
bb27:
  %t109 = load i64, ptr %l58, !tbaa !24
  store i64 %t109, ptr %l55, !tbaa !24
  br label %bb28
bb28:
  %t110 = load i64, ptr %l55, !tbaa !24
  store i64 %t110, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb29
bb29:
  %t111 = load i64, ptr %l12, !tbaa !24
  %t112 = load i64, ptr %l11, !tbaa !24
  %t115 = icmp slt i64 %t111, %t112
  %t117 = xor i1 %t115, true
  br i1 %t117, label %bb30, label %bb31
bb30:
  br label %bb38
bb31:
  br label %bb32
bb32:
  %t119 = load i64, ptr %l8, !tbaa !24
  %t120 = load i64, ptr %l12, !tbaa !24
  %t121 = load i64, ptr %l10, !tbaa !24
  %t124 = mul i64 %t120, %t121
  %t127 = add i64 %t119, %t124
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/scope:Scoper", ptr %t129, i32 0, i32 0
  %t132 = load ptr, ptr %t131, !tbaa !29
  %t134 = getelementptr %"compiler/generic:Program", ptr %t132, i32 0, i32 2
  %t135 = load i32, ptr %l1, !tbaa !23
  %t140 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t134, i32 %t135, i64 %t127)
  store i64 %t140, ptr %l81
  br label %bb33
bb33:
  %t141 = load i64, ptr %l6, !tbaa !24
  %t142 = load i64, ptr %l81, !tbaa !24
  %t144 = icmp eq i64 %t142, %t141
  br i1 %t144, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s5)
  store i1 true, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t147 = load i64, ptr %l12, !tbaa !24
  %t149 = add i64 %t147, 1
  store i64 %t149, ptr %l12, !tbaa !24
  br label %bb29
bb38:
  call void @__olang_scope_close(ptr %s5)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ederivedThroughElem(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1, ptr %a2) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca ptr
  %l3 = alloca i64
  %l9 = alloca i1
  %l15 = alloca i1
  %l18 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l24 = alloca i1
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store { i64, [2 x i64] } %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 4
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i64, i64 }, ptr %t6, i32 0, i32 0
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l3, !tbaa !24
  br label %bb3
bb2:
  br label %bb12
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load i64, ptr %l3, !tbaa !24
  %t12 = icmp sge i64 %t10, 0
  br i1 %t12, label %bb4, label %bb5
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Call", ptr %t15, i32 0, i32 1
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  %t23 = icmp slt i64 %t14, %t20
  store i1 %t23, ptr %l9, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb6
bb6:
  %t25 = load i1, ptr %l9, !tbaa !21
  br i1 %t25, label %bb7, label %bb8
bb7:
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Call", ptr %t27, i32 0, i32 1
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  store { i64, ptr } %t30, ptr %l18, !tbaa !27
  %t31 = load i64, ptr %l3, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr ptr, ptr %t34, i64 %t31
  %t36 = load ptr, ptr %t35, !tbaa !39
  %t40 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s1, ptr %a0, ptr %t36)
  store ptr %t40, ptr %l22
  br label %bb9
bb8:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb11
bb9:
  %t41 = load ptr, ptr %l22, !tbaa !29
  %t43 = call i1 @compiler_2fscope_2ethroughElemExpr(ptr %s1, ptr %t41)
  store i1 %t43, ptr %l24
  br label %bb10
bb10:
  %t44 = load i1, ptr %l24, !tbaa !21
  store i1 %t44, ptr %l15, !tbaa !21
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s1)
  %t45 = load i1, ptr %l15, !tbaa !21
  store i1 %t45, ptr %rv
  br label %ret
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i1 false, ptr %rv
  br label %ret
bb16:
  call void @__olang_check_failed(ptr @olang_loc_cad6ea40519e9749_ea608eb2fc6ab735)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edestructsAt(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l7 = alloca i32
  %l12 = alloca i32
  %l15 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i1
  %l26 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load i32, ptr %l7, !tbaa !23
  store i32 %t11, ptr %l2, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/scope:Scoper", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %l2, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l12
  br label %bb2
bb2:
  %t22 = load i32, ptr %l12, !range !{i32 0, i32 33}
  %t24 = trunc i64 18 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb3, label %bb4
bb3:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/scope:Scoper", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/generic:Program", ptr %t30, i32 0, i32 2
  %t33 = load i32, ptr %l2, !tbaa !23
  %t36 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t32, i32 %t33)
  store i1 %t36, ptr %l20
  br label %bb5
bb4:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb6
bb5:
  %t37 = load i1, ptr %l20, !tbaa !21
  store i1 %t37, ptr %l15, !tbaa !21
  br label %bb6
bb6:
  %t38 = load i1, ptr %l15, !tbaa !21
  br i1 %t38, label %bb7, label %bb8
bb7:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/scope:Scoper", ptr %t39, i32 0, i32 0
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/generic:Program", ptr %t42, i32 0, i32 2
  %t45 = load i32, ptr %l2, !tbaa !23
  %t48 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t44, i32 %t45)
  store i1 %t48, ptr %l26
  br label %bb9
bb8:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb10
bb9:
  %t49 = load i1, ptr %l26, !tbaa !21
  store i1 %t49, ptr %l21, !tbaa !21
  br label %bb10
bb10:
  %t50 = load i1, ptr %l21, !tbaa !21
  store i1 %t50, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efieldTerm(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l10 = alloca i32
  %l13 = alloca i1
  %l17 = alloca { i64, [2 x i64] }
  %l24 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca i1
  %l32 = alloca i64
  %l35 = alloca i1
  %l44 = alloca %"compiler/typed:Local"
  %l50 = alloca ptr
  %l53 = alloca i64
  %l56 = alloca i64
  %l59 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l62 = alloca i64
  %l65 = alloca i64
  %l68 = alloca ptr
  %l71 = alloca i64
  %l73 = alloca { i64, [2 x i64] }
  %l77 = alloca ptr
  %l80 = alloca i64
  %l82 = alloca { i64, [2 x i64] }
  %l84 = alloca ptr
  %l87 = alloca { i64, [2 x i64] }
  %l89 = alloca ptr
  %l91 = alloca i1
  %l93 = alloca ptr
  %l96 = alloca i64
  %l99 = alloca i64
  %l105 = alloca { i64, [2 x i64] }
  %s5 = alloca %olang.scope
  %rv = alloca { i64, [2 x i64] }
  %t124 = alloca { i64, [2 x i64] }, align 8
  %t199 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t1)
  store i32 %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load i32, ptr %l10, !tbaa !23
  store i32 %t4, ptr %l3, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr %l3, !tbaa !23
  %t9 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisStruct(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l13
  br label %bb2
bb2:
  %t10 = load i1, ptr %l13, !tbaa !21
  br i1 %t10, label %bb3, label %bb4
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l3, !tbaa !23
  %t17 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efieldMark(ptr %v0, ptr %t11, i32 %t12, i64 %a2)
  store { i64, [2 x i64] } %t17, ptr %l17
  br label %bb5
bb4:
  br label %bb60
bb5:
  %t18 = load { i64, [2 x i64] }, ptr %l17
  store { i64, [2 x i64] } %t18, ptr %l4
  %t19 = load { i64, [2 x i64] }, ptr %l4
  %t21 = extractvalue { i64, [2 x i64] } %t19, 0
  %t22 = icmp eq i64 %t21, 2
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t25 = getelementptr { i32 }, ptr %t24, i32 0, i32 0
  %t26 = load i32, ptr %t25
  store i32 %t26, ptr %l5, !tbaa !23
  br label %bb8
bb7:
  br label %bb54
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l3, !tbaa !23
  %t30 = load i32, ptr %l5, !tbaa !23
  %t34 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ectorParamIndex(ptr %v0, ptr %t28, i32 %t29, i32 %t30)
  store i64 %t34, ptr %l24
  br label %bb9
bb9:
  %t35 = load i64, ptr %l24, !tbaa !24
  store i64 %t35, ptr %l6, !tbaa !24
  %t36 = load ptr, ptr %l1, !tbaa !29
  store ptr %t36, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t37 = load ptr, ptr %l25, !tbaa !29
  %t38 = icmp ne ptr %t37, null
  br i1 %t38, label %bb10, label %bb11
bb10:
  %t40 = load ptr, ptr %l25, !tbaa !29
  %t41 = load i64, ptr %t40, !range !{i64 0, i64 8}
  %t43 = icmp eq i64 %t41, 2
  store i1 %t43, ptr %l26, !tbaa !21
  br label %bb11
bb11:
  %t44 = load i1, ptr %l26, !tbaa !21
  br i1 %t44, label %bb12, label %bb13
bb12:
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr { i64, [4 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t47, i32 0, i32 2
  %t49 = load ptr, ptr %t48
  store ptr %t49, ptr %l7, !tbaa !29
  br label %bb14
bb13:
  br label %bb34
bb14:
  %t51 = load ptr, ptr %l7, !tbaa !29
  %t53 = call i64 @compiler_2fscope_2eregionLocal(ptr %v1, ptr %t51)
  store i64 %t53, ptr %l32
  br label %bb15
bb15:
  %t54 = load i64, ptr %l32, !tbaa !24
  store i64 %t54, ptr %l8, !tbaa !24
  %t55 = load i64, ptr %l8, !tbaa !24
  %t57 = icmp sge i64 %t55, 0
  br i1 %t57, label %bb16, label %bb17
bb16:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/scope:Scoper", ptr %t59, i32 0, i32 25
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = icmp eq ptr %t62, null
  br i1 %t64, label %bb18, label %bb19
bb17:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb22
bb18:
  call void @__olang_check_failed(ptr @olang_loc_fb66d6a098581c09_2fd4002f8136e06d)
  unreachable
bb19:
  br label %bb20
bb20:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/scope:Scoper", ptr %t66, i32 0, i32 25
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Body", ptr %t69, i32 0, i32 7
  %t73 = load i64, ptr %l8, !tbaa !24
  %t76 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t72, i64 %t73)
  store %"compiler/typed:Local" %t76, ptr %l44
  br label %bb21
bb21:
  %t77 = getelementptr %"compiler/typed:Local", ptr %l44, i32 0, i32 4
  %t78 = load i32, ptr %t77, !range !{i32 0, i32 7}
  %t80 = trunc i64 0 to i32
  %t81 = icmp eq i32 %t78, %t80
  store i1 %t81, ptr %l35, !tbaa !21
  br label %bb22
bb22:
  %t83 = load i1, ptr %l35, !tbaa !21
  br i1 %t83, label %bb23, label %bb24
bb23:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/scope:Scoper", ptr %t84, i32 0, i32 137
  %t87 = load i1, ptr %t86, !tbaa !21
  br i1 %t87, label %bb25, label %bb26
bb24:
  br label %bb33
bb25:
  store %olang.scope zeroinitializer, ptr %s5
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/scope:Scoper", ptr %t89, i32 0, i32 131
  store ptr %t91, ptr %l50, !tbaa !29
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/scope:Scoper", ptr %t92, i32 0, i32 26
  %t95 = load i64, ptr %t94, !tbaa !24
  %t97 = mul i64 %t95, 65536
  store i64 %t97, ptr %l53, !tbaa !24
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load i64, ptr %l8, !tbaa !24
  %t102 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparamIndex(ptr %v0, ptr %t98, i64 %t99)
  store i64 %t102, ptr %l56
  br label %bb27
bb26:
  br label %bb31
bb27:
  %t103 = load i64, ptr %l53, !tbaa !24
  %t104 = load i64, ptr %l56, !tbaa !24
  %t105 = add i64 %t103, %t104
  %t106 = load i64, ptr %l6, !tbaa !24
  %t109 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s5, i64 %t105, i64 %t106)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t109, ptr %l59
  br label %bb28
bb28:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load i32, ptr %l3, !tbaa !23
  %t114 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edeclOf(ptr %v0, ptr %t110, i32 %t111)
  store i64 %t114, ptr %l62
  br label %bb29
bb29:
  %t115 = load ptr, ptr %l50, !tbaa !29
  %t116 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l59
  %t117 = load i64, ptr %l62, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %t115, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t116, i64 %t117)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb31:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load i64, ptr %l8, !tbaa !24
  %t122 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparamIndex(ptr %v0, ptr %t118, i64 %t119)
  store i64 %t122, ptr %l65
  br label %bb32
bb32:
  %t123 = load i64, ptr %l6, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t124
  %t125 = getelementptr { i64, [2 x i64] }, ptr %t124, i32 0, i32 0
  store i64 4, ptr %t125
  %t126 = load i64, ptr %l65, !tbaa !24
  %t127 = insertvalue { i64, i64 } undef, i64 %t126, 0
  %t129 = insertvalue { i64, i64 } %t127, i64 %t123, 1
  %t130 = getelementptr { i64, [2 x i64] }, ptr %t124, i32 0, i32 1
  store { i64, i64 } %t129, ptr %t130
  %t131 = load { i64, [2 x i64] }, ptr %t124
  store { i64, [2 x i64] } %t131, ptr %rv
  br label %ret
bb33:
  br label %bb39
bb34:
  br i1 true, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_cd1d16db8329fc51_df7e5714e2c1cec5)
  unreachable
bb39:
  %t133 = load ptr, ptr %l0, !tbaa !29
  store ptr %t133, ptr %l68, !tbaa !29
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load ptr, ptr %l1, !tbaa !29
  %t138 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erecOf(ptr %v0, ptr %v1, ptr %t134, ptr %t135)
  store i64 %t138, ptr %l71
  br label %bb40
bb40:
  %t139 = load i64, ptr %l6, !tbaa !24
  %t140 = load ptr, ptr %l68, !tbaa !29
  %t141 = load i64, ptr %l71, !tbaa !24
  %t143 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erecAt(ptr %v0, ptr %t140, i64 %t141, i64 %t139)
  store { i64, [2 x i64] } %t143, ptr %l73
  br label %bb41
bb41:
  %t144 = load { i64, [2 x i64] }, ptr %l73
  %t146 = extractvalue { i64, [2 x i64] } %t144, 0
  %t147 = icmp eq i64 %t146, 0
  %t149 = xor i1 %t147, true
  br i1 %t149, label %bb42, label %bb43
bb42:
  %t151 = load ptr, ptr %l0, !tbaa !29
  store ptr %t151, ptr %l77, !tbaa !29
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load ptr, ptr %l1, !tbaa !29
  %t156 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erecOf(ptr %v0, ptr %v1, ptr %t152, ptr %t153)
  store i64 %t156, ptr %l80
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t157 = load i64, ptr %l6, !tbaa !24
  %t158 = load ptr, ptr %l77, !tbaa !29
  %t159 = load i64, ptr %l80, !tbaa !24
  %t161 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erecAt(ptr %v0, ptr %t158, i64 %t159, i64 %t157)
  store { i64, [2 x i64] } %t161, ptr %l82
  br label %bb45
bb45:
  %t162 = load { i64, [2 x i64] }, ptr %l82
  store { i64, [2 x i64] } %t162, ptr %rv
  br label %ret
bb46:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/scope:Scoper", ptr %t163, i32 0, i32 87
  store ptr %t165, ptr %l84, !tbaa !29
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load ptr, ptr %l1, !tbaa !29
  %t170 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartsTerm(ptr %v0, ptr %v1, ptr %t166, ptr %t167)
  store { i64, [2 x i64] } %t170, ptr %l87
  br label %bb47
bb47:
  %t171 = load ptr, ptr %l84, !tbaa !29
  %t172 = load { i64, [2 x i64] }, ptr %l87
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ePush_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t171, { i64, [2 x i64] } %t172)
  br label %bb48
bb48:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/scope:Scoper", ptr %t173, i32 0, i32 88
  store ptr %t175, ptr %l89, !tbaa !29
  %t176 = load ptr, ptr %l1, !tbaa !29
  %t178 = call i1 @compiler_2fscope_2ethroughElem(ptr %v1, ptr %t176)
  store i1 %t178, ptr %l91
  br label %bb49
bb49:
  %t179 = load ptr, ptr %l89, !tbaa !29
  %t180 = load i1, ptr %l91, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t179, i1 %t180)
  br label %bb50
bb50:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/scope:Scoper", ptr %t181, i32 0, i32 89
  store ptr %t183, ptr %l93, !tbaa !29
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t185 = load i32, ptr %l3, !tbaa !23
  %t188 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edeclOf(ptr %v0, ptr %t184, i32 %t185)
  store i64 %t188, ptr %l96
  br label %bb51
bb51:
  %t189 = load ptr, ptr %l93, !tbaa !29
  %t190 = load i64, ptr %l96, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t189, i64 %t190)
  br label %bb52
bb52:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/scope:Scoper", ptr %t191, i32 0, i32 87
  %t195 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t193)
  store i64 %t195, ptr %l99
  br label %bb53
bb53:
  %t196 = load i64, ptr %l99, !tbaa !24
  %t197 = sub i64 0, %t196
  %t198 = load i64, ptr %l6, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t199
  %t200 = getelementptr { i64, [2 x i64] }, ptr %t199, i32 0, i32 0
  store i64 4, ptr %t200
  %t202 = insertvalue { i64, i64 } undef, i64 %t197, 0
  %t204 = insertvalue { i64, i64 } %t202, i64 %t198, 1
  %t205 = getelementptr { i64, [2 x i64] }, ptr %t199, i32 0, i32 1
  store { i64, i64 } %t204, ptr %t205
  %t206 = load { i64, [2 x i64] }, ptr %t199
  store { i64, [2 x i64] } %t206, ptr %rv
  br label %ret
bb54:
  br i1 true, label %bb55, label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_4a18cd046f6561ba_7ee6763527d0100e)
  unreachable
bb59:
  br label %bb60
bb60:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = load ptr, ptr %l1, !tbaa !29
  %t212 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartsTerm(ptr %v0, ptr %v1, ptr %t208, ptr %t209)
  store { i64, [2 x i64] } %t212, ptr %l105
  br label %bb61
bb61:
  %t213 = load { i64, [2 x i64] }, ptr %l105
  store { i64, [2 x i64] } %t213, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflBlockOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l16 = alloca { i64, ptr }
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflStmt(ptr %v0, ptr %v1, ptr %a0, ptr %t28)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb4
bb10:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflExprRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l29 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca i1
  %l39 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca i1
  %l48 = alloca ptr
  %l51 = alloca i32
  %l52 = alloca i64
  %l55 = alloca i1
  %l63 = alloca { i64, ptr }
  %l67 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t7 = load ptr, ptr %l9, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l9, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 2
  store i1 %t13, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l10, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t17, i32 0, i32 2
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l2, !tbaa !29
  br label %bb16
bb7:
  %t21 = load ptr, ptr %l1, !tbaa !29
  store ptr %t21, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t22 = load ptr, ptr %l15, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l15, !tbaa !29
  %t26 = load i64, ptr %t25, !range !{i64 0, i64 18}
  %t28 = icmp eq i64 %t26, 3
  store i1 %t28, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t29 = load i1, ptr %l16, !tbaa !21
  br i1 %t29, label %bb10, label %bb11
bb10:
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = getelementptr { i64, [5 x i64] }, ptr %t30, i32 0, i32 1
  %t33 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t32, i32 0, i32 2
  %t34 = load ptr, ptr %t33
  store ptr %t34, ptr %l2, !tbaa !29
  br label %bb16
bb11:
  %t36 = load ptr, ptr %l1, !tbaa !29
  store ptr %t36, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t37 = load ptr, ptr %l21, !tbaa !29
  %t38 = icmp ne ptr %t37, null
  br i1 %t38, label %bb12, label %bb13
bb12:
  %t40 = load ptr, ptr %l21, !tbaa !29
  %t41 = load i64, ptr %t40, !range !{i64 0, i64 18}
  %t43 = icmp eq i64 %t41, 4
  store i1 %t43, ptr %l22, !tbaa !21
  br label %bb13
bb13:
  %t44 = load i1, ptr %l22, !tbaa !21
  br i1 %t44, label %bb14, label %bb15
bb14:
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr { i64, [5 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t47, i32 0, i32 2
  %t49 = load ptr, ptr %t48
  store ptr %t49, ptr %l2, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load ptr, ptr %l2, !tbaa !29
  %t55 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflPlaceRoot(ptr %v0, ptr %v1, ptr %t51, ptr %t52)
  store i64 %t55, ptr %l29
  br label %bb17
bb17:
  %t56 = load i64, ptr %l29, !tbaa !24
  store i64 %t56, ptr %rv
  br label %ret
bb18:
  %t57 = load ptr, ptr %l1, !tbaa !29
  store ptr %t57, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t58 = load ptr, ptr %l30, !tbaa !29
  %t59 = icmp ne ptr %t58, null
  br i1 %t59, label %bb19, label %bb20
bb19:
  %t61 = load ptr, ptr %l30, !tbaa !29
  %t62 = load i64, ptr %t61, !range !{i64 0, i64 18}
  %t64 = icmp eq i64 %t62, 17
  store i1 %t64, ptr %l31, !tbaa !21
  br label %bb20
bb20:
  %t65 = load i1, ptr %l31, !tbaa !21
  br i1 %t65, label %bb21, label %bb22
bb21:
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr { i64, [5 x i64] }, ptr %t66, i32 0, i32 1
  %t69 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t68, i32 0, i32 2
  %t70 = load ptr, ptr %t69
  store ptr %t70, ptr %l3, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load ptr, ptr %l3, !tbaa !29
  %t77 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflExprRoot(ptr %v0, ptr %v1, ptr %t72, ptr %t73)
  store i64 %t77, ptr %l39
  br label %bb24
bb24:
  %t78 = load i64, ptr %l39, !tbaa !24
  store i64 %t78, ptr %rv
  br label %ret
bb25:
  %t79 = load ptr, ptr %l1, !tbaa !29
  store ptr %t79, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t80 = load ptr, ptr %l40, !tbaa !29
  %t81 = icmp ne ptr %t80, null
  br i1 %t81, label %bb26, label %bb27
bb26:
  %t83 = load ptr, ptr %l40, !tbaa !29
  %t84 = load i64, ptr %t83, !range !{i64 0, i64 18}
  %t86 = icmp eq i64 %t84, 6
  store i1 %t86, ptr %l41, !tbaa !21
  br label %bb27
bb27:
  %t87 = load i1, ptr %l41, !tbaa !21
  br i1 %t87, label %bb28, label %bb29
bb28:
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = getelementptr { i64, [5 x i64] }, ptr %t88, i32 0, i32 1
  %t91 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t90, i32 0, i32 2
  %t92 = load ptr, ptr %t91
  store ptr %t92, ptr %l4, !tbaa !29
  br label %bb30
bb29:
  br label %bb40
bb30:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/scope:Scoper", ptr %t94, i32 0, i32 0
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t99 = getelementptr %"compiler/generic:Program", ptr %t97, i32 0, i32 2
  store ptr %t99, ptr %l48, !tbaa !29
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load ptr, ptr %l4, !tbaa !29
  %t104 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %t100, ptr %t101)
  store i32 %t104, ptr %l51
  br label %bb31
bb31:
  %t105 = load ptr, ptr %l48, !tbaa !29
  %t106 = load i32, ptr %l51, !tbaa !23
  %t107 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t105, i32 %t106, i64 0)
  store i64 %t107, ptr %l52
  br label %bb32
bb32:
  %t108 = load i64, ptr %l52, !tbaa !24
  store i64 %t108, ptr %l5, !tbaa !24
  %t109 = load i64, ptr %l5, !tbaa !24
  %t111 = icmp sge i64 %t109, 0
  br i1 %t111, label %bb33, label %bb34
bb33:
  %t113 = load i64, ptr %l5, !tbaa !24
  %t114 = load ptr, ptr %l4, !tbaa !29
  %t116 = getelementptr %"compiler/typed:Call", ptr %t114, i32 0, i32 1
  %t117 = load { i64, ptr }, ptr %t116, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t117, 0
  %t122 = icmp slt i64 %t113, %t119
  store i1 %t122, ptr %l55, !tbaa !21
  br label %bb35
bb34:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb35
bb35:
  %t124 = load i1, ptr %l55, !tbaa !21
  br i1 %t124, label %bb36, label %bb37
bb36:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load ptr, ptr %l4, !tbaa !29
  %t128 = getelementptr %"compiler/typed:Call", ptr %t126, i32 0, i32 1
  %t129 = load { i64, ptr }, ptr %t128, !tbaa !27
  store { i64, ptr } %t129, ptr %l63, !tbaa !27
  %t130 = load i64, ptr %l5, !tbaa !24
  %t132 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr ptr, ptr %t133, i64 %t130
  %t135 = load ptr, ptr %t134, !tbaa !39
  %t139 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflExprRoot(ptr %v0, ptr %v1, ptr %t125, ptr %t135)
  store i64 %t139, ptr %l67
  br label %bb38
bb37:
  br label %bb39
bb38:
  %t140 = load i64, ptr %l67, !tbaa !24
  store i64 %t140, ptr %rv
  br label %ret
bb39:
  br label %bb45
bb40:
  br i1 true, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_c246bc7b7189f7e5_d655903db3304939)
  unreachable
bb45:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egenElemTerm(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l9 = alloca i1
  %l20 = alloca ptr
  %l29 = alloca { i64, [2 x i64] }
  %rv = alloca { i64, [2 x i64] }
  %t38 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 25
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_eb63e604b2611290_41d83017cc1dec3c)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 25
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 14
  %t15 = load i1, ptr %t14, !tbaa !21
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb9
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/scope:Scoper", ptr %t19, i32 0, i32 25
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = icmp eq ptr %t22, null
  br i1 %t24, label %bb6, label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_eb63e604b2611290_41d83017cc1dec3c)
  unreachable
bb7:
  br label %bb8
bb8:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/scope:Scoper", ptr %t26, i32 0, i32 25
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Body", ptr %t29, i32 0, i32 15
  %t33 = load i32, ptr %t32, !tbaa !23
  %t35 = icmp slt i32 %t33, 0
  store i1 %t35, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t37 = load i1, ptr %l9, !tbaa !21
  br i1 %t37, label %bb10, label %bb11
bb10:
  store { i64, [2 x i64] } zeroinitializer, ptr %t38
  %t39 = getelementptr { i64, [2 x i64] }, ptr %t38, i32 0, i32 0
  store i64 0, ptr %t39
  %t40 = load { i64, [2 x i64] }, ptr %t38
  store { i64, [2 x i64] } %t40, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/scope:Scoper", ptr %t42, i32 0, i32 31
  store ptr %t44, ptr %l20, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/scope:Scoper", ptr %t45, i32 0, i32 25
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = icmp eq ptr %t48, null
  br i1 %t50, label %bb13, label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_6c6eb04d68cfd0ef_192fcc26ed37d7ab)
  unreachable
bb14:
  br label %bb15
bb15:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/scope:Scoper", ptr %t52, i32 0, i32 25
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t58 = getelementptr %"compiler/typed:Body", ptr %t55, i32 0, i32 15
  %t59 = load i32, ptr %t58, !tbaa !23
  %t61 = sext i32 %t59 to i64
  %t62 = load ptr, ptr %l20, !tbaa !29
  %t64 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t62, i64 %t61)
  store { i64, [2 x i64] } %t64, ptr %l29
  br label %bb16
bb16:
  %t65 = load { i64, [2 x i64] }, ptr %l29
  store { i64, [2 x i64] } %t65, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egenResult(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l9 = alloca i1
  %l13 = alloca i1
  %l16 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 25
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_1040a80ff621ce40_8920315fc4c3ab44)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 25
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 14
  %t15 = load i1, ptr %t14, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/scope:Scoper", ptr %t17, i32 0, i32 39
  %t20 = load i64, ptr %t19, !tbaa !24
  %t22 = icmp sge i64 %t20, 0
  store i1 %t22, ptr %l9, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l9, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load { i64, [2 x i64] }, ptr %l1
  %t27 = extractvalue { i64, [2 x i64] } %t25, 0
  %t28 = icmp eq i64 %t27, 2
  br i1 %t28, label %bb9, label %bb10
bb8:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb12
bb9:
  %t30 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t31 = getelementptr { i64 }, ptr %t30, i32 0, i32 0
  %t32 = load i64, ptr %t31
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/scope:Scoper", ptr %t33, i32 0, i32 39
  %t36 = load i64, ptr %t35, !tbaa !24
  %t39 = icmp eq i64 %t32, %t36
  store i1 %t39, ptr %l16, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb11
bb11:
  %t41 = load i1, ptr %l16, !tbaa !21
  store i1 %t41, ptr %l13, !tbaa !21
  br label %bb12
bb12:
  %t42 = load i1, ptr %l13, !tbaa !21
  store i1 %t42, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eheldCall(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i32
  %l20 = alloca %"compiler/typed:Local"
  %l25 = alloca i1
  %l33 = alloca ptr
  %l37 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 42
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  %t8 = extractvalue { i32, ptr } %t7, 1
  %t9 = extractvalue { i32, ptr } %t7, 0
  store i32 %t9, ptr %l10
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store ptr %t8, ptr %l9
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l9, !tbaa !29
  store ptr %t12, ptr %l5, !tbaa !29
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %rv
  br label %ret
bb4:
  %t14 = load ptr, ptr %l5, !tbaa !29
  store ptr %t14, ptr %l2, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/scope:Scoper", ptr %t15, i32 0, i32 25
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = icmp eq ptr %t18, null
  br i1 %t20, label %bb5, label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_eb97c951d9e697cc_139ecfedaca533c8)
  unreachable
bb6:
  br label %bb7
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/scope:Scoper", ptr %t22, i32 0, i32 25
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t28 = getelementptr %"compiler/typed:Body", ptr %t25, i32 0, i32 7
  %t29 = load i64, ptr %l1, !tbaa !24
  %t32 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t28, i64 %t29)
  store %"compiler/typed:Local" %t32, ptr %l20
  br label %bb8
bb8:
  %t33 = getelementptr %"compiler/typed:Local", ptr %l20, i32 0, i32 4
  %t34 = load i32, ptr %t33, !range !{i32 0, i32 7}
  store i32 %t34, ptr %l3
  %t36 = load i32, ptr %l3, !range !{i32 0, i32 7}
  %t38 = trunc i64 3 to i32
  %t39 = icmp eq i32 %t36, %t38
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  %t43 = load i32, ptr %l3, !range !{i32 0, i32 7}
  %t45 = trunc i64 2 to i32
  %t46 = icmp eq i32 %t43, %t45
  %t48 = xor i1 %t46, true
  store i1 %t48, ptr %l25, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb11
bb11:
  %t50 = load i1, ptr %l25, !tbaa !21
  br i1 %t50, label %bb12, label %bb13
bb12:
  store i64 -1, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t57 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallOf(ptr %v0, ptr %v0, ptr %v0, ptr %t52, ptr %t53)
  store ptr %t57, ptr %l33
  br label %bb15
bb15:
  %t58 = load ptr, ptr %l33, !tbaa !29
  store ptr %t58, ptr %l4, !tbaa !29
  %t59 = load ptr, ptr %l4, !tbaa !29
  %t61 = icmp eq ptr %t59, null
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb16, label %bb17
bb16:
  %t65 = load ptr, ptr %l4, !tbaa !29
  %t67 = getelementptr %"compiler/typed:Call", ptr %t65, i32 0, i32 3
  %t68 = load i32, ptr %t67, !tbaa !23
  %t70 = sext i32 %t68 to i64
  store i64 %t70, ptr %l37, !tbaa !24
  br label %bb18
bb17:
  store i64 -1, ptr %l37, !tbaa !24
  br label %bb18
bb18:
  %t72 = load i64, ptr %l37, !tbaa !24
  store i64 %t72, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholdsPart(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l5 = alloca i1
  %l10 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb5
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/scope:Scoper", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t16, ptr %l10
  br label %bb4
bb4:
  %t17 = load i1, ptr %l10, !tbaa !21
  store i1 %t17, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t18 = load i1, ptr %l5, !tbaa !21
  store i1 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2einstanceOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca i64
  %l10 = alloca i32
  %l14 = alloca i64
  %l17 = alloca i64
  %l38 = alloca ptr
  %rv = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  store i64 64, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t1 = load i64, ptr %l3, !tbaa !24
  %t2 = load i64, ptr %l2, !tbaa !24
  %t5 = icmp sgt i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp sgt i64 %t7, 0
  br i1 %t9, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l2, !tbaa !24
  %t15 = sub i64 %t11, %t12
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = add i64 %t15, %t16
  %t21 = sub i64 %t19, 1
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = sdiv i64 %t21, %t22
  store i64 %t25, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t27 = load i64, ptr %l17, !tbaa !24
  store i64 %t27, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t28 = load i64, ptr %l14, !tbaa !24
  store i64 %t28, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  %t29 = load i64, ptr %l6, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = icmp slt i64 %t29, %t30
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb8, label %bb9
bb8:
  br label %bb26
bb9:
  br label %bb10
bb10:
  %t37 = load i64, ptr %l2, !tbaa !24
  %t38 = load i64, ptr %l6, !tbaa !24
  %t39 = load i64, ptr %l4, !tbaa !24
  %t42 = mul i64 %t38, %t39
  %t45 = add i64 %t37, %t42
  store i64 %t45, ptr %l7, !tbaa !24
  %t49 = getelementptr %"compiler/scope:Scoper", ptr %a0, i32 0, i32 1
  %t50 = load i64, ptr %l1, !tbaa !24
  %t53 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t49, i64 %t50)
  store ptr %t53, ptr %l38
  br label %bb11
bb11:
  %t54 = load ptr, ptr %l38, !tbaa !29
  %t56 = getelementptr %"compiler/typed:Body", ptr %t54, i32 0, i32 1
  %t57 = load { i64, [2 x i64] }, ptr %t56
  store { i64, [2 x i64] } %t57, ptr %l8
  %t59 = load { i64, [2 x i64] }, ptr %l8
  %t61 = extractvalue { i64, [2 x i64] } %t59, 0
  %t62 = icmp eq i64 %t61, 0
  br i1 %t62, label %bb12, label %bb13
bb12:
  %t64 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t65 = getelementptr { i64 }, ptr %t64, i32 0, i32 0
  %t66 = load i64, ptr %t65
  store i64 %t66, ptr %l9, !tbaa !24
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t68 = load i64, ptr %l9, !tbaa !24
  store i64 %t68, ptr %rv
  br label %ret
bb15:
  %t70 = load { i64, [2 x i64] }, ptr %l8
  %t72 = extractvalue { i64, [2 x i64] } %t70, 0
  %t73 = icmp eq i64 %t72, 4
  br i1 %t73, label %bb16, label %bb17
bb16:
  %t75 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t76 = getelementptr { i32 }, ptr %t75, i32 0, i32 0
  %t77 = load i32, ptr %t76
  store i32 %t77, ptr %l10, !tbaa !23
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t79 = load i32, ptr %l10, !tbaa !23
  %t81 = sext i32 %t79 to i64
  store i64 %t81, ptr %l1, !tbaa !24
  br label %bb24
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  store i64 -1, ptr %rv
  br label %ret
bb23:
  call void @__olang_check_failed(ptr @olang_loc_e2ea0fea769db7e4_aa8c1e0e7de89fc8)
  unreachable
bb24:
  br label %bb25
bb25:
  %t84 = load i64, ptr %l6, !tbaa !24
  %t86 = add i64 %t84, 1
  store i64 %t86, ptr %l6, !tbaa !24
  br label %bb7
bb26:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l15 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l43 = alloca i1
  %l44 = alloca i1
  %l46 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i1
  %l57 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca i1
  %l67 = alloca i1
  %l68 = alloca ptr
  %l69 = alloca i1
  %l77 = alloca i1
  %l78 = alloca ptr
  %l79 = alloca i1
  %l87 = alloca i1
  %l88 = alloca i1
  %l93 = alloca i1
  %l94 = alloca i1
  %l98 = alloca i1
  %l99 = alloca i1
  %l104 = alloca i1
  %l105 = alloca ptr
  %l106 = alloca i1
  %l113 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca i1
  %l123 = alloca i1
  %l124 = alloca i1
  %l128 = alloca i1
  %l130 = alloca { i64, ptr }
  %l133 = alloca i1
  %l134 = alloca ptr
  %l135 = alloca i1
  %l142 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t7 = load ptr, ptr %l16, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l16, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 5
  store i1 %t13, ptr %l17, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l17, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  br label %bb16
bb7:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t16 = load ptr, ptr %l20, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb8, label %bb9
bb8:
  %t19 = load ptr, ptr %l20, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 18}
  %t22 = icmp eq i64 %t20, 7
  store i1 %t22, ptr %l21, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l21, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  br label %bb16
bb11:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t25 = load ptr, ptr %l24, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb12, label %bb13
bb12:
  %t28 = load ptr, ptr %l24, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 18}
  %t31 = icmp eq i64 %t29, 8
  store i1 %t31, ptr %l25, !tbaa !21
  br label %bb13
bb13:
  %t32 = load i1, ptr %l25, !tbaa !21
  br i1 %t32, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb107
bb17:
  %t33 = load ptr, ptr %l1, !tbaa !29
  store ptr %t33, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t34 = load ptr, ptr %l28, !tbaa !29
  %t35 = icmp ne ptr %t34, null
  br i1 %t35, label %bb18, label %bb19
bb18:
  %t37 = load ptr, ptr %l28, !tbaa !29
  %t38 = load i64, ptr %t37, !range !{i64 0, i64 18}
  %t40 = icmp eq i64 %t38, 16
  store i1 %t40, ptr %l29, !tbaa !21
  br label %bb19
bb19:
  %t41 = load i1, ptr %l29, !tbaa !21
  br i1 %t41, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb107
bb23:
  %t42 = load ptr, ptr %l1, !tbaa !29
  store ptr %t42, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t43 = load ptr, ptr %l32, !tbaa !29
  %t44 = icmp ne ptr %t43, null
  br i1 %t44, label %bb24, label %bb25
bb24:
  %t46 = load ptr, ptr %l32, !tbaa !29
  %t47 = load i64, ptr %t46, !range !{i64 0, i64 18}
  %t49 = icmp eq i64 %t47, 6
  store i1 %t49, ptr %l33, !tbaa !21
  br label %bb25
bb25:
  %t50 = load i1, ptr %l33, !tbaa !21
  br i1 %t50, label %bb26, label %bb27
bb26:
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr { i64, [5 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t53, i32 0, i32 1
  %t55 = load i32, ptr %t54
  store i32 %t55, ptr %l2, !tbaa !23
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr { i64, [5 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t59, i32 0, i32 2
  %t61 = load ptr, ptr %t60
  store ptr %t61, ptr %l3, !tbaa !29
  br label %bb28
bb27:
  br label %bb34
bb28:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load ptr, ptr %l3, !tbaa !29
  %t65 = load i32, ptr %l2, !tbaa !23
  %t69 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallBuilds(ptr %v0, ptr %v1, ptr %t63, ptr %t64, i32 %t65)
  store i1 %t69, ptr %l43
  br label %bb29
bb29:
  %t70 = load i1, ptr %l43, !tbaa !21
  br i1 %t70, label %bb30, label %bb31
bb30:
  %t71 = load ptr, ptr %l3, !tbaa !29
  %t73 = call i1 @compiler_2ftyped_2eScopedCall(ptr %v1, ptr %t71)
  store i1 %t73, ptr %l46
  br label %bb32
bb31:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb33
bb32:
  %t74 = load i1, ptr %l46, !tbaa !21
  %t75 = xor i1 %t74, true
  store i1 %t75, ptr %l44, !tbaa !21
  br label %bb33
bb33:
  %t77 = load i1, ptr %l44, !tbaa !21
  store i1 %t77, ptr %l15, !tbaa !21
  br label %bb107
bb34:
  %t78 = load ptr, ptr %l1, !tbaa !29
  store ptr %t78, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t79 = load ptr, ptr %l48, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb35, label %bb36
bb35:
  %t82 = load ptr, ptr %l48, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 18}
  %t85 = icmp eq i64 %t83, 12
  store i1 %t85, ptr %l49, !tbaa !21
  br label %bb36
bb36:
  %t86 = load i1, ptr %l49, !tbaa !21
  br i1 %t86, label %bb37, label %bb38
bb37:
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 2
  %t91 = load ptr, ptr %t90
  store ptr %t91, ptr %l4, !tbaa !29
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load ptr, ptr %l4, !tbaa !29
  %t96 = getelementptr %"compiler/typed:Seq", ptr %t94, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t100 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %t93, ptr %t97)
  store i1 %t100, ptr %l57
  br label %bb40
bb40:
  %t101 = load i1, ptr %l57, !tbaa !21
  store i1 %t101, ptr %l15, !tbaa !21
  br label %bb107
bb41:
  %t102 = load ptr, ptr %l1, !tbaa !29
  store ptr %t102, ptr %l58, !tbaa !29
  store i1 false, ptr %l59, !tbaa !21
  %t103 = load ptr, ptr %l58, !tbaa !29
  %t104 = icmp ne ptr %t103, null
  br i1 %t104, label %bb42, label %bb43
bb42:
  %t106 = load ptr, ptr %l58, !tbaa !29
  %t107 = load i64, ptr %t106, !range !{i64 0, i64 18}
  %t109 = icmp eq i64 %t107, 17
  store i1 %t109, ptr %l59, !tbaa !21
  br label %bb43
bb43:
  %t110 = load i1, ptr %l59, !tbaa !21
  br i1 %t110, label %bb44, label %bb45
bb44:
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = getelementptr { i64, [5 x i64] }, ptr %t111, i32 0, i32 1
  %t114 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t113, i32 0, i32 2
  %t115 = load ptr, ptr %t114
  store ptr %t115, ptr %l5, !tbaa !29
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load ptr, ptr %l5, !tbaa !29
  %t122 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %t117, ptr %t118)
  store i1 %t122, ptr %l67
  br label %bb47
bb47:
  %t123 = load i1, ptr %l67, !tbaa !21
  store i1 %t123, ptr %l15, !tbaa !21
  br label %bb107
bb48:
  %t124 = load ptr, ptr %l1, !tbaa !29
  store ptr %t124, ptr %l68, !tbaa !29
  store i1 false, ptr %l69, !tbaa !21
  %t125 = load ptr, ptr %l68, !tbaa !29
  %t126 = icmp ne ptr %t125, null
  br i1 %t126, label %bb49, label %bb50
bb49:
  %t128 = load ptr, ptr %l68, !tbaa !29
  %t129 = load i64, ptr %t128, !range !{i64 0, i64 18}
  %t131 = icmp eq i64 %t129, 14
  store i1 %t131, ptr %l69, !tbaa !21
  br label %bb50
bb50:
  %t132 = load i1, ptr %l69, !tbaa !21
  br i1 %t132, label %bb51, label %bb52
bb51:
  %t133 = load ptr, ptr %l1, !tbaa !29
  %t135 = getelementptr { i64, [5 x i64] }, ptr %t133, i32 0, i32 1
  %t136 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t135, i32 0, i32 2
  %t137 = load ptr, ptr %t136
  store ptr %t137, ptr %l6, !tbaa !29
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load ptr, ptr %l6, !tbaa !29
  %t142 = getelementptr %"compiler/typed:Try", ptr %t140, i32 0, i32 0
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t146 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %t139, ptr %t143)
  store i1 %t146, ptr %l77
  br label %bb54
bb54:
  %t147 = load i1, ptr %l77, !tbaa !21
  store i1 %t147, ptr %l15, !tbaa !21
  br label %bb107
bb55:
  %t148 = load ptr, ptr %l1, !tbaa !29
  store ptr %t148, ptr %l78, !tbaa !29
  store i1 false, ptr %l79, !tbaa !21
  %t149 = load ptr, ptr %l78, !tbaa !29
  %t150 = icmp ne ptr %t149, null
  br i1 %t150, label %bb56, label %bb57
bb56:
  %t152 = load ptr, ptr %l78, !tbaa !29
  %t153 = load i64, ptr %t152, !range !{i64 0, i64 18}
  %t155 = icmp eq i64 %t153, 11
  store i1 %t155, ptr %l79, !tbaa !21
  br label %bb57
bb57:
  %t156 = load i1, ptr %l79, !tbaa !21
  br i1 %t156, label %bb58, label %bb59
bb58:
  %t157 = load ptr, ptr %l1, !tbaa !29
  %t159 = getelementptr { i64, [5 x i64] }, ptr %t157, i32 0, i32 1
  %t160 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t159, i32 0, i32 2
  %t161 = load ptr, ptr %t160
  store ptr %t161, ptr %l7, !tbaa !29
  br label %bb60
bb59:
  br label %bb74
bb60:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load ptr, ptr %l7, !tbaa !29
  %t166 = getelementptr %"compiler/typed:Cond", ptr %t164, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t170 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enewOrConst(ptr %v0, ptr %v1, ptr %t163, ptr %t167)
  store i1 %t170, ptr %l87
  br label %bb61
bb61:
  %t171 = load i1, ptr %l87, !tbaa !21
  br i1 %t171, label %bb62, label %bb63
bb62:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load ptr, ptr %l7, !tbaa !29
  %t175 = getelementptr %"compiler/typed:Cond", ptr %t173, i32 0, i32 2
  %t176 = load ptr, ptr %t175, !tbaa !29
  %t180 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enewOrConst(ptr %v0, ptr %v1, ptr %t172, ptr %t176)
  store i1 %t180, ptr %l93
  br label %bb64
bb63:
  store i1 false, ptr %l88, !tbaa !21
  br label %bb65
bb64:
  %t181 = load i1, ptr %l93, !tbaa !21
  store i1 %t181, ptr %l88, !tbaa !21
  br label %bb65
bb65:
  %t182 = load i1, ptr %l88, !tbaa !21
  br i1 %t182, label %bb66, label %bb67
bb66:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load ptr, ptr %l7, !tbaa !29
  %t186 = getelementptr %"compiler/typed:Cond", ptr %t184, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !29
  %t190 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %t183, ptr %t187)
  store i1 %t190, ptr %l98
  br label %bb68
bb67:
  store i1 false, ptr %l94, !tbaa !21
  br label %bb73
bb68:
  %t191 = load i1, ptr %l98, !tbaa !21
  br i1 %t191, label %bb69, label %bb70
bb69:
  store i1 true, ptr %l99, !tbaa !21
  br label %bb72
bb70:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t193 = load ptr, ptr %l7, !tbaa !29
  %t195 = getelementptr %"compiler/typed:Cond", ptr %t193, i32 0, i32 2
  %t196 = load ptr, ptr %t195, !tbaa !29
  %t200 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %t192, ptr %t196)
  store i1 %t200, ptr %l104
  br label %bb71
bb71:
  %t201 = load i1, ptr %l104, !tbaa !21
  store i1 %t201, ptr %l99, !tbaa !21
  br label %bb72
bb72:
  %t202 = load i1, ptr %l99, !tbaa !21
  store i1 %t202, ptr %l94, !tbaa !21
  br label %bb73
bb73:
  %t203 = load i1, ptr %l94, !tbaa !21
  store i1 %t203, ptr %l15, !tbaa !21
  br label %bb107
bb74:
  %t204 = load ptr, ptr %l1, !tbaa !29
  store ptr %t204, ptr %l105, !tbaa !29
  store i1 false, ptr %l106, !tbaa !21
  %t205 = load ptr, ptr %l105, !tbaa !29
  %t206 = icmp ne ptr %t205, null
  br i1 %t206, label %bb75, label %bb76
bb75:
  %t208 = load ptr, ptr %l105, !tbaa !29
  %t209 = load i64, ptr %t208, !range !{i64 0, i64 18}
  %t211 = icmp eq i64 %t209, 13
  store i1 %t211, ptr %l106, !tbaa !21
  br label %bb76
bb76:
  %t212 = load i1, ptr %l106, !tbaa !21
  br i1 %t212, label %bb77, label %bb78
bb77:
  %t213 = load ptr, ptr %l1, !tbaa !29
  %t215 = getelementptr { i64, [5 x i64] }, ptr %t213, i32 0, i32 1
  %t216 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t215, i32 0, i32 2
  %t217 = load ptr, ptr %t216
  store ptr %t217, ptr %l8, !tbaa !29
  br label %bb79
bb78:
  br label %bb81
bb79:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load ptr, ptr %l8, !tbaa !29
  %t223 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ematchFresh(ptr %v0, ptr %v1, ptr %t219, ptr %t220)
  store i1 %t223, ptr %l113
  br label %bb80
bb80:
  %t224 = load i1, ptr %l113, !tbaa !21
  store i1 %t224, ptr %l15, !tbaa !21
  br label %bb107
bb81:
  %t225 = load ptr, ptr %l1, !tbaa !29
  store ptr %t225, ptr %l114, !tbaa !29
  store i1 false, ptr %l115, !tbaa !21
  %t226 = load ptr, ptr %l114, !tbaa !29
  %t227 = icmp ne ptr %t226, null
  br i1 %t227, label %bb82, label %bb83
bb82:
  %t229 = load ptr, ptr %l114, !tbaa !29
  %t230 = load i64, ptr %t229, !range !{i64 0, i64 18}
  %t232 = icmp eq i64 %t230, 9
  store i1 %t232, ptr %l115, !tbaa !21
  br label %bb83
bb83:
  %t233 = load i1, ptr %l115, !tbaa !21
  br i1 %t233, label %bb84, label %bb85
bb84:
  %t234 = load ptr, ptr %l1, !tbaa !29
  %t236 = getelementptr { i64, [5 x i64] }, ptr %t234, i32 0, i32 1
  %t237 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t236, i32 0, i32 2
  %t238 = load i32, ptr %t237, !range !{i32 0, i32 43}
  store i32 %t238, ptr %l9
  %t240 = load ptr, ptr %l1, !tbaa !29
  %t242 = getelementptr { i64, [5 x i64] }, ptr %t240, i32 0, i32 1
  %t243 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t242, i32 0, i32 4
  %t244 = load { i64, ptr }, ptr %t243
  store { i64, ptr } %t244, ptr %l10, !tbaa !27
  br label %bb86
bb85:
  br label %bb95
bb86:
  %t246 = load i32, ptr %l9, !range !{i32 0, i32 43}
  %t248 = call i1 @compiler_2ftyped_2ePassesRefs(i32 %t246)
  store i1 %t248, ptr %l123
  br label %bb87
bb87:
  %t249 = load i1, ptr %l123, !tbaa !21
  br i1 %t249, label %bb88, label %bb89
bb88:
  %t250 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t250, 0
  %t254 = icmp sgt i64 %t252, 0
  store i1 %t254, ptr %l124, !tbaa !21
  br label %bb90
bb89:
  store i1 false, ptr %l124, !tbaa !21
  br label %bb90
bb90:
  %t256 = load i1, ptr %l124, !tbaa !21
  br i1 %t256, label %bb91, label %bb92
bb91:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t258, ptr %l130, !tbaa !27
  %t259 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t260 = load ptr, ptr %t259, !tbaa !27
  %t261 = getelementptr ptr, ptr %t260, i64 0
  %t262 = load ptr, ptr %t261, !tbaa !39
  %t266 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %t257, ptr %t262)
  store i1 %t266, ptr %l133
  br label %bb93
bb92:
  store i1 false, ptr %l128, !tbaa !21
  br label %bb94
bb93:
  %t267 = load i1, ptr %l133, !tbaa !21
  store i1 %t267, ptr %l128, !tbaa !21
  br label %bb94
bb94:
  %t268 = load i1, ptr %l128, !tbaa !21
  store i1 %t268, ptr %l15, !tbaa !21
  br label %bb107
bb95:
  %t269 = load ptr, ptr %l1, !tbaa !29
  store ptr %t269, ptr %l134, !tbaa !29
  store i1 false, ptr %l135, !tbaa !21
  %t270 = load ptr, ptr %l134, !tbaa !29
  %t271 = icmp ne ptr %t270, null
  br i1 %t271, label %bb96, label %bb97
bb96:
  %t273 = load ptr, ptr %l134, !tbaa !29
  %t274 = load i64, ptr %t273, !range !{i64 0, i64 18}
  %t276 = icmp eq i64 %t274, 15
  store i1 %t276, ptr %l135, !tbaa !21
  br label %bb97
bb97:
  %t277 = load i1, ptr %l135, !tbaa !21
  br i1 %t277, label %bb98, label %bb99
bb98:
  %t278 = load ptr, ptr %l1, !tbaa !29
  %t280 = getelementptr { i64, [5 x i64] }, ptr %t278, i32 0, i32 1
  %t281 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t280, i32 0, i32 2
  %t282 = load ptr, ptr %t281
  store ptr %t282, ptr %l11, !tbaa !29
  br label %bb100
bb99:
  br label %bb102
bb100:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load ptr, ptr %l11, !tbaa !29
  %t288 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efnFresh(ptr %v0, ptr %v1, ptr %t284, ptr %t285)
  store i1 %t288, ptr %l142
  br label %bb101
bb101:
  %t289 = load i1, ptr %l142, !tbaa !21
  store i1 %t289, ptr %l15, !tbaa !21
  br label %bb107
bb102:
  br i1 true, label %bb103, label %bb104
bb103:
  br label %bb105
bb104:
  br label %bb106
bb105:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb107
bb106:
  call void @__olang_check_failed(ptr @olang_loc_2daf47a1d2ffcaba_d6a7daf55d290cb6)
  unreachable
bb107:
  %t290 = load i1, ptr %l15, !tbaa !21
  store i1 %t290, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisNumberLike(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l6 = alloca i1
  %l7 = alloca i1
  %l12 = alloca i32
  %l20 = alloca i32
  %l23 = alloca i1
  %l28 = alloca i1
  %l29 = alloca i1
  %l32 = alloca ptr
  %l37 = alloca i32
  %l38 = alloca i32
  %l41 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l6
  br label %bb1
bb1:
  %t11 = load i1, ptr %l6, !tbaa !21
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb5
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/scope:Scoper", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %l1, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l12
  br label %bb4
bb4:
  %t22 = load i32, ptr %l12, !range !{i32 0, i32 33}
  %t24 = trunc i64 2 to i32
  %t25 = icmp eq i32 %t22, %t24
  store i1 %t25, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t27 = load i1, ptr %l7, !tbaa !21
  br i1 %t27, label %bb6, label %bb7
bb6:
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/scope:Scoper", ptr %t29, i32 0, i32 0
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t35 = load i32, ptr %l1, !tbaa !23
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t38, ptr %l20
  br label %bb9
bb9:
  %t39 = load i32, ptr %l20, !range !{i32 0, i32 33}
  %t41 = trunc i64 18 to i32
  %t42 = icmp eq i32 %t39, %t41
  br i1 %t42, label %bb10, label %bb11
bb10:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/scope:Scoper", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  %t50 = load i32, ptr %l1, !tbaa !23
  %t53 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t49, i32 %t50)
  store i1 %t53, ptr %l28
  br label %bb12
bb11:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb13
bb12:
  %t54 = load i1, ptr %l28, !tbaa !21
  store i1 %t54, ptr %l23, !tbaa !21
  br label %bb13
bb13:
  %t55 = load i1, ptr %l23, !tbaa !21
  br i1 %t55, label %bb14, label %bb15
bb14:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/scope:Scoper", ptr %t56, i32 0, i32 0
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  store ptr %t61, ptr %l32, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/scope:Scoper", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %l1, !tbaa !23
  %t71 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t67, i32 %t68)
  store i32 %t71, ptr %l37
  br label %bb16
bb15:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb18
bb16:
  %t72 = load ptr, ptr %l32, !tbaa !29
  %t73 = load i32, ptr %l37, !tbaa !23
  %t74 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t72, i32 %t73)
  store i32 %t74, ptr %l38
  br label %bb17
bb17:
  %t75 = load i32, ptr %l38, !range !{i32 0, i32 6}
  %t77 = trunc i64 4 to i32
  %t78 = icmp eq i32 %t75, %t77
  store i1 %t78, ptr %l29, !tbaa !21
  br label %bb18
bb18:
  %t80 = load i1, ptr %l29, !tbaa !21
  br i1 %t80, label %bb19, label %bb20
bb19:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l41, !tbaa !29
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/scope:Scoper", ptr %t82, i32 0, i32 0
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = getelementptr %"compiler/generic:Program", ptr %t85, i32 0, i32 2
  %t88 = load i32, ptr %l1, !tbaa !23
  %t91 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t87, i32 %t88)
  store i32 %t91, ptr %l46
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t92 = load ptr, ptr %l41, !tbaa !29
  %t93 = load i32, ptr %l46, !tbaa !23
  %t94 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisNumberLike(ptr %v0, ptr %t92, i32 %t93)
  store i1 %t94, ptr %l47
  br label %bb22
bb22:
  %t95 = load i1, ptr %l47, !tbaa !21
  store i1 %t95, ptr %rv
  br label %ret
bb23:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisStr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca ptr
  %l21 = alloca i1
  %l24 = alloca i64
  %l33 = alloca { i64, ptr }
  %l35 = alloca i1
  %l36 = alloca i1
  %l38 = alloca i1
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Body", ptr %t1, i32 0, i32 1
  %t4 = load { i64, [2 x i64] }, ptr %t3
  store { i64, [2 x i64] } %t4, ptr %l2
  %t6 = load { i64, [2 x i64] }, ptr %l2
  %t8 = extractvalue { i64, [2 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t12 = getelementptr { i64 }, ptr %t11, i32 0, i32 0
  %t13 = load i64, ptr %t12
  store i64 %t13, ptr %l3, !tbaa !24
  br label %bb3
bb2:
  br label %bb19
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/scope:Scoper", ptr %t15, i32 0, i32 0
  %t18 = load ptr, ptr %t17, !tbaa !29
  store ptr %t18, ptr %l12, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/scope:Scoper", ptr %t19, i32 0, i32 0
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t22, i64 %t23)
  store i64 %t26, ptr %l16
  br label %bb4
bb4:
  %t27 = load ptr, ptr %l12, !tbaa !29
  %t28 = load i64, ptr %l16, !tbaa !24
  %t29 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t27, i64 %t28)
  store ptr %t29, ptr %l17
  br label %bb5
bb5:
  %t30 = load ptr, ptr %l17, !tbaa !29
  store ptr %t30, ptr %l4, !tbaa !29
  %t31 = load ptr, ptr %l4, !tbaa !29
  %t33 = getelementptr %"compiler/ast:Func", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = icmp eq ptr %t34, null
  br i1 %t36, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb9
bb7:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Body", ptr %t38, i32 0, i32 5
  %t42 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v1, ptr %t40)
  store i64 %t42, ptr %l24
  br label %bb8
bb8:
  %t43 = load i64, ptr %l24, !tbaa !24
  %t44 = icmp ne i64 %t43, 1
  store i1 %t44, ptr %l21, !tbaa !21
  br label %bb9
bb9:
  %t46 = load i1, ptr %l21, !tbaa !21
  br i1 %t46, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/scope:Scoper", ptr %t48, i32 0, i32 0
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = getelementptr %"compiler/generic:Program", ptr %t51, i32 0, i32 0
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/load:Loader", ptr %t54, i32 0, i32 3
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t58 = load ptr, ptr %l4, !tbaa !29
  %t60 = getelementptr %"compiler/ast:Func", ptr %t58, i32 0, i32 2
  %t61 = load i32, ptr %t60, !tbaa !23
  %t64 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t57, i32 %t61)
  store { i64, ptr } %t64, ptr %l33
  br label %bb13
bb13:
  %t65 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t65, ptr %l5, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t68 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t66, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d20, i32 0, i32 1) })
  store i1 %t68, ptr %l35
  br label %bb14
bb14:
  %t69 = load i1, ptr %l35, !tbaa !21
  br i1 %t69, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb18
bb16:
  %t70 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t72 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t70, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d21, i32 0, i32 1) })
  store i1 %t72, ptr %l38
  br label %bb17
bb17:
  %t73 = load i1, ptr %l38, !tbaa !21
  store i1 %t73, ptr %l36, !tbaa !21
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s1)
  %t74 = load i1, ptr %l36, !tbaa !21
  store i1 %t74, ptr %rv
  br label %ret
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  store i1 false, ptr %rv
  br label %ret
bb23:
  call void @__olang_check_failed(ptr @olang_loc_23c81803d40008f7_62b49cfbea8bbbfb)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ejoin(ptr %v0, ptr %a0, %"compiler/scope:Val" %a1, %"compiler/scope:Val" %a2, { i64, [2 x i64] } %a3) #0 {
entry:
  %l1 = alloca %"compiler/scope:Val"
  %l2 = alloca %"compiler/scope:Val"
  %l3 = alloca { i64, [2 x i64] }
  %l12 = alloca i1
  %l18 = alloca i1
  %l22 = alloca { i64, [2 x i64] }
  %l24 = alloca { i64, [2 x i64] }
  %l26 = alloca i1
  %l29 = alloca i1
  %l32 = alloca i32
  %l36 = alloca %"compiler/scope:Val"
  %l40 = alloca { i64, [2 x i64] }
  %l41 = alloca %"compiler/scope:Val"
  %s5 = alloca %olang.scope
  %rv = alloca %"compiler/scope:Val"
  store %"compiler/scope:Val" %a1, ptr %l1
  store %"compiler/scope:Val" %a2, ptr %l2
  store { i64, [2 x i64] } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/scope:Val", ptr %l1, i32 0, i32 0
  %t2 = load i32, ptr %t1, !range !{i32 0, i32 5}
  %t4 = trunc i64 0 to i32
  %t5 = icmp eq i32 %t2, %t4
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load %"compiler/scope:Val", ptr %l2
  store %"compiler/scope:Val" %t7, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = getelementptr %"compiler/scope:Val", ptr %l2, i32 0, i32 0
  %t10 = load i32, ptr %t9, !range !{i32 0, i32 5}
  %t12 = trunc i64 0 to i32
  %t13 = icmp eq i32 %t10, %t12
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t15 = load %"compiler/scope:Val", ptr %l1
  store %"compiler/scope:Val" %t15, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t17 = getelementptr %"compiler/scope:Val", ptr %l1, i32 0, i32 0
  %t18 = load i32, ptr %t17, !range !{i32 0, i32 5}
  %t20 = trunc i64 1 to i32
  %t21 = icmp eq i32 %t18, %t20
  br i1 %t21, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb9
bb8:
  %t23 = getelementptr %"compiler/scope:Val", ptr %l1, i32 0, i32 0
  %t24 = load i32, ptr %t23, !range !{i32 0, i32 5}
  %t26 = trunc i64 4 to i32
  %t27 = icmp eq i32 %t24, %t26
  store i1 %t27, ptr %l12, !tbaa !21
  br label %bb9
bb9:
  %t29 = load i1, ptr %l12, !tbaa !21
  br i1 %t29, label %bb10, label %bb11
bb10:
  %t30 = load %"compiler/scope:Val", ptr %l2
  store %"compiler/scope:Val" %t30, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t32 = getelementptr %"compiler/scope:Val", ptr %l2, i32 0, i32 0
  %t33 = load i32, ptr %t32, !range !{i32 0, i32 5}
  %t35 = trunc i64 1 to i32
  %t36 = icmp eq i32 %t33, %t35
  br i1 %t36, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb15
bb14:
  %t38 = getelementptr %"compiler/scope:Val", ptr %l2, i32 0, i32 0
  %t39 = load i32, ptr %t38, !range !{i32 0, i32 5}
  %t41 = trunc i64 4 to i32
  %t42 = icmp eq i32 %t39, %t41
  store i1 %t42, ptr %l18, !tbaa !21
  br label %bb15
bb15:
  %t44 = load i1, ptr %l18, !tbaa !21
  br i1 %t44, label %bb16, label %bb17
bb16:
  %t45 = load %"compiler/scope:Val", ptr %l1
  store %"compiler/scope:Val" %t45, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t47 = getelementptr %"compiler/scope:Val", ptr %l1, i32 0, i32 1
  %t48 = load { i64, [2 x i64] }, ptr %t47
  store { i64, [2 x i64] } %t48, ptr %l22
  %t49 = getelementptr %"compiler/scope:Val", ptr %l2, i32 0, i32 1
  %t50 = load { i64, [2 x i64] }, ptr %t49
  store { i64, [2 x i64] } %t50, ptr %l24
  %t53 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l22, ptr %l24)
  store i1 %t53, ptr %l26
  br label %bb19
bb19:
  %t54 = load i1, ptr %l26, !tbaa !21
  br i1 %t54, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s5
  %t55 = getelementptr %"compiler/scope:Val", ptr %l1, i32 0, i32 0
  %t56 = load i32, ptr %t55, !range !{i32 0, i32 5}
  %t58 = trunc i64 3 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb22, label %bb23
bb21:
  br label %bb29
bb22:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb24
bb23:
  %t61 = getelementptr %"compiler/scope:Val", ptr %l2, i32 0, i32 0
  %t62 = load i32, ptr %t61, !range !{i32 0, i32 5}
  %t64 = trunc i64 3 to i32
  %t65 = icmp eq i32 %t62, %t64
  store i1 %t65, ptr %l29, !tbaa !21
  br label %bb24
bb24:
  %t67 = load i1, ptr %l29, !tbaa !21
  br i1 %t67, label %bb25, label %bb26
bb25:
  store i32 3, ptr %l32
  br label %bb27
bb26:
  %t69 = getelementptr %"compiler/scope:Val", ptr %l1, i32 0, i32 0
  %t70 = load i32, ptr %t69, !range !{i32 0, i32 5}
  store i32 %t70, ptr %l32
  br label %bb27
bb27:
  %t72 = getelementptr %"compiler/scope:Val", ptr %l1, i32 0, i32 1
  %t73 = load { i64, [2 x i64] }, ptr %t72
  %t74 = load i32, ptr %l32, !range !{i32 0, i32 5}
  %t76 = call %"compiler/scope:Val" @compiler_2fscope_3aVal_2ector(ptr %s5, i32 %t74, { i64, [2 x i64] } %t73)
  store %"compiler/scope:Val" %t76, ptr %l36
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s5)
  %t77 = load %"compiler/scope:Val", ptr %l36
  store %"compiler/scope:Val" %t77, ptr %rv
  br label %ret
bb29:
  %t79 = getelementptr %"compiler/scope:Val", ptr %l1, i32 0, i32 1
  %t80 = load { i64, [2 x i64] }, ptr %t79
  %t81 = getelementptr %"compiler/scope:Val", ptr %l2, i32 0, i32 1
  %t82 = load { i64, [2 x i64] }, ptr %t81
  %t86 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esetOf(ptr %v0, ptr %a0, { i64, [2 x i64] } %t80, { i64, [2 x i64] } %t82)
  store { i64, [2 x i64] } %t86, ptr %l40
  br label %bb30
bb30:
  %t87 = load { i64, [2 x i64] }, ptr %l40
  %t88 = call %"compiler/scope:Val" @compiler_2fscope_2eexisting({ i64, [2 x i64] } %t87)
  store %"compiler/scope:Val" %t88, ptr %l41
  br label %bb31
bb31:
  %t89 = load %"compiler/scope:Val", ptr %l41
  store %"compiler/scope:Val" %t89, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scope:Val", ptr %rv
  ret %"compiler/scope:Val" %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekeepsStorage(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i1
  %l17 = alloca i64
  %l20 = alloca i1
  %l21 = alloca ptr
  %l30 = alloca %"compiler/typed:Local"
  %l32 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t6 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s0, ptr %t1, ptr %a1)
  store ptr %t6, ptr %l8
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l8, !tbaa !29
  %t8 = call ptr @compiler_2fscope_2eunPassed(ptr %s0, ptr %s0, ptr %t7)
  store ptr %t8, ptr %l9
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l9, !tbaa !29
  store ptr %t9, ptr %l2, !tbaa !29
  %t10 = load ptr, ptr %l2, !tbaa !29
  store ptr %t10, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t11 = load ptr, ptr %l10, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load ptr, ptr %l10, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 18}
  %t17 = icmp eq i64 %t15, 3
  store i1 %t17, ptr %l11, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l11, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = getelementptr { i64, [5 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l3, !tbaa !29
  br label %bb7
bb6:
  br label %bb17
bb7:
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t27 = call i64 @compiler_2fscope_2ewholeLocal(ptr %s0, ptr %t25)
  store i64 %t27, ptr %l17
  br label %bb8
bb8:
  %t28 = load i64, ptr %l17, !tbaa !24
  store i64 %t28, ptr %l4, !tbaa !24
  %t29 = load i64, ptr %l4, !tbaa !24
  %t31 = icmp sge i64 %t29, 0
  br i1 %t31, label %bb9, label %bb10
bb9:
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l21, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/scope:Scoper", ptr %t34, i32 0, i32 25
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  br i1 %t39, label %bb11, label %bb12
bb10:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb16
bb11:
  call void @__olang_check_failed(ptr @olang_loc_3e5632f45eefd04_2819d69fa7782c38)
  unreachable
bb12:
  br label %bb13
bb13:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/scope:Scoper", ptr %t41, i32 0, i32 25
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t47 = getelementptr %"compiler/typed:Body", ptr %t44, i32 0, i32 7
  %t48 = load i64, ptr %l4, !tbaa !24
  %t51 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t47, i64 %t48)
  store %"compiler/typed:Local" %t51, ptr %l30
  br label %bb14
bb14:
  %t52 = getelementptr %"compiler/typed:Local", ptr %l30, i32 0, i32 2
  %t53 = load i32, ptr %t52, !tbaa !23
  %t54 = load ptr, ptr %l21, !tbaa !29
  %t56 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t54, i32 %t53)
  store i1 %t56, ptr %l32
  br label %bb15
bb15:
  %t57 = load i1, ptr %l32, !tbaa !21
  %t58 = xor i1 %t57, true
  store i1 %t58, ptr %l20, !tbaa !21
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s0)
  %t60 = load i1, ptr %l20, !tbaa !21
  store i1 %t60, ptr %rv
  br label %ret
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb21:
  call void @__olang_check_failed(ptr @olang_loc_754a4fe24afb426a_2a858937208e2b6e)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwArm(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l21 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Arm", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb17
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t22, ptr %l21, !tbaa !27
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l6, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l6, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Alt", ptr %t31, i32 0, i32 0
  %t34 = load ptr, ptr %t33, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwExpr(ptr %v0, ptr %v1, ptr %t30, ptr %t34, i1 true)
  br label %bb8
bb8:
  %t38 = load ptr, ptr %l6, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Alt", ptr %t38, i32 0, i32 1
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  store i64 %t45, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  %t47 = load i64, ptr %l8, !tbaa !24
  %t48 = load i64, ptr %l9, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb10, label %bb11
bb10:
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t55 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t55, ptr %l36, !tbaa !27
  %t56 = load i64, ptr %l8, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr ptr, ptr %t59, i64 %t56
  %t61 = load ptr, ptr %t60, !tbaa !39
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/typed:Bind", ptr %t61, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwExpr(ptr %v0, ptr %v1, ptr %t63, ptr %t67, i1 false)
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t71 = load i64, ptr %l8, !tbaa !24
  %t73 = add i64 %t71, 1
  store i64 %t73, ptr %l8, !tbaa !24
  br label %bb9
bb15:
  br label %bb16
bb16:
  %t75 = load i64, ptr %l4, !tbaa !24
  %t77 = add i64 %t75, 1
  store i64 %t77, ptr %l4, !tbaa !24
  br label %bb4
bb17:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t82 = getelementptr %"compiler/typed:Arm", ptr %t80, i32 0, i32 2
  %t83 = load ptr, ptr %t82, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwExpr(ptr %v0, ptr %v1, ptr %t79, ptr %t83, i1 true)
  br label %bb18
bb18:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t89 = getelementptr %"compiler/typed:Arm", ptr %t87, i32 0, i32 3
  %t90 = load ptr, ptr %t89, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwBlock(ptr %v0, ptr %v1, ptr %t86, ptr %t90)
  br label %bb19
bb19:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t96 = getelementptr %"compiler/typed:Arm", ptr %t94, i32 0, i32 4
  %t97 = load ptr, ptr %t96, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwExpr(ptr %v0, ptr %v1, ptr %t93, ptr %t97, i1 %a2)
  br label %bb20
bb20:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwCapture(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l10 = alloca ptr
  %l16 = alloca i1
  %l19 = alloca i1
  %l23 = alloca i1
  %l24 = alloca i64
  %l27 = alloca i64
  %l36 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca i64
  %l50 = alloca i1
  %l51 = alloca ptr
  %l54 = alloca ptr
  %l58 = alloca i1
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 6
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l10, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Capture", ptr %t9, i32 0, i32 0
  %t12 = load i32, ptr %t11, !tbaa !23
  %t14 = sext i32 %t12 to i64
  store i64 %t14, ptr %l5, !tbaa !24
  %t18 = xor i1 %a3, true
  br i1 %t18, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb7
bb3:
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t22 = getelementptr %"compiler/scope:summary", ptr %t20, i32 0, i32 15
  %t23 = load i1, ptr %t22, !tbaa !21
  br i1 %t23, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb6
bb5:
  %t25 = load ptr, ptr %l4, !tbaa !29
  %t27 = getelementptr %"compiler/scope:summary", ptr %t25, i32 0, i32 16
  %t28 = load i1, ptr %t27, !tbaa !21
  store i1 %t28, ptr %l19, !tbaa !21
  br label %bb6
bb6:
  %t30 = load i1, ptr %l19, !tbaa !21
  %t31 = xor i1 %t30, true
  store i1 %t31, ptr %l16, !tbaa !21
  br label %bb7
bb7:
  %t33 = load i1, ptr %l16, !tbaa !21
  br i1 %t33, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb11
bb9:
  %t34 = load i64, ptr %l5, !tbaa !24
  store i64 %t34, ptr %l24, !tbaa !24
  %t35 = load ptr, ptr %l4, !tbaa !29
  %t37 = getelementptr %"compiler/scope:summary", ptr %t35, i32 0, i32 8
  %t39 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t37)
  store i64 %t39, ptr %l27
  br label %bb10
bb10:
  %t40 = load i64, ptr %l24, !tbaa !24
  %t41 = load i64, ptr %l27, !tbaa !24
  %t42 = icmp sge i64 %t40, %t41
  store i1 %t42, ptr %l23, !tbaa !21
  br label %bb11
bb11:
  %t44 = load i1, ptr %l23, !tbaa !21
  br i1 %t44, label %bb12, label %bb13
bb12:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t48 = getelementptr %"compiler/typed:Capture", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwExpr(ptr %v0, ptr %v1, ptr %t45, ptr %t49, i1 false)
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %ret
bb15:
  %t53 = load ptr, ptr %l4, !tbaa !29
  %t55 = getelementptr %"compiler/scope:summary", ptr %t53, i32 0, i32 9
  %t56 = load i64, ptr %l5, !tbaa !24
  %t59 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t55, i64 %t56)
  store i1 %t59, ptr %l36
  br label %bb16
bb16:
  %t60 = load i1, ptr %l36, !tbaa !21
  br i1 %t60, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s2
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load ptr, ptr %l2, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Capture", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t69 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s2, ptr %t61, ptr %t65)
  store ptr %t69, ptr %l41
  br label %bb19
bb18:
  br label %bb26
bb19:
  %t70 = load ptr, ptr %l41, !tbaa !29
  %t71 = call i64 @compiler_2fscope_2eregionLocal(ptr %s2, ptr %t70)
  store i64 %t71, ptr %l42
  br label %bb20
bb20:
  %t72 = load i64, ptr %l42, !tbaa !24
  store i64 %t72, ptr %l6, !tbaa !24
  %t73 = load i64, ptr %l6, !tbaa !24
  %t75 = icmp sge i64 %t73, 0
  br i1 %t75, label %bb21, label %bb22
bb21:
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l45, !tbaa !29
  %t78 = load i64, ptr %l6, !tbaa !24
  store i64 %t78, ptr %l46, !tbaa !24
  %t79 = load ptr, ptr %l4, !tbaa !29
  %t81 = getelementptr %"compiler/scope:summary", ptr %t79, i32 0, i32 10
  %t82 = load i64, ptr %l5, !tbaa !24
  %t85 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t81, i64 %t82)
  store i1 %t85, ptr %l50
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t86 = load ptr, ptr %l45, !tbaa !29
  %t87 = load i64, ptr %l46, !tbaa !24
  %t88 = load i1, ptr %l50, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreParam(ptr %v0, ptr %t86, i64 %t87, i1 %t88)
  br label %bb24
bb24:
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb26:
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l51, !tbaa !29
  %t90 = load ptr, ptr %l2, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Capture", ptr %t90, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !29
  store ptr %t93, ptr %l54, !tbaa !29
  %t95 = load ptr, ptr %l4, !tbaa !29
  %t97 = getelementptr %"compiler/scope:summary", ptr %t95, i32 0, i32 8
  %t98 = load i64, ptr %l5, !tbaa !24
  %t101 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t97, i64 %t98)
  store i1 %t101, ptr %l58
  br label %bb27
bb27:
  %t102 = load i1, ptr %l58, !tbaa !21
  %t103 = xor i1 %t102, true
  %t104 = load ptr, ptr %l51, !tbaa !29
  %t105 = load ptr, ptr %l54, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwExpr(ptr %v0, ptr %v1, ptr %t104, ptr %t105, i1 %t103)
  br label %bb28
bb28:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwHanded(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t6 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s0, ptr %t1, ptr %a1)
  store ptr %t6, ptr %l8
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l8, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  %t8 = load ptr, ptr %l2, !tbaa !29
  store ptr %t8, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t9 = load ptr, ptr %l9, !tbaa !29
  %t10 = icmp ne ptr %t9, null
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l9, !tbaa !29
  %t13 = load i64, ptr %t12, !range !{i64 0, i64 18}
  %t15 = icmp eq i64 %t13, 3
  store i1 %t15, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l10, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr { i64, [5 x i64] }, ptr %t17, i32 0, i32 1
  %t20 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t19, i32 0, i32 2
  %t21 = load ptr, ptr %t20
  store ptr %t21, ptr %l3, !tbaa !29
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwPlace(ptr %v0, ptr %s0, ptr %t23, ptr %t24)
  br label %bb7
bb7:
  br label %bb22
bb8:
  %t27 = load ptr, ptr %l2, !tbaa !29
  store ptr %t27, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t28 = load ptr, ptr %l17, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t31 = load ptr, ptr %l17, !tbaa !29
  %t32 = load i64, ptr %t31, !range !{i64 0, i64 18}
  %t34 = icmp eq i64 %t32, 10
  store i1 %t34, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t35 = load i1, ptr %l18, !tbaa !21
  br i1 %t35, label %bb11, label %bb12
bb11:
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t38, i32 0, i32 2
  %t40 = load ptr, ptr %t39
  store ptr %t40, ptr %l4, !tbaa !29
  br label %bb13
bb12:
  br label %bb17
bb13:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l4, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Slice", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwPlace(ptr %v0, ptr %s0, ptr %t42, ptr %t46)
  br label %bb14
bb14:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t52 = getelementptr %"compiler/typed:Slice", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwExpr(ptr %v0, ptr %s0, ptr %t49, ptr %t53, i1 true)
  br label %bb15
bb15:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %l4, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Slice", ptr %t58, i32 0, i32 2
  %t61 = load ptr, ptr %t60, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwExpr(ptr %v0, ptr %s0, ptr %t57, ptr %t61, i1 true)
  br label %bb16
bb16:
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_4f09217bbbe73e28_17ebc948c6ad3e44)
  unreachable
bb22:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elastsUntil(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, { i64, [2 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i64
  %l47 = alloca ptr
  %l51 = alloca { i64, [2 x i64] }
  %l53 = alloca i1
  %l64 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  store { i64, [2 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l2
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load { i64, [2 x i64] }, ptr %l1
  %t9 = extractvalue { i64, [2 x i64] } %t7, 0
  %t10 = icmp eq i64 %t9, 5
  br i1 %t10, label %bb4, label %bb5
bb4:
  %t12 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t13 = getelementptr { i64 }, ptr %t12, i32 0, i32 0
  %t14 = load i64, ptr %t13
  store i64 %t14, ptr %l3, !tbaa !24
  br label %bb6
bb5:
  br label %bb26
bb6:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/scope:Scoper", ptr %t16, i32 0, i32 36
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t18, i64 %t19)
  store i64 %t22, ptr %l19
  br label %bb7
bb7:
  %t23 = load i64, ptr %l19, !tbaa !24
  store i64 %t23, ptr %l4, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i64, ptr %l3, !tbaa !24
  %t28 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esetEnd(ptr %v0, ptr %t24, i64 %t25)
  store i64 %t28, ptr %l22
  br label %bb8
bb8:
  %t29 = load i64, ptr %l22, !tbaa !24
  store i64 %t29, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = icmp sgt i64 %t30, %t31
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t36 = load i64, ptr %l6, !tbaa !24
  %t38 = icmp sgt i64 %t36, 0
  br i1 %t38, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb14
bb11:
  %t40 = load i64, ptr %l5, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t44 = sub i64 %t40, %t41
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = add i64 %t44, %t45
  %t50 = sub i64 %t48, 1
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = sdiv i64 %t50, %t51
  store i64 %t54, ptr %l29, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb13
bb13:
  %t56 = load i64, ptr %l29, !tbaa !24
  store i64 %t56, ptr %l26, !tbaa !24
  br label %bb14
bb14:
  %t57 = load i64, ptr %l26, !tbaa !24
  store i64 %t57, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb15
bb15:
  %t58 = load i64, ptr %l8, !tbaa !24
  %t59 = load i64, ptr %l7, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb16, label %bb17
bb16:
  br label %bb25
bb17:
  br label %bb18
bb18:
  %t66 = load i64, ptr %l4, !tbaa !24
  %t67 = load i64, ptr %l8, !tbaa !24
  %t68 = load i64, ptr %l6, !tbaa !24
  %t71 = mul i64 %t67, %t68
  %t74 = add i64 %t66, %t71
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l47, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/scope:Scoper", ptr %t77, i32 0, i32 37
  %t83 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t79, i64 %t74)
  store { i64, [2 x i64] } %t83, ptr %l51
  br label %bb19
bb19:
  %t84 = load { i64, [2 x i64] }, ptr %l2
  %t85 = load ptr, ptr %l47, !tbaa !29
  %t86 = load { i64, [2 x i64] }, ptr %l51
  %t88 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elastsUntil(ptr %v0, ptr %t85, { i64, [2 x i64] } %t86, { i64, [2 x i64] } %t84)
  store i1 %t88, ptr %l53
  br label %bb20
bb20:
  %t89 = load i1, ptr %l53, !tbaa !21
  %t90 = xor i1 %t89, true
  br i1 %t90, label %bb21, label %bb22
bb21:
  store i1 false, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t93 = load i64, ptr %l8, !tbaa !24
  %t95 = add i64 %t93, 1
  store i64 %t95, ptr %l8, !tbaa !24
  br label %bb15
bb25:
  store i1 true, ptr %rv
  br label %ret
bb26:
  %t98 = load { i64, [2 x i64] }, ptr %l1
  %t100 = extractvalue { i64, [2 x i64] } %t98, 0
  %t101 = icmp eq i64 %t100, 1
  br i1 %t101, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load { i64, [2 x i64] }, ptr %l1
  %t105 = load { i64, [2 x i64] }, ptr %l2
  %t109 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eorder(ptr %v0, ptr %t103, { i64, [2 x i64] } %t104, { i64, [2 x i64] } %t105)
  store i64 %t109, ptr %l64
  br label %bb30
bb30:
  %t110 = load i64, ptr @G_2ecompiler_2fscope_2eHolds, !tbaa !24
  %t111 = load i64, ptr %l64, !tbaa !24
  %t113 = icmp eq i64 %t111, %t110
  store i1 %t113, ptr %rv
  br label %ret
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  store i1 true, ptr %rv
  br label %ret
bb35:
  call void @__olang_check_failed(ptr @olang_loc_dd2a7e97808fa897_95cc897457ffa94b)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eliftable(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l5 = alloca i1
  %l6 = alloca i64
  %l14 = alloca i64
  %l25 = alloca %"compiler/typed:Local"
  %l29 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb7
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l6, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/scope:Scoper", ptr %t6, i32 0, i32 25
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = icmp eq ptr %t9, null
  br i1 %t11, label %bb3, label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_622a2f7e184bdd9a_1d72d3d4653d26a6)
  unreachable
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/scope:Scoper", ptr %t13, i32 0, i32 25
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Body", ptr %t16, i32 0, i32 7
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t19)
  store i64 %t21, ptr %l14
  br label %bb6
bb6:
  %t22 = load i64, ptr %l6, !tbaa !24
  %t23 = load i64, ptr %l14, !tbaa !24
  %t24 = icmp sge i64 %t22, %t23
  store i1 %t24, ptr %l5, !tbaa !21
  br label %bb7
bb7:
  %t26 = load i1, ptr %l5, !tbaa !21
  br i1 %t26, label %bb8, label %bb9
bb8:
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/scope:Scoper", ptr %t28, i32 0, i32 25
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = icmp eq ptr %t31, null
  br i1 %t33, label %bb11, label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_1ae8b7943ba83321_5c259e314454f08d)
  unreachable
bb12:
  br label %bb13
bb13:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/scope:Scoper", ptr %t35, i32 0, i32 25
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Body", ptr %t38, i32 0, i32 7
  %t42 = load i64, ptr %l1, !tbaa !24
  %t45 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t41, i64 %t42)
  store %"compiler/typed:Local" %t45, ptr %l25
  br label %bb14
bb14:
  %t46 = getelementptr %"compiler/typed:Local", ptr %l25, i32 0, i32 4
  %t47 = load i32, ptr %t46, !range !{i32 0, i32 7}
  store i32 %t47, ptr %l2
  %t49 = load i32, ptr %l2, !range !{i32 0, i32 7}
  %t51 = trunc i64 1 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb17
bb16:
  %t54 = load i32, ptr %l2, !range !{i32 0, i32 7}
  %t56 = trunc i64 3 to i32
  %t57 = icmp eq i32 %t54, %t56
  store i1 %t57, ptr %l29, !tbaa !21
  br label %bb17
bb17:
  %t59 = load i1, ptr %l29, !tbaa !21
  store i1 %t59, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eliftedVal(ptr %v0, ptr %a0, %"compiler/scope:Val" %a1, { i64, [2 x i64] } %a2, { i64, [2 x i64] } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/scope:Val"
  %l3 = alloca { i64, [2 x i64] }
  %l6 = alloca i1
  %l8 = alloca i1
  %l10 = alloca i1
  %l11 = alloca { i64, [2 x i64] }
  %l13 = alloca { i64, [2 x i64] }
  %l15 = alloca i1
  %l18 = alloca %"compiler/scope:Val"
  %rv = alloca %"compiler/scope:Val"
  store ptr %a0, ptr %l0
  store %"compiler/scope:Val" %a1, ptr %l1
  store { i64, [2 x i64] } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, [2 x i64] } %a2, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb4
bb2:
  %t6 = load { i64, [2 x i64] }, ptr %l3
  %t8 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t6)
  store i1 %t8, ptr %l8
  br label %bb3
bb3:
  %t9 = load i1, ptr %l8, !tbaa !21
  %t10 = xor i1 %t9, true
  store i1 %t10, ptr %l6, !tbaa !21
  br label %bb4
bb4:
  %t12 = load i1, ptr %l6, !tbaa !21
  br i1 %t12, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb8
bb6:
  %t13 = getelementptr %"compiler/scope:Val", ptr %l1, i32 0, i32 1
  %t14 = load { i64, [2 x i64] }, ptr %t13
  store { i64, [2 x i64] } %t14, ptr %l11
  %t15 = load { i64, [2 x i64] }, ptr %l3
  store { i64, [2 x i64] } %t15, ptr %l13
  %t18 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l11, ptr %l13)
  store i1 %t18, ptr %l15
  br label %bb7
bb7:
  %t19 = load i1, ptr %l15, !tbaa !21
  store i1 %t19, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  %t20 = load i1, ptr %l10, !tbaa !21
  br i1 %t20, label %bb9, label %bb10
bb9:
  %t21 = load %"compiler/scope:Val", ptr %l1
  store %"compiler/scope:Val" %t21, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t23 = getelementptr %"compiler/scope:Val", ptr %l1, i32 0, i32 1
  %t24 = load { i64, [2 x i64] }, ptr %t23
  %t26 = call %"compiler/scope:Val" @compiler_2fscope_2eexisting({ i64, [2 x i64] } %t24)
  store %"compiler/scope:Val" %t26, ptr %l18
  br label %bb12
bb12:
  %t27 = load %"compiler/scope:Val", ptr %l18
  store %"compiler/scope:Val" %t27, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scope:Val", ptr %rv
  ret %"compiler/scope:Val" %rr
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emarkTerm(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l3 = alloca i32
  %l4 = alloca { i64, [2 x i64] }
  %l9 = alloca { i64, [2 x i64] }
  %l15 = alloca { i64, [2 x i64] }
  %l24 = alloca { i64, [2 x i64] }
  %rv = alloca { i64, [2 x i64] }
  %t32 = alloca { i64, [2 x i64] }, align 8
  %t52 = alloca { i64, [2 x i64] }, align 8
  %t59 = alloca { i64, [2 x i64] }, align 8
  %t64 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 1
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t10 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblockTerm(ptr %v0, ptr %t6, i32 %a2)
  store { i64, [2 x i64] } %t10, ptr %l9
  br label %bb4
bb4:
  %t11 = load { i64, [2 x i64] }, ptr %l9
  store { i64, [2 x i64] } %t11, ptr %l4
  br label %bb26
bb5:
  %t12 = load { i64, [2 x i64] }, ptr %l1
  %t14 = extractvalue { i64, [2 x i64] } %t12, 0
  %t15 = icmp eq i64 %t14, 2
  br i1 %t15, label %bb6, label %bb7
bb6:
  %t17 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t18 = getelementptr { i32 }, ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l3, !tbaa !23
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l3, !tbaa !23
  %t25 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewhereLives(ptr %v0, ptr %t21, i32 %t22)
  store { i64, [2 x i64] } %t25, ptr %l15
  br label %bb9
bb9:
  %t26 = load { i64, [2 x i64] }, ptr %l15
  store { i64, [2 x i64] } %t26, ptr %l4
  br label %bb26
bb10:
  %t27 = load { i64, [2 x i64] }, ptr %l1
  %t29 = extractvalue { i64, [2 x i64] } %t27, 0
  %t30 = icmp eq i64 %t29, 3
  br i1 %t30, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store { i64, [2 x i64] } zeroinitializer, ptr %t32
  %t33 = getelementptr { i64, [2 x i64] }, ptr %t32, i32 0, i32 0
  store i64 3, ptr %t33
  %t34 = load { i64, [2 x i64] }, ptr %t32
  store { i64, [2 x i64] } %t34, ptr %l4
  br label %bb26
bb14:
  %t36 = load { i64, [2 x i64] }, ptr %l1
  %t38 = extractvalue { i64, [2 x i64] } %t36, 0
  %t39 = icmp eq i64 %t38, 4
  br i1 %t39, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb21
bb17:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/scope:Scoper", ptr %t41, i32 0, i32 39
  %t44 = load i64, ptr %t43, !tbaa !24
  %t46 = icmp sge i64 %t44, 0
  br i1 %t46, label %bb18, label %bb19
bb18:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/scope:Scoper", ptr %t48, i32 0, i32 39
  %t51 = load i64, ptr %t50, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t52
  %t53 = getelementptr { i64, [2 x i64] }, ptr %t52, i32 0, i32 0
  store i64 2, ptr %t53
  %t55 = insertvalue { i64 } undef, i64 %t51, 0
  %t56 = getelementptr { i64, [2 x i64] }, ptr %t52, i32 0, i32 1
  store { i64 } %t55, ptr %t56
  %t57 = load { i64, [2 x i64] }, ptr %t52
  store { i64, [2 x i64] } %t57, ptr %l24
  br label %bb20
bb19:
  store { i64, [2 x i64] } zeroinitializer, ptr %t59
  %t60 = getelementptr { i64, [2 x i64] }, ptr %t59, i32 0, i32 0
  store i64 6, ptr %t60
  %t61 = load { i64, [2 x i64] }, ptr %t59
  store { i64, [2 x i64] } %t61, ptr %l24
  br label %bb20
bb20:
  %t63 = load { i64, [2 x i64] }, ptr %l24
  store { i64, [2 x i64] } %t63, ptr %l4
  br label %bb26
bb21:
  br i1 true, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  store { i64, [2 x i64] } zeroinitializer, ptr %t64
  %t65 = getelementptr { i64, [2 x i64] }, ptr %t64, i32 0, i32 0
  store i64 0, ptr %t65
  %t66 = load { i64, [2 x i64] }, ptr %t64
  store { i64, [2 x i64] } %t66, ptr %l4
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_298102a92201c9c7_d2c28c3c337e3c3b)
  unreachable
bb26:
  %t68 = load { i64, [2 x i64] }, ptr %l4
  store { i64, [2 x i64] } %t68, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ematchFresh(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l32 = alloca i1
  %l35 = alloca ptr
  %l42 = alloca i1
  %l49 = alloca i1
  %l59 = alloca ptr
  %l67 = alloca i1
  %l70 = alloca ptr
  %l78 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Match", ptr %t1, i32 0, i32 3
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i1 false, ptr %l2, !tbaa !21
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Match", ptr %t9, i32 0, i32 1
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  store { i64, ptr } %t12, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  store i64 %t16, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  %t18 = load i64, ptr %l4, !tbaa !24
  %t19 = load i64, ptr %l5, !tbaa !24
  %t22 = icmp slt i64 %t18, %t19
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb5, label %bb6
bb5:
  br label %bb26
bb6:
  br label %bb7
bb7:
  %t26 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t26, ptr %l19, !tbaa !27
  %t27 = load i64, ptr %l4, !tbaa !24
  %t29 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr ptr, ptr %t30, i64 %t27
  %t32 = load ptr, ptr %t31, !tbaa !39
  store ptr %t32, ptr %l6, !tbaa !29
  %t34 = load ptr, ptr %l6, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Arm", ptr %t34, i32 0, i32 4
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  br i1 %t39, label %bb8, label %bb9
bb8:
  br label %bb25
bb9:
  br label %bb10
bb10:
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l25, !tbaa !29
  %t42 = load ptr, ptr %l6, !tbaa !29
  %t44 = getelementptr %"compiler/typed:Arm", ptr %t42, i32 0, i32 4
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = icmp eq ptr %t45, null
  br i1 %t47, label %bb11, label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_1a9ca456c0fc4f74_b6b9f556459eb628)
  unreachable
bb12:
  br label %bb13
bb13:
  %t49 = load ptr, ptr %l6, !tbaa !29
  %t51 = getelementptr %"compiler/typed:Arm", ptr %t49, i32 0, i32 4
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = load ptr, ptr %l25, !tbaa !29
  %t56 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enewOrConst(ptr %v0, ptr %v1, ptr %t54, ptr %t52)
  store i1 %t56, ptr %l32
  br label %bb14
bb14:
  %t57 = load i1, ptr %l32, !tbaa !21
  %t58 = xor i1 %t57, true
  br i1 %t58, label %bb15, label %bb16
bb15:
  store i1 false, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l35, !tbaa !29
  %t62 = load ptr, ptr %l6, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Arm", ptr %t62, i32 0, i32 4
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = icmp eq ptr %t65, null
  br i1 %t67, label %bb18, label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_2a6344a0ea169f03_937c8368e559d747)
  unreachable
bb19:
  br label %bb20
bb20:
  %t69 = load ptr, ptr %l6, !tbaa !29
  %t71 = getelementptr %"compiler/typed:Arm", ptr %t69, i32 0, i32 4
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = load ptr, ptr %l35, !tbaa !29
  %t76 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %t74, ptr %t72)
  store i1 %t76, ptr %l42
  br label %bb21
bb21:
  %t77 = load i1, ptr %l42, !tbaa !21
  br i1 %t77, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb24
bb23:
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t78 = load i64, ptr %l4, !tbaa !24
  %t80 = add i64 %t78, 1
  store i64 %t80, ptr %l4, !tbaa !24
  br label %bb4
bb26:
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr %"compiler/typed:Match", ptr %t82, i32 0, i32 2
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = icmp eq ptr %t85, null
  %t89 = xor i1 %t87, true
  br i1 %t89, label %bb27, label %bb28
bb27:
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t93 = getelementptr %"compiler/typed:Match", ptr %t91, i32 0, i32 2
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = icmp eq ptr %t94, null
  br i1 %t96, label %bb29, label %bb30
bb28:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb32
bb29:
  call void @__olang_check_failed(ptr @olang_loc_61c41c23c6ba3b82_8b9b0b538ad52716)
  unreachable
bb30:
  br label %bb31
bb31:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr %"compiler/typed:Match", ptr %t98, i32 0, i32 2
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t104 = getelementptr %"compiler/typed:Arm", ptr %t101, i32 0, i32 4
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = icmp eq ptr %t105, null
  %t109 = xor i1 %t107, true
  store i1 %t109, ptr %l49, !tbaa !21
  br label %bb32
bb32:
  %t111 = load i1, ptr %l49, !tbaa !21
  br i1 %t111, label %bb33, label %bb34
bb33:
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l59, !tbaa !29
  %t113 = load ptr, ptr %l1, !tbaa !29
  %t115 = getelementptr %"compiler/typed:Match", ptr %t113, i32 0, i32 2
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = icmp eq ptr %t116, null
  br i1 %t118, label %bb35, label %bb36
bb34:
  br label %bb49
bb35:
  call void @__olang_check_failed(ptr @olang_loc_b9c5758278fbc269_f38d2c0a467d6fd)
  unreachable
bb36:
  br label %bb37
bb37:
  %t120 = load ptr, ptr %l1, !tbaa !29
  %t122 = getelementptr %"compiler/typed:Match", ptr %t120, i32 0, i32 2
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t126 = getelementptr %"compiler/typed:Arm", ptr %t123, i32 0, i32 4
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t128 = load ptr, ptr %l59, !tbaa !29
  %t130 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enewOrConst(ptr %v0, ptr %v1, ptr %t128, ptr %t127)
  store i1 %t130, ptr %l67
  br label %bb38
bb38:
  %t131 = load i1, ptr %l67, !tbaa !21
  %t132 = xor i1 %t131, true
  br i1 %t132, label %bb39, label %bb40
bb39:
  store i1 false, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t135 = load ptr, ptr %l0, !tbaa !29
  store ptr %t135, ptr %l70, !tbaa !29
  %t136 = load ptr, ptr %l1, !tbaa !29
  %t138 = getelementptr %"compiler/typed:Match", ptr %t136, i32 0, i32 2
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t141 = icmp eq ptr %t139, null
  br i1 %t141, label %bb42, label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_8672b56b87660cf0_1560bce2a415882c)
  unreachable
bb43:
  br label %bb44
bb44:
  %t143 = load ptr, ptr %l1, !tbaa !29
  %t145 = getelementptr %"compiler/typed:Match", ptr %t143, i32 0, i32 2
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t149 = getelementptr %"compiler/typed:Arm", ptr %t146, i32 0, i32 4
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t151 = load ptr, ptr %l70, !tbaa !29
  %t153 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %t151, ptr %t150)
  store i1 %t153, ptr %l78
  br label %bb45
bb45:
  %t154 = load i1, ptr %l78, !tbaa !21
  br i1 %t154, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb48
bb47:
  br label %bb48
bb48:
  br label %bb49
bb49:
  %t155 = load i1, ptr %l2, !tbaa !21
  store i1 %t155, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enameSpan(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i1
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca i8
  %l14 = alloca i64
  %l15 = alloca i8
  %l16 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l27 = alloca i32
  %l39 = alloca %"compiler/source:Span"
  %l40 = alloca %"compiler/source:Span"
  %l41 = alloca %"compiler/source:Span"
  %l46 = alloca { i64, ptr }
  %l51 = alloca i1
  %l59 = alloca i1
  %l60 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l76 = alloca %"compiler/source:Span"
  %l79 = alloca i1
  %l82 = alloca i1
  %l87 = alloca i1
  %l90 = alloca i1
  %l97 = alloca i1
  %l105 = alloca %"compiler/source:Span"
  %l108 = alloca %"compiler/source:Span"
  %l113 = alloca i1
  %l116 = alloca i1
  %l121 = alloca %"compiler/source:Span"
  %l125 = alloca i1
  %l130 = alloca i1
  %l131 = alloca { i64, ptr }
  %l134 = alloca i1
  %l144 = alloca %"compiler/source:Span"
  %l147 = alloca i1
  %l150 = alloca i1
  %l156 = alloca i1
  %l166 = alloca i1
  %l169 = alloca i1
  %l181 = alloca i1
  %l184 = alloca i1
  %l187 = alloca i1
  %l190 = alloca %"compiler/source:Span"
  %l193 = alloca i1
  %l196 = alloca i1
  %l199 = alloca i1
  %l204 = alloca i1
  %l205 = alloca { i64, ptr }
  %l210 = alloca i1
  %l214 = alloca i1
  %l215 = alloca { i64, ptr }
  %l220 = alloca i1
  %l221 = alloca { i64, ptr }
  %l226 = alloca i1
  %l227 = alloca { i64, ptr }
  %l232 = alloca i1
  %l233 = alloca { i64, ptr }
  %l238 = alloca { i64, ptr }
  %l246 = alloca i1
  %l249 = alloca i1
  %l252 = alloca i1
  %l255 = alloca i1
  %l258 = alloca i1
  %l261 = alloca i1
  %l264 = alloca i1
  %l267 = alloca i1
  %l276 = alloca %"compiler/source:Span"
  %l282 = alloca %"compiler/source:Span"
  %l287 = alloca i1
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 10
  store ptr %t3, ptr %l18, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/scope:Scoper", ptr %t4, i32 0, i32 25
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_e498d93abb20b61c_9a7977ea577c2990)
  unreachable
bb2:
  br label %bb3
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 25
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Body", ptr %t14, i32 0, i32 3
  %t18 = load i64, ptr %t17, !tbaa !24
  %t19 = load ptr, ptr %l18, !tbaa !29
  %t21 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v0, ptr %t19, i64 %t18)
  %t22 = extractvalue { i32, { i64, ptr } } %t21, 1
  %t23 = extractvalue { i32, { i64, ptr } } %t21, 0
  store i32 %t23, ptr %l27
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb5, label %ok.25, !prof !99
ok.25:
  store { i64, ptr } %t22, ptr %l26
  br label %bb4
bb4:
  %t26 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t26, ptr %l16, !tbaa !27
  br label %bb7
bb5:
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l16, !tbaa !27
  br label %bb7
bb7:
  %t27 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t27, ptr %l2, !tbaa !27
  %t28 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t29 = load i32, ptr %t28, !tbaa !23
  %t31 = sext i32 %t29 to i64
  store i64 %t31, ptr %l3, !tbaa !24
  %t33 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t34 = load i32, ptr %t33, !tbaa !23
  %t36 = sext i32 %t34 to i64
  store i64 %t36, ptr %l4, !tbaa !24
  %t38 = load i64, ptr %l4, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t44 = icmp sgt i64 %t38, %t41
  br i1 %t44, label %bb8, label %bb9
bb8:
  %t46 = load %"compiler/source:Span", ptr %l1
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/source:Span" %t46, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t48 = load i64, ptr %l3, !tbaa !24
  store i64 %t48, ptr %l5, !tbaa !24
  %t50 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t50, ptr %l6
  %t52 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t52, ptr %l39
  br label %bb11
bb11:
  %t53 = load %"compiler/source:Span", ptr %l39
  store %"compiler/source:Span" %t53, ptr %l7
  store i1 false, ptr %l8, !tbaa !21
  store i64 0, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  %t54 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t54, ptr %l40
  br label %bb12
bb12:
  %t55 = load %"compiler/source:Span", ptr %l40
  store %"compiler/source:Span" %t55, ptr %l11
  %t56 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t56, ptr %l41
  br label %bb13
bb13:
  %t57 = load %"compiler/source:Span", ptr %l41
  store %"compiler/source:Span" %t57, ptr %l12
  br label %bb14
bb14:
  %t58 = load i64, ptr %l5, !tbaa !24
  %t59 = load i64, ptr %l4, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb15, label %bb16
bb15:
  br label %bb194
bb16:
  br label %bb17
bb17:
  %t66 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t66, ptr %l46, !tbaa !27
  %t67 = load i64, ptr %l5, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr i8, ptr %t70, i64 %t67
  %t72 = load i8, ptr %t71, !tbaa !32
  store i8 %t72, ptr %l13, !tbaa !22
  %t74 = load i8, ptr %l13, !tbaa !22
  %t76 = icmp eq i8 %t74, 34
  br i1 %t76, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb20
bb19:
  %t78 = load i8, ptr %l13, !tbaa !22
  %t80 = icmp eq i8 %t78, 39
  store i1 %t80, ptr %l51, !tbaa !21
  br label %bb20
bb20:
  %t82 = load i1, ptr %l51, !tbaa !21
  br i1 %t82, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  %t83 = load i64, ptr %l5, !tbaa !24
  %t85 = add i64 %t83, 1
  store i64 %t85, ptr %l5, !tbaa !24
  br label %bb23
bb22:
  br label %bb36
bb23:
  %t87 = load i64, ptr %l5, !tbaa !24
  %t88 = load i64, ptr %l4, !tbaa !24
  %t91 = icmp slt i64 %t87, %t88
  br i1 %t91, label %bb24, label %bb25
bb24:
  %t93 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t93, ptr %l60, !tbaa !27
  %t94 = load i64, ptr %l5, !tbaa !24
  %t96 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr i8, ptr %t97, i64 %t94
  %t99 = load i8, ptr %t98, !tbaa !32
  %t100 = load i8, ptr %l13, !tbaa !22
  %t103 = icmp ne i8 %t99, %t100
  store i1 %t103, ptr %l59, !tbaa !21
  br label %bb26
bb25:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb26
bb26:
  %t105 = load i1, ptr %l59, !tbaa !21
  %t106 = xor i1 %t105, true
  br i1 %t106, label %bb27, label %bb28
bb27:
  br label %bb34
bb28:
  br label %bb29
bb29:
  %t108 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t108, ptr %l66, !tbaa !27
  %t109 = load i64, ptr %l5, !tbaa !24
  %t111 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr i8, ptr %t112, i64 %t109
  %t114 = load i8, ptr %t113, !tbaa !32
  %t116 = icmp eq i8 %t114, 92
  br i1 %t116, label %bb30, label %bb31
bb30:
  %t118 = load i64, ptr %l5, !tbaa !24
  %t120 = add i64 %t118, 1
  store i64 %t120, ptr %l5, !tbaa !24
  br label %bb32
bb31:
  br label %bb32
bb32:
  %t122 = load i64, ptr %l5, !tbaa !24
  %t124 = add i64 %t122, 1
  store i64 %t124, ptr %l5, !tbaa !24
  br label %bb33
bb33:
  br label %bb23
bb34:
  %t126 = load i64, ptr %l5, !tbaa !24
  %t128 = add i64 %t126, 1
  store i64 %t128, ptr %l5, !tbaa !24
  %t130 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s3, i32 0, i32 0)
  store %"compiler/source:Span" %t130, ptr %l76
  br label %bb35
bb35:
  %t131 = load %"compiler/source:Span", ptr %l76
  store %"compiler/source:Span" %t131, ptr %l7
  call void @__olang_scope_close(ptr %s3)
  br label %bb193
bb36:
  %t132 = load i8, ptr %l13, !tbaa !22
  %t134 = icmp eq i8 %t132, 40
  br i1 %t134, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb39
bb38:
  %t136 = load i8, ptr %l13, !tbaa !22
  %t138 = icmp eq i8 %t136, 91
  store i1 %t138, ptr %l79, !tbaa !21
  br label %bb39
bb39:
  %t140 = load i1, ptr %l79, !tbaa !21
  br i1 %t140, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l82, !tbaa !21
  br label %bb42
bb41:
  %t141 = load i8, ptr %l13, !tbaa !22
  %t143 = icmp eq i8 %t141, 123
  store i1 %t143, ptr %l82, !tbaa !21
  br label %bb42
bb42:
  %t145 = load i1, ptr %l82, !tbaa !21
  br i1 %t145, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s6
  %t146 = load i8, ptr %l13, !tbaa !22
  %t148 = icmp eq i8 %t146, 40
  br i1 %t148, label %bb45, label %bb46
bb44:
  br label %bb62
bb45:
  %t150 = load i64, ptr %l9, !tbaa !24
  %t152 = icmp eq i64 %t150, 0
  store i1 %t152, ptr %l87, !tbaa !21
  br label %bb47
bb46:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb47
bb47:
  %t154 = load i1, ptr %l87, !tbaa !21
  br i1 %t154, label %bb48, label %bb49
bb48:
  %t155 = getelementptr %"compiler/source:Span", ptr %l7, i32 0, i32 1
  %t156 = load i32, ptr %t155, !tbaa !23
  %t157 = getelementptr %"compiler/source:Span", ptr %l7, i32 0, i32 0
  %t158 = load i32, ptr %t157, !tbaa !23
  %t161 = icmp sgt i32 %t156, %t158
  store i1 %t161, ptr %l90, !tbaa !21
  br label %bb50
bb49:
  store i1 false, ptr %l90, !tbaa !21
  br label %bb50
bb50:
  %t163 = load i1, ptr %l90, !tbaa !21
  br i1 %t163, label %bb51, label %bb52
bb51:
  %t164 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t164, ptr %l6
  store i1 true, ptr %l8, !tbaa !21
  br label %bb53
bb52:
  br label %bb53
bb53:
  %t166 = load i8, ptr %l13, !tbaa !22
  %t168 = icmp eq i8 %t166, 91
  br i1 %t168, label %bb54, label %bb55
bb54:
  %t170 = load i64, ptr %l9, !tbaa !24
  %t172 = icmp eq i64 %t170, 0
  store i1 %t172, ptr %l97, !tbaa !21
  br label %bb56
bb55:
  store i1 false, ptr %l97, !tbaa !21
  br label %bb56
bb56:
  %t174 = load i1, ptr %l97, !tbaa !21
  br i1 %t174, label %bb57, label %bb58
bb57:
  store %olang.scope zeroinitializer, ptr %s8
  %t175 = load i64, ptr %l5, !tbaa !24
  %t177 = trunc i64 %t175 to i32
  %t178 = load i64, ptr %l5, !tbaa !24
  %t180 = add i64 %t178, 1
  %t182 = trunc i64 %t180 to i32
  %t185 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s8, i32 %t177, i32 %t182)
  store %"compiler/source:Span" %t185, ptr %l105
  br label %bb59
bb58:
  br label %bb60
bb59:
  %t186 = load %"compiler/source:Span", ptr %l105
  store %"compiler/source:Span" %t186, ptr %l12
  call void @__olang_scope_close(ptr %s8)
  br label %bb60
bb60:
  %t187 = load i64, ptr %l9, !tbaa !24
  %t189 = add i64 %t187, 1
  store i64 %t189, ptr %l9, !tbaa !24
  %t191 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s6, i32 0, i32 0)
  store %"compiler/source:Span" %t191, ptr %l108
  br label %bb61
bb61:
  %t192 = load %"compiler/source:Span", ptr %l108
  store %"compiler/source:Span" %t192, ptr %l7
  %t193 = load i64, ptr %l5, !tbaa !24
  %t195 = add i64 %t193, 1
  store i64 %t195, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb193
bb62:
  %t197 = load i8, ptr %l13, !tbaa !22
  %t199 = icmp eq i8 %t197, 41
  br i1 %t199, label %bb63, label %bb64
bb63:
  store i1 true, ptr %l113, !tbaa !21
  br label %bb65
bb64:
  %t201 = load i8, ptr %l13, !tbaa !22
  %t203 = icmp eq i8 %t201, 93
  store i1 %t203, ptr %l113, !tbaa !21
  br label %bb65
bb65:
  %t205 = load i1, ptr %l113, !tbaa !21
  br i1 %t205, label %bb66, label %bb67
bb66:
  store i1 true, ptr %l116, !tbaa !21
  br label %bb68
bb67:
  %t206 = load i8, ptr %l13, !tbaa !22
  %t208 = icmp eq i8 %t206, 125
  store i1 %t208, ptr %l116, !tbaa !21
  br label %bb68
bb68:
  %t210 = load i1, ptr %l116, !tbaa !21
  br i1 %t210, label %bb69, label %bb70
bb69:
  store %olang.scope zeroinitializer, ptr %s9
  %t211 = load i64, ptr %l9, !tbaa !24
  %t213 = sub i64 %t211, 1
  store i64 %t213, ptr %l9, !tbaa !24
  %t215 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s9, i32 0, i32 0)
  store %"compiler/source:Span" %t215, ptr %l121
  br label %bb71
bb70:
  br label %bb72
bb71:
  %t216 = load %"compiler/source:Span", ptr %l121
  store %"compiler/source:Span" %t216, ptr %l7
  %t217 = load i64, ptr %l5, !tbaa !24
  %t219 = add i64 %t217, 1
  store i64 %t219, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb193
bb72:
  %t221 = load i8, ptr %l13, !tbaa !22
  %t223 = call i1 @compiler_2fscope_2eisNameChar(i8 %t221)
  store i1 %t223, ptr %l125
  br label %bb73
bb73:
  %t224 = load i1, ptr %l125, !tbaa !21
  br i1 %t224, label %bb74, label %bb75
bb74:
  %t225 = load i64, ptr %l5, !tbaa !24
  store i64 %t225, ptr %l14, !tbaa !24
  br label %bb76
bb75:
  br label %bb99
bb76:
  %t227 = load i64, ptr %l5, !tbaa !24
  %t228 = load i64, ptr %l4, !tbaa !24
  %t231 = icmp slt i64 %t227, %t228
  br i1 %t231, label %bb77, label %bb78
bb77:
  %t233 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t233, ptr %l131, !tbaa !27
  %t234 = load i64, ptr %l5, !tbaa !24
  %t236 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t237 = load ptr, ptr %t236, !tbaa !27
  %t238 = getelementptr i8, ptr %t237, i64 %t234
  %t239 = load i8, ptr %t238, !tbaa !32
  %t241 = call i1 @compiler_2fscope_2eisNameChar(i8 %t239)
  store i1 %t241, ptr %l134
  br label %bb79
bb78:
  store i1 false, ptr %l130, !tbaa !21
  br label %bb80
bb79:
  %t242 = load i1, ptr %l134, !tbaa !21
  store i1 %t242, ptr %l130, !tbaa !21
  br label %bb80
bb80:
  %t243 = load i1, ptr %l130, !tbaa !21
  %t244 = xor i1 %t243, true
  br i1 %t244, label %bb81, label %bb82
bb81:
  br label %bb85
bb82:
  br label %bb83
bb83:
  %t246 = load i64, ptr %l5, !tbaa !24
  %t248 = add i64 %t246, 1
  store i64 %t248, ptr %l5, !tbaa !24
  br label %bb84
bb84:
  br label %bb76
bb85:
  %t250 = load i64, ptr %l10, !tbaa !24
  %t252 = icmp eq i64 %t250, 0
  br i1 %t252, label %bb86, label %bb87
bb86:
  store %olang.scope zeroinitializer, ptr %s12
  %t254 = load i64, ptr %l14, !tbaa !24
  %t256 = trunc i64 %t254 to i32
  %t257 = load i64, ptr %l5, !tbaa !24
  %t259 = trunc i64 %t257 to i32
  %t262 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s12, i32 %t256, i32 %t259)
  store %"compiler/source:Span" %t262, ptr %l144
  br label %bb88
bb87:
  br label %bb89
bb88:
  %t263 = load %"compiler/source:Span", ptr %l144
  store %"compiler/source:Span" %t263, ptr %l7
  call void @__olang_scope_close(ptr %s12)
  br label %bb89
bb89:
  %t264 = load i1, ptr %l8, !tbaa !21
  %t266 = xor i1 %t264, true
  br i1 %t266, label %bb90, label %bb91
bb90:
  %t268 = load i64, ptr %l9, !tbaa !24
  %t270 = icmp eq i64 %t268, 0
  store i1 %t270, ptr %l147, !tbaa !21
  br label %bb92
bb91:
  store i1 false, ptr %l147, !tbaa !21
  br label %bb92
bb92:
  %t272 = load i1, ptr %l147, !tbaa !21
  br i1 %t272, label %bb93, label %bb94
bb93:
  %t273 = load i64, ptr %l10, !tbaa !24
  %t275 = icmp eq i64 %t273, 0
  store i1 %t275, ptr %l150, !tbaa !21
  br label %bb95
bb94:
  store i1 false, ptr %l150, !tbaa !21
  br label %bb95
bb95:
  %t277 = load i1, ptr %l150, !tbaa !21
  br i1 %t277, label %bb96, label %bb97
bb96:
  %t278 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t278, ptr %l6
  br label %bb98
bb97:
  br label %bb98
bb98:
  br label %bb193
bb99:
  %t280 = load i8, ptr %l13, !tbaa !22
  %t282 = icmp eq i8 %t280, 60
  br i1 %t282, label %bb100, label %bb101
bb100:
  %t284 = load i64, ptr %l9, !tbaa !24
  %t286 = icmp eq i64 %t284, 0
  store i1 %t286, ptr %l156, !tbaa !21
  br label %bb102
bb101:
  store i1 false, ptr %l156, !tbaa !21
  br label %bb102
bb102:
  %t288 = load i1, ptr %l156, !tbaa !21
  br i1 %t288, label %bb103, label %bb104
bb103:
  %t289 = load i64, ptr %l10, !tbaa !24
  %t291 = add i64 %t289, 1
  store i64 %t291, ptr %l10, !tbaa !24
  %t293 = load i64, ptr %l10, !tbaa !24
  %t295 = icmp eq i64 %t293, 1
  br i1 %t295, label %bb105, label %bb106
bb104:
  %t297 = load i8, ptr %l13, !tbaa !22
  %t299 = icmp eq i8 %t297, 62
  br i1 %t299, label %bb108, label %bb109
bb105:
  %t301 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t301, ptr %l11
  br label %bb107
bb106:
  br label %bb107
bb107:
  br label %bb133
bb108:
  %t303 = load i64, ptr %l10, !tbaa !24
  %t305 = icmp sgt i64 %t303, 0
  store i1 %t305, ptr %l166, !tbaa !21
  br label %bb110
bb109:
  store i1 false, ptr %l166, !tbaa !21
  br label %bb110
bb110:
  %t307 = load i1, ptr %l166, !tbaa !21
  br i1 %t307, label %bb111, label %bb112
bb111:
  %t308 = load i64, ptr %l9, !tbaa !24
  %t310 = icmp eq i64 %t308, 0
  store i1 %t310, ptr %l169, !tbaa !21
  br label %bb113
bb112:
  store i1 false, ptr %l169, !tbaa !21
  br label %bb113
bb113:
  %t312 = load i1, ptr %l169, !tbaa !21
  br i1 %t312, label %bb114, label %bb115
bb114:
  %t313 = load i64, ptr %l10, !tbaa !24
  %t315 = sub i64 %t313, 1
  store i64 %t315, ptr %l10, !tbaa !24
  %t317 = load i64, ptr %l10, !tbaa !24
  %t319 = icmp eq i64 %t317, 0
  br i1 %t319, label %bb116, label %bb117
bb115:
  %t321 = load i8, ptr %l13, !tbaa !22
  %t323 = icmp ne i8 %t321, 46
  br i1 %t323, label %bb119, label %bb120
bb116:
  %t325 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t325, ptr %l7
  br label %bb118
bb117:
  br label %bb118
bb118:
  %t327 = load i64, ptr %l5, !tbaa !24
  %t329 = add i64 %t327, 1
  store i64 %t329, ptr %l5, !tbaa !24
  br label %bb193
bb119:
  %t331 = load i8, ptr %l13, !tbaa !22
  %t333 = icmp ne i8 %t331, 32
  store i1 %t333, ptr %l181, !tbaa !21
  br label %bb121
bb120:
  store i1 false, ptr %l181, !tbaa !21
  br label %bb121
bb121:
  %t335 = load i1, ptr %l181, !tbaa !21
  br i1 %t335, label %bb122, label %bb123
bb122:
  %t336 = load i8, ptr %l13, !tbaa !22
  %t338 = icmp ne i8 %t336, 44
  store i1 %t338, ptr %l184, !tbaa !21
  br label %bb124
bb123:
  store i1 false, ptr %l184, !tbaa !21
  br label %bb124
bb124:
  %t340 = load i1, ptr %l184, !tbaa !21
  br i1 %t340, label %bb125, label %bb126
bb125:
  %t341 = load i64, ptr %l10, !tbaa !24
  %t343 = icmp eq i64 %t341, 0
  store i1 %t343, ptr %l187, !tbaa !21
  br label %bb127
bb126:
  store i1 false, ptr %l187, !tbaa !21
  br label %bb127
bb127:
  %t345 = load i1, ptr %l187, !tbaa !21
  br i1 %t345, label %bb128, label %bb129
bb128:
  store %olang.scope zeroinitializer, ptr %s20
  %t346 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s20, i32 0, i32 0)
  store %"compiler/source:Span" %t346, ptr %l190
  br label %bb130
bb129:
  br label %bb131
bb130:
  %t347 = load %"compiler/source:Span", ptr %l190
  store %"compiler/source:Span" %t347, ptr %l7
  call void @__olang_scope_close(ptr %s20)
  br label %bb131
bb131:
  br label %bb132
bb132:
  br label %bb133
bb133:
  %t348 = load i8, ptr %l13, !tbaa !22
  %t350 = icmp eq i8 %t348, 61
  br i1 %t350, label %bb134, label %bb135
bb134:
  %t352 = load i64, ptr %l9, !tbaa !24
  %t354 = icmp eq i64 %t352, 0
  store i1 %t354, ptr %l193, !tbaa !21
  br label %bb136
bb135:
  store i1 false, ptr %l193, !tbaa !21
  br label %bb136
bb136:
  %t356 = load i1, ptr %l193, !tbaa !21
  br i1 %t356, label %bb137, label %bb138
bb137:
  %t357 = load i1, ptr %l8, !tbaa !21
  %t359 = xor i1 %t357, true
  store i1 %t359, ptr %l196, !tbaa !21
  br label %bb139
bb138:
  store i1 false, ptr %l196, !tbaa !21
  br label %bb139
bb139:
  %t361 = load i1, ptr %l196, !tbaa !21
  br i1 %t361, label %bb140, label %bb141
bb140:
  %t362 = load i64, ptr %l5, !tbaa !24
  %t364 = add i64 %t362, 1
  %t365 = load i64, ptr %l4, !tbaa !24
  %t368 = icmp slt i64 %t364, %t365
  store i1 %t368, ptr %l199, !tbaa !21
  br label %bb142
bb141:
  store i1 false, ptr %l199, !tbaa !21
  br label %bb142
bb142:
  %t370 = load i1, ptr %l199, !tbaa !21
  br i1 %t370, label %bb143, label %bb144
bb143:
  %t371 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t371, ptr %l205, !tbaa !27
  %t372 = load i64, ptr %l5, !tbaa !24
  %t374 = add i64 %t372, 1
  %t376 = getelementptr { i64, ptr }, ptr %l205, i32 0, i32 1
  %t377 = load ptr, ptr %t376, !tbaa !27
  %t378 = getelementptr i8, ptr %t377, i64 %t374
  %t379 = load i8, ptr %t378, !tbaa !32
  %t381 = icmp ne i8 %t379, 61
  store i1 %t381, ptr %l204, !tbaa !21
  br label %bb145
bb144:
  store i1 false, ptr %l204, !tbaa !21
  br label %bb145
bb145:
  %t383 = load i1, ptr %l204, !tbaa !21
  br i1 %t383, label %bb146, label %bb147
bb146:
  %t384 = load i64, ptr %l5, !tbaa !24
  %t385 = load i64, ptr %l3, !tbaa !24
  %t388 = icmp sgt i64 %t384, %t385
  store i1 %t388, ptr %l210, !tbaa !21
  br label %bb148
bb147:
  store i1 false, ptr %l210, !tbaa !21
  br label %bb148
bb148:
  %t390 = load i1, ptr %l210, !tbaa !21
  br i1 %t390, label %bb149, label %bb150
bb149:
  %t391 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t391, ptr %l215, !tbaa !27
  %t392 = load i64, ptr %l5, !tbaa !24
  %t394 = sub i64 %t392, 1
  %t396 = getelementptr { i64, ptr }, ptr %l215, i32 0, i32 1
  %t397 = load ptr, ptr %t396, !tbaa !27
  %t398 = getelementptr i8, ptr %t397, i64 %t394
  %t399 = load i8, ptr %t398, !tbaa !32
  %t401 = icmp ne i8 %t399, 61
  store i1 %t401, ptr %l214, !tbaa !21
  br label %bb151
bb150:
  store i1 false, ptr %l214, !tbaa !21
  br label %bb151
bb151:
  %t403 = load i1, ptr %l214, !tbaa !21
  br i1 %t403, label %bb152, label %bb153
bb152:
  %t404 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t404, ptr %l221, !tbaa !27
  %t405 = load i64, ptr %l5, !tbaa !24
  %t407 = sub i64 %t405, 1
  %t409 = getelementptr { i64, ptr }, ptr %l221, i32 0, i32 1
  %t410 = load ptr, ptr %t409, !tbaa !27
  %t411 = getelementptr i8, ptr %t410, i64 %t407
  %t412 = load i8, ptr %t411, !tbaa !32
  %t414 = icmp ne i8 %t412, 33
  store i1 %t414, ptr %l220, !tbaa !21
  br label %bb154
bb153:
  store i1 false, ptr %l220, !tbaa !21
  br label %bb154
bb154:
  %t416 = load i1, ptr %l220, !tbaa !21
  br i1 %t416, label %bb155, label %bb156
bb155:
  %t417 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t417, ptr %l227, !tbaa !27
  %t418 = load i64, ptr %l5, !tbaa !24
  %t420 = sub i64 %t418, 1
  %t422 = getelementptr { i64, ptr }, ptr %l227, i32 0, i32 1
  %t423 = load ptr, ptr %t422, !tbaa !27
  %t424 = getelementptr i8, ptr %t423, i64 %t420
  %t425 = load i8, ptr %t424, !tbaa !32
  %t427 = icmp ne i8 %t425, 60
  store i1 %t427, ptr %l226, !tbaa !21
  br label %bb157
bb156:
  store i1 false, ptr %l226, !tbaa !21
  br label %bb157
bb157:
  %t429 = load i1, ptr %l226, !tbaa !21
  br i1 %t429, label %bb158, label %bb159
bb158:
  %t430 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t430, ptr %l233, !tbaa !27
  %t431 = load i64, ptr %l5, !tbaa !24
  %t433 = sub i64 %t431, 1
  %t435 = getelementptr { i64, ptr }, ptr %l233, i32 0, i32 1
  %t436 = load ptr, ptr %t435, !tbaa !27
  %t437 = getelementptr i8, ptr %t436, i64 %t433
  %t438 = load i8, ptr %t437, !tbaa !32
  %t440 = icmp ne i8 %t438, 62
  store i1 %t440, ptr %l232, !tbaa !21
  br label %bb160
bb159:
  store i1 false, ptr %l232, !tbaa !21
  br label %bb160
bb160:
  %t442 = load i1, ptr %l232, !tbaa !21
  br i1 %t442, label %bb161, label %bb162
bb161:
  store %olang.scope zeroinitializer, ptr %s21
  %t443 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t443, ptr %l238, !tbaa !27
  %t444 = load i64, ptr %l5, !tbaa !24
  %t446 = sub i64 %t444, 1
  %t448 = getelementptr { i64, ptr }, ptr %l238, i32 0, i32 1
  %t449 = load ptr, ptr %t448, !tbaa !27
  %t450 = getelementptr i8, ptr %t449, i64 %t446
  %t451 = load i8, ptr %t450, !tbaa !32
  store i8 %t451, ptr %l15, !tbaa !22
  %t453 = load i64, ptr %l5, !tbaa !24
  %t455 = sub i64 %t453, 1
  %t456 = load i64, ptr %l3, !tbaa !24
  %t459 = icmp sgt i64 %t455, %t456
  br i1 %t459, label %bb163, label %bb164
bb162:
  br label %bb192
bb163:
  %t461 = load i8, ptr %l15, !tbaa !22
  %t463 = icmp eq i8 %t461, 43
  br i1 %t463, label %bb165, label %bb166
bb164:
  store i1 false, ptr %l246, !tbaa !21
  br label %bb186
bb165:
  store i1 true, ptr %l249, !tbaa !21
  br label %bb167
bb166:
  %t465 = load i8, ptr %l15, !tbaa !22
  %t467 = icmp eq i8 %t465, 45
  store i1 %t467, ptr %l249, !tbaa !21
  br label %bb167
bb167:
  %t469 = load i1, ptr %l249, !tbaa !21
  br i1 %t469, label %bb168, label %bb169
bb168:
  store i1 true, ptr %l252, !tbaa !21
  br label %bb170
bb169:
  %t470 = load i8, ptr %l15, !tbaa !22
  %t472 = icmp eq i8 %t470, 42
  store i1 %t472, ptr %l252, !tbaa !21
  br label %bb170
bb170:
  %t474 = load i1, ptr %l252, !tbaa !21
  br i1 %t474, label %bb171, label %bb172
bb171:
  store i1 true, ptr %l255, !tbaa !21
  br label %bb173
bb172:
  %t475 = load i8, ptr %l15, !tbaa !22
  %t477 = icmp eq i8 %t475, 47
  store i1 %t477, ptr %l255, !tbaa !21
  br label %bb173
bb173:
  %t479 = load i1, ptr %l255, !tbaa !21
  br i1 %t479, label %bb174, label %bb175
bb174:
  store i1 true, ptr %l258, !tbaa !21
  br label %bb176
bb175:
  %t480 = load i8, ptr %l15, !tbaa !22
  %t482 = icmp eq i8 %t480, 37
  store i1 %t482, ptr %l258, !tbaa !21
  br label %bb176
bb176:
  %t484 = load i1, ptr %l258, !tbaa !21
  br i1 %t484, label %bb177, label %bb178
bb177:
  store i1 true, ptr %l261, !tbaa !21
  br label %bb179
bb178:
  %t485 = load i8, ptr %l15, !tbaa !22
  %t487 = icmp eq i8 %t485, 38
  store i1 %t487, ptr %l261, !tbaa !21
  br label %bb179
bb179:
  %t489 = load i1, ptr %l261, !tbaa !21
  br i1 %t489, label %bb180, label %bb181
bb180:
  store i1 true, ptr %l264, !tbaa !21
  br label %bb182
bb181:
  %t490 = load i8, ptr %l15, !tbaa !22
  %t492 = icmp eq i8 %t490, 124
  store i1 %t492, ptr %l264, !tbaa !21
  br label %bb182
bb182:
  %t494 = load i1, ptr %l264, !tbaa !21
  br i1 %t494, label %bb183, label %bb184
bb183:
  store i1 true, ptr %l267, !tbaa !21
  br label %bb185
bb184:
  %t495 = load i8, ptr %l15, !tbaa !22
  %t497 = icmp eq i8 %t495, 94
  store i1 %t497, ptr %l267, !tbaa !21
  br label %bb185
bb185:
  %t499 = load i1, ptr %l267, !tbaa !21
  store i1 %t499, ptr %l246, !tbaa !21
  br label %bb186
bb186:
  %t500 = load i1, ptr %l246, !tbaa !21
  br i1 %t500, label %bb187, label %bb188
bb187:
  store %olang.scope zeroinitializer, ptr %s22
  %t501 = load i64, ptr %l5, !tbaa !24
  %t503 = sub i64 %t501, 1
  %t505 = trunc i64 %t503 to i32
  %t506 = load i64, ptr %l5, !tbaa !24
  %t508 = add i64 %t506, 1
  %t510 = trunc i64 %t508 to i32
  %t513 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s22, i32 %t505, i32 %t510)
  store %"compiler/source:Span" %t513, ptr %l276
  br label %bb189
bb188:
  br label %bb190
bb189:
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s0)
  %t514 = load %"compiler/source:Span", ptr %l276
  store %"compiler/source:Span" %t514, ptr %rv
  br label %ret
bb190:
  %t515 = load i64, ptr %l5, !tbaa !24
  %t517 = trunc i64 %t515 to i32
  %t518 = load i64, ptr %l5, !tbaa !24
  %t520 = add i64 %t518, 1
  %t522 = trunc i64 %t520 to i32
  %t525 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s21, i32 %t517, i32 %t522)
  store %"compiler/source:Span" %t525, ptr %l282
  br label %bb191
bb191:
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s0)
  %t526 = load %"compiler/source:Span", ptr %l282
  store %"compiler/source:Span" %t526, ptr %rv
  br label %ret
bb192:
  %t527 = load i64, ptr %l5, !tbaa !24
  %t529 = add i64 %t527, 1
  store i64 %t529, ptr %l5, !tbaa !24
  br label %bb193
bb193:
  br label %bb14
bb194:
  %t531 = load i1, ptr %l8, !tbaa !21
  %t533 = xor i1 %t531, true
  br i1 %t533, label %bb195, label %bb196
bb195:
  %t535 = getelementptr %"compiler/source:Span", ptr %l12, i32 0, i32 1
  %t536 = load i32, ptr %t535, !tbaa !23
  %t537 = getelementptr %"compiler/source:Span", ptr %l12, i32 0, i32 0
  %t538 = load i32, ptr %t537, !tbaa !23
  %t541 = icmp sgt i32 %t536, %t538
  store i1 %t541, ptr %l287, !tbaa !21
  br label %bb197
bb196:
  store i1 false, ptr %l287, !tbaa !21
  br label %bb197
bb197:
  %t543 = load i1, ptr %l287, !tbaa !21
  br i1 %t543, label %bb198, label %bb199
bb198:
  %t544 = load %"compiler/source:Span", ptr %l12
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/source:Span" %t544, ptr %rv
  br label %ret
bb199:
  br label %bb200
bb200:
  %t546 = load %"compiler/source:Span", ptr %l6
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/source:Span" %t546, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enewOrConst(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l10 = alloca i1
  %l11 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i1
  %l20 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l34 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l44 = alloca i1
  %l45 = alloca i1
  %l50 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t11 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %t6, ptr %t7)
  store i1 %t11, ptr %l10
  br label %bb4
bb4:
  %t12 = load i1, ptr %l10, !tbaa !21
  br i1 %t12, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb8
bb6:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t17 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisNullLit(ptr %v0, ptr %v1, ptr %t13, ptr %t14)
  store i1 %t17, ptr %l14
  br label %bb7
bb7:
  %t18 = load i1, ptr %l14, !tbaa !21
  store i1 %t18, ptr %l11, !tbaa !21
  br label %bb8
bb8:
  %t19 = load i1, ptr %l11, !tbaa !21
  br i1 %t19, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb12
bb10:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t24 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estaticLiteral(ptr %v0, ptr %v1, ptr %t20, ptr %t21)
  store i1 %t24, ptr %l18
  br label %bb11
bb11:
  %t25 = load i1, ptr %l18, !tbaa !21
  store i1 %t25, ptr %l15, !tbaa !21
  br label %bb12
bb12:
  %t26 = load i1, ptr %l15, !tbaa !21
  br i1 %t26, label %bb13, label %bb14
bb13:
  store i1 true, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t28 = load ptr, ptr %l1, !tbaa !29
  store ptr %t28, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t29 = load ptr, ptr %l21, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb16, label %bb17
bb16:
  %t32 = load ptr, ptr %l21, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 18}
  %t35 = icmp eq i64 %t33, 1
  store i1 %t35, ptr %l22, !tbaa !21
  br label %bb17
bb17:
  %t36 = load i1, ptr %l22, !tbaa !21
  br i1 %t36, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb44
bb21:
  %t37 = load ptr, ptr %l1, !tbaa !29
  store ptr %t37, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t38 = load ptr, ptr %l25, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb22, label %bb23
bb22:
  %t41 = load ptr, ptr %l25, !tbaa !29
  %t42 = load i64, ptr %t41, !range !{i64 0, i64 18}
  %t44 = icmp eq i64 %t42, 17
  store i1 %t44, ptr %l26, !tbaa !21
  br label %bb23
bb23:
  %t45 = load i1, ptr %l26, !tbaa !21
  br i1 %t45, label %bb24, label %bb25
bb24:
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr { i64, [5 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t48, i32 0, i32 2
  %t50 = load ptr, ptr %t49
  store ptr %t50, ptr %l2, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t57 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enewOrConst(ptr %v0, ptr %v1, ptr %t52, ptr %t53)
  store i1 %t57, ptr %l34
  br label %bb27
bb27:
  %t58 = load i1, ptr %l34, !tbaa !21
  store i1 %t58, ptr %l20, !tbaa !21
  br label %bb44
bb28:
  %t59 = load ptr, ptr %l1, !tbaa !29
  store ptr %t59, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t60 = load ptr, ptr %l35, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb29, label %bb30
bb29:
  %t63 = load ptr, ptr %l35, !tbaa !29
  %t64 = load i64, ptr %t63, !range !{i64 0, i64 18}
  %t66 = icmp eq i64 %t64, 11
  store i1 %t66, ptr %l36, !tbaa !21
  br label %bb30
bb30:
  %t67 = load i1, ptr %l36, !tbaa !21
  br i1 %t67, label %bb31, label %bb32
bb31:
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [5 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t70, i32 0, i32 2
  %t72 = load ptr, ptr %t71
  store ptr %t72, ptr %l3, !tbaa !29
  br label %bb33
bb32:
  br label %bb39
bb33:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load ptr, ptr %l3, !tbaa !29
  %t77 = getelementptr %"compiler/typed:Cond", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t81 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enewOrConst(ptr %v0, ptr %v1, ptr %t74, ptr %t78)
  store i1 %t81, ptr %l44
  br label %bb34
bb34:
  %t82 = load i1, ptr %l44, !tbaa !21
  br i1 %t82, label %bb35, label %bb36
bb35:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l3, !tbaa !29
  %t86 = getelementptr %"compiler/typed:Cond", ptr %t84, i32 0, i32 2
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t91 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enewOrConst(ptr %v0, ptr %v1, ptr %t83, ptr %t87)
  store i1 %t91, ptr %l50
  br label %bb37
bb36:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb38
bb37:
  %t92 = load i1, ptr %l50, !tbaa !21
  store i1 %t92, ptr %l45, !tbaa !21
  br label %bb38
bb38:
  %t93 = load i1, ptr %l45, !tbaa !21
  store i1 %t93, ptr %l20, !tbaa !21
  br label %bb44
bb39:
  br i1 true, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_13609328335a5af4_71f6842a5be0a9a0)
  unreachable
bb44:
  %t94 = load i1, ptr %l20, !tbaa !21
  store i1 %t94, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, %"compiler/msgs:Msg" %a4) #0 {
entry:
  %l3 = alloca %"compiler/source:Span"
  %t21 = alloca { i64, [3 x i64] }, align 8
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 4
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t13 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t14 = load i32, ptr %t13, !tbaa !23
  %t16 = sext i32 %t14 to i64
  %t17 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 1
  %t18 = load i32, ptr %t17, !tbaa !23
  %t20 = sext i32 %t18 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t21
  %t22 = getelementptr { i64, [3 x i64] }, ptr %t21, i32 0, i32 0
  store i64 3, ptr %t22
  %t24 = insertvalue { i64, i64, i64 } undef, i64 %a2, 0
  %t26 = insertvalue { i64, i64, i64 } %t24, i64 %t16, 1
  %t28 = insertvalue { i64, i64, i64 } %t26, i64 %t20, 2
  %t29 = getelementptr { i64, [3 x i64] }, ptr %t21, i32 0, i32 1
  store { i64, i64, i64 } %t28, ptr %t29
  %t30 = load { i64, [3 x i64] }, ptr %t21
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %t10, i64 %a1, { i64, [3 x i64] } %t30, %"compiler/msgs:Msg" %a4)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteMadeNamed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, i64 %a3, { i64, ptr } %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca %"compiler/typed:Local"
  %l20 = alloca i32
  %l21 = alloca { i64, ptr }
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca i32
  %l29 = alloca i64
  %l31 = alloca { i64, ptr }
  %l34 = alloca i1
  %l40 = alloca ptr
  %l44 = alloca i64
  %l47 = alloca i64
  %l65 = alloca ptr
  %l66 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca ptr
  %l77 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i1
  %l88 = alloca ptr
  %l89 = alloca i1
  %l97 = alloca ptr
  %l103 = alloca ptr
  %l107 = alloca i1
  %l110 = alloca ptr
  %l113 = alloca i32
  %l114 = alloca i64
  %l117 = alloca i1
  %l124 = alloca i1
  %l128 = alloca i64
  %l131 = alloca i1
  %l143 = alloca %"compiler/typed:Local"
  %l146 = alloca i1
  %l149 = alloca i1
  %l160 = alloca { i64, ptr }
  %l164 = alloca %"compiler/source:Span"
  %l167 = alloca ptr
  %l168 = alloca i64
  %l175 = alloca i64
  %l176 = alloca %"compiler/source:Span"
  %l179 = alloca %"compiler/msgs:Msg"
  %l180 = alloca ptr
  %l184 = alloca ptr
  %l185 = alloca i32
  %l189 = alloca ptr
  %l193 = alloca ptr
  %l197 = alloca i1
  %l200 = alloca ptr
  %l203 = alloca i32
  %l204 = alloca i64
  %l213 = alloca i1
  %l216 = alloca i1
  %l217 = alloca i1
  %l220 = alloca i1
  %l223 = alloca { i64, ptr }
  %l227 = alloca i1
  %l228 = alloca ptr
  %l231 = alloca i32
  %l232 = alloca i64
  %l234 = alloca ptr
  %l235 = alloca i64
  %l242 = alloca i64
  %l243 = alloca %"compiler/source:Span"
  %l248 = alloca %"compiler/msgs:Msg"
  %l254 = alloca i32
  %l257 = alloca i1
  %l259 = alloca i1
  %l262 = alloca i1
  %l264 = alloca i1
  %l268 = alloca i1
  %l277 = alloca i1
  %l278 = alloca i32
  %l283 = alloca i32
  %l288 = alloca i64
  %l291 = alloca i1
  %l294 = alloca ptr
  %l298 = alloca i32
  %l299 = alloca { i64, ptr }
  %l303 = alloca ptr
  %l304 = alloca i32
  %l308 = alloca i64
  %l309 = alloca i64
  %l313 = alloca i32
  %l314 = alloca i32
  %l325 = alloca i1
  %l326 = alloca i1
  %l331 = alloca i64
  %l336 = alloca i1
  %l339 = alloca i1
  %l341 = alloca { i64, ptr }
  %l348 = alloca { i64, ptr }
  %l350 = alloca ptr
  %l351 = alloca i64
  %l358 = alloca i64
  %l359 = alloca %"compiler/source:Span"
  %l365 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s21 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l5, !tbaa !24
  %t3 = icmp sgt i64 %t1, 8
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  store i1 %t7, ptr %l34, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l34, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  br label %bb6
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t15 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %v1, ptr %t10, ptr %t11)
  store ptr %t15, ptr %l40
  br label %bb7
bb7:
  %t16 = load ptr, ptr %l40, !tbaa !29
  store ptr %t16, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  store i64 16, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t17 = load i64, ptr %l8, !tbaa !24
  %t18 = load i64, ptr %l7, !tbaa !24
  %t21 = icmp sgt i64 %t17, %t18
  br i1 %t21, label %bb8, label %bb9
bb8:
  %t23 = load i64, ptr %l9, !tbaa !24
  %t25 = icmp sgt i64 %t23, 0
  br i1 %t25, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb13
bb10:
  %t27 = load i64, ptr %l8, !tbaa !24
  %t28 = load i64, ptr %l7, !tbaa !24
  %t31 = sub i64 %t27, %t28
  %t32 = load i64, ptr %l9, !tbaa !24
  %t35 = add i64 %t31, %t32
  %t37 = sub i64 %t35, 1
  %t38 = load i64, ptr %l9, !tbaa !24
  %t41 = sdiv i64 %t37, %t38
  store i64 %t41, ptr %l47, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb12
bb12:
  %t43 = load i64, ptr %l47, !tbaa !24
  store i64 %t43, ptr %l44, !tbaa !24
  br label %bb13
bb13:
  %t44 = load i64, ptr %l44, !tbaa !24
  store i64 %t44, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb14
bb14:
  %t45 = load i64, ptr %l11, !tbaa !24
  %t46 = load i64, ptr %l10, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb15, label %bb16
bb15:
  br label %bb60
bb16:
  br label %bb17
bb17:
  %t53 = load i64, ptr %l7, !tbaa !24
  %t54 = load i64, ptr %l11, !tbaa !24
  %t55 = load i64, ptr %l9, !tbaa !24
  %t58 = mul i64 %t54, %t55
  %t61 = add i64 %t53, %t58
  store i64 %t61, ptr %l12, !tbaa !24
  %t63 = load ptr, ptr %l6, !tbaa !29
  store ptr %t63, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t64 = load ptr, ptr %l65, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb18, label %bb19
bb18:
  %t67 = load ptr, ptr %l65, !tbaa !29
  %t68 = load i64, ptr %t67, !range !{i64 0, i64 18}
  %t70 = icmp eq i64 %t68, 5
  store i1 %t70, ptr %l66, !tbaa !21
  br label %bb19
bb19:
  %t71 = load i1, ptr %l66, !tbaa !21
  br i1 %t71, label %bb20, label %bb21
bb20:
  %t72 = load ptr, ptr %l6, !tbaa !29
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 2
  %t76 = load ptr, ptr %t75
  store ptr %t76, ptr %l13, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load ptr, ptr %l13, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Promote", ptr %t79, i32 0, i32 0
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t86 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %v1, ptr %t78, ptr %t82)
  store ptr %t86, ptr %l75
  br label %bb23
bb23:
  %t87 = load ptr, ptr %l75, !tbaa !29
  store ptr %t87, ptr %l6, !tbaa !29
  br label %bb58
bb24:
  %t88 = load ptr, ptr %l6, !tbaa !29
  store ptr %t88, ptr %l76, !tbaa !29
  store i1 false, ptr %l77, !tbaa !21
  %t89 = load ptr, ptr %l76, !tbaa !29
  %t90 = icmp ne ptr %t89, null
  br i1 %t90, label %bb25, label %bb26
bb25:
  %t92 = load ptr, ptr %l76, !tbaa !29
  %t93 = load i64, ptr %t92, !range !{i64 0, i64 18}
  %t95 = icmp eq i64 %t93, 2
  store i1 %t95, ptr %l77, !tbaa !21
  br label %bb26
bb26:
  %t96 = load i1, ptr %l77, !tbaa !21
  br i1 %t96, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l6, !tbaa !29
  %t99 = getelementptr { i64, [5 x i64] }, ptr %t97, i32 0, i32 1
  %t100 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t99, i32 0, i32 2
  %t101 = load ptr, ptr %t100
  store ptr %t101, ptr %l14, !tbaa !29
  br label %bb29
bb28:
  br label %bb53
bb29:
  %t103 = load ptr, ptr %l14, !tbaa !29
  store ptr %t103, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t104 = load ptr, ptr %l82, !tbaa !29
  %t105 = icmp ne ptr %t104, null
  br i1 %t105, label %bb30, label %bb31
bb30:
  %t107 = load ptr, ptr %l82, !tbaa !29
  %t108 = load i64, ptr %t107, !range !{i64 0, i64 8}
  %t110 = icmp eq i64 %t108, 3
  store i1 %t110, ptr %l83, !tbaa !21
  br label %bb31
bb31:
  %t111 = load i1, ptr %l83, !tbaa !21
  br i1 %t111, label %bb32, label %bb33
bb32:
  %t112 = load ptr, ptr %l14, !tbaa !29
  %t114 = getelementptr { i64, [4 x i64] }, ptr %t112, i32 0, i32 1
  %t115 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t114, i32 0, i32 2
  %t116 = load ptr, ptr %t115
  store ptr %t116, ptr %l15, !tbaa !29
  br label %bb34
bb33:
  br label %bb47
bb34:
  %t118 = load ptr, ptr %l15, !tbaa !29
  store ptr %t118, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t119 = load ptr, ptr %l88, !tbaa !29
  %t120 = icmp ne ptr %t119, null
  br i1 %t120, label %bb35, label %bb36
bb35:
  %t122 = load ptr, ptr %l88, !tbaa !29
  %t123 = load i64, ptr %t122, !range !{i64 0, i64 8}
  %t125 = icmp eq i64 %t123, 6
  store i1 %t125, ptr %l89, !tbaa !21
  br label %bb36
bb36:
  %t126 = load i1, ptr %l89, !tbaa !21
  br i1 %t126, label %bb37, label %bb38
bb37:
  %t127 = load ptr, ptr %l15, !tbaa !29
  %t129 = getelementptr { i64, [4 x i64] }, ptr %t127, i32 0, i32 1
  %t130 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t129, i32 0, i32 2
  %t131 = load ptr, ptr %t130
  store ptr %t131, ptr %l16, !tbaa !29
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load ptr, ptr %l16, !tbaa !29
  %t138 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %v1, ptr %t133, ptr %t134)
  store ptr %t138, ptr %l97
  br label %bb40
bb40:
  %t139 = load ptr, ptr %l97, !tbaa !29
  store ptr %t139, ptr %l6, !tbaa !29
  br label %bb46
bb41:
  br i1 true, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb60
bb45:
  call void @__olang_check_failed(ptr @olang_loc_2a83bf20490fb4f0_b79be661c23cb1e4)
  unreachable
bb46:
  br label %bb52
bb47:
  br i1 true, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb60
bb51:
  call void @__olang_check_failed(ptr @olang_loc_28967cbbf3bb5881_fc5c9419ee26cbd5)
  unreachable
bb52:
  br label %bb58
bb53:
  br i1 true, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb60
bb57:
  call void @__olang_check_failed(ptr @olang_loc_e2b2a689ed5c2c6a_2e02b8bd326f399e)
  unreachable
bb58:
  br label %bb59
bb59:
  %t140 = load i64, ptr %l11, !tbaa !24
  %t142 = add i64 %t140, 1
  store i64 %t142, ptr %l11, !tbaa !24
  br label %bb14
bb60:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load ptr, ptr %l6, !tbaa !29
  %t149 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallOf(ptr %v0, ptr %v1, ptr %v1, ptr %t144, ptr %t145)
  store ptr %t149, ptr %l103
  br label %bb61
bb61:
  %t150 = load ptr, ptr %l103, !tbaa !29
  store ptr %t150, ptr %l17, !tbaa !29
  %t151 = load ptr, ptr %l17, !tbaa !29
  %t153 = icmp eq ptr %t151, null
  %t155 = xor i1 %t153, true
  br i1 %t155, label %bb62, label %bb63
bb62:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/scope:Scoper", ptr %t157, i32 0, i32 0
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t162 = getelementptr %"compiler/generic:Program", ptr %t160, i32 0, i32 2
  store ptr %t162, ptr %l110, !tbaa !29
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load ptr, ptr %l17, !tbaa !29
  %t167 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %t163, ptr %t164)
  store i32 %t167, ptr %l113
  br label %bb64
bb63:
  store i1 false, ptr %l107, !tbaa !21
  br label %bb66
bb64:
  %t168 = load ptr, ptr %l110, !tbaa !29
  %t169 = load i32, ptr %l113, !tbaa !23
  %t170 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t168, i32 %t169)
  store i64 %t170, ptr %l114
  br label %bb65
bb65:
  %t171 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t172 = load i64, ptr %l114, !tbaa !24
  %t174 = icmp ne i64 %t172, %t171
  store i1 %t174, ptr %l107, !tbaa !21
  br label %bb66
bb66:
  %t176 = load i1, ptr %l107, !tbaa !21
  br i1 %t176, label %bb67, label %bb68
bb67:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load i64, ptr %l1, !tbaa !24
  %t179 = load ptr, ptr %l17, !tbaa !29
  %t180 = load i64, ptr %l3, !tbaa !24
  %t181 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t182 = load i64, ptr %l5, !tbaa !24
  %t189 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteThroughResult(ptr %v0, ptr %v1, ptr %v2, ptr %t177, i64 %t178, ptr %t179, i64 %t180, { i64, ptr } %t181, i64 %t182)
  store i1 %t189, ptr %l124
  br label %bb69
bb68:
  store i1 false, ptr %l117, !tbaa !21
  br label %bb70
bb69:
  %t190 = load i1, ptr %l124, !tbaa !21
  store i1 %t190, ptr %l117, !tbaa !21
  br label %bb70
bb70:
  %t191 = load i1, ptr %l117, !tbaa !21
  br i1 %t191, label %bb71, label %bb72
bb71:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb72:
  br label %bb73
bb73:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t193 = load ptr, ptr %l2, !tbaa !29
  %t197 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeLocal(ptr %v0, ptr %v1, ptr %t192, ptr %t193, i64 0)
  store i64 %t197, ptr %l128
  br label %bb74
bb74:
  %t198 = load i64, ptr %l128, !tbaa !24
  store i64 %t198, ptr %l18, !tbaa !24
  %t199 = load i64, ptr %l18, !tbaa !24
  %t201 = icmp slt i64 %t199, 0
  br i1 %t201, label %bb75, label %bb76
bb75:
  store i1 true, ptr %l131, !tbaa !21
  br label %bb77
bb76:
  %t203 = load i64, ptr %l18, !tbaa !24
  %t204 = load i64, ptr %l3, !tbaa !24
  %t207 = icmp eq i64 %t203, %t204
  store i1 %t207, ptr %l131, !tbaa !21
  br label %bb77
bb77:
  %t209 = load i1, ptr %l131, !tbaa !21
  br i1 %t209, label %bb78, label %bb79
bb78:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb79:
  br label %bb80
bb80:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t212 = getelementptr %"compiler/scope:Scoper", ptr %t210, i32 0, i32 25
  %t213 = load ptr, ptr %t212, !tbaa !29
  %t215 = icmp eq ptr %t213, null
  br i1 %t215, label %bb81, label %bb82
bb81:
  call void @__olang_check_failed(ptr @olang_loc_9f5a8ccf03b4db04_630c918a623736e8)
  unreachable
bb82:
  br label %bb83
bb83:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t219 = getelementptr %"compiler/scope:Scoper", ptr %t217, i32 0, i32 25
  %t220 = load ptr, ptr %t219, !tbaa !29
  %t223 = getelementptr %"compiler/typed:Body", ptr %t220, i32 0, i32 7
  %t224 = load i64, ptr %l18, !tbaa !24
  %t227 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t223, i64 %t224)
  store %"compiler/typed:Local" %t227, ptr %l143
  br label %bb84
bb84:
  %t228 = load %"compiler/typed:Local", ptr %l143
  store %"compiler/typed:Local" %t228, ptr %l19
  %t229 = getelementptr %"compiler/typed:Local", ptr %l19, i32 0, i32 0
  %t230 = load i32, ptr %t229, !tbaa !23
  %t232 = icmp eq i32 %t230, 0
  br i1 %t232, label %bb85, label %bb86
bb85:
  store i1 true, ptr %l146, !tbaa !21
  br label %bb88
bb86:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load i64, ptr %l18, !tbaa !24
  %t238 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eloopElement(ptr %v0, ptr %t234, i64 %t235)
  store i1 %t238, ptr %l149
  br label %bb87
bb87:
  %t239 = load i1, ptr %l149, !tbaa !21
  store i1 %t239, ptr %l146, !tbaa !21
  br label %bb88
bb88:
  %t240 = load i1, ptr %l146, !tbaa !21
  br i1 %t240, label %bb89, label %bb90
bb89:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb90:
  br label %bb91
bb91:
  %t241 = getelementptr %"compiler/typed:Local", ptr %l19, i32 0, i32 4
  %t242 = load i32, ptr %t241, !range !{i32 0, i32 7}
  store i32 %t242, ptr %l20
  %t244 = load i32, ptr %l20, !range !{i32 0, i32 7}
  %t246 = trunc i64 1 to i32
  %t247 = icmp eq i32 %t244, %t246
  br i1 %t247, label %bb92, label %bb93
bb92:
  br label %bb96
bb93:
  %t249 = load i32, ptr %l20, !range !{i32 0, i32 7}
  %t251 = trunc i64 4 to i32
  %t252 = icmp eq i32 %t249, %t251
  br i1 %t252, label %bb94, label %bb95
bb94:
  br label %bb96
bb95:
  br label %bb97
bb96:
  br label %bb102
bb97:
  br i1 true, label %bb98, label %bb99
bb98:
  br label %bb100
bb99:
  br label %bb101
bb100:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb101:
  call void @__olang_check_failed(ptr @olang_loc_f8891e21139a6c8c_91dd882c9f718fa8)
  unreachable
bb102:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = getelementptr %"compiler/scope:Scoper", ptr %t254, i32 0, i32 0
  %t257 = load ptr, ptr %t256, !tbaa !29
  %t259 = getelementptr %"compiler/generic:Program", ptr %t257, i32 0, i32 0
  %t260 = load ptr, ptr %t259, !tbaa !29
  %t262 = getelementptr %"compiler/load:Loader", ptr %t260, i32 0, i32 3
  %t263 = load ptr, ptr %t262, !tbaa !29
  %t264 = getelementptr %"compiler/typed:Local", ptr %l19, i32 0, i32 0
  %t265 = load i32, ptr %t264, !tbaa !23
  %t268 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t263, i32 %t265)
  store { i64, ptr } %t268, ptr %l160
  br label %bb103
bb103:
  %t269 = load { i64, ptr }, ptr %l160, !tbaa !27
  store { i64, ptr } %t269, ptr %l21, !tbaa !27
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"compiler/typed:Local", ptr %l19, i32 0, i32 1
  %t272 = load %"compiler/source:Span", ptr %t271
  %t273 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t277 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewordAt(ptr %v0, ptr %v0, ptr %t270, %"compiler/source:Span" %t272, { i64, ptr } %t273)
  store %"compiler/source:Span" %t277, ptr %l164
  br label %bb104
bb104:
  %t278 = load %"compiler/source:Span", ptr %l164
  store %"compiler/source:Span" %t278, ptr %l22
  %t279 = getelementptr %"compiler/typed:Local", ptr %l19, i32 0, i32 4
  %t280 = load i32, ptr %t279, !range !{i32 0, i32 7}
  %t282 = trunc i64 4 to i32
  %t283 = icmp eq i32 %t280, %t282
  br i1 %t283, label %bb105, label %bb106
bb105:
  store %olang.scope zeroinitializer, ptr %s17
  %t285 = load ptr, ptr %l0, !tbaa !29
  store ptr %t285, ptr %l167, !tbaa !29
  %t286 = load i64, ptr %l1, !tbaa !24
  store i64 %t286, ptr %l168, !tbaa !24
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t289 = getelementptr %"compiler/scope:Scoper", ptr %t287, i32 0, i32 25
  %t290 = load ptr, ptr %t289, !tbaa !29
  %t292 = icmp eq ptr %t290, null
  br i1 %t292, label %bb107, label %bb108
bb106:
  br label %bb112
bb107:
  call void @__olang_check_failed(ptr @olang_loc_7cb574562870c9ae_44cb25218e79651a)
  unreachable
bb108:
  br label %bb109
bb109:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t296 = getelementptr %"compiler/scope:Scoper", ptr %t294, i32 0, i32 25
  %t297 = load ptr, ptr %t296, !tbaa !29
  %t300 = getelementptr %"compiler/typed:Body", ptr %t297, i32 0, i32 3
  %t301 = load i64, ptr %t300, !tbaa !24
  store i64 %t301, ptr %l175, !tbaa !24
  %t302 = load %"compiler/source:Span", ptr %l22
  store %"compiler/source:Span" %t302, ptr %l176
  %t303 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t304 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t307 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteBindingWhere(ptr %v0, ptr %v2, ptr %s17, { i64, ptr } %t303, { i64, ptr } %t304)
  store %"compiler/msgs:Msg" %t307, ptr %l179
  br label %bb110
bb110:
  %t308 = load ptr, ptr %l167, !tbaa !29
  %t309 = load i64, ptr %l168, !tbaa !24
  %t310 = load i64, ptr %l175, !tbaa !24
  %t311 = load %"compiler/source:Span", ptr %l176
  %t312 = load %"compiler/msgs:Msg", ptr %l179
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enote(ptr %v0, ptr %s17, ptr %t308, i64 %t309, i64 %t310, %"compiler/source:Span" %t311, %"compiler/msgs:Msg" %t312)
  br label %bb111
bb111:
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb112:
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t315 = getelementptr %"compiler/scope:Scoper", ptr %t313, i32 0, i32 42
  %t316 = load i64, ptr %l18, !tbaa !24
  %t319 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v0, ptr %t315, i64 %t316)
  %t320 = extractvalue { i32, ptr } %t319, 1
  %t321 = extractvalue { i32, ptr } %t319, 0
  store i32 %t321, ptr %l185
  %t322 = icmp ne i32 %t321, 0
  br i1 %t322, label %bb114, label %ok.323, !prof !99
ok.323:
  store ptr %t320, ptr %l184
  br label %bb113
bb113:
  %t324 = load ptr, ptr %l184, !tbaa !29
  store ptr %t324, ptr %l180, !tbaa !29
  br label %bb116
bb114:
  br label %bb115
bb115:
  call void @__olang_ert_req_clear()
  store ptr null, ptr %l180, !tbaa !29
  br label %bb116
bb116:
  %t325 = load ptr, ptr %l180, !tbaa !29
  store ptr %t325, ptr %l23, !tbaa !29
  %t326 = load ptr, ptr %l23, !tbaa !29
  %t328 = icmp eq ptr %t326, null
  %t330 = xor i1 %t328, true
  br i1 %t330, label %bb117, label %bb118
bb117:
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t333 = load ptr, ptr %l23, !tbaa !29
  %t337 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallOf(ptr %v0, ptr %v0, ptr %s0, ptr %t332, ptr %t333)
  store ptr %t337, ptr %l193
  br label %bb119
bb118:
  store ptr null, ptr %l189, !tbaa !29
  br label %bb120
bb119:
  %t338 = load ptr, ptr %l193, !tbaa !29
  store ptr %t338, ptr %l189, !tbaa !29
  br label %bb120
bb120:
  %t339 = load ptr, ptr %l189, !tbaa !29
  store ptr %t339, ptr %l24, !tbaa !29
  %t340 = load ptr, ptr %l24, !tbaa !29
  %t342 = icmp eq ptr %t340, null
  %t344 = xor i1 %t342, true
  br i1 %t344, label %bb121, label %bb122
bb121:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t348 = getelementptr %"compiler/scope:Scoper", ptr %t346, i32 0, i32 0
  %t349 = load ptr, ptr %t348, !tbaa !29
  %t351 = getelementptr %"compiler/generic:Program", ptr %t349, i32 0, i32 2
  store ptr %t351, ptr %l200, !tbaa !29
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t353 = load ptr, ptr %l24, !tbaa !29
  %t356 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %s0, ptr %t352, ptr %t353)
  store i32 %t356, ptr %l203
  br label %bb123
bb122:
  store i1 false, ptr %l197, !tbaa !21
  br label %bb125
bb123:
  %t357 = load ptr, ptr %l200, !tbaa !29
  %t358 = load i32, ptr %l203, !tbaa !23
  %t359 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t357, i32 %t358)
  store i64 %t359, ptr %l204
  br label %bb124
bb124:
  %t360 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t361 = load i64, ptr %l204, !tbaa !24
  %t363 = icmp ne i64 %t361, %t360
  store i1 %t363, ptr %l197, !tbaa !21
  br label %bb125
bb125:
  %t365 = load i1, ptr %l197, !tbaa !21
  br i1 %t365, label %bb126, label %bb127
bb126:
  store %olang.scope zeroinitializer, ptr %s18
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t367 = load i64, ptr %l1, !tbaa !24
  %t368 = load ptr, ptr %l24, !tbaa !29
  %t369 = load i64, ptr %l3, !tbaa !24
  %t370 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t371 = load i64, ptr %l5, !tbaa !24
  %t378 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteThroughResult(ptr %v0, ptr %s0, ptr %v2, ptr %t366, i64 %t367, ptr %t368, i64 %t369, { i64, ptr } %t370, i64 %t371)
  store i1 %t378, ptr %l213
  br label %bb128
bb127:
  br label %bb154
bb128:
  %t379 = load i1, ptr %l213, !tbaa !21
  br i1 %t379, label %bb129, label %bb130
bb129:
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb130:
  br label %bb131
bb131:
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t381 = load ptr, ptr %l24, !tbaa !29
  %t384 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisMethodCall(ptr %v0, ptr %s0, ptr %t380, ptr %t381)
  store i1 %t384, ptr %l216
  br label %bb132
bb132:
  %t385 = load i1, ptr %l216, !tbaa !21
  br i1 %t385, label %bb133, label %bb134
bb133:
  store i1 true, ptr %l217, !tbaa !21
  br label %bb136
bb134:
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t387 = load ptr, ptr %l24, !tbaa !29
  %t390 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eindexCall(ptr %v0, ptr %s0, ptr %t386, ptr %t387)
  store i1 %t390, ptr %l220
  br label %bb135
bb135:
  %t391 = load i1, ptr %l220, !tbaa !21
  store i1 %t391, ptr %l217, !tbaa !21
  br label %bb136
bb136:
  %t392 = load i1, ptr %l217, !tbaa !21
  br i1 %t392, label %bb137, label %bb138
bb137:
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb138:
  br label %bb139
bb139:
  %t393 = load ptr, ptr %l0, !tbaa !29
  %t394 = load ptr, ptr %l24, !tbaa !29
  %t397 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeName(ptr %v0, ptr %s0, ptr %s18, ptr %t393, ptr %t394)
  store { i64, ptr } %t397, ptr %l223
  br label %bb140
bb140:
  %t398 = load { i64, ptr }, ptr %l223, !tbaa !27
  store { i64, ptr } %t398, ptr %l25, !tbaa !27
  %t399 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t401 = extractvalue { i64, ptr } %t399, 0
  %t403 = icmp sgt i64 %t401, 0
  br i1 %t403, label %bb141, label %bb142
bb141:
  %t405 = load ptr, ptr %l0, !tbaa !29
  store ptr %t405, ptr %l228, !tbaa !29
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t407 = load ptr, ptr %l24, !tbaa !29
  %t410 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %s0, ptr %t406, ptr %t407)
  store i32 %t410, ptr %l231
  br label %bb143
bb142:
  store i1 false, ptr %l227, !tbaa !21
  br label %bb145
bb143:
  %t411 = load ptr, ptr %l228, !tbaa !29
  %t412 = load i32, ptr %l231, !tbaa !23
  %t413 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eresultVarOf(ptr %v0, ptr %t411, i32 %t412)
  store i64 %t413, ptr %l232
  br label %bb144
bb144:
  %t414 = load i64, ptr %l232, !tbaa !24
  %t415 = icmp sge i64 %t414, 0
  store i1 %t415, ptr %l227, !tbaa !21
  br label %bb145
bb145:
  %t417 = load i1, ptr %l227, !tbaa !21
  br i1 %t417, label %bb146, label %bb147
bb146:
  store %olang.scope zeroinitializer, ptr %s21
  %t418 = load ptr, ptr %l0, !tbaa !29
  store ptr %t418, ptr %l234, !tbaa !29
  %t419 = load i64, ptr %l1, !tbaa !24
  store i64 %t419, ptr %l235, !tbaa !24
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t422 = getelementptr %"compiler/scope:Scoper", ptr %t420, i32 0, i32 25
  %t423 = load ptr, ptr %t422, !tbaa !29
  %t425 = icmp eq ptr %t423, null
  br i1 %t425, label %bb148, label %bb149
bb147:
  br label %bb153
bb148:
  call void @__olang_check_failed(ptr @olang_loc_a5d7ffc0375a2adf_b8092e4cba9985db)
  unreachable
bb149:
  br label %bb150
bb150:
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t429 = getelementptr %"compiler/scope:Scoper", ptr %t427, i32 0, i32 25
  %t430 = load ptr, ptr %t429, !tbaa !29
  %t433 = getelementptr %"compiler/typed:Body", ptr %t430, i32 0, i32 3
  %t434 = load i64, ptr %t433, !tbaa !24
  store i64 %t434, ptr %l242, !tbaa !24
  %t435 = load %"compiler/source:Span", ptr %l22
  store %"compiler/source:Span" %t435, ptr %l243
  %t436 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t437 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t438 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t439 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t444 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteMakeWhere(ptr %v0, ptr %v2, ptr %s18, ptr %v2, ptr %s21, { i64, ptr } %t436, { i64, ptr } %t437, { i64, ptr } %t438, { i64, ptr } %t439)
  store %"compiler/msgs:Msg" %t444, ptr %l248
  br label %bb151
bb151:
  %t445 = load ptr, ptr %l234, !tbaa !29
  %t446 = load i64, ptr %l235, !tbaa !24
  %t447 = load i64, ptr %l242, !tbaa !24
  %t448 = load %"compiler/source:Span", ptr %l243
  %t449 = load %"compiler/msgs:Msg", ptr %l248
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enote(ptr %v0, ptr %s21, ptr %t445, i64 %t446, i64 %t447, %"compiler/source:Span" %t448, %"compiler/msgs:Msg" %t449)
  br label %bb152
bb152:
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb153:
  call void @__olang_scope_close(ptr %s18)
  br label %bb154
bb154:
  %t450 = getelementptr %"compiler/typed:Local", ptr %l19, i32 0, i32 2
  %t451 = load i32, ptr %t450, !tbaa !23
  store i32 %t451, ptr %l26, !tbaa !23
  %t453 = load ptr, ptr %l0, !tbaa !29
  %t455 = getelementptr %"compiler/scope:Scoper", ptr %t453, i32 0, i32 0
  %t456 = load ptr, ptr %t455, !tbaa !29
  %t458 = getelementptr %"compiler/generic:Program", ptr %t456, i32 0, i32 2
  %t459 = load i32, ptr %l26, !tbaa !23
  %t462 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t458, i32 %t459)
  store i32 %t462, ptr %l254
  br label %bb155
bb155:
  %t463 = load i32, ptr %l254, !range !{i32 0, i32 33}
  store i32 %t463, ptr %l27
  %t464 = load ptr, ptr %l0, !tbaa !29
  %t465 = load i32, ptr %l26, !tbaa !23
  %t468 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t464, i32 %t465)
  store i1 %t468, ptr %l257
  br label %bb156
bb156:
  %t469 = load i1, ptr %l257, !tbaa !21
  %t470 = xor i1 %t469, true
  br i1 %t470, label %bb157, label %bb158
bb157:
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t473 = load i32, ptr %l26, !tbaa !23
  %t476 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t472, i32 %t473)
  store i1 %t476, ptr %l262
  br label %bb159
bb158:
  store i1 false, ptr %l259, !tbaa !21
  br label %bb160
bb159:
  %t477 = load i1, ptr %l262, !tbaa !21
  %t478 = xor i1 %t477, true
  store i1 %t478, ptr %l259, !tbaa !21
  br label %bb160
bb160:
  %t480 = load i1, ptr %l259, !tbaa !21
  br i1 %t480, label %bb161, label %bb162
bb161:
  %t481 = load i32, ptr %l27, !range !{i32 0, i32 33}
  %t483 = trunc i64 19 to i32
  %t484 = icmp eq i32 %t481, %t483
  %t486 = xor i1 %t484, true
  store i1 %t486, ptr %l264, !tbaa !21
  br label %bb163
bb162:
  store i1 false, ptr %l264, !tbaa !21
  br label %bb163
bb163:
  %t488 = load i1, ptr %l264, !tbaa !21
  br i1 %t488, label %bb164, label %bb165
bb164:
  %t489 = load i32, ptr %l27, !range !{i32 0, i32 33}
  %t491 = trunc i64 18 to i32
  %t492 = icmp eq i32 %t489, %t491
  %t494 = xor i1 %t492, true
  store i1 %t494, ptr %l268, !tbaa !21
  br label %bb166
bb165:
  store i1 false, ptr %l268, !tbaa !21
  br label %bb166
bb166:
  %t496 = load i1, ptr %l268, !tbaa !21
  br i1 %t496, label %bb167, label %bb168
bb167:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb168:
  br label %bb169
bb169:
  %t497 = load ptr, ptr %l0, !tbaa !29
  %t499 = getelementptr %"compiler/scope:Scoper", ptr %t497, i32 0, i32 5
  %t500 = load { ptr, ptr }, ptr %t499
  %t502 = extractvalue { ptr, ptr } %t500, 0
  %t503 = extractvalue { ptr, ptr } zeroinitializer, 0
  %t504 = icmp eq ptr %t502, %t503
  %t505 = extractvalue { ptr, ptr } %t500, 1
  %t506 = extractvalue { ptr, ptr } zeroinitializer, 1
  %t507 = icmp eq ptr %t505, %t506
  %t508 = and i1 %t504, %t507
  br i1 %t508, label %bb170, label %bb171
bb170:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb171:
  br label %bb172
bb172:
  %t510 = load ptr, ptr %l0, !tbaa !29
  %t511 = load i32, ptr %l26, !tbaa !23
  %t514 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t510, i32 %t511)
  store i1 %t514, ptr %l277
  br label %bb173
bb173:
  %t515 = load i1, ptr %l277, !tbaa !21
  br i1 %t515, label %bb174, label %bb175
bb174:
  %t516 = load ptr, ptr %l0, !tbaa !29
  %t518 = getelementptr %"compiler/scope:Scoper", ptr %t516, i32 0, i32 0
  %t519 = load ptr, ptr %t518, !tbaa !29
  %t521 = getelementptr %"compiler/generic:Program", ptr %t519, i32 0, i32 2
  %t522 = load i32, ptr %l26, !tbaa !23
  %t525 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t521, i32 %t522)
  store i32 %t525, ptr %l283
  br label %bb176
bb175:
  %t526 = load i32, ptr %l26, !tbaa !23
  store i32 %t526, ptr %l278, !tbaa !23
  br label %bb177
bb176:
  %t528 = load i32, ptr %l283, !tbaa !23
  store i32 %t528, ptr %l278, !tbaa !23
  br label %bb177
bb177:
  %t529 = load i32, ptr %l278, !tbaa !23
  store i32 %t529, ptr %l28, !tbaa !23
  %t530 = load ptr, ptr %l0, !tbaa !29
  %t531 = load ptr, ptr %l0, !tbaa !29
  %t533 = getelementptr %"compiler/scope:Scoper", ptr %t531, i32 0, i32 26
  %t534 = load i64, ptr %t533, !tbaa !24
  %t537 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2einstanceOf(ptr %v0, ptr %t530, i64 %t534)
  store i64 %t537, ptr %l288
  br label %bb178
bb178:
  %t538 = load i64, ptr %l288, !tbaa !24
  store i64 %t538, ptr %l29, !tbaa !24
  %t539 = load i64, ptr %l29, !tbaa !24
  %t541 = icmp sge i64 %t539, 0
  br i1 %t541, label %bb179, label %bb180
bb179:
  %t543 = load ptr, ptr %l0, !tbaa !29
  %t545 = getelementptr %"compiler/scope:Scoper", ptr %t543, i32 0, i32 0
  %t546 = load ptr, ptr %t545, !tbaa !29
  %t548 = getelementptr %"compiler/generic:Program", ptr %t546, i32 0, i32 2
  store ptr %t548, ptr %l294, !tbaa !29
  %t549 = load ptr, ptr %l0, !tbaa !29
  %t551 = getelementptr %"compiler/scope:Scoper", ptr %t549, i32 0, i32 0
  %t552 = load ptr, ptr %t551, !tbaa !29
  %t553 = load i64, ptr %l29, !tbaa !24
  %t556 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t552, i64 %t553)
  store i32 %t556, ptr %l298
  br label %bb181
bb180:
  store i1 false, ptr %l291, !tbaa !21
  br label %bb183
bb181:
  %t557 = load ptr, ptr %l294, !tbaa !29
  %t558 = load i32, ptr %l298, !tbaa !23
  %t559 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t557, i32 %t558)
  store { i64, ptr } %t559, ptr %l299
  br label %bb182
bb182:
  %t560 = load { i64, ptr }, ptr %l299, !tbaa !27
  %t561 = extractvalue { i64, ptr } %t560, 0
  %t563 = icmp sgt i64 %t561, 0
  store i1 %t563, ptr %l291, !tbaa !21
  br label %bb183
bb183:
  %t565 = load i1, ptr %l291, !tbaa !21
  br i1 %t565, label %bb184, label %bb185
bb184:
  %t566 = load ptr, ptr %l0, !tbaa !29
  %t568 = getelementptr %"compiler/scope:Scoper", ptr %t566, i32 0, i32 0
  %t569 = load ptr, ptr %t568, !tbaa !29
  store ptr %t569, ptr %l303, !tbaa !29
  %t570 = load i32, ptr %l28, !tbaa !23
  store i32 %t570, ptr %l304, !tbaa !23
  %t571 = load ptr, ptr %l0, !tbaa !29
  %t573 = getelementptr %"compiler/scope:Scoper", ptr %t571, i32 0, i32 0
  %t574 = load ptr, ptr %t573, !tbaa !29
  %t575 = load i64, ptr %l29, !tbaa !24
  %t578 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t574, i64 %t575)
  store i64 %t578, ptr %l308
  br label %bb186
bb185:
  br label %bb194
bb186:
  %t579 = load i64, ptr %l308, !tbaa !24
  %t580 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t579)
  store i64 %t580, ptr %l309
  br label %bb187
bb187:
  %t581 = load ptr, ptr %l0, !tbaa !29
  %t583 = getelementptr %"compiler/scope:Scoper", ptr %t581, i32 0, i32 0
  %t584 = load ptr, ptr %t583, !tbaa !29
  %t585 = load i64, ptr %l29, !tbaa !24
  %t588 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t584, i64 %t585)
  store i32 %t588, ptr %l313
  br label %bb188
bb188:
  %t589 = load ptr, ptr %l303, !tbaa !29
  %t590 = load i32, ptr %l304, !tbaa !23
  %t591 = load i64, ptr %l309, !tbaa !24
  %t592 = load i32, ptr %l313, !tbaa !23
  %t593 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnsubst(ptr %v0, ptr %t589, i32 %t590, i64 %t591, i32 %t592)
  store i32 %t593, ptr %l314
  br label %bb189
bb189:
  %t594 = load i32, ptr %l314, !tbaa !23
  store i32 %t594, ptr %l28, !tbaa !23
  %t595 = load i32, ptr %l28, !tbaa !23
  %t596 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t599 = icmp eq i32 %t595, %t596
  br i1 %t599, label %bb190, label %bb191
bb190:
  %t601 = load ptr, ptr %l0, !tbaa !29
  %t603 = getelementptr %"compiler/scope:Scoper", ptr %t601, i32 0, i32 0
  %t604 = load ptr, ptr %t603, !tbaa !29
  %t606 = getelementptr %"compiler/generic:Program", ptr %t604, i32 0, i32 0
  %t607 = load ptr, ptr %t606, !tbaa !29
  %t609 = getelementptr %"compiler/load:Loader", ptr %t607, i32 0, i32 4
  %t610 = load ptr, ptr %t609, !tbaa !29
  %t611 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eYield(ptr %v0, ptr %t610, i64 %t611)
  br label %bb192
bb191:
  br label %bb193
bb192:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb193:
  br label %bb194
bb194:
  %t614 = load ptr, ptr %l0, !tbaa !29
  %t615 = load i32, ptr %l26, !tbaa !23
  %t618 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t614, i32 %t615)
  store i1 %t618, ptr %l325
  br label %bb195
bb195:
  %t619 = load i1, ptr %l325, !tbaa !21
  br i1 %t619, label %bb196, label %bb197
bb196:
  %t620 = load ptr, ptr %l0, !tbaa !29
  %t622 = getelementptr %"compiler/scope:Scoper", ptr %t620, i32 0, i32 0
  %t623 = load ptr, ptr %t622, !tbaa !29
  %t625 = getelementptr %"compiler/generic:Program", ptr %t623, i32 0, i32 2
  %t626 = load i32, ptr %l26, !tbaa !23
  %t629 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t625, i32 %t626)
  store i64 %t629, ptr %l331
  br label %bb198
bb197:
  store i1 true, ptr %l326, !tbaa !21
  br label %bb199
bb198:
  %t630 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t631 = load i64, ptr %l331, !tbaa !24
  %t633 = and i64 %t631, %t630
  %t635 = icmp ne i64 %t633, 0
  store i1 %t635, ptr %l326, !tbaa !21
  br label %bb199
bb199:
  %t637 = load i1, ptr %l326, !tbaa !21
  br i1 %t637, label %bb200, label %bb201
bb200:
  %t640 = load ptr, ptr %l0, !tbaa !29
  %t641 = load i32, ptr %l28, !tbaa !23
  %t644 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFunc(ptr %v0, ptr %t640, i32 %t641)
  store i1 %t644, ptr %l339
  br label %bb202
bb201:
  store i1 false, ptr %l336, !tbaa !21
  br label %bb203
bb202:
  %t645 = load i1, ptr %l339, !tbaa !21
  %t646 = xor i1 %t645, true
  store i1 %t646, ptr %l336, !tbaa !21
  br label %bb203
bb203:
  %t648 = load i1, ptr %l336, !tbaa !21
  br i1 %t648, label %bb204, label %bb205
bb204:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l341, !tbaa !27
  br label %bb206
bb205:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %l341, !tbaa !27
  br label %bb206
bb206:
  %t649 = load ptr, ptr %l0, !tbaa !29
  %t651 = getelementptr %"compiler/scope:Scoper", ptr %t649, i32 0, i32 5
  %t652 = load { ptr, ptr }, ptr %t651
  %t654 = extractvalue { ptr, ptr } %t652, 0
  %t655 = extractvalue { ptr, ptr } zeroinitializer, 0
  %t656 = icmp eq ptr %t654, %t655
  %t657 = extractvalue { ptr, ptr } %t652, 1
  %t658 = extractvalue { ptr, ptr } zeroinitializer, 1
  %t659 = icmp eq ptr %t657, %t658
  %t660 = and i1 %t656, %t659
  br i1 %t660, label %bb207, label %bb208
bb207:
  call void @__olang_check_failed(ptr @olang_loc_b5bb9adcdc2b0f40_ee4aa96e819ebaec)
  unreachable
bb208:
  br label %bb209
bb209:
  %t662 = load ptr, ptr %l0, !tbaa !29
  %t664 = getelementptr %"compiler/scope:Scoper", ptr %t662, i32 0, i32 5
  %t665 = load { ptr, ptr }, ptr %t664
  %t666 = load i32, ptr %l28, !tbaa !23
  %t668 = extractvalue { ptr, ptr } %t665, 0
  %t669 = extractvalue { ptr, ptr } %t665, 1
  %t671 = call { i64, ptr } %t668(ptr %t669, ptr %s0, i32 %t666)
  store { i64, ptr } %t671, ptr %l348
  br label %bb210
bb210:
  %t672 = load { i64, ptr }, ptr %l341, !tbaa !27
  %t673 = extractvalue { i64, ptr } %t672, 1
  %t674 = extractvalue { i64, ptr } %t672, 0
  %t675 = load { i64, ptr }, ptr %l348, !tbaa !27
  %t676 = extractvalue { i64, ptr } %t675, 1
  %t677 = extractvalue { i64, ptr } %t675, 0
  %t678 = add i64 %t674, %t677
  %t679 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t678)
  call void @olang_textcopy(ptr %t679, ptr %t673, i64 %t674)
  %t680 = getelementptr i8, ptr %t679, i64 %t674
  call void @olang_textcopy(ptr %t680, ptr %t676, i64 %t677)
  %t681 = insertvalue { i64, ptr } undef, i64 %t678, 0
  %t682 = insertvalue { i64, ptr } %t681, ptr %t679, 1
  store { i64, ptr } %t682, ptr %l31, !tbaa !27
  %t684 = load ptr, ptr %l0, !tbaa !29
  store ptr %t684, ptr %l350, !tbaa !29
  %t685 = load i64, ptr %l1, !tbaa !24
  store i64 %t685, ptr %l351, !tbaa !24
  %t686 = load ptr, ptr %l0, !tbaa !29
  %t688 = getelementptr %"compiler/scope:Scoper", ptr %t686, i32 0, i32 25
  %t689 = load ptr, ptr %t688, !tbaa !29
  %t691 = icmp eq ptr %t689, null
  br i1 %t691, label %bb211, label %bb212
bb211:
  call void @__olang_check_failed(ptr @olang_loc_dc99584e852f79f1_8cdbb8da6d334485)
  unreachable
bb212:
  br label %bb213
bb213:
  %t693 = load ptr, ptr %l0, !tbaa !29
  %t695 = getelementptr %"compiler/scope:Scoper", ptr %t693, i32 0, i32 25
  %t696 = load ptr, ptr %t695, !tbaa !29
  %t699 = getelementptr %"compiler/typed:Body", ptr %t696, i32 0, i32 3
  %t700 = load i64, ptr %t699, !tbaa !24
  store i64 %t700, ptr %l358, !tbaa !24
  %t701 = load %"compiler/source:Span", ptr %l22
  store %"compiler/source:Span" %t701, ptr %l359
  %t702 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t703 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t704 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t705 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t706 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t712 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDeclareWhere(ptr %v0, ptr %v2, ptr %v0, ptr %s0, ptr %v2, ptr %s0, { i64, ptr } %t702, { i64, ptr } %t703, { i64, ptr } %t704, { i64, ptr } %t705, { i64, ptr } %t706)
  store %"compiler/msgs:Msg" %t712, ptr %l365
  br label %bb214
bb214:
  %t713 = load ptr, ptr %l350, !tbaa !29
  %t714 = load i64, ptr %l351, !tbaa !24
  %t715 = load i64, ptr %l358, !tbaa !24
  %t716 = load %"compiler/source:Span", ptr %l359
  %t717 = load %"compiler/msgs:Msg", ptr %l365
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enote(ptr %v0, ptr %s0, ptr %t713, i64 %t714, i64 %t715, %"compiler/source:Span" %t716, %"compiler/msgs:Msg" %t717)
  br label %bb215
bb215:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteThroughResult(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, i64 %a3, { i64, ptr } %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca %"compiler/scope:rel"
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i1
  %l26 = alloca i1
  %l29 = alloca ptr
  %l32 = alloca i32
  %l33 = alloca i64
  %l37 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca ptr
  %l44 = alloca i64
  %l46 = alloca i64
  %l51 = alloca %"compiler/scope:rel"
  %l54 = alloca i1
  %l59 = alloca i1
  %l62 = alloca i1
  %l69 = alloca i64
  %l77 = alloca { i64, ptr }
  %l81 = alloca i64
  %l83 = alloca i1
  %l86 = alloca i1
  %l96 = alloca i64
  %l101 = alloca { i64, ptr }
  %l110 = alloca i64
  %l112 = alloca i64
  %l117 = alloca i64
  %l121 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Call", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t8 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebodyOf(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store i64 %t8, ptr %l20
  br label %bb1
bb1:
  %t9 = load i64, ptr %l20, !tbaa !24
  store i64 %t9, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l6, !tbaa !24
  %t12 = icmp slt i64 %t10, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb5
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i64, ptr %l6, !tbaa !24
  %t18 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esummed(ptr %v0, ptr %t14, i64 %t15)
  store i1 %t18, ptr %l26
  br label %bb4
bb4:
  %t19 = load i1, ptr %l26, !tbaa !21
  %t20 = xor i1 %t19, true
  store i1 %t20, ptr %l23, !tbaa !21
  br label %bb5
bb5:
  %t22 = load i1, ptr %l23, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l29, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t29 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %t25, ptr %t26)
  store i32 %t29, ptr %l32
  br label %bb9
bb9:
  %t30 = load ptr, ptr %l29, !tbaa !29
  %t31 = load i32, ptr %l32, !tbaa !23
  %t32 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eresultVarOf(ptr %v0, ptr %t30, i32 %t31)
  store i64 %t32, ptr %l33
  br label %bb10
bb10:
  %t33 = load i64, ptr %l33, !tbaa !24
  store i64 %t33, ptr %l7, !tbaa !24
  %t34 = load i64, ptr %l7, !tbaa !24
  %t36 = icmp slt i64 %t34, 0
  br i1 %t36, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  store i64 -1, ptr %l8, !tbaa !24
  %t39 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %l37
  br label %bb14
bb14:
  %t40 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l37
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %l9
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/scope:Scoper", ptr %t41, i32 0, i32 6
  %t44 = load i64, ptr %l6, !tbaa !24
  %t47 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t43, i64 %t44)
  store ptr %t47, ptr %l41
  br label %bb15
bb15:
  %t48 = load ptr, ptr %l41, !tbaa !29
  %t50 = getelementptr %"compiler/scope:summary", ptr %t48, i32 0, i32 0
  store ptr %t50, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb16
bb16:
  %t52 = load i64, ptr %l11, !tbaa !24
  store i64 %t52, ptr %l44, !tbaa !24
  %t53 = load ptr, ptr %l10, !tbaa !29
  %t55 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t53)
  store i64 %t55, ptr %l46
  br label %bb17
bb17:
  %t56 = load i64, ptr %l44, !tbaa !24
  %t57 = load i64, ptr %l46, !tbaa !24
  %t58 = icmp slt i64 %t56, %t57
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb18, label %bb19
bb18:
  br label %bb51
bb19:
  br label %bb20
bb20:
  %t62 = load ptr, ptr %l10, !tbaa !29
  %t63 = load i64, ptr %l11, !tbaa !24
  %t66 = call %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t62, i64 %t63)
  store %"compiler/scope:rel" %t66, ptr %l51
  br label %bb21
bb21:
  %t67 = load %"compiler/scope:rel", ptr %l51
  store %"compiler/scope:rel" %t67, ptr %l12
  %t68 = getelementptr %"compiler/scope:rel", ptr %l12, i32 0, i32 1
  %t69 = load { i64, [2 x i64] }, ptr %t68
  %t71 = extractvalue { i64, [2 x i64] } %t69, 0
  %t72 = icmp eq i64 %t71, 2
  br i1 %t72, label %bb22, label %bb23
bb22:
  %t74 = getelementptr %"compiler/scope:rel", ptr %l12, i32 0, i32 1
  %t75 = getelementptr { i64, [2 x i64] }, ptr %t74, i32 0, i32 1
  %t76 = getelementptr { i64 }, ptr %t75, i32 0, i32 0
  %t77 = load i64, ptr %t76
  %t78 = load i64, ptr %l7, !tbaa !24
  %t81 = icmp eq i64 %t77, %t78
  store i1 %t81, ptr %l54, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb24
bb24:
  %t83 = load i1, ptr %l54, !tbaa !21
  %t84 = xor i1 %t83, true
  br i1 %t84, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l59, !tbaa !21
  br label %bb30
bb26:
  %t86 = getelementptr %"compiler/scope:rel", ptr %l12, i32 0, i32 0
  %t87 = load { i64, [2 x i64] }, ptr %t86
  %t89 = extractvalue { i64, [2 x i64] } %t87, 0
  %t90 = icmp eq i64 %t89, 2
  br i1 %t90, label %bb27, label %bb28
bb27:
  %t92 = getelementptr %"compiler/scope:rel", ptr %l12, i32 0, i32 0
  %t93 = getelementptr { i64, [2 x i64] }, ptr %t92, i32 0, i32 1
  %t94 = getelementptr { i64 }, ptr %t93, i32 0, i32 0
  %t95 = load i64, ptr %t94
  %t96 = load i64, ptr %l7, !tbaa !24
  %t99 = icmp eq i64 %t95, %t96
  store i1 %t99, ptr %l62, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb29
bb29:
  %t101 = load i1, ptr %l62, !tbaa !21
  store i1 %t101, ptr %l59, !tbaa !21
  br label %bb30
bb30:
  %t102 = load i1, ptr %l59, !tbaa !21
  br i1 %t102, label %bb31, label %bb32
bb31:
  br label %bb50
bb32:
  br label %bb33
bb33:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load ptr, ptr %l2, !tbaa !29
  %t105 = getelementptr %"compiler/scope:rel", ptr %l12, i32 0, i32 0
  %t106 = load { i64, [2 x i64] }, ptr %t105
  %t110 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargOfVar(ptr %v0, ptr %v1, ptr %t103, ptr %t104, { i64, [2 x i64] } %t106)
  store i64 %t110, ptr %l69
  br label %bb34
bb34:
  %t111 = load i64, ptr %l69, !tbaa !24
  store i64 %t111, ptr %l13, !tbaa !24
  %t112 = load i64, ptr %l13, !tbaa !24
  %t114 = icmp slt i64 %t112, 0
  br i1 %t114, label %bb35, label %bb36
bb35:
  br label %bb50
bb36:
  br label %bb37
bb37:
  %t116 = load i64, ptr %l8, !tbaa !24
  %t118 = icmp slt i64 %t116, 0
  br i1 %t118, label %bb38, label %bb39
bb38:
  %t120 = load i64, ptr %l13, !tbaa !24
  store i64 %t120, ptr %l8, !tbaa !24
  br label %bb40
bb39:
  br label %bb40
bb40:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load ptr, ptr %l2, !tbaa !29
  %t125 = getelementptr %"compiler/typed:Call", ptr %t123, i32 0, i32 1
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  store { i64, ptr } %t126, ptr %l77, !tbaa !27
  %t127 = load i64, ptr %l13, !tbaa !24
  %t129 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr ptr, ptr %t130, i64 %t127
  %t132 = load ptr, ptr %t131, !tbaa !39
  %t136 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeLocal(ptr %v0, ptr %v1, ptr %t122, ptr %t132, i64 0)
  store i64 %t136, ptr %l81
  br label %bb41
bb41:
  %t137 = load i64, ptr %l81, !tbaa !24
  %t138 = icmp sge i64 %t137, 0
  br i1 %t138, label %bb42, label %bb43
bb42:
  %t140 = load i64, ptr %l13, !tbaa !24
  %t143 = call i1 @compiler_2fscope_2eflHas(ptr %s0, ptr %l9, i64 %t140)
  store i1 %t143, ptr %l86
  br label %bb44
bb43:
  store i1 false, ptr %l83, !tbaa !21
  br label %bb45
bb44:
  %t144 = load i1, ptr %l86, !tbaa !21
  %t145 = xor i1 %t144, true
  store i1 %t145, ptr %l83, !tbaa !21
  br label %bb45
bb45:
  %t147 = load i1, ptr %l83, !tbaa !21
  br i1 %t147, label %bb46, label %bb47
bb46:
  %t148 = load i64, ptr %l13, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l9, i64 %t148)
  br label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t151 = load i64, ptr %l11, !tbaa !24
  %t153 = add i64 %t151, 1
  store i64 %t153, ptr %l11, !tbaa !24
  br label %bb16
bb51:
  %t155 = load i64, ptr %l8, !tbaa !24
  %t157 = icmp slt i64 %t155, 0
  br i1 %t157, label %bb52, label %bb53
bb52:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb53:
  br label %bb54
bb54:
  %t161 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l9)
  store i64 %t161, ptr %l96
  br label %bb55
bb55:
  %t162 = load i64, ptr %l96, !tbaa !24
  %t163 = icmp eq i64 %t162, 0
  br i1 %t163, label %bb56, label %bb57
bb56:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load i64, ptr %l1, !tbaa !24
  %t167 = load ptr, ptr %l2, !tbaa !29
  %t169 = getelementptr %"compiler/typed:Call", ptr %t167, i32 0, i32 1
  %t170 = load { i64, ptr }, ptr %t169, !tbaa !27
  store { i64, ptr } %t170, ptr %l101, !tbaa !27
  %t171 = load i64, ptr %l8, !tbaa !24
  %t173 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !27
  %t175 = getelementptr ptr, ptr %t174, i64 %t171
  %t176 = load ptr, ptr %t175, !tbaa !39
  %t178 = load i64, ptr %l3, !tbaa !24
  %t179 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t180 = load i64, ptr %l5, !tbaa !24
  %t182 = add i64 %t180, 1
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteMadeNamed(ptr %v0, ptr %v1, ptr %v2, ptr %t165, i64 %t166, ptr %t176, i64 %t178, { i64, ptr } %t179, i64 %t182)
  br label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb59
bb59:
  store ptr %l9, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb60
bb60:
  %t190 = load i64, ptr %l15, !tbaa !24
  store i64 %t190, ptr %l110, !tbaa !24
  %t191 = load ptr, ptr %l14, !tbaa !29
  %t193 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t191)
  store i64 %t193, ptr %l112
  br label %bb61
bb61:
  %t194 = load i64, ptr %l110, !tbaa !24
  %t195 = load i64, ptr %l112, !tbaa !24
  %t196 = icmp slt i64 %t194, %t195
  %t198 = xor i1 %t196, true
  br i1 %t198, label %bb62, label %bb63
bb62:
  br label %bb68
bb63:
  br label %bb64
bb64:
  %t200 = load ptr, ptr %l14, !tbaa !29
  %t201 = load i64, ptr %l15, !tbaa !24
  %t204 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t200, i64 %t201)
  store i64 %t204, ptr %l117
  br label %bb65
bb65:
  %t205 = load i64, ptr %l117, !tbaa !24
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t207 = load i64, ptr %l1, !tbaa !24
  %t208 = load ptr, ptr %l2, !tbaa !29
  %t210 = getelementptr %"compiler/typed:Call", ptr %t208, i32 0, i32 1
  %t211 = load { i64, ptr }, ptr %t210, !tbaa !27
  store { i64, ptr } %t211, ptr %l121, !tbaa !27
  %t214 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr ptr, ptr %t215, i64 %t205
  %t217 = load ptr, ptr %t216, !tbaa !39
  %t219 = load i64, ptr %l3, !tbaa !24
  %t220 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t221 = load i64, ptr %l5, !tbaa !24
  %t223 = add i64 %t221, 1
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteMadeNamed(ptr %v0, ptr %v1, ptr %v2, ptr %t206, i64 %t207, ptr %t217, i64 %t219, { i64, ptr } %t220, i64 %t223)
  br label %bb66
bb66:
  br label %bb67
bb67:
  %t230 = load i64, ptr %l15, !tbaa !24
  %t232 = add i64 %t230, 1
  store i64 %t232, ptr %l15, !tbaa !24
  br label %bb60
bb68:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eocArm(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l23 = alloca { i64, ptr }
  %l32 = alloca i1
  %l43 = alloca { i64, ptr }
  %l52 = alloca i1
  %l64 = alloca i1
  %l65 = alloca i1
  %l71 = alloca i1
  %l72 = alloca i1
  %l78 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Arm", ptr %t6, i32 0, i32 1
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l6, !tbaa !24
  br label %bb4
bb4:
  %t15 = load i64, ptr %l5, !tbaa !24
  %t16 = load i64, ptr %l6, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb5, label %bb6
bb5:
  br label %bb23
bb6:
  br label %bb7
bb7:
  %t23 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t23, ptr %l23, !tbaa !27
  %t24 = load i64, ptr %l5, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr ptr, ptr %t27, i64 %t24
  %t29 = load ptr, ptr %t28, !tbaa !39
  store ptr %t29, ptr %l7, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l7, !tbaa !29
  %t34 = getelementptr %"compiler/typed:Alt", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = load i64, ptr %l2, !tbaa !24
  %t38 = load i1, ptr %l3, !tbaa !21
  %t43 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eocExpr(ptr %v0, ptr %v1, ptr %t31, ptr %t35, i64 %t37, i1 %t38)
  store i1 %t43, ptr %l32
  br label %bb8
bb8:
  %t44 = load i1, ptr %l32, !tbaa !21
  %t45 = xor i1 %t44, true
  br i1 %t45, label %bb9, label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t48 = load ptr, ptr %l7, !tbaa !29
  %t50 = getelementptr %"compiler/typed:Alt", ptr %t48, i32 0, i32 1
  %t51 = load { i64, ptr }, ptr %t50, !tbaa !27
  store { i64, ptr } %t51, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  store i64 %t55, ptr %l10, !tbaa !24
  br label %bb12
bb12:
  %t57 = load i64, ptr %l9, !tbaa !24
  %t58 = load i64, ptr %l10, !tbaa !24
  %t61 = icmp slt i64 %t57, %t58
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb13, label %bb14
bb13:
  br label %bb21
bb14:
  br label %bb15
bb15:
  %t65 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t65, ptr %l43, !tbaa !27
  %t66 = load i64, ptr %l9, !tbaa !24
  %t68 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr ptr, ptr %t69, i64 %t66
  %t71 = load ptr, ptr %t70, !tbaa !39
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/typed:Bind", ptr %t71, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = load i64, ptr %l2, !tbaa !24
  %t80 = load i1, ptr %l3, !tbaa !21
  %t85 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eocExpr(ptr %v0, ptr %v1, ptr %t73, ptr %t77, i64 %t79, i1 %t80)
  store i1 %t85, ptr %l52
  br label %bb16
bb16:
  %t86 = load i1, ptr %l52, !tbaa !21
  %t87 = xor i1 %t86, true
  br i1 %t87, label %bb17, label %bb18
bb17:
  store i1 false, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t90 = load i64, ptr %l9, !tbaa !24
  %t92 = add i64 %t90, 1
  store i64 %t92, ptr %l9, !tbaa !24
  br label %bb12
bb21:
  br label %bb22
bb22:
  %t94 = load i64, ptr %l5, !tbaa !24
  %t96 = add i64 %t94, 1
  store i64 %t96, ptr %l5, !tbaa !24
  br label %bb4
bb23:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load ptr, ptr %l1, !tbaa !29
  %t101 = getelementptr %"compiler/typed:Arm", ptr %t99, i32 0, i32 2
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t103 = load i64, ptr %l2, !tbaa !24
  %t104 = load i1, ptr %l3, !tbaa !21
  %t109 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eocExpr(ptr %v0, ptr %v1, ptr %t98, ptr %t102, i64 %t103, i1 %t104)
  store i1 %t109, ptr %l64
  br label %bb24
bb24:
  %t110 = load i1, ptr %l64, !tbaa !21
  br i1 %t110, label %bb25, label %bb26
bb25:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load ptr, ptr %l1, !tbaa !29
  %t114 = getelementptr %"compiler/typed:Arm", ptr %t112, i32 0, i32 3
  %t115 = load ptr, ptr %t114, !tbaa !29
  %t116 = load i64, ptr %l2, !tbaa !24
  %t117 = load i1, ptr %l3, !tbaa !21
  %t122 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eocBlock(ptr %v0, ptr %v1, ptr %t111, ptr %t115, i64 %t116, i1 %t117)
  store i1 %t122, ptr %l71
  br label %bb27
bb26:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb28
bb27:
  %t123 = load i1, ptr %l71, !tbaa !21
  store i1 %t123, ptr %l65, !tbaa !21
  br label %bb28
bb28:
  %t124 = load i1, ptr %l65, !tbaa !21
  br i1 %t124, label %bb29, label %bb30
bb29:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t128 = getelementptr %"compiler/typed:Arm", ptr %t126, i32 0, i32 4
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t130 = load i64, ptr %l2, !tbaa !24
  %t131 = load i1, ptr %l3, !tbaa !21
  %t136 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eocExpr(ptr %v0, ptr %v1, ptr %t125, ptr %t129, i64 %t130, i1 %t131)
  store i1 %t136, ptr %l78
  br label %bb31
bb30:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb32
bb31:
  %t137 = load i1, ptr %l78, !tbaa !21
  store i1 %t137, ptr %l72, !tbaa !21
  br label %bb32
bb32:
  %t138 = load i1, ptr %l72, !tbaa !21
  store i1 %t138, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eocPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l31 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l42 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca i1
  %l54 = alloca i1
  %l55 = alloca i1
  %l62 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l74 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca i1
  %l86 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l10, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l4, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l4, !tbaa !23
  %t18 = sext i32 %t16 to i64
  %t19 = load i64, ptr %l2, !tbaa !24
  %t22 = icmp ne i64 %t18, %t19
  store i1 %t22, ptr %rv
  br label %ret
bb6:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t25 = load ptr, ptr %l20, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = load ptr, ptr %l20, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 8}
  %t31 = icmp eq i64 %t29, 2
  store i1 %t31, ptr %l21, !tbaa !21
  br label %bb8
bb8:
  %t32 = load i1, ptr %l21, !tbaa !21
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t35 = getelementptr { i64, [4 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t35, i32 0, i32 2
  %t37 = load ptr, ptr %t36
  store ptr %t37, ptr %l5, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l5, !tbaa !29
  %t42 = load i64, ptr %l2, !tbaa !24
  %t43 = load i1, ptr %l3, !tbaa !21
  %t48 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eocExpr(ptr %v0, ptr %v1, ptr %t39, ptr %t40, i64 %t42, i1 %t43)
  store i1 %t48, ptr %l31
  br label %bb12
bb12:
  %t49 = load i1, ptr %l31, !tbaa !21
  store i1 %t49, ptr %rv
  br label %ret
bb13:
  %t50 = load ptr, ptr %l1, !tbaa !29
  store ptr %t50, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t51 = load ptr, ptr %l32, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb14, label %bb15
bb14:
  %t54 = load ptr, ptr %l32, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 8}
  %t57 = icmp eq i64 %t55, 3
  store i1 %t57, ptr %l33, !tbaa !21
  br label %bb15
bb15:
  %t58 = load i1, ptr %l33, !tbaa !21
  br i1 %t58, label %bb16, label %bb17
bb16:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t61, i32 0, i32 2
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l6, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l6, !tbaa !29
  %t67 = load i64, ptr %l2, !tbaa !24
  %t68 = load i1, ptr %l3, !tbaa !21
  %t73 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eocPlace(ptr %v0, ptr %v1, ptr %t65, ptr %t66, i64 %t67, i1 %t68)
  store i1 %t73, ptr %l42
  br label %bb19
bb19:
  %t74 = load i1, ptr %l42, !tbaa !21
  store i1 %t74, ptr %rv
  br label %ret
bb20:
  %t75 = load ptr, ptr %l1, !tbaa !29
  store ptr %t75, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t76 = load ptr, ptr %l43, !tbaa !29
  %t77 = icmp ne ptr %t76, null
  br i1 %t77, label %bb21, label %bb22
bb21:
  %t79 = load ptr, ptr %l43, !tbaa !29
  %t80 = load i64, ptr %t79, !range !{i64 0, i64 8}
  %t82 = icmp eq i64 %t80, 4
  store i1 %t82, ptr %l44, !tbaa !21
  br label %bb22
bb22:
  %t83 = load i1, ptr %l44, !tbaa !21
  br i1 %t83, label %bb23, label %bb24
bb23:
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t86 = getelementptr { i64, [4 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t86, i32 0, i32 2
  %t88 = load ptr, ptr %t87
  store ptr %t88, ptr %l7, !tbaa !29
  br label %bb25
bb24:
  br label %bb31
bb25:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load ptr, ptr %l7, !tbaa !29
  %t93 = getelementptr %"compiler/typed:Elem", ptr %t91, i32 0, i32 0
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t95 = load i64, ptr %l2, !tbaa !24
  %t96 = load i1, ptr %l3, !tbaa !21
  %t101 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eocPlace(ptr %v0, ptr %v1, ptr %t90, ptr %t94, i64 %t95, i1 %t96)
  store i1 %t101, ptr %l54
  br label %bb26
bb26:
  %t102 = load i1, ptr %l54, !tbaa !21
  br i1 %t102, label %bb27, label %bb28
bb27:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load ptr, ptr %l7, !tbaa !29
  %t106 = getelementptr %"compiler/typed:Elem", ptr %t104, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t109 = load i64, ptr %l2, !tbaa !24
  %t110 = load i1, ptr %l3, !tbaa !21
  %t115 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eocExpr(ptr %v0, ptr %v1, ptr %t103, ptr %t107, i64 %t109, i1 %t110)
  store i1 %t115, ptr %l62
  br label %bb29
bb28:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb30
bb29:
  %t116 = load i1, ptr %l62, !tbaa !21
  store i1 %t116, ptr %l55, !tbaa !21
  br label %bb30
bb30:
  %t117 = load i1, ptr %l55, !tbaa !21
  store i1 %t117, ptr %rv
  br label %ret
bb31:
  %t118 = load ptr, ptr %l1, !tbaa !29
  store ptr %t118, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t119 = load ptr, ptr %l63, !tbaa !29
  %t120 = icmp ne ptr %t119, null
  br i1 %t120, label %bb32, label %bb33
bb32:
  %t122 = load ptr, ptr %l63, !tbaa !29
  %t123 = load i64, ptr %t122, !range !{i64 0, i64 8}
  %t125 = icmp eq i64 %t123, 5
  store i1 %t125, ptr %l64, !tbaa !21
  br label %bb33
bb33:
  %t126 = load i1, ptr %l64, !tbaa !21
  br i1 %t126, label %bb34, label %bb35
bb34:
  %t127 = load ptr, ptr %l1, !tbaa !29
  %t129 = getelementptr { i64, [4 x i64] }, ptr %t127, i32 0, i32 1
  %t130 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t129, i32 0, i32 2
  %t131 = load ptr, ptr %t130
  store ptr %t131, ptr %l8, !tbaa !29
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load ptr, ptr %l8, !tbaa !29
  %t136 = getelementptr %"compiler/typed:Payload", ptr %t134, i32 0, i32 0
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t138 = load i64, ptr %l2, !tbaa !24
  %t139 = load i1, ptr %l3, !tbaa !21
  %t144 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eocPlace(ptr %v0, ptr %v1, ptr %t133, ptr %t137, i64 %t138, i1 %t139)
  store i1 %t144, ptr %l74
  br label %bb37
bb37:
  %t145 = load i1, ptr %l74, !tbaa !21
  store i1 %t145, ptr %rv
  br label %ret
bb38:
  %t146 = load ptr, ptr %l1, !tbaa !29
  store ptr %t146, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t147 = load ptr, ptr %l75, !tbaa !29
  %t148 = icmp ne ptr %t147, null
  br i1 %t148, label %bb39, label %bb40
bb39:
  %t150 = load ptr, ptr %l75, !tbaa !29
  %t151 = load i64, ptr %t150, !range !{i64 0, i64 8}
  %t153 = icmp eq i64 %t151, 6
  store i1 %t153, ptr %l76, !tbaa !21
  br label %bb40
bb40:
  %t154 = load i1, ptr %l76, !tbaa !21
  br i1 %t154, label %bb41, label %bb42
bb41:
  %t155 = load ptr, ptr %l1, !tbaa !29
  %t157 = getelementptr { i64, [4 x i64] }, ptr %t155, i32 0, i32 1
  %t158 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t157, i32 0, i32 2
  %t159 = load ptr, ptr %t158
  store ptr %t159, ptr %l9, !tbaa !29
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load ptr, ptr %l9, !tbaa !29
  %t164 = load i64, ptr %l2, !tbaa !24
  %t165 = load i1, ptr %l3, !tbaa !21
  %t170 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eocExpr(ptr %v0, ptr %v1, ptr %t161, ptr %t162, i64 %t164, i1 %t165)
  store i1 %t170, ptr %l86
  br label %bb44
bb44:
  %t171 = load i1, ptr %l86, !tbaa !21
  store i1 %t171, ptr %rv
  br label %ret
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  store i1 true, ptr %rv
  br label %ret
bb49:
  call void @__olang_check_failed(ptr @olang_loc_a3d67bab0a0a1a9_82466bf787f25fd)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eocStmts(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2, i64 %a3, i1 %a4) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l17 = alloca i64
  %l20 = alloca i64
  %l39 = alloca { i64, ptr }
  %l45 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a2, ptr %l5, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t7 = load i64, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load i64, ptr %l7, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb3:
  %t17 = load i64, ptr %l6, !tbaa !24
  %t18 = load i64, ptr %l5, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l7, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l7, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l20, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb5
bb5:
  %t33 = load i64, ptr %l20, !tbaa !24
  store i64 %t33, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t34 = load i64, ptr %l17, !tbaa !24
  store i64 %t34, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb7
bb7:
  %t35 = load i64, ptr %l9, !tbaa !24
  %t36 = load i64, ptr %l8, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb8, label %bb9
bb8:
  br label %bb16
bb9:
  br label %bb10
bb10:
  %t43 = load i64, ptr %l5, !tbaa !24
  %t44 = load i64, ptr %l9, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  %t54 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t54, ptr %l39, !tbaa !27
  %t57 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr ptr, ptr %t58, i64 %t51
  %t60 = load ptr, ptr %t59, !tbaa !39
  %t68 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eocStmt(ptr %v0, ptr %v1, ptr %a0, ptr %t60, i64 %a3, i1 %a4)
  store i1 %t68, ptr %l45
  br label %bb11
bb11:
  %t69 = load i1, ptr %l45, !tbaa !21
  %t70 = xor i1 %t69, true
  br i1 %t70, label %bb12, label %bb13
bb12:
  store i1 false, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t73 = load i64, ptr %l9, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l9, !tbaa !24
  br label %bb7
bb16:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eonlyCalled(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l12 = alloca %"compiler/typed:Local"
  %l20 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 25
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_b076c1f6c97c7ed4_fcdcfd5688cdce70)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 25
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 7
  %t15 = load i64, ptr %l3, !tbaa !24
  %t18 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t14, i64 %t15)
  store %"compiler/typed:Local" %t18, ptr %l12
  br label %bb4
bb4:
  %t19 = getelementptr %"compiler/typed:Local", ptr %l12, i32 0, i32 4
  %t20 = load i32, ptr %t19, !range !{i32 0, i32 7}
  %t22 = trunc i64 6 to i32
  %t23 = icmp eq i32 %t20, %t22
  br i1 %t23, label %bb5, label %bb6
bb5:
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i64, ptr %l3, !tbaa !24
  %t34 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eocStmts(ptr %v0, ptr %v1, ptr %t26, { i64, ptr } %a1, i64 %a2, i64 %t29, i1 false)
  store i1 %t34, ptr %l20
  br label %bb8
bb8:
  %t35 = load i1, ptr %l20, !tbaa !21
  store i1 %t35, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eoutside(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/typed:Local"
  %l11 = alloca %"compiler/typed:Local"
  %l14 = alloca i1
  %l26 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 25
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_623296b25c4a2534_fd3f86d02d068538)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 25
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 7
  %t18 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t14, i64 %a1)
  store %"compiler/typed:Local" %t18, ptr %l11
  br label %bb4
bb4:
  %t19 = load %"compiler/typed:Local", ptr %l11
  store %"compiler/typed:Local" %t19, ptr %l2
  %t20 = getelementptr %"compiler/typed:Local", ptr %l2, i32 0, i32 4
  %t21 = load i32, ptr %t20, !range !{i32 0, i32 7}
  %t23 = trunc i64 0 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb7
bb6:
  %t26 = getelementptr %"compiler/typed:Local", ptr %l2, i32 0, i32 4
  %t27 = load i32, ptr %t26, !range !{i32 0, i32 7}
  %t29 = trunc i64 5 to i32
  %t30 = icmp eq i32 %t27, %t29
  store i1 %t30, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t32 = load i1, ptr %l14, !tbaa !21
  br i1 %t32, label %bb8, label %bb9
bb8:
  store i1 true, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/scope:Scoper", ptr %t34, i32 0, i32 25
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  br i1 %t39, label %bb11, label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_954f6d28b3a52ac3_ffd2f75d7c0d3157)
  unreachable
bb12:
  br label %bb13
bb13:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/scope:Scoper", ptr %t41, i32 0, i32 25
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/scope:Scoper", ptr %t45, i32 0, i32 116
  %t48 = load i32, ptr %t47, !tbaa !23
  %t49 = getelementptr %"compiler/typed:Local", ptr %l2, i32 0, i32 3
  %t50 = load i32, ptr %t49, !tbaa !23
  %t54 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eEncloses(ptr %v0, ptr %t44, i32 %t48, i32 %t50)
  store i1 %t54, ptr %l26
  br label %bb14
bb14:
  %t55 = load i1, ptr %l26, !tbaa !21
  %t56 = xor i1 %t55, true
  store i1 %t56, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eownerAt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l17 = alloca i64
  %l20 = alloca i64
  %l42 = alloca i1
  %l43 = alloca { i64, ptr }
  %l48 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l53 = alloca %"compiler/source:Span"
  %l54 = alloca %"compiler/source:Span"
  %rv = alloca %"compiler/source:Span"
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l5, !tbaa !24
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  store i64 %t6, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t8 = load i64, ptr %l6, !tbaa !24
  %t9 = load i64, ptr %l5, !tbaa !24
  %t12 = icmp sgt i64 %t8, %t9
  br i1 %t12, label %bb1, label %bb2
bb1:
  %t14 = load i64, ptr %l7, !tbaa !24
  %t16 = icmp sgt i64 %t14, 0
  br i1 %t16, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb3:
  %t18 = load i64, ptr %l6, !tbaa !24
  %t19 = load i64, ptr %l5, !tbaa !24
  %t22 = sub i64 %t18, %t19
  %t23 = load i64, ptr %l7, !tbaa !24
  %t26 = add i64 %t22, %t23
  %t28 = sub i64 %t26, 1
  %t29 = load i64, ptr %l7, !tbaa !24
  %t32 = sdiv i64 %t28, %t29
  store i64 %t32, ptr %l20, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb5
bb5:
  %t34 = load i64, ptr %l20, !tbaa !24
  store i64 %t34, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l17, !tbaa !24
  store i64 %t35, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l9, !tbaa !24
  %t37 = load i64, ptr %l8, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb8, label %bb9
bb8:
  br label %bb20
bb9:
  br label %bb10
bb10:
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l9, !tbaa !24
  %t46 = load i64, ptr %l7, !tbaa !24
  %t49 = mul i64 %t45, %t46
  %t52 = add i64 %t44, %t49
  store i64 %t52, ptr %l10, !tbaa !24
  %t54 = load i64, ptr %l10, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 0
  %t60 = icmp slt i64 %t54, %t57
  br i1 %t60, label %bb11, label %bb12
bb11:
  %t62 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t62, ptr %l43, !tbaa !27
  %t63 = load i64, ptr %l10, !tbaa !24
  %t65 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr i64, ptr %t66, i64 %t63
  %t68 = load i64, ptr %t67, !tbaa !34
  %t72 = icmp eq i64 %t68, %a3
  store i1 %t72, ptr %l42, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb13
bb13:
  %t74 = load i1, ptr %l42, !tbaa !21
  br i1 %t74, label %bb14, label %bb15
bb14:
  store ptr %a0, ptr %l48, !tbaa !29
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr %"compiler/typed:Call", ptr %t76, i32 0, i32 1
  %t79 = load { i64, ptr }, ptr %t78, !tbaa !27
  store { i64, ptr } %t79, ptr %l50, !tbaa !27
  %t80 = load i64, ptr %l10, !tbaa !24
  %t82 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr ptr, ptr %t83, i64 %t80
  %t85 = load ptr, ptr %t84, !tbaa !39
  %t87 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t85)
  store %"compiler/source:Span" %t87, ptr %l53
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t88 = load ptr, ptr %l48, !tbaa !29
  %t89 = load %"compiler/source:Span", ptr %l53
  %t90 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elastName(ptr %v0, ptr %t88, %"compiler/source:Span" %t89)
  store %"compiler/source:Span" %t90, ptr %l54
  br label %bb17
bb17:
  %t91 = load %"compiler/source:Span", ptr %l54
  store %"compiler/source:Span" %t91, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t92 = load i64, ptr %l9, !tbaa !24
  %t94 = add i64 %t92, 1
  store i64 %t94, ptr %l9, !tbaa !24
  br label %bb7
bb20:
  store %"compiler/source:Span" %a4, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparamVarType(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca { i64, [1 x i64] }
  %l4 = alloca i32
  %l8 = alloca { i64, [1 x i64] }
  %l9 = alloca i32
  %l17 = alloca %"compiler/typed:Local"
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Body", ptr %t1, i32 0, i32 6
  %t7 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v1, ptr %t3, i64 %a2)
  store { i64, [1 x i64] } %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load { i64, [1 x i64] }, ptr %l8
  store { i64, [1 x i64] } %t8, ptr %l3
  %t9 = load { i64, [1 x i64] }, ptr %l3
  %t11 = extractvalue { i64, [1 x i64] } %t9, 0
  %t12 = icmp eq i64 %t11, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = getelementptr { i64, [1 x i64] }, ptr %l3, i32 0, i32 1
  %t15 = getelementptr { i32 }, ptr %t14, i32 0, i32 0
  %t16 = load i32, ptr %t15
  store i32 %t16, ptr %l4, !tbaa !23
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Body", ptr %t18, i32 0, i32 7
  %t21 = load i32, ptr %l4, !tbaa !23
  %t23 = sext i32 %t21 to i64
  %t26 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v1, ptr %t20, i64 %t23)
  store %"compiler/typed:Local" %t26, ptr %l17
  br label %bb5
bb5:
  %t27 = getelementptr %"compiler/typed:Local", ptr %l17, i32 0, i32 2
  %t28 = load i32, ptr %t27, !tbaa !23
  store i32 %t28, ptr %l9, !tbaa !23
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t30 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t30, ptr %l9, !tbaa !23
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_55e48b5186b67064_d8bb62a12b763a18)
  unreachable
bb11:
  %t32 = load i32, ptr %l9, !tbaa !23
  store i32 %t32, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartAdmits(ptr %v0, ptr %a0, i32 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i1
  %l4 = alloca i1
  %l7 = alloca i1
  %l8 = alloca i1
  %l11 = alloca i1
  %l15 = alloca i1
  %l16 = alloca ptr
  %l21 = alloca i32
  %l26 = alloca i64
  %l30 = alloca i1
  %l34 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i1, ptr %l2, !tbaa !21
  br i1 %t1, label %bb1, label %bb2
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t3, i32 %t4)
  store i1 %t7, ptr %l7
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb8
bb3:
  %t8 = load i1, ptr %l7, !tbaa !21
  br i1 %t8, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb7
bb5:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i32, ptr %l1, !tbaa !23
  %t13 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t9, i32 %t10)
  store i1 %t13, ptr %l11
  br label %bb6
bb6:
  %t14 = load i1, ptr %l11, !tbaa !21
  store i1 %t14, ptr %l8, !tbaa !21
  br label %bb7
bb7:
  %t15 = load i1, ptr %l8, !tbaa !21
  store i1 %t15, ptr %l4, !tbaa !21
  br label %bb8
bb8:
  %t16 = load i1, ptr %l4, !tbaa !21
  br i1 %t16, label %bb9, label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t18, i32 %t19)
  store i1 %t22, ptr %l15
  br label %bb12
bb12:
  %t23 = load i1, ptr %l15, !tbaa !21
  br i1 %t23, label %bb13, label %bb14
bb13:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l16, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/scope:Scoper", ptr %t25, i32 0, i32 0
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/generic:Program", ptr %t28, i32 0, i32 2
  %t31 = load i32, ptr %l1, !tbaa !23
  %t34 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t30, i32 %t31)
  store i32 %t34, ptr %l21
  br label %bb15
bb14:
  br label %bb18
bb15:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/scope:Scoper", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"compiler/generic:Program", ptr %t38, i32 0, i32 2
  %t41 = load i32, ptr %l1, !tbaa !23
  %t44 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t40, i32 %t41)
  store i64 %t44, ptr %l26
  br label %bb16
bb16:
  %t45 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t46 = load i64, ptr %l26, !tbaa !24
  %t48 = and i64 %t46, %t45
  %t50 = icmp ne i64 %t48, 0
  %t51 = load ptr, ptr %l16, !tbaa !29
  %t52 = load i32, ptr %l21, !tbaa !23
  %t54 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eadmitsAt(ptr %v0, ptr %t51, i32 %t52, i1 %t50)
  store i1 %t54, ptr %l30
  br label %bb17
bb17:
  %t55 = load i1, ptr %l30, !tbaa !21
  store i1 %t55, ptr %rv
  br label %ret
bb18:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i32, ptr %l1, !tbaa !23
  %t58 = load i1, ptr %l2, !tbaa !21
  %t62 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eadmitsAt(ptr %v0, ptr %t56, i32 %t57, i1 %t58)
  store i1 %t62, ptr %l34
  br label %bb19
bb19:
  %t63 = load i1, ptr %l34, !tbaa !21
  store i1 %t63, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ereassigned(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l12 = alloca i64
  %l18 = alloca i64
  %l22 = alloca i64
  %l25 = alloca i64
  %l46 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 14
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/scope:Scoper", ptr %t4, i32 0, i32 26
  %t7 = load i64, ptr %t6, !tbaa !24
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t7)
  store i64 %t10, ptr %l12
  br label %bb1
bb1:
  %t11 = load i64, ptr %l12, !tbaa !24
  store i64 %t11, ptr %l2, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/scope:Scoper", ptr %t12, i32 0, i32 14
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/scope:Scoper", ptr %t15, i32 0, i32 26
  %t18 = load i64, ptr %t17, !tbaa !24
  %t20 = add i64 %t18, 1
  %t23 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t14, i64 %t20)
  store i64 %t23, ptr %l18
  br label %bb2
bb2:
  %t24 = load i64, ptr %l18, !tbaa !24
  store i64 %t24, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t25 = load i64, ptr %l3, !tbaa !24
  %t26 = load i64, ptr %l2, !tbaa !24
  %t29 = icmp sgt i64 %t25, %t26
  br i1 %t29, label %bb3, label %bb4
bb3:
  %t31 = load i64, ptr %l4, !tbaa !24
  %t33 = icmp sgt i64 %t31, 0
  br i1 %t33, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb8
bb5:
  %t35 = load i64, ptr %l3, !tbaa !24
  %t36 = load i64, ptr %l2, !tbaa !24
  %t39 = sub i64 %t35, %t36
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = add i64 %t39, %t40
  %t45 = sub i64 %t43, 1
  %t46 = load i64, ptr %l4, !tbaa !24
  %t49 = sdiv i64 %t45, %t46
  store i64 %t49, ptr %l25, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb7
bb7:
  %t51 = load i64, ptr %l25, !tbaa !24
  store i64 %t51, ptr %l22, !tbaa !24
  br label %bb8
bb8:
  %t52 = load i64, ptr %l22, !tbaa !24
  store i64 %t52, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  %t53 = load i64, ptr %l6, !tbaa !24
  %t54 = load i64, ptr %l5, !tbaa !24
  %t57 = icmp slt i64 %t53, %t54
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb10, label %bb11
bb10:
  br label %bb18
bb11:
  br label %bb12
bb12:
  %t61 = load i64, ptr %l2, !tbaa !24
  %t62 = load i64, ptr %l6, !tbaa !24
  %t63 = load i64, ptr %l4, !tbaa !24
  %t66 = mul i64 %t62, %t63
  %t69 = add i64 %t61, %t66
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/scope:Scoper", ptr %t71, i32 0, i32 15
  %t77 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t73, i64 %t69)
  store i64 %t77, ptr %l46
  br label %bb13
bb13:
  %t79 = load i64, ptr %l46, !tbaa !24
  %t81 = icmp eq i64 %t79, %a1
  br i1 %t81, label %bb14, label %bb15
bb14:
  store i1 true, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t84 = load i64, ptr %l6, !tbaa !24
  %t86 = add i64 %t84, 1
  store i64 %t86, ptr %l6, !tbaa !24
  br label %bb9
bb18:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erecAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, [2 x i64] }
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i64
  %l15 = alloca i64
  %l23 = alloca { i64, [2 x i64] }
  %l25 = alloca i1
  %l26 = alloca { i64, [2 x i64] }
  %rv = alloca { i64, [2 x i64] }
  %t25 = alloca { i64, [2 x i64] }, align 8
  %t47 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp slt i64 %t5, 0
  store i1 %t7, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb7
bb5:
  %t10 = load i64, ptr %l1, !tbaa !24
  %t11 = load i64, ptr %l2, !tbaa !24
  %t14 = add i64 %t10, %t11
  store i64 %t14, ptr %l12, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/scope:Scoper", ptr %t15, i32 0, i32 44
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t17)
  store i64 %t19, ptr %l15
  br label %bb6
bb6:
  %t20 = load i64, ptr %l12, !tbaa !24
  %t21 = load i64, ptr %l15, !tbaa !24
  %t22 = icmp sge i64 %t20, %t21
  store i1 %t22, ptr %l9, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l9, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  store { i64, [2 x i64] } zeroinitializer, ptr %t25
  %t26 = getelementptr { i64, [2 x i64] }, ptr %t25, i32 0, i32 0
  store i64 0, ptr %t26
  %t27 = load { i64, [2 x i64] }, ptr %t25
  store { i64, [2 x i64] } %t27, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/scope:Scoper", ptr %t29, i32 0, i32 44
  %t32 = load i64, ptr %l1, !tbaa !24
  %t33 = load i64, ptr %l2, !tbaa !24
  %t36 = add i64 %t32, %t33
  %t39 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t31, i64 %t36)
  store { i64, [2 x i64] } %t39, ptr %l23
  br label %bb11
bb11:
  %t40 = load { i64, [2 x i64] }, ptr %l23
  store { i64, [2 x i64] } %t40, ptr %l3
  %t41 = load { i64, [2 x i64] }, ptr %l3
  %t43 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t41)
  store i1 %t43, ptr %l25
  br label %bb12
bb12:
  %t44 = load i1, ptr %l25, !tbaa !21
  br i1 %t44, label %bb13, label %bb14
bb13:
  %t45 = load { i64, [2 x i64] }, ptr %l3
  store { i64, [2 x i64] } %t45, ptr %l26
  br label %bb15
bb14:
  store { i64, [2 x i64] } zeroinitializer, ptr %t47
  %t48 = getelementptr { i64, [2 x i64] }, ptr %t47, i32 0, i32 0
  store i64 0, ptr %t48
  %t49 = load { i64, [2 x i64] }, ptr %t47
  store { i64, [2 x i64] } %t49, ptr %l26
  br label %bb15
bb15:
  %t51 = load { i64, [2 x i64] }, ptr %l26
  store { i64, [2 x i64] } %t51, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erequiredBy(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/scope:rel"
  %l7 = alloca { i64, [2 x i64] }
  %l8 = alloca i64
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca i64
  %l13 = alloca i1
  %l17 = alloca ptr
  %l20 = alloca i1
  %l24 = alloca ptr
  %l32 = alloca ptr
  %l35 = alloca i64
  %l37 = alloca i64
  %l42 = alloca %"compiler/scope:rel"
  %l58 = alloca i1
  %l59 = alloca { i64, ptr }
  %l64 = alloca i1
  %l65 = alloca { i64, ptr }
  %l68 = alloca i1
  %l69 = alloca { i64, ptr }
  %rv = alloca { i64, [2 x i64] }
  %t33 = alloca { i64, [2 x i64] }, align 8
  %t140 = alloca { i64, [2 x i64] }, align 8
  %t148 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb8
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/scope:Scoper", ptr %t5, i32 0, i32 6
  %t8 = load i64, ptr %l1, !tbaa !24
  %t11 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t7, i64 %t8)
  store ptr %t11, ptr %l17
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l17, !tbaa !29
  %t14 = getelementptr %"compiler/scope:summary", ptr %t12, i32 0, i32 15
  %t15 = load i1, ptr %t14, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb7
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/scope:Scoper", ptr %t17, i32 0, i32 6
  %t20 = load i64, ptr %l1, !tbaa !24
  %t23 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t19, i64 %t20)
  store ptr %t23, ptr %l24
  br label %bb6
bb6:
  %t24 = load ptr, ptr %l24, !tbaa !29
  %t26 = getelementptr %"compiler/scope:summary", ptr %t24, i32 0, i32 16
  %t27 = load i1, ptr %t26, !tbaa !21
  store i1 %t27, ptr %l20, !tbaa !21
  br label %bb7
bb7:
  %t29 = load i1, ptr %l20, !tbaa !21
  %t30 = xor i1 %t29, true
  store i1 %t30, ptr %l13, !tbaa !21
  br label %bb8
bb8:
  %t32 = load i1, ptr %l13, !tbaa !21
  br i1 %t32, label %bb9, label %bb10
bb9:
  store { i64, [2 x i64] } zeroinitializer, ptr %t33
  %t34 = getelementptr { i64, [2 x i64] }, ptr %t33, i32 0, i32 0
  store i64 0, ptr %t34
  %t35 = load { i64, [2 x i64] }, ptr %t33
  store { i64, [2 x i64] } %t35, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/scope:Scoper", ptr %t37, i32 0, i32 6
  %t40 = load i64, ptr %l1, !tbaa !24
  %t43 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t39, i64 %t40)
  store ptr %t43, ptr %l32
  br label %bb12
bb12:
  %t44 = load ptr, ptr %l32, !tbaa !29
  %t46 = getelementptr %"compiler/scope:summary", ptr %t44, i32 0, i32 0
  store ptr %t46, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb13
bb13:
  %t48 = load i64, ptr %l5, !tbaa !24
  store i64 %t48, ptr %l35, !tbaa !24
  %t49 = load ptr, ptr %l4, !tbaa !29
  %t51 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t49)
  store i64 %t51, ptr %l37
  br label %bb14
bb14:
  %t52 = load i64, ptr %l35, !tbaa !24
  %t53 = load i64, ptr %l37, !tbaa !24
  %t54 = icmp slt i64 %t52, %t53
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb15, label %bb16
bb15:
  br label %bb55
bb16:
  br label %bb17
bb17:
  %t58 = load ptr, ptr %l4, !tbaa !29
  %t59 = load i64, ptr %l5, !tbaa !24
  %t62 = call %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t58, i64 %t59)
  store %"compiler/scope:rel" %t62, ptr %l42
  br label %bb18
bb18:
  %t63 = load %"compiler/scope:rel", ptr %l42
  store %"compiler/scope:rel" %t63, ptr %l6
  %t64 = getelementptr %"compiler/scope:rel", ptr %l6, i32 0, i32 0
  %t65 = load { i64, [2 x i64] }, ptr %t64
  store { i64, [2 x i64] } %t65, ptr %l7
  %t67 = load { i64, [2 x i64] }, ptr %l7
  %t69 = extractvalue { i64, [2 x i64] } %t67, 0
  %t70 = icmp eq i64 %t69, 2
  br i1 %t70, label %bb19, label %bb20
bb19:
  %t72 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t73 = getelementptr { i64 }, ptr %t72, i32 0, i32 0
  %t74 = load i64, ptr %t73
  store i64 %t74, ptr %l8, !tbaa !24
  br label %bb21
bb20:
  br label %bb48
bb21:
  %t76 = load i64, ptr %l8, !tbaa !24
  %t80 = icmp eq i64 %t76, %a2
  br i1 %t80, label %bb22, label %bb23
bb22:
  %t82 = getelementptr %"compiler/scope:rel", ptr %l6, i32 0, i32 1
  %t83 = load { i64, [2 x i64] }, ptr %t82
  store { i64, [2 x i64] } %t83, ptr %l9
  %t85 = load { i64, [2 x i64] }, ptr %l9
  %t87 = extractvalue { i64, [2 x i64] } %t85, 0
  %t88 = icmp eq i64 %t87, 2
  br i1 %t88, label %bb24, label %bb25
bb23:
  br label %bb47
bb24:
  %t90 = getelementptr { i64, [2 x i64] }, ptr %l9, i32 0, i32 1
  %t91 = getelementptr { i64 }, ptr %t90, i32 0, i32 0
  %t92 = load i64, ptr %t91
  store i64 %t92, ptr %l10, !tbaa !24
  br label %bb26
bb25:
  br label %bb37
bb26:
  %t94 = load i64, ptr %l10, !tbaa !24
  %t95 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t95, 0
  %t100 = icmp slt i64 %t94, %t97
  br i1 %t100, label %bb27, label %bb28
bb27:
  %t102 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t102, ptr %l59, !tbaa !27
  %t103 = load i64, ptr %l10, !tbaa !24
  %t105 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr { i64, [2 x i64] }, ptr %t106, i64 %t103
  %t108 = load { i64, [2 x i64] }, ptr %t107
  %t110 = extractvalue { i64, [2 x i64] } %t108, 0
  %t111 = icmp eq i64 %t110, 0
  %t113 = xor i1 %t111, true
  store i1 %t113, ptr %l58, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb29
bb29:
  %t115 = load i1, ptr %l58, !tbaa !21
  br i1 %t115, label %bb30, label %bb31
bb30:
  %t116 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t116, ptr %l65, !tbaa !27
  %t117 = load i64, ptr %l10, !tbaa !24
  %t119 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr { i64, [2 x i64] }, ptr %t120, i64 %t117
  %t122 = load { i64, [2 x i64] }, ptr %t121
  %t124 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t122)
  store i1 %t124, ptr %l68
  br label %bb32
bb31:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb33
bb32:
  %t125 = load i1, ptr %l68, !tbaa !21
  store i1 %t125, ptr %l64, !tbaa !21
  br label %bb33
bb33:
  %t126 = load i1, ptr %l64, !tbaa !21
  br i1 %t126, label %bb34, label %bb35
bb34:
  %t127 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t127, ptr %l69, !tbaa !27
  %t128 = load i64, ptr %l10, !tbaa !24
  %t130 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr { i64, [2 x i64] }, ptr %t131, i64 %t128
  %t133 = load { i64, [2 x i64] }, ptr %t132
  store { i64, [2 x i64] } %t133, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  br label %bb46
bb37:
  %t135 = load { i64, [2 x i64] }, ptr %l9
  %t137 = extractvalue { i64, [2 x i64] } %t135, 0
  %t138 = icmp eq i64 %t137, 3
  br i1 %t138, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  store { i64, [2 x i64] } zeroinitializer, ptr %t140
  %t141 = getelementptr { i64, [2 x i64] }, ptr %t140, i32 0, i32 0
  store i64 3, ptr %t141
  %t142 = load { i64, [2 x i64] }, ptr %t140
  store { i64, [2 x i64] } %t142, ptr %rv
  br label %ret
bb41:
  br i1 true, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_c23f661bef127e16_c2f6e67eaac9a38a)
  unreachable
bb46:
  br label %bb47
bb47:
  br label %bb53
bb48:
  br i1 true, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_d1f10cb62dc90d37_b8521a3eafe7cb)
  unreachable
bb53:
  br label %bb54
bb54:
  %t144 = load i64, ptr %l5, !tbaa !24
  %t146 = add i64 %t144, 1
  store i64 %t146, ptr %l5, !tbaa !24
  br label %bb13
bb55:
  store { i64, [2 x i64] } zeroinitializer, ptr %t148
  %t149 = getelementptr { i64, [2 x i64] }, ptr %t148, i32 0, i32 0
  store i64 0, ptr %t149
  %t150 = load { i64, [2 x i64] }, ptr %t148
  store { i64, [2 x i64] } %t150, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eretOne(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca %"compiler/scope:Val"
  %l6 = alloca i1
  %l9 = alloca i32
  %l12 = alloca i1
  %l14 = alloca ptr
  %l16 = alloca ptr
  %l19 = alloca i1
  %l20 = alloca { i64, [2 x i64] }
  %l22 = alloca { i64, [2 x i64] }
  %l24 = alloca %"compiler/scope:Val"
  %l27 = alloca { i64, [2 x i64] }
  %l32 = alloca %"compiler/scope:Val"
  %l35 = alloca i1
  %l38 = alloca ptr
  %l46 = alloca i32
  %l49 = alloca i1
  %l52 = alloca ptr
  %l55 = alloca ptr
  %l63 = alloca i32
  %l64 = alloca i32
  %l77 = alloca ptr
  %l81 = alloca i1
  %l84 = alloca { i64, [2 x i64] }
  %l87 = alloca ptr
  %l88 = alloca { i64, [2 x i64] }
  %l92 = alloca { i64, [2 x i64] }
  %t25 = alloca { i64, [2 x i64] }, align 8
  %t178 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t1)
  store i32 %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load i32, ptr %l9, !tbaa !23
  store i32 %t4, ptr %l3, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr %l3, !tbaa !23
  %t9 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l12
  br label %bb2
bb2:
  %t10 = load i1, ptr %l12, !tbaa !21
  %t11 = xor i1 %t10, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l14, !tbaa !29
  %t14 = load ptr, ptr %l2, !tbaa !29
  store ptr %t14, ptr %l16, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l3, !tbaa !23
  %t20 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2earenaValue(ptr %v0, ptr %t16, i32 %t17)
  store i1 %t20, ptr %l19
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t21 = load i1, ptr %l19, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estorageTerm(ptr %v0, ptr %t22)
  store { i64, [2 x i64] } %t24, ptr %l22
  br label %bb8
bb7:
  store { i64, [2 x i64] } zeroinitializer, ptr %t25
  %t26 = getelementptr { i64, [2 x i64] }, ptr %t25, i32 0, i32 0
  store i64 0, ptr %t26
  %t27 = load { i64, [2 x i64] }, ptr %t25
  store { i64, [2 x i64] } %t27, ptr %l20
  br label %bb9
bb8:
  %t29 = load { i64, [2 x i64] }, ptr %l22
  store { i64, [2 x i64] } %t29, ptr %l20
  br label %bb9
bb9:
  %t30 = load ptr, ptr %l14, !tbaa !29
  %t31 = load ptr, ptr %l16, !tbaa !29
  %t32 = load { i64, [2 x i64] }, ptr %l20
  %t33 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t30, ptr %t31, { i64, [2 x i64] } %t32)
  store %"compiler/scope:Val" %t33, ptr %l24
  br label %bb10
bb10:
  br label %ret
bb11:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i64, ptr %l1, !tbaa !24
  %t38 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eresultTerm(ptr %v0, ptr %t34, i64 %t35)
  store { i64, [2 x i64] } %t38, ptr %l27
  br label %bb12
bb12:
  %t39 = load { i64, [2 x i64] }, ptr %l27
  store { i64, [2 x i64] } %t39, ptr %l4
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load ptr, ptr %l2, !tbaa !29
  %t43 = load { i64, [2 x i64] }, ptr %l4
  %t47 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t40, ptr %t41, { i64, [2 x i64] } %t43)
  store %"compiler/scope:Val" %t47, ptr %l32
  br label %bb13
bb13:
  %t48 = load %"compiler/scope:Val", ptr %l32
  store %"compiler/scope:Val" %t48, ptr %l5
  %t49 = load i64, ptr %l1, !tbaa !24
  %t51 = icmp eq i64 %t49, 0
  br i1 %t51, label %bb14, label %bb15
bb14:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/scope:Scoper", ptr %t53, i32 0, i32 0
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = getelementptr %"compiler/generic:Program", ptr %t56, i32 0, i32 2
  store ptr %t58, ptr %l38, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/scope:Scoper", ptr %t59, i32 0, i32 25
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = icmp eq ptr %t62, null
  br i1 %t64, label %bb16, label %bb17
bb15:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb20
bb16:
  call void @__olang_check_failed(ptr @olang_loc_a48607f77104f946_b5a91344bffd8f22)
  unreachable
bb17:
  br label %bb18
bb18:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/scope:Scoper", ptr %t66, i32 0, i32 25
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Body", ptr %t69, i32 0, i32 2
  %t73 = load i32, ptr %t72, !tbaa !23
  %t74 = load ptr, ptr %l38, !tbaa !29
  %t76 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t74, i32 %t73)
  store i32 %t76, ptr %l46
  br label %bb19
bb19:
  %t77 = load i32, ptr %l46, !range !{i32 0, i32 33}
  %t79 = trunc i64 21 to i32
  %t80 = icmp eq i32 %t77, %t79
  store i1 %t80, ptr %l35, !tbaa !21
  br label %bb20
bb20:
  %t82 = load i1, ptr %l35, !tbaa !21
  br i1 %t82, label %bb21, label %bb22
bb21:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/scope:Scoper", ptr %t83, i32 0, i32 0
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  store ptr %t88, ptr %l52, !tbaa !29
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/scope:Scoper", ptr %t89, i32 0, i32 0
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t94 = getelementptr %"compiler/generic:Program", ptr %t92, i32 0, i32 2
  store ptr %t94, ptr %l55, !tbaa !29
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/scope:Scoper", ptr %t95, i32 0, i32 25
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t100 = icmp eq ptr %t98, null
  br i1 %t100, label %bb23, label %bb24
bb22:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb28
bb23:
  call void @__olang_check_failed(ptr @olang_loc_a48607f77104f946_b5a91344bffd8f22)
  unreachable
bb24:
  br label %bb25
bb25:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/scope:Scoper", ptr %t102, i32 0, i32 25
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t108 = getelementptr %"compiler/typed:Body", ptr %t105, i32 0, i32 2
  %t109 = load i32, ptr %t108, !tbaa !23
  %t110 = load ptr, ptr %l55, !tbaa !29
  %t112 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t110, i32 %t109)
  store i32 %t112, ptr %l63
  br label %bb26
bb26:
  %t113 = load ptr, ptr %l52, !tbaa !29
  %t114 = load i32, ptr %l63, !tbaa !23
  %t115 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t113, i32 %t114)
  store i32 %t115, ptr %l64
  br label %bb27
bb27:
  %t116 = load i32, ptr %l64, !range !{i32 0, i32 33}
  %t118 = trunc i64 22 to i32
  %t119 = icmp eq i32 %t116, %t118
  %t121 = xor i1 %t119, true
  store i1 %t121, ptr %l49, !tbaa !21
  br label %bb28
bb28:
  %t123 = load i1, ptr %l49, !tbaa !21
  br i1 %t123, label %bb29, label %bb30
bb29:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteResBind(ptr %v0, ptr %v1, ptr %t124, ptr %t125)
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb32
bb32:
  %t128 = getelementptr %"compiler/scope:Val", ptr %l5, i32 0, i32 0
  %t129 = load i32, ptr %t128, !range !{i32 0, i32 5}
  %t131 = trunc i64 3 to i32
  %t132 = icmp eq i32 %t129, %t131
  %t134 = xor i1 %t132, true
  br i1 %t134, label %bb33, label %bb34
bb33:
  br label %ret
bb34:
  br label %bb35
bb35:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/scope:Scoper", ptr %t136, i32 0, i32 6
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/scope:Scoper", ptr %t139, i32 0, i32 26
  %t142 = load i64, ptr %t141, !tbaa !24
  %t145 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t138, i64 %t142)
  store ptr %t145, ptr %l77
  br label %bb36
bb36:
  %t146 = load ptr, ptr %l77, !tbaa !29
  %t148 = getelementptr %"compiler/scope:summary", ptr %t146, i32 0, i32 14
  store i1 true, ptr %t148, !tbaa !21
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load i32, ptr %l3, !tbaa !23
  %t153 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreThrough(ptr %v0, ptr %t149, i32 %t150)
  store i1 %t153, ptr %l81
  br label %bb37
bb37:
  %t154 = load i1, ptr %l81, !tbaa !21
  store i1 %t154, ptr %l6, !tbaa !21
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load i64, ptr %l1, !tbaa !24
  %t159 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eresultMark(ptr %v0, ptr %t155, i64 %t156)
  store { i64, [2 x i64] } %t159, ptr %l84
  br label %bb38
bb38:
  %t160 = load { i64, [2 x i64] }, ptr %l84
  %t163 = extractvalue { i64, [2 x i64] } %t160, 0
  %t164 = icmp eq i64 %t163, 2
  br i1 %t164, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb46
bb41:
  %t166 = load ptr, ptr %l0, !tbaa !29
  store ptr %t166, ptr %l87, !tbaa !29
  %t167 = getelementptr %"compiler/scope:Val", ptr %l5, i32 0, i32 1
  %t168 = load { i64, [2 x i64] }, ptr %t167
  store { i64, [2 x i64] } %t168, ptr %l88
  %t169 = load { i64, [2 x i64] }, ptr %l4
  %t171 = extractvalue { i64, [2 x i64] } %t169, 0
  %t172 = icmp eq i64 %t171, 0
  %t174 = xor i1 %t172, true
  br i1 %t174, label %bb42, label %bb43
bb42:
  %t176 = load { i64, [2 x i64] }, ptr %l4
  store { i64, [2 x i64] } %t176, ptr %l92
  br label %bb44
bb43:
  store { i64, [2 x i64] } zeroinitializer, ptr %t178
  %t179 = getelementptr { i64, [2 x i64] }, ptr %t178, i32 0, i32 0
  store i64 3, ptr %t179
  %t180 = load { i64, [2 x i64] }, ptr %t178
  store { i64, [2 x i64] } %t180, ptr %l92
  br label %bb44
bb44:
  %t182 = load i1, ptr %l6, !tbaa !21
  %t183 = load ptr, ptr %l2, !tbaa !29
  %t184 = load i64, ptr @G_2ecompiler_2fscope_2eFitReturn, !tbaa !24
  %t185 = load ptr, ptr %l87, !tbaa !29
  %t186 = load { i64, [2 x i64] }, ptr %l88
  %t187 = load { i64, [2 x i64] }, ptr %l92
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efit(ptr %v0, ptr %v1, ptr %t185, { i64, [2 x i64] } %t186, { i64, [2 x i64] } %t187, i1 %t182, ptr %t183, i64 %t184)
  br label %bb45
bb45:
  br label %bb52
bb46:
  br i1 true, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb51
bb49:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t192 = getelementptr %"compiler/scope:Val", ptr %l5, i32 0, i32 1
  %t193 = load { i64, [2 x i64] }, ptr %t192
  %t194 = load { i64, [2 x i64] }, ptr %l4
  %t195 = load i1, ptr %l6, !tbaa !21
  %t196 = load ptr, ptr %l2, !tbaa !29
  %t197 = load i64, ptr @G_2ecompiler_2fscope_2eFitReturn, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efit(ptr %v0, ptr %v1, ptr %t191, { i64, [2 x i64] } %t193, { i64, [2 x i64] } %t194, i1 %t195, ptr %t196, i64 %t197)
  br label %bb50
bb50:
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_3199956179aa6dd4_40cdc1669d0af040)
  unreachable
bb52:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eretake(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca i64
  %l27 = alloca i64
  %l30 = alloca i64
  %l48 = alloca { i64, ptr }
  %l52 = alloca ptr
  %l53 = alloca i64
  %l57 = alloca %"compiler/typed:Plan"
  %l59 = alloca %"compiler/typed:Plan"
  %l61 = alloca ptr
  %l62 = alloca i64
  %l66 = alloca ptr
  %l68 = alloca ptr
  %l69 = alloca i64
  %l73 = alloca i1
  %l84 = alloca i64
  %l86 = alloca i64
  %l91 = alloca %"compiler/scope:fnUse"
  %l99 = alloca i64
  %l101 = alloca i64
  %l106 = alloca %"compiler/scope:Gap"
  %l114 = alloca i64
  %l116 = alloca i64
  %l121 = alloca i64
  %l129 = alloca i64
  %l131 = alloca i64
  %l136 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l142 = alloca ptr
  %t67 = alloca %"compiler/typed:Plan", align 8
  %t70 = alloca %"compiler/typed:Plan", align 8
  %t74 = alloca %"compiler/typed:Plan", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t5 = load i64, ptr %l4, !tbaa !24
  %t6 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l5, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l30, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l30, !tbaa !24
  store i64 %t31, ptr %l27, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l27, !tbaa !24
  store i64 %t32, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t33 = load i64, ptr %l7, !tbaa !24
  %t34 = load i64, ptr %l6, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  br label %bb19
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l3, !tbaa !24
  %t42 = load i64, ptr %l7, !tbaa !24
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l8, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t51, ptr %l48, !tbaa !27
  %t52 = load i64, ptr %l8, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i64, ptr %t55, i64 %t52
  %t57 = load i64, ptr %t56, !tbaa !34
  store i64 %t57, ptr %l9, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/scope:Scoper", ptr %t59, i32 0, i32 2
  store ptr %t61, ptr %l52, !tbaa !29
  %t62 = load i64, ptr %l9, !tbaa !24
  store i64 %t62, ptr %l53, !tbaa !24
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr %"compiler/scope:compRun", ptr %t63, i32 0, i32 0
  %t66 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %t67, ptr %v1, ptr %v1, ptr %t65, i64 %t66)
  call void @llvm.memmove.p0.p0.i64(ptr %l57, ptr %t67, i64 176, i1 false)
  br label %bb11
bb11:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aPlan(ptr %t70, ptr %v1, ptr %l57)
  call void @llvm.memmove.p0.p0.i64(ptr %l59, ptr %t70, i64 176, i1 false)
  br label %bb12
bb12:
  %t72 = load ptr, ptr %l52, !tbaa !29
  %t73 = load i64, ptr %l53, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %t74, ptr %l59, i64 176, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eSetAt_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v1, ptr %t72, i64 %t73, ptr %t74)
  br label %bb13
bb13:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/scope:Scoper", ptr %t75, i32 0, i32 6
  store ptr %t77, ptr %l61, !tbaa !29
  %t78 = load i64, ptr %l9, !tbaa !24
  store i64 %t78, ptr %l62, !tbaa !24
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr %"compiler/scope:compRun", ptr %t79, i32 0, i32 1
  %t82 = load i64, ptr %l8, !tbaa !24
  %t85 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v1, ptr %v1, ptr %t81, i64 %t82)
  store ptr %t85, ptr %l66
  br label %bb14
bb14:
  %t86 = load ptr, ptr %l61, !tbaa !29
  %t87 = load i64, ptr %l62, !tbaa !24
  %t88 = load ptr, ptr %l66, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hdd18cd18fee7da2cefbfd21396944747(ptr %v0, ptr %v1, ptr %t86, i64 %t87, ptr %t88)
  br label %bb15
bb15:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/scope:Scoper", ptr %t89, i32 0, i32 11
  store ptr %t91, ptr %l68, !tbaa !29
  %t92 = load i64, ptr %l9, !tbaa !24
  store i64 %t92, ptr %l69, !tbaa !24
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t95 = getelementptr %"compiler/scope:compRun", ptr %t93, i32 0, i32 2
  %t96 = load i64, ptr %l8, !tbaa !24
  %t99 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v1, ptr %t95, i64 %t96)
  store i1 %t99, ptr %l73
  br label %bb16
bb16:
  %t100 = load ptr, ptr %l68, !tbaa !29
  %t101 = load i64, ptr %l69, !tbaa !24
  %t102 = load i1, ptr %l73, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t100, i64 %t101, i1 %t102)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t103 = load i64, ptr %l7, !tbaa !24
  %t105 = add i64 %t103, 1
  store i64 %t105, ptr %l7, !tbaa !24
  br label %bb7
bb19:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/scope:Scoper", ptr %t107, i32 0, i32 0
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/generic:Program", ptr %t110, i32 0, i32 0
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = getelementptr %"compiler/load:Loader", ptr %t113, i32 0, i32 4
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr %"compiler/scope:compRun", ptr %t117, i32 0, i32 3
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eReplay(ptr %v0, ptr %v1, ptr %t116, ptr %t119)
  br label %bb20
bb20:
  %t122 = load ptr, ptr %l1, !tbaa !29
  %t124 = getelementptr %"compiler/scope:compRun", ptr %t122, i32 0, i32 4
  store ptr %t124, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb21
bb21:
  %t126 = load i64, ptr %l11, !tbaa !24
  store i64 %t126, ptr %l84, !tbaa !24
  %t127 = load ptr, ptr %l10, !tbaa !29
  %t129 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnUse_3e_2eLen_3ccompiler_2fscope_3afnUse_3e(ptr %v1, ptr %t127)
  store i64 %t129, ptr %l86
  br label %bb22
bb22:
  %t130 = load i64, ptr %l84, !tbaa !24
  %t131 = load i64, ptr %l86, !tbaa !24
  %t132 = icmp slt i64 %t130, %t131
  %t134 = xor i1 %t132, true
  br i1 %t134, label %bb23, label %bb24
bb23:
  br label %bb29
bb24:
  br label %bb25
bb25:
  %t136 = load ptr, ptr %l10, !tbaa !29
  %t137 = load i64, ptr %l11, !tbaa !24
  %t140 = call %"compiler/scope:fnUse" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnUse_3e_2eAt_3ccompiler_2fscope_3afnUse_3e(ptr %v1, ptr %t136, i64 %t137)
  store %"compiler/scope:fnUse" %t140, ptr %l91
  br label %bb26
bb26:
  %t141 = load %"compiler/scope:fnUse", ptr %l91
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/scope:Scoper", ptr %t142, i32 0, i32 83
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnUse_3e_2ePush_3ccompiler_2fscope_3afnUse_3e(ptr %v0, ptr %t144, %"compiler/scope:fnUse" %t141)
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t148 = load i64, ptr %l11, !tbaa !24
  %t150 = add i64 %t148, 1
  store i64 %t150, ptr %l11, !tbaa !24
  br label %bb21
bb29:
  %t152 = load ptr, ptr %l1, !tbaa !29
  %t154 = getelementptr %"compiler/scope:compRun", ptr %t152, i32 0, i32 5
  store ptr %t154, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb30
bb30:
  %t156 = load i64, ptr %l14, !tbaa !24
  store i64 %t156, ptr %l99, !tbaa !24
  %t157 = load ptr, ptr %l13, !tbaa !29
  %t159 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aGap_3e_2eLen_3ccompiler_2fscope_3aGap_3e(ptr %v1, ptr %t157)
  store i64 %t159, ptr %l101
  br label %bb31
bb31:
  %t160 = load i64, ptr %l99, !tbaa !24
  %t161 = load i64, ptr %l101, !tbaa !24
  %t162 = icmp slt i64 %t160, %t161
  %t164 = xor i1 %t162, true
  br i1 %t164, label %bb32, label %bb33
bb32:
  br label %bb38
bb33:
  br label %bb34
bb34:
  %t166 = load ptr, ptr %l13, !tbaa !29
  %t167 = load i64, ptr %l14, !tbaa !24
  %t170 = call %"compiler/scope:Gap" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aGap_3e_2eAt_3ccompiler_2fscope_3aGap_3e(ptr %v1, ptr %v1, ptr %t166, i64 %t167)
  store %"compiler/scope:Gap" %t170, ptr %l106
  br label %bb35
bb35:
  %t171 = load %"compiler/scope:Gap", ptr %l106
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr %"compiler/scope:Scoper", ptr %t172, i32 0, i32 3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aGap_3e_2ePush_3ccompiler_2fscope_3aGap_3e(ptr %v0, ptr %v1, ptr %t174, %"compiler/scope:Gap" %t171)
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t178 = load i64, ptr %l14, !tbaa !24
  %t180 = add i64 %t178, 1
  store i64 %t180, ptr %l14, !tbaa !24
  br label %bb30
bb38:
  %t182 = load ptr, ptr %l1, !tbaa !29
  %t184 = getelementptr %"compiler/scope:compRun", ptr %t182, i32 0, i32 6
  store ptr %t184, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb39
bb39:
  %t186 = load i64, ptr %l17, !tbaa !24
  store i64 %t186, ptr %l114, !tbaa !24
  %t187 = load ptr, ptr %l16, !tbaa !29
  %t189 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t187)
  store i64 %t189, ptr %l116
  br label %bb40
bb40:
  %t190 = load i64, ptr %l114, !tbaa !24
  %t191 = load i64, ptr %l116, !tbaa !24
  %t192 = icmp slt i64 %t190, %t191
  %t194 = xor i1 %t192, true
  br i1 %t194, label %bb41, label %bb42
bb41:
  br label %bb47
bb42:
  br label %bb43
bb43:
  %t196 = load ptr, ptr %l16, !tbaa !29
  %t197 = load i64, ptr %l17, !tbaa !24
  %t200 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t196, i64 %t197)
  store i64 %t200, ptr %l121
  br label %bb44
bb44:
  %t201 = load i64, ptr %l121, !tbaa !24
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/scope:Scoper", ptr %t202, i32 0, i32 141
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t204, i64 %t201, i1 true)
  br label %bb45
bb45:
  br label %bb46
bb46:
  %t208 = load i64, ptr %l17, !tbaa !24
  %t210 = add i64 %t208, 1
  store i64 %t210, ptr %l17, !tbaa !24
  br label %bb39
bb47:
  %t212 = load ptr, ptr %l1, !tbaa !29
  %t214 = getelementptr %"compiler/scope:compRun", ptr %t212, i32 0, i32 7
  store ptr %t214, ptr %l19, !tbaa !29
  store i64 0, ptr %l20, !tbaa !24
  br label %bb48
bb48:
  %t216 = load i64, ptr %l20, !tbaa !24
  store i64 %t216, ptr %l129, !tbaa !24
  %t217 = load ptr, ptr %l19, !tbaa !29
  %t219 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_Hda4ef06466535e66801340e999dad217(ptr %v1, ptr %t217)
  store i64 %t219, ptr %l131
  br label %bb49
bb49:
  %t220 = load i64, ptr %l129, !tbaa !24
  %t221 = load i64, ptr %l131, !tbaa !24
  %t222 = icmp slt i64 %t220, %t221
  %t224 = xor i1 %t222, true
  br i1 %t224, label %bb50, label %bb51
bb50:
  br label %bb56
bb51:
  br label %bb52
bb52:
  %t226 = load ptr, ptr %l19, !tbaa !29
  %t227 = load i64, ptr %l20, !tbaa !24
  %t230 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H87a29777ccf22aa2985fa9d3c61f9cd3(ptr %v1, ptr %t226, i64 %t227)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t230, ptr %l136
  br label %bb53
bb53:
  %t231 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l136
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr %"compiler/scope:Scoper", ptr %t232, i32 0, i32 142
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t234, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t231, i1 true)
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t238 = load i64, ptr %l20, !tbaa !24
  %t240 = add i64 %t238, 1
  store i64 %t240, ptr %l20, !tbaa !24
  br label %bb48
bb56:
  %t242 = load ptr, ptr %l0, !tbaa !29
  store ptr %t242, ptr %l142, !tbaa !29
  %t243 = load ptr, ptr %l142, !tbaa !29
  %t244 = getelementptr %"compiler/scope:Scoper", ptr %t243, i32 0, i32 138
  %t245 = load i64, ptr %t244, !tbaa !24
  %t246 = load ptr, ptr %l1, !tbaa !29
  %t248 = getelementptr %"compiler/scope:compRun", ptr %t246, i32 0, i32 8
  %t249 = load i64, ptr %t248, !tbaa !24
  %t252 = add i64 %t245, %t249
  %t254 = load ptr, ptr %l142, !tbaa !29
  %t255 = getelementptr %"compiler/scope:Scoper", ptr %t254, i32 0, i32 138
  store i64 %t252, ptr %t255, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i64
  %l41 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca i64
  %l47 = alloca ptr
  %l50 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca i1
  %l62 = alloca i1
  %l64 = alloca i1
  %l69 = alloca i64
  %l73 = alloca ptr
  %l75 = alloca i64
  %l76 = alloca ptr
  %l77 = alloca i1
  %l87 = alloca ptr
  %l88 = alloca i1
  %l101 = alloca { i64, ptr }
  %l110 = alloca ptr
  %l111 = alloca i1
  %l124 = alloca { i64, ptr }
  %l133 = alloca ptr
  %l134 = alloca i1
  %l146 = alloca { i64, ptr }
  %l155 = alloca ptr
  %l156 = alloca i1
  %l170 = alloca ptr
  %l171 = alloca i1
  %l184 = alloca { i64, ptr }
  %l197 = alloca ptr
  %l198 = alloca i1
  %l211 = alloca { i64, ptr }
  %l228 = alloca { i64, ptr }
  %l245 = alloca ptr
  %l254 = alloca ptr
  %l255 = alloca i1
  %l272 = alloca { i64, ptr }
  %l281 = alloca ptr
  %l282 = alloca i1
  %l287 = alloca ptr
  %l288 = alloca i1
  %l300 = alloca { i64, ptr }
  %l310 = alloca ptr
  %l311 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp eq i64 %t5, 0
  store i1 %t7, ptr %l50, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l50, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t11 = load ptr, ptr %l53, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l53, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 18}
  %t17 = icmp eq i64 %t15, 3
  store i1 %t17, ptr %l54, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l54, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr { i64, [5 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t21, i32 0, i32 1
  %t23 = load i32, ptr %t22
  store i32 %t23, ptr %l3, !tbaa !23
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t27, i32 0, i32 2
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l4, !tbaa !29
  br label %bb11
bb10:
  br label %bb22
bb11:
  %t31 = load ptr, ptr %l4, !tbaa !29
  %t33 = call i1 @compiler_2fscope_2eflThroughRef(ptr %v1, ptr %t31)
  store i1 %t33, ptr %l62
  br label %bb12
bb12:
  %t34 = load i1, ptr %l62, !tbaa !21
  %t35 = xor i1 %t34, true
  br i1 %t35, label %bb13, label %bb14
bb13:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/scope:Scoper", ptr %t37, i32 0, i32 0
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 2
  %t43 = load i32, ptr %l3, !tbaa !23
  %t46 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t42, i32 %t43)
  store i64 %t46, ptr %l69
  br label %bb15
bb14:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb16
bb15:
  %t47 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t48 = load i64, ptr %l69, !tbaa !24
  %t50 = and i64 %t48, %t47
  %t52 = icmp ne i64 %t50, 0
  store i1 %t52, ptr %l64, !tbaa !21
  br label %bb16
bb16:
  %t54 = load i1, ptr %l64, !tbaa !21
  br i1 %t54, label %bb17, label %bb18
bb17:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l73, !tbaa !29
  %t56 = load ptr, ptr %l4, !tbaa !29
  %t58 = call i64 @compiler_2fscope_2eflRoot(ptr %v1, ptr %t56)
  store i64 %t58, ptr %l75
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t59 = load ptr, ptr %l73, !tbaa !29
  %t60 = load i64, ptr %l75, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlDrop(ptr %v0, ptr %t59, i64 %t60)
  br label %bb20
bb20:
  br label %bb21
bb21:
  br label %bb168
bb22:
  %t61 = load ptr, ptr %l1, !tbaa !29
  store ptr %t61, ptr %l76, !tbaa !29
  store i1 false, ptr %l77, !tbaa !21
  %t62 = load ptr, ptr %l76, !tbaa !29
  %t63 = icmp ne ptr %t62, null
  br i1 %t63, label %bb23, label %bb24
bb23:
  %t65 = load ptr, ptr %l76, !tbaa !29
  %t66 = load i64, ptr %t65, !range !{i64 0, i64 18}
  %t68 = icmp eq i64 %t66, 5
  store i1 %t68, ptr %l77, !tbaa !21
  br label %bb24
bb24:
  %t69 = load i1, ptr %l77, !tbaa !21
  br i1 %t69, label %bb25, label %bb26
bb25:
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr { i64, [5 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t72, i32 0, i32 2
  %t74 = load ptr, ptr %t73
  store ptr %t74, ptr %l5, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load ptr, ptr %l5, !tbaa !29
  %t79 = getelementptr %"compiler/typed:Promote", ptr %t77, i32 0, i32 0
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlExpr(ptr %v0, ptr %v1, ptr %t76, ptr %t80, i64 %t82)
  br label %bb28
bb28:
  br label %bb168
bb29:
  %t86 = load ptr, ptr %l1, !tbaa !29
  store ptr %t86, ptr %l87, !tbaa !29
  store i1 false, ptr %l88, !tbaa !21
  %t87 = load ptr, ptr %l87, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb30, label %bb31
bb30:
  %t90 = load ptr, ptr %l87, !tbaa !29
  %t91 = load i64, ptr %t90, !range !{i64 0, i64 18}
  %t93 = icmp eq i64 %t91, 6
  store i1 %t93, ptr %l88, !tbaa !21
  br label %bb31
bb31:
  %t94 = load i1, ptr %l88, !tbaa !21
  br i1 %t94, label %bb32, label %bb33
bb32:
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr { i64, [5 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t97, i32 0, i32 2
  %t99 = load ptr, ptr %t98
  store ptr %t99, ptr %l6, !tbaa !29
  br label %bb34
bb33:
  br label %bb42
bb34:
  %t101 = load ptr, ptr %l6, !tbaa !29
  %t103 = getelementptr %"compiler/typed:Call", ptr %t101, i32 0, i32 1
  %t104 = load { i64, ptr }, ptr %t103, !tbaa !27
  store { i64, ptr } %t104, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t106 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t106, 0
  store i64 %t108, ptr %l9, !tbaa !24
  br label %bb35
bb35:
  %t110 = load i64, ptr %l8, !tbaa !24
  %t111 = load i64, ptr %l9, !tbaa !24
  %t114 = icmp slt i64 %t110, %t111
  %t116 = xor i1 %t114, true
  br i1 %t116, label %bb36, label %bb37
bb36:
  br label %bb41
bb37:
  br label %bb38
bb38:
  %t118 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t118, ptr %l101, !tbaa !27
  %t119 = load i64, ptr %l8, !tbaa !24
  %t121 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr ptr, ptr %t122, i64 %t119
  %t124 = load ptr, ptr %t123, !tbaa !39
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t129 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlExpr(ptr %v0, ptr %v1, ptr %t126, ptr %t124, i64 %t129)
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t133 = load i64, ptr %l8, !tbaa !24
  %t135 = add i64 %t133, 1
  store i64 %t135, ptr %l8, !tbaa !24
  br label %bb35
bb41:
  br label %bb168
bb42:
  %t137 = load ptr, ptr %l1, !tbaa !29
  store ptr %t137, ptr %l110, !tbaa !29
  store i1 false, ptr %l111, !tbaa !21
  %t138 = load ptr, ptr %l110, !tbaa !29
  %t139 = icmp ne ptr %t138, null
  br i1 %t139, label %bb43, label %bb44
bb43:
  %t141 = load ptr, ptr %l110, !tbaa !29
  %t142 = load i64, ptr %t141, !range !{i64 0, i64 18}
  %t144 = icmp eq i64 %t142, 7
  store i1 %t144, ptr %l111, !tbaa !21
  br label %bb44
bb44:
  %t145 = load i1, ptr %l111, !tbaa !21
  br i1 %t145, label %bb45, label %bb46
bb45:
  %t146 = load ptr, ptr %l1, !tbaa !29
  %t148 = getelementptr { i64, [5 x i64] }, ptr %t146, i32 0, i32 1
  %t149 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t148, i32 0, i32 2
  %t150 = load ptr, ptr %t149
  store ptr %t150, ptr %l11, !tbaa !29
  br label %bb47
bb46:
  br label %bb55
bb47:
  %t152 = load ptr, ptr %l11, !tbaa !29
  %t154 = getelementptr %"compiler/typed:Make", ptr %t152, i32 0, i32 2
  %t155 = load { i64, ptr }, ptr %t154, !tbaa !27
  store { i64, ptr } %t155, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t157 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t157, 0
  store i64 %t159, ptr %l14, !tbaa !24
  br label %bb48
bb48:
  %t161 = load i64, ptr %l13, !tbaa !24
  %t162 = load i64, ptr %l14, !tbaa !24
  %t165 = icmp slt i64 %t161, %t162
  %t167 = xor i1 %t165, true
  br i1 %t167, label %bb49, label %bb50
bb49:
  br label %bb54
bb50:
  br label %bb51
bb51:
  %t169 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t169, ptr %l124, !tbaa !27
  %t170 = load i64, ptr %l13, !tbaa !24
  %t172 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !27
  %t174 = getelementptr ptr, ptr %t173, i64 %t170
  %t175 = load ptr, ptr %t174, !tbaa !39
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t180 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlExpr(ptr %v0, ptr %v1, ptr %t177, ptr %t175, i64 %t180)
  br label %bb52
bb52:
  br label %bb53
bb53:
  %t184 = load i64, ptr %l13, !tbaa !24
  %t186 = add i64 %t184, 1
  store i64 %t186, ptr %l13, !tbaa !24
  br label %bb48
bb54:
  br label %bb168
bb55:
  %t188 = load ptr, ptr %l1, !tbaa !29
  store ptr %t188, ptr %l133, !tbaa !29
  store i1 false, ptr %l134, !tbaa !21
  %t189 = load ptr, ptr %l133, !tbaa !29
  %t190 = icmp ne ptr %t189, null
  br i1 %t190, label %bb56, label %bb57
bb56:
  %t192 = load ptr, ptr %l133, !tbaa !29
  %t193 = load i64, ptr %t192, !range !{i64 0, i64 18}
  %t195 = icmp eq i64 %t193, 9
  store i1 %t195, ptr %l134, !tbaa !21
  br label %bb57
bb57:
  %t196 = load i1, ptr %l134, !tbaa !21
  br i1 %t196, label %bb58, label %bb59
bb58:
  %t197 = load ptr, ptr %l1, !tbaa !29
  %t199 = getelementptr { i64, [5 x i64] }, ptr %t197, i32 0, i32 1
  %t200 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t199, i32 0, i32 4
  %t201 = load { i64, ptr }, ptr %t200
  store { i64, ptr } %t201, ptr %l16, !tbaa !27
  br label %bb60
bb59:
  br label %bb68
bb60:
  %t203 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t203, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t205 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t207 = extractvalue { i64, ptr } %t205, 0
  store i64 %t207, ptr %l19, !tbaa !24
  br label %bb61
bb61:
  %t209 = load i64, ptr %l18, !tbaa !24
  %t210 = load i64, ptr %l19, !tbaa !24
  %t213 = icmp slt i64 %t209, %t210
  %t215 = xor i1 %t213, true
  br i1 %t215, label %bb62, label %bb63
bb62:
  br label %bb67
bb63:
  br label %bb64
bb64:
  %t217 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t217, ptr %l146, !tbaa !27
  %t218 = load i64, ptr %l18, !tbaa !24
  %t220 = getelementptr { i64, ptr }, ptr %l146, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !27
  %t222 = getelementptr ptr, ptr %t221, i64 %t218
  %t223 = load ptr, ptr %t222, !tbaa !39
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t228 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlExpr(ptr %v0, ptr %v1, ptr %t225, ptr %t223, i64 %t228)
  br label %bb65
bb65:
  br label %bb66
bb66:
  %t232 = load i64, ptr %l18, !tbaa !24
  %t234 = add i64 %t232, 1
  store i64 %t234, ptr %l18, !tbaa !24
  br label %bb61
bb67:
  br label %bb168
bb68:
  %t236 = load ptr, ptr %l1, !tbaa !29
  store ptr %t236, ptr %l155, !tbaa !29
  store i1 false, ptr %l156, !tbaa !21
  %t237 = load ptr, ptr %l155, !tbaa !29
  %t238 = icmp ne ptr %t237, null
  br i1 %t238, label %bb69, label %bb70
bb69:
  %t240 = load ptr, ptr %l155, !tbaa !29
  %t241 = load i64, ptr %t240, !range !{i64 0, i64 18}
  %t243 = icmp eq i64 %t241, 11
  store i1 %t243, ptr %l156, !tbaa !21
  br label %bb70
bb70:
  %t244 = load i1, ptr %l156, !tbaa !21
  br i1 %t244, label %bb71, label %bb72
bb71:
  %t245 = load ptr, ptr %l1, !tbaa !29
  %t247 = getelementptr { i64, [5 x i64] }, ptr %t245, i32 0, i32 1
  %t248 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t247, i32 0, i32 2
  %t249 = load ptr, ptr %t248
  store ptr %t249, ptr %l21, !tbaa !29
  br label %bb73
bb72:
  br label %bb76
bb73:
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t252 = load ptr, ptr %l21, !tbaa !29
  %t254 = getelementptr %"compiler/typed:Cond", ptr %t252, i32 0, i32 1
  %t255 = load ptr, ptr %t254, !tbaa !29
  %t256 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlExpr(ptr %v0, ptr %v1, ptr %t251, ptr %t255, i64 %t256)
  br label %bb74
bb74:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t261 = load ptr, ptr %l21, !tbaa !29
  %t263 = getelementptr %"compiler/typed:Cond", ptr %t261, i32 0, i32 2
  %t264 = load ptr, ptr %t263, !tbaa !29
  %t266 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlExpr(ptr %v0, ptr %v1, ptr %t260, ptr %t264, i64 %t266)
  br label %bb75
bb75:
  br label %bb168
bb76:
  %t270 = load ptr, ptr %l1, !tbaa !29
  store ptr %t270, ptr %l170, !tbaa !29
  store i1 false, ptr %l171, !tbaa !21
  %t271 = load ptr, ptr %l170, !tbaa !29
  %t272 = icmp ne ptr %t271, null
  br i1 %t272, label %bb77, label %bb78
bb77:
  %t274 = load ptr, ptr %l170, !tbaa !29
  %t275 = load i64, ptr %t274, !range !{i64 0, i64 18}
  %t277 = icmp eq i64 %t275, 12
  store i1 %t277, ptr %l171, !tbaa !21
  br label %bb78
bb78:
  %t278 = load i1, ptr %l171, !tbaa !21
  br i1 %t278, label %bb79, label %bb80
bb79:
  %t279 = load ptr, ptr %l1, !tbaa !29
  %t281 = getelementptr { i64, [5 x i64] }, ptr %t279, i32 0, i32 1
  %t282 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t281, i32 0, i32 2
  %t283 = load ptr, ptr %t282
  store ptr %t283, ptr %l22, !tbaa !29
  br label %bb81
bb80:
  br label %bb90
bb81:
  %t285 = load ptr, ptr %l22, !tbaa !29
  %t287 = getelementptr %"compiler/typed:Seq", ptr %t285, i32 0, i32 0
  %t288 = load { i64, ptr }, ptr %t287, !tbaa !27
  store { i64, ptr } %t288, ptr %l23, !tbaa !27
  store i64 0, ptr %l24, !tbaa !24
  %t290 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t292 = extractvalue { i64, ptr } %t290, 0
  store i64 %t292, ptr %l25, !tbaa !24
  br label %bb82
bb82:
  %t294 = load i64, ptr %l24, !tbaa !24
  %t295 = load i64, ptr %l25, !tbaa !24
  %t298 = icmp slt i64 %t294, %t295
  %t300 = xor i1 %t298, true
  br i1 %t300, label %bb83, label %bb84
bb83:
  br label %bb88
bb84:
  br label %bb85
bb85:
  %t302 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t302, ptr %l184, !tbaa !27
  %t303 = load i64, ptr %l24, !tbaa !24
  %t305 = getelementptr { i64, ptr }, ptr %l184, i32 0, i32 1
  %t306 = load ptr, ptr %t305, !tbaa !27
  %t307 = getelementptr ptr, ptr %t306, i64 %t303
  %t308 = load ptr, ptr %t307, !tbaa !39
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t313 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlStmt(ptr %v0, ptr %v1, ptr %t310, ptr %t308, i64 %t313)
  br label %bb86
bb86:
  br label %bb87
bb87:
  %t317 = load i64, ptr %l24, !tbaa !24
  %t319 = add i64 %t317, 1
  store i64 %t319, ptr %l24, !tbaa !24
  br label %bb82
bb88:
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t322 = load ptr, ptr %l22, !tbaa !29
  %t324 = getelementptr %"compiler/typed:Seq", ptr %t322, i32 0, i32 1
  %t325 = load ptr, ptr %t324, !tbaa !29
  %t326 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlExpr(ptr %v0, ptr %v1, ptr %t321, ptr %t325, i64 %t326)
  br label %bb89
bb89:
  br label %bb168
bb90:
  %t330 = load ptr, ptr %l1, !tbaa !29
  store ptr %t330, ptr %l197, !tbaa !29
  store i1 false, ptr %l198, !tbaa !21
  %t331 = load ptr, ptr %l197, !tbaa !29
  %t332 = icmp ne ptr %t331, null
  br i1 %t332, label %bb91, label %bb92
bb91:
  %t334 = load ptr, ptr %l197, !tbaa !29
  %t335 = load i64, ptr %t334, !range !{i64 0, i64 18}
  %t337 = icmp eq i64 %t335, 13
  store i1 %t337, ptr %l198, !tbaa !21
  br label %bb92
bb92:
  %t338 = load i1, ptr %l198, !tbaa !21
  br i1 %t338, label %bb93, label %bb94
bb93:
  %t339 = load ptr, ptr %l1, !tbaa !29
  %t341 = getelementptr { i64, [5 x i64] }, ptr %t339, i32 0, i32 1
  %t342 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t341, i32 0, i32 2
  %t343 = load ptr, ptr %t342
  store ptr %t343, ptr %l27, !tbaa !29
  br label %bb95
bb94:
  br label %bb118
bb95:
  %t345 = load ptr, ptr %l27, !tbaa !29
  %t347 = getelementptr %"compiler/typed:Match", ptr %t345, i32 0, i32 0
  %t348 = load { i64, ptr }, ptr %t347, !tbaa !27
  store { i64, ptr } %t348, ptr %l28, !tbaa !27
  store i64 0, ptr %l29, !tbaa !24
  %t350 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t352 = extractvalue { i64, ptr } %t350, 0
  store i64 %t352, ptr %l30, !tbaa !24
  br label %bb96
bb96:
  %t354 = load i64, ptr %l29, !tbaa !24
  %t355 = load i64, ptr %l30, !tbaa !24
  %t358 = icmp slt i64 %t354, %t355
  %t360 = xor i1 %t358, true
  br i1 %t360, label %bb97, label %bb98
bb97:
  br label %bb102
bb98:
  br label %bb99
bb99:
  %t362 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t362, ptr %l211, !tbaa !27
  %t363 = load i64, ptr %l29, !tbaa !24
  %t365 = getelementptr { i64, ptr }, ptr %l211, i32 0, i32 1
  %t366 = load ptr, ptr %t365, !tbaa !27
  %t367 = getelementptr ptr, ptr %t366, i64 %t363
  %t368 = load ptr, ptr %t367, !tbaa !39
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t373 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlStmt(ptr %v0, ptr %v1, ptr %t370, ptr %t368, i64 %t373)
  br label %bb100
bb100:
  br label %bb101
bb101:
  %t377 = load i64, ptr %l29, !tbaa !24
  %t379 = add i64 %t377, 1
  store i64 %t379, ptr %l29, !tbaa !24
  br label %bb96
bb102:
  %t381 = load ptr, ptr %l27, !tbaa !29
  %t383 = getelementptr %"compiler/typed:Match", ptr %t381, i32 0, i32 1
  %t384 = load { i64, ptr }, ptr %t383, !tbaa !27
  store { i64, ptr } %t384, ptr %l32, !tbaa !27
  store i64 0, ptr %l33, !tbaa !24
  %t386 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t388 = extractvalue { i64, ptr } %t386, 0
  store i64 %t388, ptr %l34, !tbaa !24
  br label %bb103
bb103:
  %t390 = load i64, ptr %l33, !tbaa !24
  %t391 = load i64, ptr %l34, !tbaa !24
  %t394 = icmp slt i64 %t390, %t391
  %t396 = xor i1 %t394, true
  br i1 %t396, label %bb104, label %bb105
bb104:
  br label %bb110
bb105:
  br label %bb106
bb106:
  %t398 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t398, ptr %l228, !tbaa !27
  %t399 = load i64, ptr %l33, !tbaa !24
  %t401 = getelementptr { i64, ptr }, ptr %l228, i32 0, i32 1
  %t402 = load ptr, ptr %t401, !tbaa !27
  %t403 = getelementptr ptr, ptr %t402, i64 %t399
  %t404 = load ptr, ptr %t403, !tbaa !39
  store ptr %t404, ptr %l35, !tbaa !29
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t407 = load ptr, ptr %l35, !tbaa !29
  %t409 = getelementptr %"compiler/typed:Arm", ptr %t407, i32 0, i32 3
  %t410 = load ptr, ptr %t409, !tbaa !29
  %t411 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlBlock(ptr %v0, ptr %v1, ptr %t406, ptr %t410, i64 %t411)
  br label %bb107
bb107:
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t416 = load ptr, ptr %l35, !tbaa !29
  %t418 = getelementptr %"compiler/typed:Arm", ptr %t416, i32 0, i32 4
  %t419 = load ptr, ptr %t418, !tbaa !29
  %t420 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlExpr(ptr %v0, ptr %v1, ptr %t415, ptr %t419, i64 %t420)
  br label %bb108
bb108:
  br label %bb109
bb109:
  %t424 = load i64, ptr %l33, !tbaa !24
  %t426 = add i64 %t424, 1
  store i64 %t426, ptr %l33, !tbaa !24
  br label %bb103
bb110:
  %t428 = load ptr, ptr %l27, !tbaa !29
  %t430 = getelementptr %"compiler/typed:Match", ptr %t428, i32 0, i32 2
  %t431 = load ptr, ptr %t430, !tbaa !29
  %t433 = icmp eq ptr %t431, null
  %t435 = xor i1 %t433, true
  br i1 %t435, label %bb111, label %bb112
bb111:
  %t437 = load ptr, ptr %l0, !tbaa !29
  store ptr %t437, ptr %l245, !tbaa !29
  %t438 = load ptr, ptr %l27, !tbaa !29
  %t440 = getelementptr %"compiler/typed:Match", ptr %t438, i32 0, i32 2
  %t441 = load ptr, ptr %t440, !tbaa !29
  %t443 = icmp eq ptr %t441, null
  br i1 %t443, label %bb113, label %bb114
bb112:
  br label %bb117
bb113:
  call void @__olang_check_failed(ptr @olang_loc_dba8079c89f8629e_846fd2cd4d9758c2)
  unreachable
bb114:
  br label %bb115
bb115:
  %t445 = load ptr, ptr %l27, !tbaa !29
  %t447 = getelementptr %"compiler/typed:Match", ptr %t445, i32 0, i32 2
  %t448 = load ptr, ptr %t447, !tbaa !29
  %t451 = getelementptr %"compiler/typed:Arm", ptr %t448, i32 0, i32 3
  %t452 = load ptr, ptr %t451, !tbaa !29
  %t453 = load i64, ptr %l2, !tbaa !24
  %t454 = load ptr, ptr %l245, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlBlock(ptr %v0, ptr %v1, ptr %t454, ptr %t452, i64 %t453)
  br label %bb116
bb116:
  br label %bb117
bb117:
  br label %bb168
bb118:
  %t457 = load ptr, ptr %l1, !tbaa !29
  store ptr %t457, ptr %l254, !tbaa !29
  store i1 false, ptr %l255, !tbaa !21
  %t458 = load ptr, ptr %l254, !tbaa !29
  %t459 = icmp ne ptr %t458, null
  br i1 %t459, label %bb119, label %bb120
bb119:
  %t461 = load ptr, ptr %l254, !tbaa !29
  %t462 = load i64, ptr %t461, !range !{i64 0, i64 18}
  %t464 = icmp eq i64 %t462, 14
  store i1 %t464, ptr %l255, !tbaa !21
  br label %bb120
bb120:
  %t465 = load i1, ptr %l255, !tbaa !21
  br i1 %t465, label %bb121, label %bb122
bb121:
  %t466 = load ptr, ptr %l1, !tbaa !29
  %t468 = getelementptr { i64, [5 x i64] }, ptr %t466, i32 0, i32 1
  %t469 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t468, i32 0, i32 2
  %t470 = load ptr, ptr %t469
  store ptr %t470, ptr %l36, !tbaa !29
  br label %bb123
bb122:
  br label %bb132
bb123:
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t473 = load ptr, ptr %l36, !tbaa !29
  %t475 = getelementptr %"compiler/typed:Try", ptr %t473, i32 0, i32 0
  %t476 = load ptr, ptr %t475, !tbaa !29
  %t477 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlExpr(ptr %v0, ptr %v1, ptr %t472, ptr %t476, i64 %t477)
  br label %bb124
bb124:
  %t481 = load ptr, ptr %l36, !tbaa !29
  %t483 = getelementptr %"compiler/typed:Try", ptr %t481, i32 0, i32 1
  %t484 = load { i64, ptr }, ptr %t483, !tbaa !27
  store { i64, ptr } %t484, ptr %l37, !tbaa !27
  store i64 0, ptr %l38, !tbaa !24
  %t486 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t488 = extractvalue { i64, ptr } %t486, 0
  store i64 %t488, ptr %l39, !tbaa !24
  br label %bb125
bb125:
  %t490 = load i64, ptr %l38, !tbaa !24
  %t491 = load i64, ptr %l39, !tbaa !24
  %t494 = icmp slt i64 %t490, %t491
  %t496 = xor i1 %t494, true
  br i1 %t496, label %bb126, label %bb127
bb126:
  br label %bb131
bb127:
  br label %bb128
bb128:
  %t498 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t498, ptr %l272, !tbaa !27
  %t499 = load i64, ptr %l38, !tbaa !24
  %t501 = getelementptr { i64, ptr }, ptr %l272, i32 0, i32 1
  %t502 = load ptr, ptr %t501, !tbaa !27
  %t503 = getelementptr ptr, ptr %t502, i64 %t499
  %t504 = load ptr, ptr %t503, !tbaa !39
  %t506 = load ptr, ptr %l0, !tbaa !29
  %t509 = getelementptr %"compiler/typed:Clause", ptr %t504, i32 0, i32 3
  %t510 = load ptr, ptr %t509, !tbaa !29
  %t511 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlBlock(ptr %v0, ptr %v1, ptr %t506, ptr %t510, i64 %t511)
  br label %bb129
bb129:
  br label %bb130
bb130:
  %t515 = load i64, ptr %l38, !tbaa !24
  %t517 = add i64 %t515, 1
  store i64 %t517, ptr %l38, !tbaa !24
  br label %bb125
bb131:
  br label %bb168
bb132:
  %t519 = load ptr, ptr %l1, !tbaa !29
  store ptr %t519, ptr %l281, !tbaa !29
  store i1 false, ptr %l282, !tbaa !21
  %t520 = load ptr, ptr %l281, !tbaa !29
  %t521 = icmp ne ptr %t520, null
  br i1 %t521, label %bb133, label %bb134
bb133:
  %t523 = load ptr, ptr %l281, !tbaa !29
  %t524 = load i64, ptr %t523, !range !{i64 0, i64 18}
  %t526 = icmp eq i64 %t524, 15
  store i1 %t526, ptr %l282, !tbaa !21
  br label %bb134
bb134:
  %t527 = load i1, ptr %l282, !tbaa !21
  br i1 %t527, label %bb135, label %bb136
bb135:
  %t528 = load ptr, ptr %l1, !tbaa !29
  %t530 = getelementptr { i64, [5 x i64] }, ptr %t528, i32 0, i32 1
  %t531 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t530, i32 0, i32 2
  %t532 = load ptr, ptr %t531
  store ptr %t532, ptr %l41, !tbaa !29
  br label %bb137
bb136:
  br label %bb156
bb137:
  %t534 = load ptr, ptr %l41, !tbaa !29
  store ptr %t534, ptr %l287, !tbaa !29
  store i1 false, ptr %l288, !tbaa !21
  %t535 = load ptr, ptr %l287, !tbaa !29
  %t536 = icmp ne ptr %t535, null
  br i1 %t536, label %bb138, label %bb139
bb138:
  %t538 = load ptr, ptr %l287, !tbaa !29
  %t539 = load i64, ptr %t538, !range !{i64 0, i64 3}
  %t541 = icmp eq i64 %t539, 1
  store i1 %t541, ptr %l288, !tbaa !21
  br label %bb139
bb139:
  %t542 = load i1, ptr %l288, !tbaa !21
  br i1 %t542, label %bb140, label %bb141
bb140:
  %t543 = load ptr, ptr %l41, !tbaa !29
  %t545 = getelementptr { i64, [4 x i64] }, ptr %t543, i32 0, i32 1
  %t546 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t545, i32 0, i32 1
  %t547 = load { i64, ptr }, ptr %t546
  store { i64, ptr } %t547, ptr %l42, !tbaa !27
  br label %bb142
bb141:
  br label %bb150
bb142:
  %t549 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t549, ptr %l43, !tbaa !27
  store i64 0, ptr %l44, !tbaa !24
  %t551 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t553 = extractvalue { i64, ptr } %t551, 0
  store i64 %t553, ptr %l45, !tbaa !24
  br label %bb143
bb143:
  %t555 = load i64, ptr %l44, !tbaa !24
  %t556 = load i64, ptr %l45, !tbaa !24
  %t559 = icmp slt i64 %t555, %t556
  %t561 = xor i1 %t559, true
  br i1 %t561, label %bb144, label %bb145
bb144:
  br label %bb149
bb145:
  br label %bb146
bb146:
  %t563 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t563, ptr %l300, !tbaa !27
  %t564 = load i64, ptr %l44, !tbaa !24
  %t566 = getelementptr { i64, ptr }, ptr %l300, i32 0, i32 1
  %t567 = load ptr, ptr %t566, !tbaa !27
  %t568 = getelementptr ptr, ptr %t567, i64 %t564
  %t569 = load ptr, ptr %t568, !tbaa !39
  %t571 = load ptr, ptr %l0, !tbaa !29
  %t574 = getelementptr %"compiler/typed:Capture", ptr %t569, i32 0, i32 1
  %t575 = load ptr, ptr %t574, !tbaa !29
  %t577 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlExpr(ptr %v0, ptr %v1, ptr %t571, ptr %t575, i64 %t577)
  br label %bb147
bb147:
  br label %bb148
bb148:
  %t581 = load i64, ptr %l44, !tbaa !24
  %t583 = add i64 %t581, 1
  store i64 %t583, ptr %l44, !tbaa !24
  br label %bb143
bb149:
  br label %bb155
bb150:
  br i1 true, label %bb151, label %bb152
bb151:
  br label %bb153
bb152:
  br label %bb154
bb153:
  br label %bb155
bb154:
  call void @__olang_check_failed(ptr @olang_loc_dbab6e035b5797c_e736089fb75e21e0)
  unreachable
bb155:
  br label %bb168
bb156:
  %t585 = load ptr, ptr %l1, !tbaa !29
  store ptr %t585, ptr %l310, !tbaa !29
  store i1 false, ptr %l311, !tbaa !21
  %t586 = load ptr, ptr %l310, !tbaa !29
  %t587 = icmp ne ptr %t586, null
  br i1 %t587, label %bb157, label %bb158
bb157:
  %t589 = load ptr, ptr %l310, !tbaa !29
  %t590 = load i64, ptr %t589, !range !{i64 0, i64 18}
  %t592 = icmp eq i64 %t590, 17
  store i1 %t592, ptr %l311, !tbaa !21
  br label %bb158
bb158:
  %t593 = load i1, ptr %l311, !tbaa !21
  br i1 %t593, label %bb159, label %bb160
bb159:
  %t594 = load ptr, ptr %l1, !tbaa !29
  %t596 = getelementptr { i64, [5 x i64] }, ptr %t594, i32 0, i32 1
  %t597 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t596, i32 0, i32 2
  %t598 = load ptr, ptr %t597
  store ptr %t598, ptr %l47, !tbaa !29
  br label %bb161
bb160:
  br label %bb163
bb161:
  %t600 = load ptr, ptr %l0, !tbaa !29
  %t601 = load ptr, ptr %l47, !tbaa !29
  %t603 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlExpr(ptr %v0, ptr %v1, ptr %t600, ptr %t601, i64 %t603)
  br label %bb162
bb162:
  br label %bb168
bb163:
  br i1 true, label %bb164, label %bb165
bb164:
  br label %bb166
bb165:
  br label %bb167
bb166:
  br label %bb168
bb167:
  call void @__olang_check_failed(ptr @olang_loc_207e75e919c85f37_93e6eeba566436db)
  unreachable
bb168:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erunLength(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l6 = alloca i32
  %l9 = alloca i1
  %l14 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l6
  br label %bb1
bb1:
  %t11 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t13 = trunc i64 19 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/scope:Scoper", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l1, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l14
  br label %bb4
bb3:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb5
bb4:
  %t26 = load i32, ptr %l14, !tbaa !23
  %t27 = icmp eq i32 %t26, 0
  store i1 %t27, ptr %l9, !tbaa !21
  br label %bb5
bb5:
  %t29 = load i1, ptr %l9, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca i64
  %l44 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca i64
  %l53 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i64
  %l59 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca { i64, ptr }
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca ptr
  %l65 = alloca ptr
  %l66 = alloca ptr
  %l69 = alloca i1
  %l72 = alloca ptr
  %l73 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca i1
  %l80 = alloca ptr
  %l81 = alloca i1
  %l87 = alloca i1
  %l90 = alloca i1
  %l95 = alloca ptr
  %l96 = alloca i1
  %l101 = alloca ptr
  %l102 = alloca i1
  %l109 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca i1
  %l123 = alloca i1
  %l139 = alloca ptr
  %l140 = alloca i1
  %l150 = alloca ptr
  %l151 = alloca i1
  %l158 = alloca ptr
  %l159 = alloca i1
  %l174 = alloca i64
  %l177 = alloca i64
  %l196 = alloca { i64, ptr }
  %l201 = alloca i1
  %l204 = alloca i1
  %l208 = alloca i1
  %l216 = alloca ptr
  %l217 = alloca i1
  %l234 = alloca { i64, ptr }
  %l243 = alloca ptr
  %l244 = alloca i1
  %l262 = alloca ptr
  %l263 = alloca i1
  %l277 = alloca { i64, ptr }
  %l282 = alloca i1
  %l284 = alloca i1
  %l286 = alloca i1
  %l289 = alloca i1
  %l296 = alloca ptr
  %l297 = alloca i1
  %l316 = alloca ptr
  %l317 = alloca i1
  %l330 = alloca { i64, ptr }
  %l346 = alloca ptr
  %l347 = alloca i1
  %l360 = alloca { i64, ptr }
  %l380 = alloca { i64, ptr }
  %l393 = alloca ptr
  %l394 = alloca i1
  %l411 = alloca { i64, ptr }
  %l429 = alloca { i64, ptr }
  %l440 = alloca ptr
  %l441 = alloca i1
  %l446 = alloca ptr
  %l447 = alloca i1
  %l459 = alloca { i64, ptr }
  %l468 = alloca ptr
  %l469 = alloca i1
  %l477 = alloca ptr
  %l478 = alloca i1
  %l491 = alloca { i64, ptr }
  %l494 = alloca ptr
  %l495 = alloca i1
  %l501 = alloca i1
  %l504 = alloca i1
  %l512 = alloca ptr
  %l513 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l69, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/scope:Scoper", ptr %t5, i32 0, i32 115
  %t8 = load i1, ptr %t7, !tbaa !21
  store i1 %t8, ptr %l69, !tbaa !21
  br label %bb3
bb3:
  %t10 = load i1, ptr %l69, !tbaa !21
  br i1 %t10, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t12 = load ptr, ptr %l72, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb7, label %bb8
bb7:
  %t15 = load ptr, ptr %l72, !tbaa !29
  %t16 = load i64, ptr %t15, !range !{i64 0, i64 18}
  %t18 = icmp eq i64 %t16, 0
  store i1 %t18, ptr %l73, !tbaa !21
  br label %bb8
bb8:
  %t19 = load i1, ptr %l73, !tbaa !21
  br i1 %t19, label %bb9, label %bb10
bb9:
  br label %bb15
bb10:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l76, !tbaa !29
  store i1 false, ptr %l77, !tbaa !21
  %t21 = load ptr, ptr %l76, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb11, label %bb12
bb11:
  %t24 = load ptr, ptr %l76, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 18}
  %t27 = icmp eq i64 %t25, 1
  store i1 %t27, ptr %l77, !tbaa !21
  br label %bb12
bb12:
  %t28 = load i1, ptr %l77, !tbaa !21
  br i1 %t28, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb308
bb16:
  %t29 = load ptr, ptr %l1, !tbaa !29
  store ptr %t29, ptr %l80, !tbaa !29
  store i1 false, ptr %l81, !tbaa !21
  %t30 = load ptr, ptr %l80, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb17, label %bb18
bb17:
  %t33 = load ptr, ptr %l80, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 18}
  %t36 = icmp eq i64 %t34, 2
  store i1 %t36, ptr %l81, !tbaa !21
  br label %bb18
bb18:
  %t37 = load i1, ptr %l81, !tbaa !21
  br i1 %t37, label %bb19, label %bb20
bb19:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr { i64, [5 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l3, !tbaa !29
  br label %bb21
bb20:
  br label %bb30
bb21:
  %t44 = load i1, ptr %l2, !tbaa !21
  br i1 %t44, label %bb22, label %bb23
bb22:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load ptr, ptr %l3, !tbaa !29
  %t50 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleRooted(ptr %v0, ptr %v1, ptr %t46, ptr %t47)
  store i1 %t50, ptr %l90
  br label %bb24
bb23:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb25
bb24:
  %t51 = load i1, ptr %l90, !tbaa !21
  store i1 %t51, ptr %l87, !tbaa !21
  br label %bb25
bb25:
  %t52 = load i1, ptr %l87, !tbaa !21
  br i1 %t52, label %bb26, label %bb27
bb26:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/scope:Scoper", ptr %t53, i32 0, i32 115
  store i1 true, ptr %t55, !tbaa !21
  br label %ret
bb27:
  br label %bb28
bb28:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load ptr, ptr %l3, !tbaa !29
  %t58 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esolePlace(ptr %v0, ptr %v1, ptr %t56, ptr %t57, i1 %t58)
  br label %bb29
bb29:
  br label %bb308
bb30:
  %t62 = load ptr, ptr %l1, !tbaa !29
  store ptr %t62, ptr %l95, !tbaa !29
  store i1 false, ptr %l96, !tbaa !21
  %t63 = load ptr, ptr %l95, !tbaa !29
  %t64 = icmp ne ptr %t63, null
  br i1 %t64, label %bb31, label %bb32
bb31:
  %t66 = load ptr, ptr %l95, !tbaa !29
  %t67 = load i64, ptr %t66, !range !{i64 0, i64 18}
  %t69 = icmp eq i64 %t67, 3
  store i1 %t69, ptr %l96, !tbaa !21
  br label %bb32
bb32:
  %t70 = load i1, ptr %l96, !tbaa !21
  br i1 %t70, label %bb33, label %bb34
bb33:
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr { i64, [5 x i64] }, ptr %t71, i32 0, i32 1
  %t74 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t73, i32 0, i32 2
  %t75 = load ptr, ptr %t74
  store ptr %t75, ptr %l4, !tbaa !29
  br label %bb39
bb34:
  %t77 = load ptr, ptr %l1, !tbaa !29
  store ptr %t77, ptr %l101, !tbaa !29
  store i1 false, ptr %l102, !tbaa !21
  %t78 = load ptr, ptr %l101, !tbaa !29
  %t79 = icmp ne ptr %t78, null
  br i1 %t79, label %bb35, label %bb36
bb35:
  %t81 = load ptr, ptr %l101, !tbaa !29
  %t82 = load i64, ptr %t81, !range !{i64 0, i64 18}
  %t84 = icmp eq i64 %t82, 4
  store i1 %t84, ptr %l102, !tbaa !21
  br label %bb36
bb36:
  %t85 = load i1, ptr %l102, !tbaa !21
  br i1 %t85, label %bb37, label %bb38
bb37:
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t88 = getelementptr { i64, [5 x i64] }, ptr %t86, i32 0, i32 1
  %t89 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t88, i32 0, i32 2
  %t90 = load ptr, ptr %t89
  store ptr %t90, ptr %l4, !tbaa !29
  br label %bb39
bb38:
  br label %bb45
bb39:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %l4, !tbaa !29
  %t96 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleRooted(ptr %v0, ptr %v1, ptr %t92, ptr %t93)
  store i1 %t96, ptr %l109
  br label %bb40
bb40:
  %t97 = load i1, ptr %l109, !tbaa !21
  br i1 %t97, label %bb41, label %bb42
bb41:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/scope:Scoper", ptr %t98, i32 0, i32 115
  store i1 true, ptr %t100, !tbaa !21
  br label %ret
bb42:
  br label %bb43
bb43:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load ptr, ptr %l4, !tbaa !29
  %t103 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esolePlace(ptr %v0, ptr %v1, ptr %t101, ptr %t102, i1 %t103)
  br label %bb44
bb44:
  br label %bb308
bb45:
  %t107 = load ptr, ptr %l1, !tbaa !29
  store ptr %t107, ptr %l114, !tbaa !29
  store i1 false, ptr %l115, !tbaa !21
  %t108 = load ptr, ptr %l114, !tbaa !29
  %t109 = icmp ne ptr %t108, null
  br i1 %t109, label %bb46, label %bb47
bb46:
  %t111 = load ptr, ptr %l114, !tbaa !29
  %t112 = load i64, ptr %t111, !range !{i64 0, i64 18}
  %t114 = icmp eq i64 %t112, 10
  store i1 %t114, ptr %l115, !tbaa !21
  br label %bb47
bb47:
  %t115 = load i1, ptr %l115, !tbaa !21
  br i1 %t115, label %bb48, label %bb49
bb48:
  %t116 = load ptr, ptr %l1, !tbaa !29
  %t118 = getelementptr { i64, [5 x i64] }, ptr %t116, i32 0, i32 1
  %t119 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t118, i32 0, i32 2
  %t120 = load ptr, ptr %t119
  store ptr %t120, ptr %l5, !tbaa !29
  br label %bb50
bb49:
  br label %bb58
bb50:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load ptr, ptr %l5, !tbaa !29
  %t125 = getelementptr %"compiler/typed:Slice", ptr %t123, i32 0, i32 0
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t129 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleRooted(ptr %v0, ptr %v1, ptr %t122, ptr %t126)
  store i1 %t129, ptr %l123
  br label %bb51
bb51:
  %t130 = load i1, ptr %l123, !tbaa !21
  br i1 %t130, label %bb52, label %bb53
bb52:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/scope:Scoper", ptr %t131, i32 0, i32 115
  store i1 true, ptr %t133, !tbaa !21
  br label %ret
bb53:
  br label %bb54
bb54:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load ptr, ptr %l5, !tbaa !29
  %t137 = getelementptr %"compiler/typed:Slice", ptr %t135, i32 0, i32 0
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t139 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esolePlace(ptr %v0, ptr %v1, ptr %t134, ptr %t138, i1 %t139)
  br label %bb55
bb55:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load ptr, ptr %l5, !tbaa !29
  %t146 = getelementptr %"compiler/typed:Slice", ptr %t144, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t149 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t143, ptr %t147, i1 %t149)
  br label %bb56
bb56:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load ptr, ptr %l5, !tbaa !29
  %t156 = getelementptr %"compiler/typed:Slice", ptr %t154, i32 0, i32 2
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t159 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t153, ptr %t157, i1 %t159)
  br label %bb57
bb57:
  br label %bb308
bb58:
  %t163 = load ptr, ptr %l1, !tbaa !29
  store ptr %t163, ptr %l139, !tbaa !29
  store i1 false, ptr %l140, !tbaa !21
  %t164 = load ptr, ptr %l139, !tbaa !29
  %t165 = icmp ne ptr %t164, null
  br i1 %t165, label %bb59, label %bb60
bb59:
  %t167 = load ptr, ptr %l139, !tbaa !29
  %t168 = load i64, ptr %t167, !range !{i64 0, i64 18}
  %t170 = icmp eq i64 %t168, 5
  store i1 %t170, ptr %l140, !tbaa !21
  br label %bb60
bb60:
  %t171 = load i1, ptr %l140, !tbaa !21
  br i1 %t171, label %bb61, label %bb62
bb61:
  %t172 = load ptr, ptr %l1, !tbaa !29
  %t174 = getelementptr { i64, [5 x i64] }, ptr %t172, i32 0, i32 1
  %t175 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t174, i32 0, i32 2
  %t176 = load ptr, ptr %t175
  store ptr %t176, ptr %l6, !tbaa !29
  br label %bb63
bb62:
  br label %bb65
bb63:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load ptr, ptr %l6, !tbaa !29
  %t181 = getelementptr %"compiler/typed:Promote", ptr %t179, i32 0, i32 0
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t184 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t178, ptr %t182, i1 %t184)
  br label %bb64
bb64:
  br label %bb308
bb65:
  %t188 = load ptr, ptr %l1, !tbaa !29
  store ptr %t188, ptr %l150, !tbaa !29
  store i1 false, ptr %l151, !tbaa !21
  %t189 = load ptr, ptr %l150, !tbaa !29
  %t190 = icmp ne ptr %t189, null
  br i1 %t190, label %bb66, label %bb67
bb66:
  %t192 = load ptr, ptr %l150, !tbaa !29
  %t193 = load i64, ptr %t192, !range !{i64 0, i64 18}
  %t195 = icmp eq i64 %t193, 6
  store i1 %t195, ptr %l151, !tbaa !21
  br label %bb67
bb67:
  %t196 = load i1, ptr %l151, !tbaa !21
  br i1 %t196, label %bb68, label %bb69
bb68:
  %t197 = load ptr, ptr %l1, !tbaa !29
  %t199 = getelementptr { i64, [5 x i64] }, ptr %t197, i32 0, i32 1
  %t200 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t199, i32 0, i32 2
  %t201 = load ptr, ptr %t200
  store ptr %t201, ptr %l7, !tbaa !29
  br label %bb70
bb69:
  br label %bb107
bb70:
  %t203 = load ptr, ptr %l7, !tbaa !29
  %t205 = getelementptr %"compiler/typed:Call", ptr %t203, i32 0, i32 0
  %t206 = load ptr, ptr %t205, !tbaa !29
  store ptr %t206, ptr %l8, !tbaa !29
  %t208 = load ptr, ptr %l8, !tbaa !29
  store ptr %t208, ptr %l158, !tbaa !29
  store i1 false, ptr %l159, !tbaa !21
  %t209 = load ptr, ptr %l158, !tbaa !29
  %t210 = icmp ne ptr %t209, null
  br i1 %t210, label %bb71, label %bb72
bb71:
  %t212 = load ptr, ptr %l158, !tbaa !29
  %t213 = load i64, ptr %t212, !range !{i64 0, i64 5}
  %t215 = icmp eq i64 %t213, 2
  store i1 %t215, ptr %l159, !tbaa !21
  br label %bb72
bb72:
  %t216 = load i1, ptr %l159, !tbaa !21
  br i1 %t216, label %bb73, label %bb74
bb73:
  %t217 = load ptr, ptr %l8, !tbaa !29
  %t219 = getelementptr { i64, [3 x i64] }, ptr %t217, i32 0, i32 1
  %t220 = getelementptr { ptr }, ptr %t219, i32 0, i32 0
  %t221 = load ptr, ptr %t220
  store ptr %t221, ptr %l9, !tbaa !29
  br label %bb75
bb74:
  br label %bb77
bb75:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t224 = load ptr, ptr %l9, !tbaa !29
  %t226 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t223, ptr %t224, i1 %t226)
  br label %bb76
bb76:
  br label %bb82
bb77:
  br i1 true, label %bb78, label %bb79
bb78:
  br label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb82
bb81:
  call void @__olang_check_failed(ptr @olang_loc_df5619edc5954020_95eed2e83037cdb4)
  unreachable
bb82:
  store i64 0, ptr %l10, !tbaa !24
  %t230 = load ptr, ptr %l7, !tbaa !29
  %t232 = getelementptr %"compiler/typed:Call", ptr %t230, i32 0, i32 1
  %t233 = load { i64, ptr }, ptr %t232, !tbaa !27
  %t235 = extractvalue { i64, ptr } %t233, 0
  store i64 %t235, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t237 = load i64, ptr %l11, !tbaa !24
  %t238 = load i64, ptr %l10, !tbaa !24
  %t241 = icmp sgt i64 %t237, %t238
  br i1 %t241, label %bb83, label %bb84
bb83:
  %t243 = load i64, ptr %l12, !tbaa !24
  %t245 = icmp sgt i64 %t243, 0
  br i1 %t245, label %bb85, label %bb86
bb84:
  store i64 0, ptr %l174, !tbaa !24
  br label %bb88
bb85:
  %t247 = load i64, ptr %l11, !tbaa !24
  %t248 = load i64, ptr %l10, !tbaa !24
  %t251 = sub i64 %t247, %t248
  %t252 = load i64, ptr %l12, !tbaa !24
  %t255 = add i64 %t251, %t252
  %t257 = sub i64 %t255, 1
  %t258 = load i64, ptr %l12, !tbaa !24
  %t261 = sdiv i64 %t257, %t258
  store i64 %t261, ptr %l177, !tbaa !24
  br label %bb87
bb86:
  store i64 0, ptr %l177, !tbaa !24
  br label %bb87
bb87:
  %t263 = load i64, ptr %l177, !tbaa !24
  store i64 %t263, ptr %l174, !tbaa !24
  br label %bb88
bb88:
  %t264 = load i64, ptr %l174, !tbaa !24
  store i64 %t264, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb89
bb89:
  %t265 = load i64, ptr %l14, !tbaa !24
  %t266 = load i64, ptr %l13, !tbaa !24
  %t269 = icmp slt i64 %t265, %t266
  %t271 = xor i1 %t269, true
  br i1 %t271, label %bb90, label %bb91
bb90:
  br label %bb106
bb91:
  br label %bb92
bb92:
  %t273 = load i64, ptr %l10, !tbaa !24
  %t274 = load i64, ptr %l14, !tbaa !24
  %t275 = load i64, ptr %l12, !tbaa !24
  %t278 = mul i64 %t274, %t275
  %t281 = add i64 %t273, %t278
  store i64 %t281, ptr %l15, !tbaa !24
  %t283 = load ptr, ptr %l7, !tbaa !29
  %t285 = getelementptr %"compiler/typed:Call", ptr %t283, i32 0, i32 1
  %t286 = load { i64, ptr }, ptr %t285, !tbaa !27
  store { i64, ptr } %t286, ptr %l196, !tbaa !27
  %t287 = load i64, ptr %l15, !tbaa !24
  %t289 = getelementptr { i64, ptr }, ptr %l196, i32 0, i32 1
  %t290 = load ptr, ptr %t289, !tbaa !27
  %t291 = getelementptr ptr, ptr %t290, i64 %t287
  %t292 = load ptr, ptr %t291, !tbaa !39
  store ptr %t292, ptr %l16, !tbaa !29
  %t294 = load i1, ptr %l2, !tbaa !21
  %t296 = xor i1 %t294, true
  br i1 %t296, label %bb93, label %bb94
bb93:
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t299 = load ptr, ptr %l16, !tbaa !29
  %t302 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleBorrow(ptr %v0, ptr %v1, ptr %t298, ptr %t299)
  store i1 %t302, ptr %l204
  br label %bb95
bb94:
  store i1 false, ptr %l201, !tbaa !21
  br label %bb96
bb95:
  %t303 = load i1, ptr %l204, !tbaa !21
  store i1 %t303, ptr %l201, !tbaa !21
  br label %bb96
bb96:
  %t304 = load i1, ptr %l201, !tbaa !21
  br i1 %t304, label %bb97, label %bb98
bb97:
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t306 = load ptr, ptr %l7, !tbaa !29
  %t307 = load i64, ptr %l15, !tbaa !24
  %t311 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecanKeep(ptr %v0, ptr %v1, ptr %t305, ptr %t306, i64 %t307)
  store i1 %t311, ptr %l208
  br label %bb99
bb98:
  br label %bb103
bb99:
  %t312 = load i1, ptr %l208, !tbaa !21
  br i1 %t312, label %bb100, label %bb101
bb100:
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t315 = getelementptr %"compiler/scope:Scoper", ptr %t313, i32 0, i32 115
  store i1 true, ptr %t315, !tbaa !21
  br label %bb102
bb101:
  br label %bb102
bb102:
  br label %bb105
bb103:
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t317 = load ptr, ptr %l16, !tbaa !29
  %t319 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t316, ptr %t317, i1 %t319)
  br label %bb104
bb104:
  br label %bb105
bb105:
  %t323 = load i64, ptr %l14, !tbaa !24
  %t325 = add i64 %t323, 1
  store i64 %t325, ptr %l14, !tbaa !24
  br label %bb89
bb106:
  br label %bb308
bb107:
  %t327 = load ptr, ptr %l1, !tbaa !29
  store ptr %t327, ptr %l216, !tbaa !29
  store i1 false, ptr %l217, !tbaa !21
  %t328 = load ptr, ptr %l216, !tbaa !29
  %t329 = icmp ne ptr %t328, null
  br i1 %t329, label %bb108, label %bb109
bb108:
  %t331 = load ptr, ptr %l216, !tbaa !29
  %t332 = load i64, ptr %t331, !range !{i64 0, i64 18}
  %t334 = icmp eq i64 %t332, 7
  store i1 %t334, ptr %l217, !tbaa !21
  br label %bb109
bb109:
  %t335 = load i1, ptr %l217, !tbaa !21
  br i1 %t335, label %bb110, label %bb111
bb110:
  %t336 = load ptr, ptr %l1, !tbaa !29
  %t338 = getelementptr { i64, [5 x i64] }, ptr %t336, i32 0, i32 1
  %t339 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t338, i32 0, i32 2
  %t340 = load ptr, ptr %t339
  store ptr %t340, ptr %l17, !tbaa !29
  br label %bb112
bb111:
  br label %bb121
bb112:
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t343 = load ptr, ptr %l17, !tbaa !29
  %t345 = getelementptr %"compiler/typed:Make", ptr %t343, i32 0, i32 3
  %t346 = load ptr, ptr %t345, !tbaa !29
  %t347 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t342, ptr %t346, i1 %t347)
  br label %bb113
bb113:
  %t351 = load ptr, ptr %l17, !tbaa !29
  %t353 = getelementptr %"compiler/typed:Make", ptr %t351, i32 0, i32 2
  %t354 = load { i64, ptr }, ptr %t353, !tbaa !27
  store { i64, ptr } %t354, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t356 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t358 = extractvalue { i64, ptr } %t356, 0
  store i64 %t358, ptr %l20, !tbaa !24
  br label %bb114
bb114:
  %t360 = load i64, ptr %l19, !tbaa !24
  %t361 = load i64, ptr %l20, !tbaa !24
  %t364 = icmp slt i64 %t360, %t361
  %t366 = xor i1 %t364, true
  br i1 %t366, label %bb115, label %bb116
bb115:
  br label %bb120
bb116:
  br label %bb117
bb117:
  %t368 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t368, ptr %l234, !tbaa !27
  %t369 = load i64, ptr %l19, !tbaa !24
  %t371 = getelementptr { i64, ptr }, ptr %l234, i32 0, i32 1
  %t372 = load ptr, ptr %t371, !tbaa !27
  %t373 = getelementptr ptr, ptr %t372, i64 %t369
  %t374 = load ptr, ptr %t373, !tbaa !39
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t379 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t376, ptr %t374, i1 %t379)
  br label %bb118
bb118:
  br label %bb119
bb119:
  %t383 = load i64, ptr %l19, !tbaa !24
  %t385 = add i64 %t383, 1
  store i64 %t385, ptr %l19, !tbaa !24
  br label %bb114
bb120:
  br label %bb308
bb121:
  %t387 = load ptr, ptr %l1, !tbaa !29
  store ptr %t387, ptr %l243, !tbaa !29
  store i1 false, ptr %l244, !tbaa !21
  %t388 = load ptr, ptr %l243, !tbaa !29
  %t389 = icmp ne ptr %t388, null
  br i1 %t389, label %bb122, label %bb123
bb122:
  %t391 = load ptr, ptr %l243, !tbaa !29
  %t392 = load i64, ptr %t391, !range !{i64 0, i64 18}
  %t394 = icmp eq i64 %t392, 8
  store i1 %t394, ptr %l244, !tbaa !21
  br label %bb123
bb123:
  %t395 = load i1, ptr %l244, !tbaa !21
  br i1 %t395, label %bb124, label %bb125
bb124:
  %t396 = load ptr, ptr %l1, !tbaa !29
  %t398 = getelementptr { i64, [5 x i64] }, ptr %t396, i32 0, i32 1
  %t399 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t398, i32 0, i32 2
  %t400 = load ptr, ptr %t399
  store ptr %t400, ptr %l22, !tbaa !29
  br label %bb126
bb125:
  br label %bb133
bb126:
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t403 = load ptr, ptr %l22, !tbaa !29
  %t405 = getelementptr %"compiler/typed:Collect", ptr %t403, i32 0, i32 0
  %t406 = load ptr, ptr %t405, !tbaa !29
  %t407 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t402, ptr %t406, i1 %t407)
  br label %bb127
bb127:
  %t411 = load i1, ptr %l2, !tbaa !21
  br i1 %t411, label %bb128, label %bb129
bb128:
  %t413 = load ptr, ptr %l0, !tbaa !29
  %t414 = load ptr, ptr %l22, !tbaa !29
  %t416 = getelementptr %"compiler/typed:Collect", ptr %t414, i32 0, i32 1
  %t417 = load ptr, ptr %t416, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleStrictBlock(ptr %v0, ptr %v1, ptr %t413, ptr %t417)
  br label %bb130
bb129:
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t422 = load ptr, ptr %l22, !tbaa !29
  %t424 = getelementptr %"compiler/typed:Collect", ptr %t422, i32 0, i32 1
  %t425 = load ptr, ptr %t424, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleBlock(ptr %v0, ptr %v1, ptr %t421, ptr %t425)
  br label %bb131
bb130:
  br label %bb132
bb131:
  br label %bb132
bb132:
  br label %bb308
bb133:
  %t429 = load ptr, ptr %l1, !tbaa !29
  store ptr %t429, ptr %l262, !tbaa !29
  store i1 false, ptr %l263, !tbaa !21
  %t430 = load ptr, ptr %l262, !tbaa !29
  %t431 = icmp ne ptr %t430, null
  br i1 %t431, label %bb134, label %bb135
bb134:
  %t433 = load ptr, ptr %l262, !tbaa !29
  %t434 = load i64, ptr %t433, !range !{i64 0, i64 18}
  %t436 = icmp eq i64 %t434, 9
  store i1 %t436, ptr %l263, !tbaa !21
  br label %bb135
bb135:
  %t437 = load i1, ptr %l263, !tbaa !21
  br i1 %t437, label %bb136, label %bb137
bb136:
  %t438 = load ptr, ptr %l1, !tbaa !29
  %t440 = getelementptr { i64, [5 x i64] }, ptr %t438, i32 0, i32 1
  %t441 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t440, i32 0, i32 2
  %t442 = load i32, ptr %t441, !range !{i32 0, i32 43}
  store i32 %t442, ptr %l23
  %t444 = load ptr, ptr %l1, !tbaa !29
  %t446 = getelementptr { i64, [5 x i64] }, ptr %t444, i32 0, i32 1
  %t447 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t446, i32 0, i32 4
  %t448 = load { i64, ptr }, ptr %t447
  store { i64, ptr } %t448, ptr %l24, !tbaa !27
  br label %bb138
bb137:
  br label %bb157
bb138:
  %t450 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t450, ptr %l25, !tbaa !27
  store i64 0, ptr %l26, !tbaa !24
  %t452 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t454 = extractvalue { i64, ptr } %t452, 0
  store i64 %t454, ptr %l27, !tbaa !24
  br label %bb139
bb139:
  %t456 = load i64, ptr %l26, !tbaa !24
  %t457 = load i64, ptr %l27, !tbaa !24
  %t460 = icmp slt i64 %t456, %t457
  %t462 = xor i1 %t460, true
  br i1 %t462, label %bb140, label %bb141
bb140:
  br label %bb156
bb141:
  br label %bb142
bb142:
  %t464 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t464, ptr %l277, !tbaa !27
  %t465 = load i64, ptr %l26, !tbaa !24
  %t467 = getelementptr { i64, ptr }, ptr %l277, i32 0, i32 1
  %t468 = load ptr, ptr %t467, !tbaa !27
  %t469 = getelementptr ptr, ptr %t468, i64 %t465
  %t470 = load ptr, ptr %t469, !tbaa !39
  store ptr %t470, ptr %l28, !tbaa !29
  %t472 = load i1, ptr %l2, !tbaa !21
  %t474 = xor i1 %t472, true
  br i1 %t474, label %bb143, label %bb144
bb143:
  %t476 = load i32, ptr %l23, !range !{i32 0, i32 43}
  %t478 = call i1 @compiler_2ftyped_2ePassesRefs(i32 %t476)
  store i1 %t478, ptr %l284
  br label %bb145
bb144:
  store i1 false, ptr %l282, !tbaa !21
  br label %bb146
bb145:
  %t479 = load i1, ptr %l284, !tbaa !21
  %t480 = xor i1 %t479, true
  store i1 %t480, ptr %l282, !tbaa !21
  br label %bb146
bb146:
  %t482 = load i1, ptr %l282, !tbaa !21
  br i1 %t482, label %bb147, label %bb148
bb147:
  %t483 = load ptr, ptr %l0, !tbaa !29
  %t484 = load ptr, ptr %l28, !tbaa !29
  %t487 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleBorrow(ptr %v0, ptr %v1, ptr %t483, ptr %t484)
  store i1 %t487, ptr %l289
  br label %bb149
bb148:
  store i1 false, ptr %l286, !tbaa !21
  br label %bb150
bb149:
  %t488 = load i1, ptr %l289, !tbaa !21
  store i1 %t488, ptr %l286, !tbaa !21
  br label %bb150
bb150:
  %t489 = load i1, ptr %l286, !tbaa !21
  br i1 %t489, label %bb151, label %bb152
bb151:
  br label %bb155
bb152:
  br label %bb153
bb153:
  %t490 = load ptr, ptr %l0, !tbaa !29
  %t491 = load ptr, ptr %l28, !tbaa !29
  %t493 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t490, ptr %t491, i1 %t493)
  br label %bb154
bb154:
  br label %bb155
bb155:
  %t497 = load i64, ptr %l26, !tbaa !24
  %t499 = add i64 %t497, 1
  store i64 %t499, ptr %l26, !tbaa !24
  br label %bb139
bb156:
  br label %bb308
bb157:
  %t501 = load ptr, ptr %l1, !tbaa !29
  store ptr %t501, ptr %l296, !tbaa !29
  store i1 false, ptr %l297, !tbaa !21
  %t502 = load ptr, ptr %l296, !tbaa !29
  %t503 = icmp ne ptr %t502, null
  br i1 %t503, label %bb158, label %bb159
bb158:
  %t505 = load ptr, ptr %l296, !tbaa !29
  %t506 = load i64, ptr %t505, !range !{i64 0, i64 18}
  %t508 = icmp eq i64 %t506, 11
  store i1 %t508, ptr %l297, !tbaa !21
  br label %bb159
bb159:
  %t509 = load i1, ptr %l297, !tbaa !21
  br i1 %t509, label %bb160, label %bb161
bb160:
  %t510 = load ptr, ptr %l1, !tbaa !29
  %t512 = getelementptr { i64, [5 x i64] }, ptr %t510, i32 0, i32 1
  %t513 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t512, i32 0, i32 2
  %t514 = load ptr, ptr %t513
  store ptr %t514, ptr %l29, !tbaa !29
  br label %bb162
bb161:
  br label %bb166
bb162:
  %t516 = load ptr, ptr %l0, !tbaa !29
  %t517 = load ptr, ptr %l29, !tbaa !29
  %t519 = getelementptr %"compiler/typed:Cond", ptr %t517, i32 0, i32 0
  %t520 = load ptr, ptr %t519, !tbaa !29
  %t522 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t516, ptr %t520, i1 %t522)
  br label %bb163
bb163:
  %t526 = load ptr, ptr %l0, !tbaa !29
  %t527 = load ptr, ptr %l29, !tbaa !29
  %t529 = getelementptr %"compiler/typed:Cond", ptr %t527, i32 0, i32 1
  %t530 = load ptr, ptr %t529, !tbaa !29
  %t531 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t526, ptr %t530, i1 %t531)
  br label %bb164
bb164:
  %t535 = load ptr, ptr %l0, !tbaa !29
  %t536 = load ptr, ptr %l29, !tbaa !29
  %t538 = getelementptr %"compiler/typed:Cond", ptr %t536, i32 0, i32 2
  %t539 = load ptr, ptr %t538, !tbaa !29
  %t541 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t535, ptr %t539, i1 %t541)
  br label %bb165
bb165:
  br label %bb308
bb166:
  %t545 = load ptr, ptr %l1, !tbaa !29
  store ptr %t545, ptr %l316, !tbaa !29
  store i1 false, ptr %l317, !tbaa !21
  %t546 = load ptr, ptr %l316, !tbaa !29
  %t547 = icmp ne ptr %t546, null
  br i1 %t547, label %bb167, label %bb168
bb167:
  %t549 = load ptr, ptr %l316, !tbaa !29
  %t550 = load i64, ptr %t549, !range !{i64 0, i64 18}
  %t552 = icmp eq i64 %t550, 12
  store i1 %t552, ptr %l317, !tbaa !21
  br label %bb168
bb168:
  %t553 = load i1, ptr %l317, !tbaa !21
  br i1 %t553, label %bb169, label %bb170
bb169:
  %t554 = load ptr, ptr %l1, !tbaa !29
  %t556 = getelementptr { i64, [5 x i64] }, ptr %t554, i32 0, i32 1
  %t557 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t556, i32 0, i32 2
  %t558 = load ptr, ptr %t557
  store ptr %t558, ptr %l30, !tbaa !29
  br label %bb171
bb170:
  br label %bb184
bb171:
  %t560 = load ptr, ptr %l30, !tbaa !29
  %t562 = getelementptr %"compiler/typed:Seq", ptr %t560, i32 0, i32 0
  %t563 = load { i64, ptr }, ptr %t562, !tbaa !27
  store { i64, ptr } %t563, ptr %l31, !tbaa !27
  store i64 0, ptr %l32, !tbaa !24
  %t565 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t567 = extractvalue { i64, ptr } %t565, 0
  store i64 %t567, ptr %l33, !tbaa !24
  br label %bb172
bb172:
  %t569 = load i64, ptr %l32, !tbaa !24
  %t570 = load i64, ptr %l33, !tbaa !24
  %t573 = icmp slt i64 %t569, %t570
  %t575 = xor i1 %t573, true
  br i1 %t575, label %bb173, label %bb174
bb173:
  br label %bb182
bb174:
  br label %bb175
bb175:
  %t577 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t577, ptr %l330, !tbaa !27
  %t578 = load i64, ptr %l32, !tbaa !24
  %t580 = getelementptr { i64, ptr }, ptr %l330, i32 0, i32 1
  %t581 = load ptr, ptr %t580, !tbaa !27
  %t582 = getelementptr ptr, ptr %t581, i64 %t578
  %t583 = load ptr, ptr %t582, !tbaa !39
  store ptr %t583, ptr %l34, !tbaa !29
  %t585 = load i1, ptr %l2, !tbaa !21
  br i1 %t585, label %bb176, label %bb177
bb176:
  %t587 = load ptr, ptr %l0, !tbaa !29
  %t588 = load ptr, ptr %l34, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleStrictStmt(ptr %v0, ptr %v1, ptr %t587, ptr %t588)
  br label %bb178
bb177:
  %t592 = load ptr, ptr %l0, !tbaa !29
  %t593 = load ptr, ptr %l34, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleStmt(ptr %v0, ptr %v1, ptr %t592, ptr %t593)
  br label %bb179
bb178:
  br label %bb180
bb179:
  br label %bb180
bb180:
  br label %bb181
bb181:
  %t597 = load i64, ptr %l32, !tbaa !24
  %t599 = add i64 %t597, 1
  store i64 %t599, ptr %l32, !tbaa !24
  br label %bb172
bb182:
  %t601 = load ptr, ptr %l0, !tbaa !29
  %t602 = load ptr, ptr %l30, !tbaa !29
  %t604 = getelementptr %"compiler/typed:Seq", ptr %t602, i32 0, i32 1
  %t605 = load ptr, ptr %t604, !tbaa !29
  %t606 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t601, ptr %t605, i1 %t606)
  br label %bb183
bb183:
  br label %bb308
bb184:
  %t610 = load ptr, ptr %l1, !tbaa !29
  store ptr %t610, ptr %l346, !tbaa !29
  store i1 false, ptr %l347, !tbaa !21
  %t611 = load ptr, ptr %l346, !tbaa !29
  %t612 = icmp ne ptr %t611, null
  br i1 %t612, label %bb185, label %bb186
bb185:
  %t614 = load ptr, ptr %l346, !tbaa !29
  %t615 = load i64, ptr %t614, !range !{i64 0, i64 18}
  %t617 = icmp eq i64 %t615, 13
  store i1 %t617, ptr %l347, !tbaa !21
  br label %bb186
bb186:
  %t618 = load i1, ptr %l347, !tbaa !21
  br i1 %t618, label %bb187, label %bb188
bb187:
  %t619 = load ptr, ptr %l1, !tbaa !29
  %t621 = getelementptr { i64, [5 x i64] }, ptr %t619, i32 0, i32 1
  %t622 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t621, i32 0, i32 2
  %t623 = load ptr, ptr %t622
  store ptr %t623, ptr %l35, !tbaa !29
  br label %bb189
bb188:
  br label %bb209
bb189:
  %t625 = load ptr, ptr %l35, !tbaa !29
  %t627 = getelementptr %"compiler/typed:Match", ptr %t625, i32 0, i32 0
  %t628 = load { i64, ptr }, ptr %t627, !tbaa !27
  store { i64, ptr } %t628, ptr %l36, !tbaa !27
  store i64 0, ptr %l37, !tbaa !24
  %t630 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t632 = extractvalue { i64, ptr } %t630, 0
  store i64 %t632, ptr %l38, !tbaa !24
  br label %bb190
bb190:
  %t634 = load i64, ptr %l37, !tbaa !24
  %t635 = load i64, ptr %l38, !tbaa !24
  %t638 = icmp slt i64 %t634, %t635
  %t640 = xor i1 %t638, true
  br i1 %t640, label %bb191, label %bb192
bb191:
  br label %bb200
bb192:
  br label %bb193
bb193:
  %t642 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t642, ptr %l360, !tbaa !27
  %t643 = load i64, ptr %l37, !tbaa !24
  %t645 = getelementptr { i64, ptr }, ptr %l360, i32 0, i32 1
  %t646 = load ptr, ptr %t645, !tbaa !27
  %t647 = getelementptr ptr, ptr %t646, i64 %t643
  %t648 = load ptr, ptr %t647, !tbaa !39
  store ptr %t648, ptr %l39, !tbaa !29
  %t650 = load i1, ptr %l2, !tbaa !21
  br i1 %t650, label %bb194, label %bb195
bb194:
  %t652 = load ptr, ptr %l0, !tbaa !29
  %t653 = load ptr, ptr %l39, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleStrictStmt(ptr %v0, ptr %v1, ptr %t652, ptr %t653)
  br label %bb196
bb195:
  %t657 = load ptr, ptr %l0, !tbaa !29
  %t658 = load ptr, ptr %l39, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleStmt(ptr %v0, ptr %v1, ptr %t657, ptr %t658)
  br label %bb197
bb196:
  br label %bb198
bb197:
  br label %bb198
bb198:
  br label %bb199
bb199:
  %t662 = load i64, ptr %l37, !tbaa !24
  %t664 = add i64 %t662, 1
  store i64 %t664, ptr %l37, !tbaa !24
  br label %bb190
bb200:
  %t666 = load ptr, ptr %l35, !tbaa !29
  %t668 = getelementptr %"compiler/typed:Match", ptr %t666, i32 0, i32 1
  %t669 = load { i64, ptr }, ptr %t668, !tbaa !27
  store { i64, ptr } %t669, ptr %l40, !tbaa !27
  store i64 0, ptr %l41, !tbaa !24
  %t671 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t673 = extractvalue { i64, ptr } %t671, 0
  store i64 %t673, ptr %l42, !tbaa !24
  br label %bb201
bb201:
  %t675 = load i64, ptr %l41, !tbaa !24
  %t676 = load i64, ptr %l42, !tbaa !24
  %t679 = icmp slt i64 %t675, %t676
  %t681 = xor i1 %t679, true
  br i1 %t681, label %bb202, label %bb203
bb202:
  br label %bb207
bb203:
  br label %bb204
bb204:
  %t683 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t683, ptr %l380, !tbaa !27
  %t684 = load i64, ptr %l41, !tbaa !24
  %t686 = getelementptr { i64, ptr }, ptr %l380, i32 0, i32 1
  %t687 = load ptr, ptr %t686, !tbaa !27
  %t688 = getelementptr ptr, ptr %t687, i64 %t684
  %t689 = load ptr, ptr %t688, !tbaa !39
  %t691 = load ptr, ptr %l0, !tbaa !29
  %t694 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleArm(ptr %v0, ptr %v1, ptr %t691, ptr %t689, i1 %t694)
  br label %bb205
bb205:
  br label %bb206
bb206:
  %t698 = load i64, ptr %l41, !tbaa !24
  %t700 = add i64 %t698, 1
  store i64 %t700, ptr %l41, !tbaa !24
  br label %bb201
bb207:
  %t702 = load ptr, ptr %l0, !tbaa !29
  %t703 = load ptr, ptr %l35, !tbaa !29
  %t705 = getelementptr %"compiler/typed:Match", ptr %t703, i32 0, i32 2
  %t706 = load ptr, ptr %t705, !tbaa !29
  %t707 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleArm(ptr %v0, ptr %v1, ptr %t702, ptr %t706, i1 %t707)
  br label %bb208
bb208:
  br label %bb308
bb209:
  %t711 = load ptr, ptr %l1, !tbaa !29
  store ptr %t711, ptr %l393, !tbaa !29
  store i1 false, ptr %l394, !tbaa !21
  %t712 = load ptr, ptr %l393, !tbaa !29
  %t713 = icmp ne ptr %t712, null
  br i1 %t713, label %bb210, label %bb211
bb210:
  %t715 = load ptr, ptr %l393, !tbaa !29
  %t716 = load i64, ptr %t715, !range !{i64 0, i64 18}
  %t718 = icmp eq i64 %t716, 14
  store i1 %t718, ptr %l394, !tbaa !21
  br label %bb211
bb211:
  %t719 = load i1, ptr %l394, !tbaa !21
  br i1 %t719, label %bb212, label %bb213
bb212:
  %t720 = load ptr, ptr %l1, !tbaa !29
  %t722 = getelementptr { i64, [5 x i64] }, ptr %t720, i32 0, i32 1
  %t723 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t722, i32 0, i32 2
  %t724 = load ptr, ptr %t723
  store ptr %t724, ptr %l44, !tbaa !29
  br label %bb214
bb213:
  br label %bb234
bb214:
  %t726 = load ptr, ptr %l0, !tbaa !29
  %t727 = load ptr, ptr %l44, !tbaa !29
  %t729 = getelementptr %"compiler/typed:Try", ptr %t727, i32 0, i32 0
  %t730 = load ptr, ptr %t729, !tbaa !29
  %t731 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t726, ptr %t730, i1 %t731)
  br label %bb215
bb215:
  %t735 = load ptr, ptr %l44, !tbaa !29
  %t737 = getelementptr %"compiler/typed:Try", ptr %t735, i32 0, i32 1
  %t738 = load { i64, ptr }, ptr %t737, !tbaa !27
  store { i64, ptr } %t738, ptr %l45, !tbaa !27
  store i64 0, ptr %l46, !tbaa !24
  %t740 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t742 = extractvalue { i64, ptr } %t740, 0
  store i64 %t742, ptr %l47, !tbaa !24
  br label %bb216
bb216:
  %t744 = load i64, ptr %l46, !tbaa !24
  %t745 = load i64, ptr %l47, !tbaa !24
  %t748 = icmp slt i64 %t744, %t745
  %t750 = xor i1 %t748, true
  br i1 %t750, label %bb217, label %bb218
bb217:
  br label %bb233
bb218:
  br label %bb219
bb219:
  %t752 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t752, ptr %l411, !tbaa !27
  %t753 = load i64, ptr %l46, !tbaa !24
  %t755 = getelementptr { i64, ptr }, ptr %l411, i32 0, i32 1
  %t756 = load ptr, ptr %t755, !tbaa !27
  %t757 = getelementptr ptr, ptr %t756, i64 %t753
  %t758 = load ptr, ptr %t757, !tbaa !39
  store ptr %t758, ptr %l48, !tbaa !29
  %t760 = load i1, ptr %l2, !tbaa !21
  br i1 %t760, label %bb220, label %bb221
bb220:
  %t762 = load ptr, ptr %l0, !tbaa !29
  %t763 = load ptr, ptr %l48, !tbaa !29
  %t765 = getelementptr %"compiler/typed:Clause", ptr %t763, i32 0, i32 3
  %t766 = load ptr, ptr %t765, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleStrictBlock(ptr %v0, ptr %v1, ptr %t762, ptr %t766)
  br label %bb222
bb221:
  %t769 = load ptr, ptr %l0, !tbaa !29
  %t770 = load ptr, ptr %l48, !tbaa !29
  %t772 = getelementptr %"compiler/typed:Clause", ptr %t770, i32 0, i32 3
  %t773 = load ptr, ptr %t772, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleBlock(ptr %v0, ptr %v1, ptr %t769, ptr %t773)
  br label %bb223
bb222:
  br label %bb224
bb223:
  br label %bb224
bb224:
  %t776 = load ptr, ptr %l48, !tbaa !29
  %t778 = getelementptr %"compiler/typed:Clause", ptr %t776, i32 0, i32 4
  %t779 = load { i64, ptr }, ptr %t778, !tbaa !27
  store { i64, ptr } %t779, ptr %l49, !tbaa !27
  store i64 0, ptr %l50, !tbaa !24
  %t781 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t783 = extractvalue { i64, ptr } %t781, 0
  store i64 %t783, ptr %l51, !tbaa !24
  br label %bb225
bb225:
  %t785 = load i64, ptr %l50, !tbaa !24
  %t786 = load i64, ptr %l51, !tbaa !24
  %t789 = icmp slt i64 %t785, %t786
  %t791 = xor i1 %t789, true
  br i1 %t791, label %bb226, label %bb227
bb226:
  br label %bb231
bb227:
  br label %bb228
bb228:
  %t793 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t793, ptr %l429, !tbaa !27
  %t794 = load i64, ptr %l50, !tbaa !24
  %t796 = getelementptr { i64, ptr }, ptr %l429, i32 0, i32 1
  %t797 = load ptr, ptr %t796, !tbaa !27
  %t798 = getelementptr ptr, ptr %t797, i64 %t794
  %t799 = load ptr, ptr %t798, !tbaa !39
  %t801 = load ptr, ptr %l0, !tbaa !29
  %t804 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t801, ptr %t799, i1 %t804)
  br label %bb229
bb229:
  br label %bb230
bb230:
  %t808 = load i64, ptr %l50, !tbaa !24
  %t810 = add i64 %t808, 1
  store i64 %t810, ptr %l50, !tbaa !24
  br label %bb225
bb231:
  br label %bb232
bb232:
  %t812 = load i64, ptr %l46, !tbaa !24
  %t814 = add i64 %t812, 1
  store i64 %t814, ptr %l46, !tbaa !24
  br label %bb216
bb233:
  br label %bb308
bb234:
  %t816 = load ptr, ptr %l1, !tbaa !29
  store ptr %t816, ptr %l440, !tbaa !29
  store i1 false, ptr %l441, !tbaa !21
  %t817 = load ptr, ptr %l440, !tbaa !29
  %t818 = icmp ne ptr %t817, null
  br i1 %t818, label %bb235, label %bb236
bb235:
  %t820 = load ptr, ptr %l440, !tbaa !29
  %t821 = load i64, ptr %t820, !range !{i64 0, i64 18}
  %t823 = icmp eq i64 %t821, 15
  store i1 %t823, ptr %l441, !tbaa !21
  br label %bb236
bb236:
  %t824 = load i1, ptr %l441, !tbaa !21
  br i1 %t824, label %bb237, label %bb238
bb237:
  %t825 = load ptr, ptr %l1, !tbaa !29
  %t827 = getelementptr { i64, [5 x i64] }, ptr %t825, i32 0, i32 1
  %t828 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t827, i32 0, i32 2
  %t829 = load ptr, ptr %t828
  store ptr %t829, ptr %l53, !tbaa !29
  br label %bb239
bb238:
  br label %bb265
bb239:
  %t831 = load ptr, ptr %l53, !tbaa !29
  store ptr %t831, ptr %l446, !tbaa !29
  store i1 false, ptr %l447, !tbaa !21
  %t832 = load ptr, ptr %l446, !tbaa !29
  %t833 = icmp ne ptr %t832, null
  br i1 %t833, label %bb240, label %bb241
bb240:
  %t835 = load ptr, ptr %l446, !tbaa !29
  %t836 = load i64, ptr %t835, !range !{i64 0, i64 3}
  %t838 = icmp eq i64 %t836, 1
  store i1 %t838, ptr %l447, !tbaa !21
  br label %bb241
bb241:
  %t839 = load i1, ptr %l447, !tbaa !21
  br i1 %t839, label %bb242, label %bb243
bb242:
  %t840 = load ptr, ptr %l53, !tbaa !29
  %t842 = getelementptr { i64, [4 x i64] }, ptr %t840, i32 0, i32 1
  %t843 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t842, i32 0, i32 1
  %t844 = load { i64, ptr }, ptr %t843
  store { i64, ptr } %t844, ptr %l54, !tbaa !27
  br label %bb244
bb243:
  br label %bb252
bb244:
  %t846 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t846, ptr %l55, !tbaa !27
  store i64 0, ptr %l56, !tbaa !24
  %t848 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t850 = extractvalue { i64, ptr } %t848, 0
  store i64 %t850, ptr %l57, !tbaa !24
  br label %bb245
bb245:
  %t852 = load i64, ptr %l56, !tbaa !24
  %t853 = load i64, ptr %l57, !tbaa !24
  %t856 = icmp slt i64 %t852, %t853
  %t858 = xor i1 %t856, true
  br i1 %t858, label %bb246, label %bb247
bb246:
  br label %bb251
bb247:
  br label %bb248
bb248:
  %t860 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t860, ptr %l459, !tbaa !27
  %t861 = load i64, ptr %l56, !tbaa !24
  %t863 = getelementptr { i64, ptr }, ptr %l459, i32 0, i32 1
  %t864 = load ptr, ptr %t863, !tbaa !27
  %t865 = getelementptr ptr, ptr %t864, i64 %t861
  %t866 = load ptr, ptr %t865, !tbaa !39
  %t868 = load ptr, ptr %l0, !tbaa !29
  %t871 = getelementptr %"compiler/typed:Capture", ptr %t866, i32 0, i32 1
  %t872 = load ptr, ptr %t871, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t868, ptr %t872, i1 true)
  br label %bb249
bb249:
  br label %bb250
bb250:
  %t876 = load i64, ptr %l56, !tbaa !24
  %t878 = add i64 %t876, 1
  store i64 %t878, ptr %l56, !tbaa !24
  br label %bb245
bb251:
  br label %bb264
bb252:
  %t880 = load ptr, ptr %l53, !tbaa !29
  store ptr %t880, ptr %l468, !tbaa !29
  store i1 false, ptr %l469, !tbaa !21
  %t881 = load ptr, ptr %l468, !tbaa !29
  %t882 = icmp ne ptr %t881, null
  br i1 %t882, label %bb253, label %bb254
bb253:
  %t884 = load ptr, ptr %l468, !tbaa !29
  %t885 = load i64, ptr %t884, !range !{i64 0, i64 3}
  %t887 = icmp eq i64 %t885, 2
  store i1 %t887, ptr %l469, !tbaa !21
  br label %bb254
bb254:
  %t888 = load i1, ptr %l469, !tbaa !21
  br i1 %t888, label %bb255, label %bb256
bb255:
  %t889 = load ptr, ptr %l53, !tbaa !29
  %t891 = getelementptr { i64, [4 x i64] }, ptr %t889, i32 0, i32 1
  %t892 = getelementptr { i32, ptr, i32 }, ptr %t891, i32 0, i32 1
  %t893 = load ptr, ptr %t892
  store ptr %t893, ptr %l59, !tbaa !29
  br label %bb257
bb256:
  br label %bb259
bb257:
  %t895 = load ptr, ptr %l0, !tbaa !29
  %t896 = load ptr, ptr %l59, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t895, ptr %t896, i1 true)
  br label %bb258
bb258:
  br label %bb264
bb259:
  br i1 true, label %bb260, label %bb261
bb260:
  br label %bb262
bb261:
  br label %bb263
bb262:
  br label %bb264
bb263:
  call void @__olang_check_failed(ptr @olang_loc_80a42f326454c431_eaf1445ab36ad4e5)
  unreachable
bb264:
  br label %bb308
bb265:
  %t900 = load ptr, ptr %l1, !tbaa !29
  store ptr %t900, ptr %l477, !tbaa !29
  store i1 false, ptr %l478, !tbaa !21
  %t901 = load ptr, ptr %l477, !tbaa !29
  %t902 = icmp ne ptr %t901, null
  br i1 %t902, label %bb266, label %bb267
bb266:
  %t904 = load ptr, ptr %l477, !tbaa !29
  %t905 = load i64, ptr %t904, !range !{i64 0, i64 18}
  %t907 = icmp eq i64 %t905, 16
  store i1 %t907, ptr %l478, !tbaa !21
  br label %bb267
bb267:
  %t908 = load i1, ptr %l478, !tbaa !21
  br i1 %t908, label %bb268, label %bb269
bb268:
  %t909 = load ptr, ptr %l1, !tbaa !29
  %t911 = getelementptr { i64, [5 x i64] }, ptr %t909, i32 0, i32 1
  %t912 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t911, i32 0, i32 2
  %t913 = load ptr, ptr %t912
  store ptr %t913, ptr %l60, !tbaa !29
  br label %bb270
bb269:
  br label %bb296
bb270:
  %t915 = load ptr, ptr %l60, !tbaa !29
  %t917 = getelementptr %"compiler/typed:Text", ptr %t915, i32 0, i32 0
  %t918 = load { i64, ptr }, ptr %t917, !tbaa !27
  store { i64, ptr } %t918, ptr %l61, !tbaa !27
  store i64 0, ptr %l62, !tbaa !24
  %t920 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t922 = extractvalue { i64, ptr } %t920, 0
  store i64 %t922, ptr %l63, !tbaa !24
  br label %bb271
bb271:
  %t924 = load i64, ptr %l62, !tbaa !24
  %t925 = load i64, ptr %l63, !tbaa !24
  %t928 = icmp slt i64 %t924, %t925
  %t930 = xor i1 %t928, true
  br i1 %t930, label %bb272, label %bb273
bb272:
  br label %bb295
bb273:
  br label %bb274
bb274:
  %t932 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t932, ptr %l491, !tbaa !27
  %t933 = load i64, ptr %l62, !tbaa !24
  %t935 = getelementptr { i64, ptr }, ptr %l491, i32 0, i32 1
  %t936 = load ptr, ptr %t935, !tbaa !27
  %t937 = getelementptr ptr, ptr %t936, i64 %t933
  %t938 = load ptr, ptr %t937, !tbaa !39
  store ptr %t938, ptr %l64, !tbaa !29
  %t940 = load ptr, ptr %l64, !tbaa !29
  store ptr %t940, ptr %l494, !tbaa !29
  store i1 false, ptr %l495, !tbaa !21
  %t941 = load ptr, ptr %l494, !tbaa !29
  %t942 = icmp ne ptr %t941, null
  br i1 %t942, label %bb275, label %bb276
bb275:
  %t944 = load ptr, ptr %l494, !tbaa !29
  %t945 = load i64, ptr %t944, !range !{i64 0, i64 2}
  %t947 = icmp eq i64 %t945, 1
  store i1 %t947, ptr %l495, !tbaa !21
  br label %bb276
bb276:
  %t948 = load i1, ptr %l495, !tbaa !21
  br i1 %t948, label %bb277, label %bb278
bb277:
  %t949 = load ptr, ptr %l64, !tbaa !29
  %t951 = getelementptr { i64, [2 x i64] }, ptr %t949, i32 0, i32 1
  %t952 = getelementptr { ptr }, ptr %t951, i32 0, i32 0
  %t953 = load ptr, ptr %t952
  store ptr %t953, ptr %l65, !tbaa !29
  br label %bb279
bb278:
  br label %bb288
bb279:
  %t955 = load i1, ptr %l2, !tbaa !21
  br i1 %t955, label %bb280, label %bb281
bb280:
  store i1 true, ptr %l501, !tbaa !21
  br label %bb283
bb281:
  %t957 = load ptr, ptr %l0, !tbaa !29
  %t958 = load ptr, ptr %l65, !tbaa !29
  %t961 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleBorrow(ptr %v0, ptr %v1, ptr %t957, ptr %t958)
  store i1 %t961, ptr %l504
  br label %bb282
bb282:
  %t962 = load i1, ptr %l504, !tbaa !21
  %t963 = xor i1 %t962, true
  store i1 %t963, ptr %l501, !tbaa !21
  br label %bb283
bb283:
  %t965 = load i1, ptr %l501, !tbaa !21
  br i1 %t965, label %bb284, label %bb285
bb284:
  %t966 = load ptr, ptr %l0, !tbaa !29
  %t967 = load ptr, ptr %l65, !tbaa !29
  %t969 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t966, ptr %t967, i1 %t969)
  br label %bb286
bb285:
  br label %bb287
bb286:
  br label %bb287
bb287:
  br label %bb293
bb288:
  br i1 true, label %bb289, label %bb290
bb289:
  br label %bb291
bb290:
  br label %bb292
bb291:
  br label %bb293
bb292:
  call void @__olang_check_failed(ptr @olang_loc_fdb46d1d9262e41a_919c32215229332e)
  unreachable
bb293:
  br label %bb294
bb294:
  %t973 = load i64, ptr %l62, !tbaa !24
  %t975 = add i64 %t973, 1
  store i64 %t975, ptr %l62, !tbaa !24
  br label %bb271
bb295:
  br label %bb308
bb296:
  %t977 = load ptr, ptr %l1, !tbaa !29
  store ptr %t977, ptr %l512, !tbaa !29
  store i1 false, ptr %l513, !tbaa !21
  %t978 = load ptr, ptr %l512, !tbaa !29
  %t979 = icmp ne ptr %t978, null
  br i1 %t979, label %bb297, label %bb298
bb297:
  %t981 = load ptr, ptr %l512, !tbaa !29
  %t982 = load i64, ptr %t981, !range !{i64 0, i64 18}
  %t984 = icmp eq i64 %t982, 17
  store i1 %t984, ptr %l513, !tbaa !21
  br label %bb298
bb298:
  %t985 = load i1, ptr %l513, !tbaa !21
  br i1 %t985, label %bb299, label %bb300
bb299:
  %t986 = load ptr, ptr %l1, !tbaa !29
  %t988 = getelementptr { i64, [5 x i64] }, ptr %t986, i32 0, i32 1
  %t989 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t988, i32 0, i32 2
  %t990 = load ptr, ptr %t989
  store ptr %t990, ptr %l66, !tbaa !29
  br label %bb301
bb300:
  br label %bb303
bb301:
  %t992 = load ptr, ptr %l0, !tbaa !29
  %t993 = load ptr, ptr %l66, !tbaa !29
  %t995 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t992, ptr %t993, i1 %t995)
  br label %bb302
bb302:
  br label %bb308
bb303:
  br i1 true, label %bb304, label %bb305
bb304:
  br label %bb306
bb305:
  br label %bb307
bb306:
  %t999 = load ptr, ptr %l0, !tbaa !29
  %t1001 = getelementptr %"compiler/scope:Scoper", ptr %t999, i32 0, i32 115
  store i1 true, ptr %t1001, !tbaa !21
  br label %bb308
bb307:
  call void @__olang_check_failed(ptr @olang_loc_3a379002e95ffe1b_e75bb6252129afef)
  unreachable
bb308:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estmts(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca ptr
  %l16 = alloca i64
  %l19 = alloca i64
  %l37 = alloca { i64, ptr }
  %l40 = alloca ptr
  %l41 = alloca i1
  %l56 = alloca i1
  %l57 = alloca i1
  %l60 = alloca i1
  %l61 = alloca i1
  %l68 = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l19, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l19, !tbaa !24
  store i64 %t31, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l16, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  br label %bb37
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l2, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l7, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t51, ptr %l37, !tbaa !27
  %t52 = load i64, ptr %l7, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr ptr, ptr %t55, i64 %t52
  %t57 = load ptr, ptr %t56, !tbaa !39
  store ptr %t57, ptr %l8, !tbaa !29
  %t59 = load ptr, ptr %l8, !tbaa !29
  store ptr %t59, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t60 = load ptr, ptr %l40, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb11, label %bb12
bb11:
  %t63 = load ptr, ptr %l40, !tbaa !29
  %t64 = load i64, ptr %t63, !range !{i64 0, i64 17}
  %t66 = icmp eq i64 %t64, 0
  store i1 %t66, ptr %l41, !tbaa !21
  br label %bb12
bb12:
  %t67 = load i1, ptr %l41, !tbaa !21
  br i1 %t67, label %bb13, label %bb14
bb13:
  %t68 = load ptr, ptr %l8, !tbaa !29
  %t70 = getelementptr { i64, [3 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t70, i32 0, i32 1
  %t72 = load i32, ptr %t71
  store i32 %t72, ptr %l9, !tbaa !23
  %t74 = load ptr, ptr %l8, !tbaa !29
  %t76 = getelementptr { i64, [3 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t76, i32 0, i32 2
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l10, !tbaa !29
  br label %bb15
bb14:
  br label %bb29
bb15:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i32, ptr %l9, !tbaa !23
  %t82 = load ptr, ptr %l10, !tbaa !29
  %t83 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t84 = load i64, ptr %l7, !tbaa !24
  %t86 = add i64 %t84, 1
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edecide(ptr %v0, ptr %v1, ptr %v1, ptr %t80, i32 %t81, ptr %t82, { i64, ptr } %t83, i64 %t86)
  br label %bb16
bb16:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %l10, !tbaa !29
  %t96 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecapturingLambda(ptr %v0, ptr %v1, ptr %t92, ptr %t93)
  store i1 %t96, ptr %l56
  br label %bb17
bb17:
  %t97 = load i1, ptr %l56, !tbaa !21
  br i1 %t97, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb21
bb19:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load ptr, ptr %l10, !tbaa !29
  %t102 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisAdapter(ptr %v0, ptr %v1, ptr %t98, ptr %t99)
  store i1 %t102, ptr %l60
  br label %bb20
bb20:
  %t103 = load i1, ptr %l60, !tbaa !21
  store i1 %t103, ptr %l57, !tbaa !21
  br label %bb21
bb21:
  %t104 = load i1, ptr %l57, !tbaa !21
  br i1 %t104, label %bb22, label %bb23
bb22:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t107 = load i64, ptr %l7, !tbaa !24
  %t109 = add i64 %t107, 1
  %t110 = load i32, ptr %l9, !tbaa !23
  %t112 = sext i32 %t110 to i64
  %t117 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eonlyCalled(ptr %v0, ptr %v1, ptr %t105, { i64, ptr } %t106, i64 %t109, i64 %t112)
  store i1 %t117, ptr %l68
  br label %bb24
bb23:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb25
bb24:
  %t118 = load i1, ptr %l68, !tbaa !21
  store i1 %t118, ptr %l61, !tbaa !21
  br label %bb25
bb25:
  %t119 = load i1, ptr %l61, !tbaa !21
  br i1 %t119, label %bb26, label %bb27
bb26:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/scope:Scoper", ptr %t120, i32 0, i32 68
  store i1 true, ptr %t122, !tbaa !21
  br label %bb28
bb27:
  br label %bb28
bb28:
  br label %bb34
bb29:
  br i1 true, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_894def51c550c10b_edf695233d65cd0f)
  unreachable
bb34:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estmt(ptr %v0, ptr %v1, ptr %t123, ptr %t124)
  br label %bb35
bb35:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/scope:Scoper", ptr %t128, i32 0, i32 68
  store i1 false, ptr %t130, !tbaa !21
  br label %bb36
bb36:
  %t131 = load i64, ptr %l6, !tbaa !24
  %t133 = add i64 %t131, 1
  store i64 %t133, ptr %l6, !tbaa !24
  br label %bb7
bb37:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estorOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca i1
  %l20 = alloca { i64, [2 x i64] }
  %l21 = alloca ptr
  %l22 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %l36 = alloca %"compiler/scope:Val"
  %l38 = alloca ptr
  %l39 = alloca i1
  %l46 = alloca { i64, [2 x i64] }
  %l47 = alloca ptr
  %l48 = alloca i1
  %l55 = alloca i32
  %l60 = alloca i32
  %l63 = alloca i1
  %l68 = alloca i32
  %l73 = alloca { i64, [2 x i64] }
  %l77 = alloca { i64, [2 x i64] }
  %l78 = alloca ptr
  %l79 = alloca i1
  %l87 = alloca { i64, [2 x i64] }
  %l88 = alloca ptr
  %l89 = alloca i1
  %l99 = alloca { i64, [2 x i64] }
  %l101 = alloca { i64, [2 x i64] }
  %l102 = alloca ptr
  %l103 = alloca i1
  %l108 = alloca i64
  %l110 = alloca ptr
  %l112 = alloca ptr
  %l115 = alloca i64
  %l117 = alloca ptr
  %l118 = alloca { i64, [2 x i64] }
  %rv = alloca { i64, [2 x i64] }
  %t35 = alloca { i64, [2 x i64] }, align 8
  %t57 = alloca { i64, [2 x i64] }, align 8
  %t248 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l10, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/scope:Scoper", ptr %t16, i32 0, i32 32
  %t19 = load i32, ptr %l2, !tbaa !23
  %t21 = sext i32 %t19 to i64
  %t24 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t18, i64 %t21)
  store { i64, [2 x i64] } %t24, ptr %l20
  br label %bb6
bb6:
  %t25 = load { i64, [2 x i64] }, ptr %l20
  store { i64, [2 x i64] } %t25, ptr %rv
  br label %ret
bb7:
  %t26 = load ptr, ptr %l1, !tbaa !29
  store ptr %t26, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t27 = load ptr, ptr %l21, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb8, label %bb9
bb8:
  %t30 = load ptr, ptr %l21, !tbaa !29
  %t31 = load i64, ptr %t30, !range !{i64 0, i64 8}
  %t33 = icmp eq i64 %t31, 1
  store i1 %t33, ptr %l22, !tbaa !21
  br label %bb9
bb9:
  %t34 = load i1, ptr %l22, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  store { i64, [2 x i64] } zeroinitializer, ptr %t35
  %t36 = getelementptr { i64, [2 x i64] }, ptr %t35, i32 0, i32 0
  store i64 3, ptr %t36
  %t37 = load { i64, [2 x i64] }, ptr %t35
  store { i64, [2 x i64] } %t37, ptr %rv
  br label %ret
bb13:
  %t39 = load ptr, ptr %l1, !tbaa !29
  store ptr %t39, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t40 = load ptr, ptr %l26, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb14, label %bb15
bb14:
  %t43 = load ptr, ptr %l26, !tbaa !29
  %t44 = load i64, ptr %t43, !range !{i64 0, i64 8}
  %t46 = icmp eq i64 %t44, 2
  store i1 %t46, ptr %l27, !tbaa !21
  br label %bb15
bb15:
  %t47 = load i1, ptr %l27, !tbaa !21
  br i1 %t47, label %bb16, label %bb17
bb16:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr { i64, [4 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t50, i32 0, i32 2
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l3, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l3, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t57
  %t58 = getelementptr { i64, [2 x i64] }, ptr %t57, i32 0, i32 0
  store i64 0, ptr %t58
  %t59 = load { i64, [2 x i64] }, ptr %t57
  %t63 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t54, ptr %t55, { i64, [2 x i64] } %t59)
  store %"compiler/scope:Val" %t63, ptr %l36
  br label %bb19
bb19:
  %t64 = getelementptr %"compiler/scope:Val", ptr %l36, i32 0, i32 1
  %t65 = load { i64, [2 x i64] }, ptr %t64
  store { i64, [2 x i64] } %t65, ptr %rv
  br label %ret
bb20:
  %t67 = load ptr, ptr %l1, !tbaa !29
  store ptr %t67, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t68 = load ptr, ptr %l38, !tbaa !29
  %t69 = icmp ne ptr %t68, null
  br i1 %t69, label %bb21, label %bb22
bb21:
  %t71 = load ptr, ptr %l38, !tbaa !29
  %t72 = load i64, ptr %t71, !range !{i64 0, i64 8}
  %t74 = icmp eq i64 %t72, 3
  store i1 %t74, ptr %l39, !tbaa !21
  br label %bb22
bb22:
  %t75 = load i1, ptr %l39, !tbaa !21
  br i1 %t75, label %bb23, label %bb24
bb23:
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr { i64, [4 x i64] }, ptr %t76, i32 0, i32 1
  %t79 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t78, i32 0, i32 2
  %t80 = load ptr, ptr %t79
  store ptr %t80, ptr %l4, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load ptr, ptr %l4, !tbaa !29
  %t86 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estorOf(ptr %v0, ptr %v1, ptr %t82, ptr %t83)
  store { i64, [2 x i64] } %t86, ptr %l46
  br label %bb26
bb26:
  %t87 = load { i64, [2 x i64] }, ptr %l46
  store { i64, [2 x i64] } %t87, ptr %rv
  br label %ret
bb27:
  %t88 = load ptr, ptr %l1, !tbaa !29
  store ptr %t88, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t89 = load ptr, ptr %l47, !tbaa !29
  %t90 = icmp ne ptr %t89, null
  br i1 %t90, label %bb28, label %bb29
bb28:
  %t92 = load ptr, ptr %l47, !tbaa !29
  %t93 = load i64, ptr %t92, !range !{i64 0, i64 8}
  %t95 = icmp eq i64 %t93, 4
  store i1 %t95, ptr %l48, !tbaa !21
  br label %bb29
bb29:
  %t96 = load i1, ptr %l48, !tbaa !21
  br i1 %t96, label %bb30, label %bb31
bb30:
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr { i64, [4 x i64] }, ptr %t97, i32 0, i32 1
  %t100 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t99, i32 0, i32 2
  %t101 = load ptr, ptr %t100
  store ptr %t101, ptr %l5, !tbaa !29
  br label %bb32
bb31:
  br label %bb44
bb32:
  %t103 = load ptr, ptr %l5, !tbaa !29
  %t105 = getelementptr %"compiler/typed:Elem", ptr %t103, i32 0, i32 0
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t106)
  store i32 %t108, ptr %l55
  br label %bb33
bb33:
  %t109 = load i32, ptr %l55, !tbaa !23
  store i32 %t109, ptr %l6, !tbaa !23
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/scope:Scoper", ptr %t110, i32 0, i32 0
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = getelementptr %"compiler/generic:Program", ptr %t113, i32 0, i32 2
  %t116 = load i32, ptr %l6, !tbaa !23
  %t119 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t115, i32 %t116)
  store i32 %t119, ptr %l60
  br label %bb34
bb34:
  %t120 = load i32, ptr %l60, !range !{i32 0, i32 33}
  %t122 = trunc i64 19 to i32
  %t123 = icmp eq i32 %t120, %t122
  br i1 %t123, label %bb35, label %bb36
bb35:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/scope:Scoper", ptr %t125, i32 0, i32 0
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t130 = getelementptr %"compiler/generic:Program", ptr %t128, i32 0, i32 2
  %t131 = load i32, ptr %l6, !tbaa !23
  %t134 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t130, i32 %t131)
  store i32 %t134, ptr %l68
  br label %bb37
bb36:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb38
bb37:
  %t135 = load i32, ptr %l68, !tbaa !23
  %t136 = icmp eq i32 %t135, 0
  store i1 %t136, ptr %l63, !tbaa !21
  br label %bb38
bb38:
  %t138 = load i1, ptr %l63, !tbaa !21
  br i1 %t138, label %bb39, label %bb40
bb39:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load ptr, ptr %l5, !tbaa !29
  %t142 = getelementptr %"compiler/typed:Elem", ptr %t140, i32 0, i32 0
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t146 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartsTerm(ptr %v0, ptr %v1, ptr %t139, ptr %t143)
  store { i64, [2 x i64] } %t146, ptr %l73
  br label %bb41
bb40:
  br label %bb42
bb41:
  %t147 = load { i64, [2 x i64] }, ptr %l73
  store { i64, [2 x i64] } %t147, ptr %rv
  br label %ret
bb42:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load ptr, ptr %l5, !tbaa !29
  %t151 = getelementptr %"compiler/typed:Elem", ptr %t149, i32 0, i32 0
  %t152 = load ptr, ptr %t151, !tbaa !29
  %t155 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estorOf(ptr %v0, ptr %v1, ptr %t148, ptr %t152)
  store { i64, [2 x i64] } %t155, ptr %l77
  br label %bb43
bb43:
  %t156 = load { i64, [2 x i64] }, ptr %l77
  store { i64, [2 x i64] } %t156, ptr %rv
  br label %ret
bb44:
  %t157 = load ptr, ptr %l1, !tbaa !29
  store ptr %t157, ptr %l78, !tbaa !29
  store i1 false, ptr %l79, !tbaa !21
  %t158 = load ptr, ptr %l78, !tbaa !29
  %t159 = icmp ne ptr %t158, null
  br i1 %t159, label %bb45, label %bb46
bb45:
  %t161 = load ptr, ptr %l78, !tbaa !29
  %t162 = load i64, ptr %t161, !range !{i64 0, i64 8}
  %t164 = icmp eq i64 %t162, 5
  store i1 %t164, ptr %l79, !tbaa !21
  br label %bb46
bb46:
  %t165 = load i1, ptr %l79, !tbaa !21
  br i1 %t165, label %bb47, label %bb48
bb47:
  %t166 = load ptr, ptr %l1, !tbaa !29
  %t168 = getelementptr { i64, [4 x i64] }, ptr %t166, i32 0, i32 1
  %t169 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t168, i32 0, i32 2
  %t170 = load ptr, ptr %t169
  store ptr %t170, ptr %l7, !tbaa !29
  br label %bb49
bb48:
  br label %bb51
bb49:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load ptr, ptr %l7, !tbaa !29
  %t175 = getelementptr %"compiler/typed:Payload", ptr %t173, i32 0, i32 0
  %t176 = load ptr, ptr %t175, !tbaa !29
  %t179 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estorOf(ptr %v0, ptr %v1, ptr %t172, ptr %t176)
  store { i64, [2 x i64] } %t179, ptr %l87
  br label %bb50
bb50:
  %t180 = load { i64, [2 x i64] }, ptr %l87
  store { i64, [2 x i64] } %t180, ptr %rv
  br label %ret
bb51:
  %t181 = load ptr, ptr %l1, !tbaa !29
  store ptr %t181, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t182 = load ptr, ptr %l88, !tbaa !29
  %t183 = icmp ne ptr %t182, null
  br i1 %t183, label %bb52, label %bb53
bb52:
  %t185 = load ptr, ptr %l88, !tbaa !29
  %t186 = load i64, ptr %t185, !range !{i64 0, i64 8}
  %t188 = icmp eq i64 %t186, 6
  store i1 %t188, ptr %l89, !tbaa !21
  br label %bb53
bb53:
  %t189 = load i1, ptr %l89, !tbaa !21
  br i1 %t189, label %bb54, label %bb55
bb54:
  %t190 = load ptr, ptr %l1, !tbaa !29
  %t192 = getelementptr { i64, [4 x i64] }, ptr %t190, i32 0, i32 1
  %t193 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t192, i32 0, i32 2
  %t194 = load ptr, ptr %t193
  store ptr %t194, ptr %l8, !tbaa !29
  %t196 = load ptr, ptr %l1, !tbaa !29
  %t198 = getelementptr { i64, [4 x i64] }, ptr %t196, i32 0, i32 1
  %t199 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t198, i32 0, i32 3
  %t200 = load i32, ptr %t199
  store i32 %t200, ptr %l9, !tbaa !23
  br label %bb56
bb55:
  br label %bb59
bb56:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load ptr, ptr %l8, !tbaa !29
  %t204 = load i32, ptr %l9, !tbaa !23
  %t208 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etempTerm(ptr %v0, ptr %v1, ptr %t202, ptr %t203, i32 %t204)
  store { i64, [2 x i64] } %t208, ptr %l99
  br label %bb57
bb57:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eframeHere(ptr %v0, ptr %t209)
  store { i64, [2 x i64] } %t211, ptr %l101
  br label %bb58
bb58:
  %t212 = load { i64, [2 x i64] }, ptr %l101
  store { i64, [2 x i64] } %t212, ptr %rv
  br label %ret
bb59:
  %t213 = load ptr, ptr %l1, !tbaa !29
  store ptr %t213, ptr %l102, !tbaa !29
  store i1 false, ptr %l103, !tbaa !21
  %t214 = load ptr, ptr %l102, !tbaa !29
  %t215 = icmp ne ptr %t214, null
  br i1 %t215, label %bb60, label %bb61
bb60:
  %t217 = load ptr, ptr %l102, !tbaa !29
  %t218 = load i64, ptr %t217, !range !{i64 0, i64 8}
  %t220 = icmp eq i64 %t218, 7
  store i1 %t220, ptr %l103, !tbaa !21
  br label %bb61
bb61:
  %t221 = load i1, ptr %l103, !tbaa !21
  br i1 %t221, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb72
bb64:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/scope:Scoper", ptr %t222, i32 0, i32 57
  %t226 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eLen__H22c160154c8542d83ffe3c77c98973d0(ptr %v0, ptr %t224)
  store i64 %t226, ptr %l108
  br label %bb65
bb65:
  %t227 = load i64, ptr %l108, !tbaa !24
  %t228 = icmp sge i64 %t227, 2
  br i1 %t228, label %bb66, label %bb67
bb66:
  %t230 = load ptr, ptr %l0, !tbaa !29
  store ptr %t230, ptr %l110, !tbaa !29
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr %"compiler/scope:Scoper", ptr %t231, i32 0, i32 57
  store ptr %t233, ptr %l112, !tbaa !29
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"compiler/scope:Scoper", ptr %t234, i32 0, i32 57
  %t238 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eLen__H22c160154c8542d83ffe3c77c98973d0(ptr %v0, ptr %t236)
  store i64 %t238, ptr %l115
  br label %bb68
bb67:
  br label %bb71
bb68:
  %t239 = load i64, ptr %l115, !tbaa !24
  %t240 = sub i64 %t239, 2
  %t241 = load ptr, ptr %l112, !tbaa !29
  %t243 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eAt_3ccompiler_2ftyped_3aLvalue_26_3e(ptr %v0, ptr %v0, ptr %t241, i64 %t240)
  store ptr %t243, ptr %l117
  br label %bb69
bb69:
  %t244 = load ptr, ptr %l110, !tbaa !29
  %t245 = load ptr, ptr %l117, !tbaa !29
  %t246 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estorOf(ptr %v0, ptr %v0, ptr %t244, ptr %t245)
  store { i64, [2 x i64] } %t246, ptr %l118
  br label %bb70
bb70:
  %t247 = load { i64, [2 x i64] }, ptr %l118
  store { i64, [2 x i64] } %t247, ptr %rv
  br label %ret
bb71:
  store { i64, [2 x i64] } zeroinitializer, ptr %t248
  %t249 = getelementptr { i64, [2 x i64] }, ptr %t248, i32 0, i32 0
  store i64 6, ptr %t249
  %t250 = load { i64, [2 x i64] }, ptr %t248
  store { i64, [2 x i64] } %t250, ptr %rv
  br label %ret
bb72:
  call void @__olang_check_failed(ptr @olang_loc_8bfac37a1f29704b_1a5bb9d5b57da78f)
  unreachable
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ethrough(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [2 x i64] } %a1, { i64, ptr } %a2, ptr %a3, i1 %a4) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, [2 x i64] }
  %l16 = alloca { i64, [2 x i64] }
  %l17 = alloca { i64, ptr }
  %l34 = alloca { i64, [2 x i64] }
  %rv = alloca { i64, [2 x i64] }
  %t26 = alloca { i64, [2 x i64] }, align 8
  %t36 = alloca { i64, [2 x i64] }, align 8
  %t67 = alloca { i64, [2 x i64] }, align 8
  store { i64, [2 x i64] } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 2
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i64 }, ptr %t6, i32 0, i32 0
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l5, !tbaa !24
  br label %bb3
bb2:
  br label %bb7
bb3:
  %t10 = load i64, ptr %l5, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t16 = icmp slt i64 %t10, %t13
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l17, !tbaa !27
  %t19 = load i64, ptr %l5, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t22, i64 %t19
  %t24 = load { i64, [2 x i64] }, ptr %t23
  store { i64, [2 x i64] } %t24, ptr %l16
  br label %bb6
bb5:
  store { i64, [2 x i64] } zeroinitializer, ptr %t26
  %t27 = getelementptr { i64, [2 x i64] }, ptr %t26, i32 0, i32 0
  store i64 6, ptr %t27
  %t28 = load { i64, [2 x i64] }, ptr %t26
  store { i64, [2 x i64] } %t28, ptr %l16
  br label %bb6
bb6:
  %t30 = load { i64, [2 x i64] }, ptr %l16
  store { i64, [2 x i64] } %t30, ptr %l8
  br label %bb21
bb7:
  %t31 = load { i64, [2 x i64] }, ptr %l1
  %t33 = extractvalue { i64, [2 x i64] } %t31, 0
  %t34 = icmp eq i64 %t33, 3
  br i1 %t34, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store { i64, [2 x i64] } zeroinitializer, ptr %t36
  %t37 = getelementptr { i64, [2 x i64] }, ptr %t36, i32 0, i32 0
  store i64 3, ptr %t37
  %t38 = load { i64, [2 x i64] }, ptr %t36
  store { i64, [2 x i64] } %t38, ptr %l8
  br label %bb21
bb11:
  %t40 = load { i64, [2 x i64] }, ptr %l1
  %t42 = extractvalue { i64, [2 x i64] } %t40, 0
  %t43 = icmp eq i64 %t42, 4
  br i1 %t43, label %bb12, label %bb13
bb12:
  %t45 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t46 = getelementptr { i64, i64 }, ptr %t45, i32 0, i32 0
  %t47 = load i64, ptr %t46
  store i64 %t47, ptr %l6, !tbaa !24
  %t49 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t50 = getelementptr { i64, i64 }, ptr %t49, i32 0, i32 1
  %t51 = load i64, ptr %t50
  store i64 %t51, ptr %l7, !tbaa !24
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t54 = load i64, ptr %l6, !tbaa !24
  %t55 = load i64, ptr %l7, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t65 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ederivedAt(ptr %v0, ptr %v2, ptr %v1, ptr %a0, i64 %t54, i64 %t55, ptr %a3, i1 %a4, { i64, ptr } %t58)
  store { i64, [2 x i64] } %t65, ptr %l34
  br label %bb15
bb15:
  %t66 = load { i64, [2 x i64] }, ptr %l34
  store { i64, [2 x i64] } %t66, ptr %l8
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store { i64, [2 x i64] } zeroinitializer, ptr %t67
  %t68 = getelementptr { i64, [2 x i64] }, ptr %t67, i32 0, i32 0
  store i64 6, ptr %t68
  %t69 = load { i64, [2 x i64] }, ptr %t67
  store { i64, [2 x i64] } %t69, ptr %l8
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_5042ae5260cf85f5_3d2bef1206874e11)
  unreachable
bb21:
  %t71 = load { i64, [2 x i64] }, ptr %l8
  store { i64, [2 x i64] } %t71, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etiedToBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"compiler/scope:rel"
  %l10 = alloca { i64, [2 x i64] }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l23 = alloca ptr
  %l29 = alloca i32
  %l33 = alloca i64
  %l36 = alloca i1
  %l40 = alloca ptr
  %l47 = alloca i64
  %l52 = alloca { i64, ptr }
  %l56 = alloca ptr
  %l59 = alloca i64
  %l61 = alloca i64
  %l66 = alloca %"compiler/scope:rel"
  %l69 = alloca i1
  %l84 = alloca i64
  %l87 = alloca i64
  %l110 = alloca i64
  %l113 = alloca i64
  %l120 = alloca i1
  %l125 = alloca i1
  %l126 = alloca ptr
  %l129 = alloca { i64, ptr }
  %l133 = alloca { i64, [2 x i64] }
  %l134 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t6 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallOf(ptr %v0, ptr %v1, ptr %v1, ptr %t1, ptr %a1)
  store ptr %t6, ptr %l23
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l23, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t10 = icmp eq ptr %t8, null
  br i1 %t10, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t17 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %t13, ptr %t14)
  store i32 %t17, ptr %l29
  br label %bb5
bb5:
  %t18 = load i32, ptr %l29, !tbaa !23
  store i32 %t18, ptr %l3, !tbaa !23
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t22 = getelementptr %"compiler/typed:Call", ptr %t20, i32 0, i32 0
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t26 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebodyOf(ptr %v0, ptr %v1, ptr %t19, ptr %t23)
  store i64 %t26, ptr %l33
  br label %bb6
bb6:
  %t27 = load i64, ptr %l33, !tbaa !24
  store i64 %t27, ptr %l4, !tbaa !24
  %t28 = load i64, ptr %l4, !tbaa !24
  %t30 = icmp slt i64 %t28, 0
  br i1 %t30, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb10
bb8:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/scope:Scoper", ptr %t32, i32 0, i32 6
  %t35 = load i64, ptr %l4, !tbaa !24
  %t38 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t34, i64 %t35)
  store ptr %t38, ptr %l40
  br label %bb9
bb9:
  %t39 = load ptr, ptr %l40, !tbaa !29
  %t41 = getelementptr %"compiler/scope:summary", ptr %t39, i32 0, i32 15
  %t42 = load i1, ptr %t41, !tbaa !21
  %t44 = xor i1 %t42, true
  store i1 %t44, ptr %l36, !tbaa !21
  br label %bb10
bb10:
  %t46 = load i1, ptr %l36, !tbaa !21
  br i1 %t46, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load i32, ptr %l3, !tbaa !23
  %t52 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eresultVarOf(ptr %v0, ptr %t48, i32 %t49)
  store i64 %t52, ptr %l47
  br label %bb14
bb14:
  %t53 = load i64, ptr %l47, !tbaa !24
  store i64 %t53, ptr %l5, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/scope:Scoper", ptr %t54, i32 0, i32 0
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/generic:Program", ptr %t57, i32 0, i32 2
  %t60 = load i32, ptr %l3, !tbaa !23
  %t63 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t59, i32 %t60)
  store { i64, ptr } %t63, ptr %l52
  br label %bb15
bb15:
  %t64 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t64, ptr %l6, !tbaa !27
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/scope:Scoper", ptr %t65, i32 0, i32 6
  %t68 = load i64, ptr %l4, !tbaa !24
  %t71 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t67, i64 %t68)
  store ptr %t71, ptr %l56
  br label %bb16
bb16:
  %t72 = load ptr, ptr %l56, !tbaa !29
  %t74 = getelementptr %"compiler/scope:summary", ptr %t72, i32 0, i32 0
  store ptr %t74, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb17
bb17:
  %t76 = load i64, ptr %l8, !tbaa !24
  store i64 %t76, ptr %l59, !tbaa !24
  %t77 = load ptr, ptr %l7, !tbaa !29
  %t79 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t77)
  store i64 %t79, ptr %l61
  br label %bb18
bb18:
  %t80 = load i64, ptr %l59, !tbaa !24
  %t81 = load i64, ptr %l61, !tbaa !24
  %t82 = icmp slt i64 %t80, %t81
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb19, label %bb20
bb19:
  br label %bb66
bb20:
  br label %bb21
bb21:
  %t86 = load ptr, ptr %l7, !tbaa !29
  %t87 = load i64, ptr %l8, !tbaa !24
  %t90 = call %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t86, i64 %t87)
  store %"compiler/scope:rel" %t90, ptr %l66
  br label %bb22
bb22:
  %t91 = load %"compiler/scope:rel", ptr %l66
  store %"compiler/scope:rel" %t91, ptr %l9
  %t92 = getelementptr %"compiler/scope:rel", ptr %l9, i32 0, i32 1
  %t93 = load { i64, [2 x i64] }, ptr %t92
  %t95 = extractvalue { i64, [2 x i64] } %t93, 0
  %t96 = icmp eq i64 %t95, 2
  br i1 %t96, label %bb23, label %bb24
bb23:
  %t98 = getelementptr %"compiler/scope:rel", ptr %l9, i32 0, i32 1
  %t99 = getelementptr { i64, [2 x i64] }, ptr %t98, i32 0, i32 1
  %t100 = getelementptr { i64 }, ptr %t99, i32 0, i32 0
  %t101 = load i64, ptr %t100
  %t102 = load i64, ptr %l5, !tbaa !24
  %t105 = icmp eq i64 %t101, %t102
  store i1 %t105, ptr %l69, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l69, !tbaa !21
  br label %bb25
bb25:
  %t107 = load i1, ptr %l69, !tbaa !21
  %t108 = xor i1 %t107, true
  br i1 %t108, label %bb26, label %bb27
bb26:
  br label %bb65
bb27:
  br label %bb28
bb28:
  %t110 = getelementptr %"compiler/scope:rel", ptr %l9, i32 0, i32 0
  %t111 = load { i64, [2 x i64] }, ptr %t110
  store { i64, [2 x i64] } %t111, ptr %l10
  %t113 = load { i64, [2 x i64] }, ptr %l10
  %t115 = extractvalue { i64, [2 x i64] } %t113, 0
  %t116 = icmp eq i64 %t115, 2
  br i1 %t116, label %bb29, label %bb30
bb29:
  %t118 = getelementptr { i64, [2 x i64] }, ptr %l10, i32 0, i32 1
  %t119 = getelementptr { i64 }, ptr %t118, i32 0, i32 0
  %t120 = load i64, ptr %t119
  store i64 %t120, ptr %l11, !tbaa !24
  br label %bb31
bb30:
  br label %bb59
bb31:
  store i64 0, ptr %l12, !tbaa !24
  %t122 = load ptr, ptr %l2, !tbaa !29
  %t124 = getelementptr %"compiler/typed:Call", ptr %t122, i32 0, i32 1
  %t125 = load { i64, ptr }, ptr %t124, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t125, 0
  store i64 %t127, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t129 = load i64, ptr %l13, !tbaa !24
  %t130 = load i64, ptr %l12, !tbaa !24
  %t133 = icmp sgt i64 %t129, %t130
  br i1 %t133, label %bb32, label %bb33
bb32:
  %t135 = load i64, ptr %l14, !tbaa !24
  %t137 = icmp sgt i64 %t135, 0
  br i1 %t137, label %bb34, label %bb35
bb33:
  store i64 0, ptr %l84, !tbaa !24
  br label %bb37
bb34:
  %t139 = load i64, ptr %l13, !tbaa !24
  %t140 = load i64, ptr %l12, !tbaa !24
  %t143 = sub i64 %t139, %t140
  %t144 = load i64, ptr %l14, !tbaa !24
  %t147 = add i64 %t143, %t144
  %t149 = sub i64 %t147, 1
  %t150 = load i64, ptr %l14, !tbaa !24
  %t153 = sdiv i64 %t149, %t150
  store i64 %t153, ptr %l87, !tbaa !24
  br label %bb36
bb35:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb36
bb36:
  %t155 = load i64, ptr %l87, !tbaa !24
  store i64 %t155, ptr %l84, !tbaa !24
  br label %bb37
bb37:
  %t156 = load i64, ptr %l84, !tbaa !24
  store i64 %t156, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb38
bb38:
  %t157 = load i64, ptr %l16, !tbaa !24
  %t158 = load i64, ptr %l15, !tbaa !24
  %t161 = icmp slt i64 %t157, %t158
  %t163 = xor i1 %t161, true
  br i1 %t163, label %bb39, label %bb40
bb39:
  br label %bb58
bb40:
  br label %bb41
bb41:
  %t165 = load i64, ptr %l12, !tbaa !24
  %t166 = load i64, ptr %l16, !tbaa !24
  %t167 = load i64, ptr %l14, !tbaa !24
  %t170 = mul i64 %t166, %t167
  %t173 = add i64 %t165, %t170
  store i64 %t173, ptr %l17, !tbaa !24
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/scope:Scoper", ptr %t175, i32 0, i32 0
  %t178 = load ptr, ptr %t177, !tbaa !29
  %t180 = getelementptr %"compiler/generic:Program", ptr %t178, i32 0, i32 2
  %t181 = load i32, ptr %l3, !tbaa !23
  %t182 = load i64, ptr %l17, !tbaa !24
  %t186 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t180, i32 %t181, i64 %t182)
  store i64 %t186, ptr %l110
  br label %bb42
bb42:
  %t187 = load i64, ptr %l110, !tbaa !24
  store i64 %t187, ptr %l18, !tbaa !24
  %t188 = load i64, ptr %l18, !tbaa !24
  %t190 = icmp sge i64 %t188, 0
  br i1 %t190, label %bb43, label %bb44
bb43:
  %t192 = load i64, ptr %l18, !tbaa !24
  store i64 %t192, ptr %l113, !tbaa !24
  br label %bb45
bb44:
  %t194 = load i64, ptr %l17, !tbaa !24
  store i64 %t194, ptr %l113, !tbaa !24
  br label %bb45
bb45:
  %t196 = load i64, ptr %l113, !tbaa !24
  store i64 %t196, ptr %l19, !tbaa !24
  %t197 = load i64, ptr %l11, !tbaa !24
  %t198 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t200 = extractvalue { i64, ptr } %t198, 0
  %t203 = icmp slt i64 %t197, %t200
  br i1 %t203, label %bb46, label %bb47
bb46:
  %t205 = load i64, ptr %l11, !tbaa !24
  %t207 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = getelementptr i64, ptr %t208, i64 %t205
  %t210 = load i64, ptr %t209, !tbaa !34
  %t211 = load i64, ptr %l19, !tbaa !24
  %t214 = icmp eq i64 %t210, %t211
  store i1 %t214, ptr %l120, !tbaa !21
  br label %bb48
bb47:
  store i1 false, ptr %l120, !tbaa !21
  br label %bb48
bb48:
  %t216 = load i1, ptr %l120, !tbaa !21
  br i1 %t216, label %bb49, label %bb50
bb49:
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l126, !tbaa !29
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t219 = load ptr, ptr %l2, !tbaa !29
  %t221 = getelementptr %"compiler/typed:Call", ptr %t219, i32 0, i32 1
  %t222 = load { i64, ptr }, ptr %t221, !tbaa !27
  store { i64, ptr } %t222, ptr %l129, !tbaa !27
  %t223 = load i64, ptr %l17, !tbaa !24
  %t225 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = getelementptr ptr, ptr %t226, i64 %t223
  %t228 = load ptr, ptr %t227, !tbaa !39
  %t232 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekTerm(ptr %v0, ptr %v1, ptr %t218, ptr %t228)
  store { i64, [2 x i64] } %t232, ptr %l133
  br label %bb51
bb50:
  store i1 false, ptr %l125, !tbaa !21
  br label %bb53
bb51:
  %t233 = load ptr, ptr %l126, !tbaa !29
  %t234 = load { i64, [2 x i64] }, ptr %l133
  %t235 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisBlock(ptr %v0, ptr %t233, { i64, [2 x i64] } %t234)
  store i1 %t235, ptr %l134
  br label %bb52
bb52:
  %t236 = load i1, ptr %l134, !tbaa !21
  store i1 %t236, ptr %l125, !tbaa !21
  br label %bb53
bb53:
  %t237 = load i1, ptr %l125, !tbaa !21
  br i1 %t237, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb55:
  br label %bb56
bb56:
  br label %bb57
bb57:
  %t239 = load i64, ptr %l16, !tbaa !24
  %t241 = add i64 %t239, 1
  store i64 %t241, ptr %l16, !tbaa !24
  br label %bb38
bb58:
  br label %bb64
bb59:
  br i1 true, label %bb60, label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_9d778c78f7953c66_3314afc5257f7cda)
  unreachable
bb64:
  br label %bb65
bb65:
  %t243 = load i64, ptr %l8, !tbaa !24
  %t245 = add i64 %t243, 1
  store i64 %t245, ptr %l8, !tbaa !24
  br label %bb17
bb66:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etraceAt(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l23 = alloca i32
  %l26 = alloca i1
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca { i64, ptr }
  %l40 = alloca i1
  %l41 = alloca { i64, ptr }
  %l55 = alloca i1
  %l56 = alloca { i64, ptr }
  %l67 = alloca i64
  %l70 = alloca i64
  %l88 = alloca { i64, ptr }
  %l96 = alloca i64
  %l97 = alloca { i64, ptr }
  %l98 = alloca i64
  %l99 = alloca i64
  %l100 = alloca i64
  %l105 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 10
  store ptr %t3, ptr %l14, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/scope:Scoper", ptr %t4, i32 0, i32 25
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_b5bf758209bf0a7b_bacb7224757f2cdf)
  unreachable
bb2:
  br label %bb3
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 25
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Body", ptr %t14, i32 0, i32 3
  %t18 = load i64, ptr %t17, !tbaa !24
  %t19 = load ptr, ptr %l14, !tbaa !29
  %t21 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v0, ptr %t19, i64 %t18)
  %t22 = extractvalue { i32, { i64, ptr } } %t21, 1
  %t23 = extractvalue { i32, { i64, ptr } } %t21, 0
  store i32 %t23, ptr %l23
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb5, label %ok.25, !prof !99
ok.25:
  store { i64, ptr } %t22, ptr %l22
  br label %bb4
bb4:
  %t26 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t26, ptr %l12, !tbaa !27
  br label %bb7
bb5:
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %l12, !tbaa !27
  br label %bb7
bb7:
  %t27 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t27, ptr %l2, !tbaa !27
  %t28 = load i32, ptr %l1, !tbaa !23
  %t30 = icmp slt i32 %t28, 0
  br i1 %t30, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb10
bb9:
  %t32 = load i32, ptr %l1, !tbaa !23
  %t34 = sext i32 %t32 to i64
  %t35 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t40 = icmp sgt i64 %t34, %t37
  store i1 %t40, ptr %l26, !tbaa !21
  br label %bb10
bb10:
  %t42 = load i1, ptr %l26, !tbaa !21
  br i1 %t42, label %bb11, label %bb12
bb11:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %l32, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t43, ptr %l33, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t44, 0
  store i64 %t45, ptr %l34, !tbaa !24
  %t46 = load i64, ptr %l34, !tbaa !24
  %t47 = mul i64 %t46, 1
  %t48 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  store { i64, ptr } %t50, ptr %l35, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = load i64, ptr %l34, !tbaa !24
  %t56 = mul i64 %t55, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t52, ptr %t54, i64 %t56, i1 false)
  %t57 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t57, ptr %l33, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t58 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t58, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t59 = load i32, ptr %l1, !tbaa !23
  %t61 = sext i32 %t59 to i64
  store i64 %t61, ptr %l3, !tbaa !24
  br label %bb14
bb14:
  %t63 = load i64, ptr %l3, !tbaa !24
  %t65 = icmp sgt i64 %t63, 0
  br i1 %t65, label %bb15, label %bb16
bb15:
  %t67 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t67, ptr %l41, !tbaa !27
  %t68 = load i64, ptr %l3, !tbaa !24
  %t70 = sub i64 %t68, 1
  %t72 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr i8, ptr %t73, i64 %t70
  %t75 = load i8, ptr %t74, !tbaa !32
  %t77 = icmp ne i8 %t75, 10
  store i1 %t77, ptr %l40, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb17
bb17:
  %t79 = load i1, ptr %l40, !tbaa !21
  %t80 = xor i1 %t79, true
  br i1 %t80, label %bb18, label %bb19
bb18:
  br label %bb22
bb19:
  br label %bb20
bb20:
  %t82 = load i64, ptr %l3, !tbaa !24
  %t84 = sub i64 %t82, 1
  store i64 %t84, ptr %l3, !tbaa !24
  br label %bb21
bb21:
  br label %bb14
bb22:
  %t86 = load i32, ptr %l1, !tbaa !23
  %t88 = sext i32 %t86 to i64
  store i64 %t88, ptr %l4, !tbaa !24
  br label %bb23
bb23:
  %t90 = load i64, ptr %l4, !tbaa !24
  %t91 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t91, 0
  %t96 = icmp slt i64 %t90, %t93
  br i1 %t96, label %bb24, label %bb25
bb24:
  %t98 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t98, ptr %l56, !tbaa !27
  %t99 = load i64, ptr %l4, !tbaa !24
  %t101 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr i8, ptr %t102, i64 %t99
  %t104 = load i8, ptr %t103, !tbaa !32
  %t106 = icmp ne i8 %t104, 10
  store i1 %t106, ptr %l55, !tbaa !21
  br label %bb26
bb25:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb26
bb26:
  %t108 = load i1, ptr %l55, !tbaa !21
  %t109 = xor i1 %t108, true
  br i1 %t109, label %bb27, label %bb28
bb27:
  br label %bb31
bb28:
  br label %bb29
bb29:
  %t111 = load i64, ptr %l4, !tbaa !24
  %t113 = add i64 %t111, 1
  store i64 %t113, ptr %l4, !tbaa !24
  br label %bb30
bb30:
  br label %bb23
bb31:
  store i64 1, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  %t115 = load i64, ptr %l3, !tbaa !24
  store i64 %t115, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t117 = load i64, ptr %l7, !tbaa !24
  %t118 = load i64, ptr %l6, !tbaa !24
  %t121 = icmp sgt i64 %t117, %t118
  br i1 %t121, label %bb32, label %bb33
bb32:
  %t123 = load i64, ptr %l8, !tbaa !24
  %t125 = icmp sgt i64 %t123, 0
  br i1 %t125, label %bb34, label %bb35
bb33:
  store i64 0, ptr %l67, !tbaa !24
  br label %bb37
bb34:
  %t127 = load i64, ptr %l7, !tbaa !24
  %t128 = load i64, ptr %l6, !tbaa !24
  %t131 = sub i64 %t127, %t128
  %t132 = load i64, ptr %l8, !tbaa !24
  %t135 = add i64 %t131, %t132
  %t137 = sub i64 %t135, 1
  %t138 = load i64, ptr %l8, !tbaa !24
  %t141 = sdiv i64 %t137, %t138
  store i64 %t141, ptr %l70, !tbaa !24
  br label %bb36
bb35:
  store i64 0, ptr %l70, !tbaa !24
  br label %bb36
bb36:
  %t143 = load i64, ptr %l70, !tbaa !24
  store i64 %t143, ptr %l67, !tbaa !24
  br label %bb37
bb37:
  %t144 = load i64, ptr %l67, !tbaa !24
  store i64 %t144, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb38
bb38:
  %t145 = load i64, ptr %l10, !tbaa !24
  %t146 = load i64, ptr %l9, !tbaa !24
  %t149 = icmp slt i64 %t145, %t146
  %t151 = xor i1 %t149, true
  br i1 %t151, label %bb39, label %bb40
bb39:
  br label %bb46
bb40:
  br label %bb41
bb41:
  %t153 = load i64, ptr %l6, !tbaa !24
  %t154 = load i64, ptr %l10, !tbaa !24
  %t155 = load i64, ptr %l8, !tbaa !24
  %t158 = mul i64 %t154, %t155
  %t161 = add i64 %t153, %t158
  %t163 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t163, ptr %l88, !tbaa !27
  %t166 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr i8, ptr %t167, i64 %t161
  %t169 = load i8, ptr %t168, !tbaa !32
  %t171 = icmp eq i8 %t169, 10
  br i1 %t171, label %bb42, label %bb43
bb42:
  %t173 = load i64, ptr %l5, !tbaa !24
  %t175 = add i64 %t173, 1
  store i64 %t175, ptr %l5, !tbaa !24
  br label %bb44
bb43:
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t177 = load i64, ptr %l10, !tbaa !24
  %t179 = add i64 %t177, 1
  store i64 %t179, ptr %l10, !tbaa !24
  br label %bb38
bb46:
  %t181 = load i64, ptr %l5, !tbaa !24
  store i64 %t181, ptr %l96, !tbaa !24
  %t182 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t182, ptr %l97, !tbaa !27
  %t183 = load i64, ptr %l3, !tbaa !24
  store i64 %t183, ptr %l98, !tbaa !24
  %t184 = load i64, ptr %l4, !tbaa !24
  store i64 %t184, ptr %l99, !tbaa !24
  %t185 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t186 = extractvalue { i64, ptr } %t185, 0
  store i64 %t186, ptr %l100, !tbaa !24
  %t187 = load i64, ptr %l98, !tbaa !24
  %t188 = icmp sge i64 %t187, 0
  br i1 %t188, label %bb47, label %bb48
bb47:
  %t190 = load i64, ptr %l98, !tbaa !24
  %t191 = load i64, ptr %l99, !tbaa !24
  %t192 = icmp sle i64 %t190, %t191
  br i1 %t192, label %bb49, label %bb50
bb48:
  call void @__olang_check_failed(ptr @olang_loc_f8a0ade9f5ab7564_a569fa0439998a48)
  unreachable
bb49:
  %t194 = load i64, ptr %l99, !tbaa !24
  %t195 = load i64, ptr %l100, !tbaa !24
  %t196 = icmp sle i64 %t194, %t195
  br i1 %t196, label %bb51, label %bb52
bb50:
  call void @__olang_check_failed(ptr @olang_loc_f8a0ade9f5ab7564_a569fa0439998a48)
  unreachable
bb51:
  %t198 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = load i64, ptr %l98, !tbaa !24
  %t201 = load i64, ptr %l99, !tbaa !24
  %t202 = getelementptr i8, ptr %t199, i64 %t200
  %t203 = sub i64 %t201, %t200
  %t204 = insertvalue { i64, ptr } undef, i64 %t203, 0
  %t205 = insertvalue { i64, ptr } %t204, ptr %t202, 1
  %t207 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %s0, { i64, ptr } %t205)
  store { i64, ptr } %t207, ptr %l105
  br label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_f8a0ade9f5ab7564_a569fa0439998a48)
  unreachable
bb53:
  %t208 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t209 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t210 = load i64, ptr %l96, !tbaa !24
  %t211 = call i64 @__olang_fmt_i64(ptr null, i64 %t210)
  %t212 = add i64 %t209, %t211
  %t213 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t214 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t215 = add i64 %t212, %t214
  %t216 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t217 = extractvalue { i64, ptr } %t216, 1
  %t218 = extractvalue { i64, ptr } %t216, 0
  %t219 = add i64 %t215, %t218
  %t220 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t219)
  call void @olang_textcopy(ptr %t220, ptr %t208, i64 %t209)
  %t221 = getelementptr i8, ptr %t220, i64 %t209
  %t222 = call i64 @__olang_fmt_i64(ptr %t221, i64 %t210)
  %t223 = getelementptr i8, ptr %t221, i64 %t211
  call void @olang_textcopy(ptr %t223, ptr %t213, i64 %t214)
  %t224 = getelementptr i8, ptr %t223, i64 %t214
  call void @olang_textcopy(ptr %t224, ptr %t217, i64 %t218)
  %t225 = insertvalue { i64, ptr } undef, i64 %t219, 0
  %t226 = insertvalue { i64, ptr } %t225, ptr %t220, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t226, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etransient(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l4 = alloca i64
  %l5 = alloca i1
  %l11 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l12 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l28 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l33 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load i64, ptr %l1, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t10 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t6, i64 %t7)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t10, ptr %l11
  br label %bb4
bb4:
  %t11 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l11
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t11, ptr %l3
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/scope:Scoper", ptr %t12, i32 0, i32 94
  %t15 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l3
  %t18 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t14, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t15)
  %t19 = extractvalue { i32, i64 } %t18, 1
  %t20 = extractvalue { i32, i64 } %t18, 0
  store i32 %t20, ptr %l17
  %t21 = icmp ne i32 %t20, 0
  br i1 %t21, label %bb6, label %ok.22, !prof !99
ok.22:
  store i64 %t19, ptr %l16
  br label %bb5
bb5:
  %t23 = load i64, ptr %l16, !tbaa !24
  store i64 %t23, ptr %l12, !tbaa !24
  br label %bb8
bb6:
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l12, !tbaa !24
  br label %bb8
bb8:
  %t24 = load i64, ptr %l12, !tbaa !24
  store i64 %t24, ptr %l4, !tbaa !24
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = icmp ne i64 %t25, 0
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t29 = load i64, ptr %l4, !tbaa !24
  %t31 = icmp eq i64 %t29, 3
  call void @__olang_scope_close(ptr %s0)
  store i1 %t31, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/scope:Scoper", ptr %t33, i32 0, i32 94
  %t36 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l3
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %t35, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t36, i64 1)
  br label %bb12
bb12:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load i64, ptr %l1, !tbaa !24
  %t41 = load i64, ptr %l2, !tbaa !24
  %t45 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etransientNow(ptr %v0, ptr %t39, i64 %t40, i64 %t41)
  store i1 %t45, ptr %l28
  br label %bb13
bb13:
  %t46 = load i1, ptr %l28, !tbaa !21
  store i1 %t46, ptr %l5, !tbaa !21
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/scope:Scoper", ptr %t47, i32 0, i32 94
  store ptr %t49, ptr %l30, !tbaa !29
  %t50 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l3
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t50, ptr %l31
  %t51 = load i1, ptr %l5, !tbaa !21
  br i1 %t51, label %bb14, label %bb15
bb14:
  store i64 3, ptr %l33, !tbaa !24
  br label %bb16
bb15:
  store i64 2, ptr %l33, !tbaa !24
  br label %bb16
bb16:
  %t53 = load ptr, ptr %l30, !tbaa !29
  %t54 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l31
  %t55 = load i64, ptr %l33, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %t53, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t54, i64 %t55)
  br label %bb17
bb17:
  %t56 = load i1, ptr %l5, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  store i1 %t56, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etryDefault(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i1
  %l21 = alloca { i64, ptr }
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 14
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb15
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Try", ptr %t16, i32 0, i32 1
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  store { i64, ptr } %t19, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l5, !tbaa !24
  br label %bb6
bb6:
  %t25 = load i64, ptr %l4, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb7, label %bb8
bb7:
  br label %bb14
bb8:
  br label %bb9
bb9:
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t33, ptr %l21, !tbaa !27
  %t34 = load i64, ptr %l4, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr ptr, ptr %t37, i64 %t34
  %t39 = load ptr, ptr %t38, !tbaa !39
  %t43 = getelementptr %"compiler/typed:Clause", ptr %t39, i32 0, i32 4
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t48 = icmp sgt i64 %t46, 0
  br i1 %t48, label %bb10, label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t51 = load i64, ptr %l4, !tbaa !24
  %t53 = add i64 %t51, 1
  store i64 %t53, ptr %l4, !tbaa !24
  br label %bb6
bb14:
  br label %bb20
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_3af8b11586f6b4c8_66242c1d15d5a764)
  unreachable
bb20:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExprs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l16 = alloca { i64, ptr }
  %l25 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a2, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l7, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l7, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t15, ptr %l16, !tbaa !27
  %t16 = load i64, ptr %l6, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  %t34 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %t21, i64 %a3, i64 %a4)
  store i1 %t34, ptr %l25
  br label %bb5
bb5:
  %t35 = load i1, ptr %l25, !tbaa !21
  %t36 = xor i1 %t35, true
  br i1 %t36, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l6, !tbaa !24
  %t41 = add i64 %t39, 1
  store i64 %t41, ptr %l6, !tbaa !24
  br label %bb1
bb10:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueStmt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l33 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca i1
  %l49 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l63 = alloca i1
  %l64 = alloca i1
  %l71 = alloca i1
  %l72 = alloca ptr
  %l73 = alloca i1
  %l84 = alloca i1
  %l85 = alloca ptr
  %l86 = alloca i1
  %l98 = alloca i1
  %l99 = alloca i1
  %l107 = alloca i1
  %l108 = alloca i1
  %l115 = alloca i1
  %l116 = alloca ptr
  %l117 = alloca i1
  %l130 = alloca i1
  %l131 = alloca i1
  %l137 = alloca i1
  %l138 = alloca ptr
  %l139 = alloca i1
  %l144 = alloca ptr
  %l145 = alloca i1
  %l155 = alloca i1
  %l156 = alloca ptr
  %l157 = alloca i1
  %l170 = alloca i1
  %l171 = alloca i1
  %l177 = alloca i1
  %l178 = alloca ptr
  %l179 = alloca i1
  %l189 = alloca i1
  %l190 = alloca ptr
  %l191 = alloca i1
  %l202 = alloca i1
  %l203 = alloca ptr
  %l204 = alloca i1
  %l215 = alloca i1
  %l216 = alloca ptr
  %l217 = alloca i1
  %l229 = alloca i1
  %l240 = alloca { i64, ptr }
  %l249 = alloca i1
  %l255 = alloca ptr
  %l256 = alloca i1
  %l261 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l269 = alloca i1
  %l279 = alloca { i64, ptr }
  %l289 = alloca i1
  %l301 = alloca i1
  %l312 = alloca { i64, ptr }
  %l321 = alloca i1
  %l327 = alloca ptr
  %l328 = alloca i1
  %l339 = alloca i1
  %s18 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t7 = load ptr, ptr %l37, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l37, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 17}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l38, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l38, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t17, i32 0, i32 2
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l5, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t23 = load ptr, ptr %l5, !tbaa !29
  %t25 = load i64, ptr %l3, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  %t32 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t21, ptr %t22, ptr %t23, i64 %t25, i64 %t26)
  store i1 %t32, ptr %l49
  br label %bb9
bb9:
  %t33 = load i1, ptr %l49, !tbaa !21
  store i1 %t33, ptr %rv
  br label %ret
bb10:
  %t34 = load ptr, ptr %l2, !tbaa !29
  store ptr %t34, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t35 = load ptr, ptr %l50, !tbaa !29
  %t36 = icmp ne ptr %t35, null
  br i1 %t36, label %bb11, label %bb12
bb11:
  %t38 = load ptr, ptr %l50, !tbaa !29
  %t39 = load i64, ptr %t38, !range !{i64 0, i64 17}
  %t41 = icmp eq i64 %t39, 1
  store i1 %t41, ptr %l51, !tbaa !21
  br label %bb12
bb12:
  %t42 = load i1, ptr %l51, !tbaa !21
  br i1 %t42, label %bb13, label %bb14
bb13:
  %t43 = load ptr, ptr %l2, !tbaa !29
  %t45 = getelementptr { i64, [3 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t45, i32 0, i32 1
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l6, !tbaa !29
  %t49 = load ptr, ptr %l2, !tbaa !29
  %t51 = getelementptr { i64, [3 x i64] }, ptr %t49, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t51, i32 0, i32 2
  %t53 = load ptr, ptr %t52
  store ptr %t53, ptr %l7, !tbaa !29
  br label %bb15
bb14:
  br label %bb21
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t57 = load ptr, ptr %l6, !tbaa !29
  %t58 = load i64, ptr %l3, !tbaa !24
  %t59 = load i64, ptr %l4, !tbaa !24
  %t65 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2euePlace(ptr %v0, ptr %v1, ptr %v2, ptr %t55, ptr %t56, ptr %t57, i64 %t58, i64 %t59)
  store i1 %t65, ptr %l63
  br label %bb16
bb16:
  %t66 = load i1, ptr %l63, !tbaa !21
  br i1 %t66, label %bb17, label %bb18
bb17:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t69 = load ptr, ptr %l7, !tbaa !29
  %t71 = load i64, ptr %l3, !tbaa !24
  %t72 = load i64, ptr %l4, !tbaa !24
  %t78 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t67, ptr %t68, ptr %t69, i64 %t71, i64 %t72)
  store i1 %t78, ptr %l71
  br label %bb19
bb18:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb20
bb19:
  %t79 = load i1, ptr %l71, !tbaa !21
  store i1 %t79, ptr %l64, !tbaa !21
  br label %bb20
bb20:
  %t80 = load i1, ptr %l64, !tbaa !21
  store i1 %t80, ptr %rv
  br label %ret
bb21:
  %t81 = load ptr, ptr %l2, !tbaa !29
  store ptr %t81, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t82 = load ptr, ptr %l72, !tbaa !29
  %t83 = icmp ne ptr %t82, null
  br i1 %t83, label %bb22, label %bb23
bb22:
  %t85 = load ptr, ptr %l72, !tbaa !29
  %t86 = load i64, ptr %t85, !range !{i64 0, i64 17}
  %t88 = icmp eq i64 %t86, 2
  store i1 %t88, ptr %l73, !tbaa !21
  br label %bb23
bb23:
  %t89 = load i1, ptr %l73, !tbaa !21
  br i1 %t89, label %bb24, label %bb25
bb24:
  %t90 = load ptr, ptr %l2, !tbaa !29
  %t92 = getelementptr { i64, [3 x i64] }, ptr %t90, i32 0, i32 1
  %t93 = getelementptr { %"compiler/source:Span", ptr }, ptr %t92, i32 0, i32 1
  %t94 = load ptr, ptr %t93
  store ptr %t94, ptr %l8, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t98 = load ptr, ptr %l8, !tbaa !29
  %t100 = load i64, ptr %l3, !tbaa !24
  %t101 = load i64, ptr %l4, !tbaa !24
  %t107 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t96, ptr %t97, ptr %t98, i64 %t100, i64 %t101)
  store i1 %t107, ptr %l84
  br label %bb27
bb27:
  %t108 = load i1, ptr %l84, !tbaa !21
  store i1 %t108, ptr %rv
  br label %ret
bb28:
  %t109 = load ptr, ptr %l2, !tbaa !29
  store ptr %t109, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t110 = load ptr, ptr %l85, !tbaa !29
  %t111 = icmp ne ptr %t110, null
  br i1 %t111, label %bb29, label %bb30
bb29:
  %t113 = load ptr, ptr %l85, !tbaa !29
  %t114 = load i64, ptr %t113, !range !{i64 0, i64 17}
  %t116 = icmp eq i64 %t114, 3
  store i1 %t116, ptr %l86, !tbaa !21
  br label %bb30
bb30:
  %t117 = load i1, ptr %l86, !tbaa !21
  br i1 %t117, label %bb31, label %bb32
bb31:
  %t118 = load ptr, ptr %l2, !tbaa !29
  %t120 = getelementptr { i64, [3 x i64] }, ptr %t118, i32 0, i32 1
  %t121 = getelementptr { %"compiler/source:Span", ptr }, ptr %t120, i32 0, i32 1
  %t122 = load ptr, ptr %t121
  store ptr %t122, ptr %l9, !tbaa !29
  br label %bb33
bb32:
  br label %bb43
bb33:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load ptr, ptr %l1, !tbaa !29
  %t126 = load ptr, ptr %l9, !tbaa !29
  %t128 = getelementptr %"compiler/typed:If", ptr %t126, i32 0, i32 0
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = load i64, ptr %l3, !tbaa !24
  %t132 = load i64, ptr %l4, !tbaa !24
  %t138 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t124, ptr %t125, ptr %t129, i64 %t131, i64 %t132)
  store i1 %t138, ptr %l98
  br label %bb34
bb34:
  %t139 = load i1, ptr %l98, !tbaa !21
  br i1 %t139, label %bb35, label %bb36
bb35:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load ptr, ptr %l1, !tbaa !29
  %t142 = load ptr, ptr %l9, !tbaa !29
  %t144 = getelementptr %"compiler/typed:If", ptr %t142, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !29
  %t147 = load i64, ptr %l3, !tbaa !24
  %t148 = load i64, ptr %l4, !tbaa !24
  %t154 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueBlock(ptr %v0, ptr %v1, ptr %v2, ptr %t140, ptr %t141, ptr %t145, i64 %t147, i64 %t148)
  store i1 %t154, ptr %l107
  br label %bb37
bb36:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb38
bb37:
  %t155 = load i1, ptr %l107, !tbaa !21
  store i1 %t155, ptr %l99, !tbaa !21
  br label %bb38
bb38:
  %t156 = load i1, ptr %l99, !tbaa !21
  br i1 %t156, label %bb39, label %bb40
bb39:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load ptr, ptr %l1, !tbaa !29
  %t159 = load ptr, ptr %l9, !tbaa !29
  %t161 = getelementptr %"compiler/typed:If", ptr %t159, i32 0, i32 2
  %t162 = load ptr, ptr %t161, !tbaa !29
  %t163 = load i64, ptr %l3, !tbaa !24
  %t164 = load i64, ptr %l4, !tbaa !24
  %t170 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueBlock(ptr %v0, ptr %v1, ptr %v2, ptr %t157, ptr %t158, ptr %t162, i64 %t163, i64 %t164)
  store i1 %t170, ptr %l115
  br label %bb41
bb40:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb42
bb41:
  %t171 = load i1, ptr %l115, !tbaa !21
  store i1 %t171, ptr %l108, !tbaa !21
  br label %bb42
bb42:
  %t172 = load i1, ptr %l108, !tbaa !21
  store i1 %t172, ptr %rv
  br label %ret
bb43:
  %t173 = load ptr, ptr %l2, !tbaa !29
  store ptr %t173, ptr %l116, !tbaa !29
  store i1 false, ptr %l117, !tbaa !21
  %t174 = load ptr, ptr %l116, !tbaa !29
  %t175 = icmp ne ptr %t174, null
  br i1 %t175, label %bb44, label %bb45
bb44:
  %t177 = load ptr, ptr %l116, !tbaa !29
  %t178 = load i64, ptr %t177, !range !{i64 0, i64 17}
  %t180 = icmp eq i64 %t178, 4
  store i1 %t180, ptr %l117, !tbaa !21
  br label %bb45
bb45:
  %t181 = load i1, ptr %l117, !tbaa !21
  br i1 %t181, label %bb46, label %bb47
bb46:
  %t182 = load ptr, ptr %l2, !tbaa !29
  %t184 = getelementptr { i64, [3 x i64] }, ptr %t182, i32 0, i32 1
  %t185 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t184, i32 0, i32 1
  %t186 = load ptr, ptr %t185
  store ptr %t186, ptr %l10, !tbaa !29
  %t188 = load ptr, ptr %l2, !tbaa !29
  %t190 = getelementptr { i64, [3 x i64] }, ptr %t188, i32 0, i32 1
  %t191 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t190, i32 0, i32 2
  %t192 = load ptr, ptr %t191
  store ptr %t192, ptr %l11, !tbaa !29
  br label %bb48
bb47:
  br label %bb54
bb48:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t196 = load ptr, ptr %l10, !tbaa !29
  %t198 = load i64, ptr %l3, !tbaa !24
  %t199 = load i64, ptr %l4, !tbaa !24
  %t205 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueBlock(ptr %v0, ptr %v1, ptr %v2, ptr %t194, ptr %t195, ptr %t196, i64 %t198, i64 %t199)
  store i1 %t205, ptr %l130
  br label %bb49
bb49:
  %t206 = load i1, ptr %l130, !tbaa !21
  br i1 %t206, label %bb50, label %bb51
bb50:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load ptr, ptr %l1, !tbaa !29
  %t209 = load ptr, ptr %l11, !tbaa !29
  %t210 = load i64, ptr %l3, !tbaa !24
  %t211 = load i64, ptr %l4, !tbaa !24
  %t217 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueBlock(ptr %v0, ptr %v1, ptr %v2, ptr %t207, ptr %t208, ptr %t209, i64 %t210, i64 %t211)
  store i1 %t217, ptr %l137
  br label %bb52
bb51:
  store i1 false, ptr %l131, !tbaa !21
  br label %bb53
bb52:
  %t218 = load i1, ptr %l137, !tbaa !21
  store i1 %t218, ptr %l131, !tbaa !21
  br label %bb53
bb53:
  %t219 = load i1, ptr %l131, !tbaa !21
  store i1 %t219, ptr %rv
  br label %ret
bb54:
  %t220 = load ptr, ptr %l2, !tbaa !29
  store ptr %t220, ptr %l138, !tbaa !29
  store i1 false, ptr %l139, !tbaa !21
  %t221 = load ptr, ptr %l138, !tbaa !29
  %t222 = icmp ne ptr %t221, null
  br i1 %t222, label %bb55, label %bb56
bb55:
  %t224 = load ptr, ptr %l138, !tbaa !29
  %t225 = load i64, ptr %t224, !range !{i64 0, i64 17}
  %t227 = icmp eq i64 %t225, 6
  store i1 %t227, ptr %l139, !tbaa !21
  br label %bb56
bb56:
  %t228 = load i1, ptr %l139, !tbaa !21
  br i1 %t228, label %bb57, label %bb58
bb57:
  %t229 = load ptr, ptr %l2, !tbaa !29
  %t231 = getelementptr { i64, [3 x i64] }, ptr %t229, i32 0, i32 1
  %t232 = getelementptr { %"compiler/source:Span", ptr }, ptr %t231, i32 0, i32 1
  %t233 = load ptr, ptr %t232
  store ptr %t233, ptr %l12, !tbaa !29
  br label %bb63
bb58:
  %t235 = load ptr, ptr %l2, !tbaa !29
  store ptr %t235, ptr %l144, !tbaa !29
  store i1 false, ptr %l145, !tbaa !21
  %t236 = load ptr, ptr %l144, !tbaa !29
  %t237 = icmp ne ptr %t236, null
  br i1 %t237, label %bb59, label %bb60
bb59:
  %t239 = load ptr, ptr %l144, !tbaa !29
  %t240 = load i64, ptr %t239, !range !{i64 0, i64 17}
  %t242 = icmp eq i64 %t240, 16
  store i1 %t242, ptr %l145, !tbaa !21
  br label %bb60
bb60:
  %t243 = load i1, ptr %l145, !tbaa !21
  br i1 %t243, label %bb61, label %bb62
bb61:
  %t244 = load ptr, ptr %l2, !tbaa !29
  %t246 = getelementptr { i64, [3 x i64] }, ptr %t244, i32 0, i32 1
  %t247 = getelementptr { %"compiler/source:Span", ptr }, ptr %t246, i32 0, i32 1
  %t248 = load ptr, ptr %t247
  store ptr %t248, ptr %l12, !tbaa !29
  br label %bb63
bb62:
  br label %bb65
bb63:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load ptr, ptr %l1, !tbaa !29
  %t252 = load ptr, ptr %l12, !tbaa !29
  %t253 = load i64, ptr %l3, !tbaa !24
  %t254 = load i64, ptr %l4, !tbaa !24
  %t260 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t250, ptr %t251, ptr %t252, i64 %t253, i64 %t254)
  store i1 %t260, ptr %l155
  br label %bb64
bb64:
  %t261 = load i1, ptr %l155, !tbaa !21
  store i1 %t261, ptr %rv
  br label %ret
bb65:
  %t262 = load ptr, ptr %l2, !tbaa !29
  store ptr %t262, ptr %l156, !tbaa !29
  store i1 false, ptr %l157, !tbaa !21
  %t263 = load ptr, ptr %l156, !tbaa !29
  %t264 = icmp ne ptr %t263, null
  br i1 %t264, label %bb66, label %bb67
bb66:
  %t266 = load ptr, ptr %l156, !tbaa !29
  %t267 = load i64, ptr %t266, !range !{i64 0, i64 17}
  %t269 = icmp eq i64 %t267, 10
  store i1 %t269, ptr %l157, !tbaa !21
  br label %bb67
bb67:
  %t270 = load i1, ptr %l157, !tbaa !21
  br i1 %t270, label %bb68, label %bb69
bb68:
  %t271 = load ptr, ptr %l2, !tbaa !29
  %t273 = getelementptr { i64, [3 x i64] }, ptr %t271, i32 0, i32 1
  %t274 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t273, i32 0, i32 1
  %t275 = load ptr, ptr %t274
  store ptr %t275, ptr %l13, !tbaa !29
  %t277 = load ptr, ptr %l2, !tbaa !29
  %t279 = getelementptr { i64, [3 x i64] }, ptr %t277, i32 0, i32 1
  %t280 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t279, i32 0, i32 2
  %t281 = load ptr, ptr %t280
  store ptr %t281, ptr %l14, !tbaa !29
  br label %bb70
bb69:
  br label %bb76
bb70:
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t284 = load ptr, ptr %l1, !tbaa !29
  %t285 = load ptr, ptr %l13, !tbaa !29
  %t287 = load i64, ptr %l3, !tbaa !24
  %t288 = load i64, ptr %l4, !tbaa !24
  %t294 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t283, ptr %t284, ptr %t285, i64 %t287, i64 %t288)
  store i1 %t294, ptr %l170
  br label %bb71
bb71:
  %t295 = load i1, ptr %l170, !tbaa !21
  br i1 %t295, label %bb72, label %bb73
bb72:
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t297 = load ptr, ptr %l1, !tbaa !29
  %t298 = load ptr, ptr %l14, !tbaa !29
  %t299 = load i64, ptr %l3, !tbaa !24
  %t300 = load i64, ptr %l4, !tbaa !24
  %t306 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t296, ptr %t297, ptr %t298, i64 %t299, i64 %t300)
  store i1 %t306, ptr %l177
  br label %bb74
bb73:
  store i1 false, ptr %l171, !tbaa !21
  br label %bb75
bb74:
  %t307 = load i1, ptr %l177, !tbaa !21
  store i1 %t307, ptr %l171, !tbaa !21
  br label %bb75
bb75:
  %t308 = load i1, ptr %l171, !tbaa !21
  store i1 %t308, ptr %rv
  br label %ret
bb76:
  %t309 = load ptr, ptr %l2, !tbaa !29
  store ptr %t309, ptr %l178, !tbaa !29
  store i1 false, ptr %l179, !tbaa !21
  %t310 = load ptr, ptr %l178, !tbaa !29
  %t311 = icmp ne ptr %t310, null
  br i1 %t311, label %bb77, label %bb78
bb77:
  %t313 = load ptr, ptr %l178, !tbaa !29
  %t314 = load i64, ptr %t313, !range !{i64 0, i64 17}
  %t316 = icmp eq i64 %t314, 9
  store i1 %t316, ptr %l179, !tbaa !21
  br label %bb78
bb78:
  %t317 = load i1, ptr %l179, !tbaa !21
  br i1 %t317, label %bb79, label %bb80
bb79:
  %t318 = load ptr, ptr %l2, !tbaa !29
  %t320 = getelementptr { i64, [3 x i64] }, ptr %t318, i32 0, i32 1
  %t321 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t320, i32 0, i32 2
  %t322 = load ptr, ptr %t321
  store ptr %t322, ptr %l15, !tbaa !29
  br label %bb81
bb80:
  br label %bb83
bb81:
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t325 = load ptr, ptr %l1, !tbaa !29
  %t326 = load ptr, ptr %l15, !tbaa !29
  %t327 = load i64, ptr %l3, !tbaa !24
  %t328 = load i64, ptr %l4, !tbaa !24
  %t334 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t324, ptr %t325, ptr %t326, i64 %t327, i64 %t328)
  store i1 %t334, ptr %l189
  br label %bb82
bb82:
  %t335 = load i1, ptr %l189, !tbaa !21
  store i1 %t335, ptr %rv
  br label %ret
bb83:
  %t336 = load ptr, ptr %l2, !tbaa !29
  store ptr %t336, ptr %l190, !tbaa !29
  store i1 false, ptr %l191, !tbaa !21
  %t337 = load ptr, ptr %l190, !tbaa !29
  %t338 = icmp ne ptr %t337, null
  br i1 %t338, label %bb84, label %bb85
bb84:
  %t340 = load ptr, ptr %l190, !tbaa !29
  %t341 = load i64, ptr %t340, !range !{i64 0, i64 17}
  %t343 = icmp eq i64 %t341, 11
  store i1 %t343, ptr %l191, !tbaa !21
  br label %bb85
bb85:
  %t344 = load i1, ptr %l191, !tbaa !21
  br i1 %t344, label %bb86, label %bb87
bb86:
  %t345 = load ptr, ptr %l2, !tbaa !29
  %t347 = getelementptr { i64, [3 x i64] }, ptr %t345, i32 0, i32 1
  %t348 = getelementptr { %"compiler/source:Span", ptr }, ptr %t347, i32 0, i32 1
  %t349 = load ptr, ptr %t348
  store ptr %t349, ptr %l16, !tbaa !29
  br label %bb88
bb87:
  br label %bb90
bb88:
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t352 = load ptr, ptr %l1, !tbaa !29
  %t353 = load ptr, ptr %l16, !tbaa !29
  %t355 = load i64, ptr %l3, !tbaa !24
  %t356 = load i64, ptr %l4, !tbaa !24
  %t362 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueBlock(ptr %v0, ptr %v1, ptr %v2, ptr %t351, ptr %t352, ptr %t353, i64 %t355, i64 %t356)
  store i1 %t362, ptr %l202
  br label %bb89
bb89:
  %t363 = load i1, ptr %l202, !tbaa !21
  store i1 %t363, ptr %rv
  br label %ret
bb90:
  %t364 = load ptr, ptr %l2, !tbaa !29
  store ptr %t364, ptr %l203, !tbaa !29
  store i1 false, ptr %l204, !tbaa !21
  %t365 = load ptr, ptr %l203, !tbaa !29
  %t366 = icmp ne ptr %t365, null
  br i1 %t366, label %bb91, label %bb92
bb91:
  %t368 = load ptr, ptr %l203, !tbaa !29
  %t369 = load i64, ptr %t368, !range !{i64 0, i64 17}
  %t371 = icmp eq i64 %t369, 12
  store i1 %t371, ptr %l204, !tbaa !21
  br label %bb92
bb92:
  %t372 = load i1, ptr %l204, !tbaa !21
  br i1 %t372, label %bb93, label %bb94
bb93:
  %t373 = load ptr, ptr %l2, !tbaa !29
  %t375 = getelementptr { i64, [3 x i64] }, ptr %t373, i32 0, i32 1
  %t376 = getelementptr { %"compiler/source:Span", ptr }, ptr %t375, i32 0, i32 1
  %t377 = load ptr, ptr %t376
  store ptr %t377, ptr %l17, !tbaa !29
  br label %bb95
bb94:
  br label %bb97
bb95:
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t380 = load ptr, ptr %l1, !tbaa !29
  %t381 = load ptr, ptr %l17, !tbaa !29
  %t383 = load i64, ptr %l3, !tbaa !24
  %t384 = load i64, ptr %l4, !tbaa !24
  %t390 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueBlock(ptr %v0, ptr %v1, ptr %v2, ptr %t379, ptr %t380, ptr %t381, i64 %t383, i64 %t384)
  store i1 %t390, ptr %l215
  br label %bb96
bb96:
  %t391 = load i1, ptr %l215, !tbaa !21
  store i1 %t391, ptr %rv
  br label %ret
bb97:
  %t392 = load ptr, ptr %l2, !tbaa !29
  store ptr %t392, ptr %l216, !tbaa !29
  store i1 false, ptr %l217, !tbaa !21
  %t393 = load ptr, ptr %l216, !tbaa !29
  %t394 = icmp ne ptr %t393, null
  br i1 %t394, label %bb98, label %bb99
bb98:
  %t396 = load ptr, ptr %l216, !tbaa !29
  %t397 = load i64, ptr %t396, !range !{i64 0, i64 17}
  %t399 = icmp eq i64 %t397, 13
  store i1 %t399, ptr %l217, !tbaa !21
  br label %bb99
bb99:
  %t400 = load i1, ptr %l217, !tbaa !21
  br i1 %t400, label %bb100, label %bb101
bb100:
  %t401 = load ptr, ptr %l2, !tbaa !29
  %t403 = getelementptr { i64, [3 x i64] }, ptr %t401, i32 0, i32 1
  %t404 = getelementptr { %"compiler/source:Span", ptr }, ptr %t403, i32 0, i32 1
  %t405 = load ptr, ptr %t404
  store ptr %t405, ptr %l18, !tbaa !29
  br label %bb102
bb101:
  br label %bb117
bb102:
  %t407 = load ptr, ptr %l0, !tbaa !29
  %t408 = load ptr, ptr %l1, !tbaa !29
  %t409 = load ptr, ptr %l18, !tbaa !29
  %t411 = getelementptr %"compiler/typed:Join", ptr %t409, i32 0, i32 0
  %t412 = load ptr, ptr %t411, !tbaa !29
  %t414 = load i64, ptr %l3, !tbaa !24
  %t415 = load i64, ptr %l4, !tbaa !24
  %t421 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueBlock(ptr %v0, ptr %v1, ptr %v2, ptr %t407, ptr %t408, ptr %t412, i64 %t414, i64 %t415)
  store i1 %t421, ptr %l229
  br label %bb103
bb103:
  %t422 = load i1, ptr %l229, !tbaa !21
  %t423 = xor i1 %t422, true
  br i1 %t423, label %bb104, label %bb105
bb104:
  store i1 false, ptr %rv
  br label %ret
bb105:
  br label %bb106
bb106:
  %t426 = load ptr, ptr %l18, !tbaa !29
  %t428 = getelementptr %"compiler/typed:Join", ptr %t426, i32 0, i32 2
  %t429 = load { i64, ptr }, ptr %t428, !tbaa !27
  store { i64, ptr } %t429, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t431 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t433 = extractvalue { i64, ptr } %t431, 0
  store i64 %t433, ptr %l21, !tbaa !24
  br label %bb107
bb107:
  %t435 = load i64, ptr %l20, !tbaa !24
  %t436 = load i64, ptr %l21, !tbaa !24
  %t439 = icmp slt i64 %t435, %t436
  %t441 = xor i1 %t439, true
  br i1 %t441, label %bb108, label %bb109
bb108:
  br label %bb116
bb109:
  br label %bb110
bb110:
  %t443 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t443, ptr %l240, !tbaa !27
  %t444 = load i64, ptr %l20, !tbaa !24
  %t446 = getelementptr { i64, ptr }, ptr %l240, i32 0, i32 1
  %t447 = load ptr, ptr %t446, !tbaa !27
  %t448 = getelementptr ptr, ptr %t447, i64 %t444
  %t449 = load ptr, ptr %t448, !tbaa !39
  %t451 = load ptr, ptr %l0, !tbaa !29
  %t452 = load ptr, ptr %l1, !tbaa !29
  %t455 = getelementptr %"compiler/typed:Clause", ptr %t449, i32 0, i32 3
  %t456 = load ptr, ptr %t455, !tbaa !29
  %t457 = load i64, ptr %l3, !tbaa !24
  %t458 = load i64, ptr %l4, !tbaa !24
  %t464 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueBlock(ptr %v0, ptr %v1, ptr %v2, ptr %t451, ptr %t452, ptr %t456, i64 %t457, i64 %t458)
  store i1 %t464, ptr %l249
  br label %bb111
bb111:
  %t465 = load i1, ptr %l249, !tbaa !21
  %t466 = xor i1 %t465, true
  br i1 %t466, label %bb112, label %bb113
bb112:
  store i1 false, ptr %rv
  br label %ret
bb113:
  br label %bb114
bb114:
  br label %bb115
bb115:
  %t469 = load i64, ptr %l20, !tbaa !24
  %t471 = add i64 %t469, 1
  store i64 %t471, ptr %l20, !tbaa !24
  br label %bb107
bb116:
  store i1 true, ptr %rv
  br label %ret
bb117:
  %t474 = load ptr, ptr %l2, !tbaa !29
  store ptr %t474, ptr %l255, !tbaa !29
  store i1 false, ptr %l256, !tbaa !21
  %t475 = load ptr, ptr %l255, !tbaa !29
  %t476 = icmp ne ptr %t475, null
  br i1 %t476, label %bb118, label %bb119
bb118:
  %t478 = load ptr, ptr %l255, !tbaa !29
  %t479 = load i64, ptr %t478, !range !{i64 0, i64 17}
  %t481 = icmp eq i64 %t479, 14
  store i1 %t481, ptr %l256, !tbaa !21
  br label %bb119
bb119:
  %t482 = load i1, ptr %l256, !tbaa !21
  br i1 %t482, label %bb120, label %bb121
bb120:
  %t483 = load ptr, ptr %l2, !tbaa !29
  %t485 = getelementptr { i64, [3 x i64] }, ptr %t483, i32 0, i32 1
  %t486 = getelementptr { %"compiler/source:Span", ptr }, ptr %t485, i32 0, i32 1
  %t487 = load ptr, ptr %t486
  store ptr %t487, ptr %l23, !tbaa !29
  br label %bb122
bb121:
  br label %bb156
bb122:
  store %olang.scope zeroinitializer, ptr %s18
  %t489 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s18, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t489, ptr %l261
  br label %bb123
bb123:
  %t490 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l261
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t490, ptr %l24
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t492 = load ptr, ptr %l23, !tbaa !29
  %t494 = getelementptr %"compiler/typed:Spawn", ptr %t492, i32 0, i32 1
  %t495 = load ptr, ptr %t494, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v2, ptr %s18, ptr %t491, ptr %t495, ptr %l24)
  br label %bb124
bb124:
  %t500 = load i64, ptr %l3, !tbaa !24
  %t503 = call i1 @compiler_2fscope_2eflHas(ptr %s18, ptr %l24, i64 %t500)
  store i1 %t503, ptr %l269
  br label %bb125
bb125:
  %t504 = load i1, ptr %l269, !tbaa !21
  br i1 %t504, label %bb126, label %bb127
bb126:
  call void @__olang_scope_close(ptr %s18)
  store i1 false, ptr %rv
  br label %ret
bb127:
  br label %bb128
bb128:
  %t506 = load ptr, ptr %l23, !tbaa !29
  %t508 = getelementptr %"compiler/typed:Spawn", ptr %t506, i32 0, i32 0
  %t509 = load { i64, ptr }, ptr %t508, !tbaa !27
  store { i64, ptr } %t509, ptr %l25, !tbaa !27
  store i64 0, ptr %l26, !tbaa !24
  %t511 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t513 = extractvalue { i64, ptr } %t511, 0
  store i64 %t513, ptr %l27, !tbaa !24
  br label %bb129
bb129:
  %t515 = load i64, ptr %l26, !tbaa !24
  %t516 = load i64, ptr %l27, !tbaa !24
  %t519 = icmp slt i64 %t515, %t516
  %t521 = xor i1 %t519, true
  br i1 %t521, label %bb130, label %bb131
bb130:
  br label %bb141
bb131:
  br label %bb132
bb132:
  %t523 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t523, ptr %l279, !tbaa !27
  %t524 = load i64, ptr %l26, !tbaa !24
  %t526 = getelementptr { i64, ptr }, ptr %l279, i32 0, i32 1
  %t527 = load ptr, ptr %t526, !tbaa !27
  %t528 = getelementptr ptr, ptr %t527, i64 %t524
  %t529 = load ptr, ptr %t528, !tbaa !39
  store ptr %t529, ptr %l28, !tbaa !29
  %t531 = load ptr, ptr %l28, !tbaa !29
  %t533 = icmp eq ptr %t531, null
  br i1 %t533, label %bb133, label %bb134
bb133:
  br label %bb140
bb134:
  br label %bb135
bb135:
  %t535 = load ptr, ptr %l0, !tbaa !29
  %t536 = load ptr, ptr %l1, !tbaa !29
  %t537 = load ptr, ptr %l28, !tbaa !29
  %t538 = load i64, ptr %l3, !tbaa !24
  %t539 = load i64, ptr %l4, !tbaa !24
  %t545 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2euePlace(ptr %v0, ptr %v1, ptr %v2, ptr %t535, ptr %t536, ptr %t537, i64 %t538, i64 %t539)
  store i1 %t545, ptr %l289
  br label %bb136
bb136:
  %t546 = load i1, ptr %l289, !tbaa !21
  %t547 = xor i1 %t546, true
  br i1 %t547, label %bb137, label %bb138
bb137:
  call void @__olang_scope_close(ptr %s18)
  store i1 false, ptr %rv
  br label %ret
bb138:
  br label %bb139
bb139:
  br label %bb140
bb140:
  %t550 = load i64, ptr %l26, !tbaa !24
  %t552 = add i64 %t550, 1
  store i64 %t552, ptr %l26, !tbaa !24
  br label %bb129
bb141:
  %t554 = load ptr, ptr %l0, !tbaa !29
  %t555 = load ptr, ptr %l1, !tbaa !29
  %t556 = load ptr, ptr %l23, !tbaa !29
  %t558 = getelementptr %"compiler/typed:Spawn", ptr %t556, i32 0, i32 1
  %t559 = load ptr, ptr %t558, !tbaa !29
  %t561 = load i64, ptr %l3, !tbaa !24
  %t562 = load i64, ptr %l4, !tbaa !24
  %t568 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t554, ptr %t555, ptr %t559, i64 %t561, i64 %t562)
  store i1 %t568, ptr %l301
  br label %bb142
bb142:
  %t569 = load i1, ptr %l301, !tbaa !21
  %t570 = xor i1 %t569, true
  br i1 %t570, label %bb143, label %bb144
bb143:
  call void @__olang_scope_close(ptr %s18)
  store i1 false, ptr %rv
  br label %ret
bb144:
  br label %bb145
bb145:
  %t573 = load ptr, ptr %l23, !tbaa !29
  %t575 = getelementptr %"compiler/typed:Spawn", ptr %t573, i32 0, i32 2
  %t576 = load { i64, ptr }, ptr %t575, !tbaa !27
  store { i64, ptr } %t576, ptr %l29, !tbaa !27
  store i64 0, ptr %l30, !tbaa !24
  %t578 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t580 = extractvalue { i64, ptr } %t578, 0
  store i64 %t580, ptr %l31, !tbaa !24
  br label %bb146
bb146:
  %t582 = load i64, ptr %l30, !tbaa !24
  %t583 = load i64, ptr %l31, !tbaa !24
  %t586 = icmp slt i64 %t582, %t583
  %t588 = xor i1 %t586, true
  br i1 %t588, label %bb147, label %bb148
bb147:
  br label %bb155
bb148:
  br label %bb149
bb149:
  %t590 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t590, ptr %l312, !tbaa !27
  %t591 = load i64, ptr %l30, !tbaa !24
  %t593 = getelementptr { i64, ptr }, ptr %l312, i32 0, i32 1
  %t594 = load ptr, ptr %t593, !tbaa !27
  %t595 = getelementptr ptr, ptr %t594, i64 %t591
  %t596 = load ptr, ptr %t595, !tbaa !39
  %t598 = load ptr, ptr %l0, !tbaa !29
  %t599 = load ptr, ptr %l1, !tbaa !29
  %t602 = getelementptr %"compiler/typed:TaskClause", ptr %t596, i32 0, i32 3
  %t603 = load ptr, ptr %t602, !tbaa !29
  %t604 = load i64, ptr %l3, !tbaa !24
  %t605 = load i64, ptr %l4, !tbaa !24
  %t611 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t598, ptr %t599, ptr %t603, i64 %t604, i64 %t605)
  store i1 %t611, ptr %l321
  br label %bb150
bb150:
  %t612 = load i1, ptr %l321, !tbaa !21
  %t613 = xor i1 %t612, true
  br i1 %t613, label %bb151, label %bb152
bb151:
  call void @__olang_scope_close(ptr %s18)
  store i1 false, ptr %rv
  br label %ret
bb152:
  br label %bb153
bb153:
  br label %bb154
bb154:
  %t616 = load i64, ptr %l30, !tbaa !24
  %t618 = add i64 %t616, 1
  store i64 %t618, ptr %l30, !tbaa !24
  br label %bb146
bb155:
  call void @__olang_scope_close(ptr %s18)
  store i1 true, ptr %rv
  br label %ret
bb156:
  %t621 = load ptr, ptr %l2, !tbaa !29
  store ptr %t621, ptr %l327, !tbaa !29
  store i1 false, ptr %l328, !tbaa !21
  %t622 = load ptr, ptr %l327, !tbaa !29
  %t623 = icmp ne ptr %t622, null
  br i1 %t623, label %bb157, label %bb158
bb157:
  %t625 = load ptr, ptr %l327, !tbaa !29
  %t626 = load i64, ptr %t625, !range !{i64 0, i64 17}
  %t628 = icmp eq i64 %t626, 15
  store i1 %t628, ptr %l328, !tbaa !21
  br label %bb158
bb158:
  %t629 = load i1, ptr %l328, !tbaa !21
  br i1 %t629, label %bb159, label %bb160
bb159:
  %t630 = load ptr, ptr %l2, !tbaa !29
  %t632 = getelementptr { i64, [3 x i64] }, ptr %t630, i32 0, i32 1
  %t633 = getelementptr { %"compiler/source:Span", ptr }, ptr %t632, i32 0, i32 1
  %t634 = load ptr, ptr %t633
  store ptr %t634, ptr %l33, !tbaa !29
  br label %bb161
bb160:
  br label %bb163
bb161:
  %t636 = load ptr, ptr %l0, !tbaa !29
  %t637 = load ptr, ptr %l1, !tbaa !29
  %t638 = load ptr, ptr %l33, !tbaa !29
  %t640 = load i64, ptr %l3, !tbaa !24
  %t641 = load i64, ptr %l4, !tbaa !24
  %t647 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t636, ptr %t637, ptr %t638, i64 %t640, i64 %t641)
  store i1 %t647, ptr %l339
  br label %bb162
bb162:
  %t648 = load i1, ptr %l339, !tbaa !21
  store i1 %t648, ptr %rv
  br label %ret
bb163:
  br i1 true, label %bb164, label %bb165
bb164:
  br label %bb166
bb165:
  br label %bb167
bb166:
  store i1 true, ptr %rv
  br label %ret
bb167:
  call void @__olang_check_failed(ptr @olang_loc_32fd86c1b7051b0e_a69c29150a84755a)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewalkLocal(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l12 = alloca i64
  %l14 = alloca i64
  %l19 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 25
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_8d68968aaddcddfb_f2a5e0e2182efbaf)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 25
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 17
  store ptr %t14, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t16 = load i64, ptr %l3, !tbaa !24
  store i64 %t16, ptr %l12, !tbaa !24
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t17)
  store i64 %t19, ptr %l14
  br label %bb5
bb5:
  %t20 = load i64, ptr %l12, !tbaa !24
  %t21 = load i64, ptr %l14, !tbaa !24
  %t22 = icmp slt i64 %t20, %t21
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb6, label %bb7
bb6:
  br label %bb14
bb7:
  br label %bb8
bb8:
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t27 = load i64, ptr %l3, !tbaa !24
  %t30 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t26, i64 %t27)
  store i32 %t30, ptr %l19
  br label %bb9
bb9:
  %t31 = load i32, ptr %l19, !tbaa !23
  %t34 = sext i32 %t31 to i64
  %t38 = icmp eq i64 %t34, %a1
  br i1 %t38, label %bb10, label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t41 = load i64, ptr %l3, !tbaa !24
  %t43 = add i64 %t41, 1
  store i64 %t43, ptr %l3, !tbaa !24
  br label %bb4
bb14:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewantPromotion(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l6 = alloca i1
  %l12 = alloca i64
  %l15 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 137
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 140
  %t11 = load i1, ptr %t10, !tbaa !21
  %t13 = xor i1 %t11, true
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l6, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t20 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efieldDecl(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i64 %t20, ptr %l12
  br label %bb7
bb7:
  %t21 = load i64, ptr %l12, !tbaa !24
  store i64 %t21, ptr %l2, !tbaa !24
  %t22 = load i64, ptr %l2, !tbaa !24
  %t24 = icmp slt i64 %t22, 0
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l15, !tbaa !29
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t27)
  store i32 %t29, ptr %l17
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t30 = load ptr, ptr %l15, !tbaa !29
  %t31 = load i32, ptr %l17, !tbaa !23
  %t32 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edeclOf(ptr %v0, ptr %t30, i32 %t31)
  store i64 %t32, ptr %l18
  br label %bb11
bb11:
  %t33 = load i64, ptr %l18, !tbaa !24
  store i64 %t33, ptr %l2, !tbaa !24
  br label %bb12
bb12:
  %t34 = load i64, ptr %l2, !tbaa !24
  %t36 = icmp sge i64 %t34, 0
  br i1 %t36, label %bb13, label %bb14
bb13:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewant(ptr %v0, ptr %t38, i64 %t39)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewhereLives(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, [2 x i64] }
  %l7 = alloca { i64, [2 x i64] }
  %l16 = alloca { i64, [2 x i64] }
  %rv = alloca { i64, [2 x i64] }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 31
  %t4 = load i32, ptr %l1, !tbaa !23
  %t6 = sext i32 %t4 to i64
  %t9 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t3, i64 %t6)
  store { i64, [2 x i64] } %t9, ptr %l7
  br label %bb1
bb1:
  %t10 = load { i64, [2 x i64] }, ptr %l7
  store { i64, [2 x i64] } %t10, ptr %l2
  %t11 = load { i64, [2 x i64] }, ptr %l2
  %t13 = extractvalue { i64, [2 x i64] } %t11, 0
  %t14 = icmp eq i64 %t13, 0
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load { i64, [2 x i64] }, ptr %l2
  store { i64, [2 x i64] } %t18, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/scope:Scoper", ptr %t20, i32 0, i32 32
  %t23 = load i32, ptr %l1, !tbaa !23
  %t25 = sext i32 %t23 to i64
  %t28 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t22, i64 %t25)
  store { i64, [2 x i64] } %t28, ptr %l16
  br label %bb5
bb5:
  %t29 = load { i64, [2 x i64] }, ptr %l16
  store { i64, [2 x i64] } %t29, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewordAt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l22 = alloca i32
  %l29 = alloca i1
  %l30 = alloca { i64, ptr }
  %l43 = alloca i64
  %l46 = alloca i64
  %l70 = alloca i1
  %l71 = alloca { i64, ptr }
  %l72 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i64
  %l83 = alloca i1
  %l87 = alloca i1
  %l88 = alloca { i64, ptr }
  %l92 = alloca i1
  %l100 = alloca i1
  %l101 = alloca { i64, ptr }
  %l107 = alloca i1
  %l115 = alloca %"compiler/source:Span"
  %s3 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 10
  store ptr %t3, ptr %l13, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/scope:Scoper", ptr %t4, i32 0, i32 25
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_eb4644f0af45390e_1376074f3833ad62)
  unreachable
bb2:
  br label %bb3
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 25
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Body", ptr %t14, i32 0, i32 3
  %t18 = load i64, ptr %t17, !tbaa !24
  %t19 = load ptr, ptr %l13, !tbaa !29
  %t21 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v0, ptr %t19, i64 %t18)
  %t22 = extractvalue { i32, { i64, ptr } } %t21, 1
  %t23 = extractvalue { i32, { i64, ptr } } %t21, 0
  store i32 %t23, ptr %l22
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb5, label %ok.25, !prof !99
ok.25:
  store { i64, ptr } %t22, ptr %l21
  br label %bb4
bb4:
  %t26 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t26, ptr %l11, !tbaa !27
  br label %bb7
bb5:
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) }, ptr %l11, !tbaa !27
  br label %bb7
bb7:
  %t27 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t27, ptr %l3, !tbaa !27
  %t28 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t29 = load i32, ptr %t28, !tbaa !23
  %t31 = sext i32 %t29 to i64
  store i64 %t31, ptr %l4, !tbaa !24
  br label %bb8
bb8:
  %t33 = load i64, ptr %l4, !tbaa !24
  %t34 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t39 = icmp slt i64 %t33, %t36
  br i1 %t39, label %bb9, label %bb10
bb9:
  %t41 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t41, ptr %l30, !tbaa !27
  %t42 = load i64, ptr %l4, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr i8, ptr %t45, i64 %t42
  %t47 = load i8, ptr %t46, !tbaa !32
  %t49 = icmp ne i8 %t47, 10
  store i1 %t49, ptr %l29, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb11
bb11:
  %t51 = load i1, ptr %l29, !tbaa !21
  %t52 = xor i1 %t51, true
  br i1 %t52, label %bb12, label %bb13
bb12:
  br label %bb16
bb13:
  br label %bb14
bb14:
  %t54 = load i64, ptr %l4, !tbaa !24
  %t56 = add i64 %t54, 1
  store i64 %t56, ptr %l4, !tbaa !24
  br label %bb15
bb15:
  br label %bb8
bb16:
  %t58 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t59 = load i32, ptr %t58, !tbaa !23
  %t61 = sext i32 %t59 to i64
  store i64 %t61, ptr %l5, !tbaa !24
  %t63 = load i64, ptr %l4, !tbaa !24
  store i64 %t63, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t65 = load i64, ptr %l6, !tbaa !24
  %t66 = load i64, ptr %l5, !tbaa !24
  %t69 = icmp sgt i64 %t65, %t66
  br i1 %t69, label %bb17, label %bb18
bb17:
  %t71 = load i64, ptr %l7, !tbaa !24
  %t73 = icmp sgt i64 %t71, 0
  br i1 %t73, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb22
bb19:
  %t75 = load i64, ptr %l6, !tbaa !24
  %t76 = load i64, ptr %l5, !tbaa !24
  %t79 = sub i64 %t75, %t76
  %t80 = load i64, ptr %l7, !tbaa !24
  %t83 = add i64 %t79, %t80
  %t85 = sub i64 %t83, 1
  %t86 = load i64, ptr %l7, !tbaa !24
  %t89 = sdiv i64 %t85, %t86
  store i64 %t89, ptr %l46, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb21
bb21:
  %t91 = load i64, ptr %l46, !tbaa !24
  store i64 %t91, ptr %l43, !tbaa !24
  br label %bb22
bb22:
  %t92 = load i64, ptr %l43, !tbaa !24
  store i64 %t92, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s3
  %t93 = load i64, ptr %l9, !tbaa !24
  %t94 = load i64, ptr %l8, !tbaa !24
  %t97 = icmp slt i64 %t93, %t94
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s3)
  br label %bb56
bb25:
  br label %bb26
bb26:
  %t101 = load i64, ptr %l5, !tbaa !24
  %t102 = load i64, ptr %l9, !tbaa !24
  %t103 = load i64, ptr %l7, !tbaa !24
  %t106 = mul i64 %t102, %t103
  %t109 = add i64 %t101, %t106
  store i64 %t109, ptr %l10, !tbaa !24
  %t111 = load i64, ptr %l10, !tbaa !24
  %t112 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t112, 0
  %t117 = add i64 %t111, %t114
  %t118 = load i64, ptr %l4, !tbaa !24
  %t121 = icmp sgt i64 %t117, %t118
  br i1 %t121, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb36
bb28:
  %t123 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t123, ptr %l71, !tbaa !27
  %t124 = load i64, ptr %l10, !tbaa !24
  store i64 %t124, ptr %l72, !tbaa !24
  %t125 = load i64, ptr %l10, !tbaa !24
  %t126 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t126, 0
  %t131 = add i64 %t125, %t128
  store i64 %t131, ptr %l76, !tbaa !24
  %t132 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t132, 0
  store i64 %t133, ptr %l77, !tbaa !24
  %t134 = load i64, ptr %l72, !tbaa !24
  %t135 = icmp sge i64 %t134, 0
  br i1 %t135, label %bb29, label %bb30
bb29:
  %t137 = load i64, ptr %l72, !tbaa !24
  %t138 = load i64, ptr %l76, !tbaa !24
  %t139 = icmp sle i64 %t137, %t138
  br i1 %t139, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_d7bea1f8c4fc6c43_c97bd86ee0afa2f7)
  unreachable
bb31:
  %t141 = load i64, ptr %l76, !tbaa !24
  %t142 = load i64, ptr %l77, !tbaa !24
  %t143 = icmp sle i64 %t141, %t142
  br i1 %t143, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_d7bea1f8c4fc6c43_c97bd86ee0afa2f7)
  unreachable
bb33:
  %t145 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = load i64, ptr %l72, !tbaa !24
  %t148 = load i64, ptr %l76, !tbaa !24
  %t149 = getelementptr i8, ptr %t146, i64 %t147
  %t150 = sub i64 %t148, %t147
  %t151 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t149, 1
  %t153 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t156 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t152, { i64, ptr } %t153)
  store i1 %t156, ptr %l83
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_d7bea1f8c4fc6c43_c97bd86ee0afa2f7)
  unreachable
bb35:
  %t157 = load i1, ptr %l83, !tbaa !21
  %t158 = xor i1 %t157, true
  store i1 %t158, ptr %l70, !tbaa !21
  br label %bb36
bb36:
  %t160 = load i1, ptr %l70, !tbaa !21
  br i1 %t160, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s3)
  br label %bb55
bb38:
  br label %bb39
bb39:
  %t161 = load i64, ptr %l10, !tbaa !24
  %t163 = icmp sgt i64 %t161, 0
  br i1 %t163, label %bb40, label %bb41
bb40:
  %t165 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t165, ptr %l88, !tbaa !27
  %t166 = load i64, ptr %l10, !tbaa !24
  %t168 = sub i64 %t166, 1
  %t170 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !27
  %t172 = getelementptr i8, ptr %t171, i64 %t168
  %t173 = load i8, ptr %t172, !tbaa !32
  %t175 = call i1 @compiler_2fscope_2eisNameChar(i8 %t173)
  store i1 %t175, ptr %l92
  br label %bb42
bb41:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb43
bb42:
  %t176 = load i1, ptr %l92, !tbaa !21
  store i1 %t176, ptr %l87, !tbaa !21
  br label %bb43
bb43:
  %t177 = load i1, ptr %l87, !tbaa !21
  br i1 %t177, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s3)
  br label %bb55
bb45:
  br label %bb46
bb46:
  %t178 = load i64, ptr %l10, !tbaa !24
  %t179 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t179, 0
  %t184 = add i64 %t178, %t181
  %t185 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t185, 0
  %t190 = icmp slt i64 %t184, %t187
  br i1 %t190, label %bb47, label %bb48
bb47:
  %t192 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t192, ptr %l101, !tbaa !27
  %t193 = load i64, ptr %l10, !tbaa !24
  %t194 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t194, 0
  %t199 = add i64 %t193, %t196
  %t201 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !27
  %t203 = getelementptr i8, ptr %t202, i64 %t199
  %t204 = load i8, ptr %t203, !tbaa !32
  %t206 = call i1 @compiler_2fscope_2eisNameChar(i8 %t204)
  store i1 %t206, ptr %l107
  br label %bb49
bb48:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb50
bb49:
  %t207 = load i1, ptr %l107, !tbaa !21
  store i1 %t207, ptr %l100, !tbaa !21
  br label %bb50
bb50:
  %t208 = load i1, ptr %l100, !tbaa !21
  br i1 %t208, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s3)
  br label %bb55
bb52:
  br label %bb53
bb53:
  %t209 = load i64, ptr %l10, !tbaa !24
  %t211 = trunc i64 %t209 to i32
  %t212 = load i64, ptr %l10, !tbaa !24
  %t213 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t215 = extractvalue { i64, ptr } %t213, 0
  %t218 = add i64 %t212, %t215
  %t220 = trunc i64 %t218 to i32
  %t223 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s3, i32 %t211, i32 %t220)
  store %"compiler/source:Span" %t223, ptr %l115
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s3)
  %t224 = load %"compiler/source:Span", ptr %l115
  store %"compiler/source:Span" %t224, ptr %rv
  br label %ret
bb55:
  %t225 = load i64, ptr %l9, !tbaa !24
  %t227 = add i64 %t225, 1
  store i64 %t227, ptr %l9, !tbaa !24
  br label %bb23
bb56:
  %t229 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t229, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i64 @compiler_2fscope_2eflRootExpr(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca i1
  %l35 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t7 = load ptr, ptr %l7, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l7, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 2
  store i1 %t13, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l8, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t17, i32 0, i32 2
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l1, !tbaa !29
  br label %bb16
bb7:
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t22 = load ptr, ptr %l13, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t26 = load i64, ptr %t25, !range !{i64 0, i64 18}
  %t28 = icmp eq i64 %t26, 3
  store i1 %t28, ptr %l14, !tbaa !21
  br label %bb9
bb9:
  %t29 = load i1, ptr %l14, !tbaa !21
  br i1 %t29, label %bb10, label %bb11
bb10:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr { i64, [5 x i64] }, ptr %t30, i32 0, i32 1
  %t33 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t32, i32 0, i32 2
  %t34 = load ptr, ptr %t33
  store ptr %t34, ptr %l1, !tbaa !29
  br label %bb16
bb11:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t37 = load ptr, ptr %l19, !tbaa !29
  %t38 = icmp ne ptr %t37, null
  br i1 %t38, label %bb12, label %bb13
bb12:
  %t40 = load ptr, ptr %l19, !tbaa !29
  %t41 = load i64, ptr %t40, !range !{i64 0, i64 18}
  %t43 = icmp eq i64 %t41, 4
  store i1 %t43, ptr %l20, !tbaa !21
  br label %bb13
bb13:
  %t44 = load i1, ptr %l20, !tbaa !21
  br i1 %t44, label %bb14, label %bb15
bb14:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [5 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t47, i32 0, i32 2
  %t49 = load ptr, ptr %t48
  store ptr %t49, ptr %l1, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = call i64 @compiler_2fscope_2eflRoot(ptr %v0, ptr %t51)
  store i64 %t53, ptr %l26
  br label %bb17
bb17:
  %t54 = load i64, ptr %l26, !tbaa !24
  store i64 %t54, ptr %l6, !tbaa !24
  br label %bb30
bb18:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t56 = load ptr, ptr %l27, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb19, label %bb20
bb19:
  %t59 = load ptr, ptr %l27, !tbaa !29
  %t60 = load i64, ptr %t59, !range !{i64 0, i64 18}
  %t62 = icmp eq i64 %t60, 17
  store i1 %t62, ptr %l28, !tbaa !21
  br label %bb20
bb20:
  %t63 = load i1, ptr %l28, !tbaa !21
  br i1 %t63, label %bb21, label %bb22
bb21:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr { i64, [5 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t66, i32 0, i32 2
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l2, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t70 = load ptr, ptr %l2, !tbaa !29
  %t73 = call i64 @compiler_2fscope_2eflRootExpr(ptr %v0, ptr %t70)
  store i64 %t73, ptr %l35
  br label %bb24
bb24:
  %t74 = load i64, ptr %l35, !tbaa !24
  store i64 %t74, ptr %l6, !tbaa !24
  br label %bb30
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  store i64 -1, ptr %l6, !tbaa !24
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_e9d57cf77a66352c_e30832457df38478)
  unreachable
bb30:
  %t75 = load i64, ptr %l6, !tbaa !24
  store i64 %t75, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fscope_2eflThroughRef(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %l16 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l25 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %l34 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb32
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t11 = load ptr, ptr %l9, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l9, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 3
  store i1 %t17, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l10, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l1, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = call i1 @compiler_2fscope_2eflThroughRef(ptr %v0, ptr %t25)
  store i1 %t27, ptr %l16
  br label %bb12
bb12:
  %t28 = load i1, ptr %l16, !tbaa !21
  store i1 %t28, ptr %l4, !tbaa !21
  br label %bb32
bb13:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t30 = load ptr, ptr %l17, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb14, label %bb15
bb14:
  %t33 = load ptr, ptr %l17, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 8}
  %t36 = icmp eq i64 %t34, 4
  store i1 %t36, ptr %l18, !tbaa !21
  br label %bb15
bb15:
  %t37 = load i1, ptr %l18, !tbaa !21
  br i1 %t37, label %bb16, label %bb17
bb16:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l2, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t46 = getelementptr %"compiler/typed:Elem", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = call i1 @compiler_2fscope_2eflThroughRef(ptr %v0, ptr %t47)
  store i1 %t49, ptr %l25
  br label %bb19
bb19:
  %t50 = load i1, ptr %l25, !tbaa !21
  store i1 %t50, ptr %l4, !tbaa !21
  br label %bb32
bb20:
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t52 = load ptr, ptr %l26, !tbaa !29
  %t53 = icmp ne ptr %t52, null
  br i1 %t53, label %bb21, label %bb22
bb21:
  %t55 = load ptr, ptr %l26, !tbaa !29
  %t56 = load i64, ptr %t55, !range !{i64 0, i64 8}
  %t58 = icmp eq i64 %t56, 5
  store i1 %t58, ptr %l27, !tbaa !21
  br label %bb22
bb22:
  %t59 = load i1, ptr %l27, !tbaa !21
  br i1 %t59, label %bb23, label %bb24
bb23:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr { i64, [4 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t62, i32 0, i32 2
  %t64 = load ptr, ptr %t63
  store ptr %t64, ptr %l3, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t66 = load ptr, ptr %l3, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Payload", ptr %t66, i32 0, i32 0
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = call i1 @compiler_2fscope_2eflThroughRef(ptr %v0, ptr %t69)
  store i1 %t71, ptr %l34
  br label %bb26
bb26:
  %t72 = load i1, ptr %l34, !tbaa !21
  store i1 %t72, ptr %l4, !tbaa !21
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_aab467fd51570cd7_b7c12dbd63ae1fe3)
  unreachable
bb32:
  %t73 = load i1, ptr %l4, !tbaa !21
  store i1 %t73, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2eisBlockTerm({ i64, [2 x i64] } %a0) #0 {
entry:
  %l1 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, [2 x i64] } %a0, 0
  %t4 = icmp eq i64 %t3, 1
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb9
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_f7b7284e8bdb42c_7d0460b025534e78)
  unreachable
bb9:
  %t6 = load i1, ptr %l1, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fscope_2elocalRead(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t17 = load ptr, ptr %l9, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l9, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l10, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l10, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t27, i32 0, i32 2
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l2, !tbaa !23
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t31 = load i32, ptr %l2, !tbaa !23
  %t33 = sext i32 %t31 to i64
  store i64 %t33, ptr %rv
  br label %ret
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i64 -1, ptr %rv
  br label %ret
bb15:
  call void @__olang_check_failed(ptr @olang_loc_1335909b8009e6b8_227574ff00a357c4)
  unreachable
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i64 -1, ptr %rv
  br label %ret
bb20:
  call void @__olang_check_failed(ptr @olang_loc_18ba62b867b30c89_62dfd3c940fee6b5)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fscope_2epartPlace(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca ptr
  %l3 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t11 = load ptr, ptr %l6, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l6, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 4
  store i1 %t17, ptr %l7, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l7, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l10, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 8}
  %t26 = icmp eq i64 %t24, 5
  store i1 %t26, ptr %l11, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l11, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_17d76cd793972dc1_67ead0b5b2d60e3d)
  unreachable
bb19:
  %t28 = load i1, ptr %l1, !tbaa !21
  store i1 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fscope_2eregionRoot(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i1
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i1
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i1
  %l30 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca i1
  %l39 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = call i64 @compiler_2fscope_2eregionLocal(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l13
  br label %bb6
bb6:
  %t19 = load i64, ptr %l13, !tbaa !24
  store i64 %t19, ptr %l5, !tbaa !24
  br label %bb33
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t21 = load ptr, ptr %l14, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l14, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 8}
  %t27 = icmp eq i64 %t25, 3
  store i1 %t27, ptr %l15, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l15, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l2, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = call i64 @compiler_2fscope_2eregionRoot(ptr %v0, ptr %t35)
  store i64 %t37, ptr %l21
  br label %bb13
bb13:
  %t38 = load i64, ptr %l21, !tbaa !24
  store i64 %t38, ptr %l5, !tbaa !24
  br label %bb33
bb14:
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t40 = load ptr, ptr %l22, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb15, label %bb16
bb15:
  %t43 = load ptr, ptr %l22, !tbaa !29
  %t44 = load i64, ptr %t43, !range !{i64 0, i64 8}
  %t46 = icmp eq i64 %t44, 5
  store i1 %t46, ptr %l23, !tbaa !21
  br label %bb16
bb16:
  %t47 = load i1, ptr %l23, !tbaa !21
  br i1 %t47, label %bb17, label %bb18
bb17:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr { i64, [4 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t50, i32 0, i32 2
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l3, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t54 = load ptr, ptr %l3, !tbaa !29
  %t56 = getelementptr %"compiler/typed:Payload", ptr %t54, i32 0, i32 0
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = call i64 @compiler_2fscope_2eregionRoot(ptr %v0, ptr %t57)
  store i64 %t59, ptr %l30
  br label %bb20
bb20:
  %t60 = load i64, ptr %l30, !tbaa !24
  store i64 %t60, ptr %l5, !tbaa !24
  br label %bb33
bb21:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t62 = load ptr, ptr %l31, !tbaa !29
  %t63 = icmp ne ptr %t62, null
  br i1 %t63, label %bb22, label %bb23
bb22:
  %t65 = load ptr, ptr %l31, !tbaa !29
  %t66 = load i64, ptr %t65, !range !{i64 0, i64 8}
  %t68 = icmp eq i64 %t66, 4
  store i1 %t68, ptr %l32, !tbaa !21
  br label %bb23
bb23:
  %t69 = load i1, ptr %l32, !tbaa !21
  br i1 %t69, label %bb24, label %bb25
bb24:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr { i64, [4 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t72, i32 0, i32 2
  %t74 = load ptr, ptr %t73
  store ptr %t74, ptr %l4, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t76 = load ptr, ptr %l4, !tbaa !29
  %t78 = getelementptr %"compiler/typed:Elem", ptr %t76, i32 0, i32 0
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = call i64 @compiler_2fscope_2eregionRoot(ptr %v0, ptr %t79)
  store i64 %t81, ptr %l39
  br label %bb27
bb27:
  %t82 = load i64, ptr %l39, !tbaa !24
  store i64 %t82, ptr %l5, !tbaa !24
  br label %bb33
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i64 -1, ptr %l5, !tbaa !24
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_b150ba266c9424e3_527b6225611e1947)
  unreachable
bb33:
  %t83 = load i64, ptr %l5, !tbaa !24
  store i64 %t83, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fscope_2ethroughTemp(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %l16 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l25 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %l34 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb32
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t11 = load ptr, ptr %l9, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l9, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 3
  store i1 %t17, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l10, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l1, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = call i1 @compiler_2fscope_2ethroughTemp(ptr %v0, ptr %t25)
  store i1 %t27, ptr %l16
  br label %bb12
bb12:
  %t28 = load i1, ptr %l16, !tbaa !21
  store i1 %t28, ptr %l4, !tbaa !21
  br label %bb32
bb13:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t30 = load ptr, ptr %l17, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb14, label %bb15
bb14:
  %t33 = load ptr, ptr %l17, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 8}
  %t36 = icmp eq i64 %t34, 4
  store i1 %t36, ptr %l18, !tbaa !21
  br label %bb15
bb15:
  %t37 = load i1, ptr %l18, !tbaa !21
  br i1 %t37, label %bb16, label %bb17
bb16:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l2, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t46 = getelementptr %"compiler/typed:Elem", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = call i1 @compiler_2fscope_2ethroughTemp(ptr %v0, ptr %t47)
  store i1 %t49, ptr %l25
  br label %bb19
bb19:
  %t50 = load i1, ptr %l25, !tbaa !21
  store i1 %t50, ptr %l4, !tbaa !21
  br label %bb32
bb20:
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t52 = load ptr, ptr %l26, !tbaa !29
  %t53 = icmp ne ptr %t52, null
  br i1 %t53, label %bb21, label %bb22
bb21:
  %t55 = load ptr, ptr %l26, !tbaa !29
  %t56 = load i64, ptr %t55, !range !{i64 0, i64 8}
  %t58 = icmp eq i64 %t56, 5
  store i1 %t58, ptr %l27, !tbaa !21
  br label %bb22
bb22:
  %t59 = load i1, ptr %l27, !tbaa !21
  br i1 %t59, label %bb23, label %bb24
bb23:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr { i64, [4 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t62, i32 0, i32 2
  %t64 = load ptr, ptr %t63
  store ptr %t64, ptr %l3, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t66 = load ptr, ptr %l3, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Payload", ptr %t66, i32 0, i32 0
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = call i1 @compiler_2fscope_2ethroughTemp(ptr %v0, ptr %t69)
  store i1 %t71, ptr %l34
  br label %bb26
bb26:
  %t72 = load i1, ptr %l34, !tbaa !21
  store i1 %t72, ptr %l4, !tbaa !21
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_30366b1ce1cb05a4_de371b7365ebcc00)
  unreachable
bb32:
  %t73 = load i1, ptr %l4, !tbaa !21
  store i1 %t73, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fscope_2ewholeLocal(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l1, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l1, !tbaa !23
  %t18 = sext i32 %t16 to i64
  store i64 %t18, ptr %l2, !tbaa !24
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i64 -1, ptr %l2, !tbaa !24
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_8ae797379831bd51_629aae10c041c6e5)
  unreachable
bb11:
  %t20 = load i64, ptr %l2, !tbaa !24
  store i64 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fscope_2ewithin(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca i1
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l18 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l28 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l38 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i1 @compiler_2fscope_2esamePlace(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i1 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i1, ptr %l7, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t9 = load ptr, ptr %l10, !tbaa !29
  %t10 = icmp ne ptr %t9, null
  br i1 %t10, label %bb5, label %bb6
bb5:
  %t12 = load ptr, ptr %l10, !tbaa !29
  %t13 = load i64, ptr %t12, !range !{i64 0, i64 8}
  %t15 = icmp eq i64 %t13, 3
  store i1 %t15, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t16 = load i1, ptr %l11, !tbaa !21
  br i1 %t16, label %bb7, label %bb8
bb7:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr { i64, [4 x i64] }, ptr %t17, i32 0, i32 1
  %t20 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t19, i32 0, i32 2
  %t21 = load ptr, ptr %t20
  store ptr %t21, ptr %l2, !tbaa !29
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t27 = call i1 @compiler_2fscope_2ewithin(ptr %v0, ptr %v1, ptr %t23, ptr %t24)
  store i1 %t27, ptr %l18
  br label %bb10
bb10:
  %t28 = load i1, ptr %l18, !tbaa !21
  store i1 %t28, ptr %l9, !tbaa !21
  br label %bb30
bb11:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t30 = load ptr, ptr %l19, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb12, label %bb13
bb12:
  %t33 = load ptr, ptr %l19, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 8}
  %t36 = icmp eq i64 %t34, 4
  store i1 %t36, ptr %l20, !tbaa !21
  br label %bb13
bb13:
  %t37 = load i1, ptr %l20, !tbaa !21
  br i1 %t37, label %bb14, label %bb15
bb14:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l3, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t44 = load ptr, ptr %l3, !tbaa !29
  %t46 = getelementptr %"compiler/typed:Elem", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t51 = call i1 @compiler_2fscope_2ewithin(ptr %v0, ptr %v1, ptr %t47, ptr %t48)
  store i1 %t51, ptr %l28
  br label %bb17
bb17:
  %t52 = load i1, ptr %l28, !tbaa !21
  store i1 %t52, ptr %l9, !tbaa !21
  br label %bb30
bb18:
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t54 = load ptr, ptr %l29, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb19, label %bb20
bb19:
  %t57 = load ptr, ptr %l29, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 8}
  %t60 = icmp eq i64 %t58, 5
  store i1 %t60, ptr %l30, !tbaa !21
  br label %bb20
bb20:
  %t61 = load i1, ptr %l30, !tbaa !21
  br i1 %t61, label %bb21, label %bb22
bb21:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr { i64, [4 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t64, i32 0, i32 2
  %t66 = load ptr, ptr %t65
  store ptr %t66, ptr %l4, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t68 = load ptr, ptr %l4, !tbaa !29
  %t70 = getelementptr %"compiler/typed:Payload", ptr %t68, i32 0, i32 0
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t75 = call i1 @compiler_2fscope_2ewithin(ptr %v0, ptr %v1, ptr %t71, ptr %t72)
  store i1 %t75, ptr %l38
  br label %bb24
bb24:
  %t76 = load i1, ptr %l38, !tbaa !21
  store i1 %t76, ptr %l9, !tbaa !21
  br label %bb30
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_54cb93a6de18c312_16e8d0818733306)
  unreachable
bb30:
  %t77 = load i1, ptr %l9, !tbaa !21
  store i1 %t77, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/scope:Val" @compiler_2fscope_3aVal_2ector(ptr %v0, i32 %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %rv = alloca %"compiler/scope:Val"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/scope:Val" undef, i32 %a0, 0
  %t8 = insertvalue %"compiler/scope:Val" %t6, { i64, [2 x i64] } %a1, 1
  store %"compiler/scope:Val" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scope:Val", ptr %rv
  ret %"compiler/scope:Val" %rr
}

define dso_local %"compiler/scope:placeSlot" @compiler_2fscope_3aplaceSlot_2ector(ptr %v0, { i64, [2 x i64] } %a0, i1 %a1, i64 %a2) #0 {
entry:
  %rv = alloca %"compiler/scope:placeSlot"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/scope:placeSlot" undef, { i64, [2 x i64] } %a0, 0
  %t10 = insertvalue %"compiler/scope:placeSlot" %t8, i1 %a1, 1
  %t12 = insertvalue %"compiler/scope:placeSlot" %t10, i64 %a2, 2
  store %"compiler/scope:placeSlot" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scope:placeSlot", ptr %rv
  ret %"compiler/scope:placeSlot" %rr
}

define dso_local %"compiler/scope:sumRead" @compiler_2fscope_3asumRead_2ector(ptr %v0, ptr %v1, i64 %a0, ptr %a1) #0 {
entry:
  %rv = alloca %"compiler/scope:sumRead"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/scope:sumRead" undef, i64 %a0, 0
  %t8 = insertvalue %"compiler/scope:sumRead" %t6, ptr %a1, 1
  store %"compiler/scope:sumRead" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scope:sumRead", ptr %rv
  ret %"compiler/scope:sumRead" %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
@.d0 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"inferred: " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d1 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c" locals lifted (" }>, align 8
@.d2 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c" for a part of them kept), " }>, align 8
@.d3 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c" with their storage, " }>, align 8
@.d4 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" calls landed, " }>, align 8
@.d5 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c" needing a W, " }>, align 8
@.d6 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c" fields promoted (" }>, align 8
@.d7 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" given back)" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1, !range !{i64 0, i64 7}
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3, !range !{i64 0, i64 7}
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb13
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 i64 2, label %bb5 i64 4, label %bb6 i64 5, label %bb7 ]
bb3:
  br label %bb13
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [2 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  %t20 = icmp eq i32 %t13, %t17
  br i1 %t20, label %bb8, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i64 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [2 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  %t32 = icmp eq i64 %t25, %t29
  br i1 %t32, label %bb9, label %bb1
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [2 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i64, i64 }, ptr %t35, i32 0, i32 0
  %t37 = load i64, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [2 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i64, i64 }, ptr %t39, i32 0, i32 0
  %t41 = load i64, ptr %t40
  %t44 = icmp eq i64 %t37, %t41
  br i1 %t44, label %bb10, label %bb1
bb7:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [2 x i64] }, ptr %t46, i32 0, i32 1
  %t48 = getelementptr { i64 }, ptr %t47, i32 0, i32 0
  %t49 = load i64, ptr %t48
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [2 x i64] }, ptr %t50, i32 0, i32 1
  %t52 = getelementptr { i64 }, ptr %t51, i32 0, i32 0
  %t53 = load i64, ptr %t52
  %t56 = icmp eq i64 %t49, %t53
  br i1 %t56, label %bb12, label %bb1
bb8:
  br label %bb3
bb9:
  br label %bb3
bb10:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr { i64, [2 x i64] }, ptr %t58, i32 0, i32 1
  %t60 = getelementptr { i64, i64 }, ptr %t59, i32 0, i32 1
  %t61 = load i64, ptr %t60
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr { i64, [2 x i64] }, ptr %t62, i32 0, i32 1
  %t64 = getelementptr { i64, i64 }, ptr %t63, i32 0, i32 1
  %t65 = load i64, ptr %t64
  %t68 = icmp eq i64 %t61, %t65
  br i1 %t68, label %bb11, label %bb1
bb11:
  br label %bb3
bb12:
  br label %bb3
bb13:
  %t70 = load i1, ptr %l2, !tbaa !21
  store i1 %t70, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare void @__olang_ert_req_clear()
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d8 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" diagnostics" }>, align 8
@.d9 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" refusals" }>, align 8
@.d10 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" values" }>, align 8
@.d11 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" summary of " }>, align 8
@.d12 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr void @olang_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aPlan(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/typed:Plan"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 176, i1 false)
  %t2 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 9
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t6 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t6
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 176, i1 false)
  br label %ret
ret:
  ret void
}

define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2eArray_3ccompiler_2ftyped_3aScope_3e_26(ptr %a0, ptr %a1) #0 {
entry:
  %l6 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %a0, !tbaa !27
  %t4 = load { i64, ptr }, ptr %a1, !tbaa !27
  %t9 = call i1 @olang_2eHelperKind_2eEqual_2eArray_3ccompiler_2ftyped_3aScope_3e({ i64, ptr } %t2, { i64, ptr } %t4)
  store i1 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load i1, ptr %l6, !tbaa !21
  store i1 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2eArray_3cBool_3e_26(ptr %a0, ptr %a1) #0 {
entry:
  %l6 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %a0, !tbaa !27
  %t4 = load { i64, ptr }, ptr %a1, !tbaa !27
  %t9 = call i1 @olang_2eHelperKind_2eEqual_2eArray_3cBool_3e({ i64, ptr } %t2, { i64, ptr } %t4)
  store i1 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load i1, ptr %l6, !tbaa !21
  store i1 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2eArray_3cI64_3e_26(ptr %a0, ptr %a1) #0 {
entry:
  %l6 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %a0, !tbaa !27
  %t4 = load { i64, ptr }, ptr %a1, !tbaa !27
  %t9 = call i1 @olang_2eHelperKind_2eEqual_2eArray_3cI64_3e({ i64, ptr } %t2, { i64, ptr } %t4)
  store i1 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load i1, ptr %l6, !tbaa !21
  store i1 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2eArray_3ccompiler_2ftyped_3aExpr_3f_26_3e_26(ptr %a0, ptr %a1) #0 {
entry:
  %l6 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %a0, !tbaa !27
  %t4 = load { i64, ptr }, ptr %a1, !tbaa !27
  %t9 = call i1 @olang_2eHelperKind_2eEqual_2eArray_3ccompiler_2ftyped_3aExpr_3f_26_3e({ i64, ptr } %t2, { i64, ptr } %t4)
  store i1 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load i1, ptr %l6, !tbaa !21
  store i1 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d13 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" plan of " }>, align 8
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare void @__olang_sb_add(ptr, i64)
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d16 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d17 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aBodyOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1, !range !{i64 0, i64 11}
  switch i64 %t2, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 i64 7, label %bb9 i64 8, label %bb10 i64 9, label %bb11 i64 10, label %bb12 ]
bb1:
  br label %ret
bb2:
  %t4 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t4, i64 %t5)
  %t6 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t6, i64 %t7)
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr { i64, [2 x i64] }, ptr %t8, i32 0, i32 1
  %t10 = getelementptr { i64 }, ptr %t9, i32 0, i32 0
  %t11 = load i64, ptr %t10
  %t13 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t14 = call i64 @__olang_fmt_i64(ptr %t13, i64 %t11)
  call void @__olang_sb_add(ptr %v0, i64 %t14)
  %t15 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t15, i64 %t16)
  br label %bb1
bb3:
  %t17 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t17, i64 %t18)
  %t19 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t19, i64 %t20)
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr { i64, [2 x i64] }, ptr %t21, i32 0, i32 1
  %t23 = getelementptr { i32, i32 }, ptr %t22, i32 0, i32 0
  %t24 = load i32, ptr %t23
  %t26 = sext i32 %t24 to i64
  %t27 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t28 = call i64 @__olang_fmt_i64(ptr %t27, i64 %t26)
  call void @__olang_sb_add(ptr %v0, i64 %t28)
  %t29 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t29, i64 %t30)
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr { i64, [2 x i64] }, ptr %t31, i32 0, i32 1
  %t33 = getelementptr { i32, i32 }, ptr %t32, i32 0, i32 1
  %t34 = load i32, ptr %t33
  %t36 = sext i32 %t34 to i64
  %t37 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t38 = call i64 @__olang_fmt_i64(ptr %t37, i64 %t36)
  call void @__olang_sb_add(ptr %v0, i64 %t38)
  %t39 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t39, i64 %t40)
  br label %bb1
bb4:
  %t41 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t42 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t41, i64 %t42)
  %t43 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t43, i64 %t44)
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr { i64, [2 x i64] }, ptr %t45, i32 0, i32 1
  %t47 = getelementptr { i32, i64 }, ptr %t46, i32 0, i32 0
  %t48 = load i32, ptr %t47
  %t50 = sext i32 %t48 to i64
  %t51 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t52 = call i64 @__olang_fmt_i64(ptr %t51, i64 %t50)
  call void @__olang_sb_add(ptr %v0, i64 %t52)
  %t53 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t54 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t53, i64 %t54)
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr { i64, [2 x i64] }, ptr %t55, i32 0, i32 1
  %t57 = getelementptr { i32, i64 }, ptr %t56, i32 0, i32 1
  %t58 = load i64, ptr %t57
  %t60 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t61 = call i64 @__olang_fmt_i64(ptr %t60, i64 %t58)
  call void @__olang_sb_add(ptr %v0, i64 %t61)
  %t62 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t63 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t62, i64 %t63)
  br label %bb1
bb5:
  %t64 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t65 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t64, i64 %t65)
  %t66 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t67 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t66, i64 %t67)
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr { i64, [2 x i64] }, ptr %t68, i32 0, i32 1
  %t70 = getelementptr { i32 }, ptr %t69, i32 0, i32 0
  %t71 = load i32, ptr %t70
  %t73 = sext i32 %t71 to i64
  %t74 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t75 = call i64 @__olang_fmt_i64(ptr %t74, i64 %t73)
  call void @__olang_sb_add(ptr %v0, i64 %t75)
  %t76 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t77 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t76, i64 %t77)
  br label %bb1
bb6:
  %t78 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t79 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t78, i64 %t79)
  %t80 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t81 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t80, i64 %t81)
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr { i64, [2 x i64] }, ptr %t82, i32 0, i32 1
  %t84 = getelementptr { i32 }, ptr %t83, i32 0, i32 0
  %t85 = load i32, ptr %t84
  %t87 = sext i32 %t85 to i64
  %t88 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t89 = call i64 @__olang_fmt_i64(ptr %t88, i64 %t87)
  call void @__olang_sb_add(ptr %v0, i64 %t89)
  %t90 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t91 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t90, i64 %t91)
  br label %bb1
bb7:
  %t92 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t93 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t92, i64 %t93)
  %t94 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t95 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t94, i64 %t95)
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr { i64, [2 x i64] }, ptr %t96, i32 0, i32 1
  %t98 = getelementptr { i64 }, ptr %t97, i32 0, i32 0
  %t99 = load i64, ptr %t98
  %t101 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t102 = call i64 @__olang_fmt_i64(ptr %t101, i64 %t99)
  call void @__olang_sb_add(ptr %v0, i64 %t102)
  %t103 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t104 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t103, i64 %t104)
  br label %bb1
bb8:
  %t105 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t106 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t105, i64 %t106)
  %t107 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t108 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t107, i64 %t108)
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr { i64, [2 x i64] }, ptr %t109, i32 0, i32 1
  %t111 = getelementptr { i64, i32 }, ptr %t110, i32 0, i32 0
  %t112 = load i64, ptr %t111
  %t114 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t115 = call i64 @__olang_fmt_i64(ptr %t114, i64 %t112)
  call void @__olang_sb_add(ptr %v0, i64 %t115)
  %t116 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t117 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t116, i64 %t117)
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr { i64, [2 x i64] }, ptr %t118, i32 0, i32 1
  %t120 = getelementptr { i64, i32 }, ptr %t119, i32 0, i32 1
  %t121 = load i32, ptr %t120
  %t123 = sext i32 %t121 to i64
  %t124 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t125 = call i64 @__olang_fmt_i64(ptr %t124, i64 %t123)
  call void @__olang_sb_add(ptr %v0, i64 %t125)
  %t126 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t127 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t126, i64 %t127)
  br label %bb1
bb9:
  %t128 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t129 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t128, i64 %t129)
  %t130 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t131 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t130, i64 %t131)
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr { i64, [2 x i64] }, ptr %t132, i32 0, i32 1
  %t134 = getelementptr { i64, i32 }, ptr %t133, i32 0, i32 0
  %t135 = load i64, ptr %t134
  %t137 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t138 = call i64 @__olang_fmt_i64(ptr %t137, i64 %t135)
  call void @__olang_sb_add(ptr %v0, i64 %t138)
  %t139 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t140 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t139, i64 %t140)
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr { i64, [2 x i64] }, ptr %t141, i32 0, i32 1
  %t143 = getelementptr { i64, i32 }, ptr %t142, i32 0, i32 1
  %t144 = load i32, ptr %t143
  %t146 = sext i32 %t144 to i64
  %t147 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t148 = call i64 @__olang_fmt_i64(ptr %t147, i64 %t146)
  call void @__olang_sb_add(ptr %v0, i64 %t148)
  %t149 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t150 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t149, i64 %t150)
  br label %bb1
bb10:
  %t151 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t152 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t151, i64 %t152)
  %t153 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t154 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t153, i64 %t154)
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr { i64, [2 x i64] }, ptr %t155, i32 0, i32 1
  %t157 = getelementptr { i32, i32, i64 }, ptr %t156, i32 0, i32 0
  %t158 = load i32, ptr %t157
  %t160 = sext i32 %t158 to i64
  %t161 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t162 = call i64 @__olang_fmt_i64(ptr %t161, i64 %t160)
  call void @__olang_sb_add(ptr %v0, i64 %t162)
  %t163 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t164 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t163, i64 %t164)
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr { i64, [2 x i64] }, ptr %t165, i32 0, i32 1
  %t167 = getelementptr { i32, i32, i64 }, ptr %t166, i32 0, i32 1
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aContractKind(ptr %v0, ptr %t167, i64 %a1)
  br label %bb13
bb11:
  %t170 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t171 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t170, i64 %t171)
  %t172 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t173 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t172, i64 %t173)
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr { i64, [2 x i64] }, ptr %t174, i32 0, i32 1
  %t176 = getelementptr { i64, i64 }, ptr %t175, i32 0, i32 0
  %t177 = load i64, ptr %t176
  %t179 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t180 = call i64 @__olang_fmt_i64(ptr %t179, i64 %t177)
  call void @__olang_sb_add(ptr %v0, i64 %t180)
  %t181 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t182 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t181, i64 %t182)
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr { i64, [2 x i64] }, ptr %t183, i32 0, i32 1
  %t185 = getelementptr { i64, i64 }, ptr %t184, i32 0, i32 1
  %t186 = load i64, ptr %t185
  %t188 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t189 = call i64 @__olang_fmt_i64(ptr %t188, i64 %t186)
  call void @__olang_sb_add(ptr %v0, i64 %t189)
  %t190 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t191 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t190, i64 %t191)
  br label %bb1
bb12:
  %t192 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t193 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t192, i64 %t193)
  %t194 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t195 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t194, i64 %t195)
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr { i64, [2 x i64] }, ptr %t196, i32 0, i32 1
  %t198 = getelementptr { i32, i64 }, ptr %t197, i32 0, i32 0
  %t199 = load i32, ptr %t198
  %t201 = sext i32 %t199 to i64
  %t202 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t203 = call i64 @__olang_fmt_i64(ptr %t202, i64 %t201)
  call void @__olang_sb_add(ptr %v0, i64 %t203)
  %t204 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t205 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t204, i64 %t205)
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr { i64, [2 x i64] }, ptr %t206, i32 0, i32 1
  %t208 = getelementptr { i32, i64 }, ptr %t207, i32 0, i32 1
  %t209 = load i64, ptr %t208
  %t211 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t212 = call i64 @__olang_fmt_i64(ptr %t211, i64 %t209)
  call void @__olang_sb_add(ptr %v0, i64 %t212)
  %t213 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t214 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t213, i64 %t214)
  br label %bb1
bb13:
  %t215 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t216 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t215, i64 %t216)
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr { i64, [2 x i64] }, ptr %t217, i32 0, i32 1
  %t219 = getelementptr { i32, i32, i64 }, ptr %t218, i32 0, i32 2
  %t220 = load i64, ptr %t219
  %t222 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t223 = call i64 @__olang_fmt_i64(ptr %t222, i64 %t220)
  call void @__olang_sb_add(ptr %v0, i64 %t223)
  %t224 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t225 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t224, i64 %t225)
  br label %bb1
ret:
  ret void
}

declare void @__olang_sb_done(ptr)
@.d18 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"OLANG_SCOPECHECK: component " }>, align 8
@.d19 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c" taken again but judged differently -" }>, align 8
declare void @__olang_check_failed_text(ptr, { i64, ptr }) cold noreturn
@.d20 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Str" }>, align 8
@.d21 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"str" }>, align 8
@.d22 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d23 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"mut " }>, align 8
@.d24 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d25 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d26 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"?" }>, align 8
@.d27 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"line " }>, align 8
@.d28 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d29 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2eArray_3ccompiler_2ftyped_3aScope_3e({ i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i64
  %l6 = alloca i64
  %l10 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t3, 0
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb8
bb2:
  store i64 0, ptr %l6, !tbaa !24
  br label %bb3
bb3:
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr { i64, [1 x i64] }, ptr %t15, i64 %t13
  %t17 = load i64, ptr %l6, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr { i64, [1 x i64] }, ptr %t19, i64 %t17
  %t23 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %t16, ptr %t20)
  store i1 %t23, ptr %l10
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t24 = load i1, ptr %l10, !tbaa !21
  br i1 %t24, label %bb7, label %bb1
bb7:
  %t25 = load i64, ptr %l6, !tbaa !24
  %t26 = add i64 %t25, 1
  store i64 %t26, ptr %l6, !tbaa !24
  br label %bb3
bb8:
  %t27 = load i1, ptr %l2, !tbaa !21
  store i1 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2eArray_3cBool_3e({ i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i64
  %l6 = alloca i64
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t3, 0
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb7
bb2:
  store i64 0, ptr %l6, !tbaa !24
  br label %bb3
bb3:
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i1, ptr %t15, i64 %t13
  %t17 = load i1, ptr %t16, !tbaa !31
  %t18 = load i64, ptr %l6, !tbaa !24
  %t19 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr i1, ptr %t20, i64 %t18
  %t22 = load i1, ptr %t21, !tbaa !31
  %t25 = icmp eq i1 %t17, %t22
  br i1 %t25, label %bb6, label %bb1
bb5:
  br label %bb7
bb6:
  %t27 = load i64, ptr %l6, !tbaa !24
  %t28 = add i64 %t27, 1
  store i64 %t28, ptr %l6, !tbaa !24
  br label %bb3
bb7:
  %t29 = load i1, ptr %l2, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2eArray_3cI64_3e({ i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i64
  %l6 = alloca i64
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t3, 0
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb7
bb2:
  store i64 0, ptr %l6, !tbaa !24
  br label %bb3
bb3:
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i64, ptr %t15, i64 %t13
  %t17 = load i64, ptr %t16, !tbaa !34
  %t18 = load i64, ptr %l6, !tbaa !24
  %t19 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr i64, ptr %t20, i64 %t18
  %t22 = load i64, ptr %t21, !tbaa !34
  %t25 = icmp eq i64 %t17, %t22
  br i1 %t25, label %bb6, label %bb1
bb5:
  br label %bb7
bb6:
  %t27 = load i64, ptr %l6, !tbaa !24
  %t28 = add i64 %t27, 1
  store i64 %t28, ptr %l6, !tbaa !24
  br label %bb3
bb7:
  %t29 = load i1, ptr %l2, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2eArray_3ccompiler_2ftyped_3aExpr_3f_26_3e({ i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i64
  %l6 = alloca i64
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t3, 0
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb7
bb2:
  store i64 0, ptr %l6, !tbaa !24
  br label %bb3
bb3:
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr ptr, ptr %t15, i64 %t13
  %t17 = load ptr, ptr %t16, !tbaa !39
  %t18 = load i64, ptr %l6, !tbaa !24
  %t19 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr ptr, ptr %t20, i64 %t18
  %t22 = load ptr, ptr %t21, !tbaa !39
  %t25 = icmp eq ptr %t17, %t22
  br i1 %t25, label %bb6, label %bb1
bb5:
  br label %bb7
bb6:
  %t27 = load i64, ptr %l6, !tbaa !24
  %t28 = add i64 %t27, 1
  store i64 %t28, ptr %l6, !tbaa !24
  br label %bb3
bb7:
  %t29 = load i1, ptr %l2, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare ptr @__olang_sb_grow(ptr, i64) noinline
@.d30 = private unnamed_addr constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"BodyOf.Fn" }>, align 8
@.d31 = private unnamed_addr constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d32 = private unnamed_addr constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d33 = private unnamed_addr constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"BodyOf.Ctor" }>, align 8
@.d34 = private unnamed_addr constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d35 = private unnamed_addr constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"BodyOf.Case" }>, align 8
@.d36 = private unnamed_addr constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"BodyOf.Dtor" }>, align 8
@.d37 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"BodyOf.Lambda" }>, align 8
@.d38 = private unnamed_addr constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"BodyOf.Test" }>, align 8
@.d39 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"BodyOf.Global" }>, align 8
@.d40 = private unnamed_addr constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"BodyOf.Cond" }>, align 8
@.d41 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"BodyOf.Contract" }>, align 8
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aContractKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 1}
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
ret:
  ret void
}

@.d42 = private unnamed_addr constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"BodyOf.Thunk" }>, align 8
@.d43 = private unnamed_addr constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"BodyOf.Slot" }>, align 8
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1, !range !{i64 0, i64 7}
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3, !range !{i64 0, i64 7}
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb10
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 i64 2, label %bb5 i64 4, label %bb6 ]
bb3:
  br label %bb10
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [1 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [1 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  %t20 = icmp eq i32 %t13, %t17
  br i1 %t20, label %bb7, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [1 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i64 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [1 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  %t32 = icmp eq i64 %t25, %t29
  br i1 %t32, label %bb8, label %bb1
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [1 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i32 }, ptr %t35, i32 0, i32 0
  %t37 = load i32, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [1 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i32 }, ptr %t39, i32 0, i32 0
  %t41 = load i32, ptr %t40
  %t44 = icmp eq i32 %t37, %t41
  br i1 %t44, label %bb9, label %bb1
bb7:
  br label %bb3
bb8:
  br label %bb3
bb9:
  br label %bb3
bb10:
  %t46 = load i1, ptr %l2, !tbaa !21
  store i1 %t46, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d44 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"ContractKind.Req" }>, align 8
@olang_loc_815ce866d8282155_e428af91c79b2b69 = external constant [0 x i8]
declare void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H135723289cd67fccd962ee530d90cf81(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hda9b67cfa9ae8a2a4969568452cdfd9b(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hb48ebc0aec2f1394686d895000e23a7c(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esetEnd(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_ade2525ec560ecac_5eadaea182574e0 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ePush_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparts(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_7ac300513ffc0d8b_1ff73281fb7180bf = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_bd8a316f234c31bd_e8aabd6e86499e79 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %a0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartOK(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2)
@olang_loc_5ad8ce5e83291793_3404c81b33ceede7 = external constant [0 x i8]
declare ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunPromoted(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erecOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_2489ab739aea8b00_863e154a28bdb8e4 = external constant [0 x i8]
declare %"compiler/scope:Val" @compiler_2fscope_2eplain()
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2)
@olang_loc_76dd643541c5999_442dc791771fad = external constant [0 x i8]
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblockTerm(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0, i64 %a1, { i64, [2 x i64] } %a2)
declare i1 @compiler_2fscope_2eflHas(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esetOf(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, { i64, [2 x i64] } %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eclaimRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_a61f6227542ac272_aba93d64b04206c6 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_f34ecaa27a4fd2b3_7961e1dcca83cdb7 = external constant [0 x i8]
declare { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePop_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0)
@olang_loc_b442aabc3e151319_4a7d8af854ba830d = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteLate(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H1c7d675bdd0f9eae97711af4b62e7c17(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_c5883e2e797033d1_fc44041a166d1b4d = external constant [0 x i8]
declare ptr @compiler_2fscope_2eunPassed(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_ea6e06a9360e3f29_549c073cdead9825 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_1cbcbb68212d18c9_a0b41c71999484fd = external constant [0 x i8]
@olang_loc_43bfbe21df81ba11_dcc42dbc8d435385 = external constant [0 x i8]
@olang_loc_ae19eb3dd0d17d29_4ac15fb0aa0c6205 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evalueAdmits(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeBuilds(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_190434ab470c43aa_3a8ff8b5c92040d6 = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_5cb72587228936ff_1a6837af5c2cdca3 = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarriedPlace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecanKeep(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare i1 @compiler_2ftyped_2ePassesRefs(i32 %a0)
@olang_loc_9675e93c9f07526d_8a86ee267fb7b3d9 = external constant [0 x i8]
@olang_loc_768f72a2579754c5_d91cee094dc07e21 = external constant [0 x i8]
@olang_loc_15f791c29ca5960e_c2f6ea53b6b5628a = external constant [0 x i8]
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aTaken_2eSame(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnUse_3e_2eLen_3ccompiler_2fscope_3afnUse_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fscope_2esameSummary(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fscope_2esummaryDiff(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2eEq_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aTaken_2eCount(ptr %v0, ptr %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eForget(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnUse_3e_2eTruncate_3ccompiler_2fscope_3afnUse_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aGap_3e_2eLen_3ccompiler_2fscope_3aGap_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aGap_3e_2eTruncate_3ccompiler_2fscope_3aGap_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_6a87b3eb83e8e753_81a9677ce8feda27 = external constant [0 x i8]
@olang_loc_13a66e5900397517_aa9470c685b363ab = external constant [0 x i8]
@olang_loc_5a6ddbb4ef42a8ef_2ba82a28086a35d3 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_c315d8e1b666b9f2_cb49359568748e36 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_24644cfdb6585119_908704f065623d9d = external constant [0 x i8]
@olang_loc_68a62456ab789a64_c90c032bbba18c8 = external constant [0 x i8]
@olang_loc_95e0a8f1123dd6ca_6df17d64d17059fe = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
@olang_loc_5b1407f703b7271d_53185d392c7421d9 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H58d460568d59c9f3a36f8d9425118a1c(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fscope_2eregionLocal(ptr %v0, ptr %a0)
@olang_loc_9797cac8d61c1573_9128cc3b478a4c7f = external constant [0 x i8]
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparamIndex(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparamBinding(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, { i64, ptr } %a3)
@olang_loc_5143053d218562e2_13c44612613aa94e = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2fscope_2ethroughElemExpr(ptr %v0, ptr %a0)
@olang_loc_cad6ea40519e9749_ea608eb2fc6ab735 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisStruct(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efieldMark(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ectorParamIndex(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_fb66d6a098581c09_2fd4002f8136e06d = external constant [0 x i8]
@olang_loc_cd1d16db8329fc51_df7e5714e2c1cec5 = external constant [0 x i8]
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartsTerm(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fscope_2ethroughElem(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
@olang_loc_4a18cd046f6561ba_7ee6763527d0100e = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflPlaceRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_c246bc7b7189f7e5_d655903db3304939 = external constant [0 x i8]
@olang_loc_eb63e604b2611290_41d83017cc1dec3c = external constant [0 x i8]
@olang_loc_6c6eb04d68cfd0ef_192fcc26ed37d7ab = external constant [0 x i8]
@olang_loc_1040a80ff621ce40_8920315fc4c3ab44 = external constant [0 x i8]
declare { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_eb97c951d9e697cc_139ecfedaca533c8 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_e2ea0fea769db7e4_aa8c1e0e7de89fc8 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallBuilds(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i1 @compiler_2ftyped_2eScopedCall(ptr %v0, ptr %a0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efnFresh(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_2daf47a1d2ffcaba_d6a7daf55d290cb6 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_23c81803d40008f7_62b49cfbea8bbbfb = external constant [0 x i8]
declare %"compiler/scope:Val" @compiler_2fscope_2eexisting({ i64, [2 x i64] } %a0)
@olang_loc_3e5632f45eefd04_2819d69fa7782c38 = external constant [0 x i8]
@olang_loc_754a4fe24afb426a_2a858937208e2b6e = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreParam(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_4f09217bbbe73e28_17ebc948c6ad3e44 = external constant [0 x i8]
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eorder(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, { i64, [2 x i64] } %a2)
@G_2ecompiler_2fscope_2eHolds = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@olang_loc_dd2a7e97808fa897_95cc897457ffa94b = external constant [0 x i8]
@olang_loc_622a2f7e184bdd9a_1d72d3d4653d26a6 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
@olang_loc_1ae8b7943ba83321_5c259e314454f08d = external constant [0 x i8]
@olang_loc_298102a92201c9c7_d2c28c3c337e3c3b = external constant [0 x i8]
@olang_loc_1a9ca456c0fc4f74_b6b9f556459eb628 = external constant [0 x i8]
@olang_loc_2a6344a0ea169f03_937c8368e559d747 = external constant [0 x i8]
@olang_loc_61c41c23c6ba3b82_8b9b0b538ad52716 = external constant [0 x i8]
@olang_loc_b9c5758278fbc269_f38d2c0a467d6fd = external constant [0 x i8]
@olang_loc_8672b56b87660cf0_1560bce2a415882c = external constant [0 x i8]
@olang_loc_e498d93abb20b61c_9a7977ea577c2990 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare i1 @compiler_2fscope_2eisNameChar(i8 %a0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisNullLit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estaticLiteral(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_13609328335a5af4_71f6842a5be0a9a0 = external constant [0 x i8]
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/msgs:Msg" %a3)
@olang_loc_2a83bf20490fb4f0_b79be661c23cb1e4 = external constant [0 x i8]
@olang_loc_28967cbbf3bb5881_fc5c9419ee26cbd5 = external constant [0 x i8]
@olang_loc_e2b2a689ed5c2c6a_2e02b8bd326f399e = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eRoleCtor = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
@olang_loc_9f5a8ccf03b4db04_630c918a623736e8 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eloopElement(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_f8891e21139a6c8c_91dd882c9f718fa8 = external constant [0 x i8]
@olang_loc_7cb574562870c9ae_44cb25218e79651a = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteBindingWhere(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisMethodCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eindexCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeName(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eresultVarOf(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_a5d7ffc0375a2adf_b8092e4cba9985db = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteMakeWhere(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnsubst(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i32 %a3)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eYield(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFunc(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_b5bb9adcdc2b0f40_ee4aa96e819ebaec = external constant [0 x i8]
@olang_loc_dc99584e852f79f1_8cdbb8da6d334485 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDeclareWhere(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esummed(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %a0)
declare %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargOfVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eocExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i1 %a3)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eocBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i1 %a3)
@olang_loc_a3d67bab0a0a1a9_82466bf787f25fd = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eocStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i1 %a3)
@olang_loc_b076c1f6c97c7ed4_fcdcfd5688cdce70 = external constant [0 x i8]
@olang_loc_623296b25c4a2534_fd3f86d02d068538 = external constant [0 x i8]
@olang_loc_954f6d28b3a52ac3_ffd2f75d7c0d3157 = external constant [0 x i8]
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eEncloses(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elastName(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
@olang_loc_55e48b5186b67064_d8bb62a12b763a18 = external constant [0 x i8]
@olang_loc_c23f661bef127e16_c2f6e67eaac9a38a = external constant [0 x i8]
@olang_loc_d1f10cb62dc90d37_b8521a3eafe7cb = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2earenaValue(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estorageTerm(ptr %v0, ptr %a0)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eresultTerm(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_a48607f77104f946_b5a91344bffd8f22 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteResBind(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreThrough(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eresultMark(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2fscope_2eFitReturn = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efit(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1, { i64, [2 x i64] } %a2, i1 %a3, ptr %a4, i64 %a5)
@olang_loc_3199956179aa6dd4_40cdc1669d0af040 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eSetAt_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hdd18cd18fee7da2cefbfd21396944747(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eReplay(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/scope:fnUse" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnUse_3e_2eAt_3ccompiler_2fscope_3afnUse_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnUse_3e_2ePush_3ccompiler_2fscope_3afnUse_3e(ptr %v0, ptr %a0, %"compiler/scope:fnUse" %a1)
declare %"compiler/scope:Gap" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aGap_3e_2eAt_3ccompiler_2fscope_3aGap_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aGap_3e_2ePush_3ccompiler_2fscope_3aGap_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/scope:Gap" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_Hda4ef06466535e66801340e999dad217(ptr %v0, ptr %a0)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H87a29777ccf22aa2985fa9d3c61f9cd3(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i1 %a2)
declare i64 @compiler_2fscope_2eflRoot(ptr %v0, ptr %a0)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlDrop(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
@olang_loc_dba8079c89f8629e_846fd2cd4d9758c2 = external constant [0 x i8]
@olang_loc_dbab6e035b5797c_e736089fb75e21e0 = external constant [0 x i8]
@olang_loc_207e75e919c85f37_93e6eeba566436db = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleRooted(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esolePlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
@olang_loc_df5619edc5954020_95eed2e83037cdb4 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleBorrow(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleStrictBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleStrictStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleArm(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
@olang_loc_80a42f326454c431_eaf1445ab36ad4e5 = external constant [0 x i8]
@olang_loc_fdb46d1d9262e41a_919c32215229332e = external constant [0 x i8]
@olang_loc_3a379002e95ffe1b_e75bb6252129afef = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edecide(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, { i64, ptr } %a3, i64 %a4)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecapturingLambda(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisAdapter(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_894def51c550c10b_edf695233d65cd0f = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etempTerm(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eframeHere(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eLen__H22c160154c8542d83ffe3c77c98973d0(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eAt_3ccompiler_2ftyped_3aLvalue_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_8bfac37a1f29704b_1a5bb9d5b57da78f = external constant [0 x i8]
@olang_loc_5042ae5260cf85f5_3d2bef1206874e11 = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekTerm(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisBlock(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
@olang_loc_9d778c78f7953c66_3314afc5257f7cda = external constant [0 x i8]
@olang_loc_b5bf758209bf0a7b_bacb7224757f2cdf = external constant [0 x i8]
@olang_loc_f8a0ade9f5ab7564_a569fa0439998a48 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etransientNow(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_3af8b11586f6b4c8_66242c1d15d5a764 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i64 %a4)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2euePlace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i64 %a4)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueBlock(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i64 %a4)
@olang_loc_32fd86c1b7051b0e_a69c29150a84755a = external constant [0 x i8]
@olang_loc_8d68968aaddcddfb_f2a5e0e2182efbaf = external constant [0 x i8]
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efieldDecl(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewant(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_eb4644f0af45390e_1376074f3833ad62 = external constant [0 x i8]
@olang_loc_d7bea1f8c4fc6c43_c97bd86ee0afa2f7 = external constant [0 x i8]
@olang_loc_e9d57cf77a66352c_e30832457df38478 = external constant [0 x i8]
@olang_loc_aab467fd51570cd7_b7c12dbd63ae1fe3 = external constant [0 x i8]
@olang_loc_f7b7284e8bdb42c_7d0460b025534e78 = external constant [0 x i8]
@olang_loc_1335909b8009e6b8_227574ff00a357c4 = external constant [0 x i8]
@olang_loc_18ba62b867b30c89_62dfd3c940fee6b5 = external constant [0 x i8]
@olang_loc_17d76cd793972dc1_67ead0b5b2d60e3d = external constant [0 x i8]
@olang_loc_b150ba266c9424e3_527b6225611e1947 = external constant [0 x i8]
@olang_loc_30366b1ce1cb05a4_de371b7365ebcc00 = external constant [0 x i8]
@olang_loc_8ae797379831bd51_629aae10c041c6e5 = external constant [0 x i8]
declare i1 @compiler_2fscope_2esamePlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_54cb93a6de18c312_16e8d0818733306 = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
